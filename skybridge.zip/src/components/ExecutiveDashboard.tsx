/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Airport, Route, PortfolioAsset } from "../types";
import { AlertTriangle, ArrowUpRight, Shield, Award, Layers, TrendingUp, Anchor, Activity } from "lucide-react";

interface Props {
  airports: Airport[];
  routes: Route[];
  portfolio: PortfolioAsset[];
  warnings: string[];
  connectivityScore: number;
}

export default function ExecutiveDashboard({ airports, routes, portfolio, warnings, connectivityScore }: Props) {
  // Compute High-Level Metrics
  const totalDomesticPassengers = airports.reduce((acc, curr) => acc + curr.annual_passengers, 0);
  const avgUtilisation = airports.reduce((acc, curr) => acc + curr.utilisation, 0) / airports.length;
  
  // Growth Airports (e.g. expansion potential = high, current utilisation > 75%)
  const topGrowth = airports.filter((a) => a.expansion_potential === "High" && a.utilisation > 0.75);

  const totalCapitalDeployed = portfolio.reduce((acc, curr) => acc + curr.capitalDeployed, 0);
  const avgPortfolioIRR = portfolio.reduce((acc, curr) => acc + curr.expectedIRR * (curr.capitalDeployed / totalCapitalDeployed), 0);

  // Strategic stats
  const sovereignHubsCount = airports.filter((a) => a.strategic_importance === "Sovereign Hub").length;

  return (
    <div id="executive-dashboard-container" className="space-y-6">
      {/* Platform Title Section */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-[#E5E7EB] pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">SKYBRIDGE™</h1>
          <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">National Infrastructure OS / Executive View</p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center gap-2 bg-[#F1F5F9] px-3 py-1.5 rounded-sm border border-[#E5E7EB]">
          <Shield className="w-3.5 h-3.5 text-blue-600" />
          <span className="text-[10px] font-mono text-gray-600 font-semibold tracking-wider">ELLAN VANNIN WEALTH PORTFOLIO SECURED</span>
        </div>
      </div>

      {/* Warning/Alert Board */}
      {warnings.length > 0 && (
        <div className="bg-red-50 border-l-2 border-red-500 p-4 rounded-r-sm">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-4 w-4 text-red-500" />
            </div>
            <div className="ml-3">
              <h3 className="text-xs font-bold text-red-800 uppercase tracking-wider">Operational Risk Triggers Active</h3>
              <div className="mt-2 text-[11px] text-red-700 space-y-1 font-mono">
                {warnings.map((w, idx) => (
                  <p key={idx}>• {w}</p>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* KPI 1 */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm flex flex-col justify-between">
          <div>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2 font-bold">Domestic Passengers</p>
            <h3 className="text-2xl font-light text-[#1A1A1A]">
              {(totalDomesticPassengers / 1000000).toFixed(2)}<span className="text-sm text-gray-400 ml-1">M</span>
            </h3>
          </div>
          <div className="mt-3 h-1 w-full bg-gray-100 rounded-full">
            <div className="h-1 bg-black rounded-full" style={{ width: "75%" }}></div>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm flex flex-col justify-between">
          <div>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2 font-bold">Avg Terminal Utilisation</p>
            <h3 className="text-2xl font-light text-[#1A1A1A]">
              {(avgUtilisation * 100).toFixed(1)}<span className="text-sm text-gray-400 ml-1">%</span>
            </h3>
          </div>
          <div className="mt-3 h-1 w-full bg-gray-100 rounded-full">
            <div className="h-1 bg-blue-600 rounded-full" style={{ width: `${avgUtilisation * 100}%` }}></div>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm flex flex-col justify-between">
          <div>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2 font-bold">National Connectivity</p>
            <h3 className="text-2xl font-light text-[#1A1A1A]">
              {connectivityScore.toFixed(1)}<span className="text-sm text-gray-400 ml-1">/100</span>
            </h3>
          </div>
          <div className="mt-3 flex items-center text-[10px] text-green-600 font-bold">
            <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" /> +0.4% Target
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm flex flex-col justify-between">
          <div>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-2 font-bold">Asset Deployed Stake</p>
            <h3 className="text-2xl font-light text-[#1A1A1A]">
              £{totalCapitalDeployed.toFixed(1)}<span className="text-sm text-gray-400 ml-1">M</span>
            </h3>
          </div>
          <div className="mt-3 text-[10px] text-gray-400 font-mono uppercase tracking-wider">
            Expected IRR: {avgPortfolioIRR.toFixed(1)}%
          </div>
        </div>
      </div>

      {/* Secondary Row: Growth list & exposure */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Growth Centers */}
        <div className="bg-white border border-[#E5E7EB] rounded-sm flex flex-col lg:col-span-2">
          <div className="px-5 py-4 border-b border-[#E5E7EB] flex justify-between items-center">
            <h4 className="text-[11px] uppercase font-bold tracking-widest text-[#0F172A]">Top Capacity & Investment Priorities</h4>
            <span className="text-[10px] text-gray-400 font-mono">[ STRATEGIC EXPANSION ]</span>
          </div>
          
          <div className="flex-1 p-0 flex flex-col divide-y divide-gray-100">
            {topGrowth.slice(0, 4).map((apt) => (
              <div key={apt.code} className="p-4 flex justify-between items-center hover:bg-gray-50/50 transition-colors">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-black border border-gray-200 px-1.5 py-0.5 bg-gray-50 rounded-sm">
                      {apt.code}
                    </span>
                    <span className="text-xs font-semibold text-gray-800">{apt.name}</span>
                  </div>
                  <p className="text-[10px] text-gray-400">Region: {apt.region} • Asset Value: £{apt.estimated_asset_value}M</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-[#1A1A1A]">{(apt.utilisation * 100).toFixed(0)}%</p>
                  <p className="text-[9px] text-blue-600 uppercase tracking-tighter font-medium">Utilisation</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Ellan Vannin Assets */}
        <div className="bg-white border border-[#E5E7EB] rounded-sm flex flex-col">
          <div className="px-5 py-4 border-b border-[#E5E7EB]">
            <h4 className="text-[11px] uppercase font-bold tracking-widest text-[#0F172A]">Portfolio Exposure</h4>
          </div>
          <div className="flex-1 p-5 space-y-4">
            {portfolio.map((asset) => (
              <div key={asset.code} className="border-b border-gray-100 pb-3 last:border-0 last:pb-0">
                <div className="flex items-center justify-between text-xs font-semibold text-gray-800">
                  <span>{asset.name}</span>
                  <span className="text-black font-mono">£{asset.currentValue}M</span>
                </div>
                <div className="flex justify-between items-center text-[10px] text-gray-400 mt-1 font-mono">
                  <span>Equity: {asset.equityOwnership}%</span>
                  <span>Target IRR: {asset.expectedIRR}%</span>
                </div>
                <div className="w-full bg-gray-100 h-1 rounded-full mt-2 overflow-hidden">
                  <div 
                    className="bg-black h-full rounded-full" 
                    style={{ width: `${(asset.currentValue / totalCapitalDeployed) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Infrastructure Sovereign Principles Card */}
      <div className="bg-white border border-[#E5E7EB] p-6 rounded-sm">
        <h3 className="text-[10px] font-bold uppercase tracking-widest text-blue-600">Core Infrastructure Operational Philosophy</h3>
        <h2 className="text-lg font-light text-[#0F172A] mt-2">UK Regional Connectivity as a National Utility</h2>
        <p className="text-xs text-gray-500 mt-2 leading-relaxed max-w-3xl">
          Sovereign state modeling prioritises structural regional resilience, terminal utilization, and
          route economics over short-term ticket margin exploitation. Under the Isle of Man (Ronaldsway) framework, 
          civil transport networks are guarded as national infrastructure assets.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-6 border-t border-gray-100 pt-6">
          <div>
            <span className="text-[10px] text-gray-400 uppercase tracking-wider block font-medium">Sovereign Hubs</span>
            <span className="text-xl font-light text-[#1A1A1A]">{sovereignHubsCount}</span>
          </div>
          <div>
            <span className="text-[10px] text-gray-400 uppercase tracking-wider block font-medium">Active Corridors</span>
            <span className="text-xl font-light text-[#1A1A1A]">{routes.length}</span>
          </div>
          <div>
            <span className="text-[10px] text-gray-400 uppercase tracking-wider block font-medium">Asset Value Pool</span>
            <span className="text-xl font-light text-[#1A1A1A]">£36.7B</span>
          </div>
          <div>
            <span className="text-[10px] text-gray-400 uppercase tracking-wider block font-medium">Sovereign Control</span>
            <span className="text-xl font-semibold text-blue-600">SECURED</span>
          </div>
        </div>
      </div>
    </div>
  );
}
