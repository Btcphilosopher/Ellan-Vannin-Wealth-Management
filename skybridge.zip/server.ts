/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { initialAirports } from "./src/data/airports";
import { initialRoutes } from "./src/data/routes";
import { initialConnectivityScores, initialDigitalTwins, ellanVanninPortfolio } from "./src/data/others";

// Set up in-memory mock databases pre-seeded with our realistic UK aviation data
let airports = [...initialAirports];
let routes = [...initialRoutes];
let connectivityScores = [...initialConnectivityScores];
let digitalTwins = [...initialDigitalTwins];
let portfolio = [...ellanVanninPortfolio];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // ==================== REST API ENDPOINTS ====================

  // Module 1: Airport Register APIs
  app.get("/api/airports", (req, res) => {
    res.json(airports);
  });

  app.post("/api/airports", (req, res) => {
    const newAirport = req.body;
    const index = airports.findIndex((a) => a.code === newAirport.code);
    if (index > -1) {
      airports[index] = { ...airports[index], ...newAirport };
    } else {
      airports.push(newAirport);
    }
    res.json({ success: true, airport: newAirport });
  });

  app.delete("/api/airports/:code", (req, res) => {
    const { code } = req.params;
    airports = airports.filter((a) => a.code !== code);
    res.json({ success: true, message: `Airport ${code} deleted` });
  });

  // Module 2: Route Engine APIs
  app.get("/api/routes", (req, res) => {
    res.json(routes);
  });

  app.post("/api/routes", (req, res) => {
    const newRoute = req.body;
    const index = routes.findIndex((r) => r.id === newRoute.id);
    if (index > -1) {
      routes[index] = { ...routes[index], ...newRoute };
    } else {
      routes.push(newRoute);
    }
    res.json({ success: true, route: newRoute });
  });

  app.delete("/api/routes/:id", (req, res) => {
    const { id } = req.params;
    routes = routes.filter((r) => r.id !== id);
    res.json({ success: true, message: `Route ${id} removed` });
  });

  // Module 5: National Connectivity Index APIs
  app.get("/api/connectivity", (req, res) => {
    // Dynamically calculate accessibility score updates if airports or routes have changed
    const scoreMap = connectivityScores.map((score) => {
      // Find matching airports in this region
      const regionalAirports = airports.filter((a) => a.region.toLowerCase().includes(score.region.toLowerCase()) || score.region.toLowerCase().includes(a.region.toLowerCase()));
      let multiplier = 1.0;
      if (regionalAirports.length > 0) {
        // Average utilisation affects regional connection quality
        const avgUtil = regionalAirports.reduce((acc, curr) => acc + curr.utilisation, 0) / regionalAirports.length;
        if (avgUtil > 0.90) multiplier = 0.92; // Congestion reduces effectiveness
        else if (avgUtil < 0.30) multiplier = 0.85; // Low frequency reduces index
      }
      return {
        ...score,
        overallIndex: Math.round(score.overallIndex * multiplier),
      };
    });
    res.json(scoreMap);
  });

  // Module 6: Digital Twin APIs
  app.get("/api/digital-twin/:code", (req, res) => {
    const { code } = req.params;
    const twin = digitalTwins.find((t) => t.airportCode === code);
    if (twin) {
      res.json(twin);
    } else {
      // Return a default mock structure for uninitialized digital twins
      res.json({
        airportCode: code,
        terminalsCount: 1,
        gatesCount: 6,
        taxiwaysCount: 2,
        runwaysCount: 1,
        aircraftStands: 10,
        maintenanceFacilities: 1,
        terminalUtilisation: 50,
        runwayUtilisation: 35,
        gateUtilisation: 45,
        maintenanceSchedule: [
          { asset: "Runway Inspection", lastChecked: "2026-05-01", nextScheduled: "2026-09-01", status: "Optimal" },
        ],
      });
    }
  });

  // Module 9: Portfolio Analytics APIs
  app.get("/api/portfolio", (req, res) => {
    res.json(portfolio);
  });

  // Module 10: Scenario Simulator API
  app.post("/api/scenario-simulate", (req, res) => {
    const params = req.body; // { newRunwayAt, terminalExpansionAt, additionalRoutes, demandShift, fuelPriceMultiplier, closedAirports }
    
    // Process impact on current in-memory simulation states
    const simulatedAirports = airports.map((apt) => {
      let u = apt.utilisation;
      let capacity = apt.terminal_capacity;
      let pax = apt.annual_passengers;
      let val = apt.estimated_asset_value;

      // Close airport
      if (params.closedAirports && params.closedAirports.includes(apt.code)) {
        return {
          ...apt,
          annual_passengers: 0,
          annual_movements: 0,
          utilisation: 0,
          utilisationStatus: "CLOSED",
        };
      }

      // Fuel prices shift demand downward or increase fares
      const demandMultiplier = params.demandShift * (params.fuelPriceMultiplier > 1.15 ? 0.90 : 1.0);
      pax = Math.round(pax * demandMultiplier);

      if (params.newRunwayAt === apt.code) {
        // Runway expansion decreases utilisation tension and boosts asset value
        u = Math.max(0.3, u - 0.15);
        val += 80.0;
      }
      if (params.terminalExpansionAt === apt.code) {
        capacity = Math.round(capacity * 1.35);
        val += 50.0;
        u = Math.max(0.3, u - 0.10);
      }

      // Re-calculate utilisation
      u = Math.min(1.0, pax / capacity);

      return {
        ...apt,
        annual_passengers: pax,
        terminal_capacity: capacity,
        utilisation: parseFloat(u.toFixed(2)),
        estimated_asset_value: parseFloat(val.toFixed(1)),
      };
    });

    // Determine expected warnings
    const warnings: string[] = [];
    if (params.fuelPriceMultiplier > 1.2) {
      warnings.push("High fuel overheads are depressing IRR yields on thin regional corridors.");
    }
    if (params.closedAirports && params.closedAirports.length > 0) {
      warnings.push(`Sovereign risk trigger: Core regional links fragmented by closure of ${params.closedAirports.join(", ")}.`);
    }

    res.json({
      success: true,
      airports: simulatedAirports,
      warnings,
      expectedIRR: params.fuelPriceMultiplier > 1.2 ? 6.8 : 8.9,
    });
  });

  // Module 12: Rust Architecture Explorer - Fetch files from filesystem
  app.get("/api/rust-code", (req, res) => {
    try {
      const rustFiles = [
        { path: "Cargo.toml", label: "Cargo.toml" },
        { path: "src/main.rs", label: "src/main.rs" },
        { path: "src/models.rs", label: "src/models.rs" },
        { path: "src/db.rs", label: "src/db.rs" },
        { path: "src/engine.rs", label: "src/engine.rs" },
        { path: "src/forecast.rs", label: "src/forecast.rs" },
        { path: "src/api.rs", label: "src/api.rs" },
      ];

      const explorerData = rustFiles.map((f) => {
        const fullPath = path.join(process.cwd(), "rust_src", f.path);
        let content = "// Error reading file content";
        if (fs.existsSync(fullPath)) {
          content = fs.readFileSync(fullPath, "utf-8");
        }
        return {
          filename: f.label,
          path: f.path,
          content,
        };
      });

      res.json(explorerData);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Module 13: Report Generation Endpoint
  app.post("/api/reports/generate", (req, res) => {
    const { reportType, scope } = req.body;
    
    // Compile a professional executive memo based on current metrics
    const timestamp = new Date().toLocaleDateString("en-GB", {
      year: "numeric", month: "long", day: "numeric"
    });

    let content = "";
    if (reportType === "executive") {
      content = `
========================================================================
             SKYBRIDGE™ DOMESTIC AVIATION INFRASTRUCTURE REPORT
========================================================================
Prepared for: Ellan Vannin Wealth Management Investment Committee
Date: ${timestamp}
Classification: CONFIDENTIAL / SOVEREIGN-GRADE BRIEFING

1. EXECUTIVE SUMMARY
UK regional connectivity represents vital national infrastructure, acting as 
a critical driver of regional GDP and systemic resilience. Evaluating airports
as infrastructure assets reveals a highly fragmented landscape of high-performance 
hubs and constrained regional lifelines.

2. ASSET PORTFOLIO HIGHLIGHTS
- Total Capital Deployed: £220.2M
- Expected System Portfolio IRR: 8.9%
- Strategic Asset Highlight: Isle of Man (Ronaldsway) Airport Leasehold (45% Equity)
  Ronaldsway acts as a critical Irish Sea lifeline with 820K annual passenger loads 
  and a current connectivity score of 82.

3. STRATEGIC ALLOCATION RECOMMENDATIONS
- Prioritise terminal extensions at Manchester (MAN) and Edinburgh (EDI).
- Safeguard Cardiff (CWL) and Inverness (INV) thin-routes via structured Public 
  Service Obligation (PSO) capital allocation models rather than commercial fare hikes.
      `;
    } else {
      content = `
========================================================================
             SKYBRIDGE™ COMPARATIVE AIRPORT PERFORMANCE SUMMARY
========================================================================
Prepared for: Ellan Vannin Wealth Management Portfolio Analytics Group
Date: ${timestamp}

Compare Scope: ${scope || "System-Wide Commercial UK Airports"}

Summary Metrics:
- High-Utilisation Threshold (>80%): LHR, LGW, MAN, EDI, LBA, NCL
- Sovereign Hub Asset Value Leaders: Heathrow (£16.8B), Gatwick (£6.2B), Manchester (£3.8B)
- Vulnerability Heatmap: Scotland Highlands & Islands and Isle of Man present the
  highest reliance on domestic flights for civil connectivity, with low rail and road access scores.
      `;
    }

    res.json({
      success: true,
      filename: `Skybridge_Report_${reportType}_${new Date().toISOString().slice(0,10)}.txt`,
      content,
      generatedAt: timestamp,
    });
  });

  // ==================== VITE ENGINE INTEGRATION ====================

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
