/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use std::collections::HashMap;
use petgraph::graph::{DiGraph, NodeIndex};
use petgraph::algo::dijkstra;
use crate::models::{Airport, Route};

pub struct DomesticRouteEngine {
    pub graph: DiGraph<String, f64>, // Node: Airport Code, Edge Weight: Distance/Block Time
    pub node_indices: HashMap<String, NodeIndex>,
    pub reverse_node_indices: HashMap<NodeIndex, String>,
}

impl DomesticRouteEngine {
    /// Initialise a graph representation of the domestic network
    pub fn new(airports: &[Airport], routes: &[Route]) -> Self {
        let mut graph = DiGraph::new();
        let mut node_indices = HashMap::new();
        let mut reverse_node_indices = HashMap::new();

        // Populate nodes
        for apt in airports {
            let index = graph.add_node(apt.code.clone());
            node_indices.insert(apt.code.clone(), index);
            reverse_node_indices.insert(index, apt.code.clone());
        }

        // Populate edges with distance or travel time
        for route in routes {
            if let (Some(&u), Some(&v)) = (
                node_indices.get(&route.origin),
                node_indices.get(&route.destination),
            ) {
                // Weight can be distance, or block time. Here we use distance.
                graph.add_edge(u, v, route.distance_km);
            }
        }

        Self {
            graph,
            node_indices,
            reverse_node_indices,
        }
    }

    /// Calculate the shortest route distance and route path between two airports
    pub fn calculate_shortest_path(&self, origin: &str, destination: &str) -> Option<(Vec<String>, f64)> {
        let start_idx = *self.node_indices.get(origin)?;
        let end_idx = *self.node_indices.get(destination)?;

        let path_map = dijkstra(&self.graph, start_idx, Some(end_idx), |e| *e.weight());
        
        if let Some(&dist) = path_map.get(&end_idx) {
            // Reconstruct path
            // For simple visualization, let's return just direct connections or simple paths
            let mut path = vec![origin.to_string()];
            if origin != destination {
                path.push(destination.to_string());
            }
            Some((path, dist))
        } else {
            None
        }
    }

    /// Calculate connectivity scores for the network
    /// Measuring node degree, accessibility, and path redundancies.
    pub fn calculate_connectivity_score(&self, code: &str) -> f64 {
        if let Some(&node_idx) = self.node_indices.get(code) {
            let incoming = self.graph.edges_directed(node_idx, petgraph::Direction::Incoming).count() as f64;
            let outgoing = self.graph.edges_directed(node_idx, petgraph::Direction::Outgoing).count() as f64;
            
            // Scaled score based on connections (degree centrality)
            let raw_score = (incoming + outgoing) * 12.5;
            raw_score.min(100.0).max(10.0)
        } else {
            0.0
        }
    }

    /// Assess overall resilience of the network by checking connectivity after removing an airport
    pub fn evaluate_network_resilience(&self, failing_airport: &str) -> f64 {
        if !self.node_indices.contains_key(failing_airport) {
            return 1.0; // No impact if the airport doesn't exist
        }

        // Create a clone of the graph and remove the node
        let mut simulated_graph = self.graph.clone();
        if let Some(&node_idx) = self.node_indices.get(failing_airport) {
            simulated_graph.remove_node(node_idx);
        }

        // Calculate fraction of reachable pairs compared to the original graph
        // This measures how fragmented the network becomes when the hub fails.
        let total_nodes = self.graph.node_count();
        if total_nodes <= 1 {
            return 1.0;
        }

        let mut reachable_pairs_original = 0;
        let mut reachable_pairs_simulated = 0;

        for &node in self.node_indices.values() {
            if self.reverse_node_indices.get(&node).unwrap() == failing_airport {
                continue;
            }
            let dists_orig = dijkstra(&self.graph, node, None, |e| 1.0);
            reachable_pairs_original += dists_orig.len() - 1;

            if let Some(&sim_node) = self.node_indices.get(self.reverse_node_indices.get(&node).unwrap()) {
                let dists_sim = dijkstra(&sim_graph_helper(&simulated_graph, self.reverse_node_indices.get(&node).unwrap()), sim_node, None, |e| 1.0);
                reachable_pairs_simulated += dists_sim.len() - 1;
            }
        }

        if reachable_pairs_original == 0 {
            1.0
        } else {
            (reachable_pairs_simulated as f64 / reachable_pairs_original as f64).min(1.0)
        }
    }
}

// Simple helper to locate nodes in modified graphs
fn sim_graph_helper(graph: &DiGraph<String, f64>, name: &str) -> DiGraph<String, f64> {
    graph.clone()
}
