/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};
use sqlx::FromRow;

#[derive(Debug, Serialize, Deserialize, Clone, FromRow)]
pub struct Airport {
    pub code: String,
    pub name: String,
    pub region: String,
    pub runway_length_m: i32,
    pub terminal_capacity: i64,
    pub annual_passengers: i64,
    pub annual_movements: i64,
    pub utilisation: f64,
    pub estimated_asset_value: f64, // GBP millions
    pub cargo_throughput_tonnes: i64,
    pub ownership: String,
    pub expansion_potential: String, // Low, Medium, High
    pub strategic_importance: String, // Sovereign Hub, Regional Critical, Local Connective
}

#[derive(Debug, Serialize, Deserialize, Clone, FromRow)]
pub struct Route {
    pub id: String,
    pub origin: String,
    pub destination: String,
    pub distance_km: f64,
    pub frequency_weekly: i32,
    pub average_fare: f64,
    pub operating_cost_hour: f64,
    pub passenger_demand_annual: i64,
    pub average_load_factor: f64,
    pub block_time_mins: i32,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ConnectivityScore {
    pub region: String,
    pub domestic_flights_score: f64,
    pub rail_connectivity_score: f64,
    pub motorway_access_score: f64,
    pub ferry_access_score: f64,
    pub overall_index: f64,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct DigitalTwinInfrastructure {
    pub airport_code: String,
    pub terminals_count: i32,
    pub gates_count: i32,
    pub taxiways_count: i32,
    pub runways_count: i32,
    pub aircraft_stands: i32,
    pub maintenance_facilities: i32,
    pub terminal_utilisation: f64,
    pub runway_utilisation: f64,
    pub gate_utilisation: f64,
}

#[derive(Debug, Serialize, Deserialize, Clone, FromRow)]
pub struct PortfolioAsset {
    pub code: String,
    pub name: String,
    pub capital_deployed: f64, // GBP millions
    pub equity_ownership: f64, // percentage (e.g., 45.0)
    pub current_value: f64, // GBP millions
    pub expected_irr: f64, // percentage
    pub acquisition_date: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ScenarioSimulatorParams {
    pub new_runway_at: Option<String>,
    pub terminal_expansion_at: Option<String>,
    pub additional_routes: Vec<String>,
    pub demand_shift: f64, // e.g. 1.15 (+15%)
    pub fuel_price_multiplier: f64, // e.g. 1.25 (+25%)
    pub closed_airports: Vec<String>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ScenarioSimulatorResult {
    pub impacted_airports: Vec<Airport>,
    pub system_connectivity_score: f64,
    pub average_system_utilisation: f64,
    pub expected_portfolio_irr: f64,
    pub alert_warnings: Vec<String>,
}
