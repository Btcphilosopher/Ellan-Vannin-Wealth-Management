/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use sqlx::{PgPool, Error};
use crate::models::{Airport, Route, PortfolioAsset};

pub struct Database {
    pub pool: PgPool,
}

impl Database {
    /// Initialise connection pool to the sovereign PostgreSQL database
    pub async fn new(database_url: &str) -> Result<Self, Error> {
        let pool = PgPool::connect(database_url).await?;
        Ok(Self { pool })
    }

    /// Create tables and indexes on application boot (Migration schema)
    pub async fn run_migrations(&self) -> Result<(), Error> {
        // Commercial Airport Register Table
        sqlx::query(
            r#"
            CREATE TABLE IF NOT EXISTS airports (
                code VARCHAR(10) PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                region VARCHAR(100) NOT NULL,
                runway_length_m INT NOT NULL,
                terminal_capacity BIGINT NOT NULL,
                annual_passengers BIGINT NOT NULL,
                annual_movements BIGINT NOT NULL,
                utilisation DOUBLE PRECISION NOT NULL,
                estimated_asset_value DOUBLE PRECISION NOT NULL,
                cargo_throughput_tonnes BIGINT NOT NULL,
                ownership VARCHAR(100) NOT NULL,
                expansion_potential VARCHAR(20) NOT NULL,
                strategic_importance VARCHAR(50) NOT NULL
            );
            "#
        )
        .execute(&self.pool)
        .await?;

        // Domestic Routes Table
        sqlx::query(
            r#"
            CREATE TABLE IF NOT EXISTS routes (
                id VARCHAR(30) PRIMARY KEY,
                origin VARCHAR(10) REFERENCES airports(code),
                destination VARCHAR(10) REFERENCES airports(code),
                distance_km DOUBLE PRECISION NOT NULL,
                frequency_weekly INT NOT NULL,
                average_fare DOUBLE PRECISION NOT NULL,
                operating_cost_hour DOUBLE PRECISION NOT NULL,
                passenger_demand_annual BIGINT NOT NULL,
                average_load_factor DOUBLE PRECISION NOT NULL,
                block_time_mins INT NOT NULL
            );
            "#
        )
        .execute(&self.pool)
        .await?;

        // Portfolio Analytics Table
        sqlx::query(
            r#"
            CREATE TABLE IF NOT EXISTS portfolio_assets (
                code VARCHAR(10) PRIMARY KEY REFERENCES airports(code),
                name VARCHAR(100) NOT NULL,
                capital_deployed DOUBLE PRECISION NOT NULL,
                equity_ownership DOUBLE PRECISION NOT NULL,
                current_value DOUBLE PRECISION NOT NULL,
                expected_irr DOUBLE PRECISION NOT NULL,
                acquisition_date DATE NOT NULL
            );
            "#
        )
        .execute(&self.pool)
        .await?;

        Ok(())
    }

    /// Retrieve allcommercial airports
    pub async fn fetch_all_airports(&self) -> Result<Vec<Airport>, Error> {
        let airports = sqlx::query_as::<_, Airport>("SELECT * FROM airports ORDER BY annual_passengers DESC")
            .fetch_all(&self.pool)
            .await?;
        Ok(airports)
    }

    /// Insert or update an airport record
    pub async fn upsert_airport(&self, airport: &Airport) -> Result<(), Error> {
        sqlx::query(
            r#"
            INSERT INTO airports (
                code, name, region, runway_length_m, terminal_capacity, 
                annual_passengers, annual_movements, utilisation, 
                estimated_asset_value, cargo_throughput_tonnes, ownership, 
                expansion_potential, strategic_importance
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
            ON CONFLICT (code) DO UPDATE SET
                name = EXCLUDED.name,
                region = EXCLUDED.region,
                runway_length_m = EXCLUDED.runway_length_m,
                terminal_capacity = EXCLUDED.terminal_capacity,
                annual_passengers = EXCLUDED.annual_passengers,
                annual_movements = EXCLUDED.annual_movements,
                utilisation = EXCLUDED.utilisation,
                estimated_asset_value = EXCLUDED.estimated_asset_value,
                cargo_throughput_tonnes = EXCLUDED.cargo_throughput_tonnes,
                ownership = EXCLUDED.ownership,
                expansion_potential = EXCLUDED.expansion_potential,
                strategic_importance = EXCLUDED.strategic_importance;
            "#
        )
        .bind(&airport.code)
        .bind(&airport.name)
        .bind(&airport.region)
        .bind(airport.runway_length_m)
        .bind(airport.terminal_capacity)
        .bind(airport.annual_passengers)
        .bind(airport.annual_movements)
        .bind(airport.utilisation)
        .bind(airport.estimated_asset_value)
        .bind(airport.cargo_throughput_tonnes)
        .bind(&airport.ownership)
        .bind(&airport.expansion_potential)
        .bind(&airport.strategic_importance)
        .execute(&self.pool)
        .await?;

        Ok(())
    }

    /// Fetch routes
    pub async fn fetch_all_routes(&self) -> Result<Vec<Route>, Error> {
        let routes = sqlx::query_as::<_, Route>("SELECT * FROM routes")
            .fetch_all(&self.pool)
            .await?;
        Ok(routes)
    }
}
