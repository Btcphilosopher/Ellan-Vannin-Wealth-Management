/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use axum::{
    routing::{get, post},
    extract::{State, Path, Json},
    response::IntoResponse,
    Router,
};
use std::sync::Arc;
use crate::models::{Airport, Route, ScenarioSimulatorParams, ScenarioSimulatorResult};
use crate::db::Database;
use crate::engine::DomesticRouteEngine;

pub struct AppState {
    pub db: Option<Database>,
    // In-memory fallbacks for development / test configurations
    pub airports: Vec<Airport>,
    pub routes: Vec<Route>,
}

pub fn create_router(state: Arc<AppState>) -> Router {
    Router::new()
        .route("/api/airports", get(get_airports).post(upsert_airport))
        .route("/api/routes", get(get_routes))
        .route("/api/connectivity", get(get_connectivity_metrics))
        .route("/api/simulate-scenario", post(simulate_scenario))
        .with_state(state)
}

// Handler to fetch commercial UK airports
async fn get_airports(State(state): State<Arc<AppState>>) -> impl IntoResponse {
    if let Some(db) = &state.db {
        match db.fetch_all_airports().await {
            Ok(apts) => Json(apts).into_response(),
            Err(e) => (axum::http::StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response()
        }
    } else {
        // Fallback to in-memory datasets for sandbox previews
        Json(&state.airports).into_response()
    }
}

// Handler to insert or update an airport record
async fn upsert_airport(
    State(state): State<Arc<AppState>>,
    Json(payload): Json<Airport>,
) -> impl IntoResponse {
    if let Some(db) = &state.db {
        match db.upsert_airport(&payload).await {
            Ok(_) => (axum::http::StatusCode::OK, "Airport synchronized").into_response(),
            Err(e) => (axum::http::StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response()
        }
    } else {
        (axum::http::StatusCode::NOT_IMPLEMENTED, "Write requires PostgreSQL connection").into_response()
    }
}

// Handler to fetch domestic aviation route records
async fn get_routes(State(state): State<Arc<AppState>>) -> impl IntoResponse {
    if let Some(db) = &state.db {
        match db.fetch_all_routes().await {
            Ok(rts) => Json(rts).into_response(),
            Err(e) => (axum::http::StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response()
        }
    } else {
        Json(&state.routes).into_response()
    }
}

// Handler to compute regional connectivity index
async fn get_connectivity_metrics(State(state): State<Arc<AppState>>) -> impl IntoResponse {
    let engine = DomesticRouteEngine::new(&state.airports, &state.routes);
    let mut results = std::collections::HashMap::new();
    
    for apt in &state.airports {
        let score = engine.calculate_connectivity_score(&apt.code);
        results.insert(apt.code.clone(), score);
    }
    
    Json(results)
}

// Handler to simulate aviation infrastructure scenario
async fn simulate_scenario(
    State(state): State<Arc<AppState>>,
    Json(payload): Json<ScenarioSimulatorParams>,
) -> impl IntoResponse {
    let engine = DomesticRouteEngine::new(&state.airports, &state.routes);
    
    let base_connectivity = 74.5; // Average baseline
    let mut sys_utilisation = 0.65;
    let mut expected_irr = 8.2;
    let mut warnings = Vec::new();

    // Model demand shift effects
    sys_utilisation *= payload.demand_shift;
    if sys_utilisation > 0.95 {
        warnings.push("WARNING: Critical terminal congestion risk. System-wide average utilisation exceeds 95%.".to_string());
    }

    // Model fuel price constraints on routes
    if payload.fuel_price_multiplier > 1.20 {
        warnings.push("ALERT: Fuel prices up >20%. Regional thin-routes at risk of operational suspension.".to_string());
        expected_irr -= 1.5;
    }

    // Model airport closure scenarios and check resilience
    for closed in &payload.closed_airports {
        let resilience = engine.evaluate_network_resilience(closed);
        if resilience < 0.90 {
            warnings.push(format!("CRITICAL: Closure of {} creates severe network fragmentation. System resilience degraded to {:.1}%", closed, resilience * 100.0));
        }
    }

    let result = ScenarioSimulatorResult {
        impacted_airports: state.airports.clone(),
        system_connectivity_score: base_connectivity * payload.demand_shift,
        average_system_utilisation: sys_utilisation,
        expected_portfolio_irr: expected_irr,
        alert_warnings: warnings,
    };

    Json(result)
}
