/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use std::sync::Arc;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

mod models;
mod db;
mod engine;
mod forecast;
mod api;

#[tokio::main]
async fn main() {
    // Initialise structured logging using tracing-subscriber
    tracing_subscriber::registry()
        .with(tracing_subscriber::fmt::layer())
        .init();

    tracing::info!("Starting SKYBRIDGE™ Domestic Aviation Operating System Core Core...");

    // Connect to PostgreSQL database using environment variables
    let database_url = std::env::var("DATABASE_URL")
        .unwrap_or_else(|_| "postgresql://postgres:postgres@localhost:5432/skybridge".to_string());

    tracing::info!("Connecting to sovereign database cluster...");
    
    let db_connection = match db::Database::new(&database_url).await {
        Ok(db) => {
            tracing::info!("Successfully connected to PostgreSQL database cluster.");
            if let Err(e) = db.run_migrations().await {
                tracing::error!("Database schema migration failed: {:?}", e);
            } else {
                tracing::info!("Database schemas & table constraints verified.");
            }
            Some(db)
        }
        Err(e) => {
            tracing::warn!("Database cluster offline, running in read-only sandbox mode: {:?}", e);
            None
        }
    };

    // Instantiate in-memory datasets for local state and sandbox resilience evaluations
    let state = Arc::new(api::AppState {
        db: db_connection,
        airports: Vec::new(), // Initialised at runtime
        routes: Vec::new(),    // Initialised at runtime
    });

    // Configure the Axum HTTP routing server
    let app = api::create_router(state);

    let port = std::env::var("PORT")
        .unwrap_or_else(|_| "3000".to_string())
        .parse::<u16>()
        .unwrap_or(3000);

    let addr = std::net::SocketAddr::from(([0, 0, 0, 0], port));
    tracing::info!("Sovereign service listening on: http://{}", addr);

    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
