/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use polars::prelude::*;
use rayon::prelude::*;
use crate::models::Airport;

#[derive(Debug, serde::Serialize, serde::Deserialize, Clone)]
pub struct ForecastPoint {
    pub year: i32,
    pub scenario: String, // Baseline, Optimistic, Downside
    pub projected_passengers: i64,
    pub projected_cargo_tonnes: f64,
}

pub struct PassengerForecaster;

impl PassengerForecaster {
    /// Generates a 10-year demand projection using macroeconomic indicators
    pub fn generate_projection(
        airport: &Airport,
        gdp_growth_baseline: f64, // e.g., 0.018 for 1.8%
        tourism_multiplier: f64,
        population_growth: f64,
    ) -> Vec<ForecastPoint> {
        let years = vec![2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035];
        
        // Parallelize scenario modeling using Rayon
        let scenarios = vec!["Baseline", "Optimistic", "Downside"];
        
        scenarios.into_par_iter().flat_map(|scenario| {
            let mut results = Vec::new();
            let mut current_pax = airport.annual_passengers as f64;
            let mut current_cargo = airport.cargo_throughput_tonnes as f64;

            let (gdp_rate, tourism_rate) = match scenario {
                "Optimistic" => (gdp_growth_baseline + 0.015, tourism_multiplier * 1.2),
                "Downside" => (gdp_growth_baseline - 0.02, tourism_multiplier * 0.7),
                _ => (gdp_growth_baseline, tourism_multiplier),
            };

            for &year in &years {
                // Compound growth rate combining GDP, tourism, and population
                let combined_growth = (gdp_rate * 0.5) + (population_growth * 0.3) + ((tourism_rate - 1.0) * 0.2);
                current_pax *= 1.0 + combined_growth;
                current_cargo *= 1.0 + (gdp_rate * 0.8); // Cargo is tightly coupled to GDP

                results.push(ForecastPoint {
                    year,
                    scenario: scenario.to_string(),
                    projected_passengers: current_pax as i64,
                    projected_cargo_tonnes: current_cargo,
                });
            }
            results
        }).collect()
    }

    /// Convert raw forecast vectors into a Polars DataFrame for advanced analytical rollups
    pub fn analytical_rollup(points: &[ForecastPoint]) -> Result<DataFrame, PolarsError> {
        let years: Vec<i32> = points.iter().map(|p| p.year).collect();
        let scenarios: Vec<String> = points.iter().map(|p| p.scenario.clone()).collect();
        let passengers: Vec<i64> = points.iter().map(|p| p.projected_passengers).collect();
        let cargo: Vec<f64> = points.iter().map(|p| p.projected_cargo_tonnes).collect();

        let s_year = Series::new("Year".into(), years);
        let s_scenario = Series::new("Scenario".into(), scenarios);
        let s_pax = Series::new("Passengers".into(), passengers);
        let s_cargo = Series::new("Cargo".into(), cargo);

        let df = DataFrame::new(vec![s_year, s_scenario, s_pax, s_cargo])?;
        Ok(df)
    }
}
