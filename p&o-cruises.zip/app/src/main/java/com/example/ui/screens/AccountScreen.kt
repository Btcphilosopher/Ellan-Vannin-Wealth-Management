package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransactionEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.CruiseViewModel

@Composable
fun AccountScreen(viewModel: CruiseViewModel) {
    val cruiseState by viewModel.cruiseState.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val booking by viewModel.booking.collectAsState()

    val scrollState = rememberScrollState()

    // Spending statistics calculations
    val totalSpent = transactions.sumOf { it.amount }
    val remainingCredit = ((cruiseState?.onboardCredit ?: 250.0) - totalSpent).coerceAtLeast(0.0)
    val balanceDue = (totalSpent - (cruiseState?.onboardCredit ?: 250.0)).coerceAtLeast(0.0)

    // Category calculation
    val diningSpent = transactions.filter { it.category == "Dining" }.sumOf { it.amount }
    val drinksSpent = transactions.filter { it.category == "Drinks" }.sumOf { it.amount }
    val excursionsSpent = transactions.filter { it.category == "Excursions" }.sumOf { it.amount }
    val spaSpent = transactions.filter { it.category == "Spa" }.sumOf { it.amount }
    val shoppingSpent = transactions.filter { it.category == "Shopping" }.sumOf { it.amount }
    val otherSpent = transactions.filter { it.category == "Other" }.sumOf { it.amount }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "ONBOARD ACCOUNT STATEMENT",
            style = MaterialTheme.typography.titleMedium,
            color = TextSecondaryMuted,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // Spending Balance Overview Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = NavyPrimary)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("TOTAL SPENT", color = LightCardBg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("£${"%.2f".format(totalSpent)}", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("ONBOARD CREDIT (OBC)", color = LightCardBg, fontSize = 11.sp)
                        Text("£${"%.2f".format(cruiseState?.onboardCredit ?: 250.0)}", color = AccentGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = NavySecondary)
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("OBC REMAINING", color = LightCardBg, fontSize = 11.sp)
                        Text("£${"%.2f".format(remainingCredit)}", color = if (remainingCredit > 0) AccentGold else Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("BALANCE DUE CASHLESS", color = LightCardBg, fontSize = 11.sp)
                        Text("£${"%.2f".format(balanceDue)}", color = if (balanceDue > 0) AlertWarning else Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Custom Proportional spending segmented Bar drawn with Canvas
        Text(
            text = "SPENDING ANALYTICS BY CATEGORY",
            style = MaterialTheme.typography.labelLarge,
            color = NavySecondary,
            fontWeight = FontWeight.Bold
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Drawing Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasWidth = size.width
                        val canvasHeight = size.height

                        val total = if (totalSpent == 0.0) 1.0 else totalSpent

                        // Proportions
                        val diningPct = (diningSpent / total).toFloat()
                        val drinksPct = (drinksSpent / total).toFloat()
                        val excursionsPct = (excursionsSpent / total).toFloat()
                        val spaPct = (spaSpent / total).toFloat()
                        val shoppingPct = (shoppingSpent / total).toFloat()
                        val otherPct = (otherSpent / total).toFloat()

                        // Color schemes
                        val cDining = Color(0xFF0F4C81)
                        val cDrinks = Color(0xFFF5A623)
                        val cExcursions = Color(0xFF4A90E2)
                        val cSpa = Color(0xFF50E3C2)
                        val cShopping = Color(0xFFB8E986)
                        val cOther = Color(0xFF9B9B9B)

                        if (totalSpent == 0.0) {
                            // Draw empty state grey bar
                            drawRoundRect(
                                color = Color.LightGray,
                                size = Size(canvasWidth, canvasHeight),
                                cornerRadius = CornerRadius(12f, 12f)
                            )
                        } else {
                            var currentX = 0f

                            // Dining
                            if (diningPct > 0) {
                                val w = canvasWidth * diningPct
                                drawRect(color = cDining, topLeft = Offset(currentX, 0f), size = Size(w, canvasHeight))
                                currentX += w
                            }
                            // Drinks
                            if (drinksPct > 0) {
                                val w = canvasWidth * drinksPct
                                drawRect(color = cDrinks, topLeft = Offset(currentX, 0f), size = Size(w, canvasHeight))
                                currentX += w
                            }
                            // Excursions
                            if (excursionsPct > 0) {
                                val w = canvasWidth * excursionsPct
                                drawRect(color = cExcursions, topLeft = Offset(currentX, 0f), size = Size(w, canvasHeight))
                                currentX += w
                            }
                            // Spa
                            if (spaPct > 0) {
                                val w = canvasWidth * spaPct
                                drawRect(color = cSpa, topLeft = Offset(currentX, 0f), size = Size(w, canvasHeight))
                                currentX += w
                            }
                            // Shopping
                            if (shoppingPct > 0) {
                                val w = canvasWidth * shoppingPct
                                drawRect(color = cShopping, topLeft = Offset(currentX, 0f), size = Size(w, canvasHeight))
                                currentX += w
                            }
                            // Other
                            if (otherPct > 0) {
                                val w = canvasWidth * otherPct
                                drawRect(color = cOther, topLeft = Offset(currentX, 0f), size = Size(w, canvasHeight))
                            }
                        }
                    }
                }

                // Legend layout with amounts
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LegendItem("Dining", diningSpent, Color(0xFF0F4C81))
                    LegendItem("Drinks", drinksSpent, Color(0xFFF5A623))
                    LegendItem("Shore Excursions", excursionsSpent, Color(0xFF4A90E2))
                    LegendItem("Spa Treatments", spaSpent, Color(0xFF50E3C2))
                    LegendItem("Shopping", shoppingSpent, Color(0xFFB8E986))
                    LegendItem("Other Services", otherSpent, Color(0xFF9B9B9B))
                }
            }
        }

        // Peninsular Club Loyalty Card
        Text(
            text = "PENINSULAR CLUB LOYALTY",
            style = MaterialTheme.typography.labelLarge,
            color = NavySecondary,
            fontWeight = FontWeight.Bold
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = booking?.loyaltyTier ?: "Mediterranean Blue",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Text(
                        text = "${booking?.loyaltyPoints ?: 180} pts",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = AccentGold
                    )
                }
                Text(
                    "You are on tier 3 of the P&O Peninsular Club. Loyalty benefits active on board include: 10% shop discounts, complimentary laundry service, priority disembarkation and invitations to the Captain's Cocktail Reception.",
                    fontSize = 12.sp,
                    color = TextSecondaryMuted
                )
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { ((booking?.loyaltyPoints ?: 180) / 300f).coerceAtMost(1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = AccentGold,
                    trackColor = LightCardBg
                )
                Text("300 points required to unlock 'Pacific Ruby' Loyalty Tier", fontSize = 10.sp, color = TextSecondaryMuted)
            }
        }

        // Future Cruise discovery
        Text(
            text = "DISCOVER FUTURE CRUISES",
            style = MaterialTheme.typography.labelLarge,
            color = NavySecondary,
            fontWeight = FontWeight.Bold
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Book Your Next Journey On Board", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NavyPrimary)
                Text("Reserve a future sailing while on board to secure double Peninsular loyalty points and £100 onboard credit bonus for your next cruise.", fontSize = 12.sp, color = TextSecondaryMuted)

                Card(colors = CardDefaults.cardColors(containerColor = LightCardBg)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Caribbean Sunrise Cruise - Arvia", fontWeight = FontWeight.Bold, color = NavyPrimary)
                        Text("Barbados • St Lucia • Antigua • Grenada", fontSize = 11.sp, color = TextSecondaryMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("14 Nights • Nov 2026", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text("From £1,120 pp", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NavySecondary)
                        }
                    }
                }
            }
        }

        // List Transactions
        Text(
            text = "RECENT TRANSACTIONS",
            style = MaterialTheme.typography.labelLarge,
            color = NavySecondary,
            fontWeight = FontWeight.Bold
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (transactions.isEmpty()) {
                    Text("No transactions found.", color = TextSecondaryMuted)
                } else {
                    for (tx in transactions) {
                        TransactionRowItem(tx)
                        Divider(color = LightCardBg)
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun LegendItem(label: String, value: Double, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(color, RoundedCornerShape(2.dp))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(label, fontSize = 13.sp, color = TextPrimaryDark)
        }
        Text("£${"%.2f".format(value)}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimaryDark)
    }
}

@Composable
fun TransactionRowItem(tx: TransactionEntity) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(tx.description, fontWeight = FontWeight.Bold, color = NavyPrimary, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(tx.category, fontSize = 11.sp, color = AccentGold, fontWeight = FontWeight.Bold)
                Text("Day ${tx.dayNumber}", fontSize = 11.sp, color = TextSecondaryMuted)
            }
        }
        Text(
            text = if (tx.amount < 0) "-£${"%.2f".format(-tx.amount)}" else "£${"%.2f".format(tx.amount)}",
            fontWeight = FontWeight.Bold,
            color = if (tx.amount < 0) SafeGreen else TextPrimaryDark,
            fontSize = 14.sp
        )
    }
}
