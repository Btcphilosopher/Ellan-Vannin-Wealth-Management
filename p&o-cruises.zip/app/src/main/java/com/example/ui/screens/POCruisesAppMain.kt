package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.example.data.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.CruiseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun POCruisesAppMain(viewModel: CruiseViewModel) {
    val currentTab by viewModel.currentSelectedTab.collectAsState()
    val cruiseState by viewModel.cruiseState.collectAsState()
    val unreadNotificationsCount by viewModel.unreadNotificationsCount.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val simStep by viewModel.simulationStep.collectAsState()

    var showNotificationsDialog by remember { mutableStateOf(false) }
    var showConciergeSheet by remember { mutableStateOf(false) }

    // List of Simulation Steps labels
    val simStepsLabels = listOf(
        "Day 1: Pre-Cruise Prep (12 Days Out)",
        "Day 1: At Southampton Terminal 4",
        "Day 1: Passenger Welcomed On Board",
        "Day 1: Sailaway (18.5 kts)",
        "Day 2: Sea Day (Bay of Biscay)",
        "Day 3: Arrived Vigo, Spain (Docked)",
        "Day 3: Vigo All-Aboard Alert (17:00)",
        "Day 4: Arrived Lisbon, Portugal",
        "Day 4: Lisbon Outbound (Evening Diner Queue)",
        "Day 7: Arrived Malaga, Spain",
        "Day 9: Arrived Barcelona, Spain",
        "Day 12: Southampton (Disembarkation)",
        "Post-Cruise: Voyage History & Loyalty"
    )

    Scaffold(
        topBar = {
            Column(modifier = Modifier.background(NavyPrimary)) {
                // Main Branding Header
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = "P&O CRUISES",
                            color = AccentGold,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp,
                            fontSize = 20.sp
                        )
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = NavyPrimary
                    ),
                    actions = {
                        IconButton(onClick = { showNotificationsDialog = true }) {
                            BadgedBox(
                                badge = {
                                    if (unreadNotificationsCount > 0) {
                                        Badge(containerColor = AlertWarning) {
                                            Text(unreadNotificationsCount.toString(), color = Color.White)
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Notifications,
                                    contentDescription = "Notifications",
                                    tint = AccentGold
                                )
                            }
                        }
                    }
                )

                // Interactive SIMULATION CONTROL CENTRE (CRITICAL FOR DEMO MODE)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = NavySecondary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "DEMONSTRATION SIMULATOR",
                                    fontSize = 10.sp,
                                    color = AccentGold,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = simStepsLabels.getOrNull(simStep) ?: "Scenario",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { viewModel.advanceSimulation() },
                                    colors = ButtonDefaults.buttonColors(containerColor = AccentGold),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("Next Step", color = NavyPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { viewModel.resetSimulation() },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("Reset", fontSize = 11.sp)
                                }
                            }
                        }

                        // Operational state indicators
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (cruiseState?.isCruiseStarted == true) SafeGreen else AccentGold)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Phase: ${cruiseState?.currentPhase ?: "BOOKED"}",
                                    fontSize = 11.sp,
                                    color = LightCardBg,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = "GPS: ${"%.4f".format(cruiseState?.lat ?: 50.9097)}, ${"%.4f".format(cruiseState?.lng ?: -1.4044)}",
                                fontSize = 11.sp,
                                color = LightCardBg,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = NavyPrimary,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == "HOME",
                    onClick = { viewModel.selectTab("HOME") },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NavyPrimary,
                        selectedTextColor = AccentGold,
                        unselectedIconColor = LightCardBg.copy(alpha = 0.6f),
                        unselectedTextColor = LightCardBg.copy(alpha = 0.6f),
                        indicatorColor = AccentGold
                    )
                )
                NavigationBarItem(
                    selected = currentTab == "MY_CRUISE",
                    onClick = { viewModel.selectTab("MY_CRUISE") },
                    icon = { Icon(Icons.Default.Anchor, contentDescription = "My Cruise") },
                    label = { Text("My Cruise", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NavyPrimary,
                        selectedTextColor = AccentGold,
                        unselectedIconColor = LightCardBg.copy(alpha = 0.6f),
                        unselectedTextColor = LightCardBg.copy(alpha = 0.6f),
                        indicatorColor = AccentGold
                    )
                )
                NavigationBarItem(
                    selected = currentTab == "EXPLORE",
                    onClick = { viewModel.selectTab("EXPLORE") },
                    icon = { Icon(Icons.Default.Explore, contentDescription = "Explore") },
                    label = { Text("Explore", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NavyPrimary,
                        selectedTextColor = AccentGold,
                        unselectedIconColor = LightCardBg.copy(alpha = 0.6f),
                        unselectedTextColor = LightCardBg.copy(alpha = 0.6f),
                        indicatorColor = AccentGold
                    )
                )
                NavigationBarItem(
                    selected = currentTab == "MY_DAY",
                    onClick = { viewModel.selectTab("MY_DAY") },
                    icon = { Icon(Icons.Default.EventNote, contentDescription = "My Day") },
                    label = { Text("My Day", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NavyPrimary,
                        selectedTextColor = AccentGold,
                        unselectedIconColor = LightCardBg.copy(alpha = 0.6f),
                        unselectedTextColor = LightCardBg.copy(alpha = 0.6f),
                        indicatorColor = AccentGold
                    )
                )
                NavigationBarItem(
                    selected = currentTab == "ACCOUNT",
                    onClick = { viewModel.selectTab("ACCOUNT") },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Account") },
                    label = { Text("Account", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NavyPrimary,
                        selectedTextColor = AccentGold,
                        unselectedIconColor = LightCardBg.copy(alpha = 0.6f),
                        unselectedTextColor = LightCardBg.copy(alpha = 0.6f),
                        indicatorColor = AccentGold
                    )
                )
            }
        },
        floatingActionButton = {
            // Floating button to invoke AI CONCIERGE CHAT
            FloatingActionButton(
                onClick = { showConciergeSheet = true },
                containerColor = NavyPrimary,
                contentColor = AccentGold,
                shape = CircleShape,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "P&O AI Concierge Assistant",
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                "HOME" -> HomeScreen(viewModel)
                "MY_CRUISE" -> MyCruiseScreen(viewModel)
                "EXPLORE" -> ExploreScreen(viewModel)
                "MY_DAY" -> MyDayScreen(viewModel)
                "ACCOUNT" -> AccountScreen(viewModel)
            }
        }
    }

    // AI Concierge Bottom Sheet Panel
    if (showConciergeSheet) {
        ModalBottomSheet(
            onDismissRequest = { showConciergeSheet = false },
            containerColor = MaterialTheme.colorScheme.background,
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight(0.75f)
                    .fillMaxWidth()
            ) {
                ConciergeScreen(viewModel)
            }
        }
    }

    // Notifications Dialog
    if (showNotificationsDialog) {
        AlertDialog(
            onDismissRequest = { showNotificationsDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("App Notifications", color = NavyPrimary, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { viewModel.clearAllNotifications() }) {
                        Text("Clear All", color = AlertWarning, fontSize = 12.sp)
                    }
                }
            },
            text = {
                Box(modifier = Modifier.height(300.dp)) {
                    if (notifications.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No new notifications.", color = TextSecondaryMuted)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(notifications) { nt ->
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (nt.isEmergency) AlertWarning.copy(alpha = 0.05f) else LightCardBg
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = nt.title,
                                            fontWeight = FontWeight.Bold,
                                            color = if (nt.isEmergency) AlertWarning else NavyPrimary,
                                            fontSize = 14.sp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = nt.message,
                                            color = TextPrimaryDark,
                                            fontSize = 12.sp,
                                            lineHeight = 16.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.markAllNotificationsAsRead()
                        showNotificationsDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("Close", color = Color.White)
                }
            }
        )
    }
}
