package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ActivityEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.CruiseViewModel

@Composable
fun ExploreScreen(viewModel: CruiseViewModel) {
    val activeCategory by viewModel.currentSelectedExploreCategory.collectAsState()
    val activities by viewModel.activities.collectAsState()
    val cruiseState by viewModel.cruiseState.collectAsState()
    val queueJoined by viewModel.virtualQueueJoined.collectAsState()
    val queuePosition by viewModel.virtualQueuePosition.collectAsState()
    val queueWait by viewModel.virtualQueueWaitMinutes.collectAsState()
    val queueVenue by viewModel.virtualQueueVenue.collectAsState()

    val context = LocalContext.current

    // Dialog state
    var selectedActivityForDetails by remember { mutableStateOf<ActivityEntity?>(null) }
    var conflictMessageToShow by remember { mutableStateOf<String?>(null) }

    val filteredActivities = activities.filter { it.category == activeCategory }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "DISCOVER ACTIVITIES",
            style = MaterialTheme.typography.titleMedium,
            color = TextSecondaryMuted,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // Category Filter Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val categories = listOf(
                "DINING" to "Dining",
                "ENTERTAINMENT" to "Shows",
                "EXCURSION" to "Excursions",
                "SPA" to "Spa",
                "DAILY_PROGRAMME" to "Programme"
            )
            items(categories) { (code, label) ->
                FilterChip(
                    selected = activeCategory == code,
                    onClick = { viewModel.selectExploreCategory(code) },
                    label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NavyPrimary,
                        selectedLabelColor = Color.White,
                        containerColor = Color.White,
                        labelColor = NavyPrimary
                    )
                )
            }
        }

        // Virtual Queue banner for Keel & Cow
        if (activeCategory == "DINING") {
            if (queueJoined) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Virtual Table Queue", color = AccentGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(queueVenue, color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (queuePosition > 0) "Position: $queuePosition (Est: $queueWait mins)" else "Your Table is Ready!",
                                color = if (queuePosition == 0) AccentGold else LightCardBg,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (queuePosition > 0) {
                                Button(
                                    onClick = { viewModel.advanceRestaurantQueue() },
                                    colors = ButtonDefaults.buttonColors(containerColor = AccentGold),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Sim Step", color = NavyPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            OutlinedButton(
                                onClick = { viewModel.leaveRestaurantQueue() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text(if (queuePosition == 0) "Dismiss" else "Leave", fontSize = 11.sp)
                            }
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("The Keel & Cow Gastro-pub", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NavyPrimary)
                            Text("Seated on a first-come, first-served queue.", fontSize = 12.sp, color = TextSecondaryMuted)
                        }
                        Button(
                            onClick = { viewModel.joinRestaurantQueue("The Keel & Cow") },
                            colors = ButtonDefaults.buttonColors(containerColor = NavySecondary)
                        ) {
                            Text("Join Queue", color = Color.White)
                        }
                    }
                }
            }
        }

        // Main List
        if (filteredActivities.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No activities found.", color = TextSecondaryMuted)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(filteredActivities) { activity ->
                    ActivityListItem(activity = activity) {
                        selectedActivityForDetails = activity
                    }
                }
            }
        }
    }

    // Details Modal Dialog
    selectedActivityForDetails?.let { activity ->
        AlertDialog(
            onDismissRequest = { selectedActivityForDetails = null },
            title = {
                Text(
                    text = activity.title,
                    color = NavyPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = activity.subtitle,
                        fontWeight = FontWeight.SemiBold,
                        color = AccentGold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = activity.description,
                        color = TextPrimaryDark,
                        fontSize = 13.sp
                    )
                    Divider()
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, null, tint = NavySecondary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(activity.location, fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, null, tint = NavySecondary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("${activity.time} (${activity.durationMinutes} mins)", fontSize = 12.sp)
                        }
                    }
                    if (activity.category == "DINING" && activity.allergens.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, null, tint = SafeGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(activity.allergens, fontSize = 12.sp, color = SafeGreen)
                        }
                    }
                    if (activity.category == "EXCURSION") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FitnessCenter, null, tint = NavyPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Activity Level: ${activity.intensity}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("PRICE PER PERSON", fontSize = 11.sp, color = TextSecondaryMuted)
                        Text(
                            text = if (activity.price == 0.0) "Included" else "£${"%.2f".format(activity.price)}",
                            fontWeight = FontWeight.Bold,
                            color = if (activity.price == 0.0) SafeGreen else NavyPrimary,
                            fontSize = 18.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val currentDay = (cruiseState?.currentDayIndex ?: 0) + 1
                        val conflict = viewModel.bookActivity(activity, currentDay, 2)
                        selectedActivityForDetails = null
                        if (conflict != null) {
                            conflictMessageToShow = conflict
                        } else {
                            Toast.makeText(context, "Booking successful!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("Book Now", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedActivityForDetails = null }) {
                    Text("Cancel", color = NavySecondary)
                }
            }
        )
    }

    // Conflict Dialog
    conflictMessageToShow?.let { message ->
        AlertDialog(
            onDismissRequest = { conflictMessageToShow = null },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = AlertWarning, modifier = Modifier.size(36.dp)) },
            title = {
                Text(
                    text = "Scheduling Conflict Detected",
                    color = AlertWarning,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = message,
                    color = TextPrimaryDark,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { conflictMessageToShow = null },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("I Understand", color = Color.White)
                }
            }
        )
    }
}

@Composable
fun ActivityListItem(activity: ActivityEntity, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = activity.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (activity.price == 0.0) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SafeGreen.copy(alpha = 0.1f))
                        ) {
                            Text(
                                "INCLUDED",
                                fontSize = 9.sp,
                                color = SafeGreen,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = activity.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = AccentGold,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Schedule, null, tint = TextSecondaryMuted, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(activity.time, fontSize = 12.sp, color = TextSecondaryMuted)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PinDrop, null, tint = TextSecondaryMuted, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(activity.location.split(",")[0], fontSize = 12.sp, color = TextSecondaryMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = NavySecondary)
        }
    }
}
