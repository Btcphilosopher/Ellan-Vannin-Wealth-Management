package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// P&O Cruises Premium Maritime Palette
val NavyPrimary = Color(0xFF0B2545)      // Elegant Deep Navy Blue
val NavySecondary = Color(0xFF134074)    // Ocean Blue
val AccentGold = Color(0xFFC5A059)       // Warm Sand / Luxury Accent Gold
val WarmBackground = Color(0xFFFAF9F6)   // Warm Alabaster / Off-White
val LightCardBg = Color(0xFFEEF4F8)      // Soft Sea Breeze Blue-Grey
val DarkTwilightBg = Color(0xFF031424)   // Midnight Navy Background
val GoldAccentLight = Color(0xFFD4AF37)  // Bright Gold Highlight
val AlertWarning = Color(0xFFD32F2F)     // Warning red for conflict and "all aboard" alerts
val TextPrimaryDark = Color(0xFF03162C)  // High-contrast deep text
val TextSecondaryMuted = Color(0xFF627D98) // Muted slate text
val SafeGreen = Color(0xFF2E7D32)        // Soft emerald for completed check-ins
