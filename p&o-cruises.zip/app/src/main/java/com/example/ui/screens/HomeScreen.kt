package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CruiseStateEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.CruiseViewModel

@Composable
fun HomeScreen(viewModel: CruiseViewModel) {
    val cruiseState by viewModel.cruiseState.collectAsState()
    val booking by viewModel.booking.collectAsState()
    val reservations by viewModel.reservations.collectAsState()
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Welcome Section
            Text(
                text = "GOOD MORNING, ${booking?.guestName?.uppercase() ?: "PASSENGER"}",
                style = MaterialTheme.typography.titleMedium,
                color = TextSecondaryMuted,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            val phase = cruiseState?.currentPhase ?: "BOOKED"
            when (phase) {
                "BOOKED", "APPROACHING" -> PrepareHomeView(viewModel, cruiseState)
                "AT_TERMINAL" -> TerminalHomeView(viewModel, cruiseState)
                "ON_BOARD" -> OnBoardHomeView(viewModel, cruiseState, reservations.size)
                "IN_PORT" -> PortHomeView(viewModel, cruiseState)
                "RETURN_HOME", "POST_CRUISE" -> ReturnHomeView(viewModel, cruiseState)
            }
            
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// --- BEFORE CRUISE: PREPARE VIEW ---
@Composable
fun PrepareHomeView(viewModel: CruiseViewModel, state: CruiseStateEntity?) {
    // Elegant Cruise Countdown
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NavyPrimary),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Anchor, contentDescription = null, tint = AccentGold, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "IONA • MEDITERRANEAN DISCOVERY",
                style = MaterialTheme.typography.labelLarge,
                color = AccentGold,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CountdownUnit("12", "DAYS")
                Text(":", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                CountdownUnit("04", "HOURS")
                Text(":", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                CountdownUnit("27", "MINS")
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Departing Southampton: 24 Aug 2026",
                style = MaterialTheme.typography.bodyMedium,
                color = LightCardBg
            )
        }
    }

    // Next Action Recommendation
    Text(
        text = "NEXT REQUIRED ACTION",
        style = MaterialTheme.typography.labelLarge,
        color = NavySecondary,
        fontWeight = FontWeight.Bold
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Assignment,
                contentDescription = null,
                tint = NavyPrimary,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (state?.checkInCompleted == false) "Complete Online Check-In" else "Download Boarding Pass",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Text(
                    text = if (state?.checkInCompleted == false) "Upload passport photo & check declarations." else "Access your digital pass offline.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryMuted
                )
            }
            Button(
                onClick = {
                    if (state?.checkInCompleted == false) {
                        viewModel.performCheckIn()
                    } else {
                        viewModel.downloadBoardingPass()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentGold)
            ) {
                Text(if (state?.checkInCompleted == false) "Go" else "Get", color = NavyPrimary, fontWeight = FontWeight.Bold)
            }
        }
    }

    // Pre-cruise Checklist
    Text(
        text = "YOUR PRE-CRUISE CHECKLIST",
        style = MaterialTheme.typography.labelLarge,
        color = NavySecondary,
        fontWeight = FontWeight.Bold
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ChecklistItem("Booking reference confirmed", true)
            ChecklistItem("Guest passport details completed", true)
            ChecklistItem(
                label = "Register credit/debit card",
                isDone = state?.paymentCardAdded == true,
                onActionClick = { viewModel.registerPaymentCard() },
                actionLabel = "Add"
            )
            ChecklistItem(
                label = "Complete online check-in",
                isDone = state?.checkInCompleted == true,
                onActionClick = { viewModel.performCheckIn() },
                actionLabel = "Check-In"
            )
            ChecklistItem(
                label = "Download digital boarding pass",
                isDone = state?.boardingPassDownloaded == true,
                onActionClick = { viewModel.downloadBoardingPass() },
                actionLabel = "Download",
                isEnabled = state?.checkInCompleted == true
            )
        }
    }
}

// --- EMBARKATION AT TERMINAL VIEW ---
@Composable
fun TerminalHomeView(viewModel: CruiseViewModel, state: CruiseStateEntity?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NavyPrimary)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Outlined.CheckCircle, contentDescription = null, tint = AccentGold, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "TODAY IS THE DAY",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Terminal: Southampton Ocean Terminal 4",
                style = MaterialTheme.typography.bodyMedium,
                color = LightCardBg,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Your Boarding Window: 14:00 - 14:30",
                style = MaterialTheme.typography.bodyMedium,
                color = AccentGold,
                fontWeight = FontWeight.Bold
            )
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.QrCode, contentDescription = null, tint = NavyPrimary, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Ready to Board", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NavyPrimary)
                Text("Tap to view your digital boarding pass and luggage tags.", style = MaterialTheme.typography.bodySmall, color = TextSecondaryMuted)
            }
            Button(
                onClick = { viewModel.selectTab("MY_CRUISE") },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
            ) {
                Text("View Pass", color = Color.White)
            }
        }
    }
}

// --- ONBOARD ENJOY VIEW ---
@Composable
fun OnBoardHomeView(viewModel: CruiseViewModel, state: CruiseStateEntity?, reservationCount: Int) {
    // Welcome Banner
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NavyPrimary)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "WELCOME ABOARD IONA",
                style = MaterialTheme.typography.headlineMedium,
                color = AccentGold,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "CABIN C104 IS CLEAN & READY",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                TelemetryItem(Icons.Default.Navigation, "Heading", "South")
                TelemetryItem(Icons.Default.Speed, "Speed", "${state?.speedKts ?: 0.0} kts")
                TelemetryItem(Icons.Default.WbSunny, "Weather", "${state?.weatherTemp ?: 0.0}°C")
            }
        }
    }

    // Safety muster drill highlight if Day 1
    if (state?.currentDayIndex == 0) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AlertWarning.copy(alpha = 0.1f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = AlertWarning, modifier = Modifier.size(32.dp))
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Safety Muster Drill Required", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = AlertWarning)
                    Text("Please report briefly to Muster Station C (Grand Atrium Deck 6) to register your presence.", style = MaterialTheme.typography.bodyMedium, color = TextPrimaryDark)
                }
            }
        }
    }

    // Next Smart Steps
    Text(
        text = "YOUR CRUISE AT A GLANCE",
        style = MaterialTheme.typography.labelLarge,
        color = NavySecondary,
        fontWeight = FontWeight.Bold
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SummaryMiniCard("Dining", "$reservationCount Bookings", Icons.Default.Restaurant, Modifier.weight(1f)) {
            viewModel.selectTab("EXPLORE")
            viewModel.selectExploreCategory("DINING")
        }
        SummaryMiniCard("Entertainment", "Live Shows", Icons.Default.Theaters, Modifier.weight(1f)) {
            viewModel.selectTab("EXPLORE")
            viewModel.selectExploreCategory("ENTERTAINMENT")
        }
    }
}

// --- PORT HOME VIEW ---
@Composable
fun PortHomeView(viewModel: CruiseViewModel, state: CruiseStateEntity?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NavyPrimary)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "YOU ARE IN ${state?.portName?.uppercase()}",
                style = MaterialTheme.typography.headlineMedium,
                color = AccentGold,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "TIME ASHORE REMAINING: 9h 30m",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { 0.7f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp),
                color = AccentGold,
                trackColor = NavySecondary
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsWalk, null, tint = AccentGold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Arrived: 08:00", color = Color.White, fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Alarm, null, tint = AlertWarning)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("All Aboard: 17:30", color = AlertWarning, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Excursion Warning / Safety Box
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AlertWarning.copy(alpha = 0.1f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = AlertWarning, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Return Safety Regulations", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = AlertWarning)
                Text("All guests must be back on board by 17:30. Ship departs promptly at 18:00. P&O-booked shore excursions are guaranteed to wait, but private trips are not.", style = MaterialTheme.typography.bodyMedium, color = TextPrimaryDark)
            }
        }
    }

    // Local Port Info Card
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Port Guide: Lisbon", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NavyPrimary)
            Text("Lisbon features iconic yellow historical trams (Line 28 is famous). Sample Pasteis de Nata at Belém. Card payments are widely accepted, but keep Euros (€) for minor merchants.", style = MaterialTheme.typography.bodyMedium, color = TextSecondaryMuted)
            Divider()
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Emergency Agent", fontWeight = FontWeight.Bold)
                Text("+351 210 000 000", color = NavySecondary)
            }
        }
    }
}

// --- DEPARTURE / FINAL DAY / RETURN VIEW ---
@Composable
fun ReturnHomeView(viewModel: CruiseViewModel, state: CruiseStateEntity?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NavyPrimary)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Home, contentDescription = null, tint = AccentGold, modifier = Modifier.size(40.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "YOUR JOURNEY HOME",
                style = MaterialTheme.typography.headlineMedium,
                color = AccentGold,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Arrived in Southampton ocean terminal.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White
            )
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Disembarkation Instructions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NavyPrimary)
            Text("1. Baggage: Place all heavy luggage outside your cabin door by 23:00 tonight with your RED luggage labels firmly attached.\n\n" +
                 "2. Breakfast: Horizon buffet open 06:00 - 08:30.\n\n" +
                 "3. Cabin Exit: Please vacate your cabin by 08:00.\n\n" +
                 "4. Departure: Proceed to disembarkation hall at 08:15.", style = MaterialTheme.typography.bodyMedium, color = TextSecondaryMuted)
        }
    }
}

// --- REUSABLE SUB-COMPONENTS ---
@Composable
fun CountdownUnit(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = AccentGold,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun TelemetryItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = AccentGold, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, color = LightCardBg, fontSize = 11.sp)
        Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ChecklistItem(
    label: String,
    isDone: Boolean,
    onActionClick: (() -> Unit)? = null,
    actionLabel: String = "",
    isEnabled: Boolean = true
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(
                imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (isDone) SafeGreen else TextSecondaryMuted,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isDone) TextSecondaryMuted else TextPrimaryDark,
                fontWeight = if (isDone) FontWeight.Normal else FontWeight.Medium
            )
        }
        if (!isDone && onActionClick != null) {
            Button(
                onClick = onActionClick,
                enabled = isEnabled,
                colors = ButtonDefaults.buttonColors(containerColor = NavySecondary),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Text(actionLabel, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SummaryMiniCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(icon, contentDescription = null, tint = NavyPrimary)
            Spacer(modifier = Modifier.height(12.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NavyPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondaryMuted)
        }
    }
}
