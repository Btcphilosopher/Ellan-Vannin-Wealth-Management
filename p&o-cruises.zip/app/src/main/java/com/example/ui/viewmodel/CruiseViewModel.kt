package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class CruiseViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CruiseRepository by lazy {
        val database = AppDatabase.getDatabase(application)
        CruiseRepository(database.cruiseDao())
    }

    // --- Screen State ---
    private val _currentSelectedTab = MutableStateFlow("HOME")
    val currentSelectedTab = _currentSelectedTab.asStateFlow()

    private val _currentSelectedExploreCategory = MutableStateFlow("DINING")
    val currentSelectedExploreCategory = _currentSelectedExploreCategory.asStateFlow()

    private val _currentSelectedDayIndex = MutableStateFlow(0) // Day 1-12 (index 0 to 11)
    val currentSelectedDayIndex = _currentSelectedDayIndex.asStateFlow()

    private val _chatInputText = MutableStateFlow("")
    val chatInputText = _chatInputText.asStateFlow()

    private val _isChatResponding = MutableStateFlow(false)
    val isChatResponding = _isChatResponding.asStateFlow()

    // --- Virtual Queue State ---
    private val _virtualQueueJoined = MutableStateFlow(false)
    val virtualQueueJoined = _virtualQueueJoined.asStateFlow()

    private val _virtualQueuePosition = MutableStateFlow(0)
    val virtualQueuePosition = _virtualQueuePosition.asStateFlow()

    private val _virtualQueueWaitMinutes = MutableStateFlow(0)
    val virtualQueueWaitMinutes = _virtualQueueWaitMinutes.asStateFlow()

    private val _virtualQueueVenue = MutableStateFlow("")
    val virtualQueueVenue = _virtualQueueVenue.asStateFlow()

    // --- Expose Repository Flows ---
    val cruiseState: StateFlow<CruiseStateEntity?> = repository.cruiseStateFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val booking: StateFlow<BookingEntity?> = repository.bookingFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val itinerary: StateFlow<List<ItineraryDayEntity>> = repository.itineraryFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activities: StateFlow<List<ActivityEntity>> = repository.activitiesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reservations: StateFlow<List<ReservationEntity>> = repository.allReservationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<TransactionEntity>> = repository.allTransactionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = repository.allNotificationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationsCount: StateFlow<Int> = repository.unreadNotificationsCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val chatMessages: StateFlow<List<ConciergeMessageEntity>> = repository.chatMessagesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Simulation Current Step ---
    private val _simulationStep = MutableStateFlow(0) // 0 to 11
    val simulationStep = _simulationStep.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    // --- Navigation ---
    fun selectTab(tab: String) {
        _currentSelectedTab.value = tab
    }

    fun selectExploreCategory(category: String) {
        _currentSelectedExploreCategory.value = category
    }

    fun selectDayIndex(dayIndex: Int) {
        _currentSelectedDayIndex.value = dayIndex
    }

    fun updateChatInput(text: String) {
        _chatInputText.value = text
    }

    // --- Passenger Pre-Cruise Checklist Actions ---
    fun performCheckIn() {
        viewModelScope.launch {
            val state = repository.getCruiseState() ?: return@launch
            val updated = state.copy(
                checkInCompleted = true,
                currentPhase = "APPROACHING"
            )
            repository.updateCruiseState(updated)

            // Trigger Notification
            repository.addNotification(NotificationEntity(
                id = "NT_CHKIN_COMP",
                title = "Check-In Completed",
                message = "Your passenger details and security declarations are complete! Digital boarding pass is now unlocked.",
                isRead = false
            ))
        }
    }

    fun downloadBoardingPass() {
        viewModelScope.launch {
            val state = repository.getCruiseState() ?: return@launch
            val updated = state.copy(boardingPassDownloaded = true)
            repository.updateCruiseState(updated)

            repository.addNotification(NotificationEntity(
                id = "NT_BP_DOWN",
                title = "Boarding Pass Ready",
                message = "Your digital boarding pass has been saved offline to your device. You are ready to board at the terminal.",
                isRead = false
            ))
        }
    }

    fun registerPaymentCard() {
        viewModelScope.launch {
            val state = repository.getCruiseState() ?: return@launch
            val updated = state.copy(paymentCardAdded = true)
            repository.updateCruiseState(updated)

            repository.addNotification(NotificationEntity(
                id = "NT_CARD_REG",
                title = "Payment Card Registered",
                message = "Visa ending in 4282 registered for automated onboard account billing. Cashless spending active.",
                isRead = false
            ))
        }
    }

    // --- Booking Reservations (with conflicts) ---
    // Returns conflict warning message if any, or null if successful
    fun bookActivity(activity: ActivityEntity, dayNum: Int, partySz: Int): String? {
        val currentReservations = reservations.value
        val activityTimeMins = parseTimeToMinutes(activity.time)
        val activityEndMins = activityTimeMins + activity.durationMinutes

        // Check for conflicts on the SAME day
        for (res in currentReservations) {
            if (res.dayNumber == dayNum) {
                val resTimeMins = parseTimeToMinutes(res.time)
                // We estimate pre-existing reservations take 90 minutes by default unless we know better
                val resEndMins = resTimeMins + 90 

                // Overlap check
                val overlaps = (activityTimeMins < resEndMins && activityEndMins > resTimeMins)
                if (overlaps) {
                    return "These bookings overlap. You have '${res.title}' booked at ${res.time} on Day $dayNum. We recommend adjusting times."
                }
            }
        }

        // Complete the reservation
        viewModelScope.launch {
            val resId = "RES_${activity.id}_${System.currentTimeMillis() % 100000}"
            repository.addReservation(ReservationEntity(
                reservationId = resId,
                activityId = activity.id,
                activityType = activity.category,
                title = activity.title,
                time = activity.time,
                pricePaid = activity.price * partySz,
                partySize = partySz,
                location = activity.location,
                dayNumber = dayNum
            ))

            // Update onboard spending state if there's a charge
            if (activity.price > 0.0) {
                val state = repository.getCruiseState() ?: return@launch
                val cost = activity.price * partySz
                val used = state.usedCredit + cost
                val bal = if (used > state.onboardCredit) used - state.onboardCredit else 0.0

                repository.updateCruiseState(state.copy(
                    onboardBalance = bal,
                    usedCredit = used
                ))

                // Post Transaction
                repository.addTransaction(TransactionEntity(
                    id = "TX_${System.currentTimeMillis() % 100000}",
                    description = "${activity.title} (Party of $partySz)",
                    amount = cost,
                    category = when(activity.category) {
                        "DINING" -> "Dining"
                        "SPA" -> "Spa"
                        "EXCURSION" -> "Excursions"
                        else -> "Other"
                    },
                    dayNumber = dayNum
                ))
            }

            // Trigger Notification
            repository.addNotification(NotificationEntity(
                id = "NT_BOOK_${System.currentTimeMillis() % 100000}",
                title = "Booking Confirmed",
                message = "You have successfully booked '${activity.title}' for Day $dayNum at ${activity.time}.",
                isRead = false
            ))
        }
        return null
    }

    fun cancelBooking(res: ReservationEntity) {
        viewModelScope.launch {
            repository.cancelReservation(res.reservationId)

            // Refund from spent credits if applicable
            if (res.pricePaid > 0.0) {
                val state = repository.getCruiseState() ?: return@launch
                val newUsed = (state.usedCredit - res.pricePaid).coerceAtLeast(0.0)
                val newBal = if (newUsed > state.onboardCredit) newUsed - state.onboardCredit else 0.0
                repository.updateCruiseState(state.copy(
                    onboardBalance = newBal,
                    usedCredit = newUsed
                ))

                // Post Refund Transaction
                repository.addTransaction(TransactionEntity(
                    id = "TX_REFUND_${System.currentTimeMillis() % 100000}",
                    description = "Refund: ${res.title}",
                    amount = -res.pricePaid,
                    category = when(res.activityType) {
                        "DINING" -> "Dining"
                        "SPA" -> "Spa"
                        "EXCURSION" -> "Excursions"
                        else -> "Other"
                    },
                    dayNumber = res.dayNumber
                ))
            }

            repository.addNotification(NotificationEntity(
                id = "NT_CANCEL_${System.currentTimeMillis() % 100000}",
                title = "Booking Cancelled",
                message = "Your reservation for '${res.title}' has been cancelled and fully refunded if pre-paid.",
                isRead = false
            ))
        }
    }

    // --- Virtual Queue Seating ---
    fun joinRestaurantQueue(venue: String) {
        _virtualQueueJoined.value = true
        _virtualQueueVenue.value = venue
        _virtualQueuePosition.value = 5
        _virtualQueueWaitMinutes.value = 15

        viewModelScope.launch {
            repository.addNotification(NotificationEntity(
                id = "NT_Q_JOIN",
                title = "Virtual Queue Joined",
                message = "You are in line for '$venue'. Position: 5. We will notify you when your table is ready.",
                isRead = false
            ))
        }
    }

    fun advanceRestaurantQueue() {
        if (_virtualQueueJoined.value) {
            val currPos = _virtualQueuePosition.value
            if (currPos > 1) {
                _virtualQueuePosition.value = currPos - 1
                _virtualQueueWaitMinutes.value = (currPos - 1) * 3
            } else if (currPos == 1) {
                _virtualQueuePosition.value = 0
                _virtualQueueWaitMinutes.value = 0
                viewModelScope.launch {
                    repository.addNotification(NotificationEntity(
                        id = "NT_Q_READY",
                        title = "Table Ready!",
                        message = "Your table at ${_virtualQueueVenue.value} is ready. Please present this screen to the hostess within 10 minutes.",
                        isRead = false
                    ))
                }
            }
        }
    }

    fun leaveRestaurantQueue() {
        _virtualQueueJoined.value = false
        _virtualQueueVenue.value = ""
        _virtualQueuePosition.value = 0
        _virtualQueueWaitMinutes.value = 0
    }

    // --- AI Concierge Chat ---
    fun sendChatPrompt() {
        val prompt = _chatInputText.value.trim()
        if (prompt.isEmpty()) return

        _chatInputText.value = ""
        _isChatResponding.value = true

        viewModelScope.launch {
            // Append User Message
            repository.addChatMessage(prompt, "USER")

            // Gather context to feed the system prompt
            val context = buildSystemContext()

            // Call Gemini service
            val response = GeminiService.generateResponse(prompt, context)

            // Append AI response
            repository.addChatMessage(response, "AI")
            _isChatResponding.value = false
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearChat()
            repository.addChatMessage(
                "Welcome back, Tom! I am your P&O Cruises Concierge on board Iona. Ask me anything about your cruise schedule, restaurant reservations, onboard accounts, or shore excursions.",
                "AI"
            )
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            repository.clearNotifications()
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
        }
    }

    // --- Simulation / Demonstration Engine (12 Scenarios) ---
    fun advanceSimulation() {
        val nextStep = (_simulationStep.value + 1) % 12
        _simulationStep.value = nextStep
        applySimulationStep(nextStep)
    }

    fun resetSimulation() {
        _simulationStep.value = 0
        applySimulationStep(0)
    }

    private fun applySimulationStep(step: Int) {
        viewModelScope.launch {
            val state = repository.getCruiseState() ?: return@launch
            val bookingDetails = repository.getBooking() ?: return@launch
            val days = repository.getAllItinerary()

            when (step) {
                0 -> { // Before embarkation, booking confirmed
                    _currentSelectedDayIndex.value = 0
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 0,
                        isCruiseStarted = false,
                        currentPhase = "BOOKED",
                        lat = 50.9097,
                        lng = -1.4044,
                        speedKts = 0.0,
                        portName = "Southampton",
                        weatherTemp = 18.0,
                        weatherDesc = "Overcast",
                        checkInCompleted = false,
                        boardingPassDownloaded = false,
                        paymentCardAdded = false,
                        onboardBalance = 0.0,
                        usedCredit = 196.0, // Existing seeded reservations cost
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_0",
                        title = "Preparation: 12 Days to Go",
                        message = "Your voyage is approaching! Complete online check-in, set up payments, and book fine dining or excursions to curate your ideal holiday.",
                        isRead = false
                    ))
                }
                1 -> { // At terminal, check-in done, boarding pass downloaded
                    _currentSelectedDayIndex.value = 0
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 0,
                        isCruiseStarted = false,
                        currentPhase = "AT_TERMINAL",
                        portName = "Southampton Terminal 4",
                        checkInCompleted = true,
                        boardingPassDownloaded = true,
                        paymentCardAdded = true,
                        weatherTemp = 20.0,
                        weatherDesc = "Partly Cloudy"
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_1",
                        title = "Embarkation Day: Terminal Active",
                        message = "Welcome to Southampton Ocean Terminal! Please have your physical passport and digital boarding pass QR ready for fast-track boarding.",
                        isRead = false
                    ))
                }
                2 -> { // Boarded, Cabin Ready, Muster drill
                    _currentSelectedDayIndex.value = 0
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 0,
                        isCruiseStarted = true,
                        currentPhase = "ON_BOARD",
                        portName = "Southampton",
                        speedKts = 0.0,
                        weatherTemp = 21.0,
                        weatherDesc = "Sunny"
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_2",
                        title = "Welcome Aboard Iona!",
                        message = "Cabin C104 is clean and ready. Emergency notice: Please proceed to Muster Station C (Grand Atrium) for your brief safety briefing.",
                        isRead = false,
                        isEmergency = true
                    ))
                }
                3 -> { // Sailaway, Southampton to Vigo
                    _currentSelectedDayIndex.value = 0
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 0,
                        isCruiseStarted = true,
                        currentPhase = "ON_BOARD",
                        portName = "Southampton Outbound",
                        speedKts = 18.5,
                        lat = 50.4500,
                        lng = -1.8200,
                        weatherTemp = 19.0,
                        weatherDesc = "Fresh Breeze",
                        seaConditions = "Gentle ripples"
                    ))

                    // Post a sailaway drink charge
                    repository.addTransaction(TransactionEntity(
                        id = "TX_SIM_SAIL",
                        description = "Anderson's Gin & Tonic (Sailaway)",
                        amount = 12.50,
                        category = "Drinks",
                        dayNumber = 1
                    ))

                    val newState = repository.getCruiseState()!!
                    val newUsed = newState.usedCredit + 12.50
                    repository.updateCruiseState(newState.copy(
                        usedCredit = newUsed,
                        onboardBalance = if (newUsed > newState.onboardCredit) newUsed - newState.onboardCredit else 0.0
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_3",
                        title = "Sailing Southampton Water",
                        message = "We have cast off! Join the captain and live band on Deck 16 for the Southampton sailaway toast.",
                        isRead = false
                    ))
                }
                4 -> { // Day 2: Sea Day (Biscay)
                    _currentSelectedDayIndex.value = 1
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 1,
                        isCruiseStarted = true,
                        currentPhase = "ON_BOARD",
                        portName = "At Sea (Bay of Biscay)",
                        speedKts = 21.0,
                        lat = 46.5000,
                        lng = -6.5000,
                        weatherTemp = 17.5,
                        weatherDesc = "Overcast Swells",
                        seaConditions = "Moderate swell"
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_4",
                        title = "Sea Day: Crossing Biscay",
                        message = "Relax on board! The Horizon Thermal Suite on Deck 5 has extended opening hours today. Dress Code tonight: Evening Casual.",
                        isRead = false
                    ))
                }
                5 -> { // Day 3: Arrived Vigo, Spain
                    _currentSelectedDayIndex.value = 2
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 2,
                        isCruiseStarted = true,
                        currentPhase = "IN_PORT",
                        portName = "Vigo, Spain",
                        speedKts = 0.0,
                        lat = 42.2406,
                        lng = -8.7207,
                        weatherTemp = 23.0,
                        weatherDesc = "Beautiful Blue Sky",
                        seaConditions = "Docked Calm"
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_5",
                        title = "Arrived: Vigo, Spain",
                        message = "Local authorities have cleared the vessel. Guests are free to go ashore. All Aboard is strictly at 17:00.",
                        isRead = false
                    ))
                }
                6 -> { // Day 3: Vigo - All Aboard warning
                    _currentSelectedDayIndex.value = 2
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 2,
                        isCruiseStarted = true,
                        currentPhase = "IN_PORT",
                        portName = "Vigo (Docked)",
                        speedKts = 0.0,
                        weatherTemp = 24.5,
                        weatherDesc = "Sunny Afternoon"
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_6",
                        title = "ALL ABOARD WARNING (Vigo)",
                        message = "All guests must return on board Iona. Port departure is in 30 minutes! All-aboard time is 17:00.",
                        isRead = false,
                        isEmergency = true
                    ))
                }
                7 -> { // Day 4: Arrived Lisbon, Portugal
                    _currentSelectedDayIndex.value = 3
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 3,
                        isCruiseStarted = true,
                        currentPhase = "IN_PORT",
                        portName = "Lisbon, Portugal",
                        speedKts = 0.0,
                        lat = 38.7223,
                        lng = -9.1393,
                        weatherTemp = 27.0,
                        weatherDesc = "Bright Sun",
                        seaConditions = "Docked"
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_7",
                        title = "Arrived: Lisbon, Portugal",
                        message = "Sailing past Belém Tower is complete. Lisbon terminal is open. Time Ashore: 9h 30m. Local Currency: EUR.",
                        isRead = false
                    ))
                }
                8 -> { // Day 4: Lisbon - Evening queue
                    _currentSelectedDayIndex.value = 3
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 3,
                        isCruiseStarted = true,
                        currentPhase = "ON_BOARD",
                        portName = "Lisbon Outbound",
                        speedKts = 16.0,
                        lat = 38.2000,
                        lng = -9.3000,
                        weatherTemp = 22.0,
                        weatherDesc = "Clear Night Starry",
                        seaConditions = "Calm Ripples"
                    ))

                    // Join the virtual queue automatically for demonstration
                    joinRestaurantQueue("The Keel & Cow")

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_8",
                        title = "Lisbon Sailaway & Dinner",
                        message = "We have cleared the Tagus River. Join your virtual dining queue to book a prime table tonight.",
                        isRead = false
                    ))
                }
                9 -> { // Day 7: Malaga (Granada) Excursion
                    _currentSelectedDayIndex.value = 6
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 6,
                        isCruiseStarted = true,
                        currentPhase = "IN_PORT",
                        portName = "Malaga, Spain",
                        speedKts = 0.0,
                        lat = 36.7213,
                        lng = -4.4214,
                        weatherTemp = 29.5,
                        weatherDesc = "Very Hot & Sunny",
                        seaConditions = "Docked"
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_9",
                        title = "Arrived: Malaga (Andalusia)",
                        message = "Extended shore day: Ship is docked until 22:00. Shore excursions to Granada and Malaga city have begun departing.",
                        isRead = false
                    ))
                }
                10 -> { // Day 9: Barcelona - Spa booking alert
                    _currentSelectedDayIndex.value = 8
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 8,
                        isCruiseStarted = true,
                        currentPhase = "IN_PORT",
                        portName = "Barcelona, Spain",
                        speedKts = 0.0,
                        lat = 41.3851,
                        lng = 2.1734,
                        weatherTemp = 26.0,
                        weatherDesc = "Sunny Skies"
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_10",
                        title = "Spa Appointment Reminder",
                        message = "Your Elemis Facial appointment at Oasis Spa on Deck 5 starts in 15 minutes. Please arrive 10 minutes early to check-in.",
                        isRead = false
                    ))
                }
                11 -> { // Day 12: Returning Southampton (Disembarkation)
                    _currentSelectedDayIndex.value = 11
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 11,
                        isCruiseStarted = true,
                        currentPhase = "RETURN_HOME",
                        portName = "Southampton Terminal 4",
                        speedKts = 0.0,
                        lat = 50.9097,
                        lng = -1.4044,
                        weatherTemp = 16.0,
                        weatherDesc = "Drizzle",
                        seaConditions = "Docked"
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_11",
                        title = "Disembarkation Active",
                        message = "Welcome back to Southampton. Please proceed to the luggage hall according to your color-coded label at 08:15.",
                        isRead = false
                    ))
                }
                12 -> { // Post-Cruise history & Loyalty progression
                    _currentSelectedDayIndex.value = 11
                    repository.updateCruiseState(state.copy(
                        currentDayIndex = 11,
                        isCruiseStarted = false,
                        currentPhase = "POST_CRUISE",
                        portName = "Southampton",
                        weatherTemp = 15.0,
                        weatherDesc = "Cloudy"
                    ))

                    // Update Loyalty Points to show progression! (Add 12 points for the 12-day cruise)
                    repository.updateBooking(bookingDetails.copy(
                        loyaltyPoints = 192 // 180 + 12 points
                    ))

                    repository.addNotification(NotificationEntity(
                        id = "SIM_NT_12",
                        title = "Thank You For Sailing with P&O Cruises",
                        message = "You have earned 12 Peninsular Club points. Your new balance is 192 points! Check out future cruises to explore more destinations.",
                        isRead = false
                    ))
                }
            }
        }
    }

    private fun parseTimeToMinutes(time: String): Int {
        return try {
            val parts = time.split(":")
            val h = parts[0].toInt()
            val m = parts[1].split(" ")[0].toInt()
            h * 60 + m
        } catch (e: Exception) {
            480 // Default to 08:00
        }
    }

    private fun buildSystemContext(): String {
        val currState = cruiseState.value
        val bookingVal = booking.value
        val resList = reservations.value
        val currentDay = itinerary.value.getOrNull(currState?.currentDayIndex ?: 0)

        val sb = StringBuilder()
        sb.append("Ship: Iona. Cruise: Mediterranean Discovery.\n")
        if (currState != null) {
            sb.append("Current Voyage Day: Day ${currState.currentDayIndex + 1} of 12.\n")
            sb.append("Current Location: ${currState.portName}. Lat/Lng: ${currState.lat}, ${currState.lng}.\n")
            sb.append("Current Status Phase: ${currState.currentPhase}.\n")
            sb.append("Onboard Credit Starting Amount: £${currState.onboardCredit}. Credit Spent: £${currState.usedCredit}. Cash balance due: £${currState.onboardBalance}.\n")
            sb.append("Pre-Cruise Check-In Completed: ${currState.checkInCompleted}. Payment Card Registered: ${currState.paymentCardAdded}.\n")
        }
        if (bookingVal != null) {
            sb.append("Passenger Name: ${bookingVal.guestName} ${bookingVal.guestSurname}. Cabin Number: ${bookingVal.cabinNumber}. Loyalty Status: ${bookingVal.loyaltyTier} (${bookingVal.loyaltyPoints} points).\n")
        }
        if (currentDay != null) {
            sb.append("Current Port Operational Detail: Port Name = ${currentDay.portName}, Scheduled Arrival = ${currentDay.arrivalTime}, Scheduled Departure = ${currentDay.departureTime}, Local Currency = ${currentDay.currency}.\n")
        }
        sb.append("Passenger's Current Active Bookings:\n")
        if (resList.isEmpty()) {
            sb.append("- No active bookings.\n")
        } else {
            for (res in resList) {
                sb.append("- Day ${res.dayNumber}: ${res.title} at ${res.time} (Location: ${res.location}, Cost Paid: £${res.pricePaid}, Party of ${res.partySize})\n")
            }
        }
        return sb.toString()
    }
}
