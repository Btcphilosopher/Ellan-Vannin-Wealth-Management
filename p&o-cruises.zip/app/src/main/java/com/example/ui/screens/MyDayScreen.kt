package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ReservationEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.CruiseViewModel

@Composable
fun MyDayScreen(viewModel: CruiseViewModel) {
    val selectedDayIndex by viewModel.currentSelectedDayIndex.collectAsState()
    val reservations by viewModel.reservations.collectAsState()
    val itinerary by viewModel.itinerary.collectAsState()

    val dayNumber = selectedDayIndex + 1
    val dayReservations = reservations.filter { it.dayNumber == dayNumber }
    val currentDayPort = itinerary.getOrNull(selectedDayIndex)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "MY DAY PLANNER",
            style = MaterialTheme.typography.titleMedium,
            color = TextSecondaryMuted,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // Horizontal 12-Day Scroller
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(12) { index ->
                val isSelected = index == selectedDayIndex
                Box(
                    modifier = Modifier
                        .size(width = 64.dp, height = 74.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) NavyPrimary else Color.White)
                        .clickable { viewModel.selectDayIndex(index) }
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "DAY",
                            fontSize = 10.sp,
                            color = if (isSelected) AccentGold else TextSecondaryMuted,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${index + 1}",
                            fontSize = 20.sp,
                            color = if (isSelected) Color.White else NavyPrimary,
                            fontWeight = FontWeight.Black
                        )
                        // Mini dot if there are bookings for this day
                        val hasBookings = reservations.any { it.dayNumber == index + 1 }
                        if (hasBookings) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 2.dp)
                                    .size(5.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) AccentGold else NavySecondary)
                            )
                        }
                    }
                }
            }
        }

        // Selected Day Port Header
        currentDayPort?.let { port ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = NavySecondary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (port.portName == "At Sea") Icons.Default.Waves else Icons.Default.PinDrop,
                        contentDescription = null,
                        tint = AccentGold,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = if (port.portName == "At Sea") "DAY IN THE OCEAN: AT SEA" else "PORT: ${port.portName.uppercase()}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = port.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = LightCardBg
                        )
                    }
                }
            }
        }

        // Check for conflicts inside this specific day to display warning header
        val conflictAlerts = detectDayConflicts(dayReservations)
        if (conflictAlerts.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AlertWarning.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(12.dp),
                border = CardStroke(1.dp, AlertWarning.copy(alpha = 0.5f))
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = AlertWarning)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "You have overlapping bookings today. Review schedules below.",
                        color = AlertWarning,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Daily Schedule Timeline list
        if (dayReservations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.EventNote, contentDescription = null, tint = TextSecondaryMuted, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No bookings scheduled for Day $dayNumber.", color = TextSecondaryMuted)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Explore dining, excursions, or spa to add.", color = TextSecondaryMuted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                itemsIndexed(dayReservations.sortedBy { it.time }) { index, res ->
                    val isFirst = index == 0
                    val isLast = index == dayReservations.size - 1

                    // check if this item conflicts with any other
                    val hasConflict = conflictAlerts.any { it.reservationId == res.reservationId }

                    TimelineItemRow(
                        res = res,
                        isFirst = isFirst,
                        isLast = isLast,
                        hasConflict = hasConflict,
                        onCancelClick = { viewModel.cancelBooking(res) }
                    )
                }
            }
        }
    }
}

@Composable
fun TimelineItemRow(
    res: ReservationEntity,
    isFirst: Boolean,
    isLast: Boolean,
    hasConflict: Boolean,
    onCancelClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
    ) {
        // Timeline Dot & Vertical Connection Lines
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .width(40.dp)
                .fillMaxHeight()
        ) {
            // Line before dot
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .weight(1f)
                    .background(if (isFirst) Color.Transparent else TextSecondaryMuted.copy(alpha = 0.5f))
            )
            // Dot
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(if (hasConflict) AlertWarning else NavyPrimary)
            )
            // Line after dot
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .weight(1f)
                    .background(if (isLast) Color.Transparent else TextSecondaryMuted.copy(alpha = 0.5f))
            )
        }

        // Details Card
        Card(
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(1.dp),
            shape = RoundedCornerShape(12.dp),
            border = if (hasConflict) CardStroke(1.5.dp, AlertWarning) else null
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = res.title,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary,
                            fontSize = 15.sp
                        )
                        Text(
                            text = res.activityType,
                            fontSize = 11.sp,
                            color = AccentGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onCancelClick,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Cancel booking", tint = AlertWarning, modifier = Modifier.size(18.dp))
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccessTime, null, tint = TextSecondaryMuted, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(res.time, fontSize = 12.sp, color = TextSecondaryMuted)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, null, tint = TextSecondaryMuted, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(res.location.split(",")[0], fontSize = 12.sp, color = TextSecondaryMuted)
                    }
                }
                if (res.pricePaid > 0.0) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Paid: £${"%.2f".format(res.pricePaid)} (Party of ${res.partySize})",
                        fontSize = 12.sp,
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                if (hasConflict) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "⚠ Booking conflict! Reschedule to avoid overlap.",
                        fontSize = 11.sp,
                        color = AlertWarning,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// Helper: detect conflicts in a list of reservations for a single day
private fun detectDayConflicts(dayRes: List<ReservationEntity>): List<ReservationEntity> {
    val conflicts = mutableListOf<ReservationEntity>()
    val sorted = dayRes.sortedBy { it.time }

    for (i in sorted.indices) {
        val curr = sorted[i]
        val currTime = parseTimeToMins(curr.time)
        val currEnd = currTime + 90 // estimate 90m per session

        for (j in sorted.indices) {
            if (i == j) continue
            val other = sorted[j]
            val otherTime = parseTimeToMins(other.time)
            val otherEnd = otherTime + 90

            if (currTime < otherEnd && currEnd > otherTime) {
                if (!conflicts.contains(curr)) {
                    conflicts.add(curr)
                }
            }
        }
    }
    return conflicts
}

private fun parseTimeToMins(time: String): Int {
    return try {
        val parts = time.split(":")
        val h = parts[0].toInt()
        val m = parts[1].split(" ")[0].toInt()
        h * 60 + m
    } catch (e: Exception) {
        0
    }
}

// Utility stroke wrapper
@Composable
fun CardStroke(width: androidx.compose.ui.unit.Dp, color: Color) = androidx.compose.foundation.BorderStroke(width, color)
