package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Anchor
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.CruiseViewModel

@Composable
fun MyCruiseScreen(viewModel: CruiseViewModel) {
    val booking by viewModel.booking.collectAsState()
    val cruiseState by viewModel.cruiseState.collectAsState()
    val scrollState = rememberScrollState()

    var isCardFlipped by remember { mutableStateOf(false) }
    val cardRotation by animateFloatAsState(
        targetValue = if (isCardFlipped) 180f else 0f,
        animationSpec = tween(durationMillis = 600)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "DIGITAL CRUISE CARD",
            style = MaterialTheme.typography.titleMedium,
            color = TextSecondaryMuted,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // 3D-Flipping Cruise Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .clickable { isCardFlipped = !isCardFlipped }
                .graphicsLayer {
                    rotationY = cardRotation
                    cameraDistance = 8 * density
                },
            contentAlignment = Alignment.Center
        ) {
            if (cardRotation <= 90f) {
                // FRONT OF CARD
                Card(
                    modifier = Modifier.fillMaxSize(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    elevation = CardDefaults.cardElevation(6.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "P&O CRUISES",
                                style = MaterialTheme.typography.titleMedium,
                                color = AccentGold,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            )
                            Icon(Icons.Default.Waves, null, tint = AccentGold)
                        }

                        Column {
                            Text(
                                text = "${booking?.guestName?.uppercase()} ${booking?.guestSurname?.uppercase()}",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = booking?.loyaltyTier ?: "Pacific Tier",
                                style = MaterialTheme.typography.bodyMedium,
                                color = AccentGold,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text("CABIN", color = LightCardBg, fontSize = 10.sp)
                                Text(booking?.cabinNumber?.split(" ")?.get(0) ?: "C104", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("SHIP", color = LightCardBg, fontSize = 10.sp)
                                Text(booking?.shipName ?: "IONA", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("REF", color = LightCardBg, fontSize = 10.sp)
                                Text(booking?.bookingReference ?: "POC847321", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                // BACK OF CARD (Flipped)
                Card(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { rotationY = 180f },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AccentGold),
                    elevation = CardDefaults.cardElevation(6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1.2f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                "MUSTER STATION: C",
                                style = MaterialTheme.typography.titleMedium,
                                color = NavyPrimary,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                "Location: Grand Atrium Deck 6",
                                style = MaterialTheme.typography.bodySmall,
                                color = NavyPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Divider(color = NavyPrimary, thickness = 1.dp)
                            Text(
                                "In Emergency: Listen for 7 short & 1 long whistle. Report to Muster C with lifejackets from cabin.",
                                style = MaterialTheme.typography.bodySmall,
                                color = NavyPrimary,
                                fontSize = 10.sp
                            )
                            Text(
                                "Medical Centre: Deck 4 Midship, Ext 99",
                                style = MaterialTheme.typography.bodySmall,
                                color = NavyPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Barcode mockup
                        Column(
                            modifier = Modifier
                                .weight(0.8f)
                                .fillMaxHeight(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Default.QrCode2,
                                contentDescription = "Digital Pass QR",
                                tint = NavyPrimary,
                                modifier = Modifier.size(100.dp)
                            )
                            Text("TAP TO FLIP", fontSize = 9.sp, color = NavyPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Text(
            text = "YOUR VOYAGE SUMMARY",
            style = MaterialTheme.typography.labelLarge,
            color = NavySecondary,
            fontWeight = FontWeight.Bold
        )

        // Cruise particulars list
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ParticularsRow("Ship Name", booking?.shipName ?: "Iona")
                ParticularsRow("Cabin Category", booking?.cabinCategory ?: "Deluxe Balcony Suite")
                ParticularsRow("Deck Location", "Deck 10 Forward")
                ParticularsRow("Voyage Name", booking?.cruiseName ?: "Mediterranean Discovery")
                ParticularsRow("Duration", "${booking?.durationDays ?: 12} Nights")
                ParticularsRow("Departure", "${booking?.departurePort} (${booking?.departureDate})")
                ParticularsRow("Arrival Port", booking?.arrivalPort ?: "Southampton")
                ParticularsRow("Cashless Account Status", if (cruiseState?.paymentCardAdded == true) "Auto-Billed to Visa 4282" else "Cash/No Card Registered")
                ParticularsRow("Booking Reference", booking?.bookingReference ?: "POC847321")
            }
        }

        // Emergency Medical Panel
        Text(
            text = "EMERGENCY SAFETY CENTRE",
            style = MaterialTheme.typography.labelLarge,
            color = AlertWarning,
            fontWeight = FontWeight.Bold
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AlertWarning.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = AlertWarning)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Safety Drill Registration Status", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = AlertWarning)
                }
                Text("Your Muster Station briefing is COMPLETED. Thank you for participating. In any real maritime alert, follow ship intercom commands and retrieve lifejackets from your wardrobe in cabin C104.", style = MaterialTheme.typography.bodyMedium, color = TextPrimaryDark)
                Divider(color = AlertWarning.copy(alpha = 0.2f))
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Medical Centre", fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                    Text("Dial 99 or Deck 4 Mid", color = AlertWarning, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ParticularsRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondaryMuted)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold)
    }
}
