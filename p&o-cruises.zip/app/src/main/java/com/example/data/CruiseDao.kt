package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CruiseDao {

    // --- Cruise State ---
    @Query("SELECT * FROM cruise_state WHERE id = 1 LIMIT 1")
    fun getCruiseStateFlow(): Flow<CruiseStateEntity?>

    @Query("SELECT * FROM cruise_state WHERE id = 1 LIMIT 1")
    suspend fun getCruiseState(): CruiseStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateCruiseState(state: CruiseStateEntity)

    // --- Booking Details ---
    @Query("SELECT * FROM booking_details LIMIT 1")
    fun getBookingFlow(): Flow<BookingEntity?>

    @Query("SELECT * FROM booking_details LIMIT 1")
    suspend fun getBooking(): BookingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateBooking(booking: BookingEntity)

    // --- Itinerary ---
    @Query("SELECT * FROM itinerary ORDER BY dayNumber ASC")
    fun getAllItineraryFlow(): Flow<List<ItineraryDayEntity>>

    @Query("SELECT * FROM itinerary ORDER BY dayNumber ASC")
    suspend fun getAllItinerary(): List<ItineraryDayEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItineraryDays(days: List<ItineraryDayEntity>)

    // --- Activities ---
    @Query("SELECT * FROM activities ORDER BY id ASC")
    fun getAllActivitiesFlow(): Flow<List<ActivityEntity>>

    @Query("SELECT * FROM activities WHERE category = :category ORDER BY id ASC")
    fun getActivitiesByCategoryFlow(category: String): Flow<List<ActivityEntity>>

    @Query("SELECT * FROM activities WHERE id = :id LIMIT 1")
    suspend fun getActivityById(id: String): ActivityEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivities(activities: List<ActivityEntity>)

    // --- Reservations ---
    @Query("SELECT * FROM reservations ORDER BY dayNumber ASC, time ASC")
    fun getAllReservationsFlow(): Flow<List<ReservationEntity>>

    @Query("SELECT * FROM reservations WHERE dayNumber = :dayNumber ORDER BY time ASC")
    fun getReservationsByDayFlow(dayNumber: Int): Flow<List<ReservationEntity>>

    @Query("SELECT * FROM reservations WHERE dayNumber = :dayNumber ORDER BY time ASC")
    suspend fun getReservationsByDay(dayNumber: Int): List<ReservationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReservation(reservation: ReservationEntity)

    @Query("DELETE FROM reservations WHERE reservationId = :id")
    suspend fun deleteReservationById(id: String)

    // --- Transactions ---
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactionsFlow(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions")
    suspend fun clearAllTransactions()

    // --- Notifications ---
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotificationsFlow(): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE isRead = 0")
    fun getUnreadNotificationsCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllNotificationsAsRead()

    @Query("DELETE FROM notifications")
    suspend fun clearAllNotifications()

    // --- Concierge Chat ---
    @Query("SELECT * FROM concierge_messages ORDER BY timestamp ASC")
    fun getAllConciergeMessagesFlow(): Flow<List<ConciergeMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConciergeMessage(message: ConciergeMessageEntity)

    @Query("DELETE FROM concierge_messages")
    suspend fun clearConciergeChat()
}
