package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CruiseStateEntity::class,
        BookingEntity::class,
        ItineraryDayEntity::class,
        ActivityEntity::class,
        ReservationEntity::class,
        TransactionEntity::class,
        NotificationEntity::class,
        ConciergeMessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun cruiseDao(): CruiseDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "po_cruises_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        fun setTestDatabase(db: AppDatabase) {
            synchronized(this) {
                INSTANCE = db
            }
        }
    }
}
