package com.example.data

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val TAG = "GeminiService"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateResponse(prompt: String, systemContext: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        // Check if key is empty or default placeholder
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w(TAG, "Gemini API Key is not set, using local rule-based concierge response.")
            return@withContext localFallback(prompt)
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        try {
            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                }
                put("contents", contentsArray)

                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "You are the P&O Cruises Concierge on board the Iona. " +
                                    "Provide highly helpful, elegant, and polite responses in a premium British tone. " +
                                    "Here is the passenger's current cruise context:\n$systemContext\n\n" +
                                    "Do NOT invent or hallucinate any bookings, transactions, or ship schedules that are not listed in this context. " +
                                    "If a user asks about their spending or reservations, refer exactly to the provided context data.")
                        })
                    })
                })
            }

            val body = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorBody = response.body?.string() ?: ""
                    Log.e(TAG, "Gemini REST API failed with code ${response.code}: $errorBody")
                    return@withContext localFallback(prompt)
                }

                val responseString = response.body?.string() ?: ""
                val responseJson = JSONObject(responseString)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    if (content != null) {
                        val parts = content.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            return@withContext parts.getJSONObject(0).optString("text", "P&O Concierge: I apologize, I was unable to compile an answer. Let me know if I can assist with other bookings!")
                        }
                    }
                }
                localFallback(prompt)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini API exception: ${e.message}", e)
            localFallback(prompt)
        }
    }

    internal fun localFallback(prompt: String): String {
        val query = prompt.lowercase()
        return when {
            query.contains("emergency") || query.contains("medical") || query.contains("99") -> {
                "P&O Concierge: For any medical emergencies or urgent safety assistance on board the Iona, please contact the Medical Centre immediately by dialing 99 from any cabin telephone."
            }
            query.contains("spend") || query.contains("cost") || query.contains("money") || query.contains("account") || query.contains("balance") -> {
                "P&O Concierge: You have spent £140.00 of your £250.00 complimentary onboard credit. This leaves you with exactly £110.00 in remaining credit on your onboard account. No additional payment cards need to be charged at this time."
            }
            query.contains("tomorrow") || query.contains("next port") || query.contains("arrive") -> {
                "P&O Concierge: Tomorrow we arrive in Lisbon, Portugal! The Iona is scheduled to dock at 08:00. The All Aboard warning is strictly at 17:30, with ship departure at 18:00. Local currency is Euros (€)."
            }
            query.contains("do tonight") || query.contains("activities") || query.contains("schedule") || query.contains("happening") -> {
                "P&O Concierge: Tonight's premium entertainment highlights include the breathtaking 'Sky's the Limit Aerial Show' under the SkyDome on Deck 16 at 21:00, or the West End Stage Tribute show at Headliners Theatre (Deck 6) at 19:30."
            }
            query.contains("restaurant") || query.contains("food") || query.contains("eat") || query.contains("dinner") -> {
                "P&O Concierge: I highly recommend 'Sindhu' on Deck 6 for sensational contemporary Indian cuisine (fine dining cover charge applies), or Olly Smith's 'The Glass House' for premium wine flights paired with exquisite small plates."
            }
            query.contains("conflict") || query.contains("overlap") || query.contains("fit") -> {
                "P&O Concierge: I have scanned your itinerary! You have a time overlap on Day 3: Your 'Santiago de Compostela' excursion (09:00 - 15:00) overlaps with your 'Deep Tissue Swedish Massage' at Oasis Spa (11:00). I recommend rescheduling your massage to 16:00."
            }
            query.contains("back from") || query.contains("excursion") || query.contains("time") -> {
                "P&O Concierge: For your Vigo excursion, meeting is at 09:15 and expected return is 13:00. Ship departure is 17:30, so you will return safely 4.5 hours prior to sailing."
            }
            else -> {
                "P&O Concierge: I am delighted to assist you on your voyage. You can ask me details about our ports of call (Vigo, Lisbon, Malaga, Barcelona), onboard restaurants, show times, cabin details, spending, or emergency services."
            }
        }
    }
}
