package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class CruiseRepository(private val dao: CruiseDao) {

    // Expose Flows
    val cruiseStateFlow: Flow<CruiseStateEntity?> = dao.getCruiseStateFlow()
    val bookingFlow: Flow<BookingEntity?> = dao.getBookingFlow()
    val itineraryFlow: Flow<List<ItineraryDayEntity>> = dao.getAllItineraryFlow()
    val activitiesFlow: Flow<List<ActivityEntity>> = dao.getAllActivitiesFlow()
    val allReservationsFlow: Flow<List<ReservationEntity>> = dao.getAllReservationsFlow()
    val allTransactionsFlow: Flow<List<TransactionEntity>> = dao.getAllTransactionsFlow()
    val allNotificationsFlow: Flow<List<NotificationEntity>> = dao.getAllNotificationsFlow()
    val unreadNotificationsCountFlow: Flow<Int> = dao.getUnreadNotificationsCountFlow()
    val chatMessagesFlow: Flow<List<ConciergeMessageEntity>> = dao.getAllConciergeMessagesFlow()

    fun getActivitiesByCategory(category: String): Flow<List<ActivityEntity>> {
        return dao.getActivitiesByCategoryFlow(category)
    }

    suspend fun getAllItinerary(): List<ItineraryDayEntity> = withContext(Dispatchers.IO) {
        dao.getAllItinerary()
    }

    fun getReservationsByDay(dayNumber: Int): Flow<List<ReservationEntity>> {
        return dao.getReservationsByDayFlow(dayNumber)
    }

    // Suspend operations for writes
    suspend fun updateCruiseState(state: CruiseStateEntity) = withContext(Dispatchers.IO) {
        dao.insertOrUpdateCruiseState(state)
    }

    suspend fun getCruiseState(): CruiseStateEntity? = withContext(Dispatchers.IO) {
        dao.getCruiseState()
    }

    suspend fun updateBooking(booking: BookingEntity) = withContext(Dispatchers.IO) {
        dao.insertOrUpdateBooking(booking)
    }

    suspend fun getBooking(): BookingEntity? = withContext(Dispatchers.IO) {
        dao.getBooking()
    }

    suspend fun addReservation(reservation: ReservationEntity) = withContext(Dispatchers.IO) {
        dao.insertReservation(reservation)
    }

    suspend fun cancelReservation(reservationId: String) = withContext(Dispatchers.IO) {
        dao.deleteReservationById(reservationId)
    }

    suspend fun getReservationsForDayDirect(dayNumber: Int): List<ReservationEntity> = withContext(Dispatchers.IO) {
        dao.getReservationsByDay(dayNumber)
    }

    suspend fun addTransaction(transaction: TransactionEntity) = withContext(Dispatchers.IO) {
        dao.insertTransaction(transaction)
    }

    suspend fun clearTransactions() = withContext(Dispatchers.IO) {
        dao.clearAllTransactions()
    }

    suspend fun addNotification(notification: NotificationEntity) = withContext(Dispatchers.IO) {
        dao.insertNotification(notification)
    }

    suspend fun markAllNotificationsAsRead() = withContext(Dispatchers.IO) {
        dao.markAllNotificationsAsRead()
    }

    suspend fun clearNotifications() = withContext(Dispatchers.IO) {
        dao.clearAllNotifications()
    }

    suspend fun addChatMessage(text: String, sender: String) = withContext(Dispatchers.IO) {
        dao.insertConciergeMessage(ConciergeMessageEntity(text = text, sender = sender))
    }

    suspend fun clearChat() = withContext(Dispatchers.IO) {
        dao.clearConciergeChat()
    }

    suspend fun getActivityById(id: String): ActivityEntity? = withContext(Dispatchers.IO) {
        dao.getActivityById(id)
    }

    // Seeding logic
    suspend fun seedDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        val existingState = dao.getCruiseState()
        if (existingState != null) {
            return@withContext // Database already seeded
        }

        // 1. Initial State
        val initialState = CruiseStateEntity(
            currentDayIndex = 0,
            isCruiseStarted = false,
            currentPhase = "BOOKED", // Starting before embarkation
            lat = 50.9097,
            lng = -1.4044,
            speedKts = 0.0,
            portName = "Southampton",
            weatherTemp = 19.5,
            weatherDesc = "Bright and Sunny",
            seaConditions = "Calm",
            checkInCompleted = false,
            boardingPassDownloaded = false,
            paymentCardAdded = false,
            onboardBalance = 0.0,
            usedCredit = 0.0,
            onboardCredit = 250.0
        )
        dao.insertOrUpdateCruiseState(initialState)

        // 2. Booking details
        val initialBooking = BookingEntity()
        dao.insertOrUpdateBooking(initialBooking)

        // 3. Itinerary Days (12 Days Southampton to Spain/Portugal)
        val itinerary = listOf(
            ItineraryDayEntity(1, 1, "Southampton", "UK Port of Departure - Home of P&O Cruises", "At Sea", "18:00", 50.9097, -1.4044, 0, "GBP"),
            ItineraryDayEntity(2, 2, "At Sea", "Crossing the Bay of Biscay", "At Sea", "At Sea", 46.5000, -6.5000, 420, "GBP"),
            ItineraryDayEntity(3, 3, "Vigo", "Galicia, Spain - Beautiful historic port of the Rias Baixas", "08:00", "17:30", 42.2406, -8.7207, 780, "EUR"),
            ItineraryDayEntity(4, 4, "Lisbon", "Capital of Portugal - Sailing under the April 25 Bridge", "08:00", "18:00", 38.7223, -9.1393, 1050, "EUR"),
            ItineraryDayEntity(5, 5, "Porto (Leixões)", "Northern Gateway to Portugal - Famous for Port Wine and culture", "08:00", "17:00", 41.1834, -8.6946, 1220, "EUR"),
            ItineraryDayEntity(6, 6, "At Sea", "Sailing past Cabo de São Vicente and entering Andalusia", "At Sea", "At Sea", 36.5000, -7.5000, 1530, "GBP"),
            ItineraryDayEntity(7, 7, "Malaga", "Andalusia, Spain - Birthplace of Picasso, Gateway to Granada", "08:00", "22:00", 36.7213, -4.4214, 1850, "EUR"),
            ItineraryDayEntity(8, 8, "Alicante", "Costa Blanca, Spain - Overlooked by Santa Bárbara Castle", "08:00", "17:00", 38.3452, -0.4810, 2120, "EUR"),
            ItineraryDayEntity(9, 9, "Barcelona", "Catalonia, Spain - Architectural wonders of Gaudí", "08:00", "18:00", 41.3851, 2.1734, 2380, "EUR"),
            ItineraryDayEntity(10, 10, "At Sea", "Heading back north through the Mediterranean", "At Sea", "At Sea", 38.5000, -1.5000, 2750, "GBP"),
            ItineraryDayEntity(11, 11, "At Sea", "Cruising Atlantic swells home", "At Sea", "At Sea", 45.0000, -5.5000, 3180, "GBP"),
            ItineraryDayEntity(12, 12, "Southampton", "Return to Southampton for Disembarkation", "06:30", "At Sea", 50.9097, -1.4044, 3600, "GBP")
        )
        dao.insertItineraryDays(itinerary)

        // 4. Seed Activities (Dining, Entertainment, Excursions, Spa)
        val activities = listOf(
            // --- Dining ---
            ActivityEntity(
                id = "DIN_GLASS",
                category = "DINING",
                title = "The Glass House",
                subtitle = "Fine Tapas & Wine Pairing",
                time = "18:00",
                durationMinutes = 90,
                deck = "Deck 6",
                price = 15.0,
                location = "Grand Atrium, Deck 6 Midship",
                description = "Created in partnership with award-winning wine expert Olly Smith. Exquisite small plates designed to pair with curated global wines.",
                allergens = "Gluten-free & Vegetarian options available"
            ),
            ActivityEntity(
                id = "DIN_KEEL",
                category = "DINING",
                title = "The Keel & Cow",
                subtitle = "Premium Gastro-pub & Steaks",
                time = "19:00",
                durationMinutes = 90,
                deck = "Deck 8",
                price = 0.0, // Included, but steak is premium extra
                location = "Deck 8 Forward",
                description = "A P&O Cruises classic gastro-pub. Home of 'The Prime Minister' burger, premium dry-aged steaks, and selected British craft ales.",
                allergens = "Vegan & Gluten-free alternatives on request"
            ),
            ActivityEntity(
                id = "DIN_SINDHU",
                category = "DINING",
                title = "Sindhu",
                subtitle = "Contemporary Indian Fine Dining",
                time = "18:30",
                durationMinutes = 100,
                deck = "Deck 6",
                price = 28.0,
                location = "Deck 6 Midship",
                description = "Authentic contemporary Indian cuisine with a British twist. Delicate spices, innovative plates, and an elegant luxury atmosphere.",
                allergens = "Halal, Vegetarian & Nut-free highlighted on menu"
            ),
            ActivityEntity(
                id = "DIN_EPICUREAN",
                category = "DINING",
                title = "The Epicurean",
                subtitle = "Classic French Fine Dining",
                time = "19:30",
                durationMinutes = 120,
                deck = "Deck 16",
                price = 45.0,
                location = "Deck 16 Aft",
                description = "The ultimate culinary highlight. Traditional French fine dining prepared with modern tableside presentation. Panoramic ocean views.",
                allergens = "Vegan gourmet menu available"
            ),
            ActivityEntity(
                id = "DIN_CORAL",
                category = "DINING",
                title = "The Coral Restaurant",
                subtitle = "Main Dining Room (Club Dining)",
                time = "18:15",
                durationMinutes = 80,
                deck = "Deck 6",
                price = 0.0,
                location = "Deck 6 Aft",
                description = "Your primary elegant dining venue. Five-course traditional British and global meals, fully included in your cruise price.",
                allergens = "Complete allergen listing available on tablet"
            ),

            // --- Entertainment ---
            ActivityEntity(
                id = "ENT_COMEDY",
                category = "ENTERTAINMENT",
                title = "Limelight Club: Festival of Comedy",
                subtitle = "Live Stand-Up & 3-Course Dinner",
                time = "20:30",
                durationMinutes = 120,
                deck = "Deck 6",
                price = 35.0, // dinner theater ticket
                location = "The Limelight Club, Deck 6 Forward",
                description = "A sophisticated supper club experience. Enjoy a gourmet 3-course dinner followed by an exclusive live comedy show from top UK talent."
            ),
            ActivityEntity(
                id = "ENT_SKY",
                category = "ENTERTAINMENT",
                title = "Sky's the Limit Arena Show",
                subtitle = "Acrobatic & High-Tech Aerial Showcase",
                time = "21:00",
                durationMinutes = 55,
                deck = "Deck 16",
                price = 0.0,
                location = "The SkyDome, Deck 16 Midship",
                description = "Breathtaking aerial choreography and state-of-the-art visual mapping under the iconic glass SkyDome roof."
            ),
            ActivityEntity(
                id = "ENT_THEATRE_MAIN",
                category = "ENTERTAINMENT",
                title = "Festival of Music: West End Stage",
                subtitle = "West End Tribute Production",
                time = "19:30",
                durationMinutes = 60,
                deck = "Deck 6",
                price = 0.0,
                location = "Headliners Theatre, Deck 6 Forward",
                description = "Our high-energy resident production cast performs highlights from legendary musicals including Les Misérables, Wicked, and Phantom."
            ),
            ActivityEntity(
                id = "ENT_JAZZ",
                category = "ENTERTAINMENT",
                title = "Live Jazz: Sea Waves Trio",
                subtitle = "Acoustic Jazz & Classic Cocktails",
                time = "22:00",
                durationMinutes = 90,
                deck = "Deck 17",
                price = 0.0,
                location = "The Crow's Nest, Deck 17 Forward",
                description = "Unwind with magnificent 270-degree evening sea views while our world-class jazz musicians perform classical standards."
            ),

            // --- Shore Experiences ---
            ActivityEntity(
                id = "EXC_VIGO_COAST",
                category = "EXCURSION",
                title = "Galician Coast & Vigo Panoramic",
                subtitle = "Low Intensity Scenic Sightseeing",
                time = "09:30",
                durationMinutes = 180,
                deck = "Vigo",
                price = 45.0,
                location = "Vigo Port Meeting Point",
                intensity = "Low",
                description = "Enjoy a relaxing air-conditioned coach journey along Vigo's dramatic coastline. Highlights include scenic coastal views, Castro Castle ruins, and traditional tapas tasting."
            ),
            ActivityEntity(
                id = "EXC_VIGO_SANTIAGO",
                category = "EXCURSION",
                title = "Santiago de Compostela Pilgrimage",
                subtitle = "High Intensity Historic Trek",
                time = "09:00",
                durationMinutes = 360,
                deck = "Vigo",
                price = 85.0,
                location = "Vigo Port Meeting Point",
                intensity = "High",
                description = "A magnificent full-day tour to Galicia's historic capital. Visit the breathtaking Cathedral of Santiago de Compostela, walk the final stretch of the Camino pilgrim path, and enjoy authentic Galician lunch."
            ),
            ActivityEntity(
                id = "EXC_LIS_WALK",
                category = "EXCURSION",
                title = "Historic Lisbon & Pastel de Nata",
                subtitle = "Medium Intensity Cultural Walk",
                time = "09:30",
                durationMinutes = 240,
                deck = "Lisbon",
                price = 55.0,
                location = "Lisbon Pier Side Meeting Point",
                intensity = "Medium",
                description = "Examine Lisbon's classic Alfama district on foot. Sample authentic fresh Pasteis de Belém from an iconic local bakery, ride the traditional historical yellow tram, and enjoy scenic Miradouro lookouts."
            ),
            ActivityEntity(
                id = "EXC_MALAGA_ALHAMBRA",
                category = "EXCURSION",
                title = "Granada Alhambra Palace (Extended)",
                subtitle = "Medium Intensity Full-Day Tour",
                time = "08:15",
                durationMinutes = 540, // 9 Hours - Warning! Very close to departure if delayed!
                deck = "Malaga",
                price = 125.0,
                location = "Malaga Terminal Meeting Point",
                intensity = "Medium",
                description = "A once-in-a-lifetime journey across the Sierra Nevada to Granada's stunning 13th-century Moorish palace fortress. Includes guided tour of the Generalife gardens, palace courts, and full Andalusian lunch."
            ),
            ActivityEntity(
                id = "EXC_BAR_SAGRADA",
                category = "EXCURSION",
                title = "Sagrada Família & Gaudí Masterpieces",
                subtitle = "Medium Intensity Art & Architecture",
                time = "09:30",
                durationMinutes = 240,
                deck = "Barcelona",
                price = 79.0,
                location = "Barcelona Terminal 1",
                intensity = "Medium",
                description = "Skip the line at Gaudí's unfinished cathedral masterpiece. Walk down Passeig de Gràcia to marvel at Casa Batlló and La Pedrera, accompanied by a certified Catalan architecture expert."
            ),

            // --- Spa ---
            ActivityEntity(
                id = "SPA_FACIAL",
                category = "SPA",
                title = "Elemis Pro-Collagen Age Defy Facial",
                subtitle = "Anti-aging Skin Revitalization",
                time = "14:00",
                durationMinutes = 50,
                deck = "Deck 5",
                price = 95.0,
                location = "Oasis Spa & Salon, Deck 5 Midship",
                description = "Peptides and marine algae compounds are combined with professional hands-on massage techniques to visibly plump, smooth, and nourish tired travel skin."
            ),
            ActivityEntity(
                id = "SPA_MASSAGE",
                category = "SPA",
                title = "Deep Tissue Swedish Full Body Massage",
                subtitle = "Muscle Tension Relief & Relaxation",
                time = "11:00",
                durationMinutes = 50,
                deck = "Deck 5",
                price = 110.0,
                location = "Oasis Spa & Salon, Deck 5 Midship",
                description = "Using aromatic therapeutic oils, our expert therapists focus on deep-seated muscle tension and joints to restore flexibility and complete physical ease."
            ),
            ActivityEntity(
                id = "SPA_THERMAL",
                category = "SPA",
                title = "Thermal Suite Hydrotherapy Day Pass",
                subtitle = "Unlimited Thermal Relaxation Pool & Steam",
                time = "10:00",
                durationMinutes = 120,
                deck = "Deck 5",
                price = 35.0,
                location = "The Retreat, Deck 5 Forward",
                description = "Enjoy therapeutic steam rooms, herbal saunas, heated ceramic loungers, and our state-of-the-art salt hydrotherapy pool."
            ),

            // --- Daily Onboard Programme (Free activities) ---
            ActivityEntity(
                id = "PRG_STRETCH",
                category = "DAILY_PROGRAMME",
                title = "Sunrise Morning Stretch & Yoga",
                subtitle = "Start Your Day Energised",
                time = "08:00",
                durationMinutes = 45,
                deck = "Deck 17",
                price = 0.0,
                location = "Gymnasium Studio, Deck 17 Aft",
                description = "A gentle, low-intensity flexibility and breath session. Fully open to all skill levels. Stunning panoramic sea views."
            ),
            ActivityEntity(
                id = "PRG_QUIZ",
                category = "DAILY_PROGRAMME",
                title = "The Great Maritime Trivia Sea Quiz",
                subtitle = "Friendly Onboard Competition",
                time = "11:00",
                durationMinutes = 45,
                deck = "Deck 8",
                price = 0.0,
                location = "The Keel & Cow Lounge",
                description = "Test your general knowledge and maritime trivia against fellow cruise guests. Fun, interactive, and with prizes for winners!"
            ),
            ActivityEntity(
                id = "PRG_COOKING",
                category = "DAILY_PROGRAMME",
                title = "Chef's Table Live Cooking Demo",
                subtitle = "Gastronomy Secret Tips",
                time = "14:00",
                durationMinutes = 60,
                deck = "Deck 6",
                price = 0.0,
                location = "Horizon Show Lounge",
                description = "Join our Head Pastry Chef as he demonstrates the secrets of baking the perfect traditional British warm scones and clotted cream delicacies."
            ),
            ActivityEntity(
                id = "PRG_BAND",
                category = "DAILY_PROGRAMME",
                title = "The Royal Sail Deck Live Band",
                subtitle = "Top UK Hits & Caribbean Reggae",
                time = "16:00",
                durationMinutes = 90,
                deck = "Deck 16",
                price = 0.0,
                location = "SkyDome Poolside Deck",
                description = "Dance or relax poolside with our high-energy live band playing your favorite hits under the afternoon sun."
            )
        )
        dao.insertActivities(activities)

        // 5. Seed Pre-Existing Booking Reservations (e.g. Dining)
        val seedReservations = listOf(
            ReservationEntity(
                reservationId = "RES_DIN_CORAL_1",
                activityId = "DIN_CORAL",
                activityType = "DINING",
                title = "The Coral Restaurant (Club Dining)",
                time = "18:15",
                pricePaid = 0.0,
                partySize = 4,
                location = "The Coral Restaurant, Deck 6 Aft",
                dayNumber = 1
            ),
            ReservationEntity(
                reservationId = "RES_DIN_SINDHU_3",
                activityId = "DIN_SINDHU",
                activityType = "DINING",
                title = "Sindhu Fine Indian",
                time = "18:30",
                pricePaid = 28.0,
                partySize = 2,
                location = "Sindhu, Deck 6 Midship",
                dayNumber = 3
            ),
            ReservationEntity(
                reservationId = "RES_EXC_VIGO_3",
                activityId = "EXC_VIGO_COAST",
                activityType = "EXCURSION",
                title = "Galician Coast Scenic Excursion",
                time = "09:30",
                pricePaid = 90.0, // For 2 people
                partySize = 2,
                location = "Vigo Port Meeting Point",
                dayNumber = 3
            ),
            ReservationEntity(
                reservationId = "RES_SPA_MASS_5",
                activityId = "SPA_MASSAGE",
                activityType = "SPA",
                title = "Deep Tissue Swedish Massage",
                time = "11:00",
                pricePaid = 110.0,
                partySize = 1,
                location = "Oasis Spa, Deck 5",
                dayNumber = 5
            )
        )
        for (res in seedReservations) {
            dao.insertReservation(res)
        }

        // 6. Seed initial transactions for Onboard Spending
        val initialTransactions = listOf(
            TransactionEntity("TX_01", "Olly Smith Chardonnay - Glass House", 11.50, "Drinks", "Tom", System.currentTimeMillis() - 86400000, 1),
            TransactionEntity("TX_02", "Sindhu Indian Cover Charge (Guest 1 & 2)", 56.00, "Dining", "Tom", System.currentTimeMillis() - 43200000, 3),
            TransactionEntity("TX_03", "Excursion Fee: Galician Coast", 90.00, "Excursions", "Tom", System.currentTimeMillis() - 36000000, 3),
            TransactionEntity("TX_04", "Elemis Facial Product - Spa Boutique", 32.50, "Shopping", "Sarah", System.currentTimeMillis() - 12000000, 5)
        )
        for (tx in initialTransactions) {
            dao.insertTransaction(tx)
        }

        // 7. Seed initial notifications
        val notifications = listOf(
            NotificationEntity("NT_01", "Welcome to My Holiday!", "Thank you for booking your P&O Cruises Mediterranean Discovery cruise aboard the magnificent Iona. Explore activities and plan your days!", System.currentTimeMillis() - 172800000, isRead = true),
            NotificationEntity("NT_02", "Online Check-In Now Open", "Your online check-in window is open. Please upload your passenger passport and register a payment card to receive your digital boarding pass.", System.currentTimeMillis() - 86400000, isRead = false)
        )
        for (nt in notifications) {
            dao.insertNotification(nt)
        }

        // 8. Seed initial chat welcome message
        dao.insertConciergeMessage(ConciergeMessageEntity(
            text = "Welcome aboard Iona, Tom! I am your P&O Cruises Concierge. Ask me anything about your cruise schedule, booking detail, spending, menus, or port arrivals.",
            sender = "AI"
        ))
    }
}
