package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cruise_state")
data class CruiseStateEntity(
    @PrimaryKey val id: Int = 1,
    val currentDayIndex: Int = 0, // 0 to 11 (corresponds to Days 1 to 12)
    val isCruiseStarted: Boolean = false,
    val currentPhase: String = "BOOKED", // BEFORE_BOOKING, BOOKED, APPROACHING, AT_TERMINAL, ON_BOARD, IN_PORT, RETURN_HOME, POST_CRUISE
    val lat: Double = 50.9097, // Southampton
    val lng: Double = -1.4044,
    val speedKts: Double = 0.0,
    val portName: String = "Southampton",
    val weatherTemp: Double = 18.0,
    val weatherDesc: String = "Partly Cloudy",
    val seaConditions: String = "Calm",
    val checkInCompleted: Boolean = false,
    val boardingPassDownloaded: Boolean = false,
    val paymentCardAdded: Boolean = false,
    val onboardBalance: Double = 0.0,
    val usedCredit: Double = 0.0,
    val onboardCredit: Double = 250.0 // Pre-credited £250 onboard credit
)

@Entity(tableName = "booking_details")
data class BookingEntity(
    @PrimaryKey val bookingReference: String = "POC847321",
    val guestName: String = "Tom",
    val guestSurname: String = "Ahyx",
    val loyaltyTier: String = "Mediterranean Blue", // Peninsular Club tiers
    val loyaltyPoints: Int = 180,
    val cabinNumber: String = "C104 (Deck 10)",
    val cabinCategory: String = "Deluxe Balcony Suite",
    val shipName: String = "Iona",
    val cruiseName: String = "Mediterranean Discovery",
    val durationDays: Int = 12,
    val travelPartyCount: Int = 4,
    val departurePort: String = "Southampton",
    val departureDate: String = "24 Aug 2026",
    val arrivalPort: String = "Southampton",
    val balanceRemaining: Double = 0.0
)

@Entity(tableName = "itinerary")
data class ItineraryDayEntity(
    @PrimaryKey val id: Int, // Day 1 to 12
    val dayNumber: Int,
    val portName: String,
    val description: String,
    val arrivalTime: String, // "14:00" or "At Sea"
    val departureTime: String, // "18:00" or "At Sea"
    val latitude: Double,
    val longitude: Double,
    val distanceMiles: Int,
    val currency: String = "GBP",
    val portEmergencyContact: String = "+44 23 8065 0000"
)

@Entity(tableName = "activities")
data class ActivityEntity(
    @PrimaryKey val id: String,
    val category: String, // "DINING", "ENTERTAINMENT", "EXCURSION", "SPA", "DAILY_PROGRAMME"
    val title: String,
    val subtitle: String, // Cuisine, intensity level, show type, or host
    val time: String, // e.g. "18:30" or "09:30"
    val durationMinutes: Int,
    val deck: String, // Deck level e.g. "Deck 6"
    val price: Double, // 0.0 means included
    val location: String, // Venue or Shore Meeting Point
    val dressCode: String = "Evening Casual", // Standard P&O dress codes
    val rating: Double = 4.8,
    val allergens: String = "", // Dietaries
    val capacityLeft: Int = 20,
    val intensity: String = "Low", // "Low", "Medium", "High" (excursions only)
    val description: String = ""
)

@Entity(tableName = "reservations")
data class ReservationEntity(
    @PrimaryKey val reservationId: String,
    val activityId: String,
    val activityType: String, // "DINING", "ENTERTAINMENT", "EXCURSION", "SPA"
    val title: String,
    val time: String,
    val pricePaid: Double,
    val partySize: Int,
    val location: String,
    val dayNumber: Int, // Cruise day number (1-12)
    val bookingTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val description: String,
    val amount: Double,
    val category: String, // "Dining", "Drinks", "Spa", "Excursions", "Shopping", "Other"
    val guestName: String = "Tom",
    val timestamp: Long = System.currentTimeMillis(),
    val dayNumber: Int
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val isEmergency: Boolean = false
)

@Entity(tableName = "concierge_messages")
data class ConciergeMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val sender: String, // "USER" or "AI"
    val timestamp: Long = System.currentTimeMillis()
)
