package com.example

import android.app.Application
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import com.example.ui.viewmodel.CruiseViewModel
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

// Helper extension on Flow to avoid race conditions and delays in async tests
suspend fun <T> kotlinx.coroutines.flow.Flow<T>.waitUntil(timeoutMs: Long = 2000, condition: (T) -> Boolean): T {
    val startTime = System.currentTimeMillis()
    while (System.currentTimeMillis() - startTime < timeoutMs) {
        org.robolectric.shadows.ShadowLooper.idleMainLooper()
        val current = try {
            withTimeout(100) { this@waitUntil.first() }
        } catch (e: Exception) {
            null
        }
        if (current != null && condition(current)) {
            return current
        }
        kotlinx.coroutines.delay(20)
    }
    throw AssertionError("Timed out waiting for condition after $timeoutMs ms")
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CruiseAppUnitTest {

    private lateinit var context: Application
    private lateinit var database: AppDatabase
    private lateinit var dao: CruiseDao
    private lateinit var repository: CruiseRepository
    private lateinit var viewModel: CruiseViewModel

    @Before
    fun setUp() = runBlocking {
        context = ApplicationProvider.getApplicationContext()
        
        // Build isolated in-memory database with main thread queries allowed for test runner main thread execution
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        
        AppDatabase.setTestDatabase(database)
        
        dao = database.cruiseDao()
        repository = CruiseRepository(dao)
        
        // Seed database cleanly for this test run
        repository.seedDatabaseIfEmpty()
        
        viewModel = CruiseViewModel(context)
        kotlinx.coroutines.delay(100)
    }

    @Test
    fun testDatabaseSeedingAndDefaults() = runBlocking {
        // Verify Itinerary has 12 seeded days
        val itinerary = repository.itineraryFlow.first()
        assertEquals("Should have exactly 12 itinerary days", 12, itinerary.size)
        assertEquals("Day 1 port should be Southampton", "Southampton", itinerary[0].portName)
        assertEquals("Day 12 port should be Southampton", "Southampton", itinerary[11].portName)

        // Verify Onboard activities have seeded correctly
        val activities = repository.activitiesFlow.first()
        assertTrue("Should seed at least 15 activities", activities.size >= 15)

        val diningActivities = activities.filter { it.category == "DINING" }
        assertTrue("Should have seeded dining options", diningActivities.isNotEmpty())

        // Verify Booking details seeded
        val booking = repository.bookingFlow.first()
        assertNotNull("Booking should be initialized", booking)
        assertEquals("Passenger guest name should be Tom", "Tom", booking?.guestName)
        assertEquals("Peninsular Club points", 180, booking?.loyaltyPoints)
    }

    @Test
    fun testSimulationLifecycleTransitions() = runBlocking {
        println("--- testSimulationLifecycleTransitions START ---")
        // 1. Initial pre-embarkation state
        viewModel.resetSimulation()
        println("Reset simulation triggered")
        var cruiseState = repository.cruiseStateFlow.filterNotNull().waitUntil { it.currentPhase == "BOOKED" }
        println("Phase: BOOKED verified, portName: ${cruiseState.portName}")
        assertEquals("Southampton", cruiseState.portName)
        assertEquals(0.0, cruiseState.speedKts, 0.01)
        assertFalse(cruiseState.isCruiseStarted)
        assertFalse(cruiseState.checkInCompleted)

        // 2. Advance to Terminal check-in
        println("Advancing to Step 1 (Terminal)...")
        viewModel.advanceSimulation() // step 1
        cruiseState = repository.cruiseStateFlow.filterNotNull().waitUntil { it.currentPhase == "AT_TERMINAL" }
        println("Phase: AT_TERMINAL verified")
        assertTrue(cruiseState.checkInCompleted)
        assertTrue(cruiseState.boardingPassDownloaded)

        // 3. Advance to Boarding Completed
        println("Advancing to Step 2 (On Board)...")
        viewModel.advanceSimulation() // step 2
        cruiseState = repository.cruiseStateFlow.filterNotNull().waitUntil { it.currentPhase == "ON_BOARD" && it.isCruiseStarted }
        println("Phase: ON_BOARD verified")

        // 4. Advance to Sailaway Outbound Southampton
        println("Advancing to Step 3 (Sailaway)...")
        viewModel.advanceSimulation() // step 3
        cruiseState = repository.cruiseStateFlow.filterNotNull().waitUntil { it.speedKts == 18.5 }
        println("Speed 18.5 verified, currentPhase: ${cruiseState.currentPhase}")
        assertEquals("ON_BOARD", cruiseState.currentPhase)
        assertTrue("Sailaway should update latitude", cruiseState.lat != 50.9097)

        // Check if sailaway drink transaction was recorded
        val txs = repository.allTransactionsFlow.waitUntil { list ->
            list.any { it.description.contains("Sailaway") }
        }
        println("Transactions count: ${txs.size}")
        assertTrue("Should record sailaway drink transaction", txs.any { it.description.contains("Sailaway") })
        println("--- testSimulationLifecycleTransitions END ---")
    }

    @Test
    fun testBookingConflictDetection() = runBlocking {
        val activities = repository.activitiesFlow.first()
        // Let's grab two dining activities scheduled for similar times
        val sindhu = activities.first { it.id == "DIN_SINDHU" } // Scheduled 18:30
        val glassHouse = activities.first { it.id == "DIN_GLASS" } // Scheduled 19:00

        // Reset reservations
        val currentRes = repository.allReservationsFlow.first()
        for (res in currentRes) {
            repository.cancelReservation(res.reservationId)
        }
        
        // Collect StateFlow in a background job so the StateFlow updates correctly
        val collectJob = launch {
            viewModel.reservations.collect {}
        }
        
        // Wait until reservations is empty
        viewModel.reservations.waitUntil { it.isEmpty() }

        // Book Sindhu for Day 3
        val sindhuConflict = viewModel.bookActivity(sindhu, 3, partySz = 2)
        assertNull("First booking on Day 3 should have no conflict", sindhuConflict)
        
        // Wait for database insert and state flow propagation to complete
        viewModel.reservations.waitUntil { list -> list.any { it.activityId == "DIN_SINDHU" } }

        // Book Glass House for Day 3 (Overlaps!)
        val glassConflict = viewModel.bookActivity(glassHouse, 3, partySz = 2)
        assertNotNull("Should detect conflict with Sindhu booking", glassConflict)
        assertTrue("Warning should mention 'Sindhu' or show overlapping details", glassConflict?.contains("Sindhu") == true)

        collectJob.cancel()
    }

    @Test
    fun testOfflineConciergeFallback() {
        // Query emergency on board details
        val emergencyResponse = GeminiService.localFallback("What are the emergency numbers on board?")
        assertTrue("Should return medical center details", emergencyResponse.contains("Medical Centre") || emergencyResponse.contains("99"))

        // Query ports docked info - use "excursion" to trigger Vigo fallback
        val portResponse = GeminiService.localFallback("When do we return from Vigo excursion?")
        assertTrue("Should return Vigo Spain port details", portResponse.contains("Vigo") || portResponse.contains("Vigo"))

        // Unknown queries
        val unknownResponse = GeminiService.localFallback("How much is a bottle of Dom Perignon?")
        assertTrue("Should guide passenger politely", unknownResponse.contains("Iona") || unknownResponse.contains("assist"))
    }
}
