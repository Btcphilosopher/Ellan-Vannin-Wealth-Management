export interface DataCentre {
  id: string;
  name: string;
  location: string;
  coordinates: [number, number];
  powerCapacityMw: number;
  gpuCapacity: number;
  storagePetabytes: number;
  renewablePercentage: number;
  renewableSource: string;
  coolingTech: string;
  fibreConnections: string[];
  landOwnership: string;
  buildingValue: number;
  hardwareValue: number;
  annualRevenue: number;
  operatingCost: number;
  utilization: number;
  uptime: number;
  strategicReserveGpus: number;
  commercialGpus: number;
}

export interface PortfolioSummary {
  totalAssets: number;
  assetValue: number;
  revenue: number;
  ebitda: number;
  avgUtilization: number;
  avgUptime: number;
  totalPowerMw: number;
  capitalDeployed: number;
  irr: number;
}

export interface HistoryItem {
  month: string;
  revenue: number;
  ebitda: number;
  uptime: number;
  utilization: number;
  energyMw: number;
}

export interface PortfolioResponse {
  summary: PortfolioSummary;
  assets: DataCentre[];
  history: HistoryItem[];
}

export interface QuoteRequest {
  gpusRequested: number;
  hoursNeeded: number;
  priority: 'critical' | 'strategic' | 'flexible';
  workloadType: string;
}

export interface QuoteResponse {
  quoteId: string;
  allocatedSite: string;
  allocatedSiteId: string;
  gpusAllocated: number;
  totalPowerConsumptionMwh: number;
  electricityCost: number;
  depreciationCost: number;
  finalPrice: number;
  marginPercentage: number;
  greenMatchStatus: string;
  status: string;
}

export interface HourlyForecast {
  time: string;
  gridPriceMwh: number;
  windGenMw: number;
  solarGenMw: number;
  renewableTotal: number;
  batterySoc: number;
  batteryState: string;
  action: string;
}

export interface EnergyReport {
  currentPrice: number;
  avgPrice: number;
  renewableMixPercentage: number;
  batterySystemCapacityMwh: number;
  hours: HourlyForecast[];
}

export interface SimulationParams {
  assetId: string;
  gpuScale: number;
  gridPriceModifier: number;
  demandMultiplier: number;
}

export interface TwinSimulationResponse {
  assetId: string;
  assetName: string;
  simGpus: number;
  simPowerCapacity: number;
  pue: number;
  simUtilization: number;
  simRevenue: number;
  simOperatingCost: number;
  simEbitda: number;
  ebitdaDelta: number;
  carbonFootprintTons: number;
  strategicReserveSimGpus: number;
  coolingPerformance: string;
}

export interface InvestmentInput {
  campusName: string;
  landCapex: number;
  constructionCapex: number;
  powerConnectionCapex: number;
  gpusInstalled: number;
  targetRentPerGpuMonth: number;
}

export interface CashflowYear {
  year: number;
  value: number;
}

export interface InvestmentResult {
  campusName: string;
  totalCapexUsd: number;
  annualRevenue: number;
  annualOpex: number;
  annualEbitda: number;
  irr: number;
  npvUsd: number;
  paybackYears: number;
  assetLtv: number;
  yearlyCashflows: CashflowYear[];
}

export interface ReserveAllocationInput {
  agencyName: string;
  coresRequested: number;
  durationHours: number;
  emergencyCode?: string;
}

export interface ReserveAllocationResponse {
  reserveTicket: string;
  agencyName: string;
  allocatedGpus: number;
  durationHours: number;
  emergencyOverride: boolean;
  status: string;
  gridPriority: string;
  associatedCampus: string;
  energyPreemptionMw: number;
}

export interface RiskMetric {
  portfolioBaseValue: number;
  valueAtRisk95: number;
  p10Val: number;
  p50Val: number;
  p90Val: number;
  riskRating: string;
}

export interface StressScenario {
  name: string;
  impact: string;
  probability: string;
  status: string;
}

export interface SimulationBin {
  range: string;
  count: number;
}

export interface RiskSimulationResponse {
  metrics: RiskMetric;
  stressScenarios: StressScenario[];
  bins: SimulationBin[];
}

export type SovereignRole = 'CEO' | 'Investment Committee' | 'Operations Team' | 'Engineers' | 'Analysts';
