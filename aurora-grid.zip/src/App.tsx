import React, { useState, useEffect } from 'react';
import { DataCentre, HistoryItem, PortfolioSummary, SovereignRole } from './types';
import DashboardHeader from './components/DashboardHeader';
import AssetRegisterView from './components/AssetRegisterView';
import ComputeMarketplaceView from './components/ComputeMarketplaceView';
import EnergyOptimisationView from './components/EnergyOptimisationView';
import DigitalTwinView from './components/DigitalTwinView';
import InvestmentModelView from './components/InvestmentModelView';
import SovereignComputeReserveView from './components/SovereignComputeReserveView';
import GeographicScannerView from './components/GeographicScannerView';
import RiskEngineView from './components/RiskEngineView';
import AIAdvisor from './components/AIAdvisor';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { 
  Building2, Cpu, Zap, Coins, Clock, LayoutDashboard, Database, 
  ShoppingCart, ShieldCheck, HelpCircle, Compass, ShieldAlert, Loader2,
  LineChart, TrendingUp
} from 'lucide-react';

export default function App() {
  const [role, setRole] = useState<SovereignRole>('CEO');
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [assets, setAssets] = useState<DataCentre[]>([]);
  const [summary, setSummary] = useState<PortfolioSummary | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchPortfolioData = async () => {
    try {
      const response = await fetch('/api/portfolio');
      const data = await response.json();
      setAssets(data.assets);
      setSummary(data.summary);
      setHistory(data.history);
    } catch (err) {
      console.error("Failed to fetch sovereign portfolio data", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPortfolioData();
  }, []);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  if (isLoading || !summary) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#0A0B0D] text-[#E0E2E5] p-12">
        <Loader2 className="h-10 w-10 animate-spin text-[#00F2FF] mb-3" />
        <h2 className="text-xs font-mono font-bold uppercase tracking-widest text-[#00F2FF]">Aurora Grid Core</h2>
        <p className="text-[#7A818E] text-xs mt-1">Acquiring cryptographic subsea telemetry and energy-grid metrics...</p>
      </div>
    );
  }

  // Recommended tabs depending on the active sovereign role
  const getRecommendedTab = () => {
    switch (role) {
      case 'CEO': return 'dashboard';
      case 'Investment Committee': return 'irr';
      case 'Operations Team': return 'energy';
      case 'Engineers': return 'twins';
      case 'Analysts': return 'risk';
      default: return 'dashboard';
    }
  };

  const tabs = [
    { id: 'dashboard', label: 'Portfolio Overview', icon: LayoutDashboard },
    { id: 'assets', label: 'Asset Register', icon: Database },
    { id: 'marketplace', label: 'Compute Market', icon: ShoppingCart },
    { id: 'energy', label: 'Grid Optimiser', icon: Zap },
    { id: 'twins', label: 'Digital Twins', icon: Cpu },
    { id: 'irr', label: 'IRR Modeler', icon: Coins },
    { id: 'reserves', label: 'Strategic Reserves', icon: ShieldCheck },
    { id: 'scanner', label: 'Geo Scanner', icon: Compass },
    { id: 'risk', label: 'Risk Engine', icon: ShieldAlert },
    { id: 'advisor', label: 'Sovereign Advisor', icon: HelpCircle }
  ];

  return (
    <div className="min-h-screen bg-[#0A0B0D] text-[#E0E2E5] flex flex-col font-sans selection:bg-[#00F2FF] selection:text-[#0A0B0D]" id="aurora-grid-app">
      {/* Institutional Header */}
      <DashboardHeader currentRole={role} onRoleChange={(r) => {
        setRole(r);
        // Automatically route to their recommended task hub
        switch(r) {
          case 'CEO': setActiveTab('dashboard'); break;
          case 'Investment Committee': setActiveTab('irr'); break;
          case 'Operations Team': setActiveTab('energy'); break;
          case 'Engineers': setActiveTab('twins'); break;
          case 'Analysts': setActiveTab('risk'); break;
        }
      }} />

      {/* Primary Workspace */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-px bg-[#1F2228] border-b border-[#1F2228]" id="tab-navigation">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            const isRecommended = getRecommendedTab() === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-btn-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-4 py-3 rounded-none text-[10px] font-mono uppercase tracking-widest transition-all cursor-pointer relative ${
                  isActive
                    ? 'bg-[#0F1115] text-[#00F2FF] border-b border-[#00F2FF] font-bold'
                    : 'bg-[#0A0B0D] text-[#7A818E] hover:text-[#E0E2E5] hover:bg-[#15171C]'
                }`}
              >
                <Icon className={`h-3.5 w-3.5 ${isActive ? 'text-[#00F2FF]' : 'text-[#7A818E]'}`} />
                <span>{tab.label}</span>
                {isRecommended && !isActive && (
                  <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse" title="Recommended for your active role" />
                )}
              </button>
            );
          })}
        </div>

        {/* Content Panels */}
        <div className="transition-all" id="workspace-panel">
          
          {/* TAB 1: Macro Portfolio Dashboard */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6" id="dashboard-tab">
              {/* Macro KPI Blocks */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-px bg-[#1F2228] border border-[#1F2228]">
                <div className="bg-[#0F1115] p-5 rounded-none flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-[#7A818E] uppercase tracking-[0.2em] font-bold block">Portfolio NAV</span>
                    <span className="text-xl md:text-2xl font-light font-mono text-[#E0E2E5] leading-tight block mt-2">{formatCurrency(summary.assetValue)}</span>
                  </div>
                  <span className="text-[9px] font-mono text-green-500 block mt-2">▲ Asset Book Valuation</span>
                </div>

                <div className="bg-[#0F1115] p-5 rounded-none flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-[#7A818E] uppercase tracking-[0.2em] font-bold block">Annual EBITDA</span>
                    <span className="text-xl md:text-2xl font-light font-mono text-[#E0E2E5] leading-tight block mt-2">{formatCurrency(summary.ebitda)}</span>
                  </div>
                  <span className="text-[9px] font-mono text-[#00F2FF] block mt-2">Margin: {Number(((summary.ebitda / summary.revenue) * 100).toFixed(1))}%</span>
                </div>

                <div className="bg-[#0F1115] p-5 rounded-none flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-[#7A818E] uppercase tracking-[0.2em] font-bold block">Fund IRR hurdle</span>
                    <span className="text-xl md:text-2xl font-light font-mono text-[#E0E2E5] leading-tight block mt-2">{summary.irr}%</span>
                  </div>
                  <span className="text-[9px] font-mono text-amber-500 block mt-2">Target Equity Yield</span>
                </div>

                <div className="bg-[#0F1115] p-5 rounded-none flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-[#7A818E] uppercase tracking-[0.2em] font-bold block">Avg Utilisation</span>
                    <span className="text-xl md:text-2xl font-light font-mono text-[#E0E2E5] leading-tight block mt-2">{summary.avgUtilization}%</span>
                  </div>
                  <span className="text-[9px] font-mono text-blue-400 block mt-2">Cluster Core Load</span>
                </div>

                <div className="bg-[#0F1115] p-5 rounded-none col-span-2 lg:col-span-1 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-[#7A818E] uppercase tracking-[0.2em] font-bold block">Avg SLA Uptime</span>
                    <span className="text-xl md:text-2xl font-light font-mono text-[#E0E2E5] leading-tight block mt-2">{summary.avgUptime}%</span>
                  </div>
                  <span className="text-[9px] font-mono text-green-500 block mt-2">Weighted Average</span>
                </div>
              </div>

              {/* Chart Block */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-[#0F1115] rounded-none border border-[#1F2228] p-6">
                  <div className="flex justify-between items-center border-b border-[#1F2228] pb-4 mb-4">
                    <div>
                      <h3 className="font-serif italic text-lg text-[#E0E2E5]">Sovereign Asset Financial Growth History</h3>
                      <p className="text-[#7A818E] text-xs mt-0.5">Trailing 12-month consolidated fund gross revenues and EBITDA cashflows.</p>
                    </div>
                    <span className="text-[10px] bg-[#0A0B0D] border border-[#1F2228] font-mono uppercase text-[#7A818E] px-3 py-1.5 rounded-none flex items-center gap-1.5">
                      <LineChart className="h-3.5 w-3.5 text-[#00F2FF]" />
                      Historical
                    </span>
                  </div>

                  <div className="h-72" id="portfolio-history-chart">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={history} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#00F2FF" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#00F2FF" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1F2228" />
                        <XAxis dataKey="month" stroke="#7A818E" fontSize={11} tickLine={false} />
                        <YAxis stroke="#7A818E" fontSize={11} tickLine={false} tickFormatter={(val) => `$${(val / 1000000).toFixed(0)}M`} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#0F1115', borderColor: '#1F2228', borderRadius: '0px', color: '#E0E2E5' }}
                          itemStyle={{ color: '#E0E2E5' }}
                          formatter={(val: number) => [formatCurrency(val), 'USD']}
                        />
                        <Area name="Gross Revenue" type="monotone" dataKey="revenue" stroke="#00F2FF" fillOpacity={1} fill="url(#colorRev)" strokeWidth={2.5} />
                        <Area name="EBITDA" type="monotone" dataKey="ebitda" stroke="#7A818E" fillOpacity={0} strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* AI advisor teaser panel */}
                <div className="lg:col-span-1">
                  <AIAdvisor currentRole={role} portfolioMetrics={assets} />
                </div>
              </div>

              {/* Asset Register List (Mini view or teaser link) */}
              <div className="bg-[#0F1115] rounded-none border border-[#1F2228] p-6">
                <div className="flex justify-between items-center border-b border-[#1F2228] pb-4 mb-4">
                  <div>
                    <h3 className="font-serif italic text-lg text-[#E0E2E5]">Active Infrastructure Portfolio</h3>
                    <p className="text-[#7A818E] text-xs mt-0.5">Direct capital allocations currently owned and operated by Ellan Vannin Wealth Management.</p>
                  </div>
                  <button 
                    onClick={() => setActiveTab('assets')}
                    id="btn-goto-assets"
                    className="text-xs font-mono text-[#00F2FF] hover:underline cursor-pointer uppercase tracking-wider"
                  >
                    Manage Register →
                  </button>
                </div>
                <AssetRegisterView assets={assets} />
              </div>
            </div>
          )}

          {/* TAB 2: Asset Register Detailed */}
          {activeTab === 'assets' && (
            <div id="assets-tab">
              <AssetRegisterView assets={assets} />
            </div>
          )}

          {/* TAB 3: Compute Marketplace */}
          {activeTab === 'marketplace' && (
            <div id="marketplace-tab">
              <ComputeMarketplaceView />
            </div>
          )}

          {/* TAB 4: Energy Optimiser */}
          {activeTab === 'energy' && (
            <div id="energy-tab">
              <EnergyOptimisationView />
            </div>
          )}

          {/* TAB 5: Digital Twins */}
          {activeTab === 'twins' && (
            <div id="twins-tab">
              <DigitalTwinView assets={assets} />
            </div>
          )}

          {/* TAB 6: Investment modeler */}
          {activeTab === 'irr' && (
            <div id="irr-tab">
              <InvestmentModelView />
            </div>
          )}

          {/* TAB 7: Sovereign Reserves */}
          {activeTab === 'reserves' && (
            <div id="reserves-tab">
              <SovereignComputeReserveView />
            </div>
          )}

          {/* TAB 8: Geographic Scanner */}
          {activeTab === 'scanner' && (
            <div id="scanner-tab">
              <GeographicScannerView />
            </div>
          )}

          {/* TAB 9: Risk Engine */}
          {activeTab === 'risk' && (
            <div id="risk-tab">
              <RiskEngineView />
            </div>
          )}

          {/* TAB 10: Sovereign AI Advisor */}
          {activeTab === 'advisor' && (
            <div id="advisor-tab" className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full min-h-[500px]">
              <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 shadow-md p-6 flex flex-col justify-between">
                <div>
                  <h3 className="text-lg font-black text-slate-800 tracking-tight">Institutional Advisor Deck</h3>
                  <p className="text-slate-500 text-sm mt-1 leading-normal">
                    This sovereign advisor utilizes deep transformer modeling to evaluate operational, energy grid, and macroeconomic investment datasets. 
                    The guidelines are structured based on the Ellan Vannin Wealth Management strategic mandates.
                  </p>
                  
                  <div className="mt-6 space-y-4 text-xs md:text-sm text-slate-600">
                    <div className="flex gap-3">
                      <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600 shrink-0 h-fit">
                        <Coins className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-800">Sovereign hurdle rate validation</h4>
                        <p className="text-slate-500 text-xs mt-0.5 leading-normal">Ensuring all green infrastructure acquisitions target a baseline Internal Rate of Return (IRR) exceeding 8% on equity capital.</p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="p-2 bg-blue-50 rounded-lg text-blue-600 shrink-0 h-fit">
                        <Zap className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-800">Dynamic carbon neutrality matching</h4>
                        <p className="text-slate-500 text-xs mt-0.5 leading-normal">Adhering to our 100% renewable match covenants by prioritizing campuses tied directly to offshore wind grids, pumped hydro schemes, and seawater loop thermodynamics.</p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600 shrink-0 h-fit">
                        <ShieldCheck className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-800">Strategic preemption readiness</h4>
                        <p className="text-slate-500 text-xs mt-0.5 leading-normal">Maintaining a permanent 20% dark-reserve of cluster compute power for sovereign emergency dispatching, ensuring national-grade technological resiliency.</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 p-4 bg-slate-50 rounded-xl border border-slate-200/50 flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-semibold">Active Advisory Protocol</span>
                  <span className="text-emerald-600 font-black tracking-wider uppercase bg-emerald-500/10 px-2.5 py-1 rounded-full">Secure Institutional Link</span>
                </div>
              </div>
              <div className="lg:col-span-1">
                <AIAdvisor currentRole={role} portfolioMetrics={assets} />
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Institutional Footer */}
      <footer className="border-t border-[#1F2228] bg-[#0F1115] h-12 flex flex-col sm:flex-row items-center justify-between px-6 py-2 mt-12 gap-2" id="dashboard-footer">
        <div className="flex gap-6 text-[9px] font-mono text-[#7A818E]">
          <span>SYSTEM_UPTIME: 99.999%</span>
          <span>DATA_LATENCY: 1.2ms</span>
          <span>SOVEREIGN_NODE_ENV: PROD</span>
        </div>
        <div className="text-[9px] font-mono text-[#7A818E]">
          &copy; 2026 ELLAN VANNIN WEALTH MANAGEMENT &bull; SOVEREIGN_ASSET_PROTOCOLS
        </div>
      </footer>
    </div>
  );
}
