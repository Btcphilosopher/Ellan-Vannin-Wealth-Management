import React, { useState } from 'react';
import { QuoteRequest, QuoteResponse } from '../types';
import { Cpu, Zap, Activity, ShoppingCart, DollarSign, Loader2, ArrowRight } from 'lucide-react';

export default function ComputeMarketplaceView() {
  const [gpus, setGpus] = useState<number>(1000);
  const [hours, setHours] = useState<number>(72);
  const [priority, setPriority] = useState<'critical' | 'strategic' | 'flexible'>('strategic');
  const [workload, setWorkload] = useState<string>('training');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [quote, setQuote] = useState<QuoteResponse | null>(null);

  const handleRequestQuote = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch('/api/marketplace/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gpusRequested: gpus,
          hoursNeeded: hours,
          priority,
          workloadType: workload
        })
      });
      const data = await response.json();
      setQuote(data);
    } catch (err) {
      console.error("Failed to generate quote", err);
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-[#E0E2E5]" id="compute-marketplace-view">
      {/* Scheduler Form */}
      <form onSubmit={handleRequestQuote} className="lg:col-span-5 bg-[#0F1115] rounded-none border border-[#1F2228] p-6 space-y-5" id="marketplace-request-form">
        <div className="border-b border-[#1F2228] pb-3 flex items-center gap-2">
          <ShoppingCart className="h-4 w-4 text-[#00F2FF]" />
          <h3 className="text-xs font-mono font-bold uppercase tracking-widest text-[#E0E2E5]">Sovereign Compute Allocator</h3>
        </div>

        {/* Workload Profile */}
        <div className="space-y-2">
          <label className="text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em] block">Sovereign Workload Profile</label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'training', name: 'AI Training (LLM)', desc: 'Multi-node clusters' },
              { id: 'inference', name: 'AI Inference (Low Latency)', desc: 'Instant dispatch API' },
              { id: 'hpc', name: 'Scientific (HPC)', desc: 'Double precision nodes' },
              { id: 'government', name: 'Government Encrypted', desc: 'Strategic Isolation' }
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                id={`workload-btn-${item.id}`}
                onClick={() => setWorkload(item.id)}
                className={`p-3 rounded-none border text-left transition-all cursor-pointer ${
                  workload === item.id
                    ? 'bg-[#15171C] border-[#00F2FF] text-[#00F2FF] shadow-none'
                    : 'bg-[#0A0B0D] border-[#1F2228] hover:bg-[#15171C] text-[#7A818E]'
                }`}
              >
                <p className="font-bold text-xs uppercase tracking-wider font-mono">{item.name}</p>
                <p className="text-[9px] font-mono mt-1 text-[#7A818E]">{item.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* GPU slider */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em]">
            <span>Allocated GPU Clustered Array</span>
            <span className="text-[#00F2FF] text-xs font-bold font-mono">{gpus.toLocaleString()} GPUs</span>
          </div>
          <input
            type="range"
            min="100"
            max="16000"
            step="100"
            value={gpus}
            onChange={(e) => setGpus(Number(e.target.value))}
            className="w-full h-1 bg-[#1F2228] rounded-none appearance-none cursor-pointer accent-[#00F2FF]"
          />
          <div className="flex justify-between text-[8px] text-[#7A818E] font-mono font-bold uppercase">
            <span>100 GPUs (Inference)</span>
            <span>16,000 GPUs (Exascale Supercluster)</span>
          </div>
        </div>

        {/* Duration */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em]">
            <span>Compute Lease Duration</span>
            <span className="text-[#00F2FF] text-xs font-bold font-mono">{hours} Hours ({(hours / 24).toFixed(1)} Days)</span>
          </div>
          <input
            type="range"
            min="12"
            max="720"
            step="12"
            value={hours}
            onChange={(e) => setHours(Number(e.target.value))}
            className="w-full h-1 bg-[#1F2228] rounded-none appearance-none cursor-pointer accent-[#00F2FF]"
          />
          <div className="flex justify-between text-[8px] text-[#7A818E] font-mono font-bold uppercase">
            <span>12h (Short batch)</span>
            <span>720h (30 Days continuous)</span>
          </div>
        </div>

        {/* Priority / Grid interaction */}
        <div className="space-y-2">
          <label className="text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em] block">Grid Dispatch Priority</label>
          <div className="space-y-1.5">
            {[
              { id: 'critical', title: 'Critical SLA (P1 Fast-Path)', desc: 'Guaranteed compute matching. Automatic pre-emption protection.', rate: '1.4x Premium Rate' },
              { id: 'strategic', title: 'Standard Commercial Allocation', desc: 'Nominal routing. Standard load-balancing across campuses.', rate: '1.0x Rate' },
              { id: 'flexible', title: 'Grid-Flexible (Demand Response)', desc: 'Runs during surplus green energy blocks. 20% discount.', rate: '0.8x Discount Rate' }
            ].map((p) => (
              <label
                key={p.id}
                className={`flex items-start gap-3 p-3 rounded-none border cursor-pointer transition-all ${
                  priority === p.id
                    ? 'border-[#00F2FF] bg-[#15171C] shadow-none'
                    : 'border-[#1F2228] bg-[#0A0B0D] hover:bg-[#15171C]'
                }`}
              >
                <input
                  type="radio"
                  name="priority"
                  id={`priority-radio-${p.id}`}
                  value={p.id}
                  checked={priority === p.id}
                  onChange={() => setPriority(p.id as any)}
                  className="mt-0.5 accent-[#00F2FF] cursor-pointer"
                />
                <div className="text-left font-mono">
                  <div className="flex justify-between items-center gap-2">
                    <span className="font-bold text-xs text-[#E0E2E5]">{p.title}</span>
                    <span className="text-[8px] bg-[#1F2228] px-2 py-0.5 rounded-none font-bold text-[#7A818E] uppercase">{p.rate}</span>
                  </div>
                  <p className="text-[10px] text-[#7A818E] mt-1 leading-normal">{p.desc}</p>
                </div>
              </label>
            ))}
          </div>
        </div>

        <button
          type="submit"
          id="btn-submit-compute-request"
          disabled={isLoading}
          className="w-full bg-[#00F2FF] hover:bg-[#00D8E6] text-[#0A0B0D] font-mono uppercase tracking-widest text-xs font-bold py-3 px-4 rounded-none flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
        >
          {isLoading ? (
            <>
              <Loader2 className="h-3.5 w-3.5 animate-spin text-[#0A0B0D]" />
              <span>Simulating Rust Routing Engine...</span>
            </>
          ) : (
            <>
              <span>Dispatch Allocation Request</span>
              <ArrowRight className="h-3.5 w-3.5 text-[#0A0B0D]" />
            </>
          )}
        </button>
      </form>

      {/* Quote Display */}
      <div className="lg:col-span-7 flex flex-col justify-between h-full">
        {quote ? (
          <div className="bg-[#0F1115] text-[#E0E2E5] rounded-none p-6 border border-[#1F2228] shadow-none flex flex-col justify-between h-full" id="compute-quote-card">
            <div>
              <div className="flex justify-between items-start border-b border-[#1F2228] pb-4">
                <div>
                  <span className="text-[9px] font-mono text-[#00F2FF] font-bold tracking-widest uppercase bg-[#00F2FF]/10 px-2 py-0.5 rounded-none">
                    {quote.greenMatchStatus}
                  </span>
                  <h3 className="text-base font-serif italic text-white mt-1.5">Sovereign Dispatch Certificate</h3>
                  <p className="text-[#7A818E] text-[10px] font-mono mt-0.5">Reference ID: <span className="font-bold text-[#E0E2E5]">{quote.quoteId}</span></p>
                </div>
                <div className="bg-[#15171C] px-3 py-1 rounded-none text-[10px] font-mono font-bold text-[#00F2FF] border border-[#1F2228]">
                  {quote.status}
                </div>
              </div>

              {/* Cost metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <div className="p-4 bg-[#0A0B0D] rounded-none border border-[#1F2228] flex items-start gap-3">
                  <div className="p-2 bg-[#00F2FF]/10 rounded-none text-[#00F2FF] mt-0.5">
                    <DollarSign className="h-5 w-5" />
                  </div>
                  <div className="font-mono">
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block">Consolidated Price Quote</span>
                    <span className="text-xl font-bold text-[#00F2FF]">{formatCurrency(quote.finalPrice)}</span>
                    <span className="text-[9px] text-[#7A818E] block mt-1">Rate: {formatCurrency(quote.finalPrice / (gpus * hours))}/GPU/hr</span>
                  </div>
                </div>

                <div className="p-4 bg-[#0A0B0D] rounded-none border border-[#1F2228] flex items-start gap-3">
                  <div className="p-2 bg-[#00F2FF]/10 rounded-none text-[#00F2FF] mt-0.5">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div className="font-mono">
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block">Energy Overhead</span>
                    <span className="text-lg font-bold text-[#E0E2E5]">{quote.totalPowerConsumptionMwh.toLocaleString()} MWh</span>
                    <span className="text-[9px] text-[#7A818E] block mt-1">Cost: {formatCurrency(quote.electricityCost)}</span>
                  </div>
                </div>
              </div>

              {/* Detailed Breakdown */}
              <div className="mt-6 space-y-3.5 text-xs font-mono border-t border-[#1F2228] pt-5">
                <h4 className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#7A818E]">Dispatch Allocator Logs</h4>
                <div className="flex justify-between text-[#7A818E]">
                  <span>Routing Campus</span>
                  <span className="font-bold text-[#E0E2E5]">{quote.allocatedSite}</span>
                </div>
                <div className="flex justify-between text-[#7A818E]">
                  <span>Allocated GPU Count</span>
                  <span className="font-bold text-[#E0E2E5]">{quote.gpusAllocated.toLocaleString()} Cores</span>
                </div>
                <div className="flex justify-between text-[#7A818E]">
                  <span>Hardware Wear Depreciation Cost</span>
                  <span className="font-bold text-[#E0E2E5]">{formatCurrency(quote.depreciationCost)}</span>
                </div>
                <div className="flex justify-between text-[#7A818E]">
                  <span>Operating Cost Margin Contribution</span>
                  <span className="font-bold text-[#00F2FF]">{quote.marginPercentage}%</span>
                </div>
              </div>
            </div>

            <div className="mt-6 p-3.5 bg-[#15171C] rounded-none border border-[#1F2228] flex items-center gap-3">
              <div className="p-1.5 bg-[#00F2FF]/10 rounded-none text-[#00F2FF]">
                <Activity className="h-4 w-4" />
              </div>
              <p className="text-[10px] font-mono text-[#7A818E] leading-normal">
                Sovereign security policy: All communication nodes are strictly hardware encasement verified. Workload data remains fully sovereign.
              </p>
            </div>
          </div>
        ) : (
          <div className="bg-[#0F1115] rounded-none border-2 border-dashed border-[#1F2228] p-8 h-full flex flex-col items-center justify-center text-center">
            <div className="p-4 bg-[#0A0B0D] border border-[#1F2228] rounded-none text-[#7A818E] mb-3">
              <Cpu className="h-8 w-8 text-[#00F2FF]" />
            </div>
            <h4 className="text-[#E0E2E5] font-mono font-bold text-sm uppercase tracking-wider">Generate Sovereign Allocation</h4>
            <p className="text-[#7A818E] text-xs max-w-sm mt-1.5 leading-normal font-medium">
              Input GPU cluster sizing, lease timeline, and power grid priority guidelines, then dispatch the request to trigger the live routing optimizer.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
