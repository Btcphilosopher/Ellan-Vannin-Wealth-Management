import React from 'react';
import { Shield, Layers, Users, Zap, Compass, Activity } from 'lucide-react';
import { SovereignRole } from '../types';

interface HeaderProps {
  currentRole: SovereignRole;
  onRoleChange: (role: SovereignRole) => void;
}

export default function DashboardHeader({ currentRole, onRoleChange }: HeaderProps) {
  const roles: { value: SovereignRole; label: string; icon: any; color: string; desc: string }[] = [
    { value: 'CEO', label: 'CEO / Macro', icon: Shield, color: 'text-amber-500 bg-amber-500/10', desc: 'Macro KPIs, fund NAV growth, strategic allocations, and ebitda.' },
    { value: 'Investment Committee', label: 'Investment Board', icon: Compass, color: 'text-[#00F2FF] bg-[#00F2FF]/10', desc: 'IRR validation, new asset proposals, NPV analysis, and CAPEX modeling.' },
    { value: 'Operations Team', label: 'Operations Suite', icon: Activity, color: 'text-green-500 bg-green-500/10', desc: 'Compute allocation, active grid demand response, and facility uptimes.' },
    { value: 'Engineers', label: 'Systems Engineering', icon: Zap, color: 'text-blue-500 bg-blue-500/10', desc: 'Digital twins, PUE liquid immersion performance, and hardware health.' },
    { value: 'Analysts', label: 'Risk & Quant', icon: Users, color: 'text-[#7A818E] bg-slate-800/50', desc: 'Monte Carlo simulations, Value at Risk (VaR), and pricing calculators.' },
  ];

  return (
    <header className="border-b border-[#1F2228] bg-[#0F1115] text-[#E0E2E5] p-4 lg:px-6 shadow-none" id="dashboard-header">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Brand Logo & Meta */}
        <div className="flex items-center gap-4">
          <div className="w-5 h-5 bg-[#00F2FF] rounded-none flex items-center justify-center">
            <div className="w-3 h-3 bg-[#0A0B0D] rotate-45"></div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono font-bold tracking-widest text-sm text-[#00F2FF]">AURORA GRID <span className="text-[#7A818E] font-normal">| SOVEREIGN OS</span></span>
            </div>
            <p className="text-[#7A818E] text-[10px] font-mono tracking-wider mt-0.5 uppercase">Sovereign Digital Infrastructure Core</p>
          </div>
        </div>

        {/* Console Hub / Role Selector */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[9px] font-mono font-bold uppercase tracking-[0.2em] text-[#7A818E]">Institutional Access Console</label>
          <div className="flex flex-wrap gap-1">
            {roles.map((r) => {
              const Icon = r.icon;
              const isSelected = currentRole === r.value;
              return (
                <button
                  key={r.value}
                  id={`role-btn-${r.value.toLowerCase().replace(/\s+/g, '-')}`}
                  onClick={() => onRoleChange(r.value)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-none text-[10px] font-mono uppercase tracking-wider transition-all cursor-pointer border ${
                    isSelected
                      ? 'bg-[#15171C] text-[#00F2FF] border-[#00F2FF] font-bold'
                      : 'bg-[#0A0B0D] text-[#7A818E] hover:text-[#E0E2E5] hover:border-[#7A818E]/50 border-[#1F2228]'
                  }`}
                >
                  <Icon className={`h-3 w-3 ${isSelected ? 'text-[#00F2FF]' : 'text-[#7A818E]'}`} />
                  <span>{r.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Advisory Status Header bar */}
      <div className="max-w-7xl mx-auto mt-4 bg-[#0A0B0D] rounded-none p-3 border border-[#1F2228] flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          <p className="text-[10px] font-mono text-[#E0E2E5]">
            <span className="font-bold text-[#00F2FF]">SECURITY CLEARANCE ACTIVE:</span> {currentRole} MODE. <span className="text-[#7A818E]">{roles.find(r => r.value === currentRole)?.desc}</span>
          </p>
        </div>
        <div className="hidden md:block text-[9px] font-mono text-[#7A818E]">
          RUST_NODE_CONNECTED: MAINNET-V1.04
        </div>
      </div>
    </header>
  );
}
