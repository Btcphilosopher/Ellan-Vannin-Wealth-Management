import React, { useState } from 'react';
import { Compass, Star, ChevronRight, CheckCircle2 } from 'lucide-react';

interface LocationItem {
  name: string;
  score: number;
  status: string;
  irr: number;
  powerPriceMwh: number;
  renewable: number;
  fibreScore: number;
  politicalStability: number;
  advantages: string[];
}

export default function GeographicScannerView() {
  const locations: LocationItem[] = [
    { name: "Douglas Harbor Vault (Isle of Man)", score: 95, status: "Feasibility", irr: 16.2, powerPriceMwh: 42.0, renewable: 98, fibreScore: 95, politicalStability: 99, advantages: ["Direct marine seawater loop cooling", "Off-grid tidal coupling", "100% tax-sheltered sovereign fund asset"] },
    { name: "Hull Port Hub (Expansion) (United Kingdom)", score: 92, status: "Active Bid", irr: 14.8, powerPriceMwh: 48.0, renewable: 100, fibreScore: 90, politicalStability: 95, advantages: ["Dogger Bank offshore wind direct link", "Port industrial tax advantages", "Fibre landing station link"] },
    { name: "Isle of Man North Sand (Pre-Development)", score: 91, status: "Planning", irr: 15.5, powerPriceMwh: 40.0, renewable: 100, fibreScore: 91, politicalStability: 99, advantages: ["Low land acquisition cost", "Direct Celtic subsea fibre loop", "High community support"] },
    { name: "Shetland Tidal Grid (Scotland)", score: 88, status: "Planning", irr: 13.9, powerPriceMwh: 38.0, renewable: 100, fibreScore: 82, politicalStability: 95, advantages: ["Low climate cooling overhead", "High offshore wind & tidal correlation", "Favourable Scottish enterprise grants"] },
    { name: "Belfast Sovereign Link (Northern Ireland)", score: 84, status: "Evaluation", irr: 12.5, powerPriceMwh: 54.0, renewable: 85, fibreScore: 88, politicalStability: 90, advantages: ["Strong local workforce pool", "Direct link to Dublin fibre highway", "Good municipal incentives"] }
  ];

  const [selectedLoc, setSelectedLoc] = useState<LocationItem>(locations[0]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="geographic-scanner-view">
      {/* Locations List */}
      <div className="lg:col-span-5 space-y-4">
        <div className="border-b border-slate-100 pb-3 flex items-center gap-2">
          <Compass className="h-5 w-5 text-emerald-600" />
          <h3 className="text-base font-black text-slate-800 tracking-tight">Geographic Investment Scanner</h3>
        </div>
        <p className="text-slate-500 text-xs font-medium">Evaluating and ranking potential digital infrastructure sites based on raw power capacity, climate profiles, tax jurisdictions, and subsea fibre link presence.</p>

        <div className="space-y-3">
          {locations.map((loc, idx) => (
            <button
              key={idx}
              id={`loc-btn-${idx}`}
              onClick={() => setSelectedLoc(loc)}
              className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer ${
                selectedLoc.name === loc.name
                  ? 'bg-slate-900 border-slate-900 text-slate-100 shadow-md ring-2 ring-emerald-500/20'
                  : 'bg-white hover:bg-slate-50 border-slate-200/80 text-slate-700'
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-bold text-sm tracking-tight">{loc.name}</h4>
                  <p className={`text-xs mt-0.5 ${selectedLoc.name === loc.name ? 'text-emerald-400' : 'text-slate-500'}`}>Status: {loc.status}</p>
                </div>
                <div className="flex items-center gap-1.5 bg-emerald-500/10 text-emerald-500 font-black px-2.5 py-1 rounded-lg text-xs">
                  <Star className="h-3 w-3 fill-emerald-500 stroke-none" />
                  <span>{loc.score} / 100</span>
                </div>
              </div>

              <div className="flex justify-between items-center mt-3 pt-3 border-t border-slate-200/20 text-xs font-semibold">
                <span className={selectedLoc.name === loc.name ? 'text-slate-400' : 'text-slate-500'}>Expected IRR</span>
                <span className="font-bold text-emerald-500 text-sm">{loc.irr}%</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Selected Location Deep-Dive */}
      <div className="lg:col-span-7">
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-md p-6 h-full flex flex-col justify-between" id="location-detail-panel">
          <div>
            <div className="border-b border-slate-100 pb-4">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-700">Scanner Rank #1 Opportunity</span>
              </div>
              <h3 className="text-xl font-black text-slate-800 mt-1">{selectedLoc.name}</h3>
              <p className="text-slate-500 text-xs mt-0.5">Assigned Status Code: <span className="font-bold text-slate-700 uppercase">{selectedLoc.status}</span></p>
            </div>

            {/* Scorecard Matrix */}
            <div className="grid grid-cols-2 gap-4 mt-6">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100/80">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Average Grid Price</span>
                <span className="text-lg font-black text-slate-800">${selectedLoc.powerPriceMwh} <span className="text-xs text-slate-500 font-bold">/ MWh</span></span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100/80">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Renewable Index</span>
                <span className="text-lg font-black text-emerald-600">{selectedLoc.renewable}% Match</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100/80">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Fibre Link Interconnect</span>
                <span className="text-lg font-black text-slate-800">{selectedLoc.fibreScore} / 100</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100/80">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Sovereign Political Stability</span>
                <span className="text-lg font-black text-slate-800">{selectedLoc.politicalStability} / 100</span>
              </div>
            </div>

            {/* Strategic Advantages */}
            <div className="mt-6 space-y-3.5">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">Strategic Sovereign Advantages</h4>
              <div className="space-y-2">
                {selectedLoc.advantages.map((adv, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-sm text-slate-700">
                    <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500 mt-0.5 shrink-0" />
                    <span className="font-medium leading-relaxed">{adv}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 block font-semibold">Forecast NPV (Joint Venture Model)</span>
              <span className="text-lg font-black text-slate-850">${(selectedLoc.irr * 4.2).toFixed(1)}M USD</span>
            </div>
            <button 
              id="btn-scanner-submit-board"
              className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
            >
              <span>Submit to Investment Board</span>
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
