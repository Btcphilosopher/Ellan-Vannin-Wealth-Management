import React, { useState } from 'react';
import { ReserveAllocationResponse } from '../types';
import { ShieldAlert, Server, Activity, ArrowRight, CheckCircle2, Lock } from 'lucide-react';

export default function SovereignComputeReserveView() {
  const [agency, setAgency] = useState<string>('Isle of Man Financial Intelligence Unit');
  const [cores, setCores] = useState<number>(500);
  const [duration, setDuration] = useState<number>(24);
  const [emergencyCode, setEmergencyCode] = useState<string>('');
  const [allocation, setAllocation] = useState<ReserveAllocationResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleAllocate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch('/api/reserve/allocate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agencyName: agency,
          coresRequested: cores,
          durationHours: duration,
          emergencyCode
        })
      });
      const data = await response.json();
      setAllocation(data);
    } catch (err) {
      console.error("Reserve dispatch failed", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-[#E0E2E5]" id="sovereign-reserve-view">
      {/* Request Console */}
      <form onSubmit={handleAllocate} className="lg:col-span-5 bg-[#0F1115] rounded-none border border-[#1F2228] p-6 space-y-5 shadow-none" id="reserve-request-form">
        <div className="border-b border-[#1F2228] pb-3 flex items-center gap-2">
          <Lock className="h-4 w-4 text-[#00F2FF]" />
          <h3 className="text-xs font-mono font-bold text-[#E0E2E5] uppercase tracking-wider">Reserve Preemption Console</h3>
        </div>

        {/* Agency Selection */}
        <div className="space-y-1.5">
          <label className="text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em] block">Sovereign / Security Agency</label>
          <select
            id="reserve-agency-select"
            value={agency}
            onChange={(e) => setAgency(e.target.value)}
            className="w-full bg-[#0A0B0D] border border-[#1F2228] hover:border-[#00F2FF] rounded-none px-3.5 py-2.5 text-xs font-mono font-bold text-[#E0E2E5] outline-none transition-all cursor-pointer"
          >
            <option value="Isle of Man Financial Intelligence Unit">Isle of Man FIU (Securities Audit)</option>
            <option value="Sovereign AI Research Consortium">Sovereign AI Research Group</option>
            <option value="National Emergency Dispatch">National Weather & Emergency Model</option>
            <option value="Ellan Vannin Investment Committee">Strategic Reserve Hold</option>
          </select>
        </div>

        {/* Strategic cores slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em]">
            <span>Strategic Preemption Cores</span>
            <span className="text-[#00F2FF] text-xs font-bold font-mono">{cores} GPUs</span>
          </div>
          <input
            type="range"
            min="100"
            max="3000"
            step="100"
            value={cores}
            id="slider-reserve-cores"
            onChange={(e) => setCores(Number(e.target.value))}
            className="w-full h-1 bg-[#1F2228] rounded-none appearance-none cursor-pointer accent-[#00F2FF]"
          />
        </div>

        {/* Duration slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em]">
            <span>Preemption Block Duration</span>
            <span className="text-[#00F2FF] text-xs font-bold font-mono">{duration} Hours</span>
          </div>
          <input
            type="range"
            min="6"
            max="168"
            step="6"
            value={duration}
            id="slider-reserve-duration"
            onChange={(e) => setDuration(Number(e.target.value))}
            className="w-full h-1 bg-[#1F2228] rounded-none appearance-none cursor-pointer accent-[#00F2FF]"
          />
        </div>

        {/* Emergency preemption code */}
        <div className="space-y-1.5">
          <label className="text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em] block">Strategic Emergency Code</label>
          <input
            type="password"
            id="input-emergency-code"
            value={emergencyCode}
            onChange={(e) => setEmergencyCode(e.target.value)}
            placeholder="EV-STRATEGIC-OVERRIDE for Level-1 Dispatch"
            className="w-full bg-[#0A0B0D] border border-[#1F2228] hover:border-[#00F2FF] rounded-none px-3.5 py-2.5 text-xs font-mono font-bold text-[#E0E2E5] outline-none transition-all placeholder-[#7A818E]"
          />
          <p className="text-[10px] text-[#7A818E] mt-1 font-mono leading-relaxed">
            Inputting the secure preemption override code forces instant load-shedding of commercial flexible workloads, reserving the requested cluster immediately.
          </p>
        </div>

        <button
          type="submit"
          id="btn-trigger-preemption"
          className="w-full bg-[#00F2FF] hover:bg-[#00D8E6] text-[#0A0B0D] font-mono font-bold text-xs uppercase tracking-wider py-3.5 px-4 rounded-none flex items-center justify-center gap-2 transition-all cursor-pointer shadow-none"
        >
          <span>Request Strategic Dispatch</span>
          <ArrowRight className="h-4 w-4" />
        </button>
      </form>

      {/* Allocation Response Status */}
      <div className="lg:col-span-7 flex flex-col justify-between h-full">
        {allocation ? (
          <div className="bg-[#0F1115] text-[#E0E2E5] rounded-none p-6 border border-[#1F2228] shadow-none flex flex-col justify-between h-full" id="reserve-status-card">
            <div>
              <div className="flex justify-between items-start border-b border-[#1F2228] pb-4 gap-4">
                <div>
                  <span className={`text-[9px] font-mono font-bold tracking-widest uppercase px-2.5 py-0.5 rounded-none border ${allocation.emergencyOverride ? 'bg-red-500/10 border-red-500/20 text-red-400' : 'bg-green-500/10 border-green-500/20 text-green-400'}`}>
                    {allocation.emergencyOverride ? 'Level-1 Strategic Preemption Active' : 'Sovereign Commercial Pool'}
                  </span>
                  <h3 className="text-lg font-serif italic text-[#E0E2E5] mt-1.5">Sovereign Dispatch Token</h3>
                  <p className="text-[#7A818E] text-xs mt-0.5 font-mono">Ticket ID: <span className="font-bold text-[#E0E2E5]">{allocation.reserveTicket}</span></p>
                </div>
                <div className="bg-[#0A0B0D] px-3 py-1 rounded-none text-xs font-mono font-bold text-green-400 border border-[#1F2228]">
                  {allocation.status}
                </div>
              </div>

              {/* Specifications */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <div className="p-4 bg-[#0A0B0D] rounded-none border border-[#1F2228] flex items-start gap-3">
                  <div className="p-1.5 bg-[#00F2FF]/10 rounded-none text-[#00F2FF] mt-0.5">
                    <Server className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block">Preempted Capacity</span>
                    <span className="text-base font-bold font-mono text-[#E0E2E5]">{allocation.allocatedGpus.toLocaleString()} GPUs</span>
                    <span className="text-[9px] text-[#7A818E] block mt-0.5 font-mono">Location: {allocation.associatedCampus}</span>
                  </div>
                </div>

                <div className="p-4 bg-[#0A0B0D] rounded-none border border-[#1F2228] flex items-start gap-3">
                  <div className="p-1.5 bg-[#00F2FF]/10 rounded-none text-[#00F2FF] mt-0.5">
                    <Activity className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block">Power Allocation</span>
                    <span className="text-base font-bold font-mono text-[#E0E2E5]">{allocation.energyPreemptionMw} MW</span>
                    <span className="text-[9px] text-[#7A818E] block mt-0.5 font-mono">Grid Priority: {allocation.gridPriority}</span>
                  </div>
                </div>
              </div>

              {/* Log files */}
              <div className="mt-6 space-y-3 font-mono text-xs border-t border-[#1F2228] pt-5">
                <h4 className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#7A818E]">Preemption Sequence</h4>
                <div className="flex justify-between text-[#7A818E]">
                  <span>Authorized Agency</span>
                  <span className="font-bold text-[#E0E2E5]">{allocation.agencyName}</span>
                </div>
                <div className="flex justify-between text-[#7A818E]">
                  <span>Workload duration block</span>
                  <span className="font-bold text-[#E0E2E5]">{allocation.durationHours} Hours</span>
                </div>
                <div className="flex justify-between text-[#7A818E]">
                  <span>Emergency load-shedding</span>
                  <span className={`font-bold ${allocation.emergencyOverride ? 'text-red-400' : 'text-[#7A818E]'}`}>
                    {allocation.emergencyOverride ? 'Triggered (Commercial workloads suspended)' : 'Bypassed (Standard commercial allocation)'}
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 rounded-none bg-[#15171C] border border-[#1F2228] flex items-center gap-3">
              <div className="p-1.5 bg-red-500/10 rounded-none text-red-400">
                <ShieldAlert className="h-4 w-4" />
              </div>
              <p className="text-xs text-[#7A818E] leading-normal font-mono">
                Warning: Strategic preemptions are bound by sovereign wealth fund statutes. Unauthorized overrides generate automated alerts to the Isle of Man Treasury Board.
              </p>
            </div>
          </div>
        ) : (
          <div className="bg-[#0F1115] rounded-none border border-[#1F2228] p-8 h-full flex flex-col items-center justify-center text-center">
            <div className="p-4 bg-[#0A0B0D] border border-[#1F2228] rounded-none text-[#7A818E] mb-4">
              <Lock className="h-8 w-8 text-[#00F2FF]" />
            </div>
            <h4 className="text-[#E0E2E5] font-serif italic text-base mb-1">Sovereign Reserve Security Status</h4>
            <p className="text-[#7A818E] text-xs max-w-sm font-mono leading-relaxed">
              Ellan Vannin maintains a strategic reserve of raw compute power for government crisis dispatching, academic priority computing, and financial systemic stress auditing. Use the console to simulate a preemption.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
