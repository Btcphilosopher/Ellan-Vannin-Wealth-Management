import React, { useState, useEffect } from 'react';
import { InvestmentResult } from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Calculator, DollarSign, Percent, Loader2, ArrowRight } from 'lucide-react';

export default function InvestmentModelView() {
  const [campusName, setCampusName] = useState<string>('Shetland Green Tidal Campus');
  const [land, setLand] = useState<number>(20); // M USD
  const [construction, setConstruction] = useState<number>(65); // M USD
  const [power, setPower] = useState<number>(15); // M USD
  const [gpus, setGpus] = useState<number>(6000);
  const [rent, setRent] = useState<number>(1850); // USD/GPU/month
  const [results, setResults] = useState<InvestmentResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const calculateInvestment = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsLoading(true);
    try {
      const response = await fetch('/api/investment/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          campusName,
          landCapex: land,
          constructionCapex: construction,
          powerConnectionCapex: power,
          gpusInstalled: gpus,
          targetRentPerGpuMonth: rent
        })
      });
      const data = await response.json();
      setResults(data);
    } catch (err) {
      console.error("Investment calculations failed", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    calculateInvestment();
  }, [campusName, land, construction, power, gpus, rent]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="investment-model-view">
      {/* Proposal Builder Form */}
      <form onSubmit={calculateInvestment} className="lg:col-span-5 bg-white rounded-2xl border border-slate-200/80 shadow-md p-6 space-y-5" id="investment-proposal-form">
        <div className="border-b border-slate-100 pb-3 flex items-center gap-2">
          <Calculator className="h-5 w-5 text-emerald-600" />
          <h3 className="text-base font-black text-slate-800 tracking-tight">Investment Board Proposal</h3>
        </div>

        {/* Project Name */}
        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Proposal Identification</label>
          <input
            type="text"
            id="input-campus-name"
            value={campusName}
            onChange={(e) => setCampusName(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-700 outline-none transition-all"
            placeholder="e.g. Shetland Green Tidal Campus"
          />
        </div>

        {/* Land Acquisition */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase tracking-wider">
            <span>Land Acquisition Capex</span>
            <span className="text-emerald-600 text-xs font-black">${land}M USD</span>
          </div>
          <input
            type="range"
            min="5"
            max="100"
            step="5"
            value={land}
            id="slider-land"
            onChange={(e) => setLand(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
        </div>

        {/* Construction */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase tracking-wider">
            <span>Facility Shell & Substation</span>
            <span className="text-emerald-600 text-xs font-black">${construction}M USD</span>
          </div>
          <input
            type="range"
            min="20"
            max="300"
            step="10"
            value={construction}
            id="slider-construction"
            onChange={(e) => setConstruction(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
        </div>

        {/* Power Grid Connection */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase tracking-wider">
            <span>Grid Link & High-Tension Capex</span>
            <span className="text-emerald-600 text-xs font-black">${power}M USD</span>
          </div>
          <input
            type="range"
            min="5"
            max="100"
            step="5"
            value={power}
            id="slider-power"
            onChange={(e) => setPower(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
        </div>

        {/* GPUs Installed */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase tracking-wider">
            <span>Target GPU Cluster Sizing</span>
            <span className="text-indigo-600 text-xs font-black">{gpus.toLocaleString()} GPUs</span>
          </div>
          <input
            type="range"
            min="1000"
            max="20000"
            step="1000"
            value={gpus}
            id="slider-gpus"
            onChange={(e) => setGpus(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
        </div>

        {/* Rent per GPU Month */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase tracking-wider">
            <span>Target GPU Monthly Lease Price</span>
            <span className="text-indigo-600 text-xs font-black">${rent} / Month</span>
          </div>
          <input
            type="range"
            min="1000"
            max="3000"
            step="50"
            value={rent}
            id="slider-rent"
            onChange={(e) => setRent(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
        </div>
      </form>

      {/* Financial Results Panel */}
      <div className="lg:col-span-7 flex flex-col justify-between h-full space-y-4">
        {results ? (
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-md p-6 flex flex-col justify-between h-full" id="investment-results-panel">
            <div>
              {/* Strategic metrics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-b border-slate-100 pb-5">
                <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100 flex items-start gap-3">
                  <div className="p-2 bg-emerald-100 rounded-lg text-emerald-700 mt-0.5">
                    <Percent className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold block">Internal Rate of Return</span>
                    <span className="text-2xl font-black text-emerald-700">{results.irr}%</span>
                    <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">Sovereign Hurdle: 8%</span>
                  </div>
                </div>

                <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-100 flex items-start gap-3">
                  <div className="p-2 bg-indigo-100 rounded-lg text-indigo-700 mt-0.5">
                    <DollarSign className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold block">Net Present Value</span>
                    <span className="text-xl font-black text-indigo-700">{formatCurrency(results.npvUsd)}</span>
                    <span className="text-[10px] text-indigo-600 font-bold block mt-0.5">LTV: {formatCurrency(results.assetLtv)}</span>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex items-start gap-3">
                  <div className="p-2 bg-slate-200 rounded-lg text-slate-700 mt-0.5">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold block">Payback cycle</span>
                    <span className="text-xl font-black text-slate-800">{results.paybackYears} Years</span>
                    <span className="text-[10px] text-slate-500 font-bold block mt-0.5">CAPEX: {formatCurrency(results.totalCapexUsd)}</span>
                  </div>
                </div>
              </div>

              {/* Cashflow bar chart */}
              <div className="mt-6">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-3.5">Discounted Cashflow Projection Schedule (10 Year Horizon)</h4>
                <div className="h-56" id="investment-cashflow-chart">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={results.yearlyCashflows} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="year" stroke="#94a3b8" fontSize={11} tickLine={false} tickFormatter={(val) => val === 0 ? 'Y0 (Capex)' : `Y${val}`} />
                      <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} tickFormatter={(val) => `$${(val / 1000000).toFixed(0)}M`} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '8px' }}
                        formatter={(val: number) => [formatCurrency(val), 'Net cashflow']}
                      />
                      <Bar name="Net Cashflow" dataKey="value" fill="#0f172a" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Simple breakdown details */}
              <div className="mt-6 grid grid-cols-2 gap-4 text-xs bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                <div>
                  <span className="text-slate-400 font-semibold uppercase tracking-wider block">Yearly Gross Revenue</span>
                  <span className="text-sm font-black text-slate-800">{formatCurrency(results.annualRevenue)}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-semibold uppercase tracking-wider block">Yearly Operating Overhead</span>
                  <span className="text-sm font-black text-slate-800">{formatCurrency(results.annualOpex)}</span>
                </div>
                <div className="col-span-2 pt-2 border-t border-slate-200/50">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider block">Net annual EBITDA Contribution</span>
                  <span className="text-sm font-black text-emerald-600">{formatCurrency(results.annualEbitda)}</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200 p-8 h-full flex flex-col items-center justify-center text-center">
            <Loader2 className="h-8 w-8 animate-spin text-slate-300" />
          </div>
        )}
      </div>
    </div>
  );
}
