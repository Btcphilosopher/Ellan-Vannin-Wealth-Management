import React, { useState } from 'react';
import { DataCentre } from '../types';
import { Database, Cpu, Globe, ArrowUpRight, CheckCircle2, ShieldAlert } from 'lucide-react';

interface AssetRegisterViewProps {
  assets: DataCentre[];
}

export default function AssetRegisterView({ assets }: AssetRegisterViewProps) {
  const [selectedAsset, setSelectedAsset] = useState<DataCentre | null>(assets[0] || null);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-[#E0E2E5]" id="asset-register-view">
      {/* Asset List */}
      <div className="lg:col-span-1 space-y-4">
        <h3 className="text-sm font-mono font-bold uppercase tracking-[0.2em] text-[#00F2FF] flex items-center gap-2">
          <Database className="h-4 w-4 text-[#00F2FF]" />
          <span>Sovereign Asset Holdings</span>
        </h3>
        <p className="text-[#7A818E] text-xs font-medium">Click on any asset facility below to inspect the complete hardware register and fiber infrastructure.</p>
        
        <div className="space-y-2">
          {assets.map((asset) => (
            <button
              key={asset.id}
              id={`asset-card-${asset.id}`}
              onClick={() => setSelectedAsset(asset)}
              className={`w-full text-left p-4 rounded-none border transition-all cursor-pointer ${
                selectedAsset?.id === asset.id
                  ? 'bg-[#15171C] border-[#00F2FF] text-[#E0E2E5] shadow-none'
                  : 'bg-[#0F1115] hover:bg-[#15171C] border-[#1F2228] text-[#7A818E]'
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h4 className={`font-mono text-xs uppercase tracking-wider font-bold ${selectedAsset?.id === asset.id ? 'text-[#00F2FF]' : 'text-[#E0E2E5]'}`}>{asset.name}</h4>
                  <p className="text-[10px] font-mono text-[#7A818E] mt-1">{asset.location}</p>
                </div>
                <span className={`text-[9px] font-mono px-2 py-0.5 rounded-none font-bold uppercase tracking-wider ${
                  asset.utilization > 80 
                    ? 'bg-amber-500/10 text-amber-500' 
                    : 'bg-green-500/10 text-green-400'
                }`}>
                  {asset.utilization}% Util
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-[#1F2228] text-[10px] font-mono">
                <div>
                  <p className="text-[#7A818E]">Capacity</p>
                  <p className="font-bold text-[#E0E2E5] mt-0.5">{asset.powerCapacityMw} MW</p>
                </div>
                <div>
                  <p className="text-[#7A818E]">GPU Cores</p>
                  <p className="font-bold text-[#E0E2E5] mt-0.5">{asset.gpuCapacity.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-[#7A818E]">Renewable</p>
                  <p className="font-bold text-green-400 mt-0.5">{asset.renewablePercentage}%</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Asset Deep-Dive */}
      <div className="lg:col-span-2">
        {selectedAsset ? (
          <div className="bg-[#0F1115] rounded-none border border-[#1F2228] p-6 h-full flex flex-col justify-between" id="asset-detail-card">
            <div>
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1F2228] pb-5">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] font-mono font-bold uppercase tracking-widest px-2.5 py-0.5 rounded-none bg-[#00F2FF]/10 text-[#00F2FF]">Tier-4 Sovereign DC</span>
                    <span className="text-[9px] font-mono text-[#7A818E]">Coordinates: {selectedAsset.coordinates.join(', ')}</span>
                  </div>
                  <h3 className="text-xl font-serif italic text-[#E0E2E5] mt-1.5">{selectedAsset.name}</h3>
                  <p className="text-[#7A818E] text-xs mt-0.5">{selectedAsset.location}</p>
                </div>
                <div className="bg-[#0A0B0D] px-4 py-2 border border-[#1F2228] rounded-none text-right">
                  <span className="text-[9px] font-mono text-[#7A818E] block uppercase tracking-wider">Total Book Value</span>
                  <span className="text-lg font-mono font-bold text-[#00F2FF]">{formatCurrency(selectedAsset.buildingValue + selectedAsset.hardwareValue)}</span>
                </div>
              </div>

              {/* Grid Specifications */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                {/* Hardware Stack */}
                <div className="space-y-4">
                  <h4 className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#7A818E] flex items-center gap-1.5">
                    <Cpu className="h-3.5 w-3.5 text-[#00F2FF]" />
                    <span>Hardware Register</span>
                  </h4>
                  <div className="bg-[#0A0B0D] rounded-none p-4 border border-[#1F2228] space-y-3.5 text-xs font-mono">
                    <div className="flex justify-between">
                      <span className="text-[#7A818E]">GPU Architecture</span>
                      <span className="font-bold text-[#E0E2E5]">Sovereign H100 Blocks</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#7A818E]">Total GPU Count</span>
                      <span className="font-black text-[#E0E2E5]">{(selectedAsset.gpuCapacity).toLocaleString()} Units</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#7A818E]">Sovereign Strategic Reserve</span>
                      <span className="font-bold text-amber-500">{selectedAsset.strategicReserveGpus.toLocaleString()} GPUs</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#7A818E]">Commercial Availability</span>
                      <span className="font-bold text-green-400">{selectedAsset.commercialGpus.toLocaleString()} GPUs</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#7A818E]">Storage capacity</span>
                      <span className="font-black text-[#E0E2E5]">{selectedAsset.storagePetabytes} PB (NVMe)</span>
                    </div>
                  </div>
                </div>

                {/* Infrastructure Stack */}
                <div className="space-y-4">
                  <h4 className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#7A818E] flex items-center gap-1.5">
                    <Globe className="h-3.5 w-3.5 text-[#00F2FF]" />
                    <span>Fibre & Cooling Stack</span>
                  </h4>
                  <div className="bg-[#0A0B0D] rounded-none p-4 border border-[#1F2228] space-y-3 text-xs font-mono">
                    <div>
                      <span className="text-[#7A818E] text-[10px] block mb-1">Active Subsea Fibre Corridors</span>
                      <div className="flex flex-wrap gap-1">
                        {selectedAsset.fibreConnections.map((fibre, idx) => (
                          <span key={idx} className="bg-[#15171C] text-[#00F2FF] text-[9px] px-2 py-0.5 rounded-none font-bold border border-[#1F2228]">
                            {fibre}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="pt-2 border-t border-[#1F2228]">
                      <span className="text-[#7A818E] text-[10px] block">Immersion Cooling Architecture</span>
                      <span className="font-bold text-[#E0E2E5] text-xs mt-0.5 block">{selectedAsset.coolingTech}</span>
                    </div>
                    <div className="pt-2 border-t border-[#1F2228]">
                      <span className="text-[#7A818E] text-[10px] block">Grid Interconnect Power Source</span>
                      <span className="font-bold text-green-400 text-xs mt-0.5 block flex items-center gap-1">
                        <CheckCircle2 className="h-3.5 w-3.5 text-green-400 inline" />
                        {selectedAsset.renewableSource} ({selectedAsset.renewablePercentage}% Renewable Match)
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Financial Breakdown */}
              <div className="mt-6 pt-5 border-t border-[#1F2228]">
                <h4 className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#7A818E] mb-3">Asset Financial Performance</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
                  <div className="p-3 bg-[#0A0B0D] rounded-none border border-[#1F2228]">
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-semibold block">Annual Gross Rev</span>
                    <span className="text-sm font-bold text-[#00F2FF] mt-1 block">{formatCurrency(selectedAsset.annualRevenue)}</span>
                  </div>
                  <div className="p-3 bg-[#0A0B0D] rounded-none border border-[#1F2228]">
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-semibold block">Annual Op Cost</span>
                    <span className="text-sm font-bold text-red-400 mt-1 block">{formatCurrency(selectedAsset.operatingCost)}</span>
                  </div>
                  <div className="p-3 bg-[#0A0B0D] rounded-none border border-[#1F2228]">
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-semibold block">EBITDA Contrib</span>
                    <span className="text-sm font-bold text-green-400 mt-1 block">{formatCurrency(selectedAsset.annualRevenue - selectedAsset.operatingCost)}</span>
                  </div>
                  <div className="p-3 bg-[#0A0B0D] rounded-none border border-[#1F2228]">
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-semibold block">Guaranteed SLA</span>
                    <span className="text-sm font-bold text-amber-500 mt-1 block">{selectedAsset.uptime}%</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-[#15171C] rounded-none border border-[#1F2228]">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 bg-[#00F2FF]/10 rounded-none text-[#00F2FF]">
                  <ShieldAlert className="h-4 w-4" />
                </div>
                <p className="text-[10px] font-mono text-[#7A818E] leading-normal">
                  This facility holds physical sovereignty classification. All GPU memory stacks are protected with hardware encasement and audit logs.
                </p>
              </div>
              <button 
                id="btn-dc-export"
                className="bg-[#0A0B0D] hover:bg-[#0F1115] text-[#E0E2E5] border border-[#1F2228] text-[10px] font-mono uppercase px-3 py-1.5 rounded-none flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <span>Export Audit Log</span>
                <ArrowUpRight className="h-3.5 w-3.5 text-[#00F2FF]" />
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-[#0F1115] rounded-none border-2 border-dashed border-[#1F2228] h-full flex flex-col items-center justify-center text-center p-8">
            <Database className="h-10 w-10 text-[#7A818E] mb-2" />
            <p className="text-[#7A818E] text-xs font-mono uppercase tracking-widest">Select asset holding from list to initiate digital telemetry...</p>
          </div>
        )}
      </div>
    </div>
  );
}
