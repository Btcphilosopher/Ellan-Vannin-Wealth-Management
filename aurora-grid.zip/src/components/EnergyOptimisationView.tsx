import React, { useState, useEffect } from 'react';
import { EnergyReport, HourlyForecast } from '../types';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { Zap, Battery, Wind, Sun, Clock, Loader2, ArrowRight } from 'lucide-react';

export default function EnergyOptimisationView() {
  const [data, setData] = useState<EnergyReport | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchForecast = async () => {
      try {
        const response = await fetch('/api/energy/forecast');
        const report = await response.json();
        setData(report);
      } catch (err) {
        console.error("Failed to load energy forecast", err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchForecast();
  }, []);

  if (isLoading || !data) {
    return (
      <div className="flex flex-col items-center justify-center p-12 h-64 bg-[#0A0B0D]">
        <Loader2 className="h-6 w-6 animate-spin text-[#00F2FF] mb-2" />
        <p className="text-[#7A818E] text-xs font-mono uppercase tracking-wider">Acquiring Sovereign Energy Telemetry...</p>
      </div>
    );
  }

  // Get active forecast peak & low hours
  const cheapestHours = [...data.hours].sort((a, b) => a.gridPriceMwh - b.gridPriceMwh).slice(0, 3);
  const peakHours = [...data.hours].sort((a, b) => b.gridPriceMwh - a.gridPriceMwh).slice(0, 3);

  return (
    <div className="space-y-6 text-[#E0E2E5]" id="energy-optimisation-view">
      {/* Top Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-px bg-[#1F2228] border border-[#1F2228]">
        <div className="bg-[#0F1115] p-5 rounded-none flex items-start gap-4">
          <div className="p-2 bg-[#00F2FF]/10 text-[#00F2FF] rounded-none mt-0.5">
            <Zap className="h-4 w-4" />
          </div>
          <div>
            <span className="text-[10px] text-[#7A818E] uppercase tracking-[0.2em] font-bold block">Current Spot Price</span>
            <span className="text-lg md:text-xl font-bold font-mono text-[#E0E2E5] mt-1">${data.currentPrice} <span className="text-[10px] text-[#7A818E]">/ MWh</span></span>
            <span className="text-[9px] text-[#00F2FF] font-mono block mt-1">▲ Live Grid Index</span>
          </div>
        </div>

        <div className="bg-[#0F1115] p-5 rounded-none flex items-start gap-4">
          <div className="p-2 bg-[#00F2FF]/10 text-[#00F2FF] rounded-none mt-0.5">
            <Wind className="h-4 w-4" />
          </div>
          <div>
            <span className="text-[10px] text-[#7A818E] uppercase tracking-[0.2em] font-bold block">Renewable Mix</span>
            <span className="text-lg md:text-xl font-bold font-mono text-[#E0E2E5] mt-1">{data.renewableMixPercentage}%</span>
            <span className="text-[9px] text-green-400 font-mono block mt-1">Wind, Tidal & Solar Match</span>
          </div>
        </div>

        <div className="bg-[#0F1115] p-5 rounded-none flex items-start gap-4">
          <div className="p-2 bg-[#00F2FF]/10 text-[#00F2FF] rounded-none mt-0.5">
            <Battery className="h-4 w-4" />
          </div>
          <div>
            <span className="text-[10px] text-[#7A818E] uppercase tracking-[0.2em] font-bold block">Battery Capacity</span>
            <span className="text-lg md:text-xl font-bold font-mono text-[#E0E2E5] mt-1">{data.batterySystemCapacityMwh} MWh</span>
            <span className="text-[9px] text-amber-500 font-mono block mt-1">Dual-Phase Power Banks</span>
          </div>
        </div>

        <div className="bg-[#0F1115] p-5 rounded-none flex items-start gap-4">
          <div className="p-2 bg-[#00F2FF]/10 text-[#00F2FF] rounded-none mt-0.5">
            <Clock className="h-4 w-4" />
          </div>
          <div>
            <span className="text-[10px] text-[#7A818E] uppercase tracking-[0.2em] font-bold block">Mean Spot Price (24h)</span>
            <span className="text-lg md:text-xl font-bold font-mono text-[#E0E2E5] mt-1">${data.avgPrice} <span className="text-[10px] text-[#7A818E]">/ MWh</span></span>
            <span className="text-[9px] text-[#7A818E] font-mono block mt-1">Weighted Average</span>
          </div>
        </div>
      </div>

      {/* Decision Engine Block */}
      <div className="bg-[#0F1115] text-[#E0E2E5] rounded-none p-6 border border-[#1F2228] shadow-none">
        <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-[#1F2228] pb-5 gap-4">
          <div>
            <span className="text-[9px] font-mono font-bold uppercase tracking-widest px-2.5 py-0.5 rounded-none bg-[#00F2FF]/10 text-[#00F2FF]">
              Sovereign Demand Response
            </span>
            <h3 className="text-lg font-serif italic text-[#E0E2E5] mt-1.5">Sovereign Dispatch Schedule Decisions</h3>
            <p className="text-[#7A818E] text-xs mt-0.5">Automatically aligning complex LLM training batches with local wind, solar, and tidal energy surges.</p>
          </div>
          <div className="flex gap-2 font-mono text-[10px]">
            <div className="bg-green-950/10 border border-green-500/20 px-3.5 py-2 rounded-none text-center">
              <span className="text-[#7A818E] uppercase font-bold block mb-0.5">Capture Surplus</span>
              <span className="font-bold text-green-400">{cheapestHours.map(h => h.time).join(', ')}</span>
            </div>
            <div className="bg-red-950/10 border border-red-500/20 px-3.5 py-2 rounded-none text-center">
              <span className="text-[#7A818E] uppercase font-bold block mb-0.5">Curtail Workload</span>
              <span className="font-bold text-red-400">{peakHours.map(h => h.time).join(', ')}</span>
            </div>
          </div>
        </div>

        {/* Real-Time Chart */}
        <div className="h-72 mt-6" id="energy-recharts-container">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data.hours} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorRenewable" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00F2FF" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#00F2FF" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2228" />
              <XAxis dataKey="time" stroke="#7A818E" fontSize={11} tickLine={false} />
              <YAxis stroke="#7A818E" fontSize={11} tickLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0F1115', borderColor: '#1F2228', borderRadius: '0px', color: '#E0E2E5' }}
                itemStyle={{ color: '#E0E2E5' }}
              />
              <Legend verticalAlign="top" height={36} wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace' }} />
              <Area name="Grid Spot Price ($/MWh)" type="monotone" dataKey="gridPriceMwh" stroke="#ef4444" fillOpacity={1} fill="url(#colorPrice)" strokeWidth={2} />
              <Area name="Renewable Generation (MW)" type="monotone" dataKey="renewableTotal" stroke="#00F2FF" fillOpacity={1} fill="url(#colorRenewable)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Hourly Action Log */}
      <div className="bg-[#0F1115] rounded-none border border-[#1F2228] p-6">
        <h3 className="font-serif italic text-base text-[#E0E2E5] mb-4">Live Dispatch Logs</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1F2228] text-[#7A818E] font-bold uppercase tracking-wider text-[9px]">
                <th className="pb-3 pl-4">Hour</th>
                <th className="pb-3">Grid Spot Price</th>
                <th className="pb-3">Wind / Tidal</th>
                <th className="pb-3">Solar</th>
                <th className="pb-3">Battery Storage</th>
                <th className="pb-3">Operating Action Recommendation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F2228]/50">
              {data.hours.slice(6, 18).map((hour, idx) => {
                const isHigh = hour.gridPriceMwh > 45;
                const isLow = hour.gridPriceMwh < 25;
                return (
                  <tr key={idx} className="hover:bg-[#15171C]/40 transition-colors">
                    <td className="py-3.5 pl-4 font-bold text-[#E0E2E5]">{hour.time}</td>
                    <td className="py-3.5 font-bold">
                      <span className={isHigh ? 'text-red-400' : isLow ? 'text-green-400' : 'text-[#E0E2E5]'}>
                        ${hour.gridPriceMwh.toFixed(2)} / MWh
                      </span>
                    </td>
                    <td className="py-3.5 text-[#7A818E]">{hour.windGenMw} MW</td>
                    <td className="py-3.5 text-[#7A818E]">{hour.solarGenMw} MW</td>
                    <td className="py-3.5 text-[#E0E2E5]">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${hour.batteryState.includes('Charging') ? 'bg-green-400 animate-pulse' : hour.batteryState.includes('Discharging') ? 'bg-amber-500 animate-pulse' : 'bg-[#7A818E]'}`} />
                        <span>{hour.batterySoc}% ({hour.batteryState})</span>
                      </div>
                    </td>
                    <td className="py-3.5">
                      <span className={`px-2 py-0.5 rounded-none font-bold text-[10px] uppercase tracking-wider border ${
                        isHigh 
                          ? 'bg-red-500/10 border-red-500/20 text-red-400' 
                          : isLow 
                            ? 'bg-green-500/10 border-green-500/20 text-green-400' 
                            : 'bg-[#0A0B0D] border-[#1F2228] text-[#7A818E]'
                      }`}>
                        {hour.action}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
