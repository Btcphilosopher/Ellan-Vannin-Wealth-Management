import React, { useState, useEffect } from 'react';
import { RiskSimulationResponse } from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { ShieldAlert, BarChart3, AlertCircle, RefreshCw, Loader2 } from 'lucide-react';

export default function RiskEngineView() {
  const [data, setData] = useState<RiskSimulationResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchRiskSimulation = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/risk/simulation');
      const results = await response.json();
      setData(results);
    } catch (err) {
      console.error("Failed to run risk simulation", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRiskSimulation();
  }, []);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  if (isLoading || !data) {
    return (
      <div className="flex flex-col items-center justify-center p-12 h-64">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-500" />
        <p className="text-slate-500 text-sm mt-2">Triggering 1,000 Stochastic Portfolio Monte Carlo Trials...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6" id="risk-engine-view">
      {/* Top metrics card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex items-start gap-3">
          <div className="p-2.5 bg-red-50 rounded-lg text-red-600 mt-0.5">
            <ShieldAlert className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold block">Value At Risk (VaR 95%)</span>
            <span className="text-xl font-black text-slate-850">{formatCurrency(data.metrics.valueAtRisk95)}</span>
            <span className="text-[10px] text-red-600 font-bold block mt-0.5">Maximum Stochastic Exposure</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex items-start gap-3">
          <div className="p-2.5 bg-emerald-50 rounded-lg text-emerald-600 mt-0.5">
            <BarChart3 className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold block">Portfolio Mean Valuation (P50)</span>
            <span className="text-xl font-black text-slate-850">{formatCurrency(data.metrics.p50Val)}</span>
            <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">Stochastic Median Value</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex items-start gap-3">
          <div className="p-2.5 bg-blue-50 rounded-lg text-blue-600 mt-0.5">
            <AlertCircle className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold block">Risk Encasement Rating</span>
            <span className="text-xl font-black text-slate-850">{data.metrics.riskRating}</span>
            <span className="text-[10px] text-blue-600 font-bold block mt-0.5">Sovereign Treasury Status</span>
          </div>
        </div>
      </div>

      {/* Distribution Chart */}
      <div className="bg-slate-900 text-slate-100 rounded-2xl p-6 border border-slate-800 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
          <div>
            <span className="text-[10px] text-amber-400 font-black tracking-widest uppercase bg-amber-500/10 px-2 py-0.5 rounded-full">
              Stochastic Analytics Core
            </span>
            <h3 className="text-lg font-black text-white mt-1">1,000 Trial Portfolio NAV Distribution Curve</h3>
            <p className="text-slate-400 text-xs mt-0.5">Monte Carlo probability mapping of total portfolio net assets under structural grid and supply-chain volatilities.</p>
          </div>
          <button
            onClick={fetchRiskSimulation}
            id="btn-re-run-risk"
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold border border-slate-700/50 transition-all cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Re-run Stochastic Engine</span>
          </button>
        </div>

        {/* Recharts Monte Carlo distribution */}
        <div className="h-64 mt-6" id="risk-recharts-container">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.bins} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="range" stroke="#475569" fontSize={9} tickLine={false} />
              <YAxis stroke="#475569" fontSize={11} tickLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#f1f5f9' }}
                itemStyle={{ color: '#f1f5f9' }}
              />
              <Bar name="Probability Occurrence (Trials)" dataKey="count" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Stress Scenarios list */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-md p-6">
        <h3 className="text-base font-black text-slate-800 tracking-tight mb-4">Sovereign Asset Stress Testing & Mitigations</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs md:text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                <th className="pb-3 pl-4">Stress Vector Scenario</th>
                <th className="pb-3">Financial / Physical Impact</th>
                <th className="pb-3">Estimated Probability</th>
                <th className="pb-3 pr-4">Active Sovereign Hedging Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {data.stressScenarios.map((scen, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50">
                  <td className="py-4 pl-4 font-bold text-slate-800">{scen.name}</td>
                  <td className="py-4 font-bold text-red-600">{scen.impact}</td>
                  <td className="py-4 font-semibold text-slate-500">{scen.probability}</td>
                  <td className="py-4 pr-4">
                    <span className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md font-bold text-xs border border-slate-200/50">
                      {scen.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
