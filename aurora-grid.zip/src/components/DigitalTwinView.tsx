import React, { useState, useEffect } from 'react';
import { DataCentre, TwinSimulationResponse } from '../types';
import { Settings2, Cpu, Zap, DollarSign, Activity, Globe, Loader2, ArrowUpRight } from 'lucide-react';

interface DigitalTwinViewProps {
  assets: DataCentre[];
}

export default function DigitalTwinView({ assets }: DigitalTwinViewProps) {
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id || '');
  const [gpuScale, setGpuScale] = useState<number>(1.0);
  const [gridPriceModifier, setGridPriceModifier] = useState<number>(1.0);
  const [demandMultiplier, setDemandMultiplier] = useState<number>(1.0);
  const [simResults, setSimResults] = useState<TwinSimulationResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const fetchSimulation = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/twin/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          assetId: selectedAssetId,
          gpuScale,
          gridPriceModifier,
          demandMultiplier
        })
      });
      const data = await response.json();
      setSimResults(data);
    } catch (err) {
      console.error("Simulation failed", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (selectedAssetId) {
      fetchSimulation();
    }
  }, [selectedAssetId, gpuScale, gridPriceModifier, demandMultiplier]);

  const activeAsset = assets.find(a => a.id === selectedAssetId);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-[#E0E2E5]" id="digital-twin-view">
      {/* Simulation Controllers */}
      <div className="lg:col-span-4 bg-[#0F1115] rounded-none border border-[#1F2228] p-6 space-y-6" id="twin-controls-panel">
        <div className="border-b border-[#1F2228] pb-3 flex items-center gap-2">
          <Settings2 className="h-4 w-4 text-[#00F2FF]" />
          <h3 className="text-xs font-mono font-bold text-[#E0E2E5] uppercase tracking-wider">Digital Twin Control Deck</h3>
        </div>

        {/* Facility Selector */}
        <div className="space-y-2">
          <label className="text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em] block">Target Digital Twin</label>
          <select
            id="twin-facility-select"
            value={selectedAssetId}
            onChange={(e) => {
              setSelectedAssetId(e.target.value);
              setGpuScale(1.0);
              setGridPriceModifier(1.0);
              setDemandMultiplier(1.0);
            }}
            className="w-full bg-[#0A0B0D] border border-[#1F2228] hover:border-[#00F2FF] rounded-none px-3.5 py-2.5 text-xs font-mono font-bold text-[#E0E2E5] outline-none transition-all cursor-pointer"
          >
            {assets.map((a) => (
              <option key={a.id} value={a.id}>{a.name}</option>
            ))}
          </select>
        </div>

        {/* Sliders */}
        <div className="space-y-5 pt-3 border-t border-[#1F2228]">
          {/* Slider 1: GPU Sizing */}
          <div className="space-y-2">
            <div className="flex justify-between text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em]">
              <span>Cluster GPU Scaling</span>
              <span className="text-[#00F2FF] text-xs font-bold font-mono">{gpuScale === 1.0 ? 'Baseline (1x)' : `${gpuScale.toFixed(2)}x`}</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.5"
              step="0.1"
              value={gpuScale}
              id="slider-gpu-scale"
              onChange={(e) => setGpuScale(Number(e.target.value))}
              className="w-full h-1 bg-[#1F2228] rounded-none appearance-none cursor-pointer accent-[#00F2FF]"
            />
            <div className="flex justify-between text-[8px] text-[#7A818E] font-mono font-bold uppercase">
              <span>0.5x Sizing</span>
              <span>2.5x Double-Cluster Array</span>
            </div>
          </div>

          {/* Slider 2: Electricity price */}
          <div className="space-y-2">
            <div className="flex justify-between text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em]">
              <span>Grid Spot Electricity Cost</span>
              <span className="text-amber-500 text-xs font-bold font-mono">
                {gridPriceModifier === 1.0 ? 'Base Spot Rate' : gridPriceModifier > 1.0 ? `+${Math.round((gridPriceModifier - 1) * 100)}% Surge` : `-${Math.round((1 - gridPriceModifier) * 100)}% Discount`}
              </span>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.0"
              step="0.05"
              value={gridPriceModifier}
              id="slider-grid-price-modifier"
              onChange={(e) => setGridPriceModifier(Number(e.target.value))}
              className="w-full h-1 bg-[#1F2228] rounded-none appearance-none cursor-pointer accent-[#00F2FF]"
            />
            <div className="flex justify-between text-[8px] text-[#7A818E] font-mono font-bold uppercase">
              <span>-50% Off-Peak Surplus</span>
              <span>+100% Volatile Grid Peak</span>
            </div>
          </div>

          {/* Slider 3: AI workload demand */}
          <div className="space-y-2">
            <div className="flex justify-between text-[9px] font-mono font-bold text-[#7A818E] uppercase tracking-[0.2em]">
              <span>AI Core Workload Demand</span>
              <span className="text-[#00F2FF] text-xs font-bold font-mono">{demandMultiplier === 1.0 ? 'Normal (100%)' : `${Math.round(demandMultiplier * 100)}%`}</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="1.5"
              step="0.05"
              value={demandMultiplier}
              id="slider-demand-multiplier"
              onChange={(e) => setDemandMultiplier(Number(e.target.value))}
              className="w-full h-1 bg-[#1F2228] rounded-none appearance-none cursor-pointer accent-[#00F2FF]"
            />
            <div className="flex justify-between text-[8px] text-[#7A818E] font-mono font-bold uppercase">
              <span>50% Low utilization</span>
              <span>150% Exascale Squeeze</span>
            </div>
          </div>
        </div>

        <div className="p-3.5 bg-[#15171C] rounded-none border border-[#1F2228] text-[10px] font-mono text-[#7A818E] leading-normal">
          <span className="font-bold text-[#E0E2E5]">Digital Twin Premise:</span> Adjusting these parameters recalculates the core thermodynamic PUE (cooling efficiency) and real-time EBITDA margins instantly.
        </div>
      </div>

      {/* Simulation Output Dashboard */}
      <div className="lg:col-span-8 flex flex-col justify-between h-full space-y-4">
        {simResults ? (
          <div className="bg-[#0F1115] rounded-none border border-[#1F2228] p-6 flex flex-col justify-between h-full" id="twin-results-panel">
            <div>
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1F2228] pb-4">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] font-mono font-bold uppercase tracking-widest px-2.5 py-0.5 rounded-none bg-[#00F2FF]/10 text-[#00F2FF]">Thermodynamic Real-Time Twin</span>
                    {isLoading && <Loader2 className="h-3 w-3 animate-spin text-[#00F2FF]" />}
                  </div>
                  <h3 className="text-lg font-serif italic text-[#E0E2E5] mt-1.5">{simResults.assetName}</h3>
                  <p className="text-[#7A818E] text-xs mt-0.5">Physical telemetry matched via subsea optical loop.</p>
                </div>
              </div>

              {/* Physical specs comparison */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                <div className="bg-[#0A0B0D] p-4 rounded-none border border-[#1F2228] text-left">
                  <div className="p-1.5 bg-[#00F2FF]/10 rounded-none text-[#00F2FF] w-fit">
                    <Cpu className="h-4 w-4" />
                  </div>
                  <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block mt-3">Calculated GPUs</span>
                  <span className="text-base font-bold font-mono text-[#E0E2E5]">{simResults.simGpus.toLocaleString()} Cores</span>
                  <span className="text-[9px] text-[#7A818E] font-mono block mt-0.5">Reserve: {simResults.strategicReserveSimGpus.toLocaleString()}</span>
                </div>

                <div className="bg-[#0A0B0D] p-4 rounded-none border border-[#1F2228] text-left">
                  <div className="p-1.5 bg-[#00F2FF]/10 rounded-none text-[#00F2FF] w-fit">
                    <Zap className="h-4 w-4" />
                  </div>
                  <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block mt-3">Interconnect Power</span>
                  <span className="text-base font-bold font-mono text-[#E0E2E5]">{simResults.simPowerCapacity} MW</span>
                  <span className="text-[9px] text-[#7A818E] font-mono block mt-0.5">PUE: <span className="font-bold text-green-400">{simResults.pue}</span></span>
                </div>

                <div className="bg-[#0A0B0D] p-4 rounded-none border border-[#1F2228] text-left">
                  <div className="p-1.5 bg-[#00F2FF]/10 rounded-none text-[#00F2FF] w-fit">
                    <Activity className="h-4 w-4" />
                  </div>
                  <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block mt-3">Workload Util</span>
                  <span className="text-base font-bold font-mono text-[#E0E2E5]">{simResults.simUtilization}%</span>
                  <span className="text-[9px] text-[#7A818E] font-mono block mt-0.5">Status: {simResults.simUtilization > 85 ? 'Saturated' : 'Optimal'}</span>
                </div>

                <div className="bg-[#0A0B0D] p-4 rounded-none border border-[#1F2228] text-left">
                  <div className="p-1.5 bg-[#00F2FF]/10 rounded-none text-[#00F2FF] w-fit">
                    <Globe className="h-4 w-4" />
                  </div>
                  <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block mt-3">CO2 Footprint</span>
                  <span className="text-base font-bold font-mono text-[#E0E2E5]">{simResults.carbonFootprintTons.toLocaleString()} Tons</span>
                  <span className="text-[9px] text-[#7A818E] font-mono block mt-0.5">Annual Co-emission</span>
                </div>
              </div>

              {/* Financial twin outputs */}
              <div className="mt-6 pt-5 border-t border-[#1F2228]">
                <h4 className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#7A818E] mb-3.5">Simulated Financial Twin Impact</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
                  <div className="p-4 rounded-none bg-[#0A0B0D] border border-[#1F2228]">
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block">Twin Revenue</span>
                    <span className="text-sm font-bold text-[#E0E2E5] mt-1 block">{formatCurrency(simResults.simRevenue)}</span>
                  </div>
                  <div className="p-4 rounded-none bg-[#0A0B0D] border border-[#1F2228]">
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block">Twin Operating Cost</span>
                    <span className="text-sm font-bold text-red-400 mt-1 block">{formatCurrency(simResults.simOperatingCost)}</span>
                  </div>
                  <div className="p-4 rounded-none bg-[#0A0B0D] border border-[#1F2228]">
                    <span className="text-[9px] text-[#7A818E] uppercase tracking-wider font-bold block">Twin EBITDA Margins</span>
                    <span className="text-sm font-bold text-green-400 mt-1 block">{formatCurrency(simResults.simEbitda)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* delta check banner */}
            <div className="mt-6 p-4 rounded-none bg-[#15171C] text-[#E0E2E5] flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-[#1F2228]">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#00F2FF]/10 text-[#00F2FF] rounded-none font-bold text-xs font-mono">
                  Δ
                </div>
                <div>
                  <h4 className="text-xs font-mono font-bold text-[#E0E2E5] uppercase">EBITDA Delta Comparison</h4>
                  <p className="text-[#7A818E] text-[10px] font-mono mt-0.5">Net cashflow adjustment comparing simulated configuration against existing baseline assets.</p>
                </div>
              </div>
              <div className="text-right">
                <span className={`text-sm font-mono font-bold px-3.5 py-1.5 rounded-none border ${simResults.ebitdaDelta >= 0 ? 'bg-green-950/20 border-green-500/20 text-green-400' : 'bg-red-950/20 border-red-500/20 text-red-400'}`}>
                  {simResults.ebitdaDelta >= 0 ? '+' : ''}{formatCurrency(simResults.ebitdaDelta)}
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-[#0F1115] rounded-none border-2 border-dashed border-[#1F2228] p-8 h-full flex flex-col items-center justify-center text-center">
            <Loader2 className="h-6 w-6 animate-spin text-[#00F2FF] mb-2" />
            <span className="text-[#7A818E] text-xs font-mono uppercase tracking-wider">Simulating Thermodynamic Twin...</span>
          </div>
        )}
      </div>
    </div>
  );
}
