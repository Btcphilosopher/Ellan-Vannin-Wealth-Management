import React, { useState, useEffect } from 'react';
import { SovereignRole } from '../types';
import { Send, Sparkles, Loader2, MessageSquare, ArrowRight } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface AIAdvisorProps {
  currentRole: SovereignRole;
  portfolioMetrics: any;
}

export default function AIAdvisor({ currentRole, portfolioMetrics }: AIAdvisorProps) {
  const [prompt, setPrompt] = useState<string>('');
  const [response, setResponse] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const presets: Record<SovereignRole, string[]> = {
    'CEO': [
      "Draft a 10-year capital expansion recommendation for the Isle of Man.",
      "How can we hedge our portfolio EBITDA against direct winter energy grid spikes?",
      "Summarize the macro sovereign wealth fund return profile compared to conventional real estate."
    ],
    'Investment Committee': [
      "Detail the IRR differences between Douglas Core tidal options and Shetland Wind proposals.",
      "Explain how a 30% GPU refresh Capex cycle in Year 4 affects our overall NPV.",
      "Recommend a structured senior-debt vs equity-allocation strategy for Clyde Nexus."
    ],
    'Operations Team': [
      "Suggest load-balancing rules between Clyde and Hull campuses during Dogger Bank wind dropouts.",
      "Explain the strategic benefit of our 20% Strategic Reserve holding during peak hours.",
      "Outline a demand-response automation policy for high priority workloads."
    ],
    'Engineers': [
      "Analyze the PUE thermal benefits of direct liquid-to-chip immersion vs evaporative designs.",
      "Draft a predictive maintenance checklist for immersion fluid degradation over 10,000 continuous hours.",
      "Explain the subsea fibre latency paths connecting Douglas Sovereign Core to London."
    ],
    'Analysts': [
      "Detail how the VaR 95% is calculated in our stochastic Monte Carlo simulation.",
      "Draft a pricing quote strategy for multi-node LLM training requests during high renewable surplus.",
      "Analyze the customer pricing elasticity under extreme power price fluctuations."
    ],
  };

  const activePresets = presets[currentRole] || presets['CEO'];

  const triggerInsights = async (customPrompt?: string) => {
    setIsLoading(true);
    setResponse('');
    const targetPrompt = customPrompt || prompt;

    try {
      const res = await fetch('/api/gemini/insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentMetrics: portfolioMetrics,
          role: currentRole,
          prompt: targetPrompt
        })
      });
      const data = await res.json();
      if (!res.ok || data.error && !data.text) {
        setResponse(`### ⚠️ Sovereign Advisory Server Error\n\n**Error:** ${data.error || 'Request failed'}\n\n**Details:** ${data.details || 'The sovereign advisory server returned an invalid response. Please verify your Gemini API key in the Secrets panel.'}`);
      } else {
        setResponse(data.text || "No advisory report generated.");
      }
    } catch (err) {
      console.error("Gemini failed", err);
      setResponse("Sovereign advisory server timing out. Please verify your GEMINI_API_KEY inside the Secrets panel.");
    } finally {
      setIsLoading(false);
    }
  };

  // Run initial insight when role changes
  useEffect(() => {
    triggerInsights(`Provide an initial high-level strategic overview and recommendations tailored for the ${currentRole}.`);
  }, [currentRole]);

  return (
    <div className="bg-[#0F1115] border border-[#1F2228] text-[#E0E2E5] rounded-none p-6 shadow-none flex flex-col justify-between h-full" id="ai-advisor-panel">
      <div>
        {/* Header */}
        <div className="flex items-center gap-2.5 pb-4 border-b border-[#1F2228]">
          <div className="p-1.5 bg-[#00F2FF]/10 text-[#00F2FF] rounded-none">
            <Sparkles className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[#E0E2E5]">Aurora AI Sovereign Advisor</h3>
            <p className="text-[#7A818E] text-[8px] uppercase font-bold tracking-widest mt-0.5">Engine Model: Gemini 2.5 Flash</p>
          </div>
        </div>

        {/* Preset Chips */}
        <div className="mt-4 space-y-2">
          <span className="text-[9px] text-[#7A818E] uppercase tracking-[0.2em] font-bold block">Role-Specific Analytical Queries</span>
          <div className="flex flex-col gap-1.5">
            {activePresets.map((preset, idx) => (
              <button
                key={idx}
                id={`preset-btn-${idx}`}
                type="button"
                onClick={() => {
                  setPrompt(preset);
                  triggerInsights(preset);
                }}
                className="w-full text-left px-3 py-2 bg-[#0A0B0D] hover:bg-[#15171C] border border-[#1F2228] rounded-none text-[11px] text-[#7A818E] hover:text-[#E0E2E5] transition-all cursor-pointer truncate font-mono"
              >
                &gt; {preset}
              </button>
            ))}
          </div>
        </div>

        {/* Response Box */}
        <div className="mt-5 bg-[#0A0B0D] border border-[#1F2228] rounded-none p-4 min-h-64 max-h-[340px] overflow-y-auto custom-scrollbar" id="ai-response-box">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-[#00F2FF] mb-2" />
              <p className="text-[#7A818E] text-[10px] font-mono text-center max-w-[200px] leading-normal uppercase">Consulting Sovereign wealth protocols...</p>
            </div>
          ) : response ? (
            <div className="markdown-body text-xs text-[#E0E2E5] leading-relaxed space-y-4">
              <ReactMarkdown>{response}</ReactMarkdown>
            </div>
          ) : (
            <div className="text-[#7A818E] flex flex-col items-center justify-center py-12 text-center text-xs">
              <MessageSquare className="h-6 w-6 text-[#1F2228] mb-2" />
              <span className="font-mono text-[10px] uppercase tracking-wider">Select a preset query or input customized prompt below.</span>
            </div>
          )}
        </div>
      </div>

      {/* Input box */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (prompt.trim()) triggerInsights();
        }}
        className="mt-5 flex gap-2"
        id="ai-advisor-input-form"
      >
        <input
          type="text"
          id="input-ai-prompt"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder={`Inquire about portfolio IRR, thermal models...`}
          className="flex-1 bg-[#0A0B0D] border border-[#1F2228] focus:border-[#00F2FF] rounded-none px-3 py-2.5 text-xs text-[#E0E2E5] placeholder-[#7A818E] outline-none transition-all font-mono"
        />
        <button
          type="submit"
          id="btn-ai-submit"
          disabled={isLoading || !prompt.trim()}
          className="bg-[#00F2FF] hover:bg-[#00D8E6] disabled:opacity-30 text-[#0A0B0D] p-3 rounded-none transition-all cursor-pointer shrink-0 flex items-center justify-center"
        >
          <Send className="h-3.5 w-3.5" />
        </button>
      </form>
    </div>
  );
}
