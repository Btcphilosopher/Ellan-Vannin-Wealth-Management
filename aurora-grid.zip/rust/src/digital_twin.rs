//! Module 4: Data Centre Digital Twin
//! Creates real-time physical, environmental, and financial digital twins of sovereign facilities.

use serde::{Serialize, Deserialize};
use axum::Json;
use crate::asset_register::get_mock_assets;

#[derive(Debug, Deserialize)]
pub struct SimulationParams {
    pub asset_id: String,
    pub gpu_scale: f64,              // e.g. 2.0 to double GPU capacity
    pub grid_price_modifier: f64,    // e.g. 1.2 for +20% electricity costs
    pub demand_multiplier: f64,      // e.g. 1.5 to simulate high workloads
}

#[derive(Debug, Serialize)]
pub struct TwinSimulationResponse {
    pub asset_id: String,
    pub asset_name: String,
    pub sim_gpus: u64,
    pub sim_power_capacity_mw: f64,
    pub simulated_pue: f64,
    pub sim_utilization: f64,
    pub sim_revenue_usd: f64,
    pub sim_operating_cost_usd: f64,
    pub sim_ebitda_usd: f64,
    pub ebitda_delta_usd: f64,
    pub annual_carbon_footprint_tons: f64,
    pub strategic_reserve_sim_gpus: u64,
}

pub async fn run_simulation_handler(Json(params): Json<SimulationParams>) -> Json<TwinSimulationResponse> {
    let assets = get_mock_assets();
    
    // Find asset
    let target_asset = assets.into_iter()
        .find(|a| a.id == params.asset_id)
        .unwrap_or_else(|| get_mock_assets().swap_remove(0));

    let sim_gpus = (target_asset.gpu_capacity as f64 * params.gpu_scale).round() as u64;
    
    // Power connection matches GPU scale with minor efficiency curve
    let sim_power = target_asset.power_capacity_mw * (1.0 + (params.gpu_scale - 1.0) * 0.75);
    
    // Power Usage Effectiveness (PUE) decreases (improves) slightly with cluster density or immersion
    let simulated_pue = if params.gpu_scale > 1.5 { 1.10 } else { 1.18 };
    
    let sim_util = (target_asset.utilization_percentage * params.demand_multiplier).min(98.5);
    
    let sim_revenue = target_asset.annual_revenue_usd * params.gpu_scale * (sim_util / target_asset.utilization_percentage);
    let sim_opex = target_asset.operating_cost_usd * (1.0 + (params.gpu_scale - 1.0) * 0.4) * params.grid_price_modifier;
    
    let sim_ebitda = sim_revenue - sim_opex;
    let base_ebitda = target_asset.annual_revenue_usd - target_asset.operating_cost_usd;
    
    // Carbon Footprint calculations
    let carbon_tons = sim_power * (1.0 - target_asset.renewable_percentage / 100.0) * 24.0 * 365.0 * 0.28;

    Json(TwinSimulationResponse {
        asset_id: target_asset.id,
        asset_name: target_asset.name,
        sim_gpus,
        sim_power_capacity_mw: sim_power,
        simulated_pue,
        sim_utilization: sim_util,
        sim_revenue_usd: sim_revenue,
        sim_operating_cost_usd: sim_opex,
        sim_ebitda_usd: sim_ebitda,
        ebitda_delta_usd: sim_ebitda - base_ebitda,
        annual_carbon_footprint_tons: carbon_tons,
        strategic_reserve_sim_gpus: (sim_gpus as f64 * 0.20).round() as u64, // 20% strategic reserve hold
    })
}
