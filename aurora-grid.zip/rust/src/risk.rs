//! Module 9: Risk Management Engine
//! Implements Monte Carlo simulations and scenario stress testing for data centre portfolio holdings.

use serde::Serialize;
use axum::Json;
use crate::asset_register::get_mock_assets;

#[derive(Debug, Serialize)]
pub struct StressScenario {
    pub name: String,
    pub impact: String,
    pub probability: String,
    pub status: String,
}

#[derive(Debug, Serialize)]
pub struct SimulationBin {
    pub range: String,
    pub count: usize,
}

#[derive(Debug, Serialize)]
pub struct RiskMetrics {
    pub portfolio_base_value: f64,
    pub value_at_risk_95: f64,
    pub p10_val: f64,
    pub p50_val: f64,
    pub p90_val: f64,
    pub risk_rating: String,
}

#[derive(Debug, Serialize)]
pub struct MonteCarloResponse {
    pub metrics: RiskMetrics,
    pub stress_scenarios: Vec<StressScenario>,
    pub bins: Vec<SimulationBin>,
}

pub async fn run_monte_carlo_handler() -> Json<MonteCarloResponse> {
    let assets = get_mock_assets();
    let base_value: f64 = assets.iter().map(|a| a.building_value_usd + a.hardware_value_usd).sum();
    
    let trials = 1000;
    let mut results = Vec::with_capacity(trials);
    
    // Simulating stochastic volatilities (Electricity price spikes, GPU utilization volatility, and operational hazards)
    let electricity_vol = 0.22;
    let gpu_rent_vol = 0.15;
    let cooling_hazard_prob = 0.02;

    for _ in 0..trials {
        // Mock random normal approximations
        let rand_norm1 = (rand::random::<f64>() - 0.5) * 2.0;
        let rand_norm2 = (rand::random::<f64>() - 0.5) * 2.0;
        
        let mut trial_val = base_value;
        trial_val *= 1.0 + (rand_norm1 * electricity_vol * 0.25);
        trial_val *= 1.0 + (rand_norm2 * gpu_rent_vol * 0.35);
        
        // Operational outages
        if rand::random::<f64>() < cooling_hazard_prob {
            trial_val -= 5_000_000.0; // operational recovery penalty
        }
        
        results.push(trial_val);
    }
    
    results.sort_by(|a, b| a.partial_cmp(b).unwrap());
    
    let p10 = results[trials / 10];
    let p50 = results[trials / 2];
    let p90 = results[(trials * 9) / 10];
    
    // Group into 15 distribution bins for charting
    let bin_count = 15;
    let min_val = results[0];
    let max_val = results[trials - 1];
    let bin_width = (max_val - min_val) / bin_count as f64;
    
    let mut bins = Vec::new();
    for idx in 0..bin_count {
        let bin_start = min_val + idx as f64 * bin_width;
        let bin_end = bin_start + bin_width;
        let count = results.iter().filter(|&&r| r >= bin_start && r < bin_end).count();
        
        bins.push(SimulationBin {
            range: format!("{:.0}M-{:.0}M", bin_start / 1_000_000.0, bin_end / 1_000_000.0),
            count,
        });
    }

    let stress_scenarios = vec![
        StressScenario {
            name: "Sovereign Grid Power Surge (+150% Electric Price)".to_string(),
            impact: "-$8.4M operating margins".to_string(),
            probability: "Low".to_string(),
            status: "Mitigated via PPA (Power Purchase Agreement)".to_string(),
        },
        StressScenario {
            name: "Extreme Heatwaves (PUE increases to 1.35)".to_string(),
            impact: "-1.2% overall performance".to_string(),
            probability: "Medium".to_string(),
            status: "Mitigated via Chip Immersion Cooling".to_string(),
        },
        StressScenario {
            name: "AI Cluster Supply Squeeze (GPU values appreciate 30%)".to_string(),
            impact: "+$84M NAV appreciation".to_string(),
            probability: "Low-Medium".to_string(),
            status: "Favourable".to_string(),
        }
    ];

    Json(MonteCarloResponse {
        metrics: RiskMetrics {
            portfolio_base_value: base_value,
            value_at_risk_95: base_value - p10,
            p10_val: p10,
            p50_val: p50,
            p90_val: p90,
            risk_rating: "Low-Moderate Sovereign Tier".to_string(),
        },
        stress_scenarios,
        bins,
    })
}
