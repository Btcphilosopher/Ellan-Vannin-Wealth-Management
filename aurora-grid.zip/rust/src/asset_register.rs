//! Module 1: Digital Infrastructure Asset Register
//! Tracks data centre locations, geographic coordinates, capacity, values, and compute clusters.

use serde::{Serialize, Deserialize};
use axum::Json;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct DataCentre {
    pub id: String,
    pub name: String,
    pub location: String,
    pub latitude: f64,
    pub longitude: f64,
    pub power_capacity_mw: f64,
    pub gpu_capacity: u64,
    pub storage_petabytes: f64,
    pub renewable_percentage: f64,
    pub renewable_source: String,
    pub cooling_tech: String,
    pub fibre_connections: Vec<String>,
    pub land_ownership: String,
    pub building_value_usd: f64,
    pub hardware_value_usd: f64,
    pub annual_revenue_usd: f64,
    pub operating_cost_usd: f64,
    pub utilization_percentage: f64,
    pub strategic_reserve_gpus: u64,
    pub commercial_gpus: u64,
}

#[derive(Debug, Serialize)]
pub struct PortfolioSummary {
    pub total_assets: usize,
    pub total_asset_value_usd: f64,
    pub total_annual_revenue_usd: f64,
    pub ebitda_usd: f64,
    pub average_utilization: f64,
    pub total_power_mw: f64,
    pub capital_deployed_usd: f64,
}

#[derive(Debug, Serialize)]
pub struct PortfolioResponse {
    pub summary: PortfolioSummary,
    pub assets: Vec<DataCentre>,
}

pub fn get_mock_assets() -> Vec<DataCentre> {
    vec![
        DataCentre {
            id: "dc-douglas-core".to_string(),
            name: "Douglas Sovereign Core".to_string(),
            location: "Douglas, Isle of Man".to_string(),
            latitude: 54.145,
            longitude: -4.482,
            power_capacity_mw: 120.0,
            gpu_capacity: 12000,
            storage_petabytes: 50.0,
            renewable_percentage: 98.0,
            renewable_source: "Tidal & Off-grid Wind".to_string(),
            cooling_tech: "Direct Liquid-to-Chip immersion".to_string(),
            fibre_connections: vec!["CeltixConnect".to_string(), "Lanis-3".to_string(), "Havfrue".to_string()],
            land_ownership: "Freehold (Fund Owned)".to_string(),
            building_value_usd: 145_000_000.0,
            hardware_value_usd: 280_000_000.0,
            annual_revenue_usd: 84_000_000.0,
            operating_cost_usd: 32_000_000.0,
            utilization_percentage: 82.5,
            strategic_reserve_gpus: 2400,
            commercial_gpus: 9600,
        },
        DataCentre {
            id: "dc-hull-green".to_string(),
            name: "Hull Green Maritime Campus".to_string(),
            location: "Hull, United Kingdom".to_string(),
            latitude: 53.743,
            longitude: -0.334,
            power_capacity_mw: 85.0,
            gpu_capacity: 8000,
            storage_petabytes: 35.0,
            renewable_percentage: 100.0,
            renewable_source: "Dogger Bank Offshore Wind".to_string(),
            cooling_tech: "Indirect Evaporative".to_string(),
            fibre_connections: vec!["Aegir".to_string(), "BT Sovereign Spine".to_string()],
            land_ownership: "99-Year Leasehold".to_string(),
            building_value_usd: 98_000_000.0,
            hardware_value_usd: 185_000_000.0,
            annual_revenue_usd: 56_000_000.0,
            operating_cost_usd: 21_000_000.0,
            utilization_percentage: 76.2,
            strategic_reserve_gpus: 1500,
            commercial_gpus: 6500,
        },
        DataCentre {
            id: "dc-clyde-nexus".to_string(),
            name: "Clyde Sovereign Nexus".to_string(),
            location: "Glasgow, Scotland".to_string(),
            latitude: 55.864,
            longitude: -4.251,
            power_capacity_mw: 150.0,
            gpu_capacity: 16000,
            storage_petabytes: 80.0,
            renewable_percentage: 95.0,
            renewable_source: "Pumped Hydro Storage".to_string(),
            cooling_tech: "Two-Phase Immersion".to_string(),
            fibre_connections: vec!["ScapaFlow-Fibre".to_string(), "EirGrid-Link".to_string()],
            land_ownership: "Freehold (Joint Venture)".to_string(),
            building_value_usd: 180_000_000.0,
            hardware_value_usd: 360_000_000.0,
            annual_revenue_usd: 112_000_000.0,
            operating_cost_usd: 41_000_000.0,
            utilization_percentage: 89.1,
            strategic_reserve_gpus: 3200,
            commercial_gpus: 12800,
        }
    ]
}

pub async fn get_portfolio_handler() -> Json<PortfolioResponse> {
    let assets = get_mock_assets();
    let total_assets = assets.length();
    
    let total_asset_value_usd = assets.iter().map(|a| a.building_value_usd + a.hardware_value_usd).sum();
    let total_annual_revenue_usd = assets.iter().map(|a| a.annual_revenue_usd).sum();
    let total_opex_usd: f64 = assets.iter().map(|a| a.operating_cost_usd).sum();
    let ebitda_usd = total_annual_revenue_usd - total_opex_usd;
    
    let total_util: f64 = assets.iter().map(|a| a.utilization_percentage).sum();
    let average_utilization = if total_assets > 0 { total_util / total_assets as f64 } else { 0.0 };
    let total_power_mw = assets.iter().map(|a| a.power_capacity_mw).sum();
    
    Json(PortfolioResponse {
        summary: PortfolioSummary {
            total_assets,
            total_asset_value_usd,
            total_annual_revenue_usd,
            ebitda_usd,
            average_utilization,
            total_power_mw,
            capital_deployed_usd: total_asset_value_usd * 0.75,
        },
        assets,
    })
}
