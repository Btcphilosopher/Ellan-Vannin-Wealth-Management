//! Module 2: AI Compute Marketplace Engine
//! Dynamically routes and prices AI workloads based on power prices, capacity availability, and priority.

use serde::{Serialize, Deserialize};
use axum::Json;
use crate::asset_register::get_mock_assets;

#[derive(Debug, Deserialize)]
pub struct QuoteRequest {
    pub gpus_requested: u64,
    pub hours_needed: f64,
    pub priority: String, // "critical", "strategic", "flexible"
    pub workload_type: String, // "training", "inference", "hpc"
}

#[derive(Debug, Serialize)]
pub struct QuoteResponse {
    pub quote_id: String,
    pub allocated_site: String,
    pub allocated_site_id: String,
    pub gpus_allocated: u64,
    pub total_power_consumption_mwh: f64,
    pub electricity_cost_usd: f64,
    pub depreciation_cost_usd: f64,
    pub final_price_usd: f64,
    pub margin_percentage: f64,
    pub green_match_status: String,
}

pub async fn create_quote_handler(Json(payload): Json<QuoteRequest>) -> Json<QuoteResponse> {
    let assets = get_mock_assets();
    
    // Choose site based on capacity availability and high renewable percentage
    let mut selected_asset = &assets[0];
    let mut max_renewables = 0.0;
    
    for asset in &assets {
        let available_gpus = asset.commercial_gpus as f64 * (1.0 - asset.utilization_percentage / 100.0);
        if available_gpus >= payload.gpus_requested as f64 && asset.renewable_percentage > max_renewables {
            selected_asset = asset;
            max_renewables = asset.renewable_percentage;
        }
    }

    let base_rate_per_gpu_hr = 1.85; // USD
    let priority_multiplier = match payload.priority.as_str() {
        "critical" => 1.4,
        "strategic" => 1.1,
        "flexible" => 0.8,
        _ => 1.0,
    };

    // Calculate energy cost
    let power_per_gpu_kw = 0.7; // 700W H100
    let total_power_mwh = (payload.gpus_requested as f64 * power_per_gpu_kw * payload.hours_needed) / 1000.0;
    let grid_price_per_mwh = 42.0; // Baseline grid price
    let electricity_cost = total_power_mwh * grid_price_per_mwh;

    // Calculate hardware depreciation
    let depreciation_per_gpu_hr = 0.35;
    let depreciation_cost = payload.gpus_requested as f64 * depreciation_per_gpu_hr * payload.hours_needed;

    // Final price calculation
    let final_price = payload.gpus_requested as f64 * payload.hours_needed * base_rate_per_gpu_hr * priority_multiplier;
    let total_cost = electricity_cost + depreciation_cost;
    let margin = if final_price > 0.0 { ((final_price - total_cost) / final_price) * 100.0 } else { 0.0 };

    Json(QuoteResponse {
        quote_id: format!("QT-RUST-{}", rand::hash(payload.gpus_requested) % 1_000_000),
        allocated_site: selected_asset.name.clone(),
        allocated_site_id: selected_asset.id.clone(),
        gpus_allocated: payload.gpus_requested,
        total_power_consumption_mwh: total_power_mwh,
        electricity_cost_usd: electricity_cost,
        depreciation_cost_usd: depreciation_cost,
        final_price_usd: final_price,
        margin_percentage: margin,
        green_match_status: if selected_asset.renewable_percentage > 95.0 {
            "Sovereign 100% Green Match Guaranteed".to_string()
        } else {
            "Grid Co-Mix Energy Matched".to_string()
        },
    })
}
