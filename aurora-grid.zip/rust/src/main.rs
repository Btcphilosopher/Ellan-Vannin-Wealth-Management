//! AURORA GRID
//! Sovereign Digital Infrastructure Operating System
//! Ellan Vannin Wealth Management
//! 
//! Main application server entry point utilizing Axum and Tokio.

use axum::{
    routing::{get, post},
    Router,
    Json,
};
use std::net::SocketAddr;
use tower_http::cors::CorsLayer;

pub mod asset_register;
pub mod marketplace;
pub mod energy;
pub mod digital_twin;
pub mod investment;
pub mod risk;
pub mod reserve;

#[tokio::main]
async fn main() {
    println!("--------------------------------------------------");
    println!("      AURORA GRID: SOVEREIGN OPERATING SYSTEM     ");
    println!("          Ellan Vannin Wealth Management          ");
    println!("--------------------------------------------------");
    
    // Setup CORS layer for safe dashboard linking
    let cors = CorsLayer::permissive();

    // Setup routes
    let app = Router::new()
        .route("/api/health", get(health_handler))
        .route("/api/portfolio", get(asset_register::get_portfolio_handler))
        .route("/api/marketplace/quote", post(marketplace::create_quote_handler))
        .route("/api/energy/forecast", get(energy::get_forecast_handler))
        .route("/api/twin/simulate", post(digital_twin::run_simulation_handler))
        .route("/api/investment/calculate", post(investment::calculate_irr_handler))
        .route("/api/risk/simulation", get(risk::run_monte_carlo_handler))
        .route("/api/reserve/allocate", post(reserve::allocate_reserve_handler))
        .layer(cors);

    let addr = SocketAddr::from(([0, 0, 0, 0], 8080));
    println!("Aurora Grid (Rust Axum Engine) booting on {}", addr);
    
    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}

async fn health_handler() -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "status": "HEALTHY",
        "system": "AURORA_GRID_CORE_RUST",
        "engine_version": "1.0.0",
        "uptime_seconds": 0
    }))
}
