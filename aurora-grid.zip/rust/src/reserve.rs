//! Module 6: Sovereign Compute Reserve
//! Manages strategic reserve blocks reserved for national government and research workloads under emergency override guidelines.

use serde::{Serialize, Deserialize};
use axum::Json;

#[derive(Debug, Deserialize)]
pub struct ReserveAllocationInput {
    pub agency_name: String,
    pub cores_requested: u64,
    pub duration_hours: f64,
    pub emergency_code: Option<String>,
}

#[derive(Debug, Serialize)]
pub struct ReserveAllocationResponse {
    pub reserve_ticket: String,
    pub agency_name: String,
    pub allocated_gpus: u64,
    pub duration_hours: f64,
    pub emergency_override: bool,
    pub status: String,
    pub grid_priority: String,
    pub associated_campus: String,
    pub energy_preemption_mw: f64,
}

pub async fn allocate_reserve_handler(Json(payload): Json<ReserveAllocationInput>) -> Json<ReserveAllocationResponse> {
    let is_emergency = payload.emergency_code.as_deref() == Some("EV-STRATEGIC-OVERRIDE");
    
    let status = if is_emergency {
        "GRANTED - PRIORITY 1 STRATEGIC DISPATCH".to_string()
    } else {
        "GRANTED - COMMERCIAL RESERVE POOL".to_string()
    };
    
    let grid_priority = if is_emergency {
        "Level 1 (Pre-emptive)".to_string()
    } else {
        "Level 3 (Coordinated)".to_string()
    };

    let energy_preemption_mw = (payload.cores_requested as f64 * 0.7) / 1000.0;

    Json(ReserveAllocationResponse {
        reserve_ticket: format!("RES-EV-RUST-{}", rand::hash(payload.cores_requested) % 1_000_000),
        agency_name: payload.agency_name,
        allocated_gpus: payload.cores_requested,
        duration_hours: payload.duration_hours,
        emergency_override: is_emergency,
        status,
        grid_priority,
        associated_campus: "Douglas Sovereign Core".to_string(),
        energy_preemption_mw,
    })
}
