//! Module 5: Infrastructure Investment Model
//! Capital asset modeling, discounted cashflows, payback cycles, and Internal Rate of Return (IRR) solvers.

use serde::{Serialize, Deserialize};
use axum::Json;

#[derive(Debug, Deserialize)]
pub struct InvestmentInput {
    pub campus_name: String,
    pub land_capex_m: f64,
    pub construction_capex_m: f64,
    pub power_connection_capex_m: f64,
    pub gpus_installed: u64,
    pub target_rent_per_gpu_month: f64,
}

#[derive(Debug, Serialize)]
pub struct CashflowYear {
    pub year: u32,
    pub value: f64,
}

#[derive(Debug, Serialize)]
pub struct InvestmentResult {
    pub campus_name: String,
    pub total_capex_usd: f64,
    pub annual_revenue_usd: f64,
    pub annual_opex_usd: f64,
    pub annual_ebitda_usd: f64,
    pub irr_percentage: f64,
    pub npv_usd: f64,
    pub payback_years: f64,
    pub asset_ltv_usd: f64,
    pub yearly_cashflows: Vec<CashflowYear>,
}

pub async fn calculate_irr_handler(Json(payload): Json<InvestmentInput>) -> Json<InvestmentResult> {
    // Capex calculation
    let land_capex = payload.land_capex_m * 1_000_000.0;
    let construction_capex = payload.construction_capex_m * 1_000_000.0;
    let power_capex = payload.power_connection_capex_m * 1_000_000.0;
    
    // Assume 18,000 USD per GPU server block
    let gpu_capex = payload.gpus_installed as f64 * 18_000.0;
    let total_capex = land_capex + construction_capex + power_capex + gpu_capex;

    // Financial performance
    let annual_revenue = payload.gpus_installed as f64 * payload.target_rent_per_gpu_month * 12.0;
    let annual_opex = (annual_revenue * 0.25) + (payload.gpus_installed as f64 * 0.7 * 8760.0 * 45.0 / 1000.0);
    let annual_ebitda = annual_revenue - annual_opex;

    // Yearly cashflows (10 Years)
    let mut cashflows = vec![-total_capex];
    for year in 1..=10 {
        if year == 4 || year == 8 {
            // Include hardware refresh CAPEX (30% of total initial CAPEX)
            cashflows.push(annual_ebitda - (total_capex * 0.3));
        } else {
            cashflows.push(annual_ebitda);
        }
    }

    // Solve for IRR using Newton-Raphson
    let mut irr = 0.12; // initial guess
    for _ in 0..50 {
        let mut npv = 0.0;
        let mut d_npv = 0.0;
        
        for (t, cashflow) in cashflows.iter().enumerate() {
            let discount = (1.0 + irr).powi(t as i32);
            npv += cashflow / discount;
            if t > 0 {
                d_npv -= (t as f64) * cashflow / (1.0 + irr).powi((t + 1) as i32);
            }
        }
        
        let next_irr = irr - npv / d_npv;
        if (next_irr - irr).abs() < 0.0001 {
            irr = next_irr;
            break;
        }
        irr = next_irr;
    }

    // NPV at 8% cost of capital
    let mut npv_8 = 0.0;
    for (t, cashflow) in cashflows.iter().enumerate() {
        npv_8 += cashflow / (1.0 + 0.08).powi(t as i32);
    }

    let payback = if annual_ebitda > 0.0 { total_capex / annual_ebitda } else { 0.0 };
    let ltv = annual_ebitda * 12.5; // sovereign investment multiple

    let yearly_cashflow_objs = cashflows.iter().enumerate()
        .map(|(idx, &val)| CashflowYear { year: idx as u32, value: val })
        .collect();

    Json(InvestmentResult {
        campus_name: payload.campus_name,
        total_capex_usd: total_capex,
        annual_revenue_usd: annual_revenue,
        annual_opex_usd: annual_opex,
        annual_ebitda_usd: annual_ebitda,
        irr_percentage: irr * 100.0,
        npv_usd: npv_8,
        payback_years: payback,
        asset_ltv_usd: ltv,
        yearly_cashflows: yearly_flow_objs,
    })
}
