//! Module 3: Energy Optimisation Engine
//! Manages real-time grid prices, wind/solar generation forecasting, battery dispatching, and demand response.

use serde::Serialize;
use axum::Json;

#[derive(Debug, Serialize)]
pub struct HourlyForecast {
    pub time: String,
    pub grid_price_mwh: f64,
    pub wind_generation_mw: f64,
    pub solar_generation_mw: f64,
    pub battery_state_of_charge: u32,
    pub battery_action: String,
    pub recommended_action: String,
}

#[derive(Debug, Serialize)]
pub struct EnergyReport {
    pub current_price_mwh: f64,
    pub average_price_mwh: f64,
    pub renewable_mix_percentage: f64,
    pub battery_capacity_mwh: u32,
    pub hours: Vec<HourlyForecast>,
}

pub async fn get_forecast_handler() -> Json<EnergyReport> {
    let mut hours = Vec::new();
    let mut total_price = 0.0;
    
    for h in 0..24 {
        let time = format!("{:02}:00", h);
        
        // Formulate generation curves
        let wind = 45.0 + ((h as f64 - 18.0) * std::f64::consts::PI / 12.0).sin() * 25.0;
        let solar = if h > 5 && h < 19 {
            ((h as f64 - 6.0) * std::f64::consts::PI / 12.0).sin() * 15.0
        } else {
            0.0
        };
        
        let base_demand = 60.0 + ((h as f64 - 8.0) * std::f64::consts::PI / 12.0).sin() * 20.0;
        let renewable_total = wind + solar;
        
        let grid_price = (35.0 + (base_demand * 0.6) - (renewable_total * 0.35)).max(15.0);
        total_price += grid_price;

        let battery_soc = (40.0 + ((h as f64) * std::f64::consts::PI / 12.0).sin() * 30.0) as u32;
        
        let battery_action = if grid_price > 50.0 {
            "Discharging (Grid Saving)".to_string()
        } else if grid_price < 25.0 {
            "Charging (Wind Capture)".to_string()
        } else {
            "Standby (Optimized)".to_string()
        };

        let recommended_action = if grid_price > 45.0 {
            "De-prioritize Flexible Workloads (Demand Response Active)".to_string()
        } else if grid_price < 25.0 {
            "Maximize Multi-node LLM Training Runs".to_string()
        } else {
            "Dispatch Strategic High-Compute".to_string()
        };

        hours.push(HourlyForecast {
            time,
            grid_price_mwh: grid_price,
            wind_generation_mw: wind,
            solar_generation_mw: solar,
            battery_state_of_charge: battery_soc,
            battery_action,
            recommended_action,
        });
    }

    let average_price = total_price / 24.0;

    Json(EnergyReport {
        current_price_mwh: hours[8].grid_price_mwh, // 8:00 AM mock current
        average_price_mwh: average_price,
        renewable_mix_percentage: 86.5,
        battery_capacity_mwh: 240,
        hours,
    })
}
