import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization of Gemini
let aiClient: GoogleGenAI | null = null;
function getGemini(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      console.warn("GEMINI_API_KEY environment variable is not defined. Running in fallback mode.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Global Sovereign Portfolio State (In-Memory Simulator State)
const portfolio = {
  assets: [
    {
      id: "dc-douglas-core",
      name: "Douglas Sovereign Core",
      location: "Douglas, Isle of Man",
      coordinates: [54.145, -4.482],
      powerCapacityMw: 120.0,
      gpuCapacity: 12000,
      storagePetabytes: 50.0,
      renewablePercentage: 98.0,
      renewableSource: "Tidal & Off-grid Wind",
      coolingTech: "Direct Liquid-to-Chip immersion",
      fibreConnections: ["CeltixConnect", "Lanis-3", "Havfrue"],
      landOwnership: "Freehold (Fund Owned)",
      buildingValue: 145000000, // USD
      hardwareValue: 280000000, // USD
      annualRevenue: 84000000,
      operatingCost: 32000000,
      utilization: 82.5,
      uptime: 99.999,
      strategicReserveGpus: 2400, // Sovereign compute reserve
      commercialGpus: 9600,
    },
    {
      id: "dc-hull-green",
      name: "Hull Green Maritime Campus",
      location: "Hull, United Kingdom",
      coordinates: [53.743, -0.334],
      powerCapacityMw: 85.0,
      gpuCapacity: 8000,
      storagePetabytes: 35.0,
      renewablePercentage: 100.0,
      renewableSource: "Dogger Bank Offshore Wind",
      coolingTech: "Indirect Evaporative",
      fibreConnections: ["Aegir", "BT Sovereign Spine"],
      landOwnership: "99-Year Leasehold",
      buildingValue: 98000000,
      hardwareValue: 185000000,
      annualRevenue: 56000000,
      operatingCost: 21000000,
      utilization: 76.2,
      uptime: 99.995,
      strategicReserveGpus: 1500,
      commercialGpus: 6500,
    },
    {
      id: "dc-clyde-nexus",
      name: "Clyde Sovereign Nexus",
      location: "Glasgow, Scotland",
      coordinates: [55.864, -4.251],
      powerCapacityMw: 150.0,
      gpuCapacity: 16000,
      storagePetabytes: 80.0,
      renewablePercentage: 95.0,
      renewableSource: "Pumped Hydro Storage",
      coolingTech: "Two-Phase Immersion",
      fibreConnections: ["ScapaFlow-Fibre", "EirGrid-Link"],
      landOwnership: "Freehold (Joint Venture)",
      buildingValue: 180000000,
      hardwareValue: 360000000,
      annualRevenue: 112000000,
      operatingCost: 41000000,
      utilization: 89.1,
      uptime: 99.999,
      strategicReserveGpus: 3200,
      commercialGpus: 12800,
    }
  ],
  locationsScanner: [
    { name: "Hull Hub (Expansion)", score: 92, status: "Active Bid", irr: 14.8, powerPriceMwh: 48.0, renewable: 100, fibreScore: 90, politicalStability: 95 },
    { name: "Douglas Harbor Vault", score: 95, status: "Feasibility", irr: 16.2, powerPriceMwh: 42.0, renewable: 98, fibreScore: 95, politicalStability: 99 },
    { name: "Shetland Tidal Grid", score: 88, status: "Planning", irr: 13.9, powerPriceMwh: 38.0, renewable: 100, fibreScore: 82, politicalStability: 95 },
    { name: "Belfast Sovereign Link", score: 84, status: "Evaluation", irr: 12.5, powerPriceMwh: 54.0, renewable: 85, fibreScore: 88, politicalStability: 90 },
    { name: "Isle of Man North Sand", score: 91, status: "Pre-Development", irr: 15.5, powerPriceMwh: 40.0, renewable: 100, fibreScore: 91, politicalStability: 99 }
  ]
};

// API Endpoint 1: Get Portfolio Summary and Assets
app.get("/api/portfolio", (req, res) => {
  const totalAssets = portfolio.assets.length;
  const assetValue = portfolio.assets.reduce((sum, item) => sum + item.buildingValue + item.hardwareValue, 0);
  const revenue = portfolio.assets.reduce((sum, item) => sum + item.annualRevenue, 0);
  const operatingCost = portfolio.assets.reduce((sum, item) => sum + item.operatingCost, 0);
  const ebitda = revenue - operatingCost;
  const avgUtilization = portfolio.assets.reduce((sum, item) => sum + item.utilization, 0) / totalAssets;
  const avgUptime = portfolio.assets.reduce((sum, item) => sum + item.uptime, 0) / totalAssets;
  const totalPowerMw = portfolio.assets.reduce((sum, item) => sum + item.powerCapacityMw, 0);
  
  // Calculate historical monthly data for charts
  const history = Array.from({ length: 12 }).map((_, idx) => {
    const month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][idx];
    const modifier = 1 + (idx - 6) * 0.02 + Math.sin(idx) * 0.01;
    return {
      month,
      revenue: Math.round(revenue * modifier / 12),
      ebitda: Math.round(ebitda * modifier / 12),
      uptime: Number((99.99 + Math.sin(idx) * 0.005).toFixed(3)),
      utilization: Number((avgUtilization + Math.cos(idx) * 2.5).toFixed(1)),
      energyMw: Number((totalPowerMw * (0.8 + Math.sin(idx) * 0.08)).toFixed(1))
    };
  });

  res.json({
    summary: {
      totalAssets,
      assetValue,
      revenue,
      ebitda,
      avgUtilization: Number(avgUtilization.toFixed(1)),
      avgUptime: Number(avgUptime.toFixed(3)),
      totalPowerMw,
      capitalDeployed: assetValue * 0.75, // Assuming 75% equity-deployed capital
      irr: 15.4
    },
    assets: portfolio.assets,
    history
  });
});

// API Endpoint 2: AI Compute Marketplace Engine Quote
app.post("/api/marketplace/quote", (req, res) => {
  const { gpusRequested, hoursNeeded, priority, workloadType } = req.body;
  
  if (!gpusRequested || !hoursNeeded || !priority || !workloadType) {
    return res.status(400).json({ error: "Missing required parameters" });
  }

  // Energy cost modifier depending on grid demand and renewable forecasting
  const baseRatePerHourPerGpu = 1.85; // USD/GPU/hr (H100 equivalent baseline)
  let priorityMultiplier = 1.0;
  if (priority === "critical") priorityMultiplier = 1.4;
  else if (priority === "strategic") priorityMultiplier = 1.1;
  else if (priority === "flexible") priorityMultiplier = 0.8; // Demand response discount

  // Simulation parameters
  const currentGridPriceMwh = 42.0; // USD/MWh
  const activeRenewableAvailability = 88.4; // %
  const hardwareDepreciationFactor = 0.35; // USD/GPU/hr
  const electricityConsumptionPerGpuKw = 0.7; // 700W H100

  // Calculate costs
  const totalPowerConsumptionMwh = (gpusRequested * electricityConsumptionPerGpuKw * hoursNeeded) / 1000;
  const electricityCost = totalPowerConsumptionMwh * currentGridPriceMwh;
  const depreciationCost = gpusRequested * hardwareDepreciationFactor * hoursNeeded;
  
  // High wind/renewables increases revenue margins or passes savings
  const renewableSavingFactor = activeRenewableAvailability > 80 ? 0.9 : 1.1;
  const basePrice = gpusRequested * hoursNeeded * baseRatePerHourPerGpu * priorityMultiplier * renewableSavingFactor;
  
  const finalPrice = Math.round(basePrice * 100) / 100;
  const marginPercentage = Number(((1 - (electricityCost + depreciationCost) / finalPrice) * 100).toFixed(1));

  // Determine allocation site
  const allocatedSite = portfolio.assets.reduce((best, asset) => {
    const available = asset.commercialGpus * (1 - asset.utilization / 100);
    if (available >= gpusRequested && asset.renewablePercentage > best.renewablePercentage) {
      return asset;
    }
    return best;
  }, portfolio.assets[0]);

  res.json({
    quoteId: "QT-" + Math.floor(100000 + Math.random() * 900000),
    allocatedSite: allocatedSite.name,
    allocatedSiteId: allocatedSite.id,
    gpusAllocated: gpusRequested,
    totalPowerConsumptionMwh: Number(totalPowerConsumptionMwh.toFixed(2)),
    electricityCost: Math.round(electricityCost * 100) / 100,
    depreciationCost: Math.round(depreciationCost * 100) / 100,
    finalPrice,
    marginPercentage,
    greenMatchStatus: activeRenewableAvailability > 80 ? "Sovereign 100% Green Match" : "Grid Co-Mix Match",
    status: "APPROVED"
  });
});

// API Endpoint 3: Energy Optimisation Real-Time Forecasting
app.get("/api/energy/forecast", (req, res) => {
  // Generate 24 hours of grid pricing & wind/tidal generation forecast
  const hours = Array.from({ length: 24 }).map((_, hour) => {
    const time = `${hour.toString().padStart(2, "0")}:00`;
    // Simulate wind generation peaking in the late evening/early morning
    const windGenMw = 45.0 + Math.sin((hour - 18) * Math.PI / 12) * 25.0 + Math.random() * 5;
    const solarGenMw = hour > 5 && hour < 19 ? Math.sin((hour - 6) * Math.PI / 12) * 15.0 : 0.0;
    const baseDemand = 60.0 + Math.sin((hour - 8) * Math.PI / 12) * 20.0;
    
    // Grid price is inversely proportional to renewable generation and directly to peak demand
    const renewableTotal = windGenMw + solarGenMw;
    const gridPriceMwh = Math.max(15.0, Number((35.0 + (baseDemand * 0.6) - (renewableTotal * 0.35) + Math.cos(hour * Math.PI / 6) * 4).toFixed(2)));
    
    // Battery dispatch logic
    let batteryState = "Charging";
    let batterySoc = Math.min(100, Math.max(10, 40 + Math.sin(hour * Math.PI / 12) * 30));
    if (gridPriceMwh > 50) {
      batteryState = "Discharging (Grid Saving)";
    } else if (gridPriceMwh < 25) {
      batteryState = "Charging (Wind Capture)";
    } else {
      batteryState = "Standby (Optimized)";
    }

    // Recommendation
    let action = "Dispatch Strategic High-Compute";
    if (gridPriceMwh > 45) {
      action = "De-prioritize Flexible Workloads (Demand Response Active)";
    } else if (gridPriceMwh < 25) {
      action = "Maximize Multi-node LLM Training Runs";
    }

    return {
      time,
      gridPriceMwh,
      windGenMw: Number(windGenMw.toFixed(1)),
      solarGenMw: Number(solarGenMw.toFixed(1)),
      renewableTotal: Number(renewableTotal.toFixed(1)),
      batterySoc: Math.round(batterySoc),
      batteryState,
      action
    };
  });

  res.json({
    currentPrice: hours[8].gridPriceMwh, // Mock current is 8 AM
    avgPrice: Number((hours.reduce((sum, h) => sum + h.gridPriceMwh, 0) / 24).toFixed(2)),
    renewableMixPercentage: 86.5,
    batterySystemCapacityMwh: 240,
    hours
  });
});

// API Endpoint 4: Digital Twin Live Simulator
app.post("/api/twin/simulate", (req, res) => {
  const { assetId, gpuScale, gridPriceModifier, demandMultiplier } = req.body;
  
  const targetAsset = portfolio.assets.find(a => a.id === assetId);
  if (!targetAsset) {
    return res.status(404).json({ error: "Asset not found" });
  }

  // Calculate simulated values
  const simGpus = Math.round(targetAsset.gpuCapacity * (gpuScale || 1.0));
  const simPowerCapacity = Number((targetAsset.powerCapacityMw * (1.0 + (gpuScale - 1.0) * 0.75)).toFixed(1));
  const gridCostModifier = gridPriceModifier || 1.0;
  
  const simUtilization = Math.min(98.5, targetAsset.utilization * (demandMultiplier || 1.0));
  const simRevenue = Math.round(targetAsset.annualRevenue * (gpuScale || 1.0) * (simUtilization / targetAsset.utilization));
  const simOperatingCost = Math.round(targetAsset.operatingCost * (1.0 + (gpuScale - 1.0) * 0.4) * gridCostModifier);
  const simEbitda = simRevenue - simOperatingCost;
  
  // Environmental stats
  const pue = Number((1.18 - (gpuScale - 1.0) * 0.02).toFixed(2)); // Efficiency increases with larger clusters / immersion upgrades
  const carbonFootprintTons = Math.round(simPowerCapacity * (1 - targetAsset.renewablePercentage / 100) * 24 * 365 * 0.28);

  res.json({
    assetId,
    assetName: targetAsset.name,
    simGpus,
    simPowerCapacity,
    pue,
    simUtilization: Number(simUtilization.toFixed(1)),
    simRevenue,
    simOperatingCost,
    simEbitda,
    ebitdaDelta: simEbitda - (targetAsset.annualRevenue - targetAsset.operatingCost),
    carbonFootprintTons,
    strategicReserveSimGpus: Math.round(simGpus * 0.20), // Always maintain 20% strategic reserve
    coolingPerformance: pue < 1.12 ? "Excellent (Immersion Class)" : "Nominal"
  });
});

// API Endpoint 5: Infrastructure Investment IRR Calculator
app.post("/api/investment/calculate", (req, res) => {
  const { campusName, landCapex, constructionCapex, powerConnectionCapex, gpusInstalled, targetRentPerGpuMonth } = req.body;

  // Base parameters
  const initialCapex = Number(landCapex || 20) + Number(constructionCapex || 60) + Number(powerConnectionCapex || 15) + (Number(gpusInstalled || 5000) * 0.018); // assuming 18k per GPU server block
  
  // Calculate yearly financial projections
  const totalCapexUsd = initialCapex * 1000000;
  const annualGpuRevenue = Number(gpusInstalled) * Number(targetRentPerGpuMonth) * 12;
  const annualOpex = (annualGpuRevenue * 0.25) + (Number(gpusInstalled) * 0.7 * 8760 * 45 / 1000); // 25% margin opex + GPU power at 45 USD/MWh
  const annualEbitda = annualGpuRevenue - annualOpex;
  
  // Calculate cashflows for a 10 year cycle
  const cashflows: number[] = [-totalCapexUsd];
  for (let year = 1; year <= 10; year++) {
    // Add 2.5% inflation on OPEX and minor degradation of GPU revenue over 4 years, followed by refresh cycles
    let revenueModifier = 1.0;
    if (year === 4 || year === 8) {
      // GPU refresh CAPEX
      cashflows.push(Math.round(annualEbitda - (totalCapexUsd * 0.3))); // 30% GPU replacement Capex
    } else {
      cashflows.push(Math.round(annualEbitda * revenueModifier));
    }
  }

  // Calculate IRR (Newton-Raphson approximation)
  let irr = 0.12; // initial guess
  for (let i = 0; i < 50; i++) {
    let npv = 0;
    let dNpv = 0;
    for (let t = 0; t < cashflows.length; t++) {
      npv += cashflows[t] / Math.pow(1 + irr, t);
      if (t > 0) {
        dNpv -= t * cashflows[t] / Math.pow(1 + irr, t + 1);
      }
    }
    const nextIrr = irr - npv / dNpv;
    if (Math.abs(nextIrr - irr) < 0.0001) {
      irr = nextIrr;
      break;
    }
    irr = nextIrr;
  }

  // NPV at 8% cost of capital
  let npv8 = 0;
  for (let t = 0; t < cashflows.length; t++) {
    npv8 += cashflows[t] / Math.pow(1 + 0.08, t);
  }

  const paybackPeriod = Number((totalCapexUsd / annualEbitda).toFixed(1));
  const assetLtv = annualEbitda * 12.5; // sovereign multiple valuation

  res.json({
    campusName,
    totalCapexUsd,
    annualRevenue: Math.round(annualGpuRevenue),
    annualOpex: Math.round(annualOpex),
    annualEbitda: Math.round(annualEbitda),
    irr: Number((irr * 100).toFixed(2)),
    npvUsd: Math.round(npv8),
    paybackYears: paybackPeriod,
    assetLtv: Math.round(assetLtv),
    yearlyCashflows: cashflows.map((val, idx) => ({ year: idx, value: val }))
  });
});

// API Endpoint 6: Sovereign Compute Reserve Allocation
app.post("/api/reserve/allocate", (req, res) => {
  const { agencyName, coresRequested, durationHours, emergencyCode } = req.body;
  if (!agencyName || !coresRequested || !durationHours) {
    return res.status(400).json({ error: "Missing required reserve parameters" });
  }

  // Sovereign wealth emergency override or strategic planning
  const isEmergency = emergencyCode === "EV-STRATEGIC-OVERRIDE";
  const allocationApproval = isEmergency ? "GRANTED - PRIORITY 1 STRATEGIC DISPATCH" : "GRANTED - COMMERCIAL RESERVE POOL";
  
  res.json({
    reserveTicket: "RES-EV-" + Math.floor(200000 + Math.random() * 800000),
    agencyName,
    allocatedGpus: coresRequested,
    durationHours,
    emergencyOverride: isEmergency,
    status: allocationApproval,
    gridPriority: isEmergency ? "Level 1 (Pre-emptive)" : "Level 3 (Coordinated)",
    associatedCampus: "Douglas Sovereign Core",
    energyPreemptionMw: Number((coresRequested * 0.7 / 1000).toFixed(2))
  });
});

// API Endpoint 7: Portfolio Monte Carlo Simulator Risk Engine
app.get("/api/risk/simulation", (req, res) => {
  // Monte Carlo parameters: 1000 trials of portfolio value
  const baseValue = portfolio.assets.reduce((sum, item) => sum + item.buildingValue + item.hardwareValue, 0);
  const trials = 1000;
  const results: number[] = [];

  // Volatility profiles
  const electricityVolatility = 0.22; // 22% grid volatility
  const gpuRentVolatility = 0.15; // 15% lease pricing demand shifts
  const coolingFailureProb = 0.02; // 2% operational hazard
  
  for (let i = 0; i < trials; i++) {
    // Random normal distributions using Box-Muller transform
    const u1 = Math.random();
    const u2 = Math.random();
    const randNorm1 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    const randNorm2 = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2);

    let trialVal = baseValue;
    // Apply electricity price risk
    trialVal *= (1.0 + randNorm1 * electricityVolatility * 0.25);
    // Apply demand rent risk
    trialVal *= (1.0 + randNorm2 * gpuRentVolatility * 0.35);
    
    // Apply operational outages
    if (Math.random() < coolingFailureProb) {
      trialVal -= 5000000; // $5M hardware damage / business interruption penalty
    }

    results.push(Math.round(trialVal));
  }

  // Sort results for percentiles
  results.sort((a, b) => a - b);
  const p10 = results[Math.floor(trials * 0.1)];
  const p50 = results[Math.floor(trials * 0.5)];
  const p90 = results[Math.floor(trials * 0.9)];
  
  // Create distribution bins
  const binCount = 15;
  const minVal = results[0];
  const maxVal = results[trials - 1];
  const binWidth = (maxVal - minVal) / binCount;
  
  const bins = Array.from({ length: binCount }).map((_, idx) => {
    const binStart = minVal + idx * binWidth;
    const binEnd = binStart + binWidth;
    const count = results.filter(r => r >= binStart && r < binEnd).length;
    return {
      range: `${(binStart / 1000000).toFixed(0)}M-${(binEnd / 1000000).toFixed(0)}M`,
      count
    };
  });

  res.json({
    metrics: {
      portfolioBaseValue: baseValue,
      valueAtRisk95: baseValue - p10, // 95% confidence interval VAR
      p10Val: p10,
      p50Val: p50,
      p90Val: p90,
      riskRating: "Low-Moderate Sovereign Tier"
    },
    stressScenarios: [
      { name: "Sovereign Grid Power Surge (+150% Electric Price)", impact: "-$8.4M operating margins", probability: "Low", status: "Mitigated via PPA (Power Purchase Agreement)" },
      { name: "Extreme Heatwaves (PUE increases to 1.35)", impact: "-1.2% overall performance", probability: "Medium", status: "Mitigated via Chip Immersion Cooling" },
      { name: "AI Cluster Supply Squeeze (GPU values appreciate 30%)", impact: "+$84M NAV appreciation", probability: "Low-Medium", status: "Favourable" }
    ],
    bins
  });
});

// Helper to generate a highly detailed and contextual fallback advisory report when Gemini is offline/leaked
function getFallbackResponse(role: string, userPrompt: string, isLeaked: boolean = false): string {
  const warningHeader = isLeaked
    ? `> ⚠️ **Aurora Sovereign Advisor Running in Offline Backup Mode**
> The live connection to the Gemini engine is currently suspended because the configured API key was reported as leaked or has expired.
> 
> **How to resolve:**
> 1. Open the **Settings > Secrets** panel in the AI Studio editor.
> 2. Ensure a valid, active, and secure \`GEMINI_API_KEY\` is configured.
> 3. Click "Save" and refresh the page to reconnect the live advisor.
>
> ---\n\n`
    : `> ℹ️ **Aurora Sovereign Advisor Running in Offline Backup Mode**
> The live connection to the Gemini engine is currently suspended because the \`GEMINI_API_KEY\` is not defined.
> 
> **How to resolve:**
> 1. Open the **Settings > Secrets** panel in the AI Studio editor.
> 2. Add your \`GEMINI_API_KEY\`.
> 3. Click "Save" and refresh the page to reconnect.
>
> ---\n\n`;

  const lowerPrompt = (userPrompt || "").toLowerCase();
  let specificAdvice = "";
  
  if (lowerPrompt.includes("irr") || lowerPrompt.includes("capital") || lowerPrompt.includes("investment") || lowerPrompt.includes("yield")) {
    specificAdvice = `### 📊 Financial & IRR Strategic Advisory Update
*Target Audience: ${role}*

1. **Strategic Asset Valuation**:
   - Total portfolio valuation stands at **$948M** across our three major naval data hubs.
   - Annualized run-rate revenue is **$252M** with an EBITDA margin of **$160M** (approx. 63.5% operations-to-yield efficiency).

2. **High-Yield Greenfield Target**:
   - The **Douglas Harbor Vault** is the highest scoring expansion prospect at **95/100**, yielding a projected **16.2% IRR** with a payback period of under **4.8 years**.
   - Recommend allocating 70% of the sovereign fund's next deployment cycle into Douglas Harbor, leveraging local wind-power purchase agreements (PPAs).

3. **GPU Lifecycle Management**:
   - Year 4 and Year 8 contain scheduled **30% GPU replacement Capex cycles**. To avoid NPV degradation, we recommend scheduling hardware depreciation across dual commercial/strategic tranches to spread capital drawdowns.`;
  } else if (lowerPrompt.includes("pue") || lowerPrompt.includes("thermal") || lowerPrompt.includes("cooling") || lowerPrompt.includes("engineer")) {
    specificAdvice = `### 🧪 Thermodynamic & Cooling Engineering Advisory
*Target Audience: ${role}*

1. **Direct Liquid-to-Chip Immersion (Douglas Core)**:
   - Douglas Core currently runs at **98.0% renewable match** with a class-leading baseline PUE of **1.12**. This is achieved using direct liquid-to-chip immersion cooling.
   - Expanding the GPU cluster to 2.5x scaling via the digital twin raises power requirements, but preserves high thermal efficiency.

2. **Two-Phase Immersion Cooling (Clyde Nexus)**:
   - Clyde Nexus is utilizing two-phase immersion cooling but suffers from high saturation (89.1% utilization). 
   - Recommended action: Deploy predictive maintenance schedules for dielectric fluid degradation every **10,000 continuous hours** to prevent fluid boiling drift and micro-cavitation.

3. **Subsea Latency Optimization**:
   - The Isle of Man sovereign fiber loop integrates **CeltixConnect**, **Lanis-3**, and **Havfrue**. These redundant subsea paths offer sub-3.8ms round-trip-time (RTT) latency to Irish Sea offshore grids and Dublin hyperscaler exchange nodes.`;
  } else if (lowerPrompt.includes("load") || lowerPrompt.includes("dispatch") || lowerPrompt.includes("energy") || lowerPrompt.includes("wind")) {
    specificAdvice = `### ⚡ Energy Dispatch & Load-Shedding Analysis
*Target Audience: ${role}*

1. **Surplus Wind Capture (Hull & Douglas Core)**:
   - Hull Campus is linked directly to **Dogger Bank Offshore Wind** (100% renewable match). Spot grid rates drop below **$25/MWh** during late-night tidal and wind surges.
   - Recommendation: Configure dispatch automation to trigger high-intensity LLM training batch runs exclusively during these low-rate hours (typically 23:00 - 04:00).

2. **Demand Response & Load-Shedding**:
   - During peak-demand grid hours (17:00 - 19:00), grid spot prices spike up to **$54/MWh**. 
   - Active strategy: Automatically transition flexible commercial workloads into standby mode while dispatching battery reserve power (240 MWh capacity) to safeguard high-priority security clients.

3. **Compute Preemption Allocation**:
   - The **Isle of Man Financial Intelligence Unit (FIU)** holds preemptive Level-1 strategic priority access. During security audits, up to 2,400 strategic cores at Douglas Core can be immediately isolated within 200ms.`;
  } else {
    specificAdvice = `### 🏛️ Sovereign Portfolio Telemetry Advisory
*Target Audience: ${role}*

1. **Operational Performance Metrics**:
   - Total Active Portfolio Power Capacity: **355 MW** with average 100% renewable grid-match of **97.7%**.
   - Average Cluster Utilization: **82.6%** with portfolio-wide SLA uptime exceeding **99.997%**.
   - Current Sovereign Reserve Pool: **7,100 high-performance GPUs** held in pre-emptive hardware isolation.

2. **Engineering & Energy Synergies**:
   - The Isle of Man's unique off-grid wind and tidal PPAs insulate the portfolio from UK mainland energy price shocks.
   - Direct liquid-immersion cooling at Clyde and Douglas Core is keeping the portfolio's aggregate PUE under **1.14**, saving an estimated **$14.2M** in annual utility costs compared to conventional air-cooled hubs.

3. **Recommended Immediate Action**:
   - Execute greenfield land-bids for **Hull Hub Expansion** to capture additional Dogger Bank capacity at a target **14.8% IRR**.`;
  }

  return `${warningHeader}${specificAdvice}`;
}

// API Endpoint 8: AI Advisor - Gemini Integration
app.post("/api/gemini/insights", async (req, res) => {
  const ai = getGemini();
  const { currentMetrics, role, prompt: userPrompt } = req.body;

  const dataPayloadString = JSON.stringify(currentMetrics || portfolio.assets);

  if (!ai) {
    // Fallback response when API key is missing
    return res.json({
      text: getFallbackResponse(role || "Investment Advisor", userPrompt, false)
    });
  }

  try {
    const systemInstructions = `You are the chief sovereign technology and investment advisor for Ellan Vannin Wealth Management's AURORA GRID. 
    Your tone is highly professional, academic, analytical, objective, and authoritative—befitting a leading sovereign wealth fund advisor.
    Provide strategic, high-value investment, energy, or engineering recommendations. 
    Analyze the portfolio data provided below and tailor your recommendations specifically for the user role: ${role || "Investment Analyst"}.
    Focus strictly on maximizing IRR, achieving carbon neutrality via 100% renewable match, sovereign security, energy dispatch algorithms, and cluster life cycle optimization.`;

    const modelPrompt = `
    Role: ${role || "Investment Analyst"}
    User Inquiry: ${userPrompt || "Provide a comprehensive sovereign portfolio assessment and energy-saving report."}
    Current Portfolio Data: ${dataPayloadString}
    
    Respond in concise, professional Markdown. Use logical structural groupings.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: modelPrompt,
      config: {
        systemInstruction: systemInstructions,
        temperature: 0.7
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini call failed (triggering custom offline fallback):", error);
    
    // Check if the key was reported as leaked/invalid
    const isLeaked = error.message?.includes("leaked") || error.message?.includes("PERMISSION_DENIED") || error.status === 403;
    
    // Return a 200 with fallback advisory report and instructions to help the user resolve the issue
    res.json({
      text: getFallbackResponse(role || "Investment Advisor", userPrompt, isLeaked),
      error: error.message
    });
  }
});

// Serve frontend build static files in production
if (process.env.NODE_ENV !== "production") {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  });
  app.use(vite.middlewares);
} else {
  const distPath = path.join(process.cwd(), "dist");
  app.use(express.static(distPath));
  app.get("*", (req, res) => {
    res.sendFile(path.join(distPath, "index.html"));
  });
}

app.listen(PORT, "0.0.0.0", () => {
  console.log(`AURORA GRID Server running at http://0.0.0.0:${PORT}`);
});
