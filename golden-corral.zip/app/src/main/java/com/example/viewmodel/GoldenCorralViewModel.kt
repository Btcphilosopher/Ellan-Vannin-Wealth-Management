package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.util.UUID
import kotlin.random.Random

class GoldenCorralViewModel : ViewModel() {

    // --- SEEDS & BASE DATA ---
    val restaurants = GoldenCorralSeeds.demoRestaurants
    val allMenuItems = GoldenCorralSeeds.menuItems
    val menuCategories = GoldenCorralSeeds.menuCategories

    // --- NAVIGATION STATE ---
    private val _currentTab = MutableStateFlow("HOME")
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    private val _managerMode = MutableStateFlow(false)
    val managerMode: StateFlow<Boolean> = _managerMode.asStateFlow()

    fun setTab(tab: String) {
        _currentTab.value = tab
    }

    fun toggleManagerMode() {
        _managerMode.value = !_managerMode.value
    }

    // --- SELECTED RESTAURANT & TIME CONTEXT ---
    private val _selectedRestaurant = MutableStateFlow(restaurants[0]) // Charlotte woodlawn by default
    val selectedRestaurant: StateFlow<Restaurant> = _selectedRestaurant.asStateFlow()

    fun selectRestaurant(restaurant: Restaurant) {
        _selectedRestaurant.value = restaurant
        // Reset simulation metrics for selected location to feel authentic
        triggerSimulationReset()
    }

    // --- USER PROFILE & REWARDS ---
    private val _userPoints = MutableStateFlow(72)
    val userPoints: StateFlow<Int> = _userPoints.asStateFlow()

    private val _rewardBalance = MutableStateFlow(10.00) // 100 points = $10.00
    val rewardBalance: StateFlow<Double> = _rewardBalance.asStateFlow()

    private val _rewardApplied = MutableStateFlow(0.0)
    val rewardApplied: StateFlow<Double> = _rewardApplied.asStateFlow()

    private val _rewardsLedger = MutableStateFlow<List<RewardsTransaction>>(
        listOf(
            RewardsTransaction(date = "SEP 20", description = "DINNER - Charlotte", pointsChange = 24),
            RewardsTransaction(date = "SEP 16", description = "TO GO - Charlotte", pointsChange = 18),
            RewardsTransaction(date = "SEP 10", description = "REWARD REDEEMED", pointsChange = -100)
        )
    )
    val rewardsLedger: StateFlow<List<RewardsTransaction>> = _rewardsLedger.asStateFlow()

    // --- CART / ORDERING STATE ---
    private val _orderType = MutableStateFlow(OrderType.TO_GO)
    val orderType: StateFlow<OrderType> = _orderType.asStateFlow()

    private val _cart = MutableStateFlow<List<OrderItem>>(emptyList())
    val cart: StateFlow<List<OrderItem>> = _cart.asStateFlow()

    private val _activeOrder = MutableStateFlow<Order?>(null)
    val activeOrder: StateFlow<Order?> = _activeOrder.asStateFlow()

    private val _orderHistory = MutableStateFlow<List<Order>>(emptyList())
    val orderHistory: StateFlow<List<Order>> = _orderHistory.asStateFlow()

    private val _deliveryAddress = MutableStateFlow("100 Main St, Charlotte, NC 28202")
    val deliveryAddress: StateFlow<String> = _deliveryAddress.asStateFlow()

    fun setOrderType(type: OrderType) {
        _orderType.value = type
    }

    fun setDeliveryAddress(addr: String) {
        _deliveryAddress.value = addr
    }

    fun addToCart(item: MenuItem) {
        _cart.update { current ->
            val existing = current.find { it.menuItem.id == item.id }
            if (existing != null) {
                current.map {
                    if (it.menuItem.id == item.id) it.copy(quantity = it.quantity + 1) else it
                }
            } else {
                current + OrderItem(item, 1)
            }
        }
    }

    fun removeFromCart(item: MenuItem) {
        _cart.update { current ->
            val existing = current.find { it.menuItem.id == item.id }
            if (existing != null && existing.quantity > 1) {
                current.map {
                    if (it.menuItem.id == item.id) it.copy(quantity = it.quantity - 1) else it
                }
            } else {
                current.filter { it.menuItem.id != item.id }
            }
        }
    }

    fun clearCart() {
        _cart.value = emptyList()
        _rewardApplied.value = 0.0
    }

    fun applyRewardAmount(amount: Double) {
        if (amount <= _rewardBalance.value) {
            _rewardApplied.value = amount
        }
    }

    fun calculateCartSubtotal(): Double {
        return _cart.value.sumOf { it.menuItem.basePrice * it.quantity }
    }

    fun calculateCartTotal(): Double {
        val sub = calculateCartSubtotal()
        val tax = sub * 0.08
        val discount = _rewardApplied.value
        val total = (sub + tax) - discount
        return if (total < 0.0) 0.0 else total
    }

    fun submitOrder(partySize: Int = 1) {
        val sub = calculateCartSubtotal()
        val tax = sub * 0.08
        val appliedDisc = _rewardApplied.value
        val tot = calculateCartTotal()

        val newOrder = Order(
            id = (1000..9999).random().toString(),
            restaurantId = _selectedRestaurant.value.id,
            restaurantName = _selectedRestaurant.value.name,
            items = _cart.value,
            subtotal = sub,
            discount = appliedDisc,
            total = tot,
            status = OrderStatus.RECEIVED,
            type = _orderType.value,
            deliveryAddress = if (_orderType.value == OrderType.DELIVERY) _deliveryAddress.value else null,
            estimatedReadyTime = "7:14 PM"
        )

        _activeOrder.value = newOrder
        _orderHistory.update { listOf(newOrder) + it }

        // Deduct rewards balance used
        if (appliedDisc > 0.0) {
            _rewardBalance.value = (_rewardBalance.value - appliedDisc).coerceAtLeast(0.0)
            _rewardsLedger.update {
                listOf(
                    RewardsTransaction(date = "TODAY", description = "REWARD APPLIED", pointsChange = 0)
                ) + it
            }
        }

        // Add points earned: $1 spent = 1 point
        val pointsEarned = tot.toInt()
        if (pointsEarned > 0) {
            _userPoints.value = _userPoints.value + pointsEarned
            _rewardsLedger.update {
                listOf(
                    RewardsTransaction(date = "TODAY", description = "PURCHASE - ${newOrder.id}", pointsChange = pointsEarned)
                ) + it
            }
        }

        // Check for reward unlock: If total points cross 100, award $10 off
        if (_userPoints.value >= 100) {
            val rewardsUnlocked = _userPoints.value / 100
            _rewardBalance.value = _rewardBalance.value + (rewardsUnlocked * 10.0)
            _userPoints.value = _userPoints.value % 100
            _rewardsLedger.update {
                listOf(
                    RewardsTransaction(date = "TODAY", description = "REWARD UNLOCKED", pointsChange = -100 * rewardsUnlocked)
                ) + it
            }
        }

        // Clear cart
        clearCart()

        // Start Order Status simulation
        startOrderTrackingSimulation()
    }

    private var orderTrackerJob: Job? = null
    private fun startOrderTrackingSimulation() {
        orderTrackerJob?.cancel()
        orderTrackerJob = viewModelScope.launch {
            delay(4000)
            _activeOrder.update { it?.copy(status = OrderStatus.PREPARING) }
            delay(5000)
            _activeOrder.update { it?.copy(status = OrderStatus.PACKING) }
            delay(5000)
            _activeOrder.update {
                val nextStatus = if (it?.type == OrderType.DELIVERY) OrderStatus.ON_THE_WAY else OrderStatus.READY
                it?.copy(status = nextStatus)
            }
            if (_activeOrder.value?.type == OrderType.DELIVERY) {
                delay(6000)
                _activeOrder.update { it?.copy(status = OrderStatus.DELIVERED) }
            }
        }
    }

    // --- RECEIPT SCANNER SIMULATOR ---
    private val _scanningState = MutableStateFlow<String>("IDLE") // IDLE, SCANNING, SUCCESS
    val scanningState: StateFlow<String> = _scanningState.asStateFlow()

    fun scanReceiptSimulated() {
        viewModelScope.launch {
            _scanningState.value = "SCANNING"
            delay(2500)
            _scanningState.value = "SUCCESS"
            // Add 24 points
            _userPoints.value = _userPoints.value + 24
            _rewardsLedger.update {
                listOf(
                    RewardsTransaction(date = "TODAY", description = "SCANNED RECEIPT", pointsChange = 24)
                ) + it
            }
            checkUnlock()
            delay(2000)
            _scanningState.value = "IDLE"
        }
    }

    fun submitReceiptCode(code: String) {
        if (code.length >= 5) {
            _userPoints.value = _userPoints.value + 24
            _rewardsLedger.update {
                listOf(
                    RewardsTransaction(date = "TODAY", description = "MANUAL RECEIPT CODE", pointsChange = 24)
                ) + it
            }
            checkUnlock()
        }
    }

    private fun checkUnlock() {
        if (_userPoints.value >= 100) {
            val count = _userPoints.value / 100
            _rewardBalance.value = _rewardBalance.value + (count * 10.0)
            _userPoints.value = _userPoints.value % 100
            _rewardsLedger.update {
                listOf(
                    RewardsTransaction(date = "TODAY", description = "REWARD UNLOCKED", pointsChange = -100 * count)
                ) + it
            }
        }
    }

    // --- PLATE BUILDER ("BUILD MY PLATE") ---
    private val _currentPlate = MutableStateFlow<Map<String, MenuItem>>(emptyMap()) // Category to MenuItem
    val currentPlate: StateFlow<Map<String, MenuItem>> = _currentPlate.asStateFlow()

    private val _savedPlates = MutableStateFlow<List<Pair<String, List<MenuItem>>>>(
        listOf(
            "My Sunday Feast" to listOf(
                allMenuItems.find { it.id == "m6" }!!, // Steak
                allMenuItems.find { it.id == "m14" }!!, // Mac & Cheese
                allMenuItems.find { it.id == "m22" }!!, // Roll
                allMenuItems.find { it.id == "m23" }!! // Carrot cake
            )
        )
    )
    val savedPlates: StateFlow<List<Pair<String, List<MenuItem>>>> = _savedPlates.asStateFlow()

    fun addPlateItem(category: String, item: MenuItem) {
        _currentPlate.update { current ->
            current + (category to item)
        }
    }

    fun clearPlate() {
        _currentPlate.value = emptyMap()
    }

    fun saveCurrentPlate(name: String) {
        val itemsList = _currentPlate.value.values.toList()
        if (itemsList.isNotEmpty() && name.isNotBlank()) {
            _savedPlates.update { current ->
                current + (name to itemsList)
            }
        }
    }

    fun orderPlateAgain(items: List<MenuItem>) {
        clearCart()
        items.forEach { addToCart(it) }
        _currentTab.value = "ORDER"
    }

    // --- FAMILY PROFILE STATE ---
    private val _familyMembers = MutableStateFlow<List<FamilyMember>>(
        listOf(
            FamilyMember(name = "Tom (Me)", role = "Dad", preferences = listOf("Low-Carb", "No Seafood")),
            FamilyMember(name = "Sarah", role = "Mum", preferences = listOf("Vegetarian")),
            FamilyMember(name = "Billy & Lilly", role = "Kids", preferences = listOf("Kids Favourites"))
        )
    )
    val familyMembers: StateFlow<List<FamilyMember>> = _familyMembers.asStateFlow()

    fun addFamilyMember(name: String, role: String, prefs: List<String>) {
        if (name.isNotBlank()) {
            _familyMembers.update { it + FamilyMember(name = name, role = role, preferences = prefs) }
        }
    }

    // --- FAVORITES ---
    private val _favoriteRestaurantId = MutableStateFlow<String>("1")
    val favoriteRestaurantId: StateFlow<String> = _favoriteRestaurantId.asStateFlow()

    private val _favoriteMenuItems = MutableStateFlow<Set<String>>(setOf("m6", "m8", "m22", "m23"))
    val favoriteMenuItems: StateFlow<Set<String>> = _favoriteMenuItems.asStateFlow()

    fun toggleFavoriteMenu(id: String) {
        _favoriteMenuItems.update { current ->
            if (current.contains(id)) current - id else current + id
        }
    }

    fun toggleFavoriteRestaurant(id: String) {
        _favoriteRestaurantId.value = id
    }

    // --- DIGITAL TWIN SIMULATION ENGINE ---
    // Operational Metrics inputs (Demand Simulator):
    val simDay = MutableStateFlow("Saturday")
    val simTime = MutableStateFlow("6:30 PM")
    val simWeather = MutableStateFlow("Warm & Clear")
    val simPromo = MutableStateFlow("Value Weekend Promo")

    // Outputs:
    val simCustomerCount = MutableStateFlow(486)
    val simPortionsServed = MutableStateFlow(1192)
    val simToGoOrders = MutableStateFlow(31)
    val simDeliveryOrders = MutableStateFlow(18)
    val simRevenue = MutableStateFlow(8420.50)

    val queueWaitDining = MutableStateFlow(7)
    val queueWaitToGo = MutableStateFlow(11)
    val queueWaitDelivery = MutableStateFlow(24)

    // Buffet station levels:
    private val _buffetStations = MutableStateFlow(GoldenCorralSeeds.initialBuffetStations())
    val buffetStations: StateFlow<List<BuffetStation>> = _buffetStations.asStateFlow()

    private var simulationJob: Job? = null

    init {
        startOperationsSimulation()
    }

    private fun startOperationsSimulation() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            while (true) {
                delay(3000) // tick every 3 seconds
                updateSimulationTick()
            }
        }
    }

    private fun updateSimulationTick() {
        // Portions consumed dynamically based on demand
        val rateFactor = when (simTime.value) {
            "8:00 AM" -> 0.8
            "12:30 PM" -> 1.5
            "6:30 PM" -> 2.2 // Peak dinner
            else -> 1.0
        }

        _buffetStations.update { currentStations ->
            currentStations.map { station ->
                val reduction = (Random.nextInt(1, 4) * rateFactor).toInt()
                val newPortions = (station.portionsAvailable - reduction).coerceAtLeast(0)
                val refillNeeded = newPortions <= (station.maxPortions * 0.3) // refill alert at 30%

                // Dynamically fluctuate temperature within limits to feel real
                val baseTemp = when (station.id) {
                    "s1", "s2", "s3", "s5", "s6" -> 140.0
                    "s4", "s7" -> 36.0
                    else -> 70.0
                }
                val drift = Random.nextDouble(-1.5, 1.5)
                val newTemp = baseTemp + drift

                station.copy(
                    portionsAvailable = newPortions,
                    currentTempF = Math.round(newTemp * 10.0) / 10.0,
                    isRefillRequired = refillNeeded,
                    demandLevel = if (rateFactor >= 1.8) "HIGH" else if (rateFactor >= 1.0) "MEDIUM" else "LOW"
                )
            }
        }

        // Fluctuate wait times slightly
        queueWaitDining.update { (it + Random.nextInt(-1, 2)).coerceIn(2, 35) }
        queueWaitToGo.update { (it + Random.nextInt(-1, 2)).coerceIn(5, 40) }
        queueWaitDelivery.update { (it + Random.nextInt(-2, 3)).coerceIn(10, 60) }

        // Increase operations cumulative counters
        simCustomerCount.update { it + Random.nextInt(1, 4) }
        simPortionsServed.update { it + Random.nextInt(2, 8) }
        simRevenue.update { it + Random.nextDouble(15.0, 75.0) }
    }

    fun refillStation(stationId: String) {
        _buffetStations.update { currentStations ->
            currentStations.map { station ->
                if (station.id == stationId) {
                    station.copy(
                        portionsAvailable = station.maxPortions,
                        isRefillRequired = false,
                        lastRefill = "Just Now"
                    )
                } else {
                    station
                }
            }
        }
        // Slightly lower dining queue wait time since buffet is refilled
        queueWaitDining.update { (it - 2).coerceAtLeast(3) }
    }

    fun updateDemandInputs(day: String, time: String, weather: String, promo: String) {
        simDay.value = day
        simTime.value = time
        simWeather.value = weather
        simPromo.value = promo
        triggerSimulationReset()
    }

    private fun triggerSimulationReset() {
        val peakMultiplier = when (simTime.value) {
            "8:00 AM" -> 0.6
            "12:30 PM" -> 1.4
            "6:30 PM" -> 2.0
            else -> 1.0
        }

        simCustomerCount.value = (300 * peakMultiplier).toInt() + Random.nextInt(10, 50)
        simPortionsServed.value = (800 * peakMultiplier).toInt() + Random.nextInt(20, 100)
        simToGoOrders.value = (20 * peakMultiplier).toInt() + Random.nextInt(2, 8)
        simDeliveryOrders.value = (10 * peakMultiplier).toInt() + Random.nextInt(1, 6)
        simRevenue.value = 4500.0 * peakMultiplier + Random.nextDouble(100.0, 500.0)

        queueWaitDining.value = (5 * peakMultiplier).toInt() + Random.nextInt(1, 4)
        queueWaitToGo.value = (8 * peakMultiplier).toInt() + Random.nextInt(2, 5)
        queueWaitDelivery.value = (18 * peakMultiplier).toInt() + Random.nextInt(2, 8)

        _buffetStations.value = GoldenCorralSeeds.initialBuffetStations()
    }

    // --- CATERING FLOW STATE ---
    private val _cateringHistory = MutableStateFlow<List<CateringQuoteRequest>>(emptyList())
    val cateringHistory: StateFlow<List<CateringQuoteRequest>> = _cateringHistory.asStateFlow()

    fun submitCateringRequest(eventType: String, guestCount: Int, date: String, name: String, phone: String, email: String, requestDelivery: Boolean) {
        val estimatedTotal = guestCount * 12.99
        val request = CateringQuoteRequest(
            eventType = eventType,
            guestCount = guestCount,
            date = date,
            contactName = name,
            phone = phone,
            email = email,
            requestedDelivery = requestDelivery,
            estimatedPrice = estimatedTotal
        )
        _cateringHistory.update { listOf(request) + it }
    }

    // --- PARTY ROOM STATE ---
    private val _partyHistory = MutableStateFlow<List<PartyRoomRequest>>(emptyList())
    val partyHistory: StateFlow<List<PartyRoomRequest>> = _partyHistory.asStateFlow()

    fun submitPartyRoomRequest(restaurantId: String, eventType: String, guestCount: Int, date: String, time: String, contactName: String) {
        val request = PartyRoomRequest(
            restaurantId = restaurantId,
            eventType = eventType,
            guestCount = guestCount,
            date = date,
            time = time,
            contactName = contactName
        )
        _partyHistory.update { listOf(request) + it }
    }

    // --- GIFT CARD STATE ---
    private val _giftCards = MutableStateFlow<List<GiftCard>>(
        listOf(
            GiftCard("GC-1024-5582", 25.0, "1234", "tom@ahyx.org", "Grandma", "Happy Birthday Tom!")
        )
    )
    val giftCards: StateFlow<List<GiftCard>> = _giftCards.asStateFlow()

    fun purchaseGiftCard(amount: Double, recipient: String, sender: String, message: String) {
        val newCard = GiftCard(
            cardId = "GC-${Random.nextInt(1000, 9999)}-${Random.nextInt(1000, 9999)}",
            balance = amount,
            pin = Random.nextInt(1000, 9999).toString(),
            recipientEmail = recipient,
            senderName = sender,
            message = message
        )
        _giftCards.update { it + newCard }
    }

    // --- UTILITIES ---
    fun formatPrice(price: Double): String {
        return "$" + DecimalFormat("0.00").format(price)
    }
}
