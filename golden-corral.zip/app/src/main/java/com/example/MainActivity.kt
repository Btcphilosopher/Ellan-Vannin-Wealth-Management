package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.GoldenCorralViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                GoldenCorralAppMain()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoldenCorralAppMain() {
    val viewModel: GoldenCorralViewModel = viewModel()
    val currentTab by viewModel.currentTab.collectAsState()
    val managerMode by viewModel.managerMode.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Respect navigation safe drawing padding automatically with standard NavigationBar
            NavigationBar(
                modifier = Modifier.testTag("main_bottom_nav"),
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                NavigationBarItem(
                    selected = currentTab == "HOME" && !managerMode,
                    onClick = {
                        if (managerMode) viewModel.toggleManagerMode()
                        viewModel.setTab("HOME")
                    },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_home")
                )
                NavigationBarItem(
                    selected = currentTab == "MENU" && !managerMode,
                    onClick = {
                        if (managerMode) viewModel.toggleManagerMode()
                        viewModel.setTab("MENU")
                    },
                    icon = { Icon(Icons.Default.RestaurantMenu, contentDescription = "Menu") },
                    label = { Text("Menu", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_menu")
                )
                NavigationBarItem(
                    selected = currentTab == "ORDER" && !managerMode,
                    onClick = {
                        if (managerMode) viewModel.toggleManagerMode()
                        viewModel.setTab("ORDER")
                    },
                    icon = { Icon(Icons.Default.ShoppingBag, contentDescription = "Order") },
                    label = { Text("Order", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_order")
                )
                NavigationBarItem(
                    selected = currentTab == "REWARDS" && !managerMode,
                    onClick = {
                        if (managerMode) viewModel.toggleManagerMode()
                        viewModel.setTab("REWARDS")
                    },
                    icon = { Icon(Icons.Default.Star, contentDescription = "Rewards") },
                    label = { Text("Rewards", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_rewards")
                )
                NavigationBarItem(
                    selected = currentTab == "ACCOUNT" && !managerMode,
                    onClick = {
                        if (managerMode) viewModel.toggleManagerMode()
                        viewModel.setTab("ACCOUNT")
                    },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Account") },
                    label = { Text("Account", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.testTag("nav_account")
                )
            }
        },
        floatingActionButton = {
            // Floating toggle to hop directly into the background Operations Digital Twin simulator
            ExtendedFloatingActionButton(
                onClick = { viewModel.toggleManagerMode() },
                modifier = Modifier.testTag("manager_mode_toggle_fab"),
                containerColor = if (managerMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            ) {
                Icon(
                    imageVector = if (managerMode) Icons.Default.Restaurant else Icons.Default.SoupKitchen,
                    contentDescription = "Toggle Ops Twin",
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (managerMode) "CUSTOMER VIEW" else "OPERATIONS TWIN",
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (managerMode) {
                TwinScreen(viewModel = viewModel)
            } else {
                when (currentTab) {
                    "HOME" -> HomeScreen(
                        viewModel = viewModel,
                        onNavigateToMenu = { viewModel.setTab("MENU") },
                        onNavigateToOrder = { viewModel.setTab("ORDER") },
                        onNavigateToRewards = { viewModel.setTab("REWARDS") }
                    )
                    "MENU" -> MenuScreen(
                        viewModel = viewModel,
                        onNavigateToOrder = { viewModel.setTab("ORDER") }
                    )
                    "ORDER" -> OrderScreen(viewModel = viewModel)
                    "REWARDS" -> RewardsScreen(viewModel = viewModel)
                    "ACCOUNT" -> AccountScreen(viewModel = viewModel)
                }
            }
        }
    }
}
