package com.example.data

import java.util.UUID

// --- CORE MODELS ---

data class MenuItem(
    val id: String,
    val name: String,
    val description: String,
    val calories: Int,
    val basePrice: Double,
    val category: String,
    val allergens: List<String> = emptyList(),
    val isGlutenFree: Boolean = false,
    val isVegetarian: Boolean = false,
    val isVegan: Boolean = false
)

data class Restaurant(
    val id: String,
    val name: String,
    val distance: Double,
    val address: String,
    val phone: String,
    val isOpen: Boolean,
    val closingTime: String,
    val rating: Double,
    val supportsDineIn: Boolean = true,
    val supportsToGo: Boolean = true,
    val supportsDelivery: Boolean = true,
    val hasPartyRoom: Boolean = true
)

data class RewardsTransaction(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val description: String,
    val pointsChange: Int
)

data class OrderItem(
    val menuItem: MenuItem,
    val quantity: Int
)

enum class OrderStatus {
    PENDING, RECEIVED, PREPARING, PACKING, READY, ON_THE_WAY, DELIVERED, COMPLETED, CANCELLED
}

enum class OrderType {
    DINE_IN, TO_GO, DELIVERY
}

data class Order(
    val id: String,
    val restaurantId: String,
    val restaurantName: String,
    val items: List<OrderItem>,
    val subtotal: Double,
    val discount: Double,
    val total: Double,
    val status: OrderStatus,
    val type: OrderType,
    val deliveryAddress: String? = null,
    val estimatedReadyTime: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class BuffetStation(
    val id: String,
    val name: String,
    val items: List<String>,
    var portionsAvailable: Int,
    var maxPortions: Int,
    var currentTempF: Double,
    var demandLevel: String, // HIGH, MEDIUM, LOW
    var lastRefill: String,
    var isRefillRequired: Boolean = false
)

data class FamilyMember(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val role: String, // Dad, Mum, Kid
    val preferences: List<String> = emptyList() // "Vegetarian", "No Seafood", etc.
)

data class GiftCard(
    val cardId: String,
    val balance: Double,
    val pin: String,
    val recipientEmail: String,
    val senderName: String,
    val message: String
)

data class CateringQuoteRequest(
    val id: String = UUID.randomUUID().toString(),
    val eventType: String,
    val guestCount: Int,
    val date: String,
    val contactName: String,
    val phone: String,
    val email: String,
    val requestedDelivery: Boolean,
    var estimatedPrice: Double,
    var status: String = "Pending Quote"
)

data class PartyRoomRequest(
    val id: String = UUID.randomUUID().toString(),
    val restaurantId: String,
    val eventType: String,
    val guestCount: Int,
    val date: String,
    val time: String,
    val contactName: String,
    val status: String = "Requested"
)

// --- SYNTHETIC INITIAL SEEDS ---

object GoldenCorralSeeds {

    val demoRestaurants = listOf(
        Restaurant("1", "Charlotte - Woodlawn", 2.4, "7701 South Blvd, Charlotte, NC 28273", "(704) 554-1234", true, "9:00 PM", 4.6),
        Restaurant("2", "Atlanta - Dunwoody", 3.1, "2140 Peachtree Rd NW, Atlanta, GA 30309", "(404) 351-5678", true, "9:30 PM", 4.7),
        Restaurant("3", "Dallas - North", 4.2, "14555 Dallas Pkwy, Dallas, TX 75254", "(972) 490-9876", true, "10:00 PM", 4.5),
        Restaurant("4", "Orlando - International Dr", 1.8, "8707 International Dr, Orlando, FL 32819", "(407) 345-0102", true, "10:30 PM", 4.8),
        Restaurant("5", "Columbus - West", 5.0, "3710 W Broad St, Columbus, OH 43228", "(614) 272-4000", true, "9:00 PM", 4.4),
        Restaurant("6", "Phoenix - Metro", 2.9, "1825 W Bell Rd, Phoenix, AZ 85023", "(602) 866-2211", true, "9:00 PM", 4.6),
        Restaurant("7", "Detroit - Roseville", 6.2, "29515 Gratiot Ave, Roseville, MI 48066", "(586) 779-2424", true, "9:30 PM", 4.3),
        Restaurant("8", "Pittsburgh - Robinson", 7.5, "1800 Robinson Centre Dr, Pittsburgh, PA 15205", "(412) 788-1440", true, "9:00 PM", 4.5),
        Restaurant("9", "Oklahoma City - South", 3.8, "1501 SW 74th St, Oklahoma City, OK 73159", "(405) 682-3311", true, "9:00 PM", 4.6),
        Restaurant("10", "Tucson - East", 4.7, "6885 E Speedway Blvd, Tucson, AZ 85710", "(520) 722-6400", true, "10:00 PM", 4.7)
    )

    val menuCategories = listOf(
        "BREAKFAST", "STEAKS", "CHICKEN", "SEAFOOD", "POT ROAST", "HOT SIDES", "SOUP & SALAD", "BREAD", "DESSERT", "DRINKS", "KIDS"
    )

    val menuItems = listOf(
        // BREAKFAST
        MenuItem("m1", "Scrambled Eggs", "Fluffy scrambled farm-fresh eggs", 140, 4.99, "BREAKFAST", isGlutenFree = true, isVegetarian = true),
        MenuItem("m2", "Crispy Bacon Strips", "Premium smoked thick-cut pork bacon", 180, 5.49, "BREAKFAST", isGlutenFree = true),
        MenuItem("m3", "Sausage Links", "Savory seasoned breakfast pork sausage links", 210, 4.99, "BREAKFAST", isGlutenFree = true),
        MenuItem("m4", "Buttermilk Pancakes", "Golden pancakes served with warm maple syrup", 280, 4.49, "BREAKFAST", isVegetarian = true),
        MenuItem("m5", "French Toast Strips", "Cinnamon dusted french toast with powdered sugar", 320, 4.99, "BREAKFAST", isVegetarian = true),

        // STEAKS
        MenuItem("m6", "Signature Sirloin Steak", "Premium USDA sirloin steak, grilled to order", 290, 15.99, "STEAKS", isGlutenFree = true),
        MenuItem("m7", "Garlic Butter Sirloin", "Signature sirloin topped with real garlic butter glaze", 350, 16.99, "STEAKS", isGlutenFree = true),

        // CHICKEN
        MenuItem("m8", "Signature Fried Chicken", "Crispy, hand-breaded golden fried chicken", 380, 11.99, "CHICKEN"),
        MenuItem("m9", "Bourbon Street Chicken", "Tender glazed chicken thighs cooked in sweet bourbon sauce", 310, 12.49, "CHICKEN", isGlutenFree = true),
        MenuItem("m10", "Grilled Chicken Breast", "Juicy herb-marinated chicken breast", 190, 10.99, "CHICKEN", isGlutenFree = true),

        // SEAFOOD
        MenuItem("m11", "Fried Butterfly Shrimp", "Crispy breaded golden butterfly shrimp with cocktail sauce", 240, 13.99, "SEAFOOD", allergens = listOf("Shellfish")),
        MenuItem("m12", "Baked Fish fillet", "Tender white fish baked with lemon pepper herb seasoning", 160, 13.49, "SEAFOOD", isGlutenFree = true, allergens = listOf("Fish")),

        // POT ROAST
        MenuItem("m13", "Homestyle Pot Roast", "Slow-cooked tender beef pot roast with carrots and potatoes", 260, 13.99, "POT ROAST", isGlutenFree = true),

        // HOT SIDES
        MenuItem("m14", "Homestyle Macaroni & Cheese", "Baked elbow macaroni in rich creamy real cheese sauce", 310, 4.49, "HOT SIDES", isVegetarian = true, allergens = listOf("Dairy")),
        MenuItem("m15", "Mashed Potatoes", "Real whipped Idaho potatoes with butter", 150, 3.99, "HOT SIDES", isGlutenFree = true, isVegetarian = true, allergens = listOf("Dairy")),
        MenuItem("m16", "Brown Gravy", "Rich, savory homestyle beef gravy", 45, 1.49, "HOT SIDES"),
        MenuItem("m17", "Southern Green Beans", "Green beans simmered with bacon pieces and onions", 70, 3.49, "HOT SIDES", isGlutenFree = true),
        MenuItem("m18", "Sweet Kernel Corn", "Steamed yellow sweet corn tossed in butter", 110, 3.49, "HOT SIDES", isGlutenFree = true, isVegetarian = true),

        // SOUP & SALAD
        MenuItem("m19", "Timberline Chili", "Hearty slow-simmered beef and bean chili", 220, 5.99, "SOUP & SALAD"),
        MenuItem("m20", "Garden Fresh Salad Mix", "Crisp lettuce, cucumber, tomato, and shredded carrots", 35, 4.99, "SOUP & SALAD", isGlutenFree = true, isVegetarian = true, isVegan = true),
        MenuItem("m21", "Creamy Ranch Dressing", "Classic thick house ranch dressing", 140, 1.29, "SOUP & SALAD", isGlutenFree = true, isVegetarian = true, allergens = listOf("Dairy")),

        // BREAD
        MenuItem("m22", "Famous Yeast Rolls", "Our legendary fresh-baked soft yeast rolls brushed with honey butter", 120, 1.99, "BREAD", isVegetarian = true, allergens = listOf("Dairy", "Wheat")),

        // DESSERT
        MenuItem("m23", "Warm Carrot Cake", "Spiced carrot cake with sweet real cream cheese frosting", 390, 5.49, "DESSERT", isVegetarian = true, allergens = listOf("Dairy", "Wheat")),
        MenuItem("m24", "Fudge Brownies", "Dense chewy chocolate brownies with rich fudge icing", 320, 4.49, "DESSERT", isVegetarian = true, allergens = listOf("Dairy", "Wheat")),
        MenuItem("m25", "Chocolate Fountain Treat", "Fresh strawberries dipped in the active Chocolate Fountain", 180, 5.99, "DESSERT", isGlutenFree = true, isVegetarian = true),

        // DRINKS
        MenuItem("m26", "Sweet Peach Tea", "Southern brewed sweet tea with natural peach flavor", 120, 2.99, "DRINKS", isGlutenFree = true, isVegetarian = true, isVegan = true),
        MenuItem("m27", "Unlimited Soft Drink Soda", "Coke, Diet Coke, Sprite, or Fanta fountain beverage", 150, 3.29, "DRINKS", isGlutenFree = true, isVegetarian = true, isVegan = true),

        // KIDS
        MenuItem("m28", "Kids Chicken Tenders", "Two crispy golden tenders with fries", 340, 6.99, "KIDS"),
        MenuItem("m29", "Kids Mac & Cheese Bowl", "Kids portion of our classic creamy mac & cheese", 180, 5.99, "KIDS", isVegetarian = true)
    )

    fun initialBuffetStations() = listOf(
        BuffetStation("s1", "GRILL & CARVING", listOf("Signature Sirloin Steak", "Garlic Butter Sirloin", "Baked Fish fillet"), 40, 50, 145.0, "HIGH", "6:41 PM"),
        BuffetStation("s2", "FRIED CHICKEN & POT ROAST", listOf("Signature Fried Chicken", "Homestyle Pot Roast", "Bourbon Street Chicken"), 35, 60, 150.0, "HIGH", "6:45 PM"),
        BuffetStation("s3", "HOT SIDES", listOf("Homestyle Macaroni & Cheese", "Mashed Potatoes", "Southern Green Beans", "Sweet Kernel Corn"), 45, 80, 142.0, "MEDIUM", "6:38 PM"),
        BuffetStation("s4", "SOUP & SALAD BAR", listOf("Timberline Chili", "Garden Fresh Salad Mix", "Creamy Ranch Dressing"), 25, 40, 38.0, "LOW", "6:30 PM"),
        BuffetStation("s5", "YEAST ROLL STATION", listOf("Famous Yeast Rolls"), 50, 100, 135.0, "HIGH", "6:52 PM"),
        BuffetStation("s6", "DESSERT & CHOCOLATE FOUNTAIN", listOf("Warm Carrot Cake", "Fudge Brownies", "Chocolate Fountain Treat"), 30, 50, 110.0, "HIGH", "6:48 PM"),
        BuffetStation("s7", "BEVERAGE STATION", listOf("Sweet Peach Tea", "Unlimited Soft Drink Soda"), 80, 100, 34.0, "MEDIUM", "6:50 PM")
    )
}
