package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = Golden,
    secondary = CorralRed,
    tertiary = Amber,
    background = Charcoal,
    surface = DeepBrown,
    onPrimary = DeepBrown,
    onSecondary = WarmWhite,
    onTertiary = DeepBrown,
    onBackground = WarmWhite,
    onSurface = Cream,
    primaryContainer = RoastedBrown,
    onPrimaryContainer = Golden,
    secondaryContainer = DarkRed,
    onSecondaryContainer = WarmWhite
)

private val LightColorScheme = lightColorScheme(
    primary = CorralRed,
    secondary = DeepGold,
    tertiary = RoastedBrown,
    background = WarmWhite,
    surface = Cream,
    onPrimary = WarmWhite,
    onSecondary = DeepBrown,
    onTertiary = WarmWhite,
    onBackground = Charcoal,
    onSurface = DeepBrown,
    primaryContainer = Golden,
    onPrimaryContainer = RoastedBrown,
    secondaryContainer = Paper,
    onSecondaryContainer = CorralRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // We disable dynamicColor by default to enforce Golden Corral's customized look
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
