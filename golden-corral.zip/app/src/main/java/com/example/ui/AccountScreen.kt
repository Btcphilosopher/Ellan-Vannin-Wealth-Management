package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CateringQuoteRequest
import com.example.data.FamilyMember
import com.example.data.GiftCard
import com.example.viewmodel.GoldenCorralViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(viewModel: GoldenCorralViewModel) {
    var activeSubSection by remember { mutableStateOf("MAIN") } // MAIN, PLANNER, CATERING, PARTY, GIFTCARD, FAMILY
    val selectedRest by viewModel.selectedRestaurant.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Dynamic Header back button routing
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(vertical = 12.dp)
        ) {
            if (activeSubSection != "MAIN") {
                IconButton(
                    onClick = { activeSubSection = "MAIN" },
                    modifier = Modifier.align(Alignment.CenterStart)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
            }
            Text(
                text = when (activeSubSection) {
                    "MAIN" -> "TOM'S CORRAL ACCOUNT"
                    "PLANNER" -> "GROUP VISIT PLANNER"
                    "CATERING" -> "CATERING ESTIMATOR"
                    "PARTY" -> "PRIVATE PARTY ROOMS"
                    "GIFTCARD" -> "GIFT CARDS"
                    else -> "FAMILY PROFILES"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        when (activeSubSection) {
            "MAIN" -> AccountMenu(onSelect = { activeSubSection = it })
            "PLANNER" -> GroupPlannerView(viewModel, selectedRest.name)
            "CATERING" -> CateringView(viewModel)
            "PARTY" -> PartyRoomView(viewModel)
            "GIFTCARD" -> GiftCardView(viewModel)
            "FAMILY" -> FamilyProfileView(viewModel)
        }
    }
}

@Composable
fun AccountMenu(onSelect: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Tom's Profile banner header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color(0xFFD6A62C), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("T", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Tom Harrison", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("tom@ahyx.org", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Text("Member Since: 2026", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB78319), fontWeight = FontWeight.Bold)
                }
            }
        }

        Text("SERVICES & UTILITIES", style = MaterialTheme.typography.labelLarge, color = Color.Gray, fontWeight = FontWeight.Bold)

        // Utility item links
        AccountOptionRow(icon = Icons.Default.Groups, title = "Group Visit Planner", desc = "Plan and estimate a visit with friends & family.", onClick = { onSelect("PLANNER") })
        AccountOptionRow(icon = Icons.Default.SoupKitchen, title = "Catering Calculator", desc = "Homestyle delivery quotes for large groups & offices.", onClick = { onSelect("CATERING") })
        AccountOptionRow(icon = Icons.Default.Celebration, title = "Private Party Rooms", desc = "Request free birthday/office private room spaces.", onClick = { onSelect("PARTY") })
        AccountOptionRow(icon = Icons.Default.CardGiftcard, title = "Gift Cards Wallet", desc = "Buy, flip, and check simulated card balances.", onClick = { onSelect("GIFTCARD") })
        AccountOptionRow(icon = Icons.Default.FamilyRestroom, title = "Family Profiles & Dietary Filters", desc = "Manage Mum, Dad, & Kid preference filters.", onClick = { onSelect("FAMILY") })

        Spacer(modifier = Modifier.height(24.dp))
        Text("APP PREFERENCES", style = MaterialTheme.typography.labelLarge, color = Color.Gray, fontWeight = FontWeight.Bold)

        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Push Notifications", fontWeight = FontWeight.Bold)
                    Switch(checked = true, onCheckedChange = {})
                }
                Divider()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Low Contrast Accessibility Mode", fontWeight = FontWeight.Bold)
                    Switch(checked = false, onCheckedChange = {})
                }
            }
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

@Composable
fun AccountOptionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, desc: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color.LightGray)
        }
    }
}

// --- SUB-VIEWS ---

@Composable
fun GroupPlannerView(viewModel: GoldenCorralViewModel, locationName: String) {
    var partySize by remember { mutableStateOf(8) }
    var plannedDate by remember { mutableStateOf("Saturday, Nov 15") }
    var plannedTime by remember { mutableStateOf("6:30 PM") }
    var isSubmitted by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("PLAN A GROUP buffet VISIT", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Coordinates group visits at our buffet tables easily. Enter details below:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

        OutlinedTextField(value = "$partySize People", onValueChange = {}, label = { Text("Guest count") }, readOnly = true, modifier = Modifier.fillMaxWidth())

        Slider(
            value = partySize.toFloat(),
            onValueChange = { partySize = it.toInt() },
            valueRange = 1f..30f,
            steps = 29
        )

        OutlinedTextField(
            value = plannedDate,
            onValueChange = { plannedDate = it },
            label = { Text("Planned Date") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = plannedTime,
            onValueChange = { plannedTime = it },
            label = { Text("Planned Time") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = { isSubmitted = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("GENERATE VISIT PLANNER SUMMARY")
        }

        if (isSubmitted) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5EBDD))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("GOLDEN CORRAL GROUP VISIT SUMMARY", fontWeight = FontWeight.ExtraBold, color = Color(0xFF4A3023))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Target Restaurant: $locationName", fontWeight = FontWeight.Bold)
                    Text("• Party Size: $partySize Guests")
                    Text("• Schedule: $plannedDate at $plannedTime")
                    Text("• Est. Group Buffet Cost: ${viewModel.formatPrice(partySize * 15.99)}")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "We've alerted the Charlotte host desk! While we don't hold physical tables, our digital operation twin ensures plenty of fresh fried chicken & steak are ready for your arrival.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.DarkGray
                    )
                }
            }
        }
    }
}

@Composable
fun CateringView(viewModel: GoldenCorralViewModel) {
    val cateringList by viewModel.cateringHistory.collectAsState()

    var eventType by remember { mutableStateOf("Office Meeting") }
    var guestCount by remember { mutableStateOf(25) }
    var contactName by remember { mutableStateOf("Tom Harrison") }
    var phone by remember { mutableStateOf("(704) 554-1234") }
    var email by remember { mutableStateOf("tom@ahyx.org") }
    var requestDelivery by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("CATERING CALCULATOR & QUOTE REQUEST", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Order hot buffet trays, yeast rolls, and sliders delivered to your business or event space.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

        OutlinedTextField(value = eventType, onValueChange = { eventType = it }, label = { Text("Event Category (e.g. Birthday, Office)") }, modifier = Modifier.fillMaxWidth())

        Text("Estimated Guest Size: $guestCount", fontWeight = FontWeight.Bold)
        Slider(value = guestCount.toFloat(), onValueChange = { guestCount = it.toInt() }, valueRange = 10f..150f)

        OutlinedTextField(value = contactName, onValueChange = { contactName = it }, label = { Text("Contact Name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone Number") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email Address") }, modifier = Modifier.fillMaxWidth())

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = requestDelivery, onCheckedChange = { requestDelivery = it ?: true })
            Spacer(modifier = Modifier.width(6.dp))
            Text("Request Delivery Setup (+ $25.00)")
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFEFE7DA))
        ) {
            Row(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Catering Base Estimate", fontWeight = FontWeight.Bold)
                Text(viewModel.formatPrice(guestCount * 12.99), fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
            }
        }

        Button(
            onClick = {
                viewModel.submitCateringRequest(eventType, guestCount, "2026-11-20", contactName, phone, email, requestDelivery)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("SUBMIT OFFICIAL CATERING REQUEST")
        }

        if (cateringList.isNotEmpty()) {
            Text("Catering Requests Ledger", fontWeight = FontWeight.Bold, color = Color.Gray)
            cateringList.forEach { req ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(req.eventType, fontWeight = FontWeight.Bold)
                            Text(req.status, color = Color(0xFFB78319), fontWeight = FontWeight.ExtraBold)
                        }
                        Text("Guests: ${req.guestCount} • Est. Price: ${viewModel.formatPrice(req.estimatedPrice)}")
                    }
                }
            }
        }
    }
}

@Composable
fun PartyRoomView(viewModel: GoldenCorralViewModel) {
    val partyHistory by viewModel.partyHistory.collectAsState()

    var eventType by remember { mutableStateOf("Birthday Party") }
    var guests by remember { mutableStateOf(15) }
    var date by remember { mutableStateOf("2026-12-10") }
    var time by remember { mutableStateOf("5:30 PM") }
    var name by remember { mutableStateOf("Tom Harrison") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("RESERVE A PRIVATE PARTY ROOM", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Celebrate birthdays, graduations, or sports team banquets in our designated restaurant meeting/party rooms.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

        OutlinedTextField(value = eventType, onValueChange = { eventType = it }, label = { Text("Event Theme") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = "$guests Guests", onValueChange = {}, label = { Text("Event Size") }, readOnly = true, modifier = Modifier.fillMaxWidth())
        Slider(value = guests.toFloat(), onValueChange = { guests = it.toInt() }, valueRange = 10f..50f)

        OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Event Date") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Event Time") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Contact Host Name") }, modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                viewModel.submitPartyRoomRequest("1", eventType, guests, date, time, name)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("SUBMIT PRIVATE PARTY ROOM INQUIRY")
        }

        if (partyHistory.isNotEmpty()) {
            Text("Your Party Bookings", fontWeight = FontWeight.Bold, color = Color.Gray)
            partyHistory.forEach { req ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(req.eventType, fontWeight = FontWeight.Bold)
                            Text(req.status, color = Color(0xFF52724F), fontWeight = FontWeight.ExtraBold)
                        }
                        Text("Size: ${req.guestCount} guests • Date: ${req.date} at ${req.time}")
                    }
                }
            }
        }
    }
}

@Composable
fun GiftCardView(viewModel: GoldenCorralViewModel) {
    val cards by viewModel.giftCards.collectAsState()

    var amountSelected by remember { mutableStateOf(25.0) }
    var recipient by remember { mutableStateOf("friend@ahyx.org") }
    var sender by remember { mutableStateOf("Tom Harrison") }
    var msg by remember { mutableStateOf("Merry Christmas!") }
    var showGiftCardPurchasedAlert by remember { mutableStateOf(false) }

    // Card flip simulator
    var isFlipped by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("BUY DIGITAL GIFT CARDS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        // Visual gift card (flippable on tap!)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clickable { isFlipped = !isFlipped },
            colors = CardDefaults.cardColors(
                containerColor = if (isFlipped) Color(0xFF4A3023) else Color(0xFFD6A62C)
            )
        ) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (!isFlipped) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "GOLDEN CORRAL APP",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                        Text(
                            "GIFT CARD",
                            style = MaterialTheme.typography.headlineLarge,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            "Tap to flip details",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                } else {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("CARD CODE: GC-1024-5582", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("PIN: 1234", color = Color.White.copy(alpha = 0.8f))
                        Text("Active Balance: $25.00", style = MaterialTheme.typography.titleLarge, color = Color(0xFFD6A62C), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf(10.0, 25.0, 50.0).forEach { valAmt ->
                val isSel = amountSelected == valAmt
                Button(
                    onClick = { amountSelected = valAmt },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.2f),
                        contentColor = if (isSel) Color.White else Color.Unspecified
                    ),
                    modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                ) {
                    Text("$${valAmt.toInt()}")
                }
            }
        }

        OutlinedTextField(value = recipient, onValueChange = { recipient = it }, label = { Text("Recipient Email Address") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = sender, onValueChange = { sender = it }, label = { Text("Sender Name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = msg, onValueChange = { msg = it }, label = { Text("Custom Gift Card Message") }, modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                viewModel.purchaseGiftCard(amountSelected, recipient, sender, msg)
                showGiftCardPurchasedAlert = true
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("PURCHASE SIMULATED GIFT CARD: $${amountSelected.toInt()}")
        }

        Text("ACTIVE GIFT CARDS WALLET", fontWeight = FontWeight.Bold, color = Color.Gray)
        cards.forEach { gc ->
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(gc.cardId, fontWeight = FontWeight.Bold)
                        Text(viewModel.formatPrice(gc.balance), color = Color(0xFF52724F), fontWeight = FontWeight.ExtraBold)
                    }
                    Text("Recipient: ${gc.recipientEmail} • PIN: ${gc.pin}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
        }

        if (showGiftCardPurchasedAlert) {
            AlertDialog(
                onDismissRequest = { showGiftCardPurchasedAlert = false },
                confirmButton = {
                    Button(onClick = { showGiftCardPurchasedAlert = false }) { Text("Awesome") }
                },
                title = { Text("Simulated Purchase Succeeded") },
                text = { Text("Your digital gift card of $${amountSelected.toInt()} has been successfully generated and loaded into your active gift card wallet!") }
            )
        }
    }
}

@Composable
fun FamilyProfileView(viewModel: GoldenCorralViewModel) {
    val familyMembers by viewModel.familyMembers.collectAsState()

    var name by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("Kid") }
    var isVegPref by remember { mutableStateOf(false) }
    var isLowCarbPref by remember { mutableStateOf(false) }
    var isNoSeafoodPref by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("FAMILY MEMBER DIETARY PREFERENCES", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Define preference filters for your family members. These are visual filters, not medical advice.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

        familyMembers.forEach { fm ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fm.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.background(Color.LightGray.copy(alpha = 0.4f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                Text(fm.role, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            text = if (fm.preferences.isEmpty()) "No explicit preference filters." else "Filters: " + fm.preferences.joinToString(", "),
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                    Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Divider()
        Text("ADD NEW FAMILY MEMBER", fontWeight = FontWeight.Bold, color = Color.Gray)

        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Family Member Name") }, modifier = Modifier.fillMaxWidth())

        Text("Select Family Role:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Dad", "Mum", "Kid").forEach { r ->
                val isSel = role == r
                Button(
                    onClick = { role = r },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.2f),
                        contentColor = if (isSel) Color.White else Color.Unspecified
                    )
                ) {
                    Text(r)
                }
            }
        }

        Text("Set Preference Filters:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = isVegPref, onCheckedChange = { isVegPref = it ?: false })
                Text("Vegetarian")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = isLowCarbPref, onCheckedChange = { isLowCarbPref = it ?: false })
                Text("Low-Carb Diet")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = isNoSeafoodPref, onCheckedChange = { isNoSeafoodPref = it ?: false })
                Text("No Seafood Allergy")
            }
        }

        Button(
            onClick = {
                val selectedPrefs = mutableListOf<String>()
                if (isVegPref) selectedPrefs.add("Vegetarian")
                if (isLowCarbPref) selectedPrefs.add("Low-Carb")
                if (isNoSeafoodPref) selectedPrefs.add("No Seafood")

                viewModel.addFamilyMember(name, role, selectedPrefs)
                name = ""
                isVegPref = false
                isLowCarbPref = false
                isNoSeafoodPref = false
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("SAVE FAMILY PROFILE")
        }
    }
}
