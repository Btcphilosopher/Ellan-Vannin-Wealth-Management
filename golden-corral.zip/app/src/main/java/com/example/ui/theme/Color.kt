package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Golden Corral Color System
val Golden = Color(0xFFD6A62C)
val DeepGold = Color(0xFFB78319)
val CorralRed = Color(0xFFA83A2B)
val DarkRed = Color(0xFF7D2922)
val RoastedBrown = Color(0xFF4A3023)
val DeepBrown = Color(0xFF2A211C)
val Cream = Color(0xFFF5EBDD)
val WarmWhite = Color(0xFFFBF8F2)
val Paper = Color(0xFFEFE7DA)
val Charcoal = Color(0xFF252321)
val Steel = Color(0xFF72706B)
val Green = Color(0xFF52724F)
val Amber = Color(0xFFC78B2B)
