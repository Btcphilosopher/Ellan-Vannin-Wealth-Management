package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.GoldenCorralViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RewardsScreen(viewModel: GoldenCorralViewModel) {
    val points by viewModel.userPoints.collectAsState()
    val rewardBal by viewModel.rewardBalance.collectAsState()
    val ledger by viewModel.rewardsLedger.collectAsState()
    val scanningState by viewModel.scanningState.collectAsState()

    var manualReceiptCode by remember { mutableStateOf("") }
    var alertMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(vertical = 12.dp)
        ) {
            Text(
                text = "GOLDEN CORRAL REWARDS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        if (scanningState == "SCANNING" || scanningState == "SUCCESS") {
            // Receipt Scanner Simulator overlay
            SimulatedScannerView(scanningState = scanningState)
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Large circular rewards progress meter
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF4A3023)) // Roasted Brown
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "TOM'S REWARDS POINTS Balance",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFFD6A62C),
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(160.dp)
                        ) {
                            CircularProgressIndicator(
                                progress = { points / 100f },
                                modifier = Modifier.size(140.dp),
                                color = Color(0xFFD6A62C),
                                strokeWidth = 14.dp,
                                trackColor = Color.White.copy(alpha = 0.15f)
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$points",
                                    style = MaterialTheme.typography.headlineLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 42.sp
                                )
                                Text(
                                    text = "POINTS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFF5EBDD),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "${100 - points} Points to your next $10 Off Reward!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Rewards Balance
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("REDEEMABLE WALLET BALANCE", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text(viewModel.formatPrice(rewardBal), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Color(0xFF52724F))
                        }
                        Button(
                            onClick = {
                                if (rewardBal > 0.0) {
                                    alertMessage = "Applied ${viewModel.formatPrice(rewardBal)} off! Select your items in the menu, then checkout."
                                    viewModel.applyRewardAmount(rewardBal)
                                } else {
                                    alertMessage = "You need at least 100 points ($10 reward) to redeem."
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("REDEEM NOW")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Scan receipt scanner tool options
                Text("EARN POINTS", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold, color = Color.Gray)
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Dine-In Receipt Scanner", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("Simulate scanning a dine-in printed receipt to earn points instantly.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { viewModel.scanReceiptSimulated() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("receipt_scan_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("LAUNCH SIMULATED RECEIPT SCANNER")
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = Color.LightGray.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Text("Enter 13-Digit Receipt Code", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = manualReceiptCode,
                                onValueChange = { manualReceiptCode = it },
                                label = { Text("Code (e.g. 927-2026-10)") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (manualReceiptCode.isNotBlank()) {
                                        viewModel.submitReceiptCode(manualReceiptCode)
                                        manualReceiptCode = ""
                                        alertMessage = "Success! +24 points added to your ledger."
                                    }
                                },
                                modifier = Modifier.height(56.dp)
                            ) {
                                Text("SUBMIT")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Ledger history records
                Text("REWARDS LEDGER & HISTORY", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold, color = Color.Gray)
                Spacer(modifier = Modifier.height(8.dp))

                ledger.forEach { tx ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(tx.description, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Text(tx.date, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        val isPositive = tx.pointsChange >= 0
                        Text(
                            text = if (isPositive) "+${tx.pointsChange} PTS" else "${tx.pointsChange} PTS",
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isPositive) Color(0xFF52724F) else Color(0xFFA83A2B)
                        )
                    }
                    Divider(color = Color.LightGray.copy(alpha = 0.3f))
                }

                Spacer(modifier = Modifier.height(48.dp))
            }
        }

        alertMessage?.let { msg ->
            AlertDialog(
                onDismissRequest = { alertMessage = null },
                confirmButton = {
                    Button(onClick = { alertMessage = null }) { Text("OK") }
                },
                title = { Text("Rewards Notification") },
                text = { Text(msg) }
            )
        }
    }
}

@Composable
fun SimulatedScannerView(scanningState: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.95f))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (scanningState == "SCANNING") {
            CircularProgressIndicator(
                color = Color(0xFFD6A62C),
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                "CAMERA FRAME INITIATED",
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFD6A62C),
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                "Align the barcode / QR code on your printed receipt.",
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
            )

            // Scanning box guides
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .border(2.dp, Color(0xFFD6A62C), RoundedCornerShape(12.dp))
                    .padding(24.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                        .background(Color.Red)
                        .align(Alignment.Center)
                )
            }
        } else {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF52724F),
                modifier = Modifier.size(96.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "RECEIPT PARSED SUCCESSFULLY",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                "Exactly 24 Reward Points have been loaded to your Golden Corral Wallet!",
                color = Color.LightGray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
            )
        }
    }
}
