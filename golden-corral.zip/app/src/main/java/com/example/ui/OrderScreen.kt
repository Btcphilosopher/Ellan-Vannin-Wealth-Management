package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.OrderItem
import com.example.data.OrderStatus
import com.example.data.OrderType
import com.example.viewmodel.GoldenCorralViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderScreen(viewModel: GoldenCorralViewModel) {
    val cart by viewModel.cart.collectAsState()
    val orderType by viewModel.orderType.collectAsState()
    val activeOrder by viewModel.activeOrder.collectAsState()
    val rewardBal by viewModel.rewardBalance.collectAsState()
    val rewardApplied by viewModel.rewardApplied.collectAsState()
    val deliveryAddr by viewModel.deliveryAddress.collectAsState()

    var checkoutStep by remember { mutableStateOf(false) } // False = Cart, True = Checkout
    var selectedPaymentMethod by remember { mutableStateOf("Simulated Credit Card") }
    var selectedPartySize by remember { mutableStateOf(1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(vertical = 12.dp)
        ) {
            Text(
                text = "YOUR ORDER",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        if (activeOrder != null) {
            // Live Order Tracker Screen
            OrderTrackerContent(activeOrder!!, viewModel)
        } else if (cart.isEmpty()) {
            EmptyCartView()
        } else if (!checkoutStep) {
            // Cart View
            CartContent(
                cart = cart,
                viewModel = viewModel,
                orderType = orderType,
                rewardBal = rewardBal,
                rewardApplied = rewardApplied,
                deliveryAddr = deliveryAddr,
                selectedPartySize = selectedPartySize,
                onPartySizeChange = { selectedPartySize = it },
                onCheckout = { checkoutStep = true }
            )
        } else {
            // Simulated Checkout View
            CheckoutContent(
                viewModel = viewModel,
                selectedPaymentMethod = selectedPaymentMethod,
                onPaymentMethodChange = { selectedPaymentMethod = it },
                onBackToCart = { checkoutStep = false },
                onSubmitOrder = {
                    viewModel.submitOrder(selectedPartySize)
                    checkoutStep = false
                }
            )
        }
    }
}

@Composable
fun EmptyCartView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.ShoppingBag,
            contentDescription = "Empty",
            tint = Color.LightGray,
            modifier = Modifier.size(96.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "YOUR TRAY IS EMPTY",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Browse the buffet and add your homestyle favourites here!",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
    }
}

@Composable
fun CartContent(
    cart: List<OrderItem>,
    viewModel: GoldenCorralViewModel,
    orderType: OrderType,
    rewardBal: Double,
    rewardApplied: Double,
    deliveryAddr: String,
    selectedPartySize: Int,
    onPartySizeChange: (Int) -> Unit,
    onCheckout: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Toggle Order Mode
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.LightGray.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf(OrderType.DINE_IN, OrderType.TO_GO, OrderType.DELIVERY).forEach { type ->
                val isSelected = orderType == type
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { viewModel.setOrderType(type) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when (type) {
                            OrderType.DINE_IN -> "Dine-In"
                            OrderType.TO_GO -> "To-Go"
                            OrderType.DELIVERY -> "Delivery"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Order Details form input
        when (orderType) {
            OrderType.DINE_IN -> {
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Dine-In Party Size", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            (1..6).forEach { size ->
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(
                                            color = if (selectedPartySize == size) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.2f),
                                            shape = CircleShape
                                        )
                                        .clickable { onPartySizeChange(size) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "$size",
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedPartySize == size) Color.White else Color.Unspecified
                                    )
                                }
                            }
                        }
                    }
                }
            }
            OrderType.DELIVERY -> {
                OutlinedTextField(
                    value = deliveryAddr,
                    onValueChange = { viewModel.setDeliveryAddress(it) },
                    label = { Text("Delivery Address") },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.PinDrop, contentDescription = null) }
                )
            }
            else -> {
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccessTime, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Pick up from Charlotte location ASAP (Estimated 15 mins)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Cart List Box
        Text("YOUR ITEMS", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold, color = Color.Gray)
        Spacer(modifier = Modifier.height(8.dp))

        cart.forEach { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1.5f)) {
                    Text(item.menuItem.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                    Text(viewModel.formatPrice(item.menuItem.basePrice) + " each", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButton(onClick = { viewModel.removeFromCart(item.menuItem) }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease")
                    }
                    Text("${item.quantity}", modifier = Modifier.padding(horizontal = 10.dp), fontWeight = FontWeight.Bold)
                    IconButton(onClick = { viewModel.addToCart(item.menuItem) }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            Divider(color = Color.LightGray.copy(alpha = 0.3f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Rewards Redemption Wallet application
        if (rewardBal > 0.0) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5EBDD)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD6A62C))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("REDEEM WALLET BALANCES", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF4A3023))
                    Text(
                        "You have ${viewModel.formatPrice(rewardBal)} in available rewards. Choose how much to apply:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.0, 5.0, 10.0).forEach { amt ->
                            if (amt <= rewardBal) {
                                val isSelected = rewardApplied == amt
                                Button(
                                    onClick = { viewModel.applyRewardAmount(amt) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary else Color.White,
                                        contentColor = if (isSelected) Color.White else Color(0xFF2A211C)
                                    ),
                                    modifier = Modifier.height(32.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                                ) {
                                    Text(if (amt == 0.0) "None" else "$${amt.toInt()} Off", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Price calculations invoice breakdown
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                .padding(16.dp)
        ) {
            val sub = viewModel.calculateCartSubtotal()
            val tax = sub * 0.08
            val disc = rewardApplied
            val total = viewModel.calculateCartTotal()

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Subtotal", color = Color.Gray)
                Text(viewModel.formatPrice(sub), fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Sales Tax (8%)", color = Color.Gray)
                Text(viewModel.formatPrice(tax), fontWeight = FontWeight.Bold)
            }
            if (disc > 0.0) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Rewards Discount", color = Color(0xFF52724F))
                    Text("-${viewModel.formatPrice(disc)}", color = Color(0xFF52724F), fontWeight = FontWeight.Bold)
                }
            }
            Divider(modifier = Modifier.padding(vertical = 10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("TOTAL", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                Text(viewModel.formatPrice(total), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onCheckout,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("checkout_continue_button"),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Text("CONTINUE TO SECURE CHECKOUT", style = MaterialTheme.typography.labelLarge)
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

@Composable
fun CheckoutContent(
    viewModel: GoldenCorralViewModel,
    selectedPaymentMethod: String,
    onPaymentMethodChange: (String) -> Unit,
    onBackToCart: () -> Unit,
    onSubmitOrder: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackToCart) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text("SECURE PAYMENT", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.width(48.dp)) // balancer
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Simulated Payment Watermark warning
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF7D2922), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("SIMULATED PAYMENT MODE", style = MaterialTheme.typography.labelMedium, color = Color.White, fontWeight = FontWeight.ExtraBold)
                    Text("No real money or bank card information will be processed.", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("SELECT PAYMENT INSTRUMENT", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Color.Gray)
        Spacer(modifier = Modifier.height(8.dp))

        listOf("Simulated Credit Card", "Simulated Apple Pay / Google Pay", "Simulated Gift Card").forEach { method ->
            val isSelected = selectedPaymentMethod == method
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPaymentMethodChange(method) }
                    .background(
                        color = if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = isSelected, onClick = { onPaymentMethodChange(method) })
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(method, fontWeight = FontWeight.Bold)
                    Text("Instant simulated confirmation", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
            Divider(color = Color.LightGray.copy(alpha = 0.3f))
        }

        Spacer(modifier = Modifier.height(30.dp))

        // Checkout Button
        Button(
            onClick = onSubmitOrder,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("checkout_pay_button"),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF52724F)) // green for success
        ) {
            Icon(Icons.Default.Lock, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("AUTHORIZE SIMULATED PAYMENT: " + viewModel.formatPrice(viewModel.calculateCartTotal()), style = MaterialTheme.typography.labelLarge)
        }

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedButton(onClick = onBackToCart, modifier = Modifier.fillMaxWidth()) {
            Text("Back to Cart")
        }
    }
}

@Composable
fun OrderTrackerContent(order: com.example.data.Order, viewModel: GoldenCorralViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = when (order.status) {
                OrderStatus.RECEIVED -> Icons.Default.CloudDownload
                OrderStatus.PREPARING -> Icons.Default.SoupKitchen
                OrderStatus.PACKING -> Icons.Default.Inventory2
                OrderStatus.ON_THE_WAY -> Icons.Default.LocalShipping
                OrderStatus.READY -> Icons.Default.CheckCircle
                OrderStatus.DELIVERED -> Icons.Default.TaskAlt
                else -> Icons.Default.Done
            },
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(64.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text("ORDER STATUS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Gray)
        Text(order.status.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
        Text("Order #${order.id} • ${order.restaurantName}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

        Spacer(modifier = Modifier.height(24.dp))

        // Linear Timeline display pipeline
        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val steps = listOf(
                OrderStatus.RECEIVED to "Order Received",
                OrderStatus.PREPARING to "Kitchen Preparing Buffet Selection",
                OrderStatus.PACKING to "Packing To-Go Box",
                if (order.type == OrderType.DELIVERY) OrderStatus.ON_THE_WAY to "On the Way" else OrderStatus.READY to "Ready for Pickup",
                if (order.type == OrderType.DELIVERY) OrderStatus.DELIVERED to "Delivered" else OrderStatus.COMPLETED to "Enjoy Buffet!"
            )

            val currentStepIdx = steps.indexOfFirst { it.first == order.status }.coerceAtLeast(0)

            steps.forEachIndexed { idx, (status, label) ->
                val isCompleted = idx <= currentStepIdx
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(
                                color = if (isCompleted) Color(0xFF52724F) else Color.LightGray.copy(alpha = 0.5f),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                        } else {
                            Text("${idx + 1}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (idx == currentStepIdx) FontWeight.Bold else FontWeight.Normal,
                        color = if (idx == currentStepIdx) MaterialTheme.colorScheme.onBackground else Color.Gray
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ORDER BREAKDOWN", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Gray)
                Spacer(modifier = Modifier.height(8.dp))
                order.items.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${item.quantity}x ${item.menuItem.name}", style = MaterialTheme.typography.bodyMedium)
                        Text(viewModel.formatPrice(item.menuItem.basePrice * item.quantity), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    }
                }
                Divider(modifier = Modifier.padding(vertical = 8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TOTAL CHARGED", fontWeight = FontWeight.Bold)
                    Text(viewModel.formatPrice(order.total), fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))

        Button(
            onClick = {
                // Return to home state
                viewModel.clearCart()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Back to Home")
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}
