package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.MenuItem
import com.example.data.Restaurant
import com.example.viewmodel.GoldenCorralViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: GoldenCorralViewModel,
    onNavigateToMenu: () -> Unit,
    onNavigateToOrder: () -> Unit,
    onNavigateToRewards: () -> Unit
) {
    val selectedRest by viewModel.selectedRestaurant.collectAsState()
    val points by viewModel.userPoints.collectAsState()
    val rewardsBal by viewModel.rewardBalance.collectAsState()
    val scrollState = rememberScrollState()

    var showLocationSelector by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Hero Image and Header Overlay
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
        ) {
            // Attempt to load the gorgeous generated hero banner
            val bannerPainter = painterResource(id = R.drawable.img_corral_banner_1790517547855)
            Image(
                painter = bannerPainter,
                contentDescription = "Golden Corral Buffet",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Dark linear gradient overlay for readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)),
                            startY = 100f
                        )
                    )
            )

            // Floating header text
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
            ) {
                Text(
                    text = "GOOD EVENING",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFFD6A62C), // Gold accent
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "WHAT ARE YOU HUNGRY FOR?",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Selected Restaurant Display Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .testTag("location_info_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Restaurant,
                            contentDescription = "Restaurant Locator",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "GOLDEN CORRAL",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = selectedRest.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Button(
                        onClick = { showLocationSelector = !showLocationSelector },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Change", style = MaterialTheme.typography.labelMedium)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = "Hours",
                            tint = Color(0xFF52724F),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "OPEN UNTIL ${selectedRest.closingTime}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF52724F)
                        )
                    }
                    Text(
                        text = "${selectedRest.distance} MI AWAY",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                }

                AnimatedVisibility(visible = showLocationSelector) {
                    Column {
                        Divider(modifier = Modifier.padding(vertical = 12.dp))
                        Text(
                            text = "SELECT RESTAURANT",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        viewModel.restaurants.forEach { rest ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectRestaurant(rest)
                                        showLocationSelector = false
                                    }
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = rest.name,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = if (rest.id == selectedRest.id) FontWeight.Bold else FontWeight.Normal,
                                        color = if (rest.id == selectedRest.id) MaterialTheme.colorScheme.primary else Color.Unspecified
                                    )
                                    Text(rest.address, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                }
                                Text("${rest.distance} mi", style = MaterialTheme.typography.bodyMedium)
                            }
                            Divider(color = Color.LightGray.copy(alpha = 0.5f))
                        }
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 12.dp))

                // Core quick order actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.setOrderType(com.example.data.OrderType.TO_GO)
                            onNavigateToOrder()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_togo_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = "To Go")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ORDER TO GO", style = MaterialTheme.typography.labelLarge)
                    }

                    Button(
                        onClick = {
                            viewModel.setOrderType(com.example.data.OrderType.DELIVERY)
                            onNavigateToOrder()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_delivery_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Icon(Icons.Default.LocalShipping, contentDescription = "Delivery")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("DELIVERY", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }

        // Rewards Quick-View Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clickable { onNavigateToRewards() },
            colors = CardDefaults.cardColors(containerColor = Color(0xFF4A3023)) // Roasted Brown
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1.3f)) {
                    Text(
                        text = "YOUR REWARDS BALANCE",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFD6A62C),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$points POINTS",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${100 - points} points to your next $10 reward!",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFF5EBDD)
                    )
                    if (rewardsBal > 0.0) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFD6A62C), shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "AVAILABLE: ${viewModel.formatPrice(rewardsBal)} OFF",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFF2A211C),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Mini circular points progress
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(80.dp)
                        .weight(0.7f)
                ) {
                    CircularProgressIndicator(
                        progress = { points / 100f },
                        modifier = Modifier.size(72.dp),
                        color = Color(0xFFD6A62C),
                        strokeWidth = 8.dp,
                        trackColor = Color.White.copy(alpha = 0.2f),
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$points%",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Next $10",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 8.sp,
                            color = Color(0xFFF5EBDD)
                        )
                    }
                }
            }
        }

        // Tonight's Buffet Highlights Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        ) {
            Text(
                text = "TONIGHT AT GOLDEN CORRAL",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 2.dp),
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "ENDLESS FAMILY FAVOURITES ON THE DIGITAL BUFFET",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
            )

            val highlights = viewModel.allMenuItems.filter {
                it.id in listOf("m6", "m8", "m13", "m14", "m22", "m23")
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(highlights) { item ->
                    HighlightFoodCard(item = item, onAdd = { viewModel.addToCart(item) })
                }
            }
        }

        // Active Promotions Banners
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "LATEST PROMOTIONS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            PromoBanner(
                title = "$2.50 KIDS BREAKFAST",
                subtitle = "This Weekend Only • Select Locations",
                accentColor = Color(0xFFA83A2B),
                details = "Dine-in only. Up to 2 kids meals for $2.50 with each adult buffet purchase."
            )

            Spacer(modifier = Modifier.height(12.dp))

            PromoBanner(
                title = "UNLIMITED SIRLOIN FEAST",
                subtitle = "Monday - Saturday after 4 PM",
                accentColor = Color(0xFFB78319),
                details = "Enjoy infinite tender carved USDA sirloin steak, grilled to perfection, as part of your dinner buffet."
            )
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}

@Composable
fun HighlightFoodCard(item: MenuItem, onAdd: () -> Unit) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .height(210.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(95.dp)
                    .background(Color(0xFFEFE7DA))
            ) {
                // Appetizing generic display category colors and name text representing food photography
                val bgColor = when (item.category) {
                    "STEAKS" -> Color(0xFF7D2922)
                    "CHICKEN" -> Color(0xFFB78319)
                    "POT ROAST" -> Color(0xFF4A3023)
                    "HOT SIDES" -> Color(0xFFD6A62C)
                    "BREAD" -> Color(0xFFF5EBDD)
                    else -> Color(0xFFA83A2B)
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(bgColor)
                ) {
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Restaurant,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.5f),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.category,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2
                    )
                    Text(
                        text = "${item.calories} CAL",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$${item.basePrice}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(
                        onClick = onAdd,
                        modifier = Modifier
                            .size(28.dp)
                            .background(MaterialTheme.colorScheme.primary, shape = CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add to Cart",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PromoBanner(
    title: String,
    subtitle: String,
    accentColor: Color,
    details: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = accentColor
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .background(accentColor.copy(alpha = 0.15f), CircleShape)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "2026 VALUE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = accentColor
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = details,
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }
}
