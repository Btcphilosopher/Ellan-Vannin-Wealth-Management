package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.GoldenCorralViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TwinScreen(viewModel: GoldenCorralViewModel) {
    val selectedRest by viewModel.selectedRestaurant.collectAsState()
    val stations by viewModel.buffetStations.collectAsState()

    // Demand states
    val day by viewModel.simDay.collectAsState()
    val time by viewModel.simTime.collectAsState()
    val weather by viewModel.simWeather.collectAsState()
    val promo by viewModel.simPromo.collectAsState()

    // Output counters
    val customerCount by viewModel.simCustomerCount.collectAsState()
    val portionsServed by viewModel.simPortionsServed.collectAsState()
    val toGoOrders by viewModel.simToGoOrders.collectAsState()
    val deliveryOrders by viewModel.simDeliveryOrders.collectAsState()
    val revenue by viewModel.simRevenue.collectAsState()

    // Queue wait times
    val diningWait by viewModel.queueWaitDining.collectAsState()
    val toGoWait by viewModel.queueWaitToGo.collectAsState()
    val deliveryWait by viewModel.queueWaitDelivery.collectAsState()

    var showDemandControls by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF2A211C)) // Deep Brown
                .padding(vertical = 12.dp)
        ) {
            Text(
                text = "GOLDEN CORRAL DIGITAL TWIN OS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFD6A62C),
                modifier = Modifier.align(Alignment.Center)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Live Operational heads-up banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5EBDD)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFB78319))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("RESTAURANT OPS DASHBOARD", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color(0xFF4A3023))
                            Text(text = "Location: ${selectedRest.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF52724F), CircleShape)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("SIMULATING", style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.ExtraBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Grid metric blocks
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricBlock(label = "Daily Guests", value = "$customerCount", modifier = Modifier.weight(1f))
                        MetricBlock(label = "Portions Served", value = "$portionsServed", modifier = Modifier.weight(1f))
                        MetricBlock(label = "Simulated Revenue", value = "$${revenue.toInt()}", modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricBlock(label = "To-Go orders", value = "$toGoOrders", modifier = Modifier.weight(1f))
                        MetricBlock(label = "Delivery orders", value = "$deliveryOrders", modifier = Modifier.weight(1f))
                        MetricBlock(label = "Active Stations", value = "${stations.size}", modifier = Modifier.weight(1f))
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Queue wait simulation monitors
            Text("QUEUE MONITOR & WAIT TIMES", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold, color = Color.Gray)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QueueCard(label = "Dine-In Queue", timeMinutes = diningWait, color = Color(0xFFB78319), modifier = Modifier.weight(1f))
                QueueCard(label = "To-Go Station", timeMinutes = toGoWait, color = Color(0xFFA83A2B), modifier = Modifier.weight(1f))
                QueueCard(label = "Delivery Drivers", timeMinutes = deliveryWait, color = Color(0xFF52724F), modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Demand Engine controllers trigger
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DEMAND PARAMETERS SIMULATOR",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { showDemandControls = !showDemandControls }) {
                            Icon(
                                imageVector = if (showDemandControls) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null
                            )
                        }
                    }

                    Text(
                        text = "Current: $day • $time • $weather • $promo",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )

                    AnimatedVisibility(visible = showDemandControls) {
                        Column {
                            Divider(modifier = Modifier.padding(vertical = 12.dp))

                            Text("Select Time Peak Context:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("8:00 AM", "12:30 PM", "6:30 PM").forEach { t ->
                                    val isSel = time == t
                                    Button(
                                        onClick = { viewModel.updateDemandInputs(day, t, weather, promo) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.2f),
                                            contentColor = if (isSel) Color.White else Color.Unspecified
                                        ),
                                        modifier = Modifier.height(32.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = when (t) {
                                                "8:00 AM" -> "Breakfast"
                                                "12:30 PM" -> "Lunch"
                                                else -> "Dinner Peak"
                                            },
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Select Day Context:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("Wednesday", "Saturday", "Sunday").forEach { d ->
                                    val isSel = day == d
                                    Button(
                                        onClick = { viewModel.updateDemandInputs(d, time, weather, promo) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.2f),
                                            contentColor = if (isSel) Color.White else Color.Unspecified
                                        ),
                                        modifier = Modifier.height(32.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(d, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Steam-Table Buffet Stations manager refill section
            Text("STEAM-TABLE STATIONS & FOOD Batch REFILLS", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold, color = Color.Gray)
            Spacer(modifier = Modifier.height(8.dp))

            stations.forEach { station ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .testTag("station_card_${station.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1.3f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(station.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                Spacer(modifier = Modifier.width(6.dp))
                                if (station.isRefillRequired) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFFA83A2B), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 1.dp)
                                    ) {
                                        Text("LOW", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Text(
                                text = "Portions: ${station.portionsAvailable}/${station.maxPortions} • Heat: ${station.currentTempF}°F",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                            Text(
                                text = "Last refill: " + station.lastRefill,
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }

                        // Refill button
                        Button(
                            onClick = { viewModel.refillStation(station.id) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (station.isRefillRequired) Color(0xFFA83A2B) else Color(0xFF52724F)
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .weight(0.7f)
                        ) {
                            Text("REFILL BATCH", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}

@Composable
fun MetricBlock(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(Color.White, RoundedCornerShape(8.dp))
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, color = Color.Gray, textAlign = TextAlign.Center)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color(0xFF2A211C))
        }
    }
}

@Composable
fun QueueCard(label: String, timeMinutes: Int, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.height(100.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontWeight = FontWeight.Bold)
            Text(
                text = "$timeMinutes MIN",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = if (timeMinutes < 15) "FAST FLOW" else "HIGH WAIT",
                style = MaterialTheme.typography.labelSmall,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                color = if (timeMinutes < 15) Color(0xFF52724F) else Color(0xFFA83A2B)
            )
        }
    }
}
