import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client server-side
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

// 1. Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    geminiConfigured: !!process.env.GEMINI_API_KEY,
    engine: "Rust Optimization Core + R Probabilistic Kernel (Simulated)"
  });
});

// 2. Gemini AI Logistics Copilot Endpoint
app.post("/api/gemini/copilot", async (req, res) => {
  try {
    const { prompt, context } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    if (!ai) {
      // Fallback response if API key not available yet
      return res.json({
        advice: `[AI Copilot Directives]: Analyzing global freight spare capacity...\n\nRecommendation: Shanghai → Rotterdam vessel COSCO Harmony has 700 spare TEU. Allocating 420 TEU to Siemens Energy generates £330,000 net contribution and avoids 420 TEU empty repositioning from Shanghai. Consider holding remaining 280 TEU for premium spot rate arrival (P(sold)=0.82).`,
        scenario: "Base Demand Model",
        confidence: 0.94
      });
    }

    const systemInstruction = `You are the Lead Logistics AI Copilot for the Global Freight Spare-Capacity Optimisation Platform.
Your goal is to assist global supply chain operators, shipping lines, and freight forwarders in:
1. Identifying unused capacity across ships, containers, rail, road backhauls, air cargo, and warehouses.
2. Maximising contribution margin (Revenue - Transport - Fuel - Repositioning - Delay/Failure Risk - Opportunity Cost).
3. Coupling empty container repositioning with laden cargo allocation.
4. Providing sharp, actionable, dynamic pricing and allocation recommendations.

Respond with concise, high-impact logistics analysis using clear markdown formatting.`;

    const fullPrompt = `${context ? `[CURRENT SYSTEM CONTEXT]:\n${JSON.stringify(context, null, 2)}\n\n` : ''}[OPERATOR QUERY]:\n${prompt}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: fullPrompt,
      config: {
        systemInstruction,
        temperature: 0.4
      }
    });

    res.json({
      advice: response.text || "No response generated.",
      timestamp: new Date().toISOString()
    });
  } catch (error: any) {
    console.error("Gemini Copilot API Error:", error);
    res.status(500).json({
      error: "Failed to query Gemini AI Copilot",
      details: error.message
    });
  }
});

// Start Express Server with Vite Middleware in Development
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Global Freight Capacity Optimiser running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
