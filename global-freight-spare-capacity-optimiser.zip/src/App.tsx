/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { ControlTower } from './components/ControlTower';
import { GlobalCapacityMap } from './components/GlobalCapacityMap';
import { OpportunityEngine } from './components/OpportunityEngine';
import { LegByLegAnalyzer } from './components/LegByLegAnalyzer';
import { EmptyRepositioning } from './components/EmptyRepositioning';
import { CargoDemandMatching } from './components/CargoDemandMatching';
import { ConsolidationBackhaul } from './components/ConsolidationBackhaul';
import { AuctionMarketplace } from './components/AuctionMarketplace';
import { RAnalyticsLab } from './components/RAnalyticsLab';
import { AiCopilotModal } from './components/AiCopilotModal';

import {
  GLOBAL_PORTS,
  MOCK_CAPACITY_ASSETS,
  MOCK_CARGO_DEMANDS,
  MOCK_REPOSITIONING_NODES,
  MOCK_AUCTION_LISTINGS,
  INITIAL_CONTROL_TOWER_KPIS
} from './data/mockData';
import { CargoDemand, CapacityAsset, OptimisationAlgorithm } from './types';
import { runMatchingOptimization, runCargoConsolidation } from './engine/optimiser';
import {
  LayoutDashboard,
  Compass,
  Sparkles,
  Layers,
  RefreshCw,
  Package,
  Box,
  Gavel,
  BarChart3,
  CheckCircle2
} from 'lucide-react';

export default function App() {
  const [selectedCurrency, setSelectedCurrency] = useState<'GBP' | 'USD' | 'EUR'>('GBP');
  const [activeTab, setActiveTab] = useState<string>('tower');
  const [algorithm, setAlgorithm] = useState<OptimisationAlgorithm>('MILP');
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [isCopilotOpen, setIsCopilotOpen] = useState<boolean>(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Application Data States
  const [assets, setAssets] = useState<CapacityAsset[]>(MOCK_CAPACITY_ASSETS);
  const [cargos, setCargos] = useState<CargoDemand[]>(MOCK_CARGO_DEMANDS);
  const [auctions, setAuctions] = useState(MOCK_AUCTION_LISTINGS);
  const [kpis, setKpis] = useState(INITIAL_CONTROL_TOWER_KPIS);

  const currencySymbol = selectedCurrency === 'GBP' ? '£' : selectedCurrency === 'USD' ? '$' : '€';
  const currencyMultiplier = selectedCurrency === 'GBP' ? 1.0 : selectedCurrency === 'USD' ? 1.30 : 1.18;

  // Compute Live Match Opportunities & Consolidation Groups
  const matchOpportunities = useMemo(() => {
    return runMatchingOptimization(cargos, assets, algorithm);
  }, [cargos, assets, algorithm]);

  const consolidationGroups = useMemo(() => {
    return runCargoConsolidation(cargos);
  }, [cargos]);

  // Handle Match Execution
  const handleExecuteMatch = (matchId: string) => {
    const match = matchOpportunities.find(m => m.id === matchId);
    if (!match) return;

    // Deduct capacity on asset & set cargo matched
    setAssets(prev => prev.map(a => {
      if (a.id === match.asset.id) {
        return {
          ...a,
          bookedTeu: a.bookedTeu + match.allocatedTeu,
          spareTeu: Math.max(0, a.spareTeu - match.allocatedTeu)
        };
      }
      return a;
    }));

    setCargos(prev => prev.map(c => {
      if (c.id === match.cargo.id) {
        return { ...c, status: 'MATCHED' };
      }
      return c;
    }));

    // Update KPIs
    setKpis(prev => ({
      ...prev,
      cargoWaitingTeu: Math.max(0, prev.cargoWaitingTeu - match.allocatedTeu),
      potentialIncrementalRevenueGbp: prev.potentialIncrementalRevenueGbp + match.netContributionGbp,
      unusedCapacityValueGbp: Math.max(0, prev.unusedCapacityValueGbp - match.netContributionGbp),
      avoidedRepositioningSavingsGbp: prev.avoidedRepositioningSavingsGbp + (match.avoidedEmptyRepositioningTeu * 280)
    }));

    showNotification(`Match executed! Allocated ${match.allocatedTeu} TEU to ${match.cargo.customerName}. +${currencySymbol}${(match.netContributionGbp * currencyMultiplier).toLocaleString(undefined, { maximumFractionDigits: 0 })} net contribution unlocked.`);
  };

  // Handle Adding New Cargo Request
  const handleAddCargo = (newCargo: CargoDemand) => {
    setCargos(prev => [newCargo, ...prev]);
    setKpis(prev => ({
      ...prev,
      cargoWaitingTeu: prev.cargoWaitingTeu + newCargo.requiredTeuCount
    }));
    showNotification(`Cargo request from ${newCargo.customerName} submitted successfully! Candidate matches evaluated.`);
  };

  // Handle Auction Bids
  const handlePlaceBid = (listingId: string, bidAmount: number) => {
    setAuctions(prev => prev.map(auc => {
      if (auc.id === listingId) {
        return {
          ...auc,
          currentHighestBidGbp: bidAmount,
          totalBidsCount: auc.totalBidsCount + 1,
          highestBidder: 'Your Fleet Operations'
        };
      }
      return auc;
    }));
    showNotification(`Auction bid of ${currencySymbol}${(bidAmount * currencyMultiplier).toFixed(0)} submitted successfully!`);
  };

  // Run Solver Trigger
  const handleRunOptimization = () => {
    setIsOptimizing(true);
    setTimeout(() => {
      setIsOptimizing(false);
      showNotification(`Rust ${algorithm} Optimiser executed across 14,200 lanes in 28ms. Global Capacity Efficiency updated.`);
    }, 800);
  };

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 5000);
  };

  const backhaulAssets = assets.filter(a => a.isBackhaulRoute || a.mode === 'ROAD');

  return (
    <div className="min-h-screen bg-[#0F1115] text-[#E0E0E0] font-sans selection:bg-emerald-500 selection:text-[#0F1115] flex flex-col">
      
      {/* App Navigation Header */}
      <Header
        selectedCurrency={selectedCurrency}
        setSelectedCurrency={setSelectedCurrency}
        onOpenCopilot={() => setIsCopilotOpen(true)}
        onRunOptimization={handleRunOptimization}
        isOptimizing={isOptimizing}
        algorithm={algorithm}
        setAlgorithm={setAlgorithm}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Toast Notification Banner */}
        {notification && (
          <div className="bg-[#151921] border border-emerald-500/50 text-emerald-400 px-4 py-3 rounded-sm shadow-[0_0_10px_rgba(16,185,129,0.15)] flex items-center justify-between text-xs font-mono animate-in fade-in slide-in-from-top-2">
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>{notification}</span>
            </div>
            <button onClick={() => setNotification(null)} className="text-emerald-400 font-bold hover:text-white uppercase tracking-wider text-[10px]">
              Dismiss
            </button>
          </div>
        )}

        {/* Primary Tab Navigation Bar */}
        <div className="flex items-center space-x-1 border-b border-[#2D3139] overflow-x-auto pb-1 scrollbar-none font-mono">
          {[
            { id: 'tower', label: 'CONTROL TOWER', icon: LayoutDashboard },
            { id: 'map', label: 'CAPACITY MAP', icon: Compass },
            { id: 'opportunities', label: `OPPORTUNITIES (${matchOpportunities.length})`, icon: Sparkles },
            { id: 'legbyleg', label: 'LEG INSPECTOR', icon: Layers },
            { id: 'repositioning', label: 'REPOSITIONING', icon: RefreshCw },
            { id: 'cargo', label: 'CARGO MATCHING', icon: Package },
            { id: 'consolidation', label: 'CONSOLIDATION', icon: Box },
            { id: 'auction', label: 'EXCHANGE', icon: Gavel },
            { id: 'analytics', label: 'R ANALYTICS', icon: BarChart3 },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-sm text-[11px] font-bold uppercase tracking-wider whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-[#151921] text-emerald-400 border border-emerald-500/50 shadow-[0_0_8px_rgba(16,185,129,0.2)]'
                    : 'text-[#8E9299] hover:text-white hover:bg-[#151921]/50 border border-transparent'
                }`}
              >
                <Icon className={`h-3.5 w-3.5 ${isActive ? 'text-emerald-400' : 'text-[#8E9299]'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Dynamic Active Tab View */}
        {activeTab === 'tower' && (
          <ControlTower
            kpis={kpis}
            topMatches={matchOpportunities}
            assets={assets}
            currencySymbol={currencySymbol}
            currencyMultiplier={currencyMultiplier}
            onSelectTab={setActiveTab}
            onExecuteMatch={handleExecuteMatch}
          />
        )}

        {activeTab === 'map' && (
          <GlobalCapacityMap
            ports={GLOBAL_PORTS}
            assets={assets}
            currencySymbol={currencySymbol}
          />
        )}

        {activeTab === 'opportunities' && (
          <OpportunityEngine
            opportunities={matchOpportunities}
            currencySymbol={currencySymbol}
            currencyMultiplier={currencyMultiplier}
            onExecuteMatch={handleExecuteMatch}
          />
        )}

        {activeTab === 'legbyleg' && (
          <LegByLegAnalyzer
            assets={assets}
            currencySymbol={currencySymbol}
          />
        )}

        {activeTab === 'repositioning' && (
          <EmptyRepositioning
            nodes={MOCK_REPOSITIONING_NODES}
            currencySymbol={currencySymbol}
            currencyMultiplier={currencyMultiplier}
          />
        )}

        {activeTab === 'cargo' && (
          <CargoDemandMatching
            cargos={cargos}
            assets={assets}
            ports={GLOBAL_PORTS}
            onAddCargo={handleAddCargo}
            currencySymbol={currencySymbol}
          />
        )}

        {activeTab === 'consolidation' && (
          <ConsolidationBackhaul
            consolidationGroups={consolidationGroups}
            backhaulAssets={backhaulAssets}
            currencySymbol={currencySymbol}
          />
        )}

        {activeTab === 'auction' && (
          <AuctionMarketplace
            listings={auctions}
            onPlaceBid={handlePlaceBid}
            currencySymbol={currencySymbol}
          />
        )}

        {activeTab === 'analytics' && (
          <RAnalyticsLab
            assets={assets}
            currencySymbol={currencySymbol}
          />
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-[#2D3139] bg-[#151921] py-3 text-[#8E9299] text-[10px] font-mono uppercase tracking-wider text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-2">
          <span>CAPACITY.OPTIMISER // RUST CORE + R STATISTICAL ENGINE</span>
          <span>CONTINUOUS CAPACITY MATCHING ACROSS MARITIME, CONTAINER, RAIL, ROAD, AIR & WAREHOUSE</span>
        </div>
      </footer>

      {/* Gemini AI Copilot Dialog */}
      <AiCopilotModal
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        context={{
          algorithm,
          totalSpareTeu: kpis.totalAvailableTeu,
          unusedCapacityValue: kpis.unusedCapacityValueGbp,
          topMatchCount: matchOpportunities.length,
          highestMarginMatch: matchOpportunities[0]?.netContributionGbp
        }}
      />

    </div>
  );
}
