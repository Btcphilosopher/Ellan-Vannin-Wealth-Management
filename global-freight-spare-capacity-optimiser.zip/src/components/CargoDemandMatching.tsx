import React, { useState } from 'react';
import { CargoDemand, ContainerType, CargoType, LocationNode, CapacityAsset } from '../types';
import { checkCargoCompatibility } from '../engine/optimiser';
import { Package, Plus, CheckCircle, AlertTriangle, XCircle, ArrowRight } from 'lucide-react';

interface CargoDemandMatchingProps {
  cargos: CargoDemand[];
  assets: CapacityAsset[];
  ports: LocationNode[];
  onAddCargo: (newCargo: CargoDemand) => void;
  currencySymbol: string;
}

export const CargoDemandMatching: React.FC<CargoDemandMatchingProps> = ({
  cargos,
  assets,
  ports,
  onAddCargo,
  currencySymbol,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);

  // New Cargo Form state
  const [customerName, setCustomerName] = useState('');
  const [originId, setOriginId] = useState(ports[0]?.id || '');
  const [destId, setDestId] = useState(ports[2]?.id || '');
  const [weight, setWeight] = useState(24);
  const [volume, setVolume] = useState(65);
  const [teuCount, setTeuCount] = useState(2);
  const [containerType, setContainerType] = useState<ContainerType>('40FT_DRY');
  const [cargoType, setCargoType] = useState<CargoType>('DRY');
  const [isHazmat, setIsHazmat] = useState(false);
  const [isReefer, setIsReefer] = useState(false);
  const [valueGbp, setValueGbp] = useState(500000);
  const [wtpGbp, setWtpGbp] = useState(1800);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const originPort = ports.find(p => p.id === originId) || ports[0];
    const destPort = ports.find(p => p.id === destId) || ports[1];

    const newCargo: CargoDemand = {
      id: `cargo-${Date.now()}`,
      customerName: customerName || 'Global Trader Inc',
      origin: originPort,
      destination: destPort,
      earliestDeparture: new Date().toISOString(),
      latestArrival: new Date(Date.now() + 14 * 86400000).toISOString(),
      weightTonnes: Number(weight),
      volumeM3: Number(volume),
      palletCount: Math.round(volume * 0.5),
      requiredContainerType: containerType,
      requiredTeuCount: Number(teuCount),
      cargoType: isHazmat ? 'HAZMAT' : isReefer ? 'REEFER' : cargoType,
      isHazardous: isHazmat,
      requiresTemperatureControl: isReefer,
      targetTempCelsius: isReefer ? 4 : undefined,
      declaredValueGbp: Number(valueGbp),
      willingnessToPayPerTeuGbp: Number(wtpGbp),
      priorityScore: 8,
      status: 'PENDING',
      createdDate: new Date().toISOString()
    };

    onAddCargo(newCargo);
    setShowAddForm(false);
    setCustomerName('');
  };

  return (
    <div className="space-y-6 font-mono">
      
      {/* Top Controls Banner */}
      <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xs font-bold text-white uppercase tracking-[0.15em] flex items-center space-x-2">
            <Package className="h-4 w-4 text-emerald-500" />
            <span>Cargo Demand & Physical Compatibility Engine</span>
          </h2>
          <p className="text-xs text-[#8E9299] mt-0.5 font-sans">
            Structured shipment requests checked against vessel dimensions, weight limits, hazardous rules, port restrictions, and schedule windows.
          </p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-sm shadow-[0_0_8px_#10B981] transition-all flex items-center space-x-1.5 shrink-0 uppercase tracking-wider"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>{showAddForm ? 'Cancel Request' : 'Submit Cargo Demand'}</span>
        </button>
      </div>

      {/* New Cargo Submission Form Modal/Box */}
      {showAddForm && (
        <form onSubmit={handleSubmit} className="bg-[#151921] rounded-sm p-5 border border-emerald-500/50 space-y-4 shadow-xl font-mono">
          <h3 className="text-xs font-bold text-emerald-500 uppercase tracking-wider">
            Create Cargo Demand Request (Section 9)
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="text-[#8E9299] block mb-1 uppercase text-[10px]">Customer Name</label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="e.g. BMW Logistics GmbH"
                required
                className="w-full bg-[#11141B] text-white p-2 rounded-sm border border-[#2D3139] focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-[#8E9299] block mb-1 uppercase text-[10px]">Origin Port/Hub</label>
              <select
                value={originId}
                onChange={(e) => setOriginId(e.target.value)}
                className="w-full bg-[#11141B] text-white p-2 rounded-sm border border-[#2D3139] focus:outline-none focus:border-emerald-500"
              >
                {ports.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} ({p.country})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[#8E9299] block mb-1 uppercase text-[10px]">Destination Port/Hub</label>
              <select
                value={destId}
                onChange={(e) => setDestId(e.target.value)}
                className="w-full bg-[#11141B] text-white p-2 rounded-sm border border-[#2D3139] focus:outline-none focus:border-emerald-500"
              >
                {ports.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} ({p.country})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[#8E9299] block mb-1 uppercase text-[10px]">TEU Count</label>
              <input
                type="number"
                value={teuCount}
                onChange={(e) => setTeuCount(Number(e.target.value))}
                min={1}
                max={500}
                className="w-full bg-[#11141B] text-white p-2 rounded-sm border border-[#2D3139] focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="text-[#8E9299] block mb-1 uppercase text-[10px]">Container Type</label>
              <select
                value={containerType}
                onChange={(e) => setContainerType(e.target.value as ContainerType)}
                className="w-full bg-[#11141B] text-white p-2 rounded-sm border border-[#2D3139] focus:outline-none focus:border-emerald-500"
              >
                <option value="20FT_DRY">20ft Dry</option>
                <option value="40FT_DRY">40ft Dry</option>
                <option value="40FT_HC">40ft HC (High Cube)</option>
                <option value="45FT_HC">45ft HC</option>
                <option value="REEFER">Refrigerated (Reefer)</option>
                <option value="TANK">ISO Tank Container</option>
                <option value="OPEN_TOP">Open Top</option>
                <option value="FLAT_RACK">Flat Rack</option>
              </select>
            </div>

            <div>
              <label className="text-[#8E9299] block mb-1 uppercase text-[10px]">Willingness to Pay (£/TEU)</label>
              <input
                type="number"
                value={wtpGbp}
                onChange={(e) => setWtpGbp(Number(e.target.value))}
                min={100}
                step={50}
                className="w-full bg-[#11141B] text-white p-2 rounded-sm border border-[#2D3139] focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="flex items-center space-x-6 text-xs text-[#E0E0E0] pt-1 font-mono">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isHazmat}
                onChange={(e) => setIsHazmat(e.target.checked)}
                className="rounded-sm text-emerald-500 bg-[#11141B] border-[#2D3139] focus:ring-0"
              />
              <span>Hazardous Cargo (Hazmat)</span>
            </label>

            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isReefer}
                onChange={(e) => setIsReefer(e.target.checked)}
                className="rounded-sm text-emerald-500 bg-[#11141B] border-[#2D3139] focus:ring-0"
              />
              <span>Temperature Control Needed</span>
            </label>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-sm uppercase tracking-wider transition-all"
          >
            Submit Cargo Request to Match Engine
          </button>
        </form>
      )}

      {/* Active Cargo Demands Table */}
      <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-3 font-mono">
        <h3 className="text-[10px] font-bold text-emerald-500 uppercase tracking-[0.15em]">
          Active Cargo Demand Requests ({cargos.length})
        </h3>

        <div className="space-y-2">
          {cargos.map((cargo) => {
            // Test compatibility against candidate asset vessel-101
            const candidateAsset = assets[0];
            const check = checkCargoCompatibility(cargo, candidateAsset);

            return (
              <div
                key={cargo.id}
                className="bg-[#11141B] p-3.5 rounded-sm border border-[#2D3139] flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-white text-xs uppercase">{cargo.customerName}</span>
                    <span className="px-1.5 py-0.5 bg-[#151921] text-[#8E9299] rounded-sm text-[10px] border border-[#2D3139]">
                      {cargo.requiredTeuCount} TEU ({cargo.requiredContainerType})
                    </span>
                    <span className="px-1.5 py-0.5 bg-[#151921] text-emerald-400 rounded-sm text-[10px] border border-emerald-500/30">
                      {cargo.status}
                    </span>
                  </div>
                  <div className="text-[#8E9299] text-[11px]">
                    ROUTE: <strong className="text-white">{cargo.origin.name} → {cargo.destination.name}</strong> • WEIGHT: {cargo.weightTonnes}t • VALUE: £{cargo.declaredValueGbp.toLocaleString()}
                  </div>
                </div>

                <div className="flex items-center space-x-4 border-t md:border-t-0 pt-2 md:pt-0 border-[#2D3139] shrink-0">
                  <div className="text-right">
                    <span className="text-[10px] text-[#8E9299] block uppercase font-bold">Willingness to Pay</span>
                    <span className="font-bold text-emerald-400 text-xs">
                      £{cargo.willingnessToPayPerTeuGbp} / TEU
                    </span>
                  </div>

                  <div className="flex items-center space-x-1.5 px-2.5 py-1 bg-[#151921] rounded-sm border border-[#2D3139] text-[10px]">
                    {check.status === 'COMPATIBLE' && <CheckCircle className="h-3.5 w-3.5 text-emerald-400" />}
                    {check.status === 'CONDITIONALLY_COMPATIBLE' && <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />}
                    {check.status === 'INCOMPATIBLE' && <XCircle className="h-3.5 w-3.5 text-rose-400" />}
                    <span className="font-bold text-white">{check.status}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
