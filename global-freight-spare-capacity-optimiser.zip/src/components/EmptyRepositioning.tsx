import React from 'react';
import { EmptyContainerRepositioningNode } from '../types';
import { Package, ArrowRight, RefreshCw, Leaf, CheckCircle2 } from 'lucide-react';

interface EmptyRepositioningProps {
  nodes: EmptyContainerRepositioningNode[];
  currencySymbol: string;
  currencyMultiplier: number;
}

export const EmptyRepositioning: React.FC<EmptyRepositioningProps> = ({
  nodes,
  currencySymbol,
  currencyMultiplier,
}) => {
  const formatMoney = (val: number) => `${currencySymbol}${(val * currencyMultiplier).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;

  const totalSavings = nodes.reduce((acc, n) => acc + n.netSavingsGbp, 0);

  return (
    <div className="space-y-6 font-mono">
      
      {/* Top Summary Banner */}
      <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center space-x-2 text-emerald-500 text-[10px] font-bold tracking-[0.2em] uppercase mb-1">
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Empty Container & Slot Allocation Optimiser</span>
          </div>
          <h2 className="text-base font-bold text-white tracking-tight uppercase">
            Global Empty Container Repositioning Network
          </h2>
          <p className="text-xs text-[#8E9299] mt-0.5 max-w-2xl font-sans">
            Treating empty container repositioning and laden slot allocation as a coupled decision problem. Minimising empty miles, leasing penalties, and depot holding fees.
          </p>
        </div>

        <div className="bg-[#11141B] p-3 rounded-sm border border-[#2D3139] text-right">
          <span className="text-[10px] text-[#8E9299] block uppercase font-bold">Net Avoided Cost Savings</span>
          <span className="text-xl font-bold text-emerald-400">
            {formatMoney(totalSavings)}
          </span>
          <span className="text-[10px] text-[#8E9299] block mt-0.5">
            4,200 TEU Repositioned with Cargo
          </span>
        </div>
      </div>

      {/* Repositioning Decisions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {nodes.map((node) => {
          const isSurplus = node.netBalanceTeu > 0;

          return (
            <div
              key={node.portId}
              className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-3.5 hover:border-[#3d424c] transition-all"
            >
              <div className="flex justify-between items-start border-b border-[#2D3139] pb-2.5">
                <div>
                  <h3 className="text-xs font-bold text-white uppercase">{node.portName}</h3>
                  <span className="text-[10px] text-[#8E9299]">
                    Stock: {node.currentStockTeu.toLocaleString()} TEU • Demand: {node.demandTeu.toLocaleString()} TEU
                  </span>
                </div>

                <div className={`px-2 py-0.5 rounded-sm text-[10px] font-bold uppercase ${
                  isSurplus ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                }`}>
                  {isSurplus ? `Surplus +${node.netBalanceTeu.toLocaleString()} TEU` : `Deficit ${node.netBalanceTeu.toLocaleString()} TEU`}
                </div>
              </div>

              {/* Recommended Action Card */}
              <div className="p-3 bg-[#11141B] rounded-sm border border-[#2D3139] space-y-2">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-[#8E9299] font-bold uppercase">Optimal Action Decision:</span>
                  <span className="px-1.5 py-0.5 bg-[#151921] text-emerald-400 font-bold rounded-sm border border-[#2D3139] uppercase">
                    {node.recommendedAction}
                  </span>
                </div>

                {node.targetPortName && (
                  <div className="text-xs text-[#E0E0E0] flex items-center space-x-2 pt-0.5">
                    <span className="text-[10px] text-[#8E9299]">Target Hub:</span>
                    <strong className="text-emerald-400 uppercase">{node.targetPortName}</strong>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-[#2D3139]">
                  <div>
                    <span className="text-[#8E9299] block text-[10px] uppercase">Reposition Cost</span>
                    <span className="font-bold text-white">{formatMoney(node.estimatedRepositionCostGbp)} / TEU</span>
                  </div>
                  <div>
                    <span className="text-[#8E9299] block text-[10px] uppercase">Alt Lease Cost</span>
                    <span className="font-bold text-rose-400">{formatMoney(node.alternativeLeaseCostGbp)} / TEU</span>
                  </div>
                </div>
              </div>

              {/* Financial Savings Card */}
              <div className="flex justify-between items-center text-xs bg-[#11141B] p-2.5 rounded-sm border border-emerald-500/30">
                <span className="text-[#E0E0E0] font-bold text-[10px] uppercase flex items-center space-x-1.5">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  <span>Avoided Lease Savings:</span>
                </span>
                <span className="font-bold text-emerald-400 text-xs">
                  +{formatMoney(node.netSavingsGbp)}
                </span>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
