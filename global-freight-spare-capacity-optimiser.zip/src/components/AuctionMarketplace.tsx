import React, { useState } from 'react';
import { AuctionListing } from '../types';
import { DollarSign, Clock, Gavel, ShieldCheck } from 'lucide-react';

interface AuctionMarketplaceProps {
  listings: AuctionListing[];
  onPlaceBid: (listingId: string, bidAmount: number) => void;
  currencySymbol: string;
}

export const AuctionMarketplace: React.FC<AuctionMarketplaceProps> = ({
  listings,
  onPlaceBid,
  currencySymbol,
}) => {
  const [selectedListing, setSelectedListing] = useState<AuctionListing | null>(listings[0] || null);
  const [bidInput, setBidInput] = useState<number>(0);

  const handleBidSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedListing || bidInput <= selectedListing.currentHighestBidGbp) return;
    onPlaceBid(selectedListing.id, bidInput);
    setSelectedListing({
      ...selectedListing,
      currentHighestBidGbp: bidInput,
      totalBidsCount: selectedListing.totalBidsCount + 1,
      highestBidder: 'You (Optimiser Auto-Bidder)'
    });
    setBidInput(0);
  };

  return (
    <div className="space-y-6 font-mono">
      
      {/* Header Banner */}
      <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-emerald-500 text-[10px] font-bold tracking-[0.2em] uppercase mb-1">
            <Gavel className="h-3.5 w-3.5" />
            <span>Marketplace & Exchange (Section 17)</span>
          </div>
          <h2 className="text-base font-bold text-white tracking-tight uppercase">
            Capacity Auction Exchange
          </h2>
          <p className="text-xs text-[#8E9299] mt-0.5 font-sans">
            Multi-carrier spot auction exchange allowing carriers to offer unbooked capacity directly to cargo owners with automated clearing rules.
          </p>
        </div>

        <div className="px-3.5 py-2 bg-[#11141B] rounded-sm border border-[#2D3139] text-xs text-right">
          <span className="text-[#8E9299] block text-[10px] uppercase font-bold">Active Auctions</span>
          <span className="text-base font-bold text-emerald-400">{listings.length} Open Listings</span>
        </div>
      </div>

      {/* Main Grid View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Listings List */}
        <div className="lg:col-span-2 space-y-2.5">
          {listings.map((item) => {
            const isSelected = selectedListing?.id === item.id;

            return (
              <div
                key={item.id}
                onClick={() => { setSelectedListing(item); setBidInput(item.currentHighestBidGbp + 50); }}
                className={`cursor-pointer rounded-sm p-4 border transition-all ${
                  isSelected
                    ? 'bg-[#151921] border-emerald-500/80 shadow-[0_0_8px_rgba(16,185,129,0.15)]'
                    : 'bg-[#11141B] border-[#2D3139] hover:border-[#3d424c]'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  
                  <div className="space-y-1 max-w-lg">
                    <div className="flex items-center space-x-2">
                      <span className="px-1.5 py-0.5 bg-[#151921] text-[#8E9299] font-bold text-[9px] rounded-sm border border-[#2D3139] uppercase">
                        {item.mode}
                      </span>
                      <h3 className="text-xs font-bold text-white uppercase">
                        {item.origin} → {item.destination}
                      </h3>
                      <span className="text-[10px] font-bold text-emerald-400">
                        ({item.availableTeu} TEU)
                      </span>
                    </div>

                    <p className="text-[10px] text-[#8E9299]">
                      CARRIER: <strong className="text-white">{item.sellerCarrier}</strong> • DEPARTS: {item.departureDate}
                    </p>

                    <div className="flex flex-wrap items-center gap-2 text-[10px] text-[#8E9299] pt-0.5">
                      <Clock className="h-3 w-3 text-amber-400" />
                      <span>EXPIRES: <strong className="text-amber-400">{item.expiresInHours}h</strong></span>
                      <span>•</span>
                      <span>BIDS: <strong className="text-white">{item.totalBidsCount}</strong></span>
                      {item.highestBidder && (
                        <>
                          <span>•</span>
                          <span>LEADER: <strong className="text-emerald-400">{item.highestBidder}</strong></span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Pricing Details */}
                  <div className="sm:text-right border-t sm:border-t-0 pt-2 sm:pt-0 border-[#2D3139] shrink-0">
                    <span className="text-[10px] text-[#8E9299] uppercase block font-bold">Highest Bid</span>
                    <span className="text-base font-bold text-emerald-400">
                      {currencySymbol}{item.currentHighestBidGbp.toLocaleString()} <span className="text-[10px] text-[#8E9299] font-normal">/ TEU</span>
                    </span>
                    <span className="text-[10px] text-[#8E9299] block">
                      FLOOR: {currencySymbol}{item.floorPricePerTeuGbp}/TEU
                    </span>
                  </div>

                </div>
              </div>
            );
          })}
        </div>

        {/* Bidding Panel */}
        {selectedListing && (
          <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-4 sticky top-20">
            <div>
              <span className="text-[10px] text-emerald-500 font-bold uppercase tracking-[0.15em]">
                AUCTION BIDDING PANEL
              </span>
              <h3 className="text-sm font-bold text-white uppercase mt-0.5">
                {selectedListing.origin} → {selectedListing.destination}
              </h3>
              <p className="text-[10px] text-[#8E9299]">
                {selectedListing.sellerCarrier} • {selectedListing.availableTeu} TEU Available
              </p>
            </div>

            <div className="space-y-2 bg-[#11141B] p-3 rounded-sm border border-[#2D3139] text-xs">
              <div className="flex justify-between text-[#8E9299] text-[10px] uppercase">
                <span>Floor Price:</span>
                <span className="font-bold text-white">{currencySymbol}{selectedListing.floorPricePerTeuGbp} / TEU</span>
              </div>
              <div className="flex justify-between text-[#8E9299] text-[10px] uppercase">
                <span>Current Leading Bid:</span>
                <span className="font-bold text-emerald-400">{currencySymbol}{selectedListing.currentHighestBidGbp} / TEU</span>
              </div>
              <div className="flex justify-between text-[#8E9299] text-[10px] uppercase">
                <span>Total Bids Placed:</span>
                <span className="font-bold text-white">{selectedListing.totalBidsCount}</span>
              </div>
            </div>

            {/* Acceptable Cargo Conditions */}
            <div className="space-y-1.5 text-xs">
              <div className="font-bold text-white text-[10px] uppercase flex items-center space-x-1">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                <span>Cargo Conditions</span>
              </div>
              <ul className="space-y-1 text-[#8E9299] text-[10px] pl-4 list-disc">
                {selectedListing.allowedCargoConditions.map((cond, idx) => (
                  <li key={idx}>{cond}</li>
                ))}
              </ul>
            </div>

            {/* Bid Form */}
            <form onSubmit={handleBidSubmit} className="space-y-2.5 pt-2 border-t border-[#2D3139]">
              <label className="text-[10px] font-bold text-[#8E9299] uppercase block">
                Your Bid Amount ({currencySymbol} / TEU)
              </label>
              <input
                type="number"
                value={bidInput || selectedListing.currentHighestBidGbp + 50}
                onChange={(e) => setBidInput(Number(e.target.value))}
                min={selectedListing.currentHighestBidGbp + 1}
                step={10}
                className="w-full bg-[#11141B] text-white p-2 rounded-sm border border-[#2D3139] focus:outline-none focus:border-emerald-500 text-xs font-bold"
              />
              <button
                type="submit"
                className="w-full py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-sm uppercase tracking-wider transition-all shadow-[0_0_8px_#10B981]"
              >
                Submit Auction Bid
              </button>
            </form>
          </div>
        )}

      </div>

    </div>
  );
};
