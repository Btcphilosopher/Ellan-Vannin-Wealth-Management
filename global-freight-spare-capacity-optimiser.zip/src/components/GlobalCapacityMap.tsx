import React, { useState } from 'react';
import { LocationNode, CapacityAsset } from '../types';
import { Ship, Train, Truck, Plane, MapPin, Info, Compass, Layers } from 'lucide-react';

interface GlobalCapacityMapProps {
  ports: LocationNode[];
  assets: CapacityAsset[];
  currencySymbol: string;
}

export const GlobalCapacityMap: React.FC<GlobalCapacityMapProps> = ({
  ports,
  assets,
}) => {
  const [selectedAsset, setSelectedAsset] = useState<CapacityAsset | null>(assets[0]);
  const [selectedPort, setSelectedPort] = useState<LocationNode | null>(null);
  const [filterMode, setFilterMode] = useState<string>('ALL');

  const filteredAssets = filterMode === 'ALL' 
    ? assets 
    : assets.filter(a => a.mode === filterMode);

  return (
    <div className="space-y-6">
      
      {/* Map Control Bar & Mode Toggles */}
      <div className="bg-[#151921] rounded-sm p-3.5 border border-[#2D3139] flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-2">
          <Compass className="h-4 w-4 text-emerald-500" />
          <h2 className="text-xs font-mono font-bold text-white uppercase tracking-[0.15em]">
            Global Capacity & Freight Corridor Network
          </h2>
        </div>

        <div className="flex items-center space-x-2 font-mono text-xs">
          <span className="text-[#8E9299] flex items-center space-x-1 text-[11px] uppercase">
            <Layers className="h-3.5 w-3.5" />
            <span>Filter Mode:</span>
          </span>
          {(['ALL', 'MARITIME', 'RAIL', 'ROAD', 'AIR'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setFilterMode(mode)}
              className={`px-2.5 py-1 rounded-sm text-[11px] font-bold uppercase tracking-wider transition-colors ${
                filterMode === mode
                  ? 'bg-emerald-600 text-white shadow-[0_0_8px_#10B981]'
                  : 'bg-[#11141B] text-[#8E9299] hover:text-white border border-[#2D3139]'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {/* Main Map Visualisation Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Map Canvas Box */}
        <div className="lg:col-span-2 bg-[#11141B] rounded-sm border border-[#2D3139] overflow-hidden relative min-h-[500px] flex flex-col justify-between p-5">
          
          {/* Legend Overlay */}
          <div className="absolute top-4 left-4 z-10 bg-[#151921]/95 border border-[#2D3139] p-3 rounded-sm space-y-1.5 text-[11px] font-mono">
            <div className="font-bold text-white uppercase tracking-wider text-[10px]">Capacity Status Legend</div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block shadow-[0_0_6px_#10B981]" />
              <span className="text-[#E0E0E0]">Surplus Port (+TEU)</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
              <span className="text-[#E0E0E0]">Deficit Port (-TEU)</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
              <span className="text-[#E0E0E0]">Vessel / Asset in Transit</span>
            </div>
          </div>

          {/* Interactive Geo Canvas Schematic */}
          <div className="w-full h-96 relative bg-[radial-gradient(#2D3139_1px,transparent_1px)] [background-size:16px_16px] rounded-sm border border-[#2D3139] flex items-center justify-center">
            
            {/* Port Nodes */}
            {ports.map((port) => {
              // Convert lat/lng to normalized position percentage
              const x = Math.min(92, Math.max(8, ((port.lng + 180) / 360) * 100));
              const y = Math.min(88, Math.max(12, ((90 - port.lat) / 180) * 100));

              const isDeficit = (port.currentContainerSurplus || 0) < 0;

              return (
                <button
                  key={port.id}
                  onClick={() => setSelectedPort(port)}
                  style={{ left: `${x}%`, top: `${y}%` }}
                  className={`absolute transform -translate-x-1/2 -translate-y-1/2 group transition-all z-20`}
                >
                  <div className={`p-1 rounded-sm border ${
                    isDeficit ? 'bg-rose-500/20 border-rose-500 text-rose-400' : 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                  } group-hover:scale-125 transition-transform`}>
                    <MapPin className="h-3.5 w-3.5" />
                  </div>
                  <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 px-2 py-0.5 bg-[#151921] text-[10px] font-mono font-bold text-white rounded-sm border border-[#2D3139] whitespace-nowrap opacity-80 group-hover:opacity-100 z-30">
                    {port.name} ({port.currentContainerSurplus && port.currentContainerSurplus > 0 ? `+${port.currentContainerSurplus}` : port.currentContainerSurplus})
                  </div>
                </button>
              );
            })}

            {/* Active Moving Assets */}
            {filteredAssets.map((asset) => {
              if (!asset.origin || !asset.destination) return null;
              const x = Math.min(88, Math.max(12, ((asset.origin.lng + asset.destination.lng + 360) / 720) * 100));
              const y = Math.min(84, Math.max(16, ((180 - asset.origin.lat - asset.destination.lat) / 360) * 100));

              const isSelected = selectedAsset?.id === asset.id;

              return (
                <button
                  key={asset.id}
                  onClick={() => { setSelectedAsset(asset); setSelectedPort(null); }}
                  style={{ left: `${x}%`, top: `${y}%` }}
                  className={`absolute transform -translate-x-1/2 -translate-y-1/2 z-30 transition-all ${
                    isSelected ? 'scale-125 ring-2 ring-emerald-400 rounded-full' : ''
                  }`}
                >
                  <div className="p-1.5 bg-emerald-600 text-white rounded-full shadow-[0_0_8px_#10B981] hover:bg-emerald-500">
                    {asset.mode === 'MARITIME' && <Ship className="h-3.5 w-3.5" />}
                    {asset.mode === 'RAIL' && <Train className="h-3.5 w-3.5" />}
                    {asset.mode === 'ROAD' && <Truck className="h-3.5 w-3.5" />}
                    {asset.mode === 'AIR' && <Plane className="h-3.5 w-3.5" />}
                  </div>
                </button>
              );
            })}

          </div>

          {/* Map Footer status */}
          <div className="mt-4 pt-3 border-t border-[#2D3139] flex justify-between items-center text-[10px] font-mono text-[#8E9299]">
            <span>DISPLAYING {filteredAssets.length} ACTIVE ASSETS & {ports.length} GLOBAL HUBS</span>
            <span className="text-emerald-400">LIVE TELEMETRY ACTIVE</span>
          </div>

        </div>

        {/* Right Drawer: Asset / Node Detail Drilldown */}
        <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-4">
          {selectedAsset ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-[#2D3139] pb-3">
                <div className="flex items-center space-x-2">
                  <div className="p-2 bg-[#11141B] text-emerald-400 rounded-sm border border-[#2D3139]">
                    {selectedAsset.mode === 'MARITIME' && <Ship className="h-4 w-4" />}
                    {selectedAsset.mode === 'RAIL' && <Train className="h-4 w-4" />}
                    {selectedAsset.mode === 'ROAD' && <Truck className="h-4 w-4" />}
                    {selectedAsset.mode === 'AIR' && <Plane className="h-4 w-4" />}
                  </div>
                  <div>
                    <h3 className="text-xs font-mono font-bold text-white uppercase">{selectedAsset.name}</h3>
                    <span className="text-[10px] font-mono text-[#8E9299]">{selectedAsset.carrier} • {selectedAsset.registrationOrImo}</span>
                  </div>
                </div>
              </div>

              {/* Capacity Progress Gauges */}
              <div className="space-y-2.5 bg-[#11141B] p-3.5 rounded-sm border border-[#2D3139] font-mono">
                <div className="flex justify-between text-xs">
                  <span className="text-[#8E9299]">Spare TEU Capacity:</span>
                  <span className="font-bold text-emerald-400">{selectedAsset.spareTeu} / {selectedAsset.totalTeu} TEU</span>
                </div>
                <div className="w-full bg-[#151921] rounded-none h-1.5 border border-[#2D3139]">
                  <div
                    className="bg-emerald-500 h-1.5"
                    style={{ width: `${((selectedAsset.bookedTeu / selectedAsset.totalTeu) * 100).toFixed(0)}%` }}
                  />
                </div>

                <div className="flex justify-between text-xs pt-1">
                  <span className="text-[#8E9299]">Spare Weight Cap:</span>
                  <span className="font-bold text-emerald-400">{selectedAsset.spareWeightTonnes} / {selectedAsset.totalWeightTonnes} t</span>
                </div>

                <div className="flex justify-between text-xs pt-1">
                  <span className="text-[#8E9299]">Reefer Plugs:</span>
                  <span className="font-bold text-amber-400">{selectedAsset.spareReeferPlugs} plugs available</span>
                </div>
              </div>

              {/* Leg-by-Leg Route Breakdown */}
              <div className="space-y-2 font-mono">
                <h4 className="text-[10px] font-bold text-emerald-500 uppercase tracking-wider">
                  Leg Breakdown ({selectedAsset.legs.length} legs)
                </h4>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {selectedAsset.legs.map((leg, idx) => (
                    <div key={leg.id} className="p-2.5 bg-[#11141B] rounded-sm border border-[#2D3139] text-xs space-y-1">
                      <div className="flex justify-between font-bold text-white">
                        <span>L{idx + 1}: {leg.originName} → {leg.destinationName}</span>
                        <span className="text-emerald-400">{leg.spareTeu} TEU</span>
                      </div>
                      <div className="flex justify-between text-[#8E9299] text-[10px]">
                        <span>ETD: {leg.etd.slice(0, 10)}</span>
                        <span>Cost: £{leg.costPerTeuLeg}/TEU</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-[#11141B] border border-emerald-500/30 rounded-sm text-xs font-mono text-emerald-400">
                <strong>Capacity Value:</strong> Unbooked TEUs estimated at <strong>£{(selectedAsset.spareTeu * 480).toLocaleString()}</strong>.
              </div>
            </div>
          ) : selectedPort ? (
            <div className="space-y-4">
              <div className="border-b border-[#2D3139] pb-3 font-mono">
                <h3 className="text-sm font-bold text-white uppercase">{selectedPort.name} ({selectedPort.code})</h3>
                <span className="text-[10px] text-[#8E9299]">{selectedPort.country} • {selectedPort.type}</span>
              </div>
              <div className="p-3.5 bg-[#11141B] rounded-sm border border-[#2D3139] space-y-2 font-mono">
                <div className="text-xs text-[#8E9299]">Container Balance:</div>
                <div className={`text-xl font-bold ${
                  (selectedPort.currentContainerSurplus || 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}>
                  {selectedPort.currentContainerSurplus && selectedPort.currentContainerSurplus > 0 ? `+${selectedPort.currentContainerSurplus}` : selectedPort.currentContainerSurplus} TEU
                </div>
                <p className="text-[11px] text-[#8E9299] font-sans">
                  {(selectedPort.currentContainerSurplus || 0) < 0 
                    ? 'In deficit. Ideal target for empty container repositioning from Asian surplus hubs.' 
                    : 'In surplus. High priority for loading outbound laden cargo or repositioning.'}
                </p>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-[#8E9299] text-xs font-mono">
              <Info className="h-6 w-6 mx-auto mb-2 opacity-50" />
              <span>Select port node or vessel asset on the map to inspect capacity details.</span>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
