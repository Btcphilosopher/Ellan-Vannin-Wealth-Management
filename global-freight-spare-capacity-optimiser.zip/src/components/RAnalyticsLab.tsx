import React, { useState } from 'react';
import { CapacityAsset } from '../types';
import { calculateProbabilisticBookingModel, runMonteCarloDemandForecast } from '../engine/rAnalytics';
import { BarChart3, TrendingUp, Sliders, Play, RefreshCw, Cpu } from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend
} from 'recharts';

interface RAnalyticsLabProps {
  assets: CapacityAsset[];
  currencySymbol: string;
}

export const RAnalyticsLab: React.FC<RAnalyticsLabProps> = ({
  assets,
  currencySymbol,
}) => {
  const [selectedAsset, setSelectedAsset] = useState<CapacityAsset>(assets[0]);
  const [daysToDeparture, setDaysToDeparture] = useState<number>(7);
  const [activeScenarioRoute, setActiveScenarioRoute] = useState<string>('Shanghai → Rotterdam');

  const probModel = calculateProbabilisticBookingModel(selectedAsset, daysToDeparture);
  const scenarios = runMonteCarloDemandForecast(activeScenarioRoute, 850);

  // Recharts Monte Carlo demand distribution dataset
  const forecastChartData = scenarios.map((s) => ({
    scenario: s.scenarioName.replace('_', ' '),
    P10: s.p10TeuDemand,
    P50: s.p50TeuDemand,
    P90: s.p90TeuDemand,
    Robustness: s.robustnessScorePct
  }));

  // Benchmark algorithm solver comparison data
  const solverBenchmarkData = [
    { algorithm: 'MILP (Exact)', executionMs: 42, optimalityScore: 100 },
    { algorithm: 'Min-Cost Flow', executionMs: 8, optimalityScore: 94 },
    { algorithm: 'Dynamic Prog', executionMs: 14, optimalityScore: 96 },
    { algorithm: 'Heuristics Engine', executionMs: 3, optimalityScore: 89 },
    { algorithm: 'Robust Scenario', executionMs: 65, optimalityScore: 98 },
  ];

  return (
    <div className="space-y-6 font-mono">
      
      {/* Top Header Banner */}
      <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-emerald-500 text-[10px] font-bold tracking-[0.2em] uppercase mb-1">
            <BarChart3 className="h-3.5 w-3.5" />
            <span>R Analytics Engine & Probabilistic Booking Workbench (Section 12 & 27)</span>
          </div>
          <h2 className="text-base font-bold text-white tracking-tight uppercase">
            Monte Carlo & Robust Optimisation Workbench
          </h2>
          <p className="text-xs text-[#8E9299] mt-0.5 font-sans">
            Simulating demand curves (P10, P50, P90), holding vs selling EV thresholds, dynamic pricing curves, and robust solver stress testing.
          </p>
        </div>

        <div className="px-3.5 py-2 bg-[#11141B] rounded-sm border border-[#2D3139] text-xs text-right">
          <span className="text-[#8E9299] block text-[10px] uppercase font-bold">R Kernel Packages</span>
          <span className="text-[10px] font-bold text-emerald-400">tidyverse, fable, forecast, duckdb</span>
        </div>
      </div>

      {/* Main Grid split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Left Card: Probabilistic Capacity Booking Calculator (Section 12 & 16) */}
        <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-4">
          <div className="border-b border-[#2D3139] pb-2.5">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-2">
              <Sliders className="h-3.5 w-3.5 text-emerald-500" />
              <span>Probabilistic Booking Calculator</span>
            </h3>
            <span className="text-[10px] text-[#8E9299]">Section 12: P(Capacity Sold) & Dynamic Pricing</span>
          </div>

          <div className="space-y-3.5 text-xs">
            <div>
              <label className="text-[#8E9299] block mb-1 uppercase text-[10px]">Select Voyage Asset</label>
              <select
                value={selectedAsset.id}
                onChange={(e) => {
                  const a = assets.find(item => item.id === e.target.value);
                  if (a) setSelectedAsset(a);
                }}
                className="w-full bg-[#11141B] text-white p-2 rounded-sm border border-[#2D3139] focus:outline-none focus:border-emerald-500 text-xs font-mono"
              >
                {assets.map((a) => (
                  <option key={a.id} value={a.id}>{a.name} ({a.spareTeu} TEU spare)</option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex justify-between text-[#8E9299] text-[10px] uppercase mb-1">
                <span>Days to Departure:</span>
                <span className="font-bold text-emerald-400">{daysToDeparture} Days</span>
              </div>
              <input
                type="range"
                min={1}
                max={30}
                value={daysToDeparture}
                onChange={(e) => setDaysToDeparture(Number(e.target.value))}
                className="w-full accent-emerald-500 bg-[#11141B]"
              />
            </div>

            {/* Probability Output Stats */}
            <div className="p-3 bg-[#11141B] rounded-sm border border-[#2D3139] space-y-2 text-xs">
              <div className="flex justify-between text-[10px] uppercase">
                <span className="text-[#8E9299]">P(Capacity Sold):</span>
                <span className="font-bold text-emerald-400">{(probModel.probCapacitySold * 100).toFixed(0)}%</span>
              </div>
              <div className="flex justify-between text-[10px] uppercase">
                <span className="text-[#8E9299]">P(Capacity Remaining):</span>
                <span className="font-bold text-amber-400">{(probModel.probCapacityRemaining * 100).toFixed(0)}%</span>
              </div>
              <div className="flex justify-between text-[10px] uppercase">
                <span className="text-[#8E9299]">EV(Holding Capacity):</span>
                <span className="font-bold text-emerald-400">{currencySymbol}{probModel.expectedValueHoldGbp.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[10px] uppercase">
                <span className="text-[#8E9299]">EV(Selling Now):</span>
                <span className="font-bold text-white">{currencySymbol}{probModel.expectedValueSellNowGbp.toLocaleString()}</span>
              </div>
            </div>

            {/* Dynamic Freight Pricing Thresholds (Section 16) */}
            <div className="space-y-1.5 pt-2 border-t border-[#2D3139]">
              <div className="font-bold text-[#8E9299] text-[10px] uppercase">Pricing Thresholds:</div>
              <div className="grid grid-cols-3 gap-1.5 text-[10px] text-center">
                <div className="p-1.5 bg-[#11141B] rounded-sm border border-[#2D3139]">
                  <span className="text-[#8E9299] block text-[9px] uppercase">Min Price</span>
                  <span className="font-bold text-white">{currencySymbol}{probModel.minAcceptablePriceGbp}</span>
                </div>
                <div className="p-1.5 bg-[#11141B] rounded-sm border border-[#2D3139]">
                  <span className="text-emerald-400 block text-[9px] uppercase font-bold">Target</span>
                  <span className="font-bold text-emerald-400">{currencySymbol}{probModel.targetPriceGbp}</span>
                </div>
                <div className="p-1.5 bg-[#11141B] rounded-sm border border-[#2D3139]">
                  <span className="text-emerald-400 block text-[9px] uppercase font-bold">Max Market</span>
                  <span className="font-bold text-emerald-400">{currencySymbol}{probModel.maxMarketPriceGbp}</span>
                </div>
              </div>
            </div>

            <div className="p-2.5 bg-[#11141B] rounded-sm border border-emerald-500/30 text-emerald-400 font-bold text-center uppercase text-xs">
              Action: {probModel.recommendedAction.replace(/_/g, ' ')}
            </div>

          </div>
        </div>

        {/* Right Charts & Scenario Stress-Tester */}
        <div className="lg:col-span-2 space-y-5">
          
          {/* Chart 1: Monte Carlo Demand Forecast (Section 25) */}
          <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-3">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-2">
                  <TrendingUp className="h-3.5 w-3.5 text-emerald-500" />
                  <span>Monte Carlo Demand Forecasting (P10, P50, P90)</span>
                </h3>
                <span className="text-[10px] text-[#8E9299]">R Package Simulation output across 10,000 iterations</span>
              </div>
            </div>

            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={forecastChartData} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
                  <XAxis dataKey="scenario" stroke="#8E9299" fontSize={10} />
                  <YAxis stroke="#8E9299" fontSize={10} unit=" TEU" />
                  <Tooltip contentStyle={{ backgroundColor: '#11141B', borderColor: '#2D3139', color: '#fff', fontSize: '11px' }} />
                  <Legend wrapperStyle={{ fontSize: '10px', color: '#8E9299' }} />
                  <Area type="monotone" dataKey="P10" stackId="1" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} />
                  <Area type="monotone" dataKey="P50" stackId="2" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                  <Area type="monotone" dataKey="P90" stackId="3" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.4} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 2: Rust Solver Algorithm Performance Comparison (Section 28 & 29) */}
          <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-3">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-2">
                  <Cpu className="h-3.5 w-3.5 text-emerald-500" />
                  <span>Rust Optimization Algorithm Performance (Section 29)</span>
                </h3>
                <span className="text-[10px] text-[#8E9299]">Comparing execution speed (ms) vs optimality score %</span>
              </div>
            </div>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={solverBenchmarkData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                  <XAxis dataKey="algorithm" stroke="#8E9299" fontSize={10} />
                  <YAxis stroke="#8E9299" fontSize={10} />
                  <Tooltip contentStyle={{ backgroundColor: '#11141B', borderColor: '#2D3139', color: '#fff', fontSize: '11px' }} />
                  <Legend wrapperStyle={{ fontSize: '10px', color: '#8E9299' }} />
                  <Bar dataKey="optimalityScore" fill="#10b981" name="Optimality Score %" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="executionMs" fill="#8b5cf6" name="Execution Time (ms)" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
