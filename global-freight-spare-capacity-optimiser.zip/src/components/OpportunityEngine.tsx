import React, { useState } from 'react';
import { MatchOpportunity } from '../types';
import { Sparkles, CheckCircle, AlertTriangle, XCircle, ArrowRight, ShieldCheck } from 'lucide-react';

interface OpportunityEngineProps {
  opportunities: MatchOpportunity[];
  currencySymbol: string;
  currencyMultiplier: number;
  onExecuteMatch: (matchId: string) => void;
}

export const OpportunityEngine: React.FC<OpportunityEngineProps> = ({
  opportunities,
  currencySymbol,
  currencyMultiplier,
  onExecuteMatch,
}) => {
  const [selectedOpportunity, setSelectedOpportunity] = useState<MatchOpportunity | null>(opportunities[0] || null);

  const formatMoney = (val: number) => {
    return `${currencySymbol}${(val * currencyMultiplier).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] flex flex-col sm:flex-row sm:items-center justify-between gap-4 font-mono">
        <div>
          <div className="flex items-center space-x-2 text-emerald-500 text-[10px] font-bold uppercase tracking-[0.2em] mb-1">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Matching & Revenue Optimiser</span>
          </div>
          <h2 className="text-base font-bold text-white tracking-tight uppercase">
            Capacity Opportunities Ranking Engine
          </h2>
          <p className="text-xs text-[#8E9299] mt-1 font-sans">
            Matching cargo demand with candidate slots, evaluating physical compatibility, timing, customs, and net marginal contribution.
          </p>
        </div>

        <div className="px-3.5 py-2 bg-[#11141B] rounded-sm border border-[#2D3139] text-xs text-right">
          <span className="text-[#8E9299] block text-[10px] uppercase">Total Unlocked Margin</span>
          <span className="text-base font-bold text-emerald-400">
            {formatMoney(opportunities.reduce((acc, o) => acc + o.netContributionGbp, 0))}
          </span>
        </div>
      </div>

      {/* Main Grid View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Left Column: Ranked Opportunity List */}
        <div className="lg:col-span-2 space-y-2.5 font-mono">
          {opportunities.map((opp, idx) => {
            const isSelected = selectedOpportunity?.id === opp.id;
            const compat = opp.physicalCompatibility;

            return (
              <div
                key={opp.id}
                onClick={() => setSelectedOpportunity(opp)}
                className={`cursor-pointer rounded-sm p-4 border transition-all ${
                  isSelected
                    ? 'bg-[#151921] border-emerald-500/80 shadow-[0_0_10px_rgba(16,185,129,0.15)]'
                    : 'bg-[#11141B] border-[#2D3139] hover:border-[#3d424c]'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  
                  <div className="space-y-1.5 max-w-lg">
                    <div className="flex items-center space-x-2">
                      <span className="w-5 h-5 rounded-sm bg-[#151921] text-emerald-400 border border-emerald-500/40 text-[10px] font-bold flex items-center justify-center">
                        #{idx + 1}
                      </span>
                      <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                        {opp.cargo.origin.name} → {opp.cargo.destination.name}
                      </h3>
                      <span className="px-1.5 py-0.5 text-[9px] font-bold bg-[#151921] text-[#8E9299] rounded-sm border border-[#2D3139] uppercase">
                        {opp.asset.mode}
                      </span>
                    </div>

                    <p className="text-xs text-[#E0E0E0] font-sans leading-normal">
                      Allocating <strong className="text-emerald-400 font-mono">{opp.allocatedTeu} TEU</strong> on <strong className="text-white">{opp.asset.name}</strong> for <strong className="text-white">{opp.cargo.customerName}</strong>.
                    </p>

                    <div className="flex flex-wrap items-center gap-3 text-[10px] text-[#8E9299] pt-0.5">
                      <div className="flex items-center space-x-1">
                        {compat.status === 'COMPATIBLE' && <CheckCircle className="h-3 w-3 text-emerald-400" />}
                        {compat.status === 'CONDITIONALLY_COMPATIBLE' && <AlertTriangle className="h-3 w-3 text-amber-400" />}
                        {compat.status === 'INCOMPATIBLE' && <XCircle className="h-3 w-3 text-rose-400" />}
                        <span className="font-bold">{compat.status}</span>
                      </div>
                      <span>•</span>
                      <span>P(UNSOLD): <strong className="text-amber-400">{(opp.probabilityOfUnsoldWithoutMatch * 100).toFixed(0)}%</strong></span>
                      <span>•</span>
                      <span>EMPTY SAVED: <strong className="text-emerald-400">{opp.avoidedEmptyRepositioningTeu} TEU</strong></span>
                    </div>
                  </div>

                  {/* Financial Metrics Box */}
                  <div className="sm:text-right border-t sm:border-t-0 pt-2 sm:pt-0 border-[#2D3139] flex sm:flex-col justify-between items-center sm:items-end shrink-0">
                    <div>
                      <span className="text-[10px] text-[#8E9299] uppercase font-bold block">Net Contribution</span>
                      <span className="text-lg font-bold text-emerald-400">
                        +{formatMoney(opp.netContributionGbp)}
                      </span>
                      <span className="text-[10px] text-[#8E9299] block">
                        ({formatMoney(opp.marginalValuePerTeuGbp)} / TEU)
                      </span>
                    </div>

                    <button
                      onClick={(e) => { e.stopPropagation(); onExecuteMatch(opp.id); }}
                      className="mt-2 px-3 py-1 text-[11px] font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-sm uppercase tracking-wider transition-all"
                    >
                      Execute
                    </button>
                  </div>

                </div>
              </div>
            );
          })}
        </div>

        {/* Right Column: Detailed Economics & Constraint Breakdown */}
        {selectedOpportunity && (
          <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-4 sticky top-20 font-mono">
            <div>
              <span className="text-[10px] text-emerald-500 font-bold uppercase tracking-[0.15em]">
                MATCH DEEP-DIVE ANALYSIS
              </span>
              <h3 className="text-sm font-bold text-white uppercase mt-0.5">
                {selectedOpportunity.cargo.customerName}
              </h3>
              <p className="text-[10px] text-[#8E9299]">
                Matched on {selectedOpportunity.asset.name}
              </p>
            </div>

            {/* Economic Waterfall Breakdown */}
            <div className="space-y-1.5 bg-[#11141B] p-3.5 rounded-sm border border-[#2D3139] text-xs">
              <div className="font-bold text-white border-b border-[#2D3139] pb-2 text-[11px] uppercase tracking-wider">
                Economic Calculation (Section 14)
              </div>
              
              <div className="flex justify-between text-[#E0E0E0] pt-1">
                <span>Gross Freight Revenue:</span>
                <span className="font-bold text-emerald-400">+{formatMoney(selectedOpportunity.grossRevenueGbp)}</span>
              </div>
              <div className="flex justify-between text-[#8E9299]">
                <span>- Transport Cost:</span>
                <span className="text-rose-400">-{formatMoney(selectedOpportunity.incrementalTransportCostGbp)}</span>
              </div>
              <div className="flex justify-between text-[#8E9299]">
                <span>- Terminal Handling:</span>
                <span className="text-rose-400">-{formatMoney(selectedOpportunity.handlingCostGbp)}</span>
              </div>
              <div className="flex justify-between text-[#8E9299]">
                <span>- Fuel Surcharge:</span>
                <span className="text-rose-400">-{formatMoney(selectedOpportunity.fuelCostGbp)}</span>
              </div>
              <div className="flex justify-between text-[#8E9299]">
                <span>- Repositioning Delta:</span>
                <span className={selectedOpportunity.repositioningCostGbp < 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {selectedOpportunity.repositioningCostGbp < 0 ? `+${formatMoney(-selectedOpportunity.repositioningCostGbp)}` : `-${formatMoney(selectedOpportunity.repositioningCostGbp)}`}
                </span>
              </div>
              <div className="flex justify-between text-[#8E9299]">
                <span>- Expected Risk (Delay/Fail):</span>
                <span className="text-rose-400">-{formatMoney(selectedOpportunity.expectedDelayCostGbp + selectedOpportunity.expectedFailureCostGbp)}</span>
              </div>
              <div className="flex justify-between text-[#8E9299] pb-2 border-b border-[#2D3139]">
                <span>- Opportunity Cost:</span>
                <span className="text-rose-400">-{formatMoney(selectedOpportunity.capacityOpportunityCostGbp)}</span>
              </div>

              <div className="flex justify-between text-xs font-bold text-white pt-2 uppercase">
                <span>Net Contribution Margin:</span>
                <span className="text-emerald-400">+{formatMoney(selectedOpportunity.netContributionGbp)}</span>
              </div>
            </div>

            {/* Constraint Verification Checklist */}
            <div className="space-y-2">
              <div className="text-[10px] font-bold text-emerald-500 uppercase tracking-wider flex items-center space-x-1">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                <span>Physical & Operational Verification</span>
              </div>

              <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                <div className="p-2 bg-[#11141B] rounded-sm border border-[#2D3139] flex items-center space-x-1.5">
                  <CheckCircle className="h-3 w-3 text-emerald-400" />
                  <span className="text-[#E0E0E0]">Weight & Vol</span>
                </div>
                <div className="p-2 bg-[#11141B] rounded-sm border border-[#2D3139] flex items-center space-x-1.5">
                  <CheckCircle className="h-3 w-3 text-emerald-400" />
                  <span className="text-[#E0E0E0]">Container Spec</span>
                </div>
                <div className="p-2 bg-[#11141B] rounded-sm border border-[#2D3139] flex items-center space-x-1.5">
                  <CheckCircle className="h-3 w-3 text-emerald-400" />
                  <span className="text-[#E0E0E0]">Hazmat Check</span>
                </div>
                <div className="p-2 bg-[#11141B] rounded-sm border border-[#2D3139] flex items-center space-x-1.5">
                  <CheckCircle className="h-3 w-3 text-emerald-400" />
                  <span className="text-[#E0E0E0]">Transit Window</span>
                </div>
              </div>
            </div>

            {/* Action Button */}
            <button
              onClick={() => onExecuteMatch(selectedOpportunity.id)}
              className="w-full py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-sm uppercase tracking-wider transition-all flex items-center justify-center space-x-2 shadow-[0_0_8px_#10B981]"
            >
              <span>Confirm & Lock Booking</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

      </div>

    </div>
  );
};
