import React from 'react';
import { CargoConsolidationGroup, CapacityAsset } from '../types';
import { Box, Truck, TrendingUp, Sparkles, CheckCircle2 } from 'lucide-react';

interface ConsolidationBackhaulProps {
  consolidationGroups: CargoConsolidationGroup[];
  backhaulAssets: CapacityAsset[];
  currencySymbol: string;
}

export const ConsolidationBackhaul: React.FC<ConsolidationBackhaulProps> = ({
  consolidationGroups,
  backhaulAssets,
  currencySymbol,
}) => {
  return (
    <div className="space-y-6 font-mono">
      
      {/* Header Banner */}
      <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-emerald-500 text-[10px] font-bold tracking-[0.2em] uppercase mb-1">
            <Box className="h-3.5 w-3.5" />
            <span>Cargo Consolidation & Empty Mile Reduction</span>
          </div>
          <h2 className="text-base font-bold text-white tracking-tight uppercase">
            LCL Consolidation & Backhaul Engine
          </h2>
          <p className="text-xs text-[#8E9299] mt-0.5 font-sans">
            Combining partial shipments into FCL or rail wagons to maximize volume and weight utilization while capturing empty return haul opportunities.
          </p>
        </div>

        <div className="px-3.5 py-2 bg-[#11141B] rounded-sm border border-[#2D3139] text-xs text-right">
          <span className="text-[#8E9299] block text-[10px] uppercase font-bold">Empty Mile Reduction</span>
          <span className="text-base font-bold text-emerald-400">-4,820 km Saved</span>
        </div>
      </div>

      {/* Main Grid View */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        
        {/* Left Card: Cargo Consolidation Groups (Section 20 & 21) */}
        <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-3">
          <div className="flex items-center justify-between border-b border-[#2D3139] pb-2.5">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-2">
              <Sparkles className="h-3.5 w-3.5 text-emerald-500" />
              <span>Consolidation Groups ({consolidationGroups.length})</span>
            </h3>
            <span className="text-[10px] text-emerald-400 font-bold uppercase">FCL 40ft HC Packing</span>
          </div>

          <div className="space-y-2.5">
            {consolidationGroups.map((group) => (
              <div key={group.id} className="p-3.5 bg-[#11141B] rounded-sm border border-[#2D3139] space-y-2.5">
                <div className="flex justify-between items-start text-xs">
                  <div>
                    <span className="font-bold text-white uppercase">{group.id.toUpperCase()}</span>
                    <span className="text-[#8E9299] text-[10px] block">{group.shipments.length} Combined Shipments</span>
                  </div>
                  <span className="px-2 py-0.5 bg-[#151921] text-emerald-400 border border-emerald-500/40 rounded-sm font-bold text-[10px]">
                    SAVED {currencySymbol}{group.savingsGeneratedGbp.toLocaleString()}
                  </span>
                </div>

                {/* Utilisation Gauges (Section 21) */}
                <div className="space-y-2 text-xs">
                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8E9299] text-[10px] uppercase">
                      <span>Volume Utilisation:</span>
                      <span className="font-bold text-emerald-400">{group.volumeUtilisationPct}% ({group.totalVolumeM3} / {group.containerVolumeCapM3} m³)</span>
                    </div>
                    <div className="w-full bg-[#151921] h-1.5 border border-[#2D3139]">
                      <div className="bg-emerald-500 h-1.5" style={{ width: `${group.volumeUtilisationPct}%` }} />
                    </div>
                  </div>

                  <div className="space-y-1 pt-0.5">
                    <div className="flex justify-between text-[#8E9299] text-[10px] uppercase">
                      <span>Weight Utilisation:</span>
                      <span className="font-bold text-emerald-400">{group.weightUtilisationPct}% ({group.totalWeightTonnes} / {group.containerWeightCapTonnes} t)</span>
                    </div>
                    <div className="w-full bg-[#151921] h-1.5 border border-[#2D3139]">
                      <div className="bg-emerald-500 h-1.5" style={{ width: `${group.weightUtilisationPct}%` }} />
                    </div>
                  </div>
                </div>

                <div className="text-[10px] text-[#8E9299] border-t border-[#2D3139] pt-2 flex justify-between uppercase">
                  <span>Economic Value: <strong className="text-white">{currencySymbol}{group.economicUtilisationGbp.toLocaleString()}</strong></span>
                  <span className="text-emerald-400 font-bold">Ready for FCL Stuffing</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Card: Backhaul Opportunities (Section 23 & 24) */}
        <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-3">
          <div className="flex items-center justify-between border-b border-[#2D3139] pb-2.5">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-2">
              <Truck className="h-3.5 w-3.5 text-amber-400" />
              <span>Backhaul Opportunities (Section 23)</span>
            </h3>
            <span className="text-[10px] text-amber-400 font-bold uppercase">Return Trip Pairing</span>
          </div>

          <div className="space-y-2.5">
            {backhaulAssets.map((asset) => (
              <div key={asset.id} className="p-3.5 bg-[#11141B] rounded-sm border border-[#2D3139] space-y-2.5">
                <div className="flex justify-between items-start text-xs">
                  <div>
                    <h4 className="font-bold text-white uppercase">{asset.name}</h4>
                    <span className="text-[#8E9299] text-[10px] block">{asset.carrier} • {asset.subType}</span>
                  </div>
                  <span className="px-1.5 py-0.5 bg-amber-500/20 text-amber-400 font-bold rounded-sm border border-amber-500/40 text-[9px] uppercase">
                    100% EMPTY BACKHAUL
                  </span>
                </div>

                <div className="p-2.5 bg-[#151921] rounded-sm text-xs space-y-1 border border-[#2D3139]">
                  <div className="flex justify-between text-white font-bold text-[11px] uppercase">
                    <span>Return Route: {asset.origin.name} → {asset.destination.name}</span>
                  </div>
                  <div className="flex justify-between text-[#8E9299] text-[10px]">
                    <span>Capacity: {asset.spareTeu} TEU / {asset.spareWeightTonnes}t</span>
                    <span>ETD: {asset.etd.slice(0, 10)}</span>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs pt-0.5">
                  <span className="text-[#8E9299] text-[10px] uppercase font-bold">Incremental Margin:</span>
                  <span className="font-bold text-emerald-400 text-sm">+{currencySymbol}18,400</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
