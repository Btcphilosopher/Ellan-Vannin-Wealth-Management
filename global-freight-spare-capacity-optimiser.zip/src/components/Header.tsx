import React from 'react';
import { Ship, Cpu, RefreshCw, Sparkles, BarChart3 } from 'lucide-react';

interface HeaderProps {
  selectedCurrency: 'GBP' | 'USD' | 'EUR';
  setSelectedCurrency: (curr: 'GBP' | 'USD' | 'EUR') => void;
  onOpenCopilot: () => void;
  onRunOptimization: () => void;
  isOptimizing: boolean;
  algorithm: string;
  setAlgorithm: (alg: any) => void;
}

export const Header: React.FC<HeaderProps> = ({
  selectedCurrency,
  setSelectedCurrency,
  onOpenCopilot,
  onRunOptimization,
  isOptimizing,
  algorithm,
  setAlgorithm,
}) => {
  const currencySymbol = selectedCurrency === 'GBP' ? '£' : selectedCurrency === 'USD' ? '$' : '€';

  return (
    <header className="bg-[#151921] border-b border-[#2D3139] text-[#E0E0E0] sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-emerald-500 rounded-sm flex items-center justify-center shrink-0 shadow-[0_0_8px_#10B981]">
              <Ship className="h-5 w-5 text-[#0F1115]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-base font-bold tracking-tighter uppercase text-white font-mono">
                  CAPACITY.OPTIMISER <span className="text-emerald-500 font-mono text-xs ml-1">v4.1.0-STABLE</span>
                </h1>
              </div>
              <p className="text-[10px] text-[#8E9299] uppercase tracking-wider hidden sm:block">
                Multi-Modal Freight Capacity & Empty Repositioning Engine
              </p>
            </div>
          </div>

          {/* Engine Status & Selector */}
          <div className="hidden lg:flex items-center space-x-6 text-[11px] font-mono uppercase tracking-wider text-[#8E9299] bg-[#11141B] px-3.5 py-1.5 rounded-sm border border-[#2D3139]">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10B981] animate-pulse"></span>
              <span>R-Engine: <strong className="text-emerald-500">Sync</strong></span>
            </div>
            <div className="h-3 w-px bg-[#2D3139]" />
            <div className="flex items-center space-x-2">
              <Cpu className="h-3.5 w-3.5 text-emerald-500" />
              <span>Solver:</span>
              <select
                value={algorithm}
                onChange={(e) => setAlgorithm(e.target.value)}
                className="bg-[#151921] text-emerald-400 font-mono text-[11px] px-2 py-0.5 rounded-sm border border-[#2D3139] focus:outline-none focus:border-emerald-500"
              >
                <option value="MILP">MILP (Exact)</option>
                <option value="MIN_COST_FLOW">Min-Cost Flow Graph</option>
                <option value="DYNAMIC_PROGRAMMING">Dynamic Programming</option>
                <option value="HEURISTICS">Heuristics Engine</option>
                <option value="ROBUST_OPTIMISATION">Robust Scenario Solver</option>
              </select>
            </div>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center space-x-3">
            {/* Currency Selector */}
            <div className="flex bg-[#11141B] rounded-sm p-0.5 border border-[#2D3139] font-mono text-[11px]">
              {(['GBP', 'USD', 'EUR'] as const).map((curr) => (
                <button
                  key={curr}
                  onClick={() => setSelectedCurrency(curr)}
                  className={`px-2 py-0.5 rounded-sm transition-colors ${
                    selectedCurrency === curr
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'text-[#8E9299] hover:text-white'
                  }`}
                >
                  {curr === 'GBP' ? '£ GBP' : curr === 'USD' ? '$ USD' : '€ EUR'}
                </button>
              ))}
            </div>

            {/* AI Copilot Button */}
            <button
              onClick={onOpenCopilot}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-sm text-[11px] font-mono font-bold uppercase tracking-wider bg-[#2D3139] hover:bg-[#3d424c] text-emerald-400 border border-emerald-500/30 transition-all"
            >
              <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
              <span className="hidden sm:inline">AI Copilot</span>
            </button>

            {/* Run Solver Button */}
            <button
              onClick={onRunOptimization}
              disabled={isOptimizing}
              className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-sm text-[11px] font-mono font-bold uppercase tracking-widest text-white bg-emerald-600 hover:bg-emerald-500 transition-all ${
                isOptimizing ? 'opacity-70 cursor-wait' : ''
              }`}
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isOptimizing ? 'animate-spin' : ''}`} />
              <span>{isOptimizing ? 'SOLVING...' : 'RUN SOLVER'}</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
