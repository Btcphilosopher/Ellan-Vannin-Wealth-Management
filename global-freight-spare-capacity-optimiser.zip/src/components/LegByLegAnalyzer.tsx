import React, { useState } from 'react';
import { CapacityAsset, VoyageLeg } from '../types';
import { Ship, Train, Truck, Plane, Layers, Box, AlertCircle, ChevronRight } from 'lucide-react';

interface LegByLegAnalyzerProps {
  assets: CapacityAsset[];
  currencySymbol: string;
}

export const LegByLegAnalyzer: React.FC<LegByLegAnalyzerProps> = ({
  assets,
  currencySymbol,
}) => {
  const [activeTabMode, setActiveTabMode] = useState<'MARITIME' | 'RAIL' | 'ROAD' | 'AIR'>('MARITIME');
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id || '');

  const filteredAssets = assets.filter(a => a.mode === activeTabMode);
  const selectedAsset = assets.find(a => a.id === selectedAssetId) || filteredAssets[0] || assets[0];

  return (
    <div className="space-y-6 font-mono">
      
      {/* Mode Switcher Banner */}
      <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xs font-bold text-white uppercase tracking-[0.15em] flex items-center space-x-2">
            <Layers className="h-4 w-4 text-emerald-500" />
            <span>Multi-Modal Leg-by-Leg Capacity Inspector</span>
          </h2>
          <p className="text-xs text-[#8E9299] mt-0.5 font-sans">
            Model intermediate leg utilisation simultaneously across ocean voyages, train paths, road backhauls, and air ULDs.
          </p>
        </div>

        {/* Tab buttons */}
        <div className="flex space-x-1 bg-[#11141B] p-1 rounded-sm border border-[#2D3139] text-xs">
          <button
            onClick={() => { setActiveTabMode('MARITIME'); setSelectedAssetId(assets.find(a => a.mode === 'MARITIME')?.id || ''); }}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded-sm text-[11px] font-bold uppercase transition-colors ${
              activeTabMode === 'MARITIME' ? 'bg-emerald-600 text-white shadow-[0_0_8px_#10B981]' : 'text-[#8E9299] hover:text-white'
            }`}
          >
            <Ship className="h-3.5 w-3.5" />
            <span>Maritime Ships</span>
          </button>
          <button
            onClick={() => { setActiveTabMode('RAIL'); setSelectedAssetId(assets.find(a => a.mode === 'RAIL')?.id || ''); }}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded-sm text-[11px] font-bold uppercase transition-colors ${
              activeTabMode === 'RAIL' ? 'bg-emerald-600 text-white shadow-[0_0_8px_#10B981]' : 'text-[#8E9299] hover:text-white'
            }`}
          >
            <Train className="h-3.5 w-3.5" />
            <span>Rail Corridors</span>
          </button>
          <button
            onClick={() => { setActiveTabMode('ROAD'); setSelectedAssetId(assets.find(a => a.mode === 'ROAD')?.id || ''); }}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded-sm text-[11px] font-bold uppercase transition-colors ${
              activeTabMode === 'ROAD' ? 'bg-emerald-600 text-white shadow-[0_0_8px_#10B981]' : 'text-[#8E9299] hover:text-white'
            }`}
          >
            <Truck className="h-3.5 w-3.5" />
            <span>Road Backhaul</span>
          </button>
          <button
            onClick={() => { setActiveTabMode('AIR'); setSelectedAssetId(assets.find(a => a.mode === 'AIR')?.id || ''); }}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded-sm text-[11px] font-bold uppercase transition-colors ${
              activeTabMode === 'AIR' ? 'bg-emerald-600 text-white shadow-[0_0_8px_#10B981]' : 'text-[#8E9299] hover:text-white'
            }`}
          >
            <Plane className="h-3.5 w-3.5" />
            <span>Air Cargo</span>
          </button>
        </div>
      </div>

      {/* Main Split Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Asset Selector List */}
        <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-3">
          <h3 className="text-[10px] font-bold text-emerald-500 uppercase tracking-[0.15em]">
            Available {activeTabMode} Assets ({filteredAssets.length})
          </h3>
          <div className="space-y-2">
            {filteredAssets.map((asset) => {
              const isSelected = selectedAsset?.id === asset.id;
              const bookedPct = ((asset.bookedTeu / asset.totalTeu) * 100).toFixed(0);

              return (
                <div
                  key={asset.id}
                  onClick={() => setSelectedAssetId(asset.id)}
                  className={`cursor-pointer p-3.5 rounded-sm border transition-all ${
                    isSelected
                      ? 'bg-[#11141B] border-emerald-500/80 shadow-[0_0_8px_rgba(16,185,129,0.15)]'
                      : 'bg-[#11141B] border-[#2D3139] hover:border-[#3d424c]'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <h4 className="text-xs font-bold text-white uppercase">{asset.name}</h4>
                    <span className="text-[10px] font-bold text-emerald-400 bg-[#151921] px-1.5 py-0.5 rounded-sm border border-[#2D3139]">
                      {asset.spareTeu} TEU SPARE
                    </span>
                  </div>
                  <div className="text-[10px] text-[#8E9299] mt-1">
                    ROUTE: {asset.origin.name} → {asset.destination.name}
                  </div>
                  <div className="mt-2 w-full bg-[#151921] h-1.5 border border-[#2D3139]">
                    <div
                      className="bg-emerald-500 h-1.5"
                      style={{ width: `${bookedPct}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-[#8E9299] mt-1">
                    <span>{bookedPct}% BOOKED</span>
                    <span>{asset.legs.length} LEGS</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Leg-by-Leg Matrix Drilldown */}
        {selectedAsset && (
          <div className="lg:col-span-2 bg-[#151921] rounded-sm p-5 border border-[#2D3139] space-y-5">
            
            {/* Asset Header Info */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#2D3139] pb-4">
              <div>
                <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-[0.15em]">
                  Vessel & Voyage Multi-Leg Spec
                </span>
                <h3 className="text-base font-bold text-white uppercase mt-0.5">
                  {selectedAsset.name}
                </h3>
                <span className="text-[10px] text-[#8E9299]">
                  Carrier: {selectedAsset.carrier} • {selectedAsset.registrationOrImo}
                </span>
              </div>

              <div className="flex space-x-3 text-xs">
                <div className="bg-[#11141B] p-2.5 rounded-sm border border-[#2D3139] text-center">
                  <span className="text-[#8E9299] block text-[10px] uppercase">Total Capacity</span>
                  <span className="font-bold text-white">{selectedAsset.totalTeu} TEU</span>
                </div>
                <div className="bg-[#11141B] p-2.5 rounded-sm border border-[#2D3139] text-center">
                  <span className="text-[#8E9299] block text-[10px] uppercase">Spare Capacity</span>
                  <span className="font-bold text-emerald-400">{selectedAsset.spareTeu} TEU</span>
                </div>
              </div>
            </div>

            {/* Container Class Capabilities */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
              <div className="p-3 bg-[#11141B] rounded-sm border border-[#2D3139] space-y-0.5">
                <span className="text-[#8E9299] block text-[10px] uppercase">Weight Cap</span>
                <span className="font-bold text-white">{selectedAsset.spareWeightTonnes}t spare</span>
              </div>
              <div className="p-3 bg-[#11141B] rounded-sm border border-[#2D3139] space-y-0.5">
                <span className="text-[#8E9299] block text-[10px] uppercase">Reefer Plugs</span>
                <span className="font-bold text-amber-400">{selectedAsset.spareReeferPlugs} spare</span>
              </div>
              <div className="p-3 bg-[#11141B] rounded-sm border border-[#2D3139] space-y-0.5">
                <span className="text-[#8E9299] block text-[10px] uppercase">Hazmat</span>
                <span className={`font-bold ${selectedAsset.hazmatAllowed ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {selectedAsset.hazmatAllowed ? 'Yes (IMO Classed)' : 'No'}
                </span>
              </div>
              <div className="p-3 bg-[#11141B] rounded-sm border border-[#2D3139] space-y-0.5">
                <span className="text-[#8E9299] block text-[10px] uppercase">Oversize Cargo</span>
                <span className={`font-bold ${selectedAsset.oversizeAllowed ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {selectedAsset.oversizeAllowed ? 'Permitted' : 'Restricted'}
                </span>
              </div>
            </div>

            {/* Crucial Section 5: Leg-by-Leg Capacity Breakdown */}
            <div className="space-y-3">
              <div className="flex justify-between items-center border-b border-[#2D3139] pb-2">
                <h4 className="text-xs font-bold text-[#E0E0E0] uppercase tracking-wider flex items-center space-x-1">
                  <Box className="h-3.5 w-3.5 text-emerald-500" />
                  <span>Sequential Leg Capacity Breakdown</span>
                </h4>
                <span className="text-[10px] text-emerald-400 bg-[#11141B] px-2 py-0.5 rounded-sm border border-emerald-500/40 uppercase">
                  Simultaneous Optimisation Active
                </span>
              </div>

              <div className="space-y-2.5">
                {selectedAsset.legs.map((leg: VoyageLeg, idx: number) => {
                  const legSparePct = ((leg.spareTeu / leg.totalTeuCapacity) * 100).toFixed(1);

                  return (
                    <div
                      key={leg.id}
                      className="p-3.5 bg-[#11141B] rounded-sm border border-[#2D3139] space-y-2.5"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#2D3139] pb-2">
                        <div className="flex items-center space-x-2">
                          <span className="px-1.5 py-0.5 bg-[#151921] text-emerald-400 font-bold text-[10px] rounded-sm border border-[#2D3139]">
                            L{idx + 1}
                          </span>
                          <span className="text-xs font-bold text-white flex items-center space-x-1.5 uppercase">
                            <span>{leg.originName}</span>
                            <ChevronRight className="h-3.5 w-3.5 text-[#8E9299]" />
                            <span>{leg.destinationName}</span>
                          </span>
                        </div>
                        <div className="text-[10px] text-[#8E9299] flex items-center space-x-3">
                          <span>ETD: <strong className="text-white">{leg.etd.slice(0, 10)}</strong></span>
                          <span>RATE: <strong className="text-emerald-400">{currencySymbol}{leg.marketRatePerTeu} / TEU</strong></span>
                        </div>
                      </div>

                      {/* Leg Capacity Gauge */}
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-2 text-xs">
                        <div className="bg-[#151921] p-2.5 rounded-sm border border-[#2D3139]">
                          <span className="text-[#8E9299] block text-[10px] uppercase">Leg Spare TEU</span>
                          <span className="font-bold text-emerald-400">{leg.spareTeu} / {leg.totalTeuCapacity} TEU</span>
                          <div className="w-full bg-[#11141B] h-1.5 mt-1 border border-[#2D3139]">
                            <div className="bg-emerald-500 h-1.5" style={{ width: `${legSparePct}%` }} />
                          </div>
                        </div>

                        <div className="bg-[#151921] p-2.5 rounded-sm border border-[#2D3139]">
                          <span className="text-[#8E9299] block text-[10px] uppercase">Spare Weight</span>
                          <span className="font-bold text-emerald-400">{leg.spareWeightTonnes.toLocaleString()}t</span>
                        </div>

                        <div className="bg-[#151921] p-2.5 rounded-sm border border-[#2D3139]">
                          <span className="text-[#8E9299] block text-[10px] uppercase">Reefer Slots</span>
                          <span className="font-bold text-amber-400">{leg.spareReeferPlugs} plugs</span>
                        </div>

                        <div className="bg-[#151921] p-2.5 rounded-sm border border-[#2D3139]">
                          <span className="text-[#8E9299] block text-[10px] uppercase">Hazmat Slots</span>
                          <span className="font-bold text-emerald-400">{leg.spareHazmatSlots} slots</span>
                        </div>
                      </div>

                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-3 bg-[#11141B] rounded-sm border border-[#2D3139] text-xs text-[#8E9299] flex items-start space-x-2 font-sans">
              <AlertCircle className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>Leg Optimisation Rule:</strong> Capacity is modelled independently per leg. Cargo loaded at Shanghai bound for Rotterdam holds capacity through Singapore, restricting intermediate booking on Shanghai → Singapore.
              </span>
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
