import React, { useState } from 'react';
import { Sparkles, Send, X, Bot, User, Loader2 } from 'lucide-react';

interface AiCopilotModalProps {
  isOpen: boolean;
  onClose: () => void;
  context: any;
}

export const AiCopilotModal: React.FC<AiCopilotModalProps> = ({
  isOpen,
  onClose,
  context,
}) => {
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string }>>([
    {
      sender: 'ai',
      text: "Hello! I am your AI Global Freight Optimisation Copilot powered by Gemini 3.7 Flash. Ask me to evaluate spare capacity, suggest rate strategies, analyze leg-by-leg bottlenecks, or optimize empty container repositioning."
    }
  ]);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!prompt.trim() || loading) return;

    const userText = prompt;
    setPrompt('');
    setMessages(prev => [...prev, { sender: 'user', text: userText }]);
    setLoading(true);

    try {
      const res = await fetch('/api/gemini/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userText,
          context
        })
      });

      const data = await res.json();
      setMessages(prev => [...prev, { sender: 'ai', text: data.advice || 'No analysis generated.' }]);
    } catch (err: any) {
      setMessages(prev => [...prev, { sender: 'ai', text: 'Error connecting to AI Copilot service: ' + err.message }]);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = [
    "Where is freight capacity currently being wasted?",
    "Recommend optimal allocation for 42 TEU Shanghai → Rotterdam",
    "How much empty container repositioning cost can we save?",
    "What dynamic price should we quote for Siemens Energy?"
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 font-mono">
      <div className="bg-[#151921] border border-[#2D3139] rounded-sm w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col h-[600px]">
        
        {/* Header */}
        <div className="p-3.5 bg-[#11141B] border-b border-[#2D3139] flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-sm border border-emerald-500/40">
              <Sparkles className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">AI Freight Optimisation Copilot</h3>
              <span className="text-[10px] text-[#8E9299]">Powered by Gemini 3.7 Flash Engine</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#8E9299] hover:text-white rounded-sm hover:bg-[#151921] transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Message Log */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs bg-[#0F1115]">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start space-x-2.5 ${m.sender === 'user' ? 'justify-end' : ''}`}
            >
              {m.sender === 'ai' && (
                <div className="p-1.5 bg-[#151921] text-emerald-400 rounded-sm border border-[#2D3139] shrink-0">
                  <Bot className="h-3.5 w-3.5" />
                </div>
              )}
              <div
                className={`p-3 rounded-sm max-w-lg leading-relaxed whitespace-pre-wrap ${
                  m.sender === 'user'
                    ? 'bg-emerald-600 text-white font-mono'
                    : 'bg-[#151921] text-white border border-[#2D3139] font-mono'
                }`}
              >
                {m.text}
              </div>
              {m.sender === 'user' && (
                <div className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-sm border border-emerald-500/40 shrink-0">
                  <User className="h-3.5 w-3.5" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center space-x-2 text-[#8E9299] text-xs italic">
              <Loader2 className="h-3.5 w-3.5 animate-spin text-emerald-500" />
              <span>Analyzing capacity constraints and economic trade-offs...</span>
            </div>
          )}
        </div>

        {/* Quick Sample Suggestions */}
        <div className="px-3 py-2 bg-[#11141B] border-t border-[#2D3139] flex items-center space-x-2 overflow-x-auto">
          <span className="text-[9px] text-[#8E9299] uppercase font-bold shrink-0">Suggested:</span>
          {samplePrompts.map((p, i) => (
            <button
              key={i}
              onClick={() => { setPrompt(p); }}
              className="px-2 py-1 bg-[#151921] hover:bg-[#1a1f29] text-[#8E9299] hover:text-white rounded-sm text-[10px] border border-[#2D3139] shrink-0 transition-colors uppercase"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSend} className="p-3 bg-[#11141B] border-t border-[#2D3139] flex items-center space-x-2">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Ask AI Copilot for logistics analysis or rate advice..."
            className="flex-1 bg-[#151921] text-white p-2 rounded-sm border border-[#2D3139] focus:outline-none focus:border-emerald-500 text-xs font-mono"
          />
          <button
            type="submit"
            disabled={loading || !prompt.trim()}
            className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-sm disabled:opacity-50 transition-all shadow-[0_0_8px_#10B981]"
          >
            <Send className="h-3.5 w-3.5" />
          </button>
        </form>

      </div>
    </div>
  );
};
