import React from 'react';
import {
  ControlTowerKPIs,
  MatchOpportunity,
  CapacityAsset
} from '../types';
import {
  TrendingUp,
  DollarSign,
  Package,
  Ship,
  Train,
  Truck,
  Plane,
  ArrowRight,
  Sparkles,
  Zap,
  Leaf
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell
} from 'recharts';

interface ControlTowerProps {
  kpis: ControlTowerKPIs;
  topMatches: MatchOpportunity[];
  assets: CapacityAsset[];
  currencySymbol: string;
  currencyMultiplier: number;
  onSelectTab: (tab: string) => void;
  onExecuteMatch: (matchId: string) => void;
}

export const ControlTower: React.FC<ControlTowerProps> = ({
  kpis,
  topMatches,
  assets,
  currencySymbol,
  currencyMultiplier,
  onSelectTab,
  onExecuteMatch,
}) => {
  const formatMoney = (amount: number) => {
    const val = amount * currencyMultiplier;
    if (val >= 1000000) return `${currencySymbol}${(val / 1000000).toFixed(2)}M`;
    if (val >= 1000) return `${currencySymbol}${(val / 1000).toFixed(0)}k`;
    return `${currencySymbol}${val.toFixed(0)}`;
  };

  const modeEfficiencyData = [
    { mode: 'Maritime', efficiency: 95.1, color: '#10b981' },
    { mode: 'Containers', efficiency: 89.4, color: '#059669' },
    { mode: 'Rail', efficiency: 65.0, color: '#047857' },
    { mode: 'Road Backhaul', efficiency: 38.5, color: '#f59e0b' },
    { mode: 'Air Cargo', efficiency: 84.2, color: '#10b981' },
  ];

  return (
    <div className="space-y-6">
      
      {/* Top Banner - Executive Operational Summary */}
      <div className="bg-[#151921] rounded-sm p-5 border border-[#2D3139] relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center space-x-2 text-emerald-500 text-[10px] font-mono font-bold uppercase tracking-[0.2em] mb-1">
              <Zap className="h-3.5 w-3.5" />
              <span>Real-Time Global Capacity Control Tower</span>
            </div>
            <h2 className="text-xl font-bold font-mono text-white tracking-tight uppercase">
              Spare Capacity Monetisation & Network Optimisation Engine
            </h2>
            <p className="text-xs text-[#8E9299] mt-1 max-w-3xl leading-relaxed font-sans">
              Continuously matching unutilised freight slots across 14,000+ global trade lanes. Optimising simultaneously for contribution margin, transit reliability, repositioning cost, and fuel efficiency.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 font-mono">
            <button
              onClick={() => onSelectTab('opportunities')}
              className="px-4 py-2 rounded-sm text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-all uppercase tracking-wider flex items-center space-x-2 shadow-[0_0_8px_#10B981]"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>View Top Matches ({topMatches.length})</span>
            </button>
            <button
              onClick={() => onSelectTab('map')}
              className="px-4 py-2 rounded-sm text-xs font-bold text-[#E0E0E0] bg-[#11141B] hover:bg-[#1A1F26] border border-[#2D3139] transition-all uppercase tracking-wider flex items-center space-x-2"
            >
              <span>Capacity Map</span>
              <ArrowRight className="h-3.5 w-3.5 text-emerald-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Primary Key Central Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Metric 1: Spare Capacity Value */}
        <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] relative overflow-hidden group hover:border-emerald-500/50 transition-all">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-[0.15em]">
                CENTRAL METRIC 1
              </span>
              <h3 className="text-xs font-mono uppercase tracking-wider text-[#8E9299] mt-0.5">
                Spare Capacity Value
              </h3>
            </div>
            <div className="p-2 bg-[#11141B] text-amber-400 rounded-sm border border-[#2D3139]">
              <DollarSign className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-mono font-bold text-white tracking-tight">
              {formatMoney(kpis.unusedCapacityValueGbp)}
            </div>
            <p className="text-[11px] text-[#8E9299] mt-1 font-sans">
              Extractable economic value from unbooked slots
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-[#2D3139] flex items-center justify-between text-xs font-mono">
            <span className="text-[#8E9299]">Potential Incremental Rev:</span>
            <span className="font-bold text-amber-400">{formatMoney(kpis.potentialIncrementalRevenueGbp)}</span>
          </div>
        </div>

        {/* Metric 2: Global Capacity Efficiency */}
        <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] relative overflow-hidden group hover:border-emerald-500/50 transition-all">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-[0.15em]">
                CENTRAL METRIC 2
              </span>
              <h3 className="text-xs font-mono uppercase tracking-wider text-[#8E9299] mt-0.5">
                Global Capacity Efficiency
              </h3>
            </div>
            <div className="p-2 bg-[#11141B] text-emerald-400 rounded-sm border border-[#2D3139]">
              <TrendingUp className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-mono font-bold text-white tracking-tight">
              {kpis.globalCapacityEfficiencyPct}%
            </div>
            <p className="text-[11px] text-[#8E9299] mt-1 font-sans">
              Revenue-generating capacity / Total available capacity
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-[#2D3139] flex items-center justify-between text-xs font-mono">
            <span className="text-[#8E9299]">Network Load Factor:</span>
            <span className="font-bold text-emerald-400">High Optimisation (+4.2%)</span>
          </div>
        </div>

        {/* Metric 3: Empty Movement Avoided */}
        <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] relative overflow-hidden group hover:border-emerald-500/50 transition-all">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-[0.15em]">
                CENTRAL METRIC 3
              </span>
              <h3 className="text-xs font-mono uppercase tracking-wider text-[#8E9299] mt-0.5">
                Empty Movements Avoided
              </h3>
            </div>
            <div className="p-2 bg-[#11141B] text-emerald-400 rounded-sm border border-[#2D3139]">
              <Leaf className="h-4 w-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-mono font-bold text-white tracking-tight">
              {formatMoney(kpis.avoidedRepositioningSavingsGbp)}
            </div>
            <p className="text-[11px] text-[#8E9299] mt-1 font-sans">
              Direct cost savings from coupled empty container matching
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-[#2D3139] flex items-center justify-between text-xs font-mono">
            <span className="text-[#8E9299]">Repositioned: <strong className="text-emerald-400">{kpis.emptyRepositioningTeu} TEU</strong></span>
            <span className="text-[#8E9299]">CO₂ Saved: <strong className="text-emerald-400">{kpis.avoidedEmissionsCo2Tonnes} t</strong></span>
          </div>
        </div>

      </div>

      {/* Multi-Modal Inventory Summary Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#11141B] p-3 rounded-sm border border-[#2D3139]">
          <div className="flex items-center space-x-2 text-emerald-400 text-[11px] font-mono uppercase tracking-wider">
            <Ship className="h-3.5 w-3.5" />
            <span>Maritime</span>
          </div>
          <div className="mt-2 text-lg font-mono font-bold text-white">
            {kpis.totalAvailableTeu.toLocaleString()} <span className="text-[10px] text-[#8E9299] font-normal uppercase">TEU</span>
          </div>
        </div>

        <div className="bg-[#11141B] p-3 rounded-sm border border-[#2D3139]">
          <div className="flex items-center space-x-2 text-emerald-400 text-[11px] font-mono uppercase tracking-wider">
            <Train className="h-3.5 w-3.5" />
            <span>Rail Corridors</span>
          </div>
          <div className="mt-2 text-lg font-mono font-bold text-white">
            {kpis.availableRailSlots} <span className="text-[10px] text-[#8E9299] font-normal uppercase">slots</span>
          </div>
        </div>

        <div className="bg-[#11141B] p-3 rounded-sm border border-[#2D3139]">
          <div className="flex items-center space-x-2 text-amber-400 text-[11px] font-mono uppercase tracking-wider">
            <Truck className="h-3.5 w-3.5" />
            <span>Road Backhaul</span>
          </div>
          <div className="mt-2 text-lg font-mono font-bold text-white">
            {kpis.availableTruckCapacityTonnes} <span className="text-[10px] text-[#8E9299] font-normal uppercase">tonnes</span>
          </div>
        </div>

        <div className="bg-[#11141B] p-3 rounded-sm border border-[#2D3139]">
          <div className="flex items-center space-x-2 text-emerald-400 text-[11px] font-mono uppercase tracking-wider">
            <Plane className="h-3.5 w-3.5" />
            <span>Air Freight</span>
          </div>
          <div className="mt-2 text-lg font-mono font-bold text-white">
            {kpis.availableAirCapacityTonnes} <span className="text-[10px] text-[#8E9299] font-normal uppercase">tonnes</span>
          </div>
        </div>

        <div className="bg-[#11141B] p-3 rounded-sm border border-[#2D3139]">
          <div className="flex items-center space-x-2 text-[#8E9299] text-[11px] font-mono uppercase tracking-wider">
            <Package className="h-3.5 w-3.5" />
            <span>Cargo Demand</span>
          </div>
          <div className="mt-2 text-lg font-mono font-bold text-white">
            {kpis.cargoWaitingTeu} <span className="text-[10px] text-[#8E9299] font-normal uppercase">TEU</span>
          </div>
        </div>

        <div className="bg-[#11141B] p-3 rounded-sm border border-[#2D3139]">
          <div className="flex items-center space-x-2 text-emerald-400 text-[11px] font-mono uppercase tracking-wider">
            <Zap className="h-3.5 w-3.5" />
            <span>Matched TEU</span>
          </div>
          <div className="mt-2 text-lg font-mono font-bold text-white">
            {kpis.potentialMatchesTeu} <span className="text-[10px] text-[#8E9299] font-normal uppercase">TEU</span>
          </div>
        </div>
      </div>

      {/* Analytics Chart & Top Recommendations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Left Column: Mode Efficiency Chart */}
        <div className="bg-[#151921] rounded-sm p-4 border border-[#2D3139] flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xs font-mono font-bold text-emerald-500 uppercase tracking-[0.15em]">
                Utilisation Efficiency by Mode
              </h3>
              <span className="text-[10px] font-mono text-[#8E9299]">TARGET: 95.0%</span>
            </div>
            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={modeEfficiencyData} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                  <XAxis type="number" domain={[0, 100]} stroke="#4A4F59" fontSize={10} unit="%" />
                  <YAxis type="category" dataKey="mode" stroke="#8E9299" fontSize={10} width={90} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#11141B', borderColor: '#2D3139', color: '#fff', fontSize: '11px', fontFamily: 'monospace' }}
                    formatter={(val: any) => [`${val}% Utilised`, 'Efficiency']}
                  />
                  <Bar dataKey="efficiency" radius={[0, 2, 2, 0]}>
                    {modeEfficiencyData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="p-3 bg-[#11141B] rounded-sm border border-[#2D3139] text-xs text-[#8E9299] mt-3 font-mono">
            <strong className="text-emerald-400">Backhaul Insight:</strong> Road backhaul operates at 38.5% capacity. Return trips London → Manchester unlock £18,400 contribution.
          </div>
        </div>

        {/* Right Column: Automated High-Margin Match Recommendations */}
        <div className="lg:col-span-2 bg-[#151921] rounded-sm p-4 border border-[#2D3139] space-y-3">
          <div className="flex items-center justify-between border-b border-[#2D3139] pb-3">
            <div>
              <h3 className="text-xs font-mono font-bold text-emerald-500 uppercase tracking-[0.15em]">
                Optimised Match Recommendations
              </h3>
              <p className="text-[11px] text-[#8E9299] mt-0.5">
                Ranked by net contribution margin (Revenue - Incremental Cost - Risk)
              </p>
            </div>
            <button
              onClick={() => onSelectTab('opportunities')}
              className="text-xs font-mono text-emerald-400 hover:text-emerald-300 uppercase tracking-wider flex items-center space-x-1"
            >
              <span>See All ({topMatches.length})</span>
              <ArrowRight className="h-3 w-3" />
            </button>
          </div>

          <div className="space-y-2">
            {topMatches.slice(0, 3).map((match) => (
              <div
                key={match.id}
                className="bg-[#11141B] rounded-sm p-3.5 border border-[#2D3139] hover:border-emerald-500/50 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1 max-w-xl">
                  <div className="flex items-center space-x-2 font-mono">
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 rounded-sm">
                      {match.asset.mode}
                    </span>
                    <span className="text-xs font-bold text-white">
                      {match.cargo.customerName}
                    </span>
                    <span className="text-xs text-[#8E9299]">
                      ({match.allocatedTeu} TEU)
                    </span>
                  </div>
                  <p className="text-xs text-[#E0E0E0] leading-normal font-sans">
                    {match.recommendationRationale}
                  </p>
                  <div className="flex flex-wrap items-center gap-3 text-[10px] font-mono text-[#8E9299]">
                    <span>ROUTE: <strong className="text-white">{match.cargo.origin.name} → {match.cargo.destination.name}</strong></span>
                    <span>P(UNSOLD): <strong className="text-amber-400">{(match.probabilityOfUnsoldWithoutMatch * 100).toFixed(0)}%</strong></span>
                  </div>
                </div>

                <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 pt-2 sm:pt-0 border-[#2D3139] shrink-0">
                  <div className="text-right font-mono">
                    <span className="text-[10px] text-[#8E9299] block uppercase">Net Contribution</span>
                    <span className="text-base font-bold text-emerald-400">
                      +{formatMoney(match.netContributionGbp)}
                    </span>
                  </div>
                  <button
                    onClick={() => onExecuteMatch(match.id)}
                    className="mt-2 px-3 py-1 text-[11px] font-mono font-bold uppercase tracking-wider bg-emerald-600 hover:bg-emerald-500 text-white rounded-sm transition-all"
                  >
                    Execute Match
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
