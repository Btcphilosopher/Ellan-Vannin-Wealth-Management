import {
  CapacityAsset,
  CargoDemand,
  CompatibilityCheck,
  MatchOpportunity,
  CargoConsolidationGroup,
  EmptyContainerRepositioningNode,
  OptimisationAlgorithm
} from '../types';

/**
 * Compatibility Engine (Section 10)
 * Evaluates physical, regulatory, equipment, and timing compatibility
 */
export function checkCargoCompatibility(
  cargo: CargoDemand,
  asset: CapacityAsset
): CompatibilityCheck {
  const reasons: string[] = [];
  let dimensionCheck = true;
  let weightCheck = true;
  let containerTypeCheck = true;
  let hazmatCheck = true;
  let temperatureCheck = true;
  let portCheck = true;
  let timingCheck = true;
  let customsCheck = true;

  // 1. Container / Equipment Type Check
  if (cargo.requiredContainerType === 'REEFER' && asset.spareReeferPlugs < cargo.requiredTeuCount) {
    containerTypeCheck = false;
    reasons.push(`Insufficient reefer plugs on asset (Required: ${cargo.requiredTeuCount}, Available: ${asset.spareReeferPlugs})`);
  }
  if (cargo.requiredContainerType === 'TANK' && !asset.subType.includes('TANK') && asset.mode !== 'MARITIME' && asset.mode !== 'RAIL') {
    containerTypeCheck = false;
    reasons.push(`Asset ${asset.name} does not support liquid tank ISO containers`);
  }

  // 2. Weight & Capacity Check
  if (asset.spareTeu < cargo.requiredTeuCount) {
    dimensionCheck = false;
    reasons.push(`Insufficient TEU slot capacity (Required: ${cargo.requiredTeuCount} TEU, Available: ${asset.spareTeu} TEU)`);
  }
  if (asset.spareWeightTonnes < cargo.weightTonnes) {
    weightCheck = false;
    reasons.push(`Weight limit exceeded (Required: ${cargo.weightTonnes}t, Available capacity: ${asset.spareWeightTonnes}t)`);
  }

  // 3. Hazardous Materials Check
  if (cargo.isHazardous && !asset.hazmatAllowed) {
    hazmatCheck = false;
    reasons.push(`Hazardous materials (Hazmat) not permitted on this ${asset.mode.toLowerCase()} transport asset`);
  }

  // 4. Temperature Control Check
  if (cargo.requiresTemperatureControl && asset.spareReeferPlugs < cargo.requiredTeuCount) {
    temperatureCheck = false;
    reasons.push(`Temperature control required (${cargo.targetTempCelsius}°C) but insufficient powered plugs`);
  }

  // 5. Port / Origin-Destination Route Check
  const matchesOrigin = asset.origin.id === cargo.origin.id || asset.legs.some(l => l.originPortId === cargo.origin.id);
  const matchesDest = asset.destination.id === cargo.destination.id || asset.legs.some(l => l.destinationPortId === cargo.destination.id);

  if (!matchesOrigin || !matchesDest) {
    portCheck = false;
    reasons.push(`Route mismatch: Asset serves ${asset.origin.name} → ${asset.destination.name}, cargo needs ${cargo.origin.name} → ${cargo.destination.name}`);
  }

  // 6. Timing Window Check
  const assetEtd = new Date(asset.etd).getTime();
  const cargoEarliest = new Date(cargo.earliestDeparture).getTime();
  const assetEta = new Date(asset.eta).getTime();
  const cargoLatest = new Date(cargo.latestArrival).getTime();

  if (assetEtd < cargoEarliest - 86400000) { // Allow 24h buffer
    timingCheck = false;
    reasons.push(`Departure too early: Asset departs ${asset.etd.slice(0, 10)}, cargo ready ${cargo.earliestDeparture.slice(0, 10)}`);
  }
  if (assetEta > cargoLatest + 86400000) {
    timingCheck = false;
    reasons.push(`Arrival too late: Asset arrives ${asset.eta.slice(0, 10)}, cargo deadline ${cargo.latestArrival.slice(0, 10)}`);
  }

  // Final Compatibility Status determination
  const allPassed = dimensionCheck && weightCheck && containerTypeCheck && hazmatCheck && temperatureCheck && portCheck && timingCheck;

  if (allPassed) {
    return {
      status: 'COMPATIBLE',
      dimensionCheck,
      weightCheck,
      containerTypeCheck,
      hazmatCheck,
      temperatureCheck,
      portCheck,
      customsCheck,
      timingCheck,
      reasons: ['Fully compatible across all physical, operational, safety, and timing constraints']
    };
  } else if (!dimensionCheck || !weightCheck || !portCheck) {
    return {
      status: 'INCOMPATIBLE',
      dimensionCheck,
      weightCheck,
      containerTypeCheck,
      hazmatCheck,
      temperatureCheck,
      portCheck,
      customsCheck,
      timingCheck,
      reasons
    };
  } else {
    return {
      status: 'CONDITIONALLY_COMPATIBLE',
      dimensionCheck,
      weightCheck,
      containerTypeCheck,
      hazmatCheck,
      temperatureCheck,
      portCheck,
      customsCheck,
      timingCheck,
      reasons: [...reasons, 'Requires conditional waiver or minor schedule adjustments']
    };
  }
}

/**
 * Fundamental Economic Optimisation Engine (Section 14)
 * Calculates Net Contribution Margin:
 * Freight Revenue - Incremental Transport Cost - Handling Cost - Fuel Cost - Repositioning Cost - Expected Delay Cost - Expected Failure Cost - Opportunity Cost
 */
export function calculateMatchEconomics(
  cargo: CargoDemand,
  asset: CapacityAsset,
  allocatedTeu: number
): MatchOpportunity {
  const compatibility = checkCargoCompatibility(cargo, asset);

  // Revenue calculation based on customer willingness to pay or market rate
  const marketRatePerTeu = asset.legs.length > 0 ? asset.legs[0].marketRatePerTeu : 1200;
  const ratePerTeu = Math.min(cargo.willingnessToPayPerTeuGbp, marketRatePerTeu * 1.15);
  const grossRevenueGbp = Math.round(ratePerTeu * allocatedTeu);

  // Incremental costs breakdown
  const legBaseCost = asset.legs.length > 0 ? asset.legs.reduce((acc, l) => acc + l.costPerTeuLeg, 0) : 350;
  const incrementalTransportCostGbp = Math.round(legBaseCost * allocatedTeu * 0.45); // Marginal fuel & weight cost
  const handlingCostGbp = Math.round(allocatedTeu * 140); // Port/terminal handling fee
  const fuelCostGbp = Math.round(allocatedTeu * (asset.fuelCostPerKm * 0.15));
  
  // Repositioning cost saving / penalty
  const avoidedEmptyRepositioningTeu = cargo.origin.currentContainerSurplus && cargo.origin.currentContainerSurplus > 0 ? allocatedTeu : 0;
  const repositioningCostGbp = avoidedEmptyRepositioningTeu > 0 ? -Math.round(avoidedEmptyRepositioningTeu * 280) : Math.round(allocatedTeu * 80);

  // Probabilistic Risk & Delay costs
  const expectedDelayCostGbp = Math.round(cargo.declaredValueGbp * 0.0005);
  const expectedFailureCostGbp = cargo.isHazardous ? Math.round(grossRevenueGbp * 0.05) : Math.round(grossRevenueGbp * 0.015);

  // Capacity Opportunity Cost (Value of holding capacity for potential higher-paying future demand)
  const probabilityOfUnsoldWithoutMatch = asset.spareTeu > 500 ? 0.82 : 0.65;
  const capacityOpportunityCostGbp = Math.round(grossRevenueGbp * (1 - probabilityOfUnsoldWithoutMatch) * 0.35);

  // Net Contribution Calculation
  const netContributionGbp = grossRevenueGbp 
    - incrementalTransportCostGbp 
    - handlingCostGbp 
    - fuelCostGbp 
    - repositioningCostGbp 
    - expectedDelayCostGbp 
    - expectedFailureCostGbp 
    - capacityOpportunityCostGbp;

  const marginalValuePerTeuGbp = Math.round(netContributionGbp / allocatedTeu);

  // Overall Match Score (0 - 100)
  const scoreBase = compatibility.status === 'COMPATIBLE' ? 85 : compatibility.status === 'CONDITIONALLY_COMPATIBLE' ? 60 : 10;
  const marginFactor = Math.min(30, Math.max(-20, netContributionGbp / 1000));
  const priorityFactor = cargo.priorityScore * 2;
  const overallScore = Math.min(99, Math.max(1, Math.round(scoreBase + marginFactor + priorityFactor)));

  const rationale = `Allocate ${allocatedTeu} TEU of ${asset.origin.name} → ${asset.destination.name} spare capacity to ${cargo.customerName}. Expected incremental contribution = £${netContributionGbp.toLocaleString()}. Capacity would otherwise remain unused with ${(probabilityOfUnsoldWithoutMatch * 100).toFixed(0)}% probability. Avoided empty repositioning: ${avoidedEmptyRepositioningTeu} TEU.`;

  return {
    id: `match-${cargo.id}-${asset.id}`,
    cargo,
    asset,
    recommendedLegs: asset.legs,
    allocatedTeu,
    physicalCompatibility: compatibility,
    grossRevenueGbp,
    incrementalTransportCostGbp,
    handlingCostGbp,
    fuelCostGbp,
    repositioningCostGbp,
    expectedDelayCostGbp,
    expectedFailureCostGbp,
    capacityOpportunityCostGbp,
    netContributionGbp,
    marginalValuePerTeuGbp,
    probabilityOfUnsoldWithoutMatch,
    avoidedEmptyRepositioningTeu,
    overallScore,
    recommendationRationale: rationale
  };
}

/**
 * Runs Optimization Match Engine over all pending Cargo Demands and Available Assets
 */
export function runMatchingOptimization(
  cargos: CargoDemand[],
  assets: CapacityAsset[],
  algorithm: OptimisationAlgorithm = 'MILP'
): MatchOpportunity[] {
  const results: MatchOpportunity[] = [];

  for (const cargo of cargos) {
    if (cargo.status === 'COMPLETED' || cargo.status === 'IN_TRANSIT') continue;

    let bestMatch: MatchOpportunity | null = null;

    for (const asset of assets) {
      if (asset.spareTeu <= 0) continue;

      const allocatedTeu = Math.min(cargo.requiredTeuCount, asset.spareTeu);
      const match = calculateMatchEconomics(cargo, asset, allocatedTeu);

      if (match.physicalCompatibility.status !== 'INCOMPATIBLE') {
        if (!bestMatch || match.netContributionGbp > bestMatch.netContributionGbp) {
          bestMatch = match;
        }
      }
    }

    if (bestMatch) {
      results.push(bestMatch);
    }
  }

  // Sort by highest net contribution margin
  return results.sort((a, b) => b.netContributionGbp - a.netContributionGbp);
}

/**
 * Consolidation Engine (Section 20)
 * Combines small LCL / partial shipments into FCL or rail wagons
 */
export function runCargoConsolidation(cargos: CargoDemand[]): CargoConsolidationGroup[] {
  const pendingDryCargos = cargos.filter(c => c.cargoType === 'DRY' && c.requiredTeuCount <= 2);
  const groups: CargoConsolidationGroup[] = [];

  if (pendingDryCargos.length === 0) return groups;

  let currentShipments: CargoDemand[] = [];
  let currentVol = 0;
  let currentWeight = 0;

  pendingDryCargos.forEach((c, idx) => {
    if (currentVol + c.volumeM3 <= 65 && currentWeight + c.weightTonnes <= 24) {
      currentShipments.push(c);
      currentVol += c.volumeM3;
      currentWeight += c.weightTonnes;
    } else {
      if (currentShipments.length > 0) {
        groups.push(createConsolidationGroup(`group-${groups.length + 1}`, currentShipments, currentVol, currentWeight));
      }
      currentShipments = [c];
      currentVol = c.volumeM3;
      currentWeight = c.weightTonnes;
    }
  });

  if (currentShipments.length > 0) {
    groups.push(createConsolidationGroup(`group-${groups.length + 1}`, currentShipments, currentVol, currentWeight));
  }

  return groups;
}

function createConsolidationGroup(
  id: string,
  shipments: CargoDemand[],
  vol: number,
  weight: number
): CargoConsolidationGroup {
  const maxVol = 76; // 40ft HC container vol cap
  const maxWeight = 28; // 28 tonnes cap
  const volPct = Math.round((vol / maxVol) * 100);
  const weightPct = Math.round((weight / maxWeight) * 100);
  const economicVal = shipments.reduce((acc, s) => acc + (s.willingnessToPayPerTeuGbp * s.requiredTeuCount), 0);
  const individualFreightCosts = shipments.length * 950;
  const consolidatedCost = 1450;
  const savings = Math.max(250, individualFreightCosts - consolidatedCost);

  return {
    id,
    shipments,
    totalVolumeM3: Math.round(vol),
    totalWeightTonnes: Math.round(weight),
    targetContainerType: '40FT_HC',
    containerVolumeCapM3: maxVol,
    containerWeightCapTonnes: maxWeight,
    volumeUtilisationPct: volPct,
    weightUtilisationPct: weightPct,
    economicUtilisationGbp: economicVal,
    savingsGeneratedGbp: savings
  };
}
