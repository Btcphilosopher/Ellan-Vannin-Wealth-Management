export type TransportMode = 
  | 'MARITIME' 
  | 'CONTAINER' 
  | 'RAIL' 
  | 'ROAD' 
  | 'AIR' 
  | 'WAREHOUSE';

export type VesselType = 
  | 'CONTAINER_VESSEL' 
  | 'RO_RO' 
  | 'GENERAL_CARGO' 
  | 'BULK' 
  | 'FEEDER' 
  | 'BARGE' 
  | 'COASTAL_SHIPPING';

export type ContainerType = 
  | '20FT_DRY' 
  | '40FT_DRY' 
  | '40FT_HC' 
  | '45FT_HC' 
  | 'REEFER' 
  | 'TANK' 
  | 'OPEN_TOP' 
  | 'FLAT_RACK';

export type RoadType = 
  | 'TRUCK' 
  | 'TRAILER' 
  | 'CURTAIN_SIDER' 
  | 'REFRIGERATED_TRUCK' 
  | 'TANKER' 
  | 'SPECIALIST_EQUIPMENT';

export type AirType = 
  | 'BELLY_CARGO' 
  | 'DEDICATED_FREIGHTER' 
  | 'ULD_CAPACITY';

export type CargoType = 
  | 'DRY' 
  | 'REEFER' 
  | 'HAZMAT' 
  | 'OVERSIZE' 
  | 'LIQUID' 
  | 'VALUABLE' 
  | 'EXPRESS';

export type CompatibilityStatus = 
  | 'COMPATIBLE' 
  | 'INCOMPATIBLE' 
  | 'CONDITIONALLY_COMPATIBLE';

export type OptimisationAlgorithm = 
  | 'MILP' 
  | 'MIN_COST_FLOW' 
  | 'CONSTRAINT_PROGRAMMING' 
  | 'DYNAMIC_PROGRAMMING' 
  | 'HEURISTICS' 
  | 'GENETIC_ALGORITHM' 
  | 'ROBUST_OPTIMISATION';

export interface LocationNode {
  id: string;
  name: string;
  code: string;
  country: string;
  lat: number;
  lng: number;
  type: 'PORT' | 'RAIL_TERMINAL' | 'TRUCK_DEPOT' | 'AIRPORT' | 'WAREHOUSE';
  currentContainerSurplus?: number; // TEU (+ for surplus, - for deficit)
}

export interface VoyageLeg {
  id: string;
  voyageId: string;
  assetId: string;
  originPortId: string;
  destinationPortId: string;
  originName: string;
  destinationName: string;
  etd: string;
  eta: string;
  totalTeuCapacity: number;
  bookedTeu: number;
  spareTeu: number;
  totalWeightCapTonnes: number;
  bookedWeightTonnes: number;
  spareWeightTonnes: number;
  totalReeferPlugs: number;
  bookedReeferPlugs: number;
  spareReeferPlugs: number;
  totalHazmatSlots: number;
  bookedHazmatSlots: number;
  spareHazmatSlots: number;
  costPerTeuLeg: number;
  marketRatePerTeu: number;
}

export interface CapacityAsset {
  id: string;
  name: string;
  mode: TransportMode;
  subType: string;
  carrier: string;
  registrationOrImo: string;
  origin: LocationNode;
  destination: LocationNode;
  etd: string;
  eta: string;
  totalTeu: number;
  bookedTeu: number;
  spareTeu: number;
  totalWeightTonnes: number;
  bookedWeightTonnes: number;
  spareWeightTonnes: number;
  totalVolumeM3: number;
  bookedVolumeM3: number;
  spareVolumeM3: number;
  totalReeferPlugs: number;
  bookedReeferPlugs: number;
  spareReeferPlugs: number;
  hazmatAllowed: boolean;
  oversizeAllowed: boolean;
  fuelCostPerKm: number;
  operatingCostPerKm: number;
  legs: VoyageLeg[];
  currentLocationLat?: number;
  currentLocationLng?: number;
  progressPercentage?: number;
  isBackhaulRoute?: boolean;
}

export interface CargoDemand {
  id: string;
  customerName: string;
  origin: LocationNode;
  destination: LocationNode;
  earliestDeparture: string;
  latestArrival: string;
  weightTonnes: number;
  volumeM3: number;
  palletCount: number;
  requiredContainerType: ContainerType;
  requiredTeuCount: number;
  cargoType: CargoType;
  isHazardous: boolean;
  requiresTemperatureControl: boolean;
  targetTempCelsius?: number;
  declaredValueGbp: number;
  willingnessToPayPerTeuGbp: number;
  priorityScore: number; // 1 to 10
  status: 'PENDING' | 'MATCHED' | 'IN_TRANSIT' | 'COMPLETED' | 'CANCELLED';
  createdDate: string;
}

export interface CompatibilityCheck {
  status: CompatibilityStatus;
  dimensionCheck: boolean;
  weightCheck: boolean;
  containerTypeCheck: boolean;
  hazmatCheck: boolean;
  temperatureCheck: boolean;
  portCheck: boolean;
  railGaugeCheck?: boolean;
  customsCheck: boolean;
  timingCheck: boolean;
  reasons: string[];
}

export interface MatchOpportunity {
  id: string;
  cargo: CargoDemand;
  asset: CapacityAsset;
  recommendedLegs: VoyageLeg[];
  allocatedTeu: number;
  physicalCompatibility: CompatibilityCheck;
  grossRevenueGbp: number;
  incrementalTransportCostGbp: number;
  handlingCostGbp: number;
  fuelCostGbp: number;
  repositioningCostGbp: number;
  expectedDelayCostGbp: number;
  expectedFailureCostGbp: number;
  capacityOpportunityCostGbp: number;
  netContributionGbp: number;
  marginalValuePerTeuGbp: number;
  probabilityOfUnsoldWithoutMatch: number; // e.g., 0.82 (82%)
  avoidedEmptyRepositioningTeu: number;
  overallScore: number;
  recommendationRationale: string;
}

export interface EmptyContainerRepositioningNode {
  portId: string;
  portName: string;
  currentStockTeu: number;
  demandTeu: number;
  netBalanceTeu: number; // Positive = surplus, Negative = deficit
  recommendedAction: 'CARRY_PAYING_CARGO' | 'MOVE_EMPTY' | 'REMAIN_AT_DEPOT' | 'LEASE_NEW' | 'RETURN_LEASE' | 'REPOSITION_TO_PORT';
  targetPortId?: string;
  targetPortName?: string;
  estimatedRepositionCostGbp: number;
  alternativeLeaseCostGbp: number;
  netSavingsGbp: number;
}

export interface CargoConsolidationGroup {
  id: string;
  shipments: CargoDemand[];
  totalVolumeM3: number;
  totalWeightTonnes: number;
  targetContainerType: ContainerType;
  containerVolumeCapM3: number;
  containerWeightCapTonnes: number;
  volumeUtilisationPct: number;
  weightUtilisationPct: number;
  economicUtilisationGbp: number;
  savingsGeneratedGbp: number;
}

export interface ProbabilisticBookingModel {
  voyageId: string;
  vesselName: string;
  route: string;
  daysToDeparture: number;
  currentBookedPct: number;
  probCapacitySold: number;
  probCapacityRemaining: number;
  probLastMinuteBooking: number;
  expectedValueHoldGbp: number;
  expectedValueSellNowGbp: number;
  minAcceptablePriceGbp: number;
  targetPriceGbp: number;
  maxMarketPriceGbp: number;
  recommendedAction: 'SELL_NOW_DISCOUNT' | 'HOLD_FOR_PREMIUM' | 'AUCTION_SLOTS';
}

export interface AuctionListing {
  id: string;
  sellerCarrier: string;
  origin: string;
  destination: string;
  mode: TransportMode;
  availableTeu: number;
  departureDate: string;
  floorPricePerTeuGbp: number;
  currentHighestBidGbp: number;
  highestBidder?: string;
  totalBidsCount: number;
  allowedCargoConditions: string[];
  expiresInHours: number;
  status: 'OPEN' | 'CLOSED' | 'EXPIRED';
}

export interface DemandForecastScenario {
  route: string;
  p10TeuDemand: number;
  p50TeuDemand: number;
  p90TeuDemand: number;
  scenarioName: 'BASE_DEMAND' | 'HIGH_DEMAND' | 'PORT_DISRUPTION' | 'VESSEL_DELAY' | 'FUEL_PRICE_SHOCK' | 'FREIGHT_RATE_SHOCK';
  robustnessScorePct: number;
  suggestedSafetyCapacityTeu: number;
}

export interface ControlTowerKPIs {
  totalAvailableTeu: number;
  availableRailSlots: number;
  availableTruckCapacityTonnes: number;
  availableAirCapacityTonnes: number;
  cargoWaitingTeu: number;
  potentialMatchesTeu: number;
  unusedCapacityValueGbp: number;
  potentialIncrementalRevenueGbp: number;
  emptyRepositioningTeu: number;
  avoidedRepositioningSavingsGbp: number;
  avoidedEmissionsCo2Tonnes: number;
  globalCapacityEfficiencyPct: number;
  averageTransitTimeDays: number;
}
