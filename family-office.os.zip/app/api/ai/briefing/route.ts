import { GoogleGenAI } from '@google/genai';
import { NextResponse } from 'next/server';
import {
  INITIAL_ASSET_POSITIONS,
  INITIAL_CAPITAL_CALLS,
  INITIAL_PRIVATE_FUNDS,
  INITIAL_PROPERTIES,
} from '@/lib/data/family-office-store';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export async function GET() {
  try {
    const totalAssetsUsd = INITIAL_ASSET_POSITIONS.reduce((acc, p) => acc + p.valueUsd, 0);
    const totalLiabilitiesUsd = 115000000;
    const netWorthUsd = totalAssetsUsd - totalLiabilitiesUsd;
    const liquidCashUsd = INITIAL_ASSET_POSITIONS
      .filter((p) => p.assetClass === 'CASH' || p.liquidityTier === 'T+1 Liquid')
      .reduce((acc, p) => acc + p.valueUsd, 0);

    const pendingCallsUsd = INITIAL_CAPITAL_CALLS.reduce((acc, c) => acc + c.callAmountUsd, 0);

    const summaryContext = {
      netWorthUsd,
      totalAssetsUsd,
      liquidCashUsd,
      pendingCallsUsd,
      capitalCallsCount: INITIAL_CAPITAL_CALLS.length,
      nextCallDue: INITIAL_CAPITAL_CALLS[0],
      topAssets: INITIAL_ASSET_POSITIONS.slice(0, 5).map((a) => `${a.name} ($${(a.valueUsd / 1e6).toFixed(1)}M)`),
    };

    const prompt = `Generate a concise, institutional-grade Morning Briefing for Lord Arthur Aurelia (Principal) and Julian Aurelia (CIO).

Context Summary:
${JSON.stringify(summaryContext, null, 2)}

Requirements:
- Professional, calm, institutional tone (private bank + Bloomberg + UK family office).
- Return clean JSON matching:
{
  "greeting": "GOOD MORNING, PRINCIPAL & CIO",
  "netWorthHeader": "$1.186B Consolidated Net Worth",
  "liquidityStatus": "Optimal ($294.2M T+1 Liquid)",
  "overnightMarketInsights": "Key institutional observations on interest rate expectations and private market distributions.",
  "actionItems": [
    "Review Insight Venture XII $4.2M capital call due in 34 days",
    "Audit UK Real Estate insurance renewal for 12 Grosvenor Sq",
    "Prepare Investment Committee pack for Project Helios"
  ],
  "topRisks": "Concentration in Renewable Tech Operating Corp (28.6% of Net Worth)"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        temperature: 0.3,
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return NextResponse.json(parsed);
  } catch (error: any) {
    console.error('Error generating morning brief:', error);
    return NextResponse.json({
      greeting: 'GOOD MORNING, PRINCIPAL & CIO',
      netWorthHeader: '$1.186B Consolidated Net Worth',
      liquidityStatus: '$294.2M T+1 Liquid Cash & Treasuries',
      overnightMarketInsights: 'Global markets remain rangebound; private market distributions hold steady.',
      actionItems: [
        'Review Insight Venture XII $4.2M capital call due Oct 14',
        'Audit 12 Grosvenor Square property insurance policy',
        'Review Project Helios Investment Committee submission',
      ],
      topRisks: 'Operating Company concentration at 28.6% of total wealth.',
    });
  }
}
