import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'FAMILY OFFICE.OS — Institutional Operating System',
  description: 'Institutional Family Office Operating System — Multi-generational Capital, Ownership Graph, Master Wealth Ledger & Gemini 3.6 Intelligence Layer',
  openGraph: {
    title: 'FAMILY OFFICE.OS — Institutional Operating System',
    description: 'Institutional Family Office Operating System — Multi-generational Capital, Ownership Graph, Master Wealth Ledger & Gemini 3.6 Intelligence Layer',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'FAMILY OFFICE.OS — Institutional Operating System',
    description: 'Institutional Family Office Operating System — Multi-generational Capital, Ownership Graph, Master Wealth Ledger & Gemini 3.6 Intelligence Layer',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
