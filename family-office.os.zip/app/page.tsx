'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { Navbar, NavTab } from '@/components/Navbar';
import { OverviewView } from '@/components/views/OverviewView';
import { WealthMapView } from '@/components/views/WealthMapView';
import { NetWorthView } from '@/components/views/NetWorthView';
import { PortfolioView } from '@/components/views/PortfolioView';
import { PrivateMarketsView } from '@/components/views/PrivateMarketsView';
import { DealRoomView } from '@/components/views/DealRoomView';
import { PropertyOSView } from '@/components/views/PropertyOSView';
import { CollectiblesView } from '@/components/views/CollectiblesView';
import { LiquidityRiskView } from '@/components/views/LiquidityRiskView';
import { TaxGovernanceView } from '@/components/views/TaxGovernanceView';
import { DocumentsView } from '@/components/views/DocumentsView';
import { DigitalTwinView } from '@/components/views/DigitalTwinView';
import { AskGeminiView } from '@/components/views/AskGeminiView';
import { NewRecordModal } from '@/components/NewRecordModal';
import { Search, X, ChevronRight, ArrowRight } from 'lucide-react';
import { INITIAL_ASSET_POSITIONS, INITIAL_OWNERSHIP_NODES } from '@/lib/data/family-office-store';

export default function Home() {
  const [activeTab, setActiveTab] = useState<NavTab>('OVERVIEW');
  const [currency, setCurrency] = useState<'USD' | 'GBP' | 'EUR'>('USD');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNewRecordOpen, setIsNewRecordOpen] = useState(false);
  const [aiInitialQuery, setAiInitialQuery] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');

  // Keyboard shortcut Cmd+K for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleOpenAi = (query?: string) => {
    if (query) {
      setAiInitialQuery(query);
    }
    setActiveTab('ASK_GEMINI');
  };

  const handleSaveRecord = (record: any) => {
    console.log('Record committed to ledger:', record);
  };

  // Search results
  const searchResultsAssets = INITIAL_ASSET_POSITIONS.filter(
    (a) =>
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.entityName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const searchResultsNodes = INITIAL_OWNERSHIP_NODES.filter((n) =>
    n.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col font-sans selection:bg-[#d4af37]/30 selection:text-white">
      {/* Institutional Top Navigation Header */}
      <Header
        activeCurrency={currency}
        setActiveCurrency={setCurrency}
        onOpenSearch={() => setIsSearchOpen(true)}
        onNewRecord={() => setIsNewRecordOpen(true)}
        onOpenAi={handleOpenAi}
      />

      {/* Primary Subsystem Navigation Bar */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Subsystem Container */}
      <main className="flex-1 overflow-y-auto pb-12">
        {activeTab === 'OVERVIEW' && (
          <OverviewView
            currency={currency}
            onNavigate={(tab) => setActiveTab(tab)}
            onOpenAi={handleOpenAi}
          />
        )}

        {activeTab === 'WEALTH_MAP' && (
          <WealthMapView currency={currency} onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'NET_WORTH' && (
          <NetWorthView currency={currency} onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'PORTFOLIO' && (
          <PortfolioView currency={currency} onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'PRIVATE_MARKETS' && (
          <PrivateMarketsView currency={currency} onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'DEAL_ROOM' && (
          <DealRoomView currency={currency} onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'PROPERTY_OS' && (
          <PropertyOSView currency={currency} onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'COLLECTIBLES' && (
          <CollectiblesView currency={currency} onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'LIQUIDITY_RISK' && (
          <LiquidityRiskView currency={currency} onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'TAX_GOVERNANCE' && (
          <TaxGovernanceView currency={currency} onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'DOCUMENTS' && (
          <DocumentsView onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'DIGITAL_TWIN' && (
          <DigitalTwinView currency={currency} onOpenAi={handleOpenAi} />
        )}

        {activeTab === 'ASK_GEMINI' && (
          <AskGeminiView
            initialQuery={aiInitialQuery}
            onNavigate={(tab) => setActiveTab(tab)}
          />
        )}
      </main>

      {/* Record Creation Modal */}
      <NewRecordModal
        isOpen={isNewRecordOpen}
        onClose={() => setIsNewRecordOpen(false)}
        onSave={handleSaveRecord}
      />

      {/* Global Command / Search Overlay */}
      {isSearchOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-start justify-center pt-20 p-4">
          <div className="bg-[#121927] border border-[#233148] rounded-lg max-w-2xl w-full p-4 space-y-4 shadow-2xl font-mono text-xs text-slate-100">
            <div className="flex items-center gap-3 pb-3 border-b border-[#1f2c42]">
              <Search className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                autoFocus
                placeholder="Search entities, trusts, properties, assets, or documents..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent text-slate-100 text-sm focus:outline-none"
              />
              <button
                onClick={() => setIsSearchOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-96 overflow-y-auto space-y-3">
              {searchQuery === '' ? (
                <div className="py-8 text-center text-slate-500">
                  Type to search across the entire Aurelia Family Office graph...
                </div>
              ) : (
                <>
                  <div>
                    <span className="text-[10px] text-[#d4af37] font-bold uppercase block mb-2">
                      ASSET POSITIONS ({searchResultsAssets.length})
                    </span>
                    <div className="space-y-1">
                      {searchResultsAssets.map((asset) => (
                        <div
                          key={asset.id}
                          onClick={() => {
                            setIsSearchOpen(false);
                            setActiveTab('PORTFOLIO');
                          }}
                          className="p-2.5 bg-[#0b0f17] hover:bg-[#151e2e] rounded border border-[#1f2c40] cursor-pointer flex items-center justify-between"
                        >
                          <div>
                            <span className="font-bold text-slate-100">{asset.name}</span>
                            <span className="text-slate-400 text-[10px] block">{asset.entityName}</span>
                          </div>
                          <span className="text-[#d4af37] font-bold">${(asset.valueUsd / 1e6).toFixed(1)}M</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] text-blue-400 font-bold uppercase block mb-2">
                      OWNERSHIP GRAPH NODES ({searchResultsNodes.length})
                    </span>
                    <div className="space-y-1">
                      {searchResultsNodes.map((node) => (
                        <div
                          key={node.id}
                          onClick={() => {
                            setIsSearchOpen(false);
                            setActiveTab('WEALTH_MAP');
                          }}
                          className="p-2.5 bg-[#0b0f17] hover:bg-[#151e2e] rounded border border-[#1f2c40] cursor-pointer flex items-center justify-between"
                        >
                          <div>
                            <span className="font-bold text-slate-100">{node.name}</span>
                            <span className="text-slate-400 text-[10px] block">{node.type} • {node.jurisdiction}</span>
                          </div>
                          <ChevronRight className="w-4 h-4 text-slate-500" />
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
