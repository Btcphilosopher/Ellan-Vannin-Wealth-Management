export interface FamilyMember {
  id: string;
  name: string;
  generation: 'Gen I' | 'Gen II' | 'Gen III' | 'Gen IV';
  role: string;
  citizenship: string[];
  residence: string;
  birthYear: number;
  email: string;
  status: 'Active' | 'Beneficiary' | 'Trustee';
}

export interface OwnershipNode {
  id: string;
  name: string;
  type: 'PERSON' | 'TRUST' | 'FOUNDATION' | 'COMPANY' | 'PARTNERSHIP' | 'FUND' | 'SPV' | 'ACCOUNT' | 'ASSET';
  jurisdiction?: string;
  valueUsd?: number;
  details?: string;
}

export interface OwnershipRelationship {
  id: string;
  fromId: string;
  toId: string;
  type: 'OWNS' | 'BENEFITS_FROM' | 'TRUSTEE_OF' | 'DIRECTOR_OF' | 'PARTNER_OF' | 'BENEFICIARY_OF' | 'CONTROLS' | 'MANAGES' | 'INVESTS_IN' | 'BORROWS_FROM';
  percentage?: number;
  economicShare?: number;
  votingShare?: number;
  notes?: string;
}

export interface AssetPosition {
  id: string;
  name: string;
  assetClass: 'PUBLIC_MARKETS' | 'PRIVATE_MARKETS' | 'REAL_ESTATE' | 'OPERATING_BUSINESSES' | 'COLLECTIBLES' | 'PERSONAL_AVIATION' | 'DIGITAL_IP' | 'CASH';
  subCategory: string;
  entityId: string;
  entityName: string;
  currency: 'USD' | 'EUR' | 'GBP' | 'CHF';
  valueUsd: number;
  costBasisUsd: number;
  unrealizedGainsUsd: number;
  twrPercent: number;
  irrPercent?: number;
  liquidityTier: 'T+1 Liquid' | 'T+30 Liquid' | 'Illiquid (<1 Year)' | 'Illiquid (Locked 3-10 Years)';
  lastValuationDate: string;
  valuationMethod: 'MARKET_PRICE' | 'APPRAISAL' | 'MANAGER_NAV' | 'DCF' | 'BOOK_VALUE';
  confidence: 'HIGH' | 'MEDIUM' | 'ESTIMATED';
  custodianBank?: string;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH' | 'SPECULATIVE';
  geography: string;
}

export interface PrivateFund {
  id: string;
  fundName: string;
  gpName: string;
  strategy: 'Buyout' | 'Venture Capital' | 'Private Credit' | 'Infrastructure' | 'Secondaries';
  vintageYear: number;
  currency: 'USD' | 'EUR' | 'GBP';
  commitmentUsd: number;
  calledCapitalUsd: number;
  uncalledCapitalUsd: number;
  navUsd: number;
  distributionsUsd: number;
  moic: number;
  dpi: number;
  tvpi: number;
  irr: number;
  holdingEntity: string;
}

export interface CapitalCallForecast {
  id: string;
  fundId: string;
  fundName: string;
  dueDate: string;
  callAmountUsd: number;
  purpose: string;
  cashAccountSource: string;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'SETTLED';
  urgencyDays: number;
}

export interface PropertyDigitalTwin {
  id: string;
  name: string;
  type: 'Residential Estate' | 'Commercial Plaza' | 'Alpine Chalet' | 'Development Land';
  location: string;
  owningEntity: string;
  valuationUsd: number;
  mortgageUsd: number;
  netEquityUsd: number;
  annualExpenseUsd: number;
  rentalIncomeUsd: number;
  staffCount: number;
  squareFeet: number;
  insurancePolicyNumber: string;
  insuranceExpiry: string;
  tenantsCount?: number;
}

export interface CollectibleItem {
  id: string;
  name: string;
  category: string;
  owningEntity: string;
  valuationUsd: number;
  insuredUsd: number;
  location: string;
  provenanceNotes: string;
}

export interface CollectibleAsset {
  id: string;
  name: string;
  category: 'Fine Art' | 'High Horology' | 'Classic Automobiles' | 'Yacht' | 'Private Jet';
  creatorOrMaker: string;
  year: number;
  purchasePriceUsd: number;
  currentAppraisalUsd: number;
  lastAppraisalDate: string;
  appraiser: string;
  locationCustodian: string;
  provenanceSummary: string;
  insuranceValuationUsd: number;
}

export interface DealItem {
  id: string;
  dealName: string;
  sector: string;
  geography: string;
  stage: 'SCREENING' | 'DUE_DILIGENCE' | 'INVESTMENT_MEMO' | 'COMMITTEE_REVIEW' | 'APPROVED' | 'EXECUTED';
  targetAllocationUsd: number;
  leadSponsor: string;
  expectedIrr: number;
  expectedMoic: number;
  valuationUsd: number;
  revenueUsd: number;
  ebitdaUsd: number;
  memoSummary: string;
  riskHighlights: string[];
}

export type PropertyItem = PropertyDigitalTwin;

export interface DocumentRecord {
  id: string;
  title: string;
  category: 'LEGAL_TRUST' | 'TAX_REGULATORY' | 'INVESTMENT_AGREEMENT' | 'PROPERTY_DEED' | 'INSURANCE_POLICY' | 'GOVERNANCE_MINUTES';
  owningEntity: string;
  effectiveDate: string;
  expiryDate?: string;
  fileSize: string;
  securityClassification: 'RESTRICTED_PRINCIPAL' | 'INVESTMENT_COMMITTEE' | 'ADVISOR_PERMITTED';
  summaryText: string;
  aiExtractedData: Record<string, string>;
  version: string;
}

export type DocumentItem = DocumentRecord;

export interface ScenarioSimulation {
  name: string;
  baselineNetWorthUsd: number;
  simulatedNetWorthUsd: number;
  baselineLiquidityUsd: number;
  simulatedLiquidityUsd: number;
  equityMarketShockPercent: number;
  interestRateChangeBp: number;
  capitalCallShockUsd: number;
  realEstatePriceShockPercent: number;
  fxGbpUsdChangePercent: number;
  resultingRiskStatus: 'OPTIMAL' | 'MODERATE_STRESS' | 'LIQUIDITY_WARNING' | 'CRITICAL';
  recommendations: string[];
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  objectType: string;
  objectId: string;
  details: string;
  ipAddress: string;
}

// Initial State Data for Aurelia Family Office
export const INITIAL_FAMILY_MEMBERS: FamilyMember[] = [
  {
    id: 'mem-1',
    name: 'Lord Arthur Aurelia',
    generation: 'Gen I',
    role: 'Family Principal & Patriarch',
    citizenship: ['United Kingdom', 'Switzerland'],
    residence: 'London, UK / St. Moritz',
    birthYear: 1952,
    email: 'arthur@aureliaoffice.ch',
    status: 'Active',
  },
  {
    id: 'mem-2',
    name: 'Lady Eleanor Aurelia',
    generation: 'Gen I',
    role: 'Matriarch & Foundation Chair',
    citizenship: ['United Kingdom'],
    residence: 'London, UK',
    birthYear: 1955,
    email: 'eleanor@aureliaoffice.ch',
    status: 'Active',
  },
  {
    id: 'mem-3',
    name: 'Julian Aurelia',
    generation: 'Gen II',
    role: 'Chief Investment Officer (Family)',
    citizenship: ['United Kingdom', 'United States'],
    residence: 'Geneva, Switzerland',
    birthYear: 1980,
    email: 'julian@aureliaoffice.ch',
    status: 'Active',
  },
  {
    id: 'mem-4',
    name: 'Marcus Aurelia',
    generation: 'Gen II',
    role: 'Head of Operating Companies',
    citizenship: ['United Kingdom'],
    residence: 'London, UK',
    birthYear: 1983,
    email: 'marcus@aureliaoffice.ch',
    status: 'Active',
  },
  {
    id: 'mem-5',
    name: 'Victoria Aurelia-Vane',
    generation: 'Gen II',
    role: 'Trust Beneficiary & Art Curator',
    citizenship: ['United Kingdom', 'France'],
    residence: 'Paris, France',
    birthYear: 1987,
    email: 'victoria@aureliaoffice.ch',
    status: 'Active',
  },
  {
    id: 'mem-6',
    name: 'Alexander Aurelia',
    generation: 'Gen III',
    role: 'Junior Beneficiary',
    citizenship: ['United Kingdom'],
    residence: 'London, UK',
    birthYear: 2008,
    email: 'alexander@aureliaoffice.ch',
    status: 'Beneficiary',
  },
  {
    id: 'mem-7',
    name: 'Sophia Aurelia',
    generation: 'Gen III',
    role: 'Junior Beneficiary',
    citizenship: ['United Kingdom'],
    residence: 'Geneva, Switzerland',
    birthYear: 2012,
    email: 'sophia@aureliaoffice.ch',
    status: 'Beneficiary',
  },
];

export const INITIAL_OWNERSHIP_NODES: OwnershipNode[] = [
  { id: 'node-fam', name: 'Aurelia Family', type: 'PERSON', details: 'Root Multigenerational Family' },
  { id: 'node-trust-1', name: 'Aurelia Dynastic Trust I', type: 'TRUST', jurisdiction: 'Jersey (Channel Islands)', valueUsd: 480000000 },
  { id: 'node-trust-2', name: 'Aurelia Childrens Trust II', type: 'TRUST', jurisdiction: 'Cayman Islands', valueUsd: 210000000 },
  { id: 'node-holdco', name: 'Aurelia Global Holdings SA', type: 'COMPANY', jurisdiction: 'Luxembourg', valueUsd: 540000000 },
  { id: 'node-re-holdco', name: 'Aurelia Real Estate Estates Ltd', type: 'COMPANY', jurisdiction: 'United Kingdom', valueUsd: 185000000 },
  { id: 'node-stiftung', name: 'Aurelia Philanthropic Foundation', type: 'FOUNDATION', jurisdiction: 'Zurich, Switzerland', valueUsd: 65000000 },
  { id: 'node-pe-spv', name: 'Aurelia Private Markets SPV I', type: 'SPV', jurisdiction: 'Delaware, USA', valueUsd: 168000000 },
  { id: 'node-opco', name: 'Aurelia Renewable Tech Corp', type: 'COMPANY', jurisdiction: 'United Kingdom', valueUsd: 340000000 },
  { id: 'node-aviation', name: 'Aurelia Sky Holdings LLC', type: 'SPV', jurisdiction: 'Malta', valueUsd: 62500000 },
  { id: 'node-bank-1', name: 'JPMorgan Chase Custody Account', type: 'ACCOUNT', jurisdiction: 'United States', valueUsd: 42500000 },
  { id: 'node-bank-2', name: 'UBS Wealth Management Cash', type: 'ACCOUNT', jurisdiction: 'Switzerland', valueUsd: 36100000 },
];

export const INITIAL_RELATIONSHIPS: OwnershipRelationship[] = [
  { id: 'rel-1', fromId: 'node-fam', toId: 'node-trust-1', type: 'BENEFICIARY_OF', percentage: 100, economicShare: 100, notes: 'Revocable Discretionary Trust for Gen I & II' },
  { id: 'rel-2', fromId: 'node-fam', toId: 'node-trust-2', type: 'BENEFICIARY_OF', percentage: 100, economicShare: 100, notes: 'Irrevocable Trust for Gen III & IV' },
  { id: 'rel-3', fromId: 'node-trust-1', toId: 'node-holdco', type: 'OWNS', percentage: 85, economicShare: 85, votingShare: 100, notes: 'Majority Shareholding in Luxembourg HoldCo' },
  { id: 'rel-4', fromId: 'node-trust-2', toId: 'node-holdco', type: 'OWNS', percentage: 15, economicShare: 15, votingShare: 0, notes: 'Non-voting Preferred Stock' },
  { id: 'rel-5', fromId: 'node-holdco', toId: 'node-pe-spv', type: 'OWNS', percentage: 100, economicShare: 100, votingShare: 100, notes: 'Private Equity Holding Vehicle' },
  { id: 'rel-6', fromId: 'node-holdco', toId: 'node-re-holdco', type: 'OWNS', percentage: 100, economicShare: 100, votingShare: 100, notes: 'UK Real Estate Entity' },
  { id: 'rel-7', fromId: 'node-holdco', toId: 'node-opco', type: 'OWNS', percentage: 68, economicShare: 68, votingShare: 72, notes: 'Majority Operating Company Control' },
  { id: 'rel-8', fromId: 'node-fam', toId: 'node-stiftung', type: 'CONTROLS', percentage: 100, notes: 'Stiftungsrat Board Appointment Rights' },
  { id: 'rel-9', fromId: 'node-trust-1', toId: 'node-aviation', type: 'OWNS', percentage: 100, notes: 'Aviation & Marine SPV Owner' },
];

export const INITIAL_ASSET_POSITIONS: AssetPosition[] = [
  // Public Markets
  {
    id: 'ast-pub-1',
    name: 'S&P 500 Institutional Core Index Fund',
    assetClass: 'PUBLIC_MARKETS',
    subCategory: 'US Equities',
    entityId: 'node-holdco',
    entityName: 'Aurelia Global Holdings SA',
    currency: 'USD',
    valueUsd: 112500000,
    costBasisUsd: 78000000,
    unrealizedGainsUsd: 34500000,
    twrPercent: 14.2,
    liquidityTier: 'T+1 Liquid',
    lastValuationDate: '2026-09-09',
    valuationMethod: 'MARKET_PRICE',
    confidence: 'HIGH',
    custodianBank: 'JPMorgan Securities',
    riskRating: 'MEDIUM',
    geography: 'United States',
  },
  {
    id: 'ast-pub-2',
    name: 'US Treasury Inflation-Protected Securities (TIPS) 2028-2032',
    assetClass: 'PUBLIC_MARKETS',
    subCategory: 'Sovereign Debt',
    entityId: 'node-holdco',
    entityName: 'Aurelia Global Holdings SA',
    currency: 'USD',
    valueUsd: 75000000,
    costBasisUsd: 74200000,
    unrealizedGainsUsd: 800000,
    twrPercent: 4.8,
    liquidityTier: 'T+1 Liquid',
    lastValuationDate: '2026-09-09',
    valuationMethod: 'MARKET_PRICE',
    confidence: 'HIGH',
    custodianBank: 'UBS AG Zurich',
    riskRating: 'LOW',
    geography: 'United States',
  },
  {
    id: 'ast-pub-3',
    name: 'iShares Global Energy Transition & Clean Tech ETF',
    assetClass: 'PUBLIC_MARKETS',
    subCategory: 'Global Thematic Equities',
    entityId: 'node-holdco',
    entityName: 'Aurelia Global Holdings SA',
    currency: 'EUR',
    valueUsd: 38300000,
    costBasisUsd: 42000000,
    unrealizedGainsUsd: -3700000,
    twrPercent: -6.4,
    liquidityTier: 'T+1 Liquid',
    lastValuationDate: '2026-09-09',
    valuationMethod: 'MARKET_PRICE',
    confidence: 'HIGH',
    custodianBank: 'JPMorgan Chase',
    riskRating: 'HIGH',
    geography: 'Global / Europe',
  },
  {
    id: 'ast-pub-4',
    name: 'Physical Allocated Gold Bullion Trust (Zurich Vaults)',
    assetClass: 'PUBLIC_MARKETS',
    subCategory: 'Precious Metals / Commodities',
    entityId: 'node-trust-1',
    entityName: 'Aurelia Dynastic Trust I',
    currency: 'USD',
    valueUsd: 20000000,
    costBasisUsd: 13500000,
    unrealizedGainsUsd: 6500000,
    twrPercent: 18.6,
    liquidityTier: 'T+30 Liquid',
    lastValuationDate: '2026-09-09',
    valuationMethod: 'MARKET_PRICE',
    confidence: 'HIGH',
    custodianBank: 'LGT Bank Liechtenstein / ZKB',
    riskRating: 'LOW',
    geography: 'Switzerland',
  },

  // Private Markets
  {
    id: 'ast-pe-1',
    name: 'Sequoia Capital Global Growth Fund XVIII LP',
    assetClass: 'PRIVATE_MARKETS',
    subCategory: 'Venture Capital & Tech',
    entityId: 'node-pe-spv',
    entityName: 'Aurelia Private Markets SPV I',
    currency: 'USD',
    valueUsd: 68400000,
    costBasisUsd: 42000000,
    unrealizedGainsUsd: 26400000,
    twrPercent: 26.8,
    irrPercent: 28.4,
    liquidityTier: 'Illiquid (Locked 3-10 Years)',
    lastValuationDate: '2026-06-30',
    valuationMethod: 'MANAGER_NAV',
    confidence: 'HIGH',
    custodianBank: 'State Street Fund Services',
    riskRating: 'HIGH',
    geography: 'United States & Global',
  },
  {
    id: 'ast-pe-2',
    name: 'KKR European Buyout Fund V LP',
    assetClass: 'PRIVATE_MARKETS',
    subCategory: 'Private Equity Buyout',
    entityId: 'node-pe-spv',
    entityName: 'Aurelia Private Markets SPV I',
    currency: 'EUR',
    valueUsd: 58200000,
    costBasisUsd: 38000000,
    unrealizedGainsUsd: 20200000,
    twrPercent: 19.5,
    irrPercent: 21.2,
    liquidityTier: 'Illiquid (Locked 3-10 Years)',
    lastValuationDate: '2026-06-30',
    valuationMethod: 'MANAGER_NAV',
    confidence: 'HIGH',
    custodianBank: 'BNP Paribas Luxembourg',
    riskRating: 'MEDIUM',
    geography: 'Western Europe',
  },
  {
    id: 'ast-pe-3',
    name: 'Insight Venture Partners Growth Fund XII LP',
    assetClass: 'PRIVATE_MARKETS',
    subCategory: 'Software & Growth Equity',
    entityId: 'node-pe-spv',
    entityName: 'Aurelia Private Markets SPV I',
    currency: 'USD',
    valueUsd: 41400000,
    costBasisUsd: 25000000,
    unrealizedGainsUsd: 16400000,
    twrPercent: 22.1,
    irrPercent: 24.0,
    liquidityTier: 'Illiquid (Locked 3-10 Years)',
    lastValuationDate: '2026-06-30',
    valuationMethod: 'MANAGER_NAV',
    confidence: 'HIGH',
    custodianBank: 'BNY Mellon',
    riskRating: 'HIGH',
    geography: 'North America',
  },

  // Operating Businesses
  {
    id: 'ast-opco-1',
    name: 'Aurelia Renewable Tech Corp (68% Direct Stake)',
    assetClass: 'OPERATING_BUSINESSES',
    subCategory: 'Clean Energy Infrastructure',
    entityId: 'node-opco',
    entityName: 'Aurelia Renewable Tech Corp',
    currency: 'GBP',
    valueUsd: 340000000,
    costBasisUsd: 120000000,
    unrealizedGainsUsd: 220000000,
    twrPercent: 22.5,
    irrPercent: 25.1,
    liquidityTier: 'Illiquid (<1 Year)',
    lastValuationDate: '2026-08-15',
    valuationMethod: 'DCF',
    confidence: 'HIGH',
    riskRating: 'MEDIUM',
    geography: 'United Kingdom / Europe',
  },

  // Real Estate / Real Assets
  {
    id: 'ast-re-1',
    name: 'Mayfair Townhouse & Gallery (12 Grosvenor Sq, London)',
    assetClass: 'REAL_ESTATE',
    subCategory: 'Prime Residential Estate',
    entityId: 'node-re-holdco',
    entityName: 'Aurelia Real Estate Estates Ltd',
    currency: 'GBP',
    valueUsd: 78000000,
    costBasisUsd: 45000000,
    unrealizedGainsUsd: 33000000,
    twrPercent: 8.5,
    liquidityTier: 'Illiquid (<1 Year)',
    lastValuationDate: '2026-05-10',
    valuationMethod: 'APPRAISAL',
    confidence: 'HIGH',
    riskRating: 'LOW',
    geography: 'London, UK',
  },
  {
    id: 'ast-re-2',
    name: 'Cote d\'Azur Waterfront Estate (Villa Les Palmier, Saint-Jean-Cap-Ferrat)',
    assetClass: 'REAL_ESTATE',
    subCategory: 'Prime Residential Villa',
    entityId: 'node-re-holdco',
    entityName: 'Aurelia Real Estate Estates Ltd',
    currency: 'EUR',
    valueUsd: 52000000,
    costBasisUsd: 38000000,
    unrealizedGainsUsd: 14000000,
    twrPercent: 6.2,
    liquidityTier: 'Illiquid (<1 Year)',
    lastValuationDate: '2026-04-12',
    valuationMethod: 'APPRAISAL',
    confidence: 'HIGH',
    riskRating: 'LOW',
    geography: 'France',
  },
  {
    id: 'ast-re-3',
    name: 'St. Moritz Alpine Lodge & Estate (Engadin Valley)',
    assetClass: 'REAL_ESTATE',
    subCategory: 'Alpine Luxury Residence',
    entityId: 'node-re-holdco',
    entityName: 'Aurelia Real Estate Estates Ltd',
    currency: 'CHF',
    valueUsd: 35000000,
    costBasisUsd: 28000000,
    unrealizedGainsUsd: 7000000,
    twrPercent: 5.1,
    liquidityTier: 'Illiquid (<1 Year)',
    lastValuationDate: '2026-02-20',
    valuationMethod: 'APPRAISAL',
    confidence: 'HIGH',
    riskRating: 'LOW',
    geography: 'Switzerland',
  },
  {
    id: 'ast-re-4',
    name: 'Mayfair Commercial Plaza & Retail Arcade (Bond Street)',
    assetClass: 'REAL_ESTATE',
    subCategory: 'Commercial Real Estate',
    entityId: 'node-re-holdco',
    entityName: 'Aurelia Real Estate Estates Ltd',
    currency: 'GBP',
    valueUsd: 20000000,
    costBasisUsd: 16500000,
    unrealizedGainsUsd: 3500000,
    twrPercent: 7.4,
    liquidityTier: 'Illiquid (<1 Year)',
    lastValuationDate: '2026-07-01',
    valuationMethod: 'DCF',
    confidence: 'HIGH',
    riskRating: 'LOW',
    geography: 'London, UK',
  },

  // Collectibles & Art
  {
    id: 'ast-col-1',
    name: 'Claude Monet — Nymphéas (Water Lilies 1914)',
    assetClass: 'COLLECTIBLES',
    subCategory: 'Impressionist Fine Art',
    entityId: 'node-trust-1',
    entityName: 'Aurelia Dynastic Trust I',
    currency: 'USD',
    valueUsd: 32000000,
    costBasisUsd: 18500000,
    unrealizedGainsUsd: 13500000,
    twrPercent: 12.1,
    liquidityTier: 'Illiquid (<1 Year)',
    lastValuationDate: '2026-01-15',
    valuationMethod: 'APPRAISAL',
    confidence: 'HIGH',
    custodianBank: 'Geneva FreePort Storage Vault',
    riskRating: 'MEDIUM',
    geography: 'Switzerland',
  },
  {
    id: 'ast-col-2',
    name: 'Vintage Automobile Collection (1962 Ferrari 250 GT SWB & 1955 Aston DB3S)',
    assetClass: 'COLLECTIBLES',
    subCategory: 'Classic Sports Cars',
    entityId: 'node-trust-1',
    entityName: 'Aurelia Dynastic Trust I',
    currency: 'GBP',
    valueUsd: 16200000,
    costBasisUsd: 9800000,
    unrealizedGainsUsd: 6400000,
    twrPercent: 9.8,
    liquidityTier: 'Illiquid (<1 Year)',
    lastValuationDate: '2026-03-30',
    valuationMethod: 'APPRAISAL',
    confidence: 'HIGH',
    custodianBank: 'Goodwood Climate-Controlled Facility',
    riskRating: 'MEDIUM',
    geography: 'United Kingdom',
  },

  // Personal Assets & Aviation
  {
    id: 'ast-avi-1',
    name: 'Gulfstream G650ER Long-Range Jet (Reg 9H-AURE)',
    assetClass: 'PERSONAL_AVIATION',
    subCategory: 'Executive Aircraft',
    entityId: 'node-aviation',
    entityName: 'Aurelia Sky Holdings LLC',
    currency: 'USD',
    valueUsd: 42500000,
    costBasisUsd: 58000000,
    unrealizedGainsUsd: -15500000,
    twrPercent: -4.2,
    liquidityTier: 'Illiquid (<1 Year)',
    lastValuationDate: '2026-06-01',
    valuationMethod: 'APPRAISAL',
    confidence: 'HIGH',
    riskRating: 'MEDIUM',
    geography: 'Malta / Global',
  },
  {
    id: 'ast-avi-2',
    name: '58m Custom Superyacht M/Y "Aurelia Star"',
    assetClass: 'PERSONAL_AVIATION',
    subCategory: 'Superyacht',
    entityId: 'node-aviation',
    entityName: 'Aurelia Sky Holdings LLC',
    currency: 'EUR',
    valueUsd: 20000000,
    costBasisUsd: 32000000,
    unrealizedGainsUsd: -12000000,
    twrPercent: -3.8,
    liquidityTier: 'Illiquid (<1 Year)',
    lastValuationDate: '2026-05-15',
    valuationMethod: 'APPRAISAL',
    confidence: 'HIGH',
    riskRating: 'MEDIUM',
    geography: 'Monaco / Mediterranean',
  },

  // Digital & IP Assets
  {
    id: 'ast-dig-1',
    name: 'Bitcoin (BTC) Cold Storage Reserve (Multi-Sig Vault)',
    assetClass: 'DIGITAL_IP',
    subCategory: 'Digital Assets / Sovereign Reserve',
    entityId: 'node-holdco',
    entityName: 'Aurelia Global Holdings SA',
    currency: 'USD',
    valueUsd: 28400000,
    costBasisUsd: 14200000,
    unrealizedGainsUsd: 14200000,
    twrPercent: 42.0,
    liquidityTier: 'T+1 Liquid',
    lastValuationDate: '2026-09-09',
    valuationMethod: 'MARKET_PRICE',
    confidence: 'HIGH',
    custodianBank: 'Anchor Labs / Swiss Institutional Custody',
    riskRating: 'SPECULATIVE',
    geography: 'Switzerland',
  },

  // Cash & Bank Accounts
  {
    id: 'ast-cash-1',
    name: 'JPMorgan Chase USD Institutional Cash & Money Market',
    assetClass: 'CASH',
    subCategory: 'Short-term Treasury Yield',
    entityId: 'node-bank-1',
    entityName: 'JPMorgan Chase Custody Account',
    currency: 'USD',
    valueUsd: 42500000,
    costBasisUsd: 42500000,
    unrealizedGainsUsd: 0,
    twrPercent: 5.2,
    liquidityTier: 'T+1 Liquid',
    lastValuationDate: '2026-09-09',
    valuationMethod: 'BOOK_VALUE',
    confidence: 'HIGH',
    custodianBank: 'JPMorgan Chase Bank NA',
    riskRating: 'LOW',
    geography: 'United States',
  },
  {
    id: 'ast-cash-2',
    name: 'UBS Wealth Management CHF/EUR Cash Buffer',
    assetClass: 'CASH',
    subCategory: 'Multi-Currency Bank Balance',
    entityId: 'node-bank-2',
    entityName: 'UBS Wealth Management Cash',
    currency: 'EUR',
    valueUsd: 36100000,
    costBasisUsd: 36100000,
    unrealizedGainsUsd: 0,
    twrPercent: 3.8,
    liquidityTier: 'T+1 Liquid',
    lastValuationDate: '2026-09-09',
    valuationMethod: 'BOOK_VALUE',
    confidence: 'HIGH',
    custodianBank: 'UBS Switzerland AG',
    riskRating: 'LOW',
    geography: 'Switzerland',
  },
];

export const INITIAL_PRIVATE_FUNDS: PrivateFund[] = [
  {
    id: 'fund-1',
    fundName: 'Sequoia Capital Global Growth XVIII LP',
    gpName: 'Sequoia Capital',
    strategy: 'Venture Capital',
    vintageYear: 2021,
    currency: 'USD',
    commitmentUsd: 50000000,
    calledCapitalUsd: 38000000,
    uncalledCapitalUsd: 12000000,
    navUsd: 68400000,
    distributionsUsd: 22000000,
    moic: 2.38,
    dpi: 0.58,
    tvpi: 2.38,
    irr: 28.4,
    holdingEntity: 'Aurelia Private Markets SPV I',
  },
  {
    id: 'fund-2',
    fundName: 'KKR European Buyout Fund V LP',
    gpName: 'Kohlberg Kravis Roberts & Co',
    strategy: 'Buyout',
    vintageYear: 2019,
    currency: 'EUR',
    commitmentUsd: 60000000,
    calledCapitalUsd: 48000000,
    uncalledCapitalUsd: 12000000,
    navUsd: 58200000,
    distributionsUsd: 34000000,
    moic: 1.92,
    dpi: 0.71,
    tvpi: 1.92,
    irr: 21.2,
    holdingEntity: 'Aurelia Private Markets SPV I',
  },
  {
    id: 'fund-3',
    fundName: 'Insight Venture Partners Growth XII LP',
    gpName: 'Insight Partners',
    strategy: 'Venture Capital',
    vintageYear: 2022,
    currency: 'USD',
    commitmentUsd: 40000000,
    calledCapitalUsd: 19000000,
    uncalledCapitalUsd: 21000000,
    navUsd: 41400000,
    distributionsUsd: 8500000,
    moic: 2.63,
    dpi: 0.45,
    tvpi: 2.63,
    irr: 24.0,
    holdingEntity: 'Aurelia Private Markets SPV I',
  },
];

export const INITIAL_CAPITAL_CALLS: CapitalCallForecast[] = [
  {
    id: 'call-1',
    fundId: 'fund-3',
    fundName: 'Insight Venture Partners Growth XII LP',
    dueDate: '2026-10-14',
    callAmountUsd: 4200000,
    purpose: 'Follow-on investment in AI Grid Infrastructure platform',
    cashAccountSource: 'JPMorgan Chase USD Cash',
    status: 'PENDING_APPROVAL',
    urgencyDays: 34,
  },
  {
    id: 'call-2',
    fundId: 'fund-1',
    fundName: 'Sequoia Capital Global Growth XVIII LP',
    dueDate: '2026-11-02',
    callAmountUsd: 3500000,
    purpose: 'Co-investment drawdown in Quantum Cloud Compute Inc.',
    cashAccountSource: 'JPMorgan Chase USD Cash',
    status: 'PENDING_APPROVAL',
    urgencyDays: 53,
  },
  {
    id: 'call-3',
    fundId: 'fund-2',
    fundName: 'KKR European Buyout Fund V LP',
    dueDate: '2026-12-10',
    callAmountUsd: 5800000,
    purpose: 'Add-on acquisition for Nordic Logistics Group',
    cashAccountSource: 'UBS Wealth Management Cash',
    status: 'PENDING_APPROVAL',
    urgencyDays: 91,
  },
];

export const INITIAL_PROPERTIES: PropertyDigitalTwin[] = [
  {
    id: 'prop-1',
    name: 'Mayfair Townhouse & Private Gallery',
    type: 'Residential Estate',
    location: '12 Grosvenor Square, London W1K, UK',
    owningEntity: 'Aurelia Real Estate Estates Ltd',
    valuationUsd: 78000000,
    mortgageUsd: 22000000,
    netEquityUsd: 56000000,
    annualExpenseUsd: 1450000,
    rentalIncomeUsd: 0,
    staffCount: 6,
    squareFeet: 14500,
    insurancePolicyNumber: 'LLOYDS-UK-884219',
    insuranceExpiry: '2027-03-31',
  },
  {
    id: 'prop-2',
    name: 'Villa Les Palmiers Waterfront Estate',
    type: 'Residential Estate',
    location: 'Saint-Jean-Cap-Ferrat, Cote d\'Azur, France',
    owningEntity: 'Aurelia Real Estate Estates Ltd',
    valuationUsd: 52000000,
    mortgageUsd: 12000000,
    netEquityUsd: 40000000,
    annualExpenseUsd: 980000,
    rentalIncomeUsd: 0,
    staffCount: 4,
    squareFeet: 11200,
    insurancePolicyNumber: 'AXA-FR-449102',
    insuranceExpiry: '2027-06-30',
  },
  {
    id: 'prop-3',
    name: 'St. Moritz Engadin Alpine Lodge',
    type: 'Alpine Chalet',
    location: 'Via Suvretta, St. Moritz 7500, Switzerland',
    owningEntity: 'Aurelia Real Estate Estates Ltd',
    valuationUsd: 35000000,
    mortgageUsd: 0,
    netEquityUsd: 35000000,
    annualExpenseUsd: 620000,
    rentalIncomeUsd: 0,
    staffCount: 3,
    squareFeet: 8900,
    insurancePolicyNumber: 'ZURICH-CH-901188',
    insuranceExpiry: '2026-12-15',
  },
  {
    id: 'prop-4',
    name: 'Mayfair Commercial Retail Plaza',
    type: 'Commercial Plaza',
    location: '142 Bond Street, London W1S, UK',
    owningEntity: 'Aurelia Real Estate Estates Ltd',
    valuationUsd: 20000000,
    mortgageUsd: 6000000,
    netEquityUsd: 14000000,
    annualExpenseUsd: 380000,
    rentalIncomeUsd: 1420000,
    staffCount: 2,
    squareFeet: 18400,
    tenantsCount: 4,
    insurancePolicyNumber: 'AVIVA-UK-331002',
    insuranceExpiry: '2027-01-20',
  },
];

export const INITIAL_COLLECTIBLES: CollectibleItem[] = [
  {
    id: 'col-1',
    name: 'Claude Monet — Nymphéas (Water Lilies, 1914)',
    category: 'FINE_ART',
    owningEntity: 'Aurelia Dynastic Trust I',
    valuationUsd: 42000000,
    insuredUsd: 45000000,
    location: 'Geneva FreePort Vault, Switzerland',
    provenanceNotes: 'Authenticated by Christie’s Geneva 2022. Full provenance chain back to Durand-Ruel collection.',
  },
  {
    id: 'col-2',
    name: '1962 Ferrari 250 GTO SWB (Chassis #3851GT)',
    category: 'CLASSIC_CARS',
    owningEntity: 'Aurelia Dynastic Trust I',
    valuationUsd: 45000000,
    insuredUsd: 50000000,
    location: 'Goodwood Climate Garage, UK',
    provenanceNotes: 'Ferrari Classiche certified. Matching numbers, raced at 1963 Tour de France Automobile.',
  },
  {
    id: 'col-3',
    name: 'Gulfstream G650ER Jet (N770AF / 9H-AURE)',
    category: 'AVIATION',
    owningEntity: 'Aurelia Sky Holdings LLC',
    valuationUsd: 62500000,
    insuredUsd: 65000000,
    location: 'Malta / Farnborough Airport',
    provenanceNotes: 'Malta SPV registered. Commercial charter permit, 1,200 airframe hours.',
  },
  {
    id: 'col-4',
    name: '65m Custom Superyacht "M/Y Aurelia"',
    category: 'YACHT',
    owningEntity: 'Aurelia Sky Holdings LLC',
    valuationUsd: 48200000,
    insuredUsd: 52000000,
    location: 'Monaco / Cote d\'Azur',
    provenanceNotes: 'Cayman Islands flagged. Lürssen custom build, MCA commercial code compliant.',
  },
];

export const INITIAL_DEALS: DealItem[] = [
  {
    id: 'deal-1',
    dealName: 'Project Helios — NextGen Grid Storage',
    sector: 'Clean Energy Tech',
    geography: 'United Kingdom / Nordics',
    stage: 'COMMITTEE_REVIEW',
    targetAllocationUsd: 15000000,
    leadSponsor: 'Aurelia Direct Investment Desk',
    expectedIrr: 26.5,
    expectedMoic: 3.2,
    valuationUsd: 120000000,
    revenueUsd: 18500000,
    ebitdaUsd: 4200000,
    memoSummary: 'Series B lead ticket in grid-scale iron-air battery storage manufacturer with guaranteed UK Grid off-take contracts.',
    riskHighlights: ['Regulatory approval delay in Nordics', 'Key personnel retention clause required', 'CapTable dilution guardrails'],
  },
  {
    id: 'deal-2',
    dealName: 'Project Alpine BioTech Buyout',
    sector: 'Healthcare & Life Sciences',
    geography: 'Switzerland',
    stage: 'DUE_DILIGENCE',
    targetAllocationUsd: 28000000,
    leadSponsor: 'Roche Venture Syndicate',
    expectedIrr: 22.0,
    expectedMoic: 2.8,
    valuationUsd: 210000000,
    revenueUsd: 42000000,
    ebitdaUsd: 11000000,
    memoSummary: 'Majority buyout of Swiss clinical trial software developer with 85% recurring SaaS revenues and zero debt.',
    riskHighlights: ['Competition from US incumbents', 'EU MDR compliance updates needed'],
  },
];

export const INITIAL_DOCUMENTS: DocumentRecord[] = [
  {
    id: 'doc-1',
    title: 'Aurelia Dynastic Trust I — Deed of Trust & Settlement',
    category: 'LEGAL_TRUST',
    owningEntity: 'Aurelia Dynastic Trust I',
    effectiveDate: '2004-06-18',
    fileSize: '4.8 MB',
    securityClassification: 'RESTRICTED_PRINCIPAL',
    summaryText: 'Primary settlement establishing Jersey law discretionary trust with protector committee and generation succession rules.',
    aiExtractedData: {
      'Governing Law': 'Jersey (Channel Islands)',
      'Protector': 'Lord Arthur Aurelia & Independent Trustee Corp',
      'Revocability': 'Irrevocable Discretionary',
      'Tax Residence': 'Non-UK Resident Trust',
    },
    version: 'v3.2 (Amended 2021)',
  },
  {
    id: 'doc-2',
    title: 'Aurelia Global Holdings SA — 2025 Audited Financials & Tax Return',
    category: 'TAX_REGULATORY',
    owningEntity: 'Aurelia Global Holdings SA',
    effectiveDate: '2026-03-31',
    fileSize: '12.4 MB',
    securityClassification: 'INVESTMENT_COMMITTEE',
    summaryText: 'Luxembourg tax clearance certificate and PwC audited statement confirming consolidated net assets.',
    aiExtractedData: {
      'Auditor': 'PricewaterhouseCoopers Luxembourg',
      'Net Asset Value': '€488,400,000 ($540M USD equivalent)',
      'Effective Tax Rate': '2.8% (Luxembourg Soparfi Regime)',
      'Status': 'Fully Compliant & Approved',
    },
    version: 'v1.0 Final',
  },
  {
    id: 'doc-3',
    title: 'Sequoia Growth XVIII — Limited Partnership Agreement',
    category: 'INVESTMENT_AGREEMENT',
    owningEntity: 'Aurelia Private Markets SPV I',
    effectiveDate: '2021-09-15',
    fileSize: '8.1 MB',
    securityClassification: 'INVESTMENT_COMMITTEE',
    summaryText: 'Side letter and LPA specifying $50M commitment, 1.5% management fee, and 20% hurdle rate.',
    aiExtractedData: {
      'Commitment': '$50,000,000 USD',
      'Management Fee': '1.5% on Committed during Investment Period',
      'Hurdle Rate': '8.0% Preferred Return',
      'Carried Interest': '20.0%',
    },
    version: 'v1.0 Executed',
  },
  {
    id: 'doc-4',
    title: '12 Grosvenor Square — Freehold Title & Lloyds Building Insurance',
    category: 'PROPERTY_DEED',
    owningEntity: 'Aurelia Real Estate Estates Ltd',
    effectiveDate: '2023-01-10',
    expiryDate: '2027-03-31',
    fileSize: '6.2 MB',
    securityClassification: 'ADVISOR_PERMITTED',
    summaryText: 'HM Land Registry title deed and £85M replacement cost building insurance policy.',
    aiExtractedData: {
      'Land Registry Title': 'NGL883901',
      'Sum Insured': '£85,000,000',
      'Annual Premium': '£42,500',
    },
    version: 'v2.1 Active',
  },
];

export const INITIAL_AUDIT_LOGS: AuditEvent[] = [
  {
    id: 'aud-1',
    timestamp: '2026-09-10 07:15:22 UTC',
    actor: 'System Integrity Engine',
    action: 'VALUATION_RECONCILED',
    objectType: 'AssetPosition',
    objectId: 'ast-pub-1',
    details: 'Daily valuation updated from JPMorgan Custody feed: $112.5M USD',
    ipAddress: '10.0.4.12 (Internal)',
  },
  {
    id: 'aud-2',
    timestamp: '2026-09-09 18:40:05 UTC',
    actor: 'Julian Aurelia (CIO)',
    action: 'CAPITAL_CALL_REVIEWED',
    objectType: 'CapitalCallForecast',
    objectId: 'call-1',
    details: 'Approved $4.2M capital call for Insight Venture XII due Oct 14',
    ipAddress: '194.230.145.8 (Geneva Office)',
  },
  {
    id: 'aud-3',
    timestamp: '2026-09-08 14:22:11 UTC',
    actor: 'Gemini 3.6 Document AI',
    action: 'DOCUMENT_EXTRACTED',
    objectType: 'DocumentRecord',
    objectId: 'doc-2',
    details: 'Parsed PwC Audited Financials, verified zero tax exposure discrepancy',
    ipAddress: '127.0.0.1 (Server Agent)',
  },
];
