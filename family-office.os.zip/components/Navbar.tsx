'use client';

import React from 'react';
import {
  LayoutDashboard,
  GitFork,
  Scale,
  PieChart,
  Briefcase,
  Layers,
  Building2,
  Sparkles,
  Activity,
  FileCheck2,
  FolderArchive,
  Cpu,
  BotMessageSquare,
} from 'lucide-react';

export type NavTab =
  | 'OVERVIEW'
  | 'WEALTH_MAP'
  | 'NET_WORTH'
  | 'PORTFOLIO'
  | 'PRIVATE_MARKETS'
  | 'DEAL_ROOM'
  | 'PROPERTY_OS'
  | 'COLLECTIBLES'
  | 'LIQUIDITY_RISK'
  | 'TAX_GOVERNANCE'
  | 'DOCUMENTS'
  | 'DIGITAL_TWIN'
  | 'ASK_GEMINI';

interface NavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
}

export const NAV_ITEMS: { id: NavTab; label: string; icon: React.ElementType }[] = [
  { id: 'OVERVIEW', label: 'OVERVIEW', icon: LayoutDashboard },
  { id: 'WEALTH_MAP', label: 'WEALTH MAP', icon: GitFork },
  { id: 'NET_WORTH', label: 'NET WORTH', icon: Scale },
  { id: 'PORTFOLIO', label: 'PORTFOLIO', icon: PieChart },
  { id: 'PRIVATE_MARKETS', label: 'PRIVATE MARKETS', icon: Briefcase },
  { id: 'DEAL_ROOM', label: 'DEAL ROOM', icon: Layers },
  { id: 'PROPERTY_OS', label: 'PROPERTY.OS', icon: Building2 },
  { id: 'COLLECTIBLES', label: 'COLLECTIBLES', icon: Sparkles },
  { id: 'LIQUIDITY_RISK', label: 'LIQUIDITY & RISK', icon: Activity },
  { id: 'TAX_GOVERNANCE', label: 'TAX & GOVERNANCE', icon: FileCheck2 },
  { id: 'DOCUMENTS', label: 'DOCUMENTS', icon: FolderArchive },
  { id: 'DIGITAL_TWIN', label: 'DIGITAL TWIN', icon: Cpu },
  { id: 'ASK_GEMINI', label: 'ASK GEMINI 3.6', icon: BotMessageSquare },
];

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <nav className="border-b border-[#1d2636] bg-[#0e131f] px-2 lg:px-6 overflow-x-auto no-scrollbar">
      <div className="flex items-center gap-1 min-w-max py-1.5">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          const isGemini = item.id === 'ASK_GEMINI';

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded text-xs font-mono font-semibold tracking-wide transition-all ${
                isActive
                  ? isGemini
                    ? 'bg-[#231b0c] text-[#d4af37] border border-[#d4af37]/60 shadow'
                    : 'bg-[#182234] text-slate-100 border border-[#2d3f5e] shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#141b29]'
              }`}
            >
              <Icon
                className={`w-3.5 h-3.5 ${
                  isActive
                    ? isGemini
                      ? 'text-[#d4af37]'
                      : 'text-[#d4af37]'
                    : 'text-slate-500'
                }`}
              />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
