'use client';

import React, { useState } from 'react';
import { X, Plus, Check } from 'lucide-react';

interface NewRecordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: any) => void;
}

export const NewRecordModal: React.FC<NewRecordModalProps> = ({
  isOpen,
  onClose,
  onSave,
}) => {
  const [recordType, setRecordType] = useState<'ASSET' | 'ENTITY' | 'CAPITAL_CALL' | 'DOCUMENT'>('ASSET');
  const [name, setName] = useState('');
  const [valueUsd, setValueUsd] = useState('');
  const [entityName, setEntityName] = useState('');
  const [details, setDetails] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      id: `custom-${Date.now()}`,
      type: recordType,
      name,
      valueUsd: Number(valueUsd) || 0,
      entityName,
      details,
      timestamp: new Date().toISOString(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#121927] border border-[#233148] rounded-lg max-w-lg w-full p-6 space-y-4 shadow-2xl font-mono text-xs text-slate-100">
        <div className="flex items-center justify-between pb-3 border-b border-[#1f2c42]">
          <div className="flex items-center gap-2 text-[#d4af37]">
            <Plus className="w-4 h-4" />
            <h2 className="text-sm font-bold uppercase tracking-wider">RECORD NEW LEDGER ENTRY</h2>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-100">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-slate-400 uppercase mb-1">Record Type</label>
            <select
              value={recordType}
              onChange={(e) => setRecordType(e.target.value as any)}
              className="w-full bg-[#0b0f17] border border-[#26354e] text-slate-100 p-2 rounded"
            >
              <option value="ASSET">Asset Position</option>
              <option value="ENTITY">Ownership Entity / SPV</option>
              <option value="CAPITAL_CALL">Capital Call Drawdown</option>
              <option value="DOCUMENT">Vault Document</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 uppercase mb-1">Name / Identifier</label>
            <input
              type="text"
              required
              placeholder="e.g. Zurich Commercial Retail SPV"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#0b0f17] border border-[#26354e] text-slate-100 p-2 rounded"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-400 uppercase mb-1">Valuation (USD)</label>
              <input
                type="number"
                placeholder="25000000"
                value={valueUsd}
                onChange={(e) => setValueUsd(e.target.value)}
                className="w-full bg-[#0b0f17] border border-[#26354e] text-slate-100 p-2 rounded"
              />
            </div>
            <div>
              <label className="block text-slate-400 uppercase mb-1">Owning Entity</label>
              <input
                type="text"
                placeholder="Aurelia Global Holdings SA"
                value={entityName}
                onChange={(e) => setEntityName(e.target.value)}
                className="w-full bg-[#0b0f17] border border-[#26354e] text-slate-100 p-2 rounded"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-400 uppercase mb-1">Audit Notes / Rationale</label>
            <textarea
              rows={3}
              placeholder="Audit trail and appraisal notes..."
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              className="w-full bg-[#0b0f17] border border-[#26354e] text-slate-100 p-2 rounded"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#1f2c42]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#1b263b] hover:bg-[#283856] text-slate-300 rounded"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-[#d4af37] text-black font-bold rounded hover:bg-[#e0be4d]"
            >
              Commit to Ledger
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
