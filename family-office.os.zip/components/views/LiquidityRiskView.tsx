'use client';

import React, { useState } from 'react';
import {
  Activity,
  ShieldAlert,
  TrendingDown,
  DollarSign,
  AlertTriangle,
  Sparkles,
  Zap,
} from 'lucide-react';
import { INITIAL_ASSET_POSITIONS } from '@/lib/data/family-office-store';

interface LiquidityRiskViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onOpenAi: (query?: string) => void;
}

export const LiquidityRiskView: React.FC<LiquidityRiskViewProps> = ({
  currency,
  onOpenAi,
}) => {
  const [equityShock, setEquityShock] = useState<number>(-20); // %
  const [rateShockBps, setRateShockBps] = useState<number>(150); // bps
  const [drawdownAcceleration, setDrawdownAcceleration] = useState<number>(1.5); // multiplier

  const formatVal = (usdAmount: number) => {
    let factor = 1.0;
    let symbol = '$';
    if (currency === 'GBP') {
      factor = 0.77;
      symbol = '£';
    } else if (currency === 'EUR') {
      factor = 0.91;
      symbol = '€';
    }
    const val = usdAmount * factor;
    if (val >= 1e9) return `${symbol}${(val / 1e9).toFixed(3)}B`;
    if (val >= 1e6) return `${symbol}${(val / 1e6).toFixed(1)}M`;
    return `${symbol}${val.toLocaleString()}`;
  };

  const baseNetWorth = 1186000000;
  const baseCash = 294200000;

  // Impact calculations
  const publicEquityVal = 245800000;
  const equityImpact = publicEquityVal * (equityShock / 100);

  const totalDebt = 115000000;
  const debtCostIncrease = totalDebt * (rateShockBps / 10000);

  const pendingCallsBase = 13500000;
  const acceleratedCalls = pendingCallsBase * drawdownAcceleration;

  const stressedNetWorth = baseNetWorth + equityImpact - debtCostIncrease;
  const stressedCashBuffer = baseCash - acceleratedCalls - debtCostIncrease;

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <Activity className="w-3.5 h-3.5" />
            <span>LIQUIDITY ENGINE & INSTITUTIONAL RISK STRESS-TEST</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Monte Carlo Liquidity Simulation & Multi-Factor Crash Stress Test
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time buffer evaluation across rate shocks, market drawdowns, and PE capital call accelerations.
          </p>
        </div>

        <button
          onClick={() =>
            onOpenAi(
              `Analyze family office cash runway under ${equityShock}% equity drop and +${rateShockBps}bps rate shock`
            )
          }
          className="px-3.5 py-2 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 fill-black" />
          <span>Synthesize Risk Report with Gemini</span>
        </button>
      </div>

      {/* Stressed vs Baseline Summary Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">BASELINE NET WEALTH</span>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(baseNetWorth)}</p>
          <span className="text-[11px] font-mono text-emerald-400 mt-1 block">Unstressed Balance Sheet</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">STRESSED NET WEALTH</span>
          <p
            className={`text-xl font-bold mono-num mt-1 ${
              stressedNetWorth < baseNetWorth ? 'text-rose-400' : 'text-slate-100'
            }`}
          >
            {formatVal(stressedNetWorth)}
          </p>
          <span className="text-[11px] font-mono text-rose-400 mt-1 block">
            Impact: {formatVal(equityImpact - debtCostIncrease)}
          </span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">BASELINE CASH BUFFER</span>
          <p className="text-xl font-bold text-emerald-400 mono-num mt-1">{formatVal(baseCash)}</p>
          <span className="text-[11px] font-mono text-slate-400 mt-1 block">T+1 Liquid Reserve</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">STRESSED CASH BUFFER</span>
          <p className="text-xl font-bold text-amber-400 mono-num mt-1">{formatVal(stressedCashBuffer)}</p>
          <span className="text-[11px] font-mono text-amber-400 mt-1 block">
            Remaining Buffer (Optimal)
          </span>
        </div>
      </div>

      {/* Interactive Stress Parameters Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-5">
          <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
            STRESS PARAMETERS
          </h2>

          <div className="space-y-4 font-mono text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Public Market Crash:</span>
                <span className="text-rose-400 font-bold">{equityShock}%</span>
              </div>
              <input
                type="range"
                min="-50"
                max="10"
                step="5"
                value={equityShock}
                onChange={(e) => setEquityShock(Number(e.target.value))}
                className="w-full accent-[#d4af37]"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Interest Rate Shock:</span>
                <span className="text-amber-400 font-bold">+{rateShockBps} bps</span>
              </div>
              <input
                type="range"
                min="0"
                max="400"
                step="25"
                value={rateShockBps}
                onChange={(e) => setRateShockBps(Number(e.target.value))}
                className="w-full accent-[#d4af37]"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>PE Drawdown Acceleration:</span>
                <span className="text-purple-400 font-bold">{drawdownAcceleration}x Speed</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="3.0"
                step="0.25"
                value={drawdownAcceleration}
                onChange={(e) => setDrawdownAcceleration(Number(e.target.value))}
                className="w-full accent-[#d4af37]"
              />
            </div>
          </div>
        </div>

        {/* Liquidity Tiers Breakdown */}
        <div className="lg:col-span-2 bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
          <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
            LIQUIDITY TIER DISTRIBUTION
          </h2>

          <div className="space-y-3 font-mono text-xs">
            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded flex items-center justify-between">
              <div>
                <span className="font-bold text-emerald-400 block">TIER 1: T+1 IMMEDIATE LIQUIDITY</span>
                <span className="text-slate-400 text-[11px]">Cash, Sovereign Treasuries, Money Market Funds</span>
              </div>
              <span className="text-sm font-bold text-slate-100 mono-num">{formatVal(294200000)}</span>
            </div>

            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded flex items-center justify-between">
              <div>
                <span className="font-bold text-blue-400 block">TIER 2: T+7 PUBLIC SECURITIES</span>
                <span className="text-slate-400 text-[11px]">Listed Global Equities, High Quality Corporate Debt</span>
              </div>
              <span className="text-sm font-bold text-slate-100 mono-num">{formatVal(185000000)}</span>
            </div>

            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded flex items-center justify-between">
              <div>
                <span className="font-bold text-amber-400 block">TIER 3: T+30 DIRECT CREDIT</span>
                <span className="text-slate-400 text-[11px]">Private Senior Secured Notes, Short-Term Facilities</span>
              </div>
              <span className="text-sm font-bold text-slate-100 mono-num">{formatVal(45000000)}</span>
            </div>

            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded flex items-center justify-between">
              <div>
                <span className="font-bold text-purple-400 block">TIER 4: T+365+ ILLIQUID REAL ASSETS</span>
                <span className="text-slate-400 text-[11px]">PE Funds, Operating Co., Real Estate, Fine Art</span>
              </div>
              <span className="text-sm font-bold text-slate-100 mono-num">{formatVal(776800000)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
