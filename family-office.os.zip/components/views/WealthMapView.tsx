'use client';

import React, { useState } from 'react';
import {
  GitFork,
  Building2,
  Users,
  Briefcase,
  ShieldCheck,
  Search,
  ExternalLink,
  ChevronRight,
  Layers,
  Sparkles,
  Info,
} from 'lucide-react';
import {
  INITIAL_OWNERSHIP_NODES,
  INITIAL_RELATIONSHIPS,
  INITIAL_FAMILY_MEMBERS,
  OwnershipNode,
} from '@/lib/data/family-office-store';

interface WealthMapViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onOpenAi: (query?: string) => void;
}

export const WealthMapView: React.FC<WealthMapViewProps> = ({
  currency,
  onOpenAi,
}) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-trust-1');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const selectedNode = INITIAL_OWNERSHIP_NODES.find((n) => n.id === selectedNodeId) || INITIAL_OWNERSHIP_NODES[0];

  // Relationships connected to selected node
  const outgoingRels = INITIAL_RELATIONSHIPS.filter((r) => r.fromId === selectedNodeId);
  const incomingRels = INITIAL_RELATIONSHIPS.filter((r) => r.toId === selectedNodeId);

  const formatVal = (usdAmount?: number) => {
    if (!usdAmount) return 'N/A';
    let factor = 1.0;
    let symbol = '$';
    if (currency === 'GBP') {
      factor = 0.77;
      symbol = '£';
    } else if (currency === 'EUR') {
      factor = 0.91;
      symbol = '€';
    }
    const val = usdAmount * factor;
    if (val >= 1e9) return `${symbol}${(val / 1e9).toFixed(3)}B`;
    if (val >= 1e6) return `${symbol}${(val / 1e6).toFixed(1)}M`;
    return `${symbol}${val.toLocaleString()}`;
  };

  // Filter nodes
  const filteredNodes = INITIAL_OWNERSHIP_NODES.filter((node) => {
    if (filterType !== 'ALL' && node.type !== filterType) return false;
    if (searchQuery && !node.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <GitFork className="w-3.5 h-3.5" />
            <span>AURELIA FAMILY OWNERSHIP GRAPH</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Multi-Tier Entity & Beneficial Ownership Topology
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Full look-through structure traversing Trusts, HoldCos, SPVs, Foundations, and Operating Holdings.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onOpenAi(`Explain the ultimate beneficial ownership of ${selectedNode.name}`)}
            className="px-3.5 py-2 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 fill-black" />
            <span>Traverse Node with Gemini</span>
          </button>
        </div>
      </div>

      {/* Main Split View: Graph Visual Canvas + Node Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Ownership Canvas */}
        <div className="lg:col-span-2 bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4 flex flex-col justify-between min-h-[600px]">
          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#1f2c42]">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-slate-400">Filter Node:</span>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="bg-[#0b0f17] border border-[#26354e] text-slate-200 text-xs font-mono px-2.5 py-1 rounded"
              >
                <option value="ALL">All Types</option>
                <option value="PERSON">Family Members</option>
                <option value="TRUST">Trusts</option>
                <option value="FOUNDATION">Foundations</option>
                <option value="COMPANY">Companies & HoldCos</option>
                <option value="SPV">SPVs</option>
                <option value="ACCOUNT">Accounts</option>
              </select>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Search node name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-[#0b0f17] border border-[#26354e] text-slate-200 text-xs font-mono pl-8 pr-3 py-1 rounded w-48"
              />
            </div>
          </div>

          {/* Graphical Hierarchy Map Canvas */}
          <div className="bg-[#0b0f17] border border-[#1f2c40] rounded-lg p-6 relative min-h-[480px] overflow-auto flex flex-col items-center gap-8">
            {/* Level 0: Root Family */}
            <div className="flex justify-center">
              <button
                onClick={() => setSelectedNodeId('node-fam')}
                className={`p-4 rounded-lg border-2 transition-all text-center min-w-[220px] ${
                  selectedNodeId === 'node-fam'
                    ? 'border-[#d4af37] bg-[#1e1a0f] shadow-lg shadow-[#d4af37]/10'
                    : 'border-[#2a3c5a] bg-[#121927] hover:border-[#3e5680]'
                }`}
              >
                <span className="text-[10px] font-mono text-[#d4af37] font-bold uppercase tracking-wider block">
                  ROOT FAMILY OBJECT
                </span>
                <span className="text-sm font-bold text-slate-100 block mt-1">Aurelia Family</span>
                <span className="text-[11px] font-mono text-slate-400 block mt-0.5">Generations I, II & III</span>
              </button>
            </div>

            {/* Connecting line */}
            <div className="w-0.5 h-6 bg-[#334566]" />

            {/* Level 1: Trusts & Foundations */}
            <div className="flex flex-wrap justify-center gap-6">
              {[
                { id: 'node-trust-1', name: 'Aurelia Dynastic Trust I', sub: 'Jersey • $480M' },
                { id: 'node-trust-2', name: 'Aurelia Childrens Trust II', sub: 'Cayman • $210M' },
                { id: 'node-stiftung', name: 'Aurelia Philanthropic Foundation', sub: 'Zurich • $65M' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setSelectedNodeId(item.id)}
                  className={`p-3.5 rounded-lg border transition-all text-center min-w-[180px] ${
                    selectedNodeId === item.id
                      ? 'border-[#d4af37] bg-[#1d190e] shadow-md'
                      : 'border-[#223148] bg-[#131b2a] hover:border-[#354868]'
                  }`}
                >
                  <span className="text-[10px] font-mono text-amber-400 block uppercase font-semibold">TRUST / FOUNDATION</span>
                  <span className="text-xs font-bold text-slate-100 block mt-0.5">{item.name}</span>
                  <span className="text-[10px] font-mono text-slate-400 block mt-1">{item.sub}</span>
                </button>
              ))}
            </div>

            {/* Connecting line */}
            <div className="w-0.5 h-6 bg-[#334566]" />

            {/* Level 2: Holding Companies & Operating Companies */}
            <div className="flex flex-wrap justify-center gap-6">
              {[
                { id: 'node-holdco', name: 'Aurelia Global Holdings SA', sub: 'Luxembourg • 85% Owned by Trust I' },
                { id: 'node-re-holdco', name: 'Aurelia Real Estate Estates Ltd', sub: 'UK HoldCo • 100% Owned' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setSelectedNodeId(item.id)}
                  className={`p-3.5 rounded-lg border transition-all text-center min-w-[200px] ${
                    selectedNodeId === item.id
                      ? 'border-[#d4af37] bg-[#1d190e] shadow-md'
                      : 'border-[#223148] bg-[#131b2a] hover:border-[#354868]'
                  }`}
                >
                  <span className="text-[10px] font-mono text-blue-400 block uppercase font-semibold">PRIMARY HOLDCO</span>
                  <span className="text-xs font-bold text-slate-100 block mt-0.5">{item.name}</span>
                  <span className="text-[10px] font-mono text-slate-400 block mt-1">{item.sub}</span>
                </button>
              ))}
            </div>

            {/* Connecting line */}
            <div className="w-0.5 h-6 bg-[#334566]" />

            {/* Level 3: SPVs & Operating Subsidiaries */}
            <div className="flex flex-wrap justify-center gap-4">
              {[
                { id: 'node-opco', name: 'Aurelia Renewable Tech Corp', sub: 'OpCo • $340M Val' },
                { id: 'node-pe-spv', name: 'Aurelia Private Markets SPV I', sub: 'PE SPV • $168M NAV' },
                { id: 'node-aviation', name: 'Aurelia Sky Holdings LLC', sub: 'Malta SPV • $62.5M' },
                { id: 'node-bank-1', name: 'JPMorgan Custody Account', sub: 'Bank • $42.5M' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setSelectedNodeId(item.id)}
                  className={`p-3 rounded-lg border transition-all text-center min-w-[160px] ${
                    selectedNodeId === item.id
                      ? 'border-[#d4af37] bg-[#1d190e] shadow-md'
                      : 'border-[#1e293b] bg-[#111724] hover:border-[#2f3d56]'
                  }`}
                >
                  <span className="text-[10px] font-mono text-purple-400 block uppercase font-semibold">SUBSIDIARY / ASSET</span>
                  <span className="text-xs font-bold text-slate-100 block mt-0.5">{item.name}</span>
                  <span className="text-[10px] font-mono text-slate-400 block mt-0.5">{item.sub}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="text-[11px] font-mono text-slate-400 flex items-center justify-between pt-2 border-t border-[#1f2c42]">
            <span>Click any node above to inspect legal relationships, voting control, and tax status.</span>
            <span>Server-side RBAC Verified</span>
          </div>
        </div>

        {/* Right Col: Node Inspector Panel */}
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-5 flex flex-col justify-between">
          <div>
            <div className="pb-3 border-b border-[#1f2c42]">
              <span className="text-[10px] font-mono text-[#d4af37] font-bold uppercase tracking-wider block">
                ENTITY GRAPH INSPECTOR
              </span>
              <h2 className="text-base font-bold text-slate-100 mt-0.5">{selectedNode.name}</h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1b263b] text-slate-300 rounded border border-[#2e3e5c]">
                  {selectedNode.type}
                </span>
                {selectedNode.jurisdiction && (
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1b263b] text-amber-300 rounded border border-[#2e3e5c]">
                    {selectedNode.jurisdiction}
                  </span>
                )}
              </div>
            </div>

            {/* Valuation & Details */}
            <div className="mt-4 space-y-3">
              <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded">
                <span className="text-[11px] font-mono text-slate-400 uppercase block">NODE VALUATION</span>
                <span className="text-lg font-bold text-slate-100 mono-num mt-0.5 block">
                  {formatVal(selectedNode.valueUsd)}
                </span>
                {selectedNode.details && (
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">{selectedNode.details}</p>
                )}
              </div>

              {/* Connected Relationships (Outgoing) */}
              <div>
                <span className="text-xs font-mono text-slate-400 font-semibold uppercase block mb-2">
                  OUTGOING HOLDINGS & CONTROL ({outgoingRels.length})
                </span>
                {outgoingRels.length === 0 ? (
                  <p className="text-xs text-slate-500 font-mono">No direct outgoing holdings registered.</p>
                ) : (
                  <div className="space-y-2">
                    {outgoingRels.map((rel) => {
                      const target = INITIAL_OWNERSHIP_NODES.find((n) => n.id === rel.toId);
                      return (
                        <div
                          key={rel.id}
                          className="bg-[#0b0f17] border border-[#1f2c40] p-2.5 rounded text-xs font-mono flex items-center justify-between"
                        >
                          <div>
                            <span className="text-slate-200 font-semibold">{target?.name}</span>
                            <div className="text-[10px] text-slate-400">
                              {rel.type} {rel.percentage ? `(${rel.percentage}% Economic)` : ''}
                            </div>
                          </div>
                          <button
                            onClick={() => setSelectedNodeId(rel.toId)}
                            className="p-1 hover:bg-[#1b263b] rounded text-[#d4af37]"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Connected Relationships (Incoming) */}
              <div>
                <span className="text-xs font-mono text-slate-400 font-semibold uppercase block mb-2">
                  PARENT OWNERSHIP / BENEFICIARIES ({incomingRels.length})
                </span>
                {incomingRels.length === 0 ? (
                  <p className="text-xs text-slate-500 font-mono">Top-level parent node.</p>
                ) : (
                  <div className="space-y-2">
                    {incomingRels.map((rel) => {
                      const source = INITIAL_OWNERSHIP_NODES.find((n) => n.id === rel.fromId);
                      return (
                        <div
                          key={rel.id}
                          className="bg-[#0b0f17] border border-[#1f2c40] p-2.5 rounded text-xs font-mono flex items-center justify-between"
                        >
                          <div>
                            <span className="text-slate-200 font-semibold">{source?.name}</span>
                            <div className="text-[10px] text-slate-400">
                              {rel.type} {rel.percentage ? `(${rel.percentage}% Voting)` : ''}
                            </div>
                          </div>
                          <button
                            onClick={() => setSelectedNodeId(rel.fromId)}
                            className="p-1 hover:bg-[#1b263b] rounded text-[#d4af37]"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-[#1f2c42] space-y-2">
            <button
              onClick={() => onOpenAi(`Show legal trust documents and tax rules for ${selectedNode.name}`)}
              className="w-full py-2 bg-[#1b263b] hover:bg-[#253450] text-xs font-mono font-semibold text-slate-200 rounded border border-[#304263] transition-colors flex items-center justify-center gap-1.5"
            >
              <Info className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>Query Legal Deeds with AI</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
