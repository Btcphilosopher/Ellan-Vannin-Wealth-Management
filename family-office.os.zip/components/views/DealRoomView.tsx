'use client';

import React, { useState } from 'react';
import {
  Layers,
  FileText,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Sparkles,
  ChevronRight,
  TrendingUp,
  DollarSign,
  UserCheck,
} from 'lucide-react';
import { INITIAL_DEALS, DealItem } from '@/lib/data/family-office-store';

interface DealRoomViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onOpenAi: (query?: string) => void;
}

export const DealRoomView: React.FC<DealRoomViewProps> = ({
  currency,
  onOpenAi,
}) => {
  const [deals, setDeals] = useState<DealItem[]>(INITIAL_DEALS);
  const [selectedDealId, setSelectedDealId] = useState<string>('deal-1');
  const [decisionNotes, setDecisionNotes] = useState<string>('');

  const selectedDeal = deals.find((d) => d.id === selectedDealId) || deals[0];

  const formatVal = (usdAmount: number) => {
    let factor = 1.0;
    let symbol = '$';
    if (currency === 'GBP') {
      factor = 0.77;
      symbol = '£';
    } else if (currency === 'EUR') {
      factor = 0.91;
      symbol = '€';
    }
    const val = usdAmount * factor;
    if (val >= 1e6) return `${symbol}${(val / 1e6).toFixed(1)}M`;
    return `${symbol}${val.toLocaleString()}`;
  };

  const handleVote = (status: 'APPROVED' | 'EXECUTED') => {
    setDeals((prev) =>
      prev.map((d) => (d.id === selectedDealId ? { ...d, stage: status } : d))
    );
  };

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <Layers className="w-3.5 h-3.5" />
            <span>INVESTMENT COMMITTEE TERMINAL & DEAL ROOM</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Institutional Deal Flow, Memos & Committee Governance
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Full audit workflow: Idea → DD → Memo → Committee Vote → Allocation → Execution.
          </p>
        </div>

        <button
          onClick={() =>
            onOpenAi(
              `Summarize investment memo and risk factors for ${selectedDeal.dealName}`
            )
          }
          className="px-3.5 py-2 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 fill-black" />
          <span>Draft IC Paper with Gemini 3.6</span>
        </button>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Deal Pipeline List */}
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
          <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
            ACTIVE COMMITTEE PIPELINE ({deals.length})
          </h2>

          <div className="space-y-3">
            {deals.map((deal) => (
              <button
                key={deal.id}
                onClick={() => setSelectedDealId(deal.id)}
                className={`w-full text-left p-3.5 rounded-lg border transition-all ${
                  selectedDealId === deal.id
                    ? 'border-[#d4af37] bg-[#1d180d] shadow-md'
                    : 'border-[#202d42] bg-[#0b0f17] hover:border-[#334666]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-[#d4af37] font-bold uppercase">
                    {deal.sector}
                  </span>
                  <span className="px-2 py-0.5 text-[10px] font-mono bg-[#1b263b] text-slate-200 rounded border border-[#2e3e5c]">
                    {deal.stage}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-100 mt-1">{deal.dealName}</h3>

                <div className="flex items-center justify-between text-xs font-mono text-slate-300 mt-2">
                  <span>Target: {formatVal(deal.targetAllocationUsd)}</span>
                  <span className="text-emerald-400 font-bold">{deal.expectedIrr}% IRR</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Selected Deal Memo & Valuation Workspace */}
        <div className="lg:col-span-2 bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#1f2c42]">
              <div>
                <span className="text-[10px] font-mono text-[#d4af37] font-bold uppercase">
                  INVESTMENT MEMORANDUM & DD DOSSIER
                </span>
                <h2 className="text-lg font-bold text-slate-100 mt-0.5">
                  {selectedDeal.dealName}
                </h2>
              </div>
              <span className="px-2.5 py-1 text-xs font-mono bg-[#1b263b] text-amber-300 font-bold rounded border border-[#2d3e5c]">
                Stage: {selectedDeal.stage}
              </span>
            </div>

            {/* Financial Metrics Row */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
              <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded">
                <span className="text-[10px] font-mono text-slate-400 uppercase block">TARGET TICKET</span>
                <span className="text-base font-bold text-slate-100 mono-num mt-0.5 block">
                  {formatVal(selectedDeal.targetAllocationUsd)}
                </span>
              </div>

              <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded">
                <span className="text-[10px] font-mono text-slate-400 uppercase block">IMPLIED VALUATION</span>
                <span className="text-base font-bold text-slate-100 mono-num mt-0.5 block">
                  {formatVal(selectedDeal.valuationUsd)}
                </span>
              </div>

              <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded">
                <span className="text-[10px] font-mono text-slate-400 uppercase block">EXPECTED IRR</span>
                <span className="text-base font-bold text-emerald-400 mono-num mt-0.5 block">
                  {selectedDeal.expectedIrr}%
                </span>
              </div>

              <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded">
                <span className="text-[10px] font-mono text-slate-400 uppercase block">EXPECTED MOIC</span>
                <span className="text-base font-bold text-emerald-400 mono-num mt-0.5 block">
                  {selectedDeal.expectedMoic}x
                </span>
              </div>
            </div>

            {/* Memo Summary & Risks */}
            <div className="mt-4 space-y-3 font-mono text-xs">
              <div className="bg-[#0b0f17] border border-[#1f2c40] p-3.5 rounded">
                <span className="text-slate-400 font-bold uppercase block mb-1">
                  INVESTMENT MEMO EXECUTIVE SUMMARY
                </span>
                <p className="text-slate-200 leading-relaxed font-sans text-xs">
                  {selectedDeal.memoSummary}
                </p>
              </div>

              <div className="bg-[#1c1612] border border-[#42331c] p-3.5 rounded text-[#e0bd67]">
                <span className="font-bold uppercase block mb-1.5 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-[#d4af37]" />
                  KEY RISK HIGHLIGHTS & MITIGANTS
                </span>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {selectedDeal.riskHighlights.map((risk, i) => (
                    <li key={i}>{risk}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Committee Action Panel */}
          <div className="pt-4 border-t border-[#1f2c42] space-y-3">
            <span className="text-xs font-mono text-slate-400 font-bold uppercase block">
              INVESTMENT COMMITTEE VOTING & DECISION RECORD
            </span>

            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                placeholder="Committee Decision Rationale & Allocation Terms..."
                value={decisionNotes}
                onChange={(e) => setDecisionNotes(e.target.value)}
                className="bg-[#0b0f17] border border-[#26354e] text-slate-200 text-xs font-mono px-3 py-2 rounded flex-1"
              />

              <button
                onClick={() => handleVote('APPROVED')}
                className="px-4 py-2 bg-[#1b263b] hover:bg-[#2a3c5a] text-emerald-400 text-xs font-mono font-bold rounded border border-emerald-500/40 transition-colors flex items-center gap-1.5 shrink-0"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Approve Deal</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
