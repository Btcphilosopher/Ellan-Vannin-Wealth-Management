'use client';

import React, { useState } from 'react';
import {
  Sparkles,
  ShieldCheck,
  MapPin,
  ChevronRight,
  Plane,
  Anchor,
  Palette,
  Car,
  FileText,
} from 'lucide-react';
import { INITIAL_COLLECTIBLES, CollectibleItem } from '@/lib/data/family-office-store';

interface CollectiblesViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onOpenAi: (query?: string) => void;
}

export const CollectiblesView: React.FC<CollectiblesViewProps> = ({
  currency,
  onOpenAi,
}) => {
  const [items, setItems] = useState<CollectibleItem[]>(INITIAL_COLLECTIBLES);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const formatVal = (usdAmount: number) => {
    let factor = 1.0;
    let symbol = '$';
    if (currency === 'GBP') {
      factor = 0.77;
      symbol = '£';
    } else if (currency === 'EUR') {
      factor = 0.91;
      symbol = '€';
    }
    const val = usdAmount * factor;
    if (val >= 1e6) return `${symbol}${(val / 1e6).toFixed(1)}M`;
    return `${symbol}${val.toLocaleString()}`;
  };

  const filtered = items.filter((i) => {
    if (selectedCategory !== 'ALL' && i.category !== selectedCategory) return false;
    return true;
  });

  const totalValue = items.reduce((acc, i) => acc + i.valuationUsd, 0);

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <Sparkles className="w-3.5 h-3.5" />
            <span>ART, COLLECTIBLES, AVIATION & YACHTS</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Passion Assets, Fine Art Provenance & Aviation Operating System
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Sotheby&apos;s & Christie&apos;s Appraisals, Geneva FreePort Vault Records, Flag Registration, and Custom Clearance.
          </p>
        </div>

        <button
          onClick={() => onOpenAi('Audit fine art provenance records and aviation tax compliance')}
          className="px-3.5 py-2 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 fill-black" />
          <span>Audit Provenance with Gemini</span>
        </button>
      </div>

      {/* KPI Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">TOTAL PASSION ASSET VALUATION</span>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(totalValue)}</p>
          <span className="text-[11px] font-mono text-emerald-400 mt-1 block">100% Insured at Lloyd&apos;s</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">FINE ART & MASTERPIECES</span>
          <p className="text-xl font-bold text-[#d4af37] mono-num mt-1">{formatVal(70500000)}</p>
          <span className="text-[11px] font-mono text-slate-400 mt-1 block">Monet, Picasso, Basquiat</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">CLASSIC AUTOMOBILES</span>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(57500000)}</p>
          <span className="text-[11px] font-mono text-slate-400 mt-1 block">1962 Ferrari 250 GTO</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">AVIATION & YACHTS</span>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(110700000)}</p>
          <span className="text-[11px] font-mono text-slate-400 mt-1 block">Gulfstream G650ER + Superyacht</span>
        </div>
      </div>

      {/* Filter and Grid */}
      <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#1f2c42]">
          <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider">
            PASSION ASSET REGISTER ({filtered.length})
          </h2>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-400">Category:</span>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-[#0b0f17] border border-[#26354e] text-slate-200 text-xs font-mono px-2.5 py-1 rounded"
            >
              <option value="ALL">All Categories</option>
              <option value="FINE_ART">Fine Art</option>
              <option value="CLASSIC_CARS">Classic Automobiles</option>
              <option value="AVIATION">Aviation</option>
              <option value="YACHT">Yachts & Marine</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="bg-[#0b0f17] border border-[#1f2c40] p-4 rounded-lg space-y-3 hover:border-[#334666] transition-all"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono text-[#d4af37] font-bold uppercase block">
                    {item.category}
                  </span>
                  <h3 className="text-sm font-bold text-slate-100 mt-0.5">{item.name}</h3>
                </div>
                <span className="text-sm font-bold text-slate-100 mono-num">{formatVal(item.valuationUsd)}</span>
              </div>

              <div className="bg-[#121927] p-2.5 rounded border border-[#1d283c] font-mono text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">Owner Entity:</span>
                  <span className="text-slate-200">{item.owningEntity}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Location:</span>
                  <span className="text-slate-200">{item.location}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Insured Value:</span>
                  <span className="text-emerald-400">{formatVal(item.insuredUsd)}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-[#1a2538] text-[11px] font-mono text-slate-300">
                <span className="text-slate-500 block text-[10px]">PROVENANCE / APPRAISAL</span>
                <p className="mt-0.5 leading-relaxed">{item.provenanceNotes}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
