'use client';

import React, { useEffect, useState } from 'react';
import {
  TrendingUp,
  ShieldAlert,
  Clock,
  ArrowUpRight,
  Sparkles,
  ChevronRight,
  DollarSign,
  AlertTriangle,
  FileText,
  Activity,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import {
  INITIAL_ASSET_POSITIONS,
  INITIAL_CAPITAL_CALLS,
  INITIAL_AUDIT_LOGS,
} from '@/lib/data/family-office-store';

interface OverviewViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onNavigate: (tab: any) => void;
  onOpenAi: (prompt?: string) => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  currency,
  onNavigate,
  onOpenAi,
}) => {
  const [morningBrief, setMorningBrief] = useState<any>(null);
  const [briefLoading, setBriefLoading] = useState(true);

  useEffect(() => {
    fetch('/api/ai/briefing')
      .then((res) => res.json())
      .then((data) => {
        setMorningBrief(data);
        setBriefLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load morning brief:', err);
        setBriefLoading(false);
      });
  }, []);

  // Format currency helper
  const formatVal = (usdAmount: number) => {
    let factor = 1.0;
    let symbol = '$';
    if (currency === 'GBP') {
      factor = 0.77;
      symbol = '£';
    } else if (currency === 'EUR') {
      factor = 0.91;
      symbol = '€';
    }
    const val = usdAmount * factor;
    if (val >= 1e9) return `${symbol}${(val / 1e9).toFixed(3)}B`;
    if (val >= 1e6) return `${symbol}${(val / 1e6).toFixed(1)}M`;
    return `${symbol}${val.toLocaleString()}`;
  };

  const totalAssets = INITIAL_ASSET_POSITIONS.reduce((acc, a) => acc + a.valueUsd, 0);
  const totalDebt = 115000000;
  const netWorth = totalAssets - totalDebt;
  const liquidAssets = INITIAL_ASSET_POSITIONS
    .filter((a) => a.assetClass === 'CASH' || a.liquidityTier === 'T+1 Liquid')
    .reduce((acc, a) => acc + a.valueUsd, 0);

  return (
    <div className="space-[#1e293b] space-y-6 p-4 lg:p-6 max-w-[1700px] mx-auto">
      {/* Top Banner / System Status */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg shadow-sm">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase tracking-wider">
            <span>AURELIA FAMILY OFFICE</span>
            <span>•</span>
            <span>CONSOLIDATED MASTER LEDGER</span>
          </div>
          <h1 className="text-xl lg:text-2xl font-bold text-slate-100 tracking-tight mt-0.5">
            Institutional Control Centre
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time multi-generational capital aggregation, entity graph, and liquidity monitor.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('DIGITAL_TWIN')}
            className="px-3.5 py-2 bg-[#1b263b] hover:bg-[#253450] text-slate-200 text-xs font-mono font-semibold rounded border border-[#304263] transition-colors flex items-center gap-1.5"
          >
            <span>Run Digital Twin Simulator</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onOpenAi('Prepare executive briefing on top portfolio risks and pending capital calls')}
            className="px-3.5 py-2 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] hover:from-[#b08e28] hover:to-[#826413] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 fill-black" />
            <span>Generate Brief</span>
          </button>
        </div>
      </div>

      {/* Main KPI Bar */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <p className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">NET WORTH</p>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(netWorth)}</p>
          <div className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 mt-1">
            <TrendingUp className="w-3 h-3" />
            <span>+14.8% YTD TWR</span>
          </div>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <p className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">LIQUIDITY (T+1)</p>
          <p className="text-xl font-bold text-emerald-400 mono-num mt-1">{formatVal(liquidAssets)}</p>
          <p className="text-[11px] font-mono text-slate-400 mt-1">24.8% Liquidity Buffer</p>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <p className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">PRIVATE MARKETS</p>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(312500000)}</p>
          <p className="text-[11px] font-mono text-slate-400 mt-1">IRR 24.2% • MOIC 2.15x</p>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <p className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">OPERATING CO.</p>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(340000000)}</p>
          <p className="text-[11px] font-mono text-slate-400 mt-1">68% Direct Holding</p>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <p className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">REAL ESTATE</p>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(185000000)}</p>
          <p className="text-[11px] font-mono text-slate-400 mt-1">4 Prime Properties</p>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <p className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">DEBT & FACILITIES</p>
          <p className="text-xl font-bold text-rose-400 mono-num mt-1">{formatVal(totalDebt)}</p>
          <p className="text-[11px] font-mono text-slate-400 mt-1">LTV 8.8% • Low Leverage</p>
        </div>
      </div>

      {/* Middle Grid: Morning Brief + Quick Capital Call Forecast */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Morning Brief Card */}
        <div className="lg:col-span-2 bg-[#121927] border border-[#233148] p-5 rounded-lg relative overflow-hidden">
          <div className="flex items-center justify-between pb-3 border-b border-[#1f2c42]">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#d4af37] animate-pulse" />
              <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider">
                EXECUTIVE MORNING BRIEF — GEMINI 3.6 REASONING
              </h2>
            </div>
            <span className="text-[11px] font-mono text-slate-400">
              {new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
            </span>
          </div>

          {briefLoading ? (
            <div className="py-8 text-center text-slate-400 text-xs font-mono">
              <div className="inline-block w-5 h-5 border-2 border-[#d4af37] border-t-transparent rounded-full animate-spin mb-2" />
              <p>Analyzing consolidated ledger, capital commitments, and liquidity status...</p>
            </div>
          ) : morningBrief ? (
            <div className="space-y-4 mt-4">
              <div className="bg-[#182234] border border-[#2a3c5a] p-3 rounded">
                <p className="text-xs font-mono text-[#d4af37] font-semibold">
                  {morningBrief.greeting || 'GOOD MORNING, PRINCIPAL & CIO'}
                </p>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  {morningBrief.overnightMarketInsights}
                </p>
              </div>

              <div>
                <p className="text-xs font-mono text-slate-400 uppercase mb-2 font-semibold">
                  PRIORITY DECISIONS & ACTION ITEMS
                </p>
                <div className="space-y-2">
                  {morningBrief.actionItems?.map((item: string, idx: number) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2 text-xs bg-[#0b0f17] border border-[#1f2c40] p-2.5 rounded text-slate-200"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-[#1f1a14] border border-[#4d3a1a] p-3 rounded flex items-start gap-2.5 text-xs text-[#f5d070]">
                <AlertTriangle className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                <div>
                  <span className="font-mono font-bold uppercase text-xs">CONCENTRATION RISK MONITOR: </span>
                  <span>{morningBrief.topRisks}</span>
                </div>
              </div>
            </div>
          ) : null}
        </div>

        {/* Capital Call Widget */}
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#1f2c42]">
              <h3 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider">
                UPCOMING CAPITAL CALLS
              </h3>
              <button
                onClick={() => onNavigate('PRIVATE_MARKETS')}
                className="text-xs font-mono text-[#d4af37] hover:underline flex items-center gap-0.5"
              >
                <span>Full Engine</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-3 mt-4">
              {INITIAL_CAPITAL_CALLS.map((call) => (
                <div
                  key={call.id}
                  className="bg-[#0b0f17] border border-[#1f2c42] p-3 rounded flex flex-col gap-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-slate-200 font-semibold truncate max-w-[200px]">
                      {call.fundName}
                    </span>
                    <span className="text-xs font-mono font-bold text-amber-400">
                      {formatVal(call.callAmountUsd)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>Due: {call.dueDate}</span>
                    <span className="text-amber-300 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/40">
                      In {call.urgencyDays} Days
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1f2c42]">
            <button
              onClick={() => onNavigate('PRIVATE_MARKETS')}
              className="w-full py-2 bg-[#1b263b] hover:bg-[#253450] text-xs font-mono font-semibold text-slate-200 rounded border border-[#304263] transition-colors"
            >
              Authorize & Settle Drawdowns ($13.5M Total)
            </button>
          </div>
        </div>
      </div>

      {/* Asset Allocation Breakdown Bar */}
      <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h3 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider">
            CONSOLIDATED ASSET CLASS BREAKDOWN
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Total Capital: {formatVal(totalAssets)}
          </span>
        </div>

        {/* Visual Multi-Segment Bar */}
        <div className="w-full h-4 bg-[#0b0f17] rounded overflow-hidden flex border border-[#1e293b]">
          <div className="bg-emerald-500 h-full" style={{ width: '22%' }} title="Cash & Short-Term Treasuries (22%)" />
          <div className="bg-blue-500 h-full" style={{ width: '19%' }} title="Public Markets (19%)" />
          <div className="bg-purple-500 h-full" style={{ width: '24%' }} title="Private Equity & VC (24%)" />
          <div className="bg-amber-500 h-full" style={{ width: '26%' }} title="Operating Businesses (26%)" />
          <div className="bg-rose-500 h-full" style={{ width: '14%' }} title="Real Estate (14%)" />
          <div className="bg-cyan-500 h-full" style={{ width: '8%' }} title="Collectibles & Aviation (8%)" />
        </div>

        {/* Legend */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span className="text-slate-300">Cash & Buffer ($294M)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />
            <span className="text-slate-300">Public Markets ($245M)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-purple-500" />
            <span className="text-slate-300">Private Equity ($312M)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span className="text-slate-300">Operating Co ($340M)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
            <span className="text-slate-300">Real Estate ($185M)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
            <span className="text-slate-300">Collectibles ($110M)</span>
          </div>
        </div>
      </div>

      {/* Real-time Ledger Audit Trail Stream */}
      <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#1f2c42]">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider">
              IMMUTABLE AUDIT STREAM & LEDGER EVENTS
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Hash Signed • Cryptographically Verified
          </span>
        </div>

        <div className="space-y-2">
          {INITIAL_AUDIT_LOGS.map((log) => (
            <div
              key={log.id}
              className="flex flex-col md:flex-row md:items-center justify-between bg-[#0b0f17] border border-[#1f2c42] p-3 rounded text-xs font-mono gap-2"
            >
              <div className="flex items-center gap-3">
                <span className="text-emerald-400 font-bold px-1.5 py-0.5 bg-emerald-950/80 border border-emerald-800/40 rounded text-[10px]">
                  {log.action}
                </span>
                <span className="text-slate-200">{log.details}</span>
              </div>
              <div className="flex items-center gap-4 text-slate-400 text-[11px]">
                <span>Actor: {log.actor}</span>
                <span>{log.timestamp}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
