'use client';

import React, { useState } from 'react';
import {
  Cpu,
  Sparkles,
  TrendingUp,
  ArrowRight,
  RefreshCw,
  CheckCircle2,
  DollarSign,
} from 'lucide-react';

interface DigitalTwinViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onOpenAi: (query?: string) => void;
}

export const DigitalTwinView: React.FC<DigitalTwinViewProps> = ({
  currency,
  onOpenAi,
}) => {
  const [sellProperty, setSellProperty] = useState<boolean>(false);
  const [issueDebt, setIssueDebt] = useState<boolean>(false);
  const [liquidateEquity, setLiquidateEquity] = useState<boolean>(false);
  const [philanthropicGift, setPhilanthropicGift] = useState<boolean>(false);

  const formatVal = (usdAmount: number) => {
    let factor = 1.0;
    let symbol = '$';
    if (currency === 'GBP') {
      factor = 0.77;
      symbol = '£';
    } else if (currency === 'EUR') {
      factor = 0.91;
      symbol = '€';
    }
    const val = usdAmount * factor;
    if (val >= 1e9) return `${symbol}${(val / 1e9).toFixed(3)}B`;
    if (val >= 1e6) return `${symbol}${(val / 1e6).toFixed(1)}M`;
    return `${symbol}${val.toLocaleString()}`;
  };

  const baselineNW = 1186000000;
  const baselineCash = 294200000;

  let scenarioNW = baselineNW;
  let scenarioCash = baselineCash;

  if (sellProperty) {
    // Sell Grosvenor Square ($58.5M val, $12M tax/fees)
    scenarioCash += 46500000;
    scenarioNW -= 12000000;
  }

  if (issueDebt) {
    // $50M debt facility
    scenarioCash += 50000000;
  }

  if (liquidateEquity) {
    // Sell $75M public stock, $11.2M tax
    scenarioCash += 63800000;
    scenarioNW -= 11200000;
  }

  if (philanthropicGift) {
    scenarioCash -= 15000000;
    scenarioNW -= 15000000;
  }

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <Cpu className="w-3.5 h-3.5" />
            <span>FAMILY OFFICE SCENARIO ENGINE & DIGITAL TWIN</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Simulate Asset Sales, Liquidity Events & Strategic Capital Reallocation
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Evaluate Net Worth impact, tax friction, and liquidity buffer changes before executing real transactions.
          </p>
        </div>

        <button
          onClick={() =>
            onOpenAi(
              `Synthesize CIO recommendation for scenario: Sell Property=${sellProperty}, Issue Debt=${issueDebt}, Liquidate Equity=${liquidateEquity}, Gift=${philanthropicGift}`
            )
          }
          className="px-3.5 py-2 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 fill-black" />
          <span>Evaluate Scenario with Gemini</span>
        </button>
      </div>

      {/* Scenario Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
          <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
            SIMULATION TOGGLES
          </h2>

          <div className="space-y-3 font-mono text-xs">
            <label className="flex items-center justify-between p-3 bg-[#0b0f17] border border-[#1f2c40] rounded cursor-pointer hover:border-[#334666]">
              <div>
                <span className="font-bold text-slate-200 block">Sell 12 Grosvenor Square</span>
                <span className="text-[10px] text-slate-400">Unlock +$46.5M Net Liquidity</span>
              </div>
              <input
                type="checkbox"
                checked={sellProperty}
                onChange={(e) => setSellProperty(e.target.checked)}
                className="w-4 h-4 accent-[#d4af37]"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-[#0b0f17] border border-[#1f2c40] rounded cursor-pointer hover:border-[#334666]">
              <div>
                <span className="font-bold text-slate-200 block">Issue $50M Credit Facility</span>
                <span className="text-[10px] text-slate-400">Fixed 5.25% Senior Debt</span>
              </div>
              <input
                type="checkbox"
                checked={issueDebt}
                onChange={(e) => setIssueDebt(e.target.checked)}
                className="w-4 h-4 accent-[#d4af37]"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-[#0b0f17] border border-[#1f2c40] rounded cursor-pointer hover:border-[#334666]">
              <div>
                <span className="font-bold text-slate-200 block">Liquidate 30% Public Equity</span>
                <span className="text-[10px] text-slate-[#d4af37]">+$63.8M Cash (T+2)</span>
              </div>
              <input
                type="checkbox"
                checked={liquidateEquity}
                onChange={(e) => setLiquidateEquity(e.target.checked)}
                className="w-4 h-4 accent-[#d4af37]"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-[#0b0f17] border border-[#1f2c40] rounded cursor-pointer hover:border-[#334666]">
              <div>
                <span className="font-bold text-slate-200 block">$15M Endowment Gift</span>
                <span className="text-[10px] text-slate-400">Transfer to Philanthropic Stiftung</span>
              </div>
              <input
                type="checkbox"
                checked={philanthropicGift}
                onChange={(e) => setPhilanthropicGift(e.target.checked)}
                className="w-4 h-4 accent-[#d4af37]"
              />
            </label>
          </div>
        </div>

        {/* Results Comparison */}
        <div className="lg:col-span-2 bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-5">
          <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
            SCENARIO PROJECTION RESULTS
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-[#0b0f17] border border-[#1f2c40] p-4 rounded-lg">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">BASELINE NET WORTH</span>
              <span className="text-lg font-bold text-slate-100 mono-num mt-1 block">
                {formatVal(baselineNW)}
              </span>
            </div>

            <div className="bg-[#0b0f17] border border-[#d4af37]/60 p-4 rounded-lg shadow">
              <span className="text-[10px] font-mono text-[#d4af37] font-bold uppercase block">SCENARIO NET WORTH</span>
              <span className="text-lg font-bold text-slate-100 mono-num mt-1 block">
                {formatVal(scenarioNW)}
              </span>
            </div>

            <div className="bg-[#0b0f17] border border-[#1f2c40] p-4 rounded-lg">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">NET WEALTH DELTA</span>
              <span
                className={`text-lg font-bold mono-num mt-1 block ${
                  scenarioNW >= baselineNW ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {scenarioNW >= baselineNW ? '+' : ''}
                {formatVal(scenarioNW - baselineNW)}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 font-mono text-xs">
            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3.5 rounded">
              <span className="text-slate-400 font-bold uppercase block">LIQUID CASH BUFFER RESULT</span>
              <div className="flex items-center justify-between mt-2">
                <span className="text-slate-400">Baseline: {formatVal(baselineCash)}</span>
                <ArrowRight className="w-4 h-4 text-[#d4af37]" />
                <span className="text-emerald-400 font-bold">{formatVal(scenarioCash)}</span>
              </div>
            </div>

            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3.5 rounded">
              <span className="text-slate-400 font-bold uppercase block">ESTIMATED TAX FRICTION</span>
              <div className="text-amber-400 font-bold mt-2">
                {formatVal(baselineNW - scenarioNW)} Tax & Transaction Cost
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
