'use client';

import React, { useState } from 'react';
import {
  Briefcase,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertCircle,
  ChevronRight,
  Sparkles,
  FileText,
  DollarSign,
} from 'lucide-react';
import {
  INITIAL_PRIVATE_FUNDS,
  INITIAL_CAPITAL_CALLS,
} from '@/lib/data/family-office-store';

interface PrivateMarketsViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onOpenAi: (query?: string) => void;
}

export const PrivateMarketsView: React.FC<PrivateMarketsViewProps> = ({
  currency,
  onOpenAi,
}) => {
  const [calls, setCalls] = useState(INITIAL_CAPITAL_CALLS);

  const formatVal = (usdAmount: number) => {
    let factor = 1.0;
    let symbol = '$';
    if (currency === 'GBP') {
      factor = 0.77;
      symbol = '£';
    } else if (currency === 'EUR') {
      factor = 0.91;
      symbol = '€';
    }
    const val = usdAmount * factor;
    if (val >= 1e9) return `${symbol}${(val / 1e9).toFixed(3)}B`;
    if (val >= 1e6) return `${symbol}${(val / 1e6).toFixed(1)}M`;
    return `${symbol}${val.toLocaleString()}`;
  };

  const handleApproveCall = (id: string) => {
    setCalls((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: 'APPROVED' } : c))
    );
  };

  const totalCommitment = INITIAL_PRIVATE_FUNDS.reduce((acc, f) => acc + f.commitmentUsd, 0);
  const totalCalled = INITIAL_PRIVATE_FUNDS.reduce((acc, f) => acc + f.calledCapitalUsd, 0);
  const totalUncalled = INITIAL_PRIVATE_FUNDS.reduce((acc, f) => acc + f.uncalledCapitalUsd, 0);
  const totalNav = INITIAL_PRIVATE_FUNDS.reduce((acc, f) => acc + f.navUsd, 0);
  const totalDpi = 0.61;
  const totalTvpi = 2.21;

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <Briefcase className="w-3.5 h-3.5" />
            <span>PRIVATE EQUITY & VENTURE CAPITAL ENGINE</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Institutional Fund Commitments, Drawdowns & Capital Call Forecast
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            LP Commitments, Uncalled Capital Tracking, Vintage Analytics, and Liquidity Schedules.
          </p>
        </div>

        <button
          onClick={() => onOpenAi('Analyze private markets capital call schedule and liquidity requirements for next 180 days')}
          className="px-3.5 py-2 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 fill-black" />
          <span>Forecast Liquidity with Gemini</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">TOTAL COMMITMENT</span>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(totalCommitment)}</p>
          <span className="text-[10px] font-mono text-slate-400 mt-0.5 block">3 Tier-1 Institutional LPs</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">CALLED CAPITAL</span>
          <p className="text-xl font-bold text-amber-400 mono-num mt-1">{formatVal(totalCalled)}</p>
          <span className="text-[10px] font-mono text-amber-400 mt-0.5 block">70.0% Deployed</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">UNCALLED CAPITAL</span>
          <p className="text-xl font-bold text-rose-400 mono-num mt-1">{formatVal(totalUncalled)}</p>
          <span className="text-[10px] font-mono text-slate-400 mt-0.5 block">Pending Drawdowns</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">CURRENT NAV</span>
          <p className="text-xl font-bold text-emerald-400 mono-num mt-1">{formatVal(totalNav)}</p>
          <span className="text-[10px] font-mono text-emerald-400 mt-0.5 block">+60.0% Value Creation</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">DPI / TVPI</span>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">0.61x / 2.21x</p>
          <span className="text-[10px] font-mono text-slate-400 mt-0.5 block">Realized Cash Back</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-3.5 rounded-lg">
          <span className="text-[11px] font-mono text-slate-400 uppercase">NET IRR</span>
          <p className="text-xl font-bold text-emerald-400 mono-num mt-1">24.2%</p>
          <span className="text-[10px] font-mono text-slate-400 mt-0.5 block">Blended LP Return</span>
        </div>
      </div>

      {/* Capital Call Forecast Window */}
      <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#1f2c42]">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider">
              CAPITAL CALL FORECAST SCHEDULE (NEXT 30D / 90D / 12M / 3Y)
            </h2>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Automated Cash Allocation Check Passed
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {calls.map((call) => (
            <div
              key={call.id}
              className="bg-[#0b0f17] border border-[#223148] p-4 rounded-lg space-y-3 relative"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono text-amber-400 uppercase font-bold block">
                    CAPITAL DRAWDOWN NOTICE
                  </span>
                  <h4 className="text-xs font-bold text-slate-100 mt-0.5">{call.fundName}</h4>
                </div>
                <span
                  className={`px-2 py-0.5 text-[10px] font-mono font-bold rounded ${
                    call.status === 'APPROVED'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}
                >
                  {call.status}
                </span>
              </div>

              <div className="bg-[#121927] p-2.5 rounded border border-[#1d283c] font-mono text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">Amount Due:</span>
                  <span className="font-bold text-amber-400 mono-num">{formatVal(call.callAmountUsd)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Due Date:</span>
                  <span className="text-slate-200">{call.dueDate}</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">Cash Source:</span>
                  <span className="text-slate-300">{call.cashAccountSource}</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-300 leading-relaxed font-sans">{call.purpose}</p>

              {call.status === 'PENDING_APPROVAL' ? (
                <button
                  onClick={() => handleApproveCall(call.id)}
                  className="w-full py-1.5 bg-[#1b263b] hover:bg-[#283856] text-xs font-mono font-bold text-amber-400 rounded border border-amber-500/40 transition-colors flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Authorize & Reserve Funds</span>
                </button>
              ) : (
                <div className="py-1.5 bg-emerald-950/60 border border-emerald-800/40 text-emerald-400 text-xs font-mono font-bold rounded text-center">
                  Funds Reserved in JPMorgan Escrow
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* LP Fund List Table */}
      <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
        <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider pb-3 border-b border-[#1f2c42]">
          ACTIVE PRIVATE FUND HOLDINGS & VINTAGE PERFORMANCE
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1e293b] text-slate-400 uppercase">
                <th className="pb-3 px-3">Fund Name / GP</th>
                <th className="pb-3 px-3">Strategy</th>
                <th className="pb-3 px-3">Vintage</th>
                <th className="pb-3 px-3 text-right">Commitment</th>
                <th className="pb-3 px-3 text-right">Called</th>
                <th className="pb-3 px-3 text-right">Uncalled</th>
                <th className="pb-3 px-3 text-right">NAV</th>
                <th className="pb-3 px-3 text-right">DPI</th>
                <th className="pb-3 px-3 text-right">TVPI</th>
                <th className="pb-3 px-3 text-right">Net IRR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182234]">
              {INITIAL_PRIVATE_FUNDS.map((fund) => (
                <tr key={fund.id} className="hover:bg-[#151e2e] transition-colors">
                  <td className="py-3 px-3">
                    <span className="font-bold text-slate-100 block">{fund.fundName}</span>
                    <span className="text-[10px] text-slate-400">{fund.gpName} • {fund.holdingEntity}</span>
                  </td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 bg-[#1b263b] text-slate-300 rounded border border-[#2a3c5a] text-[10px]">
                      {fund.strategy}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-300">{fund.vintageYear}</td>
                  <td className="py-3 px-3 text-right font-bold text-slate-100 mono-num">{formatVal(fund.commitmentUsd)}</td>
                  <td className="py-3 px-3 text-right text-amber-400 mono-num">{formatVal(fund.calledCapitalUsd)}</td>
                  <td className="py-3 px-3 text-right text-rose-400 mono-num">{formatVal(fund.uncalledCapitalUsd)}</td>
                  <td className="py-3 px-3 text-right font-bold text-emerald-400 mono-num">{formatVal(fund.navUsd)}</td>
                  <td className="py-3 px-3 text-right text-slate-300 mono-num">{fund.dpi}x</td>
                  <td className="py-3 px-3 text-right font-bold text-slate-100 mono-num">{fund.tvpi}x</td>
                  <td className="py-3 px-3 text-right font-bold text-emerald-400 mono-num">{fund.irr}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
