'use client';

import React, { useState, useEffect } from 'react';
import {
  BotMessageSquare,
  Sparkles,
  Send,
  Zap,
  CheckCircle2,
  FileText,
  GitFork,
  PieChart,
  ShieldAlert,
  ArrowRight,
  UserCheck,
} from 'lucide-react';

interface AskGeminiViewProps {
  initialQuery?: string;
  onNavigate: (tab: any) => void;
}

export const AskGeminiView: React.FC<AskGeminiViewProps> = ({
  initialQuery,
  onNavigate,
}) => {
  const [prompt, setPrompt] = useState<string>(initialQuery || '');
  const [selectedAgent, setSelectedAgent] = useState<string>('CIO');
  const [loading, setLoading] = useState<boolean>(false);
  const [response, setResponse] = useState<any>(null);

  const AGENTS = [
    { id: 'CIO', label: 'CIO (Chief Investment Officer)', desc: 'Asset allocation, portfolio returns & strategy' },
    { id: 'CFO', label: 'CFO (Treasury & Cash Flow)', desc: 'Liquidity, banking, debt & capital calls' },
    { id: 'RISK', label: 'Risk Manager', desc: 'Stress tests, concentration & factor exposure' },
    { id: 'TAX', label: 'Tax & Compliance', desc: 'Cross-border tax, non-dom & FATCA compliance' },
    { id: 'LEGAL', label: 'Legal & Entity Governance', desc: 'Trust deeds, SPVs & beneficial ownership' },
    { id: 'PRIVATE_MARKETS', label: 'Private PE / VC Lead', desc: 'LP commitments, drawdowns & fund IRR' },
    { id: 'PROPERTY', label: 'Real Estate & Assets', desc: 'Property digital twins & passion assets' },
    { id: 'ARCHIVIST', label: 'Vault Archivist', desc: 'Document retrieval & clause extraction' },
  ];

  const PRESETS = [
    'Summarize total liquid reserves vs upcoming capital calls in next 90 days',
    'Show full ultimate beneficial ownership breakdown of Aurelia Dynastic Trust I',
    'What are the key indemnities and terms in our Sequoia XVIII LP agreement?',
    'Analyze tax implications and capital gains if we liquidate 12 Grosvenor Square',
    'Run a -20% equity market crash scenario on portfolio net worth',
  ];

  useEffect(() => {
    if (initialQuery) {
      handleQuery(initialQuery);
    }
  }, [initialQuery]);

  const handleQuery = async (queryText?: string) => {
    const q = queryText || prompt;
    if (!q.trim()) return;

    setLoading(true);
    setResponse(null);

    try {
      const res = await fetch('/api/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: q, agentRole: selectedAgent }),
      });
      const data = await res.json();
      setResponse(data);
    } catch (err) {
      console.error('Gemini query error:', err);
      setResponse({
        answer: 'Failed to connect to the reasoning engine. Detailed ledger views remain operational.',
        sourceData: ['Local System Cache'],
        calculations: ['Fallback Offline Mode'],
        assumptions: ['As of current time'],
        confidence: 'ESTIMATED',
        actionableLinks: [],
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <BotMessageSquare className="w-3.5 h-3.5" />
            <span>GEMINI 3.6 INTELLIGENT REASONING CONSOLE</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Natural-Language Query Interface over Consolidated Family Ledger
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Grounded in verified ledger state. No hallucinations or unverified numbers.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 text-xs font-mono bg-[#1b263b] text-emerald-400 font-bold rounded border border-emerald-500/40">
            MODEL: GEMINI 3.6 REASONING
          </span>
        </div>
      </div>

      {/* Main Grid: Agent Selector & Query Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col: Agent & Preset Selection */}
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-5">
          <div>
            <h2 className="text-xs font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
              SELECT REASONING AGENT
            </h2>

            <div className="space-y-2 mt-3 font-mono text-xs">
              {AGENTS.map((ag) => (
                <button
                  key={ag.id}
                  onClick={() => setSelectedAgent(ag.id)}
                  className={`w-full text-left p-2.5 rounded border transition-all ${
                    selectedAgent === ag.id
                      ? 'border-[#d4af37] bg-[#1d180d] text-slate-100 font-bold shadow'
                      : 'border-[#1f2c40] bg-[#0b0f17] text-slate-300 hover:border-[#334666]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span>{ag.label}</span>
                    {selectedAgent === ag.id && (
                      <Zap className="w-3.5 h-3.5 text-[#d4af37] fill-[#d4af37]" />
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400 font-normal mt-0.5">{ag.desc}</p>
                </button>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-xs font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
              PRESET INSTITUTIONAL QUERIES
            </h2>

            <div className="space-y-2 mt-3">
              {PRESETS.map((p, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setPrompt(p);
                    handleQuery(p);
                  }}
                  className="w-full text-left p-2 bg-[#0b0f17] hover:bg-[#151e2e] border border-[#1f2c40] rounded text-xs text-slate-300 transition-colors font-sans flex items-center justify-between"
                >
                  <span className="truncate pr-2">{p}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#d4af37] shrink-0" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Prompt Input & Structured Output */}
        <div className="lg:col-span-2 bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-5 flex flex-col justify-between min-h-[550px]">
          <div>
            <div className="pb-3 border-b border-[#1f2c42] flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-slate-100 uppercase tracking-wider">
                QUERY CONSOLE ({selectedAgent})
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                Server RBAC Active
              </span>
            </div>

            {/* Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleQuery();
              }}
              className="mt-4 flex gap-2"
            >
              <input
                type="text"
                placeholder="Ask Gemini 3.6 about any entity, trust, capital call, property, or risk..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="flex-1 bg-[#0b0f17] border border-[#26354e] text-slate-100 text-xs font-mono px-3 py-2.5 rounded focus:border-[#d4af37] outline-none"
              />
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2.5 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] hover:from-[#b08e28] hover:to-[#826413] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5 shrink-0"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Run Query</span>
                  </>
                )}
              </button>
            </form>

            {/* Response Display Box */}
            {loading && (
              <div className="mt-8 py-12 text-center text-slate-400 font-mono text-xs space-y-2">
                <div className="inline-block w-6 h-6 border-2 border-[#d4af37] border-t-transparent rounded-full animate-spin" />
                <p>Gemini 3.6 reasoning engine inspecting consolidated family ledger...</p>
              </div>
            )}

            {response && !loading && (
              <div className="mt-6 space-y-4 font-mono text-xs">
                {/* Executive Synthesis Answer */}
                <div className="bg-[#0b0f17] border border-[#233148] p-4 rounded-lg space-y-2">
                  <div className="flex items-center justify-between pb-2 border-b border-[#1f2c40]">
                    <span className="text-[10px] text-[#d4af37] font-bold uppercase">
                      AUTHORITATIVE REASONING SYNTHESIS
                    </span>
                    <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 rounded text-[10px] font-bold border border-emerald-800">
                      CONFIDENCE: {response.confidence || 'HIGH'}
                    </span>
                  </div>
                  <p className="text-slate-100 font-sans text-sm leading-relaxed mt-2">
                    {response.answer}
                  </p>
                </div>

                {/* Referenced Source Data */}
                {response.sourceData?.length > 0 && (
                  <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded space-y-1">
                    <span className="text-slate-400 font-bold uppercase block text-[10px]">
                      REFERENCED LEDGER RECORDS & ENTITIES
                    </span>
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {response.sourceData.map((src: string, idx: number) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 bg-[#182234] text-slate-200 rounded border border-[#2b3c58] text-[10px]"
                        >
                          {src}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Calculations / Math */}
                {response.calculations?.length > 0 && (
                  <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded space-y-1">
                    <span className="text-slate-400 font-bold uppercase block text-[10px]">
                      TRACEABLE DERIVATION & MATH
                    </span>
                    <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
                      {response.calculations.map((calc: string, idx: number) => (
                        <li key={idx}>{calc}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Actionable Deep Links */}
                {response.actionableLinks?.length > 0 && (
                  <div className="pt-2 border-t border-[#1f2c42] flex flex-wrap gap-2">
                    {response.actionableLinks.map((link: any, idx: number) => (
                      <button
                        key={idx}
                        onClick={() => onNavigate(link.view)}
                        className="px-3 py-1.5 bg-[#1b263b] hover:bg-[#283856] text-[#d4af37] font-bold rounded border border-[#304263] transition-colors flex items-center gap-1"
                      >
                        <span>{link.label}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-[#1f2c42] text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>Server-side API Route • All queries cryptographically logged</span>
            <span>Gemini 3.6 Master Build</span>
          </div>
        </div>
      </div>
    </div>
  );
};
