'use client';

import React, { useState } from 'react';
import {
  Scale,
  TrendingUp,
  Download,
  Calendar,
  Layers,
  ArrowUpRight,
  ShieldCheck,
  ChevronDown,
} from 'lucide-react';
import {
  INITIAL_ASSET_POSITIONS,
  AssetPosition,
} from '@/lib/data/family-office-store';

interface NetWorthViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onOpenAi: (query?: string) => void;
}

export const NetWorthView: React.FC<NetWorthViewProps> = ({
  currency,
  onOpenAi,
}) => {
  const [selectedHorizon, setSelectedHorizon] = useState<'TODAY' | '1Y_AGO' | '5Y_AGO' | '10Y_AGO' | 'PROJECTION'>('TODAY');
  const [selectedClass, setSelectedClass] = useState<string>('ALL');

  const formatVal = (usdAmount: number) => {
    let factor = 1.0;
    let symbol = '$';
    if (currency === 'GBP') {
      factor = 0.77;
      symbol = '£';
    } else if (currency === 'EUR') {
      factor = 0.91;
      symbol = '€';
    }
    const val = usdAmount * factor;
    if (val >= 1e9) return `${symbol}${(val / 1e9).toFixed(3)}B`;
    if (val >= 1e6) return `${symbol}${(val / 1e6).toFixed(1)}M`;
    return `${symbol}${val.toLocaleString()}`;
  };

  // Compute stats based on horizon multiplier for demo
  let multiplier = 1.0;
  if (selectedHorizon === '1Y_AGO') multiplier = 0.871;
  else if (selectedHorizon === '5Y_AGO') multiplier = 0.625;
  else if (selectedHorizon === '10Y_AGO') multiplier = 0.404;
  else if (selectedHorizon === 'PROJECTION') multiplier = 1.366;

  const totalAssetsUsd = INITIAL_ASSET_POSITIONS.reduce((acc, a) => acc + a.valueUsd, 0) * multiplier;
  const totalLiabilitiesUsd = 115000000 * multiplier;
  const netWorthUsd = totalAssetsUsd - totalLiabilitiesUsd;

  const filteredAssets = INITIAL_ASSET_POSITIONS.filter((a) => {
    if (selectedClass !== 'ALL' && a.assetClass !== selectedClass) return false;
    return true;
  });

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <Scale className="w-3.5 h-3.5" />
            <span>CONSOLIDATED BALANCE SHEET</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Aurelia Family Net Worth & Multi-Year Capital Evolution
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Fully reconciled audit ledger. No unexplained numbers or floating estimates.
          </p>
        </div>

        {/* Horizon Picker */}
        <div className="flex items-center bg-[#0b0f17] rounded border border-[#233148] p-1 font-mono text-xs">
          {[
            { id: '10Y_AGO', label: '10 Years Ago' },
            { id: '5Y_AGO', label: '5 Years Ago' },
            { id: '1Y_AGO', label: '1 Year Ago' },
            { id: 'TODAY', label: 'Today (Live)' },
            { id: 'PROJECTION', label: '5Y Projection' },
          ].map((h) => (
            <button
              key={h.id}
              onClick={() => setSelectedHorizon(h.id as any)}
              className={`px-3 py-1.5 rounded transition-colors font-semibold ${
                selectedHorizon === h.id
                  ? 'bg-[#d4af37] text-black shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {h.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Net Worth Summary Box */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block">CONSOLIDATED TOTAL ASSETS</span>
          <span className="text-2xl font-bold text-slate-100 mono-num mt-1 block">{formatVal(totalAssetsUsd)}</span>
          <span className="text-[11px] font-mono text-emerald-400 mt-1 block">8 Asset Classes Across 5 Entities</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block">CONSOLIDATED LIABILITIES</span>
          <span className="text-2xl font-bold text-rose-400 mono-num mt-1 block">{formatVal(totalLiabilitiesUsd)}</span>
          <span className="text-[11px] font-mono text-slate-400 mt-1 block">Mortgages & Senior Facilities</span>
        </div>

        <div className="bg-gradient-to-br from-[#1c170d] to-[#121927] border border-[#d4af37]/60 p-5 rounded-lg shadow-lg">
          <span className="text-xs font-mono text-[#d4af37] font-bold uppercase tracking-wider block">NET FAMILY WEALTH</span>
          <span className="text-3xl font-extrabold text-slate-100 mono-num mt-1 block">{formatVal(netWorthUsd)}</span>
          <span className="text-xs font-mono text-[#d4af37] mt-1 block">
            {selectedHorizon === 'TODAY' ? '+14.8% YoY Capital Preservation' : 'Simulated Horizon State'}
          </span>
        </div>
      </div>

      {/* Filter and Ledger Table */}
      <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1f2c42]">
          <div className="flex items-center gap-3">
            <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider">
              ITEMIZED ASSET LEDGER ({filteredAssets.length})
            </h2>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="bg-[#0b0f17] border border-[#26354e] text-slate-200 text-xs font-mono px-2.5 py-1 rounded"
            >
              <option value="ALL">All Asset Classes</option>
              <option value="PUBLIC_MARKETS">Public Markets</option>
              <option value="PRIVATE_MARKETS">Private Equity & VC</option>
              <option value="OPERATING_BUSINESSES">Operating Businesses</option>
              <option value="REAL_ESTATE">Real Estate</option>
              <option value="COLLECTIBLES">Collectibles & Art</option>
              <option value="PERSONAL_AVIATION">Aviation & Yachts</option>
              <option value="DIGITAL_IP">Digital & IP</option>
              <option value="CASH">Cash & Equivalents</option>
            </select>
          </div>

          <button
            onClick={() => onOpenAi('Summarize family net worth valuation methodology and confidence bounds')}
            className="text-xs font-mono text-[#d4af37] hover:underline"
          >
            Audit Valuation Methods with Gemini 3.6
          </button>
        </div>

        {/* Detailed Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1e293b] text-slate-400 uppercase">
                <th className="pb-3 pt-1 px-3">Asset Position</th>
                <th className="pb-3 pt-1 px-3">Asset Class</th>
                <th className="pb-3 pt-1 px-3">Owning Entity</th>
                <th className="pb-3 pt-1 px-3 text-right">Valuation</th>
                <th className="pb-3 pt-1 px-3 text-right">Cost Basis</th>
                <th className="pb-3 pt-1 px-3">Liquidity Tier</th>
                <th className="pb-3 pt-1 px-3">Valuation Method</th>
                <th className="pb-3 pt-1 px-3">Confidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182234]">
              {filteredAssets.map((asset) => (
                <tr key={asset.id} className="hover:bg-[#151e2e] transition-colors">
                  <td className="py-3 px-3 font-semibold text-slate-100">{asset.name}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 bg-[#1b263b] text-slate-300 rounded border border-[#2c3d5a] text-[10px]">
                      {asset.assetClass}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-300">{asset.entityName}</td>
                  <td className="py-3 px-3 text-right font-bold text-slate-100 mono-num">
                    {formatVal(asset.valueUsd * multiplier)}
                  </td>
                  <td className="py-3 px-3 text-right text-slate-400 mono-num">
                    {formatVal(asset.costBasisUsd * multiplier)}
                  </td>
                  <td className="py-3 px-3">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] ${
                        asset.liquidityTier.includes('T+1')
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-slate-900 text-slate-400 border border-slate-800'
                      }`}
                    >
                      {asset.liquidityTier}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-300">{asset.valuationMethod}</td>
                  <td className="py-3 px-3">
                    <span className="px-1.5 py-0.5 bg-emerald-950/80 text-emerald-400 border border-emerald-800 rounded text-[10px]">
                      {asset.confidence}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
