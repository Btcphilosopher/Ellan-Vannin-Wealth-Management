'use client';

import React, { useState } from 'react';
import {
  FileCheck2,
  Users,
  ShieldCheck,
  Globe,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { INITIAL_FAMILY_MEMBERS } from '@/lib/data/family-office-store';

interface TaxGovernanceViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onOpenAi: (query?: string) => void;
}

export const TaxGovernanceView: React.FC<TaxGovernanceViewProps> = ({
  currency,
  onOpenAi,
}) => {
  const [activeTab, setActiveTab] = useState<'TAX' | 'SUCCESSION' | 'GOVERNANCE'>('TAX');

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>TAX & MULTI-GENERATIONAL GOVERNANCE ENGINE</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Jurisdictional Tax Compliance, Family Constitution & Succession
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Cross-border tax rules (UK, US, CH, Jersey, Lux), Trust Deeds, voting control, and generational transfer protocols.
          </p>
        </div>

        <button
          onClick={() => onOpenAi('Review UK non-dom reforms and generational succession tax plan')}
          className="px-3.5 py-2 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 fill-black" />
          <span>Audit Tax Rules with Gemini</span>
        </button>
      </div>

      {/* Sub-navigation */}
      <div className="flex items-center gap-2 bg-[#0b0f17] border border-[#202b3d] p-1 rounded font-mono text-xs w-fit">
        <button
          onClick={() => setActiveTab('TAX')}
          className={`px-3 py-1.5 rounded transition-colors font-semibold ${
            activeTab === 'TAX' ? 'bg-[#d4af37] text-black shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Jurisdictional Tax Compliance
        </button>
        <button
          onClick={() => setActiveTab('SUCCESSION')}
          className={`px-3 py-1.5 rounded transition-colors font-semibold ${
            activeTab === 'SUCCESSION' ? 'bg-[#d4af37] text-black shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Generational Succession Model
        </button>
        <button
          onClick={() => setActiveTab('GOVERNANCE')}
          className={`px-3 py-1.5 rounded transition-colors font-semibold ${
            activeTab === 'GOVERNANCE' ? 'bg-[#d4af37] text-black shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Family Constitution & Resolutions
        </button>
      </div>

      {/* Content Panels */}
      {activeTab === 'TAX' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
            <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
              JURISDICTIONAL RULES & FILINGS
            </h2>

            <div className="space-y-3 font-mono text-xs">
              <div className="bg-[#0b0f17] border border-[#1f2c40] p-3.5 rounded space-y-1">
                <div className="flex justify-between font-bold text-amber-400">
                  <span>UNITED KINGDOM (HMRC)</span>
                  <span className="text-emerald-400">FILING UP TO DATE</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Remittance basis reform audit completed. 12 Grosvenor Square SDLT and ATED returns submitted for 2026/27 tax year.
                </p>
              </div>

              <div className="bg-[#0b0f17] border border-[#1f2c40] p-3.5 rounded space-y-1">
                <div className="flex justify-between font-bold text-blue-400">
                  <span>UNITED STATES (IRS / FATCA)</span>
                  <span className="text-emerald-400">COMPLIANT</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Form 8938 and FBAR filings synchronized for Delaware SPVs and US beneficiary distributions.
                </p>
              </div>

              <div className="bg-[#0b0f17] border border-[#1f2c40] p-3.5 rounded space-y-1">
                <div className="flex justify-between font-bold text-purple-400">
                  <span>SWITZERLAND (ESTV / CANTON ZURICH)</span>
                  <span className="text-emerald-400">COMPLIANT</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Pillar 2 global minimum tax assessment completed for Aurelia Philanthropic Stiftung.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
            <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
              UPCOMING TAX DEADLINES
            </h2>

            <div className="space-y-2 font-mono text-xs">
              {[
                { date: '15 OCT 2026', title: 'US IRS FBAR Form 114 Deadline', status: 'In Preparation' },
                { date: '30 NOV 2026', title: 'Luxembourg Soparfi Tax Return Filing', status: 'Ready' },
                { date: '31 JAN 2027', title: 'UK HMRC Self Assessment & ATED Return', status: 'Audited' },
              ].map((d, i) => (
                <div
                  key={i}
                  className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded flex items-center justify-between"
                >
                  <div>
                    <span className="text-amber-400 font-bold block">{d.title}</span>
                    <span className="text-slate-400 text-[11px]">Due: {d.date}</span>
                  </div>
                  <span className="px-2 py-0.5 bg-[#1b263b] text-slate-200 rounded text-[10px]">
                    {d.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'SUCCESSION' && (
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
          <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
            FAMILY MEMBERS & GENERATIONAL ACCESS ROLES
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs">
            {INITIAL_FAMILY_MEMBERS.map((m) => (
              <div key={m.id} className="bg-[#0b0f17] border border-[#1f2c40] p-4 rounded-lg space-y-2">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] text-[#d4af37] font-bold uppercase">{m.generation}</span>
                    <h3 className="text-sm font-bold text-slate-100 mt-0.5">{m.name}</h3>
                  </div>
                  <span className="px-2 py-0.5 bg-[#1b263b] text-slate-200 rounded text-[10px]">{m.role}</span>
                </div>

                <div className="text-slate-400 text-[11px] space-y-1 pt-2 border-t border-[#1e293b]">
                  <div>Citizenship: {Array.isArray(m.citizenship) ? m.citizenship.join(', ') : m.citizenship}</div>
                  <div>Residence: {m.residence}</div>
                  <div className="text-emerald-400">Status: {m.status}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'GOVERNANCE' && (
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4 font-mono text-xs">
          <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
            AURELIA FAMILY CONSTITUTION & RESOLUTIONS
          </h2>

          <div className="space-y-3">
            <div className="bg-[#0b0f17] border border-[#1f2c40] p-4 rounded-lg">
              <span className="text-amber-400 font-bold block">ARTICLE 1: CAPITAL PRESERVATION PRINCIPLE</span>
              <p className="text-slate-300 mt-1 leading-relaxed">
                Core family capital shall be preserved in real terms across generations. Annual family distributions shall not exceed 3.5% of net asset value calculated on a 3-year rolling average.
              </p>
            </div>

            <div className="bg-[#0b0f17] border border-[#1f2c40] p-4 rounded-lg">
              <span className="text-amber-400 font-bold block">ARTICLE 4: INVESTMENT COMMITTEE VOTING MAJORITY</span>
              <p className="text-slate-300 mt-1 leading-relaxed">
                Direct tickets exceeding $10,000,000 require unanimous approval of the Principal, CIO, and Senior Trustee.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
