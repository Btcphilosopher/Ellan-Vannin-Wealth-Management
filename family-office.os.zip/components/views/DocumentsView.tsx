'use client';

import React, { useState } from 'react';
import {
  FolderArchive,
  FileText,
  Lock,
  Search,
  Download,
  Eye,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import { INITIAL_DOCUMENTS, DocumentItem } from '@/lib/data/family-office-store';

interface DocumentsViewProps {
  onOpenAi: (query?: string) => void;
}

export const DocumentsView: React.FC<DocumentsViewProps> = ({ onOpenAi }) => {
  const [docs, setDocs] = useState<DocumentItem[]>(INITIAL_DOCUMENTS);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filtered = docs.filter((d) => {
    if (selectedCategory !== 'ALL' && d.category !== selectedCategory) return false;
    if (searchQuery && !d.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <FolderArchive className="w-3.5 h-3.5" />
            <span>ENCRYPTED FAMILY DOCUMENT VAULT</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Archival Deeds, Trust Instruments, Property Titles & Financial Audits
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            End-to-End Encrypted Storage • Version Control • Security Classification • AI Extraction Ready.
          </p>
        </div>

        <button
          onClick={() => onOpenAi('Extract key indemnities and trustee rights from Aurelia Dynastic Trust Deed')}
          className="px-3.5 py-2 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 fill-black" />
          <span>Extract Document Clauses with AI</span>
        </button>
      </div>

      {/* Filter and Table */}
      <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1f2c42]">
          <div className="flex items-center gap-3">
            <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider">
              VAULT REPOSITORY ({filtered.length})
            </h2>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-[#0b0f17] border border-[#26354e] text-slate-200 text-xs font-mono px-2.5 py-1 rounded"
            >
              <option value="ALL">All Categories</option>
              <option value="TRUST_DEEDS">Trust Deeds</option>
              <option value="ARTICLES_OF_ASSOC">Articles of Association</option>
              <option value="PROPERTY_TITLES">Property Titles</option>
              <option value="TAX_RETURNS">Tax Returns</option>
              <option value="CONSTITUTION">Constitutions</option>
              <option value="PROVENANCE_CERTIFICATES">Provenance</option>
            </select>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
            <input
              type="text"
              placeholder="Search document title..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-[#0b0f17] border border-[#26354e] text-slate-200 text-xs font-mono pl-8 pr-3 py-1 rounded w-52"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1e293b] text-slate-400 uppercase">
                <th className="pb-3 px-3">Document Title</th>
                <th className="pb-3 px-3">Category</th>
                <th className="pb-3 px-3">Entity</th>
                <th className="pb-3 px-3">Classification</th>
                <th className="pb-3 px-3">Date Added</th>
                <th className="pb-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182234]">
              {filtered.map((doc) => (
                <tr key={doc.id} className="hover:bg-[#151e2e] transition-colors">
                  <td className="py-3 px-3 font-bold text-slate-100">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-[#d4af37]" />
                      <span>{doc.title}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-slate-300">{doc.category}</td>
                  <td className="py-3 px-3 text-slate-300">{doc.owningEntity}</td>
                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        doc.securityClassification === 'RESTRICTED_PRINCIPAL'
                          ? 'bg-rose-950 text-rose-400 border border-rose-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}
                    >
                      {doc.securityClassification}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-400">{doc.effectiveDate}</td>
                  <td className="py-3 px-3 text-right space-x-2">
                    <button
                      onClick={() =>
                        onOpenAi(`Summarize contents and legal implications of ${doc.title}`)
                      }
                      className="px-2 py-1 bg-[#1b263b] hover:bg-[#283856] text-[#d4af37] rounded border border-[#304263]"
                    >
                      AI Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
