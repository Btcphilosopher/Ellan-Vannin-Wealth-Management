'use client';

import React, { useState } from 'react';
import {
  Building2,
  Users,
  Wrench,
  ShieldCheck,
  DollarSign,
  MapPin,
  ChevronRight,
  Sparkles,
  FileText,
} from 'lucide-react';
import { INITIAL_PROPERTIES, PropertyItem } from '@/lib/data/family-office-store';

interface PropertyOSViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onOpenAi: (query?: string) => void;
}

export const PropertyOSView: React.FC<PropertyOSViewProps> = ({
  currency,
  onOpenAi,
}) => {
  const [properties, setProperties] = useState<PropertyItem[]>(INITIAL_PROPERTIES);
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>('prop-1');

  const selectedProp = properties.find((p) => p.id === selectedPropertyId) || properties[0];

  const formatVal = (usdAmount: number) => {
    let factor = 1.0;
    let symbol = '$';
    if (currency === 'GBP') {
      factor = 0.77;
      symbol = '£';
    } else if (currency === 'EUR') {
      factor = 0.91;
      symbol = '€';
    }
    const val = usdAmount * factor;
    if (val >= 1e6) return `${symbol}${(val / 1e6).toFixed(1)}M`;
    return `${symbol}${val.toLocaleString()}`;
  };

  const totalPropVal = properties.reduce((acc, p) => acc + p.valuationUsd, 0);
  const totalDebt = properties.reduce((acc, p) => acc + p.mortgageUsd, 0);
  const totalNetEquity = totalPropVal - totalDebt;

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <Building2 className="w-3.5 h-3.5" />
            <span>PROPERTY.OS — REAL ESTATE DIGITAL TWINS</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Prime Residential Estates & Commercial Real Estate Operating System
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Mortgage Debt, Staff Management, Capex Schedules, Tenancies, and Property Insurance.
          </p>
        </div>

        <button
          onClick={() =>
            onOpenAi(`Provide operational and mortgage debt breakdown for ${selectedProp.name}`)
          }
          className="px-3.5 py-2 bg-gradient-to-r from-[#9a7b20] to-[#6b520d] text-black text-xs font-mono font-bold rounded border border-[#d4af37]/60 shadow transition-all flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 fill-black" />
          <span>Audit Property with Gemini</span>
        </button>
      </div>

      {/* Real Estate KPI Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">GROSS REAL ESTATE VALUATION</span>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(totalPropVal)}</p>
          <span className="text-[11px] font-mono text-slate-400 mt-1 block">4 Prime Assets</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">MORTGAGE DEBT</span>
          <p className="text-xl font-bold text-rose-400 mono-num mt-1">{formatVal(totalDebt)}</p>
          <span className="text-[11px] font-mono text-slate-400 mt-1 block">Weighted LTV: 21.0%</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">NET REAL ESTATE EQUITY</span>
          <p className="text-xl font-bold text-emerald-400 mono-num mt-1">{formatVal(totalNetEquity)}</p>
          <span className="text-[11px] font-mono text-emerald-400 mt-1 block">Unencumbered Capital</span>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Property Selector List */}
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
          <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider pb-2 border-b border-[#1f2c42]">
            REAL ESTATE PORTFOLIO
          </h2>

          <div className="space-y-3">
            {properties.map((prop) => (
              <button
                key={prop.id}
                onClick={() => setSelectedPropertyId(prop.id)}
                className={`w-full text-left p-3.5 rounded-lg border transition-all ${
                  selectedPropertyId === prop.id
                    ? 'border-[#d4af37] bg-[#1d180d] shadow-md'
                    : 'border-[#202d42] bg-[#0b0f17] hover:border-[#334666]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-[#d4af37] font-bold uppercase">
                    {prop.type}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-500" />
                    {prop.location}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-100 mt-1">{prop.name}</h3>

                <div className="flex items-center justify-between text-xs font-mono text-slate-300 mt-2">
                  <span>Val: {formatVal(prop.valuationUsd)}</span>
                  <span className="text-emerald-400 font-bold">Net: {formatVal(prop.netEquityUsd)}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Selected Property Twin Detail Panel */}
        <div className="lg:col-span-2 bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-5">
          <div className="pb-3 border-b border-[#1f2c42] flex flex-col md:flex-row md:items-center justify-between gap-2">
            <div>
              <span className="text-[10px] font-mono text-[#d4af37] font-bold uppercase">
                DIGITAL TWIN SPECIFICATION
              </span>
              <h2 className="text-lg font-bold text-slate-100 mt-0.5">{selectedProp.name}</h2>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                {selectedProp.location} • Held by {selectedProp.owningEntity}
              </p>
            </div>

            <div className="text-right">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">NET EQUITY</span>
              <span className="text-xl font-bold text-emerald-400 mono-num">
                {formatVal(selectedProp.netEquityUsd)}
              </span>
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">VALUATION</span>
              <span className="text-sm font-bold text-slate-100 mono-num mt-0.5 block">
                {formatVal(selectedProp.valuationUsd)}
              </span>
            </div>

            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">MORTGAGE DEBT</span>
              <span className="text-sm font-bold text-rose-400 mono-num mt-0.5 block">
                {formatVal(selectedProp.mortgageUsd)}
              </span>
            </div>

            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">STAFF COUNT</span>
              <span className="text-sm font-bold text-slate-100 mono-num mt-0.5 block">
                {selectedProp.staffCount} Dedicated Staff
              </span>
            </div>

            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3 rounded">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">INSURANCE POLICY</span>
              <span className="text-sm font-bold text-emerald-400 mt-0.5 block">
                {selectedProp.insurancePolicyNumber}
              </span>
            </div>
          </div>

          {/* Operational Details */}
          <div className="space-y-3 font-mono text-xs">
            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3.5 rounded space-y-1">
              <span className="text-slate-400 font-bold uppercase block">ANNUAL OPERATING EXPENSE & RENTAL YIELD</span>
              <p className="text-slate-200">
                Annual Expense: {formatVal(selectedProp.annualExpenseUsd)} • Rental Income: {formatVal(selectedProp.rentalIncomeUsd)}
              </p>
            </div>

            <div className="bg-[#0b0f17] border border-[#1f2c40] p-3.5 rounded space-y-1">
              <span className="text-slate-400 font-bold uppercase block">INSURANCE EXPIRY & RISK STATUS</span>
              <p className="text-slate-200">Policy active through {selectedProp.insuranceExpiry}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
