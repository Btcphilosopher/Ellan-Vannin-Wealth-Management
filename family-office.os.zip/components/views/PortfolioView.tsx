'use client';

import React, { useState } from 'react';
import {
  PieChart,
  BarChart2,
  Globe,
  Briefcase,
  TrendingUp,
  Filter,
  ArrowUpRight,
  ShieldAlert,
  ChevronRight,
} from 'lucide-react';
import {
  INITIAL_ASSET_POSITIONS,
  AssetPosition,
} from '@/lib/data/family-office-store';

interface PortfolioViewProps {
  currency: 'USD' | 'GBP' | 'EUR';
  onOpenAi: (query?: string) => void;
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({
  currency,
  onOpenAi,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const formatVal = (usdAmount: number) => {
    let factor = 1.0;
    let symbol = '$';
    if (currency === 'GBP') {
      factor = 0.77;
      symbol = '£';
    } else if (currency === 'EUR') {
      factor = 0.91;
      symbol = '€';
    }
    const val = usdAmount * factor;
    if (val >= 1e9) return `${symbol}${(val / 1e9).toFixed(3)}B`;
    if (val >= 1e6) return `${symbol}${(val / 1e6).toFixed(1)}M`;
    return `${symbol}${val.toLocaleString()}`;
  };

  const filtered = INITIAL_ASSET_POSITIONS.filter((p) => {
    if (selectedCategory !== 'ALL' && p.assetClass !== selectedCategory) return false;
    if (searchQuery && !p.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const totalValue = INITIAL_ASSET_POSITIONS.reduce((acc, p) => acc + p.valueUsd, 0);
  const totalCost = INITIAL_ASSET_POSITIONS.reduce((acc, p) => acc + p.costBasisUsd, 0);
  const totalGains = totalValue - totalCost;

  return (
    <div className="p-4 lg:p-6 max-w-[1700px] mx-auto space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] font-semibold uppercase">
            <PieChart className="w-3.5 h-3.5" />
            <span>INSTITUTIONAL PORTFOLIO ENGINE</span>
          </div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight mt-0.5">
            Public & Private Investment Positions & Look-Through Analytics
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            TWR, IRR, MOIC, Cost Basis, Custodian Breakdown, and Look-through Geography.
          </p>
        </div>

        <button
          onClick={() => onOpenAi('Analyze portfolio look-through risk and technology exposure')}
          className="px-3.5 py-2 bg-[#1b263b] hover:bg-[#253450] text-slate-200 text-xs font-mono font-semibold rounded border border-[#304263] transition-colors flex items-center gap-1.5"
        >
          <span>Ask Gemini to Audit Portfolio Performance</span>
          <ChevronRight className="w-3.5 h-3.5 text-[#d4af37]" />
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">PORTFOLIO MARKET VALUE</span>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(totalValue)}</p>
          <span className="text-[11px] font-mono text-emerald-400 mt-1 block">+14.8% TWR YTD</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">TOTAL COST BASIS</span>
          <p className="text-xl font-bold text-slate-100 mono-num mt-1">{formatVal(totalCost)}</p>
          <span className="text-[11px] font-mono text-slate-400 mt-1 block">Historical Capital Deployed</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">UNREALIZED CAPITAL GAINS</span>
          <p className="text-xl font-bold text-emerald-400 mono-num mt-1">{formatVal(totalGains)}</p>
          <span className="text-[11px] font-mono text-emerald-400 mt-1 block">+{((totalGains / totalCost) * 100).toFixed(1)}% Total Return</span>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-4 rounded-lg">
          <span className="text-xs font-mono text-slate-400 uppercase">BLENDED PRIVATE IRR</span>
          <p className="text-xl font-bold text-amber-400 mono-num mt-1">22.4%</p>
          <span className="text-[11px] font-mono text-slate-400 mt-1 block">PE / VC / Co-Investments</span>
        </div>
      </div>

      {/* Look-through Sector & Geography Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-3">
          <h3 className="text-xs font-mono font-bold text-slate-100 uppercase tracking-wider">
            LOOK-THROUGH GEOGRAPHY DISTRIBUTION
          </h3>
          <div className="space-y-2 font-mono text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>North America (US & Delaware SPVs)</span>
                <span>42.5% ($552M)</span>
              </div>
              <div className="w-full h-2 bg-[#0b0f17] rounded overflow-hidden">
                <div className="bg-blue-500 h-full" style={{ width: '42.5%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Western Europe (UK, France, Swiss, Lux)</span>
                <span>48.0% ($624M)</span>
              </div>
              <div className="w-full h-2 bg-[#0b0f17] rounded overflow-hidden">
                <div className="bg-emerald-500 h-full" style={{ width: '48.0%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Global / Emerging Markets</span>
                <span>9.5% ($125M)</span>
              </div>
              <div className="w-full h-2 bg-[#0b0f17] rounded overflow-hidden">
                <div className="bg-purple-500 h-full" style={{ width: '9.5%' }} />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-3">
          <h3 className="text-xs font-mono font-bold text-slate-100 uppercase tracking-wider">
            SECTOR EXPOSURE BREAKDOWN
          </h3>
          <div className="space-y-2 font-mono text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Clean Energy & Renewables</span>
                <span>28.6% ($372M)</span>
              </div>
              <div className="w-full h-2 bg-[#0b0f17] rounded overflow-hidden">
                <div className="bg-emerald-400 h-full" style={{ width: '28.6%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Technology, AI & Software</span>
                <span>24.2% ($315M)</span>
              </div>
              <div className="w-full h-2 bg-[#0b0f17] rounded overflow-hidden">
                <div className="bg-purple-400 h-full" style={{ width: '24.2%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Prime Real Estate & Estates</span>
                <span>14.2% ($185M)</span>
              </div>
              <div className="w-full h-2 bg-[#0b0f17] rounded overflow-hidden">
                <div className="bg-amber-400 h-full" style={{ width: '14.2%' }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Positions Grid */}
      <div className="bg-[#121927] border border-[#202b3d] p-5 rounded-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1f2c42]">
          <div className="flex items-center gap-3">
            <h2 className="text-sm font-mono font-bold text-slate-100 uppercase tracking-wider">
              ALL PORTFOLIO POSITIONS ({filtered.length})
            </h2>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-[#0b0f17] border border-[#26354e] text-slate-200 text-xs font-mono px-2.5 py-1 rounded"
            >
              <option value="ALL">All Categories</option>
              <option value="PUBLIC_MARKETS">Public Markets</option>
              <option value="PRIVATE_MARKETS">Private Markets</option>
              <option value="OPERATING_BUSINESSES">Operating Co.</option>
              <option value="REAL_ESTATE">Real Estate</option>
              <option value="COLLECTIBLES">Collectibles</option>
              <option value="CASH">Cash</option>
            </select>
          </div>

          <input
            type="text"
            placeholder="Search position..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-[#0b0f17] border border-[#26354e] text-slate-200 text-xs font-mono px-3 py-1 rounded w-48"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((pos) => (
            <div
              key={pos.id}
              className="bg-[#0b0f17] border border-[#1f2c40] p-4 rounded-lg space-y-2 hover:border-[#334666] transition-all"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono text-[#d4af37] font-bold uppercase">{pos.subCategory}</span>
                  <h4 className="text-sm font-bold text-slate-100 leading-tight mt-0.5">{pos.name}</h4>
                  <span className="text-[11px] font-mono text-slate-400 block mt-0.5">{pos.entityName}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-[#1a2538] flex items-center justify-between font-mono">
                <div>
                  <span className="text-[10px] text-slate-400 block">VALUE</span>
                  <span className="text-sm font-bold text-slate-100 mono-num">{formatVal(pos.valueUsd)}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">TWR / RETURN</span>
                  <span
                    className={`text-sm font-bold mono-num ${
                      pos.twrPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {pos.twrPercent >= 0 ? '+' : ''}
                    {pos.twrPercent}%
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1">
                <span>Valuation: {pos.valuationMethod}</span>
                <span>{pos.custodianBank || pos.geography}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
