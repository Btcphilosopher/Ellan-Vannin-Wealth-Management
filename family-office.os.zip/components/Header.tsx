'use client';

import React from 'react';
import {
  ShieldCheck,
  Search,
  Zap,
  Globe,
  Bell,
  SlidersHorizontal,
} from 'lucide-react';

interface HeaderProps {
  activeCurrency: 'USD' | 'GBP' | 'EUR';
  setActiveCurrency: (c: 'USD' | 'GBP' | 'EUR') => void;
  onOpenSearch: () => void;
  onNewRecord: () => void;
  onOpenAi: (query?: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeCurrency,
  setActiveCurrency,
  onOpenSearch,
  onNewRecord,
  onOpenAi,
}) => {
  return (
    <header className="border-b border-[#1e293b] bg-[#0b0f17]/95 backdrop-blur sticky top-0 z-40 px-4 lg:px-6 py-3 flex items-center justify-between">
      {/* Brand & Family Identity */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-[#d4af37] via-[#9a7b20] to-[#5a450e] flex items-center justify-center text-black font-bold tracking-wider text-xs shadow-md border border-[#d4af37]/40">
            FO
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm tracking-wider text-slate-100 uppercase">
                FAMILY OFFICE.OS
              </span>
              <span className="px-1.5 py-0.5 text-[10px] font-mono bg-[#1e293b] text-[#d4af37] rounded border border-[#334155]">
                v3.6-INSTITUTIONAL
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">
              Aurelia Family Office • Geneva / London / Zurich
            </p>
          </div>
        </div>

        {/* Security / Clearance Badge */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 bg-[#121824] border border-[#1e293b] rounded text-xs text-emerald-400 font-mono">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>RBAC: PRINCIPAL / SERVER AUTHORIZED</span>
        </div>
      </div>

      {/* Global Actions & Controls */}
      <div className="flex items-center gap-2 lg:gap-3">
        {/* Quick Search Trigger */}
        <button
          onClick={onOpenSearch}
          className="flex items-center gap-2 bg-[#131b2a] hover:bg-[#1c273c] text-slate-300 text-xs px-3 py-1.5 rounded border border-[#233148] transition-colors"
        >
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <span className="hidden sm:inline">Search graph, assets, documents...</span>
          <kbd className="hidden lg:inline-block px-1.5 py-0.5 text-[10px] font-mono bg-[#0b0f17] text-slate-400 rounded border border-[#2d3b54]">
            ⌘K
          </kbd>
        </button>

        {/* Currency Switcher */}
        <div className="flex items-center bg-[#131b2a] rounded border border-[#233148] p-0.5">
          {(['USD', 'GBP', 'EUR'] as const).map((curr) => (
            <button
              key={curr}
              onClick={() => setActiveCurrency(curr)}
              className={`px-2 py-1 text-[11px] font-mono font-semibold rounded transition-colors ${
                activeCurrency === curr
                  ? 'bg-[#d4af37] text-black shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {curr}
            </button>
          ))}
        </div>

        {/* New Record Modal Button */}
        <button
          onClick={onNewRecord}
          className="hidden sm:flex items-center gap-1.5 bg-[#1b263b] hover:bg-[#253450] text-[#e2e8f0] text-xs font-medium px-3 py-1.5 rounded border border-[#334566] transition-colors"
        >
          <SlidersHorizontal className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>+ Record</span>
        </button>

        {/* Ask AI Shortcut */}
        <button
          onClick={() => onOpenAi()}
          className="flex items-center gap-1.5 bg-gradient-to-r from-[#1e293b] to-[#0f172a] hover:from-[#334155] hover:to-[#1e293b] text-[#d4af37] text-xs font-semibold px-3 py-1.5 rounded border border-[#d4af37]/40 shadow-sm transition-all"
        >
          <Zap className="w-3.5 h-3.5 fill-[#d4af37]" />
          <span>Ask Gemini 3.6</span>
        </button>
      </div>
    </header>
  );
};
