import React from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { DEMO_USERS } from '../../data/seedData';
import {
  Search,
  Bell,
  ChevronDown,
  Sparkles,
  Shield,
  Film,
  Building,
  Activity,
  UserCheck
} from 'lucide-react';

export const TopNav: React.FC = () => {
  const {
    activeTab,
    projects,
    selectedProjectId,
    setSelectedProjectId,
    currentUser,
    setCurrentUser,
    notifications,
    setCommandPaletteOpen,
    setNotificationPanelOpen
  } = useStudioStore();

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];
  const unreadCount = notifications.filter((n) => !n.read).length;

  const tabTitles: Record<string, string> = {
    command: 'Command Centre',
    slate: 'Slate & Portfolio Management',
    development: 'Development & Commissioning',
    productions: 'Production Management',
    scheduling: 'Shooting Schedule & Gantt Planning',
    media: 'Media Operations & Asset Management',
    post: 'Post-Production Command',
    vfx: 'Visual Effects (VFX) Management',
    distribution: 'Global Localisation & Content Supply Chain',
    finance: 'Production Finance & Cost Reports',
    rights: 'Rights & Legal Clearance',
    marketing: 'Marketing Campaigns & Deliverables',
    facilities: 'Studio Facilities & Lot Resources',
    sustainability: 'Environmental Impact & Sustainability',
    analytics: 'Enterprise Analytics & Executive Reporting',
    administration: 'Access Control & System Audit'
  };

  return (
    <header className="h-14 bg-[#12151A] border-b border-slate-800 px-4 flex items-center justify-between shrink-0 z-20">
      {/* Left section: Breadcrumb & Project Selector */}
      <div className="flex items-center space-x-4">
        {/* Project Selector Dropdown */}
        <div className="relative group">
          <div className="flex items-center space-x-2 bg-slate-900 border border-slate-700/80 hover:border-slate-600 px-3 py-1.5 rounded cursor-pointer transition-all">
            <Film className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-slate-100 max-w-[160px] truncate">
              {selectedProject.title}
            </span>
            <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
              {selectedProject.currentStage}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </div>

          <select
            value={selectedProjectId}
            onChange={(e) => setSelectedProjectId(e.target.value)}
            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
          >
            {projects.map((p) => (
              <option key={p.id} value={p.id} className="bg-slate-900 text-slate-200">
                {p.title} ({p.format} — {p.currentStage})
              </option>
            ))}
          </select>
        </div>

        {/* Separator */}
        <div className="h-4 w-px bg-slate-800" />

        {/* Breadcrumb Title */}
        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-500 font-mono uppercase">PARAMOUNT LOT</span>
          <span className="text-slate-600">/</span>
          <span className="font-semibold text-slate-200 tracking-wide">
            {tabTitles[activeTab] || 'Workspace'}
          </span>
        </div>
      </div>

      {/* Middle: Command Palette Quick Search Button */}
      <button
        onClick={() => setCommandPaletteOpen(true)}
        className="hidden md:flex items-center justify-between w-72 bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 px-3 py-1.5 rounded text-xs text-slate-400 transition-all cursor-pointer shadow-inner"
      >
        <div className="flex items-center space-x-2">
          <Search className="w-3.5 h-3.5 text-slate-400" />
          <span>Search assets, scenes, POs, rights...</span>
        </div>
        <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-slate-800 text-slate-400 border border-slate-700 rounded">
          ⌘K
        </kbd>
      </button>

      {/* Right section: System Status, Notifications, Role Switcher */}
      <div className="flex items-center space-x-3">
        {/* System Status Pill */}
        <div className="hidden lg:flex items-center space-x-2 px-2.5 py-1 bg-emerald-950/40 border border-emerald-800/40 rounded text-[11px] font-mono text-emerald-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>LOT OPS NORMAL</span>
        </div>

        {/* Notification Bell */}
        <button
          onClick={() => setNotificationPanelOpen(true)}
          className="relative p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded text-slate-300 transition-colors"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-amber-500 text-slate-950 font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </button>

        {/* User Role Switcher Dropdown */}
        <div className="relative group">
          <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 hover:border-slate-700 px-2.5 py-1 rounded cursor-pointer transition-colors">
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.name}
              className="w-6 h-6 rounded-full border border-slate-700 object-cover"
            />
            <div className="text-left hidden sm:block">
              <div className="text-xs font-semibold text-slate-200 leading-none">
                {currentUser.name}
              </div>
              <div className="text-[10px] font-mono text-amber-400 leading-tight mt-0.5">
                {currentUser.role}
              </div>
            </div>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </div>

          <select
            value={currentUser.id}
            onChange={(e) => {
              const selected = DEMO_USERS.find((u) => u.id === e.target.value);
              if (selected) setCurrentUser(selected);
            }}
            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
          >
            {DEMO_USERS.map((u) => (
              <option key={u.id} value={u.id} className="bg-slate-900 text-slate-200">
                {u.name} — {u.role} ({u.division})
              </option>
            ))}
          </select>
        </div>
      </div>
    </header>
  );
};
