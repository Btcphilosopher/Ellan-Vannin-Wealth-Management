import React from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { Sidebar } from './Sidebar';
import { TopNav } from './TopNav';
import { CommandPalette } from './CommandPalette';
import { DeveloperConsole } from './DeveloperConsole';
import { NotificationPanel } from './NotificationPanel';

import { CommandCenterView } from '../views/CommandCenterView';
import { SlateOverviewView } from '../views/SlateOverviewView';
import { DevelopmentView } from '../views/DevelopmentView';
import { ProductionWorkspaceView } from '../views/ProductionWorkspaceView';
import { SchedulingView } from '../views/SchedulingView';
import { MediaOpsView } from '../views/MediaOpsView';
import { PostProductionView } from '../views/PostProductionView';
import { VfxManagementView } from '../views/VfxManagementView';
import { DistributionView } from '../views/DistributionView';
import { FinanceView } from '../views/FinanceView';
import { RightsManagementView } from '../views/RightsManagementView';
import { MarketingView } from '../views/MarketingView';
import { FacilitiesView } from '../views/FacilitiesView';
import { SustainabilityView } from '../views/SustainabilityView';
import { AnalyticsView } from '../views/AnalyticsView';
import { AdministrationView } from '../views/AdministrationView';

export const AppShell: React.FC = () => {
  const { activeTab } = useStudioStore();

  const renderView = () => {
    switch (activeTab) {
      case 'command':
        return <CommandCenterView />;
      case 'slate':
        return <SlateOverviewView />;
      case 'development':
        return <DevelopmentView />;
      case 'productions':
        return <ProductionWorkspaceView />;
      case 'scheduling':
        return <SchedulingView />;
      case 'media':
        return <MediaOpsView />;
      case 'post':
        return <PostProductionView />;
      case 'vfx':
        return <VfxManagementView />;
      case 'distribution':
        return <DistributionView />;
      case 'finance':
        return <FinanceView />;
      case 'rights':
        return <RightsManagementView />;
      case 'marketing':
        return <MarketingView />;
      case 'facilities':
        return <FacilitiesView />;
      case 'sustainability':
        return <SustainabilityView />;
      case 'analytics':
        return <AnalyticsView />;
      case 'administration':
        return <AdministrationView />;
      default:
        return <CommandCenterView />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0A0C0E] text-slate-100 font-sans select-none">
      {/* Persistent Left Sidebar */}
      <Sidebar />

      {/* Main Content Workspace Container */}
      <div className="flex flex-col flex-1 min-w-0 h-full overflow-hidden">
        {/* Top Command Bar */}
        <TopNav />

        {/* Scrollable Active View Area */}
        <main className="flex-1 overflow-y-auto custom-scrollbar bg-[#0A0C0E]">
          {renderView()}
        </main>
      </div>

      {/* Floating Modals & Drawers */}
      <CommandPalette />
      <DeveloperConsole />
      <NotificationPanel />
    </div>
  );
};
