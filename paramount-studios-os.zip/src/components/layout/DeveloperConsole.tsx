import React, { useState } from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import {
  Terminal,
  X,
  Play,
  Pause,
  RotateCcw,
  Clock,
  AlertTriangle,
  FileWarning,
  CheckCircle,
  ShieldAlert,
  Flame,
  Zap,
  Activity,
  Calendar,
  Layers
} from 'lucide-react';

export const DeveloperConsole: React.FC = () => {
  const {
    isDeveloperConsoleOpen,
    setDeveloperConsoleOpen,
    events,
    projects,
    selectedProjectId,
    triggerScheduleDelay,
    triggerIngestFailure,
    triggerQCFailure,
    triggerRightsExpiry,
    approveVFXShot,
    advanceSimulatedTimeHours,
    resetDemoData
  } = useStudioStore();

  const [isSimulating, setIsSimulating] = useState(true);
  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  if (!isDeveloperConsoleOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div
        className="w-full max-w-4xl bg-[#0E1014] border border-amber-500/40 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh] text-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Console Header */}
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg border border-amber-500/30">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <div className="font-mono font-bold text-sm text-slate-100 flex items-center gap-2">
                STUDIO SIMULATION & DEVELOPER CONSOLE
                <span className="text-[10px] px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded uppercase font-bold">
                  SIM ENGINE ONLINE
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono">
                Target Project: <span className="text-amber-300 font-bold">{selectedProject.title}</span> ({selectedProject.id})
              </div>
            </div>
          </div>

          <button
            onClick={() => setDeveloperConsoleOpen(false)}
            className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Control Bar */}
        <div className="px-4 py-3 bg-[#12151A] border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsSimulating(!isSimulating)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded font-bold transition-all ${
                isSimulating
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-slate-800 text-slate-300 border border-slate-700'
              }`}
            >
              {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isSimulating ? 'SIMULATION ACTIVE' : 'PAUSED'}</span>
            </button>

            <button
              onClick={() => resetDemoData()}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded font-medium transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset All Demo State</span>
            </button>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-slate-400">Advance Time:</span>
            <button
              onClick={() => advanceSimulatedTimeHours(1)}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 rounded"
            >
              +1 Hr
            </button>
            <button
              onClick={() => advanceSimulatedTimeHours(12)}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 rounded"
            >
              +12 Hrs
            </button>
            <button
              onClick={() => advanceSimulatedTimeHours(24)}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 rounded"
            >
              +24 Hrs
            </button>
          </div>
        </div>

        {/* Simulation Triggers Grid */}
        <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 bg-[#0E1014] border-b border-slate-800">
          {/* Trigger 1: Schedule Delay */}
          <button
            onClick={() => triggerScheduleDelay(selectedProject.id, 2, 'Stage 14 Zero-G Cable Calibration Failure')}
            className="p-3 bg-slate-900/90 hover:bg-slate-800 border border-amber-500/30 rounded-lg text-left transition-all hover:border-amber-400 group"
          >
            <div className="flex items-center space-x-2 text-amber-400 font-bold font-mono text-xs mb-1">
              <Calendar className="w-4 h-4" />
              <span>TRIGGER SCHEDULE DELAY</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Delays current shoot by 2 days. Updates risk rating to HIGH and adjusts forecast budget variance by +$370k.
            </p>
          </button>

          {/* Trigger 2: Media Ingest Failure */}
          <button
            onClick={() => triggerIngestFailure('job_ing_881', 'SAN Cluster Network Timeout frame checksum mismatch')}
            className="p-3 bg-slate-900/90 hover:bg-slate-800 border border-red-500/30 rounded-lg text-left transition-all hover:border-red-400 group"
          >
            <div className="flex items-center space-x-2 text-red-400 font-bold font-mono text-xs mb-1">
              <FileWarning className="w-4 h-4" />
              <span>MEDIA INGEST FAILURE</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Simulates SAN transfer interruption on active camera original asset and logs checksum exception.
            </p>
          </button>

          {/* Trigger 3: QC Failure */}
          <button
            onClick={() => triggerQCFailure('asset_master_tlo_101', 'Audio dropout on Channel 3 LtRt surround track')}
            className="p-3 bg-slate-900/90 hover:bg-slate-800 border border-red-500/30 rounded-lg text-left transition-all hover:border-red-400 group"
          >
            <div className="flex items-center space-x-2 text-red-400 font-bold font-mono text-xs mb-1">
              <AlertTriangle className="w-4 h-4" />
              <span>RECORD QC FAILURE</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Flags master video asset as QC Failed. Blocks associated distribution orders until remediated.
            </p>
          </button>

          {/* Trigger 4: Rights Expiry */}
          <button
            onClick={() => triggerRightsExpiry('rgt_m101')}
            className="p-3 bg-slate-900/90 hover:bg-slate-800 border border-amber-500/30 rounded-lg text-left transition-all hover:border-amber-400 group"
          >
            <div className="flex items-center space-x-2 text-amber-400 font-bold font-mono text-xs mb-1">
              <ShieldAlert className="w-4 h-4" />
              <span>EXPIRING MUSIC RIGHTS</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Sets music licence status to EXPIRED. Flags legal restriction on German/European delivery matrix.
            </p>
          </button>

          {/* Trigger 5: Approve VFX Shot */}
          <button
            onClick={() => approveVFXShot('vfx_101')}
            className="p-3 bg-slate-900/90 hover:bg-slate-800 border border-emerald-500/30 rounded-lg text-left transition-all hover:border-emerald-400 group"
          >
            <div className="flex items-center space-x-2 text-emerald-400 font-bold font-mono text-xs mb-1">
              <CheckCircle className="w-4 h-4" />
              <span>APPROVE HERO VFX SHOT</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Approves ILM Hero Shot TLO_101_010. Updates VFX completion percentage and cost variance.
            </p>
          </button>

          {/* Trigger 6: Facility Conflict */}
          <button
            onClick={() =>
              triggerScheduleDelay(selectedProject.id, 1, 'Stage 5 Air Lock Set Power Grid Maintenance Conflict')
            }
            className="p-3 bg-slate-900/90 hover:bg-slate-800 border border-purple-500/30 rounded-lg text-left transition-all hover:border-purple-400 group"
          >
            <div className="flex items-center space-x-2 text-purple-400 font-bold font-mono text-xs mb-1">
              <Flame className="w-4 h-4" />
              <span>STAGE FACILITY CONFLICT</span>
            </div>
            <p className="text-[11px] text-slate-400">
              Simulates power grid overhaul conflict on Sound Stage 5 and flags facility overlap.
            </p>
          </button>
        </div>

        {/* Live Studio Event Stream Log */}
        <div className="p-4 bg-[#0A0C0E] flex-1 overflow-y-auto custom-scrollbar font-mono text-xs space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-[11px] uppercase tracking-wider font-bold mb-2 pb-1 border-b border-slate-800">
            <div className="flex items-center space-x-2">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              <span>LIVE STUDIO EVENT BUS LOG STREAM ({events.length} EVENTS)</span>
            </div>
            <span>DETERMINISTIC REPLAY MODE</span>
          </div>

          {events.length === 0 ? (
            <div className="text-center py-8 text-slate-500">No events logged yet.</div>
          ) : (
            events.map((evt) => (
              <div
                key={evt.id}
                className={`p-2.5 rounded border text-xs flex flex-col md:flex-row md:items-center justify-between gap-2 ${
                  evt.severity === 'Critical'
                    ? 'bg-red-950/30 border-red-800/60 text-red-200'
                    : evt.severity === 'Warning'
                    ? 'bg-amber-950/30 border-amber-800/60 text-amber-200'
                    : 'bg-slate-900/80 border-slate-800 text-slate-300'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold font-mono text-[11px] text-amber-400">
                      [{evt.type}]
                    </span>
                    <span className="font-semibold text-slate-100">{evt.title || evt.affectedEntity}</span>
                  </div>
                  <div className="text-[11px] text-slate-400">{evt.description}</div>
                </div>

                <div className="text-right text-[10px] text-slate-500 shrink-0 font-mono">
                  <div>{new Date(evt.timestamp).toLocaleTimeString()}</div>
                  <div className="text-slate-400">By: {evt.triggeredBy}</div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
