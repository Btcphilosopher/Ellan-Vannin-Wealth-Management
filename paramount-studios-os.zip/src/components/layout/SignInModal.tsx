import React, { useState } from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { DEMO_USERS } from '../../data/seedData';
import { UserProfile } from '../../types';
import { Shield, Check, Lock, Building, UserCheck, Key, AlertCircle } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const SignInModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { currentUser, setCurrentUser } = useStudioStore();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div
        className="w-full max-w-xl bg-[#0E1014] border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-600 to-amber-900 border border-amber-500/40 flex items-center justify-center font-bold text-white text-sm">
              M
            </div>
            <div>
              <div className="font-bold text-sm text-slate-100 flex items-center gap-2">
                PARAMOUNT STUDIOS OS — DEMO PROFILES & RBAC
              </div>
              <div className="text-xs text-slate-400 font-mono">
                Select a role profile to test permission boundaries & access privileges.
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded border border-slate-700 font-mono"
          >
            Close
          </button>
        </div>

        {/* Profile List */}
        <div className="p-4 max-h-[60vh] overflow-y-auto space-y-2.5 custom-scrollbar font-mono text-xs">
          {DEMO_USERS.map((user) => {
            const isSelected = currentUser.id === user.id;
            return (
              <div
                key={user.id}
                onClick={() => {
                  setCurrentUser(user);
                  onClose();
                }}
                className={`p-3.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? 'bg-amber-500/10 border-amber-500/60 text-slate-100 shadow-md'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <img
                    src={user.avatarUrl}
                    alt={user.name}
                    className="w-10 h-10 rounded-full border border-slate-700 object-cover"
                  />
                  <div>
                    <div className="font-bold text-slate-100 text-sm flex items-center gap-2">
                      {user.name}
                      {isSelected && (
                        <span className="text-[10px] px-1.5 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded font-bold">
                          ACTIVE SESSION
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-400 font-sans">{user.title}</div>
                    <div className="text-[10px] text-amber-400 mt-0.5">{user.division}</div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="px-2 py-1 bg-slate-800 rounded border border-slate-700 text-[11px] font-bold text-slate-200">
                    Role: {user.role}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Security Notice */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center space-x-2 text-[11px] text-slate-400 font-mono">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Fictional demonstration interface. No real credentials or authentication involved.</span>
        </div>
      </div>
    </div>
  );
};
