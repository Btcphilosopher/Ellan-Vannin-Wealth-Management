import React, { useState, useEffect } from 'react';
import { useStudioStore, WorkspaceTab } from '../../state/useStudioStore';
import {
  Search,
  X,
  Film,
  HardDrive,
  DollarSign,
  ShieldCheck,
  Calendar,
  Building2,
  Terminal,
  ArrowRight
} from 'lucide-react';

export const CommandPalette: React.FC = () => {
  const {
    isCommandPaletteOpen,
    setCommandPaletteOpen,
    setActiveTab,
    projects,
    scenes,
    mediaAssets,
    rightsRecords,
    purchaseOrders,
    setSelectedProjectId,
    setDeveloperConsoleOpen
  } = useStudioStore();

  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(!isCommandPaletteOpen);
      }
      if (e.key === 'Escape' && isCommandPaletteOpen) {
        setCommandPaletteOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCommandPaletteOpen, setCommandPaletteOpen]);

  if (!isCommandPaletteOpen) return null;

  const navigateTo = (tab: WorkspaceTab, projectId?: string) => {
    if (projectId) setSelectedProjectId(projectId);
    setActiveTab(tab);
    setCommandPaletteOpen(false);
    setQuery('');
  };

  const filteredProjects = projects.filter((p) =>
    p.title.toLowerCase().includes(query.toLowerCase()) ||
    p.format.toLowerCase().includes(query.toLowerCase())
  );

  const filteredScenes = scenes.filter((s) =>
    s.heading.toLowerCase().includes(query.toLowerCase()) ||
    s.sceneNumber.includes(query)
  );

  const filteredAssets = mediaAssets.filter((a) =>
    a.title.toLowerCase().includes(query.toLowerCase()) ||
    a.assetType.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-start justify-center pt-20 p-4">
      <div
        className="w-full max-w-2xl bg-[#12151A] border border-slate-700 rounded-lg shadow-2xl overflow-hidden flex flex-col text-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Header */}
        <div className="p-3 border-b border-slate-800 flex items-center justify-between bg-slate-900">
          <div className="flex items-center space-x-3 flex-1">
            <Search className="w-5 h-5 text-amber-400" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type to search across projects, scenes, media assets, rights, POs..."
              className="bg-transparent border-none text-sm text-slate-100 placeholder-slate-500 focus:outline-none w-full font-mono"
            />
          </div>
          <button
            onClick={() => setCommandPaletteOpen(false)}
            className="p-1 hover:bg-slate-800 rounded text-slate-400"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 space-y-3 custom-scrollbar text-xs font-mono">
          {/* Quick Actions */}
          {!query && (
            <div>
              <div className="px-2 py-1 text-[10px] uppercase tracking-wider text-slate-500 font-bold">
                Quick Actions
              </div>
              <div className="space-y-1 mt-1">
                <button
                  onClick={() => {
                    setDeveloperConsoleOpen(true);
                    setCommandPaletteOpen(false);
                  }}
                  className="w-full flex items-center justify-between p-2 rounded hover:bg-amber-500/10 hover:text-amber-300 text-slate-300 transition-colors group"
                >
                  <div className="flex items-center space-x-2">
                    <Terminal className="w-4 h-4 text-amber-400" />
                    <span>Open Developer Simulation Console</span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>

                <button
                  onClick={() => navigateTo('command')}
                  className="w-full flex items-center justify-between p-2 rounded hover:bg-slate-800 text-slate-300 transition-colors group"
                >
                  <div className="flex items-center space-x-2">
                    <Film className="w-4 h-4 text-sky-400" />
                    <span>View Studio Command Centre</span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>

                <button
                  onClick={() => navigateTo('rights')}
                  className="w-full flex items-center justify-between p-2 rounded hover:bg-slate-800 text-slate-300 transition-colors group"
                >
                  <div className="flex items-center space-x-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Check Rights Expirations & Legal Warnings</span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              </div>
            </div>
          )}

          {/* Projects Match */}
          {filteredProjects.length > 0 && (
            <div>
              <div className="px-2 py-1 text-[10px] uppercase tracking-wider text-slate-500 font-bold">
                Projects ({filteredProjects.length})
              </div>
              <div className="space-y-1 mt-1">
                {filteredProjects.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => navigateTo('productions', p.id)}
                    className="w-full flex items-center justify-between p-2 rounded hover:bg-slate-800 text-slate-200 transition-colors text-left"
                  >
                    <div className="flex items-center space-x-2">
                      <Film className="w-4 h-4 text-amber-400 shrink-0" />
                      <div>
                        <span className="font-bold text-slate-100">{p.title}</span>
                        <span className="text-slate-400 ml-2">({p.format})</span>
                      </div>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700 text-slate-300">
                      {p.currentStage}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Scenes Match */}
          {filteredScenes.length > 0 && (
            <div>
              <div className="px-2 py-1 text-[10px] uppercase tracking-wider text-slate-500 font-bold">
                Script Breakdown Scenes ({filteredScenes.length})
              </div>
              <div className="space-y-1 mt-1">
                {filteredScenes.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => navigateTo('development', s.projectId)}
                    className="w-full flex items-center justify-between p-2 rounded hover:bg-slate-800 text-slate-200 transition-colors text-left"
                  >
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-sky-400 shrink-0" />
                      <div>
                        <span className="font-bold text-amber-300">Scene #{s.sceneNumber}</span>
                        <span className="text-slate-300 ml-2">{s.heading}</span>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-500">{s.interiorExterior}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Media Match */}
          {filteredAssets.length > 0 && (
            <div>
              <div className="px-2 py-1 text-[10px] uppercase tracking-wider text-slate-500 font-bold">
                Media Assets ({filteredAssets.length})
              </div>
              <div className="space-y-1 mt-1">
                {filteredAssets.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => navigateTo('media', a.projectId)}
                    className="w-full flex items-center justify-between p-2 rounded hover:bg-slate-800 text-slate-200 transition-colors text-left"
                  >
                    <div className="flex items-center space-x-2">
                      <HardDrive className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span className="truncate text-slate-200 font-semibold">{a.title}</span>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 rounded text-slate-400 border border-slate-700">
                      {a.qcStatus}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-2.5 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-500 flex justify-between font-mono">
          <span>Navigate with ↑↓ | Enter to select</span>
          <span>Paramount Studios OS (MOUNTAIN)</span>
        </div>
      </div>
    </div>
  );
};
