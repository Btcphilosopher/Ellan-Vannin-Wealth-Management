import React from 'react';
import { useStudioStore, WorkspaceTab } from '../../state/useStudioStore';
import {
  LayoutDashboard,
  FolderKanban,
  FileText,
  Clapperboard,
  Calendar,
  HardDrive,
  Film,
  Sparkles,
  Globe,
  DollarSign,
  ShieldCheck,
  Megaphone,
  Building2,
  Leaf,
  BarChart3,
  ShieldAlert,
  ChevronRight,
  Terminal,
  Activity
} from 'lucide-react';

interface NavItem {
  id: WorkspaceTab;
  label: string;
  icon: React.ElementType;
  badge?: string;
  badgeType?: 'warning' | 'alert' | 'neutral';
}

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, events, notifications, setDeveloperConsoleOpen } = useStudioStore();

  const warningCount = notifications.filter((n) => !n.read && n.type === 'Warning').length;
  const alertCount = notifications.filter((n) => !n.read && n.type === 'Alert').length;

  const navItems: NavItem[] = [
    { id: 'command', label: '1. Command', icon: LayoutDashboard },
    { id: 'slate', label: '2. Slate', icon: FolderKanban },
    { id: 'development', label: '3. Development', icon: FileText },
    { id: 'productions', label: '4. Productions', icon: Clapperboard },
    { id: 'scheduling', label: '5. Scheduling', icon: Calendar },
    { id: 'media', label: '6. Media Ops', icon: HardDrive, badge: alertCount > 0 ? `${alertCount}` : undefined, badgeType: 'alert' },
    { id: 'post', label: '7. Post-Production', icon: Film },
    { id: 'vfx', label: '8. VFX', icon: Sparkles },
    { id: 'distribution', label: '9. Distribution', icon: Globe },
    { id: 'finance', label: '10. Finance', icon: DollarSign },
    { id: 'rights', label: '11. Rights & Legal', icon: ShieldCheck, badge: warningCount > 0 ? `${warningCount}` : undefined, badgeType: 'warning' },
    { id: 'marketing', label: '12. Marketing', icon: Megaphone },
    { id: 'facilities', label: '13. Facilities', icon: Building2 },
    { id: 'sustainability', label: '14. Sustainability', icon: Leaf },
    { id: 'analytics', label: '15. Analytics', icon: BarChart3 },
    { id: 'administration', label: 'Administration', icon: ShieldAlert }
  ];

  return (
    <aside className="w-64 bg-[#12151A] text-slate-300 border-r border-slate-800 flex flex-col justify-between shrink-0 select-none">
      {/* Studio Header */}
      <div>
        <div className="p-4 border-b border-slate-800/80 bg-[#0E1014] flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded bg-gradient-to-br from-amber-600 via-amber-700 to-amber-900 border border-amber-500/40 flex items-center justify-center font-bold text-white text-xs tracking-wider shadow-sm">
              MOUNTAIN
            </div>
            <div>
              <div className="font-extrabold text-sm tracking-wider text-slate-100 flex items-center gap-1">
                PARAMOUNT
                <span className="text-[10px] uppercase font-semibold px-1 py-0.2 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  OS
                </span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono tracking-wider">
                STUDIO CONTROL v3.6
              </div>
            </div>
          </div>
        </div>

        {/* Primary Navigation List */}
        <nav className="p-2 space-y-0.5 max-h-[calc(100vh-190px)] overflow-y-auto custom-scrollbar">
          <div className="px-3 py-1.5 text-[10px] font-semibold font-mono uppercase tracking-widest text-slate-500">
            Workspaces
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded text-xs font-medium transition-colors ${
                  isActive
                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`px-1.5 py-0.5 text-[10px] font-mono rounded font-bold ${
                      item.badgeType === 'alert'
                        ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                        : item.badgeType === 'warning'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer Controls / Developer Console Trigger */}
      <div className="p-3 border-t border-slate-800 bg-[#0E1014] space-y-2">
        <button
          onClick={() => setDeveloperConsoleOpen(true)}
          className="w-full flex items-center justify-between px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded text-xs text-amber-400 transition-all font-mono"
        >
          <div className="flex items-center space-x-2">
            <Terminal className="w-3.5 h-3.5 text-amber-400" />
            <span>Dev Simulation Console</span>
          </div>
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
          </span>
        </button>

        <div className="flex items-center justify-between px-2 text-[10px] text-slate-500 font-mono">
          <div className="flex items-center space-x-1.5">
            <Activity className="w-3 h-3 text-emerald-400" />
            <span>LOT EVENT BUS: ONLINE</span>
          </div>
          <span>{events.length} EVTS</span>
        </div>
      </div>
    </aside>
  );
};
