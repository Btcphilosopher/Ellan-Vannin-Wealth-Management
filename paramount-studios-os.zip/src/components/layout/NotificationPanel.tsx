import React from 'react';
import { useStudioStore, WorkspaceTab } from '../../state/useStudioStore';
import { Bell, X, Check, Trash2, AlertTriangle, Info, CheckCircle2, AlertCircle } from 'lucide-react';

export const NotificationPanel: React.FC = () => {
  const {
    isNotificationPanelOpen,
    setNotificationPanelOpen,
    notifications,
    markNotificationRead,
    clearAllNotifications,
    setActiveTab,
    setSelectedProjectId
  } = useStudioStore();

  if (!isNotificationPanelOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-80 sm:w-96 bg-[#12151A] border-l border-slate-800 shadow-2xl z-50 flex flex-col text-slate-200">
      {/* Drawer Header */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Bell className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-sm text-slate-100">Notification Centre</span>
          <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 border border-slate-700 text-slate-400 font-mono rounded">
            {notifications.length}
          </span>
        </div>
        <div className="flex items-center space-x-2">
          {notifications.length > 0 && (
            <button
              onClick={() => clearAllNotifications()}
              className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-red-400 text-xs flex items-center gap-1 font-mono"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={() => setNotificationPanelOpen(false)}
            className="p-1 hover:bg-slate-800 rounded text-slate-400"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Notifications List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2.5 custom-scrollbar font-mono text-xs">
        {notifications.length === 0 ? (
          <div className="text-center py-12 text-slate-500">No active alerts or notifications.</div>
        ) : (
          notifications.map((notif) => (
            <div
              key={notif.id}
              onClick={() => {
                if (notif.linkTab) setActiveTab(notif.linkTab as WorkspaceTab);
                if (notif.projectId) setSelectedProjectId(notif.projectId);
                markNotificationRead(notif.id);
              }}
              className={`p-3 rounded-lg border transition-all cursor-pointer relative ${
                !notif.read
                  ? 'bg-slate-900 border-amber-500/40 text-slate-100 shadow-sm'
                  : 'bg-slate-900/40 border-slate-800/80 text-slate-400'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center space-x-2 font-bold text-xs">
                  {notif.type === 'Alert' ? (
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  ) : notif.type === 'Warning' ? (
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  ) : (
                    <Info className="w-4 h-4 text-sky-400 shrink-0" />
                  )}
                  <span>{notif.title}</span>
                </div>
                <span className="text-[10px] text-slate-500 shrink-0">{notif.timestamp}</span>
              </div>

              <p className="mt-1.5 text-[11px] text-slate-300 leading-relaxed font-sans">
                {notif.message}
              </p>

              {!notif.read && (
                <div className="mt-2 flex items-center justify-end text-[10px] text-amber-400 font-bold">
                  <span>Click to view workspace →</span>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Drawer Footer */}
      <div className="p-3 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-500 text-center font-mono">
        Paramount Studio Operations Bus • Real-time alerts
      </div>
    </div>
  );
};
