import React, { useState } from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { Project, ProjectStage } from '../../types';
import {
  FolderKanban,
  List,
  Plus,
  CheckCircle,
  Clock,
  AlertCircle,
  FileText,
  DollarSign,
  ShieldAlert,
  ArrowUpRight,
  Filter,
  Check,
  X
} from 'lucide-react';

export const SlateOverviewView: React.FC = () => {
  const { projects, setSelectedProjectId, setActiveTab, greenlightProject } = useStudioStore();

  const [viewMode, setViewMode] = useState<'board' | 'list'>('board');
  const [filterDivision, setFilterDivision] = useState<string>('All');
  const [selectedGreenlightProject, setSelectedGreenlightProject] = useState<Project | null>(null);
  const [envelopeBudget, setEnvelopeBudget] = useState<number>(25000000);

  const stages: ProjectStage[] = [
    'Idea',
    'Submitted',
    'Under Review',
    'Development',
    'Budgeting',
    'Greenlit',
    'Pre-Production',
    'Production',
    'Post-Production',
    'Delivery',
    'Released'
  ];

  const filteredProjects = projects.filter((p) =>
    filterDivision === 'All' ? true : p.studioDivision === filterDivision
  );

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            STUDIO DEVELOPMENT & COMMISSIONING
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            PARAMOUNT SLATE OVERVIEW & PITCH BOARD
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Cross-stage content tracking from pitch submission to theatrical & streaming delivery.
          </p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          {/* Division Filter */}
          <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={filterDivision}
              onChange={(e) => setFilterDivision(e.target.value)}
              className="bg-transparent text-slate-200 focus:outline-none"
            >
              <option value="All" className="bg-slate-900">All Divisions</option>
              <option value="Paramount Pictures" className="bg-slate-900">Paramount Pictures</option>
              <option value="Paramount Television Studios" className="bg-slate-900">Paramount TV Studios</option>
              <option value="CBS Studios" className="bg-slate-900">CBS Studios</option>
              <option value="Paramount+ Originals" className="bg-slate-900">Paramount+ Originals</option>
              <option value="Nickelodeon Animation" className="bg-slate-900">Nickelodeon Animation</option>
            </select>
          </div>

          {/* View Toggle */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-1">
            <button
              onClick={() => setViewMode('board')}
              className={`px-3 py-1 rounded transition-colors ${
                viewMode === 'board' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FolderKanban className="w-3.5 h-3.5 inline mr-1" />
              Pitch Board
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1 rounded transition-colors ${
                viewMode === 'list' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <List className="w-3.5 h-3.5 inline mr-1" />
              List View
            </button>
          </div>
        </div>
      </div>

      {/* View Mode: Kanban Pitch Board */}
      {viewMode === 'board' ? (
        <div className="flex space-x-4 overflow-x-auto pb-6 custom-scrollbar min-h-[600px]">
          {stages.slice(0, 9).map((stage) => {
            const stageProjects = filteredProjects.filter((p) => p.currentStage === stage);
            return (
              <div
                key={stage}
                className="w-80 bg-[#12151A] border border-slate-800 rounded-xl flex flex-col shrink-0 shadow-lg"
              >
                {/* Column Header */}
                <div className="p-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-mono font-bold text-xs text-slate-200 uppercase tracking-wider">
                      {stage}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-400 font-mono">
                      {stageProjects.length}
                    </span>
                  </div>
                </div>

                {/* Cards Container */}
                <div className="p-2 space-y-2.5 flex-1 overflow-y-auto max-h-[680px] custom-scrollbar">
                  {stageProjects.length === 0 ? (
                    <div className="p-6 text-center text-slate-600 text-xs font-mono">No titles in {stage}</div>
                  ) : (
                    stageProjects.map((proj) => (
                      <div
                        key={proj.id}
                        onClick={() => {
                          setSelectedProjectId(proj.id);
                          setActiveTab('development');
                        }}
                        className="p-3.5 bg-slate-900 border border-slate-800 hover:border-amber-500/50 rounded-lg shadow-sm transition-all cursor-pointer space-y-2 group"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="font-bold text-sm text-slate-100 group-hover:text-amber-300 transition-colors">
                            {proj.title}
                          </h4>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 bg-slate-800 text-slate-400 rounded shrink-0 border border-slate-700">
                            {proj.format.split(' ')[0]}
                          </span>
                        </div>

                        <p className="text-xs text-slate-400 line-clamp-2 font-sans leading-relaxed">
                          {proj.logline}
                        </p>

                        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                          <div>
                            <span className="text-slate-500">Dev: </span>
                            <span className="text-slate-200">${(proj.developmentBudget / 1000000).toFixed(1)}M</span>
                          </div>

                          {/* Greenlight Action Trigger */}
                          {proj.currentStage === 'Development' || proj.currentStage === 'Under Review' ? (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedGreenlightProject(proj);
                              }}
                              className="px-2 py-0.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded font-bold"
                            >
                              Greenlight →
                            </button>
                          ) : (
                            <span className="text-emerald-400 font-bold">${(proj.productionBudget / 1000000).toFixed(0)}M</span>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* View Mode: List View */
        <div className="bg-[#12151A] border border-slate-800 rounded-xl overflow-hidden shadow-lg">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0E1014] text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3">Title & Logline</th>
                <th className="p-3">Format & Genre</th>
                <th className="p-3">Stage</th>
                <th className="p-3">Division</th>
                <th className="p-3">Budget Envelope</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {filteredProjects.map((p) => (
                <tr
                  key={p.id}
                  onClick={() => {
                    setSelectedProjectId(p.id);
                    setActiveTab('development');
                  }}
                  className="hover:bg-slate-800/50 cursor-pointer transition-colors"
                >
                  <td className="p-3 max-w-sm">
                    <div className="font-bold text-slate-100 text-sm">{p.title}</div>
                    <div className="text-[11px] text-slate-400 font-sans truncate">{p.logline}</div>
                  </td>
                  <td className="p-3">{p.format} • {p.genre}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 border border-slate-700 text-amber-300">
                      {p.currentStage}
                    </span>
                  </td>
                  <td className="p-3 text-slate-300">{p.studioDivision}</td>
                  <td className="p-3">
                    <div>Prod: ${(p.productionBudget / 1000000).toFixed(1)}M</div>
                    <div className="text-[10px] text-slate-500">Dev: ${(p.developmentBudget / 1000000).toFixed(1)}M</div>
                  </td>
                  <td className="p-3 text-right">
                    <button className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-bold border border-slate-700">
                      View Detail
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Simulated Greenlight Workflow Modal */}
      {selectedGreenlightProject && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div
            className="w-full max-w-lg bg-[#0E1014] border border-amber-500/50 rounded-xl shadow-2xl overflow-hidden p-5 space-y-4 text-slate-200 font-mono"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm">
                <CheckCircle className="w-5 h-5" />
                <span>EXECUTIVE GREENLIGHT APPROVAL WORKFLOW</span>
              </div>
              <button
                onClick={() => setSelectedGreenlightProject(null)}
                className="p-1 text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-slate-400">Target Project: </span>
                <span className="font-bold text-slate-100 text-sm">{selectedGreenlightProject.title}</span>
              </div>

              <div>
                <label className="block text-slate-400 text-[11px] mb-1">Approved Production Budget Envelope ($ USD):</label>
                <input
                  type="number"
                  value={envelopeBudget}
                  onChange={(e) => setEnvelopeBudget(Number(e.target.value))}
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1 text-[11px]">
                <div className="font-bold text-amber-300">GREENLIGHT PRE-CONDITIONS VERIFIED:</div>
                <div className="text-emerald-400 flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" /> Screenplay locked (Draft v4.2)
                </div>
                <div className="text-emerald-400 flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" /> Stage 14 zero-G rigging availability confirmed
                </div>
                <div className="text-emerald-400 flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" /> Lead cast commitments cleared with legal
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-end space-x-3">
              <button
                onClick={() => setSelectedGreenlightProject(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  greenlightProject(selectedGreenlightProject.id, envelopeBudget);
                  setSelectedGreenlightProject(null);
                }}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs shadow-md"
              >
                Grant Studio Greenlight →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
