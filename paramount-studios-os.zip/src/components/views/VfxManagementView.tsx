import React from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { Sparkles } from 'lucide-react';

export const VfxManagementView: React.FC = () => {
  const { vfxShots, vfxVendors, projects, selectedProjectId, approveVFXShot } = useStudioStore();

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];
  const projectShots = vfxShots.filter((v) => v.projectId === selectedProject.id);

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            VISUAL EFFECTS (VFX) SHOT MANAGEMENT
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            {selectedProject.title} — VFX SHOT GRID & VENDORS
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Vendor Bid Tracking • Shot Version Review • Turnaround Milestone Approval Engine
          </p>
        </div>
      </div>

      {/* VFX Vendor Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
        {vfxVendors.map((vendor) => (
          <div key={vendor.id} className="bg-[#12151A] border border-slate-800 p-4 rounded-xl shadow-lg space-y-2">
            <div className="flex items-center justify-between font-bold">
              <span className="text-amber-400 text-sm">{vendor.vendorName}</span>
              <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 text-slate-300 border border-slate-700 rounded">
                {vendor.allocatedShots} SHOTS
              </span>
            </div>

            <div className="text-slate-300 text-[11px]">
              Bid Total: <span className="font-bold text-slate-100">${(vendor.totalBidAmount / 1000000).toFixed(2)}M</span>
            </div>

            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-2">
              <div
                className="bg-purple-500 h-full"
                style={{ width: `${(vendor.deliveredShots / vendor.allocatedShots) * 100}%` }}
              />
            </div>

            <div className="flex justify-between text-[10px] text-slate-400 pt-1">
              <span>Delivered: {vendor.deliveredShots} / {vendor.allocatedShots}</span>
              <span>QC Score: <strong className="text-emerald-400">{vendor.qualityScore}/10</strong></span>
            </div>
          </div>
        ))}
      </div>

      {/* Shot Grid Table */}
      <div className="bg-[#12151A] border border-slate-800 rounded-xl overflow-hidden shadow-lg font-mono text-xs">
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <span className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            HERO VFX SHOT MATRIX ({projectShots.length} SHOTS)
          </span>
        </div>

        <table className="w-full text-left">
          <thead className="bg-[#0E1014] text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
            <tr>
              <th className="p-3">Shot ID</th>
              <th className="p-3">Sequence</th>
              <th className="p-3">Description & Scope</th>
              <th className="p-3">Complexity</th>
              <th className="p-3">Vendor</th>
              <th className="p-3">Cost Bid</th>
              <th className="p-3">Status</th>
              <th className="p-3 text-right">Approval Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-200">
            {projectShots.map((shot) => (
              <tr key={shot.id} className="hover:bg-slate-800/50">
                <td className="p-3 font-bold text-amber-300">{shot.shotId}</td>
                <td className="p-3 text-slate-400">{shot.sequence}</td>
                <td className="p-3 max-w-xs">{shot.description}</td>
                <td className="p-3">
                  <span className="px-2 py-0.5 bg-slate-800 text-slate-300 border border-slate-700 rounded text-[10px]">
                    {shot.complexity}
                  </span>
                </td>
                <td className="p-3 text-purple-300 font-bold">{shot.vendorName}</td>
                <td className="p-3">${shot.estimatedCost?.toLocaleString()}</td>
                <td className="p-3">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      shot.status === 'Approved' || shot.status === 'Final Delivered'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}
                  >
                    {shot.status}
                  </span>
                </td>
                <td className="p-3 text-right">
                  {shot.status !== 'Approved' && shot.status !== 'Final Delivered' ? (
                    <button
                      onClick={() => approveVFXShot(shot.id)}
                      className="px-3 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded font-bold text-[10px]"
                    >
                      ✓ Approve Shot
                    </button>
                  ) : (
                    <span className="text-emerald-400 font-bold text-[10px]">✓ FINAL LOCKED</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
