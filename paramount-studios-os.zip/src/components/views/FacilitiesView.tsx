import React, { useState } from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { Building2 } from 'lucide-react';

export const FacilitiesView: React.FC = () => {
  const { facilities } = useStudioStore();
  const [selectedFacilityId, setSelectedFacilityId] = useState<string>(facilities[0]?.id || '');

  const selectedFacility = facilities.find((f) => f.id === selectedFacilityId) || facilities[0];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            PARAMOUNT STUDIOS HOLLYWOOD LOT & SOUND STAGE MANAGEMENT
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            PAR-LOT SOUND STAGES & BACKLOT INFRASTRUCTURE
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Interactive Lot Vector Map • Sound Stage Dimensions & Power Grid • Stage Booking Schedule
          </p>
        </div>
      </div>

      {/* Interactive Sound Stage Schematic Map & Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col (2 cols): Interactive Lot Map Grid */}
        <div className="lg:col-span-2 bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-amber-400" />
              PAR-LOT SOUND STAGE SCHEMATIC MAP
            </span>
            <span className="text-emerald-400 font-bold">LOT POWER GRID: ONLINE</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {facilities.map((fac) => {
              const isSelected = fac.id === selectedFacilityId;
              return (
                <div
                  key={fac.id}
                  onClick={() => setSelectedFacilityId(fac.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer space-y-2 relative overflow-hidden ${
                    isSelected
                      ? 'bg-amber-500/15 border-amber-500/60 text-slate-100 shadow-md'
                      : fac.status === 'Occupied'
                      ? 'bg-slate-900 border-slate-800 hover:border-slate-700'
                      : 'bg-emerald-950/20 border-emerald-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span className="text-sm text-slate-100">{fac.name}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                        fac.status === 'Occupied'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      }`}
                    >
                      {fac.status}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-300 font-semibold">{fac.currentProject || fac.building}</div>

                  <div className="flex justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-800/80">
                    <span>{fac.squareFeet.toLocaleString()} sq ft</span>
                    <span>${fac.dailyRate.toLocaleString()}/day</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Selected Stage Specs Panel */}
        {selectedFacility && (
          <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 font-mono text-xs">
            <h3 className="font-bold text-sm text-amber-400 border-b border-slate-800 pb-2">
              {selectedFacility.name} SPECIFICATIONS
            </h3>

            <div className="space-y-3">
              <div className="p-3 bg-slate-900 border border-slate-800 rounded space-y-1">
                <span className="text-slate-500 block text-[10px]">CURRENT ASSIGNED PRODUCTION / BUILDING</span>
                <span className="font-bold text-slate-100 text-sm">{selectedFacility.currentProject || selectedFacility.building}</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-slate-300">
                <div className="p-2.5 bg-slate-900 border border-slate-800 rounded">
                  <span className="text-slate-500 block text-[10px]">FACILITY TYPE</span>
                  <span className="font-bold">{selectedFacility.type}</span>
                </div>
                <div className="p-2.5 bg-slate-900 border border-slate-800 rounded">
                  <span className="text-slate-500 block text-[10px]">SQUARE FEET</span>
                  <span className="font-bold">{selectedFacility.squareFeet.toLocaleString()} SQFT</span>
                </div>
              </div>

              <div className="p-3 bg-slate-900 border border-slate-800 rounded space-y-1">
                <span className="text-slate-500 block text-[10px]">DAILY RATE</span>
                <span className="font-bold text-emerald-400">${selectedFacility.dailyRate.toLocaleString()} / DAY</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
