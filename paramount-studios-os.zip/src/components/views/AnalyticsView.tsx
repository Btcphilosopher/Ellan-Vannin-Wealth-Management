import React from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { Download } from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { projects, departmentBudgets } = useStudioStore();

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            EXECUTIVE ANALYTICS & STUDIO BUSINESS INTELLIGENCE
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            CROSS-DIVISIONAL PERFORMANCE & BUDGET REPORTING
          </h1>
        </div>

        <button className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold font-mono text-xs rounded flex items-center gap-2">
          <Download className="w-4 h-4" />
          <span>Export Executive Board PDF</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <h3 className="font-bold text-slate-100 text-sm border-b border-slate-800 pb-2">
            SLATE BUDGET ALLOCATION BY DIVISION
          </h3>
          <div className="space-y-3">
            {projects.map((p) => (
              <div key={p.id} className="space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span className="font-bold">{p.title} ({p.studioDivision})</span>
                  <span className="text-amber-400">${(p.productionBudget / 1000000).toFixed(1)}M</span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-400 h-full"
                    style={{ width: `${Math.min(100, (p.productionBudget / 150000000) * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <h3 className="font-bold text-slate-100 text-sm border-b border-slate-800 pb-2">
            DEPARTMENT FORECAST VARIANCE ANALYSIS
          </h3>
          <div className="space-y-3">
            {departmentBudgets.map((d, idx) => {
              const variance = d.forecastFinal - d.originalBudget;
              return (
                <div key={idx} className="flex justify-between p-2.5 bg-slate-900 border border-slate-800 rounded">
                  <span className="font-bold text-slate-200">{d.department}</span>
                  <span className={`font-bold ${variance > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {variance >= 0 ? `+$${variance.toLocaleString()}` : `-$${Math.abs(variance).toLocaleString()}`}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
