import React from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import {
  Film,
  AlertTriangle,
  HardDrive,
  DollarSign,
  Globe,
  Activity,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  TrendingUp,
  FileText,
  ShieldAlert,
  Terminal,
  Zap,
  Building2,
  List
} from 'lucide-react';

export const CommandCenterView: React.FC = () => {
  const {
    projects,
    incidents,
    ingestJobs,
    mediaAssets,
    rightsRecords,
    distributionOrders,
    vfxShots,
    departmentBudgets,
    setActiveTab,
    setSelectedProjectId,
    setDeveloperConsoleOpen
  } = useStudioStore();

  const totalActiveProjects = projects.length;
  const inProductionCount = projects.filter((p) => p.currentStage === 'Production').length;
  const highRiskCount = projects.filter((p) => p.riskRating === 'High' || p.riskRating === 'Critical').length;

  const totalCommitted = departmentBudgets.reduce((acc, d) => acc + d.committedCost, 0);
  const totalActual = departmentBudgets.reduce((acc, d) => acc + d.actualCost, 0);
  const totalForecast = departmentBudgets.reduce((acc, d) => acc + d.forecastFinal, 0);
  const totalOriginal = departmentBudgets.reduce((acc, d) => acc + d.originalBudget, 0);
  const totalVariance = totalForecast - totalOriginal;

  const failedIngestJobs = ingestJobs.filter((j) => j.status === 'Failed');
  const expiringRights = rightsRecords.filter((r) => r.status === 'Expiring Soon' || r.status === 'Expired');
  const blockedDeliveries = distributionOrders.filter((d) => !d.qcPassed || d.status === 'Order Received');

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Executive Command Banner */}
      <div className="bg-gradient-to-r from-[#12151A] via-slate-900 to-[#12151A] border border-amber-500/30 rounded-xl p-5 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            <Activity className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>PARAMOUNT STUDIOS — GLOBAL EXECUTIVE OPERATIONAL COMMAND</span>
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            PROJECT PORTFOLIO & STUDIO RISK DASHBOARD
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Real-time cross-functional operational status across Film, Television, Post, Rights & Global Distribution.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setDeveloperConsoleOpen(true)}
            className="px-4 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/50 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition-all shadow-sm"
          >
            <Terminal className="w-4 h-4 text-amber-400" />
            <span>Developer Sim Console</span>
          </button>

          <button
            onClick={() => setActiveTab('slate')}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-mono font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Film className="w-4 h-4 text-slate-400" />
            <span>Full Slate Overview</span>
          </button>
        </div>
      </div>

      {/* High-Level Studio Key Performance Indicators */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        {/* KPI 1: Active Portfolio */}
        <div
          onClick={() => setActiveTab('slate')}
          className="bg-[#12151A] border border-slate-800 hover:border-slate-700 p-4 rounded-xl shadow-lg transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <span>ACTIVE PRODUCTIONS</span>
            <Film className="w-4 h-4 text-amber-400 group-hover:translate-x-0.5 transition-transform" />
          </div>
          <div className="text-3xl font-black text-slate-100 mt-2">{totalActiveProjects}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span className="text-emerald-400 font-bold">{inProductionCount} In Shooting</span> • Stage 14 Active
          </div>
        </div>

        {/* KPI 2: Operational Risk */}
        <div
          onClick={() => setActiveTab('productions')}
          className={`bg-[#12151A] border p-4 rounded-xl shadow-lg transition-all cursor-pointer group ${
            highRiskCount > 0 ? 'border-red-500/40 hover:border-red-400' : 'border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <span>PORTFOLIO AT RISK</span>
            <AlertTriangle className="w-4 h-4 text-red-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-3xl font-black text-red-400 mt-2">{highRiskCount} Projects</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span className="text-amber-400 font-bold">{incidents.filter((i) => i.status === 'Open').length} Open Incidents</span>
          </div>
        </div>

        {/* KPI 3: Finance Variance */}
        <div
          onClick={() => setActiveTab('finance')}
          className="bg-[#12151A] border border-slate-800 hover:border-slate-700 p-4 rounded-xl shadow-lg transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <span>FORECAST VARIANCE</span>
            <DollarSign className="w-4 h-4 text-emerald-400 group-hover:translate-x-0.5 transition-transform" />
          </div>
          <div className={`text-3xl font-black mt-2 ${totalVariance > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {totalVariance >= 0 ? `+$${(totalVariance / 1000000).toFixed(2)}M` : `-$${(Math.abs(totalVariance) / 1000000).toFixed(2)}M`}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Budget: ${(totalOriginal / 1000000).toFixed(1)}M | Forecast: ${(totalForecast / 1000000).toFixed(1)}M
          </div>
        </div>

        {/* KPI 4: Global Distribution Readiness */}
        <div
          onClick={() => setActiveTab('distribution')}
          className="bg-[#12151A] border border-slate-800 hover:border-slate-700 p-4 rounded-xl shadow-lg transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
            <span>DISTRIBUTION READINESS</span>
            <Globe className="w-4 h-4 text-sky-400 group-hover:rotate-12 transition-transform" />
          </div>
          <div className="text-3xl font-black text-slate-100 mt-2">
            {distributionOrders.filter((d) => d.qcPassed).length}/{distributionOrders.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span className="text-amber-400 font-bold">{expiringRights.length} Legal Warnings</span>
          </div>
        </div>
      </div>

      {/* Main Grid Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-sans">
        {/* Left Column (2 cols): Active Production Portfolio & Risk Register */}
        <div className="lg:col-span-2 space-y-6">
          {/* Active Production Portfolio Table */}
          <div className="bg-[#12151A] border border-slate-800 rounded-xl overflow-hidden shadow-lg">
            <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-2 font-bold text-sm text-slate-100">
                <Film className="w-4 h-4 text-amber-400" />
                <span>ACTIVE STUDIO SLATE & STAGE STATUS</span>
              </div>
              <button
                onClick={() => setActiveTab('slate')}
                className="text-xs text-amber-400 hover:underline font-mono flex items-center gap-1"
              >
                View All Slate <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#0E1014] text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="p-3">Title & Format</th>
                    <th className="p-3">Stage</th>
                    <th className="p-3">Division</th>
                    <th className="p-3">Budget / Forecast</th>
                    <th className="p-3">Risk Rating</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-200">
                  {projects.map((p) => (
                    <tr
                      key={p.id}
                      onClick={() => {
                        setSelectedProjectId(p.id);
                        setActiveTab('productions');
                      }}
                      className="hover:bg-slate-800/50 cursor-pointer transition-colors"
                    >
                      <td className="p-3">
                        <div className="font-bold text-slate-100 text-sm">{p.title}</div>
                        <div className="text-[10px] text-slate-400 font-sans">{p.format} • {p.genre}</div>
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 border border-slate-700 text-amber-300">
                          {p.currentStage}
                        </span>
                      </td>
                      <td className="p-3 text-slate-300 text-[11px]">{p.studioDivision}</td>
                      <td className="p-3 font-mono text-[11px]">
                        <div>${(p.productionBudget / 1000000).toFixed(1)}M</div>
                        <div className="text-[10px] text-slate-400">Fcst: ${(p.forecastCost / 1000000).toFixed(1)}M</div>
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                            p.riskRating === 'High'
                              ? 'bg-red-500/20 text-red-400 border-red-500/40'
                              : p.riskRating === 'Medium'
                              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                              : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          }`}
                        >
                          {p.riskRating}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px] font-bold border border-slate-700">
                          Inspect
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Operational Risk & Incident Register */}
          <div className="bg-[#12151A] border border-slate-800 rounded-xl p-4 shadow-lg space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2 font-bold text-sm text-slate-100">
                <ShieldAlert className="w-4 h-4 text-red-400" />
                <span>ACTIVE OPERATIONAL RISK & INCIDENT REGISTER</span>
              </div>
              <span className="text-xs text-slate-400 font-mono">{incidents.length} Records</span>
            </div>

            <div className="space-y-2 font-mono text-xs">
              {incidents.map((inc) => (
                <div
                  key={inc.id}
                  className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex items-start justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span
                        className={`px-1.5 py-0.5 text-[10px] font-bold rounded border ${
                          inc.severity === 'Severe'
                            ? 'bg-red-500/20 text-red-400 border-red-500/40'
                            : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        }`}
                      >
                        {inc.severity}
                      </span>
                      <span className="font-bold text-slate-200">{inc.category}: {inc.affectedDepartment}</span>
                    </div>
                    <p className="text-slate-300 text-[11px] font-sans">{inc.description}</p>
                    <div className="text-[10px] text-slate-500">Action: {inc.actionTaken}</div>
                  </div>

                  <span className="px-2 py-0.5 text-[10px] bg-slate-800 rounded text-slate-400 border border-slate-700">
                    {inc.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (1 col): Media Ops & Rights Warnings */}
        <div className="space-y-6">
          {/* Media & Ingest Pipeline Panel */}
          <div className="bg-[#12151A] border border-slate-800 rounded-xl p-4 shadow-lg space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2 font-bold text-sm text-slate-100">
                <HardDrive className="w-4 h-4 text-sky-400" />
                <span>MEDIA INGEST & QC QUEUE</span>
              </div>
              <button
                onClick={() => setActiveTab('media')}
                className="text-xs text-sky-400 hover:underline font-mono"
              >
                Media Ops →
              </button>
            </div>

            <div className="space-y-2 font-mono text-xs">
              {ingestJobs.map((job) => (
                <div key={job.id} className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200 truncate max-w-[180px]">{job.assetTitle}</span>
                    <span
                      className={`text-[10px] font-bold ${
                        job.status === 'Failed'
                          ? 'text-red-400'
                          : job.status === 'Completed'
                          ? 'text-emerald-400'
                          : 'text-amber-300'
                      }`}
                    >
                      {job.status}
                    </span>
                  </div>

                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all ${
                        job.status === 'Failed' ? 'bg-red-500' : 'bg-amber-400'
                      }`}
                      style={{ width: `${job.progressPercent}%` }}
                    />
                  </div>

                  <div className="flex justify-between text-[10px] text-slate-500">
                    <span>Stage: {job.stage}</span>
                    <span>{job.progressPercent}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Legal Rights Expirations */}
          <div className="bg-[#12151A] border border-slate-800 rounded-xl p-4 shadow-lg space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2 font-bold text-sm text-slate-100">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                <span>RIGHTS EXPIRATION WARNINGS</span>
              </div>
              <button
                onClick={() => setActiveTab('rights')}
                className="text-xs text-amber-400 hover:underline font-mono"
              >
                Rights →
              </button>
            </div>

            <div className="space-y-2 font-mono text-xs">
              {rightsRecords.map((rec) => (
                <div key={rec.id} className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200 truncate">{rec.title}</span>
                    <span
                      className={`px-1.5 py-0.5 text-[10px] font-bold rounded ${
                        rec.status === 'Expiring Soon'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      }`}
                    >
                      {rec.status}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400">Licensor: {rec.licensorName}</div>
                  <div className="text-[10px] text-slate-500">End Date: {rec.endDate}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
