import React from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { Globe, Package } from 'lucide-react';

export const DistributionView: React.FC = () => {
  const {
    distributionOrders,
    localisationItems,
    projects,
    selectedProjectId
  } = useStudioStore();

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            GLOBAL CONTENT SUPPLY CHAIN & LOCALISATION
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            {selectedProject.title} — LOCALISATION & DELIVERY MATRIX
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Territory Master Delivery • Subtitles & Dubbing Pipeline • QC Gatekeeper • AS-11 & IMF Package Builder
          </p>
        </div>
      </div>

      {/* Localisation Territory Matrix */}
      <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <span className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <Globe className="w-4 h-4 text-sky-400" />
            TERRITORY LOCALISATION TRACKER ({localisationItems.length} TERRITORIES)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {localisationItems.map((loc) => (
            <div key={loc.id} className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg space-y-2">
              <div className="flex items-center justify-between font-bold">
                <span className="text-amber-300 text-sm">{loc.territory}</span>
                <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 text-slate-400 rounded">
                  {loc.language}
                </span>
              </div>

              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">Audio:</span>
                  <span className="font-bold text-slate-200">{loc.audioStatus}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Captions:</span>
                  <span className="font-bold text-slate-200">{loc.captionsStatus}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Rights:</span>
                  <span className={loc.rightsStatus === 'Cleared' ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                    {loc.rightsStatus}
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-[10px]">
                <span className="text-slate-400 font-bold">Status: {loc.overallStatus}</span>
                {loc.blockingReason && (
                  <span className="text-amber-400 text-[9px] truncate max-w-[150px]">{loc.blockingReason}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Distribution Orders Table */}
      <div className="bg-[#12151A] border border-slate-800 rounded-xl overflow-hidden shadow-lg font-mono text-xs">
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <span className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <Package className="w-4 h-4 text-emerald-400" />
            GLOBAL FULFILMENT ORDERS & DELIVERY MATRIX
          </span>
        </div>

        <table className="w-full text-left">
          <thead className="bg-[#0E1014] text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
            <tr>
              <th className="p-3">Order Ref</th>
              <th className="p-3">Distributor / Partner</th>
              <th className="p-3">Platform</th>
              <th className="p-3">Territory</th>
              <th className="p-3">Deadline</th>
              <th className="p-3">QC Status</th>
              <th className="p-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-200">
            {distributionOrders.map((ord) => (
              <tr key={ord.id} className="hover:bg-slate-800/50">
                <td className="p-3 font-bold text-amber-300">{ord.orderNumber || ord.id}</td>
                <td className="p-3 font-semibold text-slate-100">{ord.partnerName}</td>
                <td className="p-3 text-sky-300">{ord.platform}</td>
                <td className="p-3">{ord.territory}</td>
                <td className="p-3 text-slate-400">{ord.deadline}</td>
                <td className="p-3">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      ord.qcPassed
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-red-500/20 text-red-400 border border-red-500/40'
                    }`}
                  >
                    {ord.qcPassed ? 'PASSED' : 'FAILED / REJECTED'}
                  </span>
                </td>
                <td className="p-3 font-bold text-slate-200">{ord.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
