import React from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { DEMO_USERS } from '../../data/seedData';
import { ShieldAlert, Users, Activity, Terminal, Key } from 'lucide-react';

export const AdministrationView: React.FC = () => {
  const { events, currentUser, setCurrentUser } = useStudioStore();

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <div className="pb-4 border-b border-slate-800">
        <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
          SYSTEM ADMINISTRATION & AUDIT LOG
        </div>
        <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
          ROLE-BASED ACCESS CONTROL (RBAC) & SYSTEM AUDIT TRAIL
        </h1>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          Active User Profile Switcher • Immutable Event Bus Ledger • Security Clearance Audit
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
        {/* Left Col: Role Switcher */}
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center gap-2">
            <Users className="w-4 h-4 text-amber-400" />
            REGISTERED STUDIO PROFILES ({DEMO_USERS.length})
          </h3>

          <div className="space-y-2">
            {DEMO_USERS.map((usr) => {
              const isSelected = currentUser.id === usr.id;
              return (
                <div
                  key={usr.id}
                  onClick={() => setCurrentUser(usr)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-amber-500/15 border-amber-500/60 text-slate-100 shadow-md'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="font-bold text-slate-100">{usr.name}</div>
                  <div className="text-[10px] text-amber-400">{usr.role} — {usr.division}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col (2 cols): System Audit Ledger */}
        <div className="lg:col-span-2 bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
          <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2 flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            IMMUTABLE EVENT BUS AUDIT LEDGER ({events.length} RECORDED EVENTS)
          </h3>

          <div className="space-y-2 max-h-[600px] overflow-y-auto custom-scrollbar">
            {events.map((evt) => (
              <div key={evt.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg space-y-1">
                <div className="flex items-center justify-between font-bold">
                  <span className="text-amber-400">[{evt.type}] {evt.affectedEntity}</span>
                  <span className="text-[10px] text-slate-500">{new Date(evt.timestamp).toLocaleTimeString()}</span>
                </div>
                <p className="text-slate-300 font-sans text-xs">{evt.description}</p>
                <div className="text-[10px] text-slate-500">Triggered By: {evt.triggeredBy}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
