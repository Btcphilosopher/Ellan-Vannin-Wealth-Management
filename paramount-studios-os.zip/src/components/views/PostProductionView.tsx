import React, { useState } from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { PostComment } from '../../types';
import {
  Film,
  Play,
  Pause,
  MessageSquare,
  Clock,
  CheckCircle2,
  Send,
  Sparkles,
  Volume2,
  Maximize2
} from 'lucide-react';

export const PostProductionView: React.FC = () => {
  const {
    projects,
    selectedProjectId,
    postCuts,
    postComments,
    addPostComment,
    resolvePostComment
  } = useStudioStore();

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];
  const activeCut = postCuts.find((c) => c.projectId === selectedProject.id) || postCuts[0];

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentFrame, setCurrentFrame] = useState(1342);
  const [newCommentText, setNewCommentText] = useState('');
  const [newDepartment, setNewDepartment] = useState<'Director' | 'Editorial' | 'Color' | 'Sound' | 'VFX'>('Director');

  const fps = 24;
  const frameToTC = (frame: number) => {
    const hrs = Math.floor(frame / (24 * 3600)).toString().padStart(2, '0');
    const mins = Math.floor((frame % (24 * 3600)) / (24 * 60)).toString().padStart(2, '0');
    const secs = Math.floor((frame % (24 * 60)) / 24).toString().padStart(2, '0');
    const fr = Math.floor(frame % 24).toString().padStart(2, '0');
    return `01:${mins}:${secs}:${fr}`;
  };

  const currentTimecode = frameToTC(currentFrame);

  const handlePostComment = () => {
    if (!newCommentText.trim() || !activeCut) return;
    const newComment: PostComment = {
      id: `pcmt_${Date.now()}`,
      cutId: activeCut.id,
      authorName: 'EXECUTIVE PRODUCER',
      department: newDepartment,
      timecode: currentTimecode,
      frameNumber: currentFrame,
      text: newCommentText.trim(),
      resolved: false,
      timestamp: new Date().toLocaleTimeString()
    };
    addPostComment(newComment);
    setNewCommentText('');
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            EDITORIAL & POST-PRODUCTION REVIEW
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            {selectedProject.title} — {activeCut?.cutName || 'DIRECTOR CUT'}
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Frame-Accurate Timecode Review • Color & Sound Notes • Editorial Approval Engine
          </p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <span className="px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded font-bold">
            {activeCut?.versionTag}
          </span>
        </div>
      </div>

      {/* Timecode Video Review Player & Comments Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col (2 cols): Video Canvas & Transport Controls */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#0A0C0E] border border-slate-800 rounded-xl overflow-hidden shadow-2xl relative">
            {/* Simulated Video Frame Viewport */}
            <div className="w-full aspect-video bg-gradient-to-br from-slate-950 via-slate-900 to-black flex items-center justify-center relative overflow-hidden">
              {/* Simulated Scene Graphic Overlay */}
              <div className="text-center space-y-3 z-10 p-6">
                <div className="w-20 h-20 mx-auto rounded-full border-2 border-amber-500/40 flex items-center justify-center bg-amber-500/10 text-amber-400 font-mono font-bold text-lg animate-pulse">
                  4.5K
                </div>
                <div className="font-mono text-xs text-slate-400 tracking-widest uppercase">
                  SCENE 104 / TAKE 3 • ARRI RAW PROXIES
                </div>
                <div className="text-2xl font-black text-slate-100 font-mono bg-black/60 px-4 py-1.5 rounded border border-slate-800 inline-block">
                  {currentTimecode}
                </div>
              </div>

              {/* Watermark Overlay */}
              <div className="absolute top-4 left-4 font-mono text-[10px] text-slate-600 uppercase tracking-widest pointer-events-none">
                PARAMOUNT OS • CONFIDENTIAL EDITORIAL WATERMARK
              </div>
            </div>

            {/* Scrub Bar & Controls */}
            <div className="p-4 bg-slate-900 border-t border-slate-800 space-y-3 font-mono text-xs">
              {/* Scrub Bar Slider */}
              <input
                type="range"
                min={1000}
                max={5000}
                value={currentFrame}
                onChange={(e) => setCurrentFrame(Number(e.target.value))}
                className="w-full accent-amber-400 bg-slate-800 h-2 rounded cursor-pointer"
              />

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="p-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded font-bold shadow"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>

                  <div className="font-mono text-sm font-bold text-amber-300">
                    {currentTimecode}
                  </div>
                  <span className="text-slate-500 text-[10px]">Frame #{currentFrame}</span>
                </div>

                <div className="flex items-center space-x-2 text-slate-400">
                  <Volume2 className="w-4 h-4" />
                  <span>24.00 fps</span>
                </div>
              </div>
            </div>
          </div>

          {/* Comment Creation Box */}
          <div className="bg-[#12151A] border border-slate-800 rounded-xl p-4 shadow-lg space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-amber-400">ADD TIMECODE COMMENT AT {currentTimecode}</span>
              <select
                value={newDepartment}
                onChange={(e) => setNewDepartment(e.target.value as any)}
                className="bg-slate-900 border border-slate-700 text-slate-200 rounded px-2 py-1"
              >
                <option value="Director">Director Note</option>
                <option value="Editorial">Editorial</option>
                <option value="Color">Color Grading</option>
                <option value="Sound">Sound Mix</option>
                <option value="VFX">VFX</option>
              </select>
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                placeholder="Enter feedback or edit note..."
                className="p-2 bg-slate-900 border border-slate-700 rounded text-slate-100 w-full focus:outline-none focus:border-amber-400"
              />
              <button
                onClick={handlePostComment}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center gap-1 shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Post Note</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Col: Timecode Comment Stream */}
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-4 shadow-lg space-y-3 font-mono text-xs flex flex-col">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-amber-400" />
              EDITORIAL NOTES ({postComments.length})
            </span>
            <span className="text-slate-400 text-[10px]">TIMECODE SORT</span>
          </div>

          <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[580px] custom-scrollbar">
            {postComments.map((cmt) => (
              <div
                key={cmt.id}
                className={`p-3 rounded-lg border space-y-1.5 transition-all ${
                  cmt.resolved
                    ? 'bg-slate-900/40 border-slate-800 opacity-60'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => setCurrentFrame(cmt.frameNumber)}
                    className="font-bold text-amber-300 hover:underline"
                  >
                    TC: {cmt.timecode}
                  </button>
                  <span className="px-1.5 py-0.5 text-[10px] bg-slate-800 text-slate-400 rounded border border-slate-700">
                    {cmt.department}
                  </span>
                </div>

                <p className="text-slate-200 text-xs font-sans leading-relaxed">{cmt.text}</p>

                <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
                  <span>By: {cmt.authorName}</span>
                  {!cmt.resolved && (
                    <button
                      onClick={() => resolvePostComment(cmt.id)}
                      className="text-emerald-400 hover:underline font-bold"
                    >
                      ✓ Mark Resolved
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
