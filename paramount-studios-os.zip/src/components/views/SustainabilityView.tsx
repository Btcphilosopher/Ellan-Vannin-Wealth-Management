import React from 'react';
import { Leaf, Zap, Trash2, Fuel, Award } from 'lucide-react';

export const SustainabilityView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      <div className="pb-4 border-b border-slate-800">
        <div className="text-xs font-mono uppercase text-emerald-400 font-bold tracking-wider">
          PARAMOUNT SUSTAINABILITY & GREEN PRODUCTION INITIATIVE
        </div>
        <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
          ENVIRONMENTAL IMPACT & CARBON FOOTPRINT DASHBOARD
        </h1>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          Stage Grid Solar Offset • Battery Power Units • Waste Diversion • Albert Certification Tracker
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-[#12151A] border border-slate-800 p-4 rounded-xl shadow-lg">
          <div className="text-slate-400 font-bold">SOLAR POWER OFFSET</div>
          <div className="text-3xl font-black text-emerald-400 mt-2">48.2%</div>
          <div className="text-[11px] text-slate-500 mt-1">Stage Roof Solar Arrays</div>
        </div>

        <div className="bg-[#12151A] border border-slate-800 p-4 rounded-xl shadow-lg">
          <div className="text-slate-400 font-bold">DIESEL GENERATOR DIVERSION</div>
          <div className="text-3xl font-black text-sky-400 mt-2">78.5%</div>
          <div className="text-[11px] text-slate-500 mt-1">Mobile Battery BESS Units</div>
        </div>

        <div className="bg-[#12151A] border border-slate-800 p-4 rounded-xl shadow-lg">
          <div className="text-slate-400 font-bold">SET RECYCLING & REUSE</div>
          <div className="text-3xl font-black text-amber-300 mt-2">89.1%</div>
          <div className="text-[11px] text-slate-500 mt-1">Timber & Prop Donation</div>
        </div>

        <div className="bg-[#12151A] border border-slate-800 p-4 rounded-xl shadow-lg">
          <div className="text-slate-400 font-bold">ALBERT GREEN CERTIFICATION</div>
          <div className="text-3xl font-black text-emerald-300 mt-2">3 STARS</div>
          <div className="text-[11px] text-slate-500 mt-1">Audit Passed Sep 2026</div>
        </div>
      </div>
    </div>
  );
};
