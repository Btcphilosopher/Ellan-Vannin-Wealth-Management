import React, { useState } from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import {
  Clapperboard,
  Users,
  Film,
  MapPin,
  AlertTriangle,
  HardDrive,
  Shield,
  Phone,
  Radio,
  Clock,
  CheckCircle2,
  Calendar,
  Layers,
  FileText
} from 'lucide-react';

export const ProductionWorkspaceView: React.FC = () => {
  const {
    projects,
    selectedProjectId,
    cast,
    crew,
    incidents,
    callSheets,
    dailyReports,
    shootingDays,
    setActiveTab
  } = useStudioStore();

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];
  const [activeSubTab, setActiveSubTab] = useState<'dashboard' | 'cast' | 'crew' | 'bible' | 'incidents'>('dashboard');

  const activeCallSheet = callSheets[0];
  const activeDailyReport = dailyReports[0];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            PHYSICAL PRODUCTION WORKSPACE
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            {selectedProject.title} — PRODUCTION DASHBOARD
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Stage {selectedProject.currentStage} • Production Bible • Call Sheets • Cast & Crew Roster • Safety Log
          </p>
        </div>

        {/* Sub-tab Switcher */}
        <div className="flex items-center space-x-1 bg-slate-900 border border-slate-800 rounded-lg p-1 font-mono text-xs">
          <button
            onClick={() => setActiveSubTab('dashboard')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeSubTab === 'dashboard' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveSubTab('cast')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeSubTab === 'cast' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Cast ({cast.length})
          </button>
          <button
            onClick={() => setActiveSubTab('crew')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeSubTab === 'crew' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Crew ({crew.length})
          </button>
          <button
            onClick={() => setActiveSubTab('bible')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeSubTab === 'bible' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Production Bible
          </button>
          <button
            onClick={() => setActiveSubTab('incidents')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeSubTab === 'incidents' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Safety & Incidents ({incidents.length})
          </button>
        </div>
      </div>

      {/* Main SubTab Content */}
      {activeSubTab === 'dashboard' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Active Shooting Day Status Box */}
          <div className="lg:col-span-2 bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2 font-mono font-bold text-sm text-slate-100">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>TODAY’S SHOOTING STATUS — DAY 38 / 62</span>
              </div>
              <button
                onClick={() => setActiveTab('scheduling')}
                className="text-xs font-mono text-amber-400 hover:underline"
              >
                Call Sheet Builder →
              </button>
            </div>

            {activeCallSheet && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                  <span className="text-[10px] text-slate-500 block">CREW CALL TIME</span>
                  <span className="text-base font-bold text-slate-100">{activeCallSheet.crewCallTime}</span>
                  <span className="text-[10px] text-slate-400 block mt-1">{activeCallSheet.unit}</span>
                </div>

                <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                  <span className="text-[10px] text-slate-500 block">MAIN LOCATION</span>
                  <span className="text-sm font-bold text-amber-300">{activeCallSheet.mainLocation}</span>
                  <span className="text-[10px] text-slate-400 block mt-1">Stage 14 Zero-G Rig</span>
                </div>

                <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                  <span className="text-[10px] text-slate-500 block">WEATHER / ATMOSPHERE</span>
                  <span className="text-sm font-bold text-slate-200">{activeCallSheet.weatherSummary}</span>
                  <span className="text-[10px] text-slate-400 block mt-1">High: {activeCallSheet.highTemp}°F</span>
                </div>
              </div>
            )}

            {/* Daily Production Report Summary */}
            {activeDailyReport && (
              <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-lg space-y-2 font-mono text-xs">
                <div className="flex items-center justify-between font-bold text-amber-400 border-b border-slate-800/80 pb-2">
                  <span>LAST COMPLETED DPR SUMMARY (DAY #{activeDailyReport.dayNumber})</span>
                  <span>{activeDailyReport.date}</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-slate-300">
                  <div>Pages Shot: <span className="font-bold text-slate-100">{activeDailyReport.pagesShot} pgs</span></div>
                  <div>Scenes Completed: <span className="font-bold text-emerald-400">{activeDailyReport.scenesCompleted.join(', ')}</span></div>
                  <div>Media Captured: <span className="font-bold text-sky-400">{(activeDailyReport.mediaCapturedGb / 1000).toFixed(1)} TB</span></div>
                  <div>Overtime: <span className="font-bold text-amber-300">{activeDailyReport.overtimeMinutes} mins</span></div>
                </div>
                <p className="text-[11px] text-slate-400 font-sans italic pt-1">{activeDailyReport.notes}</p>
              </div>
            )}
          </div>

          {/* Department Readiness Cards */}
          <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 font-mono text-xs">
            <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2">
              DEPARTMENT READINESS
            </h3>

            <div className="space-y-2.5">
              <div className="p-2.5 bg-slate-900 border border-slate-800 rounded flex items-center justify-between">
                <span>Camera & Optics</span>
                <span className="text-emerald-400 font-bold">READY (4.5K ARRI)</span>
              </div>
              <div className="p-2.5 bg-slate-900 border border-slate-800 rounded flex items-center justify-between">
                <span>Stunts & Zero-G Rigging</span>
                <span className="text-amber-300 font-bold">CALIBRATING</span>
              </div>
              <div className="p-2.5 bg-slate-900 border border-slate-800 rounded flex items-center justify-between">
                <span>Stage 14 Floor Operations</span>
                <span className="text-emerald-400 font-bold">CLEAR</span>
              </div>
              <div className="p-2.5 bg-slate-900 border border-slate-800 rounded flex items-center justify-between">
                <span>Medical & Safety Officer</span>
                <span className="text-emerald-400 font-bold">ON SET</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SubTab: Cast Roster */}
      {activeSubTab === 'cast' && (
        <div className="bg-[#12151A] border border-slate-800 rounded-xl overflow-hidden shadow-lg font-mono text-xs">
          <table className="w-full text-left">
            <thead className="bg-[#0E1014] text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3">Character</th>
                <th className="p-3">Actor / Talent</th>
                <th className="p-3">Role Type</th>
                <th className="p-3">Agency / Counsel</th>
                <th className="p-3">Daily Rate</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {cast.map((c) => (
                <tr key={c.id} className="hover:bg-slate-800/50">
                  <td className="p-3 font-bold text-amber-300">{c.characterName}</td>
                  <td className="p-3 font-semibold text-slate-100">{c.actorName}</td>
                  <td className="p-3">{c.roleType}</td>
                  <td className="p-3 text-slate-400">{c.agencyContact}</td>
                  <td className="p-3">${c.dailyRate.toLocaleString()}/day</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded text-[10px] font-bold">
                      {c.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* SubTab: Crew Roster */}
      {activeSubTab === 'crew' && (
        <div className="bg-[#12151A] border border-slate-800 rounded-xl overflow-hidden shadow-lg font-mono text-xs">
          <table className="w-full text-left">
            <thead className="bg-[#0E1014] text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3">Name</th>
                <th className="p-3">Department</th>
                <th className="p-3">Title</th>
                <th className="p-3">Phone</th>
                <th className="p-3">Radio Channel</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {crew.map((cr) => (
                <tr key={cr.id} className="hover:bg-slate-800/50">
                  <td className="p-3 font-bold text-slate-100">{cr.name}</td>
                  <td className="p-3 text-amber-400">{cr.department}</td>
                  <td className="p-3">{cr.title}</td>
                  <td className="p-3 text-slate-400">{cr.phone}</td>
                  <td className="p-3 text-sky-400 font-bold">{cr.radioChannel}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* SubTab: Production Bible */}
      {activeSubTab === 'bible' && (
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-6 shadow-lg space-y-4 font-sans text-slate-200">
          <h3 className="font-mono font-bold text-lg text-amber-400 border-b border-slate-800 pb-2">
            PRODUCTION BIBLE & VISUAL SPECS — {selectedProject.title}
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            {selectedProject.synopsis}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs pt-2">
            <div className="p-3 bg-slate-900 border border-slate-800 rounded">
              <span className="text-slate-400 block text-[10px]">CREATOR / SHOWRUNNER</span>
              <span className="font-bold text-slate-100">{selectedProject.creator}</span>
            </div>
            <div className="p-3 bg-slate-900 border border-slate-800 rounded">
              <span className="text-slate-400 block text-[10px]">PRODUCING ENTITY</span>
              <span className="font-bold text-slate-100">{selectedProject.productionCompany}</span>
            </div>
          </div>
        </div>
      )}

      {/* SubTab: Incidents & Safety */}
      {activeSubTab === 'incidents' && (
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-3 font-mono text-xs">
          <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2">
            INCIDENT REPORTS & SAFETY AUDIT
          </h3>
          {incidents.map((inc) => (
            <div key={inc.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg space-y-1">
              <div className="flex items-center justify-between font-bold">
                <span className="text-red-400">[{inc.severity}] {inc.category}</span>
                <span className="text-[10px] text-slate-500">{inc.date}</span>
              </div>
              <p className="text-slate-300 text-xs font-sans">{inc.description}</p>
              <div className="text-[10px] text-emerald-400">Resolution: {inc.actionTaken}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
