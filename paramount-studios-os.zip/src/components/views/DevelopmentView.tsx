import React, { useState } from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { Scene, BreakdownItem } from '../../types';
import {
  FileText,
  Plus,
  Tag,
  User,
  Box,
  Shirt,
  Car,
  Sparkles,
  Flame,
  Volume2,
  Calendar,
  Layers,
  Edit2
} from 'lucide-react';

export const DevelopmentView: React.FC = () => {
  const { scenes, projects, selectedProjectId, addScene, updateScene } = useStudioStore();

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];
  const projectScenes = scenes.filter((s) => s.projectId === selectedProject.id);

  const [activeSceneId, setActiveSceneId] = useState<string>(projectScenes[0]?.id || scenes[0]?.id || '');
  const activeScene = scenes.find((s) => s.id === activeSceneId) || projectScenes[0] || scenes[0];

  const [newCharName, setNewCharName] = useState('');
  const [newPropName, setNewPropName] = useState('');

  const handleAddCharacter = () => {
    if (!newCharName.trim() || !activeScene) return;
    const updatedChars = [...activeScene.characters, newCharName.trim()];
    updateScene(activeScene.id, { characters: updatedChars });
    setNewCharName('');
  };

  const handleAddProp = () => {
    if (!newPropName.trim() || !activeScene) return;
    const newItem: BreakdownItem = {
      id: `b_${Date.now()}`,
      category: 'PROP',
      name: newPropName.trim(),
      departmentNote: 'Added via script breakdown'
    };
    updateScene(activeScene.id, { breakdownItems: [...activeScene.breakdownItems, newItem] });
    setNewPropName('');
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            SCREENPLAY & SCRIPT BREAKDOWN TOOL
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            {selectedProject.title} — SCRIPT BREAKDOWN
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Scene breakdown categorization across Characters, Props, Wardrobe, VFX, Stunts & Sound.
          </p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <button
            onClick={() => {
              const num = `${projectScenes.length + 101}`;
              const newSc: Scene = {
                id: `scn_${Date.now()}`,
                projectId: selectedProject.id,
                sceneNumber: num,
                heading: `INT. PROMETHEUS LAB - DAY`,
                locationName: 'Stage 14 Set C',
                timeOfDay: 'DAY',
                interiorExterior: 'INT',
                pageCount: 1.2,
                estimatedMinutes: 2.0,
                characters: ['HELEN VANCE'],
                breakdownItems: [],
                notes: ['Added in breakdown editor'],
                revisionId: 'rev_white_20260921',
                complexityScore: 4,
                scriptSnippet: 'HELEN examines the oxygen pressure valve.'
              };
              addScene(newSc);
              setActiveSceneId(newSc.id);
            }}
            className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center gap-1.5 shadow"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Scene</span>
          </button>
        </div>
      </div>

      {/* Main Split Layout: Scene List Column & Script Breakdown Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Col: Scene Selector List */}
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-4 shadow-lg space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-slate-200 uppercase tracking-wider">SCENE INDEX</span>
            <span className="text-[10px] text-slate-500">{projectScenes.length} SCENES</span>
          </div>

          <div className="space-y-2 max-h-[650px] overflow-y-auto custom-scrollbar">
            {projectScenes.map((sc) => {
              const isSelected = activeScene?.id === sc.id;
              return (
                <div
                  key={sc.id}
                  onClick={() => setActiveSceneId(sc.id)}
                  className={`p-3 rounded-lg border transition-all cursor-pointer space-y-1 ${
                    isSelected
                      ? 'bg-amber-500/15 border-amber-500/60 text-slate-100 shadow-md'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span className="text-amber-300">SCENE #{sc.sceneNumber}</span>
                    <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 rounded text-slate-400 border border-slate-700">
                      {sc.interiorExterior} • {sc.timeOfDay}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-slate-200 truncate">{sc.heading}</div>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                    <span>{sc.pageCount} pgs • ~{sc.estimatedMinutes} mins</span>
                    <span className="text-amber-400 font-bold">Complexity: {sc.complexityScore}/10</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col (2 cols): Script Breakdown & Screenplay Text */}
        <div className="lg:col-span-2 space-y-6">
          {activeScene ? (
            <>
              {/* Screenplay Formatting Display */}
              <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <div className="text-[10px] font-mono text-amber-400 font-bold uppercase">
                      SCENE #{activeScene.sceneNumber} DETAILS
                    </div>
                    <h3 className="font-mono font-bold text-lg text-slate-100 mt-0.5">
                      {activeScene.heading}
                    </h3>
                  </div>
                  <div className="text-right font-mono text-xs text-slate-400">
                    <div>Loc: <span className="text-slate-200 font-bold">{activeScene.locationName}</span></div>
                    <div>Revision: <span className="text-amber-300">{activeScene.revisionId}</span></div>
                  </div>
                </div>

                {/* Screenplay Text Snippet Box */}
                <div className="p-4 bg-[#0A0C0E] border border-slate-800 rounded-lg font-mono text-xs text-amber-100/90 leading-relaxed whitespace-pre-wrap border-l-4 border-l-amber-500 shadow-inner">
                  {activeScene.scriptSnippet || 'No script snippet entered for this scene.'}
                </div>
              </div>

              {/* Department Breakdown Categories */}
              <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-5">
                <h3 className="font-mono font-bold text-sm text-slate-100 border-b border-slate-800 pb-2">
                  DEPARTMENT BREAKDOWN ITEMS
                </h3>

                {/* Characters Category */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between font-mono text-xs font-bold text-amber-400">
                    <div className="flex items-center space-x-1.5">
                      <User className="w-4 h-4" />
                      <span>CHARACTERS IN SCENE ({activeScene.characters.length})</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {activeScene.characters.map((char, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-1 bg-amber-500/15 border border-amber-500/40 text-amber-300 font-mono text-xs rounded font-bold"
                      >
                        {char}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center space-x-2 pt-1">
                    <input
                      type="text"
                      value={newCharName}
                      onChange={(e) => setNewCharName(e.target.value)}
                      placeholder="Add character..."
                      className="p-1.5 bg-slate-900 border border-slate-800 rounded text-xs font-mono text-slate-200 focus:outline-none focus:border-amber-400"
                    />
                    <button
                      onClick={handleAddCharacter}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-mono text-xs"
                    >
                      + Add
                    </button>
                  </div>
                </div>

                {/* Props & Equipment Category */}
                <div className="space-y-2 border-t border-slate-800/80 pt-4">
                  <div className="flex items-center space-x-1.5 font-mono text-xs font-bold text-sky-400">
                    <Box className="w-4 h-4" />
                    <span>PROPS, EQUIPMENT & SPECIAL REQUIREMENTS</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 font-mono text-xs">
                    {activeScene.breakdownItems.map((item) => (
                      <div
                        key={item.id}
                        className="p-2.5 bg-slate-900 border border-slate-800 rounded flex items-center justify-between"
                      >
                        <div>
                          <span className="font-bold text-slate-200">{item.name}</span>
                          <span className="text-[10px] block text-slate-400">{item.departmentNote}</span>
                        </div>
                        <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 text-sky-300 border border-slate-700 rounded uppercase">
                          {item.category}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center space-x-2 pt-1">
                    <input
                      type="text"
                      value={newPropName}
                      onChange={(e) => setNewPropName(e.target.value)}
                      placeholder="Add prop or equipment requirement..."
                      className="p-1.5 bg-slate-900 border border-slate-800 rounded text-xs font-mono text-slate-200 focus:outline-none focus:border-sky-400 w-full"
                    />
                    <button
                      onClick={handleAddProp}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-mono text-xs shrink-0"
                    >
                      + Add Item
                    </button>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="p-12 text-center text-slate-500 font-mono">Select a scene to inspect breakdown details.</div>
          )}
        </div>
      </div>
    </div>
  );
};
