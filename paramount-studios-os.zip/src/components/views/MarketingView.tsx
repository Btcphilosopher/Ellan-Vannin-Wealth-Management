import React from 'react';
import { useStudioStore } from '../../state/useStudioStore';

export const MarketingView: React.FC = () => {
  const { marketingCampaigns, projects, selectedProjectId } = useStudioStore();

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            GLOBAL MARKETING & CAMPAIGN OPERATIONS
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            {selectedProject.title} — MARKETING CAMPAIGN & KEY ART
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Teaser & Main Trailer Releases • Key Art Approval • P&A Budget Tracking • Impression Analytics
          </p>
        </div>
      </div>

      {/* Campaign Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
        {marketingCampaigns.map((camp) => (
          <div key={camp.id} className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-amber-400 font-bold text-sm block">{camp.campaignName}</span>
                <span className="text-slate-400 text-[10px]">Lead Exec: {camp.leadExec}</span>
              </div>
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded text-[10px] font-bold">
                {camp.status}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-slate-300">
              <div className="p-2.5 bg-slate-900 border border-slate-800 rounded">
                <span className="text-slate-500 block text-[10px]">TARGET LAUNCH DATE</span>
                <span className="font-bold text-slate-100">{camp.targetLaunchDate}</span>
              </div>
              <div className="p-2.5 bg-slate-900 border border-slate-800 rounded">
                <span className="text-slate-500 block text-[10px]">TERRITORY</span>
                <span className="font-bold text-sky-400">{camp.territory}</span>
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-slate-400 font-bold block text-[11px]">KEY CAMPAIGN DELIVERABLES</span>
              <div className="space-y-1.5">
                <div className="p-2 bg-slate-900 border border-slate-800 rounded flex items-center justify-between">
                  <span className="text-slate-200">Trailers (Approved / Total)</span>
                  <span className="font-bold text-emerald-400">{camp.trailersApproved} / {camp.trailersTotal}</span>
                </div>
                <div className="p-2 bg-slate-900 border border-slate-800 rounded flex items-center justify-between">
                  <span className="text-slate-200">Key Art Posters Approved</span>
                  <span className="font-bold text-emerald-400">{camp.postersApproved}</span>
                </div>
                <div className="p-2 bg-slate-900 border border-slate-800 rounded flex items-center justify-between">
                  <span className="text-slate-200">Social Media Assets Ready</span>
                  <span className="font-bold text-sky-400">{camp.socialAssetsReady}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
