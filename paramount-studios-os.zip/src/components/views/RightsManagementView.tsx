import React from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { ShieldCheck, ShieldAlert } from 'lucide-react';

export const RightsManagementView: React.FC = () => {
  const { rightsRecords, triggerRightsExpiry } = useStudioStore();

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            RIGHTS MANAGEMENT & LEGAL CLEARANCE
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            GLOBAL INTELLECTUAL PROPERTY & CLEARANCE MATRIX
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Literary Rights • Music Sync Licences • Talent Holdbacks • Territory Window Expirations
          </p>
        </div>

        <button
          onClick={() => triggerRightsExpiry('rgt_m101')}
          className="px-3.5 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded font-mono text-xs font-bold flex items-center gap-1.5"
        >
          <ShieldAlert className="w-4 h-4 text-amber-400" />
          <span>Simulate Music Expiry Event</span>
        </button>
      </div>

      {/* Rights Grid */}
      <div className="bg-[#12151A] border border-slate-800 rounded-xl overflow-hidden shadow-lg font-mono text-xs">
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <span className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            CLEARANCE RECORDS ({rightsRecords.length} LICENCES)
          </span>
        </div>

        <table className="w-full text-left">
          <thead className="bg-[#0E1014] text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
            <tr>
              <th className="p-3">Licence Ref</th>
              <th className="p-3">Title / Subject</th>
              <th className="p-3">Type</th>
              <th className="p-3">Licensor</th>
              <th className="p-3">Territories</th>
              <th className="p-3">End Date</th>
              <th className="p-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-200">
            {rightsRecords.map((r) => (
              <tr key={r.id} className="hover:bg-slate-800/50">
                <td className="p-3 font-bold text-amber-300">{r.id}</td>
                <td className="p-3 font-semibold text-slate-100">{r.title}</td>
                <td className="p-3 text-sky-300">{r.rightsType}</td>
                <td className="p-3">{r.licensorName}</td>
                <td className="p-3 text-slate-400">{r.territories?.join(', ')}</td>
                <td className="p-3 font-bold">{r.endDate}</td>
                <td className="p-3">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      r.status === 'Approved'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : r.status === 'Expiring Soon'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-red-500/20 text-red-400 border border-red-500/40'
                    }`}
                  >
                    {r.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
