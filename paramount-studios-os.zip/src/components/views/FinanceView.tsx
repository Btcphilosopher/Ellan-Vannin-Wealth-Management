import React, { useState } from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { DollarSign } from 'lucide-react';

export const FinanceView: React.FC = () => {
  const {
    departmentBudgets,
    purchaseOrders,
    projects,
    selectedProjectId,
    approvePurchaseOrder,
    createPurchaseOrder
  } = useStudioStore();

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  const totalOriginal = departmentBudgets.reduce((acc, b) => acc + b.originalBudget, 0);
  const totalCommitted = departmentBudgets.reduce((acc, b) => acc + b.committedCost, 0);
  const totalActual = departmentBudgets.reduce((acc, b) => acc + b.actualCost, 0);
  const totalForecast = departmentBudgets.reduce((acc, b) => acc + b.forecastFinal, 0);
  const totalVariance = totalForecast - totalOriginal;

  const [poVendor, setPoVendor] = useState('Panavision Optics LLC');
  const [poAmount, setPoAmount] = useState(125000);
  const [poDepartment, setPoDepartment] = useState('Camera');
  const [poDesc, setPoDesc] = useState('4.5K Anamorphic Lens Package Rental');

  const handleCreatePO = () => {
    if (!poVendor || poAmount <= 0) return;
    createPurchaseOrder({
      projectId: selectedProject.id,
      vendorName: poVendor,
      department: poDepartment,
      description: poDesc,
      amount: poAmount,
      status: 'Pending Approval'
    });
    setPoDesc('');
  };

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            PRODUCTION FINANCE & COST REPORT ENGINE
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            {selectedProject.title} — PRODUCTION COST REPORT
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Original Budget vs Committed vs Actuals • Forecast Final Variance • Purchase Order Approvals
          </p>
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <div className="bg-[#12151A] border border-slate-800 p-4 rounded-xl shadow-lg">
          <div className="text-xs text-slate-400 font-bold">ORIGINAL APPROVED BUDGET</div>
          <div className="text-3xl font-black text-slate-100 mt-2">${(totalOriginal / 1000000).toFixed(2)}M</div>
          <div className="text-[11px] text-slate-500 mt-1">Locked Greenlight Envelope</div>
        </div>

        <div className="bg-[#12151A] border border-slate-800 p-4 rounded-xl shadow-lg">
          <div className="text-xs text-slate-400 font-bold">COMMITTED COSTS (POs)</div>
          <div className="text-3xl font-black text-sky-400 mt-2">${(totalCommitted / 1000000).toFixed(2)}M</div>
          <div className="text-[11px] text-slate-500 mt-1">{((totalCommitted / totalOriginal) * 100).toFixed(1)}% of Budget</div>
        </div>

        <div className="bg-[#12151A] border border-slate-800 p-4 rounded-xl shadow-lg">
          <div className="text-xs text-slate-400 font-bold">ACTUAL EXPENDITURE TO DATE</div>
          <div className="text-3xl font-black text-emerald-400 mt-2">${(totalActual / 1000000).toFixed(2)}M</div>
          <div className="text-[11px] text-slate-500 mt-1">Invoiced & Paid</div>
        </div>

        <div className="bg-[#12151A] border border-slate-800 p-4 rounded-xl shadow-lg">
          <div className="text-xs text-slate-400 font-bold">FORECAST VARIANCE</div>
          <div className={`text-3xl font-black mt-2 ${totalVariance > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
            {totalVariance >= 0 ? `+$${(totalVariance / 1000).toFixed(0)}k` : `-$${(Math.abs(totalVariance) / 1000).toFixed(0)}k`}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Forecast Total: ${(totalForecast / 1000000).toFixed(2)}M</div>
        </div>
      </div>

      {/* Department Budget Breakdown Table */}
      <div className="bg-[#12151A] border border-slate-800 rounded-xl overflow-hidden shadow-lg font-mono text-xs">
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <span className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            DEPARTMENT COST REPORT MATRIX
          </span>
        </div>

        <table className="w-full text-left">
          <thead className="bg-[#0E1014] text-slate-400 border-b border-slate-800 uppercase tracking-wider text-[10px]">
            <tr>
              <th className="p-3">Department</th>
              <th className="p-3">Original Budget</th>
              <th className="p-3">Committed</th>
              <th className="p-3">Actual Spent</th>
              <th className="p-3">Forecast Final</th>
              <th className="p-3">Variance</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-200">
            {departmentBudgets.map((b, idx) => {
              const variance = b.forecastFinal - b.originalBudget;
              return (
                <tr key={idx} className="hover:bg-slate-800/50">
                  <td className="p-3 font-bold text-amber-300">{b.department}</td>
                  <td className="p-3">${b.originalBudget.toLocaleString()}</td>
                  <td className="p-3 text-sky-300">${b.committedCost.toLocaleString()}</td>
                  <td className="p-3 text-emerald-300">${b.actualCost.toLocaleString()}</td>
                  <td className="p-3 font-bold text-slate-100">${b.forecastFinal.toLocaleString()}</td>
                  <td className="p-3">
                    <span
                      className={`font-bold ${
                        variance > 0 ? 'text-amber-400' : variance < 0 ? 'text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      {variance >= 0 ? `+$${variance.toLocaleString()}` : `-$${Math.abs(variance).toLocaleString()}`}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Purchase Orders Section & Generator */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
        {/* Left Col (2 cols): PO List */}
        <div className="lg:col-span-2 bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="font-bold text-sm text-slate-100">PURCHASE ORDERS ({purchaseOrders.length})</span>
          </div>

          <div className="space-y-2.5">
            {purchaseOrders.map((po) => (
              <div key={po.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2 font-bold">
                    <span className="text-amber-300">{po.poNumber || po.id}</span>
                    <span className="text-slate-100">{po.vendorName}</span>
                    <span className="text-slate-400 text-[10px]">({po.department})</span>
                  </div>
                  <div className="text-[11px] text-slate-300 font-sans">{po.description}</div>
                  <div className="text-[10px] text-slate-500">Issued on {po.createdDate}</div>
                </div>

                <div className="text-right shrink-0 space-y-1">
                  <div className="font-bold text-emerald-400 text-sm">${po.amount.toLocaleString()}</div>
                  {po.status === 'Approved' ? (
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded text-[10px] font-bold">
                      ✓ APPROVED
                    </span>
                  ) : (
                    <button
                      onClick={() => approvePurchaseOrder(po.id)}
                      className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded font-bold text-[10px]"
                    >
                      Approve PO
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: Create PO Form */}
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <h3 className="font-bold text-sm text-slate-100 border-b border-slate-800 pb-2">
            RAISE NEW PURCHASE ORDER
          </h3>

          <div className="space-y-3">
            <div>
              <label className="text-slate-400 text-[10px] block mb-1">VENDOR NAME</label>
              <input
                type="text"
                value={poVendor}
                onChange={(e) => setPoVendor(e.target.value)}
                className="w-full p-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[10px] block mb-1">DEPARTMENT</label>
              <select
                value={poDepartment}
                onChange={(e) => setPoDepartment(e.target.value)}
                className="w-full p-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none"
              >
                <option value="Camera">Camera</option>
                <option value="Art & Sets">Art & Sets</option>
                <option value="VFX">VFX</option>
                <option value="Locations">Locations</option>
                <option value="Stunts">Stunts</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 text-[10px] block mb-1">PO AMOUNT ($ USD)</label>
              <input
                type="number"
                value={poAmount}
                onChange={(e) => setPoAmount(Number(e.target.value))}
                className="w-full p-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 text-[10px] block mb-1">DESCRIPTION</label>
              <input
                type="text"
                value={poDesc}
                onChange={(e) => setPoDesc(e.target.value)}
                className="w-full p-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none"
              />
            </div>

            <button
              onClick={handleCreatePO}
              className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded shadow transition-all mt-2"
            >
              + Submit Purchase Order
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
