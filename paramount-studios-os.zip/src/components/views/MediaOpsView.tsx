import React from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import { HardDrive, Server, ShieldCheck, RefreshCw, AlertOctagon } from 'lucide-react';

export const MediaOpsView: React.FC = () => {
  const {
    mediaAssets,
    ingestJobs,
    sanVolumes,
    projects,
    selectedProjectId,
    triggerIngestFailure,
    triggerQCFailure
  } = useStudioStore();

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            MEDIA OPERATIONS & DIGITAL ASSET MANAGEMENT
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            {selectedProject.title} — ASSET INGEST & SAN STORAGE PIPELINE
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            4.5K Camera Originals • Real-Time SAN Cluster Volume Monitoring • Automated QC Gatekeeper
          </p>
        </div>
      </div>

      {/* SAN Cluster Storage Grid */}
      <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <span className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <Server className="w-4 h-4 text-amber-400" />
            PARAMOUNT HOLLYWOOD LOT SAN STORAGE VOLUMES
          </span>
          <span className="text-emerald-400 font-bold">SAN HEALTH: OPTIMAL (10GbE FIBRE)</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {sanVolumes.map((vol) => (
            <div key={vol.id} className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-3">
              <div className="flex items-center justify-between font-bold">
                <span className="text-slate-100 text-sm">{vol.volumeName}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                    vol.healthStatus === 'Optimal'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  }`}
                >
                  {vol.healthStatus}
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>Storage Used: {vol.usedTb} TB</span>
                  <span>Cap: {vol.totalTb} TB</span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-400 h-full transition-all duration-500"
                    style={{ width: `${(vol.usedTb / vol.totalTb) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Ingest Jobs Queue & Assets Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        {/* Ingest Jobs */}
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-sky-400" />
              INGEST & PROXY GENERATION JOBS
            </span>
          </div>

          <div className="space-y-3">
            {ingestJobs.map((job) => (
              <div key={job.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg space-y-2">
                <div className="flex items-center justify-between font-bold">
                  <span className="text-slate-100">{job.assetTitle}</span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      job.status === 'Completed'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : job.status === 'Failed'
                        ? 'bg-red-500/20 text-red-400'
                        : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {job.status}
                  </span>
                </div>

                <div className="text-[11px] text-slate-400">
                  Stage: {job.stage} ({job.progressPercent}%)
                </div>

                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${job.status === 'Failed' ? 'bg-red-500' : 'bg-sky-400'}`}
                    style={{ width: `${job.progressPercent}%` }}
                  />
                </div>

                {job.errorDetails && (
                  <div className="text-[10px] text-red-400 p-2 bg-red-950/30 border border-red-800/40 rounded">
                    Error: {job.errorDetails}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Media Assets Register */}
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-emerald-400" />
              DIGITAL ASSET REGISTER
            </span>
          </div>

          <div className="space-y-3">
            {mediaAssets.map((asset) => (
              <div key={asset.id} className="p-3 bg-slate-900 border border-slate-800 rounded-lg space-y-1.5">
                <div className="flex items-center justify-between font-bold">
                  <span className="text-amber-300">{asset.title}</span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      asset.qcStatus === 'QC Passed'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {asset.qcStatus}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-400 pt-1 border-t border-slate-800">
                  <span>Type: {asset.assetType}</span>
                  <span>Res: {asset.resolution}</span>
                  <span>Fps: {asset.frameRate}</span>
                  <span>Codec: {asset.codec}</span>
                  <span>Color: {asset.colorSpace}</span>
                  <span>Tier: {asset.storageTier}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
