import React, { useState } from 'react';
import { useStudioStore } from '../../state/useStudioStore';
import {
  Calendar,
  Clock,
  AlertTriangle,
  FileText,
  Plus,
  Play,
  RotateCcw,
  CheckCircle2,
  Users,
  MapPin,
  ChevronRight,
  Sun
} from 'lucide-react';

export const SchedulingView: React.FC = () => {
  const {
    projects,
    selectedProjectId,
    shootingDays,
    conflicts,
    callSheets,
    triggerScheduleDelay
  } = useStudioStore();

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];
  const projectDays = shootingDays.filter((s) => s.projectId === selectedProject.id);

  const [activeTab, setActiveTab] = useState<'board' | 'gantt' | 'callsheet'>('board');
  const [delayReasonInput, setDelayReasonInput] = useState('Stage 14 Zero-G Cable Tension Adjustment');

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto text-slate-100 font-sans">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs font-mono uppercase text-amber-400 font-bold tracking-wider">
            PRODUCTION SCHEDULING & CALL SHEET BUILDER
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight mt-1">
            {selectedProject.title} — SHOOTING SCHEDULE & GANTT PLANNER
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Shooting Day Board • Turnaround Constraints • Conflict Detector • Delay Simulator
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded-lg p-1 font-mono text-xs">
          <button
            onClick={() => setActiveTab('board')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeTab === 'board' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Shooting Day Board
          </button>
          <button
            onClick={() => setActiveTab('gantt')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeTab === 'gantt' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Gantt Timeline
          </button>
          <button
            onClick={() => setActiveTab('callsheet')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeTab === 'callsheet' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Call Sheet Builder
          </button>
        </div>
      </div>

      {/* Schedule Delay Simulator Action Card */}
      <div className="p-4 bg-gradient-to-r from-slate-900 via-amber-950/20 to-slate-900 border border-amber-500/40 rounded-xl flex flex-wrap items-center justify-between gap-4 font-mono text-xs shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-amber-400 font-bold">
            <Clock className="w-4 h-4" />
            <span>SHOOTING SCHEDULE DELAY SIMULATOR & RISK CALCULATOR</span>
          </div>
          <p className="text-slate-300 text-[11px] font-sans">
            Simulate a shoot delay event. Recalculates estimated wrap date, budget forecast variance, and flags turnaround warnings.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={delayReasonInput}
            onChange={(e) => setDelayReasonInput(e.target.value)}
            className="p-2 bg-slate-900 border border-slate-700 rounded text-slate-100 w-64 text-xs focus:outline-none"
          />
          <button
            onClick={() => triggerScheduleDelay(selectedProject.id, 2, delayReasonInput)}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded flex items-center gap-1.5 shadow"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Simulate +2 Days Delay</span>
          </button>
        </div>
      </div>

      {/* Conflicts Banner if Any */}
      {conflicts.length > 0 && (
        <div className="p-4 bg-amber-950/30 border border-amber-500/40 rounded-xl space-y-2 font-mono text-xs">
          <div className="flex items-center space-x-2 text-amber-400 font-bold">
            <AlertTriangle className="w-4 h-4" />
            <span>SCHEDULE CONFLICT DETECTOR ({conflicts.length} CONSTRAINTS DETECTED)</span>
          </div>
          {conflicts.map((cnf) => (
            <div key={cnf.id} className="p-2 bg-slate-900/80 border border-amber-500/30 rounded flex items-center justify-between text-slate-200">
              <div>
                <span className="font-bold text-amber-300">[{cnf.type}] </span>
                <span>{cnf.description}</span>
              </div>
              <span className="text-[10px] text-slate-400">{cnf.affectedDate}</span>
            </div>
          ))}
        </div>
      )}

      {/* Main Tab Views */}
      {activeTab === 'board' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
          {projectDays.map((sd) => (
            <div
              key={sd.id}
              className={`p-4 rounded-xl border space-y-3 shadow-md ${
                sd.status === 'Delayed'
                  ? 'bg-red-950/20 border-red-500/50'
                  : sd.status === 'In Progress'
                  ? 'bg-amber-500/10 border-amber-500/50'
                  : 'bg-[#12151A] border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-sm text-slate-100">DAY #{sd.dayNumber}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    sd.status === 'Delayed'
                      ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                      : sd.status === 'In Progress'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  {sd.status}
                </span>
              </div>

              <div className="space-y-1">
                <div className="text-slate-400 text-[11px]">{sd.date}</div>
                <div className="font-bold text-slate-200 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-400" />
                  <span>{sd.locationName}</span>
                </div>
              </div>

              <div className="p-2 bg-slate-900 border border-slate-800 rounded space-y-1">
                <span className="text-[10px] text-slate-500 uppercase block">Scenes Scheduled</span>
                <span className="font-bold text-amber-300">Scenes #{sd.scenes.join(', ')}</span>
              </div>

              {sd.delayReason && (
                <div className="p-2 bg-red-950/40 border border-red-800 rounded text-red-300 text-[10px]">
                  Reason: {sd.delayReason}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Gantt Timeline View */}
      {activeTab === 'gantt' && (
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="font-bold text-sm text-slate-100">GANTT MILESTONE & STAGE TIMELINE</span>
            <span className="text-slate-400 text-[11px]">September 2026 – December 2026</span>
          </div>

          <div className="space-y-3">
            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>Phase 1: Principal Photography (Stage 14)</span>
                <span className="text-emerald-400 font-bold">61% Complete</span>
              </div>
              <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-amber-400 h-full w-[61%]" />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>Phase 2: Post-Production & Editorial Assembly</span>
                <span className="text-amber-300">Target Start Oct 2026</span>
              </div>
              <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-sky-500 h-full w-[25%]" />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>Phase 3: Visual Effects (ILM Hero Shots)</span>
                <span className="text-amber-300">Target Wrap Nov 2026</span>
              </div>
              <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                <div className="bg-purple-500 h-full w-[40%]" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Call Sheet Builder View */}
      {activeTab === 'callsheet' && callSheets[0] && (
        <div className="bg-[#12151A] border border-slate-800 rounded-xl p-6 shadow-lg space-y-5 font-mono text-xs">
          <div className="p-4 bg-[#0E1014] border border-slate-800 rounded-lg flex flex-wrap items-center justify-between gap-3">
            <div>
              <span className="text-amber-400 font-bold text-sm block">PARAMOUNT PICTURES OFFICIAL CALL SHEET</span>
              <span className="text-slate-200 text-base font-black">{selectedProject.title}</span>
            </div>

            <div className="text-right">
              <span className="text-slate-400 block">Date: {callSheets[0].shootingDate}</span>
              <span className="text-emerald-400 font-bold">Status: {callSheets[0].status}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-3 bg-slate-900 border border-slate-800 rounded">
              <span className="text-slate-500 block text-[10px]">CREW CALL</span>
              <span className="text-lg font-bold text-slate-100">{callSheets[0].crewCallTime}</span>
            </div>
            <div className="p-3 bg-slate-900 border border-slate-800 rounded">
              <span className="text-slate-500 block text-[10px]">CAST CALL</span>
              <span className="text-lg font-bold text-slate-100">{callSheets[0].castCallTime}</span>
            </div>
            <div className="p-3 bg-slate-900 border border-slate-800 rounded">
              <span className="text-slate-500 block text-[10px]">ESTIMATED WRAP</span>
              <span className="text-lg font-bold text-slate-100">{callSheets[0].estimatedWrapTime}</span>
            </div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg space-y-2">
            <div className="font-bold text-amber-400 text-xs">SAFETY ADVISORIES & SPECIAL INSTRUCTIONS</div>
            <ul className="list-disc list-inside space-y-1 text-slate-300">
              {callSheets[0].safetyNotes.map((note, idx) => (
                <li key={idx}>{note}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
