import {
  Project,
  Scene,
  CastMember,
  CrewMember,
  CallSheet,
  DailyProductionReport,
  IncidentReport,
  ShootingDay,
  ScheduleConflict,
  MediaAsset,
  IngestJob,
  PostStage,
  ReviewFrameComment,
  VFXShot,
  LocalisationMatrixItem,
  DistributionOrder,
  RightsRecord,
  PurchaseOrder,
  DepartmentBudget,
  MarketingCampaign,
  StudioFacility,
  FacilityBooking,
  SustainabilityMetrics,
  StudioEvent,
  AuditLogEntry,
  Notification,
  UserProfile
} from '../types';

export const DEMO_USERS: UserProfile[] = [
  {
    id: 'usr_exec1',
    name: 'Eleanor Vance',
    email: 'e.vance@paramount.com',
    role: 'Executive',
    title: 'Executive Vice President of Feature Production',
    division: 'Paramount Pictures',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'usr_prod1',
    name: 'Marcus Thorne',
    email: 'm.thorne@paramount.com',
    role: 'Producer',
    title: 'Senior Showrunner & Executive Producer',
    division: 'Paramount Television Studios',
    avatarUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'usr_pm1',
    name: 'Sarah Connor',
    email: 's.connor@paramount.com',
    role: 'Production Manager',
    title: 'Head of Physical Production',
    division: 'Paramount Pictures',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'usr_vfx1',
    name: 'David Zhao',
    email: 'd.zhao@paramount.com',
    role: 'VFX Supervisor',
    title: 'Global VFX Operations Lead',
    division: 'Paramount Pictures',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'usr_legal1',
    name: 'Rachel Sterling',
    email: 'r.sterling@paramount.com',
    role: 'Legal Reviewer',
    title: 'VP Rights & Legal Clearance',
    division: 'Paramount Pictures',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'usr_fin1',
    name: 'Arthur Pendelton',
    email: 'a.pendelton@paramount.com',
    role: 'Finance Reviewer',
    title: 'Controller of Production Finance',
    division: 'CBS Studios',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  }
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'prj_tlo',
    title: 'THE LAST ORBIT',
    workingTitle: 'MOUNTAIN-DELTA-9',
    format: 'Feature Film',
    genre: 'Sci-Fi Thriller',
    logline: 'When an orbital deep-space station loses communication during a solar anomaly, a veteran astronaut must navigate sabotage and oxygen depletion before re-entry.',
    synopsis: 'Set in 2042, orbital repair station Prometheus 7 experiences a catastrophic telemetry blackout. Mission Commander Helen Vance discovers an intentional breach in the primary airlock.',
    creator: 'Julian Vance & Aris Thorne',
    producer: 'Eleanor Vance / Red Planet Media',
    productionCompany: 'Paramount Pictures / Skydance',
    studioDivision: 'Paramount Pictures',
    targetAudience: 'PG-13 / Global Wide',
    territory: 'Worldwide',
    plannedReleaseWindow: 'Q3 2027 Theatrical Wide',
    developmentBudget: 4200000,
    productionBudget: 145000000,
    actualCostToDate: 88400000,
    forecastCost: 147800000,
    currentStage: 'Production',
    riskRating: 'High',
    confidentiality: 'Confidential',
    assignedExecutives: ['Eleanor Vance', 'Arthur Pendelton'],
    attachedDocuments: [
      { id: 'doc_1', name: 'Script_Draft_v4.2_Lock.pdf', type: 'Screenplay', date: '2026-08-10' },
      { id: 'doc_2', name: 'Stage_14_Gantt_Schedule.pdf', type: 'Schedule', date: '2026-09-01' },
      { id: 'doc_3', name: 'VFX_Bid_Package_ILM.pdf', type: 'VFX', date: '2026-08-15' }
    ],
    updatedAt: '2026-09-21T08:30:00Z'
  },
  {
    id: 'prj_pd',
    title: 'PACIFIC DIVISION',
    workingTitle: 'WEST-COAST-NOIR',
    format: 'Drama Series',
    genre: 'Crime Noir / Police Procedural',
    logline: 'An elite task force investigates corrupt high-stakes maritime smuggling along the Pacific Coast Highway from San Diego to Seattle.',
    synopsis: 'Detectives Mateo Ruiz and Claire Sterling uncover a multi-jurisdictional syndicate operating out of commercial container ports.',
    creator: 'Elena Rostova',
    producer: 'Marcus Thorne',
    productionCompany: 'Paramount Television Studios',
    studioDivision: 'Paramount Television Studios',
    targetAudience: 'TV-MA / Premium Cable & Streaming',
    territory: 'Worldwide',
    plannedReleaseWindow: 'Q1 2027 Paramount+',
    developmentBudget: 1800000,
    productionBudget: 62000000,
    actualCostToDate: 51200000,
    forecastCost: 61800000,
    currentStage: 'Post-Production',
    riskRating: 'Medium',
    confidentiality: 'Internal',
    assignedExecutives: ['Marcus Thorne', 'Rachel Sterling'],
    attachedDocuments: [
      { id: 'doc_4', name: 'Ep101_Post_Conform_Report.pdf', type: 'Post', date: '2026-09-12' }
    ],
    updatedAt: '2026-09-20T14:15:00Z'
  },
  {
    id: 'prj_nsla',
    title: 'NIGHT SHIFT: LOS ANGELES',
    workingTitle: 'LA-AFTER-DARK',
    format: 'Procedural Series',
    genre: 'Medical Action',
    logline: 'The graveyard shift at Downtown LA’s busiest trauma facility faces extreme emergency medical cases amidst citywide crisis events.',
    synopsis: 'A fast-paced ensemble hospital procedural focusing on ER surgeons, paramedic units, and urban rescue dispatchers.',
    creator: 'Dr. Michael Chen',
    producer: 'Sarah Connor',
    productionCompany: 'CBS Studios',
    studioDivision: 'CBS Studios',
    targetAudience: 'TV-14 / Network Primetime',
    territory: 'US & International Licensing',
    plannedReleaseWindow: 'Fall 2026 Broadcast',
    developmentBudget: 1200000,
    productionBudget: 48000000,
    actualCostToDate: 32000000,
    forecastCost: 47900000,
    currentStage: 'Production',
    riskRating: 'Low',
    confidentiality: 'Internal',
    assignedExecutives: ['Sarah Connor'],
    attachedDocuments: [
      { id: 'doc_5', name: 'CallSheet_Day42_Stage3.pdf', type: 'Call Sheet', date: '2026-09-21' }
    ],
    updatedAt: '2026-09-21T06:00:00Z'
  },
  {
    id: 'prj_gk',
    title: 'THE GLASS KINGDOM',
    workingTitle: 'PROJECT-CRYSTAL',
    format: 'Feature Film',
    genre: 'Epic Fantasy',
    logline: 'In a world where architecture dictates magical ley lines, an exiled guild apprentice must stop an alchemical shattering of the royal citadel.',
    synopsis: 'Adapted from the bestselling fantasy saga. Rich mythical world-building with massive physical set builds on Stage 5 & 12.',
    creator: 'Valerie Frost',
    producer: 'Eleanor Vance',
    productionCompany: 'Paramount Pictures / Temple Hill',
    studioDivision: 'Paramount Pictures',
    targetAudience: 'PG-13 / Global Tentpole',
    territory: 'Worldwide',
    plannedReleaseWindow: 'Summer 2028',
    developmentBudget: 6500000,
    productionBudget: 210000000,
    actualCostToDate: 4200000,
    forecastCost: 210000000,
    currentStage: 'Development',
    riskRating: 'Medium',
    confidentiality: 'Strictly Secret',
    assignedExecutives: ['Eleanor Vance'],
    attachedDocuments: [
      { id: 'doc_6', name: 'Lookbook_Visual_Concepts_v2.pdf', type: 'Design', date: '2026-07-19' }
    ],
    updatedAt: '2026-09-18T11:00:00Z'
  },
  {
    id: 'prj_sh',
    title: 'SIGNAL HOUSE',
    workingTitle: 'BEACON-ONE',
    format: 'Limited Series',
    genre: 'Espionage Mystery',
    logline: 'A retired signals intelligence analyst in Geneva discovers a ghost frequency transmitting coded instructions for an abandoned Cold War asset.',
    synopsis: 'A tight 6-part psychological thriller shot across Switzerland, Vienna, and Paramount Lot Backlot sets.',
    creator: 'Henrik Vanger',
    producer: 'Marcus Thorne',
    productionCompany: 'Paramount Television Studios',
    studioDivision: 'Paramount+ Originals',
    targetAudience: 'TV-MA',
    territory: 'Worldwide',
    plannedReleaseWindow: 'Q2 2027',
    developmentBudget: 2100000,
    productionBudget: 38000000,
    actualCostToDate: 8500000,
    forecastCost: 38200000,
    currentStage: 'Pre-Production',
    riskRating: 'Low',
    confidentiality: 'Confidential',
    assignedExecutives: ['Marcus Thorne', 'Arthur Pendelton'],
    attachedDocuments: [],
    updatedAt: '2026-09-19T16:20:00Z'
  },
  {
    id: 'prj_wu',
    title: 'WILDERNESS UNIT',
    workingTitle: 'EXPEDITION-SERENGETI',
    format: 'Unscripted Docuseries',
    genre: 'Nature & Conservation',
    logline: 'A team of anti-poaching rangers and wildlife biologists deploy cutting-edge drone cameras to protect endangered megafauna in East Africa.',
    synopsis: '8-part 8K HDR docuseries filmed over 14 months using ultra-low-light sensor rigs.',
    creator: 'Kofi Mensah',
    producer: 'Sarah Connor',
    productionCompany: 'MTV Entertainment / Smithsonian Channel',
    studioDivision: 'MTV Entertainment',
    targetAudience: 'TV-PG / Family',
    territory: 'Worldwide',
    plannedReleaseWindow: 'Q4 2026',
    developmentBudget: 800000,
    productionBudget: 14000000,
    actualCostToDate: 13800000,
    forecastCost: 14000000,
    currentStage: 'Delivery',
    riskRating: 'Low',
    confidentiality: 'Unclassified',
    assignedExecutives: ['Sarah Connor', 'Rachel Sterling'],
    attachedDocuments: [],
    updatedAt: '2026-09-20T09:10:00Z'
  },
  {
    id: 'prj_sa',
    title: 'STARFALL ACADEMY',
    workingTitle: 'COSMIC-KIDS',
    format: 'Animated Series',
    genre: 'Sci-Fi Adventure Animation',
    logline: 'Cadets from across the galaxy train to become starship pilots while protecting peace across deep space sectors.',
    synopsis: '26-episode CG animated series produced with Unreal Engine 5 real-time rendering workflow.',
    creator: 'Maya Lin',
    producer: 'Eleanor Vance',
    productionCompany: 'Nickelodeon Animation Studio',
    studioDivision: 'Nickelodeon Animation',
    targetAudience: 'Kids 6-11 / Family',
    territory: 'Worldwide',
    plannedReleaseWindow: 'Q2 2027',
    developmentBudget: 3500000,
    productionBudget: 32000000,
    actualCostToDate: 2100000,
    forecastCost: 32000000,
    currentStage: 'Development',
    riskRating: 'Low',
    confidentiality: 'Internal',
    assignedExecutives: ['Eleanor Vance'],
    attachedDocuments: [],
    updatedAt: '2026-09-15T10:00:00Z'
  },
  {
    id: 'prj_lw',
    title: 'THE LONG WEEKEND',
    workingTitle: 'CABIN-FEVER-COMEDY',
    format: 'Feature Film',
    genre: 'Ensemble Comedy',
    logline: 'Four college friends reunite at a remote lake house for a high school reunion, only to realize they rented the wrong property during a mayor’s campaign retreat.',
    synopsis: 'Sharp dialogue, fast shooting schedule, ensemble cast with high theatrical appeal.',
    creator: 'Ben & Sam Miller',
    producer: 'Marcus Thorne',
    productionCompany: 'Paramount Pictures',
    studioDivision: 'Paramount Pictures',
    targetAudience: 'R / Adults',
    territory: 'North America & Europe',
    plannedReleaseWindow: 'Q1 2027',
    developmentBudget: 1100000,
    productionBudget: 22000000,
    actualCostToDate: 1900000,
    forecastCost: 22000000,
    currentStage: 'Greenlit',
    riskRating: 'Low',
    confidentiality: 'Internal',
    assignedExecutives: ['Marcus Thorne'],
    attachedDocuments: [],
    updatedAt: '2026-09-17T15:45:00Z'
  }
];

export const INITIAL_SCENES: Scene[] = [
  {
    id: 'scn_101',
    projectId: 'prj_tlo',
    sceneNumber: '101',
    heading: 'EXT. PROMETHEUS 7 STATION - SOLAR ARRAY - DAY',
    locationName: 'Prometheus 7 Station Exterior (VFX Stage 14)',
    timeOfDay: 'DAY',
    interiorExterior: 'EXT',
    pageCount: 2.3,
    estimatedMinutes: 4.5,
    characters: ['HELEN VANCE', 'OPERATOR COLE'],
    breakdownItems: [
      { id: 'b_1', category: 'CHARACTER', name: 'HELEN VANCE', departmentNote: 'Eva Space Suit w/ HUD lighting' },
      { id: 'b_2', category: 'PROP', name: 'Hydraulic Tether Gun', departmentNote: 'Custom prop with high-tension wire' },
      { id: 'b_3', category: 'VFX', name: 'Solar Anomaly Lens Flare & Particle Debris', departmentNote: 'Hero VFX sequence 101' },
      { id: 'b_4', category: 'STUNT', name: 'Zero-G Wire Harness Rigging', departmentNote: 'Double required for tether snap' }
    ],
    notes: ['Special lighting setup required for solar flare contrast. High wire tension safety review.'],
    revisionId: 'rev_blue_20260901',
    scriptSnippet: 'HELEN clips her carabiner to the main guide cable. Below her, Earth arcs in brilliant sapphire blue.\n\nHELEN\nControl, solar panel array 4 is locked. But I’m seeing a thermal spike on relay three.\n\nCOLE (V.O.)\nCopy Commander. That thermal reading shouldn’t be possible without manual override.',
    complexityScore: 9
  },
  {
    id: 'scn_102',
    projectId: 'prj_tlo',
    sceneNumber: '102',
    heading: 'INT. COMMAND BRIDGE - CONTINUOUS',
    locationName: 'Prometheus Bridge (Stage 14 Set B)',
    timeOfDay: 'DAY',
    interiorExterior: 'INT',
    pageCount: 1.5,
    estimatedMinutes: 2.5,
    characters: ['OPERATOR COLE', 'DR. ARIS TIAN'],
    breakdownItems: [
      { id: 'b_5', category: 'CHARACTER', name: 'OPERATOR COLE', departmentNote: 'Flight jumpsuit' },
      { id: 'b_6', category: 'CHARACTER', name: 'DR. ARIS TIAN', departmentNote: 'Science division lab coat' },
      { id: 'b_7', category: 'EQUIPMENT', name: '360 Holographic Navigation Console', departmentNote: 'Interactive touch props with LEDs' }
    ],
    notes: ['Requires practical screen playback synced to timecode.'],
    revisionId: 'rev_blue_20260901',
    scriptSnippet: 'Cole punches the emergency override sequence. Red alert strobes flash silently across the polished bulkhead panels.',
    complexityScore: 5
  },
  {
    id: 'scn_201',
    projectId: 'prj_pd',
    sceneNumber: '201',
    heading: 'EXT. PORT OF LOS ANGELES - DOCK 44 - NIGHT',
    locationName: 'San Pedro Docks / Backlot Water Tank',
    timeOfDay: 'NIGHT',
    interiorExterior: 'EXT',
    pageCount: 3.1,
    estimatedMinutes: 5.0,
    characters: ['MATEO RUIZ', 'CLAIRE STERLING', 'SMUGGLER LEAD'],
    breakdownItems: [
      { id: 'b_8', category: 'CHARACTER', name: 'MATEO RUIZ', departmentNote: 'Tactical police vest & earpiece' },
      { id: 'b_9', category: 'VEHICLE', name: 'Unmarked Pursuit SUV & Freight Crane', departmentNote: 'Crane operator needed' },
      { id: 'b_10', category: 'SOUND', name: 'Heavy Industrial Crane Hydraulic SFX', departmentNote: 'Boom mic + hydrophones' }
    ],
    notes: ['Wet down requested for dock pavement. Rain machine setup at 20:00.'],
    revisionId: 'rev_white_20260815',
    scriptSnippet: 'Rain cascades off the towering shipping containers. Ruiz raises his sidearm.',
    complexityScore: 8
  }
];

export const INITIAL_CAST: CastMember[] = [
  { id: 'c_1', characterName: 'HELEN VANCE', actorName: 'Jessica Chastain (Simulated)', roleType: 'Lead', agencyContact: 'CAA / Management 360', status: 'On Set', dailyRate: 45000 },
  { id: 'c_2', characterName: 'OPERATOR COLE', actorName: 'Oscar Isaac (Simulated)', roleType: 'Lead', agencyContact: 'WME Agency', status: 'On Set', dailyRate: 40000 },
  { id: 'c_3', characterName: 'DR. ARIS TIAN', actorName: 'Hiroyuki Sanada (Simulated)', roleType: 'Supporting', agencyContact: 'UTA', status: 'Standby', dailyRate: 25000 },
  { id: 'c_4', characterName: 'MATEO RUIZ', actorName: 'Pedro Pascal (Simulated)', roleType: 'Lead', agencyContact: 'CAA', status: 'Wrapped', dailyRate: 35000 }
];

export const INITIAL_CREW: CrewMember[] = [
  { id: 'cr_1', name: 'Robert Elswit', department: 'Camera', title: 'Director of Photography', phone: '310-555-0192', radioChannel: 'Ch 1' },
  { id: 'cr_2', name: 'Gail Tattersall', department: 'Lighting', title: 'Gaffer', phone: '310-555-0144', radioChannel: 'Ch 2' },
  { id: 'cr_3', name: 'Mark Mangini', department: 'Sound', title: 'Production Sound Mixer', phone: '310-555-0811', radioChannel: 'Ch 3' },
  { id: 'cr_4', name: 'Hannah Beachler', department: 'Art Department', title: 'Production Designer', phone: '310-555-0922', radioChannel: 'Ch 4' }
];

export const INITIAL_CALL_SHEETS: CallSheet[] = [
  {
    id: 'cs_101',
    projectId: 'prj_tlo',
    shootingDate: '2026-09-21',
    dayNumber: 38,
    totalDays: 62,
    unit: 'Main Unit - Stage 14',
    mainLocation: 'Paramount Lot - Stage 14 (Zero-G Rigging)',
    crewCallTime: '06:00 AM',
    castCallTime: '07:00 AM',
    firstShotTime: '08:15 AM',
    estimatedWrapTime: '07:00 PM',
    weatherSummary: 'Sunny / Indoor Stage Controlled Atmosphere',
    highTemp: 78,
    lowTemp: 62,
    nearestHospital: 'Cedars-Sinai Medical Center, 8700 Beverly Blvd, LA',
    safetyNotes: [
      'High-tension wire harness testing at 06:30 AM before cast stepping into rig.',
      'All personnel on Stage 14 floor MUST wear hard hats during overhead crane travel.',
      'Laser lens flare testing at 14:00 - Eye protection required for non-essential crew.'
    ],
    scenesToShoot: ['101', '102'],
    status: 'Published',
    publishedAt: '2026-09-20T18:00:00Z'
  }
];

export const INITIAL_DAILY_REPORTS: DailyProductionReport[] = [
  {
    id: 'dpr_37',
    projectId: 'prj_tlo',
    date: '2026-09-20',
    dayNumber: 37,
    scenesCompleted: ['98', '99', '100'],
    scenesIncomplete: [],
    pagesShot: 3.8,
    actualSetupTime: '06:12 AM',
    actualWrapTime: '06:45 PM',
    delays: [{ reason: 'Zero-G Wire Calibration adjustment on Harness #2', durationMinutes: 35 }],
    incidents: ['Minor hydraulic fluid drip on Stage 14 floor - safely cleaned in 10 mins.'],
    mediaCapturedGb: 1840, // 1.8 TB camera RAW
    overtimeMinutes: 15,
    notes: 'Excellent performance by lead cast. 4K HDR playback verified by DIT.'
  }
];

export const INITIAL_INCIDENTS: IncidentReport[] = [
  {
    id: 'inc_101',
    projectId: 'prj_tlo',
    date: '2026-09-20',
    severity: 'Minor',
    category: 'Safety',
    description: 'Hydraulic cable tensioner warning sensor flagged pressure drop during Scene 99 test.',
    affectedDepartment: 'Stunts & Rigging',
    status: 'Resolved',
    actionTaken: 'Replaced secondary hydraulic valve gasket. Re-certified by safety inspector.'
  },
  {
    id: 'inc_102',
    projectId: 'prj_pd',
    date: '2026-09-18',
    severity: 'Moderate',
    category: 'Weather',
    description: 'High wind gusts at San Pedro Harbor forced suspension of crane arm extension for 2 hours.',
    affectedDepartment: 'Camera / Key Grip',
    status: 'Resolved',
    actionTaken: 'Shifted schedule to interior shipping container set until wind subsided.'
  }
];

export const INITIAL_SHOOTING_DAYS: ShootingDay[] = [
  { id: 'sd_38', projectId: 'prj_tlo', date: '2026-09-21', dayNumber: 38, scenes: ['101', '102'], locationName: 'Stage 14', isNightShoot: false, isCompanyMove: false, status: 'In Progress' },
  { id: 'sd_39', projectId: 'prj_tlo', date: '2026-09-22', dayNumber: 39, scenes: ['103', '104A'], locationName: 'Stage 14', isNightShoot: false, isCompanyMove: false, status: 'Scheduled' },
  { id: 'sd_40', projectId: 'prj_tlo', date: '2026-09-23', dayNumber: 40, scenes: ['105', '106'], locationName: 'Stage 5 Air Lock', isNightShoot: true, isCompanyMove: true, status: 'Scheduled' },
  { id: 'sd_41', projectId: 'prj_tlo', date: '2026-09-24', dayNumber: 41, scenes: ['107'], locationName: 'Stage 5 Air Lock', isNightShoot: true, isCompanyMove: false, status: 'Scheduled' }
];

export const INITIAL_MEDIA_ASSETS: MediaAsset[] = [
  {
    id: 'asset_master_tlo_101',
    projectId: 'prj_tlo',
    title: 'THE_LAST_ORBIT_A001_C001_0921_RAW.ARRI',
    assetType: 'Camera Original',
    format: 'ARRIRAW 4.5K',
    codec: 'ARRIRAW',
    resolution: '4448 x 3096',
    frameRate: '23.976 fps',
    audioChannels: '2 Ch LPCM 24-bit 48kHz',
    colorSpace: 'ARRI Wide Gamut 4 / LogC4',
    hdrStatus: 'HDR10',
    duration: '00:04:18:12',
    fileSizeBytes: 142000000000, // ~142 GB
    checksumSha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    storageTier: 'Hot High-Perf',
    storagePath: '/san/projects/tlo/dailies/20260921/A001_C001.arri',
    qcStatus: 'QC Passed',
    qcReportNote: 'Zero dropped frames. Color chart verified.',
    rightsStatus: 'Cleared',
    createdDate: '2026-09-21T09:15:00Z'
  },
  {
    id: 'asset_proxy_tlo_101',
    projectId: 'prj_tlo',
    title: 'THE_LAST_ORBIT_A001_C001_PROXY.MOV',
    assetType: 'Editorial Proxy',
    format: 'ProRes 422 Proxy',
    codec: 'ProRes 422 Proxy',
    resolution: '1920 x 1080',
    frameRate: '23.976 fps',
    audioChannels: '2 Ch Stereo',
    colorSpace: 'Rec.709',
    hdrStatus: 'SDR',
    duration: '00:04:18:12',
    fileSizeBytes: 4200000000,
    checksumSha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
    storageTier: 'Nearline SAN',
    storagePath: '/san/projects/tlo/proxies/A001_C001_Proxy.mov',
    qcStatus: 'QC Passed',
    rightsStatus: 'Cleared',
    createdDate: '2026-09-21T09:30:00Z'
  },
  {
    id: 'asset_pd_master',
    projectId: 'prj_pd',
    title: 'PACIFIC_DIVISION_EP101_UHD_MASTER.MXF',
    assetType: 'Master Video',
    format: 'MXF OP1a',
    codec: 'XAVC Intra Class 300',
    resolution: '3840 x 2160',
    frameRate: '23.976 fps',
    audioChannels: '5.1 Surround + LtRt Stereo',
    colorSpace: 'Rec.2020 / PQ',
    hdrStatus: 'Dolby Vision',
    duration: '00:54:10:00',
    fileSizeBytes: 380000000000,
    checksumSha256: '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
    storageTier: 'Hot High-Perf',
    storagePath: '/san/masters/pd/EP101_Master.mxf',
    qcStatus: 'QC Passed',
    rightsStatus: 'Cleared',
    createdDate: '2026-09-15T16:00:00Z'
  }
];

export const INITIAL_INGEST_JOBS: IngestJob[] = [
  {
    id: 'job_ing_881',
    assetId: 'asset_master_tlo_101',
    assetTitle: 'THE_LAST_ORBIT_A001_C001_0921_RAW.ARRI',
    projectId: 'prj_tlo',
    stage: 'QC Check',
    progressPercent: 92,
    status: 'In Progress',
    startedAt: '2026-09-21T09:15:00Z'
  },
  {
    id: 'job_ing_882',
    assetId: 'asset_audio_882',
    assetTitle: 'TLO_SOUND_ROLL_38_WAV.ZIP',
    projectId: 'prj_tlo',
    stage: 'Metadata Validation',
    progressPercent: 45,
    status: 'In Progress',
    startedAt: '2026-09-21T09:40:00Z'
  },
  {
    id: 'job_ing_880',
    assetId: 'asset_err_880',
    assetTitle: 'PACIFIC_DIV_EP108_B_ROLL.MOV',
    projectId: 'prj_pd',
    stage: 'Checksum',
    progressPercent: 12,
    status: 'Failed',
    errorDetails: 'Checksum verification mismatch (corrupted frame 1042 during SAN transfer)',
    startedAt: '2026-09-21T08:00:00Z'
  }
];

export const INITIAL_POST_STAGES: PostStage[] = [
  { id: 'ps_1', projectId: 'prj_pd', stageName: 'Rough Cut', owner: 'Chris Lebenzon (Editor)', targetDate: '2026-08-10', completedDate: '2026-08-08', status: 'Completed', notes: 'First assembly signed off by director.' },
  { id: 'ps_2', projectId: 'prj_pd', stageName: 'Picture Lock', owner: 'Elena Rostova (Showrunner)', targetDate: '2026-08-25', completedDate: '2026-08-26', status: 'Completed', notes: 'Picture locked at 54 mins 10 secs.' },
  { id: 'ps_3', projectId: 'prj_pd', stageName: 'Sound Mix', owner: 'Mark Mangini (Re-recording)', targetDate: '2026-09-15', completedDate: '2026-09-14', status: 'Completed', notes: 'Dolby Atmos 7.1.4 mix finalized.' },
  { id: 'ps_4', projectId: 'prj_pd', stageName: 'Color Grade', owner: 'Stephen Nakamura (Colorist)', targetDate: '2026-09-18', completedDate: '2026-09-18', status: 'Completed', notes: 'Dolby Vision HDR master rendered.' },
  { id: 'ps_5', projectId: 'prj_pd', stageName: 'Final QC', owner: 'Global Delivery QC Team', targetDate: '2026-09-22', status: 'Active', notes: 'Final QC inspection running currently.' }
];

export const INITIAL_REVIEW_COMMENTS: ReviewFrameComment[] = [
  { id: 'com_1', assetId: 'asset_pd_master', timecode: '00:14:22:10', frameNumber: 20700, author: 'Marcus Thorne', role: 'Executive Producer', comment: 'Audio stem background noise on radio line feels slightly hot. Lower dialog ducking by 1.5 dB.', status: 'Open', createdAt: '2026-09-19T10:30:00Z' },
  { id: 'com_2', assetId: 'asset_pd_master', timecode: '00:32:05:01', frameNumber: 46200, author: 'David Zhao', role: 'VFX Supervisor', comment: 'Muzzle flash plate tracking in container yard looks seamless now. Approved.', status: 'Approved', createdAt: '2026-09-18T16:15:00Z' }
];

export const INITIAL_VFX_SHOTS: VFXShot[] = [
  {
    id: 'vfx_101',
    projectId: 'prj_tlo',
    shotId: 'TLO_101_010',
    sequence: 'Seq 101 - Solar Array EVA',
    frameRange: '1001-1240 (240 frames)',
    description: 'Hero wide shot of Prometheus station orbiting Earth with solar anomaly flare bursting across horizon.',
    vendorName: 'Industrial Light & Magic (ILM)',
    complexity: 'Hero Complex',
    status: 'In Progress',
    currentVersion: 'v0.4',
    dueDate: '2026-11-15',
    estimatedCost: 185000,
    actualCost: 190000,
    notes: 'Volumetric particle pass requested by director.'
  },
  {
    id: 'vfx_102',
    projectId: 'prj_tlo',
    shotId: 'TLO_101_020',
    sequence: 'Seq 101 - Solar Array EVA',
    frameRange: '1241-1380 (140 frames)',
    description: 'Medium close-up of visor reflections depicting space debris collision.',
    vendorName: 'Framestore',
    complexity: 'High',
    status: 'Client Review',
    currentVersion: 'v1.0_rc2',
    dueDate: '2026-10-30',
    estimatedCost: 95000,
    actualCost: 92000,
    notes: 'Awaiting executive final sign-off.'
  },
  {
    id: 'vfx_201',
    projectId: 'prj_pd',
    shotId: 'PD_101_050',
    sequence: 'Seq 201 - Dock Chase',
    frameRange: '1001-1180 (180 frames)',
    description: 'Digital extension of container ship superstructure and night fog enhancement.',
    vendorName: 'Digital Domain',
    complexity: 'Medium',
    status: 'Final Delivered',
    currentVersion: 'v2.1_Final',
    dueDate: '2026-09-10',
    estimatedCost: 45000,
    actualCost: 45000,
    notes: 'Delivered in ACEScg 16-bit EXR.'
  }
];

export const INITIAL_LOCALISATION_MATRICES: LocalisationMatrixItem[] = [
  {
    id: 'loc_pd_us',
    projectId: 'prj_pd',
    territory: 'United States & Canada',
    language: 'English (Original Master)',
    videoStatus: 'Master Ready',
    audioStatus: '5.1 Master',
    captionsStatus: 'SDH Passed',
    artworkStatus: 'Localized Approved',
    rightsStatus: 'Cleared',
    overallStatus: 'Ready for Delivery'
  },
  {
    id: 'loc_pd_uk',
    projectId: 'prj_pd',
    territory: 'United Kingdom & Ireland',
    language: 'English (UK Broadcast Spec)',
    videoStatus: 'Master Ready',
    audioStatus: '5.1 Master',
    captionsStatus: 'SDH Passed',
    artworkStatus: 'Localized Approved',
    rightsStatus: 'Cleared',
    overallStatus: 'Ready for Delivery'
  },
  {
    id: 'loc_pd_latam',
    projectId: 'prj_pd',
    territory: 'Latin America',
    language: 'Spanish (neutral) & Portuguese',
    videoStatus: 'Master Ready',
    audioStatus: 'Dubbed Ready',
    captionsStatus: 'SDH Passed',
    artworkStatus: 'Localized Approved',
    rightsStatus: 'Cleared',
    overallStatus: 'Ready for Delivery'
  },
  {
    id: 'loc_pd_jp',
    projectId: 'prj_pd',
    territory: 'Japan',
    language: 'Japanese (Dub & Sub)',
    videoStatus: 'Master Ready',
    audioStatus: 'Dubbed Ready',
    captionsStatus: 'Subtitles Pending',
    artworkStatus: 'Pending Approval',
    rightsStatus: 'Cleared',
    overallStatus: 'In Progress',
    blockingReason: 'Japanese caption file pending final broadcast rating verification.'
  },
  {
    id: 'loc_pd_de',
    projectId: 'prj_pd',
    territory: 'Germany / DACH',
    language: 'German (Dub & Sub)',
    videoStatus: 'Master Ready',
    audioStatus: 'Dubbed Ready',
    captionsStatus: 'SDH Passed',
    artworkStatus: 'Localized Approved',
    rightsStatus: 'Territory Restricted',
    overallStatus: 'Blocked',
    blockingReason: 'Music License ML-9042 (Synth Track) expiring in 12 days for European SVOD window.'
  }
];

export const INITIAL_DISTRIBUTION_ORDERS: DistributionOrder[] = [
  {
    id: 'ord_1001',
    orderNumber: 'DIST-2026-9901',
    projectId: 'prj_pd',
    partnerName: 'Paramount+ Global (North America)',
    territory: 'US & Canada',
    platform: 'Streaming SVOD',
    deadline: '2026-10-01',
    status: 'Package Built',
    qcPassed: true,
    deliveryPackageId: 'pkg_pd_us_01'
  },
  {
    id: 'ord_1002',
    orderNumber: 'DIST-2026-9902',
    projectId: 'prj_pd',
    partnerName: 'Sky Cinema UK',
    territory: 'United Kingdom',
    platform: 'Linear Broadcast',
    deadline: '2026-10-15',
    status: 'Assets Collected',
    qcPassed: true
  },
  {
    id: 'ord_1003',
    orderNumber: 'DIST-2026-9903',
    projectId: 'prj_pd',
    partnerName: 'Paramount+ Germany',
    territory: 'Germany',
    platform: 'Streaming SVOD',
    deadline: '2026-10-20',
    status: 'Order Received',
    qcPassed: false
  }
];

export const INITIAL_RIGHTS_RECORDS: RightsRecord[] = [
  {
    id: 'rgt_m101',
    projectId: 'prj_pd',
    title: 'Track: "Midnight Pulse" by Synthwave Collective',
    rightsType: 'Music License',
    licensorName: 'Universal Music Publishing Group',
    territories: ['Worldwide'],
    platforms: ['Streaming SVOD', 'Linear Broadcast'],
    startDate: '2025-09-01',
    endDate: '2026-10-03', // Expiring soon!
    usageRestrictions: 'Master synchronisation rights valid for 13 months. Renewal required for DACH distribution after Oct 3.',
    status: 'Expiring Soon',
    responsibleOwner: 'Rachel Sterling',
    feeAmount: 45000
  },
  {
    id: 'rgt_t202',
    projectId: 'prj_tlo',
    title: 'Lead Talent Agreement - Jessica Chastain',
    rightsType: 'Talent Agreement',
    licensorName: 'CAA / Talent Counsel',
    territories: ['Worldwide'],
    platforms: ['Theatrical', 'SVOD', 'VOD', 'Physical Media'],
    startDate: '2026-01-01',
    endDate: '2036-01-01',
    usageRestrictions: 'Standard 10-year global exclusivity with promo publicity obligations.',
    status: 'Approved',
    responsibleOwner: 'Rachel Sterling',
    feeAmount: 12000000
  },
  {
    id: 'rgt_loc303',
    projectId: 'prj_pd',
    title: 'San Pedro Port Authority Location Agreement',
    rightsType: 'Location Release',
    licensorName: 'Port of Los Angeles Board of Harbor Commissioners',
    territories: ['Worldwide'],
    platforms: ['All Media'],
    startDate: '2026-08-01',
    endDate: '2031-08-01',
    usageRestrictions: 'Filming permitted Dock 44 only.',
    status: 'Approved',
    responsibleOwner: 'Rachel Sterling',
    feeAmount: 85000
  }
];

export const INITIAL_PURCHASE_ORDERS: PurchaseOrder[] = [
  {
    id: 'po_9001',
    poNumber: 'PO-2026-7811',
    projectId: 'prj_tlo',
    department: 'Camera & Optics',
    vendorName: 'Panavision Hollywood',
    description: 'Arri Alexa 35 Camera Package & Anamorphic T-Series Lens Rental (6 Weeks)',
    amount: 142000,
    status: 'Approved',
    createdDate: '2026-08-12'
  },
  {
    id: 'po_9002',
    poNumber: 'PO-2026-7812',
    projectId: 'prj_tlo',
    department: 'VFX',
    vendorName: 'Industrial Light & Magic',
    description: 'Milestone 2 Deposit - Hero Space Station Sequence 101 Rendering',
    amount: 850000,
    status: 'Approved',
    createdDate: '2026-08-20'
  },
  {
    id: 'po_9003',
    poNumber: 'PO-2026-7813',
    projectId: 'prj_tlo',
    department: 'Stunts & Rigging',
    vendorName: 'Zero-G Rigging Solutions Inc',
    description: 'Stage 14 Hydraulic Harness Maintenance & Load Certification',
    amount: 28500,
    status: 'Pending Approval',
    createdDate: '2026-09-19'
  }
];

export const INITIAL_FINANCE_DEPARTMENTS: DepartmentBudget[] = [
  { department: 'Above The Line (Story, Cast, Director)', originalBudget: 42000000, revisedBudget: 42000000, committedCost: 42000000, actualCost: 38500000, forecastFinal: 42000000 },
  { department: 'Production Staff & Management', originalBudget: 9500000, revisedBudget: 9800000, committedCost: 9200000, actualCost: 7100000, forecastFinal: 9800000 },
  { department: 'Stage & Set Construction', originalBudget: 18000000, revisedBudget: 19200000, committedCost: 19100000, actualCost: 18800000, forecastFinal: 19200000 },
  { department: 'Camera & Electrical / Grip', originalBudget: 12500000, revisedBudget: 12500000, committedCost: 11800000, actualCost: 8900000, forecastFinal: 12500000 },
  { department: 'Visual Effects (VFX)', originalBudget: 35000000, revisedBudget: 36800000, committedCost: 32000000, actualCost: 14200000, forecastFinal: 36800000 },
  { department: 'Post-Production Sound & Picture', originalBudget: 8000000, revisedBudget: 8000000, committedCost: 6500000, actualCost: 1200000, forecastFinal: 8000000 },
  { department: 'Insurance, Legal & Contingency', originalBudget: 20000000, revisedBudget: 19500000, committedCost: 14000000, actualCost: 9700000, forecastFinal: 19500000 }
];

export const INITIAL_MARKETING_CAMPAIGNS: MarketingCampaign[] = [
  {
    id: 'mkt_tlo',
    projectId: 'prj_tlo',
    campaignName: 'THE LAST ORBIT — Global Teaser & Comic-Con Reveal',
    territory: 'Worldwide',
    targetLaunchDate: '2027-07-15',
    trailersApproved: 1,
    trailersTotal: 3,
    postersApproved: 4,
    socialAssetsReady: 18,
    status: 'Asset Creation',
    leadExec: 'Eleanor Vance'
  },
  {
    id: 'mkt_pd',
    projectId: 'prj_pd',
    campaignName: 'PACIFIC DIVISION S1 — Paramount+ Global Premiere',
    territory: 'Worldwide',
    targetLaunchDate: '2026-11-01',
    trailersApproved: 3,
    trailersTotal: 3,
    postersApproved: 8,
    socialAssetsReady: 45,
    status: 'Approved',
    leadExec: 'Marcus Thorne'
  }
];

export const INITIAL_FACILITIES: StudioFacility[] = [
  { id: 'fac_s14', name: 'Sound Stage 14 (Zero-G Spec)', building: 'Melrose North Lot', type: 'Sound Stage', squareFeet: 22000, dailyRate: 18500, status: 'Occupied', currentProject: 'THE LAST ORBIT' },
  { id: 'fac_s05', name: 'Sound Stage 5 (Air Lock Set)', building: 'Melrose North Lot', type: 'Sound Stage', squareFeet: 16500, dailyRate: 14000, status: 'Occupied', currentProject: 'THE LAST ORBIT' },
  { id: 'fac_s12', name: 'Sound Stage 12 (High Bay)', building: 'Gower Street Lot', type: 'Sound Stage', squareFeet: 28000, dailyRate: 22000, status: 'Reserved', currentProject: 'THE GLASS KINGDOM' },
  { id: 'fac_scrA', name: 'Sherry Lansing Screening Room', building: 'Executive Building A', type: 'Screening Room', squareFeet: 4200, dailyRate: 4500, status: 'Available' },
  { id: 'fac_edt01', name: 'Editorial Suite 101 (Avid Nexis)', building: 'Post Production Center', type: 'Edit Suite', squareFeet: 850, dailyRate: 1200, status: 'Occupied', currentProject: 'PACIFIC DIVISION' },
  { id: 'fac_col01', name: 'Color Suite Alpha (Baselight 4K)', building: 'Post Production Center', type: 'Color Suite', squareFeet: 900, dailyRate: 2800, status: 'Available' },
  { id: 'fac_bkny', name: 'New York Backlot Street Set', building: 'Paramount Backlot', type: 'Backlot Set', squareFeet: 85000, dailyRate: 25000, status: 'Available' }
];

export const INITIAL_FACILITY_BOOKINGS: FacilityBooking[] = [
  { id: 'fb_1', facilityId: 'fac_s14', facilityName: 'Sound Stage 14', projectId: 'prj_tlo', startDate: '2026-08-01', endDate: '2026-10-31', requestedBy: 'Sarah Connor', status: 'Confirmed' },
  { id: 'fb_2', facilityId: 'fac_scrA', facilityName: 'Sherry Lansing Screening Room', projectId: 'prj_pd', startDate: '2026-09-22', endDate: '2026-09-22', requestedBy: 'Marcus Thorne', status: 'Confirmed' }
];

export const INITIAL_SUSTAINABILITY: SustainabilityMetrics[] = [
  {
    projectId: 'prj_tlo',
    electricityKwhEstimated: 420000,
    electricityKwhReported: 385000,
    fuelGallonsEstimated: 12500,
    flightsCount: 42,
    wasteTonsRecycled: 18.5,
    co2EmissionsTonsEstimated: 312,
    sustainabilityRating: 'A'
  },
  {
    projectId: 'prj_pd',
    electricityKwhEstimated: 210000,
    electricityKwhReported: 205000,
    fuelGallonsEstimated: 8400,
    flightsCount: 28,
    wasteTonsRecycled: 12.1,
    co2EmissionsTonsEstimated: 184,
    sustainabilityRating: 'A+'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  { id: 'aud_101', timestamp: '2026-09-21T08:30:00Z', userEmail: 'e.vance@paramount.com', userRole: 'Executive', action: 'PROJECT_STAGE_CHANGED', targetEntity: 'THE LAST ORBIT', details: 'Confirmed transition from Pre-Production to Production stage.', ipAddress: '10.240.12.88' },
  { id: 'aud_102', timestamp: '2026-09-20T18:00:00Z', userEmail: 's.connor@paramount.com', userRole: 'Production Manager', action: 'CALL_SHEET_PUBLISHED', targetEntity: 'Call Sheet #38 (Stage 14)', details: 'Published official call sheet for Day 38 with safety advisories.', ipAddress: '10.240.14.12' },
  { id: 'aud_103', timestamp: '2026-09-19T11:20:00Z', userEmail: 'r.sterling@paramount.com', userRole: 'Legal Reviewer', action: 'RIGHTS_WARNING_FLAGGED', targetEntity: 'Track ML-9042', details: 'Flagged 30-day music license expiration for DACH territory.', ipAddress: '10.240.18.5' }
];

export const INITIAL_EVENTS: StudioEvent[] = [
  { id: 'evt_1', type: 'SCHEDULE_CHANGED', timestamp: '2026-09-21T08:15:00Z', projectId: 'prj_tlo', title: 'Schedule Update Day 38', description: 'Zero-G Wire Harness test completed. Shooting commenced on Stage 14.', affectedEntity: 'Stage 14 Schedule', severity: 'Info', triggeredBy: 'Sarah Connor' },
  { id: 'evt_2', type: 'RIGHTS_EXPIRY_DETECTED', timestamp: '2026-09-20T14:00:00Z', projectId: 'prj_pd', title: 'Music License Expiration Warning', description: 'Music track "Midnight Pulse" license expires in 12 days for European SVOD window.', affectedEntity: 'DACH Delivery Package', severity: 'Warning', triggeredBy: 'Automated Rights Engine' },
  { id: 'evt_3', type: 'MEDIA_INGEST_FAILED', timestamp: '2026-09-21T08:00:00Z', projectId: 'prj_pd', title: 'Ingest Checksum Mismatch', description: 'File PACIFIC_DIV_EP108_B_ROLL.MOV failed checksum verification.', affectedEntity: 'Media Asset Storage', severity: 'Critical', triggeredBy: 'San Diego SAN Ingest Node 02' }
];

export const INITIAL_NOTIFICATIONS: Notification[] = [
  { id: 'notif_1', title: 'Music License Warning', message: 'Rights record rgt_m101 ("Midnight Pulse") expires on 2026-10-03. DACH delivery blocked.', timestamp: '10 mins ago', type: 'Warning', linkTab: 'rights', projectId: 'prj_pd', read: false },
  { id: 'notif_2', title: 'Ingest Exception Detected', message: 'Transfer job job_ing_880 failed checksum verification.', timestamp: '45 mins ago', type: 'Alert', linkTab: 'media', projectId: 'prj_pd', read: false },
  { id: 'notif_3', title: 'Call Sheet #38 Published', message: 'Main Unit call sheet for Stage 14 zero-G shoot is active.', timestamp: '2 hours ago', type: 'Success', linkTab: 'scheduling', projectId: 'prj_tlo', read: true }
];
