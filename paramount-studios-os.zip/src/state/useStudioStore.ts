import { create } from 'zustand';
import {
  Project,
  Scene,
  CastMember,
  CrewMember,
  CallSheet,
  DailyProductionReport,
  IncidentReport,
  ShootingDay,
  ScheduleConflict,
  MediaAsset,
  IngestJob,
  SANVolume,
  PostStage,
  PostCut,
  PostComment,
  ReviewFrameComment,
  VFXShot,
  VFXVendor,
  LocalisationMatrixItem,
  DistributionOrder,
  RightsRecord,
  PurchaseOrder,
  DepartmentBudget,
  MarketingCampaign,
  StudioFacility,
  FacilityBooking,
  SustainabilityMetrics,
  StudioEvent,
  AuditLogEntry,
  Notification,
  UserProfile,
  UserRole
} from '../types';

import {
  DEMO_USERS,
  INITIAL_PROJECTS,
  INITIAL_SCENES,
  INITIAL_CAST,
  INITIAL_CREW,
  INITIAL_CALL_SHEETS,
  INITIAL_DAILY_REPORTS,
  INITIAL_INCIDENTS,
  INITIAL_SHOOTING_DAYS,
  INITIAL_MEDIA_ASSETS,
  INITIAL_INGEST_JOBS,
  INITIAL_POST_STAGES,
  INITIAL_REVIEW_COMMENTS,
  INITIAL_VFX_SHOTS,
  INITIAL_LOCALISATION_MATRICES,
  INITIAL_DISTRIBUTION_ORDERS,
  INITIAL_RIGHTS_RECORDS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_FINANCE_DEPARTMENTS,
  INITIAL_MARKETING_CAMPAIGNS,
  INITIAL_FACILITIES,
  INITIAL_FACILITY_BOOKINGS,
  INITIAL_SUSTAINABILITY,
  INITIAL_AUDIT_LOGS,
  INITIAL_EVENTS,
  INITIAL_NOTIFICATIONS
} from '../data/seedData';

export type WorkspaceTab =
  | 'command'
  | 'slate'
  | 'development'
  | 'productions'
  | 'scheduling'
  | 'media'
  | 'post'
  | 'vfx'
  | 'distribution'
  | 'finance'
  | 'rights'
  | 'marketing'
  | 'facilities'
  | 'sustainability'
  | 'analytics'
  | 'administration';

interface StudioState {
  // Navigation & User Context
  activeTab: WorkspaceTab;
  setActiveTab: (tab: WorkspaceTab) => void;
  selectedProjectId: string;
  setSelectedProjectId: (id: string) => void;
  currentUser: UserProfile;
  setCurrentUser: (user: UserProfile) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isCommandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;
  isDeveloperConsoleOpen: boolean;
  setDeveloperConsoleOpen: (open: boolean) => void;
  isNotificationPanelOpen: boolean;
  setNotificationPanelOpen: (open: boolean) => void;

  // Domain Collections
  projects: Project[];
  scenes: Scene[];
  cast: CastMember[];
  crew: CrewMember[];
  callSheets: CallSheet[];
  dailyReports: DailyProductionReport[];
  incidents: IncidentReport[];
  shootingDays: ShootingDay[];
  conflicts: ScheduleConflict[];
  mediaAssets: MediaAsset[];
  ingestJobs: IngestJob[];
  sanVolumes: SANVolume[];
  postStages: PostStage[];
  postCuts: PostCut[];
  postComments: PostComment[];
  reviewComments: ReviewFrameComment[];
  vfxShots: VFXShot[];
  vfxVendors: VFXVendor[];
  localisationItems: LocalisationMatrixItem[];
  localisationMatrix: LocalisationMatrixItem[];
  distributionOrders: DistributionOrder[];
  rightsRecords: RightsRecord[];
  purchaseOrders: PurchaseOrder[];
  departmentBudgets: DepartmentBudget[];
  marketingCampaigns: MarketingCampaign[];
  facilities: StudioFacility[];
  soundStages: StudioFacility[];
  facilityBookings: FacilityBooking[];
  stageBookings: FacilityBooking[];
  sustainability: SustainabilityMetrics[];
  events: StudioEvent[];
  auditLogs: AuditLogEntry[];
  notifications: Notification[];

  // Operational Simulation & Business Logic Actions
  dispatchEvent: (event: Omit<StudioEvent, 'id' | 'timestamp'>) => void;
  
  // Scene Breakdown Actions
  addScene: (scene: Scene) => void;
  updateScene: (sceneId: string, updates: Partial<Scene>) => void;
  
  // Greenlight & Slate
  greenlightProject: (projectId: string, productionBudget: number) => void;
  
  // Simulation Events (Cross-module reactive modeling)
  triggerScheduleDelay: (projectId: string, delayDays: number, reason: string) => void;
  triggerIngestFailure: (jobId: string, reason: string) => void;
  triggerQCFailure: (assetId: string, note: string) => void;
  triggerRightsExpiry: (rightsId: string) => void;
  approveVFXShot: (shotId: string) => void;
  createPurchaseOrder: (po: Omit<PurchaseOrder, 'id' | 'poNumber' | 'createdDate'>) => void;
  approvePurchaseOrder: (poId: string) => void;
  bookFacility: (booking: Omit<FacilityBooking, 'id' | 'status'>) => void;
  addReviewComment: (comment: Omit<ReviewFrameComment, 'id' | 'createdAt'>) => void;
  addPostComment: (comment: PostComment) => void;
  resolvePostComment: (commentId: string) => void;
  markNotificationRead: (notifId: string) => void;
  clearAllNotifications: () => void;
  advanceSimulatedTimeHours: (hours: number) => void;
  resetDemoData: () => void;

}

export const useStudioStore = create<StudioState>((set, get) => ({
  activeTab: 'command',
  setActiveTab: (tab) => set({ activeTab: tab }),
  selectedProjectId: 'prj_tlo', // Default to "THE LAST ORBIT"
  setSelectedProjectId: (id) => set({ selectedProjectId: id }),
  currentUser: DEMO_USERS[0],
  setCurrentUser: (user) => set({ currentUser: user }),
  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
  isCommandPaletteOpen: false,
  setCommandPaletteOpen: (open) => set({ isCommandPaletteOpen: open }),
  isDeveloperConsoleOpen: false,
  setDeveloperConsoleOpen: (open) => set({ isDeveloperConsoleOpen: open }),
  isNotificationPanelOpen: false,
  setNotificationPanelOpen: (open) => set({ isNotificationPanelOpen: open }),

  // Collections
  projects: INITIAL_PROJECTS,
  scenes: INITIAL_SCENES,
  cast: INITIAL_CAST,
  crew: INITIAL_CREW,
  callSheets: INITIAL_CALL_SHEETS,
  dailyReports: INITIAL_DAILY_REPORTS,
  incidents: INITIAL_INCIDENTS,
  shootingDays: INITIAL_SHOOTING_DAYS,
  conflicts: [
    {
      id: 'cnf_101',
      type: 'Turnaround Constraint',
      entityName: 'Lead Cast - Jessica Chastain',
      description: 'Stage 14 shoot scheduled wrap at 19:00, but call on Stage 5 next day is 06:00 (11hr turnaround limit warning).',
      severity: 'Warning',
      affectedDate: '2026-09-22'
    }
  ],
  mediaAssets: INITIAL_MEDIA_ASSETS,
  ingestJobs: INITIAL_INGEST_JOBS,
  sanVolumes: [
    { id: 'vol_san_1', volumeName: 'PAR-SAN Cluster Alpha (4.5K Raw)', totalTb: 450, usedTb: 320, availableTb: 130, healthStatus: 'Optimal' },
    { id: 'vol_san_2', volumeName: 'PAR-SAN Cluster Beta (Dailies Proxy)', totalTb: 200, usedTb: 85, availableTb: 115, healthStatus: 'Optimal' },
    { id: 'vol_san_3', volumeName: 'PAR-SAN Cluster Gamma (VFX Archive)', totalTb: 350, usedTb: 290, availableTb: 60, healthStatus: 'Near Capacity' }
  ],
  postStages: INITIAL_POST_STAGES,
  postCuts: [
    { id: 'cut_101', projectId: 'prj_tlo', cutName: 'Director’s Cut v3.2', versionTag: 'v3.2-DIR-LOCKED', duration: '02:08:44:12' }
  ],
  postComments: [
    { id: 'pcmt_1', cutId: 'cut_101', authorName: 'Director', department: 'Director', timecode: '01:14:22:18', frameNumber: 1342, text: 'Trim 6 frames before explosion cut. Audio punch-up needed on Ch 2.', resolved: false, timestamp: '10:14 AM' },
    { id: 'pcmt_2', cutId: 'cut_101', authorName: 'VFX Supervisor', department: 'VFX', timecode: '01:18:05:02', frameNumber: 2100, text: 'Hero zero-G wire cleanup complete in ILM shot TLO_101_010.', resolved: true, timestamp: '11:30 AM' }
  ],
  reviewComments: INITIAL_REVIEW_COMMENTS,
  vfxShots: INITIAL_VFX_SHOTS,
  vfxVendors: [
    { id: 'ven_ilm', vendorName: 'Industrial Light & Magic (ILM)', totalBidAmount: 8500000, allocatedShots: 142, deliveredShots: 98, qualityScore: 9.8 },
    { id: 'ven_weta', vendorName: 'Wētā FX', totalBidAmount: 6200000, allocatedShots: 84, deliveredShots: 65, qualityScore: 9.7 },
    { id: 'ven_framestore', vendorName: 'Framestore', totalBidAmount: 3800000, allocatedShots: 52, deliveredShots: 40, qualityScore: 9.5 }
  ],
  localisationItems: INITIAL_LOCALISATION_MATRICES,
  localisationMatrix: INITIAL_LOCALISATION_MATRICES,
  distributionOrders: INITIAL_DISTRIBUTION_ORDERS,
  rightsRecords: INITIAL_RIGHTS_RECORDS,
  purchaseOrders: INITIAL_PURCHASE_ORDERS,
  departmentBudgets: INITIAL_FINANCE_DEPARTMENTS,
  marketingCampaigns: INITIAL_MARKETING_CAMPAIGNS,
  facilities: INITIAL_FACILITIES,
  soundStages: INITIAL_FACILITIES,
  facilityBookings: INITIAL_FACILITY_BOOKINGS,
  stageBookings: INITIAL_FACILITY_BOOKINGS,
  sustainability: INITIAL_SUSTAINABILITY,
  events: INITIAL_EVENTS,
  auditLogs: INITIAL_AUDIT_LOGS,
  notifications: INITIAL_NOTIFICATIONS,

  // Event Bus Publisher
  dispatchEvent: (eventData) => {
    const id = `evt_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const timestamp = new Date().toISOString();
    const newEvent: StudioEvent = { ...eventData, id, timestamp };

    const auditEntry: AuditLogEntry = {
      id: `aud_${Date.now()}`,
      timestamp,
      userEmail: get().currentUser.email,
      userRole: get().currentUser.role,
      action: eventData.type,
      targetEntity: eventData.affectedEntity,
      details: eventData.description,
      ipAddress: '10.240.12.99'
    };

    const newNotification: Notification = {
      id: `notif_${Date.now()}`,
      title: eventData.title || eventData.type,
      message: eventData.description,
      timestamp: 'Just now',
      type: eventData.severity === 'Critical' ? 'Alert' : eventData.severity === 'Warning' ? 'Warning' : 'Info',
      read: false,
      projectId: eventData.projectId
    };

    set((state) => ({
      events: [newEvent, ...state.events],
      auditLogs: [auditEntry, ...state.auditLogs],
      notifications: [newNotification, ...state.notifications]
    }));
  },

  // Scene Breakdown
  addScene: (newScene) => {
    set((state) => ({ scenes: [...state.scenes, newScene] }));
    get().dispatchEvent({
      type: 'SCHEDULE_CHANGED',
      projectId: newScene.projectId,
      title: `New Scene Added: #${newScene.sceneNumber}`,
      description: `Scene #${newScene.sceneNumber} (${newScene.heading}) added to breakdown. Estimated shooting time: ${newScene.estimatedMinutes} mins.`,
      affectedEntity: `Script Breakdown Scene ${newScene.sceneNumber}`,
      severity: 'Info',
      triggeredBy: get().currentUser.name
    });
  },

  updateScene: (sceneId, updates) => {
    set((state) => ({
      scenes: state.scenes.map((s) => (s.id === sceneId ? { ...s, ...updates } : s))
    }));
  },

  // Greenlight workflow
  greenlightProject: (projectId, productionBudget) => {
    set((state) => ({
      projects: state.projects.map((p) =>
        p.id === projectId
          ? {
              ...p,
              currentStage: 'Greenlit',
              productionBudget,
              forecastCost: productionBudget,
              riskRating: 'Low'
            }
          : p
      )
    }));

    const proj = get().projects.find((p) => p.id === projectId);
    get().dispatchEvent({
      type: 'GREENLIGHT_APPROVED',
      projectId,
      title: `Greenlight Approved: ${proj?.title}`,
      description: `Official studio greenlight granted. Approved production budget envelope: $${(productionBudget / 1000000).toFixed(1)}M.`,
      affectedEntity: proj?.title || 'Project Slate',
      previousState: 'Development',
      newState: 'Greenlit',
      severity: 'Info',
      triggeredBy: get().currentUser.name
    });
  },

  // Cross-module simulation events
  triggerScheduleDelay: (projectId, delayDays, reason) => {
    const proj = get().projects.find((p) => p.id === projectId);
    const addedCost = delayDays * 185000; // $185k per shooting day cost

    set((state) => ({
      projects: state.projects.map((p) =>
        p.id === projectId
          ? {
              ...p,
              riskRating: 'High',
              forecastCost: p.forecastCost + addedCost
            }
          : p
      ),
      shootingDays: state.shootingDays.map((sd) =>
        sd.projectId === projectId && sd.status === 'Scheduled'
          ? { ...sd, status: 'Delayed', delayReason: reason }
          : sd
      ),
      incidents: [
        {
          id: `inc_${Date.now()}`,
          projectId,
          date: new Date().toISOString().split('T')[0],
          severity: 'Moderate',
          category: 'Schedule',
          description: `Production delay of ${delayDays} days triggered: ${reason}.`,
          affectedDepartment: 'Physical Production & Stage Management',
          status: 'Open',
          actionTaken: 'Re-evaluating Stage 14 booking duration and crew turnaround.'
        },
        ...state.incidents
      ]
    }));

    get().dispatchEvent({
      type: 'SCHEDULE_CHANGED',
      projectId,
      title: `Schedule Delay Triggered (${delayDays} Days)`,
      description: `Production delay of ${delayDays} days for ${proj?.title}: ${reason}. Cost variance forecast increased by +$${(addedCost / 1000).toFixed(0)}k.`,
      affectedEntity: `${proj?.title} Production Schedule`,
      previousState: 'On Schedule',
      newState: `${delayDays}-Day Delay`,
      severity: 'Warning',
      triggeredBy: 'Developer Simulator'
    });
  },

  triggerIngestFailure: (jobId, reason) => {
    set((state) => ({
      ingestJobs: state.ingestJobs.map((j) =>
        j.id === jobId ? { ...j, status: 'Failed', errorDetails: reason } : j
      )
    }));

    const job = get().ingestJobs.find((j) => j.id === jobId);

    get().dispatchEvent({
      type: 'MEDIA_INGEST_FAILED',
      projectId: job?.projectId,
      title: `Media Ingest Failed: ${job?.assetTitle}`,
      description: `Ingest job ${jobId} failed during checksum/validation: ${reason}.`,
      affectedEntity: job?.assetTitle || 'Media Asset Ingest',
      severity: 'Critical',
      triggeredBy: 'Developer Simulator'
    });
  },

  triggerQCFailure: (assetId, note) => {
    set((state) => ({
      mediaAssets: state.mediaAssets.map((a) =>
        a.id === assetId ? { ...a, qcStatus: 'QC Failed', qcReportNote: note } : a
      ),
      distributionOrders: state.distributionOrders.map((d) => ({
        ...d,
        status: d.status === 'Package Built' ? 'Assets Collected' : d.status,
        qcPassed: false
      }))
    }));

    const asset = get().mediaAssets.find((a) => a.id === assetId);

    get().dispatchEvent({
      type: 'QC_FAILURE_RECORDED',
      projectId: asset?.projectId,
      title: `QC Inspection Failed: ${asset?.title}`,
      description: `QC failure recorded for ${asset?.title}: ${note}. Related delivery packages blocked.`,
      affectedEntity: asset?.title || 'QC Pipeline',
      previousState: 'Processing QC',
      newState: 'QC Failed',
      severity: 'Critical',
      triggeredBy: 'Developer Simulator'
    });
  },

  triggerRightsExpiry: (rightsId) => {
    set((state) => ({
      rightsRecords: state.rightsRecords.map((r) =>
        r.id === rightsId ? { ...r, status: 'Expired' } : r
      ),
      localisationItems: state.localisationItems.map((loc) =>
        loc.projectId === 'prj_pd'
          ? { ...loc, rightsStatus: 'Territory Restricted', overallStatus: 'Blocked', blockingReason: 'Licence expired.' }
          : loc
      )
    }));

    const rec = get().rightsRecords.find((r) => r.id === rightsId);

    get().dispatchEvent({
      type: 'RIGHTS_EXPIRY_DETECTED',
      projectId: rec?.projectId,
      title: `Rights License Expired: ${rec?.title}`,
      description: `Music/Talent rights record ${rec?.title} has EXPIRED. Global delivery matrices for affected territories set to BLOCKED.`,
      affectedEntity: rec?.title || 'Legal Rights Engine',
      previousState: 'Expiring Soon',
      newState: 'Expired',
      severity: 'Critical',
      triggeredBy: 'Developer Simulator'
    });
  },

  approveVFXShot: (shotId) => {
    set((state) => ({
      vfxShots: state.vfxShots.map((s) =>
        s.id === shotId ? { ...s, status: 'Approved' } : s
      )
    }));

    const shot = get().vfxShots.find((s) => s.id === shotId);

    get().dispatchEvent({
      type: 'VFX_SHOT_APPROVED',
      projectId: shot?.projectId,
      title: `VFX Shot Approved: ${shot?.shotId}`,
      description: `Shot ${shot?.shotId} (${shot?.description}) approved by VFX Supervisor & Director.`,
      affectedEntity: `VFX Shot ${shot?.shotId}`,
      previousState: shot?.status,
      newState: 'Approved',
      severity: 'Info',
      triggeredBy: get().currentUser.name
    });
  },

  createPurchaseOrder: (poData) => {
    const id = `po_${Date.now()}`;
    const poNumber = `PO-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const createdDate = new Date().toISOString().split('T')[0];

    const newPO: PurchaseOrder = {
      ...poData,
      id,
      poNumber,
      status: 'Approved',
      createdDate
    };

    set((state) => ({
      purchaseOrders: [newPO, ...state.purchaseOrders],
      departmentBudgets: state.departmentBudgets.map((dept) =>
        dept.department.includes(poData.department)
          ? { ...dept, committedCost: dept.committedCost + poData.amount }
          : dept
      )
    }));

    get().dispatchEvent({
      type: 'BUDGET_VARIANCE_UPDATED',
      projectId: poData.projectId,
      title: `New PO Issued: ${poNumber}`,
      description: `Issued PO ${poNumber} for $${poData.amount.toLocaleString()} to ${poData.vendorName} (${poData.department}).`,
      affectedEntity: poNumber,
      severity: 'Info',
      triggeredBy: get().currentUser.name
    });
  },

  approvePurchaseOrder: (poId) => {
    set((state) => ({
      purchaseOrders: state.purchaseOrders.map((p) =>
        p.id === poId ? { ...p, status: 'Approved' } : p
      )
    }));
  },

  addPostComment: (comment) => {
    set((state) => ({
      postComments: [comment, ...state.postComments]
    }));
  },

  resolvePostComment: (commentId) => {
    set((state) => ({
      postComments: state.postComments.map((c) =>
        c.id === commentId ? { ...c, resolved: true } : c
      )
    }));
  },


  bookFacility: (bookingData) => {
    const id = `fb_${Date.now()}`;
    const newBooking: FacilityBooking = {
      ...bookingData,
      id,
      status: 'Confirmed'
    };

    set((state) => ({
      facilityBookings: [newBooking, ...state.facilityBookings],
      facilities: state.facilities.map((f) =>
        f.id === bookingData.facilityId
          ? { ...f, status: 'Occupied', currentProject: bookingData.projectId }
          : f
      )
    }));

    get().dispatchEvent({
      type: 'FACILITY_BOOKING_CONFLICT',
      projectId: bookingData.projectId,
      title: `Facility Booked: ${bookingData.facilityName}`,
      description: `${bookingData.facilityName} booked from ${bookingData.startDate} to ${bookingData.endDate}.`,
      affectedEntity: bookingData.facilityName,
      severity: 'Info',
      triggeredBy: get().currentUser.name
    });
  },

  addReviewComment: (commentData) => {
    const newComment: ReviewFrameComment = {
      ...commentData,
      id: `com_${Date.now()}`,
      createdAt: new Date().toISOString()
    };

    set((state) => ({
      reviewComments: [...state.reviewComments, newComment]
    }));
  },

  markNotificationRead: (notifId) => {
    set((state) => ({
      notifications: state.notifications.map((n) =>
        n.id === notifId ? { ...n, read: true } : n
      )
    }));
  },

  clearAllNotifications: () => {
    set({ notifications: [] });
  },

  advanceSimulatedTimeHours: (hours) => {
    set((state) => ({
      ingestJobs: state.ingestJobs.map((j) => {
        if (j.status !== 'In Progress') return j;
        const newProgress = Math.min(100, j.progressPercent + hours * 25);
        return {
          ...j,
          progressPercent: newProgress,
          status: newProgress === 100 ? 'Completed' : 'In Progress',
          completedAt: newProgress === 100 ? new Date().toISOString() : undefined
        };
      })
    }));

    get().dispatchEvent({
      type: 'SIMULATION_ADVANCED',
      title: `Simulated Time Advanced +${hours} Hours`,
      description: `Studio clock advanced by ${hours} hour(s). Background ingest, proxy generation & transcode queues updated.`,
      affectedEntity: 'Studio Clock Simulation',
      severity: 'Info',
      triggeredBy: 'Developer Simulator'
    });
  },

  resetDemoData: () => {
    set({
      projects: INITIAL_PROJECTS,
      scenes: INITIAL_SCENES,
      cast: INITIAL_CAST,
      crew: INITIAL_CREW,
      callSheets: INITIAL_CALL_SHEETS,
      dailyReports: INITIAL_DAILY_REPORTS,
      incidents: INITIAL_INCIDENTS,
      shootingDays: INITIAL_SHOOTING_DAYS,
      mediaAssets: INITIAL_MEDIA_ASSETS,
      ingestJobs: INITIAL_INGEST_JOBS,
      postStages: INITIAL_POST_STAGES,
      reviewComments: INITIAL_REVIEW_COMMENTS,
      vfxShots: INITIAL_VFX_SHOTS,
      localisationItems: INITIAL_LOCALISATION_MATRICES,
      distributionOrders: INITIAL_DISTRIBUTION_ORDERS,
      rightsRecords: INITIAL_RIGHTS_RECORDS,
      purchaseOrders: INITIAL_PURCHASE_ORDERS,
      departmentBudgets: INITIAL_FINANCE_DEPARTMENTS,
      marketingCampaigns: INITIAL_MARKETING_CAMPAIGNS,
      facilities: INITIAL_FACILITIES,
      facilityBookings: INITIAL_FACILITY_BOOKINGS,
      sustainability: INITIAL_SUSTAINABILITY,
      events: INITIAL_EVENTS,
      auditLogs: INITIAL_AUDIT_LOGS,
      notifications: INITIAL_NOTIFICATIONS
    });
  }
}));
