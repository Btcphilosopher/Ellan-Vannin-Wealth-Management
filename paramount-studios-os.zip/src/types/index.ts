/**
 * Paramount Studios Enterprise Production OS (Codename: MOUNTAIN)
 * Domain Models & Type Definitions
 */

export type ProjectStage =
  | 'Idea'
  | 'Submitted'
  | 'Under Review'
  | 'Development'
  | 'Budgeting'
  | 'Greenlit'
  | 'Pre-Production'
  | 'Production'
  | 'Post-Production'
  | 'Delivery'
  | 'Released'
  | 'Archived'
  | 'Cancelled';

export type ProjectFormat =
  | 'Feature Film'
  | 'Drama Series'
  | 'Procedural Series'
  | 'Limited Series'
  | 'Unscripted Docuseries'
  | 'Animated Series'
  | 'Live Event'
  | 'News & Sports';

export type StudioDivision =
  | 'Paramount Pictures'
  | 'Paramount Television Studios'
  | 'CBS Studios'
  | 'Paramount+ Originals'
  | 'MTV Entertainment'
  | 'Nickelodeon Animation';

export type RiskRating = 'Low' | 'Medium' | 'High' | 'Critical';
export type ConfidentialityLevel = 'Unclassified' | 'Internal' | 'Confidential' | 'Strictly Secret';

export interface Project {
  id: string;
  title: string;
  workingTitle: string;
  format: ProjectFormat;
  genre: string;
  logline: string;
  synopsis: string;
  creator: string;
  producer: string;
  productionCompany: string;
  studioDivision: StudioDivision;
  targetAudience: string;
  territory: string;
  plannedReleaseWindow: string;
  developmentBudget: number;
  productionBudget: number;
  actualCostToDate: number;
  forecastCost: number;
  currentStage: ProjectStage;
  riskRating: RiskRating;
  confidentiality: ConfidentialityLevel;
  assignedExecutives: string[];
  attachedDocuments: { id: string; name: string; type: string; date: string }[];
  updatedAt: string;
}

// Script Breakdown & Scene Models
export type TimeOfDay = 'DAY' | 'NIGHT' | 'DAWN' | 'DUSK';
export type IntExt = 'INT' | 'EXT' | 'INT_EXT';

export interface BreakdownItem {
  id: string;
  category: 'CHARACTER' | 'LOCATION' | 'PROP' | 'WARDROBE' | 'VEHICLE' | 'ANIMAL' | 'VFX' | 'STUNT' | 'SOUND' | 'EQUIPMENT';
  name: string;
  departmentNote?: string;
}

export interface Scene {
  id: string;
  projectId: string;
  sceneNumber: string;
  heading: string;
  locationName: string;
  timeOfDay: TimeOfDay;
  interiorExterior: IntExt;
  pageCount: number; // in 1/8ths or decimal
  estimatedMinutes: number;
  characters: string[];
  breakdownItems: BreakdownItem[];
  notes: string[];
  revisionId: string;
  scriptSnippet?: string;
  complexityScore: number; // 1-10
}

// Production & Call Sheets
export interface CastMember {
  id: string;
  characterName: string;
  actorName: string;
  roleType: 'Lead' | 'Supporting' | 'Guest' | 'Stunt Double' | 'Background';
  agencyContact: string;
  status: 'Contracted' | 'On Set' | 'Wrapped' | 'Standby';
  dailyRate: number;
}

export interface CrewMember {
  id: string;
  name: string;
  department: string;
  title: string;
  phone: string;
  radioChannel?: string;
}

export interface CallSheet {
  id: string;
  projectId: string;
  shootingDate: string;
  dayNumber: number;
  totalDays: number;
  unit: string;
  mainLocation: string;
  crewCallTime: string;
  castCallTime: string;
  firstShotTime: string;
  estimatedWrapTime: string;
  weatherSummary: string;
  highTemp: number;
  lowTemp: number;
  nearestHospital: string;
  safetyNotes: string[];
  scenesToShoot: string[]; // scene numbers
  status: 'Draft' | 'Under Review' | 'Approved' | 'Published';
  publishedAt?: string;
}

export interface DailyProductionReport {
  id: string;
  projectId: string;
  date: string;
  dayNumber: number;
  scenesCompleted: string[];
  scenesIncomplete: string[];
  pagesShot: number;
  actualSetupTime: string;
  actualWrapTime: string;
  delays: { reason: string; durationMinutes: number }[];
  incidents: string[];
  mediaCapturedGb: number;
  overtimeMinutes: number;
  notes: string;
}

export interface IncidentReport {
  id: string;
  projectId: string;
  date: string;
  severity: 'Minor' | 'Moderate' | 'Severe';
  category: 'Safety' | 'Technical' | 'Weather' | 'Schedule' | 'Facilities';
  description: string;
  affectedDepartment: string;
  status: 'Open' | 'Under Investigation' | 'Resolved';
  actionTaken: string;
}

// Scheduling & Gantt
export interface ShootingDay {
  id: string;
  projectId: string;
  date: string;
  dayNumber: number;
  scenes: string[];
  locationName: string;
  isNightShoot: boolean;
  isCompanyMove: boolean;
  status: 'Scheduled' | 'In Progress' | 'Completed' | 'Delayed';
  delayReason?: string;
}

export interface ScheduleConflict {
  id: string;
  type: 'Cast Overlap' | 'Location Booking' | 'Turnaround Constraint' | 'Equipment Shortage';
  entityName: string;
  description: string;
  severity: 'Warning' | 'Critical';
  affectedDate: string;
}

// Media & Ingest Pipeline
export type AssetType =
  | 'Camera Original'
  | 'Audio Recording'
  | 'Editorial Proxy'
  | 'Dailies'
  | 'VFX Plate'
  | 'Master Video'
  | 'Artwork'
  | 'Subtitles & Captions';

export type StorageTier = 'Hot High-Perf' | 'Nearline SAN' | 'Cold Cloud Archive' | 'LTO Tape Archive';
export type QCStatus = 'Pending Ingest' | 'Processing QC' | 'QC Passed' | 'QC Failed' | 'Remediation Required';

export interface MediaAsset {
  id: string;
  projectId: string;
  title: string;
  assetType: AssetType;
  format: string;
  codec: string;
  resolution: string;
  frameRate: string;
  audioChannels: string;
  colorSpace: string;
  hdrStatus: 'SDR' | 'HDR10' | 'Dolby Vision';
  duration: string;
  fileSizeBytes: number;
  checksumSha256: string;
  storageTier: StorageTier;
  storagePath: string;
  qcStatus: QCStatus;
  qcReportNote?: string;
  rightsStatus: 'Cleared' | 'Restricted' | 'Pending Legal';
  createdDate: string;
}

export interface IngestJob {
  id: string;
  assetId: string;
  assetTitle: string;
  projectId: string;
  stage: 'Received' | 'Checksum' | 'Metadata Validation' | 'Proxy Generation' | 'Transcode' | 'QC Check' | 'Editorial Sync' | 'Archived';
  progressPercent: number;
  status: 'Queued' | 'In Progress' | 'Completed' | 'Failed' | 'Paused';
  errorDetails?: string;
  startedAt: string;
  completedAt?: string;
}

// Post Production & VFX
export type PostStageName =
  | 'Assembly'
  | 'Rough Cut'
  | 'Fine Cut'
  | 'Director Review'
  | 'Executive Review'
  | 'Picture Lock'
  | 'Sound Mix'
  | 'Color Grade'
  | 'Online Conform'
  | 'Mastering'
  | 'Final QC';

export interface PostStage {
  id: string;
  projectId: string;
  stageName: PostStageName;
  owner: string;
  targetDate: string;
  completedDate?: string;
  status: 'Pending' | 'Active' | 'Blocked' | 'Completed';
  notes: string;
}

export interface ReviewFrameComment {
  id: string;
  assetId: string;
  timecode: string; // e.g. "01:14:22:10"
  frameNumber: number;
  author: string;
  role: string;
  comment: string;
  status: 'Open' | 'Addressed' | 'Approved';
  createdAt: string;
}

export interface PostComment {
  id: string;
  cutId: string;
  authorName: string;
  department: 'Director' | 'Editorial' | 'Color' | 'Sound' | 'VFX';
  timecode: string;
  frameNumber: number;
  text: string;
  resolved: boolean;
  timestamp: string;
}

export interface PostCut {
  id: string;
  projectId: string;
  cutName: string;
  versionTag: string;
  duration: string;
}

export interface SANVolume {
  id: string;
  volumeName: string;
  totalTb: number;
  usedTb: number;
  availableTb: number;
  healthStatus: 'Optimal' | 'Near Capacity' | 'Degraded';
}

export interface VFXVendor {
  id: string;
  vendorName: string;
  totalBidAmount: number;
  allocatedShots: number;
  deliveredShots: number;
  qualityScore: number;
}


export type VFXShotStatus =
  | 'Not Started'
  | 'Plate Pending'
  | 'Assigned'
  | 'In Progress'
  | 'Internal Review'
  | 'Client Review'
  | 'Changes Requested'
  | 'Approved'
  | 'Final Delivered'
  | 'On Hold';

export interface VFXShot {
  id: string;
  projectId: string;
  shotId: string; // e.g., "TLO_VFX_102"
  sequence: string;
  frameRange: string;
  description: string;
  vendorName: string;
  complexity: 'Low' | 'Medium' | 'High' | 'Hero Complex';
  status: VFXShotStatus;
  currentVersion: string;
  dueDate: string;
  estimatedCost: number;
  actualCost: number;
  notes: string;
}

// Localisation & Global Distribution
export interface LocalisationMatrixItem {
  id: string;
  projectId: string;
  territory: string;
  language: string;
  videoStatus: 'Master Ready' | 'Processing' | 'Missing';
  audioStatus: '5.1 Master' | 'Dubbed In Progress' | 'Dubbed Ready' | 'Missing';
  captionsStatus: 'SDH Passed' | 'Subtitles Pending' | 'Missing';
  artworkStatus: 'Localized Approved' | 'Pending Approval' | 'Missing';
  rightsStatus: 'Cleared' | 'Territory Restricted' | 'Expired';
  overallStatus: 'Ready for Delivery' | 'Blocked' | 'In Progress';
  blockingReason?: string;
}

export interface DistributionOrder {
  id: string;
  orderNumber: string;
  projectId: string;
  partnerName: string; // e.g., "Paramount+ Global", "Sky Cinema UK", "Canal+", "Toho Japan"
  territory: string;
  platform: 'Streaming SVOD' | 'Linear Broadcast' | 'Theatrical DCP' | 'VOD EST/TVOD' | 'FAST Channel';
  deadline: string;
  status: 'Order Received' | 'Assets Collected' | 'Package Built' | 'Technical QC' | 'Partner Delivered' | 'Published';
  qcPassed: boolean;
  deliveryPackageId?: string;
}

// Rights & Legal
export type RightsStatus = 'Draft' | 'Under Review' | 'Approved' | 'Restricted' | 'Expiring Soon' | 'Expired' | 'Renewal Required';

export interface RightsRecord {
  id: string;
  projectId: string;
  title: string;
  rightsType: 'Music License' | 'Talent Agreement' | 'Script Rights' | 'Location Release' | 'Artwork Permission' | 'Stock Footage';
  licensorName: string;
  territories: string[];
  platforms: string[];
  startDate: string;
  endDate: string;
  usageRestrictions: string;
  status: RightsStatus;
  responsibleOwner: string;
  feeAmount: number;
}

// Production Finance
export interface PurchaseOrder {
  id: string;
  poNumber: string;
  projectId: string;
  department: string;
  vendorName: string;
  description: string;
  amount: number;
  status: 'Draft' | 'Pending Approval' | 'Approved' | 'Invoiced' | 'Paid';
  createdDate: string;
}

export interface DepartmentBudget {
  department: string;
  originalBudget: number;
  revisedBudget: number;
  committedCost: number;
  actualCost: number;
  forecastFinal: number;
}

// Marketing & Campaigns
export interface MarketingCampaign {
  id: string;
  projectId: string;
  campaignName: string;
  territory: string;
  targetLaunchDate: string;
  trailersApproved: number;
  trailersTotal: number;
  postersApproved: number;
  socialAssetsReady: number;
  status: 'Strategy Phase' | 'Asset Creation' | 'Localization' | 'Approved' | 'Live Campaign';
  leadExec: string;
}

// Facilities & Lot Management
export interface StudioFacility {
  id: string;
  name: string;
  building: string;
  type: 'Sound Stage' | 'Backlot Set' | 'Screening Room' | 'Edit Suite' | 'Color Suite' | 'Recording Room' | 'Equipment Vault';
  squareFeet: number;
  dailyRate: number;
  status: 'Occupied' | 'Available' | 'Maintenance' | 'Reserved';
  currentProject?: string;
}

export interface FacilityBooking {
  id: string;
  facilityId: string;
  facilityName: string;
  projectId: string;
  startDate: string;
  endDate: string;
  requestedBy: string;
  status: 'Confirmed' | 'Pending' | 'Conflict Warning';
}

// Sustainability & Impact
export interface SustainabilityMetrics {
  projectId: string;
  electricityKwhEstimated: number;
  electricityKwhReported: number;
  fuelGallonsEstimated: number;
  flightsCount: number;
  wasteTonsRecycled: number;
  co2EmissionsTonsEstimated: number;
  sustainabilityRating: 'A+' | 'A' | 'B' | 'Needs Improvement';
}

// Events & System Audit
export type StudioEventType =
  | 'PROJECT_STAGE_CHANGED'
  | 'SCHEDULE_CHANGED'
  | 'MEDIA_INGEST_FAILED'
  | 'QC_FAILURE_RECORDED'
  | 'RIGHTS_EXPIRY_DETECTED'
  | 'DELIVERY_BLOCKED'
  | 'BUDGET_VARIANCE_UPDATED'
  | 'FACILITY_BOOKING_CONFLICT'
  | 'VFX_SHOT_APPROVED'
  | 'LOCALISATION_ASSET_MISSING'
  | 'GREENLIGHT_APPROVED'
  | 'CALL_SHEET_PUBLISHED'
  | 'SIMULATION_ADVANCED';

export interface StudioEvent {
  id: string;
  type: StudioEventType;
  timestamp: string;
  projectId?: string;
  title?: string;
  description: string;
  affectedEntity: string;
  previousState?: string;
  newState?: string;
  severity: 'Info' | 'Warning' | 'Critical';
  triggeredBy: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userEmail: string;
  userRole: string;
  action: string;
  targetEntity: string;
  details: string;
  ipAddress: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'Alert' | 'Warning' | 'Info' | 'Success';
  read: boolean;
  linkTab?: string;
  projectId?: string;
}

export type UserRole =
  | 'Executive'
  | 'Producer'
  | 'Production Manager'
  | 'Department Head'
  | 'Editor'
  | 'VFX Supervisor'
  | 'Media Operator'
  | 'Distribution Manager'
  | 'Legal Reviewer'
  | 'Finance Reviewer'
  | 'Marketing Manager'
  | 'Facilities Manager'
  | 'Administrator'
  | 'Read-only Observer';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl: string;
  title: string;
  division: StudioDivision;
}
