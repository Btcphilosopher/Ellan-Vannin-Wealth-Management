/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, MetalPrice, VaultCertificate } from '../types';

interface AppContextType {
  products: Product[];
  spotPrices: MetalPrice;
  cart: CartItem[];
  wishlist: string[];
  activeCoinId: string;
  setActiveCoinId: (id: string) => void;
  addToCart: (product: Product, qty?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, qty: number) => void;
  toggleWishlist: (productId: string) => void;
  clearCart: () => void;
  priceAlerts: { id: string; target: number; type: 'above' | 'below'; metal: 'gold' | 'silver'; active: boolean }[];
  addPriceAlert: (metal: 'gold' | 'silver', target: number, type: 'above' | 'below') => void;
  removePriceAlert: (id: string) => void;
  vaultCertificates: VaultCertificate[];
  addCertificate: (cert: Omit<VaultCertificate, 'id' | 'serialNumber' | 'verificationHash'>) => void;
  userBalance: { usd: number; goldOz: number; silverOz: number };
  setUserBalance: React.Dispatch<React.SetStateAction<{ usd: number; goldOz: number; silverOz: number }>>;
}

const initialProducts: Product[] = [
  {
    id: 'lone-star-gold',
    name: 'Lone Star Gold Bullion Coin',
    type: 'gold',
    weight: '1 oz',
    purity: '.9999 Fine Gold',
    price: 2385,
    basePrice: 2350,
    premium: 0.015, // 1.5% premium
    description: 'The signature 1 oz Gold Bullion of the Lone Star State. Features an exquisite 3D high-relief star, symbolizing Texan independence and uncompromising purity. Each coin is pressed from locally refined .9999 pure gold.',
    image: '/src/assets/images/gold_lone_star_coin_1785426079210.jpg',
    inStock: true,
    rarity: 'Investment Grade'
  },
  {
    id: 'texas-silver-round',
    name: 'Texas Silver Round Bullion Coin',
    type: 'silver',
    weight: '1 oz',
    purity: '.999 Fine Silver',
    price: 32.75,
    basePrice: 31.2,
    premium: 0.05, // 5% premium
    description: 'A stunning legal-tender silver coin bearing the geographical outline of Texas with a single polished star situated above Austin. Minted in aerospace-grade cleanrooms for maximum detail and metallic brilliance.',
    image: '/src/assets/images/silver_texas_round_1785426095596.jpg',
    inStock: true,
    rarity: 'Collector & Bullion'
  },
  {
    id: 'texas-heritage-gold',
    name: 'Texas Heritage Bullion Coin',
    type: 'gold',
    weight: '1 oz',
    purity: '.9999 Fine Gold',
    price: 2395,
    basePrice: 2350,
    premium: 0.019, // 1.9% premium
    description: 'A masterpiece of American craftsmanship featuring an incredibly detailed engraving of a Texas Longhorn skull. This coin celebrates the rugged spirit of early settlers combined with modern luxury finish.',
    image: '/src/assets/images/gold_texas_heritage_1785426112901.jpg',
    inStock: true,
    rarity: 'Limited Series'
  }
];

// 30 days of historical data
const generateHistoricalData = (base: number, volatility: number) => {
  const data = [];
  const now = new Date();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    const dateStr = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const randomChange = (Math.random() - 0.48) * volatility;
    data.push({ date: dateStr, value: Math.round((base + randomChange) * 100) / 100 });
  }
  return data;
};

const initialSpotPrices: MetalPrice = {
  gold: 2350.45,
  silver: 31.22,
  goldChange: 1.45,
  silverChange: -0.24,
  goldHistorical: generateHistoricalData(2350, 15),
  silverHistorical: generateHistoricalData(31.2, 0.4)
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [spotPrices, setSpotPrices] = useState<MetalPrice>(initialSpotPrices);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [activeCoinId, setActiveCoinId] = useState<string>('lone-star-gold');
  const [priceAlerts, setPriceAlerts] = useState<AppContextType['priceAlerts']>([]);
  const [userBalance, setUserBalance] = useState({ usd: 54200, goldOz: 10, silverOz: 150 });

  const [vaultCertificates, setVaultCertificates] = useState<VaultCertificate[]>([
    {
      id: 'cert-1',
      serialNumber: 'TXM-G-829402',
      assetType: 'Gold',
      weight: '5 oz',
      purity: '.9999 Pure',
      mintDate: '10/12/2025',
      vaultLocation: 'Texas Mint Vault - Chamber Alpha',
      verificationHash: '0x8f2d...4a1e',
      ownerName: 'Tom Ahyx'
    },
    {
      id: 'cert-2',
      serialNumber: 'TXM-S-491029',
      assetType: 'Silver',
      weight: '100 oz',
      purity: '.999 Pure',
      mintDate: '03/24/2026',
      vaultLocation: 'Texas Mint Vault - Chamber Delta',
      verificationHash: '0x2c7e...fa92',
      ownerName: 'Tom Ahyx'
    }
  ]);

  // Simulate Spot Price Fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      setSpotPrices((prev) => {
        const goldDelta = (Math.random() - 0.49) * 1.5; // slight upward drift
        const silverDelta = (Math.random() - 0.49) * 0.08;

        const newGold = Math.max(2200, prev.gold + goldDelta);
        const newSilver = Math.max(25, prev.silver + silverDelta);

        const newGoldChange = prev.goldChange + (goldDelta / prev.gold) * 100;
        const newSilverChange = prev.silverChange + (silverDelta / prev.silver) * 100;

        // Check price alerts
        priceAlerts.forEach(alert => {
          if (alert.active) {
            const currentVal = alert.metal === 'gold' ? newGold : newSilver;
            const isTriggered = alert.type === 'above' ? currentVal >= alert.target : currentVal <= alert.target;
            if (isTriggered) {
              console.log(`[ALERT TRIGGERED] ${alert.metal.toUpperCase()} has gone ${alert.type} ${alert.target}!`);
              // Deactivate alert so it fires only once
              setPriceAlerts(prevAlerts =>
                prevAlerts.map(a => a.id === alert.id ? { ...a, active: false } : a)
              );
            }
          }
        });

        return {
          ...prev,
          gold: Math.round(newGold * 100) / 100,
          silver: Math.round(newSilver * 100) / 100,
          goldChange: Math.round(newGoldChange * 100) / 100,
          silverChange: Math.round(newSilverChange * 100) / 100,
        };
      });
    }, 4500);

    return () => clearInterval(interval);
  }, [priceAlerts]);

  // Keep product prices synchronized with spot prices plus premium percentage
  useEffect(() => {
    setProducts((prevProducts) =>
      prevProducts.map((p) => {
        const spot = p.type === 'gold' ? spotPrices.gold : spotPrices.silver;
        // premium calculated on spot
        const metalCost = spot;
        const calculatedPrice = Math.round(metalCost * (1 + p.premium) * 100) / 100;
        return {
          ...p,
          price: calculatedPrice
        };
      })
    );
  }, [spotPrices.gold, spotPrices.silver]);

  // Cart Handlers
  const addToCart = (product: Product, qty = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + qty }
            : item
        );
      }
      return [...prev, { product, quantity: qty }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, qty: number) => {
    if (qty <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity: qty } : item
      )
    );
  };

  const clearCart = () => setCart([]);

  // Wishlist Handler
  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  // Price Alerts Handlers
  const addPriceAlert = (metal: 'gold' | 'silver', target: number, type: 'above' | 'below') => {
    const newAlert = {
      id: `alert-${Date.now()}`,
      target,
      type,
      metal,
      active: true
    };
    setPriceAlerts((prev) => [...prev, newAlert]);
  };

  const removePriceAlert = (id: string) => {
    setPriceAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  // Vault certificates handlers
  const addCertificate = (cert: Omit<VaultCertificate, 'id' | 'serialNumber' | 'verificationHash'>) => {
    const id = `cert-${Date.now()}`;
    const randomHex = Math.random().toString(16).substr(2, 4);
    const randomHex2 = Math.random().toString(16).substr(2, 4);
    const serialNumber = `TXM-${cert.assetType[0]}-${Math.floor(100000 + Math.random() * 900000)}`;
    const verificationHash = `0x${randomHex}...${randomHex2}`;

    const newCert: VaultCertificate = {
      ...cert,
      id,
      serialNumber,
      verificationHash
    };

    setVaultCertificates((prev) => [newCert, ...prev]);

    // adjust user balances accordingly
    const weightVal = parseFloat(cert.weight);
    if (!isNaN(weightVal)) {
      setUserBalance(prev => {
        if (cert.assetType === 'Gold') {
          return { ...prev, goldOz: prev.goldOz + weightVal };
        } else {
          return { ...prev, silverOz: prev.silverOz + weightVal };
        }
      });
    }
  };

  return (
    <AppContext.Provider
      value={{
        products,
        spotPrices,
        cart,
        wishlist,
        activeCoinId,
        setActiveCoinId,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        toggleWishlist,
        clearCart,
        priceAlerts,
        addPriceAlert,
        removePriceAlert,
        vaultCertificates,
        addCertificate,
        userBalance,
        setUserBalance
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
