/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  type: 'gold' | 'silver';
  weight: string;
  purity: string;
  price: number;
  basePrice: number; // for dynamic calculations
  premium: number; // premium percentage over spot
  description: string;
  image: string;
  inStock: boolean;
  rarity?: string;
  obverseImage?: string;
}

export interface MetalPrice {
  gold: number;
  silver: number;
  goldChange: number;
  silverChange: number;
  goldHistorical: { date: string; value: number }[];
  silverHistorical: { date: string; value: number }[];
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Article {
  id: string;
  title: string;
  category: string;
  excerpt: string;
  date: string;
  readTime: string;
  image: string;
  author: string;
}

export interface VaultCertificate {
  id: string;
  serialNumber: string;
  assetType: 'Gold' | 'Silver';
  weight: string;
  purity: string;
  mintDate: string;
  vaultLocation: string;
  verificationHash: string;
  ownerName: string;
}

export interface TimelineStep {
  id: string;
  title: string;
  description: string;
  details: string[];
  duration: string;
}
