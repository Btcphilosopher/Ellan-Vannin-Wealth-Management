/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TrustBar } from './components/TrustBar';
import { FeaturedProducts } from './components/FeaturedProducts';
import { CoinViewer } from './components/CoinViewer';
import { WhyTexasMint } from './components/WhyTexasMint';
import { CollectionsGrid } from './components/CollectionsGrid';
import { PriceDashboard } from './components/PriceDashboard';
import { VaultStorage } from './components/VaultStorage';
import { ManufacturingTimeline } from './components/ManufacturingTimeline';
import { TechnologySection } from './components/TechnologySection';
import { LegacySection } from './components/LegacySection';
import { Testimonials } from './components/Testimonials';
import { NewsMagazine } from './components/NewsMagazine';
import { Footer } from './components/Footer';

function MainAppContent() {
  const { setActiveCoinId } = useApp();

  const handleSectionScroll = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      // Calculate top offset to clear sticky navbar (approx 80px)
      const navbarOffset = 80;
      const elementPosition = el.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navbarOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const handleSelectCoinAndScroll = (productId: string) => {
    setActiveCoinId(productId);
    handleSectionScroll('viewer');
  };

  return (
    <div className="min-h-screen bg-[#111111] text-white selection:bg-[#C9A227] selection:text-[#111111] font-sans antialiased overflow-x-hidden">
      {/* Sticky Top-Bar & Luxury Navigation */}
      <Navbar
        onVaultClick={() => handleSectionScroll('vault')}
        onSectionScroll={handleSectionScroll}
      />

      {/* Cinematic Skyline Sunset Hero Section */}
      <Hero onSectionScroll={handleSectionScroll} />

      {/* Trust & Guarantee Certification Badges */}
      <TrustBar />

      {/* Luxury Product Showcase Cards */}
      <FeaturedProducts
        onSelectViewer={handleSelectCoinAndScroll}
        onSectionScroll={handleSectionScroll}
      />

      {/* Interactive 3D/CSS Spectroscopic Coin Inspector */}
      <CoinViewer />

      {/* Sovereignty & American Craftsmanship values */}
      <WhyTexasMint />

      {/* Curated Limited Collections Series Grid */}
      <CollectionsGrid />

      {/* Live Market Spot Price Area Charts Ticker */}
      <PriceDashboard />

      {/* Stateful Custody and Digital Certificate Vault System */}
      <VaultStorage />

      {/* Step-by-step physical production flow map */}
      <ManufacturingTimeline />

      {/* Robotic, Nano-laser & Laser-grid Infographics */}
      <TechnologySection />

      {/* Generational Statement */}
      <LegacySection />

      {/* Horizontal Customer Reviews Carousel */}
      <Testimonials />

      {/* Editorial briefing magazine */}
      <NewsMagazine />

      {/* Premium dark corporate footer */}
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
