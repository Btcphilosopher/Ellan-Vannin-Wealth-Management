/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, Compass, Eye, HeartHandshake } from 'lucide-react';

interface ValueCard {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  desc: string;
}

const values: ValueCard[] = [
  {
    icon: Compass,
    title: 'INDEPENDENT WEALTH PRESERVATION',
    desc: 'Unshackle your portfolio from fiat inflation. Physical precious metals held directly are the ultimate form of independent wealth.'
  },
  {
    icon: ShieldAlert,
    title: 'AEROSPASE-GRADE PRECISION',
    desc: 'Our minting processes operate inside class-100 cleanrooms using state-of-the-art physical presses to guarantee pristine condition and exact grain weights.'
  },
  {
    icon: HeartHandshake,
    title: 'AMERICAN CRAFTSMANSHIP',
    desc: 'Proudly sourced, refined, and pressed in Texas. We support local communities and protect the environment with renewable energy sources.'
  },
  {
    icon: Eye,
    title: 'SECURED TRANSPARENCY',
    desc: 'Verify the physical status of your bullion instantly online. Every bar and coin has a physical certificate cataloged on-chain.'
  }
];

export const WhyTexasMint: React.FC = () => {
  return (
    <section id="why-us" className="bg-[#0a0a0a] py-24 border-b border-white/10 font-display relative overflow-hidden">
      {/* Background soft lighting */}
      <div className="absolute top-1/4 left-10 w-96 h-96 bg-[#C9A227]/3 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          
          {/* Left Side: Premium Refinery Picture */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-5 relative group"
          >
            {/* Outline highlight frames */}
            <div className="absolute inset-x-[-10px] inset-y-[-10px] border border-[#222222] pointer-events-none rounded-sm transition-all duration-500 group-hover:border-[#C9A227]/30" />
            <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-[#C9A227] pointer-events-none" />
            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-[#C9A227] pointer-events-none" />

            <div className="w-full h-[400px] sm:h-[480px] rounded-sm overflow-hidden bg-black shadow-2xl relative">
              <img
                src="/src/assets/images/high_tech_refinery_1785426130699.jpg"
                alt="Texas Mint Automated Refinery"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 filter brightness-95"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-transparent to-transparent opacity-80" />
              
              {/* Floating label */}
              <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#111111]/90 backdrop-blur-sm border border-[#2c2c2c] rounded-sm">
                <p className="text-[10px] font-bold tracking-[0.25em] text-[#C9A227] uppercase">Texas Mint Refineries</p>
                <p className="text-[9px] text-gray-400 uppercase mt-1">Class-100 Cleanroom Press Chambers • Round Rock, TX</p>
              </div>
            </div>
          </motion.div>

          {/* Right Side: Copy & Columns */}
          <div className="lg:col-span-7 space-y-10">
            <div>
              <span className="text-[10px] font-bold tracking-[0.3em] text-[#C9A227] uppercase">The Sovereign Advantage</span>
              <h2 className="text-3xl sm:text-4xl font-black tracking-[0.15em] text-white uppercase mt-3">
                WHY TEXAS MINT
              </h2>
              <div className="h-0.5 w-16 bg-[#C9A227] mt-4" />
              <p className="text-xs text-gray-400 mt-6 leading-relaxed max-w-xl">
                We are more than a refinery. Texas Mint is an institution built on financial independence and industrial innovation, fusing Western heritage with high-tech automated engineering.
              </p>
            </div>

            {/* Sub-value grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
              {values.map((v, i) => {
                const Icon = v.icon;
                return (
                  <motion.div
                    key={v.title}
                    initial={{ opacity: 0, y: 15 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: i * 0.1 }}
                    className="space-y-2.5 group"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-4 h-4 text-[#C9A227]" />
                      <h4 className="text-[11px] font-bold tracking-[0.15em] text-white uppercase group-hover:text-[#C9A227] transition-colors">
                        {v.title}
                      </h4>
                    </div>
                    <p className="text-[10px] text-gray-400 leading-relaxed font-sans">
                      {v.desc}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
