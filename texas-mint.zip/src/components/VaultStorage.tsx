/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Lock, ShieldCheck, Key, Cpu, Award, Plus, Coins, FileCheck, CheckCircle, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const VaultStorage: React.FC = () => {
  const { vaultCertificates, addCertificate, userBalance, setUserBalance, spotPrices } = useApp();
  const [activeDashboardTab, setActiveDashboardTab] = useState<'holdings' | 'mint' | 'multisig'>('holdings');

  // Minting form states
  const [depositMetal, setDepositMetal] = useState<'Gold' | 'Silver'>('Gold');
  const [depositWeight, setDepositWeight] = useState<number>(10);
  const [isMinting, setIsMinting] = useState(false);

  // Multisig simulation states
  const [sigStep, setSigStep] = useState<number>(0); // 0: Idle, 1: Co-Signer 1 pending, 2: Co-Signer 2 pending, 3: Approved
  const [withdrawMetal, setWithdrawMetal] = useState<'Gold' | 'Silver'>('Gold');
  const [withdrawWeight, setWithdrawWeight] = useState<number>(1);

  // Live Valuation
  const goldValuation = userBalance.goldOz * spotPrices.gold;
  const silverValuation = userBalance.silverOz * spotPrices.silver;
  const totalVaultValuation = goldValuation + silverValuation;

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (depositWeight <= 0) return;

    const pricePerOz = depositMetal === 'Gold' ? spotPrices.gold : spotPrices.silver;
    const totalCost = depositWeight * pricePerOz;

    if (userBalance.usd < totalCost) {
      alert(`Insufficient USD cash balance to finalize purchase. Purchase requires $${totalCost.toLocaleString(undefined, { maximumFractionDigits: 2 })} but you currently hold $${userBalance.usd.toLocaleString()}.`);
      return;
    }

    setIsMinting(true);

    setTimeout(() => {
      addCertificate({
        assetType: depositMetal,
        weight: `${depositWeight} oz`,
        purity: depositMetal === 'Gold' ? '.9999 Pure' : '.999 Pure',
        mintDate: new Date().toLocaleDateString(),
        vaultLocation: depositMetal === 'Gold' ? 'Texas Mint Vault - Chamber Alpha' : 'Texas Mint Vault - Chamber Delta',
        ownerName: 'Tom Ahyx'
      });

      setUserBalance((prev) => ({
        ...prev,
        usd: Math.max(0, prev.usd - totalCost)
      }));

      setIsMinting(false);
      setActiveDashboardTab('holdings');
    }, 1500);
  };

  const triggerWithdrawal = () => {
    const userHoldings = withdrawMetal === 'Gold' ? userBalance.goldOz : userBalance.silverOz;
    if (withdrawWeight > userHoldings) {
      alert(`Insufficient physical ${withdrawMetal} vault balance. You are requesting to withdraw ${withdrawWeight} oz, but your account only registers ${userHoldings} oz allocated.`);
      return;
    }
    setSigStep(1);
  };

  const approveSignature = (signerNum: number) => {
    if (signerNum === 1) {
      setSigStep(2);
    } else if (signerNum === 2) {
      setSigStep(3);

      // Deduct balance on final approval
      setUserBalance((prev) => {
        if (withdrawMetal === 'Gold') {
          return { ...prev, goldOz: Math.max(0, prev.goldOz - withdrawWeight) };
        } else {
          return { ...prev, silverOz: Math.max(0, prev.silverOz - withdrawWeight) };
        }
      });
    }
  };

  const resetWithdrawal = () => {
    setSigStep(0);
    setWithdrawWeight(1);
  };

  return (
    <section id="vault" className="bg-[#0a0a0a] py-24 border-b border-white/10 font-display relative overflow-hidden">
      {/* Background radial effects */}
      <div className="absolute top-1/3 right-10 w-[600px] h-[600px] bg-[#C9A227]/3 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-bold tracking-[0.3em] text-[#C9A227] uppercase">Sovereign Wealth Custody</span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-[0.15em] text-white uppercase mt-3">SECURE VAULT SYSTEM</h2>
          <div className="h-0.5 w-16 bg-[#C9A227] mx-auto mt-4" />
          <p className="text-xs text-gray-400 mt-4 leading-relaxed">
            Allocated private vaults secured deep inside the granite bedrock of Round Rock, Texas. Fully backed by individual serial numbers, physical ledger validation, and modern cryptographic signatures.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
           {/* Left Column: Educational Vault Details (Glassmorphism design cards) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div className="space-y-6">
              {/* Allocated storage */}
              <div className="bg-[#0d0d0d]/70 border border-white/10 p-5 rounded-sm backdrop-blur-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-3 opacity-20 text-gray-500 group-hover:text-[#C9A227] transition-colors">
                  <Lock className="w-8 h-8" />
                </div>
                <h3 className="text-xs font-bold tracking-[0.15em] text-white uppercase flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#C9A227]" />
                  Fully Allocated Storage
                </h3>
                <p className="text-[11px] text-gray-400 leading-relaxed mt-3">
                  Unlike paper funds or fractional gold certificates, every grain of bullion held in the Texas Mint Vault system represents physical bars and coins labeled with your unique serial numbers, fully audited, and held in trust.
                </p>
              </div>

              {/* Insurance */}
              <div className="bg-[#0d0d0d]/70 border border-white/10 p-5 rounded-sm backdrop-blur-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-3 opacity-20 text-gray-500 group-hover:text-[#C9A227] transition-colors">
                  <Award className="w-8 h-8" />
                </div>
                <h3 className="text-xs font-bold tracking-[0.15em] text-white uppercase flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#C9A227]" />
                  Underwritten Lloyds Insurance
                </h3>
                <p className="text-[11px] text-gray-400 leading-relaxed mt-3">
                  All holdings are secured against theft, natural disasters, and industrial losses under an all-risks insurance policy underwritten by the world’s leading specialized syndicate, Lloyds of London.
                </p>
              </div>

              {/* Multi-Sig and Blockchain */}
              <div className="bg-[#0d0d0d]/70 border border-white/10 p-5 rounded-sm backdrop-blur-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-3 opacity-20 text-gray-500 group-hover:text-[#C9A227] transition-colors">
                  <Key className="w-8 h-8" />
                </div>
                <h3 className="text-xs font-bold tracking-[0.15em] text-white uppercase flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#C9A227]" />
                  Multi-Signature Releases
                </h3>
                <p className="text-[11px] text-gray-400 leading-relaxed mt-3">
                  Establish a decentralized safety barrier for your physical wealth. Release gold for delivery only upon 2-of-3 secure validations (personal signature, institutional trust sign, and an optional family co-signer).
                </p>
              </div>
            </div>

            {/* Quick overview metric card */}
            <div className="bg-gradient-to-r from-[#C9A227]/10 to-[#8C6B13]/5 border border-[#C9A227]/30 p-5 rounded-sm">
              <h4 className="text-[9px] font-extrabold tracking-widest text-[#C9A227] uppercase">Vault Reserve Credentials</h4>
              <p className="text-[10px] text-gray-300 mt-2 leading-relaxed">
                Texas Mint operates as an independent private repository, maintaining a strict 100% physically-backed reserve ratio. Auditor reports are cataloged monthly.
              </p>
            </div>
          </div>

          {/* Right Column: STATEFUL Custody Dashboard Terminal (8 cols) */}
          <div className="lg:col-span-7 bg-[#0d0d0d] border border-white/10 rounded-sm flex flex-col overflow-hidden relative font-display">

            {/* Glossy header tab */}
            <div className="border-b border-white/10 px-6 py-4 bg-[#0a0a0a]/80 flex justify-between items-center flex-wrap gap-4">
              <div className="flex gap-2">
                <button
                  onClick={() => setActiveDashboardTab('holdings')}
                  className={`px-4 py-2 text-[10px] tracking-wider font-extrabold uppercase rounded-sm cursor-pointer transition-all ${
                    activeDashboardTab === 'holdings' ? 'bg-[#C9A227]/10 text-[#C9A227] border border-[#C9A227]/30' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  My Holdings
                </button>
                <button
                  onClick={() => setActiveDashboardTab('mint')}
                  className={`px-4 py-2 text-[10px] tracking-wider font-extrabold uppercase rounded-sm cursor-pointer transition-all ${
                    activeDashboardTab === 'mint' ? 'bg-[#C9A227]/10 text-[#C9A227] border border-[#C9A227]/30' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Buy & Deposit Bullion
                </button>
                <button
                  onClick={() => setActiveDashboardTab('multisig')}
                  className={`px-4 py-2 text-[10px] tracking-wider font-extrabold uppercase rounded-sm cursor-pointer transition-all ${
                    activeDashboardTab === 'multisig' ? 'bg-[#C9A227]/10 text-[#C9A227] border border-[#C9A227]/30' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Multi-Sig Release
                </button>
              </div>

              {/* Status indicator */}
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">VAULT CORE: STANDBY</span>
              </div>
            </div>

            {/* Tab Contents */}
            <div className="flex-1 p-6">
              <AnimatePresence mode="wait">
                
                {/* 1. HOLDINGS TAB */}
                {activeDashboardTab === 'holdings' && (
                  <motion.div
                    key="holdings"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6"
                  >
                    {/* Valuation Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-display">
                      <div className="bg-[#0a0a0a] border border-white/10 p-4 rounded-sm text-left relative overflow-hidden group">
                        <div className="absolute top-1 right-2 opacity-5 text-[#C9A227] font-mono font-bold select-none text-[2.5rem]">AU</div>
                        <span className="text-[8px] text-gray-500 uppercase tracking-widest font-bold">Gold Reserve Alloc.</span>
                        <span className="text-base font-bold text-white font-mono mt-1.5 block">{userBalance.goldOz} oz</span>
                        <span className="text-[10px] font-bold text-[#C9A227] font-mono block mt-1">
                          ${goldValuation.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>

                      <div className="bg-[#0a0a0a] border border-white/10 p-4 rounded-sm text-left relative overflow-hidden group">
                        <div className="absolute top-1 right-2 opacity-5 text-slate-400 font-mono font-bold select-none text-[2.5rem]">AG</div>
                        <span className="text-[8px] text-gray-500 uppercase tracking-widest font-bold">Silver Reserve Alloc.</span>
                        <span className="text-base font-bold text-white font-mono mt-1.5 block">{userBalance.silverOz} oz</span>
                        <span className="text-[10px] font-bold text-slate-300 font-mono block mt-1">
                          ${silverValuation.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>

                      <div className="bg-[#0a0a0a] border border-white/10 p-4 rounded-sm text-left relative overflow-hidden group">
                        <div className="absolute top-1 right-2 opacity-5 text-green-500 font-mono font-bold select-none text-[2.5rem]">$</div>
                        <span className="text-[8px] text-gray-500 uppercase tracking-widest font-bold">Liquid Cash Balance</span>
                        <span className="text-base font-bold text-white font-mono mt-1.5 block">
                          ${userBalance.usd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                        <span className="text-[9px] font-semibold text-gray-500 block mt-1.5 uppercase">USD CAPITAL</span>
                      </div>
                    </div>

                    {/* Total Val */}
                    <div className="bg-[#0a0a0a] p-4 border border-white/10 rounded-sm flex justify-between items-center">
                      <span className="text-[10px] tracking-widest font-extrabold text-gray-400 uppercase">Combined Allocated Asset Valuation</span>
                      <span className="text-lg font-black text-[#C9A227] font-mono">
                        ${totalVaultValuation.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} <span className="text-xs text-gray-400 font-display font-medium">USD</span>
                      </span>
                    </div>

                    {/* Active Storage Certificates */}
                    <div className="space-y-3">
                      <h4 className="text-[10px] font-extrabold tracking-widest text-white uppercase text-left flex items-center gap-1.5">
                        <FileCheck className="w-4 h-4 text-[#C9A227]" />
                        Active Physical Vault Certificates ({vaultCertificates.length})
                      </h4>

                      <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                        {vaultCertificates.map((cert) => (
                          <div
                            key={cert.id}
                            className="p-3 bg-[#0a0a0a] border border-white/10 hover:border-[#C9A227]/40 rounded-sm flex flex-col sm:flex-row justify-between sm:items-center text-left gap-3 group"
                          >
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="text-[11px] font-black tracking-wider text-white uppercase font-mono">{cert.serialNumber}</span>
                                <span className={`text-[8px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                                  cert.assetType === 'Gold' ? 'bg-[#C9A227]/10 text-[#C9A227]' : 'bg-slate-300/10 text-slate-300'
                                }`}>
                                  {cert.weight} {cert.assetType} • {cert.purity}
                                </span>
                              </div>
                              <p className="text-[9px] text-gray-500 mt-1 uppercase font-semibold">
                                {cert.vaultLocation} • Minted: {cert.mintDate}
                              </p>
                            </div>
                            <div className="text-right shrink-0">
                              <button
                                onClick={() => alert(`Certificate verification successful!\n\nSerial: ${cert.serialNumber}\nAsset: ${cert.weight} ${cert.assetType} (${cert.purity})\nVerification Hash: ${cert.verificationHash}\nCustodian: Texas Mint Private Depository`)}
                                className="px-2.5 py-1 bg-[#1a1a1a] hover:bg-[#C9A227]/15 border border-[#333333] hover:border-[#C9A227]/50 text-gray-400 hover:text-white rounded-sm text-[9px] font-bold uppercase tracking-widest transition-all cursor-pointer inline-flex items-center gap-1"
                              >
                                🔍 Verify Ledgers
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* 2. DEPOSIT / MINT TAB */}
                {activeDashboardTab === 'mint' && (
                  <motion.div
                    key="mint"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6 text-left"
                  >
                    <div>
                      <h4 className="text-[11px] font-bold tracking-[0.15em] text-white uppercase mb-2">Buy Precious Metals directly into Allocated Vault Storage</h4>
                      <p className="text-[10px] text-gray-400 leading-relaxed">
                        Specify alloy assets to purchase with cash balance. Once confirmed, physical bullion will be minted with unique serial numbers and allocated immediately to your secured vault shelf.
                      </p>
                    </div>

                    <form onSubmit={handleDepositSubmit} className="space-y-5 bg-[#0a0a0a] p-5 border border-white/10 rounded-sm">
                      <div className="grid grid-cols-2 gap-4">
                        {/* Metal Type selection */}
                        <div className="space-y-2">
                          <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">Metal Class</span>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setDepositMetal('Gold')}
                              className={`py-2 text-[10px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                                depositMetal === 'Gold' ? 'border-[#C9A227] bg-[#C9A227]/5 text-[#C9A227]' : 'border-white/10 text-gray-500 bg-transparent'
                              }`}
                            >
                              ★ Gold
                            </button>
                            <button
                              type="button"
                              onClick={() => setDepositMetal('Silver')}
                              className={`py-2 text-[10px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                                depositMetal === 'Silver' ? 'border-slate-400 bg-slate-400/5 text-slate-300' : 'border-white/10 text-gray-500 bg-transparent'
                              }`}
                            >
                              ★ Silver
                            </button>
                          </div>
                        </div>

                        {/* Weight selector */}
                        <div className="space-y-2">
                          <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">Weight volume</span>
                          <select
                            value={depositWeight}
                            onChange={(e) => setDepositWeight(parseInt(e.target.value))}
                            className="w-full bg-[#0d0d0d] border border-white/10 rounded-sm p-2 text-xs font-mono text-white focus:outline-none focus:border-[#C9A227]"
                          >
                            <option value={1}>1 oz</option>
                            <option value={5}>5 oz</option>
                            <option value={10}>10 oz</option>
                            <option value={50}>50 oz</option>
                            <option value={100}>100 oz</option>
                          </select>
                        </div>
                      </div>

                      {/* Purchase estimate cost breakdown */}
                      <div className="pt-4 border-t border-[#222222] space-y-2 text-[10px]">
                        <div className="flex justify-between">
                          <span className="text-gray-500 uppercase font-semibold">Spot Price/oz</span>
                          <span className="text-white font-mono">${(depositMetal === 'Gold' ? spotPrices.gold : spotPrices.silver).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-500 uppercase font-semibold">Total Capital Cost</span>
                          <span className="text-[#C9A227] font-mono font-bold">
                            ${((depositMetal === 'Gold' ? spotPrices.gold : spotPrices.silver) * depositWeight).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                        </div>
                        <div className="flex justify-between pt-2 border-t border-[#222222] font-bold">
                          <span className="text-gray-400 uppercase">Estimated Cash Left</span>
                          <span className="text-white font-mono">
                            ${Math.max(0, userBalance.usd - (depositMetal === 'Gold' ? spotPrices.gold : spotPrices.silver) * depositWeight).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={isMinting}
                        className="w-full py-3.5 bg-gradient-to-r from-[#E2B72E] to-[#8C6B13] hover:from-[#F0C948] hover:to-[#A37F1C] text-[#111111] font-extrabold text-[11px] tracking-[0.25em] uppercase rounded-sm transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        {isMinting ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            Minting & Securing...
                          </>
                        ) : (
                          <>
                            <Plus className="w-4 h-4" />
                            Finalize Deposit Purchase
                          </>
                        )}
                      </button>
                    </form>
                  </motion.div>
                )}

                {/* 3. MULTISIG RELEASE TAB */}
                {activeDashboardTab === 'multisig' && (
                  <motion.div
                    key="multisig"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="space-y-6 text-left"
                  >
                    <div>
                      <h4 className="text-[11px] font-bold tracking-[0.15em] text-white uppercase mb-2">Multi-Signature Physical Withdrawal Simulator</h4>
                      <p className="text-[10px] text-gray-400 leading-relaxed">
                        Physical bullion leaves the Round Rock depositories only upon co-signer cryptographic confirmation. Simulate the 2-of-3 validation protocol to approve shipment.
                      </p>
                    </div>

                    {sigStep === 0 && (
                      <div className="bg-[#111111] p-5 border border-[#222222] rounded-sm space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">Withdraw Metal</span>
                            <div className="grid grid-cols-2 gap-2">
                              <button
                                onClick={() => setWithdrawMetal('Gold')}
                                className={`py-2 text-[10px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                                  withdrawMetal === 'Gold' ? 'border-[#C9A227] bg-[#C9A227]/5' : 'border-[#222222] text-gray-500 bg-transparent'
                                }`}
                              >
                                Gold
                              </button>
                              <button
                                onClick={() => setWithdrawMetal('Silver')}
                                className={`py-2 text-[10px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                                  withdrawMetal === 'Silver' ? 'border-slate-400 bg-slate-400/5' : 'border-[#222222] text-gray-500 bg-transparent'
                                }`}
                              >
                                Silver
                              </button>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest block">Weight to Withdraw</span>
                            <input
                              type="number"
                              min="1"
                              value={withdrawWeight}
                              onChange={(e) => setWithdrawWeight(parseInt(e.target.value) || 1)}
                              className="w-full bg-[#161616] border border-[#222222] focus:border-[#C9A227] rounded-sm p-2 text-xs font-mono text-white focus:outline-none"
                            />
                          </div>
                        </div>

                        <button
                          onClick={triggerWithdrawal}
                          className="w-full py-3 border border-[#C9A227]/40 hover:border-[#C9A227] bg-[#C9A227]/5 hover:bg-[#C9A227]/10 text-[#C9A227] hover:text-white text-[11px] font-bold tracking-[0.2em] uppercase rounded-sm cursor-pointer transition-all flex items-center justify-center gap-2"
                        >
                          <Lock className="w-4 h-4" />
                          Initiate Multi-Sig Shipment
                        </button>
                      </div>
                    )}

                    {/* Step 1 Pending (Co-Signer 1) */}
                    {sigStep === 1 && (
                      <div className="bg-[#111111] p-5 border border-[#C9A227]/40 rounded-sm space-y-4 text-center">
                        <Key className="w-8 h-8 text-[#C9A227] mx-auto animate-bounce" />
                        <div>
                          <h5 className="text-xs font-bold uppercase text-white">Signature [1/3] Recorded: OWNER APPROVED</h5>
                          <p className="text-[10px] text-gray-400 mt-2">
                            Awaiting Co-Signer 1 validation. (Simulates co-signer hardware key validation or family trust proxy).
                          </p>
                        </div>
                        <div className="pt-2">
                          <button
                            onClick={() => approveSignature(1)}
                            className="px-5 py-2.5 bg-[#C9A227] hover:bg-[#D9B53E] text-[#111111] font-bold text-[10px] tracking-widest uppercase rounded-sm cursor-pointer"
                          >
                            ★ Provide Co-Signer 1 approval
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Step 2 Pending (Co-Signer 2) */}
                    {sigStep === 2 && (
                      <div className="bg-[#111111] p-5 border border-[#C9A227]/40 rounded-sm space-y-4 text-center">
                        <Key className="w-8 h-8 text-blue-400 mx-auto animate-pulse" />
                        <div>
                          <h5 className="text-xs font-bold uppercase text-white">Signature [2/3] RECORDED: TRUST VALIDATED</h5>
                          <p className="text-[10px] text-gray-400 mt-2">
                            Awaiting final Institution Security Custodian co-signature to unlock vault chamber locks.
                          </p>
                        </div>
                        <div className="pt-2">
                          <button
                            onClick={() => approveSignature(2)}
                            className="px-5 py-2.5 bg-[#C9A227] hover:bg-[#D9B53E] text-[#111111] font-bold text-[10px] tracking-widest uppercase rounded-sm cursor-pointer"
                          >
                            ★ Provide Institution Security Co-Signature
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Step 3 Approved */}
                    {sigStep === 3 && (
                      <div className="bg-[#111111] p-5 border border-green-500/40 rounded-sm space-y-4 text-center">
                        <CheckCircle className="w-8 h-8 text-green-500 mx-auto" />
                        <div>
                          <h5 className="text-xs font-bold uppercase text-green-400">Withdrawal unlocked & shipping generated!</h5>
                          <p className="text-[10px] text-gray-300 mt-2 leading-relaxed">
                            A physical parcel for <strong>{withdrawWeight} oz {withdrawMetal}</strong> has been prepared for discrete, insured armored dispatch from Round Rock, TX. Tracked ledger hash verified.
                          </p>
                        </div>
                        <div className="pt-2">
                          <button
                            onClick={resetWithdrawal}
                            className="px-5 py-2 border border-gray-600 hover:border-white text-gray-400 hover:text-white font-bold text-[10px] tracking-widest uppercase rounded-sm cursor-pointer"
                          >
                            Return to dashboard
                          </button>
                        </div>
                      </div>
                    )}

                  </motion.div>
                )}

              </AnimatePresence>
            </div>

            {/* Glassmorphism security footer */}
            <div className="bg-[#0a0a0a]/80 border-t border-white/10 px-6 py-4 flex items-center gap-3 text-left text-[9px] text-gray-500">
              <Cpu className="w-4.5 h-4.5 text-[#C9A227] shrink-0" />
              <span>
                Ledger systems synchronized. API keys and multi-sig validations are audited under SOC2 Type II standards.
              </span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
