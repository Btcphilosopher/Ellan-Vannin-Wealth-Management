/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Coins, Flame, Hammer, ZoomIn, Package, ShieldCheck, Truck, Star } from 'lucide-react';

interface TimelineStep {
  id: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  details: string[];
  duration: string;
}

const steps: TimelineStep[] = [
  {
    id: 'mine',
    title: 'Mine',
    icon: Star,
    description: 'Sourcing ethically-mined ores from premium domestic reserves, guaranteeing non-conflict minerals.',
    details: ['Ethical domestic sourcing', '100% Conflict-free validation', 'Strict environmental compliance'],
    duration: 'Pre-production'
  },
  {
    id: 'refine',
    title: 'Refining',
    icon: Flame,
    description: 'Electrochemical refining processes purify metals to certified investment-grade standards (.9999 fine gold).',
    details: ['Wohlwill electrolysis process', 'ICP-MS chemical assaying', 'Slag extraction and scrap recovery'],
    duration: '24-48 Hours'
  },
  {
    id: 'mint',
    title: 'Minting',
    icon: Hammer,
    description: 'High-tonnage hydraulic presses stamp blanks with micro-relief dies inside a cleanroom environment.',
    details: ['Blank preparation and annealing', '1000-ton dynamic press strikes', 'Dual-struck cameo proof finish'],
    duration: '3-5 Seconds/strike'
  },
  {
    id: 'inspect',
    title: 'Inspection',
    icon: ZoomIn,
    description: 'High-resolution automated optical inspection (AOI) identifies microscopic surface defects.',
    details: ['Laser topography mapping', 'Spectrometric weight check', 'High-speed automated grading'],
    duration: 'Instantaneous'
  },
  {
    id: 'package',
    title: 'Packaging',
    icon: Package,
    description: 'Bullion is hermetically sealed in Certi-Lock® secure cards with hologram strips.',
    details: ['Tamper-evident card packaging', 'Holographic authentication stripe', 'NFC micro-chip integration'],
    duration: 'Automated Line'
  },
  {
    id: 'vault',
    title: 'Vault',
    icon: ShieldCheck,
    description: 'Allocated storage items are indexed on ledgers and secured inside our private granite repositories.',
    details: ['Granite bedrock vault safety', 'Dual key lockboxes', 'Digital catalog verification'],
    duration: 'Durable Storage'
  },
  {
    id: 'delivery',
    title: 'Delivery',
    icon: Truck,
    description: 'Discreet, fully insured armored transit and direct parcel delivery with signature requirements.',
    details: ['Fully insured transport', 'Discreet double-packaging', 'Direct sign-off security'],
    duration: '1-3 Business Days'
  }
];

export const ManufacturingTimeline: React.FC = () => {
  const [activeStepId, setActiveStepId] = useState<string>('mint');
  const activeStep = steps.find((s) => s.id === activeStepId) || steps[2];

  return (
    <section id="manufacturing" className="bg-[#0a0a0a] py-24 border-b border-white/10 font-display relative overflow-hidden select-none">
      {/* Background Soft Glow */}
      <div className="absolute top-1/2 left-1/3 w-80 h-80 bg-[#C9A227]/2 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-bold tracking-[0.3em] text-[#C9A227] uppercase">The Physical Creation</span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-[0.15em] text-white uppercase mt-3">MANUFACTURING ENGINE</h2>
          <div className="h-0.5 w-16 bg-[#C9A227] mx-auto mt-4" />
          <p className="text-xs text-gray-400 mt-4 leading-relaxed">
            Witness the aerospace-grade lifecycle of sovereign wealth. Track your physical bullion from domestic raw ore reserves to cleanroom struck cameos.
          </p>
        </div>

        {/* Timeline Line */}
        <div className="relative max-w-4xl mx-auto mb-12">
          {/* Connector horizontal line */}
          <div className="absolute top-[22px] left-8 right-8 h-[1px] bg-white/10 z-0 hidden md:block" />

          {/* Steps Horizontal Flex */}
          <div className="flex flex-col md:flex-row justify-between items-center gap-6 relative z-10">
            {steps.map((step, idx) => {
              const StepIcon = step.icon;
              const isActive = step.id === activeStepId;
              return (
                <button
                  key={step.id}
                  onClick={() => setActiveStepId(step.id)}
                  className="flex flex-row md:flex-col items-center gap-3 md:gap-2 group cursor-pointer"
                >
                  {/* Circle Indicator */}
                  <div className={`w-11 h-11 rounded-full border flex items-center justify-center transition-all duration-300 ${
                    isActive
                      ? 'border-[#C9A227] bg-[#C9A227]/10 text-[#C9A227] shadow-[0_0_15px_rgba(201,162,39,0.2)] scale-110'
                      : 'border-white/10 hover:border-gray-500 bg-[#0d0d0d] text-gray-500 hover:text-white'
                  }`}>
                    <StepIcon className="w-4.5 h-4.5 transition-transform group-hover:scale-110" />
                  </div>

                  {/* Title Label */}
                  <span className={`text-[10px] font-bold uppercase tracking-widest ${
                    isActive ? 'text-[#C9A227]' : 'text-gray-500 group-hover:text-gray-300'
                  }`}>
                    {step.title}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Step Details Panel (Expanding detail box) */}
        <div className="max-w-2xl mx-auto bg-[#0d0d0d] border border-white/10 p-6 rounded-sm text-left">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeStep.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center"
            >
              {/* Left Column icon: 3 cols */}
              <div className="md:col-span-3 flex justify-center">
                <div className="w-20 h-20 rounded-full bg-[#0a0a0a] border border-[#C9A227]/20 flex items-center justify-center shadow-inner">
                  {React.createElement(activeStep.icon, { className: 'w-8 h-8 text-[#C9A227]' })}
                </div>
              </div>

              {/* Right Details: 9 cols */}
              <div className="md:col-span-9 space-y-4 font-display">
                <div className="flex justify-between items-center border-b border-white/10 pb-2">
                  <h4 className="text-sm font-black tracking-widest text-white uppercase font-display">
                    Step: {activeStep.title}
                  </h4>
                  <span className="text-[9px] font-bold text-[#C9A227] uppercase bg-[#C9A227]/10 px-2.5 py-0.5 rounded-full font-mono">
                    {activeStep.duration}
                  </span>
                </div>

                <p className="text-[11px] text-gray-400 leading-relaxed font-sans">
                  {activeStep.description}
                </p>

                {/* Sub specifications checklist */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                  {activeStep.details.map((detail, dIdx) => (
                    <div key={dIdx} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 bg-[#C9A227] rounded-full" />
                      <span className="text-[10px] text-gray-400 uppercase font-semibold tracking-wide">
                        {detail}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
};
