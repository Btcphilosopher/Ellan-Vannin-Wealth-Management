/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Star } from 'lucide-react';

export const LegacySection: React.FC = () => {
  return (
    <section className="relative py-32 flex items-center justify-center overflow-hidden bg-[#0a0a0a] border-b border-white/10 font-display">
      {/* Background Cinematic Texture with Glowing Sparkles */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[#0a0a0a] opacity-90" />
        {/* Soft Golden radial gradient reflections */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[300px] bg-gradient-to-tr from-[#C9A227]/8 to-[#8C6B13]/3 rounded-full blur-[100px] pointer-events-none" />
      </div>

      {/* Sparks floating upwards */}
      <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
        {[...Array(10)].map((_, i) => {
          const size = Math.random() * 3 + 1.5;
          const left = Math.random() * 100;
          const duration = Math.random() * 6 + 4;
          const delay = Math.random() * 3;

          return (
            <motion.div
              key={i}
              className="absolute bg-[#C9A227] rounded-full opacity-30"
              style={{
                width: size,
                height: size,
                left: `${left}%`,
                bottom: '10%',
              }}
              animate={{
                y: [-20, -250],
                opacity: [0, 0.6, 0],
              }}
              transition={{
                duration,
                repeat: Infinity,
                delay,
                ease: 'easeInOut',
              }}
            />
          );
        })}
      </div>

      {/* Foreground copy */}
      <div className="relative z-20 max-w-4xl mx-auto px-4 md:px-8 text-center space-y-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-1.5 text-[#C9A227]"
        >
          <Star className="w-4 h-4 fill-current" />
          <span className="text-[10px] font-bold tracking-[0.3em] uppercase">Generational Wealth Protection</span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-3xl sm:text-5xl md:text-6xl font-black text-white tracking-tight leading-none uppercase select-none"
        >
          BUILD WEALTH THAT
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#E2B72E] to-yellow-100">
            LASTS GENERATIONS.
          </span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-xs sm:text-sm text-gray-400 max-w-xl mx-auto leading-relaxed select-none"
        >
          Systems evolve, currencies default, and markets fluctuate. But physical gold and silver remain invariant anchors of freedom. Secure your legacy with the Texas Mint.
        </motion.p>
      </div>
    </section>
  );
};
