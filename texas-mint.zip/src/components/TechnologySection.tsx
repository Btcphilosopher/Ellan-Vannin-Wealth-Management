/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Cpu, CpuIcon, Layers, ShieldAlert, Sparkles, Activity } from 'lucide-react';

interface TechItem {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle: string;
  desc: string;
  metric: string;
}

const techItems: TechItem[] = [
  {
    icon: Cpu,
    title: 'ROBOMINT SYSTEM',
    subtitle: 'Automated Hydraulic Swarm',
    desc: 'Automated industrial robotics move blanks through precise vacuum heat-treatment chambers to strike coins with up to 1000 tons of dynamic hydraulic power.',
    metric: '99.98% Strike Accuracy'
  },
  {
    icon: Sparkles,
    title: 'AI SPECTRO-AOI',
    subtitle: 'Deep-Learning Verification',
    desc: 'Neural vision systems analyze coin topography at sub-micron levels to catalog and verify absolute proof cameos, filtering out any physical microscopic defects.',
    metric: '<1ppm Surface Variance'
  },
  {
    icon: Layers,
    title: 'NANO-LASER ETCHER',
    subtitle: 'Microscopic Counterfeit Armor',
    desc: 'A specialized laser marking engine engraving unique molecular-scale serial numbers and signature symbols on the rims of gold and silver coins.',
    metric: '12-Point Hologram Seal'
  },
  {
    icon: ShieldAlert,
    title: 'LASER-GRID VAULTS',
    subtitle: 'Ultra-Secure Chamber Defense',
    desc: 'Protected under 3-meter thick reinforced concrete-bedrock vaults. Monitored by continuous thermal lasers, weight sensors, and offline cryptographic multi-sig keys.',
    metric: 'Zero Breach Record'
  }
];

export const TechnologySection: React.FC = () => {
  return (
    <section id="technology" className="bg-[#0a0a0a] py-24 border-b border-white/10 font-display relative overflow-hidden select-none">
      {/* Background radial highlight */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#C9A227]/3 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-bold tracking-[0.3em] text-[#C9A227] uppercase">Texas Futurist Engineering</span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-[0.15em] text-white uppercase mt-3">TEXAS TECHNOLOGY</h2>
          <div className="h-0.5 w-16 bg-[#C9A227] mx-auto mt-4" />
          <p className="text-xs text-gray-400 mt-4 leading-relaxed">
            Uniting classical sovereign asset preservation with state-of-the-art robotic mechanics, high-speed neural sorting algorithms, and deep-learning optical checkers.
          </p>
        </div>

        {/* Grid layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {techItems.map((tech, idx) => {
            const TechIcon = tech.icon;
            return (
              <motion.div
                key={tech.title}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-20px' }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="p-5 bg-gradient-to-b from-[#0d0d0d] to-[#0a0a0a] border border-white/10 hover:border-[#C9A227]/40 rounded-sm relative overflow-hidden text-left group"
              >
                {/* Micro outline frame glow */}
                <div className="absolute top-0 right-0 w-[4px] h-[4px] bg-[#C9A227]" />
                
                {/* Icon Circle */}
                <div className="w-10 h-10 rounded-sm border border-[#2c2c2c] bg-[#0a0a0a] flex items-center justify-center mb-6 group-hover:border-[#C9A227]/30 group-hover:bg-[#C9A227]/5 transition-all">
                  <TechIcon className="w-4.5 h-4.5 text-[#C9A227] group-hover:scale-110 transition-transform" />
                </div>

                <div className="space-y-2">
                  <h3 className="text-xs font-black tracking-[0.15em] text-white uppercase group-hover:text-[#C9A227] transition-colors">
                    {tech.title}
                  </h3>
                  <p className="text-[9px] text-gray-500 uppercase tracking-widest font-semibold leading-none">
                    {tech.subtitle}
                  </p>
                  <p className="text-[10px] text-gray-400 leading-relaxed font-sans pt-1">
                    {tech.desc}
                  </p>
                </div>

                {/* Micro tech metrics stats row */}
                <div className="mt-6 pt-4 border-t border-white/10 flex justify-between items-center text-[8px] font-bold uppercase tracking-wider font-display">
                  <span className="text-gray-500 flex items-center gap-1">
                    <Activity className="w-3 h-3 text-[#C9A227]" />
                    Metric standard
                  </span>
                  <span className="text-white font-mono">{tech.metric}</span>
                </div>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
