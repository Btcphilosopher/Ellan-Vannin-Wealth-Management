/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Star, ArrowRight, Compass, Shield, Award } from 'lucide-react';

interface Collection {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  spec: string;
  purity: string;
  isPopular?: boolean;
}

const collections: Collection[] = [
  {
    id: 'founders',
    name: 'Founders Collection',
    subtitle: 'Limited First-Edition Engravings',
    description: 'Celebrating the legendary figures who established independent Texan frontiers. Featuring high-relief, proof-finished heavy gold rounds.',
    spec: '1 oz, 5 oz Gold Rounds',
    purity: '.9999 Pure Gold',
    isPopular: true
  },
  {
    id: 'lone-star',
    name: 'Lone Star Series',
    subtitle: 'Signature Texas Bulwark',
    description: 'Our flagship coin series embodying the resilient spirit of the star. Features modern security micro-engravings and frosted finishes.',
    spec: '1/10 oz, 1/4 oz, 1 oz, 10 oz Coins',
    purity: '.9999 Gold / .999 Silver'
  },
  {
    id: 'wildlife',
    name: 'Texas Wildlife',
    subtitle: 'Nature’s Sovereign Species',
    description: 'An annual artistic series illustrating magnificent species including the Texas Longhorn, armadillo, and golden eagle.',
    spec: '1 oz Coins & Fine Cast Bars',
    purity: '.999 Fine Silver'
  },
  {
    id: 'liberty',
    name: 'Liberty Collection',
    subtitle: 'American Independence Commemoratives',
    description: 'A patriotic collaboration blending Western aerospace ambition with historic icons of individual freedom.',
    spec: '1 oz, 10 oz Bullion Rounds',
    purity: '.9999 Fine Gold'
  },
  {
    id: 'energy',
    name: 'Energy Series',
    subtitle: 'Industrial Power Series',
    description: 'Honoring the physical forces that power Texas—from early gusher oil derricks to massive wind farms and space launching platforms.',
    spec: '10 oz, 100 oz Pressed Bars',
    purity: '.999 Fine Silver'
  },
  {
    id: 'republic',
    name: 'Republic Collection',
    subtitle: 'Historic Currency Restorations',
    description: 'Meticulous legal-tender historical recreations of the original 1836 Republic of Texas sovereign dollar designs.',
    spec: '1 oz proof rounds, boxed sets',
    purity: '.999 Fine Silver / 24K Gilt'
  }
];

export const CollectionsGrid: React.FC = () => {
  const [selectedId, setSelectedId] = useState<string | null>(null);

  return (
    <section id="collections" className="bg-[#0a0a0a] py-24 border-b border-white/10 font-display relative overflow-hidden">
      {/* Background soft lighting */}
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-[#C9A227]/3 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Section Title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-4">
          <div>
            <span className="text-[10px] font-bold tracking-[0.3em] text-[#C9A227] uppercase">Curated Catalog</span>
            <h2 className="text-3xl sm:text-4xl font-black tracking-[0.15em] text-white uppercase mt-3">
              MINT SERIES COLLECTIONS
            </h2>
            <div className="h-0.5 w-16 bg-[#C9A227] mt-4" />
          </div>
          <p className="text-xs text-gray-400 max-w-md leading-relaxed">
            Our precious metal editions are organized into curated series, catering to high-net-worth investment portfolios and fine numismatic collectors alike.
          </p>
        </div>

        {/* Collections Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-stretch">
          {collections.map((col, idx) => (
            <motion.div
              key={col.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-20px' }}
              transition={{ duration: 0.6, delay: idx * 0.08 }}
              onClick={() => setSelectedId(selectedId === col.id ? null : col.id)}
              className={`relative flex flex-col justify-between p-6 bg-[#0d0d0d] border rounded-sm cursor-pointer transition-all duration-300 group ${
                selectedId === col.id
                  ? 'border-[#C9A227] bg-[#C9A227]/5'
                  : 'border-white/10 hover:border-gray-500'
              }`}
            >
              {/* Highlight bar */}
              <div className={`absolute left-0 top-0 bottom-0 w-1 transition-all ${
                selectedId === col.id ? 'bg-[#C9A227]' : 'bg-transparent group-hover:bg-gray-700'
              }`} />

              <div>
                {/* Header Tag */}
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[9px] tracking-[0.2em] font-extrabold uppercase text-gray-500">
                    {col.spec}
                  </span>
                  {col.isPopular && (
                    <span className="text-[8px] tracking-wider font-bold text-[#C9A227] uppercase bg-[#C9A227]/10 px-2 py-0.5 rounded-sm flex items-center gap-1">
                      <Award className="w-3 h-3 text-[#C9A227]" />
                      Limited Series
                    </span>
                  )}
                </div>

                {/* Series Title */}
                <h3 className="text-sm font-black tracking-[0.15em] text-white uppercase mt-2 group-hover:text-[#C9A227] transition-colors">
                  {col.name}
                </h3>
                <p className="text-[10px] tracking-wide text-gray-400 mt-1 uppercase font-semibold">
                  {col.subtitle}
                </p>

                {/* Main description */}
                <p className="text-[11px] text-gray-500 leading-relaxed mt-4 group-hover:text-gray-300 transition-colors">
                  {col.description}
                </p>
              </div>

              {/* Collapsible/Expandable Specs block */}
              <div className="mt-6 pt-4 border-t border-[#222222]/80 space-y-2">
                <div className="flex justify-between text-[9px] font-bold uppercase">
                  <span className="text-gray-500">Alloy Standard</span>
                  <span className="text-white">{col.purity}</span>
                </div>
                <div className="flex justify-between text-[9px] font-bold uppercase">
                  <span className="text-gray-500">Secure Pack</span>
                  <span className="text-white">Certi-Lock® Holographic Sleeve</span>
                </div>
                <div className="pt-2 text-right">
                  <span className="text-[#C9A227] font-bold text-[9px] tracking-widest uppercase flex items-center justify-end gap-1 group-hover:translate-x-1 transition-transform">
                    {selectedId === col.id ? 'Collapse Specs' : 'Expand Details'}
                    <ArrowRight className="w-3 h-3 text-[#C9A227]" />
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
