/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { ShoppingBag, User, Lock, Trash2, Plus, Minus, Star, Menu, X, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  onVaultClick: () => void;
  onSectionScroll: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onVaultClick, onSectionScroll }) => {
  const { cart, updateCartQuantity, removeFromCart, spotPrices } = useApp();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const navLinks = [
    { name: 'Gold', id: 'pricing' },
    { name: 'Silver', id: 'pricing' },
    { name: 'Collections', id: 'collections' },
    { name: 'Viewer', id: 'viewer' },
    { name: 'Why Texas Mint', id: 'why-us' },
    { name: 'Vault', id: 'vault' },
    { name: 'Technology', id: 'technology' },
  ];

  return (
    <>
      {/* Top Banner Bar */}
      <div className="w-full bg-[#0a0a0a] border-b border-[#222222]/60 text-[10px] tracking-[0.25em] text-[#888888] py-2 px-4 md:px-8 flex justify-between items-center z-50 relative font-display">
        <div className="flex items-center gap-1.5 font-semibold text-[#B99326]">
          <span className="w-1.5 h-1.5 bg-[#B99326] rounded-full inline-block animate-pulse"></span>
          <span>INDEPENDENT. DECENTRALIZED. TEXAN.</span>
        </div>
        <div className="hidden sm:flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="text-[#888888]">AU/USD SPOT:</span>
            <span className="text-[#C9A227] font-semibold">${spotPrices.gold.toLocaleString()}</span>
            <span className={`text-[9px] ${spotPrices.goldChange >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              {spotPrices.goldChange >= 0 ? '▲' : '▼'} {Math.abs(spotPrices.goldChange)}%
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[#888888]">AG/USD SPOT:</span>
            <span className="text-gray-300 font-semibold">${spotPrices.silver.toLocaleString()}</span>
            <span className={`text-[9px] ${spotPrices.silverChange >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              {spotPrices.silverChange >= 0 ? '▲' : '▼'} {Math.abs(spotPrices.silverChange)}%
            </span>
          </div>
        </div>
        <div className="text-[#B99326] flex items-center gap-1 font-bold">
          <Star className="w-3 h-3 fill-current" />
          <span>PRECIOUS METAL. LEGENDARY FUTURE.</span>
        </div>
      </div>

      {/* Main Transparent sticky Nav */}
      <nav
        id="navbar"
        className={`sticky top-0 w-full z-40 transition-all duration-300 font-display border-b ${
          isScrolled
            ? 'bg-[#0a0a0a]/95 backdrop-blur-md border-[#222222] py-3'
            : 'bg-transparent border-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 md:px-8 flex justify-between items-center">
          {/* Logo */}
          <div
            onClick={() => onSectionScroll('hero')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative w-9 h-9 flex items-center justify-center bg-gradient-to-br from-[#E2B72E] to-[#8C6B13] rounded-sm p-[1px]">
              <div className="w-full h-full bg-[#111111] flex items-center justify-center rounded-[1px] relative overflow-hidden">
                <Star className="w-5 h-5 text-[#C9A227] fill-[#C9A227] group-hover:scale-110 transition-transform duration-300" />
              </div>
            </div>
            <div>
              <div className="text-sm font-bold tracking-[0.25em] text-white leading-none uppercase">
                Texas Mint
              </div>
              <div className="text-[8px] tracking-[0.4em] text-[#C9A227] uppercase mt-0.5 font-bold">
                Gold ★ Silver ★ Legacy
              </div>
            </div>
          </div>

          {/* Desktop Nav Items */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.name}
                onClick={() => onSectionScroll(link.id)}
                className="text-xs uppercase font-medium tracking-[0.18em] text-gray-400 hover:text-white hover:scale-105 transition-all duration-200 cursor-pointer"
              >
                {link.name}
              </button>
            ))}
          </div>

          {/* Icons and Actions */}
          <div className="flex items-center gap-4">
            {/* Cart Icon */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 text-gray-300 hover:text-white hover:scale-105 transition-all duration-200 cursor-pointer"
              aria-label="Open Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {totalItems > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-[#C9A227] text-[#111111] font-bold text-[9px] w-4.5 h-4.5 rounded-full flex items-center justify-center shadow-lg">
                  {totalItems}
                </span>
              )}
            </button>

            {/* Profile Sign-in Mock / Direct Vault Access */}
            <button
              onClick={onVaultClick}
              className="hidden sm:flex items-center gap-2 px-4 py-2 border border-[#C9A227]/30 hover:border-[#C9A227] bg-[#C9A227]/5 hover:bg-[#C9A227]/15 rounded-sm transition-all duration-300 group cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-[#C9A227] group-hover:scale-110 transition-transform" />
              <span className="text-[10px] tracking-[0.2em] font-bold uppercase text-white">
                Vault Access
              </span>
            </button>

            {/* Mobile menu trigger */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-gray-300 hover:text-white cursor-pointer"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Dropdown */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="lg:hidden w-full bg-[#111111]/98 border-b border-[#222222] backdrop-blur-lg absolute left-0 overflow-hidden"
            >
              <div className="px-6 py-6 flex flex-col gap-5">
                {navLinks.map((link) => (
                  <button
                    key={link.name}
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onSectionScroll(link.id);
                    }}
                    className="text-left text-xs uppercase tracking-wider font-semibold text-gray-300 hover:text-[#C9A227] py-2"
                  >
                    {link.name}
                  </button>
                ))}
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onVaultClick();
                  }}
                  className="flex items-center justify-center gap-2 w-full py-3 bg-[#C9A227] text-[#111111] font-bold uppercase text-xs tracking-widest rounded-sm mt-2"
                >
                  <Lock className="w-4 h-4" />
                  Vault Dashboard
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Cart Drawer Sidebar */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.7 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-[#000000] z-50 cursor-pointer"
            />

            {/* Panel */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 h-full w-full max-w-md bg-[#161616] border-l border-[#2c2c2c] shadow-2xl z-50 flex flex-col font-sans"
            >
              {/* Header */}
              <div className="p-6 border-b border-[#2c2c2c] flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-[#C9A227]" />
                  <h3 className="text-sm font-bold uppercase tracking-widest text-white">
                    Precious Metals Cart
                  </h3>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="p-1 text-gray-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Cart List */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center">
                    <ShoppingBag className="w-12 h-12 text-gray-600 mb-4 stroke-[1]" />
                    <p className="text-gray-400 text-sm font-medium">Your portfolio cart is empty.</p>
                    <p className="text-gray-500 text-xs mt-1">Add pure gold & silver to begin building your legacy.</p>
                  </div>
                ) : (
                  cart.map((item) => (
                    <div
                      key={item.product.id}
                      className="flex gap-4 p-4 bg-[#1e1e1e] border border-[#2c2c2c] rounded-sm relative overflow-hidden group"
                    >
                      {/* Hover subtle gold border */}
                      <div className="absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-[#C9A227]/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 object-cover rounded-sm bg-black border border-[#333333]"
                      />

                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-white uppercase truncate">
                          {item.product.name}
                        </h4>
                        <p className="text-[10px] text-gray-400 mt-0.5">
                          {item.product.weight} • {item.product.purity}
                        </p>
                        <div className="flex justify-between items-center mt-3">
                          <div className="flex items-center border border-[#3a3a3a] rounded-sm">
                            <button
                              onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                              className="p-1 px-2 text-gray-400 hover:text-white cursor-pointer text-xs"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 text-xs font-semibold text-white">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                              className="p-1 px-2 text-gray-400 hover:text-white cursor-pointer text-xs"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                          <span className="text-xs font-bold text-[#C9A227]">
                            ${(item.product.price * item.quantity).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="p-1 text-gray-500 hover:text-red-400 self-start cursor-pointer transition-colors"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>

              {/* Checkout / Footer */}
              {cart.length > 0 && (
                <div className="p-6 border-t border-[#2c2c2c] bg-[#1a1a1a] space-y-4">
                  <div className="flex justify-between text-xs text-gray-400 font-semibold uppercase tracking-wider">
                    <span>Est. Shipping & Insurance</span>
                    <span className="text-green-400 font-medium font-mono text-[10px] tracking-normal">
                      COMPLIMENTARY SECURE DELIVERY
                    </span>
                  </div>
                  <div className="flex justify-between items-end">
                    <span className="text-xs uppercase tracking-widest text-gray-400 font-semibold">
                      Total Capital Est.
                    </span>
                    <span className="text-xl font-bold text-[#C9A227]">
                      ${cartTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div className="text-[10px] text-[#888888] leading-relaxed border-t border-[#2c2c2c] pt-3 flex gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#C9A227] shrink-0" />
                    <span>
                      Locked live rate. Pricing is based on real-time gold/silver spot markets and will hold for 10 minutes.
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      alert(`Thank you for choosing Texas Mint! A secure luxury wire transfer invoice has been generated for $${cartTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}. Out of sandbox, this would process secure credit line or automated bank wire.`);
                      setIsCartOpen(false);
                    }}
                    className="w-full py-4 bg-gradient-to-r from-[#E2B72E] to-[#8C6B13] hover:from-[#F0C948] hover:to-[#A37F1C] text-[#111111] font-bold text-xs uppercase tracking-[0.2em] rounded-sm transition-all duration-300 shadow-lg cursor-pointer"
                  >
                    Lock Rate & Checkout
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};
