/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, BookOpen, Clock } from 'lucide-react';
import { Article } from '../types';

const articles: Article[] = [
  {
    id: '1',
    title: 'The Sovereign Pivot: Why Global Central Banks are Hoarding Physical Bullion',
    category: 'Market Intelligence',
    excerpt: 'An in-depth analysis of major sovereign currency shifts, rising deficit loads, and the historic move back to physical gold reserves.',
    date: 'July 28, 2026',
    readTime: '6 min read',
    author: 'Chief Analyst, Austin Capital',
    image: 'https://images.unsplash.com/photo-1610374792793-f016b77ca51a?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '2',
    title: 'Precision Refining: Inside the Class-100 Cleanroom Coin Striking Facility',
    category: 'Mint Technology',
    excerpt: 'An exclusive documentary detailing our vacuum heat-treatments, 1000-ton hydraulic presses, and anti-counterfeiting rim carvings.',
    date: 'July 15, 2026',
    readTime: '4 min read',
    author: 'VP of Minting Operations',
    image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '3',
    title: 'Securing Generational Freedom: Wealth Protection in the Digital Age',
    category: 'Wealth Strategy',
    excerpt: 'Why physical gold remains the ultimate hedge against sovereign debt, cyber currency defaults, and global inflationary spirals.',
    date: 'June 29, 2026',
    readTime: '8 min read',
    author: 'Founders Council Advisory',
    image: 'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&q=80&w=800'
  }
];

export const NewsMagazine: React.FC = () => {
  return (
    <section id="news" className="bg-[#0a0a0a] py-24 border-b border-white/10 font-display relative overflow-hidden select-none">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Section Title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-4">
          <div>
            <span className="text-[10px] font-bold tracking-[0.3em] text-[#C9A227] uppercase">Sovereign Chronicles</span>
            <h2 className="text-3xl sm:text-4xl font-black tracking-[0.15em] text-white uppercase mt-3">
              MINT EDITORIAL & ANALYSIS
            </h2>
            <div className="h-0.5 w-16 bg-[#C9A227] mt-4" />
          </div>
          <p className="text-xs text-gray-400 max-w-md leading-relaxed">
            Read high-quality economic briefings, gold and silver standard analysis, and operational releases directly from our advisory boards.
          </p>
        </div>

        {/* Editorial Layout Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {articles.map((art, idx) => (
            <motion.article
              key={art.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="flex flex-col bg-[#0d0d0d] border border-white/10 hover:border-[#C9A227]/40 rounded-sm overflow-hidden group cursor-pointer transition-all duration-300"
            >
              {/* Picture banner */}
              <div className="relative h-48 overflow-hidden bg-black border-b border-white/10">
                <img
                  src={art.image}
                  alt={art.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent opacity-85" />
                
                {/* Float Category Tag */}
                <span className="absolute top-4 left-4 text-[9px] font-bold tracking-widest text-[#C9A227] uppercase bg-[#0a0a0a]/90 border border-[#C9A227]/20 px-2.5 py-1 rounded-sm">
                  {art.category}
                </span>
              </div>

              {/* Text Body */}
              <div className="flex-1 p-6 flex flex-col justify-between space-y-4 text-left">
                <div className="space-y-3">
                  {/* Meta stats */}
                  <div className="flex items-center gap-3 text-[9px] font-bold uppercase text-gray-500">
                    <span>{art.date}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-[#C9A227]" />
                      {art.readTime}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-sm font-black tracking-widest text-white uppercase group-hover:text-[#C9A227] transition-colors leading-snug">
                    {art.title}
                  </h3>

                  {/* Excerpt */}
                  <p className="text-[11px] text-gray-400 leading-relaxed font-sans">
                    {art.excerpt}
                  </p>
                </div>

                {/* Footer metadata */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                  <span className="text-[10px] font-bold tracking-wider text-gray-500 uppercase font-display">
                    By {art.author}
                  </span>
                  
                  <span className="text-[#C9A227] text-[9px] font-bold uppercase tracking-widest inline-flex items-center gap-1 group-hover:underline">
                    Read Article
                    <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </span>
                </div>
              </div>
            </motion.article>
          ))}
        </div>

      </div>
    </section>
  );
};
