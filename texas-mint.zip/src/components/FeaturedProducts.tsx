/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Product } from '../types';
import { ShoppingCart, Star, Heart, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface ShinyReflectCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
  isWishlisted: boolean;
  onSelectViewer: (productId: string) => void;
}

const ShinyReflectCard: React.FC<ShinyReflectCardProps> = ({
  product,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
  onSelectViewer
}) => {
  const [coords, setCoords] = useState({ x: 50, y: 50 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setCoords({ x, y });
  };

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative flex flex-col justify-between h-full bg-[#0d0d0d] border border-white/10 hover:border-[#C9A227]/50 rounded-sm p-5 transition-all duration-300 overflow-hidden group select-none"
      style={{
        boxShadow: isHovered ? '0 10px 30px -10px rgba(201, 162, 39, 0.15)' : 'none'
      }}
    >
      {/* Dynamic Metal Highlight Overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          background: `radial-gradient(circle at ${coords.x}% ${coords.y}%, rgba(201, 162, 39, 0.06) 0%, rgba(255, 255, 255, 0.01) 50%, transparent 100%)`
        }}
      />

      {/* Shimmer sweep line */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="w-[150%] h-full bg-gradient-to-r from-transparent via-white/5 to-transparent -skew-x-12 translate-x-[-150%] group-hover:translate-x-[150%] transition-transform duration-1000 ease-out" />
      </div>

      {/* Top Details & Wishlist */}
      <div className="flex justify-between items-start">
        <span className="text-[9px] font-bold tracking-widest text-[#C9A227] uppercase bg-[#C9A227]/10 px-2.5 py-1 rounded-full border border-[#C9A227]/10">
          {product.rarity || 'Bullion'}
        </span>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product.id);
          }}
          className="p-1.5 text-gray-500 hover:text-red-400 hover:scale-110 transition-all cursor-pointer"
          aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'text-red-500 fill-red-500' : ''}`} />
        </button>
      </div>

      {/* Coin Render Image */}
      <div
        onClick={() => onSelectViewer(product.id)}
        className="my-6 relative w-full aspect-square flex items-center justify-center cursor-pointer"
      >
        <motion.div
          animate={{
            rotate: isHovered ? [0, 4, -4, 0] : 0,
            scale: isHovered ? 1.04 : 1
          }}
          transition={{ duration: 0.8, ease: 'easeInOut' }}
          className="w-40 h-40 rounded-full overflow-hidden shadow-[0_15px_35px_rgba(0,0,0,0.6)] border border-[#333333] relative"
        >
          <img
            src={product.image}
            alt={product.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          {/* Static premium glint effect on image */}
          <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none group-hover:opacity-0 transition-opacity" />
        </motion.div>

        {/* Action helper overlay */}
        <div className="absolute bottom-[-10px] left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-[8px] font-bold tracking-widest text-gray-400 uppercase bg-[#111111]/90 px-3 py-1 border border-[#333333] rounded-sm pointer-events-none">
          Click to inspect in 3D
        </div>
      </div>

      {/* Copy & Pricing */}
      <div className="space-y-1 text-center font-display">
        <h3 className="text-xs font-black text-white tracking-[0.15em] uppercase group-hover:text-[#C9A227] transition-colors">
          {product.name.replace(' Bullion Coin', '')}
        </h3>
        <p className="text-[10px] tracking-wider text-gray-400">
          {product.weight} • {product.purity}
        </p>
        <div className="pt-2 font-mono text-sm font-bold text-[#C9A227] flex items-center justify-center gap-1.5 group-hover:scale-105 transition-transform">
          <span>${product.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          <span className="text-[9px] text-[#888888] font-sans font-normal tracking-wide">USD</span>
        </div>
      </div>

      {/* Buy Button */}
      <div className="mt-5 pt-3 border-t border-[#222222] flex gap-2">
        <button
          onClick={() => onSelectViewer(product.id)}
          className="flex-1 py-2.5 border border-[#333333] hover:border-[#C9A227]/50 text-[10px] tracking-widest font-extrabold uppercase text-gray-300 hover:text-white rounded-sm transition-all cursor-pointer text-center"
        >
          Inspect
        </button>
        <button
          onClick={() => onAddToCart(product)}
          className="flex-1 py-2.5 gold-gradient text-black font-black text-[10px] tracking-widest uppercase rounded-sm transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg hover:brightness-110"
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          Add
        </button>
      </div>
    </motion.div>
  );
};

export const FeaturedProducts: React.FC<{
  onSelectViewer: (productId: string) => void;
  onSectionScroll: (sectionId: string) => void;
}> = ({ onSelectViewer, onSectionScroll }) => {
  const { products, addToCart, toggleWishlist, wishlist } = useApp();

  return (
    <section id="pricing" className="bg-[#0a0a0a] py-24 border-b border-white/10 font-display relative overflow-hidden">
      {/* Background aesthetics */}
      <div className="absolute top-1/3 right-10 w-[500px] h-[500px] bg-[#C9A227]/2 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Hero-Text column: 3cols */}
          <div className="lg:col-span-3 flex flex-col justify-between p-6 bg-gradient-to-b from-[#0a0a0a] to-[#121212] border border-white/10 rounded-sm relative overflow-hidden">
            {/* Subtle glow border */}
            <div className="absolute top-0 left-0 w-1 h-12 bg-[#C9A227]" />
            <div>
              <h2 className="text-xl sm:text-2xl font-black tracking-[0.18em] text-white uppercase leading-tight select-none">
                MINTED IN TEXAS.<br />
                FOR THE WORLD.
              </h2>
              <p className="text-xs tracking-relaxed text-gray-400 mt-6 select-none leading-relaxed">
                Every coin tells a story of independence, innovation, and enduring strength. Own a physical piece of that legacy. Guaranteed purity, sealed security, absolute privacy.
              </p>
            </div>
            <div className="mt-8 lg:mt-0">
              <button
                onClick={() => onSectionScroll('collections')}
                className="py-3 px-5 border border-[#C9A227]/40 hover:border-[#C9A227] bg-[#C9A227]/5 hover:bg-[#C9A227]/10 text-[#C9A227] hover:text-white font-bold text-[10px] tracking-[0.2em] uppercase rounded-sm transition-all flex items-center justify-center gap-2.5 cursor-pointer group w-full"
              >
                Explore Collections
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          {/* Central Cards Grid: 6cols */}
          <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-3 gap-6">
            {products.map((product) => (
              <ShinyReflectCard
                key={product.id}
                product={product}
                onAddToCart={addToCart}
                onToggleWishlist={toggleWishlist}
                isWishlisted={wishlist.includes(product.id)}
                onSelectViewer={onSelectViewer}
              />
            ))}
          </div>

          {/* Right Hero-Text column: 3cols */}
          <div className="lg:col-span-3 flex flex-col justify-between p-6 bg-gradient-to-b from-[#121212] to-[#0a0a0a] border border-white/10 rounded-sm relative overflow-hidden text-right items-end">
            <div className="absolute top-0 right-0 w-1 h-12 bg-[#C9A227]" />
            <div className="w-full">
              <div className="flex items-center justify-end gap-1.5 text-[#C9A227]">
                <Star className="w-3 h-3 fill-[#C9A227]" />
                <span className="text-[9px] font-bold tracking-[0.2em] uppercase">Build Your Legacy</span>
              </div>
              <h2 className="text-lg sm:text-xl font-black tracking-[0.18em] text-white uppercase leading-tight mt-3 select-none">
                INVEST IN<br />
                WHAT LASTS.
              </h2>
              <p className="text-xs text-gray-400 mt-6 select-none leading-relaxed">
                Gold. Silver. Freedom. Ensure safety against system inflation and market instability. Preserve wealth that crosses generational generations.
              </p>
            </div>
            <div className="mt-8 lg:mt-0 w-full">
              <button
                onClick={() => onSectionScroll('collections')}
                className="py-3 px-5 bg-gradient-to-r from-[#2c2c2c] to-[#1f1f1f] hover:from-[#3a3a3a] hover:to-[#222222] text-white font-bold text-[10px] tracking-[0.2em] uppercase rounded-sm border border-white/10 hover:border-white/30 transition-all flex items-center justify-center gap-2.5 cursor-pointer group w-full"
              >
                View Bullion Catalog
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
