/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

interface Testimonial {
  id: string;
  name: string;
  role: string;
  quote: string;
  rating: number;
}

const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sampson Caldwell',
    role: 'Managing Partner, Caldwell & Sons Family Office',
    quote: "Securing physical precious metals in independent, allocated facilities was a critical priority for our asset preservation strategy. The Texas Mint Vault system offers the finest modern digital dashboard combined with heavy bedrock defense.",
    rating: 5
  },
  {
    id: '2',
    name: 'Elena Rostova',
    role: 'Private Collection Curator',
    quote: "The Lone Star Gold proof coin is an artistic masterclass. The frosted relief of the central star against the pristine mirror background easily rivals the finest numismatic specimens from major federal mints around the globe.",
    rating: 5
  },
  {
    id: '3',
    name: 'Marcus Vance',
    role: 'Sovereign Treasury Consultant',
    quote: "We chose Texas Mint for our private reserves because of their full transparency, class-100 cleanroom precision minting, and advanced multi-signature security vaults. Highly secure and meticulously managed.",
    rating: 5
  }
];

export const Testimonials: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };

  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  const active = testimonials[activeIndex];

  return (
    <section className="bg-[#0a0a0a] py-24 border-b border-white/10 font-display relative overflow-hidden select-none">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left info column: 4 cols */}
          <div className="lg:col-span-4 text-left space-y-6">
            <div>
              <span className="text-[10px] font-bold tracking-[0.3em] text-[#C9A227] uppercase">Sovereign Validation</span>
              <h2 className="text-3xl sm:text-4xl font-black tracking-[0.15em] text-white uppercase mt-3">
                TRUSTED BY LEADING INVESTORS
              </h2>
              <div className="h-0.5 w-16 bg-[#C9A227] mt-4" />
            </div>
            <p className="text-xs text-gray-400 leading-relaxed font-sans">
              Discover why private family offices, curated collectors, and institutional portfolio managers entrust their wealth preservation to the Texas Mint.
            </p>

            {/* Slider triggers */}
            <div className="flex items-center gap-3 pt-4">
              <button
                onClick={prevTestimonial}
                className="w-10 h-10 border border-white/10 bg-[#0d0d0d] hover:border-[#C9A227] hover:bg-[#C9A227]/5 text-white hover:text-[#C9A227] rounded-full flex items-center justify-center cursor-pointer transition-all"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={nextTestimonial}
                className="w-10 h-10 border border-white/10 bg-[#0d0d0d] hover:border-[#C9A227] hover:bg-[#C9A227]/5 text-white hover:text-[#C9A227] rounded-full flex items-center justify-center cursor-pointer transition-all"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Right quote slider: 8 cols */}
          <div className="lg:col-span-8 bg-[#0d0d0d] border border-white/10 p-8 md:p-12 rounded-sm relative min-h-[300px] flex flex-col justify-between font-display">
            <Quote className="absolute right-8 top-8 w-12 h-12 text-gray-800/40 select-none pointer-events-none" />

            <div className="space-y-6 text-left">
              {/* Stars rating */}
              <div className="flex items-center gap-1">
                {[...Array(active.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-[#C9A227] fill-[#C9A227]" />
                ))}
              </div>

              {/* Quote text */}
              <AnimatePresence mode="wait">
                <motion.p
                  key={active.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.4 }}
                  className="text-sm md:text-base text-gray-300 leading-relaxed font-sans select-none"
                >
                  "{active.quote}"
                </motion.p>
              </AnimatePresence>
            </div>

            {/* Author details */}
            <div className="pt-8 border-t border-white/10 flex items-center justify-between flex-wrap gap-4 text-left">
              <div>
                <h4 className="text-xs font-black tracking-widest text-white uppercase font-display">
                  {active.name}
                </h4>
                <p className="text-[10px] text-gray-500 uppercase font-semibold mt-1">
                  {active.role}
                </p>
              </div>
              
              {/* Small stamp label */}
              <span className="text-[8px] tracking-[0.25em] font-extrabold text-[#C9A227] uppercase border border-[#C9A227]/20 px-2.5 py-1 bg-[#C9A227]/5">
                Verified Signatory
              </span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
