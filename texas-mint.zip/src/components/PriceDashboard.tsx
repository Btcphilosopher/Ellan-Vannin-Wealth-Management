/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { TrendingUp, TrendingDown, Bell, Trash2, Sliders, Activity, AlertCircle, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const PriceDashboard: React.FC = () => {
  const { spotPrices, priceAlerts, addPriceAlert, removePriceAlert } = useApp();
  const [activeTab, setActiveTab] = useState<'gold' | 'silver'>('gold');
  const [alertTarget, setAlertTarget] = useState<string>('');
  const [alertType, setAlertType] = useState<'above' | 'below'>('above');
  const [notification, setNotification] = useState<string | null>(null);

  const historicalData = activeTab === 'gold' ? spotPrices.goldHistorical : spotPrices.silverHistorical;
  const currentPrice = activeTab === 'gold' ? spotPrices.gold : spotPrices.silver;
  const currentChange = activeTab === 'gold' ? spotPrices.goldChange : spotPrices.silverChange;
  const colorTheme = activeTab === 'gold' ? '#C9A227' : '#D9D9D9';

  const handleAddAlert = (e: React.FormEvent) => {
    e.preventDefault();
    const targetVal = parseFloat(alertTarget);
    if (isNaN(targetVal) || targetVal <= 0) return;

    addPriceAlert(activeTab, targetVal, alertType);
    setAlertTarget('');

    setNotification(`Alert established! We will monitor if Spot ${activeTab.toUpperCase()} crosses ${alertType} $${targetVal}.`);
    setTimeout(() => setNotification(null), 4000);
  };

  // Calculate high, low, avg for metrics
  const values = historicalData.map(d => d.value);
  const highest = Math.max(...values, currentPrice);
  const lowest = Math.min(...values, currentPrice);
  const average = Math.round((values.reduce((sum, v) => sum + v, 0) / values.length) * 100) / 100;

  return (
    <section id="pricing" className="bg-[#0a0a0a] py-24 border-b border-white/10 font-display relative overflow-hidden select-none">
      {/* Background radial highlight */}
      <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] bg-[#C9A227]/2 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-bold tracking-[0.3em] text-[#C9A227] uppercase">Global Spot Exchange</span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-[0.15em] text-white uppercase mt-3">MARKET FEED TERMINAL</h2>
          <div className="h-0.5 w-16 bg-[#C9A227] mx-auto mt-4" />
          <p className="text-xs text-gray-400 mt-4 leading-relaxed">
            Direct high-frequency telemetry tracking spot prices for .9999 gold and .999 silver bullion. Set customized threshold limits to lock and preserve wealth instantly.
          </p>
        </div>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Main Chart Terminal: 8 cols */}
          <div className="lg:col-span-8 bg-[#0d0d0d] border border-white/10 rounded-sm p-6 flex flex-col justify-between">
            <div>
              {/* Header Toggles */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
                <div className="flex gap-2">
                  <button
                    onClick={() => setActiveTab('gold')}
                    className={`px-5 py-2.5 text-[10px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                      activeTab === 'gold'
                        ? 'border-[#C9A227] bg-[#C9A227]/5 text-[#C9A227]'
                        : 'border-white/10 text-gray-500 hover:text-white bg-transparent'
                    }`}
                  >
                    ★ Gold (AU-USD)
                  </button>
                  <button
                    onClick={() => setActiveTab('silver')}
                    className={`px-5 py-2.5 text-[10px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                      activeTab === 'silver'
                        ? 'border-slate-400 bg-slate-400/5 text-slate-300'
                        : 'border-white/10 text-gray-500 hover:text-white bg-transparent'
                    }`}
                  >
                    ★ Silver (AG-USD)
                  </button>
                </div>

                {/* Spot Readout */}
                <div className="flex items-center gap-4 text-left">
                  <div>
                    <span className="text-[9px] text-gray-500 uppercase font-semibold tracking-wider block">Live Spot Price</span>
                    <span className="text-xl font-bold text-white font-mono leading-none">
                      ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className={`px-2 py-1 rounded-sm flex items-center gap-1.5 text-[10px] font-bold ${
                    currentChange >= 0 ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'
                  }`}>
                    {currentChange >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                    <span>{currentChange >= 0 ? '+' : ''}{currentChange.toFixed(2)}%</span>
                  </div>
                </div>
              </div>

              {/* Responsive Chart Container */}
              <div className="h-80 w-full pt-8 font-mono text-[9px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={historicalData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={colorTheme} stopOpacity={0.25} />
                        <stop offset="95%" stopColor={colorTheme} stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#161616" vertical={false} />
                    <XAxis
                      dataKey="date"
                      stroke="#444444"
                      fontSize={9}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      stroke="#444444"
                      fontSize={9}
                      tickLine={false}
                      axisLine={false}
                      domain={['auto', 'auto']}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#111111',
                        border: '1px solid #333333',
                        color: '#ffffff',
                        fontSize: '11px',
                        borderRadius: '2px',
                        fontFamily: 'monospace'
                      }}
                      labelClassName="text-gray-500 text-[10px] uppercase font-sans font-bold"
                    />
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke={colorTheme}
                      strokeWidth={1.5}
                      fillOpacity={1}
                      fill="url(#chartGradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Performance Stats row */}
            <div className="grid grid-cols-3 gap-4 border-t border-white/10 pt-6 mt-6">
              <div className="text-left bg-[#0d0d0d] p-3 rounded-sm border border-white/5">
                <span className="text-[8px] text-gray-500 uppercase tracking-widest font-semibold block">30D Peak High</span>
                <span className="text-xs font-bold text-white font-mono mt-1 block">${highest.toLocaleString()}</span>
              </div>
              <div className="text-left bg-[#0d0d0d] p-3 rounded-sm border border-white/5">
                <span className="text-[8px] text-gray-500 uppercase tracking-widest font-semibold block">30D Floor Low</span>
                <span className="text-xs font-bold text-white font-mono mt-1 block">${lowest.toLocaleString()}</span>
              </div>
              <div className="text-left bg-[#0d0d0d] p-3 rounded-sm border border-white/5">
                <span className="text-[8px] text-gray-500 uppercase tracking-widest font-semibold block">30D Moving Avg</span>
                <span className="text-xs font-bold text-white font-mono mt-1 block">${average.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Price Alerts and Action Panel: 4 cols */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            {/* Price alerts terminal */}
            <div className="bg-[#0d0d0d] border border-white/10 p-6 rounded-sm flex-1 flex flex-col justify-between">
              <div>
                <h3 className="text-[11px] font-bold tracking-[0.18em] text-white uppercase border-b border-white/10 pb-3 flex items-center gap-2">
                  <Bell className="w-4 h-4 text-[#C9A227]" />
                  Price Alert Terminal
                </h3>

                {/* Form to establish new alarm */}
                <form onSubmit={handleAddAlert} className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setAlertType('above')}
                      className={`py-2 text-[9px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                        alertType === 'above'
                          ? 'border-[#C9A227] bg-[#C9A227]/5 text-white'
                          : 'border-white/10 text-gray-500 bg-transparent'
                      }`}
                    >
                      Crosses Above ▲
                    </button>
                    <button
                      type="button"
                      onClick={() => setAlertType('below')}
                      className={`py-2 text-[9px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                        alertType === 'below'
                          ? 'border-[#C9A227] bg-[#C9A227]/5 text-white'
                          : 'border-white/10 text-gray-500 bg-transparent'
                      }`}
                    >
                      Drops Below ▼
                    </button>
                  </div>

                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 font-bold text-xs">$</span>
                    <input
                      type="number"
                      step="0.01"
                      required
                      placeholder={`Target ${activeTab === 'gold' ? 'AU' : 'AG'} Price`}
                      value={alertTarget}
                      onChange={(e) => setAlertTarget(e.target.value)}
                      className="w-full bg-[#0a0a0a] border border-white/10 focus:border-[#C9A227] rounded-sm py-2.5 pl-8 pr-4 text-xs font-mono text-white placeholder-gray-600 focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 gold-gradient text-black font-extrabold rounded-sm transition-all cursor-pointer"
                      aria-label="Set Alert"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </form>

                {/* Notification toast simulation */}
                <AnimatePresence>
                  {notification && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-3 p-3 bg-[#C9A227]/10 border border-[#C9A227]/20 rounded-sm flex items-start gap-2"
                    >
                      <Activity className="w-4 h-4 text-[#C9A227] shrink-0 mt-0.5" />
                      <p className="text-[9px] text-[#C9A227] leading-relaxed uppercase tracking-wider font-semibold">
                        {notification}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Active Alerts List */}
                <div className="mt-6 space-y-2.5">
                  <span className="text-[9px] font-bold tracking-widest text-gray-500 uppercase block">Active Watchers ({priceAlerts.length})</span>
                  {priceAlerts.length === 0 ? (
                    <div className="border border-dashed border-white/10 p-4 text-center rounded-sm text-gray-600 text-[10px] uppercase font-semibold">
                      No active threshold watchdogs set.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-32 overflow-y-auto pr-1">
                      {priceAlerts.map((alert) => (
                        <div
                          key={alert.id}
                          className={`flex justify-between items-center p-2.5 bg-[#0a0a0a] border rounded-sm ${
                            alert.active ? 'border-white/10' : 'border-green-500/30 opacity-60'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              alert.active ? 'bg-[#C9A227] animate-pulse' : 'bg-green-500'
                            }`} />
                            <div className="text-left leading-none">
                              <span className="text-[10px] font-bold text-white uppercase font-mono">{alert.metal.toUpperCase()}</span>
                              <span className="text-[9px] text-gray-500 uppercase ml-2 tracking-wide font-semibold">
                                {alert.type === 'above' ? '≥' : '≤'} ${alert.target.toLocaleString()}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {!alert.active && (
                              <span className="text-[8px] bg-green-500/10 text-green-400 font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wide">
                                Fired
                              </span>
                            )}
                            <button
                              onClick={() => removePriceAlert(alert.id)}
                              className="text-gray-600 hover:text-red-400 cursor-pointer p-0.5"
                              aria-label="Delete alert"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Bottom security assurance disclosure */}
              <div className="border-t border-white/10 pt-4 mt-6 flex gap-2">
                <AlertCircle className="w-4 h-4 text-[#C9A227] shrink-0" />
                <p className="text-[9px] text-gray-500 leading-normal font-light">
                  Rate validation utilizes London Bullion Market Association (LBMA) feeds with a micro-variance of ±0.03%. Rate locking is guaranteed for verified account portfolios.
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
