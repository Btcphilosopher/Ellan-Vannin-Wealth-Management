/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Shield, Lock, Scale, Truck, Star } from 'lucide-react';

interface TrustBadge {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  sub: string;
}

const badges: TrustBadge[] = [
  {
    icon: Scale,
    title: '.999+ PURE METALS',
    sub: 'UNCOMPROMISING PURITY',
  },
  {
    icon: Shield,
    title: 'VERIFIED AUTHENTICITY',
    sub: 'SECURED DIGITAL REGISTRY',
  },
  {
    icon: Star,
    title: 'MINTED IN TEXAS',
    sub: 'INDEPENDENT CRAFTSMANSHIP',
  },
  {
    icon: Lock,
    title: 'SECURE STORAGE',
    sub: 'INSURED VAULT CHAMBERS',
  },
  {
    icon: Truck,
    title: 'FAST & INSURED',
    sub: 'DISCREET ARMORED DELIVERY',
  },
];

export const TrustBar: React.FC = () => {
  return (
    <section
      id="trustbar"
      className="w-full bg-[#0a0a0a] border-y border-white/10 py-8 relative overflow-hidden font-display"
    >
      {/* Background soft glow */}
      <div className="absolute top-1/2 -translate-y-1/2 left-1/4 w-96 h-20 bg-[#C9A227]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6 md:gap-4 items-center">
          {badges.map((badge, idx) => {
            const Icon = badge.icon;
            return (
              <motion.div
                key={badge.title}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-20px' }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="flex flex-col sm:flex-row items-center sm:items-start md:justify-center gap-3 text-center sm:text-left group"
              >
                {/* Icon Container */}
                <div className="w-10 h-10 shrink-0 rounded-sm border border-[#2c2c2c] group-hover:border-[#C9A227]/40 bg-[#161616] group-hover:bg-[#C9A227]/5 flex items-center justify-center transition-all duration-300">
                  <Icon className="w-4.5 h-4.5 text-[#C9A227] group-hover:scale-110 transition-transform duration-300" />
                </div>

                {/* Text Details */}
                <div className="min-w-0">
                  <h4 className="text-[10px] sm:text-[11px] font-bold tracking-[0.18em] text-white uppercase leading-tight select-none">
                    {badge.title}
                  </h4>
                  <p className="text-[9px] tracking-[0.1em] text-gray-500 uppercase font-semibold mt-1 select-none">
                    {badge.sub}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
