/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Star, ChevronDown } from 'lucide-react';

interface HeroProps {
  onSectionScroll: (sectionId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onSectionScroll }) => {
  return (
    <section
      id="hero"
      className="relative min-h-[92vh] flex items-center justify-center overflow-hidden bg-[#0a0a0a] px-4 md:px-8 pt-10"
    >
      {/* Background Cinematic Image with Luxury Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/texas_mint_hero_bg_1785426062239.jpg"
          alt="Texas Futurist Skyline"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-40 scale-105 filter brightness-50 contrast-125"
        />
        {/* Soft atmospheric gradient and lighting overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/50 to-[#0a0a0a]/80 z-10" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-transparent to-[#0a0a0a] z-10" />
        <div className="absolute inset-0 bg-radial-gradient from-transparent via-[#0a0a0a]/10 to-[#0a0a0a] z-10" />

        {/* Golden Horizon Glow */}
        <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-[#0a0a0a] to-transparent z-20 pointer-events-none" />
      </div>

      {/* Subtle Background Textures & Glows from Bold Typography theme */}
      <div className="absolute inset-0 opacity-30 pointer-events-none overflow-hidden z-10">
        <div className="absolute top-[-10%] right-[-10%] w-[600px] h-[600px] rounded-full bg-[#C9A227] blur-[150px] opacity-15"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-blue-900 blur-[150px] opacity-10"></div>
        <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(255,255,255,0.05) 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
      </div>

      {/* Floating Sparkles/Particles */}
      <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
        {[...Array(15)].map((_, i) => {
          const size = Math.random() * 4 + 2;
          const left = Math.random() * 100;
          const top = Math.random() * 100;
          const duration = Math.random() * 8 + 6;
          const delay = Math.random() * 4;

          return (
            <motion.div
              key={i}
              className="absolute bg-[#C9A227] rounded-full opacity-40 blur-[1px]"
              style={{
                width: size,
                height: size,
                left: `${left}%`,
                top: `${top}%`,
              }}
              animate={{
                y: [-20, -120],
                x: [0, Math.sin(i) * 20],
                opacity: [0, 0.7, 0],
              }}
              transition={{
                duration,
                repeat: Infinity,
                delay,
                ease: 'easeInOut',
              }}
            />
          );
        })}
      </div>

      {/* Foreground Content */}
      <div className="relative z-20 max-w-7xl mx-auto w-full flex flex-col items-start justify-center text-left py-20">
        {/* Decorative Tagline */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex items-center gap-2 mb-6 font-display"
        >
          <div className="h-[1px] w-12 bg-[#C9A227]"></div>
          <span className="text-[10px] sm:text-xs font-bold text-[#C9A227] tracking-[0.4em] uppercase">
            Established 1836 // Future 2077
          </span>
        </motion.div>

        {/* Big Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.4 }}
          className="hero-text font-display mb-8 text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-500 uppercase select-none tracking-tighter"
        >
          PRECIOUS METALS.<br />TEXAN VALUES.
        </motion.h1>

        {/* Supporting Copy */}
        <motion.p
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.6 }}
          className="text-base sm:text-lg text-gray-400 max-w-md leading-relaxed font-light mb-10 select-none"
        >
          The Texas Mint engineers world-class gold and silver bullion for global investors, sovereign collectors, and the next generations of wealth.
        </motion.p>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row items-stretch sm:items-center gap-6 w-full sm:w-auto font-sans"
        >
          <button
            onClick={() => onSectionScroll('pricing')}
            className="px-10 py-5 gold-gradient text-black font-black uppercase text-xs tracking-widest rounded-sm hover:brightness-110 transition-all duration-300 shadow-xl flex items-center justify-center gap-3 cursor-pointer group"
          >
            Buy Gold Bullion
            <span className="text-sm transition-transform group-hover:translate-x-1.5">→</span>
          </button>

          <button
            onClick={() => onSectionScroll('pricing')}
            className="px-10 py-5 border border-white/20 hover:border-white/60 bg-white/5 hover:bg-white/10 text-white font-black uppercase text-xs tracking-widest rounded-sm transition-all duration-300 backdrop-blur-sm flex items-center justify-center gap-3 cursor-pointer group"
          >
            Explore Silver
            <span className="text-sm transition-transform group-hover:translate-x-1.5">→</span>
          </button>
        </motion.div>
      </div>

      {/* Animated Scroll Down Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 1, 0] }}
        transition={{ duration: 2.5, repeat: Infinity, delay: 1.5 }}
        onClick={() => onSectionScroll('trustbar')}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 cursor-pointer"
      >
        <span className="text-[9px] uppercase tracking-[0.3em] text-[#C9A227] font-semibold">
          Scroll to explore
        </span>
        <ChevronDown className="w-4 h-4 text-[#C9A227] animate-bounce" />
      </motion.div>
    </section>
  );
};
