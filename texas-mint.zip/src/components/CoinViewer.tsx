/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { motion, AnimatePresence } from 'motion/react';
import { Sliders, RotateCw, ZoomIn, ZoomOut, Check, Sparkles, ShieldAlert, ArrowRight, Star } from 'lucide-react';

export const CoinViewer: React.FC = () => {
  const { products, activeCoinId, setActiveCoinId } = useApp();
  const [rotation, setRotation] = useState(0); // in degrees
  const [zoom, setZoom] = useState(1); // 1 to 2.5
  const [activeFace, setActiveFace] = useState<'obverse' | 'reverse'>('obverse');
  const [activeMetal, setActiveMetal] = useState<'gold' | 'silver'>('gold');
  const [finish, setFinish] = useState<'proof' | 'satin'>('proof');
  const [isDragging, setIsDragging] = useState(false);
  const dragStartX = useRef(0);
  const coinRef = useRef<HTMLDivElement>(null);
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);

  const activeProduct = products.find((p) => p.id === activeCoinId) || products[0];

  // Sync active metal when selected product changes
  useEffect(() => {
    setActiveMetal(activeProduct.type);
  }, [activeCoinId]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStartX.current = e.clientX;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const deltaX = e.clientX - dragStartX.current;
    setRotation((prev) => prev + deltaX * 0.8);
    dragStartX.current = e.clientX;
  };

  const handleMouseUpOrLeave = () => {
    setIsDragging(false);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true);
    dragStartX.current = e.touches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    const deltaX = e.touches[0].clientX - dragStartX.current;
    setRotation((prev) => prev + deltaX * 0.8);
    dragStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  const resetControls = () => {
    setRotation(0);
    setZoom(1);
    setActiveFace('obverse');
    setFinish('proof');
  };

  // Switch between coins
  const selectCoin = (id: string) => {
    setActiveCoinId(id);
    resetControls();
  };

  // Determine if showing front or back side based on rotation angle (card flip effect)
  const normalizedRotation = ((rotation % 360) + 360) % 360;
  const isReverseShowing = normalizedRotation > 90 && normalizedRotation < 270;

  // Metal color filters for dynamic coloring of coin textures
  const getMetalStyles = () => {
    if (activeMetal === 'gold') {
      return {
        filter: finish === 'proof' ? 'contrast(1.1) brightness(1.05)' : 'saturate(0.85) brightness(1.05) contrast(0.95)',
        overlayColor: 'from-amber-400/20 via-transparent to-[#8C6B13]/30',
        borderColor: 'border-[#E2B72E]/20'
      };
    } else {
      return {
        filter: finish === 'proof'
          ? 'grayscale(1) contrast(1.2) brightness(1.1)'
          : 'grayscale(1) saturate(0) brightness(1.1) contrast(0.9)',
        overlayColor: 'from-slate-200/20 via-transparent to-slate-700/20',
        borderColor: 'border-slate-500/20'
      };
    }
  };

  const metalStyles = getMetalStyles();

  // Highlight points/hotspots
  const hotspots = [
    {
      id: 'purity',
      top: '20%',
      left: '30%',
      title: 'Guaranteed Purity',
      desc: activeMetal === 'gold' ? 'Certified .9999 fine investment gold, verified at production.' : 'Certified .999 fine investment silver, verified at production.'
    },
    {
      id: 'engraving',
      top: '50%',
      left: '50%',
      title: 'High-Relief Stamping',
      desc: '3D high-relief minting provides extraordinary physical texture and premium weight.'
    },
    {
      id: 'security',
      top: '75%',
      left: '60%',
      title: 'Micro-Laser Mark',
      desc: 'Anti-counterfeiting micro-mark on the rim containing serialized molecular validation.'
    }
  ];

  return (
    <section id="viewer" className="bg-[#0a0a0a] py-24 border-b border-white/10 font-display relative overflow-hidden select-none">
      {/* Background Soft Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-tr from-[#C9A227]/3 to-transparent rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-bold tracking-[0.3em] text-[#C9A227] uppercase">Interactive Laboratory</span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-[0.15em] text-white uppercase mt-3 font-display">COIN INSPECTOR</h2>
          <div className="h-0.5 w-16 bg-[#C9A227] mx-auto mt-4" />
          <p className="text-xs text-gray-400 mt-4 leading-relaxed font-light">
            Manipulate custom-minted physical assets in high fidelity. Rotate, zoom, and modify finishes to observe light reflections on premium bullion.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Controls: 3 cols */}
          <div className="lg:col-span-3 space-y-6 order-2 lg:order-1">
            {/* Coin selector */}
            <div className="bg-[#0d0d0d] border border-white/10 p-5 rounded-sm space-y-3">
              <h3 className="text-[11px] font-bold tracking-[0.18em] text-white uppercase border-b border-white/10 pb-2">
                Select Specimen
              </h3>
              <div className="space-y-2 pt-1">
                {products.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => selectCoin(p.id)}
                    className={`w-full flex items-center gap-3 p-3 text-left border rounded-sm transition-all cursor-pointer ${
                      activeCoinId === p.id
                        ? 'border-[#C9A227] bg-[#C9A227]/5'
                        : 'border-[#222222] hover:border-gray-500 bg-transparent'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-full overflow-hidden bg-black shrink-0 border border-[#333333]">
                      <img src={p.image} alt={p.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-[10px] font-bold text-white uppercase truncate leading-none">
                        {p.name.replace(' Bullion Coin', '')}
                      </p>
                      <p className="text-[9px] text-gray-500 mt-1 uppercase tracking-wider font-semibold">
                        {p.weight} • {p.purity}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive Properties */}
            <div className="bg-[#0d0d0d] border border-white/10 p-5 rounded-sm space-y-5">
              <h3 className="text-[11px] font-bold tracking-[0.18em] text-white uppercase border-b border-white/10 pb-2">
                Spectroscopic Adjustments
              </h3>

              {/* Metal Alloy selector */}
              <div className="space-y-2">
                <span className="text-[9px] font-bold tracking-widest text-gray-500 uppercase block">Metal Alloy</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setActiveMetal('gold')}
                    className={`py-2 text-[10px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                      activeMetal === 'gold'
                        ? 'border-[#C9A227] bg-[#C9A227]/10 text-[#C9A227]'
                        : 'border-[#222222] hover:border-gray-500 text-gray-400 bg-transparent'
                    }`}
                  >
                    ★ Gold Alloy
                  </button>
                  <button
                    onClick={() => setActiveMetal('silver')}
                    className={`py-2 text-[10px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                      activeMetal === 'silver'
                        ? 'border-slate-400 bg-slate-400/10 text-slate-300'
                        : 'border-[#222222] hover:border-gray-500 text-gray-400 bg-transparent'
                    }`}
                  >
                    ★ Silver Alloy
                  </button>
                </div>
              </div>

              {/* Finish Type Selector */}
              <div className="space-y-2">
                <span className="text-[9px] font-bold tracking-widest text-gray-500 uppercase block">Mint Polish Finish</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setFinish('proof')}
                    className={`py-2 text-[10px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                      finish === 'proof'
                        ? 'border-[#C9A227] bg-[#C9A227]/5 text-white'
                        : 'border-[#222222] text-gray-500 hover:text-white bg-transparent'
                    }`}
                  >
                    Mirror-Proof
                  </button>
                  <button
                    onClick={() => setFinish('satin')}
                    className={`py-2 text-[10px] font-extrabold uppercase tracking-widest rounded-sm border cursor-pointer transition-all ${
                      finish === 'satin'
                        ? 'border-[#C9A227] bg-[#C9A227]/5 text-white'
                        : 'border-[#222222] text-gray-500 hover:text-white bg-transparent'
                    }`}
                  >
                    Satin-Matte
                  </button>
                </div>
              </div>

              {/* Zoom slider */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-[9px] font-bold tracking-widest text-gray-500 uppercase">
                  <span>Zoom Inspection</span>
                  <span className="text-white font-mono">{zoom.toFixed(1)}x</span>
                </div>
                <div className="flex items-center gap-3">
                  <ZoomOut className="w-3.5 h-3.5 text-gray-500 cursor-pointer hover:text-white" onClick={() => setZoom(Math.max(1, zoom - 0.2))} />
                  <input
                    type="range"
                    min="1"
                    max="2.5"
                    step="0.1"
                    value={zoom}
                    onChange={(e) => setZoom(parseFloat(e.target.value))}
                    className="flex-1 accent-[#C9A227] h-1 bg-[#222222] rounded-lg cursor-pointer"
                  />
                  <ZoomIn className="w-3.5 h-3.5 text-gray-500 cursor-pointer hover:text-white" onClick={() => setZoom(Math.min(2.5, zoom + 0.2))} />
                </div>
              </div>
            </div>
          </div>

          {/* Center Stage: 6 cols */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center order-1 lg:order-2 space-y-8">
            {/* The Stage */}
            <div
              ref={coinRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUpOrLeave}
              onMouseLeave={handleMouseUpOrLeave}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              className="relative w-80 h-80 sm:w-96 sm:h-96 flex items-center justify-center cursor-grab active:cursor-grabbing perspective-1000 select-none"
            >
              {/* Outer light aura matching selected metal */}
              <div className={`absolute w-72 h-72 sm:w-80 sm:h-80 rounded-full blur-[60px] opacity-40 transition-all duration-500 ${
                activeMetal === 'gold' ? 'bg-[#C9A227]/15' : 'bg-slate-300/10'
              }`} />

              {/* 3D Coin Model Card Flipping Container */}
              <div
                className="relative w-64 h-64 sm:w-72 sm:h-72 transition-transform duration-100 ease-out preserve-3d"
                style={{
                  transform: `rotateY(${rotation}deg) scale(${zoom})`,
                }}
              >
                {/* Obverse Front Face */}
                <div className="absolute inset-0 backface-hidden rounded-full shadow-[0_20px_50px_rgba(0,0,0,0.8)] border border-[#333333] overflow-hidden">
                  <img
                    src={activeProduct.image}
                    alt="Coin Obverse"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                    style={{ filter: metalStyles.filter }}
                  />

                  {/* Reflected Dynamic Lighting Highlight Overlay */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-b ${metalStyles.overlayColor} mix-blend-overlay`}
                    style={{
                      transform: `rotate(${-rotation}deg)`,
                      transition: 'transform 0.1s ease-out'
                    }}
                  />
                  {/* Subtle rim metal sparkle */}
                  <div className="absolute inset-0 border-2 border-white/10 rounded-full pointer-events-none" />
                </div>

                {/* Reverse Back Face (Mirrored texture mapping) */}
                <div
                  className="absolute inset-0 backface-hidden rounded-full shadow-[0_20px_50px_rgba(0,0,0,0.8)] border border-[#333333] overflow-hidden"
                  style={{ transform: 'rotateY(180deg)' }}
                >
                  {/* In our premium render, let's reverse mirror the obverse, applying elegant crest designs */}
                  <img
                    src={activeProduct.image}
                    alt="Coin Reverse"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover scale-x-[-1] brightness-90 filter"
                    style={{ filter: `hue-rotate(10deg) ${metalStyles.filter}` }}
                  />
                  {/* Texas Mint Official Crest Overlay effect */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-16 h-16 rounded-full border border-white/20 flex items-center justify-center bg-black/65 backdrop-blur-[2px]">
                      <Star className="w-6 h-6 text-[#C9A227] fill-[#C9A227] animate-pulse" />
                    </div>
                  </div>
                  {/* Reflected Lighting */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-b ${metalStyles.overlayColor} mix-blend-overlay`}
                    style={{
                      transform: `rotate(${rotation}deg)`,
                      transition: 'transform 0.1s ease-out'
                    }}
                  />
                </div>
              </div>

              {/* Hotspot Indicators (Visible when not actively dragging and zoomed) */}
              {!isDragging && (
                <div className="absolute inset-0 pointer-events-none">
                  {hotspots.map((point) => (
                    <div
                      key={point.id}
                      className="absolute pointer-events-auto"
                      style={{ top: point.top, left: point.left }}
                    >
                      <button
                        onMouseEnter={() => setActiveHotspot(point.id)}
                        onMouseLeave={() => setActiveHotspot(null)}
                        className="relative w-5 h-5 flex items-center justify-center group cursor-pointer"
                      >
                        <span className="absolute w-4 h-4 bg-[#C9A227]/40 rounded-full animate-ping" />
                        <span className="w-2.5 h-2.5 bg-[#C9A227] rounded-full border border-white shadow-md group-hover:scale-125 transition-transform" />
                      </button>

                      {/* Info Tooltip */}
                      <AnimatePresence>
                        {activeHotspot === point.id && (
                          <motion.div
                            initial={{ opacity: 0, scale: 0.9, y: 5 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.9, y: 5 }}
                            className="absolute left-1/2 -translate-x-1/2 bottom-7 w-48 bg-[#161616]/95 border border-[#C9A227]/30 backdrop-blur-md p-3 rounded-sm shadow-xl z-30 pointer-events-none"
                          >
                            <h5 className="text-[9px] font-bold uppercase text-[#C9A227] tracking-wider mb-1">
                              {point.title}
                            </h5>
                            <p className="text-[8px] text-gray-300 leading-normal">
                              {point.desc}
                            </p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Instruction Tips & Manual Actions */}
            <div className="flex items-center gap-6 text-[10px] tracking-[0.15em] text-gray-500 uppercase font-semibold">
              <span className="flex items-center gap-1.5">
                <RotateCw className="w-3.5 h-3.5 text-[#C9A227]" />
                Drag to rotate 360°
              </span>
              <span>•</span>
              <button
                onClick={() => setRotation((prev) => prev + 180)}
                className="text-white hover:text-[#C9A227] hover:underline cursor-pointer transition-colors"
              >
                Flip Coin (Reverse/Obverse)
              </button>
              <span>•</span>
              <button onClick={resetControls} className="hover:text-white cursor-pointer">
                Reset
              </button>
            </div>
          </div>

          {/* Right Copy: 3 cols */}
          <div className="lg:col-span-3 space-y-6 order-3">
            <div className="bg-[#0d0d0d] border border-white/10 p-6 rounded-sm space-y-4">
              <h4 className="text-[10px] font-bold tracking-[0.2em] text-[#C9A227] uppercase flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Laboratory Spec
              </h4>

              <div className="space-y-3 pt-2">
                <div className="flex justify-between items-center border-b border-white/10 pb-1.5">
                  <span className="text-[9px] font-semibold text-gray-500 uppercase">Mass Weight</span>
                  <span className="text-[10px] font-bold text-white uppercase font-mono">{activeProduct.weight}</span>
                </div>
                <div className="flex justify-between items-center border-b border-white/10 pb-1.5">
                  <span className="text-[9px] font-semibold text-gray-500 uppercase">Fineness Purity</span>
                  <span className="text-[10px] font-bold text-white uppercase font-mono">{activeProduct.purity}</span>
                </div>
                <div className="flex justify-between items-center border-b border-white/10 pb-1.5">
                  <span className="text-[9px] font-semibold text-gray-500 uppercase">Milled Edge</span>
                  <span className="text-[10px] font-bold text-white uppercase font-mono">Reeded</span>
                </div>
                <div className="flex justify-between items-center pb-1.5">
                  <span className="text-[9px] font-semibold text-gray-500 uppercase">Production Line</span>
                  <span className="text-[10px] font-bold text-white uppercase">Chamber B</span>
                </div>
              </div>
            </div>

            <div className="bg-[#0d0d0d] border border-white/10 p-6 rounded-sm space-y-3">
              <h4 className="text-[10px] font-bold tracking-[0.2em] text-white uppercase flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-[#C9A227]" />
                Tamper-Evident Tech
              </h4>
              <p className="text-[10px] text-gray-400 leading-relaxed">
                Our coins are packaged in sealed Certi-Lock® cards. The reverse contains a holographic security strip and custom blockchain signature credentials to prevent aftermarket dilution.
              </p>
              <div className="pt-2">
                <a
                  href="#vault"
                  className="text-[#C9A227] font-bold text-[9px] tracking-widest uppercase hover:underline inline-flex items-center gap-1 group"
                >
                  Verify Certificates
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
