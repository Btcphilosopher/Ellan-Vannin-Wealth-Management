/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Star, Shield, ArrowRight, CheckCircle2 } from 'lucide-react';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setIsSubscribed(true);
    setEmail('');
    setTimeout(() => setIsSubscribed(false), 3500);
  };

  return (
    <footer className="bg-[#0a0a0a] border-t border-white/10 pt-20 pb-8 font-display text-left relative overflow-hidden select-none">
      
      {/* Background soft glow */}
      <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-[#0d0d0d] to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10 font-display">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 border-b border-white/10 pb-16">
          
          {/* Logo Column: 4 cols */}
          <div className="md:col-span-4 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-sm bg-gradient-to-br from-[#E2B72E] to-[#8C6B13] p-[1px]">
                <div className="w-full h-full bg-[#0a0a0a] flex items-center justify-center rounded-[1px]">
                  <Star className="w-4.5 h-4.5 text-[#C9A227] fill-[#C9A227]" />
                </div>
              </div>
              <div>
                <h3 className="text-xs font-black tracking-[0.2em] text-white uppercase leading-none">
                  Texas Mint
                </h3>
                <span className="text-[8px] tracking-[0.3em] text-gray-500 font-bold uppercase mt-1 block">
                  Gold ★ Silver ★ Legacy
                </span>
              </div>
            </div>

            <p className="text-[11px] text-gray-400 leading-relaxed max-w-sm">
              The Texas Mint creates premier physical gold and silver bullion under aerospace-grade specifications. Providing independent sovereign asset custody for collectors and global investors.
            </p>

            <div className="flex gap-4 text-xs font-bold text-gray-500 uppercase tracking-widest">
              <a href="#" className="hover:text-white transition-colors">X</a>
              <span>•</span>
              <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
              <span>•</span>
              <a href="#" className="hover:text-white transition-colors">Instagram</a>
            </div>
          </div>

          {/* Links Column 1: 2 cols */}
          <div className="md:col-span-2 space-y-4">
            <h4 className="text-[10px] font-bold tracking-widest text-[#C9A227] uppercase">SPECIMENS</h4>
            <ul className="space-y-2 text-[10px] uppercase font-semibold text-gray-400">
              <li><a href="#pricing" className="hover:text-white transition-all">Gold Bullion</a></li>
              <li><a href="#pricing" className="hover:text-white transition-all">Silver Bullion</a></li>
              <li><a href="#collections" className="hover:text-white transition-all">Curated Series</a></li>
              <li><a href="#viewer" className="hover:text-white transition-all">Interactive Laboratory</a></li>
            </ul>
          </div>

          {/* Links Column 2: 2 cols */}
          <div className="md:col-span-2 space-y-4">
            <h4 className="text-[10px] font-bold tracking-widest text-[#C9A227] uppercase">RESOURCES</h4>
            <ul className="space-y-2 text-[10px] uppercase font-semibold text-gray-400">
              <li><a href="#why-us" className="hover:text-white transition-all">Why Texas Mint</a></li>
              <li><a href="#vault" className="hover:text-white transition-all">Vault Audits</a></li>
              <li><a href="#technology" className="hover:text-white transition-all">Technology</a></li>
              <li><a href="#news" className="hover:text-white transition-all">Chronicles</a></li>
            </ul>
          </div>

          {/* Newsletter Column: 4 cols */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-[10px] font-bold tracking-widest text-white uppercase">Sovereign Intel Subscription</h4>
            <p className="text-[11px] text-gray-400 leading-relaxed">
              Recieve monthly macroeconomic briefings, gold-reserve audit sheets, and limited-edition product pre-sales.
            </p>

            <form onSubmit={handleSubscribe} className="relative mt-2">
              <input
                type="email"
                required
                placeholder="Secure Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#0d0d0d] border border-white/10 focus:border-[#C9A227] rounded-sm py-3.5 pl-4 pr-12 text-xs text-white placeholder-gray-600 focus:outline-none transition-all"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-[#C9A227] hover:bg-[#D9B53E] text-[#111111] rounded-sm transition-all cursor-pointer"
                aria-label="Subscribe"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {isSubscribed && (
              <div className="flex items-center gap-2 p-2.5 bg-green-500/10 border border-green-500/20 text-green-400 rounded-sm text-[9px] font-bold uppercase tracking-wider">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Subscription authenticated. Secure reports pending.</span>
              </div>
            )}
          </div>

        </div>

        {/* Corporate Legal Footer */}
        <div className="pt-10 flex flex-col md:flex-row justify-between items-center gap-6 text-[9px] font-semibold text-gray-500 uppercase tracking-widest">
          <div className="flex items-center gap-1.5 text-gray-400">
            <span>© 2026 TEXAS MINT. MINTING FREEDOM. PRESERVING WEALTH. BUILDING LEGACY.</span>
          </div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white">Legal Relations</a>
            <a href="#" className="hover:text-white">Privacy</a>
            <a href="#" className="hover:text-white">SEC Disclosures</a>
            <a href="#" className="hover:text-white">Careers</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
