import React, { useState, useEffect, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { RightPanel } from './components/RightPanel';
import { GlobalPlayer } from './components/GlobalPlayer';
import { FullscreenPlayer } from './components/FullscreenPlayer';
import { CommandSearch } from './components/CommandSearch';
import { ToastContainer } from './components/ToastContainer';

// Views
import { HomeView } from './components/views/HomeView';
import { BrowseView } from './components/views/BrowseView';
import { BagpipeTutorView } from './components/views/BagpipeTutorView';
import { ScotlandMapView } from './components/views/ScotlandMapView';
import { ArchiveView } from './components/views/ArchiveView';
import { PlaylistsView } from './components/views/PlaylistsView';
import { LiveEventsView } from './components/views/LiveEventsView';
import { RadioView } from './components/views/RadioView';
import { PodcastsView } from './components/views/PodcastsView';
import { PremiumView } from './components/views/PremiumView';
import { SettingsView } from './components/views/SettingsView';

import { 
  MOCK_TRACKS, 
  MOCK_PLAYLISTS, 
  MOCK_GENRES, 
  MOCK_ARTISTS, 
  MOCK_LESSONS, 
  MOCK_EVENTS, 
  MOCK_ARCHIVE_RECORDS, 
  MOCK_PODCASTS 
} from './data/mockData';

import { ViewMode, Track, Playlist, Genre, AudioQuality, UserProfile } from './types';
import { audioEngine } from './services/audioEngine';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewMode>('home');
  const [currentTrack, setCurrentTrack] = useState<Track | null>(MOCK_TRACKS[0]);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(MOCK_TRACKS[0].duration);
  const [volume, setVolume] = useState<number>(0.85);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isShuffle, setIsShuffle] = useState<boolean>(false);
  const [isRepeat, setIsRepeat] = useState<boolean>(false);
  const [audioQuality, setAudioQuality] = useState<AudioQuality>('lossless');
  
  const [queue, setQueue] = useState<Track[]>(MOCK_TRACKS);
  const [queueIndex, setQueueIndex] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [likedTrackIds, setLikedTrackIds] = useState<string[]>(['t-1', 't-2', 't-3']);
  const [playlists, setPlaylists] = useState<Playlist[]>(MOCK_PLAYLISTS);

  const [user, setUser] = useState<UserProfile>({
    name: 'Highland Piper',
    email: 'piper@albapipes.scot',
    tier: 'Alba Premium+',
    avatarUrl: 'https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&w=300&q=80',
    likedTrackIds: ['t-1', 't-2', 't-3'],
    favoriteArtistIds: ['a-8', 'a-3'],
    savedAlbumIds: ['alb-1', 'alb-2'],
    playlists: MOCK_PLAYLISTS,
    downloadedTrackIds: ['t-1', 't-2'],
  });

  const [isCommandSearchOpen, setIsCommandSearchOpen] = useState<boolean>(false);
  const [isFullscreenPlayerOpen, setIsFullscreenPlayerOpen] = useState<boolean>(false);
  const [toasts, setToasts] = useState<Array<{ id: string; message: string }>>([]);

  const addToast = (message: string) => {
    const id = Date.now().toString();
    setToasts((prev) => [...prev, { id, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  };

  // Audio engine timeupdate subscription
  useEffect(() => {
    audioEngine.onTimeUpdate((time) => {
      setCurrentTime(time);
    });

    audioEngine.onEnded(() => {
      handleNext();
    });
  }, [queueIndex, queue]);

  // Audio Play Track Handler
  const handlePlayTrack = useCallback((track: Track) => {
    setCurrentTrack(track);
    setDuration(track.duration);
    setCurrentTime(0);
    setIsPlaying(true);

    const idx = queue.findIndex((t) => t.id === track.id);
    if (idx !== -1) {
      setQueueIndex(idx);
    } else {
      setQueue([track, ...queue]);
      setQueueIndex(0);
    }

    audioEngine.playTrack(track.duration, track.tuneType || 'march', track.bpm || 80);
    addToast(`Now playing: ${track.title}`);
  }, [queue]);

  const handleTogglePlay = () => {
    if (!currentTrack) return;

    if (isPlaying) {
      audioEngine.pause();
      setIsPlaying(false);
    } else {
      audioEngine.resume();
      setIsPlaying(true);
    }
  };

  const handleNext = useCallback(() => {
    if (queue.length === 0) return;
    let nextIdx = queueIndex + 1;
    if (isShuffle) {
      nextIdx = Math.floor(Math.random() * queue.length);
    } else if (nextIdx >= queue.length) {
      nextIdx = 0;
    }
    setQueueIndex(nextIdx);
    const nextTrack = queue[nextIdx];
    if (nextTrack) {
      handlePlayTrack(nextTrack);
    }
  }, [queue, queueIndex, isShuffle, handlePlayTrack]);

  const handlePrevious = useCallback(() => {
    if (queue.length === 0) return;
    let prevIdx = queueIndex - 1;
    if (prevIdx < 0) prevIdx = queue.length - 1;
    setQueueIndex(prevIdx);
    const prevTrack = queue[prevIdx];
    if (prevTrack) {
      handlePlayTrack(prevTrack);
    }
  }, [queue, queueIndex, handlePlayTrack]);

  const handleSeek = (time: number) => {
    setCurrentTime(time);
    audioEngine.seek(time);
  };

  const handleVolumeChange = (vol: number) => {
    setVolume(vol);
    setIsMuted(false);
    audioEngine.setVolume(vol);
  };

  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    audioEngine.setVolume(nextMuted ? 0 : volume);
  };

  const handleToggleLike = (trackId: string) => {
    if (likedTrackIds.includes(trackId)) {
      setLikedTrackIds(likedTrackIds.filter((id) => id !== trackId));
      addToast('Removed from Liked Songs');
    } else {
      setLikedTrackIds([...likedTrackIds, trackId]);
      addToast('Added to Liked Songs');
    }
  };

  const handleCreatePlaylist = (name: string, description: string) => {
    const newPl: Playlist = {
      id: `pl-${Date.now()}`,
      name,
      description: description || 'Custom Scottish piping collection',
      coverUrl: 'https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?auto=format&fit=crop&w=800&q=80',
      trackCount: 0,
      tracks: [],
    };
    setPlaylists([newPl, ...playlists]);
    addToast(`Created playlist: ${name}`);
  };

  const handleDeletePlaylist = (playlistId: string) => {
    setPlaylists(playlists.filter((p) => p.id !== playlistId));
    addToast('Playlist deleted');
  };

  const handleOpenPlaylist = (playlist: Playlist) => {
    if (playlist.tracks.length > 0) {
      handlePlayTrack(playlist.tracks[0]);
    } else {
      addToast(`Opening ${playlist.name}`);
    }
  };

  const handleDownloadTrack = (track: Track) => {
    setUser((prev) => ({
      ...prev,
      downloadedTrackIds: [...prev.downloadedTrackIds, track.id],
    }));
    addToast(`Downloaded "${track.title}" in Lossless FLAC`);
  };

  // Keyboard Shortcuts Handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore when typing inside input elements
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;

      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandSearchOpen((prev) => !prev);
      } else if (e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.key === 'n' || e.key === 'N') {
        handleNext();
      } else if (e.key === 'p' || e.key === 'P') {
        handlePrevious();
      } else if (e.key === 'l' || e.key === 'L') {
        if (currentTrack) handleToggleLike(currentTrack.id);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleTogglePlay, handleNext, handlePrevious, currentTrack]);

  return (
    <div className="flex h-screen bg-[#070b0e] text-slate-100 overflow-hidden font-sans selection:bg-amber-500/30 selection:text-amber-200">
      <ToastContainer toasts={toasts} />

      {/* LEFT SIDEBAR */}
      <Sidebar
        currentView={currentView}
        onNavigate={setCurrentView}
        likedCount={likedTrackIds.length}
        playlistCount={playlists.length}
      />

      {/* CENTER MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* TOP HEADER */}
        <Header
          onSearch={(q) => setSearchQuery(q)}
          onNavigate={setCurrentView}
          currentView={currentView}
          user={user}
          onOpenAuth={() => setCurrentView('premium')}
        />

        {/* SCROLLABLE VIEW CANVAS */}
        <main className="flex-1 overflow-y-auto custom-scrollbar pb-24">
          {currentView === 'home' && (
            <HomeView
              featuredPlaylists={playlists}
              newReleases={MOCK_TRACKS.slice(5, 11)}
              genres={MOCK_GENRES}
              onPlayTrack={handlePlayTrack}
              onOpenPlaylist={handleOpenPlaylist}
              onNavigate={setCurrentView}
              onSelectGenre={() => setCurrentView('genres')}
              currentTrackId={currentTrack?.id}
              isPlaying={isPlaying}
            />
          )}

          {(currentView === 'browse' || currentView === 'search') && (
            <BrowseView
              tracks={MOCK_TRACKS}
              artists={MOCK_ARTISTS}
              playlists={playlists}
              onPlayTrack={handlePlayTrack}
              onOpenPlaylist={handleOpenPlaylist}
              onNavigate={setCurrentView}
              searchQuery={searchQuery}
            />
          )}

          {currentView === 'playlists' && (
            <PlaylistsView
              playlists={playlists}
              onCreatePlaylist={handleCreatePlaylist}
              onOpenPlaylist={handleOpenPlaylist}
              onPlayTrack={handlePlayTrack}
              onDeletePlaylist={handleDeletePlaylist}
            />
          )}

          {currentView === 'tutor' && (
            <BagpipeTutorView
              lessons={MOCK_LESSONS}
              onPlayTrack={handlePlayTrack}
            />
          )}

          {currentView === 'map' && (
            <ScotlandMapView
              onPlayTrack={handlePlayTrack}
            />
          )}

          {currentView === 'archive' && (
            <ArchiveView
              archiveRecords={MOCK_ARCHIVE_RECORDS}
              onPlayTrack={handlePlayTrack}
            />
          )}

          {currentView === 'live' && (
            <LiveEventsView
              events={MOCK_EVENTS}
              onPlayTrack={handlePlayTrack}
            />
          )}

          {currentView === 'radio' && (
            <RadioView
              tracks={MOCK_TRACKS}
              onPlayTrack={handlePlayTrack}
            />
          )}

          {currentView === 'podcasts' && (
            <PodcastsView
              podcasts={MOCK_PODCASTS}
              onPlayTrack={handlePlayTrack}
            />
          )}

          {currentView === 'premium' && (
            <PremiumView
              currentTier={user.tier}
              onUpgradeTier={(tier) => {
                setUser((prev) => ({ ...prev, tier }));
                addToast(`Upgraded subscription to ${tier}`);
              }}
            />
          )}

          {currentView === 'settings' && (
            <SettingsView
              audioQuality={audioQuality}
              onChangeQuality={(q) => {
                setAudioQuality(q);
                addToast(`Audio quality set to ${q.toUpperCase()}`);
              }}
              user={user}
            />
          )}

          {currentView === 'liked-songs' && (
            <BrowseView
              tracks={MOCK_TRACKS.filter((t) => likedTrackIds.includes(t.id))}
              artists={MOCK_ARTISTS}
              playlists={playlists}
              onPlayTrack={handlePlayTrack}
              onOpenPlaylist={handleOpenPlaylist}
              onNavigate={setCurrentView}
            />
          )}
        </main>

        {/* PERSISTENT BOTTOM GLOBAL PLAYER */}
        <GlobalPlayer
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          currentTime={currentTime}
          duration={duration}
          volume={volume}
          isMuted={isMuted}
          isShuffle={isShuffle}
          isRepeat={isRepeat}
          audioQuality={audioQuality}
          likedTrackIds={likedTrackIds}
          onTogglePlay={handleTogglePlay}
          onNext={handleNext}
          onPrevious={handlePrevious}
          onSeek={handleSeek}
          onVolumeChange={handleVolumeChange}
          onToggleMute={handleToggleMute}
          onToggleShuffle={() => setIsShuffle(!isShuffle)}
          onToggleRepeat={() => setIsRepeat(!isRepeat)}
          onToggleLike={handleToggleLike}
          onChangeQuality={setAudioQuality}
          onOpenFullscreen={() => setIsFullscreenPlayerOpen(true)}
          onToggleQueue={() => addToast('Opening Play Queue')}
        />
      </div>

      {/* RIGHT WIDGET PANEL (Matching mockup) */}
      <RightPanel
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        currentTime={currentTime}
        duration={duration}
        onPlayTrack={handlePlayTrack}
        onTogglePlay={handleTogglePlay}
        onSeek={handleSeek}
        onNavigate={setCurrentView}
        topTracks={MOCK_TRACKS}
        continueListeningTracks={MOCK_TRACKS.slice(1, 4)}
        likedTrackIds={likedTrackIds}
        onToggleLike={handleToggleLike}
      />

      {/* FULLSCREEN NOW PLAYING EXPANDABLE VIEW */}
      {isFullscreenPlayerOpen && currentTrack && (
        <FullscreenPlayer
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          currentTime={currentTime}
          duration={duration}
          volume={volume}
          isMuted={isMuted}
          isShuffle={isShuffle}
          isRepeat={isRepeat}
          audioQuality={audioQuality}
          isLiked={likedTrackIds.includes(currentTrack.id)}
          onClose={() => setIsFullscreenPlayerOpen(false)}
          onTogglePlay={handleTogglePlay}
          onNext={handleNext}
          onPrevious={handlePrevious}
          onSeek={handleSeek}
          onVolumeChange={handleVolumeChange}
          onToggleMute={handleToggleMute}
          onToggleShuffle={() => setIsShuffle(!isShuffle)}
          onToggleRepeat={() => setIsRepeat(!isRepeat)}
          onToggleLike={handleToggleLike}
          onDownloadTrack={handleDownloadTrack}
        />
      )}

      {/* COMMAND SEARCH MODAL */}
      <CommandSearch
        isOpen={isCommandSearchOpen}
        onClose={() => setIsCommandSearchOpen(false)}
        tracks={MOCK_TRACKS}
        artists={MOCK_ARTISTS}
        playlists={playlists}
        onPlayTrack={handlePlayTrack}
        onNavigate={setCurrentView}
      />
    </div>
  );
}
