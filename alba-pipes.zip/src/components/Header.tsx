import React, { useState } from 'react';
import { Search, ChevronLeft, ChevronRight, SlidersHorizontal, Crown } from 'lucide-react';
import { ViewMode, UserProfile } from '../types';

interface HeaderProps {
  onSearch: (query: string) => void;
  onNavigate: (view: ViewMode) => void;
  currentView: ViewMode;
  user: UserProfile;
  onOpenAuth: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onSearch,
  onNavigate,
  currentView,
  user,
  onOpenAuth,
}) => {
  const [query, setQuery] = useState('');

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuery(e.target.value);
    onSearch(e.target.value);
    if (e.target.value.trim() && currentView !== 'search') {
      onNavigate('search');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      onSearch(query);
      onNavigate('search');
    }
  };

  return (
    <header className="h-16 border-b border-white/10 bg-[#090A0C]/95 backdrop-blur-md px-8 flex items-center justify-between sticky top-0 z-10 flex-shrink-0">
      {/* Navigation arrows */}
      <div className="flex items-center space-x-3">
        <button 
          onClick={() => onNavigate('home')}
          className="w-8 h-8 rounded-full glass flex items-center justify-center text-white/60 hover:text-white transition-opacity"
          title="Go Home"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <button 
          onClick={() => onNavigate('browse')}
          className="w-8 h-8 rounded-full glass flex items-center justify-center text-white/60 hover:text-white transition-opacity"
          title="Search & Catalog"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Center Search Input & Account Controls */}
      <div className="flex items-center space-x-6">
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={handleSearchChange}
            onKeyDown={handleKeyDown}
            placeholder="Search artists, tunes, bands..."
            className="bg-[#1A1D23] border border-white/10 rounded-full py-1.5 pl-10 pr-10 text-xs w-64 text-[#F5F2ED] placeholder:text-white/40 focus:outline-none focus:border-[#C5A059] transition-all"
          />
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
          <kbd className="absolute right-3 top-1/2 -translate-y-1/2 px-1.5 py-0.5 text-[9px] font-mono text-white/40 bg-white/5 rounded border border-white/10">
            ⌘K
          </kbd>
        </div>

        <button
          onClick={() => onNavigate('settings')}
          className="p-2 rounded-full text-white/60 hover:text-[#C5A059] transition-colors"
          title="Playback & Audio Settings"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>

        <button
          onClick={() => onNavigate('premium')}
          className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded-full glass text-[#C5A059] text-xs font-semibold hover:bg-white/10 transition-all border border-[#C5A059]/30"
        >
          <Crown className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>{user.tier}</span>
        </button>

        {user ? (
          <button
            onClick={() => onNavigate('settings')}
            className="flex items-center space-x-2.5 pl-1.5 pr-3 py-1 rounded-full glass hover:border-[#C5A059]/50 transition-all"
          >
            <img
              src={user.avatarUrl}
              alt={user.name}
              className="w-7 h-7 rounded-full object-cover border border-[#C5A059]"
            />
            <span className="text-xs font-medium text-[#F5F2ED] hidden md:inline">
              {user.name}
            </span>
          </button>
        ) : (
          <div className="flex items-center space-x-2">
            <button
              onClick={onOpenAuth}
              className="px-3 py-1.5 rounded-full text-xs font-medium text-white/70 hover:text-white transition-colors"
            >
              Log In
            </button>
            <button
              onClick={onOpenAuth}
              className="px-4 py-1.5 rounded-full text-xs font-bold gold-bg text-[#090A0C] hover:opacity-90 transition-opacity shadow-sm"
            >
              Sign Up
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
