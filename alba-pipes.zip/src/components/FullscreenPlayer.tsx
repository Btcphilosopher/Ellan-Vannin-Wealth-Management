import React, { useEffect, useRef, useState } from 'react';
import { 
  X, 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Shuffle, 
  Repeat, 
  Volume2, 
  VolumeX, 
  Heart, 
  Share2, 
  Download, 
  Sparkles, 
  Music,
  Activity,
  Sliders
} from 'lucide-react';
import { Track, AudioQuality } from '../types';
import { audioEngine } from '../services/audioEngine';

interface FullscreenPlayerProps {
  currentTrack: Track;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  isRepeat: boolean;
  audioQuality: AudioQuality;
  isLiked: boolean;
  onClose: () => void;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onSeek: (seconds: number) => void;
  onVolumeChange: (vol: number) => void;
  onToggleMute: () => void;
  onToggleShuffle: () => void;
  onToggleRepeat: () => void;
  onToggleLike: (trackId: string) => void;
  onDownloadTrack: (track: Track) => void;
}

export const FullscreenPlayer: React.FC<FullscreenPlayerProps> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  volume,
  isMuted,
  isShuffle,
  isRepeat,
  audioQuality,
  isLiked,
  onClose,
  onTogglePlay,
  onNext,
  onPrevious,
  onSeek,
  onVolumeChange,
  onToggleMute,
  onToggleShuffle,
  onToggleRepeat,
  onToggleLike,
  onDownloadTrack,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [activeTab, setActiveTab] = useState<'visualizer' | 'notes' | 'tuning'>('visualizer');

  // Realtime Audio Spectrum Visualizer Animation
  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      const data = audioEngine.getVisualizerData();
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const barWidth = (canvas.width / data.length) * 1.5;
      let x = 0;

      for (let i = 0; i < data.length; i++) {
        const barHeight = (data[i] / 255) * canvas.height * 0.85;

        const gradient = ctx.createLinearGradient(0, canvas.height, 0, 0);
        gradient.addColorStop(0, '#f59e0b'); // Warm Gold
        gradient.addColorStop(0.6, '#d97706');
        gradient.addColorStop(1, '#b45309');

        ctx.fillStyle = gradient;
        ctx.fillRect(x, canvas.height - barHeight, barWidth - 2, barHeight);

        x += barWidth;
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="fixed inset-0 bg-[#060a0d] z-50 flex flex-col justify-between p-6 overflow-hidden animate-fadeIn select-none">
      {/* Background Subtle Backdrop Artwork */}
      <div className="absolute inset-0 z-0 opacity-15 pointer-events-none filter blur-2xl scale-110">
        <img
          src={currentTrack.coverUrl}
          alt={currentTrack.title}
          className="w-full h-full object-cover"
        />
      </div>

      {/* TOP BAR */}
      <div className="relative z-10 flex items-center justify-between border-b border-amber-900/30 pb-4">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-xs font-bold text-amber-300 uppercase tracking-widest font-mono">
              ALBA PIPES NOW PLAYING
            </h2>
            <p className="text-[10px] text-slate-400 font-mono uppercase">
              QUALITY: {audioQuality} • 24-BIT / 96KHZ FLAC
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex bg-slate-900/80 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('visualizer')}
              className={`px-3 py-1 rounded-md transition-colors ${
                activeTab === 'visualizer' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Visualizer
            </button>
            <button
              onClick={() => setActiveTab('notes')}
              className={`px-3 py-1 rounded-md transition-colors ${
                activeTab === 'notes' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Tune Notes
            </button>
            <button
              onClick={() => setActiveTab('tuning')}
              className={`px-3 py-1 rounded-md transition-colors ${
                activeTab === 'tuning' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Bagpipe Tuning
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-amber-300 border border-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* MIDDLE CONTENT AREA */}
      <div className="relative z-10 flex-1 grid grid-cols-1 md:grid-cols-2 gap-8 my-6 items-center max-w-5xl mx-auto w-full">
        {/* Left: Large Artwork & Visualizer Canvas */}
        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="relative w-72 h-72 md:w-80 md:h-80 rounded-2xl overflow-hidden shadow-2xl border-2 border-amber-500/30 group">
            <img
              src={currentTrack.coverUrl}
              alt={currentTrack.title}
              className="w-full h-full object-cover"
            />
            {isPlaying && (
              <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-amber-500/90 text-slate-950 text-[10px] font-bold font-mono tracking-wider flex items-center space-x-1 shadow-md">
                <Activity className="w-3 h-3 animate-pulse" />
                <span>LIVE DRONE ACTIVE</span>
              </div>
            )}
          </div>

          {/* Visualizer Canvas */}
          <div className="w-full h-16 bg-slate-950/60 rounded-xl border border-amber-900/20 p-2 overflow-hidden flex items-center justify-center">
            <canvas
              ref={canvasRef}
              width={320}
              height={60}
              className="w-full h-full"
            />
          </div>
        </div>

        {/* Right: Detailed Track Meta, Notes, or Drone Tuning Gauge */}
        <div className="space-y-6 bg-slate-900/60 border border-amber-900/30 p-6 rounded-2xl backdrop-blur-md">
          {activeTab === 'visualizer' && (
            <div className="space-y-4">
              <div>
                <span className="text-xs text-amber-400 font-mono uppercase tracking-widest">
                  {currentTrack.tuneType ? currentTrack.tuneType.replace('_', ' ') : 'Slow Air'}
                </span>
                <h1 className="font-serif text-2xl md:text-3xl font-bold text-amber-100 mt-1">
                  {currentTrack.title}
                </h1>
                <p className="text-sm text-slate-300 font-medium mt-1">
                  {currentTrack.artist}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">
                  Album: <span className="text-amber-200">{currentTrack.album}</span>
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-800 text-xs">
                <div>
                  <span className="text-slate-500 block text-[10px]">Composer</span>
                  <span className="text-slate-200 font-medium">{currentTrack.composer || 'Traditional Scottish'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Key Signature</span>
                  <span className="text-amber-300 font-mono font-bold">{currentTrack.keySignature || 'A Mixolydian'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Tempo (BPM)</span>
                  <span className="text-slate-200 font-mono">{currentTrack.bpm || 80} BPM</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Region of Origin</span>
                  <span className="text-slate-200">{currentTrack.region || 'Highlands'}</span>
                </div>
              </div>

              <div className="flex items-center space-x-3 pt-2">
                <button
                  onClick={() => onToggleLike(currentTrack.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-semibold border transition-all ${
                    isLiked
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                      : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'fill-amber-400' : ''}`} />
                  <span>{isLiked ? 'In Your Library' : 'Add to Library'}</span>
                </button>

                <button
                  onClick={() => onDownloadTrack(currentTrack)}
                  className="flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Lossless</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'notes' && (
            <div className="space-y-3">
              <h3 className="font-serif text-lg font-bold text-amber-200">
                Piping Cultural & Performance Notes
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                {currentTrack.lyricsOrNotes ||
                  `"This tune is a cornerstone of traditional Highland piping repertoire, featuring classic A Mixolydian ornaments including cut grace notes, double-strikes on Low A, and long melodic phrasing supported by continuous tenor and bass drones."`}
              </p>
              <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-xl text-xs text-amber-200 space-y-1">
                <p className="font-bold">Did you know?</p>
                <p className="text-[11px] text-amber-300/80">
                  Great Highland Bagpipes operate at a continuous wind pressure between 25 and 30 inches of water column, requiring synchronized arm squeeze and blowing breath.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'tuning' && (
            <div className="space-y-4">
              <h3 className="font-serif text-lg font-bold text-amber-200">
                Live Drone Tuning Monitor
              </h3>
              <p className="text-xs text-slate-300">
                Highland Bagpipe pitch calibration reference for A440Hz / Low A 452Hz pitch:
              </p>
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>Bass Drone (A1 - 110Hz)</span>
                  <span className="text-emerald-400 font-mono font-bold">LOCKED IN TUNE</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-1/2 h-full bg-emerald-400 rounded-full mx-auto" />
                </div>

                <div className="flex justify-between text-xs text-slate-300 pt-2">
                  <span>Tenor Drones (A2 - 220Hz)</span>
                  <span className="text-amber-300 font-mono font-bold">+0.3Hz Natural Beat</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="w-2/3 h-full bg-amber-400 rounded-full" />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* BOTTOM CONTROL BAR */}
      <div className="relative z-10 border-t border-amber-900/30 pt-4 max-w-4xl mx-auto w-full">
        {/* Progress Slider */}
        <div className="space-y-1 mb-4">
          <input
            type="range"
            min={0}
            max={duration || currentTrack.duration || 240}
            value={currentTime}
            onChange={(e) => onSeek(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
          />
          <div className="flex justify-between text-xs font-mono text-slate-400">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration || currentTrack.duration || 240)}</span>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button
              onClick={onToggleMute}
              className="text-slate-400 hover:text-amber-300 transition-colors"
            >
              {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={isMuted ? 0 : volume}
              onChange={(e) => onVolumeChange(Number(e.target.value))}
              className="w-24 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
            />
          </div>

          <div className="flex items-center space-x-6">
            <button
              onClick={onToggleShuffle}
              className={`p-2 rounded-full transition-colors ${
                isShuffle ? 'text-amber-400 bg-amber-500/20' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Shuffle className="w-5 h-5" />
            </button>

            <button
              onClick={onPrevious}
              className="p-2 text-slate-300 hover:text-amber-300 transition-colors"
            >
              <SkipBack className="w-6 h-6" />
            </button>

            <button
              onClick={onTogglePlay}
              className="w-14 h-14 rounded-full bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 flex items-center justify-center hover:scale-105 transition-transform shadow-xl shadow-amber-500/30"
            >
              {isPlaying ? (
                <Pause className="w-7 h-7 fill-slate-950" />
              ) : (
                <Play className="w-7 h-7 fill-slate-950 ml-1" />
              )}
            </button>

            <button
              onClick={onNext}
              className="p-2 text-slate-300 hover:text-amber-300 transition-colors"
            >
              <SkipForward className="w-6 h-6" />
            </button>

            <button
              onClick={onToggleRepeat}
              className={`p-2 rounded-full transition-colors ${
                isRepeat ? 'text-amber-400 bg-amber-500/20' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Repeat className="w-5 h-5" />
            </button>
          </div>

          <div className="text-xs font-mono text-amber-400 font-bold">
            ALBA PIPES AUDIO ENGINE
          </div>
        </div>
      </div>
    </div>
  );
};
