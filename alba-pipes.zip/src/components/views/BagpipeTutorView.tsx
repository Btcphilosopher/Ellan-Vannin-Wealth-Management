import React, { useState } from 'react';
import { GraduationCap, Play, Pause, Repeat, Sliders, Volume2, Sparkles, BookOpen, Music, CheckCircle } from 'lucide-react';
import { Lesson, Track } from '../../types';
import { audioEngine } from '../../services/audioEngine';

interface BagpipeTutorViewProps {
  lessons: Lesson[];
  onPlayTrack: (track: Track) => void;
}

export const BagpipeTutorView: React.FC<BagpipeTutorViewProps> = ({
  lessons,
  onPlayTrack,
}) => {
  const [selectedLesson, setSelectedLesson] = useState<Lesson>(lessons[0]);
  const [tempoRate, setTempoRate] = useState<number>(1.0);
  const [isMetronomeActive, setIsMetronomeActive] = useState<boolean>(false);
  const [isPlayingLesson, setIsPlayingLesson] = useState<boolean>(false);
  const [activeFingeringNote, setActiveFingeringNote] = useState<string>('Low A');

  const notesList = ['Low A', 'B', 'C#', 'D', 'E', 'F#', 'High G', 'High A'];

  const handlePlayLessonAudio = () => {
    if (isPlayingLesson) {
      audioEngine.pause();
      setIsPlayingLesson(false);
    } else {
      audioEngine.setPlaybackRate(tempoRate);
      audioEngine.playTrack(120, 'march', selectedLesson.bpm || 80);
      setIsPlayingLesson(true);
    }
  };

  const handleNoteClick = (note: string) => {
    setActiveFingeringNote(note);
    audioEngine.playChanterNote(note, 0.8);
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto animate-fadeIn text-[#F5F2ED]">
      {/* HEADER BANNER */}
      <div className="relative rounded-2xl overflow-hidden glass p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-3 max-w-2xl">
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase gold-accent block">
            Alba Piping Academy
          </span>
          <h1 className="serif text-3xl md:text-4xl font-normal text-[#F5F2ED]">
            Bagpipe Tutor & Academy
          </h1>
          <p className="text-sm text-white/60 leading-relaxed">
            Master the Highland bagpipe, border pipes, and classical Piobaireachd with interactive sheet music, tempo control, drone tuning, and fingering diagrams.
          </p>
        </div>

        <div className="glass p-5 rounded-xl border border-white/10 flex items-center space-x-5 flex-shrink-0">
          <div className="text-center px-2">
            <span className="block text-2xl font-bold font-mono gold-accent">8</span>
            <span className="text-[10px] text-white/40 uppercase tracking-wider block font-bold">Scale Notes</span>
          </div>
          <div className="text-center px-2 border-l border-white/10">
            <span className="block text-2xl font-bold font-mono gold-accent">5</span>
            <span className="text-[10px] text-white/40 uppercase tracking-wider block font-bold">Modules</span>
          </div>
          <div className="text-center px-2 border-l border-white/10">
            <span className="block text-2xl font-bold font-mono gold-accent">452Hz</span>
            <span className="text-[10px] text-white/40 uppercase tracking-wider block font-bold">Base Pitch</span>
          </div>
        </div>
      </div>

      {/* INTERACTIVE LESSON PLAYER & CHANTER FINGERING WORKBENCH */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* LEFT 2 COLS: Active Lesson Details & Sheet Music Workbench */}
        <div className="lg:col-span-2 space-y-6">
          <div className="glass p-6 rounded-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] font-mono gold-accent font-bold uppercase tracking-widest">
                  {selectedLesson.category} • {selectedLesson.level}
                </span>
                <h2 className="serif text-2xl font-bold text-[#F5F2ED] mt-0.5">
                  {selectedLesson.title}
                </h2>
                <p className="text-xs text-white/50 mt-1">
                  Instructor: <span className="text-white/80 font-semibold">{selectedLesson.instructor}</span>
                </p>
              </div>

              <button
                onClick={handlePlayLessonAudio}
                className="px-6 py-3 rounded-full gold-bg text-[#090A0C] font-bold text-xs flex items-center space-x-2 shadow-xl hover:opacity-90 transition-opacity uppercase tracking-widest flex-shrink-0"
              >
                {isPlayingLesson ? (
                  <>
                    <Pause className="w-4 h-4 fill-[#090A0C]" />
                    <span>Pause Demo</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-[#090A0C] ml-0.5" />
                    <span>Practice Audio</span>
                  </>
                )}
              </button>
            </div>

            {/* TEMPO & METRONOME CONTROLS */}
            <div className="bg-[#1A1D23] border border-white/10 p-4 rounded-xl flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center space-x-3">
                <span className="text-xs font-bold text-white/60">Tempo Speed:</span>
                <div className="flex glass p-1 rounded-lg text-xs font-mono">
                  {[0.5, 0.75, 1.0, 1.25].map((rate) => (
                    <button
                      key={rate}
                      onClick={() => {
                        setTempoRate(rate);
                        audioEngine.setPlaybackRate(rate);
                      }}
                      className={`px-3 py-1 rounded transition-colors ${
                        tempoRate === rate ? 'gold-bg text-[#090A0C] font-bold' : 'text-white/60 hover:text-white'
                      }`}
                    >
                      {rate}x
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <span className="text-xs font-bold text-white/60">Metronome (80 BPM):</span>
                <button
                  onClick={() => setIsMetronomeActive(!isMetronomeActive)}
                  className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                    isMetronomeActive
                      ? 'bg-[#C5A059]/20 border-[#C5A059] gold-accent'
                      : 'glass border-white/10 text-white/60 hover:text-white'
                  }`}
                >
                  {isMetronomeActive ? 'Metronome ON' : 'Metronome OFF'}
                </button>
              </div>
            </div>

            {/* HIGHLAND CHANTER FINGERING KEYBOARD */}
            <div className="space-y-3">
              <h3 className="text-[10px] font-bold tracking-[0.3em] uppercase gold-accent flex items-center justify-between">
                <span>HIGHLAND CHANTER SCALE FINGERING & REED TONAL TEST</span>
                <span className="text-white/40 font-mono">CLICK NOTE TO PLAY</span>
              </h3>

              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                {notesList.map((note) => (
                  <button
                    key={note}
                    onClick={() => handleNoteClick(note)}
                    className={`p-3.5 rounded-xl border text-center transition-all ${
                      activeFingeringNote === note
                        ? 'gold-bg text-[#090A0C] border-[#C5A059] font-bold shadow-xl scale-105'
                        : 'bg-[#1A1D23] border-white/10 hover:border-[#C5A059]/40 text-[#F5F2ED]'
                    }`}
                  >
                    <span className="block text-xs font-mono font-bold">{note}</span>
                    <span className="block text-[9px] opacity-60 mt-1">Chanter</span>
                  </button>
                ))}
              </div>
            </div>

            {/* LESSON INSTRUCTOR NOTES */}
            <div className="p-4 glass rounded-xl space-y-2 border border-[#C5A059]/20">
              <h4 className="text-xs font-bold gold-accent uppercase tracking-wider flex items-center space-x-2">
                <BookOpen className="w-4 h-4" />
                <span>Instructor Technique Guidelines</span>
              </h4>
              <p className="text-xs text-white/70 leading-relaxed">
                {selectedLesson.notes || selectedLesson.description}
              </p>
            </div>
          </div>
        </div>

        {/* RIGHT COL: LESSON LIST & CURRICULUM */}
        <div className="space-y-4">
          <h3 className="serif text-2xl text-[#F5F2ED]">
            Curriculum
          </h3>

          <div className="space-y-2">
            {lessons.map((les) => {
              const isSelected = selectedLesson.id === les.id;
              return (
                <div
                  key={les.id}
                  onClick={() => setSelectedLesson(les)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer group ${
                    isSelected
                      ? 'bg-[#C5A059]/15 border-[#C5A059]/50 text-[#F5F2ED] shadow-xl'
                      : 'glass border-white/10 hover:bg-white/5 text-white/70'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-mono gold-accent font-bold uppercase tracking-wider">
                        {les.level} • {les.durationMinutes} MIN
                      </span>
                      <h4 className="serif text-sm font-bold group-hover:gold-accent mt-0.5">
                        {les.title}
                      </h4>
                      <p className="text-xs text-white/50 line-clamp-2 mt-1">
                        {les.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
