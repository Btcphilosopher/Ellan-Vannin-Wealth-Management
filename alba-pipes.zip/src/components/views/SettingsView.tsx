import React from 'react';
import { Sliders, Sparkles, Volume2, Shield, Download, Trash2 } from 'lucide-react';
import { AudioQuality, UserProfile } from '../../types';

interface SettingsViewProps {
  audioQuality: AudioQuality;
  onChangeQuality: (q: AudioQuality) => void;
  user: UserProfile;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  audioQuality,
  onChangeQuality,
  user,
}) => {
  return (
    <div className="p-6 md:p-8 space-y-8 max-w-4xl mx-auto animate-fadeIn text-slate-200">
      <div className="flex items-center space-x-3 border-b border-slate-800 pb-4">
        <Sliders className="w-8 h-8 text-amber-400" />
        <div>
          <h1 className="font-serif text-2xl md:text-3xl font-extrabold text-amber-100">
            Playback & Audio Settings
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Configure audio streaming fidelity, crossfade, loudness normalization, and offline downloads.
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {/* AUDIO QUALITY SECTION */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-amber-900/30 space-y-4 shadow-xl">
          <h2 className="font-serif text-base font-bold text-amber-200 flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Streaming Audio Quality</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { key: 'standard' as const, label: 'Standard (160kbps AAC)', desc: 'Saves mobile data.' },
              { key: 'high' as const, label: 'High Quality (320kbps MP3)', desc: 'Crisp acoustic detail.' },
              { key: 'lossless' as const, label: 'Lossless (24-bit / 96kHz FLAC)', desc: 'Full studio master dynamics.' },
            ].map((q) => (
              <button
                key={q.key}
                onClick={() => onChangeQuality(q.key)}
                className={`p-4 rounded-xl border text-left transition-all ${
                  audioQuality === q.key
                    ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-bold shadow-md'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <span className="text-xs font-bold block">{q.label}</span>
                <span className="text-[10px] text-slate-400 mt-1 block">{q.desc}</span>
              </button>
            ))}
          </div>
        </div>

        {/* ACCOUNT PROFILE DETAILS */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-amber-900/30 space-y-3 shadow-xl">
          <h2 className="font-serif text-base font-bold text-amber-200">
            Account & Subscription Profile
          </h2>
          <div className="flex items-center space-x-4">
            <img
              src={user.avatarUrl}
              alt={user.name}
              className="w-12 h-12 rounded-full object-cover border-2 border-amber-500/40"
            />
            <div>
              <p className="text-sm font-bold text-slate-100">{user.name}</p>
              <p className="text-xs text-slate-400">{user.email}</p>
              <span className="inline-block mt-1 text-[10px] font-mono font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30">
                ACTIVE TIER: {user.tier}
              </span>
            </div>
          </div>
        </div>

        {/* OFFLINE STORAGE */}
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-amber-900/30 space-y-3 shadow-xl">
          <h2 className="font-serif text-base font-bold text-amber-200 flex items-center space-x-2">
            <Download className="w-4 h-4 text-amber-400" />
            <span>Offline Downloads & Cache</span>
          </h2>
          <p className="text-xs text-slate-300">
            Downloaded tracks: <span className="font-mono text-amber-300 font-bold">{user.downloadedTrackIds.length} tracks</span> (~120 MB)
          </p>
          <button
            onClick={() => alert('Offline audio cache cleared successfully.')}
            className="px-4 py-2 rounded-xl bg-red-900/30 border border-red-500/40 text-red-300 text-xs font-bold hover:bg-red-900/50 transition-colors flex items-center space-x-2"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear Offline Downloads Cache</span>
          </button>
        </div>
      </div>
    </div>
  );
};
