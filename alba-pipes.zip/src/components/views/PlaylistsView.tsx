import React, { useState } from 'react';
import { ListMusic, Plus, Play, Trash2, Share2, Download, Check, Sparkles } from 'lucide-react';
import { Playlist, Track } from '../../types';

interface PlaylistsViewProps {
  playlists: Playlist[];
  onCreatePlaylist: (name: string, description: string) => void;
  onOpenPlaylist: (playlist: Playlist) => void;
  onPlayTrack: (track: Track) => void;
  onDeletePlaylist: (playlistId: string) => void;
}

export const PlaylistsView: React.FC<PlaylistsViewProps> = ({
  playlists,
  onCreatePlaylist,
  onOpenPlaylist,
  onPlayTrack,
  onDeletePlaylist,
}) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [newPlaylistDesc, setNewPlaylistDesc] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistName.trim()) return;
    onCreatePlaylist(newPlaylistName, newPlaylistDesc);
    setNewPlaylistName('');
    setNewPlaylistDesc('');
    setShowCreateModal(false);
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto animate-fadeIn text-slate-200">
      {/* HEADER & CREATE BUTTON */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 className="font-serif text-2xl md:text-3xl font-extrabold text-amber-100">
            Playlists & Custom Collections
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Build, reorder, share and download personalized Scottish piping playlists for study, exercise, and Highland celebrations.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="px-5 py-2.5 rounded-full bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs flex items-center space-x-2 shadow-lg hover:scale-105 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Create Playlist</span>
        </button>
      </div>

      {/* PLAYLISTS GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {playlists.map((pl) => (
          <div
            key={pl.id}
            onClick={() => onOpenPlaylist(pl)}
            className="group p-5 rounded-2xl bg-slate-900/80 border border-amber-900/30 hover:border-amber-500/40 transition-all shadow-xl cursor-pointer hover:bg-slate-800/60 relative overflow-hidden"
          >
            <div className="relative aspect-video rounded-xl overflow-hidden mb-4 shadow-md">
              <img
                src={pl.coverUrl}
                alt={pl.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (pl.tracks.length > 0) onPlayTrack(pl.tracks[0]);
                  }}
                  className="w-12 h-12 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow-lg"
                >
                  <Play className="w-6 h-6 fill-slate-950 ml-0.5" />
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <h3 className="font-serif text-base font-bold text-amber-100 group-hover:text-amber-300 truncate">
                  {pl.name}
                </h3>
                {pl.isCurated && (
                  <span className="text-[9px] font-mono font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/40">
                    CURATED
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 line-clamp-2">
                {pl.description}
              </p>
              <div className="flex items-center justify-between pt-2 text-[10px] font-mono text-slate-500">
                <span>{pl.tracks.length} tracks</span>
                {!pl.isCurated && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeletePlaylist(pl.id);
                    }}
                    className="text-red-400 hover:text-red-300 p-1"
                    title="Delete Playlist"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* CREATE PLAYLIST MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h2 className="font-serif text-xl font-bold text-amber-100">
              Create New Playlist
            </h2>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Playlist Name
                </label>
                <input
                  type="text"
                  value={newPlaylistName}
                  onChange={(e) => setNewPlaylistName(e.target.value)}
                  placeholder="e.g. My Morning Highland Walk"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Description (Optional)
                </label>
                <textarea
                  value={newPlaylistDesc}
                  onChange={(e) => setNewPlaylistDesc(e.target.value)}
                  placeholder="Describe the mood, piping style or occasion..."
                  rows={3}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400"
                >
                  Save Playlist
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
