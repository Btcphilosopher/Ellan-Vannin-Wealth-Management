import React, { useState } from 'react';
import { Search, Filter, Play, Music, Users, Disc, ListMusic, History } from 'lucide-react';
import { Track, Album, Artist, Playlist, ViewMode } from '../../types';

interface BrowseViewProps {
  tracks: Track[];
  artists: Artist[];
  playlists: Playlist[];
  onPlayTrack: (track: Track) => void;
  onOpenPlaylist: (playlist: Playlist) => void;
  onNavigate: (view: ViewMode) => void;
  searchQuery?: string;
}

export const BrowseView: React.FC<BrowseViewProps> = ({
  tracks,
  artists,
  playlists,
  onPlayTrack,
  onOpenPlaylist,
  onNavigate,
  searchQuery = '',
}) => {
  const [filterTab, setFilterTab] = useState<'all' | 'tracks' | 'artists' | 'playlists'>('all');
  const [selectedTuneType, setSelectedTuneType] = useState<string>('all');

  const filteredTracks = tracks.filter((t) => {
    const matchesQuery = !searchQuery || 
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.artist.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTuneType = selectedTuneType === 'all' || t.tuneType === selectedTuneType;
    return matchesQuery && matchesTuneType;
  });

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto animate-fadeIn text-[#F5F2ED]">
      {/* HEADER & TABS */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase gold-accent mb-2 block">
            Catalog & Archives
          </span>
          <h1 className="serif text-3xl md:text-4xl font-normal text-[#F5F2ED]">
            Music Discovery
          </h1>
          <p className="text-xs text-white/50 mt-1 max-w-xl">
            Browse thousands of traditional marches, reels, slow airs, competition sets, and restored Gold Medal recordings.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex glass p-1 rounded-full border border-white/10 text-xs font-semibold">
          <button
            onClick={() => setFilterTab('all')}
            className={`px-4 py-1.5 rounded-full transition-all ${
              filterTab === 'all' ? 'gold-bg text-[#090A0C] font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            All Catalogue
          </button>
          <button
            onClick={() => setFilterTab('tracks')}
            className={`px-4 py-1.5 rounded-full transition-all ${
              filterTab === 'tracks' ? 'gold-bg text-[#090A0C] font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            Tracks ({filteredTracks.length})
          </button>
          <button
            onClick={() => setFilterTab('artists')}
            className={`px-4 py-1.5 rounded-full transition-all ${
              filterTab === 'artists' ? 'gold-bg text-[#090A0C] font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            Artists & Bands
          </button>
          <button
            onClick={() => setFilterTab('playlists')}
            className={`px-4 py-1.5 rounded-full transition-all ${
              filterTab === 'playlists' ? 'gold-bg text-[#090A0C] font-bold' : 'text-white/60 hover:text-white'
            }`}
          >
            Playlists
          </button>
        </div>
      </div>

      {/* TUNE TYPE SUB-FILTER PILLS */}
      {(filterTab === 'all' || filterTab === 'tracks') && (
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-xs font-bold uppercase tracking-wider text-white/40 mr-2 flex items-center space-x-1">
            <Filter className="w-3.5 h-3.5 gold-accent" />
            <span>Tune Type:</span>
          </span>
          {['all', 'march', 'slow_air', 'reel', 'jig', 'strathspey', 'piobaireachd', 'folk_fusion'].map((type) => (
            <button
              key={type}
              onClick={() => setSelectedTuneType(type)}
              className={`px-3 py-1 rounded-full text-xs capitalize transition-all border ${
                selectedTuneType === type
                  ? 'bg-[#C5A059]/20 border-[#C5A059] gold-accent font-bold'
                  : 'glass border-white/10 text-white/60 hover:text-white'
              }`}
            >
              {type.replace('_', ' ')}
            </button>
          ))}
        </div>
      )}

      {/* TRACKS GRID / LIST */}
      {(filterTab === 'all' || filterTab === 'tracks') && (
        <div className="space-y-4 pt-2">
          <h2 className="text-[10px] font-bold tracking-[0.3em] uppercase gold-accent">
            RECORDINGS ({filteredTracks.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTracks.map((track) => (
              <div
                key={track.id}
                onClick={() => onPlayTrack(track)}
                className="flex items-center justify-between p-3.5 rounded-xl glass hover:border-[#C5A059]/40 hover:bg-white/5 transition-all cursor-pointer group"
              >
                <div className="flex items-center space-x-3.5 overflow-hidden">
                  <img
                    src={track.coverUrl}
                    alt={track.title}
                    className="w-12 h-12 rounded object-cover flex-shrink-0 border border-white/10"
                  />
                  <div className="overflow-hidden">
                    <h3 className="serif text-sm font-bold text-[#F5F2ED] group-hover:gold-accent truncate">
                      {track.title}
                    </h3>
                    <p className="text-xs text-white/50 truncate mt-0.5">
                      {track.artist}
                    </p>
                    <span className="inline-block text-[9px] font-mono gold-accent uppercase tracking-wider mt-1">
                      {track.tuneType?.replace('_', ' ') || 'Piping'}
                    </span>
                  </div>
                </div>

                <button className="w-8 h-8 rounded-full gold-bg/10 border border-[#C5A059]/30 text-[#C5A059] group-hover:gold-bg group-hover:text-[#090A0C] flex items-center justify-center transition-all flex-shrink-0">
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ARTISTS & BANDS SECTION */}
      {(filterTab === 'all' || filterTab === 'artists') && (
        <div className="space-y-4 pt-6">
          <h2 className="text-[10px] font-bold tracking-[0.3em] uppercase gold-accent">
            FEATURED PIPERS & PIPE BANDS
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
            {artists.map((art) => (
              <div
                key={art.id}
                onClick={() => onNavigate('artists')}
                className="glass hover:border-[#C5A059]/40 rounded-xl p-5 text-center cursor-pointer group hover:bg-white/5 transition-all"
              >
                <img
                  src={art.avatarUrl}
                  alt={art.name}
                  className="w-20 h-20 rounded-full object-cover mx-auto mb-3 border border-[#C5A059]/40 group-hover:scale-105 transition-transform"
                />
                <h3 className="serif text-sm font-bold text-[#F5F2ED] group-hover:gold-accent truncate">
                  {art.name}
                </h3>
                <p className="text-[10px] text-white/50 uppercase tracking-wider mt-1">
                  {art.role}
                </p>
                <span className="text-[9px] font-mono gold-accent block mt-1">
                  {art.monthlyListeners.toLocaleString()} monthly listeners
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
