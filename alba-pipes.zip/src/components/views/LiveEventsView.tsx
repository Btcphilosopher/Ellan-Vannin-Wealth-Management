import React from 'react';
import { Calendar, MapPin, Radio, Ticket, ExternalLink, Play } from 'lucide-react';
import { Event, Track } from '../../types';

interface LiveEventsViewProps {
  events: Event[];
  onPlayTrack: (track: Track) => void;
}

export const LiveEventsView: React.FC<LiveEventsViewProps> = ({ events, onPlayTrack }) => {
  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto animate-fadeIn text-slate-200">
      {/* HEADER BANNER */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/60 border border-amber-500/30 p-8 shadow-2xl flex flex-col md:flex-row items-center justify-between">
        <div className="space-y-3 max-w-xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-red-500/20 text-red-300 text-xs font-semibold border border-red-500/40">
            <Radio className="w-4 h-4 animate-pulse text-red-400" />
            <span>LIVE BROADCASTS & EVENTS</span>
          </div>
          <h1 className="font-serif text-3xl md:text-4xl font-extrabold text-amber-100">
            Highland Games & Live Arenas
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed">
            Stream live broadcasts from Glasgow Green, Edinburgh Castle, Cowal, and royal Highland gatherings across Scotland and international piping circuits.
          </p>
        </div>
      </div>

      {/* EVENTS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {events.map((evt) => (
          <div
            key={evt.id}
            className="p-5 rounded-2xl bg-slate-900/80 border border-amber-900/30 hover:border-amber-500/40 transition-all shadow-xl flex flex-col justify-between space-y-4"
          >
            <div className="space-y-3">
              <div className="relative aspect-video rounded-xl overflow-hidden shadow-md">
                <img
                  src={evt.imageUrl}
                  alt={evt.title}
                  className="w-full h-full object-cover"
                />
                {evt.isLiveNow && (
                  <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-red-600 text-white font-mono font-bold text-[10px] tracking-wider uppercase animate-pulse flex items-center space-x-1.5 shadow-lg">
                    <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                    <span>STREAMING LIVE NOW</span>
                  </div>
                )}
              </div>

              <div>
                <span className="text-[10px] font-mono text-amber-400 font-bold block uppercase">
                  {evt.date} • {evt.location}
                </span>
                <h3 className="font-serif text-base font-bold text-amber-100 mt-1">
                  {evt.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  {evt.description}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800 text-xs space-y-1">
                <span className="text-slate-500 font-semibold text-[10px] uppercase block">Key Performers:</span>
                <p className="text-slate-300 font-medium text-xs">
                  {evt.performers.join(', ')}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3 pt-2">
              <button
                onClick={() => alert(`Streaming live feed for ${evt.title}`)}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-colors flex items-center justify-center space-x-1.5"
              >
                <Radio className="w-4 h-4" />
                <span>Watch Stream</span>
              </button>

              <button
                onClick={() => alert(`Redirecting to official ticket partner for ${evt.title}`)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 font-semibold text-xs hover:text-white transition-colors flex items-center space-x-1"
              >
                <Ticket className="w-4 h-4" />
                <span>Tickets</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
