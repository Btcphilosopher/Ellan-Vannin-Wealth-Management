import React from 'react';
import { Podcast as PodcastIcon, Play, Mic, Clock } from 'lucide-react';
import { Podcast, Track } from '../../types';

interface PodcastsViewProps {
  podcasts: Podcast[];
  onPlayTrack: (track: Track) => void;
}

export const PodcastsView: React.FC<PodcastsViewProps> = ({ podcasts, onPlayTrack }) => {
  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto animate-fadeIn text-slate-200">
      <div className="flex items-center space-x-3 border-b border-slate-800 pb-4">
        <PodcastIcon className="w-8 h-8 text-amber-400" />
        <div>
          <h1 className="font-serif text-2xl md:text-3xl font-extrabold text-amber-100">
            Podcasts & Scottish Cultural Oral Stories
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Exclusive interviews with Pipe Majors, Clan MacCrimmon history, Gaelic song origins, and tune breakdown masterclasses.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {podcasts.map((pod) => (
          <div
            key={pod.id}
            className="p-6 rounded-2xl bg-slate-900/80 border border-amber-900/30 hover:border-amber-500/40 transition-all shadow-xl flex flex-col md:flex-row items-start space-y-4 md:space-y-0 md:space-x-4"
          >
            <img
              src={pod.coverUrl}
              alt={pod.title}
              className="w-28 h-28 rounded-xl object-cover border border-amber-500/30 flex-shrink-0"
            />
            <div className="space-y-2 flex-1">
              <span className="text-[10px] font-mono text-amber-400 font-bold uppercase">
                {pod.episodesCount} EPISODES • HOST: {pod.host}
              </span>
              <h3 className="font-serif text-lg font-bold text-amber-100">
                {pod.title}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {pod.description}
              </p>

              <div className="pt-2 border-t border-slate-800 space-y-2">
                <span className="text-[10px] font-bold text-amber-300 block">LATEST EPISODE:</span>
                <div className="flex items-center justify-between text-xs text-slate-200">
                  <span className="font-semibold">{pod.latestEpisode.title}</span>
                  <button
                    onClick={() => onPlayTrack(pod.latestEpisode.track)}
                    className="px-3 py-1 rounded-full bg-amber-500 text-slate-950 font-bold text-[10px] flex items-center space-x-1"
                  >
                    <Play className="w-3 h-3 fill-slate-950" />
                    <span>Play Episode</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
