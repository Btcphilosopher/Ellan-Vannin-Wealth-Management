import React, { useState } from 'react';
import { MapPin, Music, Play, ChevronRight, Compass, Sparkles } from 'lucide-react';
import { SCOTLAND_REGIONS, MOCK_TRACKS } from '../../data/mockData';
import { Track } from '../../types';

interface ScotlandMapViewProps {
  onPlayTrack: (track: Track) => void;
}

export const ScotlandMapView: React.FC<ScotlandMapViewProps> = ({ onPlayTrack }) => {
  const [selectedRegion, setSelectedRegion] = useState(SCOTLAND_REGIONS[0]);

  // Filter tracks associated with the selected region
  const regionalTracks = MOCK_TRACKS.filter((t) => 
    t.region?.toLowerCase().includes(selectedRegion.name.toLowerCase()) ||
    t.region?.toLowerCase().includes(selectedRegion.id.toLowerCase())
  ).concat(MOCK_TRACKS.slice(0, 3)); // Fallback items for richness

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto animate-fadeIn text-slate-200">
      {/* HEADER BANNER */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/50 border border-amber-500/20 p-8 shadow-2xl flex flex-col md:flex-row items-center justify-between">
        <div className="space-y-3 max-w-xl">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold border border-amber-500/30">
            <Compass className="w-4 h-4" />
            <span>INTERACTIVE GEOGRAPHIC MAP</span>
          </div>
          <h1 className="font-serif text-3xl md:text-4xl font-extrabold text-amber-100">
            The Sound Map of Scotland
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed">
            Explore Scottish piping history and living traditions by region — from the ancient MacCrimmon college on Skye to Edinburgh Castle Esplanade and Glasgow World Championships.
          </p>
        </div>
      </div>

      {/* MAP GRID & REGION SELECTOR */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* LEFT: SVG SCOTLAND REGIONAL INTERACTIVE MAP */}
        <div className="lg:col-span-1 bg-slate-900/80 border border-amber-900/30 rounded-2xl p-6 shadow-xl flex flex-col items-center justify-center min-h-[420px]">
          <h2 className="font-serif text-sm font-bold text-amber-300 uppercase tracking-widest mb-4 flex items-center space-x-2">
            <MapPin className="w-4 h-4 text-amber-400" />
            <span>SELECT REGION ON MAP</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full">
            {SCOTLAND_REGIONS.map((reg) => {
              const isSelected = selectedRegion.id === reg.id;
              return (
                <button
                  key={reg.id}
                  onClick={() => setSelectedRegion(reg)}
                  className={`p-3 rounded-xl border text-left transition-all group ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-lg'
                      : 'bg-slate-950/80 border-slate-800 hover:border-amber-500/40 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold font-serif">{reg.name}</span>
                    <span className={`text-[10px] font-mono ${isSelected ? 'text-slate-900' : 'text-amber-400'}`}>
                      {reg.count}
                    </span>
                  </div>
                  <p className={`text-[10px] line-clamp-1 mt-1 ${isSelected ? 'text-slate-900' : 'text-slate-400'}`}>
                    {reg.desc}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* RIGHT 2 COLS: Selected Region Heritage & Music Collection */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900/80 border border-amber-900/30 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-mono text-amber-400 font-bold uppercase tracking-widest">
                  REGIONAL SPOTLIGHT
                </span>
                <h2 className="font-serif text-2xl font-bold text-amber-100 mt-0.5">
                  {selectedRegion.name}
                </h2>
                <p className="text-xs text-slate-300 mt-1">
                  {selectedRegion.desc}
                </p>
              </div>

              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold">
                {selectedRegion.count}
              </span>
            </div>

            {/* Regional Tracks */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                FEATURED PIPING RECORDINGS FROM {selectedRegion.name.toUpperCase()}
              </h3>

              <div className="space-y-2">
                {regionalTracks.slice(0, 5).map((track) => (
                  <div
                    key={track.id}
                    onClick={() => onPlayTrack(track)}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-amber-500/40 hover:bg-slate-800/60 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center space-x-3 overflow-hidden">
                      <img
                        src={track.coverUrl}
                        alt={track.title}
                        className="w-10 h-10 rounded-lg object-cover flex-shrink-0 border border-slate-700/50"
                      />
                      <div className="overflow-hidden">
                        <h4 className="text-xs font-serif font-bold text-slate-200 group-hover:text-amber-200 truncate">
                          {track.title}
                        </h4>
                        <p className="text-[11px] text-slate-400 truncate">
                          {track.artist}
                        </p>
                      </div>
                    </div>

                    <button className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 group-hover:bg-amber-500 group-hover:text-slate-950 flex items-center justify-center transition-all">
                      <Play className="w-4 h-4 fill-current ml-0.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
