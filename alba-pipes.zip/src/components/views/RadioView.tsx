import React from 'react';
import { Radio as RadioIcon, Play, Sparkles, Volume2 } from 'lucide-react';
import { Track } from '../../types';

interface RadioViewProps {
  onPlayTrack: (track: Track) => void;
  tracks: Track[];
}

export const RadioView: React.FC<RadioViewProps> = ({ onPlayTrack, tracks }) => {
  const radioStations = [
    { id: 'rad-1', name: 'Alba Ceòl Mòr Radio', desc: 'Non-stop classical Piobaireachd & Gold Medal performances.', icon: '🎼', track: tracks[9] || tracks[0] },
    { id: 'rad-2', name: 'World Pipe Band Championships Stream', desc: 'Grade 1 competition sets & massed pipe band marches.', icon: '🥁', track: tracks[7] || tracks[1] },
    { id: 'rad-3', name: 'Highland Sunset Chill Radio', desc: 'Gentle slow airs, smallpipes, and ambient Scottish soundscapes.', icon: '🌅', track: tracks[0] },
    { id: 'rad-4', name: 'Celtic Rock & Pipe Fusion', desc: 'High-energy bagpipe rock, border pipes, and electronic grooves.', icon: '⚡', track: tracks[10] || tracks[2] },
  ];

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto animate-fadeIn text-slate-200">
      <div className="flex items-center space-x-3 border-b border-slate-800 pb-4">
        <RadioIcon className="w-8 h-8 text-amber-400" />
        <div>
          <h1 className="font-serif text-2xl md:text-3xl font-extrabold text-amber-100">
            Alba Continuous Radio Stations
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Endless continuous radio channels powered by Alba Pipes smart tune recommendations.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {radioStations.map((st) => (
          <div
            key={st.id}
            onClick={() => onPlayTrack(st.track)}
            className="p-6 rounded-2xl bg-slate-900/80 border border-amber-900/30 hover:border-amber-500/40 transition-all shadow-xl cursor-pointer group hover:bg-slate-800/60 flex flex-col justify-between space-y-4"
          >
            <div className="space-y-2">
              <span className="text-3xl block">{st.icon}</span>
              <h3 className="font-serif text-lg font-bold text-amber-100 group-hover:text-amber-300">
                {st.name}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {st.desc}
              </p>
            </div>

            <button className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center space-x-2 shadow-md">
              <Play className="w-4 h-4 fill-slate-950" />
              <span>Listen Live Station</span>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
