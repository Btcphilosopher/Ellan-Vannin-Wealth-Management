import React from 'react';
import { History, Sparkles, Play, Shield, Disc, Clock } from 'lucide-react';
import { ArchiveRecord, Track } from '../../types';

interface ArchiveViewProps {
  archiveRecords: ArchiveRecord[];
  onPlayTrack: (track: Track) => void;
}

export const ArchiveView: React.FC<ArchiveViewProps> = ({ archiveRecords, onPlayTrack }) => {
  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto animate-fadeIn text-[#F5F2ED]">
      {/* HEADER BANNER */}
      <div className="relative rounded-2xl overflow-hidden glass p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-3 max-w-2xl">
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase gold-accent block">
            Scottish National Sound Archive
          </span>
          <h1 className="serif text-3xl md:text-4xl font-normal text-[#F5F2ED]">
            Historic Scottish Sound Archive
          </h1>
          <p className="text-sm text-white/60 leading-relaxed">
            Preserving rare 20th-century shellac 78rpm discs, wax cylinders, early BBC radio reel-to-reel master tapes, and legendary Gold Medal solo piping recordings.
          </p>
        </div>

        <div className="p-5 glass rounded-xl text-center space-y-1 border border-white/10 flex-shrink-0">
          <span className="block text-2xl font-bold font-mono gold-accent">1920–1990</span>
          <span className="text-[10px] text-white/40 uppercase tracking-widest block font-bold">Archival Era Range</span>
          <span className="text-[10px] gold-accent font-mono block">24-Bit Digital Restoration</span>
        </div>
      </div>

      {/* ARCHIVAL RECORDS LIST */}
      <div className="space-y-4">
        <h2 className="serif text-2xl text-[#F5F2ED]">
          Digitally Restored Archival Recordings
        </h2>

        <div className="space-y-4">
          {archiveRecords.map((record) => (
            <div
              key={record.id}
              className="p-6 rounded-xl glass hover:border-[#C5A059]/40 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-6"
            >
              <div className="flex items-start space-x-5">
                <img
                  src={record.coverUrl}
                  alt={record.title}
                  className="w-20 h-20 rounded object-cover border border-white/10 flex-shrink-0"
                />
                <div className="space-y-1">
                  <div className="flex items-center space-x-3">
                    <span className="text-[10px] font-mono gold-accent font-bold px-2 py-0.5 rounded glass border border-[#C5A059]/30">
                      {record.recordingYear} RECORDING
                    </span>
                    <span className="text-[10px] text-white/40 font-mono uppercase tracking-wider">
                      {record.location}
                    </span>
                  </div>
                  <h3 className="serif text-lg font-bold text-[#F5F2ED]">
                    {record.title}
                  </h3>
                  <p className="text-xs text-white/70 font-semibold">
                    Performer: {record.performer}
                  </p>
                  <p className="text-xs text-white/50 mt-1 max-w-2xl leading-relaxed">
                    {record.description}
                  </p>
                  <p className="text-[10px] font-mono gold-accent pt-1">
                    Source: {record.sourceArchive} • {record.restorationDetails}
                  </p>
                </div>
              </div>

              <button
                onClick={() => onPlayTrack(record.track)}
                className="w-full md:w-auto px-6 py-3 rounded-full gold-bg text-[#090A0C] font-bold text-xs flex items-center justify-center space-x-2 shadow-xl hover:opacity-90 transition-opacity flex-shrink-0 uppercase tracking-widest"
              >
                <Play className="w-4 h-4 fill-[#090A0C] ml-0.5" />
                <span>Play Archival Track</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
