import React from 'react';
import { Crown, Check, Sparkles, Shield, GraduationCap, Disc } from 'lucide-react';

interface PremiumViewProps {
  currentTier: string;
  onUpgradeTier: (tier: 'Free' | 'Alba Premium' | 'Alba Premium+') => void;
}

export const PremiumView: React.FC<PremiumViewProps> = ({ currentTier, onUpgradeTier }) => {
  const plans = [
    {
      name: 'Free',
      price: '£0',
      period: 'Forever Free',
      description: 'Standard bagpipe streaming with ad support.',
      features: [
        'Standard 160kbps Audio Quality',
        'Access to Public Catalogue',
        'Basic Player Controls',
        'Community Playlists'
      ],
      tierKey: 'Free' as const,
    },
    {
      name: 'Alba Premium',
      price: '£9.99',
      period: 'per month',
      popular: true,
      description: 'High-Fidelity ad-free Scottish streaming & offline downloads.',
      features: [
        'Ad-Free Unlimited Streaming',
        'Hi-Fi Lossless Audio (320kbps / FLAC)',
        'Unlimited Offline Track Downloads',
        'Interactive Bagpipe Tutor Access',
        'Smart Scotland Sound Map Access'
      ],
      tierKey: 'Alba Premium' as const,
    },
    {
      name: 'Alba Premium+',
      price: '£14.99',
      period: 'per month',
      description: 'The ultimate Scottish cultural archive & piping masterclass tier.',
      features: [
        '24-Bit / 96kHz Studio Lossless FLAC',
        'Full Historic Sound Archive Access (1920–1990)',
        'All Bagpipe Tutor Advanced Masterclasses',
        'Live World Championships & Tattoo Stream Front-Row',
        'VIP Artist & Band Community Access'
      ],
      tierKey: 'Alba Premium+' as const,
    }
  ];

  return (
    <div className="p-6 md:p-8 space-y-10 max-w-6xl mx-auto animate-fadeIn text-slate-200">
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold border border-amber-500/30">
          <Crown className="w-4 h-4 text-amber-400" />
          <span>SCOTTISH MUSIC SUBSCRIPTION</span>
        </div>
        <h1 className="font-serif text-3xl md:text-4xl font-extrabold text-amber-100">
          Choose Your Alba Pipes Tier
        </h1>
        <p className="text-xs md:text-sm text-slate-300">
          Support Scottish traditional artists, gold medallist pipers, and regional pipe bands while enjoying world-class audio streaming.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan) => {
          const isCurrent = currentTier === plan.tierKey;
          return (
            <div
              key={plan.name}
              className={`rounded-3xl p-6 flex flex-col justify-between space-y-6 relative transition-all ${
                plan.popular
                  ? 'bg-gradient-to-b from-amber-950/80 via-slate-900 to-amber-950/40 border-2 border-amber-500 shadow-2xl scale-105'
                  : 'bg-slate-900/80 border border-slate-800 shadow-xl'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-amber-500 text-slate-950 font-bold text-[10px] tracking-widest uppercase shadow-md">
                  MOST POPULAR
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <h3 className="font-serif text-xl font-bold text-amber-100">
                    {plan.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {plan.description}
                  </p>
                </div>

                <div className="flex items-baseline space-x-1">
                  <span className="font-serif text-3xl font-extrabold text-amber-300">
                    {plan.price}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    /{plan.period}
                  </span>
                </div>

                <div className="pt-4 border-t border-slate-800 space-y-2.5 text-xs text-slate-300">
                  {plan.features.map((feat) => (
                    <div key={feat} className="flex items-center space-x-2.5">
                      <Check className="w-4 h-4 text-amber-400 flex-shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  onUpgradeTier(plan.tierKey);
                  alert(`Successfully switched plan to ${plan.name}`);
                }}
                disabled={isCurrent}
                className={`w-full py-3 rounded-xl font-bold text-xs transition-all ${
                  isCurrent
                    ? 'bg-slate-800 text-slate-400 border border-slate-700 cursor-default'
                    : plan.popular
                    ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-lg'
                    : 'bg-slate-800 hover:bg-slate-700 text-amber-200 border border-slate-700'
                }`}
              >
                {isCurrent ? 'Current Active Tier' : `Select ${plan.name}`}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
