import React from 'react';
import { Play, Sparkles, Trophy, Music, Compass, ChevronRight, Heart } from 'lucide-react';
import { Track, Playlist, Genre, ViewMode } from '../../types';

interface HomeViewProps {
  featuredPlaylists: Playlist[];
  newReleases: Track[];
  genres: Genre[];
  onPlayTrack: (track: Track) => void;
  onOpenPlaylist: (playlist: Playlist) => void;
  onNavigate: (view: ViewMode) => void;
  onSelectGenre: (genre: Genre) => void;
  currentTrackId?: string;
  isPlaying?: boolean;
}

export const HomeView: React.FC<HomeViewProps> = ({
  featuredPlaylists,
  newReleases,
  genres,
  onPlayTrack,
  onOpenPlaylist,
  onNavigate,
  onSelectGenre,
  currentTrackId,
  isPlaying,
}) => {
  return (
    <div className="p-8 space-y-10 max-w-7xl mx-auto animate-fadeIn text-[#F5F2ED]">
      {/* 1. HERO BANNER */}
      <div className="relative rounded-2xl overflow-hidden glass min-h-[320px] md:min-h-[380px] flex items-center p-8 md:p-12">
        {/* Background Photograph */}
        <div className="absolute inset-0 z-0 bg-[#1A1D23]">
          <img
            src="https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&w=1600&q=80"
            alt="Scottish Highlands"
            className="w-full h-full object-cover object-center opacity-30 filter brightness-90 contrast-110"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0F1115] via-[#0F1115]/85 to-transparent z-10" />
        </div>

        {/* Hero Copy & CTA */}
        <div className="relative z-20 max-w-xl space-y-4">
          <span className="text-[10px] font-bold tracking-[0.4em] uppercase gold-accent mb-2 block">
            Featured Series
          </span>

          <h2 className="serif text-4xl sm:text-5xl font-normal leading-tight text-[#F5F2ED]">
            The Master Pipers of the 20th Century
          </h2>

          <p className="text-sm opacity-70 leading-relaxed max-w-md">
            A curated collection of restored competition recordings, Gold Medal solo piping, and massed pipe band marches from the Scottish Highlands.
          </p>

          <div className="flex items-center space-x-4 pt-4">
            <button
              onClick={() => onPlayTrack(newReleases[0])}
              className="gold-bg text-[#090A0C] px-8 py-3 rounded-full text-xs font-black tracking-widest uppercase hover:opacity-90 transition-opacity shadow-xl flex items-center space-x-2"
            >
              <Play className="w-4 h-4 fill-[#090A0C]" />
              <span>Play Now</span>
            </button>

            <button
              onClick={() => onNavigate('premium')}
              className="glass px-8 py-3 rounded-full text-xs font-black tracking-widest uppercase hover:bg-white/10 transition-colors text-[#F5F2ED]"
            >
              Save To Library
            </button>
          </div>
        </div>
      </div>

      {/* 2. TRENDING IN THE HIGHLANDS (FEATURED PLAYLISTS) */}
      <section className="space-y-4">
        <div className="flex items-end justify-between">
          <h3 className="serif text-2xl text-[#F5F2ED]">
            Trending in the Highlands
          </h3>
          <button
            onClick={() => onNavigate('playlists')}
            className="text-[10px] gold-accent uppercase tracking-widest font-bold hover:underline"
          >
            Show All
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6">
          {featuredPlaylists.map((pl) => (
            <div
              key={pl.id}
              onClick={() => onOpenPlaylist(pl)}
              className="group cursor-pointer"
            >
              <div className="aspect-square bg-[#1A1D23] rounded-lg mb-3 relative overflow-hidden glass border border-white/10">
                <img
                  src={pl.coverUrl}
                  alt={pl.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                />
                <div className="absolute bottom-3 right-3 w-10 h-10 gold-bg rounded-full flex items-center justify-center text-[#090A0C] translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all shadow-xl">
                  <Play className="w-5 h-5 fill-[#090A0C] ml-0.5" />
                </div>
              </div>
              <h4 className="font-bold text-sm text-[#F5F2ED] mb-1 truncate group-hover:gold-accent transition-colors">
                {pl.name}
              </h4>
              <p className="text-xs opacity-50 truncate">
                {pl.trackCount} tracks
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* 3. NEW RELEASES */}
      <section className="space-y-4 pt-2">
        <div className="flex items-end justify-between">
          <h3 className="serif text-2xl text-[#F5F2ED]">
            New Scottish Releases
          </h3>
          <button
            onClick={() => onNavigate('new-releases')}
            className="text-[10px] gold-accent uppercase tracking-widest font-bold hover:underline"
          >
            Show All
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6">
          {newReleases.map((track) => {
            const isCurrent = currentTrackId === track.id;
            return (
              <div
                key={track.id}
                onClick={() => onPlayTrack(track)}
                className="group cursor-pointer"
              >
                <div className={`aspect-square bg-[#1A1D23] rounded-lg mb-3 relative overflow-hidden glass ${
                  isCurrent ? 'border-2 border-[#C5A059]' : 'border border-white/10'
                }`}>
                  <img
                    src={track.coverUrl}
                    alt={track.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                  />
                  <div className={`absolute bottom-3 right-3 w-10 h-10 gold-bg rounded-full flex items-center justify-center text-[#090A0C] ${
                    isCurrent ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100'
                  } transition-all shadow-xl`}>
                    <Play className="w-5 h-5 fill-[#090A0C] ml-0.5" />
                  </div>
                </div>
                <h4 className="font-bold text-sm text-[#F5F2ED] mb-1 truncate group-hover:gold-accent transition-colors">
                  {track.title}
                </h4>
                <p className="text-xs opacity-50 truncate">
                  {track.artist}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. GENRES & MOODS */}
      <section className="space-y-4 pt-2">
        <div className="flex items-end justify-between">
          <h3 className="serif text-2xl text-[#F5F2ED]">
            Piping Genres & Styles
          </h3>
          <button
            onClick={() => onNavigate('genres')}
            className="text-[10px] gold-accent uppercase tracking-widest font-bold hover:underline"
          >
            Show All
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
          {genres.slice(0, 6).map((g) => (
            <button
              key={g.id}
              onClick={() => onSelectGenre(g)}
              className="flex items-center space-x-3 p-3.5 rounded-lg glass hover:border-[#C5A059]/40 hover:bg-white/5 transition-all text-left group"
            >
              <div className="w-8 h-8 rounded gold-bg/10 border border-[#C5A059]/30 flex items-center justify-center gold-accent group-hover:scale-105 transition-transform">
                <Music className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-[#F5F2ED] group-hover:gold-accent transition-colors">
                {g.name}
              </span>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};
