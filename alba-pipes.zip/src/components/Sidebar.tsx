import React from 'react';
import { 
  Home, 
  Compass, 
  ListMusic, 
  Sparkles, 
  Users, 
  Grid, 
  Radio, 
  GraduationCap, 
  History as HistoryIcon, 
  Heart, 
  Disc, 
  Podcast, 
  MapPin, 
  Radio as LiveIcon,
  Crown,
  ChevronRight
} from 'lucide-react';
import { ViewMode } from '../types';

interface SidebarProps {
  currentView: ViewMode;
  onNavigate: (view: ViewMode) => void;
  likedCount: number;
  playlistCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  likedCount,
  playlistCount
}) => {
  const mainNavItems = [
    { id: 'home' as ViewMode, label: 'Home', icon: Home },
    { id: 'browse' as ViewMode, label: 'Search', icon: Compass },
    { id: 'archive' as ViewMode, label: 'Music Archive', icon: HistoryIcon },
    { id: 'live' as ViewMode, label: 'Live Events', icon: LiveIcon },
  ];

  const eduNavItems = [
    { id: 'tutor' as ViewMode, label: 'Bagpipe Tutor', icon: GraduationCap },
    { id: 'map' as ViewMode, label: 'Scotland Music Map', icon: MapPin },
    { id: 'radio' as ViewMode, label: 'Continuous Radio', icon: Radio },
  ];

  const libraryNavItems = [
    { id: 'liked-songs' as ViewMode, label: 'Liked Tracks', icon: Heart, count: likedCount },
    { id: 'playlists' as ViewMode, label: 'Your Playlists', icon: ListMusic, badge: playlistCount > 0 ? `${playlistCount}` : undefined },
    { id: 'podcasts' as ViewMode, label: 'Podcasts', icon: Podcast },
  ];

  return (
    <aside className="w-64 bg-[#090A0C] border-r border-white/10 flex flex-col h-full text-[#F5F2ED] select-none flex-shrink-0 z-20 p-6">
      {/* Brand Header */}
      <div 
        onClick={() => onNavigate('home')} 
        className="mb-8 cursor-pointer group"
      >
        <h1 className="serif text-2xl tracking-widest gold-accent font-bold uppercase transition-opacity group-hover:opacity-90">
          Alba Pipes
        </h1>
        <p className="text-[10px] uppercase tracking-[0.3em] opacity-50 mt-1">
          Scottish Bagpipe Streaming
        </p>
      </div>

      {/* Navigation Groups */}
      <nav className="flex-1 overflow-y-auto space-y-6 custom-scrollbar pr-1">
        {/* Discovery Category */}
        <div>
          <div className="text-[10px] uppercase tracking-widest opacity-40 mb-3 px-2 font-bold">
            Discovery
          </div>
          <div className="space-y-1">
            {mainNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`sidebar-link w-full flex items-center justify-between px-3 py-2 rounded text-sm font-medium transition-colors ${
                    isActive
                      ? 'text-[#C5A059] bg-[#C5A059]/10 font-semibold'
                      : 'text-white/70 hover:text-[#C5A059]'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Educational Category */}
        <div>
          <div className="text-[10px] uppercase tracking-widest opacity-40 mb-3 px-2 font-bold">
            Educational
          </div>
          <div className="space-y-1">
            {eduNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`sidebar-link w-full flex items-center justify-between px-3 py-2 rounded text-sm font-medium transition-colors ${
                    isActive
                      ? 'text-[#C5A059] bg-[#C5A059]/10 font-semibold'
                      : 'text-white/70 hover:text-[#C5A059]'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Library Category */}
        <div>
          <div className="text-[10px] uppercase tracking-widest opacity-40 mb-3 px-2 font-bold">
            Library
          </div>
          <div className="space-y-1">
            {libraryNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`sidebar-link w-full flex items-center justify-between px-3 py-2 rounded text-sm font-medium transition-colors ${
                    isActive
                      ? 'text-[#C5A059] bg-[#C5A059]/10 font-semibold'
                      : 'text-white/70 hover:text-[#C5A059]'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  {item.count !== undefined && item.count > 0 && (
                    <span className="text-[10px] gold-accent bg-[#C5A059]/15 px-2 py-0.5 rounded font-mono">
                      {item.count}
                    </span>
                  )}
                  {item.badge && (
                    <span className="text-[10px] text-white/50 bg-white/10 px-1.5 py-0.5 rounded">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Upgrade Box Footer */}
      <div className="mt-auto pt-6 border-t border-white/5">
        <div className="glass p-4 rounded-lg">
          <p className="text-[11px] gold-accent font-semibold mb-1 tracking-wider uppercase">
            ALBA PREMIUM
          </p>
          <p className="text-[10px] opacity-60 leading-tight">
            High-resolution lossless Celtic & Scottish piping audio.
          </p>
          <button
            onClick={() => onNavigate('premium')}
            className="w-full mt-3 py-2 bg-white/10 hover:bg-white/20 text-[10px] font-bold tracking-widest uppercase rounded text-white transition-colors"
          >
            Upgrade
          </button>
        </div>
      </div>
    </aside>
  );
};
