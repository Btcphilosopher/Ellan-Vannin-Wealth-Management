import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Shuffle, 
  Repeat, 
  Volume2, 
  VolumeX, 
  Heart, 
  Maximize2, 
  ListMusic, 
  Sparkles,
  Sliders
} from 'lucide-react';
import { Track, AudioQuality } from '../types';

interface GlobalPlayerProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  isRepeat: boolean;
  audioQuality: AudioQuality;
  likedTrackIds: string[];
  onTogglePlay: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onSeek: (seconds: number) => void;
  onVolumeChange: (vol: number) => void;
  onToggleMute: () => void;
  onToggleShuffle: () => void;
  onToggleRepeat: () => void;
  onToggleLike: (trackId: string) => void;
  onChangeQuality: (quality: AudioQuality) => void;
  onOpenFullscreen: () => void;
  onToggleQueue: () => void;
}

export const GlobalPlayer: React.FC<GlobalPlayerProps> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  volume,
  isMuted,
  isShuffle,
  isRepeat,
  audioQuality,
  likedTrackIds,
  onTogglePlay,
  onNext,
  onPrevious,
  onSeek,
  onVolumeChange,
  onToggleMute,
  onToggleShuffle,
  onToggleRepeat,
  onToggleLike,
  onChangeQuality,
  onOpenFullscreen,
  onToggleQueue,
}) => {
  const [showQualityMenu, setShowQualityMenu] = useState(false);

  if (!currentTrack) return null;

  const isLiked = likedTrackIds.includes(currentTrack.id);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="h-24 bg-[#090A0C] border-t border-white/10 px-8 flex items-center justify-between sticky bottom-0 z-30 select-none shadow-2xl">
      {/* LEFT: Track Info & Heart */}
      <div className="flex items-center space-x-4 w-1/4 min-w-[220px]">
        <div 
          onClick={onOpenFullscreen}
          className="relative w-14 h-14 bg-[#1A1D23] rounded-lg overflow-hidden flex-shrink-0 cursor-pointer group shadow-lg border border-white/5"
        >
          <img
            src={currentTrack.coverUrl}
            alt={currentTrack.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
          />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
            <Maximize2 className="w-4 h-4" />
          </div>
        </div>

        <div className="overflow-hidden">
          <h5 
            onClick={onOpenFullscreen}
            className="text-sm font-bold text-[#F5F2ED] hover:gold-accent truncate cursor-pointer leading-tight"
          >
            {currentTrack.title}
          </h5>
          <p className="text-xs text-white/50 truncate leading-tight mt-0.5">
            {currentTrack.artist}
          </p>
        </div>

        <button
          onClick={() => onToggleLike(currentTrack.id)}
          className={`p-1.5 rounded-full transition-colors ${
            isLiked ? 'gold-accent fill-[#C5A059]' : 'text-white/40 hover:text-white'
          }`}
        >
          <Heart className={`w-4 h-4 ${isLiked ? 'fill-[#C5A059]' : ''}`} />
        </button>
      </div>

      {/* CENTER: Player Controls & Seek Bar */}
      <div className="flex flex-col items-center flex-1 max-w-xl px-10">
        <div className="flex items-center space-x-8 mb-2">
          <button
            onClick={onToggleShuffle}
            className={`transition-opacity text-sm ${
              isShuffle ? 'gold-accent font-bold opacity-100' : 'opacity-40 hover:opacity-100'
            }`}
            title="Shuffle"
          >
            <Shuffle className="w-4 h-4" />
          </button>

          <button
            onClick={onPrevious}
            className="text-xl text-white/70 hover:text-white transition-colors"
            title="Previous"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            onClick={onTogglePlay}
            className="w-10 h-10 gold-bg text-[#090A0C] rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-xl"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-5 h-5 fill-[#090A0C]" />
            ) : (
              <Play className="w-5 h-5 fill-[#090A0C] ml-0.5" />
            )}
          </button>

          <button
            onClick={onNext}
            className="text-xl text-white/70 hover:text-white transition-colors"
            title="Next"
          >
            <SkipForward className="w-4 h-4" />
          </button>

          <button
            onClick={onToggleRepeat}
            className={`transition-opacity text-sm ${
              isRepeat ? 'gold-accent font-bold opacity-100' : 'opacity-40 hover:opacity-100'
            }`}
            title="Repeat"
          >
            <Repeat className="w-4 h-4" />
          </button>
        </div>

        {/* Seek Bar */}
        <div className="w-full flex items-center space-x-3">
          <span className="text-[10px] opacity-40 font-mono w-8 text-right">
            {formatTime(currentTime)}
          </span>
          <div className="relative flex-1 flex items-center">
            <input
              type="range"
              min={0}
              max={duration || currentTrack.duration || 240}
              value={currentTime}
              onChange={(e) => onSeek(Number(e.target.value))}
              className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-[#C5A059] transition-colors"
            />
          </div>
          <span className="text-[10px] opacity-40 font-mono w-8">
            {formatTime(duration || currentTrack.duration || 240)}
          </span>
        </div>
      </div>

      {/* RIGHT: Quality, Queue, Volume */}
      <div className="flex items-center justify-end space-x-4 w-1/4 min-w-[200px] text-white/60">
        {/* Audio Quality Pill */}
        <div className="relative">
          <button
            onClick={() => setShowQualityMenu(!showQualityMenu)}
            className="hidden lg:flex items-center space-x-1.5 px-2.5 py-1 rounded text-[10px] font-mono tracking-widest uppercase glass gold-accent font-bold hover:bg-white/10 transition-all border border-[#C5A059]/30"
          >
            <Sparkles className="w-3 h-3 text-[#C5A059]" />
            <span>{audioQuality}</span>
          </button>

          {showQualityMenu && (
            <div className="absolute bottom-12 right-0 w-40 glass bg-[#090A0C] border border-white/10 rounded-lg p-2 shadow-2xl text-xs space-y-1 z-50">
              <div className="px-2 py-1 text-[10px] font-bold tracking-widest text-white/40 uppercase">
                Audio Quality
              </div>
              {(['standard', 'high', 'lossless'] as AudioQuality[]).map((q) => (
                <button
                  key={q}
                  onClick={() => {
                    onChangeQuality(q);
                    setShowQualityMenu(false);
                  }}
                  className={`w-full text-left px-2 py-1.5 rounded text-xs capitalize transition-colors ${
                    audioQuality === q ? 'bg-[#C5A059]/20 gold-accent font-bold' : 'hover:bg-white/10 text-white/70'
                  }`}
                >
                  {q === 'lossless' ? 'Lossless 24-bit' : q}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Queue Button */}
        <button
          onClick={onToggleQueue}
          className="opacity-60 hover:opacity-100 transition-opacity"
          title="Play Queue"
        >
          <ListMusic className="w-4 h-4" />
        </button>

        {/* Volume Controls */}
        <div className="hidden sm:flex items-center space-x-2 w-24">
          <button onClick={onToggleMute} className="opacity-60 hover:opacity-100 transition-opacity">
            {isMuted || volume === 0 ? (
              <VolumeX className="w-4 h-4 text-red-400" />
            ) : (
              <Volume2 className="w-4 h-4" />
            )}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={isMuted ? 0 : volume}
            onChange={(e) => onVolumeChange(Number(e.target.value))}
            className="flex-1 h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-[#C5A059]"
          />
        </div>

        {/* Fullscreen Player Toggle */}
        <button
          onClick={onOpenFullscreen}
          className="opacity-60 hover:opacity-100 transition-opacity"
          title="Expand Player"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
