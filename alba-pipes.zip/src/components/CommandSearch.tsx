import React, { useState } from 'react';
import { Search, X, Play, Music, Users, ListMusic, History } from 'lucide-react';
import { Track, Artist, Playlist, ViewMode } from '../types';

interface CommandSearchProps {
  isOpen: boolean;
  onClose: () => void;
  tracks: Track[];
  artists: Artist[];
  playlists: Playlist[];
  onPlayTrack: (track: Track) => void;
  onNavigate: (view: ViewMode) => void;
}

export const CommandSearch: React.FC<CommandSearchProps> = ({
  isOpen,
  onClose,
  tracks,
  artists,
  playlists,
  onPlayTrack,
  onNavigate,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const filteredTracks = tracks.filter((t) =>
    t.title.toLowerCase().includes(query.toLowerCase()) ||
    t.artist.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-start justify-center pt-20 p-4 animate-fadeIn">
      <div className="bg-[#0c1218] border border-amber-500/40 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden space-y-3">
        {/* Search Bar Input */}
        <div className="flex items-center space-x-3 px-4 py-3 border-b border-amber-900/30">
          <Search className="w-5 h-5 text-amber-400" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type tune name, piper, album, or genre..."
            className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-500 focus:outline-none"
          />
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Results list */}
        <div className="max-h-96 overflow-y-auto px-4 pb-4 space-y-2 custom-scrollbar">
          {filteredTracks.slice(0, 8).map((track) => (
            <div
              key={track.id}
              onClick={() => {
                onPlayTrack(track);
                onClose();
              }}
              className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-800/80 cursor-pointer transition-colors group"
            >
              <div className="flex items-center space-x-3 overflow-hidden">
                <img
                  src={track.coverUrl}
                  alt={track.title}
                  className="w-10 h-10 rounded-lg object-cover border border-slate-700/50 flex-shrink-0"
                />
                <div className="overflow-hidden">
                  <h4 className="text-xs font-serif font-bold text-amber-100 group-hover:text-amber-300 truncate">
                    {track.title}
                  </h4>
                  <p className="text-[11px] text-slate-400 truncate">
                    {track.artist}
                  </p>
                </div>
              </div>

              <span className="text-[10px] font-mono text-amber-400/80 uppercase">
                {track.tuneType?.replace('_', ' ')}
              </span>
            </div>
          ))}

          {query && filteredTracks.length === 0 && (
            <div className="text-center py-8 text-xs text-slate-400">
              No Scottish piping recordings found for "{query}". Try searching "Amazing Grace", "Piobaireachd", or "Highland Cathedral".
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
