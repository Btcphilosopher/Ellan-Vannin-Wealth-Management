import React from 'react';
import { Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, MoreVertical, GraduationCap, Heart } from 'lucide-react';
import { Track, ViewMode } from '../types';

interface RightPanelProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  onPlayTrack: (track: Track) => void;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  onNavigate: (view: ViewMode) => void;
  topTracks: Track[];
  continueListeningTracks: Track[];
  likedTrackIds: string[];
  onToggleLike: (trackId: string) => void;
}

export const RightPanel: React.FC<RightPanelProps> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  onPlayTrack,
  onTogglePlay,
  onSeek,
  onNavigate,
  topTracks,
  continueListeningTracks,
  likedTrackIds,
  onToggleLike,
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const activeTrack = currentTrack || topTracks[0];

  return (
    <aside className="w-80 bg-[#090A0C] border-l border-white/10 flex flex-col h-full overflow-y-auto p-5 space-y-6 flex-shrink-0 z-10 custom-scrollbar text-[#F5F2ED]">
      {/* 1. NOW PLAYING WIDGET */}
      <div className="glass p-4 rounded-2xl relative overflow-hidden space-y-3">
        <h2 className="text-[10px] font-bold tracking-[0.3em] uppercase gold-accent flex items-center justify-between">
          <span>NOW PLAYING</span>
          {activeTrack && likedTrackIds.includes(activeTrack.id) && (
            <Heart className="w-3.5 h-3.5 gold-accent fill-[#C5A059]" />
          )}
        </h2>

        {/* Album Artwork */}
        <div className="relative aspect-square rounded-lg overflow-hidden group shadow-lg border border-white/10 bg-[#1A1D23]">
          <img
            src={activeTrack?.coverUrl}
            alt={activeTrack?.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
            <span className="text-[10px] gold-accent font-mono uppercase tracking-wider">
              {activeTrack?.region || 'Scottish Highlands'}
            </span>
          </div>
        </div>

        {/* Track Title & Artist */}
        <div>
          <h3 className="serif text-base font-bold text-[#F5F2ED] truncate">
            {activeTrack?.title || 'Amazing Grace'}
          </h3>
          <p className="text-xs text-white/50 truncate mt-0.5">
            {activeTrack?.artist || 'The Skye Collection'}
          </p>
        </div>

        {/* Progress Bar */}
        <div className="space-y-1">
          <input
            type="range"
            min={0}
            max={duration || activeTrack?.duration || 240}
            value={currentTime}
            onChange={(e) => onSeek(Number(e.target.value))}
            className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-[#C5A059]"
          />
          <div className="flex justify-between text-[10px] font-mono text-white/40">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration || activeTrack?.duration || 240)}</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between pt-1 text-white/50">
          <button className="hover:text-white transition-colors">
            <Shuffle className="w-3.5 h-3.5" />
          </button>
          <button className="hover:text-white transition-colors">
            <SkipBack className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              if (currentTrack?.id === activeTrack?.id) {
                onTogglePlay();
              } else if (activeTrack) {
                onPlayTrack(activeTrack);
              }
            }}
            className="w-10 h-10 gold-bg text-[#090A0C] rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-lg"
          >
            {isPlaying && currentTrack?.id === activeTrack?.id ? (
              <Pause className="w-5 h-5 fill-[#090A0C]" />
            ) : (
              <Play className="w-5 h-5 fill-[#090A0C] ml-0.5" />
            )}
          </button>
          <button className="hover:text-white transition-colors">
            <SkipForward className="w-4 h-4" />
          </button>
          <button className="hover:text-white transition-colors">
            <Repeat className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 2. CONTINUE LISTENING */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-[10px] font-bold tracking-[0.3em] uppercase gold-accent">
            CONTINUE LISTENING
          </h2>
          <button 
            onClick={() => onNavigate('archive')}
            className="text-[10px] gold-accent uppercase tracking-widest font-bold hover:underline"
          >
            View all
          </button>
        </div>

        <div className="space-y-2">
          {continueListeningTracks.slice(0, 3).map((track) => (
            <div
              key={track.id}
              onClick={() => onPlayTrack(track)}
              className="group flex items-center justify-between p-2 rounded-lg glass hover:bg-white/5 transition-all cursor-pointer"
            >
              <div className="flex items-center space-x-3 overflow-hidden">
                <img
                  src={track.coverUrl}
                  alt={track.title}
                  className="w-10 h-10 rounded object-cover flex-shrink-0 border border-white/5"
                />
                <div className="overflow-hidden">
                  <h4 className="text-xs font-bold text-[#F5F2ED] group-hover:gold-accent truncate">
                    {track.title}
                  </h4>
                  <p className="text-[11px] text-white/50 truncate">
                    {track.artist}
                  </p>
                  <div className="w-24 h-0.5 bg-white/10 rounded-full mt-1 overflow-hidden">
                    <div className="w-2/3 h-full gold-bg" />
                  </div>
                </div>
              </div>
              <button 
                onClick={(e) => { e.stopPropagation(); }}
                className="p-1 text-white/40 hover:text-white"
              >
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* 3. TOP TRACKS */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-[10px] font-bold tracking-[0.3em] uppercase gold-accent">
            TOP TRACKS
          </h2>
          <button 
            onClick={() => onNavigate('browse')}
            className="text-[10px] gold-accent uppercase tracking-widest font-bold hover:underline"
          >
            View all
          </button>
        </div>

        <div className="space-y-1">
          {topTracks.slice(0, 5).map((track, index) => {
            const isSelected = currentTrack?.id === track.id;
            return (
              <div
                key={track.id}
                onClick={() => onPlayTrack(track)}
                className={`flex items-center justify-between py-2 px-2.5 rounded transition-colors cursor-pointer group ${
                  isSelected ? 'bg-[#C5A059]/15 border border-[#C5A059]/30' : 'hover:bg-white/5'
                }`}
              >
                <div className="flex items-center space-x-3 overflow-hidden">
                  <span className={`text-xs font-mono w-4 text-center font-bold ${
                    isSelected ? 'gold-accent' : 'text-white/40 group-hover:text-white'
                  }`}>
                    {index + 1}
                  </span>
                  <div className="overflow-hidden">
                    <h4 className={`text-xs font-medium truncate ${
                      isSelected ? 'gold-accent font-semibold' : 'text-[#F5F2ED] group-hover:text-white'
                    }`}>
                      {track.title}
                    </h4>
                    <p className="text-[10px] text-white/50 truncate">
                      {track.artist}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-white/40">
                  {formatTime(track.duration)}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. BAGPIPE TUTOR CTA BANNER */}
      <div 
        onClick={() => onNavigate('tutor')}
        className="glass p-4 rounded-xl cursor-pointer group hover:border-[#C5A059]/50 transition-all relative overflow-hidden"
      >
        <div className="relative z-10 space-y-2">
          <span className="text-[10px] font-bold tracking-[0.3em] uppercase gold-accent block">
            LEARN. PLAY. PRESERVE.
          </span>
          <p className="serif text-sm font-bold text-[#F5F2ED] leading-snug">
            Explore our Bagpipe Tutor lessons & score sheet library.
          </p>
          <div className="pt-2 flex items-center text-xs font-bold gold-accent group-hover:translate-x-1 transition-transform">
            <span>Start Learning</span>
            <span className="ml-1">→</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
