export type ViewMode = 
  | 'home'
  | 'browse'
  | 'playlists'
  | 'playlist-detail'
  | 'new-releases'
  | 'artists'
  | 'artist-detail'
  | 'album-detail'
  | 'genres'
  | 'genre-detail'
  | 'radio'
  | 'tutor'
  | 'lesson-detail'
  | 'archive'
  | 'map'
  | 'live'
  | 'event-detail'
  | 'podcasts'
  | 'liked-songs'
  | 'albums'
  | 'history'
  | 'premium'
  | 'settings'
  | 'search';

export type AudioQuality = 'standard' | 'high' | 'lossless';

export interface Track {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  album: string;
  albumId: string;
  coverUrl: string;
  duration: number; // in seconds
  audioUrl?: string; // fallback or generated frequency pattern
  tuneType?: 'march' | 'reel' | 'jig' | 'strathspey' | 'slow_air' | 'piobaireachd' | 'lament' | 'folk_fusion';
  composer?: string;
  year?: number;
  isPopular?: boolean;
  plays?: number;
  lyricsOrNotes?: string;
  sheetMusicAvailable?: boolean;
  bpm?: number;
  keySignature?: string;
  region?: string;
  isArchival?: boolean;
}

export interface Album {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  coverUrl: string;
  releaseYear: number;
  genre: string;
  description: string;
  tracks: Track[];
  isPopular?: boolean;
  label?: string;
}

export interface Artist {
  id: string;
  name: string;
  role: string; // e.g., 'Pipe Major', 'Solo Piper', 'Pipe Band', 'Folk Ensemble'
  type: 'solo' | 'band' | 'military' | 'ensemble';
  avatarUrl: string;
  heroUrl: string;
  bio: string;
  location: string;
  region: string;
  monthlyListeners: number;
  instruments: string[];
  popularTracks: Track[];
  albums: Album[];
  achievements?: string[];
  formedYear?: number;
  websiteUrl?: string;
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  coverUrl: string;
  trackCount: number;
  duration?: number;
  isCurated?: boolean;
  isPublic?: boolean;
  tracks: Track[];
  createdBy?: string;
}

export interface Genre {
  id: string;
  name: string;
  description: string;
  color: string;
  imageUrl: string;
  featuredTracks: Track[];
}

export interface Event {
  id: string;
  title: string;
  subtitle: string;
  date: string;
  location: string;
  region: string;
  imageUrl: string;
  description: string;
  performers: string[];
  isLiveNow?: boolean;
  streamUrl?: string;
  ticketPrice?: string;
  coordinates?: { lat: number; lng: number };
}

export interface Lesson {
  id: string;
  title: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Piobaireachd Master';
  instructor: string;
  durationMinutes: number;
  imageUrl: string;
  description: string;
  category: 'Technique' | 'Tune' | 'Maintenance' | 'Theory' | 'Piobaireachd';
  bpm?: number;
  keyNotes?: string[];
  sheetMusicSvg?: string;
  videoUrl?: string;
  notes?: string;
}

export interface ArchiveRecord {
  id: string;
  title: string;
  performer: string;
  recordingYear: number;
  location: string;
  sourceArchive: string;
  description: string;
  audioQualityNote: string;
  restorationDetails: string;
  coverUrl: string;
  track: Track;
}

export interface Podcast {
  id: string;
  title: string;
  host: string;
  coverUrl: string;
  description: string;
  episodesCount: number;
  latestEpisode: {
    title: string;
    duration: number;
    publishDate: string;
    track: Track;
  };
}

export interface UserProfile {
  name: string;
  email: string;
  tier: 'Free' | 'Alba Premium' | 'Alba Premium+';
  avatarUrl: string;
  likedTrackIds: string[];
  favoriteArtistIds: string[];
  savedAlbumIds: string[];
  playlists: Playlist[];
  downloadedTrackIds: string[];
}

export interface PlaybackState {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  isRepeat: boolean;
  queue: Track[];
  queueIndex: number;
  audioQuality: AudioQuality;
  crossfadeSeconds: number;
  history: Track[];
}
