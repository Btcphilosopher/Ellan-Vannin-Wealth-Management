/**
 * Alba Pipes - Web Audio Bagpipe & Celtic Audio Engine
 * Generates realistic Highland bagpipe drone, chanter harmonics, and melody patterns,
 * with real-time audio visualization, tempo control, and pitch synthesis.
 */

class AudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private masterGain: GainNode | null = null;
  private droneGain: GainNode | null = null;
  private chanterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  
  // Oscillators
  private bassDroneOsc: OscillatorNode | null = null;
  private tenorDrone1Osc: OscillatorNode | null = null;
  private tenorDrone2Osc: OscillatorNode | null = null;
  
  private melodyInterval: number | null = null;
  private currentNoteIndex: number = 0;
  private currentBpm: number = 80;
  private playbackRate: number = 1.0;
  private activeChanterOsc: OscillatorNode | null = null;

  // Listeners
  private onTimeUpdateCallback: ((time: number) => void) | null = null;
  private onEndedCallback: (() => void) | null = null;
  private currentTimeSeconds: number = 0;
  private trackDuration: number = 240; // Default fallback
  private timerId: number | null = null;

  // Frequency mapping for Highland Bagpipe Chanter (A440 base pitch)
  // Low A, B, C#, D, E, F#, High G, High A
  private scaleFreqs: { [key: string]: number } = {
    'Low A': 220.00,
    'B': 246.94,
    'C#': 277.18,
    'D': 293.66,
    'E': 329.63,
    'F#': 369.99,
    'High G': 392.00,
    'High A': 440.00,
  };

  private tunePatterns: { [key: string]: string[] } = {
    march: ['Low A', 'D', 'E', 'F#', 'High A', 'F#', 'E', 'D', 'Low A', 'B', 'C#', 'D', 'E', 'D'],
    slow_air: ['Low A', 'D', 'F#', 'High A', 'F#', 'E', 'D', 'B', 'Low A', 'D', 'E', 'D'],
    piobaireachd: ['Low A', 'Low A', 'D', 'E', 'F#', 'High A', 'High G', 'F#', 'E', 'D', 'C#', 'B', 'Low A'],
    reel: ['Low A', 'B', 'C#', 'D', 'E', 'F#', 'High G', 'High A', 'High G', 'F#', 'E', 'D', 'C#', 'B'],
    jig: ['D', 'F#', 'High A', 'F#', 'D', 'E', 'G', 'E', 'C#', 'D', 'F#', 'D'],
    strathspey: ['Low A', 'D', 'D', 'F#', 'E', 'D', 'B', 'Low A', 'D', 'F#', 'High A', 'F#'],
  };

  public init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 64;

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.8, this.ctx.currentTime);
      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);

      this.droneGain = this.ctx.createGain();
      this.droneGain.gain.setValueAtTime(0.35, this.ctx.currentTime);
      this.droneGain.connect(this.masterGain);

      this.chanterGain = this.ctx.createGain();
      this.chanterGain.gain.setValueAtTime(0.55, this.ctx.currentTime);
      this.chanterGain.connect(this.masterGain);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(vol: number) {
    if (this.masterGain && this.ctx) {
      const clamped = Math.max(0, Math.min(1, vol));
      this.masterGain.gain.setTargetAtTime(clamped, this.ctx.currentTime, 0.05);
    }
  }

  public setPlaybackRate(rate: number) {
    this.playbackRate = Math.max(0.5, Math.min(2.0, rate));
  }

  public playTrack(duration: number = 240, tuneType: string = 'march', bpm: number = 85) {
    this.init();
    this.stop();

    this.isPlaying = true;
    this.trackDuration = duration;
    this.currentBpm = bpm;
    this.currentTimeSeconds = 0;

    this.startDrones();
    this.startChanterMelody(tuneType);

    // Timer loop for time updating
    this.timerId = window.setInterval(() => {
      if (this.isPlaying) {
        this.currentTimeSeconds += 0.2 * this.playbackRate;
        if (this.onTimeUpdateCallback) {
          this.onTimeUpdateCallback(this.currentTimeSeconds);
        }

        if (this.currentTimeSeconds >= this.trackDuration) {
          this.stop();
          if (this.onEndedCallback) {
            this.onEndedCallback();
          }
        }
      }
    }, 200);
  }

  public seek(seconds: number) {
    this.currentTimeSeconds = Math.max(0, Math.min(this.trackDuration, seconds));
    if (this.onTimeUpdateCallback) {
      this.onTimeUpdateCallback(this.currentTimeSeconds);
    }
  }

  public pause() {
    this.isPlaying = false;
    this.stopDrones();
    if (this.melodyInterval) {
      window.clearInterval(this.melodyInterval);
      this.melodyInterval = null;
    }
    if (this.timerId) {
      window.clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  public resume() {
    if (!this.isPlaying && this.ctx) {
      this.isPlaying = true;
      this.startDrones();
      this.startChanterMelody('march');
      this.timerId = window.setInterval(() => {
        if (this.isPlaying) {
          this.currentTimeSeconds += 0.2 * this.playbackRate;
          if (this.onTimeUpdateCallback) {
            this.onTimeUpdateCallback(this.currentTimeSeconds);
          }
          if (this.currentTimeSeconds >= this.trackDuration) {
            this.stop();
            if (this.onEndedCallback) {
              this.onEndedCallback();
            }
          }
        }
      }, 200);
    }
  }

  public stop() {
    this.isPlaying = false;
    this.stopDrones();
    if (this.activeChanterOsc) {
      try { this.activeChanterOsc.stop(); } catch { /* ignore */ }
      this.activeChanterOsc = null;
    }
    if (this.melodyInterval) {
      window.clearInterval(this.melodyInterval);
      this.melodyInterval = null;
    }
    if (this.timerId) {
      window.clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  private startDrones() {
    if (!this.ctx || !this.droneGain) return;

    // Bass Drone (Low A1 = 110Hz or A2 = 220Hz harmonic)
    this.bassDroneOsc = this.ctx.createOscillator();
    this.bassDroneOsc.type = 'sawtooth';
    this.bassDroneOsc.frequency.setValueAtTime(110, this.ctx.currentTime); // Bass Drone A1

    // Tenor Drone 1 (Low A2 = 220Hz)
    this.tenorDrone1Osc = this.ctx.createOscillator();
    this.tenorDrone1Osc.type = 'sawtooth';
    this.tenorDrone1Osc.frequency.setValueAtTime(220, this.ctx.currentTime);

    // Tenor Drone 2 (Low A2 = 220.5Hz for natural beating warmth)
    this.tenorDrone2Osc = this.ctx.createOscillator();
    this.tenorDrone2Osc.type = 'sawtooth';
    this.tenorDrone2Osc.frequency.setValueAtTime(220.8, this.ctx.currentTime);

    // Lowpass filter for warm reed tone
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, this.ctx.currentTime);

    this.bassDroneOsc.connect(filter);
    this.tenorDrone1Osc.connect(filter);
    this.tenorDrone2Osc.connect(filter);
    filter.connect(this.droneGain);

    this.bassDroneOsc.start();
    this.tenorDrone1Osc.start();
    this.tenorDrone2Osc.start();
  }

  private stopDrones() {
    try {
      if (this.bassDroneOsc) { this.bassDroneOsc.stop(); this.bassDroneOsc = null; }
      if (this.tenorDrone1Osc) { this.tenorDrone1Osc.stop(); this.tenorDrone1Osc = null; }
      if (this.tenorDrone2Osc) { this.tenorDrone2Osc.stop(); this.tenorDrone2Osc = null; }
    } catch {
      /* ignore */
    }
  }

  private startChanterMelody(tuneType: string) {
    if (!this.ctx || !this.chanterGain) return;

    const pattern = this.tunePatterns[tuneType] || this.tunePatterns['march'];
    this.currentNoteIndex = 0;

    const intervalMs = Math.max(150, (60 / (this.currentBpm * this.playbackRate)) * 1000 * 0.75);

    this.melodyInterval = window.setInterval(() => {
      if (!this.isPlaying || !this.ctx) return;

      const noteName = pattern[this.currentNoteIndex % pattern.length];
      this.playChanterNote(noteName, (intervalMs / 1000) * 0.9);
      this.currentNoteIndex++;
    }, intervalMs);
  }

  public playChanterNote(noteName: string, durationSec: number = 0.5) {
    if (!this.ctx || !this.chanterGain) return;

    const freq = this.scaleFreqs[noteName] || 293.66;

    // Grace note simulation (High G cut ornament)
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'triangle';

    const noteGain = this.ctx.createGain();
    
    // Envelope
    noteGain.gain.setValueAtTime(0.01, now);
    noteGain.gain.exponentialRampToValueAtTime(0.4, now + 0.02);
    noteGain.gain.exponentialRampToValueAtTime(0.01, now + durationSec);

    // Grace note frequency shift
    osc.frequency.setValueAtTime(392.00, now); // High G grace note strike
    osc.frequency.setValueAtTime(freq, now + 0.03); // resolve to target note

    // Resonant chanter filter
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(freq * 1.5, now);
    filter.Q.setValueAtTime(3, now);

    osc.connect(filter);
    filter.connect(noteGain);
    noteGain.connect(this.chanterGain);

    osc.start(now);
    osc.stop(now + durationSec);
  }

  public getVisualizerData(): Uint8Array {
    if (!this.analyser) {
      return new Uint8Array(32).fill(10);
    }
    const data = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(data);
    return data;
  }

  public onTimeUpdate(cb: (time: number) => void) {
    this.onTimeUpdateCallback = cb;
  }

  public onEnded(cb: () => void) {
    this.onEndedCallback = cb;
  }
}

export const audioEngine = new AudioEngine();
