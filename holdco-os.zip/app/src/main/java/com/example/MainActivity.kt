package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.holdco.data.model.*
import com.example.holdco.ui.components.*
import com.example.holdco.ui.screens.*
import com.example.holdco.ui.theme.*
import com.example.holdco.ui.viewmodel.HoldcoTab
import com.example.holdco.ui.viewmodel.HoldcoViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HoldcoTheme {
                HoldcoApp()
            }
        }
    }
}

@Composable
fun HoldcoApp(viewModel: HoldcoViewModel = viewModel()) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val activeExecutive by viewModel.activeExecutive.collectAsStateWithLifecycle()
    val reportingCurrency by viewModel.reportingCurrency.collectAsStateWithLifecycle()
    val globalSearch by viewModel.globalSearch.collectAsStateWithLifecycle()
    val kpiSummary by viewModel.kpiSummary.collectAsStateWithLifecycle()

    val entities by viewModel.entities.collectAsStateWithLifecycle()
    val decisions by viewModel.decisions.collectAsStateWithLifecycle()
    val directives by viewModel.directives.collectAsStateWithLifecycle()
    val fundingRequests by viewModel.fundingRequests.collectAsStateWithLifecycle()
    val commitments by viewModel.capitalCommitments.collectAsStateWithLifecycle()
    val treasuryAccounts by viewModel.treasuryAccounts.collectAsStateWithLifecycle()
    val payments by viewModel.payments.collectAsStateWithLifecycle()
    val journalEntries by viewModel.journalEntries.collectAsStateWithLifecycle()
    val intercompanyTransactions by viewModel.intercompanyTransactions.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val risks by viewModel.risks.collectAsStateWithLifecycle()
    val compliance by viewModel.compliance.collectAsStateWithLifecycle()
    val contracts by viewModel.contracts.collectAsStateWithLifecycle()
    val ipAssets by viewModel.ipAssets.collectAsStateWithLifecycle()
    val auditEvents by viewModel.auditEvents.collectAsStateWithLifecycle()

    val selectedEntity by viewModel.selectedEntity.collectAsStateWithLifecycle()
    val paymentPreview by viewModel.paymentPreview.collectAsStateWithLifecycle()
    val activeTerminalResult by viewModel.activeTerminalResult.collectAsStateWithLifecycle()
    val toastNotification by viewModel.toastNotification.collectAsStateWithLifecycle()

    // Back handling
    BackHandler(enabled = selectedEntity != null || paymentPreview != null || currentTab != HoldcoTab.COMMAND_CENTRE) {
        if (selectedEntity != null) {
            viewModel.selectEntity(null)
        } else if (paymentPreview != null) {
            viewModel.cancelPaymentPreview()
        } else if (currentTab != HoldcoTab.COMMAND_CENTRE) {
            viewModel.selectTab(HoldcoTab.COMMAND_CENTRE)
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(toastNotification) {
        toastNotification?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("holdco_main_scaffold"),
        containerColor = TerminalBackground,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = TerminalSurfaceElevated,
                    contentColor = SovereignGoldText,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp)
                )
            }
        },
        topBar = {
            TerminalTopBar(
                activeExecutive = activeExecutive,
                reportingCurrency = reportingCurrency,
                currentTab = currentTab,
                globalSearch = globalSearch,
                onTabSelected = { viewModel.selectTab(it) },
                onCurrencySelected = { viewModel.switchCurrency(it) },
                onRoleSelected = { viewModel.switchUserRole(it) },
                onSearchChanged = { viewModel.setGlobalSearch(it) },
                onOpenTerminal = { viewModel.selectTab(HoldcoTab.NATURAL_TERMINAL) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(TerminalBackground)
        ) {
            when (currentTab) {
                HoldcoTab.COMMAND_CENTRE -> {
                    CommandCentreScreen(
                        kpi = kpiSummary,
                        reportingCurrency = reportingCurrency,
                        decisions = decisions,
                        directives = directives,
                        fundingRequests = fundingRequests,
                        treasuryAccounts = treasuryAccounts,
                        risks = risks,
                        auditEvents = auditEvents,
                        onNavigateTab = { viewModel.selectTab(it) },
                        onApproveDecision = { viewModel.approveDecision(it) },
                        onAcknowledgeDirective = { viewModel.acknowledgeDirective(it) }
                    )
                }

                HoldcoTab.CORPORATE_STRUCTURE -> {
                    CorporateRegistryScreen(
                        entities = entities,
                        reportingCurrency = reportingCurrency,
                        searchQuery = globalSearch,
                        onEntitySelected = { viewModel.selectEntity(it) },
                        onAddNewEntity = { legal, trading, type, jur, reg, parent, pct, curr, exec, desc, cash, rev ->
                            viewModel.addNewEntity(legal, trading, type, jur, reg, parent, pct, curr, exec, desc, cash, rev)
                        }
                    )
                }

                HoldcoTab.DECISIONS_DIRECTIVES -> {
                    DecisionsDirectivesScreen(
                        decisions = decisions,
                        directives = directives,
                        entities = entities,
                        onApproveDecision = { viewModel.approveDecision(it) },
                        onRejectDecision = { id, rsn -> viewModel.rejectDecision(id, rsn) },
                        onSubmitDecision = { viewModel.submitDecision(it) },
                        onAcknowledgeDirective = { viewModel.acknowledgeDirective(it) },
                        onUpdateDirectiveStatus = { id, st, notes -> viewModel.updateDirectiveStatus(id, st, notes) }
                    )
                }

                HoldcoTab.CAPITAL_ALLOCATION -> {
                    CapitalAllocationScreen(
                        fundingRequests = fundingRequests,
                        commitments = commitments,
                        entities = entities,
                        unallocatedLiquidity = kpiSummary.unallocatedCapital,
                        reportingCurrency = reportingCurrency,
                        onApproveFundingRequest = { reqId, amt -> viewModel.approveFundingRequest(reqId, amt) }
                    )
                }

                HoldcoTab.TREASURY_LIQUIDITY -> {
                    TreasuryLiquidityScreen(
                        treasuryAccounts = treasuryAccounts,
                        payments = payments,
                        entities = entities,
                        reportingCurrency = reportingCurrency,
                        onInitiatePaymentPreview = { src, tgt, amt, curr, purp ->
                            viewModel.initiatePaymentPreview(src, tgt, amt, curr, purp)
                        }
                    )
                }

                HoldcoTab.FINANCIAL_CONSOLIDATION -> {
                    FinancialConsolidationScreen(
                        journalEntries = journalEntries,
                        intercompanyTransactions = intercompanyTransactions,
                        entities = entities,
                        reportingCurrency = reportingCurrency,
                        onReconcileTransaction = { viewModel.reconcileTransaction(it) }
                    )
                }

                HoldcoTab.SUBSIDIARIES_PROJECTS -> {
                    SubsidiariesProjectsScreen(
                        entities = entities,
                        projects = projects,
                        reportingCurrency = reportingCurrency,
                        onEntitySelected = { viewModel.selectEntity(it) }
                    )
                }

                HoldcoTab.RISK_LEGAL_IP -> {
                    RiskComplianceIpScreen(
                        risks = risks,
                        compliance = compliance,
                        contracts = contracts,
                        ipAssets = ipAssets,
                        entities = entities
                    )
                }

                HoldcoTab.NATURAL_TERMINAL -> {
                    NaturalCommandScreen(
                        activeResult = activeTerminalResult,
                        onSubmitCommand = { viewModel.submitNaturalCommand(it) },
                        onExecuteAction = { viewModel.executeTerminalAction() }
                    )
                }

                HoldcoTab.AUDIT_GOVERNANCE -> {
                    AuditAdminScreen(
                        auditEvents = auditEvents,
                        onExportCsv = { viewModel.exportAuditReportCsv() },
                        onResetData = {
                            viewModel.repository.seedInitialInstitutionalData()
                            viewModel.showToast("Demonstration state re-seeded successfully.")
                        }
                    )
                }
            }

            // Entity Dossier Modal
            selectedEntity?.let { entity ->
                val parent = entities.find { it.id == entity.parentEntityId }
                val children = viewModel.repository.getEntityChildren(entity.id)
                EntityDetailModal(
                    entity = entity,
                    parentEntity = parent,
                    children = children,
                    onDismiss = { viewModel.selectEntity(null) }
                )
            }

            // Payment Preview Modal
            paymentPreview?.let { instruction ->
                PaymentPreviewModal(
                    instruction = instruction,
                    onConfirmExecute = { viewModel.confirmExecutePayment() },
                    onCancel = { viewModel.cancelPaymentPreview() }
                )
            }
        }
    }
}
