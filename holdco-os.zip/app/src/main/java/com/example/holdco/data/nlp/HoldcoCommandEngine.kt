package com.example.holdco.data.nlp

import com.example.holdco.data.model.*
import com.example.holdco.data.repository.HoldcoRepository
import java.util.Locale

data class CommandResult(
    val intent: String,
    val summary: String,
    val details: List<String>,
    val requiresConfirmation: Boolean = false,
    val executableAction: (() -> String)? = null,
    val statusBadge: String = "QUERY_SUCCESS"
)

class HoldcoCommandEngine(private val repository: HoldcoRepository) {

    fun executeNaturalCommand(rawQuery: String): CommandResult {
        val query = rawQuery.trim().lowercase(Locale.ROOT)

        return when {
            // 1. Show subsidiaries / ownership percentages
            query.contains("subsidiaries") || query.contains("ownership") -> {
                val subs = repository.entities.value.filter { it.parentEntityId != null }
                val details = subs.map { entity ->
                    val parentName = repository.entities.value.find { it.id == entity.parentEntityId }?.tradingName ?: "Parent"
                    "• ${entity.tradingName} (${entity.legalName}): ${entity.ownershipPercentage}% owned by $parentName | Jurisdiction: ${entity.jurisdiction} | Status: ${entity.legalStatus.displayName}"
                }
                CommandResult(
                    intent = "PORTFOLIO_OWNERSHIP_AUDIT",
                    summary = "Identified ${subs.size} active subsidiary entities in corporate hierarchy.",
                    details = details
                )
            }

            // 2. Which funding requests require approval?
            query.contains("funding") && (query.contains("approval") || query.contains("pending") || query.contains("require")) -> {
                val pending = repository.fundingRequests.value.filter {
                    it.status == FundingStatus.SUBMITTED || it.status == FundingStatus.COMMITTEE_REVIEW
                }
                val details = pending.map { req ->
                    val entity = repository.entities.value.find { it.id == req.recipientEntityId }?.tradingName ?: req.recipientEntityId
                    "• ${req.id} [$entity]: $${String.format(Locale.US, "%,.0f", req.requestedAmount)} ${req.currency} for '${req.projectOrInvestment}'. IRR: ${req.appraisal.internalRateOfReturn}%, NPV: $${String.format(Locale.US, "%,.0f", req.appraisal.netPresentValue)} | Status: ${req.status.displayName}"
                }
                CommandResult(
                    intent = "PENDING_CAPITAL_ALLOCATION_AUDIT",
                    summary = "There are ${pending.size} capital funding requests awaiting committee or executive sign-off.",
                    details = details.ifEmpty { listOf("No pending funding proposals requiring immediate committee approval.") }
                )
            }

            // 3. Compare cash positions
            query.contains("cash") && (query.contains("compare") || query.contains("position") || query.contains("subsidiaries")) -> {
                val entitiesWithCash = repository.entities.value.sortedByDescending { it.cashBalance }
                val totalCash = entitiesWithCash.sumOf { it.cashBalance }
                val details = entitiesWithCash.map {
                    "• ${it.tradingName} [${it.jurisdiction}]: $${String.format(Locale.US, "%,.0f", it.cashBalance)} (Headcount: ${it.headcount}, Revenue: $${String.format(Locale.US, "%,.0f", it.annualRevenue)})"
                }
                CommandResult(
                    intent = "SUBSIDIARY_LIQUIDITY_COMPARISON",
                    summary = "Consolidated group-wide entity cash pool: $${String.format(Locale.US, "%,.0f", totalCash)} across ${entitiesWithCash.size} entities.",
                    details = details
                )
            }

            // 4. Overdue executive directives
            query.contains("overdue") || (query.contains("directive") && query.contains("status")) -> {
                val overdue = repository.directives.value.filter { it.isOverdue || it.status == DirectiveStatus.OVERDUE }
                val details = overdue.map { dir ->
                    val target = repository.entities.value.find { it.id == dir.targetEntityId }?.tradingName ?: dir.targetEntityId
                    "• [OVERDUE] ${dir.id} -> $target: '${dir.title}' (Deadline: ${dir.deadline}, Priority: ${dir.priority.displayName}). Assigned: ${dir.responsiblePerson}. Risk: ${dir.riskClassification}"
                }
                CommandResult(
                    intent = "OVERDUE_DIRECTIVES_ESCALATION",
                    summary = "Found ${overdue.size} overdue executive instruction(s) requiring immediate intervention.",
                    details = details.ifEmpty { listOf("All current executive directives are within scheduled milestone deadlines.") },
                    statusBadge = if (overdue.isNotEmpty()) "CRITICAL_ACTION_REQUIRED" else "COMPLIANT"
                )
            }

            // 5. Identify unallocated capital
            query.contains("unallocated") || (query.contains("capital") && query.contains("available")) -> {
                val totalUnencumbered = repository.treasuryAccounts.value.sumOf { it.availableLiquidity }
                val activeCommitments = repository.capitalCommitments.value.filter { !it.isDisbursed }.sumOf { it.committedAmount }
                val unallocated = totalUnencumbered - activeCommitments
                val details = listOf(
                    "• Total Unencumbered Treasury Liquidity: $${String.format(Locale.US, "%,.0f", totalUnencumbered)}",
                    "• Active Approved Undisbursed Commitments: -$${String.format(Locale.US, "%,.0f", activeCommitments)}",
                    "• Current Unallocated Capital Surplus: $${String.format(Locale.US, "%,.0f", unallocated)}",
                    "• Double-allocation guard status: ACTIVE & ENFORCED"
                )
                CommandResult(
                    intent = "UNALLOCATED_CAPITAL_SURPLUS",
                    summary = "Available unallocated capital ready for investment: $${String.format(Locale.US, "%,.0f", unallocated)}",
                    details = details
                )
            }

            // 6. Contracts expiring in next 90 days
            query.contains("contract") && (query.contains("expir") || query.contains("90")) -> {
                val expiring = repository.contracts.value.filter { it.isExpiringSoon }
                val details = expiring.map { c ->
                    val entity = repository.entities.value.find { it.id == c.entityId }?.tradingName ?: c.entityId
                    "• ${c.id}: '${c.title}' with ${c.counterparty} [$entity]. Expiry: ${c.expiryDate} (Alert window: ${c.renewalAlertDays} days). Value: $${String.format(Locale.US, "%,.0f", c.annualValue)}/yr. Status: ${c.status}"
                }
                CommandResult(
                    intent = "CONTRACT_RENEWAL_ALERT",
                    summary = "Identified ${expiring.size} contract(s) approaching expiry or renewal windows within 90 days.",
                    details = details.ifEmpty { listOf("No critical commercial or credit contracts expiring within 90 days.") }
                )
            }

            // 7. Projects that exceed budgets
            query.contains("budget") && (query.contains("exceed") || query.contains("overrun") || query.contains("project")) -> {
                val overruns = repository.projects.value.filter { it.isBudgetOverrun }
                val details = overruns.map { p ->
                    val variance = p.actualExpenditure - p.budgetTotal
                    "• [BUDGET OVERRUN] ${p.id} '${p.title}' (Lead: ${p.projectLead}): Actual: $${String.format(Locale.US, "%,.0f", p.actualExpenditure)} vs Budget: $${String.format(Locale.US, "%,.0f", p.budgetTotal)} (Variance: +$${String.format(Locale.US, "%,.0f", variance)}). Stage: ${p.stage.displayName}"
                }
                CommandResult(
                    intent = "PROJECT_EXPENDITURE_VARIANCE",
                    summary = "${overruns.size} strategic project(s) currently exceed authorized budget ceilings.",
                    details = details.ifEmpty { listOf("All active group projects are operating within authorized budget envelopes.") },
                    statusBadge = if (overruns.isNotEmpty()) "BUDGET_OVERRUN_ALERT" else "WITHIN_BUDGET"
                )
            }

            // 8. Reconcile intercompany ledger
            query.contains("reconcil") || query.contains("intercompany") -> {
                val unreconciled = repository.intercompanyTransactions.value.filter { !it.isReconciled }
                val details = unreconciled.map { tx ->
                    val orig = repository.entities.value.find { it.id == tx.originatingEntityId }?.tradingName ?: tx.originatingEntityId
                    val counter = repository.entities.value.find { it.id == tx.counterpartyEntityId }?.tradingName ?: tx.counterpartyEntityId
                    "• ${tx.id} ($orig -> $counter): $${String.format(Locale.US, "%,.0f", tx.amount)} ${tx.currency} [${tx.transactionType.displayName}]. Discrepancy: ${tx.discrepancyNotes ?: "Missing voucher"}"
                }
                CommandResult(
                    intent = "INTERCOMPANY_RECONCILIATION_AUDIT",
                    summary = "Unreconciled intercompany items: ${unreconciled.size} transaction(s) requiring ledger matching.",
                    details = details.ifEmpty { listOf("All intercompany loans, management charges, and royalty remittances are fully reconciled.") },
                    requiresConfirmation = unreconciled.isNotEmpty(),
                    executableAction = {
                        unreconciled.forEach { repository.reconcileIntercompanyTransaction(it.id) }
                        "Automated reconciliation executed: All ${unreconciled.size} transactions verified and ledger matching posted."
                    }
                )
            }

            // 9. Show high risks
            query.contains("risk") || query.contains("threat") -> {
                val highRisks = repository.risks.value.filter { it.severity == RiskSeverity.HIGH || it.severity == RiskSeverity.CRITICAL }
                val details = highRisks.map { r ->
                    val entity = repository.entities.value.find { it.id == r.affectedEntityId }?.tradingName ?: r.affectedEntityId
                    "• [${r.severity.name}] ${r.id} ($entity): '${r.title}' | Inherent: ${r.inherentScore}/25, Residual: ${r.residualScore}/25. Owner: ${r.owner}. Control: ${r.controlsSummary}"
                }
                CommandResult(
                    intent = "GROUP_RISK_EXPOSURE_HEATMAP",
                    summary = "Found ${highRisks.size} elevated material risk items on group register.",
                    details = details
                )
            }

            // 10. Default / Help interpretation
            else -> {
                CommandResult(
                    intent = "NATURAL_LANGUAGE_COMMAND_HELP",
                    summary = "HOLDCO OS Executive Terminal ready. Example valid plain-English queries:",
                    details = listOf(
                        "• 'Show all subsidiaries with their ownership percentages'",
                        "• 'Which funding requests require approval?'",
                        "• 'Compare the cash positions of all subsidiaries'",
                        "• 'Show overdue executive directives'",
                        "• 'Identify unallocated capital'",
                        "• 'List contracts expiring in the next 90 days'",
                        "• 'Show projects that exceed their budgets'",
                        "• 'Reconcile intercompany ledger'",
                        "• 'Show high risks'"
                    )
                )
            }
        }
    }
}
