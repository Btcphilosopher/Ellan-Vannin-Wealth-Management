package com.example.holdco.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.CorporateEntity
import com.example.holdco.data.model.VerificationStatus
import com.example.holdco.ui.theme.*

@Composable
fun EntityDetailModal(
    entity: CorporateEntity,
    parentEntity: CorporateEntity?,
    children: List<CorporateEntity>,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = entity.tradingName.uppercase(),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldText,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${entity.id} • ${entity.entityType.displayName}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Legal Status & Verification
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatusBadgePill(entity.legalStatus.displayName, TerminalEmerald)
                    StatusBadgePill(
                        entity.verificationStatus.displayName,
                        if (entity.verificationStatus == VerificationStatus.VERIFIED) TerminalEmerald else TerminalWarningAmber
                    )
                }

                // Corporate Identity Dossier
                TerminalCard(title = "CORPORATE REGISTRY DOSSIER") {
                    KeyValueRow("Legal Registered Name", entity.legalName)
                    KeyValueRow("Jurisdiction of Org", entity.jurisdiction)
                    KeyValueRow("Registration Number", entity.registrationNumber)
                    KeyValueRow("Incorporation Date", entity.incorporationDate)
                    KeyValueRow("Responsible Officer", entity.responsibleExecutive)
                }

                // Ownership & Governance Structure
                TerminalCard(title = "GOVERNANCE & CAPITAL STRUCTURE") {
                    KeyValueRow("Direct Holdco Ownership", "${entity.ownershipPercentage}%")
                    KeyValueRow("Voting Rights Control", "${entity.votingPercentage}%")
                    KeyValueRow("Share Class Specification", entity.shareClasses)
                    KeyValueRow("Effective Ownership Date", entity.ownershipEffectiveDate)
                    KeyValueRow("Parent Intermediate Entity", parentEntity?.tradingName ?: "Ultimate Parent (None)")
                }

                // Operating Performance
                TerminalCard(title = "FINANCIAL PERFORMANCE SUMMARY") {
                    KeyValueRow("Annualized Revenue", formatCurrency(entity.annualRevenue, entity.reportingCurrency))
                    KeyValueRow("Operating Profit / EBIT", formatCurrency(entity.operatingProfit, entity.reportingCurrency))
                    KeyValueRow("Current Cash Reserves", formatCurrency(entity.cashBalance, entity.reportingCurrency), SovereignGoldText)
                    KeyValueRow("Active Headcount", "${entity.headcount} FTE")
                }

                // Subsidiaries under this entity
                if (children.isNotEmpty()) {
                    TerminalCard(title = "SUBSIDIARY ENTITIES (${children.size})") {
                        children.forEach { child ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "• ${child.tradingName}",
                                    fontSize = 11.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${child.ownershipPercentage}% owned",
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                // Purpose
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = "BUSINESS MANDATE & STRATEGIC MISSION",
                            fontSize = 9.sp,
                            color = TextTertiary,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = entity.businessDescription,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.testTag("close_entity_modal_btn")
            ) {
                Text("CLOSE DOSSIER", color = TerminalBackground, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        },
        containerColor = TerminalSurfaceElevated
    )
}
