package com.example.holdco.data.model

enum class AccountClass(val displayName: String) {
    ASSET("Asset"),
    LIABILITY("Liability"),
    EQUITY("Equity"),
    REVENUE("Revenue"),
    EXPENSE("Expense")
}

data class JournalLine(
    val accountCode: String,
    val accountName: String,
    val accountClass: AccountClass,
    val debitAmount: Double,
    val creditAmount: Double,
    val memo: String
)

data class JournalEntry(
    val id: String,
    val entryNumber: String,
    val postingDate: String,
    val entityId: String,
    val description: String,
    val lines: List<JournalLine>,
    val isPosted: Boolean = true
) {
    val totalDebits: Double get() = lines.sumOf { it.debitAmount }
    val totalCredits: Double get() = lines.sumOf { it.creditAmount }
    val isBalanced: Boolean get() = kotlin.math.abs(totalDebits - totalCredits) < 0.001
}

enum class IntercompanyType(val displayName: String) {
    INTERCOMPANY_LOAN("Intercompany Loan"),
    LOAN_REPAYMENT("Principal / Interest Repayment"),
    MANAGEMENT_SERVICE_FEE("Parent Management Charge"),
    ROYALTY_IP_LICENCE("IP Royalty Licence"),
    SHARED_SERVICE_ALLOCATION("Shared Cost Allocation"),
    DIVIDEND_DISTRIBUTION("Subsidiary Dividend Upstream"),
    CAPITAL_INJECTION("Capital Injection")
}

data class IntercompanyTransaction(
    val id: String,
    val date: String,
    val originatingEntityId: String,
    val counterpartyEntityId: String,
    val transactionType: IntercompanyType,
    val amount: Double,
    val currency: String,
    val originatingLedgerReference: String,
    val counterpartyLedgerReference: String?,
    val isReconciled: Boolean,
    val eliminationRequired: Boolean = true,
    val discrepancyNotes: String? = null
)

data class ConsolidatedFinancialStatement(
    val reportingPeriod: String,
    val groupCurrency: String,
    val grossGroupRevenue: Double,
    val intercompanyEliminationsRevenue: Double,
    val consolidatedNetRevenue: Double,
    val operatingExpenses: Double,
    val groupEbitda: Double,
    val netInterestAndTax: Double,
    val consolidatedNetIncome: Double,
    // Balance sheet
    val totalCashAndEquivalents: Double,
    val accountsReceivableIntercompanyEliminated: Double,
    val tangibleAssetsAndProperty: Double,
    val intellectualPropertyAndGoodwill: Double,
    val totalConsolidatedAssets: Double,
    val externalDebtLiabilities: Double,
    val otherLiabilities: Double,
    val totalShareholdersEquity: Double
)
