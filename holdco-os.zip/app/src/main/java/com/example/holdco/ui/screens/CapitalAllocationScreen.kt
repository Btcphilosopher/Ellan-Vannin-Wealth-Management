package com.example.holdco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.*
import com.example.holdco.ui.components.*
import com.example.holdco.ui.theme.*

@Composable
fun CapitalAllocationScreen(
    fundingRequests: List<FundingRequest>,
    commitments: List<CapitalCommitment>,
    entities: List<CorporateEntity>,
    unallocatedLiquidity: Double,
    reportingCurrency: String,
    onApproveFundingRequest: (requestId: String, amount: Double) -> Unit
) {
    var selectedReqForAppraisal by remember { mutableStateOf<FundingRequest?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Section: Capital Allocation Envelope
        item {
            TerminalCard(
                title = "INVESTMENT COMMITTEE CAPITAL ALLOCATION DESK",
                badgeText = "Hurdle Rate: 15% ROIC",
                badgeColor = SovereignGold
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "UNALLOCATED LIQUIDITY SURPLUS",
                            fontSize = 10.sp,
                            color = TextTertiary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = formatCurrency(unallocatedLiquidity, reportingCurrency),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = TerminalEmerald,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "ACTIVE COMMITMENTS",
                            fontSize = 10.sp,
                            color = TextTertiary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = formatCurrency(commitments.sumOf { it.committedAmount }, reportingCurrency),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGoldText,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Double-allocation prevention: Capital commitments reserve funds before disbursement.\n• Hurdle rate policy: Minimum 15% ROIC required for capex grants.",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }

        // Section: Funding Requests Pipeline
        item {
            Text(
                text = "PORTFOLIO FUNDING PROPOSALS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = SovereignGoldText
            )
        }

        items(fundingRequests, key = { it.id }) { req ->
            val entity = entities.find { it.id == req.recipientEntityId }
            val statusColor = when (req.status) {
                FundingStatus.APPROVED, FundingStatus.DISBURSED -> TerminalEmerald
                FundingStatus.COMMITTEE_REVIEW -> SovereignGold
                FundingStatus.SUBMITTED -> TerminalCyan
                FundingStatus.REJECTED -> TerminalAlertRed
                else -> TextSecondary
            }

            TerminalCard(
                title = "${entity?.tradingName ?: req.recipientEntityId} — ${req.projectOrInvestment}",
                badgeText = req.status.displayName,
                badgeColor = statusColor,
                modifier = Modifier.testTag("funding_req_${req.id}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatusBadgePill(req.instrument.displayName, SovereignGold)
                    Text(
                        text = "Requested: ${formatCurrency(req.requestedAmount, req.currency)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldText,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = req.purpose,
                    fontSize = 12.sp,
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quantitative Financial Appraisal Grid
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalSurfaceElevated)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "QUANTITATIVE INVESTMENT APPRAISAL",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGoldText,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "NPV: ${formatCurrency(req.appraisal.netPresentValue, req.currency)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TerminalEmerald,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "IRR: ${req.appraisal.internalRateOfReturn}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TerminalCyan,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "ROIC: ${req.appraisal.roicPercentage}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignGold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Payback: ${req.appraisal.paybackMonths}m",
                                fontSize = 11.sp,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Business Case: ${req.businessCase}",
                    fontSize = 11.sp,
                    color = TextSecondary
                )

                if (req.status == FundingStatus.COMMITTEE_REVIEW || req.status == FundingStatus.SUBMITTED) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = { onApproveFundingRequest(req.id, req.requestedAmount) },
                            colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.testTag("approve_capital_${req.id}")
                        ) {
                            Text(
                                text = "APPROVE & COMMIT TRANCHE",
                                color = TerminalBackground,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                } else if (req.status == FundingStatus.APPROVED) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Commitment Active: Approved amount of ${formatCurrency(req.approvedAmount ?: req.requestedAmount, req.currency)} reserved in capital pool.",
                        fontSize = 10.sp,
                        color = TerminalEmerald,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Section: Active Commitments Ledger
        item {
            TerminalCard(
                title = "ACTIVE CAPITAL COMMITMENTS LEDGER",
                badgeText = "${commitments.size} Commitments",
                badgeColor = TerminalCyan
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    commitments.forEach { comm ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceElevated)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${comm.id} • ${comm.targetEntityId}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Committed: ${comm.committedDate}",
                                    fontSize = 10.sp,
                                    color = TextTertiary
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = formatCurrency(comm.committedAmount, comm.currency),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SovereignGoldText,
                                    fontFamily = FontFamily.Monospace
                                )
                                StatusBadgePill(
                                    if (comm.isDisbursed) "Disbursed" else "Reserved",
                                    if (comm.isDisbursed) TerminalEmerald else SovereignGold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
