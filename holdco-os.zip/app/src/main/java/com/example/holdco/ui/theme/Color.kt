package com.example.holdco.ui.theme

import androidx.compose.ui.graphics.Color

val TerminalBackground = Color(0xFF070A12)
val TerminalSurface = Color(0xFF0E1526)
val TerminalSurfaceElevated = Color(0xFF151E33)
val TerminalSurfaceHighlight = Color(0xFF1E2942)
val TerminalBorder = Color(0xFF23304A)
val TerminalBorderActive = Color(0xFF384B70)

val SovereignGold = Color(0xFFE5B842)
val SovereignGoldContainer = Color(0xFF2C220E)
val SovereignGoldText = Color(0xFFF6D87C)

val TerminalEmerald = Color(0xFF10B981)
val TerminalEmeraldContainer = Color(0xFF0D2E22)
val TerminalCyan = Color(0xFF06B6D4)
val TerminalCyanContainer = Color(0xFF0A2933)

val TerminalAlertRed = Color(0xFFEF4444)
val TerminalAlertRedContainer = Color(0xFF331215)
val TerminalWarningAmber = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
