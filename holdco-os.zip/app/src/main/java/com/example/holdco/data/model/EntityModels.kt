package com.example.holdco.data.model

enum class EntityType(val displayName: String) {
    PARENT_HOLDING("Parent Holding Co"),
    INTERMEDIATE_HOLDING("Intermediate Holding"),
    OPERATING_SUBSIDIARY("Operating Subsidiary"),
    JOINT_VENTURE("Joint Venture"),
    ASSOCIATE("Associate (Minority)"),
    INVESTMENT_VEHICLE("Investment Vehicle / SPV"),
    SPECIAL_PURPOSE_ENTITY("Special Purpose Entity"),
    BRANCH("Regional Branch"),
    INTERNAL_DIVISION("Internal Division"),
    BRAND_TRADING_NAME("Brand / Trading Name"),
    RESEARCH_PROGRAMME("Research Programme"),
    IP_HOLDING_ENTITY("IP Holding Co")
}

enum class VerificationStatus(val displayName: String) {
    VERIFIED("Verified"),
    USER_DECLARED("User-Declared"),
    PENDING_VERIFICATION("Pending Verification"),
    PROPOSED("Proposed"),
    DISPUTED("Disputed"),
    ARCHIVED("Archived")
}

enum class LegalOperatingStatus(val displayName: String) {
    ACTIVE("Active / Good Standing"),
    DORMANT("Dormant"),
    REORGANIZING("Under Reorganization"),
    LIQUIDATION("In Liquidation")
}

data class CorporateEntity(
    val id: String,
    val legalName: String,
    val tradingName: String,
    val entityType: EntityType,
    val jurisdiction: String,
    val registrationNumber: String,
    val incorporationDate: String,
    val parentEntityId: String?,
    val ownershipPercentage: Double,
    val votingPercentage: Double,
    val shareClasses: String,
    val ownershipEffectiveDate: String,
    val verificationStatus: VerificationStatus,
    val legalStatus: LegalOperatingStatus,
    val reportingCurrency: String,
    val responsibleExecutive: String,
    val businessDescription: String,
    val annualRevenue: Double,
    val operatingProfit: Double,
    val cashBalance: Double,
    val headcount: Int,
    val isControlled: Boolean = ownershipPercentage >= 50.0
)

data class ShareholderRelation(
    val entityId: String,
    val shareholderName: String,
    val percentage: Double,
    val votingRightsPercentage: Double,
    val shareClass: String,
    val isParentHolding: Boolean
)
