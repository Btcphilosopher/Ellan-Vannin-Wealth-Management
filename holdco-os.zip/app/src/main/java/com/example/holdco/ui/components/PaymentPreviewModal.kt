package com.example.holdco.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.PaymentInstruction
import com.example.holdco.ui.theme.*

@Composable
fun PaymentPreviewModal(
    instruction: PaymentInstruction,
    onConfirmExecute: () -> Unit,
    onCancel: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = {
            Text(
                text = "TREASURY PAYMENT PREVIEW & CLEARING VALIDATION",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = SovereignGold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalEmeraldContainer)
                        .border(1.dp, TerminalEmerald, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "✓ LIQUIDITY VERIFIED • FUNDS RESERVED • ZERO DUPLICATE COLLISIONS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalEmerald,
                        fontFamily = FontFamily.Monospace
                    )
                }

                TerminalCard(title = "TRANSACTION SPECIFICATIONS") {
                    KeyValueRow("Transfer Amount", formatCurrency(instruction.amount, instruction.currency), SovereignGoldText)
                    KeyValueRow("Source Account ID", instruction.sourceAccountId)
                    KeyValueRow("Target Recipient Entity", instruction.targetEntityId)
                    KeyValueRow("Settlement Code", instruction.referenceCode)
                    KeyValueRow("Mandate Purpose", instruction.paymentPurpose)
                    KeyValueRow("Initiating Officer", instruction.initiatedBy)
                }

                TerminalCard(title = "INSTITUTIONAL CLEARING CONTROLS") {
                    KeyValueRow("Idempotency Hash", instruction.idempotencyKey.take(12), TerminalCyan)
                    KeyValueRow("Dual Authorization Policy", "Enforced (Level 8+)")
                    KeyValueRow("Bookkeeping Impact", "Double-Entry JE will be posted automatically upon settlement")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirmExecute,
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.testTag("confirm_execute_payment_btn")
            ) {
                Text(
                    text = "AUTHORIZE & EXECUTE SETTLEMENT",
                    color = TerminalBackground,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onCancel) {
                Text("CANCEL / ABORT", color = TextSecondary, fontFamily = FontFamily.Monospace)
            }
        },
        containerColor = TerminalSurfaceElevated
    )
}
