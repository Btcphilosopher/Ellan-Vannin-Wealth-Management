package com.example.holdco.data.model

enum class FundingInstrument(val displayName: String) {
    EQUITY_CONTRIBUTION("Equity Contribution"),
    INTERCOMPANY_LOAN("Intercompany Loan (Subordinated)"),
    EXTERNAL_FACILITY("External Credit Facility"),
    CAPEX_GRANT("Capital Expenditure Allocation"),
    OPERATING_BUDGET("Operating Cash Tranche"),
    RESEARCH_BUDGET("R&D Strategic Budget"),
    ACQUISITION_FACILITY("M&A Bridge Facility")
}

enum class FundingStatus(val displayName: String) {
    DRAFT("Draft Proposal"),
    SUBMITTED("Submitted"),
    COMMITTEE_REVIEW("Investment Committee Review"),
    APPROVED("Approved / Committed"),
    REJECTED("Rejected"),
    DISBURSED("Disbursed"),
    RECONCILED("Reconciled & Active")
}

data class FinancialAppraisal(
    val netPresentValue: Double,
    val internalRateOfReturn: Double,
    val paybackMonths: Int,
    val roicPercentage: Double,
    val discountRate: Double,
    val downsideScenarioLoss: Double
)

data class FundingRequest(
    val id: String,
    val requestingEntityId: String,
    val recipientEntityId: String,
    val projectOrInvestment: String,
    val requestedAmount: Double,
    val currency: String,
    val instrument: FundingInstrument,
    val purpose: String,
    val businessCase: String,
    val cashFlowForecastSummary: String,
    val appraisal: FinancialAppraisal,
    val proposedRepaymentTerms: String?,
    val status: FundingStatus,
    val approvedAmount: Double? = null,
    val committeeResolution: String? = null,
    val disbursedDate: String? = null
)

data class CapitalCommitment(
    val id: String,
    val fundingRequestId: String,
    val committedAmount: Double,
    val currency: String,
    val sourceEntityId: String,
    val targetEntityId: String,
    val committedDate: String,
    val isDisbursed: Boolean = false
)
