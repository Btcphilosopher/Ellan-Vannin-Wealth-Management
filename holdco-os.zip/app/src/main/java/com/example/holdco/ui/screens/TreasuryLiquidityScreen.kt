package com.example.holdco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.*
import com.example.holdco.ui.components.*
import com.example.holdco.ui.theme.*

@Composable
fun TreasuryLiquidityScreen(
    treasuryAccounts: List<TreasuryAccount>,
    payments: List<PaymentInstruction>,
    entities: List<CorporateEntity>,
    reportingCurrency: String,
    onInitiatePaymentPreview: (sourceAccountId: String, targetEntityId: String, amount: Double, currency: String, purpose: String) -> Unit
) {
    var showPaymentModal by remember { mutableStateOf(false) }
    var selectedSourceAccountId by remember { mutableStateOf(treasuryAccounts.firstOrNull()?.id ?: "") }
    var selectedTargetEntityId by remember { mutableStateOf(entities.getOrNull(3)?.id ?: "") }
    var paymentAmountText by remember { mutableStateOf("1500000") }
    var paymentPurpose by remember { mutableStateOf("Tranche 2 Capex Allocation") }

    val totalBalance = treasuryAccounts.sumOf { it.balance }
    val totalRestricted = treasuryAccounts.sumOf { it.restrictedBalance }
    val totalAvailable = treasuryAccounts.sumOf { it.availableLiquidity }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Section: Treasury Summary Header
        item {
            TerminalCard(
                title = "CENTRAL TREASURY & MULTI-CURRENCY LIQUIDITY",
                badgeText = "Live Gateway: Connected",
                badgeColor = TerminalEmerald
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("TOTAL RECORDED CASH", fontSize = 10.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                        Text(formatCurrency(totalBalance, reportingCurrency), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SovereignGoldText, fontFamily = FontFamily.Monospace)
                    }
                    Column {
                        Text("RESTRICTED / ESCROW", fontSize = 10.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                        Text(formatCurrency(totalRestricted, reportingCurrency), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TerminalAlertRed, fontFamily = FontFamily.Monospace)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("UNENCUMBERED LIQUIDITY", fontSize = 10.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                        Text(formatCurrency(totalAvailable, reportingCurrency), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TerminalEmerald, fontFamily = FontFamily.Monospace)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { showPaymentModal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth().testTag("initiate_disbursement_btn")
                ) {
                    Text(
                        text = "INITIATE TREASURY DISBURSEMENT",
                        color = TerminalBackground,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Section: Treasury Bank Accounts Breakdown
        item {
            Text(
                text = "INSTITUTIONAL BANK ACCOUNTS & SWEEP FACILITIES",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = SovereignGoldText
            )
        }

        items(treasuryAccounts, key = { it.id }) { acct ->
            TerminalCard(
                title = acct.institutionName,
                badgeText = acct.verification.displayName,
                badgeColor = if (acct.verification == BalanceVerification.LIVE_PROVIDER) TerminalEmerald else TerminalCyan,
                modifier = Modifier.testTag("account_card_${acct.id}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${acct.accountType.displayName} • ${acct.accountNumberMasked}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "APY: ${acct.yieldApy}%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalEmerald,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                KeyValueRow("Gross Stored Balance", formatCurrency(acct.balance, acct.currency), SovereignGoldText)
                if (acct.restrictedBalance > 0.0) {
                    KeyValueRow("Restricted / Pledged Covenants", "-${formatCurrency(acct.restrictedBalance, acct.currency)}", TerminalAlertRed)
                }
                KeyValueRow("Net Unencumbered Liquidity", formatCurrency(acct.availableLiquidity, acct.currency), TerminalEmerald)
                KeyValueRow("Last Refreshed", acct.lastRefreshed)
            }
        }

        // Section: 30d, 90d, 12m Cashflow Forecast
        item {
            TerminalCard(
                title = "GROUP CASHFLOW PROJECTIONS & SCENARIO ANALYSIS",
                badgeText = "Stress Tested",
                badgeColor = TerminalCyan
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val forecasts = listOf(
                        Triple("30-DAY OUTLOOK", 18_400_000.0, -12_200_000.0),
                        Triple("90-DAY OUTLOOK", 54_800_000.0, -38_900_000.0),
                        Triple("12-MONTH HORIZON", 215_000_000.0, -154_000_000.0)
                    )

                    forecasts.forEach { (horizon, inflows, outflows) ->
                        val net = inflows + outflows
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceElevated)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(horizon, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary, fontFamily = FontFamily.Monospace)
                                Text("Inflows: +${formatCurrency(inflows, reportingCurrency)} • Outflows: ${formatCurrency(outflows, reportingCurrency)}", fontSize = 10.sp, color = TextSecondary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Net: ${if (net >= 0) "+" else ""}${formatCurrency(net, reportingCurrency)}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (net >= 0) TerminalEmerald else TerminalAlertRed,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text("Base scenario", fontSize = 9.sp, color = TextTertiary)
                            }
                        }
                    }
                }
            }
        }

        // Section: Recent Payments & Transfers
        item {
            TerminalCard(
                title = "RECENT SETTLEMENTS & DISBURSEMENTS",
                badgeText = "${payments.size} Recorded",
                badgeColor = SovereignGold
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    payments.forEach { pmt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceElevated)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${pmt.referenceCode} • To ${pmt.targetEntityId}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "${pmt.paymentPurpose} • Initiator: ${pmt.initiatedBy}",
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                                if (pmt.executionLog != null) {
                                    Text(
                                        text = pmt.executionLog,
                                        fontSize = 9.sp,
                                        color = TextTertiary,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = formatCurrency(pmt.amount, pmt.currency),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SovereignGoldText,
                                    fontFamily = FontFamily.Monospace
                                )
                                StatusBadgePill(pmt.status.displayName, TerminalEmerald)
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Initiate Payment
    if (showPaymentModal) {
        AlertDialog(
            onDismissRequest = { showPaymentModal = false },
            title = {
                Text(
                    text = "INITIATE TREASURY DISBURSEMENT",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SovereignGold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Select Funding Source Account:", fontSize = 11.sp, color = TextSecondary)
                    treasuryAccounts.forEach { acct ->
                        val isSelected = acct.id == selectedSourceAccountId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) SovereignGoldContainer else TerminalSurface)
                                .border(1.dp, if (isSelected) SovereignGold else TerminalBorder, RoundedCornerShape(4.dp))
                                .clickable { selectedSourceAccountId = acct.id }
                                .padding(6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(acct.institutionName, fontSize = 11.sp, color = if (isSelected) SovereignGoldText else TextPrimary)
                            Text(formatCurrency(acct.availableLiquidity, acct.currency), fontSize = 11.sp, color = SovereignGoldText, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = paymentAmountText,
                        onValueChange = { paymentAmountText = it },
                        label = { Text("Transfer Amount ($)") },
                        modifier = Modifier.fillMaxWidth().testTag("payment_amount_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = paymentPurpose,
                        onValueChange = { paymentPurpose = it },
                        label = { Text("Mandate / Purpose") },
                        modifier = Modifier.fillMaxWidth().testTag("payment_purpose_input"),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = paymentAmountText.toDoubleOrNull() ?: 0.0
                        if (amt > 0) {
                            onInitiatePaymentPreview(
                                selectedSourceAccountId,
                                selectedTargetEntityId,
                                amt,
                                "USD",
                                paymentPurpose
                            )
                            showPaymentModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                    modifier = Modifier.testTag("preview_payment_btn")
                ) {
                    Text("GENERATE PAYMENT PREVIEW", color = TerminalBackground, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPaymentModal = false }) { Text("CANCEL", color = TextSecondary) }
            },
            containerColor = TerminalSurfaceElevated
        )
    }
}
