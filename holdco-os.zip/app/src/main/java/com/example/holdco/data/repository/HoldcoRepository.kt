package com.example.holdco.data.repository

import com.example.holdco.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class HoldcoRepository {

    private val _entities = MutableStateFlow<List<CorporateEntity>>(emptyList())
    val entities: StateFlow<List<CorporateEntity>> = _entities.asStateFlow()

    private val _decisions = MutableStateFlow<List<ExecutiveDecision>>(emptyList())
    val decisions: StateFlow<List<ExecutiveDecision>> = _decisions.asStateFlow()

    private val _directives = MutableStateFlow<List<Directive>>(emptyList())
    val directives: StateFlow<List<Directive>> = _directives.asStateFlow()

    private val _fundingRequests = MutableStateFlow<List<FundingRequest>>(emptyList())
    val fundingRequests: StateFlow<List<FundingRequest>> = _fundingRequests.asStateFlow()

    private val _capitalCommitments = MutableStateFlow<List<CapitalCommitment>>(emptyList())
    val capitalCommitments: StateFlow<List<CapitalCommitment>> = _capitalCommitments.asStateFlow()

    private val _treasuryAccounts = MutableStateFlow<List<TreasuryAccount>>(emptyList())
    val treasuryAccounts: StateFlow<List<TreasuryAccount>> = _treasuryAccounts.asStateFlow()

    private val _payments = MutableStateFlow<List<PaymentInstruction>>(emptyList())
    val payments: StateFlow<List<PaymentInstruction>> = _payments.asStateFlow()

    private val _journalEntries = MutableStateFlow<List<JournalEntry>>(emptyList())
    val journalEntries: StateFlow<List<JournalEntry>> = _journalEntries.asStateFlow()

    private val _intercompanyTransactions = MutableStateFlow<List<IntercompanyTransaction>>(emptyList())
    val intercompanyTransactions: StateFlow<List<IntercompanyTransaction>> = _intercompanyTransactions.asStateFlow()

    private val _projects = MutableStateFlow<List<ProjectItem>>(emptyList())
    val projects: StateFlow<List<ProjectItem>> = _projects.asStateFlow()

    private val _risks = MutableStateFlow<List<RiskItem>>(emptyList())
    val risks: StateFlow<List<RiskItem>> = _risks.asStateFlow()

    private val _compliance = MutableStateFlow<List<ComplianceObligation>>(emptyList())
    val compliance: StateFlow<List<ComplianceObligation>> = _compliance.asStateFlow()

    private val _contracts = MutableStateFlow<List<ContractItem>>(emptyList())
    val contracts: StateFlow<List<ContractItem>> = _contracts.asStateFlow()

    private val _ipAssets = MutableStateFlow<List<IPAssetItem>>(emptyList())
    val ipAssets: StateFlow<List<IPAssetItem>> = _ipAssets.asStateFlow()

    private val _auditEvents = MutableStateFlow<List<AuditEvent>>(emptyList())
    val auditEvents: StateFlow<List<AuditEvent>> = _auditEvents.asStateFlow()

    private val _activeExecutive = MutableStateFlow(
        ActiveExecutive(
            name = "Lord Alistair Sterling",
            title = "Executive Chairman & Group CEO",
            role = UserRole.GROUP_OWNER
        )
    )
    val activeExecutive: StateFlow<ActiveExecutive> = _activeExecutive.asStateFlow()

    private val _reportingCurrency = MutableStateFlow("USD")
    val reportingCurrency: StateFlow<String> = _reportingCurrency.asStateFlow()

    init {
        seedInitialInstitutionalData()
    }

    private fun getCurrentTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        return sdf.format(Date())
    }

    private fun computeSha256(data: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(data.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }.take(16).uppercase()
    }

    fun logAudit(
        actionType: String,
        targetType: String,
        targetId: String,
        summary: String,
        previousState: String? = null,
        newState: String? = null
    ) {
        val exec = _activeExecutive.value
        val ts = getCurrentTimestamp()
        val signature = computeSha256("$ts-${exec.name}-$actionType-$targetId-$summary")
        val event = AuditEvent(
            id = "AUD-${UUID.randomUUID().toString().take(8).uppercase()}",
            timestamp = ts,
            userRole = exec.role.roleTitle,
            userName = exec.name,
            actionType = actionType,
            targetType = targetType,
            targetId = targetId,
            summary = summary,
            previousState = previousState,
            newState = newState,
            verificationHash = signature
        )
        _auditEvents.value = listOf(event) + _auditEvents.value
    }

    fun setActiveExecutive(role: UserRole) {
        val newExec = when (role) {
            UserRole.GROUP_OWNER -> ActiveExecutive("Lord Alistair Sterling", "Executive Chairman & Group CEO", role)
            UserRole.GROUP_CEO -> ActiveExecutive("Dr. Evelyn Vance", "Group Chief Executive Officer", role)
            UserRole.CHIEF_FINANCIAL_OFFICER -> ActiveExecutive("Julian Croft, FCA", "Group Chief Financial Officer", role)
            UserRole.HEAD_OF_TREASURY -> ActiveExecutive("Elena Rostova", "Head of Global Treasury & Liquidity", role)
            UserRole.SUBSIDIARY_EXECUTIVE -> ActiveExecutive("Marcus Chen", "Managing Director, Nexus Robotics", role, "ENT-004")
            UserRole.GROUP_AUDITOR -> ActiveExecutive("Claire Beauchamp", "Chief Internal Auditor", role)
        }
        val prev = _activeExecutive.value.role.roleTitle
        _activeExecutive.value = newExec
        logAudit("ROLE_SWITCH", "UserSession", role.name, "Switched active terminal role to ${role.roleTitle}", prev, role.roleTitle)
    }

    fun setReportingCurrency(curr: String) {
        _reportingCurrency.value = curr
    }

    // ==========================================
    // Corporate Registry & Ownership Logic
    // ==========================================

    fun addCorporateEntity(entity: CorporateEntity): Result<Unit> {
        // Prevent circular ownership
        if (entity.parentEntityId != null) {
            if (isCircularParent(entity.id, entity.parentEntityId)) {
                return Result.failure(IllegalArgumentException("Circular ownership structure detected! Entity cannot be its own ancestor."))
            }
        }
        _entities.value = _entities.value + entity
        logAudit("ENTITY_REGISTRATION", "CorporateEntity", entity.id, "Registered new entity: ${entity.legalName} (${entity.entityType.displayName}) in ${entity.jurisdiction}")
        return Result.success(Unit)
    }

    fun isCircularParent(proposedEntityId: String, targetParentId: String): Boolean {
        if (proposedEntityId == targetParentId) return true
        var current: CorporateEntity? = _entities.value.find { it.id == targetParentId }
        val visited = mutableSetOf<String>()
        while (current != null && current.parentEntityId != null) {
            if (current.parentEntityId == proposedEntityId) return true
            if (visited.contains(current.id)) return true
            visited.add(current.id)
            current = _entities.value.find { it.id == current?.parentEntityId }
        }
        return false
    }

    fun getEntityChildren(parentId: String): List<CorporateEntity> {
        return _entities.value.filter { it.parentEntityId == parentId }
    }

    // ==========================================
    // Decisions & Directives Lifecycle
    // ==========================================

    fun submitDecision(id: String): Boolean {
        val list = _decisions.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) {
            val d = list[idx]
            val updated = d.copy(status = DecisionStatus.SUBMITTED)
            list[idx] = updated
            _decisions.value = list
            logAudit("DECISION_SUBMIT", "ExecutiveDecision", id, "Submitted decision '${d.title}' for board/committee review", d.status.name, updated.status.name)
            return true
        }
        return false
    }

    fun approveDecision(id: String): Boolean {
        val list = _decisions.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) {
            val d = list[idx]
            val exec = _activeExecutive.value
            val ts = getCurrentTimestamp()
            val updated = d.copy(
                status = DecisionStatus.APPROVED,
                approvedBy = "${exec.name} (${exec.role.roleTitle})",
                approvalTimestamp = ts
            )
            list[idx] = updated
            _decisions.value = list
            logAudit("DECISION_APPROVE", "ExecutiveDecision", id, "Approved decision '${d.title}' with cost authorization: $${d.estimatedCost}", d.status.name, updated.status.name)
            return true
        }
        return false
    }

    fun rejectDecision(id: String, rationale: String): Boolean {
        val list = _decisions.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) {
            val d = list[idx]
            val updated = d.copy(status = DecisionStatus.REJECTED, outcomeNotes = "Rejected: $rationale")
            list[idx] = updated
            _decisions.value = list
            logAudit("DECISION_REJECT", "ExecutiveDecision", id, "Rejected decision '${d.title}': $rationale", d.status.name, updated.status.name)
            return true
        }
        return false
    }

    fun acknowledgeDirective(id: String, acknowledgedBy: String): Boolean {
        val list = _directives.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) {
            val d = list[idx]
            val updated = d.copy(
                status = DirectiveStatus.ACKNOWLEDGED,
                acknowledgementTimestamp = getCurrentTimestamp(),
                executionUpdates = d.executionUpdates + "Acknowledged by $acknowledgedBy at ${getCurrentTimestamp()}"
            )
            list[idx] = updated
            _directives.value = list
            logAudit("DIRECTIVE_ACK", "Directive", id, "Subsidiary acknowledged directive: ${d.title}", d.status.name, updated.status.name)
            return true
        }
        return false
    }

    fun updateDirectiveStatus(id: String, newStatus: DirectiveStatus, notes: String): Boolean {
        val list = _directives.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) {
            val d = list[idx]
            val updated = d.copy(
                status = newStatus,
                executionUpdates = d.executionUpdates + "[${getCurrentTimestamp()}] Status changed to ${newStatus.name}: $notes"
            )
            list[idx] = updated
            _directives.value = list
            logAudit("DIRECTIVE_STATUS", "Directive", id, "Directive ${d.title} set to ${newStatus.name}", d.status.name, newStatus.name)
            return true
        }
        return false
    }

    // ==========================================
    // Capital Allocation Workflow
    // ==========================================

    fun approveFundingRequest(requestId: String, approvedAmount: Double): Result<CapitalCommitment> {
        val reqList = _fundingRequests.value.toMutableList()
        val idx = reqList.indexOfFirst { it.id == requestId }
        if (idx < 0) return Result.failure(IllegalArgumentException("Funding request $requestId not found"))

        val req = reqList[idx]
        if (req.status == FundingStatus.APPROVED || req.status == FundingStatus.DISBURSED) {
            return Result.failure(IllegalStateException("Funding request already approved or disbursed!"))
        }

        // Prevent double allocation: check total available liquidity across treasury
        val totalUnencumberedCash = _treasuryAccounts.value.sumOf { it.availableLiquidity }
        val activeCommitments = _capitalCommitments.value.filter { !it.isDisbursed }.sumOf { it.committedAmount }
        val unallocatedCapital = totalUnencumberedCash - activeCommitments

        if (approvedAmount > unallocatedCapital) {
            return Result.failure(IllegalStateException("Capital commitment of $$approvedAmount exceeds unallocated liquidity ($$unallocatedCapital)"))
        }

        val updatedReq = req.copy(
            status = FundingStatus.APPROVED,
            approvedAmount = approvedAmount,
            committeeResolution = "Approved by Investment Committee. Executive signatory: ${_activeExecutive.value.name}"
        )
        reqList[idx] = updatedReq
        _fundingRequests.value = reqList

        val commitment = CapitalCommitment(
            id = "COMM-${UUID.randomUUID().toString().take(6).uppercase()}",
            fundingRequestId = req.id,
            committedAmount = approvedAmount,
            currency = req.currency,
            sourceEntityId = "ENT-001",
            targetEntityId = req.recipientEntityId,
            committedDate = getCurrentTimestamp()
        )
        _capitalCommitments.value = _capitalCommitments.value + commitment

        logAudit("CAPITAL_COMMIT", "CapitalCommitment", commitment.id, "Committed $$approvedAmount to entity ${req.recipientEntityId} for ${req.projectOrInvestment}")
        return Result.success(commitment)
    }

    // ==========================================
    // Treasury & Payment Simulation
    // ==========================================

    fun previewPayment(
        sourceAccountId: String,
        targetEntityId: String,
        amount: Double,
        currency: String,
        purpose: String
    ): Result<PaymentInstruction> {
        val account = _treasuryAccounts.value.find { it.id == sourceAccountId }
            ?: return Result.failure(IllegalArgumentException("Source treasury account not found"))

        if (account.availableLiquidity < amount) {
            return Result.failure(IllegalStateException("Insufficient available liquidity! Account balance: $${account.balance}, Restricted: $${account.restrictedBalance}, Requested: $$amount"))
        }

        val idempotencyKey = computeSha256("$sourceAccountId-$targetEntityId-$amount-$purpose")
        // Check for duplicate payment instruction
        val existing = _payments.value.find { it.idempotencyKey == idempotencyKey && it.status != PaymentStatus.FAILED }
        if (existing != null) {
            return Result.failure(IllegalStateException("Duplicate payment instruction detected! Reference: ${existing.referenceCode}"))
        }

        val instruction = PaymentInstruction(
            id = "PMT-${UUID.randomUUID().toString().take(6).uppercase()}",
            sourceAccountId = sourceAccountId,
            targetEntityId = targetEntityId,
            recipientIbanOrAccount = "GB82BARC20201599887766",
            amount = amount,
            currency = currency,
            paymentPurpose = purpose,
            referenceCode = "REF-${System.currentTimeMillis().toString().takeLast(6)}",
            status = PaymentStatus.FUNDS_CHECKED,
            idempotencyKey = idempotencyKey,
            initiatedBy = _activeExecutive.value.name,
            timestamp = getCurrentTimestamp()
        )
        return Result.success(instruction)
    }

    fun executePayment(instruction: PaymentInstruction): Result<PaymentInstruction> {
        val acctList = _treasuryAccounts.value.toMutableList()
        val acctIdx = acctList.indexOfFirst { it.id == instruction.sourceAccountId }
        if (acctIdx < 0) return Result.failure(IllegalArgumentException("Source treasury account missing"))

        val acct = acctList[acctIdx]
        if (acct.availableLiquidity < instruction.amount) {
            return Result.failure(IllegalStateException("Insufficient funds at execution time!"))
        }

        // Deduct from account
        val updatedAcct = acct.copy(balance = acct.balance - instruction.amount)
        acctList[acctIdx] = updatedAcct
        _treasuryAccounts.value = acctList

        // Mark payment settled
        val settledInstruction = instruction.copy(
            status = PaymentStatus.SETTLED,
            authorizedBy = _activeExecutive.value.name,
            executionLog = "Settled via Simulated SWIFT / RTGS Clearing gateway. Auth Token: HOLDCO-GATEWAY-${UUID.randomUUID().toString().take(8)}"
        )
        _payments.value = listOf(settledInstruction) + _payments.value

        // Post balanced double-entry journal entry!
        val journalEntry = JournalEntry(
            id = "JE-${UUID.randomUUID().toString().take(6).uppercase()}",
            entryNumber = "JE-2026-${_journalEntries.value.size + 101}",
            postingDate = getCurrentTimestamp().take(10),
            entityId = acct.entityId,
            description = "Disbursement: ${instruction.paymentPurpose} (${instruction.referenceCode})",
            lines = listOf(
                JournalLine(
                    accountCode = "1200-INTERCO",
                    accountName = "Intercompany Funding Asset / Investment",
                    accountClass = AccountClass.ASSET,
                    debitAmount = instruction.amount,
                    creditAmount = 0.0,
                    memo = "Tranche allocated to entity ${instruction.targetEntityId}"
                ),
                JournalLine(
                    accountCode = "1000-CASH",
                    accountName = "Cash & Cash Equivalents (${acct.institutionName})",
                    accountClass = AccountClass.ASSET,
                    debitAmount = 0.0,
                    creditAmount = instruction.amount,
                    memo = "Settlement clearing transfer"
                )
            ),
            isPosted = true
        )
        _journalEntries.value = listOf(journalEntry) + _journalEntries.value

        logAudit("TREASURY_DISBURSEMENT", "PaymentInstruction", instruction.id, "Executed payment of $${instruction.amount} from ${acct.institutionName} to ${instruction.targetEntityId}. JE ${journalEntry.entryNumber} balanced.")
        return Result.success(settledInstruction)
    }

    // ==========================================
    // Intercompany Reconciliation
    // ==========================================

    fun reconcileIntercompanyTransaction(id: String): Boolean {
        val list = _intercompanyTransactions.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) {
            val tx = list[idx]
            val updated = tx.copy(isReconciled = true, discrepancyNotes = "Reconciled with counterparty ledger confirmation on ${getCurrentTimestamp()}")
            list[idx] = updated
            _intercompanyTransactions.value = list
            logAudit("INTERCO_RECON", "IntercompanyTransaction", id, "Reconciled intercompany transaction: ${tx.transactionType.displayName} ($${tx.amount})")
            return true
        }
        return false
    }

    // ==========================================
    // Seed Data Initialization
    // ==========================================

    fun seedInitialInstitutionalData() {
        val entitiesList = listOf(
            CorporateEntity(
                id = "ENT-001",
                legalName = "Aethelgard Holdings PLC",
                tradingName = "Aethelgard Group",
                entityType = EntityType.PARENT_HOLDING,
                jurisdiction = "United Kingdom (England & Wales)",
                registrationNumber = "UK-08492014",
                incorporationDate = "1994-04-12",
                parentEntityId = null,
                ownershipPercentage = 100.0,
                votingPercentage = 100.0,
                shareClasses = "Class A Ordinary (Voting), Golden Governance Share",
                ownershipEffectiveDate = "1994-04-12",
                verificationStatus = VerificationStatus.VERIFIED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "USD",
                responsibleExecutive = "Lord Alistair Sterling",
                businessDescription = "Parent holding corporation exercising sovereign governance, capital allocation, and consolidated group treasury over global subsidiaries.",
                annualRevenue = 412_500_000.0,
                operatingProfit = 94_200_000.0,
                cashBalance = 165_500_000.0,
                headcount = 42
            ),
            CorporateEntity(
                id = "ENT-002",
                legalName = "Aethelgard Continental B.V.",
                tradingName = "Aethelgard Europe",
                entityType = EntityType.INTERMEDIATE_HOLDING,
                jurisdiction = "Netherlands",
                registrationNumber = "NL-KVK-3490182",
                incorporationDate = "2006-09-18",
                parentEntityId = "ENT-001",
                ownershipPercentage = 100.0,
                votingPercentage = 100.0,
                shareClasses = "Common Shares",
                ownershipEffectiveDate = "2006-09-18",
                verificationStatus = VerificationStatus.VERIFIED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "EUR",
                responsibleExecutive = "Dr. Evelyn Vance",
                businessDescription = "Intermediate continental European holding vehicle managing EU single-market subsidiaries and tax treaty compliance.",
                annualRevenue = 118_400_000.0,
                operatingProfit = 22_600_000.0,
                cashBalance = 34_200_000.0,
                headcount = 14
            ),
            CorporateEntity(
                id = "ENT-003",
                legalName = "Aethelgard Americas Inc.",
                tradingName = "Aethelgard Americas",
                entityType = EntityType.INTERMEDIATE_HOLDING,
                jurisdiction = "United States (Delaware)",
                registrationNumber = "DE-CORP-4820199",
                incorporationDate = "2010-02-14",
                parentEntityId = "ENT-001",
                ownershipPercentage = 100.0,
                votingPercentage = 100.0,
                shareClasses = "Series A Common",
                ownershipEffectiveDate = "2010-02-14",
                verificationStatus = VerificationStatus.VERIFIED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "USD",
                responsibleExecutive = "Julian Croft",
                businessDescription = "North American holding entity providing regional governance and capital distribution for US operating units.",
                annualRevenue = 194_800_000.0,
                operatingProfit = 44_100_000.0,
                cashBalance = 88_500_000.0,
                headcount = 18
            ),
            CorporateEntity(
                id = "ENT-004",
                legalName = "Nexus Robotics Ltd",
                tradingName = "Nexus Autonomous",
                entityType = EntityType.OPERATING_SUBSIDIARY,
                jurisdiction = "United Kingdom",
                registrationNumber = "UK-11294801",
                incorporationDate = "2016-05-20",
                parentEntityId = "ENT-001",
                ownershipPercentage = 82.5,
                votingPercentage = 85.0,
                shareClasses = "Ordinary Shares (82.5% Holdco, 17.5% Founders)",
                ownershipEffectiveDate = "2018-11-04",
                verificationStatus = VerificationStatus.VERIFIED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "GBP",
                responsibleExecutive = "Marcus Chen (MD)",
                businessDescription = "Industrial autonomous mobile robots, automated warehouse fulfillment systems, and heavy logistics cobots.",
                annualRevenue = 92_600_000.0,
                operatingProfit = 18_400_000.0,
                cashBalance = 19_800_000.0,
                headcount = 210
            ),
            CorporateEntity(
                id = "ENT-005",
                legalName = "Helios CleanGrid GmbH",
                tradingName = "Helios Power",
                entityType = EntityType.OPERATING_SUBSIDIARY,
                jurisdiction = "Germany",
                registrationNumber = "DE-HRB-89102",
                incorporationDate = "2017-08-30",
                parentEntityId = "ENT-002",
                ownershipPercentage = 74.0,
                votingPercentage = 74.0,
                shareClasses = "Geschäftsanteile (74% Continental BV, 26% Municipal Consortium)",
                ownershipEffectiveDate = "2019-03-15",
                verificationStatus = VerificationStatus.VERIFIED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "EUR",
                responsibleExecutive = "Klara Lindner (CEO)",
                businessDescription = "Utility-scale battery energy storage systems (BESS), smart virtual power plant algorithms, and microgrid infrastructure.",
                annualRevenue = 64_300_000.0,
                operatingProfit = 11_800_000.0,
                cashBalance = 14_500_000.0,
                headcount = 145
            ),
            CorporateEntity(
                id = "ENT-006",
                legalName = "Vanguard Therapeutics Corp",
                tradingName = "Vanguard Bio",
                entityType = EntityType.OPERATING_SUBSIDIARY,
                jurisdiction = "United States (Massachusetts)",
                registrationNumber = "MA-CORP-992104",
                incorporationDate = "2019-11-12",
                parentEntityId = "ENT-003",
                ownershipPercentage = 68.0,
                votingPercentage = 70.0,
                shareClasses = "Series B Preferred (Holdco 68%, Academic Founders 32%)",
                ownershipEffectiveDate = "2021-06-25",
                verificationStatus = VerificationStatus.VERIFIED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "USD",
                responsibleExecutive = "Dr. Aris Thorne",
                businessDescription = "Precision synthetic oncology and messenger RNA therapeutics pipeline with two Phase-II clinical assets.",
                annualRevenue = 28_400_000.0,
                operatingProfit = -6_200_000.0, // High R&D investment phase
                cashBalance = 24_100_000.0,
                headcount = 88
            ),
            CorporateEntity(
                id = "ENT-007",
                legalName = "Aethelgard Sovereign Estates Ltd",
                tradingName = "Sovereign Logistics Estates",
                entityType = EntityType.OPERATING_SUBSIDIARY,
                jurisdiction = "United Kingdom",
                registrationNumber = "UK-04910291",
                incorporationDate = "2008-03-10",
                parentEntityId = "ENT-001",
                ownershipPercentage = 100.0,
                votingPercentage = 100.0,
                shareClasses = "Ordinary Freehold Shares",
                ownershipEffectiveDate = "2008-03-10",
                verificationStatus = VerificationStatus.VERIFIED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "GBP",
                responsibleExecutive = "Geoffrey Palmer",
                businessDescription = "Freehold commercial logistics real estate, data center land holdings, and long-term infrastructure leases.",
                annualRevenue = 54_800_000.0,
                operatingProfit = 31_200_000.0,
                cashBalance = 16_400_000.0,
                headcount = 28
            ),
            CorporateEntity(
                id = "ENT-008",
                legalName = "Hyperion Quantum JV S.A.",
                tradingName = "Hyperion Quantum",
                entityType = EntityType.JOINT_VENTURE,
                jurisdiction = "Switzerland (Zurich)",
                registrationNumber = "CH-020.3.048.112",
                incorporationDate = "2022-01-19",
                parentEntityId = "ENT-001",
                ownershipPercentage = 49.0,
                votingPercentage = 50.0,
                shareClasses = "Equal Joint Venture Participation Shares",
                ownershipEffectiveDate = "2022-01-19",
                verificationStatus = VerificationStatus.VERIFIED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "CHF",
                responsibleExecutive = "Beat Meier (Co-Chair)",
                businessDescription = "Joint venture with Swiss Federal Institute for cryo-cooled quantum magnetometers and navigation sensors.",
                annualRevenue = 14_200_000.0,
                operatingProfit = 1_800_000.0,
                cashBalance = 8_900_000.0,
                headcount = 34
            ),
            CorporateEntity(
                id = "ENT-009",
                legalName = "Nordic PowerCell AB",
                tradingName = "Nordic Cell",
                entityType = EntityType.ASSOCIATE,
                jurisdiction = "Sweden",
                registrationNumber = "SE-556812-4019",
                incorporationDate = "2018-04-09",
                parentEntityId = "ENT-002",
                ownershipPercentage = 35.0,
                votingPercentage = 35.0,
                shareClasses = "Class B Shares (Minority Interest)",
                ownershipEffectiveDate = "2020-07-12",
                verificationStatus = VerificationStatus.USER_DECLARED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "EUR",
                responsibleExecutive = "Astrid Lindgren (Board Observer)",
                businessDescription = "Advanced sodium-ion cell manufacturing plant supplying European commercial fleet electrification.",
                annualRevenue = 38_100_000.0,
                operatingProfit = 3_400_000.0,
                cashBalance = 7_200_000.0,
                headcount = 62
            ),
            CorporateEntity(
                id = "ENT-010",
                legalName = "Aethelgard Alpha Ventures SPV",
                tradingName = "Alpha Ventures",
                entityType = EntityType.INVESTMENT_VEHICLE,
                jurisdiction = "Cayman Islands",
                registrationNumber = "CY-SPV-9014",
                incorporationDate = "2021-05-11",
                parentEntityId = "ENT-001",
                ownershipPercentage = 100.0,
                votingPercentage = 100.0,
                shareClasses = "Participating Redeemable Shares",
                ownershipEffectiveDate = "2021-05-11",
                verificationStatus = VerificationStatus.VERIFIED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "USD",
                responsibleExecutive = "Julian Croft",
                businessDescription = "Special purpose investment fund holding strategic minority stakes in deep-tech seed and growth assets.",
                annualRevenue = 8_200_000.0,
                operatingProfit = 7_500_000.0,
                cashBalance = 22_000_000.0,
                headcount = 4
            ),
            CorporateEntity(
                id = "ENT-011",
                legalName = "Project Orion Green Hydrogen SPV",
                tradingName = "Project Orion",
                entityType = EntityType.SPECIAL_PURPOSE_ENTITY,
                jurisdiction = "Germany",
                registrationNumber = "DE-SPV-4410",
                incorporationDate = "2023-02-01",
                parentEntityId = "ENT-005",
                ownershipPercentage = 80.0,
                votingPercentage = 80.0,
                shareClasses = "Project Equity Shares",
                ownershipEffectiveDate = "2023-02-01",
                verificationStatus = VerificationStatus.PROPOSED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "EUR",
                responsibleExecutive = "Klara Lindner",
                businessDescription = "Dedicated project financing vehicle for 100MW green hydrogen electrolyser plant in North Rhine-Westphalia.",
                annualRevenue = 2_100_000.0,
                operatingProfit = -800_000.0,
                cashBalance = 6_500_000.0,
                headcount = 12
            ),
            CorporateEntity(
                id = "ENT-012",
                legalName = "Aethelgard Intellectual Assets LLC",
                tradingName = "Aethelgard IP Fortress",
                entityType = EntityType.IP_HOLDING_ENTITY,
                jurisdiction = "Ireland (Dublin)",
                registrationNumber = "IE-CRO-712894",
                incorporationDate = "2015-06-30",
                parentEntityId = "ENT-001",
                ownershipPercentage = 100.0,
                votingPercentage = 100.0,
                shareClasses = "Proprietary IP Ordinary",
                ownershipEffectiveDate = "2015-06-30",
                verificationStatus = VerificationStatus.VERIFIED,
                legalStatus = LegalOperatingStatus.ACTIVE,
                reportingCurrency = "EUR",
                responsibleExecutive = "Sean O'Callaghan",
                businessDescription = "Group central IP repository holding 142 patents, global trademarks, and exclusive algorithms licensed across subsidiaries.",
                annualRevenue = 24_600_000.0,
                operatingProfit = 21_900_000.0,
                cashBalance = 15_100_000.0,
                headcount = 8
            )
        )
        _entities.value = entitiesList

        // Seed Decisions
        _decisions.value = listOf(
            ExecutiveDecision(
                id = "DEC-2026-001",
                title = "Helios CleanGrid Phase III Battery Expansion",
                category = DecisionCategory.CAPEX,
                originatingEntityId = "ENT-005",
                decisionOwner = "Klara Lindner & CFO Julian Croft",
                proposalSummary = "Commitment of $45,000,000 for 250MWh automated cell pack integration facility in Saxony.",
                businessRationale = "Secures 4.2x capacity multiplier to meet contracted utility delivery backlogs with E.ON and RWE.",
                supportingEvidence = "Board memo BM-2026-44, independent technical assessment by Fichtner Engineering.",
                alternativesConsidered = "Subcontracting manufacturing to third-party OEM in Poland (rejected due to IP loss risk).",
                expectedBenefits = "Consolidated revenue increase of +$38M/yr from 2028 with EBITDA margin of 28%.",
                estimatedCost = 45_000_000.0,
                currency = "EUR",
                risksAndDependencies = "Supply chain delivery delays on liquid-cooled thermal modules.",
                requiredApprovers = listOf("Board of Directors", "Group CEO", "Chief Financial Officer"),
                effectiveDate = "2026-11-01",
                reviewDate = "2027-05-01",
                status = DecisionStatus.APPROVED,
                approvedBy = "Lord Alistair Sterling (Group Owner)",
                approvalTimestamp = "2026-10-10 14:22:00",
                outcomeNotes = "Authorized in full. Tranche A release scheduled for Q4 2026."
            ),
            ExecutiveDecision(
                id = "DEC-2026-002",
                title = "Strategic Acquisition of CyberShield Autonomous Systems",
                category = DecisionCategory.ACQUISITION,
                originatingEntityId = "ENT-001",
                decisionOwner = "Dr. Evelyn Vance (Group CEO)",
                proposalSummary = "Acquire 100% of share capital of CyberShield Ltd for $18,500,000 cash consideration + earn-out.",
                businessRationale = "Proprietary obstacle avoidance and encrypted drone swarming patents directly integrate into Nexus Robotics.",
                supportingEvidence = "KPMG Quality of Earnings report, Baker McKenzie Legal Due Diligence.",
                alternativesConsidered = "In-house development over 36 months estimated at $24M with execution risk.",
                expectedBenefits = "Immediate gross profit accretion and defensible industrial robotics moat.",
                estimatedCost = 18_500_000.0,
                currency = "USD",
                risksAndDependencies = "Key personnel retention post-closing.",
                requiredApprovers = listOf("Investment Committee", "Group Owner"),
                effectiveDate = "2026-12-01",
                reviewDate = "2027-03-01",
                status = DecisionStatus.UNDER_REVIEW
            ),
            ExecutiveDecision(
                id = "DEC-2026-003",
                title = "2027 Group Capital Expenditure Envelope Approval",
                category = DecisionCategory.BUDGET_APPROVAL,
                originatingEntityId = "ENT-001",
                decisionOwner = "Julian Croft (CFO)",
                proposalSummary = "Approve group-wide baseline capital expenditure of $120,000,000 across all 4 operating divisions.",
                businessRationale = "Formal annual capital budgeting policy pursuant to Governance Charter Art. 14.",
                supportingEvidence = "Subsidiary 3-year bottom-up capital requirements dossiers.",
                alternativesConsidered = "Discretionary ad-hoc request approvals (rejected: causes liquidity volatility).",
                expectedBenefits = "Rigorous capital rationing and clear hurdle rate enforcement (minimum 15% ROIC).",
                estimatedCost = 120_000_000.0,
                currency = "USD",
                risksAndDependencies = "Macro interest rate fluctuations affecting external facility drawdowns.",
                requiredApprovers = listOf("Full Board of Directors"),
                effectiveDate = "2027-01-01",
                reviewDate = "2027-06-30",
                status = DecisionStatus.SUBMITTED
            )
        )

        // Seed Directives
        _directives.value = listOf(
            Directive(
                id = "DIR-2026-088",
                originatingAuthority = "Group Executive Committee",
                targetEntityId = "ENT-004", // Nexus Robotics
                title = "Submit 3-Year Capex & IP Commercialisation Roadmap",
                instruction = "Formulate and present a comprehensive 3-year capital expenditure forecast, robotics manufacturing throughput model, and detailed IP licensing schedule to the Group Investment Committee.",
                rationale = "Required ahead of Q4 board capital allocation hearings.",
                priority = DirectivePriority.URGENT,
                deadline = "2026-10-25",
                effectiveDate = "2026-10-01",
                responsiblePerson = "Marcus Chen (Managing Director)",
                budgetAuthorisation = 150_000.0,
                currency = "GBP",
                deliverables = "Detailed financial model, technical specification dossier, signed executive summary.",
                successCriteria = "IRR exceeding 20% hurdle rate; complete engineering risk breakdown.",
                dependencies = "Finalization of Q3 automated cell test results.",
                riskClassification = "High Strategic Significance",
                status = DirectiveStatus.IN_PROGRESS,
                acknowledgementTimestamp = "2026-10-02 09:14:00",
                executionUpdates = listOf("Draft v1.2 submitted to CFO on 2026-10-12 for preliminary audit review.")
            ),
            Directive(
                id = "DIR-2026-089",
                originatingAuthority = "Group Audit & Compliance Committee",
                targetEntityId = "ENT-006", // Vanguard Therapeutics
                title = "Reconcile Intercompany IP Licence Royalties with Dublin IP Entity",
                instruction = "Resolve $1.8M discrepancy in quarterly royalty remittance payable to Aethelgard Intellectual Assets LLC under agreement IE-IP-2022-04.",
                rationale = "Unreconciled transfer-pricing discrepancies create audit scrutiny and tax exposure under OECD rules.",
                priority = DirectivePriority.HIGH,
                deadline = "2026-10-18",
                effectiveDate = "2026-09-20",
                responsiblePerson = "Dr. Aris Thorne & VP Finance",
                budgetAuthorisation = 50_000.0,
                currency = "USD",
                deliverables = "Reconciliation statement, signed transfer pricing schedules, tax counsel sign-off.",
                successCriteria = "Zero variance across ENT-006 and ENT-012 general ledgers.",
                dependencies = "Audit confirmation of US gross sales deduction baseline.",
                riskClassification = "Regulatory & Tax Scrutiny",
                status = DirectiveStatus.OVERDUE,
                isOverdue = true,
                executionUpdates = listOf("Alert raised by Group Controller: 3 days overdue. Escalation to Group CFO initiated.")
            ),
            Directive(
                id = "DIR-2026-090",
                originatingAuthority = "Chief Executive Officer",
                targetEntityId = "ENT-005", // Helios CleanGrid
                title = "Complete ISO-27001 & TUV Safety Recertification for Smart Inverters",
                instruction = "Engage accredited audit body to complete full cybersecurity compliance audit on IoT power grid gateways.",
                rationale = "Mandatory for German Federal Network Agency (BNetzA) critical infrastructure certification.",
                priority = DirectivePriority.MEDIUM,
                deadline = "2026-11-30",
                effectiveDate = "2026-09-15",
                responsiblePerson = "Klara Lindner",
                budgetAuthorisation = 85_000.0,
                currency = "EUR",
                deliverables = "ISO-27001 certificate of compliance, TUV Rheinland safety report.",
                successCriteria = "Zero critical or high CVE vulnerabilities.",
                dependencies = "Firmware v4.8 rollout to testing rig.",
                riskClassification = "Operational & Regulatory",
                status = DirectiveStatus.ACKNOWLEDGED,
                acknowledgementTimestamp = "2026-09-16 11:30:00"
            )
        )

        // Seed Funding Requests
        _fundingRequests.value = listOf(
            FundingRequest(
                id = "REQ-2026-012",
                requestingEntityId = "ENT-004", // Nexus
                recipientEntityId = "ENT-004",
                projectOrInvestment = "Cobot Line Alpha Automation",
                requestedAmount = 12_500_000.0,
                currency = "USD",
                instrument = FundingInstrument.CAPEX_GRANT,
                purpose = "High-precision 6-axis collaborative robotic assembly line to expand annual unit deliveries from 400 to 1,800 units.",
                businessCase = "Operating margins increase from 19.8% to 27.2% by reducing manual precision calibration cycle from 18 hours to 42 minutes.",
                cashFlowForecastSummary = "Positive EBITDA generation starting Month 11; free cash flow payback within 26 months.",
                appraisal = FinancialAppraisal(
                    netPresentValue = 18_420_000.0,
                    internalRateOfReturn = 24.5,
                    paybackMonths = 26,
                    roicPercentage = 22.8,
                    discountRate = 9.5,
                    downsideScenarioLoss = 1_800_000.0
                ),
                proposedRepaymentTerms = "Subordinated intercompany dividend stream of 15% net profits over 5 years.",
                status = FundingStatus.COMMITTEE_REVIEW
            ),
            FundingRequest(
                id = "REQ-2026-013",
                requestingEntityId = "ENT-005", // Helios
                recipientEntityId = "ENT-005",
                projectOrInvestment = "Grid Inverter Substation Expansion",
                requestedAmount = 8_200_000.0,
                currency = "EUR",
                instrument = FundingInstrument.INTERCOMPANY_LOAN,
                purpose = "Procurement of specialized high-voltage switchgear and transformers for 80MW storage connection.",
                businessCase = "Unlocks contracted grid connection agreement with TenneT TSO.",
                cashFlowForecastSummary = "Tariff revenue starts Q1 2027 at €2.1M quarterly.",
                appraisal = FinancialAppraisal(
                    netPresentValue = 11_350_000.0,
                    internalRateOfReturn = 19.8,
                    paybackMonths = 34,
                    roicPercentage = 18.2,
                    discountRate = 8.5,
                    downsideScenarioLoss = 950_000.0
                ),
                proposedRepaymentTerms = "Intercompany loan at EURIBOR + 2.25%, 7-year amortization.",
                status = FundingStatus.APPROVED,
                approvedAmount = 8_200_000.0,
                committeeResolution = "Approved unanimously by Investment Committee on 2026-10-08."
            ),
            FundingRequest(
                id = "REQ-2026-014",
                requestingEntityId = "ENT-006", // Vanguard Bio
                recipientEntityId = "ENT-006",
                projectOrInvestment = "Phase II Synthetic mRNA Oncology Cohort",
                requestedAmount = 5_000_000.0,
                currency = "USD",
                instrument = FundingInstrument.RESEARCH_BUDGET,
                purpose = "Patient enrollment and clinical biomarker sequencing for VG-401 target antigen trial.",
                businessCase = "Target readout expected Q3 2027; sets up out-licensing partnership with global pharma estimated at $120M upfront.",
                cashFlowForecastSummary = "Pure strategic R&D allocation; returns gated upon commercial licence milestone.",
                appraisal = FinancialAppraisal(
                    netPresentValue = 32_000_000.0,
                    internalRateOfReturn = 38.0,
                    paybackMonths = 48,
                    roicPercentage = 31.0,
                    discountRate = 14.0,
                    downsideScenarioLoss = 5_000_000.0
                ),
                proposedRepaymentTerms = "Holdco equity percentage increase from 68% to 71.5%.",
                status = FundingStatus.SUBMITTED
            )
        )

        // Seed Commitments
        _capitalCommitments.value = listOf(
            CapitalCommitment(
                id = "COMM-001",
                fundingRequestId = "REQ-2026-013",
                committedAmount = 8_200_000.0,
                currency = "EUR",
                sourceEntityId = "ENT-001",
                targetEntityId = "ENT-005",
                committedDate = "2026-10-08 16:30:00",
                isDisbursed = false
            )
        )

        // Seed Treasury Accounts
        _treasuryAccounts.value = listOf(
            TreasuryAccount(
                id = "ACCT-001",
                institutionName = "Barclays Corporate Banking London",
                accountNumberMasked = "•••• 4892",
                entityId = "ENT-001",
                accountType = AccountType.OPERATING_CHECKING,
                currency = "GBP",
                balance = 42_800_000.0,
                restrictedBalance = 5_000_000.0, // Minimum bond debt service covenant
                yieldApy = 4.75,
                verification = BalanceVerification.LIVE_PROVIDER,
                lastRefreshed = "2026-10-15 06:40:00"
            ),
            TreasuryAccount(
                id = "ACCT-002",
                institutionName = "JPMorgan Chase Institutional NY",
                accountNumberMasked = "•••• 9104",
                entityId = "ENT-001",
                accountType = AccountType.LIQUIDITY_SWEEP,
                currency = "USD",
                balance = 88_500_000.0,
                restrictedBalance = 0.0,
                yieldApy = 5.15,
                verification = BalanceVerification.LIVE_PROVIDER,
                lastRefreshed = "2026-10-15 06:40:00"
            ),
            TreasuryAccount(
                id = "ACCT-003",
                institutionName = "Deutsche Bank AG Frankfurt",
                accountNumberMasked = "•••• 3321",
                entityId = "ENT-002",
                accountType = AccountType.OPERATING_CHECKING,
                currency = "EUR",
                balance = 34_200_000.0,
                restrictedBalance = 2_000_000.0,
                yieldApy = 3.65,
                verification = BalanceVerification.LIVE_PROVIDER,
                lastRefreshed = "2026-10-15 06:38:00"
            ),
            TreasuryAccount(
                id = "ACCT-004",
                institutionName = "UBS AG Wealth Management Zurich",
                accountNumberMasked = "•••• 7740",
                entityId = "ENT-001",
                accountType = AccountType.RESTRICTED_ESCROW,
                currency = "CHF",
                balance = 12_000_000.0,
                restrictedBalance = 12_000_000.0, // Fully pledged for Hyperion Quantum JV warranties
                yieldApy = 1.85,
                verification = BalanceVerification.IMPORTED_STATEMENT,
                lastRefreshed = "2026-10-14 18:00:00"
            )
        )

        // Seed Payments
        _payments.value = listOf(
            PaymentInstruction(
                id = "PMT-0091",
                sourceAccountId = "ACCT-002",
                targetEntityId = "ENT-004",
                recipientIbanOrAccount = "GB82BARC20201599887766",
                amount = 2_500_000.0,
                currency = "USD",
                paymentPurpose = "Tranche 1 R&D Grant for Nexus Cobots",
                referenceCode = "REF-NEX-01",
                status = PaymentStatus.SETTLED,
                idempotencyKey = "IDEMP-8849201",
                initiatedBy = "Julian Croft (CFO)",
                authorizedBy = "Lord Alistair Sterling",
                timestamp = "2026-10-12 11:00:00",
                executionLog = "Clearing completed via Fedwire. FedRef: 20261012-00482910."
            )
        )

        // Seed Journal Entries (Double-Entry Bookkeeping)
        _journalEntries.value = listOf(
            JournalEntry(
                id = "JE-001",
                entryNumber = "JE-2026-101",
                postingDate = "2026-10-01",
                entityId = "ENT-001",
                description = "Quarterly Central Management Service Charges to Subsidiaries",
                lines = listOf(
                    JournalLine("1200-REC-INTERCO", "Intercompany Receivables (Nexus/Helios/Vanguard)", AccountClass.ASSET, 4_500_000.0, 0.0, "Management fees charged"),
                    JournalLine("4100-REV-FEES", "Holding Company Management Fee Revenue", AccountClass.REVENUE, 0.0, 4_500_000.0, "Intercompany shared corporate governance")
                ),
                isPosted = true
            ),
            JournalEntry(
                id = "JE-002",
                entryNumber = "JE-2026-102",
                postingDate = "2026-10-05",
                entityId = "ENT-001",
                description = "Group Corporate Bond Coupon Payment",
                lines = listOf(
                    JournalLine("5200-EXP-INTEREST", "Bond Debt Interest Expense", AccountClass.EXPENSE, 1_850_000.0, 0.0, "Semi-annual 4.25% Notes 2031"),
                    JournalLine("1000-CASH-BARC", "Cash at Barclays Corporate", AccountClass.ASSET, 0.0, 1_850_000.0, "Disbursed via clearing trustee")
                ),
                isPosted = true
            )
        )

        // Seed Intercompany Transactions
        _intercompanyTransactions.value = listOf(
            IntercompanyTransaction(
                id = "ICT-001",
                date = "2026-10-01",
                originatingEntityId = "ENT-001",
                counterpartyEntityId = "ENT-004",
                transactionType = IntercompanyType.MANAGEMENT_SERVICE_FEE,
                amount = 1_800_000.0,
                currency = "GBP",
                originatingLedgerReference = "JE-2026-101-L1",
                counterpartyLedgerReference = "NEX-AP-8911",
                isReconciled = true,
                eliminationRequired = true
            ),
            IntercompanyTransaction(
                id = "ICT-002",
                date = "2026-09-30",
                originatingEntityId = "ENT-012", // Dublin IP
                counterpartyEntityId = "ENT-006", // Vanguard
                transactionType = IntercompanyType.ROYALTY_IP_LICENCE,
                amount = 1_800_000.0,
                currency = "USD",
                originatingLedgerReference = "IE-IP-REV-404",
                counterpartyLedgerReference = null, // Discrepancy!
                isReconciled = false,
                eliminationRequired = true,
                discrepancyNotes = "Counterparty voucher unconfirmed by Vanguard US accounts payable."
            ),
            IntercompanyTransaction(
                id = "ICT-003",
                date = "2026-08-15",
                originatingEntityId = "ENT-001",
                counterpartyEntityId = "ENT-005",
                transactionType = IntercompanyType.INTERCOMPANY_LOAN,
                amount = 10_000_000.0,
                currency = "EUR",
                originatingLedgerReference = "HOLDCO-LOAN-HL-01",
                counterpartyLedgerReference = "HELIOS-LT-DEBT-01",
                isReconciled = true,
                eliminationRequired = true
            )
        )

        // Seed Projects
        _projects.value = listOf(
            ProjectItem(
                id = "PRJ-01",
                title = "Titan 600 Heavy-Payload Autonomous Cobot",
                sponsorEntityId = "ENT-004",
                projectLead = "Dr. Henrik Blomqvist",
                strategicObjective = "Deliver high-capacity automated heavy material transport for automotive factories.",
                stage = StageGate.EXECUTION,
                budgetTotal = 8_500_000.0,
                actualExpenditure = 6_200_000.0,
                currency = "GBP",
                progressPercentage = 75,
                targetCompletionDate = "2027-02-28"
            ),
            ProjectItem(
                id = "PRJ-02",
                title = "Project Zephyr Solid-State Battery Lab",
                sponsorEntityId = "ENT-005",
                projectLead = "Prof. Ilse Neumann",
                strategicObjective = "Develop 450 Wh/kg solid electrolyte cells without cobalt dependencies.",
                stage = StageGate.VALIDATION,
                budgetTotal = 14_000_000.0,
                actualExpenditure = 11_400_000.0,
                currency = "EUR",
                progressPercentage = 82,
                targetCompletionDate = "2026-12-15"
            ),
            ProjectItem(
                id = "PRJ-03",
                title = "Synthetic Oncology Antigen VG-401 Trial",
                sponsorEntityId = "ENT-006",
                projectLead = "Dr. Aris Thorne",
                strategicObjective = "Complete Phase-II multi-center solid tumor trial with 90-patient cohort.",
                stage = StageGate.EXECUTION,
                budgetTotal = 18_000_000.0,
                actualExpenditure = 19_200_000.0, // Overrun
                currency = "USD",
                progressPercentage = 60,
                targetCompletionDate = "2027-08-30"
            )
        )

        // Seed Risks
        _risks.value = listOf(
            RiskItem(
                id = "RSK-001",
                title = "Critical Rare-Earth Magnet Supply Chain Bottleneck",
                category = RiskCategory.OPERATIONAL,
                affectedEntityId = "ENT-004",
                likelihood = 4,
                impact = 5,
                controlsSummary = "Strategic 9-month inventory buffer stocked in Rotterdam bonded warehouse; secondary sourcing certified in Australia.",
                residualScore = 8,
                severity = RiskSeverity.HIGH,
                owner = "Marcus Chen",
                status = "Active Mitigation"
            ),
            RiskItem(
                id = "RSK-002",
                title = "EU Grid Connection Regulatory Approval Delay",
                category = RiskCategory.LEGAL_REGULATORY,
                affectedEntityId = "ENT-005",
                likelihood = 3,
                impact = 4,
                controlsSummary = "Engagement of specialized energy regulatory legal counsel in Berlin; pre-consultation completed with TenneT.",
                residualScore = 6,
                severity = RiskSeverity.MEDIUM,
                owner = "Klara Lindner",
                status = "Monitored"
            ),
            RiskItem(
                id = "RSK-003",
                title = "Intercompany Transfer Pricing Audit Scrutiny",
                category = RiskCategory.FINANCIAL_LIQUIDITY,
                affectedEntityId = "ENT-012",
                likelihood = 4,
                impact = 4,
                controlsSummary = "Comprehensive OECD Base Erosion and Profit Shifting (BEPS) economic benchmarking report by Deloitte.",
                residualScore = 6,
                severity = RiskSeverity.HIGH,
                owner = "Julian Croft (CFO)",
                status = "Escalated to Group Board"
            )
        )

        // Seed Compliance
        _compliance.value = listOf(
            ComplianceObligation(
                id = "CMP-01",
                entityId = "ENT-001",
                regulatoryBody = "UK Companies House & Financial Conduct Authority",
                obligationTitle = "Annual Consolidated Group Accounts & Director Report Filing",
                jurisdiction = "United Kingdom",
                dueDate = "2026-12-31",
                isMandatoryFiling = true,
                status = "In Preparation by Auditors (PwC)"
            ),
            ComplianceObligation(
                id = "CMP-02",
                entityId = "ENT-002",
                regulatoryBody = "Dutch Tax & Customs Administration (Belastingdienst)",
                obligationTitle = "Corporate Income Tax Return & Controlled Foreign Corp Declaration",
                jurisdiction = "Netherlands",
                dueDate = "2026-11-30",
                isMandatoryFiling = true,
                status = "Compliant / Submitted"
            ),
            ComplianceObligation(
                id = "CMP-03",
                entityId = "ENT-006",
                regulatoryBody = "US Food and Drug Administration (FDA)",
                obligationTitle = "Annual Investigational New Drug (IND) Safety Update",
                jurisdiction = "United States",
                dueDate = "2026-10-31",
                isMandatoryFiling = true,
                status = "Pending Sign-off (Due in 16 days)"
            )
        )

        // Seed Contracts
        _contracts.value = listOf(
            ContractItem(
                id = "CTR-001",
                title = "Master Robotics OEM Supply Agreement",
                contractType = "Commercial Supply",
                entityId = "ENT-004",
                counterparty = "BMW Group AG",
                effectiveDate = "2023-01-01",
                expiryDate = "2026-12-31",
                renewalAlertDays = 77,
                annualValue = 34_500_000.0,
                currency = "EUR",
                keyObligations = "Deliver 250 units/yr with 99.6% uptime SLA and 4-hour field response.",
                status = "Active - Renewal Window Open",
                isExpiringSoon = true
            ),
            ContractItem(
                id = "CTR-002",
                title = "Syndicated Revolving Credit Facility ($250M)",
                contractType = "Financing Facility",
                entityId = "ENT-001",
                counterparty = "Consortium led by HSBC & Barclays",
                effectiveDate = "2024-06-15",
                expiryDate = "2029-06-15",
                renewalAlertDays = 970,
                annualValue = 5_800_000.0,
                currency = "USD",
                keyObligations = "Net Debt / EBITDA covenant <= 3.25x; minimum unencumbered liquidity $30M.",
                status = "Active / Fully Compliant",
                isExpiringSoon = false
            ),
            ContractItem(
                id = "CTR-003",
                title = "Exclusive Global IP Master Licence IE-IP-2022-04",
                contractType = "IP Licence",
                entityId = "ENT-012",
                counterparty = "Vanguard Therapeutics Corp",
                effectiveDate = "2022-01-01",
                expiryDate = "2032-12-31",
                renewalAlertDays = 2260,
                annualValue = 1_800_000.0,
                currency = "USD",
                keyObligations = "6% quarterly gross royalty remittance on commercial therapeutics exploitation.",
                status = "Dispute / Audit Pending",
                isExpiringSoon = false
            )
        )

        // Seed IP Assets
        _ipAssets.value = listOf(
            IPAssetItem(
                id = "IP-001",
                assetName = "Autonomous Swarm Trajectory Optimization Architecture",
                ipType = "Granted Patent (PCT / USPTO)",
                registeredOwnerEntityId = "ENT-012",
                registrationJurisdiction = "Worldwide (PCT/US1092841)",
                registrationNumber = "US-11,842,910-B2",
                commercialStatus = "Licensed exclusively to Nexus Robotics Ltd",
                annualRoyaltyRunRate = 3_200_000.0,
                expiryDate = "2041-08-14"
            ),
            IPAssetItem(
                id = "IP-002",
                assetName = "Quantum-Assisted Solid-State Electrolyte Formulation",
                ipType = "Patent Application",
                registeredOwnerEntityId = "ENT-012",
                registrationJurisdiction = "European Patent Office (EPO)",
                registrationNumber = "EP-24190812.3",
                commercialStatus = "Licensed to Helios CleanGrid GmbH",
                annualRoyaltyRunRate = 1_400_000.0,
                expiryDate = "2044-03-22"
            ),
            IPAssetItem(
                id = "IP-003",
                assetName = "Aethelgard™ Global Registered Sovereign Wordmark",
                ipType = "Registered Trademark",
                registeredOwnerEntityId = "ENT-001",
                registrationJurisdiction = "Madrid Protocol (WIPO)",
                registrationNumber = "WIPO-TM-1492019",
                commercialStatus = "Exploited across all group entities",
                annualRoyaltyRunRate = 0.0,
                expiryDate = "2034-11-30"
            )
        )

        // Seed Initial Audit Event
        _auditEvents.value = listOf(
            AuditEvent(
                id = "AUD-INIT-001",
                timestamp = getCurrentTimestamp(),
                userRole = "System Architect",
                userName = "HOLDCO OS Core Engine",
                actionType = "BOOTSTRAP",
                targetType = "HoldingSystem",
                targetId = "SYS-01",
                summary = "HOLDCO OS command terminal bootstrapped with 12 sovereign entities, consolidated balance sheet, and live treasury ledgers.",
                previousState = null,
                newState = "INSTITUTIONAL_ACTIVE",
                verificationHash = computeSha256("BOOTSTRAP-INITIAL-AETHELGARD")
            )
        )
    }
}
