package com.example.holdco.data.model

enum class DirectivePriority(val displayName: String) {
    URGENT("Urgent"),
    HIGH("High"),
    MEDIUM("Medium"),
    LOW("Low")
}

enum class DirectiveStatus(val displayName: String) {
    DRAFT("Draft"),
    APPROVED("Approved"),
    ISSUED("Issued"),
    ACKNOWLEDGED("Acknowledged"),
    IN_PROGRESS("In Progress"),
    SUBMITTED_FOR_REVIEW("Submitted for Review"),
    COMPLETED("Completed"),
    BLOCKED("Blocked"),
    SUSPENDED("Suspended"),
    REJECTED("Rejected"),
    CANCELLED("Cancelled"),
    OVERDUE("Overdue")
}

data class Directive(
    val id: String,
    val originatingAuthority: String,
    val targetEntityId: String,
    val title: String,
    val instruction: String,
    val rationale: String,
    val priority: DirectivePriority,
    val deadline: String,
    val effectiveDate: String,
    val responsiblePerson: String,
    val budgetAuthorisation: Double,
    val currency: String,
    val deliverables: String,
    val successCriteria: String,
    val dependencies: String,
    val riskClassification: String,
    val status: DirectiveStatus,
    val acknowledgementTimestamp: String? = null,
    val executionUpdates: List<String> = emptyList(),
    val completionEvidence: String? = null,
    val reviewOutcome: String? = null,
    val isOverdue: Boolean = false
)
