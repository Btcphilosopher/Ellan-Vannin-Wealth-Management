package com.example.holdco.data.model

enum class AccountType(val displayName: String) {
    OPERATING_CHECKING("Operating Commercial Account"),
    LIQUIDITY_SWEEP("Overnight Liquidity Sweep"),
    RESTRICTED_ESCROW("Restricted Escrow / Reserve"),
    TERM_DEPOSIT("Yield Term Deposit"),
    CREDIT_FACILITY("Revolving Credit Facility")
}

enum class BalanceVerification(val displayName: String) {
    LIVE_PROVIDER("Live Bank Feed (API)"),
    IMPORTED_STATEMENT("Imported MT940 / CAMT"),
    INTERNAL_LEDGER("Internal Ledger Derived"),
    SIMULATED_TEST("Simulated Sandbox Provider")
}

data class TreasuryAccount(
    val id: String,
    val institutionName: String,
    val accountNumberMasked: String,
    val entityId: String,
    val accountType: AccountType,
    val currency: String,
    val balance: Double,
    val restrictedBalance: Double,
    val availableLiquidity: Double = (balance - restrictedBalance).coerceAtLeast(0.0),
    val yieldApy: Double,
    val verification: BalanceVerification,
    val lastRefreshed: String
)

enum class PaymentStatus(val displayName: String) {
    DRAFT_PREVIEW("Payment Preview"),
    VALIDATED("Validated & Risk Passed"),
    FUNDS_CHECKED("Sufficient Funds Reserved"),
    PENDING_DUAL_AUTH("Pending Dual Authorization"),
    AUTHORISED("Authorized for Settlement"),
    EXECUTING("Executing with Provider"),
    SETTLED("Settled & Reconciled"),
    FAILED("Execution Failed / Rejected")
}

data class PaymentInstruction(
    val id: String,
    val sourceAccountId: String,
    val targetEntityId: String,
    val recipientIbanOrAccount: String,
    val amount: Double,
    val currency: String,
    val paymentPurpose: String,
    val referenceCode: String,
    val status: PaymentStatus,
    val idempotencyKey: String,
    val initiatedBy: String,
    val authorizedBy: String? = null,
    val timestamp: String,
    val executionLog: String? = null
)

data class CashFlowPeriodForecast(
    val periodLabel: String, // 30-Day, 90-Day, 12-Month
    val inflowsExpected: Double,
    val operatingOutflows: Double,
    val committedCapex: Double,
    val debtService: Double,
    val netCashPosition: Double,
    val stressScenarioDeficit: Double
)
