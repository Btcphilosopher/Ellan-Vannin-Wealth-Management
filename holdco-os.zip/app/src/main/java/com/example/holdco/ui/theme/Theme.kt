package com.example.holdco.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = SovereignGold,
    onPrimary = TerminalBackground,
    primaryContainer = SovereignGoldContainer,
    onPrimaryContainer = SovereignGoldText,
    secondary = TerminalCyan,
    onSecondary = TerminalBackground,
    secondaryContainer = TerminalCyanContainer,
    onSecondaryContainer = TerminalCyan,
    tertiary = TerminalEmerald,
    onTertiary = TerminalBackground,
    background = TerminalBackground,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = TerminalBorder,
    outlineVariant = TerminalBorderActive,
    error = TerminalAlertRed,
    onError = TextPrimary,
    errorContainer = TerminalAlertRedContainer,
    onErrorContainer = TerminalAlertRed
)

@Composable
fun HoldcoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = com.example.ui.theme.Typography,
        content = content
    )
}
