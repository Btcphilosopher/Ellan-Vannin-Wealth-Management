package com.example.holdco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.*
import com.example.holdco.ui.components.*
import com.example.holdco.ui.theme.*

@Composable
fun FinancialConsolidationScreen(
    journalEntries: List<JournalEntry>,
    intercompanyTransactions: List<IntercompanyTransaction>,
    entities: List<CorporateEntity>,
    reportingCurrency: String,
    onReconcileTransaction: (String) -> Unit
) {
    var selectedSection by remember { mutableStateOf(0) } // 0 = Consolidated Statements, 1 = Journal Entries, 2 = Intercompany Desk

    val grossRevenue = entities.sumOf { it.annualRevenue }
    val intercoRevenueElim = 24_600_000.0 // Management fees and internal royalties eliminated
    val consolidatedNetRevenue = grossRevenue - intercoRevenueElim
    val consolidatedEbitda = entities.sumOf { it.operatingProfit }
    val totalCash = entities.sumOf { it.cashBalance }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        // Section Switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(TerminalSurfaceElevated)
                .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                .padding(4.dp)
        ) {
            listOf("CONSOLIDATION", "JOURNAL ENTRIES", "INTERCOMPANY RECON").forEachIndexed { idx, title ->
                val isSelected = selectedSection == idx
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) SovereignGoldContainer else Color.Transparent)
                        .clickable { selectedSection = idx }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) SovereignGoldText else TextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (selectedSection) {
            0 -> {
                // CONSOLIDATED FINANCIAL STATEMENTS
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        TerminalCard(
                            title = "CONSOLIDATED GROUP INCOME STATEMENT (P&L)",
                            badgeText = "IFRS / GAAP Consolidated",
                            badgeColor = SovereignGold
                        ) {
                            KeyValueRow("Gross Combined Entity Revenue", formatCurrency(grossRevenue, reportingCurrency))
                            KeyValueRow("Less: Intercompany Eliminations", "-${formatCurrency(intercoRevenueElim, reportingCurrency)}", TerminalAlertRed)
                            KeyValueRow("Consolidated Net Revenue", formatCurrency(consolidatedNetRevenue, reportingCurrency), TerminalEmerald)
                            Spacer(modifier = Modifier.height(4.dp))
                            KeyValueRow("Combined Operating Expenses", "-${formatCurrency(consolidatedNetRevenue - consolidatedEbitda, reportingCurrency)}")
                            KeyValueRow("Consolidated Group EBITDA", formatCurrency(consolidatedEbitda, reportingCurrency), SovereignGoldText)
                            KeyValueRow("Net Financing Charges & Taxation", "-${formatCurrency(14_800_000.0, reportingCurrency)}")
                            KeyValueRow("Consolidated Net Profit After Tax", formatCurrency(consolidatedEbitda - 14_800_000.0, reportingCurrency), TerminalEmerald)
                        }
                    }

                    item {
                        TerminalCard(
                            title = "CONSOLIDATED BALANCE SHEET",
                            badgeText = "Balanced: Assets = L + E",
                            badgeColor = TerminalCyan
                        ) {
                            Text("ASSETS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SovereignGoldText, fontFamily = FontFamily.Monospace)
                            KeyValueRow("Cash & Institutional Treasury", formatCurrency(totalCash, reportingCurrency), SovereignGoldText)
                            KeyValueRow("Tangible Freehold & Industrial Plant", formatCurrency(840_000_000.0, reportingCurrency))
                            KeyValueRow("Intellectual Property Fortress & Goodwill", formatCurrency(320_000_000.0, reportingCurrency))
                            KeyValueRow("Total Consolidated Assets", formatCurrency(totalCash + 1_160_000_000.0, reportingCurrency), TerminalEmerald)

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("LIABILITIES & SHAREHOLDERS' EQUITY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SovereignGoldText, fontFamily = FontFamily.Monospace)
                            KeyValueRow("External Syndicated Facility & Debt Notes", formatCurrency(280_000_000.0, reportingCurrency))
                            KeyValueRow("Trade & Operational Payables", formatCurrency(68_400_000.0, reportingCurrency))
                            KeyValueRow("Total Group Shareholders' Equity", formatCurrency(totalCash + 1_160_000_000.0 - 348_400_000.0, reportingCurrency), TerminalEmerald)
                        }
                    }
                }
            }

            1 -> {
                // DOUBLE-ENTRY JOURNAL ENTRIES
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(journalEntries, key = { it.id }) { je ->
                        TerminalCard(
                            title = "${je.entryNumber} • ${je.postingDate}",
                            badgeText = if (je.isBalanced) "BALANCED" else "UNBALANCED",
                            badgeColor = if (je.isBalanced) TerminalEmerald else TerminalAlertRed,
                            modifier = Modifier.testTag("journal_entry_${je.id}")
                        ) {
                            Text(
                                text = je.description,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            // Debit / Credit lines table
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(TerminalSurfaceElevated)
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("ACCOUNT / MEMO", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                                        Text("DEBIT ($)", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                        Text("CREDIT ($)", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                    }
                                }

                                je.lines.forEach { line ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(line.accountName, fontSize = 11.sp, color = TextPrimary)
                                            Text(line.memo, fontSize = 9.sp, color = TextSecondary)
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                            Text(
                                                text = if (line.debitAmount > 0) formatCurrency(line.debitAmount) else "-",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (line.debitAmount > 0) TerminalEmerald else TextTertiary,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = if (line.creditAmount > 0) formatCurrency(line.creditAmount) else "-",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (line.creditAmount > 0) SovereignGoldText else TextTertiary,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total Debits: ${formatCurrency(je.totalDebits)}", fontSize = 10.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
                                Text("Total Credits: ${formatCurrency(je.totalCredits)}", fontSize = 10.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            2 -> {
                // INTERCOMPANY RECONCILIATION DESK
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            text = "INTERCOMPANY TRANSACTIONS & ELIMINATION AUDIT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGoldText,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    items(intercompanyTransactions, key = { it.id }) { tx ->
                        val orig = entities.find { it.id == tx.originatingEntityId }?.tradingName ?: tx.originatingEntityId
                        val counter = entities.find { it.id == tx.counterpartyEntityId }?.tradingName ?: tx.counterpartyEntityId

                        TerminalCard(
                            title = "$orig  ➔  $counter",
                            badgeText = if (tx.isReconciled) "RECONCILED" else "DISCREPANCY FLAGGED",
                            badgeColor = if (tx.isReconciled) TerminalEmerald else TerminalAlertRed,
                            modifier = Modifier.testTag("interco_tx_${tx.id}")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                StatusBadgePill(tx.transactionType.displayName, SovereignGold)
                                Text(
                                    text = formatCurrency(tx.amount, tx.currency),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SovereignGoldText,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            KeyValueRow("Orig Ledger Ref", tx.originatingLedgerReference)
                            KeyValueRow("Counter Ledger Ref", tx.counterpartyLedgerReference ?: "MISSING VOUCHER", if (tx.counterpartyLedgerReference == null) TerminalAlertRed else TextPrimary)

                            if (tx.discrepancyNotes != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(TerminalAlertRedContainer)
                                        .padding(6.dp)
                                ) {
                                    Text(
                                        text = "Variance Note: ${tx.discrepancyNotes}",
                                        fontSize = 10.sp,
                                        color = TerminalAlertRed
                                    )
                                }
                            }

                            if (!tx.isReconciled) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Button(
                                        onClick = { onReconcileTransaction(tx.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.testTag("reconcile_btn_${tx.id}")
                                    ) {
                                        Text("RESOLVE & RECONCILE", color = TerminalBackground, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
