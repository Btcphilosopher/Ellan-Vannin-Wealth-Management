package com.example.holdco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.*
import com.example.holdco.ui.components.*
import com.example.holdco.ui.theme.*

@Composable
fun DecisionsDirectivesScreen(
    decisions: List<ExecutiveDecision>,
    directives: List<Directive>,
    entities: List<CorporateEntity>,
    onApproveDecision: (String) -> Unit,
    onRejectDecision: (String, String) -> Unit,
    onSubmitDecision: (String) -> Unit,
    onAcknowledgeDirective: (String) -> Unit,
    onUpdateDirectiveStatus: (String, DirectiveStatus, String) -> Unit
) {
    var selectedSection by remember { mutableStateOf(0) } // 0 = Decisions, 1 = Directives
    var rejectDialogTargetId by remember { mutableStateOf<String?>(null) }
    var rejectReason by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        // Switcher Bar: Decisions vs Directives
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(TerminalSurfaceElevated)
                .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (selectedSection == 0) SovereignGoldContainer else Color.Transparent)
                    .clickable { selectedSection = 0 }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "EXECUTIVE DECISIONS (${decisions.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedSection == 0) SovereignGoldText else TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (selectedSection == 1) SovereignGoldContainer else Color.Transparent)
                    .clickable { selectedSection = 1 }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "SUBSIDIARY DIRECTIVES (${directives.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedSection == 1) SovereignGoldText else TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (selectedSection == 0) {
            // DECISIONS LIST
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(decisions, key = { it.id }) { dec ->
                    val statusColor = when (dec.status) {
                        DecisionStatus.APPROVED -> TerminalEmerald
                        DecisionStatus.UNDER_REVIEW -> SovereignGold
                        DecisionStatus.SUBMITTED -> TerminalCyan
                        DecisionStatus.REJECTED -> TerminalAlertRed
                        else -> TextSecondary
                    }

                    TerminalCard(
                        title = dec.title,
                        badgeText = dec.status.displayName,
                        badgeColor = statusColor,
                        modifier = Modifier.testTag("decision_card_${dec.id}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatusBadgePill(dec.category.displayName, SovereignGold)
                            Text(
                                text = "Estimated: ${formatCurrency(dec.estimatedCost, dec.currency)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignGoldText,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = dec.proposalSummary,
                            fontSize = 12.sp,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Rationale: ${dec.businessRationale}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        KeyValueRow("Decision Owner", dec.decisionOwner)
                        KeyValueRow("Required Signatories", dec.requiredApprovers.joinToString(", "))
                        if (dec.approvedBy != null) {
                            KeyValueRow("Approved Signatory", dec.approvedBy, TerminalEmerald)
                        }

                        // Action Controls
                        if (dec.status == DecisionStatus.UNDER_REVIEW || dec.status == DecisionStatus.SUBMITTED) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { rejectDialogTargetId = dec.id },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TerminalAlertRed),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.testTag("reject_btn_${dec.id}")
                                ) {
                                    Text("REJECT", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { onApproveDecision(dec.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.testTag("approve_decision_btn_${dec.id}")
                                ) {
                                    Text("APPROVE DECISION", color = TerminalBackground, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        } else if (dec.status == DecisionStatus.DRAFT) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { onSubmitDecision(dec.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = TerminalCyan),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("SUBMIT FOR BOARD REVIEW", color = TerminalBackground, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            // DIRECTIVES LIST
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(directives, key = { it.id }) { dir ->
                    val targetEntity = entities.find { it.id == dir.targetEntityId }
                    val priorityColor = when (dir.priority) {
                        DirectivePriority.URGENT -> TerminalAlertRed
                        DirectivePriority.HIGH -> TerminalWarningAmber
                        DirectivePriority.MEDIUM -> TerminalCyan
                        DirectivePriority.LOW -> TextSecondary
                    }

                    TerminalCard(
                        title = dir.title,
                        badgeText = if (dir.isOverdue) "OVERDUE" else dir.status.displayName,
                        badgeColor = if (dir.isOverdue) TerminalAlertRed else TerminalEmerald,
                        modifier = Modifier.testTag("directive_card_${dir.id}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "TO: ${targetEntity?.tradingName ?: dir.targetEntityId}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignGoldText,
                                fontFamily = FontFamily.Monospace
                            )
                            StatusBadgePill("PRIORITY: ${dir.priority.displayName}", priorityColor)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = dir.instruction,
                            fontSize = 12.sp,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        KeyValueRow("Mandated Deadline", dir.deadline, if (dir.isOverdue) TerminalAlertRed else TextPrimary)
                        KeyValueRow("Responsible Lead", dir.responsiblePerson)
                        KeyValueRow("Authorized Expense Envelope", formatCurrency(dir.budgetAuthorisation, dir.currency))
                        KeyValueRow("Expected Deliverables", dir.deliverables)

                        // Action Controls
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            if (dir.status == DirectiveStatus.ISSUED || dir.status == DirectiveStatus.OVERDUE) {
                                Button(
                                    onClick = { onAcknowledgeDirective(dir.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.testTag("ack_directive_${dir.id}")
                                ) {
                                    Text("ACKNOWLEDGE RECEIPT", color = TerminalBackground, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            } else if (dir.status == DirectiveStatus.ACKNOWLEDGED || dir.status == DirectiveStatus.IN_PROGRESS) {
                                Button(
                                    onClick = { onUpdateDirectiveStatus(dir.id, DirectiveStatus.COMPLETED, "Completed verified deliverables") },
                                    colors = ButtonDefaults.buttonColors(containerColor = TerminalEmerald),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.testTag("complete_directive_${dir.id}")
                                ) {
                                    Text("MARK COMPLETED", color = TerminalBackground, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Reject Dialog
    if (rejectDialogTargetId != null) {
        AlertDialog(
            onDismissRequest = { rejectDialogTargetId = null },
            title = { Text("REJECT EXECUTIVE DECISION", color = TerminalAlertRed, fontFamily = FontFamily.Monospace) },
            text = {
                Column {
                    Text("Provide corporate rationale for rejecting proposal:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectReason,
                        onValueChange = { rejectReason = it },
                        label = { Text("Rationale / Legal grounds") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRejectDecision(rejectDialogTargetId!!, rejectReason.ifBlank { "Rejected by executive directive" })
                        rejectDialogTargetId = null
                        rejectReason = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalAlertRed)
                ) {
                    Text("CONFIRM REJECTION")
                }
            },
            dismissButton = {
                TextButton(onClick = { rejectDialogTargetId = null }) { Text("CANCEL") }
            },
            containerColor = TerminalSurfaceElevated
        )
    }
}
