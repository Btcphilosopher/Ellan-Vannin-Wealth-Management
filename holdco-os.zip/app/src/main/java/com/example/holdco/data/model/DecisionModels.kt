package com.example.holdco.data.model

enum class DecisionCategory(val displayName: String) {
    CAPEX("Capital Expenditure"),
    INVESTMENT("Investment"),
    ACQUISITION("Acquisition / M&A"),
    DIVESTMENT("Divestment"),
    FINANCING("Debt & Financing"),
    BUDGET_APPROVAL("Annual Budget Approval"),
    APPOINTMENT("Executive Appointment"),
    STRATEGIC_PLANNING("Strategic Plan"),
    PRODUCT_DEVELOPMENT("Product R&D"),
    CONTRACT_APPROVAL("Contract Approval"),
    RESTRUCTURING("Group Restructuring"),
    RISK_RESPONSE("Risk Response"),
    OPERATIONAL_CHANGE("Operational Change")
}

enum class DecisionStatus(val displayName: String) {
    DRAFT("Draft"),
    SUBMITTED("Submitted"),
    UNDER_REVIEW("Under Review"),
    APPROVED("Approved"),
    REJECTED("Rejected"),
    IMPLEMENTED("Implemented"),
    REVIEWED("Reviewed"),
    DEFERRED("Deferred"),
    WITHDRAWN("Withdrawn"),
    SUPERSEDED("Superseded"),
    CANCELLED("Cancelled")
}

data class ExecutiveDecision(
    val id: String,
    val title: String,
    val category: DecisionCategory,
    val originatingEntityId: String,
    val decisionOwner: String,
    val proposalSummary: String,
    val businessRationale: String,
    val supportingEvidence: String,
    val alternativesConsidered: String,
    val expectedBenefits: String,
    val estimatedCost: Double,
    val currency: String,
    val risksAndDependencies: String,
    val requiredApprovers: List<String>,
    val effectiveDate: String,
    val reviewDate: String,
    val status: DecisionStatus,
    val outcomeNotes: String? = null,
    val relatedDirectiveId: String? = null,
    val revisionHistory: List<String> = emptyList(),
    val approvedBy: String? = null,
    val approvalTimestamp: String? = null
)
