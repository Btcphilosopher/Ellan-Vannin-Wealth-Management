package com.example.holdco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.*
import com.example.holdco.ui.components.*
import com.example.holdco.ui.theme.*
import com.example.holdco.ui.viewmodel.ExecutiveKpiSummary
import com.example.holdco.ui.viewmodel.HoldcoTab

@Composable
fun CommandCentreScreen(
    kpi: ExecutiveKpiSummary,
    reportingCurrency: String,
    decisions: List<ExecutiveDecision>,
    directives: List<Directive>,
    fundingRequests: List<FundingRequest>,
    treasuryAccounts: List<TreasuryAccount>,
    risks: List<RiskItem>,
    auditEvents: List<AuditEvent>,
    onNavigateTab: (HoldcoTab) -> Unit,
    onApproveDecision: (String) -> Unit,
    onAcknowledgeDirective: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Section: Top High-Density Metric Grid
        item {
            Text(
                text = "EXECUTIVE TELEMETRY OVERVIEW",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = SovereignGoldText
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KpiMetricTile(
                        label = "Group Net Asset Value",
                        value = formatCurrency(kpi.groupNavEstimate, reportingCurrency),
                        subtitle = "12 Sovereign Entities",
                        accentColor = SovereignGold,
                        tag = "kpi_nav",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateTab(HoldcoTab.CORPORATE_STRUCTURE) }
                    )
                    KpiMetricTile(
                        label = "Recorded Liquidity",
                        value = formatCurrency(kpi.totalRecordedLiquidity, reportingCurrency),
                        subtitle = "Unencumbered: ${formatCurrency(kpi.unallocatedCapital, reportingCurrency)}",
                        accentColor = TerminalEmerald,
                        tag = "kpi_liquidity",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateTab(HoldcoTab.TREASURY_LIQUIDITY) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KpiMetricTile(
                        label = "Committed Capital",
                        value = formatCurrency(kpi.approvedCommitmentsTotal, reportingCurrency),
                        subtitle = "${kpi.pendingFundingRequestsCount} proposals pending",
                        accentColor = TerminalCyan,
                        tag = "kpi_commitments",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateTab(HoldcoTab.CAPITAL_ALLOCATION) }
                    )
                    KpiMetricTile(
                        label = "Overdue Directives",
                        value = "${kpi.overdueDirectivesCount} ALERTS",
                        subtitle = "High material risk: ${kpi.highRiskItemsCount}",
                        accentColor = if (kpi.overdueDirectivesCount > 0) TerminalAlertRed else TerminalEmerald,
                        tag = "kpi_overdue",
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateTab(HoldcoTab.DECISIONS_DIRECTIVES) }
                    )
                }
            }
        }

        // Section: Critical Action Centre (Approvals awaiting attention)
        item {
            TerminalCard(
                title = "CRITICAL ACTION CENTER",
                badgeText = "Requires Sign-off",
                badgeColor = TerminalAlertRed
            ) {
                val pendingDecisions = decisions.filter { it.status == DecisionStatus.UNDER_REVIEW || it.status == DecisionStatus.SUBMITTED }
                val overdueDirectives = directives.filter { it.isOverdue || it.status == DirectiveStatus.OVERDUE }

                if (pendingDecisions.isEmpty() && overdueDirectives.isEmpty()) {
                    Text(
                        text = "All executive actions, directives, and capital approvals are up to date.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        pendingDecisions.take(2).forEach { dec ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(TerminalSurfaceElevated)
                                    .border(1.dp, SovereignGold.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        StatusBadgePill(dec.category.displayName, SovereignGold)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = dec.id,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = TextTertiary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = dec.title,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "Cost: ${formatCurrency(dec.estimatedCost, dec.currency)} • Owner: ${dec.decisionOwner}",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }

                                Button(
                                    onClick = { onApproveDecision(dec.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                                    shape = RoundedCornerShape(4.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("approve_btn_${dec.id}")
                                ) {
                                    Text(
                                        text = "APPROVE",
                                        color = TerminalBackground,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }

                        overdueDirectives.forEach { dir ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(TerminalAlertRedContainer)
                                    .border(1.dp, TerminalAlertRed.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        StatusBadgePill("OVERDUE DIRECTIVE", TerminalAlertRed)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Target: ${dir.targetEntityId}",
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = TextTertiary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = dir.title,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "Deadline: ${dir.deadline} • Lead: ${dir.responsiblePerson}",
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }

                                OutlinedButton(
                                    onClick = { onAcknowledgeDirective(dir.id) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TerminalAlertRed),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalAlertRed)),
                                    shape = RoundedCornerShape(4.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("ack_btn_${dir.id}")
                                ) {
                                    Text(
                                        text = "ACKNOWLEDGE",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section: Treasury Balances Snapshot
        item {
            TerminalCard(
                title = "TREASURY & INSTITUTIONAL ACCOUNTS",
                badgeText = "Live Data Feeds",
                badgeColor = TerminalEmerald,
                onClick = { onNavigateTab(HoldcoTab.TREASURY_LIQUIDITY) }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    treasuryAccounts.forEach { acct ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = acct.institutionName,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${acct.accountType.displayName} • ${acct.accountNumberMasked}",
                                    fontSize = 10.sp,
                                    color = TextTertiary
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = formatCurrency(acct.balance, acct.currency),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SovereignGoldText,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Yield: ${acct.yieldApy}% APY",
                                    fontSize = 10.sp,
                                    color = TerminalEmerald
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: High Material Risks Watchlist
        item {
            TerminalCard(
                title = "MATERIAL RISK WATCHLIST",
                badgeText = "${risks.count { it.severity == RiskSeverity.HIGH }} High Risks",
                badgeColor = TerminalWarningAmber,
                onClick = { onNavigateTab(HoldcoTab.RISK_LEGAL_IP) }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    risks.take(2).forEach { rsk ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceElevated)
                                .padding(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = rsk.title,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                StatusBadgePill(rsk.severity.displayName, if (rsk.severity == RiskSeverity.HIGH) TerminalAlertRed else TerminalWarningAmber)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Mitigation: ${rsk.controlsSummary}",
                                fontSize = 10.sp,
                                color = TextSecondary,
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }

        // Section: Cryptographic Audit Stream
        item {
            TerminalCard(
                title = "SYSTEM AUDIT STREAM (IMMUTABLE)",
                badgeText = "SHA-256 Verified",
                badgeColor = TerminalCyan,
                onClick = { onNavigateTab(HoldcoTab.AUDIT_GOVERNANCE) }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    auditEvents.take(3).forEach { evt ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = evt.timestamp.takeLast(8),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalCyan,
                                modifier = Modifier.width(60.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = evt.summary,
                                    fontSize = 11.sp,
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                                Text(
                                    text = "By ${evt.userName} [${evt.actionType}] • Hash: ${evt.verificationHash}",
                                    fontSize = 9.sp,
                                    color = TextTertiary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
