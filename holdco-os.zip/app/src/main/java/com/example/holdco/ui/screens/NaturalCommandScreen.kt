package com.example.holdco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.nlp.CommandResult
import com.example.holdco.ui.components.*
import com.example.holdco.ui.theme.*

@Composable
fun NaturalCommandScreen(
    activeResult: CommandResult?,
    onSubmitCommand: (String) -> Unit,
    onExecuteAction: () -> Unit
) {
    var queryInput by remember { mutableStateOf("") }

    val promptSuggestions = listOf(
        "Show all subsidiaries with their ownership percentages",
        "Which funding requests require approval?",
        "Compare the cash positions of all subsidiaries",
        "Show overdue executive directives",
        "Identify unallocated capital",
        "List contracts expiring in the next 90 days",
        "Show projects that exceed their budgets",
        "Reconcile intercompany ledger",
        "Show high risks"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Terminal Header
        TerminalCard(
            title = "EXECUTIVE NATURAL-LANGUAGE COMMAND TERMINAL",
            badgeText = "Kernel Active",
            badgeColor = TerminalCyan
        ) {
            Text(
                text = "Issue plain-English executive queries, evaluate cross-subsidiary financials, inspect overdue instructions, and execute governance actions directly through natural language.",
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        // Quick Command Pills
        val scrollState = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            promptSuggestions.forEach { prompt ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalSurfaceElevated)
                        .border(1.dp, SovereignGold.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                        .clickable {
                            queryInput = prompt
                            onSubmitCommand(prompt)
                        }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = prompt,
                        fontSize = 10.sp,
                        color = SovereignGoldText,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Command Prompt Input
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = queryInput,
                onValueChange = { queryInput = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("terminal_command_input"),
                placeholder = {
                    Text(
                        text = "Enter executive query (e.g. 'Show overdue executive directives')",
                        fontSize = 11.sp,
                        color = TextTertiary
                    )
                },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Terminal, contentDescription = "Terminal", tint = SovereignGold)
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = TerminalSurfaceElevated,
                    unfocusedContainerColor = TerminalSurfaceElevated,
                    focusedBorderColor = SovereignGold,
                    unfocusedBorderColor = TerminalBorder
                ),
                shape = RoundedCornerShape(6.dp)
            )

            Button(
                onClick = {
                    if (queryInput.isNotBlank()) {
                        onSubmitCommand(queryInput)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.testTag("submit_terminal_command_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Run",
                    tint = TerminalBackground,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Output Result Card
        if (activeResult != null) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    TerminalCard(
                        title = "INTENT: ${activeResult.intent}",
                        badgeText = activeResult.statusBadge,
                        badgeColor = if (activeResult.statusBadge.contains("ALERT") || activeResult.statusBadge.contains("CRITICAL")) TerminalAlertRed else TerminalEmerald,
                        modifier = Modifier.testTag("command_result_card")
                    ) {
                        Text(
                            text = activeResult.summary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceElevated)
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            activeResult.details.forEach { detail ->
                                Text(
                                    text = detail,
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        // Actionable Execution Button if requested
                        if (activeResult.requiresConfirmation && activeResult.executableAction != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = onExecuteAction,
                                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("confirm_terminal_action_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Execute",
                                    tint = TerminalBackground
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "CONFIRM & EXECUTE GOVERNANCE ACTION",
                                    color = TerminalBackground,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Awaiting command",
                        tint = SovereignGold.copy(alpha = 0.4f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "HOLDCO OS NATURAL COMMAND PROMPT READY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextTertiary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Select a prompt suggestion above or enter a custom executive query.",
                        fontSize = 10.sp,
                        color = TextTertiary
                    )
                }
            }
        }
    }
}
