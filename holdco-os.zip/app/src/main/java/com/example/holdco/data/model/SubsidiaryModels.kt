package com.example.holdco.data.model

enum class StageGate(val displayName: String) {
    IDEA("Stage 1: Idea"),
    DISCOVERY("Stage 2: Discovery"),
    FEASIBILITY("Stage 3: Feasibility"),
    APPROVAL("Stage 4: Executive Approval"),
    EXECUTION("Stage 5: Execution / Engineering"),
    VALIDATION("Stage 6: Validation & Audit"),
    DEPLOYMENT("Stage 7: Commercial Deployment"),
    CLOSURE("Stage 8: Value Realization / Close")
}

data class ProjectItem(
    val id: String,
    val title: String,
    val sponsorEntityId: String,
    val projectLead: String,
    val strategicObjective: String,
    val stage: StageGate,
    val budgetTotal: Double,
    val actualExpenditure: Double,
    val currency: String,
    val progressPercentage: Int,
    val targetCompletionDate: String,
    val isBudgetOverrun: Boolean = actualExpenditure > budgetTotal
)

enum class RiskSeverity(val displayName: String, val level: Int) {
    LOW("Low", 1),
    MEDIUM("Medium", 2),
    HIGH("High", 3),
    CRITICAL("Critical", 4)
}

enum class RiskCategory(val displayName: String) {
    FINANCIAL_LIQUIDITY("Financial & Liquidity"),
    OPERATIONAL("Operational & Supply"),
    CYBER_TECH("Cybersecurity & Tech"),
    LEGAL_REGULATORY("Legal & Regulatory"),
    CONTRACTUAL("Contractual & Third-Party"),
    STRATEGIC("Strategic & Market"),
    GEOPOLITICAL("Geopolitical & Trade")
}

data class RiskItem(
    val id: String,
    val title: String,
    val category: RiskCategory,
    val affectedEntityId: String,
    val likelihood: Int, // 1 to 5
    val impact: Int,     // 1 to 5
    val inherentScore: Int = likelihood * impact,
    val controlsSummary: String,
    val residualScore: Int,
    val severity: RiskSeverity,
    val owner: String,
    val status: String
)

data class ComplianceObligation(
    val id: String,
    val entityId: String,
    val regulatoryBody: String,
    val obligationTitle: String,
    val jurisdiction: String,
    val dueDate: String,
    val isMandatoryFiling: Boolean,
    val status: String // Compliant, Pending Submission, Overdue, Under Examination
)

data class ContractItem(
    val id: String,
    val title: String,
    val contractType: String,
    val entityId: String,
    val counterparty: String,
    val effectiveDate: String,
    val expiryDate: String,
    val renewalAlertDays: Int,
    val annualValue: Double,
    val currency: String,
    val keyObligations: String,
    val status: String,
    val isExpiringSoon: Boolean // < 90 days
)

data class IPAssetItem(
    val id: String,
    val assetName: String,
    val ipType: String, // Patent, Trademark, Proprietary Codebase, AI Algorithm, Domain
    val registeredOwnerEntityId: String,
    val registrationJurisdiction: String,
    val registrationNumber: String,
    val commercialStatus: String, // Exploited In-House, Licensed to Subsidiary, Monetized
    val annualRoyaltyRunRate: Double,
    val expiryDate: String
)

data class SubsidiaryScorecard(
    val entityId: String,
    val revenueRunRate: Double,
    val revenueBudget: Double,
    val operatingMarginPct: Double,
    val cashRunwayMonths: Double,
    val openDirectivesCount: Int,
    val openRisksCount: Int,
    val flagLateReports: Boolean,
    val flagBudgetOverrun: Boolean,
    val flagMissedMilestones: Boolean,
    val flagIntercompanyDiscrepancy: Boolean
)
