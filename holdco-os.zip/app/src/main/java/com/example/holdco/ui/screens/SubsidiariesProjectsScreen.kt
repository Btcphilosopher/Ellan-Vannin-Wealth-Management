package com.example.holdco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.*
import com.example.holdco.ui.components.*
import com.example.holdco.ui.theme.*

@Composable
fun SubsidiariesProjectsScreen(
    entities: List<CorporateEntity>,
    projects: List<ProjectItem>,
    reportingCurrency: String,
    onEntitySelected: (CorporateEntity) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Subsidiaries, 1 = Projects

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(TerminalSurfaceElevated)
                .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (selectedTab == 0) SovereignGoldContainer else Color.Transparent)
                    .clickable { selectedTab = 0 }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "OPERATING SUBSIDIARIES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedTab == 0) SovereignGoldText else TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (selectedTab == 1) SovereignGoldContainer else Color.Transparent)
                    .clickable { selectedTab = 1 }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "STRATEGIC PROGRAMMES (${projects.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedTab == 1) SovereignGoldText else TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (selectedTab == 0) {
            // SUBSIDIARY SCORECARDS
            val operatingSubs = entities.filter { it.parentEntityId != null }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(operatingSubs, key = { it.id }) { sub ->
                    val margin = if (sub.annualRevenue > 0) (sub.operatingProfit / sub.annualRevenue) * 100.0 else 0.0
                    val isLossMaking = sub.operatingProfit < 0

                    TerminalCard(
                        title = sub.tradingName,
                        badgeText = "${sub.ownershipPercentage}% OWNED",
                        badgeColor = if (sub.ownershipPercentage >= 100.0) TerminalEmerald else SovereignGold,
                        onClick = { onEntitySelected(sub) },
                        modifier = Modifier.testTag("sub_scorecard_${sub.id}")
                    ) {
                        Text(
                            text = "${sub.legalName} • ${sub.jurisdiction}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceElevated)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("REVENUE", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                Text(formatCurrency(sub.annualRevenue, sub.reportingCurrency), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary, fontFamily = FontFamily.Monospace)
                            }
                            Column {
                                Text("OPERATING PROFIT", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                Text(formatCurrency(sub.operatingProfit, sub.reportingCurrency), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isLossMaking) TerminalAlertRed else TerminalEmerald, fontFamily = FontFamily.Monospace)
                            }
                            Column {
                                Text("EBITDA MARGIN", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                Text("${String.format("%.1f", margin)}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (margin >= 15.0) TerminalEmerald else SovereignGold, fontFamily = FontFamily.Monospace)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("CASH", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                Text(formatCurrency(sub.cashBalance, sub.reportingCurrency), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SovereignGoldText, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        KeyValueRow("Managing Director", sub.responsibleExecutive)
                        KeyValueRow("Workforce", "${sub.headcount} FTE Employees")

                        // Health Flags
                        if (isLossMaking) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(TerminalAlertRedContainer)
                                    .padding(6.dp)
                            ) {
                                Text(
                                    text = "⚠ OPERATIONAL LOSS NOTICE: High R&D clinical burn rate currently funded via Holdco equity.",
                                    fontSize = 10.sp,
                                    color = TerminalAlertRed
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // STRATEGIC PROJECTS
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(projects, key = { it.id }) { prj ->
                    val sponsor = entities.find { it.id == prj.sponsorEntityId }

                    TerminalCard(
                        title = prj.title,
                        badgeText = prj.stage.displayName,
                        badgeColor = if (prj.isBudgetOverrun) TerminalAlertRed else TerminalCyan,
                        modifier = Modifier.testTag("project_item_${prj.id}")
                    ) {
                        Text(
                            text = "Sponsor: ${sponsor?.tradingName ?: prj.sponsorEntityId} • Lead: ${prj.projectLead}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = prj.strategicObjective,
                            fontSize = 12.sp,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Progress Bar
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("MILESTONE COMPLETION", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                Text("${prj.progressPercentage}%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SovereignGoldText, fontFamily = FontFamily.Monospace)
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            LinearProgressIndicator(
                                progress = { prj.progressPercentage / 100f },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                color = if (prj.isBudgetOverrun) TerminalAlertRed else SovereignGold,
                                trackColor = TerminalSurfaceElevated
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        KeyValueRow("Budget Allocation", formatCurrency(prj.budgetTotal, prj.currency))
                        KeyValueRow(
                            "Actual Incurred Spend",
                            formatCurrency(prj.actualExpenditure, prj.currency),
                            if (prj.isBudgetOverrun) TerminalAlertRed else TerminalEmerald
                        )
                        KeyValueRow("Target Delivery Date", prj.targetCompletionDate)

                        if (prj.isBudgetOverrun) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "⚠ BUDGET OVERRUN: Incurred expenditure exceeds authorized budget ceiling.",
                                fontSize = 10.sp,
                                color = TerminalAlertRed,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}
