package com.example.holdco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.AuditEvent
import com.example.holdco.data.model.UserRole
import com.example.holdco.ui.components.*
import com.example.holdco.ui.theme.*

@Composable
fun AuditAdminScreen(
    auditEvents: List<AuditEvent>,
    onExportCsv: () -> Unit,
    onResetData: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Audit Trail, 1 = Governance & Permissions

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        // Actions Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AUDIT TRAIL & CORPORATE GOVERNANCE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    color = SovereignGoldText
                )
                Text(
                    text = "Cryptographically Verifiable Ledger • Non-Repudiation",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onExportCsv,
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("export_audit_csv_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Export CSV",
                        tint = TerminalBackground,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "EXPORT CSV",
                        color = TerminalBackground,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                OutlinedButton(
                    onClick = onResetData,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                    shape = RoundedCornerShape(4.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("reset_sandbox_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset Data",
                        tint = TextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "RESET DATA",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Tab Switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(TerminalSurfaceElevated)
                .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                .padding(4.dp)
        ) {
            listOf("IMMUTABLE AUDIT TRAIL (${auditEvents.size})", "GOVERNANCE & PERMISSIONS").forEachIndexed { idx, label ->
                val isSelected = selectedTab == idx
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) SovereignGoldContainer else androidx.compose.ui.graphics.Color.Transparent)
                        .clickable { selectedTab = idx }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) SovereignGoldText else TextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (selectedTab == 0) {
            // AUDIT TRAIL LOG
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(auditEvents, key = { it.id }) { evt ->
                    TerminalCard(
                        title = "${evt.id} • ${evt.timestamp}",
                        badgeText = evt.actionType,
                        badgeColor = when (evt.actionType) {
                            "DECISION_APPROVE", "CAPITAL_COMMIT", "TREASURY_DISBURSEMENT" -> SovereignGold
                            "ROLE_SWITCH" -> TerminalCyan
                            "INTERCO_RECON" -> TerminalEmerald
                            else -> TextSecondary
                        },
                        modifier = Modifier.testTag("audit_event_${evt.id}")
                    ) {
                        Text(
                            text = evt.summary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        KeyValueRow("Actor / Authority", "${evt.userName} (${evt.userRole})")
                        KeyValueRow("Target Resource", "${evt.targetType} [${evt.targetId}]")
                        if (evt.previousState != null && evt.newState != null) {
                            KeyValueRow("State Transition", "${evt.previousState}  ➔  ${evt.newState}", SovereignGoldText)
                        }
                        KeyValueRow("SHA-256 Seal", evt.verificationHash, TerminalCyan)
                    }
                }
            }
        } else {
            // GOVERNANCE & ROLES MATRIX
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    TerminalCard(title = "GOVERNANCE CHARTER & DUAL-CONTROL POLICIES") {
                        Text(
                            text = "• Article 14: Capital commitments exceeding $1,000,000 require Board sign-off.\n• Article 19: All treasury payments undergo automated unencumbered liquidity and duplicate checks.\n• Article 22: Subsidiary directives must be acknowledged within 72 hours of issue.\n• Article 28: Zero-trust intercompany transfer pricing reconciliation mandatory under OECD guidelines.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                items(UserRole.values()) { role ->
                    TerminalCard(
                        title = role.roleTitle,
                        badgeText = role.level,
                        badgeColor = SovereignGold
                    ) {
                        val permissions = when (role) {
                            UserRole.GROUP_OWNER -> "Full Sovereign Governance • Directives Issue • Final Board Approvals • Unlimited Capital Authorisation"
                            UserRole.GROUP_CEO -> "Group Strategy • Operational Command • Directives Issue • Approvals up to $50M"
                            UserRole.CHIEF_FINANCIAL_OFFICER -> "Treasury Allocations • Commitments Sign-off • Consolidations • Payments up to $25M"
                            UserRole.HEAD_OF_TREASURY -> "Liquidity Management • Bank Clearing • Payment Instructions Preview & Initiation"
                            UserRole.SUBSIDIARY_EXECUTIVE -> "Operating Entity Administration • Directives Acknowledgement • Funding Request Submissions"
                            UserRole.GROUP_AUDITOR -> "Read-Only Inspection • Forensic Ledger Auditing • Risk Matrix Certification"
                        }
                        Text(text = "Privileges: $permissions", fontSize = 11.sp, color = TextPrimary)
                    }
                }
            }
        }
    }
}
