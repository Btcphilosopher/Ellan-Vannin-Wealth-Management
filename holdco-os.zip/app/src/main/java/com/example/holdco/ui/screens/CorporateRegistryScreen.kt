package com.example.holdco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.*
import com.example.holdco.ui.components.*
import com.example.holdco.ui.theme.*

@Composable
fun CorporateRegistryScreen(
    entities: List<CorporateEntity>,
    reportingCurrency: String,
    searchQuery: String,
    onEntitySelected: (CorporateEntity) -> Unit,
    onAddNewEntity: (
        legalName: String,
        tradingName: String,
        entityType: EntityType,
        jurisdiction: String,
        registrationNumber: String,
        parentEntityId: String?,
        ownershipPct: Double,
        currency: String,
        executive: String,
        description: String,
        cash: Double,
        revenue: Double
    ) -> Unit
) {
    var selectedFilter by remember { mutableStateOf<EntityType?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val filteredEntities = entities.filter { entity ->
        val matchesFilter = selectedFilter == null || entity.entityType == selectedFilter
        val matchesSearch = searchQuery.isBlank() ||
                entity.legalName.contains(searchQuery, ignoreCase = true) ||
                entity.tradingName.contains(searchQuery, ignoreCase = true) ||
                entity.jurisdiction.contains(searchQuery, ignoreCase = true) ||
                entity.responsibleExecutive.contains(searchQuery, ignoreCase = true)
        matchesFilter && matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        // Header & Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CORPORATE REGISTRY & OWNERSHIP GRAPH",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    color = SovereignGoldText
                )
                Text(
                    text = "${entities.size} Registered Legal Entities across 6 Jurisdictions",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                shape = RoundedCornerShape(4.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.testTag("register_entity_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Entity",
                    tint = TerminalBackground,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "REGISTER ENTITY",
                    color = TerminalBackground,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Pills
        val scrollState = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (selectedFilter == null) SovereignGoldContainer else TerminalSurfaceElevated)
                    .border(1.dp, if (selectedFilter == null) SovereignGold else TerminalBorder, RoundedCornerShape(4.dp))
                    .clickable { selectedFilter = null }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "ALL CLASSIFICATIONS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedFilter == null) SovereignGoldText else TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            }

            EntityType.values().take(6).forEach { type ->
                val isSelected = selectedFilter == type
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) SovereignGoldContainer else TerminalSurfaceElevated)
                        .border(1.dp, if (isSelected) SovereignGold else TerminalBorder, RoundedCornerShape(4.dp))
                        .clickable { selectedFilter = type }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = type.displayName.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) SovereignGoldText else TextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Entity Cards List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredEntities, key = { it.id }) { entity ->
                val parent = entities.find { it.id == entity.parentEntityId }

                TerminalCard(
                    title = entity.tradingName,
                    badgeText = "${entity.ownershipPercentage}% OWNED",
                    badgeColor = if (entity.ownershipPercentage >= 100.0) TerminalEmerald else if (entity.ownershipPercentage >= 50.0) SovereignGold else TerminalCyan,
                    onClick = { onEntitySelected(entity) },
                    modifier = Modifier.testTag("entity_card_${entity.id}")
                ) {
                    Text(
                        text = entity.legalName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${entity.entityType.displayName} • ${entity.jurisdiction}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "PARENT ENTITY",
                                fontSize = 9.sp,
                                color = TextTertiary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = parent?.tradingName ?: "Ultimate Parent (None)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "VERIFICATION",
                                fontSize = 9.sp,
                                color = TextTertiary,
                                fontFamily = FontFamily.Monospace
                            )
                            StatusBadgePill(
                                text = entity.verificationStatus.displayName,
                                color = if (entity.verificationStatus == VerificationStatus.VERIFIED) TerminalEmerald else TerminalWarningAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(TerminalSurfaceElevated)
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Revenue: ${formatCurrency(entity.annualRevenue, entity.reportingCurrency)}",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Cash: ${formatCurrency(entity.cashBalance, entity.reportingCurrency)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGoldText,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Team: ${entity.headcount}",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }

    // Modal: Register New Entity
    if (showAddDialog) {
        var legalName by remember { mutableStateOf("") }
        var tradingName by remember { mutableStateOf("") }
        var entityType by remember { mutableStateOf(EntityType.OPERATING_SUBSIDIARY) }
        var jurisdiction by remember { mutableStateOf("United Kingdom") }
        var regNumber by remember { mutableStateOf("") }
        var selectedParentId by remember { mutableStateOf("ENT-001") }
        var ownershipPctText by remember { mutableStateOf("100.0") }
        var executiveName by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var initialCashText by remember { mutableStateOf("5000000") }
        var initialRevenueText by remember { mutableStateOf("12000000") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = {
                Text(
                    text = "REGISTER NEW CORPORATE ENTITY",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SovereignGold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = legalName,
                        onValueChange = { legalName = it },
                        label = { Text("Legal Entity Name") },
                        modifier = Modifier.fillMaxWidth().testTag("new_entity_legal_name"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = tradingName,
                        onValueChange = { tradingName = it },
                        label = { Text("Trading / Brand Name") },
                        modifier = Modifier.fillMaxWidth().testTag("new_entity_trading_name"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = jurisdiction,
                        onValueChange = { jurisdiction = it },
                        label = { Text("Jurisdiction") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = ownershipPctText,
                            onValueChange = { ownershipPctText = it },
                            label = { Text("Ownership %") },
                            modifier = Modifier.weight(1f).testTag("new_entity_ownership_pct"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = initialCashText,
                            onValueChange = { initialCashText = it },
                            label = { Text("Initial Cash ($)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    OutlinedTextField(
                        value = executiveName,
                        onValueChange = { executiveName = it },
                        label = { Text("Responsible Executive") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = desc,
                        onValueChange = { desc = it },
                        label = { Text("Business Purpose & Scope") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pct = ownershipPctText.toDoubleOrNull() ?: 100.0
                        val cash = initialCashText.toDoubleOrNull() ?: 0.0
                        val rev = initialRevenueText.toDoubleOrNull() ?: 0.0
                        if (legalName.isNotBlank() && tradingName.isNotBlank()) {
                            onAddNewEntity(
                                legalName,
                                tradingName,
                                entityType,
                                jurisdiction,
                                regNumber,
                                selectedParentId,
                                pct,
                                "USD",
                                executiveName.ifBlank { "Unassigned" },
                                desc.ifBlank { "Corporate entity under Aethelgard Holdings PLC" },
                                cash,
                                rev
                            )
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SovereignGold),
                    modifier = Modifier.testTag("submit_new_entity_btn")
                ) {
                    Text("REGISTER", color = TerminalBackground, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("CANCEL", color = TextSecondary)
                }
            },
            containerColor = TerminalSurfaceElevated
        )
    }
}
