package com.example.holdco.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.ActiveExecutive
import com.example.holdco.data.model.UserRole
import com.example.holdco.ui.theme.*
import com.example.holdco.ui.viewmodel.HoldcoTab

@Composable
fun TerminalTopBar(
    activeExecutive: ActiveExecutive,
    reportingCurrency: String,
    currentTab: HoldcoTab,
    globalSearch: String,
    onTabSelected: (HoldcoTab) -> Unit,
    onCurrencySelected: (String) -> Unit,
    onRoleSelected: (UserRole) -> Unit,
    onSearchChanged: (String) -> Unit,
    onOpenTerminal: () -> Unit
) {
    var showRoleMenu by remember { mutableStateOf(false) }
    var showCurrencyMenu by remember { mutableStateOf(false) }
    var showSearchExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(width = 1.dp, color = TerminalBorder)
    ) {
        // Upper telemetry row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Crest & Company Brand
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(SovereignGoldContainer)
                        .border(1.dp, SovereignGold, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "AH",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        color = SovereignGold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "AETHELGARD",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.5.sp,
                                fontFamily = FontFamily.Monospace
                            ),
                            color = SovereignGoldText
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "HOLDINGS PLC",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "EXECUTIVE COMMAND TERMINAL • 2026-10-15",
                        fontSize = 9.sp,
                        color = TextTertiary,
                        letterSpacing = 0.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Right controls: Currency, Persona Switcher, Telemetry status
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Currency Pill
                Box {
                    Row(
                        modifier = Modifier
                            .testTag("currency_selector")
                            .clip(RoundedCornerShape(4.dp))
                            .background(TerminalSurfaceElevated)
                            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                            .clickable { showCurrencyMenu = true }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = reportingCurrency,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Select currency",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showCurrencyMenu,
                        onDismissRequest = { showCurrencyMenu = false },
                        modifier = Modifier.background(TerminalSurfaceElevated)
                    ) {
                        listOf("USD", "GBP", "EUR", "CHF").forEach { curr ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "$curr (Reporting)",
                                        color = if (curr == reportingCurrency) SovereignGold else TextPrimary,
                                        fontFamily = FontFamily.Monospace
                                    )
                                },
                                onClick = {
                                    onCurrencySelected(curr)
                                    showCurrencyMenu = false
                                }
                            )
                        }
                    }
                }

                // Persona / Role Switcher
                Box {
                    Row(
                        modifier = Modifier
                            .testTag("persona_switcher")
                            .clip(RoundedCornerShape(4.dp))
                            .background(TerminalSurfaceElevated)
                            .border(1.dp, SovereignGold.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                            .clickable { showRoleMenu = true }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(TerminalEmerald)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = activeExecutive.role.level,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Switch executive role",
                            tint = SovereignGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showRoleMenu,
                        onDismissRequest = { showRoleMenu = false },
                        modifier = Modifier.background(TerminalSurfaceElevated)
                    ) {
                        UserRole.values().forEach { role ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = role.roleTitle,
                                            fontWeight = FontWeight.Bold,
                                            color = if (role == activeExecutive.role) SovereignGold else TextPrimary,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = role.level,
                                            fontSize = 10.sp,
                                            color = TextSecondary,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                },
                                onClick = {
                                    onRoleSelected(role)
                                    showRoleMenu = false
                                }
                            )
                        }
                    }
                }

                // AI Terminal Quick Launcher
                IconButton(
                    onClick = onOpenTerminal,
                    modifier = Modifier
                        .testTag("ai_terminal_quick_button")
                        .size(32.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalCyanContainer)
                        .border(1.dp, TerminalCyan.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "AI Terminal",
                        tint = TerminalCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Global Search Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = globalSearch,
                onValueChange = onSearchChanged,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("global_search_input"),
                placeholder = {
                    Text(
                        text = "Global Search entities, decisions, directives, treasury, contracts...",
                        fontSize = 11.sp,
                        color = TextTertiary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = SovereignGold,
                        modifier = Modifier.size(16.dp)
                    )
                },
                trailingIcon = {
                    if (globalSearch.isNotEmpty()) {
                        IconButton(onClick = { onSearchChanged("") }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear",
                                tint = TextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = TerminalSurfaceElevated,
                    unfocusedContainerColor = TerminalSurfaceElevated,
                    focusedBorderColor = SovereignGold,
                    unfocusedBorderColor = TerminalBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(6.dp)
            )
        }

        // Horizontal Workspace Tab Bar
        val scrollState = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            HoldcoTab.values().forEach { tab ->
                val isSelected = tab == currentTab
                val containerColor = if (isSelected) SovereignGoldContainer else Color.Transparent
                val borderColor = if (isSelected) SovereignGold else Color.Transparent
                val textColor = if (isSelected) SovereignGoldText else TextSecondary

                Box(
                    modifier = Modifier
                        .testTag("tab_${tab.name.lowercase()}")
                        .clip(RoundedCornerShape(4.dp))
                        .background(containerColor)
                        .border(1.dp, borderColor, RoundedCornerShape(4.dp))
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = tab.title.uppercase(),
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = textColor,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}
