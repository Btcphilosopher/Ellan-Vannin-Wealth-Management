package com.example.holdco.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.holdco.data.model.*
import com.example.holdco.ui.components.*
import com.example.holdco.ui.theme.*

@Composable
fun RiskComplianceIpScreen(
    risks: List<RiskItem>,
    compliance: List<ComplianceObligation>,
    contracts: List<ContractItem>,
    ipAssets: List<IPAssetItem>,
    entities: List<CorporateEntity>
) {
    var selectedSection by remember { mutableStateOf(0) } // 0 = Risks, 1 = Compliance, 2 = Contracts, 3 = IP Assets

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(TerminalSurfaceElevated)
                .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                .padding(4.dp)
        ) {
            listOf("RISKS", "COMPLIANCE", "CONTRACTS", "IP ASSETS").forEachIndexed { idx, title ->
                val isSelected = selectedSection == idx
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) SovereignGoldContainer else Color.Transparent)
                        .clickable { selectedSection = idx }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) SovereignGoldText else TextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (selectedSection) {
            0 -> {
                // RISKS
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(risks, key = { it.id }) { rsk ->
                        val entity = entities.find { it.id == rsk.affectedEntityId }
                        val severityColor = when (rsk.severity) {
                            RiskSeverity.CRITICAL, RiskSeverity.HIGH -> TerminalAlertRed
                            RiskSeverity.MEDIUM -> TerminalWarningAmber
                            RiskSeverity.LOW -> TerminalEmerald
                        }

                        TerminalCard(
                            title = rsk.title,
                            badgeText = "${rsk.severity.displayName} RISK",
                            badgeColor = severityColor,
                            modifier = Modifier.testTag("risk_item_${rsk.id}")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Affected Entity: ${entity?.tradingName ?: rsk.affectedEntityId}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                StatusBadgePill(rsk.category.displayName, SovereignGold)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(TerminalSurfaceElevated)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("INHERENT SCORE", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                    Text("${rsk.inherentScore}/25", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TerminalAlertRed, fontFamily = FontFamily.Monospace)
                                }
                                Column {
                                    Text("LIKELIHOOD / IMPACT", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                    Text("L${rsk.likelihood} × I${rsk.impact}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary, fontFamily = FontFamily.Monospace)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("RESIDUAL SCORE", fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
                                    Text("${rsk.residualScore}/25", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TerminalEmerald, fontFamily = FontFamily.Monospace)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Controls: ${rsk.controlsSummary}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                            KeyValueRow("Risk Officer", rsk.owner)
                            KeyValueRow("Status", rsk.status)
                        }
                    }
                }
            }

            1 -> {
                // COMPLIANCE OBLIGATIONS
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(compliance, key = { it.id }) { cmp ->
                        val entity = entities.find { it.id == cmp.entityId }

                        TerminalCard(
                            title = cmp.obligationTitle,
                            badgeText = cmp.status,
                            badgeColor = if (cmp.status.contains("Compliant", ignoreCase = true)) TerminalEmerald else TerminalWarningAmber,
                            modifier = Modifier.testTag("compliance_item_${cmp.id}")
                        ) {
                            KeyValueRow("Corporate Entity", entity?.tradingName ?: cmp.entityId)
                            KeyValueRow("Regulatory Authority", cmp.regulatoryBody)
                            KeyValueRow("Jurisdiction", cmp.jurisdiction)
                            KeyValueRow("Statutory Filing Due Date", cmp.dueDate, SovereignGoldText)
                            KeyValueRow("Mandatory Audit Requirement", if (cmp.isMandatoryFiling) "Yes (Statutory Filing)" else "Discretionary")
                        }
                    }
                }
            }

            2 -> {
                // CONTRACTS & OBLIGATIONS
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(contracts, key = { it.id }) { ctr ->
                        val entity = entities.find { it.id == ctr.entityId }

                        TerminalCard(
                            title = ctr.title,
                            badgeText = if (ctr.isExpiringSoon) "RENEWAL ALERT" else ctr.status,
                            badgeColor = if (ctr.isExpiringSoon) TerminalAlertRed else TerminalEmerald,
                            modifier = Modifier.testTag("contract_item_${ctr.id}")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Counterparty: ${ctr.counterparty}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Value: ${formatCurrency(ctr.annualValue, ctr.currency)}/yr",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SovereignGoldText,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            KeyValueRow("Contracting Entity", entity?.tradingName ?: ctr.entityId)
                            KeyValueRow("Effective Date", ctr.effectiveDate)
                            KeyValueRow("Expiry Date", ctr.expiryDate, if (ctr.isExpiringSoon) TerminalAlertRed else TextPrimary)
                            KeyValueRow("Renewal Window", "${ctr.renewalAlertDays} days remaining")
                            KeyValueRow("Key Governance Terms", ctr.keyObligations)
                        }
                    }
                }
            }

            3 -> {
                // IP ASSETS
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(ipAssets, key = { it.id }) { ip ->
                        val owner = entities.find { it.id == ip.registeredOwnerEntityId }

                        TerminalCard(
                            title = ip.assetName,
                            badgeText = ip.ipType,
                            badgeColor = TerminalCyan,
                            modifier = Modifier.testTag("ip_asset_${ip.id}")
                        ) {
                            KeyValueRow("Registered Legal Owner", owner?.tradingName ?: ip.registeredOwnerEntityId)
                            KeyValueRow("Registration Number", ip.registrationNumber, SovereignGoldText)
                            KeyValueRow("Jurisdiction / Registry", ip.registrationJurisdiction)
                            KeyValueRow("Commercial Status", ip.commercialStatus)
                            if (ip.annualRoyaltyRunRate > 0) {
                                KeyValueRow("Annualized Royalty Revenue", formatCurrency(ip.annualRoyaltyRunRate, "USD"), TerminalEmerald)
                            }
                            KeyValueRow("Patent / Term Expiry", ip.expiryDate)
                        }
                    }
                }
            }
        }
    }
}
