package com.example.holdco.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.holdco.data.model.*
import com.example.holdco.data.nlp.CommandResult
import com.example.holdco.data.nlp.HoldcoCommandEngine
import com.example.holdco.data.repository.HoldcoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

enum class HoldcoTab(val title: String, val iconName: String) {
    COMMAND_CENTRE("Command Centre", "Dashboard"),
    CORPORATE_STRUCTURE("Entities & Org", "AccountTree"),
    DECISIONS_DIRECTIVES("Decisions & Directives", "Gavel"),
    CAPITAL_ALLOCATION("Capital Allocation", "AccountBalance"),
    TREASURY_LIQUIDITY("Treasury & Payments", "Payments"),
    FINANCIAL_CONSOLIDATION("Ledger & Consolidation", "AutoStories"),
    SUBSIDIARIES_PROJECTS("Subsidiaries & Projects", "Business"),
    RISK_LEGAL_IP("Risk, Legal & IP", "Security"),
    NATURAL_TERMINAL("Executive AI Terminal", "Terminal"),
    AUDIT_GOVERNANCE("Audit & Governance", "Verified")
}

data class ExecutiveKpiSummary(
    val registeredEntitiesCount: Int,
    val activeSubsidiariesCount: Int,
    val totalRecordedLiquidity: Double,
    val approvedCommitmentsTotal: Double,
    val unallocatedCapital: Double,
    val pendingFundingRequestsCount: Int,
    val pendingDecisionsCount: Int,
    val overdueDirectivesCount: Int,
    val highRiskItemsCount: Int,
    val grossConsolidatedRevenue: Double,
    val groupNavEstimate: Double
)

class HoldcoViewModel(
    val repository: HoldcoRepository = HoldcoRepository()
) : ViewModel() {

    private val commandEngine = HoldcoCommandEngine(repository)

    private val _currentTab = MutableStateFlow(HoldcoTab.COMMAND_CENTRE)
    val currentTab: StateFlow<HoldcoTab> = _currentTab.asStateFlow()

    private val _globalSearch = MutableStateFlow("")
    val globalSearch: StateFlow<String> = _globalSearch.asStateFlow()

    private val _selectedEntity = MutableStateFlow<CorporateEntity?>(null)
    val selectedEntity: StateFlow<CorporateEntity?> = _selectedEntity.asStateFlow()

    private val _paymentPreview = MutableStateFlow<PaymentInstruction?>(null)
    val paymentPreview: StateFlow<PaymentInstruction?> = _paymentPreview.asStateFlow()

    private val _activeTerminalResult = MutableStateFlow<CommandResult?>(null)
    val activeTerminalResult: StateFlow<CommandResult?> = _activeTerminalResult.asStateFlow()

    private val _toastNotification = MutableStateFlow<String?>(null)
    val toastNotification: StateFlow<String?> = _toastNotification.asStateFlow()

    val entities = repository.entities
    val decisions = repository.decisions
    val directives = repository.directives
    val fundingRequests = repository.fundingRequests
    val capitalCommitments = repository.capitalCommitments
    val treasuryAccounts = repository.treasuryAccounts
    val payments = repository.payments
    val journalEntries = repository.journalEntries
    val intercompanyTransactions = repository.intercompanyTransactions
    val projects = repository.projects
    val risks = repository.risks
    val compliance = repository.compliance
    val contracts = repository.contracts
    val ipAssets = repository.ipAssets
    val auditEvents = repository.auditEvents
    val activeExecutive = repository.activeExecutive
    val reportingCurrency = repository.reportingCurrency

    val kpiSummary: StateFlow<ExecutiveKpiSummary> = combine(
        combine(entities, treasuryAccounts, capitalCommitments) { ents, accts, comms ->
            Triple(ents, accts, comms)
        },
        combine(fundingRequests, decisions, directives, risks) { reqs, decs, dirs, rskList ->
            listOf(reqs, decs, dirs, rskList)
        }
    ) { (ents, accts, comms), other ->
        @Suppress("UNCHECKED_CAST")
        val reqs = other[0] as List<FundingRequest>
        @Suppress("UNCHECKED_CAST")
        val decs = other[1] as List<ExecutiveDecision>
        @Suppress("UNCHECKED_CAST")
        val dirs = other[2] as List<Directive>
        @Suppress("UNCHECKED_CAST")
        val rskList = other[3] as List<RiskItem>

        val totalLiq = accts.sumOf { it.availableLiquidity }
        val activeComms = comms.filter { !it.isDisbursed }.sumOf { it.committedAmount }
        val unalloc = (totalLiq - activeComms).coerceAtLeast(0.0)
        val grossRev = ents.sumOf { it.annualRevenue }
        val nav = ents.sumOf { it.annualRevenue * 2.8 + it.cashBalance }

        ExecutiveKpiSummary(
            registeredEntitiesCount = ents.size,
            activeSubsidiariesCount = ents.count { it.parentEntityId != null && it.legalStatus == LegalOperatingStatus.ACTIVE },
            totalRecordedLiquidity = totalLiq,
            approvedCommitmentsTotal = activeComms,
            unallocatedCapital = unalloc,
            pendingFundingRequestsCount = reqs.count { it.status == FundingStatus.SUBMITTED || it.status == FundingStatus.COMMITTEE_REVIEW },
            pendingDecisionsCount = decs.count { it.status == DecisionStatus.SUBMITTED || it.status == DecisionStatus.UNDER_REVIEW },
            overdueDirectivesCount = dirs.count { it.isOverdue || it.status == DirectiveStatus.OVERDUE },
            highRiskItemsCount = rskList.count { it.severity == RiskSeverity.HIGH || it.severity == RiskSeverity.CRITICAL },
            grossConsolidatedRevenue = grossRev,
            groupNavEstimate = nav
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        ExecutiveKpiSummary(0, 0, 0.0, 0.0, 0.0, 0, 0, 0, 0, 0.0, 0.0)
    )

    fun selectTab(tab: HoldcoTab) {
        _currentTab.value = tab
    }

    fun setGlobalSearch(query: String) {
        _globalSearch.value = query
    }

    fun selectEntity(entity: CorporateEntity?) {
        _selectedEntity.value = entity
    }

    fun switchUserRole(role: UserRole) {
        repository.setActiveExecutive(role)
        showToast("Switched active persona to ${role.roleTitle}")
    }

    fun switchCurrency(currency: String) {
        repository.setReportingCurrency(currency)
        showToast("Reporting currency set to $currency")
    }

    fun showToast(msg: String) {
        _toastNotification.value = msg
    }

    fun clearToast() {
        _toastNotification.value = null
    }

    fun approveDecision(id: String) {
        if (repository.approveDecision(id)) {
            showToast("Decision $id successfully approved and logged to audit register.")
        } else {
            showToast("Failed to approve decision $id")
        }
    }

    fun rejectDecision(id: String, rationale: String) {
        if (repository.rejectDecision(id, rationale)) {
            showToast("Decision $id rejected.")
        }
    }

    fun submitDecision(id: String) {
        if (repository.submitDecision(id)) {
            showToast("Decision $id submitted for executive review.")
        }
    }

    fun acknowledgeDirective(id: String) {
        val exec = activeExecutive.value.name
        if (repository.acknowledgeDirective(id, exec)) {
            showToast("Directive $id acknowledged by $exec.")
        }
    }

    fun updateDirectiveStatus(id: String, status: DirectiveStatus, notes: String) {
        if (repository.updateDirectiveStatus(id, status, notes)) {
            showToast("Directive $id updated to ${status.displayName}.")
        }
    }

    fun approveFundingRequest(requestId: String, amount: Double) {
        val result = repository.approveFundingRequest(requestId, amount)
        result.onSuccess { comm ->
            showToast("Capital commitment created (${comm.id}) for $${String.format(Locale.US, "%,.0f", amount)}.")
        }.onFailure { err ->
            showToast("Error: ${err.message}")
        }
    }

    fun initiatePaymentPreview(sourceAccountId: String, targetEntityId: String, amount: Double, currency: String, purpose: String) {
        val result = repository.previewPayment(sourceAccountId, targetEntityId, amount, currency, purpose)
        result.onSuccess { instruction ->
            _paymentPreview.value = instruction
            showToast("Payment preview generated. Verification checks passed.")
        }.onFailure { err ->
            showToast("Payment Preview Error: ${err.message}")
        }
    }

    fun confirmExecutePayment() {
        val preview = _paymentPreview.value ?: return
        val result = repository.executePayment(preview)
        result.onSuccess { settled ->
            _paymentPreview.value = null
            showToast("Payment ${settled.referenceCode} settled. Double-entry ledger journal posted.")
        }.onFailure { err ->
            showToast("Disbursement Failure: ${err.message}")
        }
    }

    fun cancelPaymentPreview() {
        _paymentPreview.value = null
    }

    fun reconcileTransaction(txId: String) {
        if (repository.reconcileIntercompanyTransaction(txId)) {
            showToast("Intercompany transaction $txId reconciled.")
        }
    }

    fun submitNaturalCommand(query: String) {
        viewModelScope.launch {
            val result = commandEngine.executeNaturalCommand(query)
            _activeTerminalResult.value = result
            repository.logAudit("COMMAND_EXEC", "Terminal", "CLI", "Processed executive prompt: '$query'", null, result.intent)
        }
    }

    fun executeTerminalAction() {
        val res = _activeTerminalResult.value ?: return
        val action = res.executableAction ?: return
        val output = action.invoke()
        _activeTerminalResult.value = res.copy(
            summary = output,
            requiresConfirmation = false,
            statusBadge = "ACTION_COMPLETED"
        )
        showToast(output)
    }

    fun addNewEntity(
        legalName: String,
        tradingName: String,
        entityType: EntityType,
        jurisdiction: String,
        registrationNumber: String,
        parentEntityId: String?,
        ownershipPct: Double,
        currency: String,
        executive: String,
        description: String,
        cash: Double,
        revenue: Double
    ) {
        val id = "ENT-${(entities.value.size + 1).toString().padStart(3, '0')}"
        val entity = CorporateEntity(
            id = id,
            legalName = legalName,
            tradingName = tradingName,
            entityType = entityType,
            jurisdiction = jurisdiction,
            registrationNumber = registrationNumber.ifBlank { "REG-PENDING" },
            incorporationDate = "2026-10-15",
            parentEntityId = parentEntityId,
            ownershipPercentage = ownershipPct,
            votingPercentage = ownershipPct,
            shareClasses = "Standard Class A",
            ownershipEffectiveDate = "2026-10-15",
            verificationStatus = VerificationStatus.USER_DECLARED,
            legalStatus = LegalOperatingStatus.ACTIVE,
            reportingCurrency = currency,
            responsibleExecutive = executive,
            businessDescription = description,
            annualRevenue = revenue,
            operatingProfit = revenue * 0.18,
            cashBalance = cash,
            headcount = 12
        )
        val res = repository.addCorporateEntity(entity)
        res.onSuccess {
            showToast("Entity ${entity.tradingName} ($id) successfully registered.")
            selectEntity(entity)
        }.onFailure { err ->
            showToast("Validation Error: ${err.message}")
        }
    }

    fun exportAuditReportCsv(): String {
        val events = auditEvents.value
        val sb = StringBuilder()
        sb.append("Event ID,Timestamp,Role,User,Action,Target Type,Target ID,Summary,Hash\n")
        events.forEach { e ->
            sb.append("\"${e.id}\",\"${e.timestamp}\",\"${e.userRole}\",\"${e.userName}\",\"${e.actionType}\",\"${e.targetType}\",\"${e.targetId}\",\"${e.summary.replace("\"", "\"\"")}\",\"${e.verificationHash}\"\n")
        }
        showToast("Generated CSV report with ${events.size} audit events.")
        return sb.toString()
    }
}
