package com.example.holdco.data.model

enum class UserRole(val roleTitle: String, val level: String) {
    GROUP_OWNER("Group Owner / Board Chair", "L10 - Sovereign"),
    GROUP_CEO("Group Chief Executive", "L9 - Group Exec"),
    CHIEF_FINANCIAL_OFFICER("Chief Financial Officer", "L9 - Group Exec"),
    HEAD_OF_TREASURY("Head of Group Treasury", "L8 - Corporate"),
    SUBSIDIARY_EXECUTIVE("Subsidiary Managing Director", "L7 - Operating Unit"),
    GROUP_AUDITOR("Group Internal Auditor", "L7 - Audit / Risk")
}

data class ActiveExecutive(
    val name: String,
    val title: String,
    val role: UserRole,
    val entityId: String? = null // null means Group-wide
)

data class AuditEvent(
    val id: String,
    val timestamp: String,
    val userRole: String,
    val userName: String,
    val actionType: String,
    val targetType: String,
    val targetId: String,
    val summary: String,
    val previousState: String? = null,
    val newState: String? = null,
    val verificationHash: String
)
