package com.example.holdco

import com.example.holdco.data.model.*
import com.example.holdco.data.nlp.HoldcoCommandEngine
import com.example.holdco.data.repository.HoldcoRepository
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class HoldcoDomainTest {

    private lateinit var repository: HoldcoRepository
    private lateinit var commandEngine: HoldcoCommandEngine

    @Before
    fun setUp() {
        repository = HoldcoRepository()
        commandEngine = HoldcoCommandEngine(repository)
    }

    @Test
    fun testCircularOwnershipPrevention() {
        // ENT-001 is parent of ENT-002. ENT-002 is parent of ENT-005.
        // Trying to make ENT-001 have ENT-005 as parent should be flagged as circular!
        assertTrue(
            "Detect circular parentage",
            repository.isCircularParent("ENT-001", "ENT-005")
        )

        // An entity cannot be its own parent
        assertTrue(
            "Self parentage is circular",
            repository.isCircularParent("ENT-004", "ENT-004")
        )

        // A valid non-circular parentage: ENT-004 under ENT-002
        assertFalse(
            "Valid parentage is not circular",
            repository.isCircularParent("ENT-004", "ENT-002")
        )
    }

    @Test
    fun testDoubleEntryBookkeepingBalance() {
        val entries = repository.journalEntries.value
        assertTrue("Should have initial journal entries", entries.isNotEmpty())

        for (je in entries) {
            assertTrue(
                "Journal entry ${je.entryNumber} debits (${je.totalDebits}) must equal credits (${je.totalCredits})",
                je.isBalanced
            )
        }
    }

    @Test
    fun testDecisionLifecycleTransitions() {
        val decision = repository.decisions.value.first()
        val originalStatus = decision.status

        // Test approval
        val approved = repository.approveDecision(decision.id)
        assertTrue("Approve decision should succeed", approved)

        val updated = repository.decisions.value.find { it.id == decision.id }
        assertNotNull(updated)
        assertEquals(DecisionStatus.APPROVED, updated?.status)
        assertNotNull(updated?.approvedBy)
        assertNotNull(updated?.approvalTimestamp)
    }

    @Test
    fun testDirectiveLifecycleAcknowledgement() {
        val dir = repository.directives.value.first()
        val ack = repository.acknowledgeDirective(dir.id, "Managing Director")
        assertTrue("Acknowledgement should succeed", ack)

        val updated = repository.directives.value.find { it.id == dir.id }
        assertEquals(DirectiveStatus.ACKNOWLEDGED, updated?.status)
        assertNotNull(updated?.acknowledgementTimestamp)
    }

    @Test
    fun testCapitalAllocationDoubleAllocationSafeguard() {
        val totalLiquidity = repository.treasuryAccounts.value.sumOf { it.availableLiquidity }

        // Attempting to allocate an absurd amount far exceeding total liquidity must fail!
        val result = repository.approveFundingRequest("REQ-2026-012", totalLiquidity * 10)
        assertTrue("Excessive commitment must fail", result.isFailure)
    }

    @Test
    fun testTreasuryPaymentPreviewAndDuplicateProtection() {
        val acct = repository.treasuryAccounts.value.first { it.availableLiquidity > 500_000.0 }

        val preview = repository.previewPayment(
            sourceAccountId = acct.id,
            targetEntityId = "ENT-004",
            amount = 100_000.0,
            currency = "USD",
            purpose = "Test Tranche Allocation"
        )
        assertTrue("Payment preview should succeed with available liquidity", preview.isSuccess)

        val instruction = preview.getOrNull()
        assertNotNull(instruction)

        // Executing the payment
        val execution = repository.executePayment(instruction!!)
        assertTrue("Execution should succeed", execution.isSuccess)

        // Attempting to generate duplicate payment with same idempotency key must fail!
        val duplicate = repository.previewPayment(
            sourceAccountId = acct.id,
            targetEntityId = "ENT-004",
            amount = 100_000.0,
            currency = "USD",
            purpose = "Test Tranche Allocation"
        )
        assertTrue("Duplicate payment instruction must be rejected", duplicate.isFailure)
    }

    @Test
    fun testNaturalLanguageCommandResolution() {
        // Query 1: Subsidiaries ownership
        val r1 = commandEngine.executeNaturalCommand("Show all subsidiaries with ownership percentages")
        assertEquals("PORTFOLIO_OWNERSHIP_AUDIT", r1.intent)
        assertTrue(r1.details.isNotEmpty())

        // Query 2: Overdue directives
        val r2 = commandEngine.executeNaturalCommand("Show overdue executive directives")
        assertEquals("OVERDUE_DIRECTIVES_ESCALATION", r2.intent)

        // Query 3: Unallocated capital
        val r3 = commandEngine.executeNaturalCommand("Identify unallocated capital")
        assertEquals("UNALLOCATED_CAPITAL_SURPLUS", r3.intent)

        // Query 4: Expiring contracts
        val r4 = commandEngine.executeNaturalCommand("List contracts expiring in the next 90 days")
        assertEquals("CONTRACT_RENEWAL_ALERT", r4.intent)
    }
}
