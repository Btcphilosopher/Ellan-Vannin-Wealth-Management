import express from "express";
import path from "path";
import { exec } from "child_process";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route 1: Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", engine: "DESALFLOW ENGINE", version: "1.0.0" });
  });

  // API Route 2: Run Steady-State Physics Simulation
  app.post("/api/simulate", (req, res) => {
    const { temp = 25.0, salinity = 35.0, flow = 2000.0, pressure = 65.0 } = req.body || {};
    
    const cmd = `PYTHONPATH=. python3 -m desalflow.cli.main simulate --temp ${temp} --salinity ${salinity} --flow ${flow} --pressure ${pressure}`;

    exec(cmd, { cwd: process.cwd(), maxBuffer: 10 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error) {
        console.error("Simulation Execution Error:", stderr);
        return res.status(500).json({ error: "Simulation failed", details: stderr });
      }
      try {
        const result = JSON.parse(stdout);
        res.json(result);
      } catch (e) {
        res.status(500).json({ error: "Failed to parse simulation stdout", raw: stdout });
      }
    });
  });

  // API Route 3: Parametric Sweep
  app.post("/api/sweep", (req, res) => {
    const { pmin = 52.0, pmax = 76.0 } = req.body || {};

    const cmd = `PYTHONPATH=. python3 -m desalflow.cli.main sweep --pmin ${pmin} --pmax ${pmax}`;

    exec(cmd, { cwd: process.cwd(), maxBuffer: 10 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error) {
        return res.status(500).json({ error: "Sweep failed", details: stderr });
      }
      try {
        const data = JSON.parse(stdout);
        res.json({ sweep: data });
      } catch (e) {
        res.status(500).json({ error: "Failed to parse sweep data", raw: stdout });
      }
    });
  });

  // API Route 4: SEC Minimization Optimization
  app.post("/api/optimize", (req, res) => {
    const { tdsMax = 300.0 } = req.body || {};

    const cmd = `PYTHONPATH=. python3 -m desalflow.cli.main optimize --tds-max ${tdsMax}`;

    exec(cmd, { cwd: process.cwd(), maxBuffer: 10 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error) {
        return res.status(500).json({ error: "Optimization failed", details: stderr });
      }
      try {
        const result = JSON.parse(stdout);
        res.json(result);
      } catch (e) {
        res.status(500).json({ error: "Failed to parse optimization result", raw: stdout });
      }
    });
  });

  // API Route 5: Plant Sizer
  app.post("/api/size", (req, res) => {
    const { capacity = 50000.0 } = req.body || {};

    const cmd = `PYTHONPATH=. python3 -m desalflow.cli.main size --capacity ${capacity}`;

    exec(cmd, { cwd: process.cwd() }, (error, stdout, stderr) => {
      if (error) {
        return res.status(500).json({ error: "Sizing failed", details: stderr });
      }
      try {
        const result = JSON.parse(stdout);
        res.json(result);
      } catch (e) {
        res.status(500).json({ error: "Failed to parse sizing result", raw: stdout });
      }
    });
  });

  // API Route 6: Generate Performance Map Plot
  app.post("/api/generate-plot", (req, res) => {
    const outPath = path.join(process.cwd(), "public", "swro_map.png");
    const cmd = `python3 -c "from desalflow.analysis.curves import PerformanceCurvePlotter; PerformanceCurvePlotter.generate_swro_performance_map('${outPath}')"`;

    exec(cmd, { cwd: process.cwd() }, (error, stdout, stderr) => {
      if (error) {
        return res.status(500).json({ error: "Plot generation failed", details: stderr });
      }
      res.json({ success: true, url: "/swro_map.png" });
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`DESALFLOW Engine server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
