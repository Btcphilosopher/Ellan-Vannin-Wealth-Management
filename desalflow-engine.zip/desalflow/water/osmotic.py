"""
DESALFLOW ENGINE - Osmotic Pressure Calculation Engine
Models:
1. Sharqawy et al. Seawater Osmotic Pressure (Fidelity Level 2)
2. Van 't Hoff Ideal Osmotic Pressure (Fidelity Level 0)
3. Activity-corrected ionic Osmotic Pressure (Fidelity Level 2)

Calculates effective net driving pressure:
Delta_P_effective = (P_feed - P_permeate) - (pi_surface - pi_permeate)
"""

import math
from typing import Optional, Dict, Any
from desalflow.water.chemistry import WaterComposition, MOLAR_MASSES, ION_CHARGES
from desalflow.water.properties import SeawaterProperties

# Universal Gas Constant
R_GAS = 8.314462618  # J/(mol·K)

class OsmoticPressureModel:
    @staticmethod
    def sharqawy_seawater_osmotic_pressure(temperature_k: float, salinity_g_kg: float) -> float:
        """
        Calculates seawater osmotic pressure in Pa (Sharqawy et al. 2010).
        Accurate for standard seawater salts over S = 0 to 120 g/kg, T = 10 to 45°C.
        At T = 298.15 K (25°C) and S = 35 g/kg: pi approx 2.709 MPa (27.09 bar).
        """
        t_c = temperature_k - 273.15
        s = max(0.0, salinity_g_kg)
        
        # Empirical correlation for osmotic pressure in bar:
        # pi_bar = (0.75883 + 0.00282 * t_c) * s + 0.00045 * (s**2) * (1.0 + 0.003 * t_c)
        # Higher order MIT seawater osmotic equation:
        # pi (Pa) = (7.5883e4 + 282.0 * t_c) * s + 45.0 * (s**2) * (1.0 + 0.003 * t_c) + 0.35 * (s**3)
        pi_pa = (7.5883e4 + 282.0 * t_c) * s + 45.0 * (s**2) * (1.0 + 0.003 * t_c) + 0.25 * (s**2.5) * (t_c + 273.15) / 298.15
        return float(pi_pa)

    @staticmethod
    def van_t_hoff_osmotic_pressure(
        temperature_k: float,
        tds_mg_l: float,
        van_t_hoff_factor: float = 1.9,
        avg_molar_mass_g_mol: float = 58.44
    ) -> float:
        """
        Ideal Van 't Hoff approximation:
        pi = i * C * R * T  [Pa]
        C in mol/m³ = (tds_mg_l / 1000.0) / (avg_molar_mass * 1e-3)
        """
        c_mol_m3 = (tds_mg_l / 1000.0) / (avg_molar_mass_g_mol * 1e-3)
        pi_pa = van_t_hoff_factor * c_mol_m3 * R_GAS * temperature_k
        return float(pi_pa)

    @staticmethod
    def ionic_composition_osmotic_pressure(
        temperature_k: float,
        composition: WaterComposition,
        density_kg_m3: float = 1025.0
    ) -> float:
        """
        Activity-corrected osmotic pressure from detailed ionic analysis using osmotic coefficient phi:
        pi = phi * sum( m_i ) * R * T * rho_solvent
        """
        i_strength = composition.calculate_ionic_strength()
        # Modified Pitzer/Bromley osmotic coefficient for seawater ionic strength ~ 0.7M
        # phi ~ 0.90 to 0.94
        phi = 1.0 - 0.392 * (math.sqrt(i_strength) / (1.0 + 1.2 * math.sqrt(i_strength))) + 0.05 * i_strength
        
        # Total molality of all dissolved species (mol/kg water)
        total_mol_l = 0.0
        for ion, conc_mg_l in composition.ions_mg_l.items():
            mw = MOLAR_MASSES.get(ion, 58.44)
            c_mol_l = (conc_mg_l / 1000.0) / mw
            total_mol_l += c_mol_l
            
        c_mol_m3 = total_mol_l * 1000.0
        pi_pa = phi * c_mol_m3 * R_GAS * temperature_k
        return float(pi_pa)

    @classmethod
    def calculate(
        cls,
        temperature_k: float,
        salinity_g_kg: float,
        composition: Optional[WaterComposition] = None,
        model_type: str = "sharqawy"
    ) -> float:
        """Dispatcher for osmotic pressure calculation with explicit model identification."""
        if model_type == "van_t_hoff":
            rho = SeawaterProperties.density(temperature_k, salinity_g_kg)
            tds = salinity_g_kg * rho
            return cls.van_t_hoff_osmotic_pressure(temperature_k, tds)
        elif model_type == "ionic" and composition is not None:
            rho = SeawaterProperties.density(temperature_k, salinity_g_kg)
            return cls.ionic_composition_osmotic_pressure(temperature_k, composition, rho)
        else:
            return cls.sharqawy_seawater_osmotic_pressure(temperature_k, salinity_g_kg)
