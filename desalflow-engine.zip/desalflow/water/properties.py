"""
DESALFLOW ENGINE - Seawater Thermophysical Properties
Implements high-fidelity seawater thermophysical correlations from:
Sharqawy, M.H., Lienhard V, J.H., and Zubair, S.M. (2010),
"Thermophysical properties of seawater: a review of existing correlations and data",
Desalination and Water Treatment, 16(1-3), pp. 354-380.

Properties calculated:
- Density rho [kg/m³] as function of T [K], S [g/kg], P [Pa]
- Dynamic Viscosity mu [Pa·s] as function of T [K], S [g/kg]
- Kinematic Viscosity nu = mu / rho [m²/s]
- Specific Heat Capacity cp [J/(kg·K)]
- Thermal Conductivity k [W/(m·K)]
- Electrical Conductivity kappa [S/m or mS/cm]
"""

import math
from typing import Dict, Any

class SeawaterProperties:
    @staticmethod
    def pure_water_density(t_c: float) -> float:
        """
        Pure water density at atmospheric pressure (IAPWS / Tanaka et al.).
        Valid range: 0°C to 180°C.
        """
        # Tanaka et al. equation
        a1 = -3.983035
        a2 = 301.797
        a3 = 522528.9
        a4 = 69.34881
        a5 = 999.974950
        return a5 * (1.0 - ((t_c + a1)**2 * (t_c + a2)) / (a3 * (t_c + a4)))

    @staticmethod
    def density(temperature_k: float, salinity_g_kg: float, pressure_pa: float = 101325.0) -> float:
        """
        Seawater density rho in kg/m³ (Sharqawy et al. 2010).
        Valid range: T = 0 to 180°C (273.15 to 453.15 K), S = 0 to 160 g/kg, P = 0.1 to 14 MPa.
        """
        t_c = temperature_k - 273.15
        s = max(0.0, salinity_g_kg)
        
        # Atmospheric pressure density rho_0
        rho_w = SeawaterProperties.pure_water_density(t_c)
        
        # Salinity correction terms (Sharqawy eq. 8)
        b1 = 8.020e-1
        b2 = -2.001e-3
        b3 = 1.677e-5
        b4 = -3.060e-8
        b5 = -1.613e-8
        
        c1 = 1.610e-3
        c2 = -6.442e-6
        
        rho_0 = rho_w + (b1 + b2*t_c + b3*(t_c**2) + b4*(t_c**3) + b5*(t_c**4))*s + (c1 + c2*t_c)*(s**1.5)
        
        # Pressure correction for high pressure SWRO (up to 80-100 bar)
        # Bulk modulus of seawater K(T, S) in Pa
        p_gauge_bar = max(0.0, (pressure_pa - 101325.0) / 1e5)
        if p_gauge_bar > 0.1:
            # Secant bulk modulus K_0 approx ~ 2.2e9 Pa + 1e7 Pa/bar * S_factor
            k_mod = (2.2e9 + 1.2e7 * t_c - 1.0e5 * (t_c**2) + 6.0e6 * s)
            rho_p = rho_0 / (1.0 - (pressure_pa - 101325.0) / k_mod)
            return rho_p
            
        return rho_0

    @staticmethod
    def dynamic_viscosity(temperature_k: float, salinity_g_kg: float) -> float:
        """
        Seawater dynamic viscosity mu in Pa·s (Sharqawy et al. 2010, eq. 22).
        Valid range: T = 0 to 180°C, S = 0 to 150 g/kg.
        """
        t_c = temperature_k - 273.15
        s = max(0.0, salinity_g_kg)
        
        # Pure water viscosity mu_w (Pa·s)
        # mu_w = 2.414e-5 * 10^(247.8 / (T - 140))
        mu_w = 2.414e-5 * math.pow(10.0, 247.8 / (temperature_k - 140.0))
        
        # Salinity correction factor A and B
        a = 1.474e-3 + 1.5e-5 * t_c - 3.927e-8 * (t_c**2)
        b = 1.073e-5 - 8.5e-8 * t_c + 2.23e-10 * (t_c**2)
        
        mu_sw = mu_w * (1.0 + a * s + b * (s**2))
        return mu_sw

    @staticmethod
    def kinematic_viscosity(temperature_k: float, salinity_g_kg: float, pressure_pa: float = 101325.0) -> float:
        """Kinematic viscosity nu in m²/s = dynamic_viscosity / density."""
        rho = SeawaterProperties.density(temperature_k, salinity_g_kg, pressure_pa)
        mu = SeawaterProperties.dynamic_viscosity(temperature_k, salinity_g_kg)
        return mu / rho

    @staticmethod
    def specific_heat_capacity(temperature_k: float, salinity_g_kg: float) -> float:
        """
        Specific heat capacity cp in J/(kg·K) (Sharqawy et al. 2010).
        Valid range: T = 0 to 180°C, S = 0 to 120 g/kg.
        """
        t_c = temperature_k - 273.15
        s = max(0.0, salinity_g_kg)
        
        # Pure water cp_w (J/kg·K)
        cp_w = 4217.4 - 3.720283 * t_c + 0.1412855 * (t_c**2) - 2.654387e-3 * (t_c**3) + 2.093236e-5 * (t_c**4)
        
        # Salinity correction terms
        a = -5.58 + 0.101 * t_c - 1.8e-3 * (t_c**2)
        b = 0.05 - 9.0e-4 * t_c + 1.6e-5 * (t_c**2)
        
        cp_sw = cp_w + a * s + b * (s**2)
        return cp_sw

    @staticmethod
    def thermal_conductivity(temperature_k: float, salinity_g_kg: float) -> float:
        """Thermal conductivity k in W/(m·K) (Sharqawy et al. 2010)."""
        t_c = temperature_k - 273.15
        s = max(0.0, salinity_g_kg)
        
        # Pure water
        k_w = 0.569 + 1.88e-3 * t_c - 7.72e-6 * (t_c**2)
        log10_term = math.log10(240.0 + s)
        k_sw = k_w * (1.0 - 0.00022 * s)
        return k_sw

    @staticmethod
    def electrical_conductivity(temperature_k: float, salinity_g_kg: float) -> float:
        """
        Electrical conductivity in S/m (PSS-78 Practical Salinity Scale).
        Standard Seawater (S=35, T=25°C) ~ 5.3 S/m (53,000 uS/cm = 53 mS/cm).
        """
        t_c = temperature_k - 273.15
        s = max(0.0, salinity_g_kg)
        # Linear/polynomial approximation around reference standard seawater
        ratio_s = s / 35.0
        temp_factor = 1.0 + 0.02 * (t_c - 25.0)
        return 5.308 * ratio_s * temp_factor

    @staticmethod
    def get_full_property_dict(temperature_k: float, salinity_g_kg: float, pressure_pa: float = 101325.0) -> Dict[str, Any]:
        return {
            "density_kg_m3": SeawaterProperties.density(temperature_k, salinity_g_kg, pressure_pa),
            "dynamic_viscosity_pa_s": SeawaterProperties.dynamic_viscosity(temperature_k, salinity_g_kg),
            "kinematic_viscosity_m2_s": SeawaterProperties.kinematic_viscosity(temperature_k, salinity_g_kg, pressure_pa),
            "specific_heat_j_kg_k": SeawaterProperties.specific_heat_capacity(temperature_k, salinity_g_kg),
            "thermal_conductivity_w_m_k": SeawaterProperties.thermal_conductivity(temperature_k, salinity_g_kg),
            "electrical_conductivity_s_m": SeawaterProperties.electrical_conductivity(temperature_k, salinity_g_kg)
        }
