"""
DESALFLOW ENGINE - Canonical WaterStream Class
A WaterStream is a physical water object connecting process equipment.
Parameters:
- temperature [K]
- pressure [Pa]
- mass_flow [kg/s]
- volume_flow [m³/s]
- density [kg/m³]
- viscosity [Pa·s]
- salinity [g/kg]
- TDS [mg/L]
- pH
- conductivity [S/m]
- composition [WaterComposition]
"""

from typing import Optional, Dict, Any
from pydantic import BaseModel, Field
from desalflow.core.units import Units
from desalflow.core.quantities import DimensionalCheck
from desalflow.water.chemistry import WaterComposition
from desalflow.water.salinity import SalinityConverter
from desalflow.water.properties import SeawaterProperties
from desalflow.water.osmotic import OsmoticPressureModel

class WaterStream:
    def __init__(
        self,
        temperature_k: float = 298.15,
        pressure_pa: float = 101325.0,
        mass_flow_kg_s: Optional[float] = None,
        volume_flow_m3_s: Optional[float] = None,
        salinity_g_kg: float = 35.0,
        composition: Optional[WaterComposition] = None,
        name: str = "Stream"
    ):
        self.name = name
        self.temperature_k = float(temperature_k)
        self.pressure_pa = float(pressure_pa)
        self.salinity_g_kg = max(0.0, float(salinity_g_kg))
        
        # Composition handling
        if composition is None:
            self.composition = WaterComposition.standard_seawater(self.salinity_g_kg)
        else:
            self.composition = composition

        # Validate dimensional bounds
        DimensionalCheck.assert_temperature_kelvin(self.temperature_k, f"{name}.temperature")
        DimensionalCheck.assert_positive_pressure(self.pressure_pa, f"{name}.pressure")

        # Thermophysical property calculations
        self.density_kg_m3 = SeawaterProperties.density(self.temperature_k, self.salinity_g_kg, self.pressure_pa)
        self.viscosity_pa_s = SeawaterProperties.dynamic_viscosity(self.temperature_k, self.salinity_g_kg)
        self.kinematic_viscosity_m2_s = self.viscosity_pa_s / self.density_kg_m3
        self.specific_heat_j_kg_k = SeawaterProperties.specific_heat_capacity(self.temperature_k, self.salinity_g_kg)
        self.conductivity_s_m = SeawaterProperties.electrical_conductivity(self.temperature_k, self.salinity_g_kg)
        
        # TDS in mg/L
        self.tds_mg_l = SalinityConverter.g_kg_to_tds_mg_l(self.salinity_g_kg, self.density_kg_m3)
        self.pH = self.composition.pH

        # Mass vs Volumetric flow relation: mass_flow = density * volume_flow
        if mass_flow_kg_s is not None:
            self.mass_flow_kg_s = max(0.0, float(mass_flow_kg_s))
            self.volume_flow_m3_s = self.mass_flow_kg_s / self.density_kg_m3
        elif volume_flow_m3_s is not None:
            self.volume_flow_m3_s = max(0.0, float(volume_flow_m3_s))
            self.mass_flow_kg_s = self.volume_flow_m3_s * self.density_kg_m3
        else:
            self.mass_flow_kg_s = 0.0
            self.volume_flow_m3_s = 0.0

        # Osmotic pressure calculation
        self.osmotic_pressure_pa = OsmoticPressureModel.calculate(
            temperature_k=self.temperature_k,
            salinity_g_kg=self.salinity_g_kg,
            composition=self.composition,
            model_type="sharqawy"
        )

    # Convenience human-facing property getters
    @property
    def temperature_c(self) -> float:
        return Units.k_to_c(self.temperature_k)

    @property
    def pressure_bar(self) -> float:
        return Units.pa_to_bar(self.pressure_pa)

    @property
    def osmotic_pressure_bar(self) -> float:
        return Units.pa_to_bar(self.osmotic_pressure_pa)

    @property
    def volume_flow_m3_h(self) -> float:
        return Units.m3s_to_m3h(self.volume_flow_m3_s)

    @property
    def volume_flow_l_s(self) -> float:
        return Units.m3s_to_ls(self.volume_flow_m3_s)

    @property
    def salt_mass_flow_kg_s(self) -> float:
        """Solute mass flow: m_salt = m_total * (salinity_g_kg / 1000)."""
        return self.mass_flow_kg_s * (self.salinity_g_kg / 1000.0)

    def copy_with(
        self,
        temperature_k: Optional[float] = None,
        pressure_pa: Optional[float] = None,
        mass_flow_kg_s: Optional[float] = None,
        volume_flow_m3_s: Optional[float] = None,
        salinity_g_kg: Optional[float] = None,
        name: Optional[str] = None
    ) -> "WaterStream":
        return WaterStream(
            temperature_k=temperature_k if temperature_k is not None else self.temperature_k,
            pressure_pa=pressure_pa if pressure_pa is not None else self.pressure_pa,
            mass_flow_kg_s=mass_flow_kg_s if mass_flow_kg_s is not None else self.mass_flow_kg_s,
            volume_flow_m3_s=volume_flow_m3_s if volume_flow_m3_s is not None else (self.volume_flow_m3_s if mass_flow_kg_s is None else None),
            salinity_g_kg=salinity_g_kg if salinity_g_kg is not None else self.salinity_g_kg,
            composition=self.composition,
            name=name if name is not None else f"{self.name}_derived"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "temperature_k": self.temperature_k,
            "temperature_c": round(self.temperature_c, 2),
            "pressure_pa": self.pressure_pa,
            "pressure_bar": round(self.pressure_bar, 2),
            "osmotic_pressure_bar": round(self.osmotic_pressure_bar, 2),
            "mass_flow_kg_s": round(self.mass_flow_kg_s, 4),
            "volume_flow_m3_h": round(self.volume_flow_m3_h, 2),
            "volume_flow_m3_s": round(self.volume_flow_m3_s, 6),
            "salinity_g_kg": round(self.salinity_g_kg, 2),
            "tds_mg_l": round(self.tds_mg_l, 1),
            "density_kg_m3": round(self.density_kg_m3, 2),
            "viscosity_pa_s": round(self.viscosity_pa_s, 6),
            "pH": round(self.pH, 2)
        }
