"""
DESALFLOW ENGINE - Salinity Representation and Rigorous Conversion Models
Converts between:
- Salinity S in g/kg (practical salinity / reference salinity mass fraction * 1000)
- Salinity S in g/L (volumetric concentration)
- TDS in mg/L
- Mass fraction w = S (g/kg) / 1000.0 (kg solute / kg solution)
"""

from typing import Tuple

class SalinityConverter:
    @staticmethod
    def g_kg_to_g_l(salinity_g_kg: float, density_kg_m3: float) -> float:
        """
        Converts g/kg to g/L:
        C [g/L] = S [g/kg] * rho [kg/m³] / 1000.0
        """
        return salinity_g_kg * (density_kg_m3 / 1000.0)

    @staticmethod
    def g_l_to_g_kg(salinity_g_l: float, density_kg_m3: float) -> float:
        """
        Converts g/L to g/kg:
        S [g/kg] = C [g/L] / (rho [kg/m³] / 1000.0)
        """
        return salinity_g_l / (density_kg_m3 / 1000.0)

    @staticmethod
    def g_kg_to_tds_mg_l(salinity_g_kg: float, density_kg_m3: float) -> float:
        """Converts g/kg to TDS in mg/L (ppm)."""
        return SalinityConverter.g_kg_to_g_l(salinity_g_kg, density_kg_m3) * 1000.0

    @staticmethod
    def tds_mg_l_to_g_kg(tds_mg_l: float, density_kg_m3: float) -> float:
        """Converts TDS in mg/L to g/kg."""
        return SalinityConverter.g_l_to_g_kg(tds_mg_l / 1000.0, density_kg_m3)

    @staticmethod
    def mass_fraction_to_g_kg(w: float) -> float:
        return w * 1000.0

    @staticmethod
    def g_kg_to_mass_fraction(s_g_kg: float) -> float:
        return s_g_kg / 1000.0
