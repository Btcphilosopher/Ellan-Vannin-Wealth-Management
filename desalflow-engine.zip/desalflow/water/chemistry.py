"""
DESALFLOW ENGINE - Chemical Composition and Dissolved Ions
Models multi-component dissolved ions, charge balance, ionic strength, and stoichiometry.
Components: Na+, Cl-, Mg2+, Ca2+, K+, SO4(2-), HCO3-, CO3(2-), Br-, B, SiO2, and arbitrary species.
"""

from typing import Dict, Optional
from pydantic import BaseModel, Field

# Molecular weights in g/mol
MOLAR_MASSES: Dict[str, float] = {
    "Na": 22.989769,
    "Cl": 35.453,
    "Mg": 24.305,
    "Ca": 40.078,
    "K": 39.0983,
    "SO4": 96.06,
    "HCO3": 61.0168,
    "CO3": 60.0089,
    "Br": 79.904,
    "B": 10.811,
    "SiO2": 60.0843,
    "Sr": 87.62,
    "F": 18.998403,
    "NO3": 62.0049,
    "Ba": 137.327
}

# Valence charges
ION_CHARGES: Dict[str, int] = {
    "Na": 1,
    "Cl": -1,
    "Mg": 2,
    "Ca": 2,
    "K": 1,
    "SO4": -2,
    "HCO3": -1,
    "CO3": -2,
    "Br": -1,
    "B": 0,       # Boric acid predominantly neutral B(OH)3 at seawater pH ~8.1
    "SiO2": 0,    # Monosilicic acid neutral at typical pH
    "Sr": 2,
    "F": -1,
    "NO3": -1,
    "Ba": 2
}

class WaterComposition(BaseModel):
    """
    Dissolved ion composition representation with explicit concentration in mg/L (or g/m³).
    Default values correspond to Standard Seawater at S = 35.0 g/kg (35,000 mg/L TDS approx).
    """
    ions_mg_l: Dict[str, float] = Field(default_factory=lambda: {
        "Na": 10768.0,
        "Cl": 19353.0,
        "Mg": 1292.0,
        "Ca": 412.3,
        "K": 399.1,
        "SO4": 2712.0,
        "HCO3": 141.7,
        "CO3": 17.6,
        "Br": 67.3,
        "B": 4.5,
        "SiO2": 2.0,
        "Sr": 7.9,
        "F": 1.3
    })
    pH: float = 8.1
    turbidity_ntu: float = 0.5
    sdi_15: float = 4.0

    @classmethod
    def standard_seawater(cls, salinity_g_kg: float = 35.0) -> "WaterComposition":
        """Generates standard seawater composition scaled linearly by salinity ratio."""
        ratio = salinity_g_kg / 35.0
        base = {
            "Na": 10768.0 * ratio,
            "Cl": 19353.0 * ratio,
            "Mg": 1292.0 * ratio,
            "Ca": 412.3 * ratio,
            "K": 399.1 * ratio,
            "SO4": 2712.0 * ratio,
            "HCO3": 141.7 * ratio,
            "CO3": 17.6 * ratio,
            "Br": 67.3 * ratio,
            "B": 4.5 * ratio,
            "SiO2": 2.0 * ratio,
            "Sr": 7.9 * ratio,
            "F": 1.3 * ratio
        }
        return cls(ions_mg_l=base, pH=8.1)

    @classmethod
    def brackish_water(cls, tds_mg_l: float = 3000.0) -> "WaterComposition":
        """Generates typical sodium-chloride-sulfate dominant brackish water."""
        ratio = tds_mg_l / 3000.0
        base = {
            "Na": 850.0 * ratio,
            "Cl": 1100.0 * ratio,
            "Mg": 90.0 * ratio,
            "Ca": 150.0 * ratio,
            "K": 20.0 * ratio,
            "SO4": 550.0 * ratio,
            "HCO3": 220.0 * ratio,
            "CO3": 5.0 * ratio,
            "Br": 2.0 * ratio,
            "B": 0.5 * ratio,
            "SiO2": 15.0 * ratio
        }
        return cls(ions_mg_l=base, pH=7.6)

    def total_dissolved_solids_mg_l(self) -> float:
        """Sum of all dissolved constituents in mg/L."""
        return sum(self.ions_mg_l.values())

    def get_ion_mol_m3(self, ion: str) -> float:
        """Returns molar concentration in mol/m³ (equivalent to mmol/L)."""
        conc_mg_l = self.ions_mg_l.get(ion, 0.0)
        mw = MOLAR_MASSES.get(ion, 50.0)
        return conc_mg_l / mw

    def calculate_ionic_strength(self) -> float:
        """
        Calculates molal/molar ionic strength:
        I = 0.5 * sum( c_i * z_i^2 ) in mol/L
        """
        i_sum = 0.0
        for ion, conc_mg_l in self.ions_mg_l.items():
            mw = MOLAR_MASSES.get(ion, 50.0)
            z = ION_CHARGES.get(ion, 0)
            c_mol_l = (conc_mg_l / 1000.0) / mw # mol/L
            i_sum += c_mol_l * (z ** 2)
        return 0.5 * i_sum

    def calculate_charge_balance_error_pct(self) -> float:
        """
        Calculates cation/anion charge balance error percentage:
        Error = (Cations - |Anions|) / (Cations + |Anions|) * 100%
        """
        cations_meq = 0.0
        anions_meq = 0.0
        for ion, conc_mg_l in self.ions_mg_l.items():
            mw = MOLAR_MASSES.get(ion, 50.0)
            z = ION_CHARGES.get(ion, 0)
            meq = (conc_mg_l / mw) * abs(z)
            if z > 0:
                cations_meq += meq
            elif z < 0:
                anions_meq += meq
        
        total = cations_meq + anions_meq
        if total == 0:
            return 0.0
        return ((cations_meq - anions_meq) / total) * 100.0
