"""
DESALFLOW ENGINE - Chemical Conditioning Pretreatment
Models chemical dosing for anti-scalant, acid (H2SO4/HCl) pH adjustment, and coagulant (FeCl3).
"""

from typing import Dict, Any
from desalflow.water.stream import WaterStream

class ChemicalConditioning:
    def __init__(
        self,
        antiscalant_dose_mg_l: float = 3.0,
        acid_dose_mg_l: float = 10.0, # Acid addition for pH control
        target_ph: float = 7.8,
        name: str = "Chemical Conditioning"
    ):
        self.name = name
        self.antiscalant_dose_mg_l = float(antiscalant_dose_mg_l)
        self.acid_dose_mg_l = float(acid_dose_mg_l)
        self.target_ph = float(target_ph)

    def calculate(self, inlet_stream: WaterStream) -> Dict[str, Any]:
        if inlet_stream.volume_flow_m3_s <= 0.0:
            return {"chemical_mass_flow_kg_h": 0.0, "outlet_stream": inlet_stream}

        # Calculate chemical consumption rates
        q_m3h = inlet_stream.volume_flow_m3_h
        antiscalant_kg_h = (self.antiscalant_dose_mg_l * q_m3h) / 1000.0
        acid_kg_h = (self.acid_dose_mg_l * q_m3h) / 1000.0

        comp_outlet = inlet_stream.composition.model_copy()
        comp_outlet.pH = self.target_ph

        # Pressure loss across static mixer (~ 0.05 bar)
        dp_pa = 0.05 * 1e5
        outlet_pressure = max(0.0, inlet_stream.pressure_pa - dp_pa)

        outlet_stream = WaterStream(
            temperature_k=inlet_stream.temperature_k,
            pressure_pa=outlet_pressure,
            mass_flow_kg_s=inlet_stream.mass_flow_kg_s,
            salinity_g_kg=inlet_stream.salinity_g_kg,
            composition=comp_outlet,
            name=f"{self.name}_Outlet"
        )

        return {
            "antiscalant_dose_mg_l": self.antiscalant_dose_mg_l,
            "antiscalant_consumption_kg_h": round(antiscalant_kg_h, 3),
            "acid_consumption_kg_h": round(acid_kg_h, 3),
            "adjusted_pH": self.target_ph,
            "outlet_stream": outlet_stream
        }
