"""
DESALFLOW ENGINE - Cartridge Filter Model (Guard Filtration)
Models 5-micron melt-blown / wound cartridge filter housing:
- Flow per 10-inch element
- Differential pressure as function of flow and fouling state
"""

from typing import Dict, Any
from desalflow.water.stream import WaterStream

class CartridgeFilter:
    def __init__(
        self,
        number_of_elements: int = 120,
        element_length_inches: int = 40,
        micron_rating_um: float = 5.0,
        clean_dp_bar: float = 0.10,
        max_dp_bar: float = 1.0,
        name: str = "Cartridge Filter"
    ):
        self.name = name
        self.number_of_elements = int(number_of_elements)
        self.element_length_inches = int(element_length_inches)
        self.micron_rating_um = float(micron_rating_um)
        self.clean_dp_bar = float(clean_dp_bar)
        self.max_dp_bar = float(max_dp_bar)

    def calculate(self, inlet_stream: WaterStream, fouling_factor: float = 1.0) -> Dict[str, Any]:
        if inlet_stream.volume_flow_m3_s <= 0.0:
            outlet = inlet_stream.copy_with(name=f"{self.name}_Outlet")
            return {"flow_per_element_m3h": 0.0, "pressure_drop_bar": 0.0, "outlet_stream": outlet}

        # Equivalent 10-inch element count
        equivalent_10in_count = self.number_of_elements * (self.element_length_inches / 10.0)
        flow_per_10in_m3h = (inlet_stream.volume_flow_m3_h) / max(1.0, equivalent_10in_count)

        # Base rated flow per 10in element is ~ 1.1 m³/h (5 gpm)
        ratio = flow_per_10in_m3h / 1.1
        dp_bar = min(self.max_dp_bar, self.clean_dp_bar * (ratio ** 1.5) * max(1.0, fouling_factor))
        dp_pa = dp_bar * 1e5

        outlet_pressure = max(0.0, inlet_stream.pressure_pa - dp_pa)

        # SDI protection: Cartridge filter reduces SDI to target SWRO feed levels (< 3.0)
        comp_outlet = inlet_stream.composition.model_copy()
        comp_outlet.sdi_15 = min(comp_outlet.sdi_15, 2.5)

        outlet_stream = WaterStream(
            temperature_k=inlet_stream.temperature_k,
            pressure_pa=outlet_pressure,
            mass_flow_kg_s=inlet_stream.mass_flow_kg_s,
            salinity_g_kg=inlet_stream.salinity_g_kg,
            composition=comp_outlet,
            name=f"{self.name}_Outlet"
        )

        return {
            "equivalent_10in_count": equivalent_10in_count,
            "flow_per_10in_element_m3h": round(flow_per_10in_m3h, 3),
            "pressure_drop_bar": round(dp_bar, 3),
            "outlet_sdi_15": round(comp_outlet.sdi_15, 2),
            "outlet_stream": outlet_stream
        }
