"""
DESALFLOW ENGINE - Dual Media / Granular Pressure Filter Model
Calculates filtration velocity, head loss (Ergun / Rose equation), solids loading,
and SDI / Turbidity removal efficiency.
"""

import math
from typing import Dict, Any
from desalflow.water.stream import WaterStream

class Filter:
    def __init__(
        self,
        bed_area_m2: float = 25.0,
        media_depth_m: float = 1.2,
        effective_grain_size_m: float = 0.0008, # 0.8 mm sand
        porosity: float = 0.42,
        clean_dp_bar: float = 0.15,
        turbidity_removal_pct: float = 85.0,
        name: str = "Dual Media Filter"
    ):
        self.name = name
        self.bed_area_m2 = float(bed_area_m2)
        self.media_depth_m = float(media_depth_m)
        self.effective_grain_size_m = float(effective_grain_size_m)
        self.porosity = float(porosity)
        self.clean_dp_bar = float(clean_dp_bar)
        self.turbidity_removal_pct = float(turbidity_removal_pct)

    def calculate(self, inlet_stream: WaterStream, loading_factor: float = 1.0) -> Dict[str, Any]:
        if inlet_stream.volume_flow_m3_s <= 0.0 or self.bed_area_m2 <= 0.0:
            outlet = inlet_stream.copy_with(name=f"{self.name}_Outlet")
            return {"filtration_velocity_m_h": 0.0, "pressure_drop_bar": 0.0, "outlet_stream": outlet}

        # Filtration velocity v = Q / A [m/s] -> m/h
        v_m_s = inlet_stream.volume_flow_m3_s / self.bed_area_m2
        v_m_h = v_m_s * 3600.0

        # Ergun modification for clean bed friction loss
        # Delta P = (150 * mu * (1-eps)^2 * L * v) / (eps^3 * d_p^2)
        mu = inlet_stream.viscosity_pa_s
        eps = self.porosity
        dp_ergun_pa = (150.0 * mu * ((1.0 - eps)**2) * self.media_depth_m * v_m_s) / ((eps**3) * (self.effective_grain_size_m**2))
        
        # Total DP including cake loading factor (1.0 = clean, 2.0 = dirty)
        dp_total_pa = max(self.clean_dp_bar * 1e5, dp_ergun_pa * max(1.0, loading_factor))
        dp_total_bar = dp_total_pa / 1e5

        outlet_pressure = max(0.0, inlet_stream.pressure_pa - dp_total_pa)

        # Turbidity / SDI reduction
        outlet_turbidity = inlet_stream.composition.turbidity_ntu * (1.0 - self.turbidity_removal_pct / 100.0)
        outlet_sdi = max(1.0, inlet_stream.composition.sdi_15 * 0.4)

        comp_outlet = inlet_stream.composition.model_copy()
        comp_outlet.turbidity_ntu = outlet_turbidity
        comp_outlet.sdi_15 = outlet_sdi

        outlet_stream = WaterStream(
            temperature_k=inlet_stream.temperature_k,
            pressure_pa=outlet_pressure,
            mass_flow_kg_s=inlet_stream.mass_flow_kg_s,
            salinity_g_kg=inlet_stream.salinity_g_kg,
            composition=comp_outlet,
            name=f"{self.name}_Outlet"
        )

        return {
            "filtration_velocity_m_h": round(v_m_h, 2),
            "pressure_drop_bar": round(dp_total_bar, 3),
            "inlet_turbidity_ntu": inlet_stream.composition.turbidity_ntu,
            "outlet_turbidity_ntu": round(outlet_turbidity, 2),
            "outlet_sdi_15": round(outlet_sdi, 2),
            "outlet_stream": outlet_stream
        }
