"""
DESALFLOW ENGINE - Minor Losses in Pipe Fittings
Calculates head loss through elbows, tees, reducers, expansions, entrances, exits:
Delta_P_minor = K * (0.5 * rho * v^2)
"""

from typing import Dict, Any, List
from desalflow.water.stream import WaterStream

# Typical K resistance loss coefficients
FITTING_K_FACTORS: Dict[str, float] = {
    "elbow_90_standard": 0.75,
    "elbow_90_long_radius": 0.45,
    "elbow_45_standard": 0.35,
    "tee_line_flow": 0.40,
    "tee_branch_flow": 1.50,
    "gate_valve_full_open": 0.15,
    "check_valve_swing": 2.00,
    "pipe_entrance_square": 0.50,
    "pipe_entrance_rounded": 0.05,
    "pipe_exit": 1.00,
    "reducer_conical": 0.25,
    "expansion_sudden": 1.00
}

class FittingLosses:
    def __init__(self, fittings: Dict[str, int], pipe_diameter_m: float):
        """fittings: dict mapping fitting type to count, e.g. {'elbow_90_standard': 4, 'gate_valve_full_open': 2}"""
        self.fittings = fittings
        self.pipe_diameter_m = float(pipe_diameter_m)
        self.area_m2 = (3.141592653589793 / 4.0) * (self.pipe_diameter_m ** 2)

    def calculate_total_k(self) -> float:
        total_k = 0.0
        for fitting, count in self.fittings.items():
            k_val = FITTING_K_FACTORS.get(fitting, 0.5)
            total_k += k_val * count
        return total_k

    def calculate_pressure_drop(self, stream: WaterStream) -> Dict[str, Any]:
        total_k = self.calculate_total_k()
        if stream.volume_flow_m3_s <= 0.0 or total_k <= 0.0:
            return {"total_k": total_k, "pressure_drop_pa": 0.0, "outlet_pressure_pa": stream.pressure_pa}

        velocity = stream.volume_flow_m3_s / self.area_m2
        dynamic_pressure = 0.5 * stream.density_kg_m3 * (velocity ** 2)
        dp_pa = total_k * dynamic_pressure
        outlet_p = max(0.0, stream.pressure_pa - dp_pa)

        return {
            "total_k": total_k,
            "velocity_m_s": velocity,
            "pressure_drop_pa": dp_pa,
            "pressure_drop_bar": dp_pa / 1e5,
            "outlet_pressure_pa": outlet_p,
            "outlet_pressure_bar": outlet_p / 1e5
        }
