"""
DESALFLOW ENGINE - Reynolds Number and Fluid Regime Calculations
Calculates:
- Reynolds number Re = (rho * v * D) / mu = (v * D) / nu
- Flow regime: Laminar (Re < 2300), Transitional (2300 <= Re <= 4000), Turbulent (Re > 4000)
- Darcy-Weisbach friction factor f using Swamee-Jain / Haaland / Colebrook-White
"""

import math

class ReynoldsCalculator:
    @staticmethod
    def calculate_reynolds_number(
        velocity_m_s: float,
        diameter_m: float,
        density_kg_m3: float,
        viscosity_pa_s: float
    ) -> float:
        """Re = (rho * v * D) / mu"""
        if viscosity_pa_s <= 0.0 or diameter_m <= 0.0:
            return 0.0
        return (density_kg_m3 * abs(velocity_m_s) * diameter_m) / viscosity_pa_s

    @staticmethod
    def determine_regime(reynolds: float) -> str:
        if reynolds < 2300.0:
            return "Laminar"
        elif reynolds <= 4000.0:
            return "Transitional"
        else:
            return "Turbulent"

    @staticmethod
    def darcy_friction_factor(
        reynolds: float,
        roughness_m: float,
        diameter_m: float
    ) -> float:
        """
        Calculates Darcy-Weisbach friction factor f:
        - Laminar (Re < 2300): f = 64 / Re
        - Turbulent (Re > 4000): Swamee-Jain approximation to Colebrook-White
          1/sqrt(f) = -2.0 * log10( (roughness / (3.7 * D)) + (5.74 / (Re**0.9)) )
        - Transitional: Linear interpolation between f(2300) and f(4000)
        """
        if reynolds <= 1.0:
            return 64.0

        if reynolds < 2300.0:
            return 64.0 / reynolds

        rel_roughness = roughness_m / diameter_m

        # Turbulent friction factor at Re = 4000
        def turbulent_f(re: float) -> float:
            arg = (rel_roughness / 3.7) + (5.74 / (re ** 0.9))
            return 0.25 / (math.log10(arg) ** 2)

        if reynolds > 4000.0:
            return turbulent_f(reynolds)

        # Transitional region interpolation
        f_lam = 64.0 / 2300.0
        f_turb = turbulent_f(4000.0)
        fraction = (reynolds - 2300.0) / (4000.0 - 2300.0)
        return f_lam + fraction * (f_turb - f_lam)
