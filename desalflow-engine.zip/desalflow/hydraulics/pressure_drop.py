"""
DESALFLOW ENGINE - Hydraulics Pressure Drop Aggregator
Tracks and verifies pressure balance across a hydraulic train section:
P_in - sum(pressure_losses) = P_out
"""

from typing import List, Dict, Any
from desalflow.water.stream import WaterStream

class PressureDropAggregator:
    @staticmethod
    def calculate_section_losses(
        inlet_stream: WaterStream,
        losses_dict: Dict[str, float]
    ) -> Dict[str, Any]:
        """
        losses_dict: component_name -> pressure_loss_pa
        Returns inlet, outlet, total loss, and verified pressure balance.
        """
        total_loss_pa = sum(losses_dict.values())
        outlet_pressure_pa = max(0.0, inlet_stream.pressure_pa - total_loss_pa)
        
        # Pressure balance verification
        balance_residual = inlet_stream.pressure_pa - (outlet_pressure_pa + total_loss_pa)

        return {
            "inlet_pressure_bar": inlet_stream.pressure_bar,
            "total_loss_pa": total_loss_pa,
            "total_loss_bar": total_loss_pa / 1e5,
            "outlet_pressure_bar": outlet_pressure_pa / 1e5,
            "component_breakdown_bar": {k: v / 1e5 for k, v in losses_dict.items()},
            "balance_residual_pa": balance_residual
        }
