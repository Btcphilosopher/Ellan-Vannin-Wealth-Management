"""
DESALFLOW ENGINE - Hydraulic Pipe Model
Implements Darcy-Weisbach pipe friction equation:
Delta_P_friction = f * (L / D) * (rho * v^2 / 2)
"""

import math
from typing import Dict, Any, Optional
from desalflow.water.stream import WaterStream
from desalflow.hydraulics.reynolds import ReynoldsCalculator

class Pipe:
    def __init__(
        self,
        length_m: float,
        inner_diameter_m: float,
        roughness_m: float = 4.5e-5,  # Commercial steel / stainless steel 0.045 mm
        elevation_change_m: float = 0.0,
        name: str = "Pipe"
    ):
        self.name = name
        self.length_m = float(length_m)
        self.inner_diameter_m = float(inner_diameter_m)
        self.roughness_m = float(roughness_m)
        self.elevation_change_m = float(elevation_change_m)
        self.cross_section_area_m2 = (math.pi / 4.0) * (self.inner_diameter_m ** 2)

    def calculate_pressure_drop(self, stream: WaterStream) -> Dict[str, Any]:
        """
        Calculates hydraulic friction loss and hydrostatic elevation head loss for a stream:
        Delta_P_total = Delta_P_friction + rho * g * Delta_h
        """
        if stream.volume_flow_m3_s <= 0.0:
            return {
                "velocity_m_s": 0.0,
                "reynolds": 0.0,
                "regime": "Laminar",
                "friction_factor": 0.0,
                "friction_loss_pa": 0.0,
                "hydrostatic_loss_pa": 0.0,
                "total_pressure_drop_pa": 0.0,
                "outlet_pressure_pa": stream.pressure_pa
            }

        velocity = stream.volume_flow_m3_s / self.cross_section_area_m2
        reynolds = ReynoldsCalculator.calculate_reynolds_number(
            velocity, self.inner_diameter_m, stream.density_kg_m3, stream.viscosity_pa_s
        )
        regime = ReynoldsCalculator.determine_regime(reynolds)
        f = ReynoldsCalculator.darcy_friction_factor(reynolds, self.roughness_m, self.inner_diameter_m)

        # Dynamic pressure q = 0.5 * rho * v^2
        dynamic_pressure = 0.5 * stream.density_kg_m3 * (velocity ** 2)
        dp_friction = f * (self.length_m / self.inner_diameter_m) * dynamic_pressure
        
        # Hydrostatic pressure
        g = 9.80665
        dp_hydrostatic = stream.density_kg_m3 * g * self.elevation_change_m
        
        dp_total = dp_friction + dp_hydrostatic
        outlet_pressure = max(0.0, stream.pressure_pa - dp_total)

        return {
            "velocity_m_s": velocity,
            "reynolds": reynolds,
            "regime": regime,
            "friction_factor": f,
            "friction_loss_pa": dp_friction,
            "friction_loss_bar": dp_friction / 1e5,
            "hydrostatic_loss_pa": dp_hydrostatic,
            "total_pressure_drop_pa": dp_total,
            "total_pressure_drop_bar": dp_total / 1e5,
            "outlet_pressure_pa": outlet_pressure,
            "outlet_pressure_bar": outlet_pressure / 1e5
        }
