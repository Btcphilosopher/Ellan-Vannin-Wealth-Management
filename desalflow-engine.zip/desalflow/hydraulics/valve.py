"""
DESALFLOW ENGINE - Hydraulic Valve Model
Calculates valve pressure drop from Cv coefficient or percent opening:
Q_gpm = Cv * sqrt( Delta_P_psi / SG )
Delta_P_pa = ( (Q_m3s / (Cv * 6.309e-5)) ^ 2 ) * SG * 6894.76
"""

import math
from typing import Dict, Any
from desalflow.water.stream import WaterStream

class Valve:
    def __init__(
        self,
        cv_max: float = 150.0,
        opening_fraction: float = 1.0,
        characteristic: str = "equal_percentage", # equal_percentage, linear, quick_opening
        name: str = "Valve"
    ):
        self.name = name
        self.cv_max = float(cv_max)
        self.opening_fraction = max(0.01, min(1.0, float(opening_fraction)))
        self.characteristic = characteristic

    def get_effective_cv(self) -> float:
        x = self.opening_fraction
        if self.characteristic == "linear":
            return self.cv_max * x
        elif self.characteristic == "quick_opening":
            return self.cv_max * math.sqrt(x)
        else: # equal percentage (R = 50)
            r = 50.0
            return self.cv_max * (r ** (x - 1.0))

    def calculate_pressure_drop(self, stream: WaterStream) -> Dict[str, Any]:
        cv = self.get_effective_cv()
        if stream.volume_flow_m3_s <= 0.0 or cv <= 0.0:
            return {
                "effective_cv": cv,
                "pressure_drop_pa": 0.0,
                "outlet_pressure_pa": stream.pressure_pa
            }

        # Specific gravity SG = rho / rho_water_ref
        sg = stream.density_kg_m3 / 998.2
        q_gpm = stream.volume_flow_m3_s / 6.30901964e-5
        
        # Delta P in psi = SG * (Q_gpm / Cv)^2
        dp_psi = sg * ((q_gpm / cv) ** 2)
        dp_pa = dp_psi * 6894.757293168
        outlet_p = max(0.0, stream.pressure_pa - dp_pa)

        return {
            "effective_cv": cv,
            "opening_fraction": self.opening_fraction,
            "pressure_drop_pa": dp_pa,
            "pressure_drop_bar": dp_pa / 1e5,
            "outlet_pressure_pa": outlet_p,
            "outlet_pressure_bar": outlet_p / 1e5
        }
