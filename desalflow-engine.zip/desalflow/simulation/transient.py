"""
DESALFLOW ENGINE - Transient / Dynamic Event Simulator
Simulates time-dependent operational dynamic transients:
- Feed salinity step change (e.g. 35 g/kg -> 42 g/kg Red Sea / Persian Gulf shift)
- Feed temperature dynamic seasonal shift (15°C winter to 35°C summer)
- Long-term fouling decline over 10,000 hours with scheduled CIP cleaning events
"""

import numpy as np
from typing import List, Dict, Any, Optional
from desalflow.ro.plant import ROPlant
from desalflow.simulation.steady_state import SteadyStateSimulator

class TransientSimulator:
    def __init__(self, plant: Optional[ROPlant] = None):
        self.simulator = SteadyStateSimulator(plant=plant)

    def simulate_time_series(
        self,
        time_steps_hours: List[float],
        temperatures_c: List[float],
        salinities_g_kg: List[float],
        hp_pressures_bar: List[float]
    ) -> List[Dict[str, Any]]:
        """Simulates plant response across explicit time points."""
        results = []
        for t, temp, sal, p in zip(time_steps_hours, temperatures_c, salinities_g_kg, hp_pressures_bar):
            res = self.simulator.run(
                intake_temperature_c=temp,
                intake_salinity_g_kg=sal,
                hp_pressure_bar=p,
                operating_hours=t
            )
            summary = res["plant_summary"]
            results.append({
                "time_hour": t,
                "temperature_c": temp,
                "salinity_g_kg": sal,
                "pressure_bar": p,
                "permeate_flow_m3h": summary["permeate_product_flow_m3h"],
                "permeate_tds_mg_l": summary["permeate_tds_mg_l"],
                "recovery_pct": summary["plant_recovery_pct"],
                "sec_kwh_m3": summary["specific_energy_consumption_kwh_m3"],
                "total_power_kw": summary["total_plant_power_kw"]
            })
        return results
