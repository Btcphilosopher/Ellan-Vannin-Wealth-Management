"""
DESALFLOW ENGINE - Steady-State Simulator
Runs full plant convergence loops, verifies mass, salt, and energy conservation laws.
"""

from typing import Dict, Any, Optional
from desalflow.water.stream import WaterStream
from desalflow.ro.plant import ROPlant
from desalflow.balances.water import MassBalanceValidator
from desalflow.balances.salt import SaltBalanceValidator
from desalflow.balances.energy import EnergyBalanceValidator

class SteadyStateSimulator:
    def __init__(self, plant: Optional[ROPlant] = None):
        self.plant = plant if plant is not None else ROPlant()

    def run(
        self,
        intake_temperature_c: float = 25.0,
        intake_salinity_g_kg: float = 35.0,
        intake_flow_m3h: float = 2000.0,
        hp_pressure_bar: float = 65.0,
        operating_hours: float = 0.0
    ) -> Dict[str, Any]:
        """Runs full plant steady-state simulation."""
        # Update plant operating pressure
        self.plant.target_hp_pressure_bar = hp_pressure_bar

        # Create intake stream
        intake_stream = WaterStream(
            temperature_k=273.15 + intake_temperature_c,
            pressure_pa=101325.0 + 2.0e5, # Intake pump pressure 2 bar gauge
            volume_flow_m3_s=intake_flow_m3h / 3600.0,
            salinity_g_kg=intake_salinity_g_kg,
            name="Raw_Seawater_Intake"
        )

        # Solve plant topology
        plant_results = self.plant.solve_plant(
            raw_intake_stream=intake_stream,
            operating_hours=operating_hours
        )

        product_perm = plant_results["product_permeate"]
        brine_disch = plant_results["brine_discharge"]

        # Validate Conservation Balances
        mass_val = MassBalanceValidator.validate(
            inlet_streams=[intake_stream],
            outlet_streams=[product_perm, brine_disch]
        )

        salt_val = SaltBalanceValidator.validate(
            inlet_streams=[intake_stream],
            outlet_streams=[product_perm, brine_disch]
        )

        energy_val = EnergyBalanceValidator.calculate_sec(
            total_electrical_power_kw=plant_results["total_plant_power_kw"],
            product_flow_m3_h=product_perm.volume_flow_m3_h
        )

        summary = plant_results.copy()
        summary["product_permeate"] = product_perm.to_dict()
        summary["brine_discharge"] = brine_disch.to_dict()
        if "single_train_sample" in summary:
            st = summary["single_train_sample"].copy()
            if "final_permeate" in st and hasattr(st["final_permeate"], "to_dict"):
                st["final_permeate"] = st["final_permeate"].to_dict()
            if "final_brine" in st and hasattr(st["final_brine"], "to_dict"):
                st["final_brine"] = st["final_brine"].to_dict()
            if "train_permeate" in st and hasattr(st["train_permeate"], "to_dict"):
                st["train_permeate"] = st["train_permeate"].to_dict()
            if "vessel_results" in st:
                # Remove non-serializable vessel stream objects
                st["vessel_results"] = [
                    {
                        "vessel_index": vr.get("vessel_index"),
                        "stage_index": vr.get("stage_index"),
                        "vessel_recovery_pct": vr.get("vessel_recovery_pct"),
                        "vessel_permeate_tds_mg_l": vr.get("vessel_permeate_tds_mg_l"),
                        "vessel_pressure_drop_bar": vr.get("vessel_pressure_drop_bar")
                    }
                    for vr in st["vessel_results"]
                ]
            summary["single_train_sample"] = st

        return {
            "simulation_type": "Steady-State Physics Simulation",
            "plant_summary": summary,
            "conservation_balances": {
                "mass_balance": mass_val,
                "salt_balance": salt_val,
                "energy_balance": energy_val
            }
        }
