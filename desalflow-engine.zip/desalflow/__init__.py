"""
DESALFLOW ENGINE
Hard-engineering desalination process and numerical equipment calculation engine.
Physics, conservation laws, numerical methods, and explicit engineering assumptions.
"""

__version__ = "1.0.0"
__author__ = "DESALFLOW Engineering Team"

from desalflow.core.units import Units
from desalflow.core.results import EngineeringResult, SimulationState
from desalflow.water.stream import WaterStream
from desalflow.water.chemistry import WaterComposition
from desalflow.water.properties import SeawaterProperties
from desalflow.water.osmotic import OsmoticPressureModel
from desalflow.membranes.membrane import MembraneSpecification
from desalflow.membranes.transport import SolutionDiffusionModel
from desalflow.ro.element import MembraneElement
from desalflow.ro.vessel import PressureVessel
from desalflow.ro.stage import ROStage
from desalflow.ro.train import ROTrain
from desalflow.ro.plant import ROPlant
from desalflow.pumps.pump import HighPressurePump
from desalflow.energy_recovery.pressure_exchanger import PressureExchanger

__all__ = [
    "Units",
    "EngineeringResult",
    "SimulationState",
    "WaterStream",
    "WaterComposition",
    "SeawaterProperties",
    "OsmoticPressureModel",
    "MembraneSpecification",
    "SolutionDiffusionModel",
    "MembraneElement",
    "PressureVessel",
    "ROStage",
    "ROTrain",
    "ROPlant",
    "HighPressurePump",
    "PressureExchanger",
]
