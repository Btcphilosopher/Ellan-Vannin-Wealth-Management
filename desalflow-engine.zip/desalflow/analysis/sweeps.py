"""
DESALFLOW ENGINE - Parametric Sweep Generator
Generates grid sweeps over feed salinity (25 to 50 g/kg), feed temperature (10 to 40 °C),
and operating feed pressure (50 to 80 bar).
"""

import numpy as np
from typing import List, Dict, Any
from desalflow.simulation.steady_state import SteadyStateSimulator

class ParametricSweepGenerator:
    @staticmethod
    def pressure_sweep(
        pressures_bar: List[float],
        temp_c: float = 25.0,
        salinity_g_kg: float = 35.0,
        intake_flow_m3h: float = 2000.0
    ) -> List[Dict[str, Any]]:
        sim = SteadyStateSimulator()
        sweep_data = []

        for p in pressures_bar:
            res = sim.run(
                intake_temperature_c=temp_c,
                intake_salinity_g_kg=salinity_g_kg,
                intake_flow_m3h=intake_flow_m3h,
                hp_pressure_bar=p
            )["plant_summary"]

            sweep_data.append({
                "pressure_bar": p,
                "permeate_flow_m3h": res["permeate_product_flow_m3h"],
                "permeate_tds_mg_l": res["permeate_tds_mg_l"],
                "recovery_pct": res["plant_recovery_pct"],
                "sec_kwh_m3": res["specific_energy_consumption_kwh_m3"],
                "total_power_kw": res["total_plant_power_kw"]
            })

        return sweep_data

    @staticmethod
    def temperature_sweep(
        temperatures_c: List[float],
        p_bar: float = 65.0,
        salinity_g_kg: float = 35.0,
        intake_flow_m3h: float = 2000.0
    ) -> List[Dict[str, Any]]:
        sim = SteadyStateSimulator()
        sweep_data = []

        for t in temperatures_c:
            res = sim.run(
                intake_temperature_c=t,
                intake_salinity_g_kg=salinity_g_kg,
                intake_flow_m3h=intake_flow_m3h,
                hp_pressure_bar=p_bar
            )["plant_summary"]

            sweep_data.append({
                "temperature_c": t,
                "permeate_flow_m3h": res["permeate_product_flow_m3h"],
                "permeate_tds_mg_l": res["permeate_tds_mg_l"],
                "recovery_pct": res["plant_recovery_pct"],
                "sec_kwh_m3": res["specific_energy_consumption_kwh_m3"]
            })

        return sweep_data
