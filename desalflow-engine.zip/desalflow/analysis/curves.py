"""
DESALFLOW ENGINE - Performance Mapping & Matplotlib Exporter
Generates publication-quality technical performance curves and exports data arrays / PNG plots.
"""

import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from typing import Dict, Any, List
from desalflow.analysis.sweeps import ParametricSweepGenerator

class PerformanceCurvePlotter:
    @staticmethod
    def generate_swro_performance_map(
        output_filepath: str = "swro_performance_map.png"
    ) -> str:
        """
        Generates 2x2 subplot grid of SWRO plant behavior:
        1. Pressure vs Permeate Flow & Recovery
        2. Pressure vs SEC (kWh/m³)
        3. Temperature vs Permeate TDS & Flux
        4. Pressure vs Permeate Quality (TDS)
        """
        pressures = [52.0, 56.0, 60.0, 64.0, 68.0, 72.0, 76.0]
        p_sweep = ParametricSweepGenerator.pressure_sweep(pressures)

        temps = [12.0, 18.0, 24.0, 30.0, 36.0, 42.0]
        t_sweep = ParametricSweepGenerator.temperature_sweep(temps)

        p_vals = [d["pressure_bar"] for d in p_sweep]
        q_perm = [d["permeate_flow_m3h"] for d in p_sweep]
        rec_pct = [d["recovery_pct"] for d in p_sweep]
        sec_vals = [d["sec_kwh_m3"] for d in p_sweep]
        tds_vals = [d["permeate_tds_mg_l"] for d in p_sweep]

        fig, axs = plt.subplots(2, 2, figsize=(11, 8), dpi=150)
        fig.suptitle("DESALFLOW ENGINE - SWRO Plant Performance Curves", fontsize=14, fontweight="bold")

        # Plot 1: Pressure vs Flow & Recovery
        ax1 = axs[0, 0]
        ax1.plot(p_vals, q_perm, 'b-o', label="Permeate Flow (m³/h)")
        ax1.set_xlabel("Feed Pressure (bar)")
        ax1.set_ylabel("Permeate Flow (m³/h)", color='b')
        ax1.grid(True, linestyle="--", alpha=0.6)
        
        ax1_twin = ax1.twinx()
        ax1_twin.plot(p_vals, rec_pct, 'g--s', label="Recovery (%)")
        ax1_twin.set_ylabel("Recovery (%)", color='g')

        # Plot 2: Pressure vs SEC
        ax2 = axs[0, 1]
        ax2.plot(p_vals, sec_vals, 'r-^', linewidth=2)
        ax2.set_xlabel("Feed Pressure (bar)")
        ax2.set_ylabel("SEC (kWh/m³)")
        ax2.set_title("Specific Energy Consumption")
        ax2.grid(True, linestyle="--", alpha=0.6)

        # Plot 3: Temperature vs TDS
        t_vals = [d["temperature_c"] for d in t_sweep]
        t_tds = [d["permeate_tds_mg_l"] for d in t_sweep]
        ax3 = axs[1, 0]
        ax3.plot(t_vals, t_tds, 'm-d', linewidth=2)
        ax3.set_xlabel("Feed Temperature (°C)")
        ax3.set_ylabel("Permeate TDS (mg/L)")
        ax3.set_title("Temperature Pass-Through Effect")
        ax3.grid(True, linestyle="--", alpha=0.6)

        # Plot 4: Pressure vs TDS
        ax4 = axs[1, 1]
        ax4.plot(p_vals, tds_vals, 'c-h', linewidth=2)
        ax4.set_xlabel("Feed Pressure (bar)")
        ax4.set_ylabel("Permeate TDS (mg/L)")
        ax4.set_title("Salt Passage Rejection Trend")
        ax4.grid(True, linestyle="--", alpha=0.6)

        plt.tight_layout()
        plt.savefig(output_filepath)
        plt.close()

        return output_filepath
