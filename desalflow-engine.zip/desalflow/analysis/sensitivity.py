"""
DESALFLOW ENGINE - Numerical Sensitivity Analysis
Calculates finite-difference numerical partial derivatives:
- d(Permeate_Flow) / d(Pressure)
- d(SEC) / d(Salinity)
- d(Permeate_TDS) / d(Temperature)
"""

from typing import Dict, Any
from desalflow.simulation.steady_state import SteadyStateSimulator

class SensitivityAnalyzer:
    @staticmethod
    def calculate_sensitivities(
        base_pressure_bar: float = 65.0,
        base_temp_c: float = 25.0,
        base_salinity_g_kg: float = 35.0,
        intake_flow_m3h: float = 2000.0
    ) -> Dict[str, Any]:
        sim = SteadyStateSimulator()

        # Base case
        base = sim.run(base_temp_c, base_salinity_g_kg, intake_flow_m3h, base_pressure_bar)["plant_summary"]

        # Perturb Pressure by +1.0 bar
        p_plus = sim.run(base_temp_c, base_salinity_g_kg, intake_flow_m3h, base_pressure_bar + 1.0)["plant_summary"]
        
        # Perturb Temperature by +1.0 °C
        t_plus = sim.run(base_temp_c + 1.0, base_salinity_g_kg, intake_flow_m3h, base_pressure_bar)["plant_summary"]

        # Perturb Salinity by +1.0 g/kg
        s_plus = sim.run(base_temp_c, base_salinity_g_kg + 1.0, intake_flow_m3h, base_pressure_bar)["plant_summary"]

        # Finite difference derivatives
        dp_dP = (p_plus["permeate_product_flow_m3h"] - base["permeate_product_flow_m3h"]) / 1.0
        dsec_dS = (s_plus["specific_energy_consumption_kwh_m3"] - base["specific_energy_consumption_kwh_m3"]) / 1.0
        dtds_dT = (t_plus["permeate_tds_mg_l"] - base["permeate_tds_mg_l"]) / 1.0

        return {
            "d_permeate_flow_d_pressure": round(dp_dP, 2), # [m³/h per bar]
            "d_sec_d_salinity": round(dsec_dS, 3),          # [kWh/m³ per g/kg]
            "d_permeate_tds_d_temperature": round(dtds_dT, 2) # [mg/L per °C]
        }
