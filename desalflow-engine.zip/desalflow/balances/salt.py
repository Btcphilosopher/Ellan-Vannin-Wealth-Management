"""
DESALFLOW ENGINE - Salt Solute Mass Balance Validator
Enforces solute mass conservation:
m_salt_in - ( sum(m_salt_out) ) = Residual Error [kg/s]
m_salt = m_stream * (salinity_g_kg / 1000)
"""

from typing import List, Dict, Any
from desalflow.water.stream import WaterStream

class SaltBalanceValidator:
    @staticmethod
    def validate(
        inlet_streams: List[WaterStream],
        outlet_streams: List[WaterStream],
        tolerance_rel: float = 1e-4
    ) -> Dict[str, Any]:
        salt_in = sum(s.salt_mass_flow_kg_s for s in inlet_streams)
        salt_out = sum(s.salt_mass_flow_kg_s for s in outlet_streams)
        
        residual = salt_in - salt_out
        rel_error = abs(residual) / max(1e-9, salt_in)
        is_balanced = rel_error <= tolerance_rel

        return {
            "total_salt_in_kg_s": salt_in,
            "total_salt_out_kg_s": salt_out,
            "residual_kg_s": residual,
            "relative_error": rel_error,
            "is_balanced": is_balanced,
            "status": "CONSERVED" if is_balanced else f"SALT VIOLATION (Error: {rel_error:.2e})"
        }
