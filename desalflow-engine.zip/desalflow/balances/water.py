"""
DESALFLOW ENGINE - Mass / Volumetric Conservation Validator
Enforces total mass balance conservation law:
m_in - ( sum(m_out) ) = Residual Error [kg/s]
Relative Error = |Residual| / m_in
Validation threshold < 1e-6 relative tolerance.
"""

from typing import List, Dict, Any
from desalflow.water.stream import WaterStream

class MassBalanceValidator:
    @staticmethod
    def validate(
        inlet_streams: List[WaterStream],
        outlet_streams: List[WaterStream],
        tolerance_rel: float = 1e-5
    ) -> Dict[str, Any]:
        total_m_in = sum(s.mass_flow_kg_s for s in inlet_streams)
        total_m_out = sum(s.mass_flow_kg_s for s in outlet_streams)
        
        residual = total_m_in - total_m_out
        rel_error = abs(residual) / max(1e-9, total_m_in)
        is_balanced = rel_error <= tolerance_rel

        return {
            "total_mass_in_kg_s": total_m_in,
            "total_mass_out_kg_s": total_m_out,
            "residual_kg_s": residual,
            "relative_error": rel_error,
            "is_balanced": is_balanced,
            "status": "CONSERVED" if is_balanced else f"VIOLATION (Error: {rel_error:.2e})"
        }
