"""
DESALFLOW ENGINE - Energy & Power Balance
Calculates thermodynamic energy balance and Specific Energy Consumption (SEC):
Power_in = P_pumps - P_erd_recovered [kW]
SEC = Power_in / Permeate_Flow_m3h [kWh/m³]
"""

from typing import Dict, Any

class EnergyBalanceValidator:
    @staticmethod
    def calculate_sec(
        total_electrical_power_kw: float,
        product_flow_m3_h: float
    ) -> Dict[str, Any]:
        if product_flow_m3_h <= 0.0:
            return {"sec_kwh_m3": 0.0, "total_power_kw": total_electrical_power_kw}
            
        sec = total_electrical_power_kw / product_flow_m3_h
        return {
            "sec_kwh_m3": round(sec, 3),
            "total_power_kw": round(total_electrical_power_kw, 1),
            "product_flow_m3h": round(product_flow_m3_h, 1),
            "product_flow_m3d": round(product_flow_m3_h * 24.0, 1)
        }
