"""
DESALFLOW ENGINE - Physics Validation and Bounds Checking
Ensures all operating conditions and physical parameters satisfy thermodynamic,
hydraulic, and mechanical limits. Rejects unphysical scenarios.
"""

from typing import List

class ValidationError(Exception):
    """Raised when an engineering model receives unphysical or out-of-bounds parameters."""
    pass

class BalanceError(Exception):
    """Raised when conservation of mass, salt, or energy is violated beyond tolerance."""
    pass

class SolverError(Exception):
    """Raised when a numerical non-linear solver fails to converge."""
    pass

class ParameterValidator:
    @staticmethod
    def validate_water_state(temperature_k: float, pressure_pa: float, salinity_g_kg: float):
        if temperature_k < 273.15 - 5.0: # Allow slight subcooling down to freezing point
            raise ValidationError(f"Temperature {temperature_k} K is below seawater freezing threshold (~271 K).")
        if temperature_k > 373.15 + 50.0:
            raise ValidationError(f"Temperature {temperature_k} K is beyond liquid operating range.")
        if pressure_pa < 0.0:
            raise ValidationError(f"Absolute pressure {pressure_pa} Pa cannot be negative.")
        if salinity_g_kg < 0.0:
            raise ValidationError(f"Salinity {salinity_g_kg} g/kg cannot be negative.")
        if salinity_g_kg > 200.0:
            raise ValidationError(f"Salinity {salinity_g_kg} g/kg exceeds saturation/crystallization limit for RO simulation.")

    @staticmethod
    def validate_membrane_element(area_m2: float, a_coeff: float, b_coeff: float):
        if area_m2 <= 0.0:
            raise ValidationError(f"Membrane active area must be positive, got {area_m2} m².")
        if a_coeff <= 0.0:
            raise ValidationError(f"Water permeability A must be positive, got {a_coeff} m/(s·Pa).")
        if b_coeff < 0.0:
            raise ValidationError(f"Salt permeability B cannot be negative, got {b_coeff} m/s.")
