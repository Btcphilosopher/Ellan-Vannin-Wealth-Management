"""
DESALFLOW ENGINE - Core Units System
All internal calculations use SI base/derived units:
- Pressure: Pa
- Temperature: K
- Mass flow: kg/s
- Volume flow: m³/s
- Density: kg/m³
- Dynamic Viscosity: Pa·s
- Power: W
- Energy: J
- Length / Diameter: m
- Area: m²
- Salinity: g/kg (dimensionless mass fraction * 1000)
- Concentration: kg/m³ or mol/m³
"""

from typing import Union, Dict, Any

class Units:
    # Pressure conversions to/from Pa
    @staticmethod
    def bar_to_pa(bar: float) -> float:
        return bar * 1e5

    @staticmethod
    def pa_to_bar(pa: float) -> float:
        return pa / 1e5

    @staticmethod
    def mpa_to_pa(mpa: float) -> float:
        return mpa * 1e6

    @staticmethod
    def pa_to_mpa(pa: float) -> float:
        return pa / 1e6

    @staticmethod
    def psi_to_pa(psi: float) -> float:
        return psi * 6894.757293168

    @staticmethod
    def pa_to_psi(pa: float) -> float:
        return pa / 6894.757293168

    # Temperature conversions to/from K
    @staticmethod
    def c_to_k(celsius: float) -> float:
        if celsius < -273.15:
            raise ValueError(f"Temperature {celsius}°C is below absolute zero.")
        return celsius + 273.15

    @staticmethod
    def k_to_c(kelvin: float) -> float:
        if kelvin < 0.0:
            raise ValueError(f"Temperature {kelvin} K is below absolute zero.")
        return kelvin - 273.15

    # Volumetric flow conversions to/from m³/s
    @staticmethod
    def m3h_to_m3s(m3h: float) -> float:
        return m3h / 3600.0

    @staticmethod
    def m3s_to_m3h(m3s: float) -> float:
        return m3s * 3600.0

    @staticmethod
    def ls_to_m3s(ls: float) -> float:
        return ls / 1000.0

    @staticmethod
    def m3s_to_ls(m3s: float) -> float:
        return m3s * 1000.0

    @staticmethod
    def m3d_to_m3s(m3d: float) -> float:
        return m3d / 86400.0

    @staticmethod
    def m3s_to_m3d(m3s: float) -> float:
        return m3s * 86400.0

    @staticmethod
    def gpm_to_m3s(gpm: float) -> float:
        return gpm * 6.30901964e-5

    @staticmethod
    def m3s_to_gpm(m3s: float) -> float:
        return m3s / 6.30901964e-5

    # Power conversions to/from W
    @staticmethod
    def kw_to_w(kw: float) -> float:
        return kw * 1000.0

    @staticmethod
    def w_to_kw(w: float) -> float:
        return w / 1000.0

    @staticmethod
    def mw_to_w(mw: float) -> float:
        return mw * 1e6

    @staticmethod
    def w_to_mw(w: float) -> float:
        return w / 1e6

    @staticmethod
    def hp_to_w(hp: float) -> float:
        return hp * 745.699872

    # Specific Energy Consumption
    @staticmethod
    def sec_j_per_m3_to_kwh_per_m3(j_per_m3: float) -> float:
        return j_per_m3 / 3.6e6

    @staticmethod
    def sec_kwh_per_m3_to_j_per_m3(kwh_per_m3: float) -> float:
        return kwh_per_m3 * 3.6e6

    # Water flux conversions (m/s to LMH: L/(m²·h))
    @staticmethod
    def lmh_to_ms(lmh: float) -> float:
        # 1 L/(m²·h) = 1e-3 m³ / (m² · 3600 s) = 1 / 3.6e6 m/s
        return lmh / 3.6e6

    @staticmethod
    def ms_to_lmh(ms: float) -> float:
        return ms * 3.6e6

    # Membrane permeability A: m/(s·Pa) to LMH/bar or m³/(m²·s·Pa)
    @staticmethod
    def lmh_per_bar_to_si(a_lmh_bar: float) -> float:
        # A in LMH/bar -> (1/3.6e6 m/s) / 1e5 Pa = 1 / 3.6e11 m/(s·Pa)
        return a_lmh_bar / 3.6e11

    @staticmethod
    def si_to_lmh_per_bar(a_si: float) -> float:
        return a_si * 3.6e11

    # Solute permeability B: m/s to LMH or μm/s
    @staticmethod
    def lmh_to_b_si(b_lmh: float) -> float:
        return b_lmh / 3.6e6

    @staticmethod
    def b_si_to_lmh(b_si: float) -> float:
        return b_si * 3.6e6

    # Concentration conversions
    @staticmethod
    def mg_l_to_kg_m3(mg_l: float) -> float:
        return mg_l / 1000.0

    @staticmethod
    def kg_m3_to_mg_l(kg_m3: float) -> float:
        return kg_m3 * 1000.0

    @staticmethod
    def g_l_to_kg_m3(g_l: float) -> float:
        return g_l

    @staticmethod
    def kg_m3_to_g_l(kg_m3: float) -> float:
        return kg_m3
