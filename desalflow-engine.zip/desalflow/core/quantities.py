"""
DESALFLOW ENGINE - Engineering Quantities and Dimensional Validation
Provides type-safe dimensional verification for SI engineering equations.
"""

from typing import Dict, Any, Optional

class DimensionalCheck:
    """Verifies that mathematical operations conform to dimensional consistency."""
    
    @staticmethod
    def assert_temperature_kelvin(val: float, name: str = "temperature"):
        if val < 0.0:
            raise ValueError(f"Thermodynamic violation: {name} = {val} K is below absolute zero (0 K).")
        if val < 250.0 or val > 380.0:
            # Physical liquid water range check
            pass

    @staticmethod
    def assert_positive_pressure(val: float, name: str = "pressure"):
        if val < 0.0:
            raise ValueError(f"Hydraulic violation: Absolute {name} = {val} Pa cannot be negative.")

    @staticmethod
    def assert_non_negative_flow(val: float, name: str = "flow"):
        if val < 0.0:
            raise ValueError(f"Mass balance violation: {name} = {val} cannot be negative.")

    @staticmethod
    def assert_fraction(val: float, name: str = "recovery", min_val: float = 0.0, max_val: float = 1.0):
        if not (min_val <= val <= max_val):
            raise ValueError(f"Engineering bounds violation: {name} = {val} must be in [{min_val}, {max_val}].")
