"""
DESALFLOW ENGINE - Engineering Result Objects
Captures every physical output with explicit value, unit, governing equation,
model fidelity, input dependencies, assumptions, and validity boundaries.
"""

from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field

class EngineeringResult(BaseModel):
    name: str
    value: float
    unit: str
    equation: str
    model: str
    fidelity: str = "Level 2 - Detailed Process Model"
    assumptions: List[str] = Field(default_factory=list)
    input_dependencies: Dict[str, Any] = Field(default_factory=dict)
    validity_range: str = "Unrestricted"
    uncertainty_pct: Optional[float] = None
    warnings: List[str] = Field(default_factory=list)

    def to_display_string(self) -> str:
        return f"{self.name}: {self.value:.4g} {self.unit} [{self.model}]"

class EquipmentState(BaseModel):
    equipment_id: str
    equipment_type: str
    status: str = "OK"
    inlet_pressure_bar: float
    outlet_pressure_bar: float
    pressure_drop_bar: float
    inlet_flow_m3h: float
    outlet_flow_m3h: float
    power_kw: float = 0.0
    efficiency: float = 1.0
    metrics: Dict[str, float] = Field(default_factory=dict)
    warnings: List[str] = Field(default_factory=list)

class SimulationState(BaseModel):
    plant_name: str
    timestamp: str
    converged: bool
    iterations: int
    residual_norm: float
    solver_tolerance: float
    
    # Global stream summaries
    feed_flow_m3h: float
    feed_pressure_bar: float
    feed_temperature_c: float
    feed_salinity_g_kg: float
    feed_tds_mg_l: float
    
    permeate_flow_m3h: float
    permeate_salinity_g_kg: float
    permeate_tds_mg_l: float
    
    concentrate_flow_m3h: float
    concentrate_salinity_g_kg: float
    concentrate_tds_mg_l: float
    concentrate_pressure_bar: float
    
    recovery_ratio: float
    salt_rejection_pct: float
    
    # Energy
    hpp_electrical_power_kw: float
    booster_electrical_power_kw: float
    erd_power_recovered_kw: float
    pretreatment_power_kw: float
    auxiliary_power_kw: float
    total_electrical_power_kw: float
    sec_kwh_per_m3: float
    
    # Conservation Balances
    water_balance_error_pct: float
    salt_balance_error_pct: float
    energy_balance_error_pct: float
    
    # Element / Stage Profiles
    vessel_profiles: List[Dict[str, Any]] = Field(default_factory=list)
    equipment_states: List[EquipmentState] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    assumptions: List[str] = Field(default_factory=list)
