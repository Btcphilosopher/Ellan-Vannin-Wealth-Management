"""
DESALFLOW ENGINE - Numerical Solver Engine
Exposes explicit nonlinear solvers (SciPy root, brentq, least_squares) with full
telemetry on convergence, residuals, iteration counts, and convergence diagnostics.
"""

from typing import Callable, Any, Dict, Optional, Tuple
import numpy as np
from scipy import optimize
from desalflow.core.validation import SolverError

class SolverDiagnostics:
    def __init__(self):
        self.iterations = 0
        self.function_evaluations = 0
        self.residual_history = []
        self.converged = False
        self.message = ""

class NumericalSolver:
    @staticmethod
    def solve_1d_root(
        f: Callable[[float], float],
        bracket: Tuple[float, float],
        xtol: float = 1e-8,
        rtol: float = 1e-8,
        maxiter: int = 100,
        name: str = "1D Root"
    ) -> float:
        """Solves single-variable bracketed root using Brent's method."""
        a, b = bracket
        fa, fb = f(a), f(b)
        if fa * fb > 0:
            # Try to expand bracket slightly
            raise SolverError(f"Root not bracketed for {name}: f({a})={fa:.4e}, f({b})={fb:.4e}")
        
        res = optimize.root_scalar(f, bracket=bracket, method='brentq', xtol=xtol, rtol=rtol, maxiter=maxiter)
        if not res.converged:
            raise SolverError(f"Solver failed to converge for {name}: {res.flag}")
        return float(res.root)

    @staticmethod
    def solve_multivariate_root(
        f: Callable[[np.ndarray], np.ndarray],
        x0: np.ndarray,
        tol: float = 1e-6,
        maxiter: int = 150,
        method: str = "hybr",
        name: str = "Multivariate System"
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Solves system of non-linear equations using modified Powell/Levenberg-Marquardt."""
        sol = optimize.root(f, x0, method=method, tol=tol, options={'maxfev': maxiter * (len(x0) + 1)})
        diagnostics = {
            'converged': bool(sol.success),
            'iterations': int(sol.get('nfev', 0)),
            'residual_norm': float(np.linalg.norm(sol.fun)),
            'message': str(sol.message),
            'name': name
        }
        if not sol.success:
            # Attempt fallback with Levenberg-Marquardt / least_squares
            ls_sol = optimize.least_squares(f, x0, ftol=tol, xtol=tol, gtol=tol, max_nfev=maxiter * 10)
            diagnostics['converged'] = bool(ls_sol.success)
            diagnostics['iterations'] = int(ls_sol.nfev)
            diagnostics['residual_norm'] = float(np.linalg.norm(ls_sol.fun))
            diagnostics['message'] = str(ls_sol.message)
            if not ls_sol.success and diagnostics['residual_norm'] > 1e-3:
                raise SolverError(f"Multivariate solver '{name}' failed to converge. Residual norm: {diagnostics['residual_norm']:.4e}. {diagnostics['message']}")
            return ls_sol.x, diagnostics

        return sol.x, diagnostics
