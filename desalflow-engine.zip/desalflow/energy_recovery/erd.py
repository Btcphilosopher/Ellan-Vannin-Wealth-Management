"""
DESALFLOW ENGINE - Base Energy Recovery Device (ERD) Class
Supports isobaric pressure exchangers (PX) and hydraulic turbochargers/turbines (Pelton wheel).
"""

from typing import Dict, Any, Optional
from desalflow.core.units import Units
from desalflow.water.stream import WaterStream

class BaseERD:
    def __init__(
        self,
        efficiency: float = 0.95,
        name: str = "Energy Recovery Device"
    ):
        self.name = name
        self.efficiency = float(efficiency)

    def calculate(
        self,
        hp_brine_stream: WaterStream,
        lp_feed_stream: WaterStream
    ) -> Dict[str, Any]:
        raise NotImplementedError
