"""
DESALFLOW ENGINE - Isobaric Pressure Exchanger (PX) Model
Models pressure transfer efficiency, volumetric flow mismatch/overshift,
lubrication leakage, and high-pressure brine / low-pressure feed volumetric mixing.

High-Pressure Brine (HP_Brine) + Low-Pressure Feed (LP_Feed)
--> High-Pressure Boosted Feed (HP_Feed) + Low-Pressure Brine Discharge (LP_Brine)
"""

from typing import Dict, Any
from desalflow.core.units import Units
from desalflow.water.stream import WaterStream
from desalflow.energy_recovery.erd import BaseERD

class PressureExchanger(BaseERD):
    def __init__(
        self,
        pressure_transfer_efficiency: float = 0.96, # 96% PX pressure transfer efficiency
        volumetric_mixing_pct: float = 0.8,         # 0.8% volumetric mixing of brine into feed
        high_pressure_lubrication_leakage_pct: float = 0.5, # 0.5% internal leakage
        name: str = "PX Isobaric Pressure Exchanger"
    ):
        super().__init__(efficiency=pressure_transfer_efficiency, name=name)
        self.volumetric_mixing_pct = float(volumetric_mixing_pct)
        self.lubrication_leakage_pct = float(high_pressure_lubrication_leakage_pct)

    def calculate(
        self,
        hp_brine_stream: WaterStream,
        lp_feed_stream: WaterStream
    ) -> Dict[str, Any]:
        """
        Calculates pressure exchanger performance:
        1. HP Brine transfers hydraulic pressure to LP Feed
        2. HP Boosted Feed pressure P_boosted = P_lp_in + efficiency * (P_hp_brine - P_lp_in) - delta_P_px_friction
        3. Energy recovered = Q_hp_brine * (P_hp_brine - P_lp_discharge) * efficiency [kW]
        """
        if hp_brine_stream.volume_flow_m3_s <= 0.0 or lp_feed_stream.volume_flow_m3_s <= 0.0:
            return {
                "hp_boosted_feed_pressure_bar": lp_feed_stream.pressure_bar,
                "power_recovered_kw": 0.0,
                "hp_feed_outlet_stream": lp_feed_stream,
                "lp_brine_outlet_stream": hp_brine_stream
            }

        # Available pressure differential
        dp_available_pa = hp_brine_stream.pressure_pa - lp_feed_stream.pressure_pa
        
        # Boosted feed pressure output from PX
        dp_transferred_pa = self.efficiency * dp_available_pa
        p_hp_feed_outlet_pa = lp_feed_stream.pressure_pa + dp_transferred_pa - 0.8e5 # Subtract internal friction ~0.8 bar

        # Volumetric mixing salinity adjustment on boosted feed
        mixing_fraction = self.volumetric_mixing_pct / 100.0
        salinity_boosted_feed = (1.0 - mixing_fraction) * lp_feed_stream.salinity_g_kg + mixing_fraction * hp_brine_stream.salinity_g_kg

        # Leakage adjusted mass flows
        leakage_frac = self.lubrication_leakage_pct / 100.0
        m_hp_feed = lp_feed_stream.mass_flow_kg_s * (1.0 - leakage_frac)
        m_lp_brine = hp_brine_stream.mass_flow_kg_s + lp_feed_stream.mass_flow_kg_s * leakage_frac

        # Outlet streams
        hp_feed_outlet = WaterStream(
            temperature_k=lp_feed_stream.temperature_k,
            pressure_pa=p_hp_feed_outlet_pa,
            mass_flow_kg_s=m_hp_feed,
            salinity_g_kg=salinity_boosted_feed,
            composition=lp_feed_stream.composition,
            name=f"{self.name}_Boosted_Feed"
        )

        lp_brine_outlet = WaterStream(
            temperature_k=hp_brine_stream.temperature_k,
            pressure_pa=101325.0 + 1.2e5, # Discharge backpressure ~1.2 bar gauge
            mass_flow_kg_s=m_lp_brine,
            salinity_g_kg=hp_brine_stream.salinity_g_kg,
            composition=hp_brine_stream.composition,
            name=f"{self.name}_LP_Brine_Discharge"
        )

        # Power recovered in kW = Q * Delta_P * efficiency
        q_transferred_m3s = min(hp_brine_stream.volume_flow_m3_s, lp_feed_stream.volume_flow_m3_s)
        power_recovered_w = q_transferred_m3s * dp_transferred_pa
        power_recovered_kw = Units.w_to_kw(power_recovered_w)

        return {
            "pressure_transfer_efficiency": self.efficiency,
            "hp_brine_inlet_pressure_bar": hp_brine_stream.pressure_bar,
            "hp_boosted_feed_pressure_bar": hp_feed_outlet.pressure_bar,
            "power_recovered_kw": round(power_recovered_kw, 2),
            "salinity_boost_g_kg": round(salinity_boosted_feed - lp_feed_stream.salinity_g_kg, 4),
            "hp_feed_outlet": hp_feed_outlet,
            "lp_brine_outlet": lp_brine_outlet
        }
