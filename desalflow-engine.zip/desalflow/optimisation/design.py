"""
DESALFLOW ENGINE - Engineering Design Sizing & Optimization
Calculates required membrane vessel count, element quantity, and pump rating for target plant capacity.
"""

import math
from typing import Dict, Any
from desalflow.membranes.membrane import MembraneSpecification

class PlantSizer:
    @staticmethod
    def size_swro_plant(
        target_capacity_m3d: float = 50000.0, # 50,000 m³/day plant
        recovery_fraction: float = 0.45,       # 45% recovery
        design_flux_lmh: float = 14.5,         # Design average flux ~ 14.5 LMH
        elements_per_vessel: int = 7
    ) -> Dict[str, Any]:
        """Calculates exact element count, vessel count, train count, and feed flow required."""
        q_perm_m3h = target_capacity_m3d / 24.0
        q_feed_m3h = q_perm_m3h / recovery_fraction
        q_brine_m3h = q_feed_m3h - q_perm_m3h

        spec = MembraneSpecification.dow_filmtec_sw30hrle_440()
        element_area_m2 = spec.membrane_area_m2

        # Required total membrane area = Q_perm [m³/h] * 1000 [L/m³] / Design_Flux [LMH]
        total_required_area_m2 = (q_perm_m3h * 1000.0) / design_flux_lmh
        total_elements_required = math.ceil(total_required_area_m2 / element_area_m2)
        
        # Round up elements to multiples of elements_per_vessel
        total_vessels_required = math.ceil(total_elements_required / elements_per_vessel)
        
        # Train distribution (e.g., 4 or 6 trains)
        num_trains = 4 if total_vessels_required >= 24 else (2 if total_vessels_required >= 8 else 1)
        vessels_per_train = math.ceil(total_vessels_required / num_trains)
        total_vessels_final = vessels_per_train * num_trains
        total_elements_final = total_vessels_final * elements_per_vessel
        actual_area_m2 = total_elements_final * element_area_m2
        actual_flux_lmh = (q_perm_m3h * 1000.0) / actual_area_m2

        return {
            "target_capacity_m3d": target_capacity_m3d,
            "target_capacity_m3h": round(q_perm_m3h, 1),
            "required_feed_flow_m3h": round(q_feed_m3h, 1),
            "required_brine_flow_m3h": round(q_brine_m3h, 1),
            "recovery_pct": recovery_fraction * 100.0,
            "design_flux_lmh": design_flux_lmh,
            "actual_average_flux_lmh": round(actual_flux_lmh, 2),
            "num_trains": num_trains,
            "vessels_per_train": vessels_per_train,
            "total_vessels": total_vessels_final,
            "total_elements": total_elements_final,
            "total_membrane_area_m2": round(actual_area_m2, 1)
        }
