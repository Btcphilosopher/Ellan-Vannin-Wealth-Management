"""
DESALFLOW ENGINE - SciPy Operating Cost & SEC Minimizer
Uses SciPy `minimize` / `minimize_scalar` to find optimal feed pressure P_opt and plant recovery R_opt
that minimizes Specific Energy Consumption SEC [kWh/m³] subject to permeate quality constraint (TDS < 300 mg/L).
"""

from scipy.optimize import minimize
from typing import Dict, Any, Optional
from desalflow.simulation.steady_state import SteadyStateSimulator

class OperationOptimizer:
    @staticmethod
    def minimize_sec(
        intake_temp_c: float = 25.0,
        intake_salinity_g_kg: float = 35.0,
        intake_flow_m3h: float = 2000.0,
        max_permeate_tds_mg_l: float = 350.0
    ) -> Dict[str, Any]:
        sim = SteadyStateSimulator()

        def objective(p_bar: float) -> float:
            try:
                res = sim.run(
                    intake_temperature_c=intake_temp_c,
                    intake_salinity_g_kg=intake_salinity_g_kg,
                    intake_flow_m3h=intake_flow_m3h,
                    hp_pressure_bar=p_bar[0]
                )
                summary = res["plant_summary"]
                sec = summary["specific_energy_consumption_kwh_m3"]
                tds = summary["permeate_tds_mg_l"]
                
                # Penalty if TDS exceeds threshold
                penalty = 10.0 * max(0.0, tds - max_permeate_tds_mg_l)
                return sec + penalty
            except Exception:
                return 1e5

        # Bound search for pressure between 50 bar and 80 bar
        opt_res = minimize(
            fun=objective,
            x0=[63.0],
            method="Nelder-Mead",
            bounds=[(50.0, 80.0)],
            options={"maxiter": 30, "xatol": 0.2}
        )

        opt_p_bar = float(opt_res.x[0])
        best_run = sim.run(
            intake_temperature_c=intake_temp_c,
            intake_salinity_g_kg=intake_salinity_g_kg,
            intake_flow_m3h=intake_flow_m3h,
            hp_pressure_bar=opt_p_bar
        )["plant_summary"]

        return {
            "optimal_pressure_bar": round(opt_p_bar, 2),
            "minimum_sec_kwh_m3": round(best_run["specific_energy_consumption_kwh_m3"], 3),
            "resulting_permeate_tds_mg_l": best_run["permeate_tds_mg_l"],
            "resulting_recovery_pct": best_run["plant_recovery_pct"],
            "total_plant_power_kw": best_run["total_plant_power_kw"]
        }
