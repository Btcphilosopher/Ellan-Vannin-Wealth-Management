"""
DESALFLOW ENGINE - Concentration Polarisation (CP) Mass Transfer Model
Film Theory Equation:
CP = C_membrane_surface / C_bulk = exp( J_w / k )
where:
  k = mass transfer coefficient in boundary layer [m/s]
  Sherwood number correlation for spiral-wound net spacers:
    Sh = k * d_h / D_solute = A_sh * (Re^a) * (Sc^b)
"""

import math
from typing import Dict, Any
from desalflow.water.properties import SeawaterProperties

class ConcentrationPolarizationModel:
    @staticmethod
    def solute_diffusivity_m2_s(temperature_k: float, salinity_g_kg: float) -> float:
        """
        NaCl diffusion coefficient in water D_s [m²/s] (Wilke-Chang / Vitagliano):
        At 25°C (298.15 K): D_s approx 1.61e-9 m²/s
        """
        # Stokes-Einstein temperature correction
        d_ref = 1.61e-9
        mu_ref = 0.89e-3 # Pa·s at 25°C
        mu_t = SeawaterProperties.dynamic_viscosity(temperature_k, salinity_g_kg)
        d_s = d_ref * (temperature_k / 298.15) * (mu_ref / max(1e-5, mu_t))
        return d_s

    @staticmethod
    def mass_transfer_coefficient_k(
        velocity_m_s: float,
        hydraulic_diameter_m: float,
        temperature_k: float,
        salinity_g_kg: float
    ) -> float:
        """
        Calculates mass transfer coefficient k [m/s] for spiral wound feed channel:
        Sh = 0.065 * (Re ** 0.875) * (Sc ** 0.25)
        k = Sh * D_s / d_h
        """
        if velocity_m_s <= 0.0 or hydraulic_diameter_m <= 0.0:
            return 1e-4  # Default fallback k ~ 1e-4 m/s

        rho = SeawaterProperties.density(temperature_k, salinity_g_kg)
        mu = SeawaterProperties.dynamic_viscosity(temperature_k, salinity_g_kg)
        nu = mu / rho
        d_s = ConcentrationPolarizationModel.solute_diffusivity_m2_s(temperature_k, salinity_g_kg)

        # Dimensionless numbers
        re = (rho * velocity_m_s * hydraulic_diameter_m) / mu
        sc = nu / d_s

        # Sherwood correlation for mesh spacers
        sh = 0.065 * (re ** 0.875) * (sc ** 0.25)
        k = (sh * d_s) / hydraulic_diameter_m
        return max(1e-6, k)

    @classmethod
    def calculate_surface_concentration(
        cls,
        c_bulk_g_kg: float,
        j_w_m_s: float,
        k_m_s: float
    ) -> Dict[str, Any]:
        """
        Calculates membrane surface concentration C_w using film theory:
        CP modulus = C_w / C_b = exp( J_w / k )
        C_w = C_b * exp( J_w / k )
        """
        if k_m_s <= 0.0 or j_w_m_s <= 0.0:
            return {"cp_modulus": 1.0, "c_surface_g_kg": c_bulk_g_kg}

        cp_modulus = math.exp(j_w_m_s / k_m_s)
        c_surface_g_kg = c_bulk_g_kg * cp_modulus

        return {
            "cp_modulus": round(cp_modulus, 4),
            "c_surface_g_kg": c_surface_g_kg,
            "mass_transfer_k_m_s": k_m_s
        }
