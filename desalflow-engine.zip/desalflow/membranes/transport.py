"""
DESALFLOW ENGINE - Solution-Diffusion Membrane Transport Model
Governing equations:
1. Water flux:
   J_w = A * ( Delta_P_hydraulic - Delta_pi_effective )
   where:
     Delta_P_hydraulic = P_feed_avg - P_permeate
     Delta_pi_effective = pi_membrane_surface - pi_permeate

2. Solute flux:
   J_s = B * ( C_membrane_surface - C_permeate )

3. Permeate concentration:
   C_permeate = J_s / J_w = ( B * C_surface ) / ( J_w + B )

4. Salt Rejection R_salt:
   R_salt = 1 - ( C_permeate / C_bulk )
"""

import math
from typing import Dict, Any, Tuple
from desalflow.core.units import Units
from desalflow.membranes.membrane import MembraneSpecification
from desalflow.water.osmotic import OsmoticPressureModel
from desalflow.water.properties import SeawaterProperties

class SolutionDiffusionModel:
    @staticmethod
    def temperature_corrected_a(
        spec: MembraneSpecification,
        temperature_k: float
    ) -> float:
        """
        Temperature correction factor for A(T) using modified Arrhenius expression:
        TCF = exp( E_A * (1/298.15 - 1/T) )
        """
        tcf = math.exp(spec.e_activation_water_k * ((1.0 / 298.15) - (1.0 / temperature_k)))
        return spec.a_permeability_si * tcf

    @staticmethod
    def temperature_corrected_b(
        spec: MembraneSpecification,
        temperature_k: float
    ) -> float:
        """
        Temperature correction factor for B(T):
        TCF_B = exp( E_B * (1/298.15 - 1/T) )
        """
        tcf = math.exp(spec.e_activation_salt_k * ((1.0 / 298.15) - (1.0 / temperature_k)))
        return spec.b_permeability_si * tcf

    @classmethod
    def calculate_fluxes(
        cls,
        spec: MembraneSpecification,
        p_feed_pa: float,
        p_permeate_pa: float,
        c_surface_g_kg: float,
        c_bulk_g_kg: float,
        c_permeate_guess_g_kg: float,
        temperature_k: float,
        fouling_resistance_m1: float = 0.0
    ) -> Dict[str, Any]:
        """
        Calculates water flux Jw [m/s], salt flux Js [kg/(m²·s)], permeate concentration C_p [g/kg],
        and salt rejection R [%].
        """
        a_t = cls.temperature_corrected_a(spec, temperature_k)
        b_t = cls.temperature_corrected_b(spec, temperature_k)

        # Incorporate fouling resistance into effective permeability A_eff
        # 1 / A_eff = (1 / A_t) + mu * R_foul
        mu = SeawaterProperties.dynamic_viscosity(temperature_k, c_bulk_g_kg)
        if fouling_resistance_m1 > 0:
            a_eff = 1.0 / ((1.0 / a_t) + mu * fouling_resistance_m1)
        else:
            a_eff = a_t

        # Applied hydraulic pressure difference
        dp_hydraulic = max(0.0, p_feed_pa - p_permeate_pa)

        # Osmotic pressures
        pi_surface = OsmoticPressureModel.sharqawy_seawater_osmotic_pressure(temperature_k, c_surface_g_kg)
        pi_permeate = OsmoticPressureModel.sharqawy_seawater_osmotic_pressure(temperature_k, c_permeate_guess_g_kg)
        dpi_effective = max(0.0, pi_surface - pi_permeate)

        # Net driving pressure NDP = Delta_P - Delta_pi
        ndp_pa = dp_hydraulic - dpi_effective

        if ndp_pa <= 0.0:
            # Below osmotic pressure threshold - zero or reverse flux
            return {
                "net_driving_pressure_pa": ndp_pa,
                "net_driving_pressure_bar": ndp_pa / 1e5,
                "water_flux_ms": 0.0,
                "water_flux_lmh": 0.0,
                "salt_flux_kg_m2_s": 0.0,
                "permeate_concentration_g_kg": c_bulk_g_kg,
                "salt_rejection_pct": 0.0,
                "observed_rejection_pct": 0.0,
                "a_eff_si": a_eff,
                "b_t_si": b_t
            }

        # Water flux J_w = A_eff * NDP
        j_w = a_eff * ndp_pa

        # Density conversion for salt concentration: C_g_kg * rho / 1000 = C_kg_m3
        rho_sw = SeawaterProperties.density(temperature_k, c_surface_g_kg)
        c_surface_kg_m3 = c_surface_g_kg * (rho_sw / 1000.0)

        # Analytical permeate concentration C_p from C_p = (B * C_surface) / (J_w + B)
        c_p_kg_m3 = (b_t * c_surface_kg_m3) / (j_w + b_t)
        c_p_g_kg = c_p_kg_m3 / (rho_sw / 1000.0)

        # Solute flux J_s = J_w * C_p [kg/(m²·s)]
        j_s = j_w * c_p_kg_m3

        # Salt rejection percentages
        intrinsic_rejection = (1.0 - (c_p_g_kg / max(1e-6, c_surface_g_kg))) * 100.0
        observed_rejection = (1.0 - (c_p_g_kg / max(1e-6, c_bulk_g_kg))) * 100.0

        return {
            "net_driving_pressure_pa": ndp_pa,
            "net_driving_pressure_bar": ndp_pa / 1e5,
            "water_flux_ms": j_w,
            "water_flux_lmh": Units.ms_to_lmh(j_w),
            "salt_flux_kg_m2_s": j_s,
            "permeate_concentration_g_kg": max(0.0, c_p_g_kg),
            "intrinsic_rejection_pct": min(100.0, max(0.0, intrinsic_rejection)),
            "observed_rejection_pct": min(100.0, max(0.0, observed_rejection)),
            "a_eff_si": a_eff,
            "b_t_si": b_t
        }
