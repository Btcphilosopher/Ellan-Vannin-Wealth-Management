"""
DESALFLOW ENGINE - Membrane Specifications
Defines commercial SWRO / BWRO membrane element specifications:
- Active membrane surface area [m²] (e.g. 400 sq ft = 37.2 m² or 440 sq ft = 40.9 m²)
- Water permeability coefficient A [m/(s·Pa)] (or LMH/bar)
- Solute permeability coefficient B [m/s] (or LMH)
- Temperature correction factor TCFF (Arrhenius / Film model)
- Maximum hydraulic pressure limit [Pa]
"""

from pydantic import BaseModel, Field
from desalflow.core.units import Units

class MembraneSpecification(BaseModel):
    model_name: str = "SW30HRLE-440"
    membrane_type: str = "SWRO"  # SWRO or BWRO
    membrane_area_m2: float = 40.9  # 440 sq ft = 40.877 m²
    
    # Pure water permeability A at reference 25°C [m/(s·Pa)]
    # Typical SWRO A ~ 1.0 - 1.5 LMH/bar = (1.0 to 1.5) / 3.6e11 m/(s·Pa)
    a_permeability_si: float = 1.2 / 3.6e11
    
    # Solute permeability B at reference 25°C [m/s]
    # Typical SWRO B ~ 0.02 - 0.05 LMH = (0.02 to 0.05) / 3.6e6 m/s
    b_permeability_si: float = 0.035 / 3.6e6
    
    # Pressure drop parameters per element
    spacer_thickness_mil: float = 28.0 # 28 mil feed spacer
    max_pressure_pa: float = 83e5 # 83 bar (1200 psi) max rating
    max_temperature_k: float = 318.15 # 45°C max rating
    max_recovery_per_element: float = 0.15 # Max 15% recovery per 1m element
    
    # Arrhenius activation energies for temperature dependence
    e_activation_water_k: float = 2800.0  # Arrhenius constant for A(T)
    e_activation_salt_k: float = 4200.0   # Arrhenius constant for B(T)

    @classmethod
    def dow_filmtec_sw30hrle_440(cls) -> "MembraneSpecification":
        return cls(
            model_name="DOW FilmTec SW30HRLE-440",
            membrane_type="SWRO",
            membrane_area_m2=40.9,
            a_permeability_si=1.25 / 3.6e11, # 1.25 LMH/bar
            b_permeability_si=0.032 / 3.6e6,  # 0.032 LMH (~ 99.8% nominal rejection)
            spacer_thickness_mil=28.0
        )

    @classmethod
    def dow_filmtec_bw30_400(cls) -> "MembraneSpecification":
        return cls(
            model_name="DOW FilmTec BW30-400",
            membrane_type="BWRO",
            membrane_area_m2=37.2,
            a_permeability_si=3.5 / 3.6e11,  # 3.5 LMH/bar
            b_permeability_si=0.15 / 3.6e6,   # 0.15 LMH
            spacer_thickness_mil=34.0
        )

    @property
    def a_lmh_per_bar(self) -> float:
        return Units.si_to_lmh_per_bar(self.a_permeability_si)

    @property
    def b_lmh(self) -> float:
        return Units.b_si_to_lmh(self.b_permeability_si)
