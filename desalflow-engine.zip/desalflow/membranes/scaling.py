"""
DESALFLOW ENGINE - Mineral Scaling Indices
Calculates saturation indices (SI) in concentrate stream to assess scaling potential for:
- Langelier Saturation Index (LSI) for CaCO3
- Stiff-Davis Index (SDSI) for high ionic strength seawater
- Calcium Sulfate (CaSO4) saturation ratio
- Silica (SiO2) solubility limit
"""

import math
from typing import Dict, Any
from desalflow.water.stream import WaterStream

class ScalingIndices:
    @staticmethod
    def calculate_stiff_davis_index(
        stream: WaterStream
    ) -> Dict[str, Any]:
        """
        Calculates Stiff-Davis Index (SDSI) for seawater concentrate:
        SDSI = pH - pH_s
        pH_s = pK2 - pKs + pCa + pAlk + K_sdsi(I, T)
        """
        comp = stream.composition
        ph = comp.pH
        t_c = stream.temperature_c
        
        # Simplified SDSI empirical fit for SWRO concentrate
        salinity = stream.salinity_g_kg
        k_sdsi = 2.80 - 0.012 * t_c + 0.0001 * (salinity ** 1.2)
        ph_s = k_sdsi
        sdsi = ph - ph_s

        # CaSO4 saturation ratio (IP / Ksp)
        # Ca2+ ~ 412 mg/L in 35g/kg, scales with recovery ratio
        caso4_sat_ratio = (comp.ions_ppm.get("Ca2+", 412.0) * comp.ions_ppm.get("SO42-", 2712.0)) / (412.0 * 2712.0 * 2.5)

        # Silica solubility limit (~ 120 mg/L at 25°C)
        silica_ppm = comp.ions_ppm.get("SiO2", 2.0)
        silica_sat_pct = (silica_ppm / 120.0) * 100.0

        return {
            "sdsi": round(sdsi, 2),
            "sdsi_status": "Scaling Likelihood High" if sdsi > 0.5 else ("Slight Scaling" if sdsi > 0.0 else "Non-Scaling"),
            "caso4_saturation_ratio": round(caso4_sat_ratio, 3),
            "silica_saturation_pct": round(silica_sat_pct, 1),
            "antiscalant_required": sdsi > 0.0 or caso4_sat_ratio > 1.0 or silica_sat_pct > 100.0
        }
