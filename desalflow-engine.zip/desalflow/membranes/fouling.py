"""
DESALFLOW ENGINE - Membrane Fouling Model
Resistance-in-series model for particulate/organic/biofouling:
1 / A_eff = 1 / A_intrinsic + mu * ( R_cake + R_bio )
where R_cake = alpha_foul * (t_hours / 1000)^0.8
"""

import math
from typing import Dict, Any

class FoulingModel:
    def __init__(
        self,
        fouling_rate_factor: float = 0.05, # Clean feed = 0.01, Dirty feed = 0.10
        cleaning_interval_hours: float = 2160.0 # 90 days CIP cycle
    ):
        self.fouling_rate_factor = float(fouling_rate_factor)
        self.cleaning_interval_hours = float(cleaning_interval_hours)

    def calculate_fouling_resistance(self, operating_hours: float, sdi_15: float = 3.0) -> float:
        """
        Calculates additional fouling resistance R_foul [m^-1] as a function of operating time and feed SDI:
        R_foul = 1.0e11 * fouling_rate_factor * (SDI_15 / 3.0) * (t_hours / 1000.0) ^ 0.75
        """
        if operating_hours <= 0.0:
            return 0.0
        
        t_eff = operating_hours % self.cleaning_interval_hours
        sdi_ratio = max(0.5, sdi_15 / 3.0)
        r_foul = 1.0e11 * self.fouling_rate_factor * sdi_ratio * ((t_eff / 1000.0) ** 0.75)
        return float(r_foul)
