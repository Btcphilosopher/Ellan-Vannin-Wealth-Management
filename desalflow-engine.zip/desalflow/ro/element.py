"""
DESALFLOW ENGINE - MembraneElement Model
Models a single spiral-wound RO membrane element (1m length, 8-inch diameter).
Solves internal spatial discretization or point transport:
- Feed inlet water stream -> Concentrate outlet & Permeate outlet
- Calculates average feed pressure, flux profile, pressure drop across spacer (~0.2-0.4 bar)
- Mass balance: Feed_mass = Conc_mass + Perm_mass
- Salt balance: Feed_salt = Conc_salt + Perm_salt
"""

import math
from typing import Dict, Any, Tuple
from desalflow.core.units import Units
from desalflow.water.stream import WaterStream
from desalflow.membranes.membrane import MembraneSpecification
from desalflow.membranes.transport import SolutionDiffusionModel
from desalflow.membranes.polarization import ConcentrationPolarizationModel

class MembraneElement:
    def __init__(
        self,
        spec: MembraneSpecification,
        element_position: int = 1,
        name: str = "RO Element"
    ):
        self.spec = spec
        self.element_position = int(element_position)
        self.name = name

    def calculate(
        self,
        inlet_feed: WaterStream,
        permeate_backpressure_pa: float = 101325.0, # 0 bar gauge default
        operating_hours: float = 0.0
    ) -> Dict[str, Any]:
        """
        Solves element transport:
        1. Estimates feed channel pressure drop across element spacer (~0.25 bar per element)
        2. Calculates local crossflow velocity v = Q / (A_feed_channel)
        3. Mass transfer coefficient k and CP modulus
        4. Iterative coupling between Solution-Diffusion flux J_w, permeate concentration C_p, and CP modulus C_w
        5. Balance updates for concentrate and permeate streams
        """
        if inlet_feed.mass_flow_kg_s <= 0.0 or inlet_feed.volume_flow_m3_s <= 0.0:
            perm_empty = inlet_feed.copy_with(mass_flow_kg_s=0.0, pressure_pa=permeate_backpressure_pa, name=f"{self.name}_Permeate")
            return {
                "recovery_pct": 0.0,
                "flux_lmh": 0.0,
                "pressure_drop_bar": 0.0,
                "concentrate": inlet_feed,
                "permeate": perm_empty
            }

        # 1. Hydraulic pressure drop across feed channel spacer
        # Spacer channel height h_c = 28 mil = 0.711 mm
        h_spacer_m = (self.spec.spacer_thickness_mil * 2.54e-5)
        # Approximate feed channel width W = 0.85 m for 8-inch vessel
        w_channel_m = 0.85
        a_cross_section_m2 = h_spacer_m * w_channel_m
        d_h = 2.0 * h_spacer_m # Hydraulic diameter

        v_feed_m_s = inlet_feed.volume_flow_m3_s / a_cross_section_m2
        
        # Spacer pressure loss Delta_P = f_spacer * (L / d_h) * (0.5 * rho * v^2)
        # Empirical spacer friction loss ~ 0.20 to 0.35 bar per element
        dp_spacer_pa = max(0.15e5, min(0.60e5, 0.25e5 * ((v_feed_m_s / 0.15) ** 1.5)))
        p_feed_avg_pa = inlet_feed.pressure_pa - 0.5 * dp_spacer_pa
        p_conc_outlet_pa = max(0.0, inlet_feed.pressure_pa - dp_spacer_pa)

        # 2. Mass transfer coefficient k
        k_m_s = ConcentrationPolarizationModel.mass_transfer_coefficient_k(
            velocity_m_s=v_feed_m_s,
            hydraulic_diameter_m=d_h,
            temperature_k=inlet_feed.temperature_k,
            salinity_g_kg=inlet_feed.salinity_g_kg
        )

        # 3. Iterative solver for J_w, C_w, C_p
        c_bulk = inlet_feed.salinity_g_kg
        c_surface = c_bulk
        c_p = 0.05 # Initial guess 50 ppm = 0.05 g/kg

        for iteration in range(15):
            # Calculate fluxes with current surface concentration guess
            res = SolutionDiffusionModel.calculate_fluxes(
                spec=self.spec,
                p_feed_pa=p_feed_avg_pa,
                p_permeate_pa=permeate_backpressure_pa,
                c_surface_g_kg=c_surface,
                c_bulk_g_kg=c_bulk,
                c_permeate_guess_g_kg=c_p,
                temperature_k=inlet_feed.temperature_k
            )

            j_w = res["water_flux_ms"]
            if j_w <= 0.0:
                break

            # Update surface concentration C_w = C_b * exp(J_w / k)
            cp_res = ConcentrationPolarizationModel.calculate_surface_concentration(c_bulk, j_w, k_m_s)
            c_surface_new = cp_res["c_surface_g_kg"]
            c_p_new = res["permeate_concentration_g_kg"]

            if abs(c_surface_new - c_surface) < 1e-5 and abs(c_p_new - c_p) < 1e-5:
                c_surface = c_surface_new
                c_p = c_p_new
                break

            c_surface = 0.5 * (c_surface + c_surface_new)
            c_p = 0.5 * (c_p + c_p_new)

        # 4. Total permeate volumetric and mass flow from active element area
        q_perm_m3s = j_w * self.spec.membrane_area_m2
        rho_perm = 998.2 # Permeate water density ~ 998 kg/m³
        m_perm_kg_s = q_perm_m3s * rho_perm

        # Salt mass flow permeate = m_perm * (c_p / 1000)
        m_salt_perm_kg_s = m_perm_kg_s * (c_p / 1000.0)

        # 5. Mass balance for concentrate stream
        m_conc_kg_s = max(0.0, inlet_feed.mass_flow_kg_s - m_perm_kg_s)
        m_salt_feed_kg_s = inlet_feed.salt_mass_flow_kg_s
        m_salt_conc_kg_s = max(0.0, m_salt_feed_kg_s - m_salt_perm_kg_s)

        # Concentrate salinity S_conc = (m_salt_conc / m_conc) * 1000
        salinity_conc = (m_salt_conc_kg_s / m_conc_kg_s) * 1000.0 if m_conc_kg_s > 0 else c_bulk

        # Stream construction
        permeate_stream = WaterStream(
            temperature_k=inlet_feed.temperature_k,
            pressure_pa=permeate_backpressure_pa,
            mass_flow_kg_s=m_perm_kg_s,
            salinity_g_kg=max(0.0, c_p),
            composition=inlet_feed.composition.model_copy(),
            name=f"{self.name}_Permeate"
        )

        concentrate_stream = WaterStream(
            temperature_k=inlet_feed.temperature_k,
            pressure_pa=p_conc_outlet_pa,
            mass_flow_kg_s=m_conc_kg_s,
            salinity_g_kg=salinity_conc,
            composition=inlet_feed.composition.model_copy(),
            name=f"{self.name}_Concentrate"
        )

        element_recovery_pct = (m_perm_kg_s / inlet_feed.mass_flow_kg_s) * 100.0 if inlet_feed.mass_flow_kg_s > 0 else 0.0

        return {
            "element_position": self.element_position,
            "flux_lmh": round(Units.ms_to_lmh(j_w), 2),
            "water_flux_ms": j_w,
            "net_driving_pressure_bar": round(res["net_driving_pressure_bar"], 2),
            "cp_modulus": round(c_surface / max(1e-6, c_bulk), 3),
            "pressure_drop_bar": round(dp_spacer_pa / 1e5, 3),
            "element_recovery_pct": round(element_recovery_pct, 2),
            "permeate_tds_mg_l": round(permeate_stream.tds_mg_l, 1),
            "permeate": permeate_stream,
            "concentrate": concentrate_stream
        }
