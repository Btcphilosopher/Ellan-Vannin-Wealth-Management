"""
DESALFLOW ENGINE - ROStage Model
Models an RO Stage consisting of M parallel pressure vessels.
Distributes stage feed equally across all M vessels:
Feed_per_vessel = Stage_Feed / M
Combines vessel concentrate streams into Stage Concentrate outlet.
Combines vessel permeate streams into Stage Permeate outlet.
"""

from typing import Dict, Any
from desalflow.water.stream import WaterStream
from desalflow.membranes.membrane import MembraneSpecification
from desalflow.ro.vessel import PressureVessel

class ROStage:
    def __init__(
        self,
        spec: MembraneSpecification,
        num_vessels: int = 12,
        elements_per_vessel: int = 7,
        stage_index: int = 1,
        name: str = "RO Stage"
    ):
        self.spec = spec
        self.num_vessels = max(1, int(num_vessels))
        self.elements_per_vessel = int(elements_per_vessel)
        self.stage_index = int(stage_index)
        self.name = f"{name} {stage_index}"
        self.vessel_template = PressureVessel(spec=spec, elements_per_vessel=elements_per_vessel, name=f"{self.name}_PV")

    def calculate(
        self,
        stage_feed: WaterStream,
        permeate_backpressure_pa: float = 101325.0,
        operating_hours: float = 0.0
    ) -> Dict[str, Any]:
        if stage_feed.mass_flow_kg_s <= 0.0:
            perm_empty = stage_feed.copy_with(mass_flow_kg_s=0.0, name=f"{self.name}_Permeate")
            return {"stage_recovery_pct": 0.0, "stage_permeate": perm_empty, "stage_concentrate": stage_feed}

        # Divide feed equally among parallel vessels
        feed_per_vessel = stage_feed.copy_with(
            mass_flow_kg_s=stage_feed.mass_flow_kg_s / self.num_vessels,
            name=f"{self.name}_Vessel_Feed"
        )

        # Solve single representative vessel
        vessel_res = self.vessel_template.calculate(
            inlet_feed=feed_per_vessel,
            permeate_backpressure_pa=permeate_backpressure_pa,
            operating_hours=operating_hours
        )

        vessel_perm = vessel_res["permeate"]
        vessel_conc = vessel_res["concentrate"]

        # Multiply up for M parallel vessels
        stage_perm_mass_kg_s = vessel_perm.mass_flow_kg_s * self.num_vessels
        stage_conc_mass_kg_s = vessel_conc.mass_flow_kg_s * self.num_vessels

        stage_permeate = WaterStream(
            temperature_k=stage_feed.temperature_k,
            pressure_pa=permeate_backpressure_pa,
            mass_flow_kg_s=stage_perm_mass_kg_s,
            salinity_g_kg=vessel_perm.salinity_g_kg,
            composition=stage_feed.composition.model_copy(),
            name=f"{self.name}_Permeate"
        )

        stage_concentrate = WaterStream(
            temperature_k=stage_feed.temperature_k,
            pressure_pa=vessel_conc.pressure_pa,
            mass_flow_kg_s=stage_conc_mass_kg_s,
            salinity_g_kg=vessel_conc.salinity_g_kg,
            composition=stage_feed.composition.model_copy(),
            name=f"{self.name}_Concentrate"
        )

        stage_recovery_pct = (stage_perm_mass_kg_s / stage_feed.mass_flow_kg_s) * 100.0

        return {
            "stage_index": self.stage_index,
            "num_vessels": self.num_vessels,
            "total_elements": self.num_vessels * self.elements_per_vessel,
            "stage_recovery_pct": round(stage_recovery_pct, 2),
            "stage_pressure_drop_bar": round(vessel_res["vessel_pressure_drop_bar"], 2),
            "average_flux_lmh": vessel_res["average_flux_lmh"],
            "permeate_tds_mg_l": round(stage_permeate.tds_mg_l, 1),
            "vessel_sample_results": vessel_res,
            "stage_permeate": stage_permeate,
            "stage_concentrate": stage_concentrate
        }
