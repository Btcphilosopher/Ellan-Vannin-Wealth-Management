"""
DESALFLOW ENGINE - PressureVessel Model
Models a pressure vessel housing N elements in series (typically N = 6, 7, or 8 elements).
Sequential serial calculation:
Feed -> Element 1 (Conc 1) -> Element 2 (Conc 2) ... -> Element N (Final Brine)
Permeate streams from all N elements are collected into common vessel permeate header.
"""

from typing import List, Dict, Any
from desalflow.water.stream import WaterStream
from desalflow.membranes.membrane import MembraneSpecification
from desalflow.ro.element import MembraneElement

class PressureVessel:
    def __init__(
        self,
        spec: MembraneSpecification,
        elements_per_vessel: int = 7,
        name: str = "Pressure Vessel"
    ):
        self.spec = spec
        self.elements_per_vessel = int(elements_per_vessel)
        self.name = name
        self.elements = [
            MembraneElement(spec=spec, element_position=i + 1, name=f"{name}_E{i+1}")
            for i in range(self.elements_per_vessel)
        ]

    def calculate(
        self,
        inlet_feed: WaterStream,
        permeate_backpressure_pa: float = 101325.0,
        operating_hours: float = 0.0
    ) -> Dict[str, Any]:
        """
        Executes serial element calculation through the vessel length.
        """
        current_feed = inlet_feed
        element_results = []
        total_perm_mass_kg_s = 0.0
        total_perm_salt_mass_kg_s = 0.0

        for elem in self.elements:
            res = elem.calculate(
                inlet_feed=current_feed,
                permeate_backpressure_pa=permeate_backpressure_pa,
                operating_hours=operating_hours
            )
            element_results.append(res)
            
            perm = res["permeate"]
            total_perm_mass_kg_s += perm.mass_flow_kg_s
            total_perm_salt_mass_kg_s += perm.salt_mass_flow_kg_s
            
            # Step concentrate to next element
            current_feed = res["concentrate"]

        # Final vessel concentrate outlet
        vessel_concentrate = current_feed

        # Vessel combined permeate calculation
        vessel_perm_salinity_g_kg = (total_perm_salt_mass_kg_s / total_perm_mass_kg_s) * 1000.0 if total_perm_mass_kg_s > 0 else 0.0
        
        vessel_permeate = WaterStream(
            temperature_k=inlet_feed.temperature_k,
            pressure_pa=permeate_backpressure_pa,
            mass_flow_kg_s=total_perm_mass_kg_s,
            salinity_g_kg=vessel_perm_salinity_g_kg,
            composition=inlet_feed.composition.model_copy(),
            name=f"{self.name}_Combined_Permeate"
        )

        vessel_recovery_pct = (total_perm_mass_kg_s / inlet_feed.mass_flow_kg_s) * 100.0 if inlet_feed.mass_flow_kg_s > 0 else 0.0
        vessel_pressure_drop_bar = (inlet_feed.pressure_pa - vessel_concentrate.pressure_pa) / 1e5

        # Average vessel flux [LMH]
        avg_flux_lmh = sum(r["flux_lmh"] for r in element_results) / self.elements_per_vessel

        return {
            "vessel_recovery_pct": round(vessel_recovery_pct, 2),
            "vessel_pressure_drop_bar": round(vessel_pressure_drop_bar, 2),
            "average_flux_lmh": round(avg_flux_lmh, 2),
            "permeate_tds_mg_l": round(vessel_permeate.tds_mg_l, 1),
            "element_breakdown": element_results,
            "permeate": vessel_permeate,
            "concentrate": vessel_concentrate
        }
