"""
DESALFLOW ENGINE - ROTrain Model
Models a single RO Train containing one or multiple stages in series (e.g., 2:1 staging).
Stage 1 Concentrate becomes Stage 2 Feed (with optional booster pump if required).
Combines Stage 1 and Stage 2 permeate streams.
"""

from typing import List, Dict, Any, Optional
from desalflow.water.stream import WaterStream
from desalflow.membranes.membrane import MembraneSpecification
from desalflow.ro.stage import ROStage

class ROTrain:
    def __init__(
        self,
        spec: MembraneSpecification,
        vessel_counts: List[int] = [12],  # e.g. [12] for 1-stage SWRO or [16, 8] for 2:1 BWRO
        elements_per_vessel: int = 7,
        train_index: int = 1,
        name: str = "RO Train"
    ):
        self.spec = spec
        self.vessel_counts = vessel_counts
        self.elements_per_vessel = elements_per_vessel
        self.train_index = train_index
        self.name = f"{name} {train_index}"
        
        self.stages = [
            ROStage(
                spec=spec,
                num_vessels=v_count,
                elements_per_vessel=elements_per_vessel,
                stage_index=idx + 1,
                name=f"{self.name}_Stage"
            )
            for idx, v_count in enumerate(vessel_counts)
        ]

    def calculate(
        self,
        train_feed: WaterStream,
        permeate_backpressure_pa: float = 101325.0,
        operating_hours: float = 0.0
    ) -> Dict[str, Any]:
        current_feed = train_feed
        stage_results = []
        
        total_perm_mass_kg_s = 0.0
        total_perm_salt_kg_s = 0.0

        for stage in self.stages:
            stg_res = stage.calculate(
                stage_feed=current_feed,
                permeate_backpressure_pa=permeate_backpressure_pa,
                operating_hours=operating_hours
            )
            stage_results.append(stg_res)
            
            p_stg = stg_res["stage_permeate"]
            total_perm_mass_kg_s += p_stg.mass_flow_kg_s
            total_perm_salt_kg_s += p_stg.salt_mass_flow_kg_s
            
            # Next stage feed is current stage concentrate
            current_feed = stg_res["stage_concentrate"]

        final_brine = current_feed
        
        # Combined train permeate stream
        train_perm_salinity_g_kg = (total_perm_salt_kg_s / total_perm_mass_kg_s) * 1000.0 if total_perm_mass_kg_s > 0 else 0.0
        
        train_permeate = WaterStream(
            temperature_k=train_feed.temperature_k,
            pressure_pa=permeate_backpressure_pa,
            mass_flow_kg_s=total_perm_mass_kg_s,
            salinity_g_kg=train_perm_salinity_g_kg,
            composition=train_feed.composition.model_copy(),
            name=f"{self.name}_Combined_Permeate"
        )

        overall_recovery_pct = (total_perm_mass_kg_s / train_feed.mass_flow_kg_s) * 100.0 if train_feed.mass_flow_kg_s > 0 else 0.0

        return {
            "train_index": self.train_index,
            "number_of_stages": len(self.stages),
            "total_vessels": sum(self.vessel_counts),
            "total_elements": sum(self.vessel_counts) * self.elements_per_vessel,
            "overall_recovery_pct": round(overall_recovery_pct, 2),
            "permeate_flow_m3h": round(train_permeate.volume_flow_m3_h, 1),
            "permeate_tds_mg_l": round(train_permeate.tds_mg_l, 1),
            "brine_salinity_g_kg": round(final_brine.salinity_g_kg, 2),
            "stage_breakdown": stage_results,
            "train_permeate": train_permeate,
            "final_brine": final_brine
        }
