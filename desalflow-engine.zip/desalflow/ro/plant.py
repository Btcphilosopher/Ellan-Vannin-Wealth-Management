"""
DESALFLOW ENGINE - ROPlant Topology Integrator
Links complete process train:
Seawater Intake Stream
  ↓ (Pretreatment: Media Filter + Cartridge Filter + Chemical Dosing)
Pretreated Feed Stream
  ↓ (Split: Direct HP Pump vs PX Low-Pressure Stream)
  ├─> High Pressure Pump -> High Pressure Stream
  └─> PX Isobaric Energy Recovery Device -> PX Boosted Stream + Booster Pump
  ↓ (Mixer Header)
RO Feed Stream at SWRO HP Pressure (~60-70 bar)
  ↓
RO Membrane Trains (Parallel N_trains)
  ↓
Permeate Header (Product Water) & HP Brine Header (To PX ERD)
"""

from typing import List, Dict, Any, Optional
from desalflow.core.units import Units
from desalflow.water.stream import WaterStream
from desalflow.membranes.membrane import MembraneSpecification
from desalflow.pretreatment.filter import Filter
from desalflow.pretreatment.cartridge import CartridgeFilter
from desalflow.pretreatment.conditioning import ChemicalConditioning
from desalflow.pumps.pump import HighPressurePump
from desalflow.energy_recovery.pressure_exchanger import PressureExchanger
from desalflow.ro.train import ROTrain

class ROPlant:
    def __init__(
        self,
        num_trains: int = 4,
        vessel_counts_per_train: List[int] = [18],
        elements_per_vessel: int = 7,
        target_recovery_fraction: float = 0.45, # 45% recovery
        target_hp_pressure_bar: float = 65.0,
        membrane_spec: Optional[MembraneSpecification] = None,
        name: str = "DESALFLOW-SWRO-PLANT"
    ):
        self.name = name
        self.num_trains = max(1, int(num_trains))
        self.target_recovery_fraction = float(target_recovery_fraction)
        self.target_hp_pressure_bar = float(target_hp_pressure_bar)
        
        self.membrane_spec = membrane_spec if membrane_spec is not None else MembraneSpecification.dow_filmtec_sw30hrle_440()
        
        # Pretreatment components
        self.dual_media_filter = Filter(bed_area_m2=35.0, name="DMF Intake Filter")
        self.cartridge_filter = CartridgeFilter(number_of_elements=150, name="5-Micron Cartridge Guard")
        self.chemical_dosing = ChemicalConditioning(antiscalant_dose_mg_l=2.5, acid_dose_mg_l=8.0)
        
        # Pumps & ERD
        self.hp_pump = HighPressurePump(
            target_discharge_pressure_bar=target_hp_pressure_bar,
            efficiency_hydraulic=0.88,
            efficiency_motor=0.96,
            name="Main HP Feed Pump"
        )
        self.px_erd = PressureExchanger(pressure_transfer_efficiency=0.96, name="PX Isobaric ERD")
        self.px_booster_pump = HighPressurePump(
            target_discharge_pressure_bar=target_hp_pressure_bar,
            efficiency_hydraulic=0.84,
            efficiency_motor=0.95,
            name="PX Booster Pump"
        )

        # Parallel RO Trains
        self.trains = [
            ROTrain(
                spec=self.membrane_spec,
                vessel_counts=vessel_counts_per_train,
                elements_per_vessel=elements_per_vessel,
                train_index=i + 1,
                name=f"{self.name}_Train"
            )
            for i in range(self.num_trains)
        ]

    def solve_plant(
        self,
        raw_intake_stream: WaterStream,
        operating_hours: float = 0.0
    ) -> Dict[str, Any]:
        """
        Calculates complete process topology solution for the plant.
        """
        # 1. Pretreatment chain
        dmf_res = self.dual_media_filter.calculate(raw_intake_stream)
        cf_res = self.cartridge_filter.calculate(dmf_res["outlet_stream"])
        chem_res = self.chemical_dosing.calculate(cf_res["outlet_stream"])
        
        pretreated_feed = chem_res["outlet_stream"]

        # 2. Divide pretreated feed across N_trains
        m_feed_per_train = pretreated_feed.mass_flow_kg_s / self.num_trains
        
        train_feed_lp = pretreated_feed.copy_with(
            mass_flow_kg_s=m_feed_per_train,
            name="Train_LP_Feed"
        )

        # Estimate recovery split for PX sizing: Q_brine_per_train = Q_feed_per_train * (1 - Recovery)
        q_brine_est_ratio = (1.0 - self.target_recovery_fraction)
        
        # HP Pump handles Q_permeate, PX handles Q_brine
        m_hp_pump_stream = train_feed_lp.mass_flow_kg_s * self.target_recovery_fraction
        m_px_feed_stream = train_feed_lp.mass_flow_kg_s * q_brine_est_ratio

        stream_hp_pump_in = train_feed_lp.copy_with(mass_flow_kg_s=m_hp_pump_stream, name="HP_Pump_Inlet")
        stream_px_feed_in = train_feed_lp.copy_with(mass_flow_kg_s=m_px_feed_stream, name="PX_Feed_Inlet")

        # Main HP pump discharge
        hp_pump_res = self.hp_pump.calculate(stream_hp_pump_in, target_pressure_bar=self.target_hp_pressure_bar)
        stream_hp_pump_out = hp_pump_res["outlet_stream"]

        # First pass RO train solution (using target HP pressure)
        stream_ro_hp_feed = train_feed_lp.copy_with(
            pressure_pa=self.target_hp_pressure_bar * 1e5,
            name="Combined_RO_HP_Feed"
        )

        # Solve representative train
        single_train_res = self.trains[0].calculate(
            train_feed=stream_ro_hp_feed,
            operating_hours=operating_hours
        )

        train_hp_brine = single_train_res["final_brine"]
        train_permeate = single_train_res["train_permeate"]

        # 3. Energy Recovery Device PX integration
        px_res = self.px_erd.calculate(
            hp_brine_stream=train_hp_brine,
            lp_feed_stream=stream_px_feed_in
        )
        
        px_boosted_feed = px_res["hp_feed_outlet"]
        
        # PX Booster pump raises PX boosted feed from PX outlet bar to Target HP pressure
        booster_res = self.px_booster_pump.calculate(
            inlet_stream=px_boosted_feed,
            target_pressure_bar=self.target_hp_pressure_bar
        )

        # 4. Total Plant Performance Aggregation across all N_trains
        plant_permeate_mass_kg_s = train_permeate.mass_flow_kg_s * self.num_trains
        plant_brine_mass_kg_s = train_hp_brine.mass_flow_kg_s * self.num_trains

        plant_permeate = WaterStream(
            temperature_k=raw_intake_stream.temperature_k,
            pressure_pa=101325.0,
            mass_flow_kg_s=plant_permeate_mass_kg_s,
            salinity_g_kg=train_permeate.salinity_g_kg,
            composition=train_permeate.composition.model_copy(),
            name=f"{self.name}_Total_Permeate"
        )

        plant_brine = WaterStream(
            temperature_k=raw_intake_stream.temperature_k,
            pressure_pa=px_res["lp_brine_outlet"].pressure_pa,
            mass_flow_kg_s=plant_brine_mass_kg_s,
            salinity_g_kg=train_hp_brine.salinity_g_kg,
            composition=train_hp_brine.composition.model_copy(),
            name=f"{self.name}_Total_Brine_Discharge"
        )

        # Power calculations (kW per train -> total plant kW)
        p_hp_pump_kw = hp_pump_res["electrical_power_kw"] * self.num_trains
        p_booster_kw = booster_res["electrical_power_kw"] * self.num_trains
        total_power_kw = p_hp_pump_kw + p_booster_kw + 15.0 # Add ~15 kW auxiliary power for intake/pretreatment

        # Specific Energy Consumption SEC [kWh/m³] = Total_Power_kW / Permeate_Flow_m3h
        q_perm_total_m3h = plant_permeate.volume_flow_m3_h
        sec_kwh_m3 = total_power_kw / max(1e-3, q_perm_total_m3h)

        plant_recovery_pct = (plant_permeate_mass_kg_s / raw_intake_stream.mass_flow_kg_s) * 100.0 if raw_intake_stream.mass_flow_kg_s > 0 else 0.0

        return {
            "plant_name": self.name,
            "num_trains": self.num_trains,
            "raw_intake_flow_m3h": round(raw_intake_stream.volume_flow_m3_h, 1),
            "permeate_product_flow_m3h": round(q_perm_total_m3h, 1),
            "permeate_product_flow_m3d": round(q_perm_total_m3h * 24.0, 1),
            "permeate_tds_mg_l": round(plant_permeate.tds_mg_l, 1),
            "plant_recovery_pct": round(plant_recovery_pct, 2),
            "feed_pressure_bar": self.target_hp_pressure_bar,
            "hp_pump_power_kw": round(p_hp_pump_kw, 1),
            "px_booster_power_kw": round(p_booster_kw, 1),
            "total_plant_power_kw": round(total_power_kw, 1),
            "specific_energy_consumption_kwh_m3": round(sec_kwh_m3, 3),
            "px_power_recovered_kw": round(px_res["power_recovered_kw"] * self.num_trains, 1),
            "single_train_sample": single_train_res,
            "product_permeate": plant_permeate,
            "brine_discharge": plant_brine
        }
