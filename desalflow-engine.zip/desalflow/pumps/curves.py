"""
DESALFLOW ENGINE - Pump Curves Model
Supports polynomial, tabulated, and measured pump performance curves:
- H(Q) : Head vs Flow
- eta(Q) : Efficiency vs Flow
- P(Q) : Power vs Flow
"""

import numpy as np
from typing import List, Tuple, Callable, Optional

class PumpCurve:
    def __init__(
        self,
        head_coefficients: List[float],  # Polynomial coefficients [a0, a1, a2, ...] H(Q) = a0 + a1*Q + a2*Q^2 ...
        efficiency_coefficients: List[float], # eta(Q) = b0 + b1*Q + b2*Q^2 ...
        q_min_m3h: float = 0.0,
        q_max_m3h: float = 2000.0,
        bep_q_m3h: float = 1000.0
    ):
        self.head_coeffs = np.array(head_coefficients, dtype=float)
        self.eff_coeffs = np.array(efficiency_coefficients, dtype=float)
        self.q_min_m3h = float(q_min_m3h)
        self.q_max_m3h = float(q_max_m3h)
        self.bep_q_m3h = float(bep_q_m3h)

    @classmethod
    def create_standard_swro_pump_curve(cls, q_design_m3h: float = 1000.0, head_design_m: float = 650.0) -> "PumpCurve":
        """
        Creates a realistic high-efficiency centrifugal SWRO pump curve centered on design point.
        BEP efficiency ~ 88%.
        """
        q = q_design_m3h
        h = head_design_m
        
        # H(Q) = H_shutoff - k*Q^2 where H_shutoff ~ 1.2 * H_design
        h_shutoff = 1.20 * h
        k_h = (h_shutoff - h) / (q ** 2)
        head_coeffs = [h_shutoff, 0.0, -k_h]
        
        # eta(Q) parabola peaking at Q_design with eta_max = 0.88
        # eta(Q) = 0.88 - c * (Q - Q_design)^2
        c_eff = 0.88 / (q ** 2)
        b0 = 0.88 - c_eff * (q ** 2)
        b1 = 2.0 * c_eff * q
        b2 = -c_eff
        eff_coeffs = [b0, b1, b2]

        return cls(
            head_coefficients=head_coeffs,
            efficiency_coefficients=eff_coeffs,
            q_min_m3h=0.3 * q,
            q_max_m3h=1.4 * q,
            bep_q_m3h=q
        )

    def get_head_m(self, flow_m3h: float) -> float:
        q = max(0.0, flow_m3h)
        val = np.polyval(self.head_coeffs[::-1], q)
        return max(0.0, float(val))

    def get_efficiency(self, flow_m3h: float) -> float:
        q = max(0.0, flow_m3h)
        val = np.polyval(self.eff_coeffs[::-1], q)
        return max(0.10, min(0.92, float(val)))
