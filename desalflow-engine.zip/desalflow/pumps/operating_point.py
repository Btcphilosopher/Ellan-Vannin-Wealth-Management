"""
DESALFLOW ENGINE - Pump Operating Point Solver
Solves intersection of PUMP CURVE H_pump(Q) vs SYSTEM CURVE H_sys(Q):
H_sys(Q) = H_static + K_sys * Q^2
"""

from typing import Dict, Any, Tuple
import math
from desalflow.pumps.curves import PumpCurve
from desalflow.core.solver import NumericalSolver

class PumpOperatingPointSolver:
    @staticmethod
    def solve(
        pump_curve: PumpCurve,
        static_head_m: float,
        system_k_factor: float, # H_friction = K_sys * Q^2
        q_initial_m3h: float = 1000.0
    ) -> Dict[str, Any]:
        """Solves H_pump(Q) - (H_static + K_sys * Q^2) = 0"""
        def residual(q: float) -> float:
            h_pump = pump_curve.get_head_m(q)
            h_sys = static_head_m + system_k_factor * (q ** 2)
            return h_pump - h_sys

        # Bracket search for root
        q_op = NumericalSolver.solve_1d_root(
            f=residual,
            bracket=(0.1, pump_curve.q_max_m3h * 1.5),
            name="Pump Operating Point"
        )

        h_op = pump_curve.get_head_m(q_op)
        eff_op = pump_curve.get_efficiency(q_op)

        return {
            "operating_flow_m3h": round(q_op, 2),
            "operating_head_m": round(h_op, 2),
            "operating_efficiency": round(eff_op, 4),
            "static_head_m": round(static_head_m, 2),
            "friction_head_m": round(system_k_factor * (q_op ** 2), 2)
        }
