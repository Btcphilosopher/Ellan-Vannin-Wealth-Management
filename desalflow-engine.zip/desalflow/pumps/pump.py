"""
DESALFLOW ENGINE - High Pressure Pump Model
Calculates:
- Hydraulic power: P_hydraulic = rho * g * Q * H = Q * Delta_P [W]
- Shaft power: P_shaft = P_hydraulic / eta_hydraulic [W]
- Electrical power: P_elec = P_shaft / eta_motor [W]
Uses strict explicit unit handling.
"""

import math
from typing import Dict, Any, Optional
from desalflow.core.units import Units
from desalflow.water.stream import WaterStream
from desalflow.pumps.curves import PumpCurve

class HighPressurePump:
    def __init__(
        self,
        design_flow_m3h: float = 1000.0,
        target_discharge_pressure_bar: float = 65.0,
        efficiency_hydraulic: float = 0.88,
        efficiency_motor: float = 0.96,
        vfd_speed_ratio: float = 1.0,
        pump_curve: Optional[PumpCurve] = None,
        name: str = "High-Pressure Pump"
    ):
        self.name = name
        self.design_flow_m3h = float(design_flow_m3h)
        self.target_discharge_pressure_bar = float(target_discharge_pressure_bar)
        self.efficiency_hydraulic = float(efficiency_hydraulic)
        self.efficiency_motor = float(efficiency_motor)
        self.vfd_speed_ratio = max(0.5, min(1.2, float(vfd_speed_ratio)))
        
        if pump_curve is None:
            head_m = (target_discharge_pressure_bar * 1e5) / (1025.0 * 9.80665)
            self.pump_curve = PumpCurve.create_standard_swro_pump_curve(design_flow_m3h, head_m)
        else:
            self.pump_curve = pump_curve

    def calculate(
        self,
        inlet_stream: WaterStream,
        target_pressure_bar: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Calculates pump operation given suction inlet stream and target discharge pressure.
        """
        p_target_bar = target_pressure_bar if target_pressure_bar is not None else self.target_discharge_pressure_bar
        p_target_pa = p_target_bar * 1e5

        # Pressure boost required Delta_P = P_discharge - P_suction
        dp_pa = max(0.0, p_target_pa - inlet_stream.pressure_pa)
        dp_bar = dp_pa / 1e5

        # Head H = Delta_P / (rho * g)
        g = 9.80665
        rho = inlet_stream.density_kg_m3
        head_m = dp_pa / (rho * g) if rho > 0 else 0.0

        # Hydraulic power P_hydraulic = Q * Delta_P [W]
        q_m3s = inlet_stream.volume_flow_m3_s
        p_hydraulic_w = q_m3s * dp_pa

        # Efficiency calculation (using affinity laws or curve if present)
        eta_hyd = self.pump_curve.get_efficiency(inlet_stream.volume_flow_m3_h / self.vfd_speed_ratio) if self.pump_curve else self.efficiency_hydraulic
        eta_combined = max(0.1, eta_hyd * self.efficiency_motor)

        # Shaft and Electrical power
        p_shaft_w = p_hydraulic_w / max(0.1, eta_hyd)
        p_elec_w = p_shaft_w / max(0.1, self.efficiency_motor)

        outlet_stream = WaterStream(
            temperature_k=inlet_stream.temperature_k + (p_shaft_w - p_hydraulic_w) / (inlet_stream.mass_flow_kg_s * inlet_stream.specific_heat_j_kg_k) if inlet_stream.mass_flow_kg_s > 0 else inlet_stream.temperature_k,
            pressure_pa=p_target_pa,
            mass_flow_kg_s=inlet_stream.mass_flow_kg_s,
            salinity_g_kg=inlet_stream.salinity_g_kg,
            composition=inlet_stream.composition,
            name=f"{self.name}_Discharge"
        )

        return {
            "suction_pressure_bar": inlet_stream.pressure_bar,
            "discharge_pressure_bar": p_target_bar,
            "pressure_boost_bar": dp_bar,
            "head_m": head_m,
            "hydraulic_power_kw": Units.w_to_kw(p_hydraulic_w),
            "shaft_power_kw": Units.w_to_kw(p_shaft_w),
            "electrical_power_kw": Units.w_to_kw(p_elec_w),
            "hydraulic_efficiency": eta_hyd,
            "motor_efficiency": self.efficiency_motor,
            "overall_efficiency": eta_combined,
            "outlet_stream": outlet_stream
        }
