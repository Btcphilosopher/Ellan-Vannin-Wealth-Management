"""
DESALFLOW ENGINE - Hard-Engineering Command-Line Interface (CLI)
Provides CLI execution commands:
- `desalflow simulate`: Runs steady-state plant simulation
- `desalflow solve`: Solves plant operating point and conservation balances
- `desalflow sweep`: Runs parametric pressure/salinity sweep
- `desalflow optimize`: Runs SEC minimization solver
"""

import sys
import json
import argparse
from typing import Dict, Any
from desalflow.simulation.steady_state import SteadyStateSimulator
from desalflow.analysis.sweeps import ParametricSweepGenerator
from desalflow.optimisation.operation import OperationOptimizer
from desalflow.optimisation.design import PlantSizer

def main():
    parser = argparse.ArgumentParser(
        prog="desalflow",
        description="DESALFLOW ENGINE - Hard-Engineering Desalination Process Simulator"
    )
    subparsers = parser.add_subparsers(dest="command")

    # Command 1: simulate
    sim_parser = subparsers.add_parser("simulate", help="Run steady-state plant simulation")
    sim_parser.add_argument("--temp", type=float, default=25.0, help="Feed Temperature [°C]")
    sim_parser.add_argument("--salinity", type=float, default=35.0, help="Feed Salinity [g/kg]")
    sim_parser.add_argument("--flow", type=float, default=2000.0, help="Intake Flow [m³/h]")
    sim_parser.add_argument("--pressure", type=float, default=65.0, help="Feed Pressure [bar]")

    # Command 2: sweep
    sweep_parser = subparsers.add_parser("sweep", help="Run pressure parametric sweep")
    sweep_parser.add_argument("--pmin", type=float, default=52.0, help="Min Pressure [bar]")
    sweep_parser.add_argument("--pmax", type=float, default=76.0, help="Max Pressure [bar]")
    sweep_parser.add_argument("--steps", type=int, default=7, help="Number of steps")

    # Command 3: optimize
    opt_parser = subparsers.add_parser("optimize", help="Minimize SEC subject to TDS constraint")
    opt_parser.add_argument("--tds-max", type=float, default=300.0, help="Max Permeate TDS constraint [mg/L]")

    # Command 4: size
    size_parser = subparsers.add_parser("size", help="Size SWRO plant from target capacity")
    size_parser.add_argument("--capacity", type=float, default=50000.0, help="Target capacity [m³/day]")

    args = parser.parse_args()

    if args.command == "simulate" or args.command is None:
        temp = getattr(args, "temp", 25.0)
        sal = getattr(args, "salinity", 35.0)
        flow = getattr(args, "flow", 2000.0)
        p = getattr(args, "pressure", 65.0)

        sim = SteadyStateSimulator()
        res = sim.run(intake_temperature_c=temp, intake_salinity_g_kg=sal, intake_flow_m3h=flow, hp_pressure_bar=p)
        print(json.dumps(res, indent=2, default=str))

    elif args.command == "sweep":
        pressures = [float(x) for x in list(range(int(args.pmin), int(args.pmax) + 1, int((args.pmax - args.pmin) / (args.steps - 1))))]
        data = ParametricSweepGenerator.pressure_sweep(pressures)
        print(json.dumps(data, indent=2))

    elif args.command == "optimize":
        opt = OperationOptimizer.minimize_sec(max_permeate_tds_mg_l=args.tds_max)
        print(json.dumps(opt, indent=2))

    elif args.command == "size":
        size_res = PlantSizer.size_swro_plant(target_capacity_m3d=args.capacity)
        print(json.dumps(size_res, indent=2))

if __name__ == "__main__":
    main()
