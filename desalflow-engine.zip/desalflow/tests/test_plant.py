"""
DESALFLOW ENGINE - Physics Validation & Test Suite
Test Plant: DESALFLOW-TEST-01
Verifies:
1. Sharqawy thermodynamic property correlation outputs against published benchmarks
2. Solution-diffusion transport equations
3. Concentration polarization film theory
4. Conservation laws: Mass balance residual < 1e-5 relative, Salt balance residual < 1e-4
5. Specific Energy Consumption SEC calculation in SWRO regime (typically 2.5 - 3.8 kWh/m³)
"""

import pytest
from desalflow.core.units import Units
from desalflow.core.quantities import DimensionalCheck
from desalflow.water.chemistry import WaterComposition
from desalflow.water.properties import SeawaterProperties
from desalflow.water.osmotic import OsmoticPressureModel
from desalflow.water.stream import WaterStream
from desalflow.hydraulics.pipe import Pipe
from desalflow.membranes.membrane import MembraneSpecification
from desalflow.membranes.transport import SolutionDiffusionModel
from desalflow.simulation.steady_state import SteadyStateSimulator
from desalflow.balances.water import MassBalanceValidator
from desalflow.balances.salt import SaltBalanceValidator

def test_sharqawy_seawater_density():
    # At 25°C (298.15 K) and 35 g/kg salinity, density should be ~ 1023.3 kg/m³
    rho = SeawaterProperties.density(298.15, 35.0, 101325.0)
    assert 1020.0 <= rho <= 1026.0

def test_osmotic_pressure():
    # Seawater 35 g/kg at 25°C should have osmotic pressure ~ 27-30 bar
    pi_pa = OsmoticPressureModel.sharqawy_seawater_osmotic_pressure(298.15, 35.0)
    pi_bar = Units.pa_to_bar(pi_pa)
    assert 26.5 <= pi_bar <= 30.5

def test_water_stream_creation():
    stream = WaterStream(temperature_k=298.15, pressure_pa=65e5, volume_flow_m3_s=0.5, salinity_g_kg=35.0, name="TestFeed")
    assert stream.temperature_c == 25.0
    assert stream.pressure_bar == 65.0
    assert stream.mass_flow_kg_s > 0.0

def test_pipe_hydraulic_friction():
    stream = WaterStream(temperature_k=298.15, pressure_pa=10e5, volume_flow_m3_s=0.10, salinity_g_kg=35.0)
    pipe = Pipe(length_m=50.0, inner_diameter_m=0.20)
    res = pipe.calculate_pressure_drop(stream)
    assert res["velocity_m_s"] > 0.0
    assert res["reynolds"] > 4000.0 # Turbulent
    assert res["total_pressure_drop_bar"] > 0.0

def test_membrane_solution_diffusion():
    spec = MembraneSpecification.dow_filmtec_sw30hrle_440()
    res = SolutionDiffusionModel.calculate_fluxes(
        spec=spec,
        p_feed_pa=65e5, # 65 bar feed
        p_permeate_pa=101325.0,
        c_surface_g_kg=38.0,
        c_bulk_g_kg=35.0,
        c_permeate_guess_g_kg=0.15,
        temperature_k=298.15
    )
    assert res["water_flux_lmh"] > 5.0 # Positive flux
    assert res["intrinsic_rejection_pct"] > 99.0 # > 99% rejection

def test_full_plant_simulation_and_balances():
    sim = SteadyStateSimulator()
    run_res = sim.run(
        intake_temperature_c=25.0,
        intake_salinity_g_kg=35.0,
        intake_flow_m3h=2000.0,
        hp_pressure_bar=65.0
    )
    
    summary = run_res["plant_summary"]
    balances = run_res["conservation_balances"]

    # 1. Product quality check: SWRO permeate TDS < 350 mg/L
    assert summary["permeate_tds_mg_l"] < 400.0
    
    # 2. Recovery check
    assert 25.0 <= summary["plant_recovery_pct"] <= 55.0

    # 3. SEC check
    assert 2.0 <= summary["specific_energy_consumption_kwh_m3"] <= 10.0

    # 4. Conservation law assertions
    assert balances["mass_balance"]["is_balanced"] is True
    assert balances["salt_balance"]["is_balanced"] is True
