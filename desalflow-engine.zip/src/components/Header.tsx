import React from 'react';
import { Activity, ShieldCheck, Cpu, Terminal, RefreshCw } from 'lucide-react';

interface HeaderProps {
  isSimulating: boolean;
  onRunSimulation: () => void;
  lastSolvedTime?: string;
}

export const Header: React.FC<HeaderProps> = ({ isSimulating, onRunSimulation, lastSolvedTime }) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <div className="p-2.5 bg-blue-600/20 border border-blue-500/40 rounded-lg text-blue-400">
          <Activity className="w-6 h-6" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-white font-mono">DESALFLOW ENGINE</h1>
            <span className="text-xs px-2 py-0.5 bg-blue-950 text-blue-300 border border-blue-800 rounded font-mono">
              v1.0.0
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Hard-Engineering Numerical Desalination Process & Physical Equipment Simulator
          </p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="hidden lg:flex items-center gap-3 text-xs text-slate-400 font-mono border-r border-slate-800 pr-4">
          <div className="flex items-center gap-1.5 text-emerald-400">
            <ShieldCheck className="w-4 h-4" />
            <span>Conservation Laws Active</span>
          </div>
          <div className="flex items-center gap-1.5 text-blue-400">
            <Cpu className="w-4 h-4" />
            <span>SciPy Solvers Ready</span>
          </div>
        </div>

        {lastSolvedTime && (
          <span className="text-xs font-mono text-slate-400 hidden sm:inline">
            Solved: {lastSolvedTime}
          </span>
        )}

        <button
          onClick={onRunSimulation}
          disabled={isSimulating}
          id="run-simulation-btn"
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 text-white font-medium px-4 py-2 rounded-lg text-sm transition-all shadow-sm shadow-blue-900/40 font-mono cursor-pointer"
        >
          <RefreshCw className={`w-4 h-4 ${isSimulating ? 'animate-spin' : ''}`} />
          <span>{isSimulating ? 'SOLVING PHYSICS...' : 'EXECUTE SIMULATION'}</span>
        </button>
      </div>
    </header>
  );
};
