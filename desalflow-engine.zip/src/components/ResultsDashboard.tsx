import React from 'react';
import { Zap, CheckCircle2, AlertTriangle, Scale, Gauge, Activity, Cpu } from 'lucide-react';
import { SimulationResult } from '../types';

interface ResultsDashboardProps {
  result?: SimulationResult;
}

export const ResultsDashboard: React.FC<ResultsDashboardProps> = ({ result }) => {
  if (!result) return null;

  const { plant_summary, conservation_balances } = result;
  const { mass_balance, salt_balance, energy_balance } = conservation_balances;

  return (
    <div className="space-y-6">
      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Permeate TDS */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            Product Permeate TDS
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-emerald-400">
              {plant_summary.permeate_tds_mg_l}
            </span>
            <span className="text-xs font-mono text-slate-400">mg/L</span>
          </div>
          <span className="text-[10px] font-mono text-emerald-500/80 mt-1 block">
            WHO Potable Target &lt; 500 mg/L
          </span>
        </div>

        {/* Card 2: Specific Energy Consumption */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            Specific Energy (SEC)
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-amber-400">
              {plant_summary.specific_energy_consumption_kwh_m3}
            </span>
            <span className="text-xs font-mono text-slate-400">kWh/m³</span>
          </div>
          <span className="text-[10px] font-mono text-amber-500/80 mt-1 block">
            SWRO Benchmark ~ 2.5 - 3.8 kWh/m³
          </span>
        </div>

        {/* Card 3: Total Power */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            Total Electrical Power
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-blue-400">
              {plant_summary.total_plant_power_kw.toLocaleString()}
            </span>
            <span className="text-xs font-mono text-slate-400">kW</span>
          </div>
          <span className="text-[10px] font-mono text-blue-500/80 mt-1 block">
            HP Pump + PX Booster
          </span>
        </div>

        {/* Card 4: Plant Recovery */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
            Plant Recovery Ratio
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-cyan-400">
              {plant_summary.plant_recovery_pct}
            </span>
            <span className="text-xs font-mono text-slate-400">%</span>
          </div>
          <span className="text-[10px] font-mono text-cyan-500/80 mt-1 block">
            Design Optimum: 42 - 48%
          </span>
        </div>
      </div>

      {/* Conservation Laws Verification Panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm text-slate-100">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Scale className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider font-mono">
              Numerical Conservation Laws Audit
            </h3>
          </div>
          <span className="text-xs px-2.5 py-1 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded font-mono flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Strict Conservation Passed
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Mass Conservation */}
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-mono text-slate-300 font-semibold">Total Water Mass Balance</span>
              <span className="text-[11px] font-mono text-emerald-400">{mass_balance.status}</span>
            </div>
            <div className="space-y-1 text-xs font-mono text-slate-400">
              <div className="flex justify-between">
                <span>Mass In:</span>
                <span className="text-slate-200">{mass_balance.total_mass_in_kg_s.toFixed(3)} kg/s</span>
              </div>
              <div className="flex justify-between">
                <span>Mass Out:</span>
                <span className="text-slate-200">{mass_balance.total_mass_out_kg_s.toFixed(3)} kg/s</span>
              </div>
              <div className="flex justify-between border-t border-slate-800 pt-1 mt-1">
                <span>Residual Error:</span>
                <span className="text-emerald-400">{mass_balance.residual_kg_s.toExponential(3)} kg/s</span>
              </div>
            </div>
          </div>

          {/* Salt Conservation */}
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-mono text-slate-300 font-semibold">Solute Salt Mass Balance</span>
              <span className="text-[11px] font-mono text-emerald-400">{salt_balance.status}</span>
            </div>
            <div className="space-y-1 text-xs font-mono text-slate-400">
              <div className="flex justify-between">
                <span>Salt In:</span>
                <span className="text-slate-200">{salt_balance.total_salt_in_kg_s.toFixed(4)} kg/s</span>
              </div>
              <div className="flex justify-between">
                <span>Salt Out:</span>
                <span className="text-slate-200">{salt_balance.total_salt_out_kg_s.toFixed(4)} kg/s</span>
              </div>
              <div className="flex justify-between border-t border-slate-800 pt-1 mt-1">
                <span>Relative Error:</span>
                <span className="text-emerald-400">{(salt_balance.relative_error * 100).toExponential(3)} %</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
