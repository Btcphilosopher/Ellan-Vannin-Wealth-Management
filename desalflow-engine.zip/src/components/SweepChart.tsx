import React from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { LineChart as ChartIcon } from 'lucide-react';
import { SweepPoint } from '../types';

interface SweepChartProps {
  data: SweepPoint[];
}

export const SweepChart: React.FC<SweepChartProps> = ({ data }) => {
  if (!data || data.length === 0) return null;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm text-slate-100">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <div className="flex items-center gap-2">
          <ChartIcon className="w-4 h-4 text-amber-400" />
          <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider font-mono">
            Parametric Sweep Performance Curves
          </h3>
        </div>
        <span className="text-xs font-mono text-slate-400">
          Feed Pressure (52 - 76 bar) vs SEC & Flow
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Pressure vs SEC */}
        <div>
          <h4 className="text-xs font-mono text-slate-400 mb-2">Specific Energy Consumption vs Pressure</h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="pressure_bar" stroke="#94a3b8" label={{ value: 'Feed Pressure (bar)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 11 }} />
                <YAxis stroke="#94a3b8" domain={['auto', 'auto']} label={{ value: 'SEC (kWh/m³)', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 11 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Line type="monotone" dataKey="sec_kwh_m3" stroke="#f59e0b" strokeWidth={2.5} dot={{ r: 4 }} name="SEC (kWh/m³)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Pressure vs Permeate Flow */}
        <div>
          <h4 className="text-xs font-mono text-slate-400 mb-2">Product Permeate Flow vs Pressure</h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="pressure_bar" stroke="#94a3b8" label={{ value: 'Feed Pressure (bar)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 11 }} />
                <YAxis stroke="#94a3b8" domain={['auto', 'auto']} label={{ value: 'Permeate Flow (m³/h)', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 11 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Line type="monotone" dataKey="permeate_flow_m3h" stroke="#38bdf8" strokeWidth={2.5} dot={{ r: 4 }} name="Permeate Flow (m³/h)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
