import React, { useState } from 'react';
import { Target, Cpu, Layers, ArrowRight } from 'lucide-react';
import { OptimizationResult, SizingResult } from '../types';

interface OptimizerPanelProps {
  temp: number;
  salinity: number;
  flow: number;
}

export const OptimizerPanel: React.FC<OptimizerPanelProps> = ({ temp, salinity, flow }) => {
  const [targetTds, setTargetTds] = useState<number>(300.0);
  const [targetCapacity, setTargetCapacity] = useState<number>(50000.0);
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [isSizing, setIsSizing] = useState<boolean>(false);
  const [optResult, setOptResult] = useState<OptimizationResult | null>(null);
  const [sizeResult, setSizeResult] = useState<SizingResult | null>(null);

  const handleOptimize = async () => {
    setIsOptimizing(true);
    try {
      const res = await fetch('/api/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tdsMax: targetTds, temp, salinity, flow })
      });
      const data = await res.json();
      setOptResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleSize = async () => {
    setIsSizing(true);
    try {
      const res = await fetch('/api/size', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ capacity: targetCapacity })
      });
      const data = await res.json();
      setSizeResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSizing(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* SciPy Operating Point Optimizer */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm text-slate-100">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider font-mono">
              SciPy Operating Cost Optimizer
            </h3>
          </div>
        </div>

        <p className="text-xs text-slate-400 mb-4">
          Uses SciPy <code className="text-amber-400">minimize</code> (Nelder-Mead algorithm) to find optimal feed pressure that minimizes SEC subject to permeate TDS constraint.
        </p>

        <div className="flex items-center gap-3 mb-4">
          <label htmlFor="target-tds-input" className="text-xs font-mono text-slate-300">Max Permeate TDS Constraint:</label>
          <input
            id="target-tds-input"
            type="number"
            value={targetTds}
            onChange={(e) => setTargetTds(parseFloat(e.target.value) || 300)}
            className="w-24 bg-slate-950 border border-slate-800 text-xs font-mono px-2.5 py-1.5 rounded text-amber-400 font-bold focus:outline-none focus:border-amber-500"
          />
          <span className="text-xs text-slate-400 font-mono">mg/L</span>
          <button
            onClick={handleOptimize}
            disabled={isOptimizing}
            id="scipy-optimize-btn"
            className="ml-auto bg-amber-600 hover:bg-amber-500 disabled:bg-amber-900 text-white text-xs font-mono font-semibold px-3 py-1.5 rounded transition-all cursor-pointer"
          >
            {isOptimizing ? 'SOLVING...' : 'RUN SCIPY MINIMIZER'}
          </button>
        </div>

        {optResult && (
          <div className="bg-slate-950 border border-amber-900/40 p-4 rounded-lg space-y-2 font-mono text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Optimal Feed Pressure:</span>
              <span className="text-amber-400 font-bold">{optResult.optimal_pressure_bar} bar</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Minimum SEC:</span>
              <span className="text-emerald-400 font-bold">{optResult.minimum_sec_kwh_m3} kWh/m³</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Resulting Permeate TDS:</span>
              <span className="text-slate-200">{optResult.resulting_permeate_tds_mg_l} mg/L</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Optimized Recovery:</span>
              <span className="text-cyan-400">{optResult.resulting_recovery_pct}%</span>
            </div>
          </div>
        )}
      </div>

      {/* Engineering Plant Sizer */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm text-slate-100">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider font-mono">
              SWRO Equipment Sizing Engine
            </h3>
          </div>
        </div>

        <p className="text-xs text-slate-400 mb-4">
          Calculates required total membrane surface area, element quantity (SW30HRLE-440), pressure vessels, and train configuration for target plant capacity.
        </p>

        <div className="flex items-center gap-3 mb-4">
          <label htmlFor="target-capacity-input" className="text-xs font-mono text-slate-300">Target Plant Capacity:</label>
          <input
            id="target-capacity-input"
            type="number"
            step="5000"
            value={targetCapacity}
            onChange={(e) => setTargetCapacity(parseFloat(e.target.value) || 50000)}
            className="w-32 bg-slate-950 border border-slate-800 text-xs font-mono px-2.5 py-1.5 rounded text-cyan-400 font-bold focus:outline-none focus:border-cyan-500"
          />
          <span className="text-xs text-slate-400 font-mono">m³/day</span>
          <button
            onClick={handleSize}
            disabled={isSizing}
            id="plant-sizing-btn"
            className="ml-auto bg-cyan-600 hover:bg-cyan-500 disabled:bg-cyan-900 text-white text-xs font-mono font-semibold px-3 py-1.5 rounded transition-all cursor-pointer"
          >
            {isSizing ? 'CALCULATING...' : 'SIZE PLANT'}
          </button>
        </div>

        {sizeResult && (
          <div className="bg-slate-950 border border-cyan-900/40 p-4 rounded-lg space-y-2 font-mono text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Total Membrane Elements:</span>
              <span className="text-cyan-300 font-bold">{sizeResult.total_elements.toLocaleString()} elements</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Total Pressure Vessels:</span>
              <span className="text-slate-200">{sizeResult.total_vessels} vessels ({sizeResult.num_trains} trains x {sizeResult.vessels_per_train})</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Total Active Area:</span>
              <span className="text-slate-200">{sizeResult.total_membrane_area_m2.toLocaleString()} m²</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Actual Average Flux:</span>
              <span className="text-emerald-400 font-bold">{sizeResult.actual_average_flux_lmh} LMH</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
