import React from 'react';
import { Sliders, Thermometer, Droplets, Gauge, Waves } from 'lucide-react';

interface InputPanelProps {
  temp: number;
  setTemp: (v: number) => void;
  salinity: number;
  setSalinity: (v: number) => void;
  flow: number;
  setFlow: (v: number) => void;
  pressure: number;
  setPressure: (v: number) => void;
  onRun: () => void;
}

export const InputPanel: React.FC<InputPanelProps> = ({
  temp,
  setTemp,
  salinity,
  setSalinity,
  flow,
  setFlow,
  pressure,
  setPressure,
  onRun,
}) => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm text-slate-100">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-blue-400" />
          <h2 className="text-sm font-semibold text-slate-200 uppercase tracking-wider font-mono">
            Process Operating Parameters
          </h2>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Input 1: Temperature */}
        <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800/80">
          <div className="flex items-center justify-between mb-2">
            <label htmlFor="temp-input" className="text-xs font-mono text-slate-400 flex items-center gap-1.5">
              <Thermometer className="w-3.5 h-3.5 text-amber-400" />
              Feed Temperature
            </label>
            <span className="text-sm font-mono font-bold text-amber-400">{temp} °C</span>
          </div>
          <input
            id="temp-input"
            type="range"
            min="10"
            max="42"
            step="0.5"
            value={temp}
            onChange={(e) => setTemp(parseFloat(e.target.value))}
            className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
            <span>10 °C</span>
            <span>25 °C</span>
            <span>42 °C</span>
          </div>
        </div>

        {/* Input 2: Salinity */}
        <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800/80">
          <div className="flex items-center justify-between mb-2">
            <label htmlFor="salinity-input" className="text-xs font-mono text-slate-400 flex items-center gap-1.5">
              <Droplets className="w-3.5 h-3.5 text-cyan-400" />
              Feed Salinity
            </label>
            <span className="text-sm font-mono font-bold text-cyan-400">{salinity} g/kg</span>
          </div>
          <input
            id="salinity-input"
            type="range"
            min="20"
            max="50"
            step="0.5"
            value={salinity}
            onChange={(e) => setSalinity(parseFloat(e.target.value))}
            className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
            <span>20 (Brackish)</span>
            <span>35 (Std SW)</span>
            <span>50 (Red Sea)</span>
          </div>
        </div>

        {/* Input 3: Intake Flow */}
        <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800/80">
          <div className="flex items-center justify-between mb-2">
            <label htmlFor="flow-input" className="text-xs font-mono text-slate-400 flex items-center gap-1.5">
              <Waves className="w-3.5 h-3.5 text-blue-400" />
              Intake Feed Flow
            </label>
            <span className="text-sm font-mono font-bold text-blue-400">{flow} m³/h</span>
          </div>
          <input
            id="flow-input"
            type="range"
            min="500"
            max="5000"
            step="100"
            value={flow}
            onChange={(e) => setFlow(parseFloat(e.target.value))}
            className="w-full accent-blue-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
            <span>500 m³/h</span>
            <span>2000 m³/h</span>
            <span>5000 m³/h</span>
          </div>
        </div>

        {/* Input 4: Target HP Pressure */}
        <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800/80">
          <div className="flex items-center justify-between mb-2">
            <label htmlFor="pressure-input" className="text-xs font-mono text-slate-400 flex items-center gap-1.5">
              <Gauge className="w-3.5 h-3.5 text-emerald-400" />
              Target HP Feed Pressure
            </label>
            <span className="text-sm font-mono font-bold text-emerald-400">{pressure} bar</span>
          </div>
          <input
            id="pressure-input"
            type="range"
            min="50"
            max="80"
            step="0.5"
            value={pressure}
            onChange={(e) => setPressure(parseFloat(e.target.value))}
            className="w-full accent-emerald-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
            <span>50 bar</span>
            <span>65 bar</span>
            <span>80 bar</span>
          </div>
        </div>
      </div>
    </div>
  );
};
