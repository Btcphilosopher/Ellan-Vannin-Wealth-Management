import React from 'react';
import { ArrowRight, Filter as FilterIcon, Zap, Shield, ChevronRight } from 'lucide-react';
import { PlantSummary } from '../types';

interface ProcessDiagramProps {
  summary?: PlantSummary;
}

export const ProcessDiagram: React.FC<ProcessDiagramProps> = ({ summary }) => {
  if (!summary) return null;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm text-slate-100">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <h2 className="text-sm font-semibold text-slate-200 uppercase tracking-wider font-mono">
          Process Topology Flow Diagram (PFD)
        </h2>
        <span className="text-xs font-mono text-slate-400">
          4-Train Parallel SWRO Setup
        </span>
      </div>

      <div className="overflow-x-auto pb-2">
        <div className="min-w-[800px] grid grid-cols-5 gap-3 items-center">
          {/* Node 1: Intake Water */}
          <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-lg text-center">
            <span className="text-[10px] font-mono text-cyan-400 font-semibold block uppercase mb-1">RAW INTAKE</span>
            <div className="text-base font-bold font-mono text-white mb-1">
              {summary.raw_intake_flow_m3h} <span className="text-xs text-slate-400">m³/h</span>
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              P: 2.0 bar | S: 35.0 g/kg
            </div>
          </div>

          <div className="flex justify-center text-slate-600">
            <ChevronRight className="w-6 h-6 animate-pulse text-blue-500" />
          </div>

          {/* Node 2: Pretreatment */}
          <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-lg text-center">
            <span className="text-[10px] font-mono text-amber-400 font-semibold block uppercase mb-1">PRETREATMENT</span>
            <div className="text-xs font-mono text-slate-300 font-medium mb-1">
              DMF + Cartridge Guard
            </div>
            <div className="text-[10px] font-mono text-slate-400">
              Turbidity &lt; 0.1 NTU
            </div>
            <div className="text-[10px] font-mono text-emerald-400 mt-1">
              SDI_15 &lt; 2.5
            </div>
          </div>

          <div className="flex justify-center text-slate-600">
            <ChevronRight className="w-6 h-6 animate-pulse text-blue-500" />
          </div>

          {/* Node 3: Pumps & ERD Split */}
          <div className="bg-slate-950 border border-blue-900/60 p-3.5 rounded-lg text-center">
            <span className="text-[10px] font-mono text-blue-400 font-semibold block uppercase mb-1">HP PUMP & PX ERD</span>
            <div className="text-xs font-mono text-white font-bold mb-1">
              {summary.feed_pressure_bar} <span className="text-xs text-slate-400">bar Feed</span>
            </div>
            <div className="text-[10px] font-mono text-slate-400">
              PX Efficiency: 96.0%
            </div>
            <div className="text-[10px] font-mono text-amber-400 mt-1">
              PX Recovered: {summary.px_power_recovered_kw} kW
            </div>
          </div>
        </div>

        {/* Output streams split */}
        <div className="min-w-[800px] grid grid-cols-2 gap-4 mt-4 border-t border-slate-800/80 pt-4">
          {/* Permeate Stream */}
          <div className="bg-emerald-950/30 border border-emerald-800/50 p-4 rounded-lg flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-emerald-400 font-semibold uppercase block">PRODUCT PERMEATE</span>
              <div className="text-lg font-bold font-mono text-emerald-300 mt-0.5">
                {summary.permeate_product_flow_m3h} <span className="text-xs text-emerald-400">m³/h</span>
                <span className="text-xs text-slate-400 font-normal ml-2">({summary.permeate_product_flow_m3d.toLocaleString()} m³/day)</span>
              </div>
            </div>
            <div className="text-right font-mono">
              <span className="text-xs text-slate-300 block">TDS: <strong className="text-emerald-400 font-bold">{summary.permeate_tds_mg_l} mg/L</strong></span>
              <span className="text-[11px] text-slate-400">Recovery: {summary.plant_recovery_pct}%</span>
            </div>
          </div>

          {/* Brine Stream */}
          <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-cyan-400 font-semibold uppercase block">BRINE DISCHARGE</span>
              <div className="text-lg font-bold font-mono text-slate-200 mt-0.5">
                {roundVal(summary.raw_intake_flow_m3h - summary.permeate_product_flow_m3h)} <span className="text-xs text-slate-400">m³/h</span>
              </div>
            </div>
            <div className="text-right font-mono">
              <span className="text-xs text-slate-300 block">Salinity: <strong className="text-cyan-400 font-bold">{summary.brine_discharge.salinity_g_kg} g/kg</strong></span>
              <span className="text-[11px] text-slate-400">PX Discharge: 1.2 bar</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

function roundVal(v: number): number {
  return Math.round(v * 10) / 10;
}
