export interface StreamData {
  name: string;
  temperature_k: number;
  temperature_c: number;
  pressure_pa: number;
  pressure_bar: number;
  osmotic_pressure_bar: number;
  mass_flow_kg_s: number;
  volume_flow_m3_h: number;
  volume_flow_m3_s: number;
  salinity_g_kg: number;
  tds_mg_l: number;
  density_kg_m3: number;
  viscosity_pa_s: number;
  pH: number;
}

export interface PlantSummary {
  plant_name: string;
  num_trains: number;
  raw_intake_flow_m3h: number;
  permeate_product_flow_m3h: number;
  permeate_product_flow_m3d: number;
  permeate_tds_mg_l: number;
  plant_recovery_pct: number;
  feed_pressure_bar: number;
  hp_pump_power_kw: number;
  px_booster_power_kw: number;
  total_plant_power_kw: number;
  specific_energy_consumption_kwh_m3: number;
  px_power_recovered_kw: number;
  product_permeate: StreamData;
  brine_discharge: StreamData;
  single_train_sample: any;
}

export interface ConservationBalances {
  mass_balance: {
    total_mass_in_kg_s: number;
    total_mass_out_kg_s: number;
    residual_kg_s: number;
    relative_error: number;
    is_balanced: boolean;
    status: string;
  };
  salt_balance: {
    total_salt_in_kg_s: number;
    total_salt_out_kg_s: number;
    residual_kg_s: number;
    relative_error: number;
    is_balanced: boolean;
    status: string;
  };
  energy_balance: {
    sec_kwh_m3: number;
    total_power_kw: number;
    product_flow_m3h: number;
  };
}

export interface SimulationResult {
  simulation_type: string;
  plant_summary: PlantSummary;
  conservation_balances: ConservationBalances;
}

export interface SweepPoint {
  pressure_bar: number;
  permeate_flow_m3h: number;
  permeate_tds_mg_l: number;
  recovery_pct: number;
  sec_kwh_m3: number;
  total_power_kw: number;
}

export interface OptimizationResult {
  optimal_pressure_bar: number;
  minimum_sec_kwh_m3: number;
  resulting_permeate_tds_mg_l: number;
  resulting_recovery_pct: number;
  total_plant_power_kw: number;
}

export interface SizingResult {
  target_capacity_m3d: number;
  target_capacity_m3h: number;
  required_feed_flow_m3h: number;
  required_brine_flow_m3h: number;
  recovery_pct: number;
  actual_average_flux_lmh: number;
  num_trains: number;
  vessels_per_train: number;
  total_vessels: number;
  total_elements: number;
  total_membrane_area_m2: number;
}
