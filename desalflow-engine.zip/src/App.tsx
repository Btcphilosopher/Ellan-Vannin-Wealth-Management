import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { InputPanel } from './components/InputPanel';
import { ProcessDiagram } from './components/ProcessDiagram';
import { ResultsDashboard } from './components/ResultsDashboard';
import { SweepChart } from './components/SweepChart';
import { OptimizerPanel } from './components/OptimizerPanel';
import { SimulationResult, SweepPoint } from './types';

export function App() {
  const [temp, setTemp] = useState<number>(25.0);
  const [salinity, setSalinity] = useState<number>(35.0);
  const [flow, setFlow] = useState<number>(2000.0);
  const [pressure, setPressure] = useState<number>(65.0);

  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [sweepData, setSweepData] = useState<SweepPoint[]>([]);
  const [lastSolvedTime, setLastSolvedTime] = useState<string>('');

  const runSimulation = async () => {
    setIsSimulating(true);
    try {
      // 1. Run main physics simulation
      const simRes = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ temp, salinity, flow, pressure })
      });
      const simData: SimulationResult = await simRes.json();
      setResult(simData);

      // 2. Run pressure sweep for curves
      const sweepRes = await fetch('/api/sweep', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pmin: 52.0, pmax: 76.0, temp, salinity, flow })
      });
      const sweepJson = await sweepRes.json();
      if (sweepJson.sweep) {
        setSweepData(sweepJson.sweep);
      }

      const now = new Date();
      setLastSolvedTime(now.toLocaleTimeString());
    } catch (err) {
      console.error("Simulation Execution Error:", err);
    } finally {
      setIsSimulating(false);
    }
  };

  useEffect(() => {
    runSimulation();
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col">
      {/* Header */}
      <Header
        isSimulating={isSimulating}
        onRunSimulation={runSimulation}
        lastSolvedTime={lastSolvedTime}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        {/* Operating Inputs */}
        <InputPanel
          temp={temp}
          setTemp={setTemp}
          salinity={salinity}
          setSalinity={setSalinity}
          flow={flow}
          setFlow={setFlow}
          pressure={pressure}
          setPressure={setPressure}
          onRun={runSimulation}
        />

        {/* Process Flow Diagram */}
        <ProcessDiagram summary={result?.plant_summary} />

        {/* Results & Conservation Audit */}
        <ResultsDashboard result={result} />

        {/* Parametric Sweep Charts */}
        <SweepChart data={sweepData} />

        {/* Optimization & Equipment Sizer */}
        <OptimizerPanel temp={temp} salinity={salinity} flow={flow} />
      </main>

      {/* Engineering Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-500 py-3 px-6 text-center text-xs font-mono">
        DESALFLOW ENGINE &copy; 2026 — Numerical Engineering Desalination Simulator | Sharqawy Property Models | Mass, Salt & Energy Balance Verified
      </footer>
    </div>
  );
}

export default App;
