package com.example

import com.example.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class TerminalOsUnitTest {

    @Test
    fun testMoneyMinorArithmetic() {
        val price1 = MoneyMinor(380L) // £3.80
        val price2 = MoneyMinor(320L) // £3.20
        val sum = price1 + price2
        assertEquals(700L, sum.value)
        assertEquals("£7.00", sum.format(Currency.GBP))
        assertEquals(7.0, sum.toMajorDouble(Currency.GBP), 0.001)

        val jpy = MoneyMinor(1200L)
        assertEquals("¥1200", jpy.format(Currency.JPY))
    }

    @Test
    fun testCartCalculationAndVat() {
        val prodFlatWhite = Product(
            id = "p1",
            sku = "SKU1",
            name = "Flat White",
            description = "",
            category = ProductCategory.COFFEE,
            price = MoneyMinor(380L)
        )
        val prodCroissant = Product(
            id = "p2",
            sku = "SKU2",
            name = "Croissant",
            description = "",
            category = ProductCategory.BAKERY,
            price = MoneyMinor(320L)
        )

        val cart = Cart(
            items = listOf(
                CartItem(prodFlatWhite, 1),
                CartItem(prodCroissant, 1)
            ),
            taxRule = TaxRule(isIncludedInPrice = true, rate = 0.20)
        )

        assertEquals(700L, cart.totalAmount.value)
        assertEquals(2, cart.itemCount)
        assertFalse(cart.isEmpty)
    }

    @Test
    fun testDoubleEntryLedgerBalances() {
        val amount = MoneyMinor(700L)
        val fee = MoneyMinor(30L)
        val net = MoneyMinor(670L)

        val creditEntry = LedgerEntry(
            id = LedgerEntryId("l1"),
            transactionId = TransactionId("t1"),
            paymentIntentId = PaymentIntentId("pi1"),
            type = LedgerEntryType.PAYMENT_CAPTURE,
            amount = amount,
            isDebit = false,
            account = "Merchant Settlement Account",
            contraAccount = "Stripe Clearing Account",
            description = "Card Present Sale"
        )

        val feeEntry = LedgerEntry(
            id = LedgerEntryId("l2"),
            transactionId = TransactionId("t1"),
            paymentIntentId = PaymentIntentId("pi1"),
            type = LedgerEntryType.STRIPE_PROCESSING_FEE,
            amount = fee,
            isDebit = true,
            account = "Stripe Fee Expense",
            contraAccount = "Merchant Settlement Account",
            description = "Processing Fee"
        )

        assertEquals(700L, creditEntry.amount.value)
        assertEquals(30L, feeEntry.amount.value)
        assertEquals(net.value, (creditEntry.amount - feeEntry.amount).value)
    }

    @Test
    fun testReconciliationStatusMatching() {
        val item = ReconciliationItem(
            id = "rec_1",
            paymentIntentId = "pi_1",
            type = ReconciliationType.DUPLICATE,
            status = ResolutionStatus.UNRESOLVED,
            posAmount = MoneyMinor(800L),
            processorAmount = MoneyMinor(1600L),
            description = "Duplicate charge"
        )

        assertEquals(ResolutionStatus.UNRESOLVED, item.status)
        val resolved = item.copy(
            status = ResolutionStatus.RESOLVED,
            auditNote = "Reversed duplicate batch"
        )
        assertEquals(ResolutionStatus.RESOLVED, resolved.status)
    }
}
