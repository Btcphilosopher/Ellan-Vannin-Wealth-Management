package com.example.sdk

import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

sealed class PaymentLifecycleState {
    object Idle : PaymentLifecycleState()
    data class RequiresPaymentMethod(val intent: PaymentIntent) : PaymentLifecycleState()
    data class WaitingForCard(val intent: PaymentIntent, val reader: Reader) : PaymentLifecycleState()
    data class CardDetected(val intent: PaymentIntent, val card: SimulatedCard) : PaymentLifecycleState()
    data class ReadingCard(val intent: PaymentIntent, val card: SimulatedCard) : PaymentLifecycleState()
    data class RequiringPin(val intent: PaymentIntent, val card: SimulatedCard, val enteredDigits: Int) : PaymentLifecycleState()
    data class Authorizing(val intent: PaymentIntent, val card: SimulatedCard) : PaymentLifecycleState()
    data class Processing(val intent: PaymentIntent) : PaymentLifecycleState()
    data class Approved(val intent: PaymentIntent, val transaction: Transaction, val receipt: Receipt) : PaymentLifecycleState()
    data class Declined(val intent: PaymentIntent, val reason: String) : PaymentLifecycleState()
    data class Cancelled(val intent: PaymentIntent, val reason: String) : PaymentLifecycleState()
    data class Error(val intent: PaymentIntent?, val message: String) : PaymentLifecycleState()
}

sealed class PaymentResult {
    data class Succeeded(
        val paymentIntent: PaymentIntent,
        val transaction: Transaction,
        val receipt: Receipt
    ) : PaymentResult()

    data class Failed(
        val paymentIntent: PaymentIntent,
        val declineCode: String,
        val reason: String
    ) : PaymentResult()

    data class Canceled(
        val paymentIntent: PaymentIntent,
        val reason: String
    ) : PaymentResult()
}

sealed class TerminalEvent {
    data class TerminalStateChanged(val status: TerminalStatus) : TerminalEvent()
    data class ReaderDiscovered(val readers: List<Reader>) : TerminalEvent()
    data class ReaderConnected(val reader: Reader) : TerminalEvent()
    data class ReaderDisconnected(val readerId: ReaderId) : TerminalEvent()
    data class PaymentIntentCreated(val intent: PaymentIntent) : TerminalEvent()
    data class PaymentMethodCollected(val intent: PaymentIntent, val card: SimulatedCard) : TerminalEvent()
    data class PaymentAuthorized(val intent: PaymentIntent, val authCode: String) : TerminalEvent()
    data class PaymentCaptured(val intent: PaymentIntent, val transaction: Transaction) : TerminalEvent()
    data class PaymentSucceeded(val transaction: Transaction, val receipt: Receipt) : TerminalEvent()
    data class PaymentFailed(val intent: PaymentIntent, val reason: String) : TerminalEvent()
    data class PaymentCanceled(val intent: PaymentIntent) : TerminalEvent()
    data class RefundCreated(val refund: Refund) : TerminalEvent()
    data class RefundSucceeded(val refund: Refund) : TerminalEvent()
    data class WebhookDispatched(val event: WebhookEvent) : TerminalEvent()
    data class AuditLogged(val record: AuditRecord) : TerminalEvent()
}

interface TerminalClient {
    val terminalState: StateFlow<TerminalStatus>
    val readerState: StateFlow<ReaderConnectionState>
    val activeReader: StateFlow<Reader?>
    val paymentState: StateFlow<PaymentLifecycleState>
    val events: Flow<TerminalEvent>

    suspend fun discoverReaders(): List<Reader>
    suspend fun connectReader(reader: Reader): Result<Reader>
    suspend fun disconnectReader(): Result<Unit>
    suspend fun createPaymentIntent(
        amount: MoneyMinor,
        currency: Currency = Currency.GBP,
        description: String = "POS Payment",
        metadata: Map<String, String> = emptyMap(),
        idempotencyKey: String? = null
    ): Result<PaymentIntent>

    suspend fun collectPaymentMethod(
        paymentIntent: PaymentIntent,
        scenario: TestCardScenario = TestCardScenario.TEST_CARD_APPROVE
    ): Result<PaymentIntent>

    suspend fun cancelPaymentCollection(): Result<PaymentIntent>
    suspend fun confirmPayment(paymentIntent: PaymentIntent): Result<PaymentIntent>
    suspend fun processPayment(
        paymentIntent: PaymentIntent,
        scenario: TestCardScenario = TestCardScenario.TEST_CARD_APPROVE,
        cartItems: List<CartItem> = emptyList()
    ): PaymentResult

    suspend fun refundPayment(
        paymentIntentId: PaymentIntentId,
        amount: MoneyMinor? = null,
        reason: String = "requested_by_customer"
    ): Result<Refund>

    suspend fun cancelPaymentIntent(paymentIntentId: PaymentIntentId): Result<PaymentIntent>
    suspend fun rebootTerminal(): Result<Unit>
    suspend fun triggerSoftwareUpdate(): Result<SoftwareUpdate>
    fun resetPaymentState()
}
