package com.example.sdk

import com.example.data.repository.TerminalRepository
import com.example.domain.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.ConcurrentHashMap

class SimulatedTerminalClient(
    private val repository: TerminalRepository,
    private val defaultTerminalId: TerminalId = TerminalId("tm_soho_01"),
    private val defaultLocationId: LocationId = LocationId("loc_london_soho")
) : TerminalClient {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _terminalState = MutableStateFlow(TerminalStatus.READY)
    override val terminalState: StateFlow<TerminalStatus> = _terminalState.asStateFlow()

    private val _readerState = MutableStateFlow(ReaderConnectionState.READY)
    override val readerState: StateFlow<ReaderConnectionState> = _readerState.asStateFlow()

    private val _activeReader = MutableStateFlow<Reader?>(
        Reader(
            id = ReaderId("rdr_soho_01"),
            label = "Counter 01 (S700)",
            locationId = defaultLocationId,
            locationName = "London Soho",
            serialNumber = "WPOS-GB-884012",
            readerType = ReaderType.STRIPE_S700,
            capabilities = setOf(ReaderCapability.CONTACTLESS, ReaderCapability.CHIP, ReaderCapability.PIN, ReaderCapability.NFC),
            connectionState = ReaderConnectionState.READY,
            ipAddress = "192.168.1.108",
            softwareVersion = "3.2.0.12",
            isDefault = true
        )
    )
    override val activeReader: StateFlow<Reader?> = _activeReader.asStateFlow()

    private val _paymentState = MutableStateFlow<PaymentLifecycleState>(PaymentLifecycleState.Idle)
    override val paymentState: StateFlow<PaymentLifecycleState> = _paymentState.asStateFlow()

    private val _events = MutableSharedFlow<TerminalEvent>(extraBufferCapacity = 64)
    override val events: Flow<TerminalEvent> = _events.asSharedFlow()

    // Idempotency cache: key -> PaymentIntent
    private val idempotencyStore = ConcurrentHashMap<String, PaymentIntent>()

    override suspend fun discoverReaders(): List<Reader> = withContext(Dispatchers.Default) {
        val start = System.currentTimeMillis()
        _readerState.value = ReaderConnectionState.DISCOVERING
        delay(400) // Simulated Bluetooth/LAN discovery scan
        val readers = listOf(
            Reader(ReaderId("rdr_soho_01"), "Counter 01 (S700)", defaultLocationId, "London Soho", "WPOS-GB-884012", ReaderType.STRIPE_S700, connectionState = ReaderConnectionState.READY, isDefault = true),
            Reader(ReaderId("rdr_soho_02"), "Counter 02 (S700)", defaultLocationId, "London Soho", "WPOS-GB-884013", ReaderType.STRIPE_S700, connectionState = ReaderConnectionState.READY),
            Reader(ReaderId("rdr_soho_03"), "Mobile Pod (WisePad 3)", defaultLocationId, "London Soho", "WP3-GB-102931", ReaderType.BBPOS_WISEPAD3, connectionState = ReaderConnectionState.READY),
            Reader(ReaderId("rdr_shoreditch_01"), "Shoreditch Bar (S700)", LocationId("loc_london_shoreditch"), "London Shoreditch", "WPOS-GB-992011", ReaderType.STRIPE_S700, connectionState = ReaderConnectionState.READY),
            Reader(ReaderId("rdr_mcr_01"), "Manchester Bar (S700)", LocationId("loc_manchester"), "Manchester Northern Quarter", "WPOS-GB-334109", ReaderType.STRIPE_S700, connectionState = ReaderConnectionState.READY)
        )
        _readerState.value = if (_activeReader.value != null) ReaderConnectionState.READY else ReaderConnectionState.DISCONNECTED
        _events.emit(TerminalEvent.ReaderDiscovered(readers))
        
        repository.recordApiLog(
            method = "GET",
            path = "/v1/terminal/readers",
            statusCode = 200,
            durationMs = System.currentTimeMillis() - start,
            responsePayload = """{"object":"list","count":${readers.size}}"""
        )
        readers
    }

    override suspend fun connectReader(reader: Reader): Result<Reader> = withContext(Dispatchers.Default) {
        val start = System.currentTimeMillis()
        _readerState.value = ReaderConnectionState.CONNECTING
        _terminalState.value = TerminalStatus.CONNECTING
        delay(600) // Connection handshake
        val connectedReader = reader.copy(connectionState = ReaderConnectionState.READY)
        _activeReader.value = connectedReader
        _readerState.value = ReaderConnectionState.READY
        _terminalState.value = TerminalStatus.READY

        repository.updateReaderStatus(reader.id.value, ReaderConnectionState.READY)
        repository.updateTerminalStatus(defaultTerminalId.value, TerminalStatus.READY)
        _events.emit(TerminalEvent.ReaderConnected(connectedReader))
        _events.emit(TerminalEvent.TerminalStateChanged(TerminalStatus.READY))

        repository.recordApiLog(
            method = "POST",
            path = "/v1/terminal/readers/${reader.id.value}/connect",
            statusCode = 200,
            durationMs = System.currentTimeMillis() - start,
            responsePayload = """{"id":"${reader.id.value}","status":"ready","label":"${reader.label}"}"""
        )

        repository.logAudit(
            who = "pos_operator",
            role = "CASHIER",
            action = "READER_CONNECTED",
            resourceType = "READER",
            resourceId = reader.id.value,
            details = "Connected to reader ${reader.label} via local subnet IP ${reader.ipAddress}",
            terminalId = defaultTerminalId.value,
            locationName = reader.locationName
        )

        // Webhook
        repository.recordWebhook(
            eventType = WebhookEventType.READER_CONNECTED,
            resourceId = reader.id.value,
            payloadJson = """{"id":"${reader.id.value}","object":"terminal.reader","status":"connected"}"""
        )

        Result.success(connectedReader)
    }

    override suspend fun disconnectReader(): Result<Unit> = withContext(Dispatchers.Default) {
        val reader = _activeReader.value ?: return@withContext Result.success(Unit)
        val start = System.currentTimeMillis()
        _readerState.value = ReaderConnectionState.DISCONNECTED
        _terminalState.value = TerminalStatus.OFFLINE
        _activeReader.value = null

        repository.updateReaderStatus(reader.id.value, ReaderConnectionState.DISCONNECTED)
        repository.updateTerminalStatus(defaultTerminalId.value, TerminalStatus.OFFLINE)
        _events.emit(TerminalEvent.ReaderDisconnected(reader.id))
        _events.emit(TerminalEvent.TerminalStateChanged(TerminalStatus.OFFLINE))

        repository.recordApiLog(
            method = "POST",
            path = "/v1/terminal/readers/${reader.id.value}/disconnect",
            statusCode = 200,
            durationMs = System.currentTimeMillis() - start,
            responsePayload = """{"status":"disconnected"}"""
        )

        repository.recordWebhook(
            eventType = WebhookEventType.READER_DISCONNECTED,
            resourceId = reader.id.value,
            payloadJson = """{"id":"${reader.id.value}","object":"terminal.reader","status":"disconnected"}"""
        )

        Result.success(Unit)
    }

    override suspend fun createPaymentIntent(
        amount: MoneyMinor,
        currency: Currency,
        description: String,
        metadata: Map<String, String>,
        idempotencyKey: String?
    ): Result<PaymentIntent> = withContext(Dispatchers.Default) {
        val start = System.currentTimeMillis()
        if (idempotencyKey != null && idempotencyStore.containsKey(idempotencyKey)) {
            val cached = idempotencyStore[idempotencyKey]!!
            return@withContext Result.success(cached)
        }

        val id = PaymentIntentId("pi_${System.currentTimeMillis().toString().takeLast(6)}_${(1000..9999).random()}")
        val intent = PaymentIntent(
            id = id,
            merchantId = MerchantId("acct_merchant_thecoffeehouse"),
            amount = amount,
            currency = currency,
            description = description,
            status = PaymentIntentStatus.REQUIRES_PAYMENT_METHOD,
            terminalId = defaultTerminalId,
            readerId = _activeReader.value?.id,
            metadata = metadata,
            idempotencyKey = idempotencyKey,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        if (idempotencyKey != null) {
            idempotencyStore[idempotencyKey] = intent
        }

        repository.savePaymentIntent(intent)
        _paymentState.value = PaymentLifecycleState.RequiresPaymentMethod(intent)
        _events.emit(TerminalEvent.PaymentIntentCreated(intent))

        val reqPayload = """{"amount":${amount.value},"currency":"${currency.code.lowercase()}","description":"$description"}"""
        val resPayload = """{"id":"${intent.id.value}","object":"payment_intent","amount":${amount.value},"status":"requires_payment_method"}"""
        
        repository.recordApiLog(
            method = "POST",
            path = "/v1/payment_intents",
            statusCode = 201,
            durationMs = System.currentTimeMillis() - start,
            requestPayload = reqPayload,
            responsePayload = resPayload,
            idempotencyKey = idempotencyKey
        )

        repository.recordWebhook(
            eventType = WebhookEventType.PAYMENT_INTENT_CREATED,
            resourceId = intent.id.value,
            payloadJson = resPayload
        )

        Result.success(intent)
    }

    override suspend fun collectPaymentMethod(
        paymentIntent: PaymentIntent,
        scenario: TestCardScenario
    ): Result<PaymentIntent> = withContext(Dispatchers.Default) {
        val reader = _activeReader.value
            ?: return@withContext Result.failure(IllegalStateException("No active card reader connected."))

        _readerState.value = ReaderConnectionState.COLLECTING
        _terminalState.value = TerminalStatus.BUSY
        _paymentState.value = PaymentLifecycleState.WaitingForCard(paymentIntent, reader)

        Result.success(paymentIntent)
    }

    override suspend fun cancelPaymentCollection(): Result<PaymentIntent> = withContext(Dispatchers.Default) {
        val current = _paymentState.value
        val intent = when (current) {
            is PaymentLifecycleState.RequiresPaymentMethod -> current.intent
            is PaymentLifecycleState.WaitingForCard -> current.intent
            is PaymentLifecycleState.CardDetected -> current.intent
            is PaymentLifecycleState.ReadingCard -> current.intent
            is PaymentLifecycleState.RequiringPin -> current.intent
            else -> null
        }

        if (intent != null) {
            val canceledIntent = intent.copy(
                status = PaymentIntentStatus.CANCELED,
                cancellationReason = "abandoned",
                updatedAt = System.currentTimeMillis()
            )
            repository.savePaymentIntent(canceledIntent)
            _paymentState.value = PaymentLifecycleState.Cancelled(canceledIntent, "Payment collection canceled by merchant")
            _readerState.value = ReaderConnectionState.READY
            _terminalState.value = TerminalStatus.READY
            _events.emit(TerminalEvent.PaymentCanceled(canceledIntent))

            repository.recordApiLog(
                method = "POST",
                path = "/v1/payment_intents/${intent.id.value}/cancel",
                statusCode = 200,
                durationMs = 24,
                responsePayload = """{"id":"${intent.id.value}","status":"canceled"}"""
            )
            return@withContext Result.success(canceledIntent)
        }

        Result.failure(IllegalStateException("No active payment collection to cancel."))
    }

    override suspend fun confirmPayment(paymentIntent: PaymentIntent): Result<PaymentIntent> = withContext(Dispatchers.Default) {
        _paymentState.value = PaymentLifecycleState.Authorizing(
            paymentIntent,
            SimulatedCard(
                brand = CardBrand.VISA,
                last4 = "4242",
                entryMethod = EntryMethod.CONTACTLESS_CARD
            )
        )
        Result.success(paymentIntent)
    }

    override suspend fun processPayment(
        paymentIntent: PaymentIntent,
        scenario: TestCardScenario,
        cartItems: List<CartItem>
    ): PaymentResult = withContext(Dispatchers.Default) {
        val start = System.currentTimeMillis()
        val reader = _activeReader.value
            ?: return@withContext PaymentResult.Failed(
                paymentIntent,
                "reader_unavailable",
                "No card reader is connected to terminal."
            )

        val card = SimulatedCard(
            brand = scenario.brand,
            last4 = scenario.last4,
            entryMethod = scenario.defaultEntryMethod
        )

        // 1. Waiting for Card
        _paymentState.value = PaymentLifecycleState.WaitingForCard(paymentIntent, reader)
        _readerState.value = ReaderConnectionState.COLLECTING
        _terminalState.value = TerminalStatus.BUSY
        delay(450)

        // 2. Card Detected
        _paymentState.value = PaymentLifecycleState.CardDetected(paymentIntent, card)
        delay(350)

        // 3. Reading Card Data (EMV/NFC Handshake)
        _paymentState.value = PaymentLifecycleState.ReadingCard(paymentIntent, card)
        delay(400)

        // 4. If PIN scenario, simulate PIN entry on reader
        if (scenario == TestCardScenario.TEST_CARD_CHIP_PIN) {
            for (i in 1..4) {
                _paymentState.value = PaymentLifecycleState.RequiringPin(paymentIntent, card, enteredDigits = i)
                delay(280)
            }
        }

        // 5. Authorizing with Simulated Processor
        _paymentState.value = PaymentLifecycleState.Authorizing(paymentIntent, card)
        _readerState.value = ReaderConnectionState.PROCESSING
        delay(550)

        if (!scenario.willSucceed) {
            val failureReason = scenario.failureReason ?: "Payment authorization failed."
            val failedIntent = paymentIntent.copy(
                status = PaymentIntentStatus.FAILED,
                failureMessage = failureReason,
                paymentMethodDetails = PaymentMethodDetails(
                    brand = card.brand,
                    last4 = card.last4,
                    entryMethod = card.entryMethod
                ),
                updatedAt = System.currentTimeMillis()
            )
            repository.savePaymentIntent(failedIntent)
            _paymentState.value = PaymentLifecycleState.Declined(failedIntent, failureReason)
            _readerState.value = ReaderConnectionState.READY
            _terminalState.value = TerminalStatus.READY
            _events.emit(TerminalEvent.PaymentFailed(failedIntent, failureReason))

            repository.recordApiLog(
                method = "POST",
                path = "/v1/payment_intents/${paymentIntent.id.value}/confirm",
                statusCode = 402,
                durationMs = System.currentTimeMillis() - start,
                responsePayload = """{"error":{"type":"card_error","message":"$failureReason"}}"""
            )

            repository.recordWebhook(
                eventType = WebhookEventType.PAYMENT_INTENT_FAILED,
                resourceId = paymentIntent.id.value,
                payloadJson = """{"id":"${paymentIntent.id.value}","status":"failed","failure_message":"$failureReason"}"""
            )

            return@withContext PaymentResult.Failed(failedIntent, "card_declined", failureReason)
        }

        // 6. Payment Authorization Success & Capture
        val authCode = "AUTH_${(100000..999999).random()}"
        val transactionId = TransactionId("txn_${System.currentTimeMillis().toString().takeLast(6)}_${card.last4}")
        val receiptId = ReceiptId("rcpt_${System.currentTimeMillis().toString().takeLast(6)}")

        val paymentMethodDetails = PaymentMethodDetails(
            brand = card.brand,
            last4 = card.last4,
            expMonth = 12,
            expYear = 2028,
            entryMethod = card.entryMethod,
            cardholderName = card.cardholderName,
            authCode = authCode
        )

        val succeededIntent = paymentIntent.copy(
            status = PaymentIntentStatus.SUCCEEDED,
            paymentMethodDetails = paymentMethodDetails,
            receiptId = receiptId,
            updatedAt = System.currentTimeMillis()
        )

        val transaction = Transaction(
            id = transactionId,
            paymentIntentId = paymentIntent.id,
            merchantId = MerchantId("acct_merchant_thecoffeehouse"),
            locationId = reader.locationId,
            locationName = reader.locationName,
            terminalId = defaultTerminalId,
            terminalName = "Counter 01",
            readerId = reader.id,
            amount = paymentIntent.amount,
            feeAmount = MoneyMinor((paymentIntent.amount.value * 0.014 + 20).toLong()),
            netAmount = MoneyMinor(paymentIntent.amount.value - (paymentIntent.amount.value * 0.014 + 20).toLong()),
            currency = paymentIntent.currency,
            status = TransactionStatus.SUCCEEDED,
            customerName = card.cardholderName,
            paymentMethod = paymentMethodDetails,
            receiptId = receiptId,
            createdAt = System.currentTimeMillis()
        )

        // Construct Receipt Lines from Cart or fallback
        val receiptLines = if (cartItems.isNotEmpty()) {
            cartItems.map { ReceiptLine(it.product.name, it.quantity, it.product.price) }
        } else {
            listOf(ReceiptLine(paymentIntent.description, 1, paymentIntent.amount))
        }

        val taxMinor = MoneyMinor((paymentIntent.amount.value - (paymentIntent.amount.value / 1.20)).toLong())
        val subtotalMinor = MoneyMinor(paymentIntent.amount.value - taxMinor.value)

        val receipt = Receipt(
            id = receiptId,
            transactionId = transactionId,
            paymentIntentId = paymentIntent.id,
            merchantName = "The Coffee House",
            locationAddress = "44 Old Compton St, London W1D 4TY",
            lines = receiptLines,
            subtotal = subtotalMinor,
            tax = ReceiptTax("UK VAT (20%)", 0.20, taxMinor),
            total = paymentIntent.amount,
            currency = paymentIntent.currency,
            cardBrand = card.brand,
            cardLast4 = card.last4,
            authCode = authCode,
            entryMethod = card.entryMethod,
            terminalName = "${reader.label} (${reader.readerType.displayName})",
            timestamp = System.currentTimeMillis()
        )

        // Save everything to DB & Ledger
        repository.savePaymentIntent(succeededIntent)
        repository.saveTransaction(transaction)
        repository.saveReceipt(receipt)

        // Double Entry Ledger: Credit Merchant Settlement, Debit Clearing, Debit Fee Expense
        repository.recordLedgerEntry(
            LedgerEntry(
                id = LedgerEntryId("led_${System.currentTimeMillis().toString().takeLast(6)}_cr"),
                transactionId = transactionId,
                paymentIntentId = paymentIntent.id,
                type = LedgerEntryType.PAYMENT_CAPTURE,
                amount = paymentIntent.amount,
                isDebit = false,
                currency = paymentIntent.currency,
                account = "Merchant Settlement Account",
                contraAccount = "Stripe Clearing Account",
                description = "Point-of-Sale Sale (${card.brand.displayName} •••• ${card.last4})"
            )
        )

        repository.recordLedgerEntry(
            LedgerEntry(
                id = LedgerEntryId("led_${System.currentTimeMillis().toString().takeLast(6)}_fee"),
                transactionId = transactionId,
                paymentIntentId = paymentIntent.id,
                type = LedgerEntryType.STRIPE_PROCESSING_FEE,
                amount = transaction.feeAmount,
                isDebit = true,
                currency = paymentIntent.currency,
                account = "Stripe Fee Expense",
                contraAccount = "Merchant Settlement Account",
                description = "Stripe Card-Present Processing Fee"
            )
        )

        // Audit Trail
        repository.logAudit(
            who = "pos_terminal_${defaultTerminalId.value}",
            role = "POS_SYSTEM",
            action = "PAYMENT_CAPTURED",
            resourceType = "TRANSACTION",
            resourceId = transactionId.value,
            details = "Captured ${paymentIntent.amount.format(paymentIntent.currency)} via ${card.brand.displayName} •••• ${card.last4} (${card.entryMethod.displayName}). Auth code: $authCode",
            terminalId = defaultTerminalId.value,
            locationName = reader.locationName
        )

        // API Log
        repository.recordApiLog(
            method = "POST",
            path = "/v1/payment_intents/${paymentIntent.id.value}/confirm",
            statusCode = 200,
            durationMs = System.currentTimeMillis() - start,
            responsePayload = """{"id":"${paymentIntent.id.value}","status":"succeeded","charges":{"data":[{"id":"${transactionId.value}","paid":true}]}}"""
        )

        // Webhook Dispatch
        repository.recordWebhook(
            eventType = WebhookEventType.PAYMENT_INTENT_SUCCEEDED,
            resourceId = paymentIntent.id.value,
            payloadJson = """{"id":"${paymentIntent.id.value}","object":"payment_intent","amount":${paymentIntent.amount.value},"currency":"${paymentIntent.currency.code.lowercase()}","status":"succeeded","charges":[{"id":"${transactionId.value}"}]}"""
        )

        _paymentState.value = PaymentLifecycleState.Approved(succeededIntent, transaction, receipt)
        _readerState.value = ReaderConnectionState.READY
        _terminalState.value = TerminalStatus.READY
        _events.emit(TerminalEvent.PaymentSucceeded(transaction, receipt))

        PaymentResult.Succeeded(succeededIntent, transaction, receipt)
    }

    override suspend fun refundPayment(
        paymentIntentId: PaymentIntentId,
        amount: MoneyMinor?,
        reason: String
    ): Result<Refund> = withContext(Dispatchers.Default) {
        val start = System.currentTimeMillis()
        val refundId = RefundId("ref_${System.currentTimeMillis().toString().takeLast(6)}")
        val refundAmount = amount ?: MoneyMinor(700L) // Default or specified
        val refund = Refund(
            id = refundId,
            paymentIntentId = paymentIntentId,
            transactionId = TransactionId("txn_${paymentIntentId.value.takeLast(6)}"),
            amount = refundAmount,
            currency = Currency.GBP,
            status = RefundStatus.SUCCEEDED,
            refundType = if (amount == null) RefundType.FULL_REFUND else RefundType.PARTIAL_REFUND,
            reason = reason,
            receiptNumber = "ref_rec_${(10000..99999).random()}",
            createdAt = System.currentTimeMillis()
        )

        repository.saveRefund(refund)

        // Ledger Entry for Refund
        repository.recordLedgerEntry(
            LedgerEntry(
                id = LedgerEntryId("led_${System.currentTimeMillis().toString().takeLast(6)}_ref"),
                transactionId = refund.transactionId,
                paymentIntentId = paymentIntentId,
                type = LedgerEntryType.REFUND,
                amount = refund.amount,
                isDebit = true,
                currency = refund.currency,
                account = "Merchant Settlement Account",
                contraAccount = "Stripe Clearing Account",
                description = "Customer Refund for ${paymentIntentId.value}"
            )
        )

        repository.logAudit(
            who = "sarah_jenkins_manager",
            role = "MERCHANT_OWNER",
            action = "REFUND_ISSUED",
            resourceType = "REFUND",
            resourceId = refundId.value,
            details = "Issued ${refund.amount.format(refund.currency)} refund for intent ${paymentIntentId.value}. Reason: $reason",
            terminalId = defaultTerminalId.value,
            locationName = "London Soho"
        )

        repository.recordApiLog(
            method = "POST",
            path = "/v1/refunds",
            statusCode = 200,
            durationMs = System.currentTimeMillis() - start,
            responsePayload = """{"id":"${refundId.value}","object":"refund","amount":${refund.amount.value},"status":"succeeded"}"""
        )

        repository.recordWebhook(
            eventType = WebhookEventType.REFUND_SUCCEEDED,
            resourceId = refundId.value,
            payloadJson = """{"id":"${refundId.value}","payment_intent":"${paymentIntentId.value}","amount":${refund.amount.value},"status":"succeeded"}"""
        )

        _events.emit(TerminalEvent.RefundSucceeded(refund))
        Result.success(refund)
    }

    override suspend fun cancelPaymentIntent(paymentIntentId: PaymentIntentId): Result<PaymentIntent> = withContext(Dispatchers.Default) {
        val canceled = PaymentIntent(
            id = paymentIntentId,
            amount = MoneyMinor(0L),
            status = PaymentIntentStatus.CANCELED,
            cancellationReason = "requested_by_merchant"
        )
        repository.savePaymentIntent(canceled)
        _events.emit(TerminalEvent.PaymentCanceled(canceled))
        Result.success(canceled)
    }

    override suspend fun rebootTerminal(): Result<Unit> = withContext(Dispatchers.Default) {
        _terminalState.value = TerminalStatus.OFFLINE
        _readerState.value = ReaderConnectionState.DISCONNECTED
        delay(1200)
        _terminalState.value = TerminalStatus.CONNECTING
        delay(600)
        _terminalState.value = TerminalStatus.READY
        _readerState.value = ReaderConnectionState.READY
        repository.updateTerminalStatus(defaultTerminalId.value, TerminalStatus.READY)
        Result.success(Unit)
    }

    override suspend fun triggerSoftwareUpdate(): Result<SoftwareUpdate> = withContext(Dispatchers.Default) {
        _terminalState.value = TerminalStatus.UPDATING
        delay(1000)
        _terminalState.value = TerminalStatus.READY
        Result.success(SoftwareUpdate(currentVersion = "2.5.0", availableVersion = "2.5.0", updateStatus = UpdateJobStatus.COMPLETE))
    }

    override fun resetPaymentState() {
        _paymentState.value = PaymentLifecycleState.Idle
    }
}
