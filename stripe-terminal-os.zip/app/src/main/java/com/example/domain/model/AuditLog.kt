package com.example.domain.model

data class AuditRecord(
    val id: String = "aud_${System.currentTimeMillis().toString().takeLast(6)}",
    val who: String, // user or service identity
    val role: String = "MERCHANT_OWNER",
    val action: String, // e.g. "TERMINAL_CONNECT", "PAYMENT_INTENT_CAPTURED", "REFUND_PROCESSED"
    val resourceType: String,
    val resourceId: String,
    val details: String,
    val requestId: String = "req_${System.currentTimeMillis().toString().takeLast(7)}",
    val terminalId: String? = null,
    val locationName: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
