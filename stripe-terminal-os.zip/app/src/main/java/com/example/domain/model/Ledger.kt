package com.example.domain.model

enum class LedgerEntryType(val displayName: String) {
    PAYMENT_CAPTURE("Payment Capture"),
    STRIPE_PROCESSING_FEE("Processing Fee"),
    REFUND("Refund"),
    PAYOUT("Payout to Bank"),
    ADJUSTMENT("Reconciliation Adjustment"),
    REVERSAL("Charge Reversal")
}

data class LedgerAccount(
    val accountId: String,
    val name: String,
    val currency: Currency = Currency.GBP,
    val balance: MoneyMinor = MoneyMinor.ZERO
)

data class LedgerEntry(
    val id: LedgerEntryId,
    val transactionId: TransactionId?,
    val paymentIntentId: PaymentIntentId?,
    val type: LedgerEntryType,
    val amount: MoneyMinor, // positive = credit, negative = debit
    val isDebit: Boolean,
    val currency: Currency = Currency.GBP,
    val account: String = "Merchant Settlement Account",
    val contraAccount: String = "Stripe Clearing Account",
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)
