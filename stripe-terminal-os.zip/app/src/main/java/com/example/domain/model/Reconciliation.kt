package com.example.domain.model

enum class ReconciliationType(val displayName: String) {
    MATCHED("Matched"),
    DUPLICATE("Duplicate Transaction"),
    MISSING_RECORD("Missing Processor Record"),
    AMOUNT_MISMATCH("Amount Mismatch"),
    CURRENCY_MISMATCH("Currency Mismatch"),
    LATE_CAPTURE("Late Event"),
    UNKNOWN("Unknown Discrepancy")
}

enum class ResolutionStatus(val displayName: String) {
    UNRESOLVED("Action Required"),
    INVESTIGATING("Investigating"),
    RESOLVED("Resolved"),
    DISMISSED("Dismissed")
}

data class ReconciliationItem(
    val id: String,
    val paymentIntentId: String,
    val type: ReconciliationType,
    val status: ResolutionStatus = ResolutionStatus.UNRESOLVED,
    val posAmount: MoneyMinor,
    val processorAmount: MoneyMinor,
    val currency: Currency = Currency.GBP,
    val terminalName: String = "Counter 02",
    val locationName: String = "London Soho",
    val description: String,
    val auditNote: String? = null,
    val resolvedBy: String? = null,
    val resolvedAt: Long? = null,
    val timestamp: Long = System.currentTimeMillis()
)
