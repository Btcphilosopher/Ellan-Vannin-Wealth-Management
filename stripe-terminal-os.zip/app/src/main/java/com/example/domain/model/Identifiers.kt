package com.example.domain.model

@JvmInline
value class PaymentIntentId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class ReaderId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class TerminalId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class MerchantId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class LocationId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class TransactionId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class RefundId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class ReceiptId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class CustomerId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class WebhookEventId(val value: String) {
    override fun toString(): String = value
}

@JvmInline
value class LedgerEntryId(val value: String) {
    override fun toString(): String = value
}
