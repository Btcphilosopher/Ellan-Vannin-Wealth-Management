package com.example.domain.model

import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.Locale

enum class Currency(
    val code: String,
    val symbol: String,
    val decimalPlaces: Int,
    val displayName: String
) {
    GBP("GBP", "£", 2, "British Pound"),
    USD("USD", "$", 2, "US Dollar"),
    EUR("EUR", "€", 2, "Euro"),
    CAD("CAD", "CA$", 2, "Canadian Dollar"),
    AUD("AUD", "AU$", 2, "Australian Dollar"),
    JPY("JPY", "¥", 0, "Japanese Yen");

    companion object {
        fun fromCode(code: String): Currency {
            return entries.find { it.code.equals(code, ignoreCase = true) } ?: GBP
        }
    }
}

@JvmInline
value class MoneyMinor(val value: Long) : Comparable<MoneyMinor> {

    operator fun plus(other: MoneyMinor): MoneyMinor = MoneyMinor(this.value + other.value)
    operator fun minus(other: MoneyMinor): MoneyMinor = MoneyMinor(this.value - other.value)
    operator fun times(multiplier: Long): MoneyMinor = MoneyMinor(this.value * multiplier)
    operator fun times(multiplier: Double): MoneyMinor = MoneyMinor((this.value * multiplier).toLong())

    override fun compareTo(other: MoneyMinor): Int = this.value.compareTo(other.value)

    fun toMajorDouble(currency: Currency = Currency.GBP): Double {
        return if (currency.decimalPlaces == 0) {
            value.toDouble()
        } else {
            value.toDouble() / Math.pow(10.0, currency.decimalPlaces.toDouble())
        }
    }

    fun format(currency: Currency = Currency.GBP): String {
        return if (currency.decimalPlaces == 0) {
            "${currency.symbol}${value}"
        } else {
            val amount = value.toDouble() / 100.0
            val formatter = DecimalFormat("#,##0.00")
            "${currency.symbol}${formatter.format(amount)}"
        }
    }

    companion object {
        val ZERO = MoneyMinor(0L)

        fun fromMajor(major: Double, currency: Currency = Currency.GBP): MoneyMinor {
            val multiplier = if (currency.decimalPlaces == 0) 1.0 else 100.0
            return MoneyMinor((major * multiplier).toLong())
        }

        fun gbp(minor: Long): Money = Money(MoneyMinor(minor), Currency.GBP)
        fun usd(minor: Long): Money = Money(MoneyMinor(minor), Currency.USD)
        fun eur(minor: Long): Money = Money(MoneyMinor(minor), Currency.EUR)
    }
}

data class Money(
    val amount: MoneyMinor,
    val currency: Currency = Currency.GBP
) {
    fun format(): String = amount.format(currency)

    operator fun plus(other: Money): Money {
        require(currency == other.currency) { "Cannot add mismatched currencies: $currency and ${other.currency}" }
        return Money(amount + other.amount, currency)
    }

    operator fun minus(other: Money): Money {
        require(currency == other.currency) { "Cannot subtract mismatched currencies: $currency and ${other.currency}" }
        return Money(amount - other.amount, currency)
    }

    companion object {
        fun zero(currency: Currency = Currency.GBP) = Money(MoneyMinor.ZERO, currency)
        fun gbp(minor: Long) = Money(MoneyMinor(minor), Currency.GBP)
        fun usd(minor: Long) = Money(MoneyMinor(minor), Currency.USD)
        fun eur(minor: Long) = Money(MoneyMinor(minor), Currency.EUR)
    }
}
