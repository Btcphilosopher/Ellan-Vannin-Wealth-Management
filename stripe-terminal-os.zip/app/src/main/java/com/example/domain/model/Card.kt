package com.example.domain.model

enum class CardBrand(val displayName: String, val iconCode: String) {
    VISA("Visa", "VISA"),
    MASTERCARD("Mastercard", "MC"),
    AMEX("American Express", "AMEX"),
    DISCOVER("Discover", "DISC"),
    INTERAC("Interac", "INTERAC"),
    EFTPOS("EFTPOS", "EFTPOS")
}

enum class EntryMethod(val displayName: String) {
    CONTACTLESS_CARD("Contactless Card"),
    PHONE_NFC("Apple / Google Pay"),
    SMARTWATCH_NFC("Smartwatch"),
    CHIP_INSERT("Chip (EMV)"),
    MAGSTRIPE_SWIPE("Magnetic Stripe")
}

enum class TestCardScenario(
    val title: String,
    val description: String,
    val last4: String,
    val brand: CardBrand,
    val defaultEntryMethod: EntryMethod,
    val willSucceed: Boolean,
    val failureReason: String? = null
) {
    TEST_CARD_APPROVE(
        title = "Test Card (Approve)",
        description = "Standard successful payment authorization",
        last4 = "4242",
        brand = CardBrand.VISA,
        defaultEntryMethod = EntryMethod.CONTACTLESS_CARD,
        willSucceed = true
    ),
    TEST_CARD_PHONE_PAY(
        title = "Apple Pay / Google Wallet",
        description = "Biometric authenticated mobile NFC tap",
        last4 = "8891",
        brand = CardBrand.MASTERCARD,
        defaultEntryMethod = EntryMethod.PHONE_NFC,
        willSucceed = true
    ),
    TEST_CARD_CHIP_PIN(
        title = "EMV Chip + PIN",
        description = "Physical chip insertion requiring simulated PIN",
        last4 = "1098",
        brand = CardBrand.VISA,
        defaultEntryMethod = EntryMethod.CHIP_INSERT,
        willSucceed = true
    ),
    TEST_CARD_DECLINE(
        title = "Test Card (Decline)",
        description = "Simulates standard issuer card decline",
        last4 = "0002",
        brand = CardBrand.VISA,
        defaultEntryMethod = EntryMethod.CONTACTLESS_CARD,
        willSucceed = false,
        failureReason = "card_declined: The card was declined by the simulated card issuer."
    ),
    TEST_CARD_INSUFFICIENT_FUNDS(
        title = "Insufficient Funds",
        description = "Simulates issuer 51 decline code",
        last4 = "9995",
        brand = CardBrand.MASTERCARD,
        defaultEntryMethod = EntryMethod.CONTACTLESS_CARD,
        willSucceed = false,
        failureReason = "insufficient_funds: The customer card has insufficient funds."
    ),
    TEST_CARD_EXPIRED(
        title = "Expired Card",
        description = "Simulates expired authorization token",
        last4 = "0069",
        brand = CardBrand.VISA,
        defaultEntryMethod = EntryMethod.CHIP_INSERT,
        willSucceed = false,
        failureReason = "expired_card: The card has expired."
    ),
    TEST_CARD_TIMEOUT(
        title = "Processor Timeout",
        description = "Simulates upstream acquiring gateway latency timeout",
        last4 = "5000",
        brand = CardBrand.VISA,
        defaultEntryMethod = EntryMethod.CONTACTLESS_CARD,
        willSucceed = false,
        failureReason = "gateway_timeout: The simulated acquiring bank timed out."
    ),
    TEST_CARD_CANCEL(
        title = "Cardholder Cancelled",
        description = "Customer aborted transaction on device",
        last4 = "4242",
        brand = CardBrand.VISA,
        defaultEntryMethod = EntryMethod.CONTACTLESS_CARD,
        willSucceed = false,
        failureReason = "customer_canceled: The cardholder pressed cancel on the reader."
    )
}

data class SimulatedCard(
    val id: String = "card_tok_${System.currentTimeMillis().toString().takeLast(6)}",
    val brand: CardBrand,
    val last4: String,
    val expMonth: Int = 12,
    val expYear: Int = 2028,
    val cardholderName: String = "Alex Morgan",
    val funding: String = "credit",
    val entryMethod: EntryMethod,
    val token: String = "tok_${System.currentTimeMillis()}_${brand.name.lowercase()}"
)
