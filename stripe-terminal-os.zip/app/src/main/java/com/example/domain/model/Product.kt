package com.example.domain.model

enum class ProductCategory(val displayName: String, val icon: String) {
    COFFEE("Coffee & Espresso", "LocalCafe"),
    TEA("Artisan Teas", "EmojiFoodBeverage"),
    BAKERY("Pastries & Bakery", "BakeryDining"),
    FOOD("Kitchen & Food", "LunchDining"),
    MERCHANDISE("Retail & Beans", "ShoppingBag")
}

data class TaxRule(
    val id: String = "tax_uk_vat_standard",
    val name: String = "UK Standard VAT (20%)",
    val rate: Double = 0.20,
    val isIncludedInPrice: Boolean = true
)

data class Discount(
    val code: String,
    val description: String,
    val percentage: Double = 0.0,
    val fixedAmount: MoneyMinor = MoneyMinor.ZERO
)

data class Product(
    val id: String,
    val sku: String,
    val name: String,
    val description: String,
    val category: ProductCategory,
    val price: MoneyMinor,
    val currency: Currency = Currency.GBP,
    val taxRate: Double = 0.20,
    val inStock: Boolean = true,
    val stockQuantity: Int = 50,
    val colorAccent: Long = 0xFF635BFF
)

data class CartItem(
    val product: Product,
    val quantity: Int = 1,
    val notes: String? = null
) {
    val lineSubtotal: MoneyMinor get() = MoneyMinor(product.price.value * quantity)
}

data class Cart(
    val items: List<CartItem> = emptyList(),
    val appliedDiscount: Discount? = null,
    val taxRule: TaxRule = TaxRule(),
    val currency: Currency = Currency.GBP
) {
    val rawSubtotal: MoneyMinor get() = MoneyMinor(items.sumOf { it.lineSubtotal.value })
    
    val discountAmount: MoneyMinor get() {
        if (appliedDiscount == null) return MoneyMinor.ZERO
        return if (appliedDiscount.percentage > 0) {
            MoneyMinor((rawSubtotal.value * (appliedDiscount.percentage / 100.0)).toLong())
        } else {
            appliedDiscount.fixedAmount
        }
    }

    val subtotalAfterDiscount: MoneyMinor get() = MoneyMinor(Math.max(0L, rawSubtotal.value - discountAmount.value))

    // If VAT is inclusive (standard UK retail): VAT = subtotal - (subtotal / (1 + rate))
    val taxAmount: MoneyMinor get() {
        return if (taxRule.isIncludedInPrice) {
            val net = subtotalAfterDiscount.value / (1.0 + taxRule.rate)
            MoneyMinor((subtotalAfterDiscount.value - net).toLong())
        } else {
            MoneyMinor((subtotalAfterDiscount.value * taxRule.rate).toLong())
        }
    }

    val totalAmount: MoneyMinor get() {
        return if (taxRule.isIncludedInPrice) {
            subtotalAfterDiscount
        } else {
            subtotalAfterDiscount + taxAmount
        }
    }

    val isEmpty: Boolean get() = items.isEmpty()
    val itemCount: Int get() = items.sumOf { it.quantity }
}
