package com.example.domain.model

data class ApiRequestLog(
    val id: String = "req_${System.currentTimeMillis().toString().takeLast(7)}",
    val method: String, // "POST", "GET", "DELETE"
    val path: String, // "/v1/payment_intents"
    val statusCode: Int, // 200, 201, 400, 402, 500
    val durationMs: Long,
    val requestPayload: String? = null,
    val responsePayload: String? = null,
    val idempotencyKey: String? = null,
    val clientIp: String = "127.0.0.1",
    val timestamp: Long = System.currentTimeMillis()
)
