package com.example.domain.model

enum class TerminalStatus(val displayName: String) {
    OFFLINE("Offline"),
    CONNECTING("Connecting"),
    CONNECTED("Connected"),
    READY("Ready"),
    BUSY("Busy"),
    UPDATING("Updating"),
    ERROR("Error"),
    MAINTENANCE("Maintenance")
}

data class HealthMetrics(
    val batteryPercent: Int = 98,
    val isCharging: Boolean = true,
    val temperatureCelsius: Double = 27.4,
    val wifiSignalDbm: Int = -52,
    val networkLatencyMs: Long = 18,
    val memoryUsagePercent: Int = 34,
    val storageAvailableMb: Int = 3420,
    val transactionCountToday: Int = 142,
    val errorRatePercent: Double = 0.02
)

data class SoftwareUpdate(
    val currentVersion: String = "2.4.1",
    val availableVersion: String = "2.5.0",
    val updateChannel: String = "stable",
    val updateStatus: UpdateJobStatus = UpdateJobStatus.IDLE,
    val updateProgress: Float = 0f
)

enum class UpdateJobStatus {
    IDLE,
    AVAILABLE,
    DOWNLOADING,
    INSTALLING,
    RESTARTING,
    VALIDATING,
    COMPLETE,
    FAILED
}

data class Terminal(
    val id: TerminalId,
    val merchantId: MerchantId,
    val locationId: LocationId,
    val locationName: String = "London Soho",
    val deviceName: String,
    val deviceType: String = "Stripe Reader S700",
    val serialNumber: String = "STRIPE-S700-${id.value.takeLast(6).uppercase()}",
    val ipAddress: String = "192.168.1.104",
    val softwareVersion: String = "2.4.1",
    val hardwareVersion: String = "v3.1-GB",
    val status: TerminalStatus = TerminalStatus.READY,
    val readerId: ReaderId? = null,
    val health: HealthMetrics = HealthMetrics(),
    val softwareUpdate: SoftwareUpdate = SoftwareUpdate(),
    val lastHeartbeat: Long = System.currentTimeMillis(),
    val environment: String = "SIMULATION"
)

data class FleetSummary(
    val totalTerminals: Int = 1284,
    val onlineCount: Int = 1201,
    val offlineCount: Int = 57,
    val updatingCount: Int = 18,
    val maintenanceCount: Int = 8
)
