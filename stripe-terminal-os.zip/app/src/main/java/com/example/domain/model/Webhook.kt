package com.example.domain.model

enum class WebhookEventType(val eventName: String) {
    PAYMENT_INTENT_CREATED("payment_intent.created"),
    PAYMENT_INTENT_PROCESSING("payment_intent.processing"),
    PAYMENT_INTENT_SUCCEEDED("payment_intent.succeeded"),
    PAYMENT_INTENT_FAILED("payment_intent.payment_failed"),
    PAYMENT_INTENT_CANCELED("payment_intent.canceled"),
    REFUND_CREATED("refund.created"),
    REFUND_SUCCEEDED("refund.succeeded"),
    READER_CONNECTED("terminal.reader.connected"),
    READER_DISCONNECTED("terminal.reader.disconnected"),
    TERMINAL_HEALTH_ALERT("terminal.health.alert")
}

enum class DeliveryStatus(val displayName: String) {
    PENDING("Pending"),
    DELIVERED("Delivered (200 OK)"),
    RETRYING("Retrying"),
    FAILED("Failed (503 / Timeout)")
}

data class WebhookAttempt(
    val attemptNumber: Int,
    val httpStatus: Int,
    val durationMs: Long,
    val responseBody: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class WebhookEvent(
    val id: WebhookEventId,
    val eventType: WebhookEventType,
    val resourceId: String,
    val payloadJson: String,
    val livemode: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class WebhookEndpoint(
    val id: String = "we_1Nx${System.currentTimeMillis().toString().takeLast(6)}",
    val url: String = "https://api.thecoffeehouse.co.uk/webhooks/stripe",
    val status: String = "enabled",
    val eventsSubscribed: List<String> = listOf("payment_intent.succeeded", "refund.succeeded", "terminal.reader.disconnected"),
    val secretKey: String = "whsec_test_7f92a10b42c8d"
)

data class WebhookDelivery(
    val id: String,
    val event: WebhookEvent,
    val endpointUrl: String = "https://api.thecoffeehouse.co.uk/webhooks/stripe",
    val status: DeliveryStatus = DeliveryStatus.DELIVERED,
    val attemptCount: Int = 1,
    val maxRetries: Int = 3,
    val lastAttempt: WebhookAttempt? = null,
    val nextAttemptTimestamp: Long? = null
)
