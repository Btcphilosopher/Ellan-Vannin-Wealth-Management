package com.example.domain.model

enum class TransactionStatus(val displayName: String) {
    PENDING("Pending"),
    AUTHORIZED("Authorized"),
    CAPTURED("Captured"),
    SUCCEEDED("Succeeded"),
    FAILED("Failed"),
    REFUNDED("Refunded"),
    PARTIALLY_REFUNDED("Partially Refunded"),
    CANCELED("Canceled")
}

data class Transaction(
    val id: TransactionId,
    val paymentIntentId: PaymentIntentId,
    val merchantId: MerchantId,
    val locationId: LocationId,
    val locationName: String = "London Soho",
    val terminalId: TerminalId,
    val terminalName: String = "Counter 01",
    val readerId: ReaderId,
    val amount: MoneyMinor,
    val feeAmount: MoneyMinor = MoneyMinor((amount.value * 0.014 + 20).toLong()), // 1.4% + 20p simulated Stripe fee
    val netAmount: MoneyMinor = MoneyMinor(amount.value - (amount.value * 0.014 + 20).toLong()),
    val currency: Currency = Currency.GBP,
    val status: TransactionStatus = TransactionStatus.SUCCEEDED,
    val customerName: String = "Walk-in Customer",
    val paymentMethod: PaymentMethodDetails = PaymentMethodDetails(),
    val receiptId: ReceiptId? = null,
    val failureReason: String? = null,
    val refundedAmount: MoneyMinor = MoneyMinor.ZERO,
    val createdAt: Long = System.currentTimeMillis()
)

data class ReceiptLine(
    val description: String,
    val quantity: Int = 1,
    val unitPrice: MoneyMinor,
    val totalPrice: MoneyMinor = MoneyMinor(unitPrice.value * quantity)
)

data class ReceiptTax(
    val name: String = "VAT (20%)",
    val rate: Double = 0.20,
    val amount: MoneyMinor
)

data class Receipt(
    val id: ReceiptId,
    val transactionId: TransactionId,
    val paymentIntentId: PaymentIntentId,
    val merchantName: String = "The Coffee House",
    val locationAddress: String = "44 Old Compton St, London W1D 4TY",
    val lines: List<ReceiptLine>,
    val subtotal: MoneyMinor,
    val tax: ReceiptTax,
    val total: MoneyMinor,
    val currency: Currency = Currency.GBP,
    val cardBrand: CardBrand = CardBrand.VISA,
    val cardLast4: String = "4242",
    val authCode: String = "AUTH_849201",
    val entryMethod: EntryMethod = EntryMethod.CONTACTLESS_CARD,
    val terminalName: String = "Counter 01 (S700)",
    val timestamp: Long = System.currentTimeMillis(),
    val deliveredVia: String? = null, // "EMAIL", "SMS", "QR", "PRINT"
    val deliveryTarget: String? = null // e.g. "alex@example.com"
)
