package com.example.domain.model

enum class PaymentIntentStatus(val displayName: String, val apiValue: String) {
    REQUIRES_PAYMENT_METHOD("Requires Payment Method", "requires_payment_method"),
    REQUIRES_CONFIRMATION("Requires Confirmation", "requires_confirmation"),
    REQUIRES_ACTION("Requires Action", "requires_action"),
    PROCESSING("Processing", "processing"),
    SUCCEEDED("Succeeded", "succeeded"),
    CANCELED("Canceled", "canceled"),
    FAILED("Failed", "failed")
}

enum class CaptureMethod(val apiValue: String) {
    AUTOMATIC("automatic"),
    MANUAL("manual")
}

data class PaymentMethodDetails(
    val type: String = "card_present",
    val brand: CardBrand = CardBrand.VISA,
    val last4: String = "4242",
    val expMonth: Int = 12,
    val expYear: Int = 2028,
    val entryMethod: EntryMethod = EntryMethod.CONTACTLESS_CARD,
    val cardholderName: String? = null,
    val authCode: String = "AUTH_${(100000..999999).random()}",
    val emvApplicationId: String = "A0000000031010",
    val networkTransactionId: String = "ntid_${System.currentTimeMillis().toString().takeLast(8)}"
)

data class PaymentIntent(
    val id: PaymentIntentId,
    val merchantId: MerchantId = MerchantId("acct_merchant_01"),
    val amount: MoneyMinor,
    val currency: Currency = Currency.GBP,
    val description: String = "Point of Sale Charge",
    val status: PaymentIntentStatus = PaymentIntentStatus.REQUIRES_PAYMENT_METHOD,
    val captureMethod: CaptureMethod = CaptureMethod.AUTOMATIC,
    val terminalId: TerminalId? = null,
    val readerId: ReaderId? = null,
    val customerId: CustomerId? = null,
    val customerEmail: String? = null,
    val paymentMethodDetails: PaymentMethodDetails? = null,
    val cancellationReason: String? = null,
    val failureMessage: String? = null,
    val metadata: Map<String, String> = emptyMap(),
    val receiptId: ReceiptId? = null,
    val idempotencyKey: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun formattedAmount(): String = amount.format(currency)
}
