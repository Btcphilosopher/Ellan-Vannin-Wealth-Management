package com.example.domain.model

enum class UserRole(val displayName: String) {
    MERCHANT_OWNER("Merchant Owner"),
    MERCHANT_ADMIN("Merchant Admin"),
    CASHIER("Cashier / Operator"),
    DEVELOPER("Developer"),
    FINANCE("Finance & Reconciliation"),
    AUDITOR("Auditor (Read-Only)")
}

data class MerchantUser(
    val id: String = "usr_01",
    val email: String = "operator@thecoffeehouse.co.uk",
    val name: String = "Sarah Jenkins",
    val role: UserRole = UserRole.MERCHANT_OWNER
)

data class MerchantLocation(
    val id: LocationId,
    val merchantId: MerchantId = MerchantId("acct_merchant_01"),
    val name: String,
    val city: String,
    val addressLine: String,
    val postalCode: String,
    val country: String = "GB",
    val activeTerminalsCount: Int = 3,
    val todayRevenue: MoneyMinor = MoneyMinor(142000L),
    val isPrimary: Boolean = false
)

data class Merchant(
    val id: MerchantId = MerchantId("acct_merchant_01"),
    val businessName: String = "The Coffee House Ltd",
    val statementDescriptor: String = "THE COFFEE HOUSE",
    val country: String = "GB",
    val defaultCurrency: Currency = Currency.GBP,
    val timezone: String = "Europe/London",
    val environment: String = "SANDBOX / SIMULATION",
    val publishableKey: String = "pk_test_51MzPOSDemoKey99281A",
    val secretKey: String = "sk_test_51MzSecretPOS99281B",
    val restrictedKey: String = "rk_test_TerminalRestricted420",
    val locations: List<MerchantLocation> = emptyList()
)
