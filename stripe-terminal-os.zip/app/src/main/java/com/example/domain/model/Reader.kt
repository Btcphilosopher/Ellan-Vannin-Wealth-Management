package com.example.domain.model

enum class ReaderType(val displayName: String, val modelCode: String) {
    STRIPE_S700("Stripe Reader S700", "s700"),
    STRIPE_M2("Stripe Reader M2", "m2"),
    BBPOS_WISEPAD3("BBPOS WisePad 3", "wisepad3"),
    BBPOS_WISEPOSE("BBPOS WisePOS E", "wisepos_e"),
    VERIFONE_P400("Verifone P400", "p400")
}

enum class ReaderCapability {
    CONTACTLESS,
    CHIP,
    PIN,
    MAGSTRIPE,
    SIGNATURE,
    NFC
}

enum class ReaderConnectionState(val displayName: String) {
    DISCONNECTED("Disconnected"),
    DISCOVERING("Discovering"),
    CONNECTING("Connecting"),
    CONNECTED("Connected"),
    READY("Ready"),
    COLLECTING("Collecting Payment"),
    PROCESSING("Processing"),
    ERROR("Error")
}

data class ReaderDiagnostic(
    val batteryLevel: Int = 100,
    val isCharging: Boolean = true,
    val emvKernelVersion: String = "EMV_Co_L2_v4.3",
    val nfcAntennaStatus: String = "ACTIVE_OK",
    val secureKeyInjected: Boolean = true,
    val lastTamperCheck: String = "PASSED",
    val bluetoothSignalDbm: Int = -45
)

data class Reader(
    val id: ReaderId,
    val label: String,
    val locationId: LocationId,
    val locationName: String = "London Soho",
    val serialNumber: String = "WPOS-GB-${id.value.takeLast(6).uppercase()}",
    val readerType: ReaderType = ReaderType.STRIPE_S700,
    val capabilities: Set<ReaderCapability> = setOf(
        ReaderCapability.CONTACTLESS,
        ReaderCapability.CHIP,
        ReaderCapability.PIN,
        ReaderCapability.NFC
    ),
    val connectionState: ReaderConnectionState = ReaderConnectionState.READY,
    val ipAddress: String = "192.168.1.108",
    val softwareVersion: String = "3.2.0.12",
    val diagnostic: ReaderDiagnostic = ReaderDiagnostic(),
    val isDefault: Boolean = false
)
