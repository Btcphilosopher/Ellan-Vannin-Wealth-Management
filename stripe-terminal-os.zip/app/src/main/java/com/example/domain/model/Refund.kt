package com.example.domain.model

enum class RefundStatus(val displayName: String, val apiValue: String) {
    REQUESTED("Requested", "requested"),
    PROCESSING("Processing", "processing"),
    SUCCEEDED("Succeeded", "succeeded"),
    FAILED("Failed", "failed"),
    CANCELED("Canceled", "canceled")
}

enum class RefundType {
    FULL_REFUND,
    PARTIAL_REFUND
}

data class Refund(
    val id: RefundId,
    val paymentIntentId: PaymentIntentId,
    val transactionId: TransactionId,
    val amount: MoneyMinor,
    val currency: Currency = Currency.GBP,
    val status: RefundStatus = RefundStatus.SUCCEEDED,
    val refundType: RefundType = RefundType.FULL_REFUND,
    val reason: String = "requested_by_customer",
    val receiptNumber: String = "ref_${System.currentTimeMillis().toString().takeLast(6)}",
    val createdAt: Long = System.currentTimeMillis()
)
