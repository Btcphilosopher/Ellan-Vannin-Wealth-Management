package com.example.data.repository

import com.example.data.db.*
import com.example.domain.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TerminalRepository(
    private val db: TerminalDatabase
) {
    private val scope = CoroutineScope(Dispatchers.IO)

    init {
        scope.launch {
            seedInitialDataIfNeeded()
        }
    }

    private suspend fun seedInitialDataIfNeeded() = withContext(Dispatchers.IO) {
        val existingProducts = db.productDao().getAllProducts().firstOrNull()
        if (existingProducts.isNullOrEmpty()) {
            db.productDao().insertProducts(SeedData.initialProducts())
            db.terminalDao().insertTerminals(SeedData.initialTerminals())
            db.terminalDao().insertReaders(SeedData.initialReaders())
            for (tx in SeedData.initialTransactions()) {
                db.paymentDao().insertTransaction(tx)
            }
            db.reconciliationDao().insertReconciliationItems(SeedData.initialReconciliationItems())
            for (entry in SeedData.initialLedgerEntries()) {
                db.ledgerDao().insertLedgerEntry(entry)
            }
            for (wh in SeedData.initialWebhookEvents()) {
                db.webhookDao().insertWebhookEvent(wh)
            }
            for (req in SeedData.initialApiLogs()) {
                db.apiLogDao().insertApiLog(req)
            }
            db.auditDao().insertAuditRecord(
                AuditRecordEntity(
                    id = "aud_init_sys",
                    who = "system_initialization",
                    role = "SYSTEM",
                    action = "INITIALIZE_TERMINAL_OS",
                    resourceType = "MERCHANT_ACCOUNT",
                    resourceId = "acct_merchant_thecoffeehouse",
                    details = "Initialized Stripe Terminal.OS v2.4.1 sandbox ledger and fleet.",
                    requestId = "req_sys_boot",
                    terminalId = null,
                    locationName = "London Soho",
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    // Products
    fun getProducts(): Flow<List<Product>> {
        return db.productDao().getAllProducts().map { entities ->
            entities.map { entity ->
                Product(
                    id = entity.id,
                    sku = entity.sku,
                    name = entity.name,
                    description = entity.description,
                    category = ProductCategory.valueOf(entity.category),
                    price = MoneyMinor(entity.priceMinor),
                    currency = Currency.fromCode(entity.currencyCode),
                    inStock = entity.inStock,
                    stockQuantity = entity.stockQuantity,
                    colorAccent = entity.colorAccent
                )
            }
        }
    }

    // Terminals & Readers
    fun getTerminals(): Flow<List<Terminal>> {
        return db.terminalDao().getAllTerminals().map { entities ->
            entities.map { e ->
                Terminal(
                    id = TerminalId(e.id),
                    merchantId = MerchantId(e.merchantId),
                    locationId = LocationId(e.locationId),
                    locationName = e.locationName,
                    deviceName = e.deviceName,
                    deviceType = e.deviceType,
                    serialNumber = e.serialNumber,
                    ipAddress = e.ipAddress,
                    softwareVersion = e.softwareVersion,
                    hardwareVersion = e.hardwareVersion,
                    status = TerminalStatus.valueOf(e.status),
                    readerId = e.readerId?.let { ReaderId(it) },
                    health = HealthMetrics(
                        batteryPercent = e.batteryPercent,
                        isCharging = e.isCharging,
                        temperatureCelsius = e.temperatureCelsius,
                        wifiSignalDbm = e.wifiSignalDbm,
                        networkLatencyMs = e.latencyMs
                    ),
                    lastHeartbeat = e.lastHeartbeat
                )
            }
        }
    }

    fun getReaders(): Flow<List<Reader>> {
        return db.terminalDao().getAllReaders().map { entities ->
            entities.map { e ->
                Reader(
                    id = ReaderId(e.id),
                    label = e.label,
                    locationId = LocationId(e.locationId),
                    locationName = e.locationName,
                    serialNumber = e.serialNumber,
                    readerType = ReaderType.valueOf(e.readerType),
                    connectionState = ReaderConnectionState.valueOf(e.connectionState),
                    ipAddress = e.ipAddress,
                    softwareVersion = e.softwareVersion,
                    isDefault = e.isDefault
                )
            }
        }
    }

    // Transactions
    fun getTransactions(): Flow<List<Transaction>> {
        return db.paymentDao().getAllTransactions().map { list ->
            list.map { e ->
                Transaction(
                    id = TransactionId(e.id),
                    paymentIntentId = PaymentIntentId(e.paymentIntentId),
                    merchantId = MerchantId(e.merchantId),
                    locationId = LocationId(e.locationId),
                    locationName = e.locationName,
                    terminalId = TerminalId(e.terminalId),
                    terminalName = e.terminalName,
                    readerId = ReaderId(e.readerId),
                    amount = MoneyMinor(e.amountMinor),
                    feeAmount = MoneyMinor(e.feeMinor),
                    netAmount = MoneyMinor(e.netMinor),
                    currency = Currency.fromCode(e.currencyCode),
                    status = TransactionStatus.valueOf(e.status),
                    customerName = e.customerName,
                    paymentMethod = PaymentMethodDetails(
                        brand = CardBrand.valueOf(e.cardBrand),
                        last4 = e.cardLast4,
                        entryMethod = EntryMethod.valueOf(e.entryMethod),
                        authCode = e.authCode
                    ),
                    receiptId = e.receiptId?.let { ReceiptId(it) },
                    failureReason = e.failureReason,
                    refundedAmount = MoneyMinor(e.refundedAmountMinor),
                    createdAt = e.createdAt
                )
            }
        }
    }

    suspend fun saveTransaction(tx: Transaction) = withContext(Dispatchers.IO) {
        val entity = TransactionEntity(
            id = tx.id.value,
            paymentIntentId = tx.paymentIntentId.value,
            merchantId = tx.merchantId.value,
            locationId = tx.locationId.value,
            locationName = tx.locationName,
            terminalId = tx.terminalId.value,
            terminalName = tx.terminalName,
            readerId = tx.readerId.value,
            amountMinor = tx.amount.value,
            feeMinor = tx.feeAmount.value,
            netMinor = tx.netAmount.value,
            currencyCode = tx.currency.code,
            status = tx.status.name,
            customerName = tx.customerName,
            cardBrand = tx.paymentMethod.brand.name,
            cardLast4 = tx.paymentMethod.last4,
            entryMethod = tx.paymentMethod.entryMethod.name,
            authCode = tx.paymentMethod.authCode,
            receiptId = tx.receiptId?.value,
            failureReason = tx.failureReason,
            refundedAmountMinor = tx.refundedAmount.value,
            createdAt = tx.createdAt
        )
        db.paymentDao().insertTransaction(entity)
    }

    suspend fun savePaymentIntent(intent: PaymentIntent) = withContext(Dispatchers.IO) {
        val entity = PaymentIntentEntity(
            id = intent.id.value,
            merchantId = intent.merchantId.value,
            amountMinor = intent.amount.value,
            currencyCode = intent.currency.code,
            description = intent.description,
            status = intent.status.name,
            captureMethod = intent.captureMethod.name,
            terminalId = intent.terminalId?.value,
            readerId = intent.readerId?.value,
            customerId = intent.customerId?.value,
            customerEmail = intent.customerEmail,
            cardBrand = intent.paymentMethodDetails?.brand?.name,
            cardLast4 = intent.paymentMethodDetails?.last4,
            cardEntryMethod = intent.paymentMethodDetails?.entryMethod?.name,
            authCode = intent.paymentMethodDetails?.authCode,
            cancellationReason = intent.cancellationReason,
            failureMessage = intent.failureMessage,
            receiptId = intent.receiptId?.value,
            idempotencyKey = intent.idempotencyKey,
            createdAt = intent.createdAt,
            updatedAt = intent.updatedAt
        )
        db.paymentDao().insertPaymentIntent(entity)
    }

    suspend fun saveReceipt(receipt: Receipt) = withContext(Dispatchers.IO) {
        val linesSerialized = receipt.lines.joinToString(";;") { "${it.description}|${it.quantity}|${it.unitPrice.value}" }
        val entity = ReceiptEntity(
            id = receipt.id.value,
            transactionId = receipt.transactionId.value,
            paymentIntentId = receipt.paymentIntentId.value,
            merchantName = receipt.merchantName,
            locationAddress = receipt.locationAddress,
            linesJson = linesSerialized,
            subtotalMinor = receipt.subtotal.value,
            taxName = receipt.tax.name,
            taxRate = receipt.tax.rate,
            taxMinor = receipt.tax.amount.value,
            totalMinor = receipt.total.value,
            currencyCode = receipt.currency.code,
            cardBrand = receipt.cardBrand.name,
            cardLast4 = receipt.cardLast4,
            authCode = receipt.authCode,
            entryMethod = receipt.entryMethod.name,
            terminalName = receipt.terminalName,
            timestamp = receipt.timestamp,
            deliveredVia = receipt.deliveredVia,
            deliveryTarget = receipt.deliveryTarget
        )
        db.paymentDao().insertReceipt(entity)
    }

    // Ledger
    fun getLedgerEntries(): Flow<List<LedgerEntry>> {
        return db.ledgerDao().getAllLedgerEntries().map { list ->
            list.map { e ->
                LedgerEntry(
                    id = LedgerEntryId(e.id),
                    transactionId = e.transactionId?.let { TransactionId(it) },
                    paymentIntentId = e.paymentIntentId?.let { PaymentIntentId(it) },
                    type = LedgerEntryType.valueOf(e.type),
                    amount = MoneyMinor(e.amountMinor),
                    isDebit = e.isDebit,
                    currency = Currency.fromCode(e.currencyCode),
                    account = e.account,
                    contraAccount = e.contraAccount,
                    description = e.description,
                    timestamp = e.timestamp
                )
            }
        }
    }

    suspend fun recordLedgerEntry(entry: LedgerEntry) = withContext(Dispatchers.IO) {
        db.ledgerDao().insertLedgerEntry(
            LedgerEntryEntity(
                id = entry.id.value,
                transactionId = entry.transactionId?.value,
                paymentIntentId = entry.paymentIntentId?.value,
                type = entry.type.name,
                amountMinor = entry.amount.value,
                isDebit = entry.isDebit,
                currencyCode = entry.currency.code,
                account = entry.account,
                contraAccount = entry.contraAccount,
                description = entry.description,
                timestamp = entry.timestamp
            )
        )
    }

    // Refunds
    fun getRefunds(): Flow<List<Refund>> {
        return db.paymentDao().getAllRefunds().map { list ->
            list.map { e ->
                Refund(
                    id = RefundId(e.id),
                    paymentIntentId = PaymentIntentId(e.paymentIntentId),
                    transactionId = TransactionId(e.transactionId),
                    amount = MoneyMinor(e.amountMinor),
                    currency = Currency.fromCode(e.currencyCode),
                    status = RefundStatus.valueOf(e.status),
                    refundType = RefundType.valueOf(e.refundType),
                    reason = e.reason,
                    receiptNumber = e.receiptNumber,
                    createdAt = e.createdAt
                )
            }
        }
    }

    suspend fun saveRefund(refund: Refund) = withContext(Dispatchers.IO) {
        db.paymentDao().insertRefund(
            RefundEntity(
                id = refund.id.value,
                paymentIntentId = refund.paymentIntentId.value,
                transactionId = refund.transactionId.value,
                amountMinor = refund.amount.value,
                currencyCode = refund.currency.code,
                status = refund.status.name,
                refundType = refund.refundType.name,
                reason = refund.reason,
                receiptNumber = refund.receiptNumber,
                createdAt = refund.createdAt
            )
        )

        // Update transaction refunded amount
        val txEntity = db.paymentDao().getTransactionById(refund.transactionId.value)
        if (txEntity != null) {
            val newRefunded = txEntity.refundedAmountMinor + refund.amount.value
            val newStatus = if (newRefunded >= txEntity.amountMinor) "REFUNDED" else "PARTIALLY_REFUNDED"
            db.paymentDao().updateTransaction(
                txEntity.copy(
                    refundedAmountMinor = newRefunded,
                    status = newStatus
                )
            )
        }
    }

    // Reconciliation
    fun getReconciliationItems(): Flow<List<ReconciliationItem>> {
        return db.reconciliationDao().getAllReconciliationItems().map { list ->
            list.map { e ->
                ReconciliationItem(
                    id = e.id,
                    paymentIntentId = e.paymentIntentId,
                    type = ReconciliationType.valueOf(e.type),
                    status = ResolutionStatus.valueOf(e.status),
                    posAmount = MoneyMinor(e.posAmountMinor),
                    processorAmount = MoneyMinor(e.processorAmountMinor),
                    currency = Currency.fromCode(e.currencyCode),
                    terminalName = e.terminalName,
                    locationName = e.locationName,
                    description = e.description,
                    auditNote = e.auditNote,
                    resolvedBy = e.resolvedBy,
                    resolvedAt = e.resolvedAt,
                    timestamp = e.timestamp
                )
            }
        }
    }

    suspend fun resolveReconciliationItem(
        id: String,
        note: String,
        resolvedBy: String = "Sarah Jenkins (Finance)"
    ) = withContext(Dispatchers.IO) {
        val items = db.reconciliationDao().getAllReconciliationItems().firstOrNull() ?: emptyList()
        val item = items.find { it.id == id }
        if (item != null) {
            db.reconciliationDao().updateReconciliationItem(
                item.copy(
                    status = "RESOLVED",
                    auditNote = note,
                    resolvedBy = resolvedBy,
                    resolvedAt = System.currentTimeMillis()
                )
            )
            // Log audit
            db.auditDao().insertAuditRecord(
                AuditRecordEntity(
                    id = "aud_rec_${System.currentTimeMillis().toString().takeLast(6)}",
                    who = resolvedBy,
                    role = "FINANCE",
                    action = "RECONCILIATION_EXCEPTION_RESOLVED",
                    resourceType = "RECONCILIATION_ITEM",
                    resourceId = id,
                    details = "Resolved discrepancy on intent ${item.paymentIntentId}: $note",
                    requestId = "req_audit_${System.currentTimeMillis().toString().takeLast(6)}",
                    terminalId = item.terminalName,
                    locationName = item.locationName,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun injectReconciliationDiscrepancy(type: ReconciliationType) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val newItem = when (type) {
            ReconciliationType.DUPLICATE -> ReconciliationEntity(
                id = "rec_${now.toString().takeLast(6)}_dup",
                paymentIntentId = "pi_sim_${now.toString().takeLast(6)}",
                type = "DUPLICATE",
                status = "UNRESOLVED",
                posAmountMinor = 800L,
                processorAmountMinor = 1600L,
                currencyCode = "GBP",
                terminalName = "Counter 01",
                locationName = "London Soho",
                description = "Simulated duplicate settlement batch submission detected.",
                auditNote = null,
                resolvedBy = null,
                resolvedAt = null,
                timestamp = now
            )
            ReconciliationType.MISSING_RECORD -> ReconciliationEntity(
                id = "rec_${now.toString().takeLast(6)}_miss",
                paymentIntentId = "pi_sim_${now.toString().takeLast(6)}",
                type = "MISSING_RECORD",
                status = "UNRESOLVED",
                posAmountMinor = 2450L,
                processorAmountMinor = 0L,
                currencyCode = "GBP",
                terminalName = "Shoreditch Front Bar",
                locationName = "London Shoreditch",
                description = "Simulated offline store-and-forward transaction missing acquiring sync.",
                auditNote = null,
                resolvedBy = null,
                resolvedAt = null,
                timestamp = now
            )
            ReconciliationType.AMOUNT_MISMATCH -> ReconciliationEntity(
                id = "rec_${now.toString().takeLast(6)}_mismatch",
                paymentIntentId = "pi_sim_${now.toString().takeLast(6)}",
                type = "AMOUNT_MISMATCH",
                status = "UNRESOLVED",
                posAmountMinor = 1850L,
                processorAmountMinor = 2150L,
                currencyCode = "GBP",
                terminalName = "Counter 02",
                locationName = "London Soho",
                description = "Simulated gratuity/surcharge variance between POS intent and processor authorization.",
                auditNote = null,
                resolvedBy = null,
                resolvedAt = null,
                timestamp = now
            )
            else -> ReconciliationEntity(
                id = "rec_${now.toString().takeLast(6)}_unk",
                paymentIntentId = "pi_sim_${now.toString().takeLast(6)}",
                type = "UNKNOWN",
                status = "UNRESOLVED",
                posAmountMinor = 1200L,
                processorAmountMinor = 1200L,
                currencyCode = "GBP",
                terminalName = "Manchester Main Bar",
                locationName = "Manchester Northern Quarter",
                description = "Simulated late capture after authorization expiration window.",
                auditNote = null,
                resolvedBy = null,
                resolvedAt = null,
                timestamp = now
            )
        }
        db.reconciliationDao().insertReconciliationItems(listOf(newItem))
    }

    // Webhooks
    fun getWebhookEvents(): Flow<List<WebhookEventEntity>> = db.webhookDao().getAllWebhookEvents()

    suspend fun recordWebhook(
        eventType: WebhookEventType,
        resourceId: String,
        payloadJson: String,
        status: DeliveryStatus = DeliveryStatus.DELIVERED,
        responseCode: Int = 200,
        durationMs: Long = 32L
    ) = withContext(Dispatchers.IO) {
        val entity = WebhookEventEntity(
            id = "evt_${System.currentTimeMillis().toString().takeLast(8)}",
            eventType = eventType.eventName,
            resourceId = resourceId,
            payloadJson = payloadJson,
            deliveryStatus = status.name,
            attemptCount = 1,
            lastResponseCode = responseCode,
            lastDurationMs = durationMs,
            createdAt = System.currentTimeMillis()
        )
        db.webhookDao().insertWebhookEvent(entity)
    }

    // API Logs
    fun getApiLogs(): Flow<List<ApiRequestEntity>> = db.apiLogDao().getRecentApiLogs()

    suspend fun recordApiLog(
        method: String,
        path: String,
        statusCode: Int,
        durationMs: Long,
        requestPayload: String? = null,
        responsePayload: String? = null,
        idempotencyKey: String? = null
    ) = withContext(Dispatchers.IO) {
        db.apiLogDao().insertApiLog(
            ApiRequestEntity(
                id = "req_${System.currentTimeMillis().toString().takeLast(7)}",
                method = method,
                path = path,
                statusCode = statusCode,
                durationMs = durationMs,
                requestPayload = requestPayload,
                responsePayload = responsePayload,
                idempotencyKey = idempotencyKey,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    // Audit Logs
    fun getAuditLogs(): Flow<List<AuditRecordEntity>> = db.auditDao().getRecentAuditRecords()

    suspend fun logAudit(
        who: String,
        role: String,
        action: String,
        resourceType: String,
        resourceId: String,
        details: String,
        terminalId: String? = null,
        locationName: String? = null
    ) = withContext(Dispatchers.IO) {
        db.auditDao().insertAuditRecord(
            AuditRecordEntity(
                id = "aud_${System.currentTimeMillis().toString().takeLast(6)}",
                who = who,
                role = role,
                action = action,
                resourceType = resourceType,
                resourceId = resourceId,
                details = details,
                requestId = "req_${System.currentTimeMillis().toString().takeLast(6)}",
                terminalId = terminalId,
                locationName = locationName,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun updateReaderStatus(readerId: String, state: ReaderConnectionState) = withContext(Dispatchers.IO) {
        val readers = db.terminalDao().getAllReaders().firstOrNull() ?: emptyList()
        val reader = readers.find { it.id == readerId }
        if (reader != null) {
            db.terminalDao().updateReader(reader.copy(connectionState = state.name))
        }
    }

    suspend fun updateTerminalStatus(terminalId: String, status: TerminalStatus) = withContext(Dispatchers.IO) {
        val terminal = db.terminalDao().getTerminalById(terminalId)
        if (terminal != null) {
            db.terminalDao().updateTerminal(
                terminal.copy(
                    status = status.name,
                    lastHeartbeat = System.currentTimeMillis()
                )
            )
        }
    }
}
