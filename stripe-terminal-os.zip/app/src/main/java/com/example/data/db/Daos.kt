package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payment_intents ORDER BY createdAt DESC")
    fun getAllPaymentIntents(): Flow<List<PaymentIntentEntity>>

    @Query("SELECT * FROM payment_intents WHERE id = :id LIMIT 1")
    suspend fun getPaymentIntentById(id: String): PaymentIntentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentIntent(intent: PaymentIntentEntity)

    @Update
    suspend fun updatePaymentIntent(intent: PaymentIntentEntity)

    @Query("SELECT * FROM transactions ORDER BY createdAt DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    suspend fun getTransactionById(id: String): TransactionEntity?

    @Query("SELECT * FROM transactions WHERE paymentIntentId = :intentId LIMIT 1")
    suspend fun getTransactionByIntentId(intentId: String): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: TransactionEntity)

    @Update
    suspend fun updateTransaction(tx: TransactionEntity)

    @Query("SELECT * FROM refunds ORDER BY createdAt DESC")
    fun getAllRefunds(): Flow<List<RefundEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRefund(refund: RefundEntity)

    @Query("SELECT * FROM receipts WHERE id = :id LIMIT 1")
    suspend fun getReceiptById(id: String): ReceiptEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceipt(receipt: ReceiptEntity)
}

@Dao
interface TerminalDao {
    @Query("SELECT * FROM terminals ORDER BY deviceName ASC")
    fun getAllTerminals(): Flow<List<TerminalEntity>>

    @Query("SELECT * FROM terminals WHERE id = :id LIMIT 1")
    suspend fun getTerminalById(id: String): TerminalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTerminals(terminals: List<TerminalEntity>)

    @Update
    suspend fun updateTerminal(terminal: TerminalEntity)

    @Query("SELECT * FROM readers ORDER BY isDefault DESC, label ASC")
    fun getAllReaders(): Flow<List<ReaderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReaders(readers: List<ReaderEntity>)

    @Update
    suspend fun updateReader(reader: ReaderEntity)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM ledger_entries ORDER BY timestamp DESC")
    fun getAllLedgerEntries(): Flow<List<LedgerEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntry(entry: LedgerEntryEntity)
}

@Dao
interface ReconciliationDao {
    @Query("SELECT * FROM reconciliation_items ORDER BY timestamp DESC")
    fun getAllReconciliationItems(): Flow<List<ReconciliationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReconciliationItems(items: List<ReconciliationEntity>)

    @Update
    suspend fun updateReconciliationItem(item: ReconciliationEntity)
}

@Dao
interface WebhookDao {
    @Query("SELECT * FROM webhook_events ORDER BY createdAt DESC")
    fun getAllWebhookEvents(): Flow<List<WebhookEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWebhookEvent(event: WebhookEventEntity)

    @Update
    suspend fun updateWebhookEvent(event: WebhookEventEntity)
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_records ORDER BY timestamp DESC LIMIT 200")
    fun getRecentAuditRecords(): Flow<List<AuditRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditRecord(record: AuditRecordEntity)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)
}

@Dao
interface ApiLogDao {
    @Query("SELECT * FROM api_request_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentApiLogs(): Flow<List<ApiRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApiLog(log: ApiRequestEntity)
}
