package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.*

@Entity(tableName = "payment_intents")
data class PaymentIntentEntity(
    @PrimaryKey val id: String,
    val merchantId: String,
    val amountMinor: Long,
    val currencyCode: String,
    val description: String,
    val status: String,
    val captureMethod: String,
    val terminalId: String?,
    val readerId: String?,
    val customerId: String?,
    val customerEmail: String?,
    val cardBrand: String?,
    val cardLast4: String?,
    val cardEntryMethod: String?,
    val authCode: String?,
    val cancellationReason: String?,
    val failureMessage: String?,
    val receiptId: String?,
    val idempotencyKey: String?,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val paymentIntentId: String,
    val merchantId: String,
    val locationId: String,
    val locationName: String,
    val terminalId: String,
    val terminalName: String,
    val readerId: String,
    val amountMinor: Long,
    val feeMinor: Long,
    val netMinor: Long,
    val currencyCode: String,
    val status: String,
    val customerName: String,
    val cardBrand: String,
    val cardLast4: String,
    val entryMethod: String,
    val authCode: String,
    val receiptId: String?,
    val failureReason: String?,
    val refundedAmountMinor: Long,
    val createdAt: Long
)

@Entity(tableName = "refunds")
data class RefundEntity(
    @PrimaryKey val id: String,
    val paymentIntentId: String,
    val transactionId: String,
    val amountMinor: Long,
    val currencyCode: String,
    val status: String,
    val refundType: String,
    val reason: String,
    val receiptNumber: String,
    val createdAt: Long
)

@Entity(tableName = "receipts")
data class ReceiptEntity(
    @PrimaryKey val id: String,
    val transactionId: String,
    val paymentIntentId: String,
    val merchantName: String,
    val locationAddress: String,
    val linesJson: String, // JSON serialized lines
    val subtotalMinor: Long,
    val taxName: String,
    val taxRate: Double,
    val taxMinor: Long,
    val totalMinor: Long,
    val currencyCode: String,
    val cardBrand: String,
    val cardLast4: String,
    val authCode: String,
    val entryMethod: String,
    val terminalName: String,
    val timestamp: Long,
    val deliveredVia: String?,
    val deliveryTarget: String?
)

@Entity(tableName = "terminals")
data class TerminalEntity(
    @PrimaryKey val id: String,
    val merchantId: String,
    val locationId: String,
    val locationName: String,
    val deviceName: String,
    val deviceType: String,
    val serialNumber: String,
    val ipAddress: String,
    val softwareVersion: String,
    val hardwareVersion: String,
    val status: String,
    val readerId: String?,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val temperatureCelsius: Double,
    val wifiSignalDbm: Int,
    val latencyMs: Long,
    val lastHeartbeat: Long
)

@Entity(tableName = "readers")
data class ReaderEntity(
    @PrimaryKey val id: String,
    val label: String,
    val locationId: String,
    val locationName: String,
    val serialNumber: String,
    val readerType: String,
    val connectionState: String,
    val ipAddress: String,
    val softwareVersion: String,
    val batteryLevel: Int,
    val isDefault: Boolean
)

@Entity(tableName = "ledger_entries")
data class LedgerEntryEntity(
    @PrimaryKey val id: String,
    val transactionId: String?,
    val paymentIntentId: String?,
    val type: String,
    val amountMinor: Long,
    val isDebit: Boolean,
    val currencyCode: String,
    val account: String,
    val contraAccount: String,
    val description: String,
    val timestamp: Long
)

@Entity(tableName = "reconciliation_items")
data class ReconciliationEntity(
    @PrimaryKey val id: String,
    val paymentIntentId: String,
    val type: String,
    val status: String,
    val posAmountMinor: Long,
    val processorAmountMinor: Long,
    val currencyCode: String,
    val terminalName: String,
    val locationName: String,
    val description: String,
    val auditNote: String?,
    val resolvedBy: String?,
    val resolvedAt: Long?,
    val timestamp: Long
)

@Entity(tableName = "webhook_events")
data class WebhookEventEntity(
    @PrimaryKey val id: String,
    val eventType: String,
    val resourceId: String,
    val payloadJson: String,
    val deliveryStatus: String,
    val attemptCount: Int,
    val lastResponseCode: Int,
    val lastDurationMs: Long,
    val createdAt: Long
)

@Entity(tableName = "audit_records")
data class AuditRecordEntity(
    @PrimaryKey val id: String,
    val who: String,
    val role: String,
    val action: String,
    val resourceType: String,
    val resourceId: String,
    val details: String,
    val requestId: String,
    val terminalId: String?,
    val locationName: String?,
    val timestamp: Long
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val sku: String,
    val name: String,
    val description: String,
    val category: String,
    val priceMinor: Long,
    val currencyCode: String,
    val inStock: Boolean,
    val stockQuantity: Int,
    val colorAccent: Long
)

@Entity(tableName = "api_request_logs")
data class ApiRequestEntity(
    @PrimaryKey val id: String,
    val method: String,
    val path: String,
    val statusCode: Int,
    val durationMs: Long,
    val requestPayload: String?,
    val responsePayload: String?,
    val idempotencyKey: String?,
    val timestamp: Long
)
