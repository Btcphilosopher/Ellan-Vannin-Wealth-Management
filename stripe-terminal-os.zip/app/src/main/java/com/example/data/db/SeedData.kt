package com.example.data.db

import com.example.domain.model.*

object SeedData {

    val locations = listOf(
        MerchantLocation(
            id = LocationId("loc_london_soho"),
            name = "London Soho",
            city = "London",
            addressLine = "44 Old Compton St",
            postalCode = "W1D 4TY",
            activeTerminalsCount = 4,
            todayRevenue = MoneyMinor(4829100L), // £48,291.00
            isPrimary = true
        ),
        MerchantLocation(
            id = LocationId("loc_london_shoreditch"),
            name = "London Shoreditch",
            city = "London",
            addressLine = "88 Redchurch Street",
            postalCode = "E2 7DD",
            activeTerminalsCount = 3,
            todayRevenue = MoneyMinor(3145000L),
            isPrimary = false
        ),
        MerchantLocation(
            id = LocationId("loc_manchester"),
            name = "Manchester Northern Quarter",
            city = "Manchester",
            addressLine = "12 Stevenson Square",
            postalCode = "M1 1FB",
            activeTerminalsCount = 2,
            todayRevenue = MoneyMinor(2290000L),
            isPrimary = false
        ),
        MerchantLocation(
            id = LocationId("loc_edinburgh"),
            name = "Edinburgh Old Town",
            city = "Edinburgh",
            addressLine = "104 Victoria Street",
            postalCode = "EH1 2JX",
            activeTerminalsCount = 2,
            todayRevenue = MoneyMinor(1874000L),
            isPrimary = false
        )
    )

    val defaultMerchant = Merchant(
        id = MerchantId("acct_merchant_thecoffeehouse"),
        businessName = "The Coffee House Ltd",
        statementDescriptor = "THE COFFEE HOUSE",
        country = "GB",
        defaultCurrency = Currency.GBP,
        locations = locations
    )

    fun initialProducts(): List<ProductEntity> = listOf(
        ProductEntity("prod_flat_white", "BEV-001", "Flat White", "Double ristretto with micro-foam steamed milk", "COFFEE", 380L, "GBP", true, 100, 0xFF635BFF),
        ProductEntity("prod_latte", "BEV-002", "Caffè Latte", "Silky espresso with textured fresh whole milk", "COFFEE", 420L, "GBP", true, 100, 0xFF635BFF),
        ProductEntity("prod_cappuccino", "BEV-003", "Cappuccino", "Rich espresso, equal parts steamed and frothed milk", "COFFEE", 400L, "GBP", true, 80, 0xFF635BFF),
        ProductEntity("prod_croissant", "BAK-001", "Butter Croissant", "All-butter artisanal flaky pastry baked fresh daily", "BAKERY", 320L, "GBP", true, 45, 0xFF00D4B2),
        ProductEntity("prod_pain_au_choc", "BAK-002", "Pain au Chocolat", "Dark Valrhona chocolate folded into butter pastry", "BAKERY", 360L, "GBP", true, 30, 0xFF00D4B2),
        ProductEntity("prod_matcha_latte", "BEV-004", "Ceremonial Matcha", "Uji ceremonial grade matcha whisked with oat milk", "TEA", 480L, "GBP", true, 60, 0xFF10B981),
        ProductEntity("prod_earl_grey", "BEV-005", "Earl Grey Supreme", "Single-origin black tea infused with bergamot", "TEA", 340L, "GBP", true, 90, 0xFF10B981),
        ProductEntity("prod_avocado_toast", "FOD-001", "Smashed Avocado Toast", "Crushed Hass avocado, poached egg, sourdough", "FOOD", 950L, "GBP", true, 25, 0xFFF59E0B),
        ProductEntity("prod_roast_beans", "RET-001", "Single Origin Beans 250g", "Ethiopian Yirgacheffe notes of bergamot & peach", "MERCHANDISE", 1400L, "GBP", true, 40, 0xFF6366F1),
        ProductEntity("prod_reusable_cup", "RET-002", "KeepCup 12oz", "Insulated stainless steel barista travel cup", "MERCHANDISE", 2200L, "GBP", true, 15, 0xFF6366F1)
    )

    fun initialTerminals(): List<TerminalEntity> = listOf(
        TerminalEntity(
            id = "tm_soho_01",
            merchantId = "acct_merchant_thecoffeehouse",
            locationId = "loc_london_soho",
            locationName = "London Soho",
            deviceName = "Counter 01 (Main Espresso)",
            deviceType = "Stripe Reader S700",
            serialNumber = "STRIPE-S700-SOHO01",
            ipAddress = "192.168.1.101",
            softwareVersion = "2.4.1",
            hardwareVersion = "v3.1-GB",
            status = "READY",
            readerId = "rdr_soho_01",
            batteryPercent = 100,
            isCharging = true,
            temperatureCelsius = 26.8,
            wifiSignalDbm = -48,
            latencyMs = 16,
            lastHeartbeat = System.currentTimeMillis()
        ),
        TerminalEntity(
            id = "tm_soho_02",
            merchantId = "acct_merchant_thecoffeehouse",
            locationId = "loc_london_soho",
            locationName = "London Soho",
            deviceName = "Counter 02 (Pastry & Takeout)",
            deviceType = "Stripe Reader S700",
            serialNumber = "STRIPE-S700-SOHO02",
            ipAddress = "192.168.1.102",
            softwareVersion = "2.4.1",
            hardwareVersion = "v3.1-GB",
            status = "READY",
            readerId = "rdr_soho_02",
            batteryPercent = 94,
            isCharging = true,
            temperatureCelsius = 28.2,
            wifiSignalDbm = -54,
            latencyMs = 21,
            lastHeartbeat = System.currentTimeMillis()
        ),
        TerminalEntity(
            id = "tm_soho_03",
            merchantId = "acct_merchant_thecoffeehouse",
            locationId = "loc_london_soho",
            locationName = "London Soho",
            deviceName = "Counter 03 (Table Service Handheld)",
            deviceType = "BBPOS WisePad 3",
            serialNumber = "BBPOS-WP3-SOHO03",
            ipAddress = "192.168.1.103",
            softwareVersion = "2.3.9",
            hardwareVersion = "v2.0-BT",
            status = "READY",
            readerId = "rdr_soho_03",
            batteryPercent = 82,
            isCharging = false,
            temperatureCelsius = 25.1,
            wifiSignalDbm = -60,
            latencyMs = 28,
            lastHeartbeat = System.currentTimeMillis()
        ),
        TerminalEntity(
            id = "tm_shoreditch_01",
            merchantId = "acct_merchant_thecoffeehouse",
            locationId = "loc_london_shoreditch",
            locationName = "London Shoreditch",
            deviceName = "Shoreditch Front Bar",
            deviceType = "Stripe Reader S700",
            serialNumber = "STRIPE-S700-SHOR01",
            ipAddress = "192.168.4.101",
            softwareVersion = "2.4.1",
            hardwareVersion = "v3.1-GB",
            status = "READY",
            readerId = "rdr_shoreditch_01",
            batteryPercent = 99,
            isCharging = true,
            temperatureCelsius = 27.0,
            wifiSignalDbm = -50,
            latencyMs = 19,
            lastHeartbeat = System.currentTimeMillis()
        ),
        TerminalEntity(
            id = "tm_manchester_01",
            merchantId = "acct_merchant_thecoffeehouse",
            locationId = "loc_manchester",
            locationName = "Manchester Northern Quarter",
            deviceName = "Manchester Main Bar",
            deviceType = "Stripe Reader S700",
            serialNumber = "STRIPE-S700-MCR01",
            ipAddress = "192.168.6.101",
            softwareVersion = "2.4.1",
            hardwareVersion = "v3.1-GB",
            status = "READY",
            readerId = "rdr_mcr_01",
            batteryPercent = 97,
            isCharging = true,
            temperatureCelsius = 26.5,
            wifiSignalDbm = -52,
            latencyMs = 24,
            lastHeartbeat = System.currentTimeMillis()
        )
    )

    fun initialReaders(): List<ReaderEntity> = listOf(
        ReaderEntity("rdr_soho_01", "Counter 01 (S700)", "loc_london_soho", "London Soho", "WPOS-GB-884012", "STRIPE_S700", "READY", "192.168.1.108", "3.2.0.12", 100, true),
        ReaderEntity("rdr_soho_02", "Counter 02 (S700)", "loc_london_soho", "London Soho", "WPOS-GB-884013", "STRIPE_S700", "READY", "192.168.1.109", "3.2.0.12", 95, false),
        ReaderEntity("rdr_soho_03", "Mobile Pod (WisePad 3)", "loc_london_soho", "London Soho", "WP3-GB-102931", "BBPOS_WISEPAD3", "READY", "192.168.1.110", "2.1.8", 82, false),
        ReaderEntity("rdr_shoreditch_01", "Shoreditch Bar (S700)", "loc_london_shoreditch", "London Shoreditch", "WPOS-GB-992011", "STRIPE_S700", "READY", "192.168.4.108", "3.2.0.12", 99, false),
        ReaderEntity("rdr_mcr_01", "Manchester Bar (S700)", "loc_manchester", "Manchester Northern Quarter", "WPOS-GB-334109", "STRIPE_S700", "READY", "192.168.6.108", "3.2.0.12", 97, false)
    )

    fun initialTransactions(): List<TransactionEntity> {
        val now = System.currentTimeMillis()
        return listOf(
            TransactionEntity(
                id = "txn_101_soho_4821",
                paymentIntentId = "pi_101_soho_4821",
                merchantId = "acct_merchant_thecoffeehouse",
                locationId = "loc_london_soho",
                locationName = "London Soho",
                terminalId = "tm_soho_01",
                terminalName = "Counter 01",
                readerId = "rdr_soho_01",
                amountMinor = 700L, // £7.00 (Flat White + Croissant)
                feeMinor = 30L,
                netMinor = 670L,
                currencyCode = "GBP",
                status = "SUCCEEDED",
                customerName = "James Thornton",
                cardBrand = "VISA",
                cardLast4 = "4242",
                entryMethod = "CONTACTLESS_CARD",
                authCode = "AUTH_849201",
                receiptId = "rcpt_101_soho",
                failureReason = null,
                refundedAmountMinor = 0L,
                createdAt = now - 180000L
            ),
            TransactionEntity(
                id = "txn_102_soho_4822",
                paymentIntentId = "pi_102_soho_4822",
                merchantId = "acct_merchant_thecoffeehouse",
                locationId = "loc_london_soho",
                locationName = "London Soho",
                terminalId = "tm_soho_02",
                terminalName = "Counter 02",
                readerId = "rdr_soho_02",
                amountMinor = 1420L, // £14.20
                feeMinor = 40L,
                netMinor = 1380L,
                currencyCode = "GBP",
                status = "SUCCEEDED",
                customerName = "Emma Watson",
                cardBrand = "MASTERCARD",
                cardLast4 = "8891",
                entryMethod = "PHONE_NFC",
                authCode = "AUTH_720194",
                receiptId = "rcpt_102_soho",
                failureReason = null,
                refundedAmountMinor = 0L,
                createdAt = now - 420000L
            ),
            TransactionEntity(
                id = "txn_103_shoreditch_991",
                paymentIntentId = "pi_103_shoreditch_991",
                merchantId = "acct_merchant_thecoffeehouse",
                locationId = "loc_london_shoreditch",
                locationName = "London Shoreditch",
                terminalId = "tm_shoreditch_01",
                terminalName = "Shoreditch Front Bar",
                readerId = "rdr_shoreditch_01",
                amountMinor = 2200L, // £22.00
                feeMinor = 51L,
                netMinor = 2149L,
                currencyCode = "GBP",
                status = "SUCCEEDED",
                customerName = "Marcus Aurelius",
                cardBrand = "AMEX",
                cardLast4 = "1005",
                entryMethod = "CHIP_INSERT",
                authCode = "AUTH_330912",
                receiptId = "rcpt_103_shoreditch",
                failureReason = null,
                refundedAmountMinor = 0L,
                createdAt = now - 780000L
            ),
            TransactionEntity(
                id = "txn_104_soho_ref",
                paymentIntentId = "pi_104_soho_ref",
                merchantId = "acct_merchant_thecoffeehouse",
                locationId = "loc_london_soho",
                locationName = "London Soho",
                terminalId = "tm_soho_01",
                terminalName = "Counter 01",
                readerId = "rdr_soho_01",
                amountMinor = 4500L, // £45.00
                feeMinor = 83L,
                netMinor = 4417L,
                currencyCode = "GBP",
                status = "PARTIALLY_REFUNDED",
                customerName = "Oliver Queen",
                cardBrand = "VISA",
                cardLast4 = "4242",
                entryMethod = "CONTACTLESS_CARD",
                authCode = "AUTH_901844",
                receiptId = "rcpt_104_soho",
                failureReason = null,
                refundedAmountMinor = 1200L, // £12.00 refunded
                createdAt = now - 1200000L
            )
        )
    }

    fun initialReconciliationItems(): List<ReconciliationEntity> = listOf(
        ReconciliationEntity(
            id = "rec_001_dup",
            paymentIntentId = "pi_soho_dup_9918",
            type = "DUPLICATE",
            status = "UNRESOLVED",
            posAmountMinor = 840L,
            processorAmountMinor = 1680L,
            currencyCode = "GBP",
            terminalName = "Counter 02",
            locationName = "London Soho",
            description = "Cardholder charged twice on reader timeout retry. Needs auto-reversal.",
            auditNote = null,
            resolvedBy = null,
            resolvedAt = null,
            timestamp = System.currentTimeMillis() - 3600000L
        ),
        ReconciliationEntity(
            id = "rec_002_missing",
            paymentIntentId = "pi_shoreditch_off_22",
            type = "MISSING_RECORD",
            status = "UNRESOLVED",
            posAmountMinor = 1450L,
            processorAmountMinor = 0L,
            currencyCode = "GBP",
            terminalName = "Shoreditch Front Bar",
            locationName = "London Shoreditch",
            description = "Transaction recorded locally during degraded WiFi; unconfirmed on acquiring gateway.",
            auditNote = null,
            resolvedBy = null,
            resolvedAt = null,
            timestamp = System.currentTimeMillis() - 7200000L
        ),
        ReconciliationEntity(
            id = "rec_003_amount",
            paymentIntentId = "pi_mcr_tip_381",
            type = "AMOUNT_MISMATCH",
            status = "UNRESOLVED",
            posAmountMinor = 1200L,
            processorAmountMinor = 1400L,
            currencyCode = "GBP",
            terminalName = "Manchester Main Bar",
            locationName = "Manchester Northern Quarter",
            description = "£2.00 barista gratuity added on terminal screen before capture sync.",
            auditNote = null,
            resolvedBy = null,
            resolvedAt = null,
            timestamp = System.currentTimeMillis() - 14400000L
        )
    )

    fun initialLedgerEntries(): List<LedgerEntryEntity> {
        val now = System.currentTimeMillis()
        return listOf(
            LedgerEntryEntity("led_01", "txn_101_soho_4821", "pi_101_soho_4821", "PAYMENT_CAPTURE", 700L, false, "GBP", "Merchant Settlement Account", "Stripe Clearing Account", "Card Present Sale (Counter 01)", now - 180000L),
            LedgerEntryEntity("led_02", "txn_101_soho_4821", "pi_101_soho_4821", "STRIPE_PROCESSING_FEE", 30L, true, "GBP", "Stripe Fee Expense", "Merchant Settlement Account", "Stripe Terminal Processing Fee (1.4% + 20p)", now - 180000L),
            LedgerEntryEntity("led_03", "txn_102_soho_4822", "pi_102_soho_4822", "PAYMENT_CAPTURE", 1420L, false, "GBP", "Merchant Settlement Account", "Stripe Clearing Account", "Mobile NFC Sale (Counter 02)", now - 420000L),
            LedgerEntryEntity("led_04", "txn_102_soho_4822", "pi_102_soho_4822", "STRIPE_PROCESSING_FEE", 40L, true, "GBP", "Stripe Fee Expense", "Merchant Settlement Account", "Stripe Terminal Processing Fee", now - 420000L),
            LedgerEntryEntity("led_05", "txn_104_soho_ref", "pi_104_soho_ref", "REFUND", 1200L, true, "GBP", "Merchant Settlement Account", "Stripe Clearing Account", "Partial Refund to Visa •••• 4242", now - 1000000L)
        )
    }

    fun initialWebhookEvents(): List<WebhookEventEntity> {
        val now = System.currentTimeMillis()
        return listOf(
            WebhookEventEntity(
                id = "evt_3N9xJ92eZvKYlo2C01",
                eventType = "payment_intent.succeeded",
                resourceId = "pi_101_soho_4821",
                payloadJson = """{"id":"pi_101_soho_4821","object":"payment_intent","amount":700,"currency":"gbp","status":"succeeded","payment_method_types":["card_present"],"capture_method":"automatic"}""",
                deliveryStatus = "DELIVERED",
                attemptCount = 1,
                lastResponseCode = 200,
                lastDurationMs = 38,
                createdAt = now - 180000L
            ),
            WebhookEventEntity(
                id = "evt_3N9xJ92eZvKYlo2C02",
                eventType = "payment_intent.succeeded",
                resourceId = "pi_102_soho_4822",
                payloadJson = """{"id":"pi_102_soho_4822","object":"payment_intent","amount":1420,"currency":"gbp","status":"succeeded","payment_method_types":["card_present"]}""",
                deliveryStatus = "DELIVERED",
                attemptCount = 1,
                lastResponseCode = 200,
                lastDurationMs = 44,
                createdAt = now - 420000L
            ),
            WebhookEventEntity(
                id = "evt_3N9xJ92eZvKYlo2C03",
                eventType = "refund.created",
                resourceId = "ref_104_soho",
                payloadJson = """{"id":"ref_104_soho","object":"refund","amount":1200,"currency":"gbp","status":"succeeded","payment_intent":"pi_104_soho_ref"}""",
                deliveryStatus = "DELIVERED",
                attemptCount = 1,
                lastResponseCode = 200,
                lastDurationMs = 52,
                createdAt = now - 1000000L
            )
        )
    }

    fun initialApiLogs(): List<ApiRequestEntity> {
        val now = System.currentTimeMillis()
        return listOf(
            ApiRequestEntity("req_948102a", "POST", "/v1/payment_intents", 201, 38, """{"amount":700,"currency":"gbp"}""", """{"id":"pi_101_soho_4821","status":"requires_payment_method"}""", "idemp_soho_901", now - 190000L),
            ApiRequestEntity("req_948102b", "POST", "/v1/terminal/readers/rdr_soho_01/process_payment_intent", 200, 42, """{"payment_intent":"pi_101_soho_4821"}""", """{"status":"succeeded"}""", null, now - 180000L),
            ApiRequestEntity("req_948102c", "POST", "/v1/payment_intents", 201, 29, """{"amount":1420,"currency":"gbp"}""", """{"id":"pi_102_soho_4822","status":"requires_payment_method"}""", "idemp_soho_902", now - 430000L),
            ApiRequestEntity("req_948102d", "GET", "/v1/terminal/readers", 200, 18, null, """{"data":[{"id":"rdr_soho_01","status":"ready"}]}""", null, now - 500000L)
        )
    }
}
