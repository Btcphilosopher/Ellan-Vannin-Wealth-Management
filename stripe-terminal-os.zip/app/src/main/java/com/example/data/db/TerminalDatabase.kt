package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PaymentIntentEntity::class,
        TransactionEntity::class,
        RefundEntity::class,
        ReceiptEntity::class,
        TerminalEntity::class,
        ReaderEntity::class,
        LedgerEntryEntity::class,
        ReconciliationEntity::class,
        WebhookEventEntity::class,
        AuditRecordEntity::class,
        ProductEntity::class,
        ApiRequestEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TerminalDatabase : RoomDatabase() {
    abstract fun paymentDao(): PaymentDao
    abstract fun terminalDao(): TerminalDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun reconciliationDao(): ReconciliationDao
    abstract fun webhookDao(): WebhookDao
    abstract fun auditDao(): AuditDao
    abstract fun productDao(): ProductDao
    abstract fun apiLogDao(): ApiLogDao

    companion object {
        @Volatile
        private var INSTANCE: TerminalDatabase? = null

        fun getDatabase(context: Context): TerminalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TerminalDatabase::class.java,
                    "stripe_terminal_os_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
