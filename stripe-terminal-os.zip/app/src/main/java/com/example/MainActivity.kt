package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.StripeBadge
import com.example.ui.screens.dashboard.*
import com.example.ui.screens.pos.PosScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppNavigationTab
import com.example.ui.viewmodel.TerminalViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: TerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                TerminalApp(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalApp(viewModel: TerminalViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val terminalState by viewModel.terminalState.collectAsState()
    val activeReader by viewModel.activeReader.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(StripeBackground),
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(StripeSurface)
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Logo & Brand
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(StripeIndigo),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PointOfSale,
                                contentDescription = "Terminal.OS",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "TERMINAL.OS",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = StripeNavy,
                                    letterSpacing = 0.5.sp
                                )
                                StripeBadge(
                                    text = "SANDBOX",
                                    bgColor = StripeIndigoSubtle,
                                    textColor = StripeIndigo
                                )
                            }
                            Text(
                                text = "The Coffee House • London Soho",
                                fontSize = 11.sp,
                                color = StripeSubdued
                            )
                        }
                    }

                    // Reader Connection Status Indicator
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(StripeBorderSubtle)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (activeReader != null) StripeSuccess else StripeDanger)
                        )
                        Text(
                            text = (activeReader?.label ?: "Disconnected").uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = StripeNavy
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = StripeSurface,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, StripeBorder)
                    .navigationBarsPadding()
            ) {
                AppNavigationTab.entries.forEach { tab ->
                    val isSelected = tab == selectedTab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(tab) },
                        icon = {
                            Icon(
                                imageVector = when (tab) {
                                    AppNavigationTab.POS -> Icons.Default.PointOfSale
                                    AppNavigationTab.OVERVIEW -> Icons.Default.Dashboard
                                    AppNavigationTab.PAYMENTS -> Icons.Default.ReceiptLong
                                    AppNavigationTab.TERMINALS -> Icons.Default.DevicesOther
                                    AppNavigationTab.RECONCILIATION -> Icons.Default.AccountBalance
                                    AppNavigationTab.DEVELOPERS -> Icons.Default.Code
                                },
                                contentDescription = tab.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = StripeIndigo,
                            selectedTextColor = StripeIndigo,
                            unselectedIconColor = StripeSubdued,
                            unselectedTextColor = StripeSubdued,
                            indicatorColor = StripeIndigoSubtle
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                AppNavigationTab.POS -> PosScreen(viewModel = viewModel)
                AppNavigationTab.OVERVIEW -> DashboardOverviewScreen(viewModel = viewModel)
                AppNavigationTab.PAYMENTS -> PaymentsScreen(viewModel = viewModel)
                AppNavigationTab.TERMINALS -> TerminalsFleetScreen(viewModel = viewModel)
                AppNavigationTab.RECONCILIATION -> ReconciliationScreen(viewModel = viewModel)
                AppNavigationTab.DEVELOPERS -> DeveloperConsoleScreen(viewModel = viewModel)
            }
        }
    }
}
