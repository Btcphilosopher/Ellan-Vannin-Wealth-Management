package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun StripeCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = StripeSurface,
    borderColor: Color = StripeBorder,
    shapeRadius: Dp = 10.dp,
    padding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(shapeRadius)),
        shape = RoundedCornerShape(shapeRadius),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(padding)) {
            content()
        }
    }
}

@Composable
fun StripeBadge(
    text: String,
    modifier: Modifier = Modifier,
    bgColor: Color = StripeIndigoSubtle,
    textColor: Color = StripeIndigo,
    dotColor: Color? = null
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (dotColor != null) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
        }
        Text(
            text = text.uppercase(),
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.4.sp
        )
    }
}

@Composable
fun StripeStatusPill(status: String) {
    when (status.uppercase()) {
        "SUCCEEDED", "READY", "ONLINE", "DELIVERED", "RESOLVED", "MATCHED" -> {
            StripeBadge(text = status, bgColor = StripeSuccessBg, textColor = StripeSuccessDark, dotColor = StripeSuccess)
        }
        "PROCESSING", "UPDATING", "CONNECTING", "REQUESTED", "COLLECTING" -> {
            StripeBadge(text = status, bgColor = StripeIndigoSubtle, textColor = StripeIndigo, dotColor = StripeIndigo)
        }
        "WAITING_FOR_CARD", "INVESTIGATING", "PARTIALLY_REFUNDED", "RETRYING" -> {
            StripeBadge(text = status, bgColor = StripeWarningBg, textColor = StripeWarningDark, dotColor = StripeWarning)
        }
        "FAILED", "OFFLINE", "ERROR", "DECLINED", "DUPLICATE", "MISSING_RECORD", "AMOUNT_MISMATCH" -> {
            StripeBadge(text = status, bgColor = StripeDangerBg, textColor = StripeDanger, dotColor = StripeDanger)
        }
        else -> {
            StripeBadge(text = status, bgColor = StripeBorderSubtle, textColor = StripeSlate, dotColor = StripeSubdued)
        }
    }
}

@Composable
fun StripeMetricTile(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    trendText: String? = null,
    isPositiveTrend: Boolean = true
) {
    StripeCard(modifier = modifier, padding = PaddingValues(14.dp)) {
        Text(
            text = title.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = StripeSubdued,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = value,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = StripeNavy,
            letterSpacing = (-0.5).sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (trendText != null) {
                Text(
                    text = trendText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isPositiveTrend) StripeSuccessDark else StripeDanger
                )
            }
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = StripeSlate,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun StripeButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    isPrimary: Boolean = true,
    isLoading: Boolean = false,
    enabled: Boolean = true,
    testTag: String = "stripe_button"
) {
    Button(
        onClick = onClick,
        enabled = enabled && !isLoading,
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isPrimary) StripeIndigo else StripeSurface,
            contentColor = if (isPrimary) Color.White else StripeNavy,
            disabledContainerColor = StripeBorderSubtle,
            disabledContentColor = StripeSubdued
        ),
        border = if (!isPrimary) androidx.compose.foundation.BorderStroke(1.dp, StripeBorder) else null,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        modifier = modifier
            .testTag(testTag)
            .heightIn(min = 44.dp)
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                color = if (isPrimary) Color.White else StripeIndigo,
                strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(8.dp))
        } else if (icon != null) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(
            text = text,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun StripeCodeBlock(code: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF0F172A))
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Text(
            text = code,
            color = Color(0xFF94A3B8),
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            lineHeight = 16.sp
        )
    }
}
