package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.model.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun PaymentDetailModal(
    transaction: Transaction,
    onDismiss: () -> Unit,
    onIssueRefund: (Transaction, MoneyMinor?) -> Unit
) {
    var isRefunding by remember { mutableStateOf(false) }
    var partialRefundAmount by remember { mutableStateOf("") }

    val formattedDate = remember(transaction.createdAt) {
        SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.UK).format(Date(transaction.createdAt))
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .clip(RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = StripeSurface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PAYMENT INTENT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StripeSubdued,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = transaction.paymentIntentId.value,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = StripeNavy
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = StripeSlate)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Hero Amount + Status Pill
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = transaction.amount.format(transaction.currency),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            color = StripeNavy,
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = "Net: ${transaction.netAmount.format(transaction.currency)} • Fee: ${transaction.feeAmount.format(transaction.currency)}",
                            fontSize = 12.sp,
                            color = StripeSlate
                        )
                    }
                    StripeStatusPill(status = transaction.status.name)
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = StripeBorder, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Timeline lifecycle steps
                Text(
                    text = "PAYMENT TIMELINE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StripeSubdued,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                val steps = listOf(
                    "Payment Intent Created" to "Created on POS counter",
                    "Card Present Collected" to "${transaction.paymentMethod.brand.displayName} •••• ${transaction.paymentMethod.last4} via ${transaction.paymentMethod.entryMethod.displayName}",
                    "Processor Authorized" to "Auth Code: ${transaction.paymentMethod.authCode}",
                    "Funds Captured" to "Settled to Merchant Settlement Ledger",
                    "Receipt Issued" to (transaction.receiptId?.value ?: "Digital receipt issued")
                )

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    steps.forEachIndexed { index, (title, sub) ->
                        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(StripeSuccess),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                            }
                            Column {
                                Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = StripeNavy)
                                Text(text = sub, fontSize = 11.sp, color = StripeSlate)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = StripeBorder, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))

                // Hardware & Location info
                Text(
                    text = "HARDWARE & TERMINAL",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StripeSubdued,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                StripeCard(padding = PaddingValues(10.dp), backgroundColor = StripeBackground) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Location", fontSize = 12.sp, color = StripeSlate)
                        Text(transaction.locationName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = StripeNavy)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Terminal", fontSize = 12.sp, color = StripeSlate)
                        Text(transaction.terminalName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = StripeNavy)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Time", fontSize = 12.sp, color = StripeSlate)
                        Text(formattedDate, fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = StripeNavy)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions: Full Refund / Partial Refund
                if (transaction.status == TransactionStatus.SUCCEEDED) {
                    if (!isRefunding) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StripeButton(
                                text = "Full Refund (${transaction.amount.format(transaction.currency)})",
                                onClick = {
                                    onIssueRefund(transaction, null)
                                    onDismiss()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("full_refund_btn"),
                                isPrimary = false
                            )

                            StripeButton(
                                text = "Partial Refund",
                                onClick = { isRefunding = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("partial_refund_btn"),
                                isPrimary = false
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(StripeBorderSubtle)
                                .padding(10.dp)
                        ) {
                            Text("Enter Partial Refund Amount (in pence / cents):", fontSize = 11.sp, color = StripeNavy)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = partialRefundAmount,
                                    onValueChange = { partialRefundAmount = it },
                                    placeholder = { Text("e.g. 500 = £5.00", fontSize = 12.sp) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp),
                                    shape = RoundedCornerShape(6.dp),
                                    singleLine = true
                                )
                                Button(
                                    onClick = {
                                        val minor = partialRefundAmount.toLongOrNull() ?: 0L
                                        if (minor in 1..transaction.amount.value) {
                                            onIssueRefund(transaction, MoneyMinor(minor))
                                            onDismiss()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = StripeIndigo),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Confirm", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
