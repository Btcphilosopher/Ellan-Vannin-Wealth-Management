package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardOverviewScreen(viewModel: TerminalViewModel) {
    val transactions by viewModel.transactions.collectAsState()
    val terminals by viewModel.terminals.collectAsState()
    val selectedPaymentDetail by viewModel.selectedPaymentDetail.collectAsState()

    if (selectedPaymentDetail != null) {
        PaymentDetailModal(
            transaction = selectedPaymentDetail!!,
            onDismiss = { viewModel.selectPaymentDetail(null) },
            onIssueRefund = { tx, amt -> viewModel.issueRefund(tx.paymentIntentId, amt) }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StripeBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TERMINAL OVERVIEW",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "The Coffee House • Multi-Location Network",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeNavy
                    )
                }

                StripeBadge(
                    text = "SANDBOX / SIMULATION",
                    bgColor = Color(0xFFEFF6FF),
                    textColor = Color(0xFF1D4ED8),
                    dotColor = Color(0xFF3B82F6)
                )
            }
        }

        // Metrics 2x2 Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StripeMetricTile(
                        title = "Gross Volume Today",
                        value = "£48,291.00",
                        subtitle = "across 4 active locations",
                        trendText = "+14.2%",
                        isPositiveTrend = true,
                        modifier = Modifier.weight(1f)
                    )
                    StripeMetricTile(
                        title = "Payments Count",
                        value = "1,842",
                        subtitle = "in-person card present",
                        trendText = "+8.9%",
                        isPositiveTrend = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StripeMetricTile(
                        title = "Average Ticket",
                        value = "£26.22",
                        subtitle = "standard POS transaction",
                        trendText = "+2.1%",
                        isPositiveTrend = true,
                        modifier = Modifier.weight(1f)
                    )
                    StripeMetricTile(
                        title = "Terminal Success Rate",
                        value = "97.8%",
                        subtitle = "0.02% card reader error",
                        trendText = "Nominal",
                        isPositiveTrend = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Location Revenue Distribution
        item {
            StripeCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LOCATIONS NETWORK",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "4 Locations Active",
                        fontSize = 11.sp,
                        color = StripeSlate
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                val locations = listOf(
                    Triple("London Soho", "44 Old Compton St", "£48,291.00"),
                    Triple("London Shoreditch", "88 Redchurch Street", "£31,450.00"),
                    Triple("Manchester Northern Quarter", "12 Stevenson Square", "£22,900.00"),
                    Triple("Edinburgh Old Town", "104 Victoria Street", "£18,740.00")
                )

                locations.forEach { (name, address, revenue) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = StripeNavy)
                            Text(text = address, fontSize = 11.sp, color = StripeSubdued)
                        }
                        Text(
                            text = revenue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = StripeNavy
                        )
                    }
                    Divider(color = StripeBorderSubtle, thickness = 1.dp)
                }
            }
        }

        // Live Transaction Stream
        item {
            Text(
                text = "RECENT IN-PERSON PAYMENTS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StripeSubdued,
                letterSpacing = 0.5.sp
            )
        }

        items(transactions) { tx ->
            val formattedTime = remember(tx.createdAt) {
                SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date(tx.createdAt))
            }

            StripeCard(
                modifier = Modifier.clickable { viewModel.selectPaymentDetail(tx) },
                padding = PaddingValues(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(StripeIndigoSubtle),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CreditCard, contentDescription = null, tint = StripeIndigo, modifier = Modifier.size(16.dp))
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = tx.amount.format(tx.currency),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StripeNavy,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "• ${tx.paymentMethod.brand.displayName} •••• ${tx.paymentMethod.last4}",
                                    fontSize = 12.sp,
                                    color = StripeSlate
                                )
                            }
                            Text(
                                text = "${tx.locationName} • ${tx.terminalName} • $formattedTime",
                                fontSize = 11.sp,
                                color = StripeSubdued
                            )
                        }
                    }

                    StripeStatusPill(status = tx.status.name)
                }
            }
        }
    }
}
