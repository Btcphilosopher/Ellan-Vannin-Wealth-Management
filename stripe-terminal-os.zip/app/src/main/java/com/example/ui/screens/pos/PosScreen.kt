package com.example.ui.screens.pos

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.sdk.PaymentLifecycleState
import com.example.ui.components.ReceiptModal
import com.example.ui.components.StripeButton
import com.example.ui.components.StripeCard
import com.example.ui.components.TerminalPhysicalReaderView
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun PosScreen(viewModel: TerminalViewModel) {
    val posState by viewModel.posState.collectAsState()
    val products by viewModel.products.collectAsState()
    val activeReader by viewModel.activeReader.collectAsState()
    val paymentState by viewModel.paymentLifecycleState.collectAsState()

    var showCustomKeypad by remember { mutableStateOf(false) }

    if (posState.isReceiptModalOpen && posState.activeReceipt != null) {
        ReceiptModal(
            receipt = posState.activeReceipt!!,
            onDismiss = { viewModel.dismissReceiptModal() }
        )
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(StripeBackground)
    ) {
        // Left Area: Product Catalogue & Categories OR Custom Keypad
        Column(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxHeight()
                .padding(12.dp)
        ) {
            // Mode Switcher: Catalogue vs Custom Keypad
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "THE COFFEE HOUSE • POS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = StripeSubdued,
                    letterSpacing = 0.5.sp
                )

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(StripeBorderSubtle)
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (!showCustomKeypad) StripeSurface else Color.Transparent)
                            .clickable { showCustomKeypad = false }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "Catalogue",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (!showCustomKeypad) StripeIndigo else StripeSlate
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (showCustomKeypad) StripeSurface else Color.Transparent)
                            .clickable { showCustomKeypad = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "Custom Amount",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (showCustomKeypad) StripeIndigo else StripeSlate
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (!showCustomKeypad) {
                // Category Pills
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(ProductCategory.entries) { cat ->
                        val isSelected = cat == posState.selectedCategory
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) StripeIndigo else StripeSurface)
                                .border(1.dp, if (isSelected) StripeIndigo else StripeBorder, RoundedCornerShape(20.dp))
                                .clickable { viewModel.selectCategory(cat) }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = cat.displayName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else StripeNavy
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Products Grid
                val filteredProducts = products.filter { it.category == posState.selectedCategory }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredProducts) { product ->
                        ProductItemCard(
                            product = product,
                            quantityInCart = posState.cart.items.find { it.product.id == product.id }?.quantity ?: 0,
                            onAdd = { viewModel.addToCart(product) }
                        )
                    }
                }
            } else {
                // Custom Amount Keypad
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val amountMinor = posState.customAmountInput.toLongOrNull() ?: 0L
                    val formatted = MoneyMinor(amountMinor).format(Currency.GBP)

                    Text("ENTER CUSTOM SALE AMOUNT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StripeSubdued)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = formatted,
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeNavy,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // 3x4 Number Keypad
                    val keys = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9"),
                        listOf("C", "0", "⌫")
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        keys.forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                row.forEach { key ->
                                    Button(
                                        onClick = {
                                            when (key) {
                                                "C" -> viewModel.clearCart()
                                                "⌫" -> viewModel.deleteCustomAmountDigit()
                                                else -> viewModel.appendCustomAmountDigit(key)
                                            }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (key == "C" || key == "⌫") StripeBorderSubtle else StripeSurface,
                                            contentColor = StripeNavy
                                        ),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, StripeBorder),
                                        modifier = Modifier
                                            .size(width = 76.dp, height = 48.dp)
                                    ) {
                                        Text(text = key, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Right Area: Live Cart & Reader Drawer
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .background(StripeSurface)
                .border(1.dp, StripeBorder)
                .padding(12.dp)
        ) {
            // Cart Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = StripeIndigo, modifier = Modifier.size(16.dp))
                    Text(
                        text = "ORDER SUMMARY (${posState.cart.itemCount})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                }

                if (!posState.cart.isEmpty) {
                    Text(
                        text = "Clear",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = StripeDanger,
                        modifier = Modifier.clickable { viewModel.clearCart() }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Cart Items or Empty Placeholder
            if (posState.cart.isEmpty && !posState.isCustomAmountActive) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(StripeBackground)
                        .border(1.dp, StripeBorderSubtle, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Cart is empty • Tap items or keypad to charge",
                        fontSize = 11.sp,
                        color = StripeSubdued
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                ) {
                    if (posState.isCustomAmountActive) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Custom Point-of-Sale Charge", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = StripeNavy)
                                Text(
                                    MoneyMinor(posState.customAmountInput.toLongOrNull() ?: 0L).format(Currency.GBP),
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        items(posState.cart.items) { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("${item.quantity}x", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StripeIndigo)
                                    Text(item.product.name, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = StripeNavy, maxLines = 1)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(item.lineSubtotal.format(Currency.GBP), fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
                                    Icon(
                                        Icons.Default.RemoveCircleOutline,
                                        contentDescription = "Remove",
                                        tint = StripeSubdued,
                                        modifier = Modifier
                                            .size(14.dp)
                                            .clickable { viewModel.removeFromCart(item.product.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Divider(color = StripeBorder, thickness = 1.dp)
            Spacer(modifier = Modifier.height(6.dp))

            // Subtotal / Total
            val finalAmount = if (posState.isCustomAmountActive) {
                MoneyMinor(posState.customAmountInput.toLongOrNull() ?: 0L)
            } else {
                posState.cart.totalAmount
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TOTAL DUE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = finalAmount.format(Currency.GBP),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeNavy,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // PAY Button launching Terminal Engine
                val isBusy = paymentState !is PaymentLifecycleState.Idle && paymentState !is PaymentLifecycleState.Approved
                StripeButton(
                    text = if (isBusy) "Collecting..." else "PAY NOW",
                    onClick = { viewModel.initiateTerminalPayment() },
                    icon = Icons.Default.Contactless,
                    enabled = finalAmount.value > 0 && !isBusy,
                    isLoading = isBusy,
                    modifier = Modifier.testTag("pos_pay_button")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Physical Hardware Terminal Simulator View
            TerminalPhysicalReaderView(
                reader = activeReader,
                paymentState = paymentState,
                selectedScenario = posState.selectedTestScenario,
                onScenarioSelected = { viewModel.setTestScenario(it) },
                onSimulateCardTap = { viewModel.initiateTerminalPayment() },
                onCancelPayment = { viewModel.cancelActivePayment() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun ProductItemCard(
    product: Product,
    quantityInCart: Int,
    onAdd: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onAdd() }
            .border(1.dp, if (quantityInCart > 0) StripeIndigo else StripeBorder, RoundedCornerShape(10.dp)),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = StripeSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color(product.colorAccent).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (product.category) {
                            ProductCategory.COFFEE -> Icons.Default.LocalCafe
                            ProductCategory.TEA -> Icons.Default.EmojiFoodBeverage
                            ProductCategory.BAKERY -> Icons.Default.BakeryDining
                            ProductCategory.FOOD -> Icons.Default.LunchDining
                            ProductCategory.MERCHANDISE -> Icons.Default.ShoppingBag
                        },
                        contentDescription = null,
                        tint = Color(product.colorAccent),
                        modifier = Modifier.size(14.dp)
                    )
                }

                if (quantityInCart > 0) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(StripeIndigo)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "$quantityInCart",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = product.name,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp,
                color = StripeNavy,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = product.description,
                fontSize = 10.sp,
                color = StripeSubdued,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = product.price.format(product.currency),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = StripeNavy
            )
        }
    }
}
