package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.model.Receipt
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReceiptModal(
    receipt: Receipt,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var deliveryMethod by remember { mutableStateOf<String?>(null) }
    var deliveryInput by remember { mutableStateOf("") }
    var deliverySent by remember { mutableStateOf(false) }

    val formattedDate = remember(receipt.timestamp) {
        SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.UK).format(Date(receipt.timestamp))
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .clip(RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = StripeSurface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Thermal Receipt Paper styling
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFCFDFD))
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                        .padding(18.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = receipt.merchantName.uppercase(),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = StripeNavy,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = receipt.locationAddress,
                            fontSize = 11.sp,
                            color = StripeSlate,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = formattedDate,
                            fontSize = 10.sp,
                            color = StripeSubdued,
                            fontFamily = FontFamily.Monospace
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        Divider(color = Color(0xFFCBD5E1), thickness = 1.dp)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Line items
                        receipt.lines.forEach { line ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (line.quantity > 1) "${line.quantity}x ${line.description}" else line.description,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = StripeNavy
                                )
                                Text(
                                    text = line.totalPrice.format(receipt.currency),
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = StripeNavy
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = Color(0xFFE2E8F0), thickness = 1.dp)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Subtotal & VAT
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Subtotal", fontSize = 12.sp, color = StripeSlate)
                            Text(text = receipt.subtotal.format(receipt.currency), fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = StripeSlate)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = receipt.tax.name, fontSize = 12.sp, color = StripeSlate)
                            Text(text = receipt.tax.amount.format(receipt.currency), fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = StripeSlate)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = Color(0xFFCBD5E1), thickness = 1.dp)
                        Spacer(modifier = Modifier.height(8.dp))

                        // TOTAL
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "TOTAL", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = StripeNavy)
                            Text(
                                text = receipt.total.format(receipt.currency),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = StripeNavy
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Card EMV Auth block
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFF1F5F9))
                                .padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "${receipt.cardBrand.displayName} •••• ${receipt.cardLast4} (${receipt.entryMethod.displayName})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = StripeNavy
                            )
                            Text(
                                text = "AUTH: ${receipt.authCode} • ${receipt.terminalName}",
                                fontSize = 10.sp,
                                color = StripeSubdued,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "APPROVED",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = StripeSuccessDark,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Digital Delivery Actions (EMAIL / SMS / QR / PRINT)
                if (!deliverySent) {
                    Text(
                        text = "SEND DIGITAL RECEIPT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { deliveryMethod = "EMAIL" },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (deliveryMethod == "EMAIL") StripeIndigo else StripeBorderSubtle,
                                contentColor = if (deliveryMethod == "EMAIL") Color.White else StripeNavy
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.Email, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Email", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { deliveryMethod = "SMS" },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (deliveryMethod == "SMS") StripeIndigo else StripeBorderSubtle,
                                contentColor = if (deliveryMethod == "SMS") Color.White else StripeNavy
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.PhoneIphone, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SMS", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                Toast.makeText(context, "Receipt sent to thermal printer.", Toast.LENGTH_SHORT).show()
                                deliverySent = true
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StripeBorderSubtle,
                                contentColor = StripeNavy
                            ),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Print", fontSize = 12.sp)
                        }
                    }

                    if (deliveryMethod != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = deliveryInput,
                                onValueChange = { deliveryInput = it },
                                placeholder = {
                                    Text(
                                        if (deliveryMethod == "EMAIL") "alex@example.com" else "+44 7700 900077",
                                        fontSize = 12.sp
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp)
                            )

                            Button(
                                onClick = {
                                    if (deliveryInput.isNotEmpty()) {
                                        Toast.makeText(context, "Receipt delivered via $deliveryMethod to $deliveryInput", Toast.LENGTH_SHORT).show()
                                        deliverySent = true
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StripeIndigo),
                                modifier = Modifier.height(48.dp)
                            ) {
                                Text("Send", fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(StripeSuccessBg)
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StripeSuccessDark, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Receipt dispatched successfully", color = StripeSuccessDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Done / Dismiss
                StripeButton(
                    text = "Done & New Order",
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("receipt_done_btn"),
                    isPrimary = true
                )
            }
        }
    }
}
