package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Transaction
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun PaymentsScreen(viewModel: TerminalViewModel) {
    val transactions by viewModel.transactions.collectAsState()
    val searchQuery by viewModel.paymentSearchQuery.collectAsState()
    val statusFilter by viewModel.paymentStatusFilter.collectAsState()
    val selectedPaymentDetail by viewModel.selectedPaymentDetail.collectAsState()

    if (selectedPaymentDetail != null) {
        PaymentDetailModal(
            transaction = selectedPaymentDetail!!,
            onDismiss = { viewModel.selectPaymentDetail(null) },
            onIssueRefund = { tx, amt -> viewModel.issueRefund(tx.paymentIntentId, amt) }
        )
    }

    val filteredTransactions = transactions.filter { tx ->
        val matchesSearch = searchQuery.isEmpty() ||
            tx.paymentIntentId.value.contains(searchQuery, ignoreCase = true) ||
            tx.customerName.contains(searchQuery, ignoreCase = true) ||
            tx.terminalName.contains(searchQuery, ignoreCase = true) ||
            tx.locationName.contains(searchQuery, ignoreCase = true)

        val matchesStatus = statusFilter == "ALL" || tx.status.name.equals(statusFilter, ignoreCase = true)
        matchesSearch && matchesStatus
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StripeBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Header & Search Bar
        item {
            Text(
                text = "PAYMENTS & TRANSACTIONS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = StripeSubdued,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "In-Person Point-of-Sale Transactions",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = StripeNavy
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setPaymentSearchQuery(it) },
                placeholder = { Text("Filter by payment ID (pi_...), terminal, or location...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = StripeSubdued) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setPaymentSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = StripeSubdued)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("payment_search_input"),
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = StripeIndigo,
                    unfocusedBorderColor = StripeBorder,
                    focusedContainerColor = StripeSurface,
                    unfocusedContainerColor = StripeSurface
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Status Filter Chips
            val filterOptions = listOf("ALL", "SUCCEEDED", "REFUNDED", "PARTIALLY_REFUNDED", "FAILED")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(filterOptions) { opt ->
                    val isSelected = opt == statusFilter
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) StripeIndigo else StripeSurface)
                            .border(1.dp, if (isSelected) StripeIndigo else StripeBorder, RoundedCornerShape(16.dp))
                            .clickable { viewModel.setPaymentStatusFilter(opt) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = opt.replace("_", " "),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isSelected) Color.White else StripeSlate
                        )
                    }
                }
            }
        }

        // Transactions Count
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredTransactions.size} transactions found",
                    fontSize = 12.sp,
                    color = StripeSubdued
                )
            }
        }

        // Transactions List
        items(filteredTransactions) { tx ->
            val formattedDate = remember(tx.createdAt) {
                SimpleDateFormat("dd MMM, HH:mm:ss", Locale.UK).format(Date(tx.createdAt))
            }

            StripeCard(
                modifier = Modifier.clickable { viewModel.selectPaymentDetail(tx) },
                padding = PaddingValues(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = tx.amount.format(tx.currency),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = StripeNavy,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "• ${tx.paymentIntentId.value}",
                                fontSize = 12.sp,
                                color = StripeSlate,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${tx.customerName} • ${tx.paymentMethod.brand.displayName} •••• ${tx.paymentMethod.last4} (${tx.paymentMethod.entryMethod.displayName})",
                            fontSize = 12.sp,
                            color = StripeNavy
                        )
                        Text(
                            text = "${tx.locationName} • ${tx.terminalName} • $formattedDate",
                            fontSize = 11.sp,
                            color = StripeSubdued
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        StripeStatusPill(status = tx.status.name)
                        if (tx.refundedAmount.value > 0) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Ref: ${tx.refundedAmount.format(tx.currency)}",
                                fontSize = 10.sp,
                                color = StripeDanger,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}
