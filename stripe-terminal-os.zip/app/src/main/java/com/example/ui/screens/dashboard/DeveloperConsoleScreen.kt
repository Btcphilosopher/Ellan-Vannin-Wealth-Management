package com.example.ui.screens.dashboard

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.WebhookEventType
import com.example.ui.components.StripeBadge
import com.example.ui.components.StripeCard
import com.example.ui.components.StripeCodeBlock
import com.example.ui.components.StripeStatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DeveloperConsoleScreen(viewModel: TerminalViewModel) {
    val context = LocalContext.current
    val apiLogs by viewModel.apiLogs.collectAsState()
    val webhookEvents by viewModel.webhookEvents.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()

    var activeSubTab by remember { mutableStateOf("API_LOGS") } // "API_LOGS", "WEBHOOKS", "SDK", "AUDIT"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StripeBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Developer Top Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DEVELOPER CONSOLE & TERMINAL API",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Stripe Terminal.OS SDK & HTTP API",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeNavy
                    )
                }

                StripeBadge(
                    text = "TEST MODE",
                    bgColor = StripeIndigoSubtle,
                    textColor = StripeIndigo,
                    dotColor = StripeIndigo
                )
            }
        }

        // Simulated API Keys Card
        item {
            StripeCard {
                Text(
                    text = "SIMULATED API CREDENTIALS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StripeSubdued,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Publishable Key", fontSize = 12.sp, color = StripeSlate)
                        Text("pk_test_51MzPOSDemoKey99281A", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, color = StripeNavy)
                    }
                    Divider(color = StripeBorderSubtle, thickness = 1.dp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Secret Key", fontSize = 12.sp, color = StripeSlate)
                        Text("sk_test_••••••••••••••••", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, color = StripeNavy)
                    }
                    Divider(color = StripeBorderSubtle, thickness = 1.dp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Webhook Secret", fontSize = 12.sp, color = StripeSlate)
                        Text("whsec_test_7f92a10b42c8d", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, color = StripeNavy)
                    }
                }
            }
        }

        // Sub Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(StripeBorderSubtle)
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val tabs = listOf(
                    "API_LOGS" to "Live Logs",
                    "WEBHOOKS" to "Webhooks",
                    "SDK" to "Kotlin SDK",
                    "AUDIT" to "Audit Trail"
                )

                tabs.forEach { (key, label) ->
                    val isSelected = activeSubTab == key
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) StripeSurface else Color.Transparent)
                            .clickable { activeSubTab = key }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isSelected) StripeIndigo else StripeSlate
                        )
                    }
                }
            }
        }

        when (activeSubTab) {
            "API_LOGS" -> {
                item {
                    Text(
                        text = "REAL-TIME API REQUEST STREAM",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                }

                items(apiLogs) { log ->
                    val formattedTime = remember(log.timestamp) {
                        SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date(log.timestamp))
                    }

                    StripeCard(padding = PaddingValues(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (log.statusCode in 200..299) StripeSuccessBg else StripeDangerBg)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${log.statusCode}",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (log.statusCode in 200..299) StripeSuccessDark else StripeDanger
                                    )
                                }
                                Text(
                                    text = "${log.method} ${log.path}",
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = StripeNavy
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "${log.durationMs}ms",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = StripeSubdued
                                )
                                Text(
                                    text = formattedTime,
                                    fontSize = 10.sp,
                                    color = StripeSubdued
                                )
                            }
                        }

                        if (log.responsePayload != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            StripeCodeBlock(code = log.responsePayload)
                        }
                    }
                }
            }

            "WEBHOOKS" -> {
                item {
                    StripeCard(backgroundColor = Color(0xFFF8FAFC)) {
                        Text(
                            text = "TRIGGER TEST WEBHOOK DISPATCH",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StripeSubdued,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.testWebhookDispatch(WebhookEventType.PAYMENT_INTENT_SUCCEEDED)
                                    Toast.makeText(context, "Dispatched payment_intent.succeeded", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StripeSurface, contentColor = StripeNavy),
                                border = androidx.compose.foundation.BorderStroke(1.dp, StripeBorder),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(4.dp)
                            ) {
                                Text("intent.succeeded", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    viewModel.testWebhookDispatch(WebhookEventType.REFUND_SUCCEEDED)
                                    Toast.makeText(context, "Dispatched refund.succeeded", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StripeSurface, contentColor = StripeNavy),
                                border = androidx.compose.foundation.BorderStroke(1.dp, StripeBorder),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(4.dp)
                            ) {
                                Text("refund.succeeded", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    viewModel.testWebhookDispatch(WebhookEventType.READER_DISCONNECTED)
                                    Toast.makeText(context, "Dispatched terminal.disconnected", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StripeSurface, contentColor = StripeNavy),
                                border = androidx.compose.foundation.BorderStroke(1.dp, StripeBorder),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(4.dp)
                            ) {
                                Text("reader.disconnected", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                items(webhookEvents) { evt ->
                    StripeCard(padding = PaddingValues(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = evt.eventType,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = StripeNavy
                                )
                                Text(
                                    text = "ID: ${evt.id} • Latency: ${evt.lastDurationMs}ms • Code: ${evt.lastResponseCode}",
                                    fontSize = 11.sp,
                                    color = StripeSubdued
                                )
                            }
                            StripeStatusPill(status = evt.deliveryStatus)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        StripeCodeBlock(code = evt.payloadJson)
                    }
                }
            }

            "SDK" -> {
                item {
                    Text(
                        text = "KOTLIN TERMINAL SDK USAGE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val snippet = """
// 1. Create PaymentIntent with typed MoneyMinor
val intent = terminal.createPaymentIntent(
    amount = Money.gbp(2450), // £24.50
    description = "Counter 01 Coffee Sale",
    idempotencyKey = "pos_tx_09184"
)

// 2. Connect Reader & Collect Card Present
terminal.connectReader(reader)
terminal.collectPaymentMethod(intent)

// 3. Process with deterministic state machine
val result = terminal.processPayment(intent)

when (result) {
    is PaymentResult.Succeeded -> {
        println("Payment Approved: " + result.receipt.id)
    }
    is PaymentResult.Failed -> {
        println("Decline: " + result.reason)
    }
}
                    """.trimIndent()

                    StripeCodeBlock(code = snippet)
                }
            }

            "AUDIT" -> {
                items(auditLogs) { record ->
                    val formattedTime = remember(record.timestamp) {
                        SimpleDateFormat("dd MMM, HH:mm:ss", Locale.UK).format(Date(record.timestamp))
                    }

                    StripeCard(padding = PaddingValues(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = record.action,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StripeNavy
                                )
                                Text(
                                    text = record.details,
                                    fontSize = 11.sp,
                                    color = StripeSlate
                                )
                                Text(
                                    text = "By: ${record.who} (${record.role}) • $formattedTime",
                                    fontSize = 10.sp,
                                    color = StripeSubdued
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
