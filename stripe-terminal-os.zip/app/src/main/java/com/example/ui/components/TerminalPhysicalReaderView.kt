package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.sdk.PaymentLifecycleState
import com.example.ui.theme.*

@Composable
fun TerminalPhysicalReaderView(
    reader: Reader?,
    paymentState: PaymentLifecycleState,
    selectedScenario: TestCardScenario,
    onScenarioSelected: (TestCardScenario) -> Unit,
    onSimulateCardTap: () -> Unit,
    onCancelPayment: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "nfc_pulse")
    val nfcAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "nfc_alpha"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ReaderChassisDark)
            .border(1.dp, ReaderChassisBorder, RoundedCornerShape(16.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Reader Hardware Top Bar: Model & Status Indicator
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (reader != null) StripeSuccess else StripeDanger)
                )
                Text(
                    text = (reader?.label ?: "No Reader Connected").uppercase(),
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            // 4 Contactless EMV LEDs
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                val isProcessing = paymentState !is PaymentLifecycleState.Idle
                for (i in 1..4) {
                    val isLit = when (paymentState) {
                        is PaymentLifecycleState.Idle -> false
                        is PaymentLifecycleState.WaitingForCard -> i == 1
                        is PaymentLifecycleState.CardDetected -> i <= 2
                        is PaymentLifecycleState.ReadingCard, is PaymentLifecycleState.RequiringPin -> i <= 3
                        is PaymentLifecycleState.Authorizing, is PaymentLifecycleState.Processing -> true
                        is PaymentLifecycleState.Approved -> true
                        is PaymentLifecycleState.Declined, is PaymentLifecycleState.Cancelled, is PaymentLifecycleState.Error -> false
                        else -> false
                    }
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(
                                if (isLit) Color(0xFF38BDF8)
                                else if (paymentState is PaymentLifecycleState.Declined) StripeDanger
                                else Color(0xFF334155)
                            )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // OLED Display Screen
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(ReaderScreenBg)
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(10.dp))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            when (paymentState) {
                is PaymentLifecycleState.Idle -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Contactless,
                            contentDescription = null,
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "STRIPE TERMINAL.OS",
                            color = Color(0xFF64748B),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Reader Ready • Awaiting POS Cart",
                            color = Color(0xFF475569),
                            fontSize = 12.sp
                        )
                    }
                }

                is PaymentLifecycleState.RequiresPaymentMethod,
                is PaymentLifecycleState.WaitingForCard -> {
                    val intent = (paymentState as? PaymentLifecycleState.RequiresPaymentMethod)?.intent
                        ?: (paymentState as PaymentLifecycleState.WaitingForCard).intent

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = intent.formattedAmount(),
                            color = ReaderScreenText,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.5).sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "READY FOR PAYMENT",
                            color = Color(0xFF38BDF8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Contactless,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8).copy(alpha = nfcAlpha),
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "Tap, insert or swipe",
                                color = Color(0xFFCBD5E1),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                is PaymentLifecycleState.CardDetected -> {
                    val card = (paymentState as PaymentLifecycleState.CardDetected).card
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "CARD DETECTED",
                            color = Color(0xFF38BDF8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${card.brand.displayName} •••• ${card.last4}",
                            color = ReaderScreenText,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                is PaymentLifecycleState.ReadingCard -> {
                    val card = (paymentState as PaymentLifecycleState.ReadingCard).card
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = Color(0xFF38BDF8),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "READING CARD DATA...",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        )
                        Text(
                            text = "Do not remove card",
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                    }
                }

                is PaymentLifecycleState.RequiringPin -> {
                    val pinState = paymentState as PaymentLifecycleState.RequiringPin
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "ENTER PIN",
                            color = Color(0xFF38BDF8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (digit in 1..4) {
                                val entered = digit <= pinState.enteredDigits
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clip(CircleShape)
                                        .background(if (entered) Color.White else Color(0xFF334155))
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Press OK on Keypad",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }

                is PaymentLifecycleState.Authorizing,
                is PaymentLifecycleState.Processing -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(28.dp),
                            color = StripeIndigo,
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "AUTHORIZING...",
                            color = ReaderScreenText,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Connecting to acquiring processor",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }

                is PaymentLifecycleState.Approved -> {
                    val approved = paymentState as PaymentLifecycleState.Approved
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(StripeSuccess),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "PAYMENT APPROVED",
                            color = StripeSuccess,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = approved.intent.formattedAmount(),
                            color = ReaderScreenText,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Please take your receipt",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }

                is PaymentLifecycleState.Declined -> {
                    val declined = paymentState as PaymentLifecycleState.Declined
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(StripeDanger),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "PAYMENT DECLINED",
                            color = StripeDanger,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = declined.reason,
                            color = Color(0xFFCBD5E1),
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                is PaymentLifecycleState.Cancelled -> {
                    val cancelled = paymentState as PaymentLifecycleState.Cancelled
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "TRANSACTION CANCELLED",
                            color = Color(0xFFF59E0B),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = cancelled.reason,
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }

                is PaymentLifecycleState.Error -> {
                    val error = paymentState as PaymentLifecycleState.Error
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "TERMINAL ERROR",
                            color = StripeDanger,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = error.message,
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Synthetic Test Card Selector & Interactive Tap Drawer
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "SIMULATED CARD SCENARIO",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Test Scenario Buttons row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TestCardScenario.entries.take(4).forEach { scenario ->
                    val isSelected = scenario == selectedScenario
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) StripeIndigo else Color(0xFF2C3446))
                            .clickable { onScenarioSelected(scenario) }
                            .padding(vertical = 6.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = when (scenario) {
                                TestCardScenario.TEST_CARD_APPROVE -> "✓ Approve"
                                TestCardScenario.TEST_CARD_PHONE_PAY -> "📱 ApplePay"
                                TestCardScenario.TEST_CARD_CHIP_PIN -> "💳 Chip+PIN"
                                TestCardScenario.TEST_CARD_DECLINE -> "✕ Decline"
                                else -> scenario.title
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isSelected) Color.White else Color(0xFFCBD5E1),
                            maxLines = 1
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Active Card Indicator Bar with simulated Tap / Cancel triggers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF131826))
                    .border(1.dp, Color(0xFF232D42), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF1E293B))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = selectedScenario.brand.name,
                            color = Color(0xFF38BDF8),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "•••• ${selectedScenario.last4} (${selectedScenario.defaultEntryMethod.displayName})",
                        color = Color(0xFFE2E8F0),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (paymentState is PaymentLifecycleState.WaitingForCard || paymentState is PaymentLifecycleState.RequiresPaymentMethod) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = onSimulateCardTap,
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = StripeIndigo),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("reader_simulate_tap_btn")
                        ) {
                            Text("Simulate Tap", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        IconButton(
                            onClick = onCancelPayment,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
