package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = StripeIndigo,
    onPrimary = Color.White,
    primaryContainer = StripeDarkSurface,
    onPrimaryContainer = Color.White,
    secondary = StripeSuccess,
    onSecondary = StripeNavy,
    background = StripeDarkBg,
    onBackground = StripeDarkTextPrimary,
    surface = StripeDarkSurface,
    onSurface = StripeDarkTextPrimary,
    surfaceVariant = StripeDarkBorder,
    onSurfaceVariant = StripeDarkTextSecondary,
    outline = StripeDarkBorder,
    error = StripeDanger,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = StripeIndigo,
    onPrimary = Color.White,
    primaryContainer = StripeIndigoSubtle,
    onPrimaryContainer = StripeIndigoHover,
    secondary = StripeNavy,
    onSecondary = Color.White,
    background = StripeBackground,
    onBackground = StripeNavy,
    surface = StripeSurface,
    onSurface = StripeNavy,
    surfaceVariant = StripeBorderSubtle,
    onSurfaceVariant = StripeSlate,
    outline = StripeBorder,
    error = StripeDanger,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep Stripe pure palette consistent
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
