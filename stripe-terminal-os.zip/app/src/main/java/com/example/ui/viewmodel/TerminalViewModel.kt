package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.TerminalDatabase
import com.example.data.repository.TerminalRepository
import com.example.domain.model.*
import com.example.sdk.PaymentLifecycleState
import com.example.sdk.PaymentResult
import com.example.sdk.SimulatedTerminalClient
import com.example.sdk.TerminalEvent
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppNavigationTab(val title: String, val icon: String) {
    POS("POS Terminal", "PointOfSale"),
    OVERVIEW("Overview", "Dashboard"),
    PAYMENTS("Payments", "ReceiptLong"),
    TERMINALS("Fleet (1.2k)", "DevicesOther"),
    RECONCILIATION("Reconciliation", "AccountBalance"),
    DEVELOPERS("Developers", "Code")
}

data class PosUiState(
    val cart: Cart = Cart(),
    val customAmountInput: String = "",
    val selectedCategory: ProductCategory = ProductCategory.COFFEE,
    val selectedTestScenario: TestCardScenario = TestCardScenario.TEST_CARD_APPROVE,
    val isCustomAmountActive: Boolean = false,
    val isReceiptModalOpen: Boolean = false,
    val activeReceipt: Receipt? = null,
    val lastPaymentResult: PaymentResult? = null
)

class TerminalViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TerminalDatabase.getDatabase(application)
    val repository = TerminalRepository(db)
    val terminalSdk: SimulatedTerminalClient = SimulatedTerminalClient(repository)

    // Navigation State
    private val _selectedTab = MutableStateFlow(AppNavigationTab.POS)
    val selectedTab: StateFlow<AppNavigationTab> = _selectedTab.asStateFlow()

    // POS State
    private val _posState = MutableStateFlow(PosUiState())
    val posState: StateFlow<PosUiState> = _posState.asStateFlow()

    // Dashboard Filter States
    private val _selectedLocation = MutableStateFlow<MerchantLocation?>(null)
    val selectedLocation: StateFlow<MerchantLocation?> = _selectedLocation.asStateFlow()

    private val _paymentSearchQuery = MutableStateFlow("")
    val paymentSearchQuery: StateFlow<String> = _paymentSearchQuery.asStateFlow()

    private val _paymentStatusFilter = MutableStateFlow<String>("ALL")
    val paymentStatusFilter: StateFlow<String> = _paymentStatusFilter.asStateFlow()

    private val _terminalStatusFilter = MutableStateFlow<String>("ALL")
    val terminalStatusFilter: StateFlow<String> = _terminalStatusFilter.asStateFlow()

    private val _selectedPaymentDetail = MutableStateFlow<Transaction?>(null)
    val selectedPaymentDetail: StateFlow<Transaction?> = _selectedPaymentDetail.asStateFlow()

    // Repository Flows
    val products = repository.getProducts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val terminals = repository.getTerminals().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val readers = repository.getReaders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val transactions = repository.getTransactions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val refunds = repository.getRefunds().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val ledgerEntries = repository.getLedgerEntries().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val reconciliationItems = repository.getReconciliationItems().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val webhookEvents = repository.getWebhookEvents().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val apiLogs = repository.getApiLogs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val auditLogs = repository.getAuditLogs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // SDK State Flows
    val terminalState = terminalSdk.terminalState
    val readerState = terminalSdk.readerState
    val activeReader = terminalSdk.activeReader
    val paymentLifecycleState = terminalSdk.paymentState
    val terminalEvents = terminalSdk.events

    init {
        // Collect SDK events and update UI accordingly
        viewModelScope.launch {
            terminalEvents.collect { event ->
                when (event) {
                    is TerminalEvent.PaymentSucceeded -> {
                        _posState.update {
                            it.copy(
                                activeReceipt = event.receipt,
                                isReceiptModalOpen = true,
                                cart = Cart() // clear cart on success
                            )
                        }
                    }
                    else -> {}
                }
            }
        }
    }

    fun selectTab(tab: AppNavigationTab) {
        _selectedTab.value = tab
    }

    // POS Cart Operations
    fun addToCart(product: Product) {
        _posState.update { state ->
            val currentItems = state.cart.items.toMutableList()
            val existingIndex = currentItems.indexOfFirst { it.product.id == product.id }
            if (existingIndex >= 0) {
                val existing = currentItems[existingIndex]
                currentItems[existingIndex] = existing.copy(quantity = existing.quantity + 1)
            } else {
                currentItems.add(CartItem(product, quantity = 1))
            }
            state.copy(
                cart = state.cart.copy(items = currentItems),
                isCustomAmountActive = false
            )
        }
    }

    fun removeFromCart(productId: String) {
        _posState.update { state ->
            val currentItems = state.cart.items.toMutableList()
            val existingIndex = currentItems.indexOfFirst { it.product.id == productId }
            if (existingIndex >= 0) {
                val existing = currentItems[existingIndex]
                if (existing.quantity > 1) {
                    currentItems[existingIndex] = existing.copy(quantity = existing.quantity - 1)
                } else {
                    currentItems.removeAt(existingIndex)
                }
            }
            state.copy(cart = state.cart.copy(items = currentItems))
        }
    }

    fun clearCart() {
        _posState.update {
            it.copy(
                cart = Cart(),
                customAmountInput = "",
                isCustomAmountActive = false
            )
        }
    }

    fun selectCategory(category: ProductCategory) {
        _posState.update { it.copy(selectedCategory = category) }
    }

    fun setTestScenario(scenario: TestCardScenario) {
        _posState.update { it.copy(selectedTestScenario = scenario) }
    }

    fun appendCustomAmountDigit(digit: String) {
        _posState.update { state ->
            val newInput = if (state.customAmountInput.length < 6) state.customAmountInput + digit else state.customAmountInput
            state.copy(
                customAmountInput = newInput,
                isCustomAmountActive = true
            )
        }
    }

    fun deleteCustomAmountDigit() {
        _posState.update { state ->
            val newInput = state.customAmountInput.dropLast(1)
            state.copy(
                customAmountInput = newInput,
                isCustomAmountActive = newInput.isNotEmpty()
            )
        }
    }

    // Process Payment via Terminal SDK
    fun initiateTerminalPayment() {
        viewModelScope.launch {
            val state = _posState.value
            val amountMinor = if (state.isCustomAmountActive && state.customAmountInput.isNotEmpty()) {
                MoneyMinor(state.customAmountInput.toLong())
            } else {
                state.cart.totalAmount
            }

            if (amountMinor.value <= 0) return@launch

            val desc = if (state.cart.items.isNotEmpty()) {
                state.cart.items.joinToString(", ") { "${it.quantity}x ${it.product.name}" }
            } else {
                "Quick Sale Amount"
            }

            // 1. Create PaymentIntent
            val intentResult = terminalSdk.createPaymentIntent(
                amount = amountMinor,
                currency = Currency.GBP,
                description = desc,
                idempotencyKey = "pos_idemp_${System.currentTimeMillis()}"
            )

            intentResult.onSuccess { intent ->
                // 2. Process payment on reader with selected simulated scenario
                val result = terminalSdk.processPayment(
                    paymentIntent = intent,
                    scenario = state.selectedTestScenario,
                    cartItems = state.cart.items
                )
                _posState.update { it.copy(lastPaymentResult = result) }
            }
        }
    }

    fun cancelActivePayment() {
        viewModelScope.launch {
            terminalSdk.cancelPaymentCollection()
        }
    }

    fun dismissReceiptModal() {
        _posState.update { it.copy(isReceiptModalOpen = false) }
        terminalSdk.resetPaymentState()
    }

    // Dashboard Actions
    fun setPaymentSearchQuery(query: String) {
        _paymentSearchQuery.value = query
    }

    fun setPaymentStatusFilter(status: String) {
        _paymentStatusFilter.value = status
    }

    fun setTerminalStatusFilter(status: String) {
        _terminalStatusFilter.value = status
    }

    fun selectPaymentDetail(tx: Transaction?) {
        _selectedPaymentDetail.value = tx
    }

    fun issueRefund(paymentIntentId: PaymentIntentId, amount: MoneyMinor? = null) {
        viewModelScope.launch {
            terminalSdk.refundPayment(paymentIntentId, amount)
        }
    }

    fun resolveReconciliationDiscrepancy(itemId: String, note: String) {
        viewModelScope.launch {
            repository.resolveReconciliationItem(itemId, note)
        }
    }

    fun injectReconciliationCase(type: ReconciliationType) {
        viewModelScope.launch {
            repository.injectReconciliationDiscrepancy(type)
        }
    }

    fun rebootTerminal() {
        viewModelScope.launch {
            terminalSdk.rebootTerminal()
        }
    }

    fun switchReader(reader: Reader) {
        viewModelScope.launch {
            terminalSdk.connectReader(reader)
        }
    }

    fun testWebhookDispatch(eventType: WebhookEventType) {
        viewModelScope.launch {
            repository.recordWebhook(
                eventType = eventType,
                resourceId = "test_res_${System.currentTimeMillis().toString().takeLast(6)}",
                payloadJson = """{"event":"${eventType.eventName}","time":${System.currentTimeMillis()},"status":"simulated_delivery"}"""
            )
        }
    }
}
