package com.example.ui.screens.dashboard

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Terminal
import com.example.domain.model.TerminalStatus
import com.example.ui.components.StripeBadge
import com.example.ui.components.StripeButton
import com.example.ui.components.StripeCard
import com.example.ui.components.StripeStatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun TerminalsFleetScreen(viewModel: TerminalViewModel) {
    val context = LocalContext.current
    val terminals by viewModel.terminals.collectAsState()
    val statusFilter by viewModel.terminalStatusFilter.collectAsState()
    val activeReader by viewModel.activeReader.collectAsState()

    var selectedTerminalForDiagnostics by remember { mutableStateOf<Terminal?>(null) }

    val filteredTerminals = terminals.filter { t ->
        statusFilter == "ALL" || t.status.name.equals(statusFilter, ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StripeBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Fleet Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TERMINAL FLEET MANAGEMENT",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "1,284 Managed Fleet Devices",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeNavy
                    )
                }

                Button(
                    onClick = {
                        viewModel.rebootTerminal()
                        Toast.makeText(context, "Dispatched OTA reboot signal to active reader", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StripeBorderSubtle, contentColor = StripeNavy),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reboot All", fontSize = 11.sp)
                }
            }
        }

        // Fleet Summary 4-card Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StripeCard(modifier = Modifier.weight(1f), padding = PaddingValues(10.dp)) {
                    Text("ONLINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = StripeSuccessDark)
                    Text("1,201", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = StripeNavy)
                }
                StripeCard(modifier = Modifier.weight(1f), padding = PaddingValues(10.dp)) {
                    Text("OFFLINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = StripeDanger)
                    Text("57", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = StripeNavy)
                }
                StripeCard(modifier = Modifier.weight(1f), padding = PaddingValues(10.dp)) {
                    Text("UPDATING", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = StripeIndigo)
                    Text("18", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = StripeNavy)
                }
                StripeCard(modifier = Modifier.weight(1f), padding = PaddingValues(10.dp)) {
                    Text("MAINT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = StripeWarningDark)
                    Text("8", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = StripeNavy)
                }
            }
        }

        // Filter Pills
        item {
            val filterOptions = listOf("ALL", "READY", "OFFLINE", "UPDATING", "BUSY")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(filterOptions) { opt ->
                    val isSelected = opt == statusFilter
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) StripeIndigo else StripeSurface)
                            .border(1.dp, if (isSelected) StripeIndigo else StripeBorder, RoundedCornerShape(16.dp))
                            .clickable { viewModel.setTerminalStatusFilter(opt) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = opt,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isSelected) Color.White else StripeSlate
                        )
                    }
                }
            }
        }

        // Fleet Terminals List
        items(filteredTerminals) { term ->
            val isActive = term.deviceName.contains("Counter 01")

            StripeCard(
                borderColor = if (isActive) StripeIndigo else StripeBorder,
                padding = PaddingValues(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = term.deviceName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = StripeNavy
                            )
                            if (isActive) {
                                StripeBadge(text = "CURRENT POS", bgColor = StripeIndigoSubtle, textColor = StripeIndigo)
                            }
                        }
                        Text(
                            text = "${term.deviceType} • ${term.locationName} • ${term.serialNumber}",
                            fontSize = 11.sp,
                            color = StripeSubdued
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = "IP: ${term.ipAddress}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = StripeSlate
                            )
                            Text(
                                text = "Firmware: v${term.softwareVersion}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = StripeSlate
                            )
                            Text(
                                text = "Battery: ${term.health.batteryPercent}% ⚡",
                                fontSize = 10.sp,
                                color = StripeSuccessDark
                            )
                            Text(
                                text = "WiFi: ${term.health.wifiSignalDbm}dBm",
                                fontSize = 10.sp,
                                color = StripeSlate
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        StripeStatusPill(status = term.status.name)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                Toast.makeText(context, "Diagnostic ping sent to ${term.deviceName}: ${term.health.networkLatencyMs}ms", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = StripeBorderSubtle, contentColor = StripeNavy),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Diagnose", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
