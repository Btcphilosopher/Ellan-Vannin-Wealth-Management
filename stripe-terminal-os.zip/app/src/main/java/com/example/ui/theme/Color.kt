package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Stripe Core Brand Tokens
val StripeIndigo = Color(0xFF635BFF)
val StripeIndigoHover = Color(0xFF533AFD)
val StripeIndigoSubtle = Color(0xFFF2F1FF)
val StripeNavy = Color(0xFF0A2540)
val StripeSlate = Color(0xFF425466)
val StripeSubdued = Color(0xFF68778D)
val StripeBorder = Color(0xFFE3E8EE)
val StripeBorderSubtle = Color(0xFFEDF2F7)
val StripeBackground = Color(0xFFF8FAFC)
val StripeSurface = Color(0xFFFFFFFF)

// Accent and State Colors
val StripeSuccess = Color(0xFF00D4B2)
val StripeSuccessDark = Color(0xFF00875A)
val StripeSuccessBg = Color(0xFFE6F8F4)
val StripeWarning = Color(0xFFF59E0B)
val StripeWarningDark = Color(0xFFD97706)
val StripeWarningBg = Color(0xFFFFFBEB)
val StripeDanger = Color(0xFFDF1B41)
val StripeDangerBg = Color(0xFFFDE8EB)

// Reader OLED & Hardware Simulation Colors
val ReaderChassisDark = Color(0xFF1E232F)
val ReaderChassisBorder = Color(0xFF2C3446)
val ReaderScreenBg = Color(0xFF0F172A)
val ReaderScreenText = Color(0xFFF8FAFC)
val ReaderNfcGlow = Color(0xFF38BDF8)
val ReaderChipGold = Color(0xFFD97706)

// Dark Theme Variants
val StripeDarkBg = Color(0xFF0F1422)
val StripeDarkSurface = Color(0xFF181F33)
val StripeDarkBorder = Color(0xFF242E49)
val StripeDarkTextPrimary = Color(0xFFF8FAFC)
val StripeDarkTextSecondary = Color(0xFF94A3B8)
