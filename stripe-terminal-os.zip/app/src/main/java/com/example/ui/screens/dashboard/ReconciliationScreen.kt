package com.example.ui.screens.dashboard

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.model.ReconciliationItem
import com.example.domain.model.ReconciliationType
import com.example.domain.model.ResolutionStatus
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReconciliationScreen(viewModel: TerminalViewModel) {
    val context = LocalContext.current
    val items by viewModel.reconciliationItems.collectAsState()
    val ledgerEntries by viewModel.ledgerEntries.collectAsState()

    var activeResolutionItem by remember { mutableStateOf<ReconciliationItem?>(null) }
    var resolutionNote by remember { mutableStateOf("") }

    if (activeResolutionItem != null) {
        Dialog(onDismissRequest = { activeResolutionItem = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .clip(RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = StripeSurface)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "RESOLVE RECONCILIATION EXCEPTION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Discrepancy: ${activeResolutionItem!!.type.displayName}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeNavy
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Intent: ${activeResolutionItem!!.paymentIntentId} • POS: ${activeResolutionItem!!.posAmount.format(activeResolutionItem!!.currency)} vs Processor: ${activeResolutionItem!!.processorAmount.format(activeResolutionItem!!.currency)}",
                        fontSize = 12.sp,
                        color = StripeSlate
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Audit Resolution Note (Immutable Record):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = StripeNavy
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = resolutionNote,
                        onValueChange = { resolutionNote = it },
                        placeholder = { Text("e.g. Verified with bank clearing logs; auto-reversal applied.") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { activeResolutionItem = null },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Cancel")
                        }

                        Button(
                            onClick = {
                                viewModel.resolveReconciliationDiscrepancy(
                                    activeResolutionItem!!.id,
                                    if (resolutionNote.isNotEmpty()) resolutionNote else "Resolved with settlement ledger adjustment."
                                )
                                Toast.makeText(context, "Exception resolved & audit ledger updated.", Toast.LENGTH_SHORT).show()
                                activeResolutionItem = null
                                resolutionNote = ""
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("confirm_resolution_btn"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = StripeIndigo)
                        ) {
                            Text("Confirm & Audit")
                        }
                    }
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StripeBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "RECONCILIATION & DOUBLE-ENTRY LEDGER",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeSubdued,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Automated Settlement Reconciliation",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = StripeNavy
                    )
                }
            }
        }

        // Test Anomaly Injector Bar
        item {
            StripeCard(backgroundColor = Color(0xFFF1F5F9)) {
                Text(
                    text = "SIMULATE DISCREPANCY SCENARIOS (SIGNATURE DEMO)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StripeSubdued,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.injectReconciliationCase(ReconciliationType.DUPLICATE)
                            Toast.makeText(context, "Injected Duplicate Settlement Discrepancy", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StripeSurface, contentColor = StripeDanger),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StripeBorder),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("+ Duplicate", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            viewModel.injectReconciliationCase(ReconciliationType.MISSING_RECORD)
                            Toast.makeText(context, "Injected Missing Processor Record", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StripeSurface, contentColor = StripeWarningDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StripeBorder),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("+ Missing", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            viewModel.injectReconciliationCase(ReconciliationType.AMOUNT_MISMATCH)
                            Toast.makeText(context, "Injected Amount Mismatch Variance", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StripeSurface, contentColor = StripeIndigo),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StripeBorder),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text("+ Mismatch", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Active Exceptions List
        item {
            val unresolvedCount = items.count { it.status == ResolutionStatus.UNRESOLVED }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE EXCEPTIONS ($unresolvedCount)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StripeSubdued,
                    letterSpacing = 0.5.sp
                )
            }
        }

        items(items) { item ->
            val formattedDate = remember(item.timestamp) {
                SimpleDateFormat("dd MMM, HH:mm", Locale.UK).format(Date(item.timestamp))
            }

            StripeCard(
                borderColor = if (item.status == ResolutionStatus.UNRESOLVED) StripeDanger.copy(alpha = 0.5f) else StripeBorder,
                padding = PaddingValues(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = item.type.displayName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (item.status == ResolutionStatus.UNRESOLVED) StripeDanger else StripeNavy
                            )
                            StripeBadge(
                                text = item.status.name,
                                bgColor = if (item.status == ResolutionStatus.RESOLVED) StripeSuccessBg else StripeDangerBg,
                                textColor = if (item.status == ResolutionStatus.RESOLVED) StripeSuccessDark else StripeDanger
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.description,
                            fontSize = 12.sp,
                            color = StripeNavy
                        )
                        Text(
                            text = "POS: ${item.posAmount.format(item.currency)} • Processor: ${item.processorAmount.format(item.currency)} • ${item.locationName} (${item.terminalName})",
                            fontSize = 11.sp,
                            color = StripeSlate
                        )

                        if (item.auditNote != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF8FAFC))
                                    .padding(6.dp)
                            ) {
                                Text(
                                    text = "Audit Note: ${item.auditNote} (${item.resolvedBy ?: "Finance"})",
                                    fontSize = 11.sp,
                                    color = StripeSuccessDark,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    if (item.status == ResolutionStatus.UNRESOLVED) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { activeResolutionItem = item },
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = StripeIndigo),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("resolve_exception_btn")
                        ) {
                            Text("Resolve", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Ledger Accounts & Double-entry Table
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "IMMUTABLE LEDGER ENTRIES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StripeSubdued,
                letterSpacing = 0.5.sp
            )
        }

        items(ledgerEntries) { entry ->
            val formattedDate = remember(entry.timestamp) {
                SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date(entry.timestamp))
            }

            StripeCard(padding = PaddingValues(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = entry.description,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = StripeNavy
                        )
                        Text(
                            text = "${entry.account} ⇄ ${entry.contraAccount} • $formattedDate",
                            fontSize = 10.sp,
                            color = StripeSubdued
                        )
                    }

                    Text(
                        text = "${if (entry.isDebit) "-" else "+"}${entry.amount.format(entry.currency)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (entry.isDebit) StripeDanger else StripeSuccessDark
                    )
                }
            }
        }
    }
}
