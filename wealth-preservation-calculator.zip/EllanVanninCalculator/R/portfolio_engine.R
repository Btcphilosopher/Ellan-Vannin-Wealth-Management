# ==============================================================================
# Ellan Vannin Wealth Management - Portfolio Engine
# Purpose: Manage asset allocation models and calculate portfolio metrics.
# ==============================================================================

#' Retrieve Predefined Institutional Scenarios
#' @return A named list of asset allocation weight lists.
get_portfolio_scenarios <- function() {
  list(
    conservative = list(
      stocks = 0.20, bonds = 0.50, cash = 0.15, gold = 0.10, property = 0.05, pe = 0.00, bitcoin = 0.00, crypto = 0.00
    ),
    balanced = list(
      stocks = 0.45, bonds = 0.30, cash = 0.05, gold = 0.08, property = 0.10, pe = 0.02, bitcoin = 0.00, crypto = 0.00
    ),
    growth = list(
      stocks = 0.65, bonds = 0.15, cash = 0.02, gold = 0.05, property = 0.08, pe = 0.05, bitcoin = 0.00, crypto = 0.00
    ),
    aggressive = list(
      stocks = 0.75, bonds = 0.05, cash = 0.02, gold = 0.03, property = 0.05, pe = 0.08, bitcoin = 0.02, crypto = 0.00
    ),
    bitcoin_heavy = list(
      stocks = 0.40, bonds = 0.05, cash = 0.03, gold = 0.05, property = 0.07, pe = 0.05, bitcoin = 0.30, crypto = 0.05
    ),
    property_heavy = list(
      stocks = 0.15, bonds = 0.10, cash = 0.05, gold = 0.05, property = 0.60, pe = 0.05, bitcoin = 0.00, crypto = 0.00
    ),
    family_office = list(
      stocks = 0.30, bonds = 0.10, cash = 0.05, gold = 0.12, property = 0.15, pe = 0.20, bitcoin = 0.05, crypto = 0.03
    ),
    institutional = list(
      stocks = 0.35, bonds = 0.25, cash = 0.02, gold = 0.10, property = 0.10, pe = 0.15, bitcoin = 0.02, crypto = 0.01
    )
  )
}

#' Calculate Portfolio Expected Return and Volatility
#' @param weights List of numeric. Asset weights summing to 1.0.
#' @param asset_returns List of numeric. Expected returns for each asset.
#' @param asset_vols List of numeric. Expected volatilities for each asset.
#' @return A list with expected portfolio return and portfolio volatility.
calculate_portfolio_metrics <- function(weights, asset_returns, asset_vols) {
  # Normalize weights if they don't sum to 1
  w <- unlist(weights)
  w_sum <- sum(w)
  if (w_sum > 0) w <- w / w_sum
  
  r <- unlist(asset_returns)
  v <- unlist(asset_vols)
  
  # Align keys
  keys <- intersect(names(w), names(r))
  w <- w[keys]
  r <- r[keys]
  v <- v[keys]
  
  # 1. Expected Return (Weighted Linear Average)
  portfolio_return <- sum(w * r)
  
  # 2. Portfolio Volatility (Matrix Algebra: w^T * Sigma * w)
  # Standard asset correlation matrix (illustrative institutional assumptions)
  assets_list <- c("stocks", "bonds", "cash", "gold", "property", "pe", "bitcoin", "crypto")
  n <- length(assets_list)
  cor_matrix <- matrix(c(
    1.00,  0.10, -0.05,  0.05,  0.30,  0.60,  0.15,  0.18, # stocks
    0.10,  1.00,  0.20,  0.15,  0.05, -0.10, -0.05, -0.08, # bonds
   -0.05,  0.20,  1.00,  0.02, -0.01, -0.15, -0.12, -0.15, # cash
    0.05,  0.15,  0.02,  1.00,  0.08, -0.05,  0.10,  0.05, # gold
    0.30,  0.05, -0.01,  0.08,  1.00,  0.25,  0.02,  0.01, # property
    0.60, -0.10, -0.15, -0.05,  0.25,  1.00,  0.12,  0.15, # pe
    0.15, -0.05, -0.12,  0.10,  0.02,  0.12,  1.00,  0.65, # bitcoin
    0.18, -0.08, -0.15,  0.05,  0.01,  0.15,  0.65,  1.00  # crypto
  ), nrow = n, byrow = TRUE, dimnames = list(assets_list, assets_list))
  
  # Construct Covariance Matrix: Sigma = D * R * D
  # where D is diagonal matrix of volatilities
  v_full <- setNames(rep(0.05, n), assets_list)
  for (nm in names(v)) {
    if (nm %in% names(v_full)) v_full[nm] <- v[nm]
  }
  
  # Set missing weights to 0
  w_full <- setNames(rep(0, n), assets_list)
  for (nm in names(w)) {
    if (nm %in% names(w_full)) w_full[nm] <- w[nm]
  }
  
  # Calculate portfolio variance
  D <- diag(v_full)
  Sigma <- D %*% cor_matrix %*% D
  portfolio_variance <- t(w_full) %*% Sigma %*% w_full
  portfolio_volatility <- sqrt(as.numeric(portfolio_variance))
  
  list(
    expected_return = portfolio_return,
    volatility = portfolio_volatility
  )
}
