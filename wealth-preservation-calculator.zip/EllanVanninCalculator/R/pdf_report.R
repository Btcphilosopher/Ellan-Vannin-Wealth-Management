# ==============================================================================
# Ellan Vannin Wealth Management - PDF Report Generator
# Purpose: Compiles high-quality client wealth preservation reports via Rmd.
# ==============================================================================

#' Generate Professional PDF/HTML Advisory Report
#' @param client_data List containing personal_info, tax_summary, growth_data, portfolio_data.
#' @param output_filepath Character. Path where the compiled report should be written.
#' @param format Character. Either "pdf" or "html" (fallback).
#' @return The path of the generated report.
generate_advisory_report <- function(client_data, output_filepath, format = "html") {
  # Establish raw Rmd content dynamically to ensure self-containment
  rmd_content <- '---
title: "WEALTH PRESERVATION ADVISORY REPORT"
subtitle: "Ellan Vannin Wealth Management"
author: "Sovereign & Private Client Services"
date: "`r format(Sys.time(), \'%B %d, %Y\')`"
output:
  html_document:
    theme: cosmo
    toc: false
    highlight: tango
  pdf_document:
    toc: false
    latex_engine: xelatex
---

```{r setup, include=FALSE}
knitr::opts_chunk$set(echo = FALSE, warning = FALSE, message = FALSE)
library(scales)
library(knitr)
```

## Executive Summary

Prepared for: **`r client_data$personal_info$name %||% "Valued Client"`**  
Current Residence: **`r client_data$personal_info$residence %||% "Isle of Man"`**  
Tax Jurisdiction: **`r client_data$personal_info$tax_residence %||% "Isle of Man"`**  
Risk Profile: **`r client_data$personal_info$risk_profile %||% "Balanced"`**  

***

### 1. Key Performance Indicators

- **Total Current Net Worth:** `r dollar(client_data$financials$total_net_worth %||% 2500000, prefix = "£")`
- **Estimated Annual Tax Drag (Current):** `r dollar(client_data$financials$annual_tax %||% 12500, prefix = "£")`
- **Effective Annual Tax Rate:** `r percent(client_data$financials$effective_rate %||% 0.05)`
- **Projected 30-Year Wealth (Nominal):** `r dollar(client_data$financials$projected_terminal %||% 7200000, prefix = "£")`
- **Preserved Capital (Tax-Structured Advantage):** `r dollar(client_data$financials$preserved_wealth %||% 480000, prefix = "£")`

***

### 2. Asset Allocation Breakdown

Below is the structured division of capital aligned with your private banking profile:

```{r asset_table}
asset_df <- data.frame(
  Asset_Class = c("Stocks", "Bonds", "Cash", "Gold", "Property", "Pensions", "Bitcoin"),
  Value = c(
    client_data$assets$stocks %||% 1000000,
    client_data$assets$bonds %||% 500000,
    client_data$assets$cash %||% 200000,
    client_data$assets$gold %||% 100000,
    client_data$assets$property %||% 500000,
    client_data$assets$pensions %||% 150000,
    client_data$assets$bitcoin %||% 50000
  )
)
asset_df$Weight <- asset_df$Value / sum(asset_df$Value)
asset_df$Value_Formatted <- dollar(asset_df$Value, prefix = "£")
asset_df$Weight_Formatted <- percent(asset_df$Weight)

kable(asset_df[, c("Asset_Class", "Value_Formatted", "Weight_Formatted")], 
      col.names = c("Asset Class", "Current Allocation", "Portfolio Weight"), 
      align = "lrr")
```

***

### 3. Decadal Wealth Projections (Real vs. Nominal)

A multi-decade simulation showing compound growth adjusted for an illustrative inflation rate of **`r percent(client_data$general$inflation %||% 0.025)`**:

```{r projection_table}
proj_df <- data.frame(
  Year = c(5, 10, 20, 30, 40),
  Nominal = c(
    client_data$projection$y5_nom %||% 3100000,
    client_data$projection$y10_nom %||% 3850000,
    client_data$projection$y20_nom %||% 5400000,
    client_data$projection$y30_nom %||% 7200000,
    client_data$projection$y40_nom %||% 9800000
  ),
  Real = c(
    client_data$projection$y5_real %||% 2750000,
    client_data$projection$y10_real %||% 3000000,
    client_data$projection$y20_real %||% 3300000,
    client_data$projection$y30_real %||% 3400000,
    client_data$projection$y40_real %||% 3650000
  )
)
proj_df$Nominal_Formatted <- dollar(proj_df$Nominal, prefix = "£")
proj_df$Real_Formatted <- dollar(proj_df$Real, prefix = "£")

kable(proj_df[, c("Year", "Nominal_Formatted", "Real_Formatted")], 
      col.names = c("Projection Horizon (Years)", "Projected Capital (Nominal)", "Projected Capital (Real)"), 
      align = "crr")
```

***

### 4. Professional Disclosure & Disclaimer

**This calculator is provided for illustrative purposes only and does not constitute tax, legal or investment advice. Tax outcomes depend upon personal circumstances and applicable law.**

Ellan Vannin Wealth Management is a premier offshore private wealth management practice. Past performance is no guarantee of future returns. Investments can fluctuate in value and you may receive back less than initially committed.

***
*Report generated securely on behalf of Ellan Vannin Sovereign & Private Client Portals.*
'

  # Write Rmd content to temporary file
  temp_rmd_path <- tempfile(fileext = ".Rmd")
  writeLines(rmd_content, temp_rmd_path)
  
  # Determine output format and render
  output_format <- if (format == "pdf") "pdf_document" else "html_document"
  
  # Safeguard compiling: If PDF fails (due to missing xelatex), fallback to HTML
  result <- tryCatch({
    rmarkdown::render(
      input = temp_rmd_path,
      output_format = output_format,
      output_file = output_filepath,
      quiet = TRUE
    )
    output_filepath
  }, error = function(e) {
    # Fallback to HTML
    if (format == "pdf") {
      message("LaTeX rendering failed; compiling to HTML format instead.")
      rmarkdown::render(
        input = temp_rmd_path,
        output_format = "html_document",
        output_file = gsub("\\.pdf$", ".html", output_filepath),
        quiet = TRUE
      )
    } else {
      stop(e)
    }
  })
  
  return(result)
}

# Helper definition if missing
`%%||%` <- function(a, b) if (!is.null(a)) a else b
