# ==============================================================================
# Ellan Vannin Wealth Management - Tax Engine
# Purpose: Abstract tax calculation framework with configurable parameters.
# This code is for illustrative purposes and does not constitute tax advice.
# ==============================================================================

#' Create a Default Tax Configuration Object
#' @param personal_allowance Income that is tax-free.
#' @param income_tax_rate Standard rate for income tax.
#' @param higher_income_tax_rate Rate for income exceeding threshold.
#' @param higher_income_threshold Income threshold for higher rate.
#' @param capital_gains_rate Tax rate on capital gains.
#' @param capital_gains_allowance Tax-free capital gains allowance.
#' @param dividend_rate Tax rate on dividend distributions.
#' @param corporation_tax_rate Business profits tax rate.
#' @param wealth_tax_rate Wealth tax rate on net assets (illustrative).
#' @param wealth_tax_threshold Asset threshold before wealth tax applies.
#' @return A list containing the tax configuration parameters.
create_tax_config <- function(personal_allowance = 14500,
                              income_tax_rate = 0.10,
                              higher_income_tax_rate = 0.20,
                              higher_income_threshold = 20000,
                              capital_gains_rate = 0.00,
                              capital_gains_allowance = 10000,
                              dividend_rate = 0.00,
                              corporation_tax_rate = 0.00,
                              wealth_tax_rate = 0.00,
                              wealth_tax_threshold = 1000000) {
  list(
    personal_allowance = personal_allowance,
    income_tax_rate = income_tax_rate,
    higher_income_tax_rate = higher_income_tax_rate,
    higher_income_threshold = higher_income_threshold,
    capital_gains_rate = capital_gains_rate,
    capital_gains_allowance = capital_gains_allowance,
    dividend_rate = dividend_rate,
    corporation_tax_rate = corporation_tax_rate,
    wealth_tax_rate = wealth_tax_rate,
    wealth_tax_threshold = wealth_tax_threshold
  )
}

#' Calculate Income Tax
#' @param income Numeric. Annual salary/earnings.
#' @param config List. Tax configuration parameters.
#' @return A list containing gross income, allowance, taxable income, tax paid, and net income.
calculate_income_tax <- function(income, config) {
  if (is.null(income) || is.na(income)) income <- 0
  
  allowance <- min(income, config$personal_allowance)
  taxable_income <- max(0, income - allowance)
  
  tax_paid <- 0
  
  # Multi-band calculation
  if (taxable_income > 0) {
    if (taxable_income <= config$higher_income_threshold) {
      tax_paid <- taxable_income * config$income_tax_rate
    } else {
      # First band
      tax_paid <- config$higher_income_threshold * config$income_tax_rate
      # Second band
      excess <- taxable_income - config$higher_income_threshold
      tax_paid <- tax_paid + (excess * config$higher_income_higher_rate %||% config$higher_income_tax_rate)
    }
  }
  
  net_income <- income - tax_paid
  effective_rate <- if (income > 0) tax_paid / income else 0
  
  list(
    gross_income = income,
    allowance = allowance,
    taxable_income = taxable_income,
    tax_paid = tax_paid,
    net_income = net_income,
    effective_rate = effective_rate
  )
}

#' Calculate Dividend Tax
#' @param dividends Numeric. Dividend income.
#' @param config List. Tax configuration parameters.
#' @return A list with gross dividend, tax paid, and net dividend.
calculate_dividend_tax <- function(dividends, config) {
  if (is.null(dividends) || is.na(dividends)) dividends <- 0
  tax_paid <- dividends * config$dividend_rate
  list(
    gross = dividends,
    tax_paid = tax_paid,
    net = dividends - tax_paid
  )
}

#' Calculate Capital Gains Tax
#' @param gains Numeric. Realized capital gains.
#' @param config List. Tax configuration parameters.
#' @return A list with gross gains, tax paid, and net gains.
calculate_cgt <- function(gains, config) {
  if (is.null(gains) || is.na(gains)) gains <- 0
  taxable_gains <- max(0, gains - config$capital_gains_allowance)
  tax_paid <- taxable_gains * config$capital_gains_rate
  list(
    gross = gains,
    taxable = taxable_gains,
    tax_paid = tax_paid,
    net = gains - tax_paid
  )
}

#' Calculate Corporation Tax
#' @param profit Numeric. Annual corporate profits.
#' @param config List. Tax configuration parameters.
#' @return A list with gross profit, tax paid, and net corporate profit.
calculate_corp_tax <- function(profit, config) {
  if (is.null(profit) || is.na(profit)) profit <- 0
  tax_paid <- profit * config$corporation_tax_rate
  list(
    gross = profit,
    tax_paid = tax_paid,
    net = profit - tax_paid
  )
}

#' Calculate Annual Wealth Tax
#' @param net_worth Numeric. Client's overall net assets.
#' @param config List. Tax configuration parameters.
#' @return Numeric. Estimated annual wealth tax.
calculate_wealth_tax <- function(net_worth, config) {
  if (is.null(net_worth) || is.na(net_worth)) return(0)
  if (net_worth <= config$wealth_tax_threshold) return(0)
  
  taxable_wealth <- net_worth - config$wealth_tax_threshold
  taxable_wealth * config$wealth_tax_rate
}

# Helper operator
`%||%` <- function(a, b) if (!is.null(a)) a else b
