# ==============================================================================
# Ellan Vannin Wealth Management - Growth Model Engine
# Purpose: Compounding, annual contributions, asset class growth, and tax drag.
# ==============================================================================

#' Run a Deterministic Wealth Projection
#' @param initial_assets List. Starting values of each asset class (stocks, bonds, cash, gold, property, pensions, bitcoin).
#' @param annual_contributions List. Additions made to each asset class each year.
#' @param asset_returns List. CAGR for each asset class.
#' @param tax_config List. Tax parameters from tax_engine.R.
#' @param general_inputs List. General parameters: inflation, horizon, tax_regime ("standard", "preservation", "zero_tax").
#' @return A data frame containing annual wealth progression details.
project_wealth <- function(initial_assets,
                           annual_contributions,
                           asset_returns,
                           tax_config,
                           general_inputs) {
  
  years <- general_inputs$horizon %||% 40
  inflation_rate <- general_inputs$inflation_rate %||% 0.025
  
  # Initialize tracking matrices/vectors
  nw_nominal <- numeric(years + 1)
  nw_real <- numeric(years + 1)
  cumulative_tax <- numeric(years + 1)
  cumulative_contributions <- numeric(years + 1)
  
  # Current balances for iteration
  balances <- list(
    stocks = initial_assets$stocks %||% 0,
    bonds = initial_assets$bonds %||% 0,
    cash = initial_assets$cash %||% 0,
    gold = initial_assets$gold %||% 0,
    property = initial_assets$property %||% 0,
    pensions = initial_assets$pensions %||% 0,
    bitcoin = initial_assets$bitcoin %||% 0
  )
  
  # Set year 0 values
  total_initial <- sum(unlist(balances))
  nw_nominal[1] <- total_initial
  nw_real[1] <- total_initial
  cumulative_tax[1] <- 0
  cumulative_contributions[1] <- 0
  
  # Accumulators
  total_tax_paid <- 0
  total_saved <- 0
  
  df_list <- list()
  df_list[[1]] <- data.frame(
    Year = 0,
    Stocks = balances$stocks,
    Bonds = balances$bonds,
    Cash = balances$cash,
    Gold = balances$gold,
    Property = balances$property,
    Pensions = balances$pensions,
    Bitcoin = balances$bitcoin,
    Total_Nominal = total_initial,
    Total_Real = total_initial,
    Annual_Tax = 0,
    Cumulative_Tax = 0,
    Cumulative_Contributions = 0,
    stringsAsFactors = FALSE
  )
  
  for (t in 1:years) {
    # 1. Apply capital growth & dividends before tax drag
    g_stocks   <- balances$stocks * (asset_returns$stocks %||% 0.07)
    g_bonds    <- balances$bonds * (asset_returns$bonds %||% 0.03)
    g_cash     <- balances$cash * (asset_returns$cash %||% 0.02)
    g_gold     <- balances$gold * (asset_returns$gold %||% 0.04)
    g_property <- balances$property * (asset_returns$property %||% 0.05)
    g_pensions <- balances$pensions * (asset_returns$pensions %||% 0.06)
    g_bitcoin  <- balances$bitcoin * (asset_returns$bitcoin %||% 0.15)
    
    # 2. Add annual contributions
    balances$stocks   <- balances$stocks + g_stocks + (annual_contributions$stocks %||% 0)
    balances$bonds    <- balances$bonds + g_bonds + (annual_contributions$bonds %||% 0)
    balances$cash     <- balances$cash + g_cash + (annual_contributions$cash %||% 0)
    balances$gold     <- balances$gold + g_gold + (annual_contributions$gold %||% 0)
    balances$property <- balances$property + g_property # property contributions handled through mortgage/rental reinvestment
    balances$pensions <- balances$pensions + g_pensions + (annual_contributions$pensions %||% 0)
    balances$bitcoin  <- balances$bitcoin + g_bitcoin + (annual_contributions$bitcoin %||% 0)
    
    # Track contributions added this year
    annual_contrib_sum <- (annual_contributions$stocks %||% 0) +
                          (annual_contributions$bonds %||% 0) +
                          (annual_contributions$cash %||% 0) +
                          (annual_contributions$gold %||% 0) +
                          (annual_contributions$pensions %||% 0) +
                          (annual_contributions$bitcoin %||% 0)
    total_saved <- total_saved + annual_contrib_sum
    
    # 3. Apply Tax Drag (Dividends, Wealth Tax, Capital Gains Drag)
    # Estimate annual dividends on stocks (e.g., 2% dividend yield)
    div_yield <- 0.02
    est_dividends <- balances$stocks * div_yield
    div_tax <- est_dividends * tax_config$dividend_rate
    
    # Estimate realized gains (assuming 10% of equity portfolio is turned over and taxed)
    cgt_realized_rate <- 0.10
    est_cgt <- max(0, (balances$stocks * cgt_realized_rate) * tax_config$capital_gains_rate)
    
    # Wealth tax drag (overall net worth)
    current_net_assets <- sum(unlist(balances))
    wealth_tax_paid <- 0
    if (current_net_assets > tax_config$wealth_tax_threshold) {
      wealth_tax_paid <- (current_net_assets - tax_config$wealth_tax_threshold) * tax_config$wealth_tax_rate
    }
    
    # Apply tax deductions from balances
    total_annual_tax <- div_tax + est_cgt + wealth_tax_paid
    total_tax_paid <- total_tax_paid + total_annual_tax
    
    # Deduct tax from cash or stock balances
    if (balances$cash >= total_annual_tax) {
      balances$cash <- balances$cash - total_annual_tax
    } else {
      overflow <- total_annual_tax - balances$cash
      balances$cash <- 0
      balances$stocks <- max(0, balances$stocks - overflow)
    }
    
    # Recompute total net assets after tax
    net_nominal <- sum(unlist(balances))
    
    # 4. Inflation Adjustment (Real value discounting)
    discount_factor <- (1 + inflation_rate)^t
    net_real <- net_nominal / discount_factor
    
    df_list[[t + 1]] <- data.frame(
      Year = t,
      Stocks = balances$stocks,
      Bonds = balances$bonds,
      Cash = balances$cash,
      Gold = balances$gold,
      Property = balances$property,
      Pensions = balances$pensions,
      Bitcoin = balances$bitcoin,
      Total_Nominal = net_nominal,
      Total_Real = net_real,
      Annual_Tax = total_annual_tax,
      Cumulative_Tax = total_tax_paid,
      Cumulative_Contributions = total_saved,
      stringsAsFactors = FALSE
    )
  }
  
  do.call(rbind, df_list)
}

#' Extract Specific Interval Outcomes for Client Presentation
#' @param projection_df Dataframe. Result of project_wealth.
#' @return A structured dataframe of milestone years (5, 10, 20, 30, 40).
get_milestone_outcomes <- function(projection_df) {
  milestones <- c(5, 10, 20, 30, 40)
  milestones <- milestones[milestones <= max(projection_df$Year)]
  
  result <- projection_df[projection_df$Year %in% milestones, ]
  rownames(result) <- NULL
  result
}
