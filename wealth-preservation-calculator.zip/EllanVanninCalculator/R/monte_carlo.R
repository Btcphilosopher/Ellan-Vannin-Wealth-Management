# ==============================================================================
# Ellan Vannin Wealth Management - Monte Carlo Engine
# Purpose: Stochastic simulation for long-term wealth preservation.
# ==============================================================================

#' Run Stochastic Portfolio Projections
#' @param initial_wealth Numeric. Total starting assets.
#' @param annual_savings Numeric. Annual savings added.
#' @param expected_return Numeric. Mean nominal return (e.g., 0.06).
#' @param volatility Numeric. Standard deviation of portfolio returns (e.g., 0.12).
#' @param inflation_rate Numeric. Core inflation rate (e.g., 0.02).
#' @param tax_drag_rate Numeric. Estimated overall tax drag rate (e.g., 0.015).
#' @param horizon Numeric. Number of projection years (e.g., 30).
#' @param n_sims Numeric. Number of simulation paths (default: 10,000).
#' @return A list containing simulation details, percentiles, and success probability.
run_monte_carlo <- function(initial_wealth,
                            annual_savings = 50000,
                            expected_return = 0.07,
                            volatility = 0.12,
                            inflation_rate = 0.025,
                            tax_drag_rate = 0.01,
                            horizon = 30,
                            n_sims = 10000) {
  
  # Set seed for reproducible results
  set.seed(42)
  
  # Effective net return mean and standard deviation
  # We use log-normal returns
  mu <- expected_return - tax_drag_rate
  sigma <- volatility
  
  # Initialize results matrix: Rows = Years, Columns = Simulations
  paths <- matrix(0, nrow = horizon + 1, ncol = n_sims)
  paths[1, ] <- initial_wealth
  
  # Core simulation loop
  # Vectorized for extreme performance in R
  for (t in 1:horizon) {
    # Generate random returns for all simulations for year t
    # Using geometric Brownian motion or lognormal return steps
    shocks <- rnorm(n_sims, mean = mu - 0.5 * sigma^2, sd = sigma)
    returns <- exp(shocks)
    
    # Next year wealth = (Current Wealth * Return) + Savings
    # Savings are added at the end of the year, also adjusted for inflation
    inflated_savings <- annual_savings * (1 + inflation_rate)^t
    paths[t + 1, ] <- paths[t, ] * returns + inflated_savings
  }
  
  # Inflation adjust the paths (convert nominal to real values)
  paths_real <- paths
  for (t in 0:horizon) {
    paths_real[t + 1, ] <- paths[t + 1, ] / (1 + inflation_rate)^t
  }
  
  # Calculate summary percentiles over time (nominal and real)
  years <- 0:horizon
  
  percentiles_nominal <- apply(paths, 1, function(x) {
    quantile(x, probs = c(0.10, 0.25, 0.50, 0.75, 0.90))
  })
  # Transpose to have years as rows, quantiles as columns
  pct_nom_df <- as.data.frame(t(percentiles_nominal))
  colnames(pct_nom_df) <- c("P10", "P25", "P50", "P75", "P90")
  pct_nom_df$Year <- years
  
  percentiles_real <- apply(paths_real, 1, function(x) {
    quantile(x, probs = c(0.10, 0.25, 0.50, 0.75, 0.90))
  })
  pct_real_df <- as.data.frame(t(percentiles_real))
  colnames(pct_real_df) <- c("P10", "P25", "P50", "P75", "P90")
  pct_real_df$Year <- years
  
  # Calculate probability of capital preservation
  # Success is defined as terminal real wealth being greater than initial wealth
  terminal_real_wealth <- paths_real[horizon + 1, ]
  success_count <- sum(terminal_real_wealth >= initial_wealth)
  prob_success <- success_count / n_sims
  
  list(
    raw_paths_nominal = paths,
    raw_paths_real = paths_real,
    percentiles_nominal = pct_nom_df,
    percentiles_real = pct_real_df,
    prob_preservation = prob_success,
    median_terminal_wealth_real = pct_real_df$P50[horizon + 1],
    p10_terminal_wealth_real = pct_real_df$P10[horizon + 1],
    p90_terminal_wealth_real = pct_real_df$P90[horizon + 1]
  )
}
