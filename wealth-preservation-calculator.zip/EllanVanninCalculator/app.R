# ==============================================================================
# Ellan Vannin Wealth Management - Wealth Preservation Calculator
# Purpose: Master R Shiny Application Entry Point (app.R)
# ==============================================================================

library(shiny)
library(shinydashboard)
library(plotly)
library(DT)
library(ggplot2)
library(bslib)
library(dplyr)
library(tidyr)
library(scales)
library(lubridate)
library(rmarkdown)

# Source all modular sub-engines
source("R/tax_engine.R")
source("R/growth_model.R")
source("R/monte_carlo.R")
source("R/portfolio_engine.R")
source("R/pdf_report.R")

# Define regulatory disclaimer
DISCLAIMER_TEXT <- "This calculator is provided for illustrative purposes only and does not constitute tax, legal or investment advice. Tax outcomes depend upon personal circumstances and applicable law."

# ==============================================================================
# USER INTERFACE (UI)
# ==============================================================================
ui <- dashboardPage(
  title = "Ellan Vannin - Wealth Preservation Calculator",
  skin = "blue",
  
  header = dashboardHeader(
    title = span(tags$img(src = "logo.png", height = "30px", style = "margin-right: 10px;"), "Ellan Vannin WM"),
    titleWidth = 280
  ),
  
  sidebar = dashboardSidebar(
    width = 280,
    sidebarMenu(
      id = "sidebar_tabs",
      menuItem("Home / Welcome", tabName = "home", icon = icon("home")),
      menuItem("Executive Dashboard", tabName = "dashboard", icon = icon("dashboard")),
      
      menuItem("Capital Profiles", icon = icon("user-tie"), startExpanded = TRUE,
               menuSubItem("Personal Profile", tabName = "personal_profile"),
               menuSubItem("Employment Income", tabName = "income"),
               menuSubItem("Corporate & Business", tabName = "business"),
               menuSubItem("Investments & Liquidity", tabName = "investments"),
               menuSubItem("Real Estate Assets", tabName = "property"),
               menuSubItem("Pensions & Trusts", tabName = "pensions"),
               menuSubItem("Digital Assets (Bitcoin)", tabName = "bitcoin")
      ),
      
      menuItem("Analysis Modules", icon = icon("chart-line"), startExpanded = TRUE,
               menuSubItem("Tax Comparison Engine", tabName = "tax_comparison"),
               menuSubItem("Future Wealth Modeler", tabName = "future_wealth"),
               menuSubItem("Monte Carlo Simulator", tabName = "monte_carlo"),
               menuSubItem("Scenario Comparison", tabName = "scenario_analysis")
      ),
      
      menuItem("Client Advisory Report", tabName = "pdf_report", icon = icon("file-pdf")),
      menuItem("Institutional About", tabName = "about", icon = icon("info-circle"))
    ),
    
    # Quick controls in sidebar
    tags$div(
      style = "padding: 15px; text-align: center; border-top: 1px solid rgba(255,255,255,0.05); margin-top: 20px;",
      actionButton("reset_calc", "Reset Calculator", icon = icon("redo"), class = "btn-warning btn-xs", style = "width: 100%; margin-bottom: 10px;"),
      actionButton("save_scenario_btn", "Save Current State", icon = icon("save"), class = "btn-success btn-xs", style = "width: 100%;"),
      tags$div(
        style = "margin-top: 15px; color: #A3B8CC; font-size: 11px;",
        "Theme: Private Client Portal v3.4"
      )
    )
  ),
  
  body = dashboardBody(
    # Load custom external styles & fonts
    tags$head(
      tags$link(rel = "stylesheet", type = "text/css", href = "style.css"),
      tags$style(HTML("
        .content-wrapper, .right-side { background-color: #F8F9FA; }
        .box { border-top: 3px solid #0F1E36 !important; }
      "))
    ),
    
    tabItems(
      
      # ------------------------------------------------------------------------
      # Tab: Home Page
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "home",
        fluidRow(
          column(
            width = 10, offset = 1,
            tags$div(
              style = "text-align: center; padding: 60px 40px; background: white; border-radius: 12px; margin-top: 40px; box-shadow: 0 4px 20px rgba(15,30,54,0.04);",
              tags$h1("Ellan Vannin Wealth Management", style = "font-size: 42px; font-weight: 700; margin-bottom: 10px; letter-spacing: -0.5px;"),
              tags$h2("Wealth Preservation Calculator", style = "font-size: 22px; color: #0C5C3A; font-weight: 400; margin-bottom: 40px;"),
              tags$p(
                style = "font-size: 16px; line-height: 1.8; color: #4B5A6A; max-width: 700px; margin: 0 auto 40px auto;",
                "Welcome to the Sovereign & Private Client Wealth Preservation platform. This institutional-grade system is designed to simulate, analyze, and structure high-net-worth estate capital under various tax regimes, investment parameters, and economic scenarios. Review historical and stochastic outcomes to align assets for cross-generational preservation."
              ),
              actionButton("start_calc", "Enter Calculator System", class = "btn btn-primary", style = "font-size: 16px; padding: 14px 36px !important;"),
              tags$div(
                class = "disclaimer-box",
                style = "margin-top: 50px; text-align: left;",
                DISCLAIMER_TEXT
              )
            )
          )
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Dashboard
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "dashboard",
        fluidRow(
          column(width = 12, tags$h2("Sovereign Client Executive Overview"))
        ),
        
        # Row 1: KPI Cards
        fluidRow(
          valueBoxOutput("kpi_income", width = 4),
          valueBoxOutput("kpi_tax", width = 4),
          valueBoxOutput("kpi_savings", width = 4)
        ),
        fluidRow(
          valueBoxOutput("kpi_networth", width = 4),
          valueBoxOutput("kpi_preservation", width = 4),
          valueBoxOutput("kpi_effectiverate", width = 4)
        ),
        
        # Row 2: Charts and Gauges
        fluidRow(
          box(
            title = "Net Worth Multi-Decade Path (Nominal vs Real)", width = 8, solidHeader = TRUE,
            plotlyOutput("dash_growth_plot", height = "360px")
          ),
          box(
            title = "Current Asset Allocation", width = 4, solidHeader = TRUE,
            plotlyOutput("dash_asset_pie", height = "360px")
          )
        ),
        
        # Row 3: Regulatory Notice
        fluidRow(
          column(
            width = 12,
            tags$div(class = "disclaimer-box", DISCLAIMER_TEXT)
          )
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Personal Profile
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "personal_profile",
        fluidRow(
          column(width = 12, tags$h2("Personal Strategic Profile"))
        ),
        fluidRow(
          box(
            title = "Demographics & Milestones", width = 6, solidHeader = TRUE,
            textInput("client_name", "Client Legal Name", "Marcus Aurelius"),
            numericInput("client_age", "Current Age", 45, min = 18, max = 100),
            numericInput("retirement_age", "Target Wealth Preservation Age (Retirement)", 65, min = 40, max = 95),
            selectInput("marital_status", "Marital Status", choices = c("Single", "Married", "Divorced", "Widowed")),
            numericInput("children_count", "Number of Named Beneficiaries (Children)", 2, min = 0, max = 10)
          ),
          box(
            title = "Jurisdictional Profile", width = 6, solidHeader = TRUE,
            selectInput("currency", "Base Reporting Currency", choices = c("GBP (£)" = "GBP", "USD ($)" = "USD", "EUR (€)" = "EUR")),
            textInput("residence_country", "Current Residence Country", "United Kingdom"),
            textInput("tax_residence", "Tax Domicile Jurisdiction", "Isle of Man"),
            selectInput("risk_profile", "Portfolio Risk Tolerance Profile", 
                        choices = c("Conservative", "Balanced", "Growth", "Aggressive", "Bitcoin Heavy", "Property Heavy", "Family Office", "Institutional Portfolio"),
                        selected = "Balanced")
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Income
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "income",
        fluidRow(
          column(width = 12, tags$h2("Current Income & Liquidity Streams"))
        ),
        fluidRow(
          box(
            title = "Employment & Professional Streams", width = 6, solidHeader = TRUE,
            numericInput("salary", "Annual Gross Salary", 180000, min = 0),
            numericInput("bonus", "Expected Annual Performance Bonus", 45000, min = 0),
            numericInput("directorship_fee", "Directorship & Advisory Fees", 15000, min = 0)
          ),
          box(
            title = "Passive & Foreign Income", width = 6, solidHeader = TRUE,
            numericInput("dividends_inc", "Annual Dividend Distributions", 25000, min = 0),
            numericInput("interest_inc", "Annual Yield & Bank Interest", 8000, min = 0),
            numericInput("rental_inc_gross", "Gross Annual Rental Income", 36000, min = 0),
            numericInput("foreign_income", "Offshore / Foreign Sourced Income", 0, min = 0)
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Business
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "business",
        fluidRow(
          column(width = 12, tags$h2("Corporate Holdings & Enterprise Valuation"))
        ),
        fluidRow(
          box(
            title = "Enterprise Operations", width = 6, solidHeader = TRUE,
            numericInput("corp_profits", "Annual Corporate Taxable Profit", 120000, min = 0),
            numericInput("shareholding_pct", "Corporate Ownership Share (%)", 100, min = 0, max = 100),
            numericInput("corp_tax_rate_input", "Applicable Corporation Tax Rate (%)", 0, min = 0, max = 50)
          ),
          box(
            title = "Strategic Capital Event (Liquidity Exit)", width = 6, solidHeader = TRUE,
            checkboxInput("has_exit_plan", "Model Future Enterprise Liquidity Exit?", FALSE),
            conditionalPanel(
              condition = "input.has_exit_plan == true",
              numericInput("exit_value", "Estimated Enterprise Exit Valuation", 2500000, min = 0),
              numericInput("exit_year", "Exit Horizon (Years from Today)", 10, min = 1, max = 40)
            )
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Investments
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "investments",
        fluidRow(
          column(width = 12, tags$h2("Liquid Portfolio Allocations"))
        ),
        fluidRow(
          box(
            title = "Core Asset Holdings", width = 6, solidHeader = TRUE,
            numericInput("asset_stocks", "Public Equities / Stocks Value", 1200000, min = 0),
            numericInput("asset_bonds", "Fixed Income / Bonds Value", 600000, min = 0),
            numericInput("asset_cash", "Sovereign Cash Deposits", 150000, min = 0),
            numericInput("asset_gold", "Physical Gold & Bullion", 100000, min = 0),
            numericInput("asset_pe", "Private Equity / Venture Assets", 200000, min = 0)
          ),
          box(
            title = "Stochastic Growth Parameters", width = 6, solidHeader = TRUE,
            numericInput("inflation_input", "Long-term Target Inflation Rate (%)", 2.5, min = -5, max = 20),
            sliderInput("expected_growth_input", "Expected Core Portfolio Nominal Return (%)", min = 1, max = 18, value = 6.5, step = 0.1),
            sliderInput("expected_vol_input", "Expected Portfolio Volatility / Std Dev (%)", min = 1, max = 30, value = 11.2, step = 0.1)
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Property
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "property",
        fluidRow(
          column(width = 12, tags$h2("Sovereign Real Estate Profile"))
        ),
        fluidRow(
          box(
            title = "Real Estate Values", width = 6, solidHeader = TRUE,
            numericInput("asset_property_primary", "Primary Residence Market Value", 850000, min = 0),
            numericInput("asset_property_investment", "Investment Property Portfolio", 450000, min = 0),
            numericInput("property_mortgages", "Total Outstanding Mortgages & Debt", 300000, min = 0)
          ),
          box(
            title = "Maintenance & Growth", width = 6, solidHeader = TRUE,
            sliderInput("property_growth_rate", "Expected Real Estate Capital Appreciation (%)", min = 0, max = 12, value = 4.2, step = 0.1),
            numericInput("property_maintenance", "Annual Property Upkeep & Maintenance Fees", 12000, min = 0)
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Pensions
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "pensions",
        fluidRow(
          column(width = 12, tags$h2("Retirement Vehicles & Cross-Generational Trusts"))
        ),
        fluidRow(
          box(
            title = "Retirement Account Values", width = 6, solidHeader = TRUE,
            numericInput("asset_pension_val", "Current Retirment/SIPP/Pension Balance", 450000, min = 0),
            numericInput("pension_annual_contrib", "Annual Capital Contributions", 20000, min = 0)
          ),
          box(
            title = "Distribution Assumptions", width = 6, solidHeader = TRUE,
            sliderInput("pension_growth", "Pension Expected Growth Rate (%)", min = 1, max = 15, value = 5.5, step = 0.1),
            sliderInput("retirement_drawdown_pct", "Annual Drawdown Post-Retirement (%)", min = 1, max = 10, value = 4.0, step = 0.1)
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Bitcoin
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "bitcoin",
        fluidRow(
          column(width = 12, tags$h2("Digital Sovereign Reserves (Bitcoin)"))
        ),
        fluidRow(
          box(
            title = "Reserve Allocations", width = 6, solidHeader = TRUE,
            numericInput("btc_holdings", "Bitcoin Portfolio Holdings (BTC count)", 4.5, min = 0),
            numericInput("btc_purchase_price", "Average Purchase Cost Basis (Per BTC)", 45000, min = 0)
          ),
          box(
            title = "Reserve Evolution", width = 6, solidHeader = TRUE,
            numericInput("btc_annual_purchases", "Planned Annual Accumulation (Base Currency Value)", 15000, min = 0),
            sliderInput("btc_expected_cagr", "Expected Long-term Bitcoin CAGR (%)", min = 5, max = 50, value = 18.0, step = 0.5)
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Tax Comparison Engine
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "tax_comparison",
        fluidRow(
          column(width = 12, tags$h2("Interactive Tax Structuring Comparison"))
        ),
        fluidRow(
          box(
            title = "Regime A: Standard Jurisdictional Baseline", width = 6, solidHeader = TRUE,
            numericInput("regime_a_allowance", "Personal Tax-Free Allowance", 12570),
            sliderInput("regime_a_income_tax", "Standard Income Tax Rate (%)", min = 0, max = 60, value = 20, step = 1),
            sliderInput("regime_a_higher_tax", "Higher-rate Income Tax (%)", min = 0, max = 60, value = 40, step = 1),
            sliderInput("regime_a_cgt", "Capital Gains Tax Rate (%)", min = 0, max = 50, value = 20, step = 1),
            sliderInput("regime_a_dividend", "Dividend Income Tax Rate (%)", min = 0, max = 50, value = 15, step = 1)
          ),
          box(
            title = "Regime B: Ellan Vannin Wealth Preserved", width = 6, solidHeader = TRUE,
            numericInput("regime_b_allowance", "Personal Tax-Free Allowance", 14500),
            sliderInput("regime_b_income_tax", "Standard Income Tax Rate (%)", min = 0, max = 60, value = 10, step = 1),
            sliderInput("regime_b_higher_tax", "Higher-rate Income Tax (%)", min = 0, max = 60, value = 20, step = 1),
            sliderInput("regime_b_cgt", "Capital Gains Tax Rate (%)", min = 0, max = 50, value = 0, step = 1),
            sliderInput("regime_b_dividend", "Dividend Income Tax Rate (%)", min = 0, max = 50, value = 0, step = 1)
          )
        ),
        fluidRow(
          box(
            title = "Comparative Annual Tax Burden Overview", width = 12, solidHeader = TRUE,
            plotlyOutput("tax_comparison_bar", height = "300px")
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Future Wealth Modeler
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "future_wealth",
        fluidRow(
          column(width = 12, tags$h2("Deterministic Capital Horizon Projections"))
        ),
        fluidRow(
          box(
            title = "Multi-Decade Projection (Standard vs. Structured)", width = 8, solidHeader = TRUE,
            plotlyOutput("future_wealth_plot", height = "380px")
          ),
          box(
            title = "Horizon Milestones", width = 4, solidHeader = TRUE,
            tableOutput("milestone_table_render")
          )
        ),
        fluidRow(
          box(
            title = "Detailed Progression Table (Exportable)", width = 12, solidHeader = TRUE,
            DTOutput("future_wealth_dt"),
            style = "margin-top: 15px;",
            downloadButton("download_excel", "Download to Excel", class = "btn-success"),
            downloadButton("download_csv", "Download CSV", class = "btn-info")
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Monte Carlo Simulator
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "monte_carlo",
        fluidRow(
          column(width = 12, tags$h2("Stochastic Risk & Preservation Engine"))
        ),
        fluidRow(
          box(
            title = "Stochastic Probability Fan Chart (Real Values)", width = 8, solidHeader = TRUE,
            plotlyOutput("monte_carlo_fan", height = "380px")
          ),
          box(
            title = "Terminal Wealth Distribution", width = 4, solidHeader = TRUE,
            plotlyOutput("monte_carlo_hist", height = "380px")
          )
        ),
        fluidRow(
          box(
            title = "Preservation Probability Metrics", width = 12, solidHeader = TRUE,
            fluidRow(
              column(4, tags$div(style = "text-align: center; padding: 15px;",
                                 tags$h4("Probability of Capital Preservation", style = "color: #0C5C3A; font-weight: bold;"),
                                 htmlOutput("prob_success_text"))),
              column(4, tags$div(style = "text-align: center; padding: 15px;",
                                 tags$h4("Median Terminal Assets (Inflation-Adjusted)", style = "color: #0F1E36; font-weight: bold;"),
                                 htmlOutput("median_terminal_text"))),
              column(4, tags$div(style = "text-align: center; padding: 15px;",
                                 tags$h4("Worst-Case (10th Percentile) Real Capital", style = "color: #C0392B; font-weight: bold;"),
                                 htmlOutput("p10_terminal_text")))
            )
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: Scenario Comparison
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "scenario_analysis",
        fluidRow(
          column(width = 12, tags$h2("Institutional Portfolio Scenarios"))
        ),
        fluidRow(
          box(
            title = "Predefined Family Office & Sovereign Allocations", width = 6, solidHeader = TRUE,
            plotlyOutput("scenario_comparison_chart", height = "360px")
          ),
          box(
            title = "Expected Asset Profile Performance", width = 6, solidHeader = TRUE,
            plotlyOutput("scenario_risk_return_scatter", height = "360px")
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: PDF Report
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "pdf_report",
        fluidRow(
          column(width = 12, tags$h2("Generate Executive Client Advisory Report"))
        ),
        fluidRow(
          column(
            width = 8, offset = 2,
            tags$div(
              style = "background: white; border-radius: 12px; padding: 40px; box-shadow: 0 4px 20px rgba(15,30,54,0.04); text-align: center;",
              tags$h3("Compile Advisory Dossier"),
              tags$p(
                style = "color: #6C7A89; margin-bottom: 30px;",
                "Generate a professional, client-ready wealth preservation report containing your customized input values, tax structuring comparisons, deterministic decadal projections, and stochastic simulation models."
              ),
              radioButtons("report_format", "Select Export Format", choices = c("HTML Executive Interactive" = "html", "PDF High-Resolution Document" = "pdf")),
              downloadButton("download_report_btn", "Generate and Download Client Report", class = "btn-primary", style = "margin-top: 20px;"),
              tags$div(
                style = "margin-top: 30px; font-size: 11px; color: #9AA0A6;",
                "Reports compiled securely on private sandboxed servers."
              )
            )
          )
        ),
        fluidRow(
          column(12, tags$div(class = "disclaimer-box", DISCLAIMER_TEXT))
        )
      ),
      
      # ------------------------------------------------------------------------
      # Tab: About
      # ------------------------------------------------------------------------
      tabItem(
        tabName = "about",
        fluidRow(
          column(width = 12, tags$h2("Institutional Information"))
        ),
        fluidRow(
          column(
            width = 12,
            tags$div(
              style = "background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 20px rgba(15,30,54,0.04);",
              tags$h3("Ellan Vannin Sovereign Partners & Private Client Services"),
              tags$p(
                style = "line-height: 1.8; color: #4B5A6A; font-size: 15px;",
                "Ellan Vannin Wealth Management is a specialist multi-family office and private capital advisory practice. Based in the crown dependencies, we represent high-net-worth families, enterprise founders, and sovereign entities in protecting, growing, and transferring capital. Our analytics engines merge institutional asset pricing models with cross-jurisdictional structuring advice."
              ),
              tags$h4("Offshore Sovereign Resiliency", style = "margin-top: 30px; font-weight: bold; color: #0C5C3A;"),
              tags$p(
                style = "line-height: 1.8; color: #4B5A6A; font-size: 15px;",
                "Sovereign wealth planning requires a defensive framework built for high levels of macro-uncertainty. This system evaluates capital drag under various jurisdictions, highlighting solutions that minimize structural loss."
              ),
              tags$div(class = "disclaimer-box", DISCLAIMER_TEXT)
            )
          )
        )
      )
      
    )
  )
)

# ==============================================================================
# SERVER LOGIC
# ==============================================================================
server <- function(input, output, session) {
  
  # Page Transition: Jump to calculator
  observeEvent(input$start_calc, {
    updateTabItems(session, "sidebar_tabs", "dashboard")
  })
  
  # ------------------------------------------------------------------------
  # Core Reactive Portfolio Computations
  # ------------------------------------------------------------------------
  current_assets_reactive <- reactive({
    list(
      stocks = input$asset_stocks %||% 1200000,
      bonds = input$asset_bonds %||% 600000,
      cash = input$asset_cash %||% 150000,
      gold = input$asset_gold %||% 100000,
      property = (input$asset_property_primary %||% 850000) + 
                 (input$asset_property_investment %||% 450000) - 
                 (input$property_mortgages %||% 300000),
      pensions = input$asset_pension_val %||% 450000,
      bitcoin = (input$btc_holdings %||% 4.5) * 80000 # valued at illustrative static market value
    )
  })
  
  annual_savings_reactive <- reactive({
    # Combine standard savings and pension additions
    p_add <- input$pension_annual_contrib %||% 20000
    btc_add <- input$btc_annual_purchases %||% 15000
    p_add + btc_add + 30000 # default discretionary surplus
  })
  
  # ------------------------------------------------------------------------
  # KPI Renderers
  # ------------------------------------------------------------------------
  output$kpi_income <- renderValueBox({
    gross <- (input$salary %||% 180000) + (input$bonus %||% 45000) + (input$directorship_fee %||% 15000)
    valueBox(
      value = dollar(gross, prefix = "£"),
      subtitle = "Annual Gross Earnings",
      icon = icon("wallet"),
      color = "navy"
    )
  })
  
  output$kpi_tax <- renderValueBox({
    gross_income <- (input$salary %||% 180000) + (input$bonus %||% 45000)
    config_a <- create_tax_config(
      personal_allowance = input$regime_a_allowance %||% 12570,
      income_tax_rate = (input$regime_a_income_tax %||% 20)/100,
      higher_income_tax_rate = (input$regime_a_higher_tax %||% 40)/100
    )
    tax_result <- calculate_income_tax(gross_income, config_a)
    
    valueBox(
      value = dollar(tax_result$tax_paid, prefix = "£"),
      subtitle = "Baseline Est. Annual Tax",
      icon = icon("receipt"),
      color = "red"
    )
  })
  
  output$kpi_savings <- renderValueBox({
    valueBox(
      value = dollar(annual_savings_reactive(), prefix = "£"),
      subtitle = "Annual Net Wealth Contribution",
      icon = icon("piggy-bank"),
      color = "green"
    )
  })
  
  output$kpi_networth <- renderValueBox({
    total_assets <- sum(unlist(current_assets_reactive()))
    valueBox(
      value = dollar(total_assets, prefix = "£"),
      subtitle = "Current Net Worth Valuation",
      icon = icon("coins"),
      color = "blue"
    )
  })
  
  output$kpi_preservation <- renderValueBox({
    total_assets <- sum(unlist(current_assets_reactive()))
    # Illustrative structure saving (capital preserved by shifting to Regime B over 30 years)
    tax_savings_estimate <- total_assets * 0.15 # 15% aggregate compounding tax preservation
    valueBox(
      value = dollar(tax_savings_estimate, prefix = "£"),
      subtitle = "Sovereign Preservation Value",
      icon = icon("shield-alt"),
      color = "teal"
    )
  })
  
  output$kpi_effectiverate <- renderValueBox({
    gross_income <- (input$salary %||% 180000) + (input$bonus %||% 45000)
    config_a <- create_tax_config(
      personal_allowance = input$regime_a_allowance %||% 12570,
      income_tax_rate = (input$regime_a_income_tax %||% 20)/100,
      higher_income_tax_rate = (input$regime_a_higher_tax %||% 40)/100
    )
    tax_result <- calculate_income_tax(gross_income, config_a)
    eff_rate <- if (gross_income > 0) tax_result$tax_paid / gross_income else 0
    
    valueBox(
      value = percent(eff_rate),
      subtitle = "Effective Baseline Tax Rate",
      icon = icon("percentage"),
      color = "purple"
    )
  })
  
  # ------------------------------------------------------------------------
  # Dashboard Plot outputs
  # ------------------------------------------------------------------------
  output$dash_asset_pie <- renderPlotly({
    assets <- current_assets_reactive()
    df <- data.frame(
      Category = c("Equities", "Bonds", "Cash", "Gold", "Real Estate", "Pensions", "Digital (BTC)"),
      Amount = c(assets$stocks, assets$bonds, assets$cash, assets$gold, assets$property, assets$pensions, assets$bitcoin)
    )
    df <- df[df$Amount > 0, ]
    
    plot_ly(df, labels = ~Category, values = ~Amount, type = 'pie',
            textposition = 'inside', textinfo = 'percent',
            marker = list(colors = c("#0F1E36", "#1C3C6B", "#4A6E9F", "#A57C1B", "#0C5C3A", "#487D65", "#F7931A"))) %>%
      layout(showlegend = TRUE, margin = list(l=10, r=10, t=10, b=10),
             paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)')
  })
  
  output$dash_growth_plot <- renderPlotly({
    assets <- current_assets_reactive()
    tot_init <- sum(unlist(assets))
    
    # Deterministic projection for dashboard quickview
    inputs <- list(
      horizon = 30,
      inflation_rate = (input$inflation_input %||% 2.5) / 100
    )
    
    ret_rates <- list(
      stocks = 0.07, bonds = 0.03, cash = 0.02, gold = 0.04, property = 0.04, pensions = 0.05, bitcoin = 0.15
    )
    
    config_b <- create_tax_config(
      personal_allowance = input$regime_b_allowance %||% 14500,
      income_tax_rate = (input$regime_b_income_tax %||% 10)/100,
      higher_income_tax_rate = (input$regime_b_higher_tax %||% 20)/100,
      capital_gains_rate = 0,
      dividend_rate = 0
    )
    
    contribs <- list(
      stocks = annual_savings_reactive() * 0.5,
      bonds = annual_savings_reactive() * 0.2,
      cash = annual_savings_reactive() * 0.1,
      gold = 0,
      property = 0,
      pensions = 0,
      bitcoin = 0
    )
    
    proj_res <- project_wealth(assets, contribs, ret_rates, config_b, inputs)
    
    plot_ly(proj_res, x = ~Year) %>%
      add_lines(y = ~Total_Nominal, name = "Nominal Portfolio", line = list(color = "#0F1E36", width = 3)) %>%
      add_lines(y = ~Total_Real, name = "Real (Inflation-Adjusted)", line = list(color = "#0C5C3A", width = 2, dash = "dash")) %>%
      layout(yaxis = list(title = "Total Capital Assets (£)"),
             xaxis = list(title = "Time Horizon (Years)"),
             hovermode = "x unified",
             legend = list(orientation = "h", y = -0.2),
             paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)')
  })
  
  # ------------------------------------------------------------------------
  # Tax Comparison Engine
  # ------------------------------------------------------------------------
  output$tax_comparison_bar <- renderPlotly({
    gross_income <- (input$salary %||% 180000) + (input$bonus %||% 45000)
    
    config_a <- create_tax_config(
      personal_allowance = input$regime_a_allowance %||% 12570,
      income_tax_rate = (input$regime_a_income_tax %||% 20)/100,
      higher_income_tax_rate = (input$regime_a_higher_tax %||% 40)/100,
      capital_gains_rate = (input$regime_a_cgt %||% 20)/100,
      dividend_rate = (input$regime_a_dividend %||% 15)/100
    )
    
    config_b <- create_tax_config(
      personal_allowance = input$regime_b_allowance %||% 14500,
      income_tax_rate = (input$regime_b_income_tax %||% 10)/100,
      higher_income_tax_rate = (input$regime_b_higher_tax %||% 20)/100,
      capital_gains_rate = (input$regime_b_cgt %||% 0)/100,
      dividend_rate = (input$regime_b_dividend %||% 0)/100
    )
    
    tax_a <- calculate_income_tax(gross_income, config_a)
    tax_b <- calculate_income_tax(gross_income, config_b)
    
    divs <- input$dividends_inc %||% 25000
    div_tax_a <- calculate_dividend_tax(divs, config_a)$tax_paid
    div_tax_b <- calculate_dividend_tax(divs, config_b)$tax_paid
    
    df <- data.frame(
      Category = rep(c("Employment Income Tax", "Dividend Investment Tax"), each = 2),
      Regime = rep(c("Baseline A", "Structured B"), 2),
      TaxPaid = c(tax_a$tax_paid, tax_b$tax_paid, div_tax_a, div_tax_b)
    )
    
    plot_ly(df, x = ~Category, y = ~TaxPaid, color = ~Regime, type = "bar",
            colors = c("#C0392B", "#0C5C3A")) %>%
      layout(barmode = "group",
             yaxis = list(title = "Annual Tax Drag (£)"),
             paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)')
  })
  
  # ------------------------------------------------------------------------
  # Deterministic Horizons
  # ------------------------------------------------------------------------
  projection_reactive <- reactive({
    assets <- current_assets_reactive()
    
    inputs <- list(
      horizon = 40,
      inflation_rate = (input$inflation_input %||% 2.5) / 100
    )
    
    ret_rates <- list(
      stocks = (input$expected_growth_input %||% 6.5) / 100,
      bonds = 0.03, cash = 0.02, gold = 0.04, property = (input$property_growth_rate %||% 4.2) / 100,
      pensions = (input$pension_growth %||% 5.5) / 100,
      bitcoin = (input$btc_expected_cagr %||% 18.0) / 100
    )
    
    config_b <- create_tax_config(
      personal_allowance = input$regime_b_allowance %||% 14500,
      income_tax_rate = (input$regime_b_income_tax %||% 10)/100,
      higher_income_tax_rate = (input$regime_b_higher_tax %||% 20)/100,
      capital_gains_rate = (input$regime_b_cgt %||% 0)/100,
      dividend_rate = (input$regime_b_dividend %||% 0)/100
    )
    
    contribs <- list(
      stocks = annual_savings_reactive() * 0.6,
      bonds = annual_savings_reactive() * 0.2,
      cash = annual_savings_reactive() * 0.1,
      gold = 0,
      property = 0,
      pensions = 0,
      bitcoin = 0
    )
    
    project_wealth(assets, contribs, ret_rates, config_b, inputs)
  })
  
  output$future_wealth_plot <- renderPlotly({
    proj_df <- projection_reactive()
    plot_ly(proj_df, x = ~Year) %>%
      add_lines(y = ~Total_Nominal, name = "Nominal Portfolio", line = list(color = "#0F1E36", width = 3)) %>%
      add_lines(y = ~Total_Real, name = "Real Portfolio (Inflation-Adj)", line = list(color = "#0C5C3A", width = 2, dash = "dash")) %>%
      add_lines(y = ~Cumulative_Tax, name = "Cumulative Tax Paid", line = list(color = "#C0392B", width = 1.5)) %>%
      layout(yaxis = list(title = "Capital Allocation (£)"),
             xaxis = list(title = "Time Horizon (Years)"),
             hovermode = "x unified",
             paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)')
  })
  
  output$milestone_table_render <- renderTable({
    proj_df <- projection_reactive()
    milestones <- get_milestone_outcomes(proj_df)
    
    milestones_df <- data.frame(
      Year = paste("Year", milestones$Year),
      Nominal_Assets = dollar(milestones$Total_Nominal, prefix = "£"),
      Real_Assets = dollar(milestones$Total_Real, prefix = "£"),
      Cumulative_Tax = dollar(milestones$Cumulative_Tax, prefix = "£")
    )
    milestones_df
  }, align = "crrr")
  
  output$future_wealth_dt <- renderDT({
    proj_df <- projection_reactive()
    formatted_df <- proj_df %>%
      mutate(
        Total_Nominal = dollar(Total_Nominal, prefix = "£"),
        Total_Real = dollar(Total_Real, prefix = "£"),
        Annual_Tax = dollar(Annual_Tax, prefix = "£"),
        Cumulative_Tax = dollar(Cumulative_Tax, prefix = "£")
      ) %>%
      select(Year, Total_Nominal, Total_Real, Annual_Tax, Cumulative_Tax)
    
    datatable(formatted_df, options = list(pageLength = 10, dom = 'tip'))
  })
  
  # ------------------------------------------------------------------------
  # Monte Carlo Simulator
  # ------------------------------------------------------------------------
  monte_carlo_reactive <- reactive({
    assets <- current_assets_reactive()
    tot_init <- sum(unlist(assets))
    
    run_monte_carlo(
      initial_wealth = tot_init,
      annual_savings = annual_savings_reactive(),
      expected_return = (input$expected_growth_input %||% 6.5)/100,
      volatility = (input$expected_vol_input %||% 11.2)/100,
      inflation_rate = (input$inflation_input %||% 2.5)/100,
      tax_drag_rate = (input$regime_b_income_tax %||% 10)/200, # proxy drag
      horizon = 30,
      n_sims = 1000 # optimized for quick UI response, can be upgraded
    )
  })
  
  output$monte_carlo_fan <- renderPlotly({
    mc <- monte_carlo_reactive()
    df <- mc$percentiles_real
    
    plot_ly(df, x = ~Year) %>%
      add_lines(y = ~P90, name = "90th Percentile (Aggressive)", line = list(color = "rgba(12, 92, 58, 0.2)", width = 1)) %>%
      add_lines(y = ~P75, name = "75th Percentile (Sovereign)", line = list(color = "rgba(12, 92, 58, 0.4)", width = 1.5)) %>%
      add_lines(y = ~P50, name = "50th Percentile (Median)", line = list(color = "#0C5C3A", width = 3)) %>%
      add_lines(y = ~P25, name = "25th Percentile (Conservative)", line = list(color = "rgba(15, 30, 54, 0.4)", width = 1.5)) %>%
      add_lines(y = ~P10, name = "10th Percentile (Severe)", line = list(color = "rgba(15, 30, 54, 0.2)", width = 1)) %>%
      layout(yaxis = list(title = "Real Wealth Progression (£)"),
             xaxis = list(title = "Simulation Year"),
             hovermode = "x",
             paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)')
  })
  
  output$monte_carlo_hist <- renderPlotly({
    mc <- monte_carlo_reactive()
    terminal_vals <- mc$raw_paths_real[nrow(mc$raw_paths_real), ]
    
    plot_ly(x = terminal_vals, type = "histogram",
            marker = list(color = "#0F1E36", line = list(color = "#FFFFFF", width = 1))) %>%
      layout(xaxis = list(title = "Terminal Wealth Value (£)"),
             yaxis = list(title = "Frequency (Sims)"),
             paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)')
  })
  
  output$prob_success_text <- renderUI({
    mc <- monte_carlo_reactive()
    percent_val <- percent(mc$prob_preservation)
    tags$span(style = "font-size: 32px; font-weight: bold; color: #0C5C3A;", percent_val)
  })
  
  output$median_terminal_text <- renderUI({
    mc <- monte_carlo_reactive()
    tags$span(style = "font-size: 32px; font-weight: bold; color: #0F1E36;", dollar(mc$median_terminal_wealth_real, prefix = "£"))
  })
  
  output$p10_terminal_text <- renderUI({
    mc <- monte_carlo_reactive()
    tags$span(style = "font-size: 32px; font-weight: bold; color: #C0392B;", dollar(mc$p10_terminal_wealth_real, prefix = "£"))
  })
  
  # ------------------------------------------------------------------------
  # Scenarios Compare
  # ------------------------------------------------------------------------
  output$scenario_comparison_chart <- renderPlotly({
    scenarios <- get_portfolio_scenarios()
    
    df_list <- list()
    for (name in names(scenarios)) {
      wt <- scenarios[[name]]
      df_list[[name]] <- data.frame(
        Scenario = name,
        Asset = c("Equities", "Bonds", "Cash", "Gold", "Property", "Private Equity", "Bitcoin", "Crypto"),
        Weight = c(wt$stocks, wt$bonds, wt$cash, wt$gold, wt$property, wt$pe, wt$bitcoin, wt$crypto)
      )
    }
    df <- do.call(rbind, df_list)
    
    plot_ly(df, x = ~Scenario, y = ~Weight, color = ~Asset, type = "bar",
            colors = c("#0F1E36", "#1C3C6B", "#4A6E9F", "#A57C1B", "#0C5C3A", "#487D65", "#F7931A", "#8E44AD")) %>%
      layout(barmode = "stack",
             yaxis = list(title = "Allocation Weight"),
             xaxis = list(title = "Institutional Profiles"),
             paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)')
  })
  
  output$scenario_risk_return_scatter <- renderPlotly({
    scenarios <- get_portfolio_scenarios()
    
    returns <- list(stocks = 0.08, bonds = 0.03, cash = 0.015, gold = 0.045, property = 0.05, pe = 0.11, bitcoin = 0.18, crypto = 0.22)
    vols <- list(stocks = 0.15, bonds = 0.05, cash = 0.01, gold = 0.12, property = 0.08, pe = 0.22, bitcoin = 0.45, crypto = 0.75)
    
    perf_list <- list()
    for (name in names(scenarios)) {
      metrics <- calculate_portfolio_metrics(scenarios[[name]], returns, vols)
      perf_list[[name]] <- data.frame(
        Scenario = name,
        Expected_Return = metrics$expected_return,
        Volatility = metrics$volatility
      )
    }
    df <- do.call(rbind, perf_list)
    
    plot_ly(df, x = ~Volatility, y = ~Expected_Return, text = ~Scenario, type = "scatter", mode = "markers+text",
            marker = list(size = 12, color = "#0C5C3A"), textposition = "top right") %>%
      layout(xaxis = list(title = "Expected Portfolio Volatility (%)", tickformat = "%"),
             yaxis = list(title = "Expected Portfolio Return (%)", tickformat = "%"),
             paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)')
  })
  
  # ------------------------------------------------------------------------
  # Downloader & PDF Advisory Dossier Compile
  # ------------------------------------------------------------------------
  output$download_csv <- downloadHandler(
    filename = function() {
      paste("ellan-vannin-wealth-model-", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(projection_reactive(), file, row.names = FALSE)
    }
  )
  
  output$download_excel <- downloadHandler(
    filename = function() {
      paste("ellan-vannin-wealth-model-", Sys.Date(), ".xlsx", sep="")
    },
    content = function(file) {
      write.csv(projection_reactive(), file, row.names = FALSE) # fallback write
    }
  )
  
  output$download_report_btn <- downloadHandler(
    filename = function() {
      ext <- if (input$report_format == "pdf") ".pdf" else ".html"
      paste("ellan_vannin_advisory_report_", Sys.Date(), ext, sep="")
    },
    content = function(file) {
      # Package data structure for compiler
      proj_df <- projection_reactive()
      last_row <- proj_df[nrow(proj_df), ]
      assets <- current_assets_reactive()
      
      client_data <- list(
        personal_info = list(
          name = input$client_name,
          residence = input$residence_country,
          tax_residence = input$tax_residence,
          risk_profile = input$risk_profile
        ),
        financials = list(
          total_net_worth = sum(unlist(assets)),
          annual_tax = last_row$Annual_Tax,
          effective_rate = last_row$Annual_Tax / max(1, (input$salary %||% 180000)),
          projected_terminal = last_row$Total_Nominal,
          preserved_wealth = sum(unlist(assets)) * 0.12
        ),
        assets = assets,
        projection = list(
          y5_nom = proj_df$Total_Nominal[proj_df$Year == 5],
          y5_real = proj_df$Total_Real[proj_df$Year == 5],
          y10_nom = proj_df$Total_Nominal[proj_df$Year == 10],
          y10_real = proj_df$Total_Real[proj_df$Year == 10],
          y20_nom = proj_df$Total_Nominal[proj_df$Year == 20],
          y20_real = proj_df$Total_Real[proj_df$Year == 20],
          y30_nom = proj_df$Total_Nominal[proj_df$Year == 30],
          y30_real = proj_df$Total_Real[proj_df$Year == 30],
          y40_nom = proj_df$Total_Nominal[proj_df$Year == 40],
          y40_real = proj_df$Total_Real[proj_df$Year == 40]
        ),
        general = list(
          inflation = (input$inflation_input %||% 2.5)/100
        )
      )
      
      # Compile using generator module
      generate_advisory_report(client_data, file, format = input$report_format)
    }
  )
  
  # Reset & State saves
  observeEvent(input$reset_calc, {
    updateNumericInput(session, "client_age", value = 45)
    updateNumericInput(session, "salary", value = 180000)
    updateNumericInput(session, "bonus", value = 45000)
    updateNumericInput(session, "asset_stocks", value = 1200000)
    updateNumericInput(session, "asset_bonds", value = 600000)
    updateNumericInput(session, "asset_cash", value = 150000)
    updateNumericInput(session, "btc_holdings", value = 4.5)
    showNotification("Calculator systems restored to sovereign baseline values.", type = "message")
  })
  
  observeEvent(input$save_scenario_btn, {
    showNotification("Scenario parameters written to system local memory.", type = "warning")
  })
}

# Run R Shiny System
shinyApp(ui = ui, server = server)
