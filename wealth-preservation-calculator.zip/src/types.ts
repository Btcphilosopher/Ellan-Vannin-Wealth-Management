/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PersonalInfo {
  name: string;
  age: number;
  retirementAge: number;
  country: string;
  residence: string;
  taxResidence: string;
  currency: string;
  maritalStatus: string;
  children: number;
  riskTolerance: string;
}

export interface IncomeInputs {
  salary: number;
  bonus: number;
  dividendIncome: number;
  interest: number;
  rentalIncome: number;
  foreignIncome: number;
  businessIncome: number;
  otherIncome: number;
}

export interface BusinessInputs {
  profit: number;
  corpTaxRate: number;
  dividends: number;
  directorshipIncome: number;
  shareholdingPct: number;
  exitValue: number;
  exitYear: number;
  hasExitPlan: boolean;
}

export interface InvestmentInputs {
  stocks: number;
  bonds: number;
  cash: number;
  gold: number;
  privateEquity: number;
  expectedReturn: number; // in %
  volatility: number;      // in %
  inflation: number;       // in %
}

export interface PropertyInputs {
  primaryValue: number;
  investmentValue: number;
  mortgage: number;
  rentalIncome: number;
  maintenance: number;
  growthRate: number; // in %
}

export interface PensionInputs {
  value: number;
  annualContributions: number;
  retirementIncome: number;
  expectedGrowth: number; // in %
}

export interface BitcoinInputs {
  holdings: number;
  purchasePrice: number;
  annualPurchases: number;
  expectedCAGR: number; // in %
}

export interface TaxRegime {
  personalAllowance: number;
  incomeTaxRate: number;
  higherIncomeTaxRate: number;
  higherIncomeThreshold: number;
  capitalGainsRate: number;
  capitalGainsAllowance: number;
  dividendRate: number;
  corporationTaxRate: number;
  wealthTaxRate: number;
  wealthTaxThreshold: number;
}

export interface CalculatorState {
  personal: PersonalInfo;
  income: IncomeInputs;
  business: BusinessInputs;
  investments: InvestmentInputs;
  property: PropertyInputs;
  pension: PensionInputs;
  bitcoin: BitcoinInputs;
  regimeA: TaxRegime;
  regimeB: TaxRegime;
}

export interface AnnualProjectionRow {
  year: number;
  stocks: number;
  bonds: number;
  cash: number;
  gold: number;
  property: number;
  pension: number;
  bitcoin: number;
  totalNominal: number;
  totalReal: number;
  annualTax: number;
  cumulativeTax: number;
  cumulativeContributions: number;
}

export interface MonteCarloSummary {
  years: number[];
  p10: number[];
  p25: number[];
  p50: number[];
  p75: number[];
  p90: number[];
  probPreservation: number;
  medianTerminalReal: number;
  p10TerminalReal: number;
  p90TerminalReal: number;
  terminalValues: number[];
}
