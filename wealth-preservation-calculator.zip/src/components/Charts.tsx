/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";

// Helper to format currency
const formatCurrency = (val: number) => {
  if (val >= 1e6) return `£${(val / 1e6).toFixed(2)}M`;
  if (val >= 1e3) return `£${(val / 1e3).toFixed(0)}k`;
  return `£${val.toFixed(0)}`;
};

// ==============================================================================
// 1. STACKED PIE / DONUT CHART
// ==============================================================================
interface PieData {
  label: string;
  value: number;
  color: string;
}

export function PieChart({ data }: { data: PieData[] }) {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  let accumulatedAngle = 0;

  const slices = data.map((d) => {
    const percentage = d.value / (total || 1);
    const angle = percentage * 360;
    const startAngle = accumulatedAngle;
    accumulatedAngle += angle;
    return { ...d, percentage, startAngle, angle };
  });

  return (
    <div className="flex flex-col md:flex-row items-center justify-between gap-6 w-full">
      <div className="relative w-48 h-48 flex-shrink-0">
        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
          {slices.map((slice, i) => {
            const x1 = 50 + 40 * Math.cos((slice.startAngle * Math.PI) / 180);
            const y1 = 50 + 40 * Math.sin((slice.startAngle * Math.PI) / 180);
            const x2 = 50 + 40 * Math.cos(((slice.startAngle + slice.angle) * Math.PI) / 180);
            const y2 = 50 + 40 * Math.sin(((slice.startAngle + slice.angle) * Math.PI) / 180);
            const largeArc = slice.angle > 180 ? 1 : 0;
            const pathData = `
              M 50 50
              L ${x1} ${y1}
              A 40 40 0 ${largeArc} 1 ${x2} ${y2}
              Z
            `;
            return (
              <path
                key={i}
                d={pathData}
                fill={slice.color}
                className="transition-all duration-300 hover:opacity-90 cursor-pointer"
                stroke="#ffffff"
                strokeWidth="1"
              />
            );
          })}
          {/* Inner hole for donut appearance */}
          <circle cx="50" cy="50" r="22" fill="#ffffff" className="dark:fill-[#0A192F] transition-colors" />
        </svg>
      </div>

      <div className="flex-1 w-full flex flex-col gap-2">
        {slices.map((slice, i) => (
          <div key={i} className="flex items-center justify-between text-xs font-medium">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: slice.color }} />
              <span className="text-slate-700 dark:text-slate-300">{slice.label}</span>
            </div>
            <div className="text-right">
              <span className="text-slate-900 dark:text-white font-semibold mr-2">{formatCurrency(slice.value)}</span>
              <span className="text-slate-400">({(slice.percentage * 100).toFixed(1)}%)</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==============================================================================
// 2. MULTI-LINE / PROJECTION CHART
// ==============================================================================
interface LineChartData {
  year: number;
  nominal: number;
  real: number;
  tax?: number;
}

export function ProjectionLineChart({ data }: { data: LineChartData[] }) {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  const padding = { top: 20, right: 20, bottom: 35, left: 55 };
  const width = 500;
  const height = 280;

  const maxVal = Math.max(...data.map((d) => Math.max(d.nominal, d.real, d.tax || 0))) * 1.05 || 100;
  const years = data.map((d) => d.year);
  const maxYear = Math.max(...years) || 1;

  const getX = (year: number) => padding.left + (year / maxYear) * (width - padding.left - padding.right);
  const getY = (val: number) => height - padding.bottom - (val / maxVal) * (height - padding.top - padding.bottom);

  // Path generators
  const nominalPath = data
    .map((d) => `${getX(d.year)},${getY(d.nominal)}`)
    .reduce((acc, curr, i) => (i === 0 ? `M ${curr}` : `${acc} L ${curr}`), "");

  const realPath = data
    .map((d) => `${getX(d.year)},${getY(d.real)}`)
    .reduce((acc, curr, i) => (i === 0 ? `M ${curr}` : `${acc} L ${curr}`), "");

  const taxPath = data
    .filter((d) => d.tax !== undefined)
    .map((d) => `${getX(d.year)},${getY(d.tax || 0)}`)
    .reduce((acc, curr, i) => (i === 0 ? `M ${curr}` : `${acc} L ${curr}`), "");

  // Grid ticks
  const yTicks = [0, maxVal * 0.25, maxVal * 0.5, maxVal * 0.75, maxVal];
  const xTicks = [0, Math.floor(maxYear * 0.25), Math.floor(maxYear * 0.5), Math.floor(maxYear * 0.75), maxYear];

  return (
    <div className="relative w-full">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
        {/* Grids and Axes */}
        {yTicks.map((tick, idx) => (
          <g key={idx} className="opacity-40">
            <line
              x1={padding.left}
              y1={getY(tick)}
              x2={width - padding.right}
              y2={getY(tick)}
              stroke="#CBD5E1"
              strokeDasharray="4 4"
            />
            <text
              x={padding.left - 8}
              y={getY(tick) + 4}
              textAnchor="end"
              className="fill-slate-500 text-[10px] font-semibold"
            >
              {formatCurrency(tick)}
            </text>
          </g>
        ))}

        {xTicks.map((tick, idx) => (
          <g key={idx}>
            <text
              x={getX(tick)}
              y={height - 12}
              textAnchor="middle"
              className="fill-slate-500 text-[10px] font-semibold"
            >
              Yr {tick}
            </text>
          </g>
        ))}

        {/* Shaded area for growth */}
        <path
          d={`${nominalPath} L ${getX(maxYear)},${getY(0)} L ${getX(0)},${getY(0)} Z`}
          fill="rgba(10, 25, 47, 0.03)"
        />

        {/* Lines */}
        <path d={nominalPath} fill="none" stroke="#0A192F" strokeWidth="3" strokeLinecap="round" />
        <path d={realPath} fill="none" stroke="#10B981" strokeWidth="2.5" strokeDasharray="5 5" strokeLinecap="round" />
        {taxPath && <path d={taxPath} fill="none" stroke="#EF4444" strokeWidth="1.5" strokeLinecap="round" />}

        {/* Hover overlay markers */}
        {data.map((d, i) => (
          <g
            key={i}
            onMouseEnter={() => setHoverIndex(i)}
            onMouseLeave={() => setHoverIndex(null)}
            className="cursor-pointer"
          >
            <rect
              x={getX(d.year) - 8}
              y={padding.top}
              width="16"
              height={height - padding.top - padding.bottom}
              fill="transparent"
            />
            {hoverIndex === i && (
              <g>
                <line
                  x1={getX(d.year)}
                  y1={padding.top}
                  x2={getX(d.year)}
                  y2={height - padding.bottom}
                  stroke="#94A3B8"
                  strokeWidth="1.5"
                />
                <circle cx={getX(d.year)} cy={getY(d.nominal)} r="5" fill="#0A192F" />
                <circle cx={getX(d.year)} cy={getY(d.real)} r="5" fill="#10B981" />
              </g>
            )}
          </g>
        ))}
      </svg>

      {/* Interactive Tooltip Card */}
      {hoverIndex !== null && data[hoverIndex] && (
        <div className="absolute top-4 right-4 bg-white dark:bg-slate-800 p-3 rounded-lg shadow-xl border border-slate-200 dark:border-slate-700 text-xs flex flex-col gap-1 z-10 min-w-44">
          <p className="font-bold text-slate-800 dark:text-white border-b pb-1 mb-1">Year {data[hoverIndex].year} Snapshot</p>
          <div className="flex justify-between gap-4">
            <span className="text-slate-500">Nominal Assets:</span>
            <span className="font-semibold text-slate-950 dark:text-white">{formatCurrency(data[hoverIndex].nominal)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-slate-500">Real (Inflation-Adj):</span>
            <span className="font-semibold text-[#10B981]">{formatCurrency(data[hoverIndex].real)}</span>
          </div>
          {data[hoverIndex].tax !== undefined && (
            <div className="flex justify-between gap-4">
              <span className="text-slate-500">Cumulative Tax paid:</span>
              <span className="font-semibold text-red-600">{formatCurrency(data[hoverIndex].tax || 0)}</span>
            </div>
          )}
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap justify-center gap-6 mt-4 text-xs font-semibold">
        <div className="flex items-center gap-2">
          <span className="w-4 h-1 bg-[#0A192F] inline-block rounded-full" />
          <span className="text-slate-700 dark:text-slate-300">Nominal Assets</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-4 h-1 border-b-2 border-dashed border-[#10B981] inline-block" />
          <span className="text-slate-700 dark:text-slate-300">Real (Inflation-Adjusted)</span>
        </div>
        {data.some((d) => d.tax !== undefined) && (
          <div className="flex items-center gap-2">
            <span className="w-4 h-1 bg-red-500 inline-block rounded-full" />
            <span className="text-slate-700 dark:text-slate-300">Cumulative Tax Paid</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ==============================================================================
// 3. GROUPED BAR CHART FOR TAX JURISDICTIONS
// ==============================================================================
interface TaxBarData {
  label: string;
  regimeA: number;
  regimeB: number;
}

export function TaxGroupedBarChart({ data }: { data: TaxBarData[] }) {
  const maxVal = Math.max(...data.map((d) => Math.max(d.regimeA, d.regimeB))) * 1.1 || 1000;
  const padding = { top: 20, right: 20, bottom: 30, left: 60 };
  const width = 500;
  const height = 240;

  const barWidth = 35;
  const groupSpacing = 70;

  const getBarHeight = (val: number) => ((val / maxVal) * (height - padding.top - padding.bottom));
  const getY = (val: number) => height - padding.bottom - getBarHeight(val);

  return (
    <div className="w-full">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
        {/* Grids */}
        {[0, maxVal * 0.25, maxVal * 0.5, maxVal * 0.75, maxVal].map((tick, idx) => (
          <g key={idx} className="opacity-40">
            <line
              x1={padding.left}
              y1={getY(tick)}
              x2={width - padding.right}
              y2={getY(tick)}
              stroke="#CBD5E1"
              strokeDasharray="4 4"
            />
            <text x={padding.left - 8} y={getY(tick) + 4} textAnchor="end" className="fill-slate-500 text-[10px] font-semibold">
              {formatCurrency(tick)}
            </text>
          </g>
        ))}

        {/* Bars */}
        {data.map((group, idx) => {
          const groupCenterX = padding.left + (idx + 0.5) * ((width - padding.left - padding.right) / data.length);
          const xA = groupCenterX - barWidth - 2;
          const xB = groupCenterX + 2;

          return (
            <g key={idx}>
              {/* Regime A bar (Red/Grey baselines) */}
              <rect
                x={xA}
                y={getY(group.regimeA)}
                width={barWidth}
                height={Math.max(2, getBarHeight(group.regimeA))}
                fill="#EF4444"
                rx="4"
              />
              <text x={xA + barWidth/2} y={getY(group.regimeA) - 6} textAnchor="middle" className="text-[9px] fill-red-600 font-bold">
                {formatCurrency(group.regimeA)}
              </text>

              {/* Regime B bar (Emerald preservation) */}
              <rect
                x={xB}
                y={getY(group.regimeB)}
                width={barWidth}
                height={Math.max(2, getBarHeight(group.regimeB))}
                fill="#10B981"
                rx="4"
              />
              <text x={xB + barWidth/2} y={getY(group.regimeB) - 6} textAnchor="middle" className="text-[9px] fill-emerald-700 font-bold">
                {formatCurrency(group.regimeB)}
              </text>

              {/* Group X label */}
              <text x={groupCenterX} y={height - 8} textAnchor="middle" className="fill-slate-700 dark:fill-slate-300 text-[11px] font-bold">
                {group.label}
              </text>
            </g>
          );
        })}
      </svg>

      <div className="flex justify-center gap-6 mt-4 text-xs font-semibold">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-red-500 rounded-sm" />
          <span className="text-slate-700 dark:text-slate-300">Baseline Regime A</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-[#10B981] rounded-sm" />
          <span className="text-slate-700 dark:text-slate-300">Preserved Regime B</span>
        </div>
      </div>
    </div>
  );
}

// ==============================================================================
// 4. STOCHASTIC FAN CHART
// ==============================================================================
interface FanChartProps {
  years: number[];
  p10: number[];
  p25: number[];
  p50: number[];
  p75: number[];
  p90: number[];
}

export function MonteCarloFanChart({ data }: { data: FanChartProps }) {
  const [hoverYear, setHoverYear] = useState<number | null>(null);

  const padding = { top: 20, right: 20, bottom: 30, left: 60 };
  const width = 500;
  const height = 280;

  const maxVal = Math.max(...data.p90) * 1.05 || 1000;
  const maxYear = data.years[data.years.length - 1] || 30;

  const getX = (year: number) => padding.left + (year / maxYear) * (width - padding.left - padding.right);
  const getY = (val: number) => height - padding.bottom - (val / maxVal) * (height - padding.top - padding.bottom);

  // Build shaded polygon strings
  // P10 to P90 polygon
  const p10to90Points = [
    ...data.years.map((y, idx) => `${getX(y)},${getY(data.p90[idx])}`),
    ...data.years.slice().reverse().map((y, idx) => {
      const revIdx = data.years.length - 1 - idx;
      return `${getX(y)},${getY(data.p10[revIdx])}`;
    })
  ].join(" ");

  // P25 to P75 polygon
  const p25to75Points = [
    ...data.years.map((y, idx) => `${getX(y)},${getY(data.p75[idx])}`),
    ...data.years.slice().reverse().map((y, idx) => {
      const revIdx = data.years.length - 1 - idx;
      return `${getX(y)},${getY(data.p25[revIdx])}`;
    })
  ].join(" ");

  // Median line
  const p50Path = data.years
    .map((y, idx) => `${getX(y)},${getY(data.p50[idx])}`)
    .reduce((acc, curr, i) => (i === 0 ? `M ${curr}` : `${acc} L ${curr}`), "");

  return (
    <div className="relative w-full">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
        {/* Grids */}
        {[0, maxVal * 0.25, maxVal * 0.5, maxVal * 0.75, maxVal].map((tick, idx) => (
          <g key={idx} className="opacity-40">
            <line x1={padding.left} y1={getY(tick)} x2={width - padding.right} y2={getY(tick)} stroke="#CBD5E1" strokeDasharray="4 4" />
            <text x={padding.left - 8} y={getY(tick) + 4} textAnchor="end" className="fill-slate-500 text-[10px] font-semibold">
              {formatCurrency(tick)}
            </text>
          </g>
        ))}

        {data.years.filter((_, i) => i % 5 === 0).map((yr, idx) => (
          <g key={idx}>
            <text x={getX(yr)} y={height - 10} textAnchor="middle" className="fill-slate-500 text-[10px] font-semibold">
              Yr {yr}
            </text>
          </g>
        ))}

        {/* Polygons */}
        <polygon points={p10to90Points} fill="rgba(16, 185, 129, 0.08)" />
        <polygon points={p25to75Points} fill="rgba(16, 185, 129, 0.18)" />

        {/* Median Line */}
        <path d={p50Path} fill="none" stroke="#10B981" strokeWidth="3" strokeLinecap="round" />

        {/* Hover elements */}
        {data.years.map((yr, idx) => (
          <g key={idx} onMouseEnter={() => setHoverYear(yr)} onMouseLeave={() => setHoverYear(null)} className="cursor-pointer">
            <rect x={getX(yr) - 8} y={padding.top} width="16" height={height - padding.top - padding.bottom} fill="transparent" />
            {hoverYear === yr && (
              <g>
                <line x1={getX(yr)} y1={padding.top} x2={getX(yr)} y2={height - padding.bottom} stroke="#94A3B8" strokeWidth="1.5" />
                <circle cx={getX(yr)} cy={getY(data.p50[idx])} r="5" fill="#10B981" />
              </g>
            )}
          </g>
        ))}
      </svg>

      {hoverYear !== null && (
        <div className="absolute top-4 right-4 bg-white dark:bg-slate-800 p-3 rounded-lg shadow-xl border border-slate-200 dark:border-slate-700 text-xs flex flex-col gap-1 z-10 min-w-48">
          <p className="font-bold text-slate-800 dark:text-white border-b pb-1 mb-1">Year {hoverYear} Probability</p>
          <div className="flex justify-between gap-4">
            <span className="text-slate-400">90% chance (Optimistic):</span>
            <span className="font-semibold text-slate-900 dark:text-white">{formatCurrency(data.p90[data.years.indexOf(hoverYear)])}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-slate-400">75% chance (Structured):</span>
            <span className="font-semibold text-slate-900 dark:text-white">{formatCurrency(data.p75[data.years.indexOf(hoverYear)])}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-slate-500 font-bold">50% chance (Median):</span>
            <span className="font-bold text-[#10B981]">{formatCurrency(data.p50[data.years.indexOf(hoverYear)])}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-slate-400">25% chance (Defensive):</span>
            <span className="font-semibold text-slate-900 dark:text-white">{formatCurrency(data.p25[data.years.indexOf(hoverYear)])}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-slate-400">10% chance (Severe):</span>
            <span className="font-semibold text-red-600">{formatCurrency(data.p10[data.years.indexOf(hoverYear)])}</span>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap justify-center gap-4 mt-3 text-[10px] font-bold uppercase tracking-wider text-slate-500">
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 bg-[rgba(16,185,129,0.08)] border border-[rgba(16,185,129,0.18)]" />
          <span>Severe to Optimistic Bound (10th - 90th)</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 bg-[rgba(16,185,129,0.22)] border border-[rgba(16,185,129,0.3)]" />
          <span>Interquartile range (25th - 75th)</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-4 h-1 bg-[#10B981]" />
          <span className="text-emerald-600">50th Percentile (Median Path)</span>
        </div>
      </div>
    </div>
  );
}

// ==============================================================================
// 5. TERMINAL HISTOGRAM
// ==============================================================================
export function TerminalHistogram({ values }: { values: number[] }) {
  if (!values || values.length === 0) return null;
  const minVal = Math.min(...values);
  const maxVal = Math.max(...values);
  const binCount = 15;
  const binWidth = (maxVal - minVal) / binCount;

  const bins = Array.from({ length: binCount }, () => 0);
  values.forEach((v) => {
    let binIdx = Math.floor((v - minVal) / (binWidth || 1));
    if (binIdx >= binCount) binIdx = binCount - 1;
    if (binIdx < 0) binIdx = 0;
    bins[binIdx]++;
  });

  const maxBinCount = Math.max(...bins) || 1;
  const padding = { top: 15, right: 10, bottom: 25, left: 35 };
  const width = 240;
  const height = 180;

  const getX = (binIdx: number) => padding.left + (binIdx / binCount) * (width - padding.left - padding.right);
  const getY = (count: number) => height - padding.bottom - (count / maxBinCount) * (height - padding.top - padding.bottom);

  return (
    <div className="w-full h-full">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
        {bins.map((count, idx) => {
          const x = getX(idx);
          const barWidth = (width - padding.left - padding.right) / binCount - 2;
          const y = getY(count);
          const barHeight = height - padding.bottom - y;

          return (
            <g key={idx}>
              <rect x={x} y={y} width={barWidth} height={Math.max(1, barHeight)} fill="#0A192F" rx="2" />
            </g>
          );
        })}
        {/* Horizontal baseline */}
        <line x1={padding.left} y1={height - padding.bottom} x2={width - padding.right} y2={height - padding.bottom} stroke="#94A3B8" />
        <text x={padding.left} y={height - 8} textAnchor="start" className="fill-slate-500 text-[8px] font-bold">
          {formatCurrency(minVal)}
        </text>
        <text x={width - padding.right} y={height - 8} textAnchor="end" className="fill-slate-500 text-[8px] font-bold">
          {formatCurrency(maxVal)}
        </text>
      </svg>
    </div>
  );
}

// ==============================================================================
// 6. SCATTER PLOT
// ==============================================================================
interface ScatterPoint {
  label: string;
  x: number; // Volatility in %
  y: number; // Return in %
}

export function RiskReturnScatter({ points }: { points: ScatterPoint[] }) {
  const padding = { top: 20, right: 30, bottom: 35, left: 45 };
  const width = 340;
  const height = 240;

  const maxX = Math.max(...points.map((p) => p.x)) * 1.1 || 20;
  const maxY = Math.max(...points.map((p) => p.y)) * 1.1 || 10;

  const getX = (val: number) => padding.left + (val / maxX) * (width - padding.left - padding.right);
  const getY = (val: number) => height - padding.bottom - (val / maxY) * (height - padding.top - padding.bottom);

  return (
    <div className="w-full h-full">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full overflow-visible">
        {/* Grids */}
        {[0, maxY * 0.25, maxY * 0.5, maxY * 0.75, maxY].map((tick, idx) => (
          <g key={idx} className="opacity-40">
            <line x1={padding.left} y1={getY(tick)} x2={width - padding.right} y2={getY(tick)} stroke="#CBD5E1" strokeDasharray="3 3" />
            <text x={padding.left - 6} y={getY(tick) + 3} textAnchor="end" className="fill-slate-500 text-[8px] font-bold">
              {tick.toFixed(1)}%
            </text>
          </g>
        ))}

        {/* X axis ticks */}
        {[0, maxX * 0.25, maxX * 0.5, maxX * 0.75, maxX].map((tick, idx) => (
          <text key={idx} x={getX(tick)} y={height - 8} textAnchor="middle" className="fill-slate-500 text-[8px] font-bold">
            {tick.toFixed(0)}% Vol
          </text>
        ))}

        {/* Scatter Points */}
        {points.map((pt, idx) => (
          <g key={idx} className="group cursor-pointer">
            <circle cx={getX(pt.x)} cy={getY(pt.y)} r="6" fill="#10B981" className="transition-all hover:r-8" />
            <text x={getX(pt.x)} y={getY(pt.y) - 10} textAnchor="middle" className="fill-slate-700 dark:fill-slate-300 text-[8px] font-bold uppercase tracking-wide">
              {pt.label}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}
