/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CalculatorState, AnnualProjectionRow, TaxRegime, MonteCarloSummary } from "../types";

export const initialCalculatorState: CalculatorState = {
  personal: {
    name: "Marcus Aurelius",
    age: 45,
    retirementAge: 65,
    country: "United Kingdom",
    residence: "United Kingdom",
    taxResidence: "Isle of Man",
    currency: "GBP",
    maritalStatus: "Married",
    children: 2,
    riskTolerance: "Balanced",
  },
  income: {
    salary: 180000,
    bonus: 45000,
    dividendIncome: 25000,
    interest: 8000,
    rentalIncome: 36000,
    foreignIncome: 0,
    businessIncome: 0,
    otherIncome: 0,
  },
  business: {
    profit: 120000,
    corpTaxRate: 0,
    dividends: 30000,
    directorshipIncome: 15000,
    shareholdingPct: 100,
    exitValue: 2500000,
    exitYear: 10,
    hasExitPlan: false,
  },
  investments: {
    stocks: 1200000,
    bonds: 600000,
    cash: 150000,
    gold: 100000,
    privateEquity: 200000,
    expectedReturn: 6.5,
    volatility: 11.2,
    inflation: 2.5,
  },
  property: {
    primaryValue: 850000,
    investmentValue: 450000,
    mortgage: 300000,
    rentalIncome: 18000,
    maintenance: 12000,
    growthRate: 4.2,
  },
  pension: {
    value: 450000,
    annualContributions: 20000,
    retirementIncome: 0,
    expectedGrowth: 5.5,
  },
  bitcoin: {
    holdings: 4.5,
    purchasePrice: 45000,
    annualPurchases: 15000,
    expectedCAGR: 18.0,
  },
  regimeA: {
    personalAllowance: 12570,
    incomeTaxRate: 0.20,
    higherIncomeTaxRate: 0.40,
    higherIncomeThreshold: 37700,
    capitalGainsRate: 0.20,
    capitalGainsAllowance: 3000,
    dividendRate: 0.0875,
    corporationTaxRate: 0.19,
    wealthTaxRate: 0.00,
    wealthTaxThreshold: 1000000,
  },
  regimeB: {
    personalAllowance: 14500,
    incomeTaxRate: 0.10,
    higherIncomeTaxRate: 0.20,
    higherIncomeThreshold: 20000,
    capitalGainsRate: 0.00,
    capitalGainsAllowance: 10000,
    dividendRate: 0.00,
    corporationTaxRate: 0.00,
    wealthTaxRate: 0.00,
    wealthTaxThreshold: 1000000,
  },
};

export function calculateIncomeTax(income: number, regime: TaxRegime) {
  const allowance = Math.min(income, regime.personalAllowance);
  const taxable = Math.max(0, income - allowance);
  let taxPaid = 0;

  if (taxable > 0) {
    if (taxable <= regime.higherIncomeThreshold) {
      taxPaid = taxable * regime.incomeTaxRate;
    } else {
      taxPaid = regime.higherIncomeThreshold * regime.incomeTaxRate;
      taxPaid += (taxable - regime.higherIncomeThreshold) * regime.higherIncomeTaxRate;
    }
  }

  return {
    gross: income,
    allowance,
    taxable,
    taxPaid,
    net: income - taxPaid,
    effectiveRate: income > 0 ? taxPaid / income : 0,
  };
}

export function calculateDividendTax(dividends: number, regime: TaxRegime) {
  const taxPaid = dividends * regime.dividendRate;
  return {
    gross: dividends,
    taxPaid,
    net: dividends - taxPaid,
  };
}

export function projectWealth(state: CalculatorState, regime: TaxRegime, horizon = 40): AnnualProjectionRow[] {
  const inflationRate = state.investments.inflation / 100;

  // Initial asset values
  let stocks = state.investments.stocks;
  let bonds = state.investments.bonds;
  let cash = state.investments.cash;
  let gold = state.investments.gold;
  let property = state.property.primaryValue + state.property.investmentValue - state.property.mortgage;
  let pension = state.pension.value;
  let bitcoin = state.bitcoin.holdings * 80000; // current index evaluation

  const totalInitial = stocks + bonds + cash + gold + property + pension + bitcoin;

  const rows: AnnualProjectionRow[] = [{
    year: 0,
    stocks,
    bonds,
    cash,
    gold,
    property,
    pension,
    bitcoin,
    totalNominal: totalInitial,
    totalReal: totalInitial,
    annualTax: 0,
    cumulativeTax: 0,
    cumulativeContributions: 0,
  }];

  let cumulativeTax = 0;
  let cumulativeContributions = 0;

  // Annual returns
  const rStocks = state.investments.expectedReturn / 100;
  const rBonds = 0.03;
  const rCash = 0.02;
  const rGold = 0.04;
  const rProperty = state.property.growthRate / 100;
  const rPension = state.pension.expectedGrowth / 100;
  const rBitcoin = state.bitcoin.expectedCAGR / 100;

  // Contributions
  const annualCashAddition = state.pension.annualContributions + state.bitcoin.annualPurchases + 30000; // discretionary saving

  for (let t = 1; t <= horizon; t++) {
    // 1. Portfolio appreciation
    const gStocks = stocks * rStocks;
    const gBonds = bonds * rBonds;
    const gCash = cash * rCash;
    const gGold = gold * rGold;
    const gProperty = property * rProperty;
    const gPension = pension * rPension;
    const gBitcoin = bitcoin * rBitcoin;

    // 2. Add additions
    stocks = stocks + gStocks + annualCashAddition * 0.5;
    bonds = bonds + gBonds + annualCashAddition * 0.2;
    cash = cash + gCash + annualCashAddition * 0.1;
    gold = gold + gGold + annualCashAddition * 0.1;
    property = property + gProperty;
    pension = pension + gPension + state.pension.annualContributions;
    bitcoin = bitcoin + gBitcoin + state.bitcoin.annualPurchases;

    cumulativeContributions += (annualCashAddition + state.pension.annualContributions);

    // 3. Tax Drag Calculations (estimated dividend yields + turnovers)
    const divYield = 0.02;
    const dividends = stocks * divYield;
    const divTax = dividends * regime.dividendRate;

    const turnoverRate = 0.10;
    const capitalGains = stocks * turnoverRate * 0.15; // illustrative growth gain
    const cgt = Math.max(0, (capitalGains - regime.capitalGainsAllowance) * regime.capitalGainsRate);

    // Corporate tax drag (if business module active)
    const corpTax = state.business.profit * regime.corporationTaxRate;

    // Wealth tax
    const currentNom = stocks + bonds + cash + gold + property + pension + bitcoin;
    let wealthTax = 0;
    if (currentNom > regime.wealthTaxThreshold) {
      wealthTax = (currentNom - regime.wealthTaxThreshold) * regime.wealthTaxRate;
    }

    const annualTax = divTax + cgt + corpTax + wealthTax;
    cumulativeTax += annualTax;

    // Deduct tax from liquid cash or equities
    if (cash >= annualTax) {
      cash -= annualTax;
    } else {
      const overflow = annualTax - cash;
      cash = 0;
      stocks = Math.max(0, stocks - overflow);
    }

    const totalNominal = stocks + bonds + cash + gold + property + pension + bitcoin;
    const totalReal = totalNominal / Math.pow(1 + inflationRate, t);

    rows.push({
      year: t,
      stocks,
      bonds,
      cash,
      gold,
      property,
      pension,
      bitcoin,
      totalNominal,
      totalReal,
      annualTax,
      cumulativeTax,
      cumulativeContributions,
    });
  }

  return rows;
}

export function runMonteCarlo(
  initialWealth: number,
  annualSavings: number,
  expectedReturn: number, // e.g. 0.075
  volatility: number,     // e.g. 0.115
  inflationRate: number,  // e.g. 0.025
  taxDrag: number,        // e.g. 0.01
  horizon = 30,
  nSims = 1000
): MonteCarloSummary {
  
  const years = Array.from({ length: horizon + 1 }, (_, i) => i);
  const paths: number[][] = Array.from({ length: horizon + 1 }, () => new Array(nSims).fill(0));
  
  // Set initial assets
  for (let i = 0; i < nSims; i++) {
    paths[0][i] = initialWealth;
  }

  const mu = expectedReturn - taxDrag;
  const sigma = volatility;

  // Box-Muller transform for standard normal random variables
  function randNormal() {
    const u = 1 - Math.random(); // Converting [0,1) to (0,1]
    const v = Math.random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  }

  // Generate paths
  for (let t = 1; t <= horizon; t++) {
    const savings = annualSavings * Math.pow(1 + inflationRate, t);
    for (let i = 0; i < nSims; i++) {
      const z = randNormal();
      const annualReturn = Math.exp((mu - 0.5 * sigma * sigma) + sigma * z);
      paths[t][i] = paths[t - 1][i] * annualReturn + savings;
    }
  }

  // Real (inflation discounted) paths
  const pathsReal: number[][] = Array.from({ length: horizon + 1 }, () => new Array(nSims).fill(0));
  for (let t = 0; t <= horizon; t++) {
    const disc = Math.pow(1 + inflationRate, t);
    for (let i = 0; i < nSims; i++) {
      pathsReal[t][i] = paths[t][i] / disc;
    }
  }

  // Calculate percentiles
  const p10: number[] = [];
  const p25: number[] = [];
  const p50: number[] = [];
  const p75: number[] = [];
  const p90: number[] = [];

  for (let t = 0; t <= horizon; t++) {
    const values = [...pathsReal[t]].sort((a, b) => a - b);
    p10.push(values[Math.floor(nSims * 0.10)]);
    p25.push(values[Math.floor(nSims * 0.25)]);
    p50.push(values[Math.floor(nSims * 0.50)]);
    p75.push(values[Math.floor(nSims * 0.75)]);
    p90.push(values[Math.floor(nSims * 0.90)]);
  }

  // Success definition: terminal real assets >= initial wealth
  const terminalReal = pathsReal[horizon];
  let successCount = 0;
  for (let i = 0; i < nSims; i++) {
    if (terminalReal[i] >= initialWealth) {
      successCount++;
    }
  }

  const probPreservation = successCount / nSims;

  return {
    years,
    p10,
    p25,
    p50,
    p75,
    p90,
    probPreservation,
    medianTerminalReal: p50[horizon],
    p10TerminalReal: p10[horizon],
    p90TerminalReal: p90[horizon],
    terminalValues: terminalReal,
  };
}
