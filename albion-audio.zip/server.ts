import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import {
  MOCK_TRACKS,
  MOCK_ALBUMS,
  MOCK_ARTISTS,
  MOCK_EDITORIAL_ARTICLES,
  MOCK_COLLECTIONS,
  MOCK_ANALYTICS_DATA
} from './src/data/mockData.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const POSTGRESQL_DDL_SCHEMA = `
-- ALBION AUDIO: PostgreSQL Schema Architecture (HQ: Douglas, Isle of Man)

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Regions & Heritage
CREATE TYPE british_region AS ENUM (
  'Isle of Man', 'England', 'Scotland', 'Wales', 'Ireland', 'Cornwall', 'British Diaspora'
);

-- Users & Subscriptions
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  display_name VARCHAR(100) NOT NULL,
  location VARCHAR(100) DEFAULT 'Douglas, Isle of Man',
  membership_tier VARCHAR(50) DEFAULT 'Patron Member',
  preferred_audio_quality VARCHAR(50) DEFAULT 'FLAC 24-bit/96kHz',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Record Labels
CREATE TABLE record_labels (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  headquarters VARCHAR(100) DEFAULT 'Douglas, Isle of Man',
  founded_year INTEGER,
  catalog_code VARCHAR(20) UNIQUE
);

-- Artists
CREATE TABLE artists (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  region british_region NOT NULL,
  genre VARCHAR(100) NOT NULL,
  biography TEXT,
  image_url VARCHAR(512),
  featured_title VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Albums
CREATE TABLE albums (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(255) NOT NULL,
  artist_id UUID REFERENCES artists(id) ON DELETE CASCADE,
  label_id UUID REFERENCES record_labels(id),
  release_year INTEGER NOT NULL,
  genre VARCHAR(100) NOT NULL,
  cover_art_url VARCHAR(512) NOT NULL,
  editorial_description TEXT,
  recording_location VARCHAR(255),
  catalog_number VARCHAR(50) UNIQUE,
  is_featured BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tracks & Range Streams
CREATE TABLE tracks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  album_id UUID REFERENCES albums(id) ON DELETE CASCADE,
  artist_id UUID REFERENCES artists(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  duration_seconds INTEGER NOT NULL,
  audio_file_url VARCHAR(512) NOT NULL,
  file_size_bytes BIGINT,
  bitrate_kbps INTEGER DEFAULT 320,
  composer VARCHAR(255),
  producer VARCHAR(255),
  recording_year INTEGER,
  lyrics TEXT,
  editorial_notes TEXT,
  play_count BIGINT DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Playlists & User Library
CREATE TABLE playlists (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  is_public BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE playlist_tracks (
  playlist_id UUID REFERENCES playlists(id) ON DELETE CASCADE,
  track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  PRIMARY KEY (playlist_id, track_id)
);

-- User Favorites & Listening History
CREATE TABLE user_favorites (
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, track_id)
);

CREATE TABLE listening_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
  played_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  duration_listened_seconds INTEGER,
  completed BOOLEAN DEFAULT TRUE
);

-- Editorial Essays
CREATE TABLE editorial_essays (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(255) NOT NULL,
  subtitle VARCHAR(255),
  author VARCHAR(100) NOT NULL,
  author_role VARCHAR(100),
  category VARCHAR(50) NOT NULL,
  excerpt TEXT NOT NULL,
  content JSONB NOT NULL,
  image_url VARCHAR(512) NOT NULL,
  featured_album_id UUID REFERENCES albums(id),
  region_tag british_region,
  published_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Streaming Audit Logs
CREATE TABLE streaming_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  track_id UUID REFERENCES tracks(id),
  user_id UUID REFERENCES users(id),
  ip_address VARCHAR(45),
  bytes_served BIGINT,
  buffered_ranges JSONB,
  user_agent TEXT,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
`;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'Albion Audio Digital Streaming Engine',
      headquarters: 'Douglas, Isle of Man',
      timestamp: new Date().toISOString()
    });
  });

  app.get('/api/tracks', (_req, res) => {
    res.json(MOCK_TRACKS);
  });

  app.get('/api/albums', (_req, res) => {
    res.json(MOCK_ALBUMS);
  });

  app.get('/api/artists', (_req, res) => {
    res.json(MOCK_ARTISTS);
  });

  app.get('/api/editorial', (_req, res) => {
    res.json(MOCK_EDITORIAL_ARTICLES);
  });

  app.get('/api/collections', (_req, res) => {
    res.json(MOCK_COLLECTIONS);
  });

  app.get('/api/analytics', (_req, res) => {
    res.json({
      metrics: MOCK_ANALYTICS_DATA,
      summary: {
        totalStreams: '137,700',
        activeListeners: '36,360',
        bandwidthServedTB: '1.84 TB',
        storageCapacityGB: '12,500 GB',
        avgListeningDuration: '35.8 min'
      }
    });
  });

  app.get('/api/schema', (_req, res) => {
    res.json({
      database: 'PostgreSQL 16 (Albion Primary Cluster)',
      location: 'Douglas, Isle of Man (Isle Data Center)',
      ddl: POSTGRESQL_DDL_SCHEMA
    });
  });

  // Simulated HTTP Range Request Audio Stream metadata
  app.get('/api/audio-stream/:id', (req, res) => {
    const track = MOCK_TRACKS.find((t) => t.id === req.params.id) || MOCK_TRACKS[0];
    const range = req.headers.range || 'bytes=0-';

    res.status(206).set({
      'Content-Type': 'audio/mpeg',
      'Accept-Ranges': 'bytes',
      'Content-Range': `bytes 0-1048575/1048576`,
      'Content-Length': '1048576',
      'X-Albion-Stream-Codec': 'MP3 320kbps Lossless Source',
      'X-Albion-HQ': 'Douglas, Isle of Man'
    });

    res.json({
      trackId: track.id,
      title: track.title,
      streamUrl: track.audioUrl,
      rangeAccepted: range,
      bitrate: '320kbps'
    });
  });

  // Vite development vs production static setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Albion Audio Server running at http://0.0.0.0:${PORT} (Douglas, Isle of Man)`);
  });
}

startServer();
