import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { FeaturedReleases } from './components/FeaturedReleases';
import { CuratedCollections } from './components/CuratedCollections';
import { EditorialView } from './components/EditorialView';
import { MusicLibraryView } from './components/MusicLibraryView';
import { AnalyticsView } from './components/AnalyticsView';
import { AdminCMS } from './components/AdminCMS';
import { TechSchemaView } from './components/TechSchemaView';
import { AudioPlayer } from './components/AudioPlayer';
import { SearchModal } from './components/SearchModal';
import { AlbumDetailModal } from './components/AlbumDetailModal';
import { UserAccountModal } from './components/UserAccountModal';

import {
  MOCK_TRACKS,
  MOCK_ALBUMS,
  MOCK_ARTISTS,
  MOCK_EDITORIAL_ARTICLES,
  MOCK_COLLECTIONS,
  MOCK_USER_PROFILE,
  MOCK_ANALYTICS_DATA
} from './data/mockData';

import { Track, Album, Artist, Playlist, CuratedCollection, UserProfile } from './types';
import { globalAudioEngine } from './audio/AudioEngine';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('discover');
  
  // Data States
  const [tracks, setTracks] = useState<Track[]>(MOCK_TRACKS);
  const [albums, setAlbums] = useState<Album[]>(MOCK_ALBUMS);
  const [artists] = useState<Artist[]>(MOCK_ARTISTS);
  const [articles] = useState(MOCK_EDITORIAL_ARTICLES);
  const [collections] = useState<CuratedCollection[]>(MOCK_COLLECTIONS);
  const [userProfile, setUserProfile] = useState<UserProfile>(MOCK_USER_PROFILE);

  const [playlists, setPlaylists] = useState<Playlist[]>([
    {
      id: 'pl-01',
      title: 'Irish Sea Coastal Chamber Suite',
      description: 'Acoustic harps and strings recorded in Douglas & Peel Castle.',
      createdAt: '2026-08-01',
      tracks: [MOCK_TRACKS[0], MOCK_TRACKS[1]]
    },
    {
      id: 'pl-02',
      title: 'Yorkshire Industrial Synthesizers',
      description: 'Minimalist electronic loops and cold analog recordings from Sheffield.',
      createdAt: '2026-08-03',
      tracks: [MOCK_TRACKS[2], MOCK_TRACKS[3]]
    }
  ]);

  // Modal States
  const [searchOpen, setSearchOpen] = useState(false);
  const [userAccountOpen, setUserAccountOpen] = useState(false);
  const [selectedAlbumModal, setSelectedAlbumModal] = useState<Album | null>(null);

  // Audio Engine State for Navbar status
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrackTitle, setCurrentTrackTitle] = useState<string | undefined>();

  useEffect(() => {
    const unsub = globalAudioEngine.subscribe(() => {
      setIsPlaying(globalAudioEngine.isPlaying);
      setCurrentTrackTitle(globalAudioEngine.currentTrack?.title);
    });
    return unsub;
  }, []);

  // Global ⌘K shortcut listener for Search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Audio Stream Actions
  const handlePlayTrack = (track: Track) => {
    globalAudioEngine.setQueue(tracks, tracks.findIndex((t) => t.id === track.id));
  };

  const handlePlayAlbum = (album: Album) => {
    if (album.tracks.length > 0) {
      globalAudioEngine.setQueue(album.tracks, 0);
    }
  };

  const handlePlayCollection = (col: CuratedCollection) => {
    if (col.featuredTracks.length > 0) {
      globalAudioEngine.setQueue(col.featuredTracks, 0);
    }
  };

  // Admin CMS additions
  const handleAddTrack = (newTrack: Track) => {
    setTracks([newTrack, ...tracks]);
  };

  const handleAddAlbum = (newAlbum: Album) => {
    setAlbums([newAlbum, ...albums]);
  };

  // Playlist management
  const handleCreatePlaylist = (title: string, description: string) => {
    const newPl: Playlist = {
      id: `pl-${Date.now()}`,
      title,
      description,
      createdAt: new Date().toISOString().split('T')[0],
      tracks: [tracks[0]]
    };
    setPlaylists([newPl, ...playlists]);
  };

  const handleDeletePlaylist = (id: string) => {
    setPlaylists(playlists.filter((p) => p.id !== id));
  };

  const handleRemoveTrackFromPlaylist = (playlistId: string, trackId: string) => {
    setPlaylists(
      playlists.map((p) => {
        if (p.id === playlistId) {
          return { ...p, tracks: p.tracks.filter((t) => t.id !== trackId) };
        }
        return p;
      })
    );
  };

  const favoriteTracks = tracks.filter((t) => t.isFavorite);

  return (
    <div className="min-h-screen bg-[#F5F2ED] text-[#0A1128] flex flex-col font-sans pb-28">
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenSearch={() => setSearchOpen(true)}
        onOpenUserAccount={() => setUserAccountOpen(true)}
        isPlaying={isPlaying}
        currentTrackTitle={currentTrackTitle}
      />

      {/* Primary Page Views */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {activeTab === 'discover' && (
          <div className="space-y-12 sm:space-y-16">
            <HeroBanner
              featuredTrack={tracks[0]}
              onPlayFeatured={handlePlayTrack}
              onExploreCollections={() => setActiveTab('collections')}
              onReadEditorial={() => setActiveTab('editorial')}
            />

            <FeaturedReleases
              albums={albums}
              artists={artists}
              tracks={tracks}
              onPlayTrack={handlePlayTrack}
              onPlayAlbum={handlePlayAlbum}
              onSelectAlbum={(alb) => setSelectedAlbumModal(alb)}
              onSelectArtist={() => setActiveTab('discover')}
            />
          </div>
        )}

        {activeTab === 'collections' && (
          <CuratedCollections
            collections={collections}
            onPlayCollection={handlePlayCollection}
            onPlayTrack={handlePlayTrack}
          />
        )}

        {activeTab === 'editorial' && (
          <EditorialView
            articles={articles}
            albums={albums}
            onPlayAlbum={handlePlayAlbum}
          />
        )}

        {activeTab === 'library' && (
          <MusicLibraryView
            favoriteTracks={favoriteTracks}
            savedAlbums={albums.slice(0, 3)}
            playlists={playlists}
            allTracks={tracks}
            onPlayTrack={handlePlayTrack}
            onPlayAlbum={handlePlayAlbum}
            onCreatePlaylist={handleCreatePlaylist}
            onDeletePlaylist={handleDeletePlaylist}
            onRemoveTrackFromPlaylist={handleRemoveTrackFromPlaylist}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView analyticsData={MOCK_ANALYTICS_DATA} />
        )}

        {activeTab === 'admin' && (
          <AdminCMS
            tracks={tracks}
            albums={albums}
            artists={artists}
            articles={articles}
            onAddTrack={handleAddTrack}
            onAddAlbum={handleAddAlbum}
          />
        )}

        {activeTab === 'schema' && <TechSchemaView />}
      </main>

      {/* Persistent Audio Player */}
      <AudioPlayer />

      {/* Modals */}
      <SearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        tracks={tracks}
        albums={albums}
        artists={artists}
        articles={articles}
        collections={collections}
        onPlayTrack={handlePlayTrack}
        onSelectAlbum={(alb) => setSelectedAlbumModal(alb)}
        onSelectArtist={() => setActiveTab('discover')}
      />

      <AlbumDetailModal
        album={selectedAlbumModal}
        onClose={() => setSelectedAlbumModal(null)}
        onPlayAlbum={handlePlayAlbum}
        onPlayTrack={handlePlayTrack}
      />

      <UserAccountModal
        isOpen={userAccountOpen}
        onClose={() => setUserAccountOpen(false)}
        userProfile={userProfile}
        onUpdateProfile={setUserProfile}
      />
    </div>
  );
}
