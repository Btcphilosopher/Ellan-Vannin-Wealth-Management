export interface Track {
  id: string;
  title: string;
  artistId: string;
  artistName: string;
  albumId: string;
  albumTitle: string;
  coverArt: string;
  duration: number; // in seconds
  audioUrl: string;
  year: number;
  composer: string;
  producer: string;
  label: string;
  genre: string;
  region: 'Isle of Man' | 'England' | 'Scotland' | 'Wales' | 'Ireland' | 'Cornwall' | 'British Diaspora';
  lyrics?: string;
  editorialNotes?: string;
  playCount: number;
  isFavorite?: boolean;
}

export interface Album {
  id: string;
  title: string;
  artistId: string;
  artistName: string;
  coverArt: string;
  releaseYear: number;
  genre: string;
  label: string;
  tracks: Track[];
  editorialDescription: string;
  composer?: string;
  producer?: string;
  recordingLocation?: string;
  catalogNumber: string;
  featured?: boolean;
}

export interface Artist {
  id: string;
  name: string;
  region: string;
  genre: string;
  imageUrl: string;
  biography: string;
  featuredYear: string;
  discography: {
    albumId: string;
    title: string;
    year: number;
    coverArt: string;
  }[];
  relatedArtistIds: string[];
}

export interface EditorialArticle {
  id: string;
  title: string;
  subtitle: string;
  author: string;
  authorRole: string;
  date: string;
  readTime: string;
  category: 'Essay' | 'Biography' | 'History' | 'Interview' | 'Review' | 'Archive';
  imageUrl: string;
  imageCaption?: string;
  excerpt: string;
  content: string[]; // paragraphs
  featuredAlbumId?: string;
  regionTag: string;
}

export interface CuratedCollection {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  coverImage: string;
  region: string;
  trackCount: number;
  featuredTracks: Track[];
  tags: string[];
}

export interface Playlist {
  id: string;
  title: string;
  description: string;
  createdAt: string;
  tracks: Track[];
  isCustom?: boolean;
}

export interface UserProfile {
  name: string;
  location: string;
  joinedDate: string;
  membershipTier: 'Fellow Listener' | 'Patron Member' | 'Archival Sponsor';
  preferredAudioQuality: 'FLAC 24-bit/96kHz' | '320kbps High MP3' | '192kbps Standard MP3';
  themeAccent: 'Forest Green' | 'Deep Navy' | 'Bronze Ochre';
  autoPlayNext: boolean;
  crossfade: number;
}

export interface AnalyticsMetric {
  date: string;
  streams: number;
  activeListeners: number;
  bandwidthGB: number;
  avgDurationMin: number;
}
