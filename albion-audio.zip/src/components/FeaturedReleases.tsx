import React from 'react';
import { Play, Disc, Clock, Radio, Info, Heart, ListPlus } from 'lucide-react';
import { Album, Track, Artist } from '../types';

interface FeaturedReleasesProps {
  albums: Album[];
  artists: Artist[];
  tracks: Track[];
  onPlayTrack: (track: Track) => void;
  onPlayAlbum: (album: Album) => void;
  onSelectAlbum: (album: Album) => void;
  onSelectArtist: (artist: Artist) => void;
}

export const FeaturedReleases: React.FC<FeaturedReleasesProps> = ({
  albums,
  artists,
  tracks,
  onPlayTrack,
  onPlayAlbum,
  onSelectAlbum,
  onSelectArtist,
}) => {
  return (
    <div className="space-y-12 sm:space-y-16">
      
      {/* 1. Featured Archival Albums Section */}
      <section>
        <div className="flex items-end justify-between border-b border-[#0A1128]/10 pb-4 mb-6">
          <div>
            <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.2em] font-semibold block mb-1">
              CURATED DISCOGRAPHY
            </span>
            <h2 className="font-serif italic font-light text-3xl sm:text-4xl text-[#0A1128] tracking-tight">
              Featured Albums
            </h2>
          </div>
          <p className="hidden sm:block text-xs text-[#0A1128]/60 font-mono">
            Recorded in Lossless Audio
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {albums.map((album) => (
            <div
              key={album.id}
              className="group bg-[#F5F2ED] border border-[#0A1128]/10 hover:border-[#8C704B] rounded-xs p-5 transition-all duration-300 shadow-xs hover:shadow-md flex flex-col justify-between"
            >
              <div>
                {/* Artwork with Overlay Play Button */}
                <div
                  onClick={() => onSelectAlbum(album)}
                  className="relative aspect-square w-full bg-[#0A1128]/5 overflow-hidden rounded-xs cursor-pointer mb-4 border border-[#0A1128]/10"
                >
                  <img
                    src={album.coverArt}
                    alt={album.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onPlayAlbum(album);
                      }}
                      className="w-12 h-12 bg-[#F5F2ED] text-[#0A1128] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
                      title="Play entire album"
                    >
                      <Play className="w-5 h-5 fill-current ml-0.5 text-[#0A1128]" />
                    </button>
                  </div>

                  <span className="absolute top-2 left-2 bg-[#0A1128]/90 text-[#F5F2ED] text-[10px] font-mono px-2 py-0.5 rounded-xs tracking-wider">
                    {album.releaseYear}
                  </span>
                </div>

                {/* Info */}
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-[0.15em] font-bold text-[#8C704B]">
                    {album.genre}
                  </span>
                  <h3
                    onClick={() => onSelectAlbum(album)}
                    className="font-serif font-semibold text-xl text-[#0A1128] group-hover:text-[#8C704B] cursor-pointer line-clamp-1 transition-colors"
                  >
                    {album.title}
                  </h3>
                  <p className="text-xs text-[#0A1128]/70 italic">{album.artistName}</p>
                  <p className="text-[11px] text-[#64748B] font-mono line-clamp-2 pt-1 leading-relaxed">
                    {album.editorialDescription}
                  </p>
                </div>
              </div>

              {/* Footer details */}
              <div className="mt-5 pt-3 border-t border-[#0A1128]/10 flex items-center justify-between text-[11px] text-[#0A1128]/60 font-mono">
                <span>{album.label}</span>
                <button
                  onClick={() => onSelectAlbum(album)}
                  className="text-[#8C704B] font-bold hover:underline flex items-center space-x-1 uppercase text-[10px] tracking-wider"
                >
                  <Info className="w-3 h-3" />
                  <span>Details</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 2. Top Archival Tracks Stream List */}
      <section>
        <div className="flex items-end justify-between border-b border-[#0A1128]/10 pb-4 mb-6">
          <div>
            <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.2em] font-semibold block mb-1">
              HIGH FIDELITY STREAMS
            </span>
            <h2 className="font-serif italic font-light text-3xl sm:text-4xl text-[#0A1128] tracking-tight">
              New Master Recordings
            </h2>
          </div>
        </div>

        <div className="bg-[#F5F2ED] border border-[#0A1128]/10 rounded-xs divide-y divide-[#0A1128]/10">
          {tracks.map((track, idx) => (
            <div
              key={track.id}
              className="p-3 sm:p-4 flex items-center justify-between hover:bg-[#EFECE6] transition-colors group"
            >
              <div className="flex items-center space-x-3 sm:space-x-4 min-w-0 flex-1">
                <span className="font-mono text-xs text-[#0A1128]/50 w-6 text-center">
                  0{idx + 1}
                </span>

                <button
                  onClick={() => onPlayTrack(track)}
                  className="relative shrink-0 w-11 h-11 bg-[#0A1128]/5 rounded-xs overflow-hidden group/btn border border-[#0A1128]/10"
                >
                  <img
                    src={track.coverArt}
                    alt={track.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover/btn:opacity-100 flex items-center justify-center transition-opacity">
                    <Play className="w-4 h-4 fill-white text-white" />
                  </div>
                </button>

                <div className="min-w-0 flex-1">
                  <h4
                    onClick={() => onPlayTrack(track)}
                    className="font-serif font-bold text-sm sm:text-base text-[#0A1128] group-hover:text-[#8C704B] cursor-pointer truncate transition-colors"
                  >
                    {track.title}
                  </h4>
                  <p className="text-xs text-[#0A1128]/70 truncate">
                    {track.artistName} • <span className="font-mono text-[#0A1128]/50">{track.albumTitle}</span>
                  </p>
                </div>
              </div>

              {/* Track Metadata & Action */}
              <div className="flex items-center space-x-4 sm:space-x-6 text-xs text-[#0A1128]/70 font-mono">
                <span className="hidden md:inline bg-[#8C704B]/10 text-[#8C704B] px-2 py-0.5 rounded-xs border border-[#8C704B]/20 font-semibold">
                  {track.region}
                </span>
                <span className="hidden sm:inline w-20 text-right">
                  {Math.floor(track.duration / 60)}:
                  {(track.duration % 60).toString().padStart(2, '0')}
                </span>
                <button
                  onClick={() => onPlayTrack(track)}
                  className="px-3.5 py-1.5 bg-[#0A1128] hover:bg-[#8C704B] text-[#F5F2ED] text-[11px] uppercase tracking-[0.1em] font-semibold rounded-xs transition-colors flex items-center space-x-1.5"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span className="hidden sm:inline">Stream</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Featured British & Celtic Artists */}
      <section>
        <div className="flex items-end justify-between border-b border-[#0A1128]/10 pb-4 mb-6">
          <div>
            <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.2em] font-semibold block mb-1">
              HERITAGE PERFORMERS
            </span>
            <h2 className="font-serif italic font-light text-3xl sm:text-4xl text-[#0A1128] tracking-tight">
              Featured Artists & Ensembles
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {artists.slice(0, 4).map((artist) => (
            <div
              key={artist.id}
              onClick={() => onSelectArtist(artist)}
              className="group bg-[#F5F2ED] border border-[#0A1128]/10 hover:border-[#8C704B] rounded-xs p-5 cursor-pointer transition-all shadow-xs hover:shadow-md text-center"
            >
              <div className="w-24 h-24 sm:w-28 sm:h-28 mx-auto rounded-full overflow-hidden border-2 border-[#0A1128]/10 group-hover:border-[#8C704B] mb-4 transition-colors">
                <img
                  src={artist.imageUrl}
                  alt={artist.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>

              <h3 className="font-serif font-bold text-base text-[#0A1128] group-hover:text-[#8C704B] line-clamp-1 transition-colors">
                {artist.name}
              </h3>
              <p className="text-xs text-[#8C704B] font-mono font-semibold mt-1">{artist.region}</p>
              <p className="text-[11px] text-[#0A1128]/60 font-mono mt-0.5">{artist.genre}</p>

              <div className="mt-3 pt-3 border-t border-[#0A1128]/10 text-[10px] text-[#0A1128]/50 font-mono">
                {artist.featuredYear}
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
