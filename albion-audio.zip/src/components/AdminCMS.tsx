import React, { useState } from 'react';
import { Sliders, Plus, Edit2, Trash2, Shield, Radio, Check, RefreshCw } from 'lucide-react';
import { Track, Album, Artist, EditorialArticle } from '../types';

interface AdminCMSProps {
  tracks: Track[];
  albums: Album[];
  artists: Artist[];
  articles: EditorialArticle[];
  onAddTrack: (track: Track) => void;
  onAddAlbum: (album: Album) => void;
}

export const AdminCMS: React.FC<AdminCMSProps> = ({
  tracks,
  albums,
  artists,
  articles,
  onAddTrack,
  onAddAlbum,
}) => {
  const [activeSection, setActiveSection] = useState<'tracks' | 'albums' | 'editorial' | 'streaming'>('tracks');
  const [showAddTrackModal, setShowAddTrackModal] = useState(false);
  const [newTrackTitle, setNewTrackTitle] = useState('');
  const [newTrackArtist, setNewTrackArtist] = useState('');
  const [newTrackGenre, setNewTrackGenre] = useState('Modern Classical');
  const [newTrackRegion, setNewTrackRegion] = useState<'Isle of Man' | 'England' | 'Scotland' | 'Wales' | 'Ireland' | 'Cornwall' | 'British Diaspora'>('Isle of Man');

  const handleCreateTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTrackTitle.trim()) return;

    const newT: Track = {
      id: `tr-${Date.now()}`,
      title: newTrackTitle.trim(),
      artistId: 'art-01',
      artistName: newTrackArtist || 'Elora Vance & The Manx Chamber Ensemble',
      albumId: 'alb-01',
      albumTitle: 'Isle of Man: Echoes Across the Iris Sea',
      coverArt: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop',
      duration: 210,
      audioUrl: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=celtic-irish-folk-music-113303.mp3',
      year: 2026,
      composer: 'Douglas Archival Composer',
      producer: 'Julian Heathcote',
      label: 'Albion Archival Records',
      genre: newTrackGenre,
      region: newTrackRegion,
      playCount: 1,
    };

    onAddTrack(newT);
    setNewTrackTitle('');
    setShowAddTrackModal(false);
  };

  return (
    <div className="space-y-8">
      {/* CMS Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#0A1128]/10 pb-6">
        <div>
          <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.2em] font-semibold block flex items-center space-x-1 mb-1">
            <Shield className="w-3.5 h-3.5 text-[#8C704B]" />
            <span>EXECUTIVE MANAGEMENT PANEL</span>
          </span>
          <h2 className="font-serif italic font-light text-3xl sm:text-4xl text-[#0A1128] tracking-tight">
            Administration & Editorial CMS
          </h2>
          <p className="text-sm text-[#0A1128]/70 mt-1 font-sans">
            Manage catalogue releases, stream bitrates, artist biographies, and editorial articles for Albion Audio.
          </p>
        </div>

        {/* Section Switcher */}
        <div className="flex items-center space-x-2 bg-[#EFECE6] p-1 rounded-xs border border-[#0A1128]/10">
          {(['tracks', 'albums', 'editorial', 'streaming'] as const).map((sec) => (
            <button
              key={sec}
              onClick={() => setActiveSection(sec)}
              className={`px-3.5 py-1.5 text-xs font-semibold uppercase tracking-[0.1em] rounded-xs transition-colors ${
                activeSection === sec ? 'bg-[#0A1128] text-[#F5F2ED]' : 'text-[#0A1128]/70 hover:text-[#0A1128]'
              }`}
            >
              {sec}
            </button>
          ))}
        </div>
      </div>

      {/* TRACKS MANAGEMENT */}
      {activeSection === 'tracks' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <p className="text-xs text-[#64748B] font-mono">
              Total Catalog Tracks: <span className="font-bold text-[#0A1128]">{tracks.length}</span>
            </p>
            <button
              onClick={() => setShowAddTrackModal(true)}
              className="px-4 py-2 bg-[#0A1128] hover:bg-[#1E3A2B] text-[#FAF9F6] text-xs font-medium rounded-xs flex items-center space-x-2"
            >
              <Plus className="w-4 h-4" />
              <span>Upload & Register Track</span>
            </button>
          </div>

          <div className="bg-[#FAF9F6] border border-[#E5E5E0] rounded-xs overflow-hidden">
            <table className="w-full text-left text-xs font-sans">
              <thead className="bg-[#F1F1EC] border-b border-[#E5E5E0] font-mono text-[#64748B] uppercase text-[10px]">
                <tr>
                  <th className="p-3">Track Title</th>
                  <th className="p-3">Artist</th>
                  <th className="p-3">Region</th>
                  <th className="p-3">Genre</th>
                  <th className="p-3">Label</th>
                  <th className="p-3 text-right">Plays</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E5E0]">
                {tracks.map((t) => (
                  <tr key={t.id} className="hover:bg-[#F1F1EC]/60 transition-colors">
                    <td className="p-3 font-serif font-bold text-[#0A1128]">{t.title}</td>
                    <td className="p-3 text-[#334155]">{t.artistName}</td>
                    <td className="p-3 font-mono text-[11px] text-[#1E3A2B]">{t.region}</td>
                    <td className="p-3 text-[#64748B]">{t.genre}</td>
                    <td className="p-3 font-mono text-[11px] text-[#64748B]">{t.label}</td>
                    <td className="p-3 text-right font-mono font-bold text-[#0A1128]">
                      {t.playCount.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ALBUMS MANAGEMENT */}
      {activeSection === 'albums' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {albums.map((alb) => (
            <div key={alb.id} className="bg-[#FAF9F6] border border-[#E5E5E0] p-4 rounded-xs space-y-3">
              <div className="flex items-center space-x-3">
                <img src={alb.coverArt} alt={alb.title} className="w-14 h-14 object-cover rounded-xs" />
                <div>
                  <h4 className="font-serif font-bold text-sm text-[#0A1128]">{alb.title}</h4>
                  <p className="text-xs text-[#64748B]">{alb.artistName}</p>
                  <p className="text-[10px] font-mono text-[#854D0E]">{alb.catalogNumber}</p>
                </div>
              </div>
              <p className="text-xs text-[#64748B] line-clamp-2">{alb.editorialDescription}</p>
            </div>
          ))}
        </div>
      )}

      {/* STREAMING CONFIGURATION */}
      {activeSection === 'streaming' && (
        <div className="bg-[#FAF9F6] border border-[#E5E5E0] p-6 rounded-xs space-y-6">
          <h3 className="font-serif font-bold text-xl text-[#0A1128]">
            HTTP Range Streaming Engine Settings (Douglas Server)
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs font-mono">
            <div className="p-4 bg-[#F1F1EC] rounded-xs space-y-2 border border-[#E5E5E0]">
              <span className="text-[#854D0E] uppercase font-bold block">Primary Audio Codec</span>
              <p className="text-[#0A1128] text-sm font-bold">FLAC 24-bit / 96kHz Lossless</p>
              <p className="text-[#64748B]">Fallback MP3 320kbps Constant Bitrate</p>
            </div>

            <div className="p-4 bg-[#F1F1EC] rounded-xs space-y-2 border border-[#E5E5E0]">
              <span className="text-[#854D0E] uppercase font-bold block">Buffer Strategy</span>
              <p className="text-[#0A1128] text-sm font-bold">Progressive HTTP Range 256KB Chunks</p>
              <p className="text-[#64748B]">Low Latency Edge CDN Active</p>
            </div>
          </div>
        </div>
      )}

      {/* Add Track Modal */}
      {showAddTrackModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#FAF9F6] border border-[#E5E5E0] rounded-xs max-w-md w-full p-6 shadow-2xl space-y-4">
            <h3 className="font-serif font-bold text-xl text-[#0A1128]">Register New Master Recording</h3>

            <form onSubmit={handleCreateTrack} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-[#64748B] mb-1">Track Title</label>
                <input
                  type="text"
                  required
                  value={newTrackTitle}
                  onChange={(e) => setNewTrackTitle(e.target.value)}
                  placeholder="e.g. Douglas Harbor Nocturne in F Major"
                  className="w-full px-3 py-2 bg-white border border-[#E5E5E0] rounded-xs text-sm text-[#0A1128]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#64748B] mb-1">Artist / Ensemble</label>
                <input
                  type="text"
                  value={newTrackArtist}
                  onChange={(e) => setNewTrackArtist(e.target.value)}
                  placeholder="Elora Vance & The Manx Chamber Ensemble"
                  className="w-full px-3 py-2 bg-white border border-[#E5E5E0] rounded-xs text-sm text-[#0A1128]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-[#64748B] mb-1">Genre</label>
                  <select
                    value={newTrackGenre}
                    onChange={(e) => setNewTrackGenre(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#E5E5E0] rounded-xs text-xs text-[#0A1128]"
                  >
                    <option value="Modern Classical">Modern Classical</option>
                    <option value="Celtic Folk">Celtic Folk</option>
                    <option value="Electronic">Electronic</option>
                    <option value="Ambient">Ambient</option>
                    <option value="Choral">Choral</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono text-[#64748B] mb-1">Region</label>
                  <select
                    value={newTrackRegion}
                    onChange={(e) => setNewTrackRegion(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white border border-[#E5E5E0] rounded-xs text-xs text-[#0A1128]"
                  >
                    <option value="Isle of Man">Isle of Man</option>
                    <option value="England">England</option>
                    <option value="Scotland">Scotland</option>
                    <option value="Wales">Wales</option>
                    <option value="Cornwall">Cornwall</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddTrackModal(false)}
                  className="px-4 py-2 bg-[#F1F1EC] text-[#334155] text-xs font-medium rounded-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#0A1128] text-[#FAF9F6] text-xs font-medium rounded-xs"
                >
                  Save & Register
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
