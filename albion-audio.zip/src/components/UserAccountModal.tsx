import React, { useState } from 'react';
import { User, Shield, MapPin, X, Check, Radio, Headphones, Sliders } from 'lucide-react';
import { UserProfile } from '../types';

interface UserAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
}

export const UserAccountModal: React.FC<UserAccountModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onUpdateProfile,
}) => {
  const [profile, setProfile] = useState<UserProfile>(userProfile);

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateProfile(profile);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-fadeIn">
      <div className="bg-[#F5F2ED] border border-[#0A1128]/20 rounded-xs max-w-md w-full shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-6 bg-[#0A1128] text-[#F5F2ED] flex items-center justify-between border-b border-[#1E293B]">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-[#8C704B] text-[#F5F2ED] rounded-xs flex items-center justify-center font-serif font-bold text-lg">
              TR
            </div>
            <div>
              <h3 className="font-serif italic font-light text-xl text-[#F5F2ED]">{profile.name}</h3>
              <p className="text-xs text-[#94A3B8] font-mono flex items-center space-x-1">
                <MapPin className="w-3 h-3 text-[#8C704B]" />
                <span>{profile.location}</span>
              </p>
            </div>
          </div>

          <button onClick={onClose} className="text-[#94A3B8] hover:text-[#F5F2ED]">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[75vh]">
          {/* Tier badge */}
          <div className="p-3 bg-[#8C704B]/10 border border-[#8C704B]/20 rounded-xs flex items-center justify-between text-xs">
            <span className="font-mono text-[#8C704B] font-bold uppercase tracking-wider">{profile.membershipTier}</span>
            <span className="text-[10px] text-[#0A1128]/60 font-mono">Joined {profile.joinedDate}</span>
          </div>

          {/* Audio Quality Setting */}
          <div className="space-y-2">
            <label className="block text-[10px] font-mono uppercase text-[#8C704B] tracking-wider font-semibold flex items-center space-x-1">
              <Headphones className="w-3.5 h-3.5" />
              <span>Streaming Audio Fidelity</span>
            </label>
            <div className="space-y-2">
              {[
                'FLAC 24-bit/96kHz',
                '320kbps High MP3',
                '192kbps Standard MP3'
              ].map((quality) => (
                <button
                  key={quality}
                  onClick={() => setProfile({ ...profile, preferredAudioQuality: quality as any })}
                  className={`w-full p-3 rounded-xs border text-left text-xs font-mono flex items-center justify-between transition-colors ${
                    profile.preferredAudioQuality === quality
                      ? 'bg-[#0A1128] text-[#F5F2ED] border-[#0A1128]'
                      : 'bg-[#F5F2ED] text-[#0A1128] border-[#0A1128]/10 hover:bg-[#EFECE6]'
                  }`}
                >
                  <span>{quality}</span>
                  {profile.preferredAudioQuality === quality && <Check className="w-4 h-4 text-[#8C704B]" />}
                </button>
              ))}
            </div>
          </div>

          {/* Auto Play Setting */}
          <div className="flex items-center justify-between pt-2">
            <div>
              <span className="text-xs font-serif font-bold text-[#0A1128] block">Autoplay Suite Continuously</span>
              <span className="text-[11px] text-[#0A1128]/60">Automatically queue recommended regional works</span>
            </div>
            <input
              type="checkbox"
              checked={profile.autoPlayNext}
              onChange={(e) => setProfile({ ...profile, autoPlayNext: e.target.checked })}
              className="w-4 h-4 accent-[#8C704B] cursor-pointer"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-[#EFECE6] border-t border-[#0A1128]/10 flex justify-end space-x-2">
          <button onClick={onClose} className="px-4 py-2 bg-[#F5F2ED] border border-[#0A1128]/10 text-[#0A1128] text-xs font-medium rounded-xs hover:bg-[#EFECE6]">
            Cancel
          </button>
          <button onClick={handleSave} className="px-4 py-2 bg-[#0A1128] hover:bg-[#8C704B] text-[#F5F2ED] text-xs font-medium uppercase tracking-wider rounded-xs transition-colors">
            Save Preferences
          </button>
        </div>
      </div>
    </div>
  );
};
