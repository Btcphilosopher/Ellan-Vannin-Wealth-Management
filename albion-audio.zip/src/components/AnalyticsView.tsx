import React from 'react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { BarChart3, Radio, HardDrive, Clock, Activity, Globe } from 'lucide-react';
import { AnalyticsMetric } from '../types';

interface AnalyticsViewProps {
  analyticsData: AnalyticsMetric[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ analyticsData }) => {
  const regionalData = [
    { name: 'Isle of Man', value: 38, color: '#8C704B' },
    { name: 'England', value: 28, color: '#0A1128' },
    { name: 'Scotland', value: 16, color: '#A3835B' },
    { name: 'Wales', value: 10, color: '#334155' },
    { name: 'Ireland', value: 8, color: '#64748B' },
  ];

  return (
    <div className="space-y-10">
      {/* Header */}
      <div className="border-b border-[#0A1128]/10 pb-6">
        <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.2em] font-semibold block mb-1">
          INSTITUTIONAL METRICS
        </span>
        <h2 className="font-serif italic font-light text-3xl sm:text-4xl text-[#0A1128] tracking-tight">
          Streaming & Listener Analytics
        </h2>
        <p className="text-sm text-[#0A1128]/70 mt-1 font-sans">
          Real-time metrics on bandwidth delivery, concurrent audio streams, and archival listener engagement.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="p-5 bg-[#F5F2ED] border border-[#0A1128]/10 rounded-xs space-y-2">
          <div className="flex items-center justify-between text-[#0A1128]/60">
            <span className="text-xs font-mono uppercase">Total Streams</span>
            <Activity className="w-4 h-4 text-[#8C704B]" />
          </div>
          <p className="font-serif font-bold text-3xl text-[#0A1128]">137,700</p>
          <span className="text-[11px] text-[#8C704B] font-mono font-semibold">+14.2% from last week</span>
        </div>

        <div className="p-5 bg-[#F5F2ED] border border-[#0A1128]/10 rounded-xs space-y-2">
          <div className="flex items-center justify-between text-[#0A1128]/60">
            <span className="text-xs font-mono uppercase">Active Listeners</span>
            <Radio className="w-4 h-4 text-[#8C704B]" />
          </div>
          <p className="font-serif font-bold text-3xl text-[#0A1128]">36,360</p>
          <span className="text-[11px] text-[#8C704B] font-mono font-semibold">6,950 Peak Concurrent</span>
        </div>

        <div className="p-5 bg-[#F5F2ED] border border-[#0A1128]/10 rounded-xs space-y-2">
          <div className="flex items-center justify-between text-[#0A1128]/60">
            <span className="text-xs font-mono uppercase">Bandwidth Served</span>
            <HardDrive className="w-4 h-4 text-[#0A1128]" />
          </div>
          <p className="font-serif font-bold text-3xl text-[#0A1128]">1.84 TB</p>
          <span className="text-[11px] text-[#0A1128] font-mono font-semibold">Lossless Audio CDN</span>
        </div>

        <div className="p-5 bg-[#F5F2ED] border border-[#0A1128]/10 rounded-xs space-y-2">
          <div className="flex items-center justify-between text-[#0A1128]/60">
            <span className="text-xs font-mono uppercase">Avg Listening Duration</span>
            <Clock className="w-4 h-4 text-[#334155]" />
          </div>
          <p className="font-serif font-bold text-3xl text-[#0A1128]">35.8 min</p>
          <span className="text-[11px] text-[#0A1128]/70 font-mono">High Session Retention</span>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Streams Timeline Chart */}
        <div className="lg:col-span-8 bg-[#F5F2ED] border border-[#0A1128]/10 p-6 rounded-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-serif font-bold text-xl text-[#0A1128]">
              Daily Audio Streams & Listeners
            </h3>
            <span className="text-xs font-mono text-[#0A1128]/60">7-Day Archival Trend</span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analyticsData}>
                <defs>
                  <linearGradient id="streamGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8C704B" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#8C704B" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#0A1128" strokeOpacity={0.1} />
                <XAxis dataKey="date" stroke="#0A1128" opacity={0.6} fontSize={11} fontFamily="monospace" />
                <YAxis stroke="#0A1128" opacity={0.6} fontSize={11} fontFamily="monospace" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0A1128', borderColor: '#8C704B', color: '#F5F2ED', borderRadius: 2 }}
                />
                <Area type="monotone" dataKey="streams" stroke="#8C704B" fillOpacity={1} fill="url(#streamGrad)" name="Audio Streams" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Regional Distribution Pie Chart */}
        <div className="lg:col-span-4 bg-[#F5F2ED] border border-[#0A1128]/10 p-6 rounded-xs space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="font-serif font-bold text-xl text-[#0A1128]">
              Regional Distribution
            </h3>
            <p className="text-xs text-[#0A1128]/60 mt-1 font-mono">
              Streams by Geographical Zone
            </p>
          </div>

          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={regionalData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} innerRadius={40}>
                  {regionalData.map((entry, idx) => (
                    <Cell key={`cell-${idx}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-1.5 pt-2 border-t border-[#0A1128]/10">
            {regionalData.map((item) => (
              <div key={item.name} className="flex items-center justify-between text-xs font-mono">
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-[#0A1128]">{item.name}</span>
                </div>
                <span className="font-bold text-[#0A1128]">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
