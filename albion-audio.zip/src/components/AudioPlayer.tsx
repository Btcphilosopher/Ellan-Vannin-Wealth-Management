import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Heart,
  ListMusic,
  Gauge,
  X,
  Info,
  MapPin,
  Music2
} from 'lucide-react';
import { Track } from '../types';
import { globalAudioEngine } from '../audio/AudioEngine';

interface AudioPlayerProps {
  onOpenTrackDetails?: (track: Track) => void;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ onOpenTrackDetails }) => {
  const [engineState, setEngineState] = useState({
    currentTrack: globalAudioEngine.currentTrack,
    isPlaying: globalAudioEngine.isPlaying,
    currentTime: globalAudioEngine.currentTime,
    duration: globalAudioEngine.duration,
    volume: globalAudioEngine.volume,
    isMuted: globalAudioEngine.isMuted,
    playbackRate: globalAudioEngine.playbackRate,
    isShuffle: globalAudioEngine.isShuffle,
    repeatMode: globalAudioEngine.repeatMode,
    bufferedProgress: globalAudioEngine.bufferedProgress,
  });

  const [isExpanded, setIsExpanded] = useState(false);
  const [showQueue, setShowQueue] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Subscribe to AudioEngine state updates
  useEffect(() => {
    const unsubscribe = globalAudioEngine.subscribe(() => {
      setEngineState({
        currentTrack: globalAudioEngine.currentTrack,
        isPlaying: globalAudioEngine.isPlaying,
        currentTime: globalAudioEngine.currentTime,
        duration: globalAudioEngine.duration,
        volume: globalAudioEngine.volume,
        isMuted: globalAudioEngine.isMuted,
        playbackRate: globalAudioEngine.playbackRate,
        isShuffle: globalAudioEngine.isShuffle,
        repeatMode: globalAudioEngine.repeatMode,
        bufferedProgress: globalAudioEngine.bufferedProgress,
      });
    });
    return unsubscribe;
  }, []);

  // Keyboard Shortcuts handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing inside an input field
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) return;

      if (e.code === 'Space') {
        e.preventDefault();
        globalAudioEngine.togglePlay();
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        globalAudioEngine.seek(Math.min(engineState.duration, engineState.currentTime + 5));
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        globalAudioEngine.seek(Math.max(0, engineState.currentTime - 5));
      } else if (e.key === 'm' || e.key === 'M') {
        globalAudioEngine.toggleMute();
      } else if (e.key === 'f' || e.key === 'F') {
        setIsExpanded((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [engineState.currentTime, engineState.duration]);

  // Audio Waveform Visualizer Canvas loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const renderWaveform = () => {
      const data = globalAudioEngine.getVisualizerData();
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const barWidth = (canvas.width / data.length) * 1.5;
      let x = 0;

      for (let i = 0; i < data.length; i++) {
        const barHeight = (data[i] / 255) * canvas.height;

        // Elegant navy & bronze gradient for waveform
        const gradient = ctx.createLinearGradient(0, canvas.height, 0, 0);
        gradient.addColorStop(0, '#0A1128');
        gradient.addColorStop(1, '#8C704B');

        ctx.fillStyle = engineState.isPlaying ? gradient : '#CBD5E1';
        ctx.fillRect(x, canvas.height - barHeight, barWidth - 1, barHeight);

        x += barWidth + 1;
      }

      animId = requestAnimationFrame(renderWaveform);
    };

    renderWaveform();
    return () => cancelAnimationFrame(animId);
  }, [engineState.isPlaying]);

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds < 0) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const currentTrack = engineState.currentTrack;

  if (!currentTrack) {
    return null; // Player appears as soon as a track is queued or played
  }

  return (
    <>
      {/* Persistent Audio Player Bar Fixed at Bottom */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#0A1128] text-[#FAF9F6] border-t border-[#1E293B] shadow-2xl transition-all">
        {/* Timeline & Buffer Progress Bar */}
        <div className="relative w-full h-1.5 bg-[#1E293B] group cursor-pointer">
          {/* Buffer Bar */}
          <div
            className="absolute top-0 bottom-0 left-0 bg-[#334155]/60 transition-all duration-300"
            style={{ width: `${engineState.bufferedProgress}%` }}
          />
          {/* Active Playback Progress Bar */}
          <div
            className="absolute top-0 bottom-0 left-0 bg-[#8C704B] group-hover:bg-[#A3835B] transition-all"
            style={{
              width: `${(engineState.currentTime / (engineState.duration || 1)) * 100}%`,
            }}
          />
          <input
            type="range"
            min={0}
            max={engineState.duration || 100}
            value={engineState.currentTime}
            onChange={(e) => globalAudioEngine.seek(parseFloat(e.target.value))}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
            aria-label="Seek track position"
          />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-2 sm:gap-4">
          {/* Left: Track Thumbnail, Title & Artist */}
          <div className="flex items-center space-x-3 min-w-0 w-1/4 sm:w-1/3">
            <button
              onClick={() => setIsExpanded(true)}
              className="relative shrink-0 group rounded-xs overflow-hidden border border-[#334155]"
            >
              <img
                src={currentTrack.coverArt}
                alt={currentTrack.title}
                className="w-12 h-12 sm:w-14 sm:h-14 object-cover group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                <Maximize2 className="w-4 h-4 text-white" />
              </div>
            </button>

            <div className="min-w-0">
              <div className="flex items-center space-x-2">
                <h4
                  onClick={() => setIsExpanded(true)}
                  className="font-serif font-bold text-sm sm:text-base text-[#FAF9F6] truncate cursor-pointer hover:underline"
                >
                  {currentTrack.title}
                </h4>
                <span className="hidden lg:inline-block text-[10px] font-mono bg-[#1E3A2B] px-1.5 py-0.5 rounded-xs text-[#FAF9F6] shrink-0">
                  {currentTrack.genre}
                </span>
              </div>
              <p className="text-xs text-[#94A3B8] truncate">{currentTrack.artistName}</p>
              <p className="hidden md:block text-[10px] text-[#64748B] font-mono truncate">
                {currentTrack.label} • {currentTrack.year}
              </p>
            </div>

            <button
              onClick={() => {
                currentTrack.isFavorite = !currentTrack.isFavorite;
                setEngineState({ ...engineState });
              }}
              className="hidden sm:block p-1.5 text-[#64748B] hover:text-[#FAF9F6] transition-colors"
              title="Save to favorites"
            >
              <Heart
                className={`w-4 h-4 ${
                  currentTrack.isFavorite ? 'fill-[#854D0E] text-[#854D0E]' : ''
                }`}
              />
            </button>
          </div>

          {/* Center: Playback Controls & Waveform */}
          <div className="flex flex-col items-center justify-center space-y-1 w-1/2 sm:w-1/3">
            <div className="flex items-center space-x-3 sm:space-x-5">
              {/* Shuffle */}
              <button
                onClick={() => globalAudioEngine.toggleShuffle()}
                className={`p-1.5 rounded-xs transition-colors ${
                  engineState.isShuffle ? 'text-[#854D0E] bg-[#1E293B]' : 'text-[#64748B] hover:text-[#FAF9F6]'
                }`}
                title="Shuffle queue"
              >
                <Shuffle className="w-3.5 h-3.5" />
              </button>

              {/* Prev */}
              <button
                onClick={() => globalAudioEngine.prevTrack()}
                className="p-1.5 text-[#94A3B8] hover:text-[#FAF9F6] transition-colors"
                title="Previous track"
              >
                <SkipBack className="w-4 h-4" />
              </button>

              {/* Play / Pause Toggle */}
              <button
                onClick={() => globalAudioEngine.togglePlay()}
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#FAF9F6] text-[#0A1128] hover:bg-[#E5E5E0] flex items-center justify-center transition-transform active:scale-95 shadow-md"
                title={engineState.isPlaying ? 'Pause' : 'Play'}
              >
                {engineState.isPlaying ? (
                  <Pause className="w-5 h-5 fill-current" />
                ) : (
                  <Play className="w-5 h-5 fill-current ml-0.5" />
                )}
              </button>

              {/* Next */}
              <button
                onClick={() => globalAudioEngine.nextTrack()}
                className="p-1.5 text-[#94A3B8] hover:text-[#FAF9F6] transition-colors"
                title="Next track"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              {/* Repeat Mode */}
              <button
                onClick={() => globalAudioEngine.cycleRepeatMode()}
                className={`p-1.5 rounded-xs transition-colors ${
                  engineState.repeatMode !== 'off'
                    ? 'text-[#854D0E] bg-[#1E293B]'
                    : 'text-[#64748B] hover:text-[#FAF9F6]'
                }`}
                title={`Repeat mode: ${engineState.repeatMode}`}
              >
                {engineState.repeatMode === 'one' ? (
                  <Repeat1 className="w-3.5 h-3.5" />
                ) : (
                  <Repeat className="w-3.5 h-3.5" />
                )}
              </button>
            </div>

            {/* Time Indicators & Waveform Canvas */}
            <div className="w-full flex items-center space-x-2 text-[11px] text-[#94A3B8] font-mono">
              <span className="w-9 text-right">{formatTime(engineState.currentTime)}</span>
              <div className="flex-1 h-3 flex items-center justify-center">
                <canvas
                  ref={canvasRef}
                  width={120}
                  height={12}
                  className="w-full h-3 max-w-[200px]"
                />
              </div>
              <span className="w-9">{formatTime(engineState.duration)}</span>
            </div>
          </div>

          {/* Right: Volume, Speed & Queue buttons */}
          <div className="flex items-center justify-end space-x-2 sm:space-x-3 w-1/4 sm:w-1/3">
            {/* Speed Selector */}
            <div className="relative hidden lg:block">
              <button
                onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                className="flex items-center space-x-1 px-2 py-1 text-xs font-mono text-[#94A3B8] hover:text-[#FAF9F6] bg-[#1E293B]/60 rounded-xs border border-[#334155]"
                title="Playback speed"
              >
                <Gauge className="w-3 h-3" />
                <span>{engineState.playbackRate}x</span>
              </button>

              {showSpeedMenu && (
                <div className="absolute bottom-full mb-2 right-0 bg-[#0A1128] border border-[#334155] rounded-xs shadow-xl py-1 w-24 text-xs z-50">
                  {[0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => (
                    <button
                      key={rate}
                      onClick={() => {
                        globalAudioEngine.setPlaybackRate(rate);
                        setShowSpeedMenu(false);
                      }}
                      className={`w-full text-left px-3 py-1 text-xs font-mono hover:bg-[#1E293B] ${
                        engineState.playbackRate === rate ? 'text-[#854D0E] font-bold' : 'text-[#FAF9F6]'
                      }`}
                    >
                      {rate}x
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Volume Control */}
            <div className="hidden sm:flex items-center space-x-1.5">
              <button
                onClick={() => globalAudioEngine.toggleMute()}
                className="text-[#94A3B8] hover:text-[#FAF9F6] p-1"
                title="Mute / Unmute"
              >
                {engineState.isMuted || engineState.volume === 0 ? (
                  <VolumeX className="w-4 h-4 text-[#E2E8F0]" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={engineState.isMuted ? 0 : engineState.volume}
                onChange={(e) => globalAudioEngine.setVolume(parseFloat(e.target.value))}
                className="w-16 lg:w-20 h-1 bg-[#334155] rounded-lg appearance-none cursor-pointer"
                aria-label="Volume slider"
              />
            </div>

            {/* Queue Toggle */}
            <button
              onClick={() => setShowQueue(!showQueue)}
              className={`p-2 rounded-xs transition-colors ${
                showQueue ? 'bg-[#1E293B] text-[#FAF9F6]' : 'text-[#94A3B8] hover:text-[#FAF9F6]'
              }`}
              title="Toggle queue"
            >
              <ListMusic className="w-4 h-4" />
            </button>

            {/* Expand Full Player */}
            <button
              onClick={() => setIsExpanded(true)}
              className="p-2 text-[#94A3B8] hover:text-[#FAF9F6] transition-colors"
              title="Expand full player"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Queue Drawer Modal */}
      {showQueue && (
        <div className="fixed bottom-16 right-4 sm:right-8 z-50 w-80 sm:w-96 max-h-96 bg-[#0A1128] text-[#FAF9F6] border border-[#334155] rounded-xs shadow-2xl overflow-hidden flex flex-col">
          <div className="p-3 bg-[#1E293B] flex items-center justify-between border-b border-[#334155]">
            <span className="font-serif font-bold text-sm">Up Next ({globalAudioEngine.queue.length})</span>
            <button onClick={() => setShowQueue(false)} className="text-[#94A3B8] hover:text-[#FAF9F6]">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="divide-y divide-[#1E293B] overflow-y-auto max-h-80">
            {globalAudioEngine.queue.map((t, idx) => (
              <div
                key={`${t.id}-${idx}`}
                onClick={() => globalAudioEngine.playTrack(t)}
                className={`p-3 flex items-center space-x-3 cursor-pointer hover:bg-[#1E293B]/70 ${
                  t.id === currentTrack.id ? 'bg-[#1E3A2B]/40 text-[#FAF9F6]' : 'text-[#94A3B8]'
                }`}
              >
                <img src={t.coverArt} alt={t.title} className="w-10 h-10 object-cover rounded-xs" />
                <div className="min-w-0 flex-1">
                  <p className="font-medium text-xs truncate text-[#FAF9F6]">{t.title}</p>
                  <p className="text-[11px] truncate text-[#94A3B8]">{t.artistName}</p>
                </div>
                <span className="text-[10px] font-mono text-[#64748B]">
                  {formatTime(t.duration)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Expanded Full-Screen Player Modal */}
      {isExpanded && (
        <div className="fixed inset-0 z-50 bg-[#0A1128]/98 backdrop-blur-xl text-[#FAF9F6] flex flex-col p-6 sm:p-12 overflow-y-auto animate-fadeIn">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[#1E293B] pb-6 mb-8">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-[#1E3A2B] flex items-center justify-center font-serif font-bold text-lg rounded-xs">
                A
              </div>
              <div>
                <h3 className="font-serif font-bold text-lg tracking-wide">ALBION AUDIO PLAYER</h3>
                <p className="text-xs text-[#94A3B8] font-mono">24-BIT / 96KHZ ARCHIVAL STREAM</p>
              </div>
            </div>

            <button
              onClick={() => setIsExpanded(false)}
              className="p-2 bg-[#1E293B] hover:bg-[#334155] rounded-full transition-colors"
            >
              <Minimize2 className="w-5 h-5 text-[#FAF9F6]" />
            </button>
          </div>

          {/* Main Expanded Layout */}
          <div className="max-w-5xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center my-auto">
            {/* Artwork Frame */}
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="relative group w-full max-w-md aspect-square bg-[#1E293B] rounded-xs shadow-2xl border border-[#334155] overflow-hidden">
                <img
                  src={currentTrack.coverArt}
                  alt={currentTrack.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex items-center space-x-2 text-xs text-[#94A3B8] font-mono pt-2">
                <MapPin className="w-3.5 h-3.5 text-[#854D0E]" />
                <span>Recorded in {currentTrack.region}</span>
              </div>
            </div>

            {/* Right: Release Notes, Lyrics & Credits */}
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono uppercase tracking-widest text-[#854D0E] bg-[#854D0E]/10 px-2.5 py-1 rounded-xs border border-[#854D0E]/20">
                  {currentTrack.genre} • {currentTrack.year}
                </span>
                <h1 className="font-serif font-bold text-3xl sm:text-4xl text-[#FAF9F6] mt-3 leading-tight">
                  {currentTrack.title}
                </h1>
                <h2 className="text-lg text-[#94A3B8] mt-1 font-serif">{currentTrack.artistName}</h2>
                <p className="text-xs text-[#64748B] font-mono mt-1">
                  Album: <span className="text-[#E2E8F0]">{currentTrack.albumTitle}</span>
                </p>
              </div>

              {/* Track Metadata Grid */}
              <div className="grid grid-cols-2 gap-4 p-4 bg-[#1E293B]/60 rounded-xs border border-[#334155] text-xs">
                <div>
                  <span className="text-[#64748B] block font-mono">Composer</span>
                  <span className="font-medium text-[#FAF9F6]">{currentTrack.composer}</span>
                </div>
                <div>
                  <span className="text-[#64748B] block font-mono">Producer</span>
                  <span className="font-medium text-[#FAF9F6]">{currentTrack.producer}</span>
                </div>
                <div>
                  <span className="text-[#64748B] block font-mono">Record Label</span>
                  <span className="font-medium text-[#FAF9F6]">{currentTrack.label}</span>
                </div>
                <div>
                  <span className="text-[#64748B] block font-mono">Archival Plays</span>
                  <span className="font-medium text-[#FAF9F6]">{currentTrack.playCount.toLocaleString()}</span>
                </div>
              </div>

              {/* Lyrics / Editorial Notes */}
              {currentTrack.lyrics && (
                <div className="p-4 bg-[#1E293B]/30 rounded-xs border border-[#334155]/60 max-h-44 overflow-y-auto">
                  <h4 className="text-xs font-mono uppercase text-[#854D0E] mb-2">Lyrics & Verse</h4>
                  <pre className="font-serif text-sm text-[#E2E8F0] whitespace-pre-wrap leading-relaxed italic">
                    {currentTrack.lyrics}
                  </pre>
                </div>
              )}

              {currentTrack.editorialNotes && (
                <div className="p-4 bg-[#1E293B]/30 rounded-xs border border-[#334155]/60">
                  <h4 className="text-xs font-mono uppercase text-[#854D0E] mb-1 flex items-center space-x-1">
                    <Info className="w-3.5 h-3.5" />
                    <span>Archival Notes</span>
                  </h4>
                  <p className="text-xs text-[#94A3B8] leading-relaxed">
                    {currentTrack.editorialNotes}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
