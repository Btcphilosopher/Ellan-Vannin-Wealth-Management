import React from 'react';
import { Play, Compass, BookOpen, ShieldCheck, Landmark } from 'lucide-react';
import { Track } from '../types';

interface HeroBannerProps {
  featuredTrack: Track;
  onPlayFeatured: (track: Track) => void;
  onExploreCollections: () => void;
  onReadEditorial: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  featuredTrack,
  onPlayFeatured,
  onExploreCollections,
  onReadEditorial,
}) => {
  return (
    <section className="relative bg-[#0A1128] text-[#FAF9F6] border-b border-[#1E293B] overflow-hidden">
      {/* Background Architectural Grid Overlay */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#FAF9F6_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Institutional Statement */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Headquarters & Seal Badge */}
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#0A1128] text-[#F5F2ED] text-[10px] font-mono uppercase tracking-[0.2em] rounded-xs border border-[#8C704B]/30">
              <Landmark className="w-3.5 h-3.5 text-[#8C704B]" />
              <span>ISLE OF MAN ARCHIVAL TRUST • DOUGLAS</span>
            </div>

            {/* Main Heading */}
            <h1 className="font-serif italic font-light text-4xl sm:text-5xl lg:text-6xl tracking-tight text-[#F5F2ED] leading-[1.1]">
              Music for the Isles.
            </h1>

            {/* Editorial Lead Paragraph */}
            <p className="text-base sm:text-lg text-[#CBD5E1] font-sans leading-relaxed max-w-2xl font-normal opacity-90">
              Albion Audio is a digital cultural repository and streaming platform headquartered on the Isle of Man. Preserving centuries of acoustic, classical, folk, and electronic recordings from Britain and the Celtic nations.
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => onPlayFeatured(featuredTrack)}
                className="flex items-center space-x-3 px-6 py-3 bg-[#F5F2ED] text-[#0A1128] hover:bg-[#8C704B] hover:text-[#F5F2ED] font-semibold text-xs sm:text-sm uppercase tracking-[0.12em] rounded-xs transition-colors shadow-md"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Stream Featured Suite</span>
              </button>

              <button
                onClick={onExploreCollections}
                className="flex items-center space-x-2 px-5 py-3 bg-[#1E293B] hover:bg-[#334155] text-[#F5F2ED] font-semibold text-xs sm:text-sm uppercase tracking-[0.12em] rounded-xs border border-[#334155] transition-colors"
              >
                <Compass className="w-4 h-4 text-[#8C704B]" />
                <span>Explore Collections</span>
              </button>

              <button
                onClick={onReadEditorial}
                className="flex items-center space-x-2 px-5 py-3 bg-transparent hover:bg-[#1E293B]/60 text-[#CBD5E1] hover:text-[#F5F2ED] font-semibold text-xs sm:text-sm uppercase tracking-[0.12em] rounded-xs transition-colors"
              >
                <BookOpen className="w-4 h-4 text-[#8C704B]" />
                <span>Editorial Essays</span>
              </button>
            </div>

            {/* Institutional Trust Guarantees */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-[#1E293B] text-xs font-mono text-[#94A3B8]">
              <div>
                <span className="block text-[#FAF9F6] font-bold text-sm">24-BIT / 96KHZ</span>
                <span>Lossless Quality</span>
              </div>
              <div>
                <span className="block text-[#FAF9F6] font-bold text-sm">6 REGIONS</span>
                <span>British & Celtic</span>
              </div>
              <div>
                <span className="block text-[#FAF9F6] font-bold text-sm">NO ADS</span>
                <span>Uninterrupted Focus</span>
              </div>
            </div>

          </div>

          {/* Right Column: Featured Release Frame */}
          <div className="lg:col-span-5">
            <div className="bg-[#1E293B] p-6 sm:p-8 rounded-xs border border-[#334155] shadow-2xl relative group">
              <div className="aspect-square w-full relative overflow-hidden rounded-xs border border-[#334155] mb-6">
                <img
                  src={featuredTrack.coverArt}
                  alt={featuredTrack.albumTitle}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 bg-[#0A1128]/90 text-[#FAF9F6] px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider rounded-xs border border-[#334155]">
                  Featured Release
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-mono uppercase text-[#854D0E]">
                  {featuredTrack.region} • {featuredTrack.year}
                </span>
                <h3 className="font-serif font-bold text-xl text-[#FAF9F6]">
                  {featuredTrack.albumTitle}
                </h3>
                <p className="text-sm text-[#94A3B8]">{featuredTrack.artistName}</p>
                <p className="text-xs text-[#64748B] font-mono pt-1">
                  Label: {featuredTrack.label}
                </p>
              </div>

              <button
                onClick={() => onPlayFeatured(featuredTrack)}
                className="w-full mt-6 py-2.5 bg-[#1E3A2B] hover:bg-[#2D5A40] text-[#FAF9F6] text-xs font-medium uppercase tracking-wider rounded-xs transition-colors flex items-center justify-center space-x-2"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Listen Now ({Math.floor(featuredTrack.duration / 60)}m {featuredTrack.duration % 60}s)</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
