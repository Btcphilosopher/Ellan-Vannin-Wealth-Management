import React from 'react';
import { Play, X, Disc, MapPin, Calendar, Music } from 'lucide-react';
import { Album, Track } from '../types';

interface AlbumDetailModalProps {
  album: Album | null;
  onClose: () => void;
  onPlayAlbum: (album: Album) => void;
  onPlayTrack: (track: Track) => void;
}

export const AlbumDetailModal: React.FC<AlbumDetailModalProps> = ({
  album,
  onClose,
  onPlayAlbum,
  onPlayTrack,
}) => {
  if (!album) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-fadeIn">
      <div className="bg-[#F5F2ED] border border-[#0A1128]/20 rounded-xs max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        {/* Header Banner */}
        <div className="p-6 bg-[#0A1128] text-[#F5F2ED] flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 relative border-b border-[#1E293B]">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-[#F5F2ED]/70 hover:text-[#F5F2ED] bg-[#1E293B] rounded-xs"
          >
            <X className="w-5 h-5" />
          </button>

          <img
            src={album.coverArt}
            alt={album.title}
            className="w-28 h-28 sm:w-36 sm:h-36 object-cover rounded-xs border border-[#8C704B]/30 shrink-0"
          />

          <div className="min-w-0 space-y-2 text-center sm:text-left">
            <span className="text-[10px] font-mono uppercase text-[#8C704B] bg-[#8C704B]/10 px-2 py-0.5 rounded-xs border border-[#8C704B]/30 tracking-widest font-semibold">
              {album.genre} • {album.releaseYear}
            </span>
            <h2 className="font-serif italic font-light text-2xl sm:text-3xl text-[#F5F2ED] leading-tight">
              {album.title}
            </h2>
            <p className="text-sm text-[#CBD5E1]">{album.artistName}</p>
            <p className="text-xs font-mono text-[#94A3B8]">Catalog: {album.catalogNumber}</p>

            <button
              onClick={() => {
                onPlayAlbum(album);
                onClose();
              }}
              className="mt-2 px-5 py-2 bg-[#8C704B] hover:bg-[#A3835B] text-[#F5F2ED] text-xs font-semibold uppercase tracking-[0.12em] rounded-xs flex items-center justify-center sm:justify-start space-x-2 transition-colors"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Stream Entire Album</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          <div>
            <h4 className="text-[10px] font-mono uppercase text-[#8C704B] tracking-wider font-semibold mb-1">Editorial Description</h4>
            <p className="text-xs sm:text-sm text-[#0A1128]/80 leading-relaxed font-sans">
              {album.editorialDescription}
            </p>
          </div>

          {album.recordingLocation && (
            <div className="flex items-center space-x-2 text-xs text-[#0A1128]/60 font-mono">
              <MapPin className="w-3.5 h-3.5 text-[#8C704B]" />
              <span>Recording Location: {album.recordingLocation}</span>
            </div>
          )}

          {/* Tracklist Table */}
          <div className="space-y-2">
            <h4 className="text-[10px] font-mono uppercase text-[#8C704B] tracking-wider font-semibold">Archival Tracklist</h4>
            <div className="divide-y divide-[#0A1128]/10 border border-[#0A1128]/10 rounded-xs bg-[#F5F2ED]">
              {album.tracks.map((track, i) => (
                <div
                  key={track.id}
                  className="p-3 flex items-center justify-between hover:bg-[#EFECE6] transition-colors"
                >
                  <div className="flex items-center space-x-3 min-w-0">
                    <span className="font-mono text-xs text-[#0A1128]/50 w-5">0{i + 1}</span>
                    <div className="min-w-0">
                      <p className="font-serif font-bold text-xs text-[#0A1128] truncate">{track.title}</p>
                      <p className="text-[11px] text-[#0A1128]/60 truncate">{track.composer}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onPlayTrack(track);
                      onClose();
                    }}
                    className="px-3 py-1 bg-[#0A1128] hover:bg-[#8C704B] text-[#F5F2ED] text-xs font-semibold uppercase tracking-wider rounded-xs flex items-center space-x-1 transition-colors"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Play</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
