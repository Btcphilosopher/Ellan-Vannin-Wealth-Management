import React, { useState } from 'react';
import { Code2, Database, Server, Copy, Check, Terminal, Shield, Cpu } from 'lucide-react';

export const TechSchemaView: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const postgresqlDdl = `-- ALBION AUDIO: PostgreSQL Schema Architecture (HQ: Douglas, Isle of Man)

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Regions & Heritage
CREATE TYPE british_region AS ENUM (
  'Isle of Man', 'England', 'Scotland', 'Wales', 'Ireland', 'Cornwall', 'British Diaspora'
);

-- Users & Subscriptions
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  display_name VARCHAR(100) NOT NULL,
  location VARCHAR(100) DEFAULT 'Douglas, Isle of Man',
  membership_tier VARCHAR(50) DEFAULT 'Patron Member',
  preferred_audio_quality VARCHAR(50) DEFAULT 'FLAC 24-bit/96kHz',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Record Labels
CREATE TABLE record_labels (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  headquarters VARCHAR(100) DEFAULT 'Douglas, Isle of Man',
  founded_year INTEGER,
  catalog_code VARCHAR(20) UNIQUE
);

-- Artists
CREATE TABLE artists (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  region british_region NOT NULL,
  genre VARCHAR(100) NOT NULL,
  biography TEXT,
  image_url VARCHAR(512),
  featured_title VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Albums
CREATE TABLE albums (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(255) NOT NULL,
  artist_id UUID REFERENCES artists(id) ON DELETE CASCADE,
  label_id UUID REFERENCES record_labels(id),
  release_year INTEGER NOT NULL,
  genre VARCHAR(100) NOT NULL,
  cover_art_url VARCHAR(512) NOT NULL,
  editorial_description TEXT,
  recording_location VARCHAR(255),
  catalog_number VARCHAR(50) UNIQUE,
  is_featured BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tracks & Range Streams
CREATE TABLE tracks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  album_id UUID REFERENCES albums(id) ON DELETE CASCADE,
  artist_id UUID REFERENCES artists(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  duration_seconds INTEGER NOT NULL,
  audio_file_url VARCHAR(512) NOT NULL,
  file_size_bytes BIGINT,
  bitrate_kbps INTEGER DEFAULT 320,
  composer VARCHAR(255),
  producer VARCHAR(255),
  recording_year INTEGER,
  lyrics TEXT,
  editorial_notes TEXT,
  play_count BIGINT DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Playlists & User Library
CREATE TABLE playlists (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  is_public BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE playlist_tracks (
  playlist_id UUID REFERENCES playlists(id) ON DELETE CASCADE,
  track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  PRIMARY KEY (playlist_id, track_id)
);`;

  const dockerCompose = `version: '3.8'

services:
  albion-backend:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgres://albion:secret@postgres:5432/albion_audio
      - REDIS_URL=redis://redis:6379
      - AUDIO_BITRATE_DEFAULT=320kbps
    depends_on:
      - postgres
      - redis

  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: albion_audio
      POSTGRES_USER: albion
      POSTGRES_PASSWORD: secret
    volumes:
      - pgdata:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine

volumes:
  pgdata:`;

  const handleCopy = () => {
    navigator.clipboard.writeText(postgresqlDdl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="border-b border-[#0A1128]/10 pb-6">
        <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.2em] font-semibold block mb-1">
          TECHNICAL SPECIFICATION & ARCHITECTURE
        </span>
        <h2 className="font-serif italic font-light text-3xl sm:text-4xl text-[#0A1128] tracking-tight">
          PostgreSQL Schema & Deployment Blueprint
        </h2>
        <p className="text-sm text-[#0A1128]/70 mt-1 font-sans">
          Production relational schema, HTTP Range streaming engine, REST endpoints, and container deployment spec for Douglas, Isle of Man.
        </p>
      </div>

      {/* Tech Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs font-mono">
        <div className="p-4 bg-[#F5F2ED] border border-[#0A1128]/10 rounded-xs space-y-1">
          <Database className="w-5 h-5 text-[#8C704B] mb-2" />
          <span className="font-bold text-[#0A1128] text-sm block">PostgreSQL 16 Cluster</span>
          <p className="text-[#0A1128]/60">Relational integrity, custom British region ENUMs, UUID primary keys.</p>
        </div>

        <div className="p-4 bg-[#F5F2ED] border border-[#0A1128]/10 rounded-xs space-y-1">
          <Server className="w-5 h-5 text-[#0A1128] mb-2" />
          <span className="font-bold text-[#0A1128] text-sm block">HTTP Range Audio Engine</span>
          <p className="text-[#0A1128]/60">Partial 206 Content-Range audio streaming with progressive MP3/FLAC buffering.</p>
        </div>

        <div className="p-4 bg-[#F5F2ED] border border-[#0A1128]/10 rounded-xs space-y-1">
          <Cpu className="w-5 h-5 text-[#8C704B] mb-2" />
          <span className="font-bold text-[#0A1128] text-sm block">Douglas Edge Node</span>
          <p className="text-[#0A1128]/60">Node.js Express backend with Redis audio chunk caching.</p>
        </div>
      </div>

      {/* DDL Code Box */}
      <div className="bg-[#0A1128] text-[#FAF9F6] border border-[#1E293B] rounded-xs overflow-hidden shadow-2xl">
        <div className="p-4 bg-[#1E293B] flex items-center justify-between border-b border-[#334155]">
          <div className="flex items-center space-x-2 text-xs font-mono text-[#CBD5E1]">
            <Terminal className="w-4 h-4 text-[#854D0E]" />
            <span>schema.sql (PostgreSQL 16 DDL)</span>
          </div>

          <button
            onClick={handleCopy}
            className="px-3 py-1 bg-[#0A1128] hover:bg-[#334155] text-xs font-mono text-[#FAF9F6] rounded-xs border border-[#334155] flex items-center space-x-1.5 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied DDL' : 'Copy SQL Schema'}</span>
          </button>
        </div>

        <pre className="p-6 font-mono text-xs text-[#94A3B8] overflow-x-auto leading-relaxed max-h-96">
          {postgresqlDdl}
        </pre>
      </div>

      {/* Docker Compose Box */}
      <div className="bg-[#0A1128] text-[#FAF9F6] border border-[#1E293B] rounded-xs overflow-hidden shadow-2xl">
        <div className="p-4 bg-[#1E293B] flex items-center justify-between border-b border-[#334155]">
          <span className="text-xs font-mono text-[#CBD5E1]">docker-compose.yml</span>
        </div>

        <pre className="p-6 font-mono text-xs text-[#94A3B8] overflow-x-auto leading-relaxed">
          {dockerCompose}
        </pre>
      </div>
    </div>
  );
};
