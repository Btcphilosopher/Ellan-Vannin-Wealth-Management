import React, { useState } from 'react';
import { BookOpen, Calendar, Clock, User, ArrowRight, Disc, Play, X, Share2 } from 'lucide-react';
import { EditorialArticle, Album } from '../types';

interface EditorialViewProps {
  articles: EditorialArticle[];
  albums: Album[];
  onPlayAlbum: (album: Album) => void;
}

export const EditorialView: React.FC<EditorialViewProps> = ({ articles, albums, onPlayAlbum }) => {
  const [selectedArticle, setSelectedArticle] = useState<EditorialArticle | null>(null);

  const getFeaturedAlbum = (albumId?: string) => {
    return albums.find((a) => a.id === albumId);
  };

  return (
    <div className="space-y-10">
      {/* Editorial Section Header */}
      <div className="border-b border-[#0A1128]/10 pb-6">
        <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.2em] font-semibold block mb-1">
          THE ALBION REVIEW & JOURNAL
        </span>
        <h2 className="font-serif italic font-light text-3xl sm:text-4xl text-[#0A1128] tracking-tight">
          Editorial & Cultural Essays
        </h2>
        <p className="text-sm text-[#0A1128]/70 mt-1 max-w-2xl font-sans leading-relaxed">
          Long-form essays, musicology, artist biographies, and cultural commentary published by the Douglas Cultural Institute.
        </p>
      </div>

      {/* Featured Lead Article Frame */}
      {articles[0] && (
        <article className="bg-[#F5F2ED] border border-[#0A1128]/10 rounded-xs overflow-hidden shadow-xs hover:shadow-md transition-shadow">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="flex items-center space-x-3 text-xs font-mono">
                  <span className="bg-[#0A1128] text-[#F5F2ED] px-2.5 py-0.5 rounded-xs uppercase tracking-wider font-semibold text-[10px]">
                    {articles[0].category}
                  </span>
                  <span className="text-[#8C704B] font-semibold">{articles[0].regionTag}</span>
                  <span className="text-[#0A1128]/30">•</span>
                  <span className="text-[#0A1128]/60">{articles[0].readTime}</span>
                </div>

                <h3
                  onClick={() => setSelectedArticle(articles[0])}
                  className="font-serif italic font-light text-2xl sm:text-3xl text-[#0A1128] hover:text-[#8C704B] cursor-pointer leading-tight transition-colors"
                >
                  {articles[0].title}
                </h3>

                <p className="font-serif italic text-sm text-[#8C704B]">
                  {articles[0].subtitle}
                </p>

                <p className="text-xs sm:text-sm text-[#0A1128]/70 leading-relaxed line-clamp-3">
                  {articles[0].excerpt}
                </p>
              </div>

              {/* Author & Read Action */}
              <div className="pt-4 border-t border-[#0A1128]/10 flex items-center justify-between">
                <div>
                  <p className="font-serif font-bold text-xs text-[#0A1128]">{articles[0].author}</p>
                  <p className="text-[11px] text-[#0A1128]/60 font-mono">{articles[0].authorRole}</p>
                </div>

                <button
                  onClick={() => setSelectedArticle(articles[0])}
                  className="px-4 py-2 bg-[#0A1128] hover:bg-[#8C704B] text-[#F5F2ED] text-xs font-semibold uppercase tracking-[0.1em] rounded-xs transition-colors flex items-center space-x-2"
                >
                  <span>Read Essay</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#8C704B]" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-5 relative min-h-[280px] bg-[#0A1128]/5 border-l border-[#0A1128]/10">
              <img
                src={articles[0].imageUrl}
                alt={articles[0].title}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </article>
      )}

      {/* Grid of Remaining Articles */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {articles.slice(1).map((article) => {
          const featuredAlbum = getFeaturedAlbum(article.featuredAlbumId);
          return (
            <article
              key={article.id}
              className="bg-[#F5F2ED] border border-[#0A1128]/10 hover:border-[#8C704B] rounded-xs overflow-hidden transition-all duration-300 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="aspect-video w-full overflow-hidden bg-[#0A1128]/5 relative border-b border-[#0A1128]/10">
                  <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover" />
                  <span className="absolute top-3 left-3 bg-[#0A1128] text-[#F5F2ED] text-[10px] font-mono uppercase px-2 py-0.5 rounded-xs font-semibold tracking-wider">
                    {article.category}
                  </span>
                </div>

                <div className="p-6 space-y-3">
                  <div className="flex items-center space-x-2 text-[11px] text-[#0A1128]/60 font-mono">
                    <Calendar className="w-3 h-3 text-[#8C704B]" />
                    <span>{article.date}</span>
                    <span>•</span>
                    <Clock className="w-3 h-3 text-[#8C704B]" />
                    <span>{article.readTime}</span>
                  </div>

                  <h3
                    onClick={() => setSelectedArticle(article)}
                    className="font-serif font-semibold text-xl text-[#0A1128] hover:text-[#8C704B] cursor-pointer line-clamp-2 transition-colors"
                  >
                    {article.title}
                  </h3>

                  <p className="text-xs text-[#0A1128]/70 leading-relaxed line-clamp-3">
                    {article.excerpt}
                  </p>
                </div>
              </div>

              <div className="p-6 pt-0 border-t border-[#0A1128]/10 mt-4 flex items-center justify-between">
                <div>
                  <p className="font-serif font-bold text-xs text-[#0A1128]">{article.author}</p>
                  <p className="text-[10px] text-[#0A1128]/60 font-mono">{article.authorRole}</p>
                </div>

                <button
                  onClick={() => setSelectedArticle(article)}
                  className="text-xs font-semibold text-[#8C704B] hover:underline flex items-center space-x-1 uppercase tracking-wider"
                >
                  <span>Read Article</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </article>
          );
        })}
      </div>

      {/* Reader Modal View */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 overflow-y-auto animate-fadeIn">
          <div className="bg-[#F5F2ED] border border-[#0A1128]/20 rounded-xs max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col">
            {/* Header */}
            <div className="p-6 sm:p-8 bg-[#0A1128] text-[#F5F2ED] relative">
              <button
                onClick={() => setSelectedArticle(null)}
                className="absolute top-6 right-6 p-1.5 text-[#F5F2ED]/70 hover:text-[#F5F2ED] bg-[#1E293B] rounded-xs"
              >
                <X className="w-5 h-5" />
              </button>

              <span className="text-xs font-mono uppercase text-[#8C704B] bg-[#8C704B]/10 px-2.5 py-1 rounded-xs border border-[#8C704B]/30 tracking-widest font-semibold">
                {selectedArticle.category} • {selectedArticle.regionTag}
              </span>

              <h1 className="font-serif italic font-light text-2xl sm:text-4xl text-[#F5F2ED] mt-4 leading-tight">
                {selectedArticle.title}
              </h1>

              <p className="font-serif italic text-base text-[#CBD5E1] mt-2">
                {selectedArticle.subtitle}
              </p>

              <div className="flex items-center space-x-4 text-xs font-mono text-[#94A3B8] mt-6 pt-4 border-t border-[#1E293B]">
                <span>By {selectedArticle.author} ({selectedArticle.authorRole})</span>
                <span>•</span>
                <span>{selectedArticle.date}</span>
              </div>
            </div>

            {/* Article Content */}
            <div className="p-6 sm:p-10 space-y-6 text-[#0A1128] font-sans leading-relaxed">
              <img
                src={selectedArticle.imageUrl}
                alt={selectedArticle.title}
                className="w-full aspect-video object-cover rounded-xs border border-[#0A1128]/10"
              />

              {selectedArticle.imageCaption && (
                <p className="text-xs text-[#0A1128]/60 font-mono text-center italic">
                  {selectedArticle.imageCaption}
                </p>
              )}

              {/* Pull Quote */}
              <div className="p-6 bg-[#EFECE6] border-l-4 border-[#8C704B] my-6">
                <p className="font-serif italic text-lg text-[#0A1128]">
                  "{selectedArticle.excerpt}"
                </p>
              </div>

              {selectedArticle.content.map((paragraph, idx) => (
                <p key={idx} className="text-sm sm:text-base text-[#0A1128]/80 leading-loose">
                  {paragraph}
                </p>
              ))}

              {/* Related Featured Album */}
              {selectedArticle.featuredAlbumId && getFeaturedAlbum(selectedArticle.featuredAlbumId) && (
                <div className="mt-8 p-5 bg-[#0A1128] text-[#F5F2ED] rounded-xs flex items-center justify-between border border-[#8C704B]/30">
                  <div className="flex items-center space-x-4">
                    <img
                      src={getFeaturedAlbum(selectedArticle.featuredAlbumId)!.coverArt}
                      alt="Featured Album"
                      className="w-14 h-14 object-cover rounded-xs border border-[#8C704B]/30"
                    />
                    <div>
                      <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-wider font-semibold">
                        ACCOMPANYING RECORDING
                      </span>
                      <h4 className="font-serif font-bold text-base text-[#F5F2ED]">
                        {getFeaturedAlbum(selectedArticle.featuredAlbumId)!.title}
                      </h4>
                      <p className="text-xs text-[#94A3B8]">
                        {getFeaturedAlbum(selectedArticle.featuredAlbumId)!.artistName}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onPlayAlbum(getFeaturedAlbum(selectedArticle.featuredAlbumId)!);
                      setSelectedArticle(null);
                    }}
                    className="px-4 py-2 bg-[#8C704B] hover:bg-[#A3835B] text-[#F5F2ED] text-xs font-semibold uppercase tracking-[0.1em] rounded-xs flex items-center space-x-2 shrink-0 transition-colors"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Stream Album</span>
                  </button>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-6 bg-[#EFECE6] border-t border-[#0A1128]/10 flex items-center justify-between text-xs font-mono text-[#0A1128]/60">
              <span>DOUGLAS CULTURAL INSTITUTE • ALBION AUDIO</span>
              <button
                onClick={() => setSelectedArticle(null)}
                className="px-4 py-2 bg-[#0A1128] text-[#F5F2ED] rounded-xs hover:bg-[#8C704B] transition-colors font-semibold uppercase tracking-[0.1em] text-xs"
              >
                Close Reader
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
