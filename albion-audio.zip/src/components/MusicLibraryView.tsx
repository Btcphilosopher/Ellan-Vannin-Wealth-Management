import React, { useState } from 'react';
import {
  Library,
  Heart,
  ListMusic,
  History,
  Plus,
  Play,
  Trash2,
  Share2,
  Download,
  Disc,
  FolderHeart,
  X
} from 'lucide-react';
import { Track, Album, Playlist } from '../types';

interface MusicLibraryViewProps {
  favoriteTracks: Track[];
  savedAlbums: Album[];
  playlists: Playlist[];
  allTracks: Track[];
  onPlayTrack: (track: Track) => void;
  onPlayAlbum: (album: Album) => void;
  onCreatePlaylist: (title: string, description: string) => void;
  onDeletePlaylist: (id: string) => void;
  onRemoveTrackFromPlaylist: (playlistId: string, trackId: string) => void;
}

export const MusicLibraryView: React.FC<MusicLibraryViewProps> = ({
  favoriteTracks,
  savedAlbums,
  playlists,
  allTracks,
  onPlayTrack,
  onPlayAlbum,
  onCreatePlaylist,
  onDeletePlaylist,
  onRemoveTrackFromPlaylist,
}) => {
  const [activeTab, setActiveTab] = useState<'favorites' | 'albums' | 'playlists' | 'history'>('favorites');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [selectedPlaylist, setSelectedPlaylist] = useState<Playlist | null>(null);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onCreatePlaylist(newTitle.trim(), newDesc.trim());
    setNewTitle('');
    setNewDesc('');
    setShowCreateModal(false);
  };

  const exportPlaylistM3U = (playlist: Playlist) => {
    let content = `#EXTM3U\n#PLAYLIST:${playlist.title}\n`;
    playlist.tracks.forEach((t) => {
      content += `#EXTINF:${t.duration},${t.artistName} - ${t.title}\n${t.audioUrl}\n`;
    });
    const blob = new Blob([content], { type: 'audio/x-mpegurl' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${playlist.title.toLowerCase().replace(/\s+/g, '_')}.m3u`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Header & Sub-Navigation */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#0A1128]/10 pb-6">
        <div>
          <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.2em] font-semibold block mb-1">
            PERSONAL ARCHIVE
          </span>
          <h2 className="font-serif italic font-light text-3xl sm:text-4xl text-[#0A1128] tracking-tight">
            Music Library
          </h2>
        </div>

        {/* Action Tabs */}
        <div className="flex items-center space-x-2 bg-[#EFECE6] p-1 rounded-xs border border-[#0A1128]/10">
          <button
            onClick={() => setActiveTab('favorites')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.1em] rounded-xs transition-colors ${
              activeTab === 'favorites' ? 'bg-[#0A1128] text-[#F5F2ED]' : 'text-[#0A1128]/70 hover:text-[#0A1128]'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${activeTab === 'favorites' ? 'text-[#8C704B]' : ''}`} />
            <span>Favorites ({favoriteTracks.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('albums')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.1em] rounded-xs transition-colors ${
              activeTab === 'albums' ? 'bg-[#0A1128] text-[#F5F2ED]' : 'text-[#0A1128]/70 hover:text-[#0A1128]'
            }`}
          >
            <Disc className={`w-3.5 h-3.5 ${activeTab === 'albums' ? 'text-[#8C704B]' : ''}`} />
            <span>Saved Albums ({savedAlbums.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('playlists')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.1em] rounded-xs transition-colors ${
              activeTab === 'playlists' ? 'bg-[#0A1128] text-[#F5F2ED]' : 'text-[#0A1128]/70 hover:text-[#0A1128]'
            }`}
          >
            <ListMusic className={`w-3.5 h-3.5 ${activeTab === 'playlists' ? 'text-[#8C704B]' : ''}`} />
            <span>Playlists ({playlists.length})</span>
          </button>
        </div>
      </div>

      {/* 1. FAVORITES TAB */}
      {activeTab === 'favorites' && (
        <div className="space-y-4">
          {favoriteTracks.length === 0 ? (
            <div className="p-12 text-center bg-[#FAF9F6] border border-[#E5E5E0] rounded-xs">
              <FolderHeart className="w-12 h-12 text-[#94A3B8] mx-auto mb-3" />
              <h3 className="font-serif font-bold text-lg text-[#0A1128]">No Favorite Tracks Yet</h3>
              <p className="text-xs text-[#64748B] mt-1 font-sans">
                Click the heart icon on any recording to save it to your personal Douglas archive.
              </p>
            </div>
          ) : (
            <div className="bg-[#FAF9F6] border border-[#E5E5E0] rounded-xs divide-y divide-[#E5E5E0]">
              {favoriteTracks.map((track, i) => (
                <div
                  key={track.id}
                  className="p-3 sm:p-4 flex items-center justify-between hover:bg-[#F1F1EC] transition-colors"
                >
                  <div className="flex items-center space-x-3 sm:space-x-4 min-w-0 flex-1">
                    <span className="font-mono text-xs text-[#94A3B8] w-6">0{i + 1}</span>
                    <img src={track.coverArt} alt={track.title} className="w-11 h-11 object-cover rounded-xs" />
                    <div className="min-w-0 flex-1">
                      <h4 className="font-serif font-bold text-sm text-[#0A1128] truncate">{track.title}</h4>
                      <p className="text-xs text-[#64748B] truncate">{track.artistName} • {track.albumTitle}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => onPlayTrack(track)}
                      className="px-3 py-1.5 bg-[#0A1128] hover:bg-[#1E3A2B] text-[#FAF9F6] text-xs font-sans rounded-xs flex items-center space-x-1.5"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Stream</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. SAVED ALBUMS TAB */}
      {activeTab === 'albums' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {savedAlbums.map((album) => (
            <div
              key={album.id}
              className="bg-[#FAF9F6] border border-[#E5E5E0] hover:border-[#1E3A2B] p-4 rounded-xs shadow-xs transition-all flex flex-col justify-between"
            >
              <div>
                <div className="relative aspect-square w-full overflow-hidden bg-[#E5E5E0] rounded-xs mb-3">
                  <img src={album.coverArt} alt={album.title} className="w-full h-full object-cover" />
                  <button
                    onClick={() => onPlayAlbum(album)}
                    className="absolute bottom-3 right-3 w-10 h-10 bg-[#0A1128] text-white rounded-full flex items-center justify-center shadow-lg"
                  >
                    <Play className="w-4 h-4 fill-current ml-0.5" />
                  </button>
                </div>
                <h3 className="font-serif font-bold text-base text-[#0A1128]">{album.title}</h3>
                <p className="text-xs text-[#64748B]">{album.artistName}</p>
              </div>

              <div className="mt-3 pt-3 border-t border-[#E5E5E0] text-[10px] text-[#94A3B8] font-mono flex justify-between">
                <span>{album.label}</span>
                <span>{album.releaseYear}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 3. PLAYLISTS TAB */}
      {activeTab === 'playlists' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <p className="text-xs text-[#64748B] font-mono">
              Custom user suites and exported collections
            </p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-4 py-2 bg-[#0A1128] hover:bg-[#1E3A2B] text-[#FAF9F6] text-xs font-medium rounded-xs flex items-center space-x-2"
            >
              <Plus className="w-4 h-4" />
              <span>Create Playlist</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {playlists.map((pl) => (
              <div
                key={pl.id}
                className="bg-[#FAF9F6] border border-[#E5E5E0] hover:border-[#1E3A2B] p-5 rounded-xs shadow-xs transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-mono uppercase bg-[#1E3A2B]/10 text-[#1E3A2B] px-2 py-0.5 rounded-xs">
                      {pl.tracks.length} TRACKS
                    </span>
                    <button
                      onClick={() => onDeletePlaylist(pl.id)}
                      className="text-[#94A3B8] hover:text-red-600 p-1"
                      title="Delete playlist"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <h3 className="font-serif font-bold text-lg text-[#0A1128]">{pl.title}</h3>
                  <p className="text-xs text-[#64748B] mt-1 font-sans">{pl.description || 'No description provided.'}</p>
                </div>

                <div className="mt-4 pt-4 border-t border-[#E5E5E0] flex items-center justify-between">
                  <button
                    onClick={() => exportPlaylistM3U(pl)}
                    className="text-xs text-[#854D0E] font-mono hover:underline flex items-center space-x-1"
                    title="Export as M3U file"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export M3U</span>
                  </button>

                  <button
                    onClick={() => {
                      if (pl.tracks.length > 0) {
                        onPlayTrack(pl.tracks[0]);
                      }
                    }}
                    className="px-3 py-1.5 bg-[#0A1128] text-[#FAF9F6] text-xs rounded-xs flex items-center space-x-1"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Play Suite</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Create Playlist Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#FAF9F6] border border-[#E5E5E0] rounded-xs max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#E5E5E0] pb-3">
              <h3 className="font-serif font-bold text-xl text-[#0A1128]">Create Archival Playlist</h3>
              <button onClick={() => setShowCreateModal(false)} className="text-[#64748B]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-[#64748B] mb-1">Playlist Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Hebridean Nightfall Suite"
                  className="w-full px-3 py-2 bg-white border border-[#E5E5E0] rounded-xs text-sm text-[#0A1128] focus:outline-none focus:border-[#1E3A2B]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-[#64748B] mb-1">Description</label>
                <textarea
                  rows={3}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Notes on curation or intended listening environment..."
                  className="w-full px-3 py-2 bg-white border border-[#E5E5E0] rounded-xs text-sm text-[#0A1128] focus:outline-none focus:border-[#1E3A2B]"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 bg-[#F1F1EC] text-[#334155] text-xs font-medium rounded-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#0A1128] hover:bg-[#1E3A2B] text-[#FAF9F6] text-xs font-medium rounded-xs"
                >
                  Save Playlist
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
