import React, { useState } from 'react';
import { Play, Disc, MapPin, Tag, ArrowRight, X } from 'lucide-react';
import { CuratedCollection, Track } from '../types';

interface CuratedCollectionsProps {
  collections: CuratedCollection[];
  onPlayCollection: (collection: CuratedCollection) => void;
  onPlayTrack: (track: Track) => void;
}

export const CuratedCollections: React.FC<CuratedCollectionsProps> = ({
  collections,
  onPlayCollection,
  onPlayTrack,
}) => {
  const [selectedRegion, setSelectedRegion] = useState<string>('All');
  const [activeModalCollection, setActiveModalCollection] = useState<CuratedCollection | null>(null);

  const regions = ['All', 'Isle of Man & Scottish Isles', 'Northern England', 'Celtic Nations', 'United Kingdom'];

  const filteredCollections = selectedRegion === 'All'
    ? collections
    : collections.filter((c) => c.region.toLowerCase().includes(selectedRegion.toLowerCase()));

  return (
    <div className="space-y-8">
      {/* Header & Regional Filters */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#0A1128]/10 pb-6">
        <div>
          <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.2em] font-semibold block mb-1">
            CULTURAL ANTHOLOGY
          </span>
          <h2 className="font-serif italic font-light text-3xl sm:text-4xl text-[#0A1128] tracking-tight">
            Curated Collections
          </h2>
          <p className="text-sm text-[#0A1128]/70 mt-1 max-w-xl font-sans">
            Specialized acoustic anthologies grouped by geographical terrain, industrial heritage, and Celtic oral history.
          </p>
        </div>

        {/* Region Pills */}
        <div className="flex flex-wrap gap-2">
          {regions.map((region) => (
            <button
              key={region}
              onClick={() => setSelectedRegion(region)}
              className={`px-3.5 py-1.5 text-xs font-semibold uppercase tracking-[0.1em] rounded-xs transition-colors ${
                selectedRegion === region
                  ? 'bg-[#0A1128] text-[#F5F2ED]'
                  : 'bg-[#EFECE6] text-[#0A1128]/70 hover:bg-[#E5E0D8]'
              }`}
            >
              {region}
            </button>
          ))}
        </div>
      </div>

      {/* Collection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredCollections.map((col) => (
          <div
            key={col.id}
            className="group bg-[#F5F2ED] border border-[#0A1128]/10 hover:border-[#8C704B] rounded-xs overflow-hidden transition-all duration-300 shadow-xs hover:shadow-md flex flex-col justify-between"
          >
            <div>
              {/* Image Frame */}
              <div className="relative aspect-video w-full overflow-hidden bg-[#0A1128]/5 border-b border-[#0A1128]/10">
                <img
                  src={col.coverImage}
                  alt={col.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <span className="text-[10px] font-mono uppercase tracking-[0.18em] font-semibold bg-[#0A1128]/90 text-[#F5F2ED] px-2 py-0.5 rounded-xs border border-[#8C704B]/30">
                    {col.region}
                  </span>
                  <h3 className="font-serif italic font-light text-2xl text-white mt-1">
                    {col.title}
                  </h3>
                </div>
              </div>

              {/* Description */}
              <div className="p-5 space-y-3">
                <p className="text-xs font-serif italic text-[#8C704B]">
                  {col.subtitle}
                </p>
                <p className="text-xs text-[#0A1128]/70 leading-relaxed line-clamp-3">
                  {col.description}
                </p>

                {/* Tag Pills */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {col.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[10px] font-mono bg-[#EFECE6] text-[#0A1128]/70 px-2 py-0.5 rounded-xs border border-[#0A1128]/10"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="p-5 pt-0 flex items-center justify-between border-t border-[#0A1128]/10 mt-4">
              <span className="text-[11px] text-[#0A1128]/50 font-mono">
                {col.trackCount} Tracks Included
              </span>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setActiveModalCollection(col)}
                  className="px-3 py-1.5 bg-[#EFECE6] hover:bg-[#E5E0D8] text-[#0A1128] text-xs font-semibold uppercase tracking-[0.1em] rounded-xs transition-colors"
                >
                  Tracks
                </button>

                <button
                  onClick={() => onPlayCollection(col)}
                  className="px-3 py-1.5 bg-[#0A1128] hover:bg-[#8C704B] text-[#F5F2ED] text-xs font-semibold uppercase tracking-[0.1em] rounded-xs transition-colors flex items-center space-x-1.5"
                >
                  <Play className="w-3 h-3 fill-current text-[#8C704B]" />
                  <span>Stream Suite</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Collection Tracks Detail Modal */}
      {activeModalCollection && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-fadeIn">
          <div className="bg-[#FAF9F6] border border-[#E5E5E0] rounded-xs max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col shadow-2xl">
            {/* Modal Header */}
            <div className="p-6 bg-[#0A1128] text-[#FAF9F6] flex items-center justify-between">
              <div>
                <span className="text-xs font-mono uppercase text-[#854D0E]">
                  {activeModalCollection.region} COLLECTION
                </span>
                <h3 className="font-serif font-bold text-2xl text-[#FAF9F6] mt-1">
                  {activeModalCollection.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveModalCollection(null)}
                className="p-1.5 text-[#94A3B8] hover:text-[#FAF9F6] rounded-xs"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body Tracks List */}
            <div className="p-6 overflow-y-auto space-y-4 flex-1">
              <p className="text-xs text-[#64748B] font-serif italic">
                {activeModalCollection.description}
              </p>

              <div className="divide-y divide-[#E5E5E0] border border-[#E5E5E0] rounded-xs bg-white">
                {activeModalCollection.featuredTracks.map((track, i) => (
                  <div
                    key={track.id}
                    className="p-3 flex items-center justify-between hover:bg-[#F1F1EC] transition-colors"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <span className="font-mono text-xs text-[#94A3B8] w-5">
                        0{i + 1}
                      </span>
                      <img src={track.coverArt} alt={track.title} className="w-9 h-9 object-cover rounded-xs" />
                      <div className="min-w-0">
                        <p className="font-serif font-bold text-xs text-[#0A1128] truncate">{track.title}</p>
                        <p className="text-[11px] text-[#64748B] truncate">{track.artistName}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onPlayTrack(track);
                        setActiveModalCollection(null);
                      }}
                      className="px-3 py-1 bg-[#1E3A2B] hover:bg-[#2D5A40] text-[#FAF9F6] text-xs rounded-xs flex items-center space-x-1"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Play</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-[#F1F1EC] border-t border-[#E5E5E0] flex items-center justify-between">
              <span className="text-xs font-mono text-[#64748B]">
                {activeModalCollection.trackCount} Archival Works Included
              </span>
              <button
                onClick={() => {
                  onPlayCollection(activeModalCollection);
                  setActiveModalCollection(null);
                }}
                className="px-4 py-2 bg-[#0A1128] hover:bg-[#1E3A2B] text-[#FAF9F6] text-xs font-medium rounded-xs flex items-center space-x-2"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Play Entire Collection</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
