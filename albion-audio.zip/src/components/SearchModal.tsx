import React, { useState, useEffect, useRef } from 'react';
import { Search, X, Play, Disc, User, BookOpen, Music } from 'lucide-react';
import { Track, Album, Artist, EditorialArticle, CuratedCollection } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  tracks: Track[];
  albums: Album[];
  artists: Artist[];
  articles: EditorialArticle[];
  collections: CuratedCollection[];
  onPlayTrack: (track: Track) => void;
  onSelectAlbum: (album: Album) => void;
  onSelectArtist: (artist: Artist) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  tracks,
  albums,
  artists,
  articles,
  collections,
  onPlayTrack,
  onSelectAlbum,
  onSelectArtist,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const q = query.trim().toLowerCase();

  const matchedTracks = q ? tracks.filter((t) => t.title.toLowerCase().includes(q) || t.artistName.toLowerCase().includes(q)) : [];
  const matchedAlbums = q ? albums.filter((a) => a.title.toLowerCase().includes(q) || a.artistName.toLowerCase().includes(q)) : [];
  const matchedArtists = q ? artists.filter((art) => art.name.toLowerCase().includes(q) || art.region.toLowerCase().includes(q)) : [];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-start justify-center pt-16 sm:pt-24 p-4 animate-fadeIn">
      <div className="bg-[#F5F2ED] border border-[#0A1128]/20 rounded-xs max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Input Bar */}
        <div className="p-4 bg-[#0A1128] text-[#F5F2ED] flex items-center space-x-3 border-b border-[#1E293B]">
          <Search className="w-5 h-5 text-[#8C704B]" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search tracks, artists, albums, or archives..."
            className="w-full bg-transparent text-base text-[#F5F2ED] placeholder-[#94A3B8] focus:outline-none font-sans"
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-[#94A3B8] hover:text-[#F5F2ED]">
              <X className="w-4 h-4" />
            </button>
          )}
          <button onClick={onClose} className="text-[#94A3B8] hover:text-[#F5F2ED] text-xs font-mono px-2 py-1 bg-[#1E293B] rounded-xs border border-[#334155]">
            ESC
          </button>
        </div>

        {/* Results Container */}
        <div className="p-6 overflow-y-auto space-y-6">
          {!q ? (
            <div className="text-center py-8 text-[#0A1128]/60 font-serif italic text-sm">
              Type a title, performer, or region (e.g. "Isle of Man", "Sheffield", "Snaefell")
            </div>
          ) : (
            <>
              {/* Tracks Results */}
              {matchedTracks.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.18em] font-semibold block">
                    TRACKS ({matchedTracks.length})
                  </span>
                  <div className="divide-y divide-[#0A1128]/10 border border-[#0A1128]/10 rounded-xs bg-[#F5F2ED]">
                    {matchedTracks.map((track) => (
                      <div
                        key={track.id}
                        onClick={() => {
                          onPlayTrack(track);
                          onClose();
                        }}
                        className="p-3 flex items-center justify-between hover:bg-[#EFECE6] cursor-pointer transition-colors"
                      >
                        <div className="flex items-center space-x-3 min-w-0">
                          <img src={track.coverArt} alt={track.title} className="w-9 h-9 object-cover rounded-xs border border-[#0A1128]/10" />
                          <div className="min-w-0">
                            <p className="font-serif font-bold text-xs text-[#0A1128] truncate">{track.title}</p>
                            <p className="text-[11px] text-[#0A1128]/60 truncate">{track.artistName}</p>
                          </div>
                        </div>
                        <Play className="w-4 h-4 text-[#8C704B] fill-current" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Albums Results */}
              {matchedAlbums.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase text-[#8C704B] tracking-[0.18em] font-semibold block">
                    ALBUMS ({matchedAlbums.length})
                  </span>
                  <div className="grid grid-cols-2 gap-3">
                    {matchedAlbums.map((album) => (
                      <div
                        key={album.id}
                        onClick={() => {
                          onSelectAlbum(album);
                          onClose();
                        }}
                        className="p-3 bg-[#F5F2ED] border border-[#0A1128]/10 hover:border-[#8C704B] rounded-xs cursor-pointer flex items-center space-x-3 transition-colors"
                      >
                        <img src={album.coverArt} alt={album.title} className="w-10 h-10 object-cover rounded-xs border border-[#0A1128]/10" />
                        <div className="min-w-0">
                          <p className="font-serif font-bold text-xs text-[#0A1128] truncate">{album.title}</p>
                          <p className="text-[11px] text-[#0A1128]/60 truncate">{album.artistName}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {matchedTracks.length === 0 && matchedAlbums.length === 0 && (
                <p className="text-center text-xs text-[#0A1128]/60 py-8">
                  No matching recordings found for "{query}".
                </p>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
