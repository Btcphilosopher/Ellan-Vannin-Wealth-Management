import React from 'react';
import {
  Compass,
  Disc,
  BookOpen,
  Library,
  Sliders,
  BarChart3,
  Code2,
  Search,
  User,
  Radio,
  MapPin,
  Volume2
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenSearch: () => void;
  onOpenUserAccount: () => void;
  isPlaying: boolean;
  currentTrackTitle?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenSearch,
  onOpenUserAccount,
  isPlaying,
  currentTrackTitle,
}) => {
  const navItems = [
    { id: 'discover', label: 'Discover', icon: Compass },
    { id: 'collections', label: 'Collections', icon: Disc },
    { id: 'editorial', label: 'Editorial', icon: BookOpen },
    { id: 'library', label: 'Library', icon: Library },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'admin', label: 'Administration', icon: Sliders },
    { id: 'schema', label: 'System Schema', icon: Code2 },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#F5F2ED]/95 backdrop-blur-md border-b border-[#0A1128]/10">
      {/* Top Institutional Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 border-b border-[#0A1128]/10">
          
          {/* Brand Logo & Tagline */}
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setActiveTab('discover')}
              className="text-left group flex items-center space-x-3.5"
            >
              <div className="w-10 h-10 bg-[#0A1128] text-[#F5F2ED] flex items-center justify-center font-serif italic text-2xl font-light rounded-sm shadow-xs group-hover:bg-[#8C704B] transition-colors">
                A
              </div>
              <div className="flex flex-col">
                <div className="flex items-center space-x-2">
                  <span className="font-serif italic font-light text-2xl sm:text-3xl tracking-tight text-[#0A1128]">
                    Albion Audio
                  </span>
                  <span className="hidden md:inline-block text-[10px] tracking-[0.18em] font-mono uppercase bg-[#8C704B]/10 text-[#8C704B] px-2 py-0.5 rounded-xs border border-[#8C704B]/20 font-semibold">
                    ARCHIVAL & STREAMING
                  </span>
                </div>
                <p className="text-[10px] uppercase tracking-[0.2em] font-medium text-[#0A1128]/60">
                  Douglas, Isle of Man
                </p>
              </div>
            </button>
          </div>

          {/* Location & Current Playing Indicator */}
          <div className="hidden lg:flex items-center space-x-6 text-xs text-[#334155]">
            {/* Headquarters Badge */}
            <div className="flex items-center space-x-1.5 px-3 py-1 bg-[#EFECE6] rounded-xs border border-[#0A1128]/10">
              <MapPin className="w-3.5 h-3.5 text-[#8C704B]" />
              <span className="font-medium text-[#0A1128] text-[11px] tracking-wide">Douglas Ops Center</span>
            </div>

            {/* Live Playing Status Pill */}
            {isPlaying && currentTrackTitle && (
              <div className="flex items-center space-x-2 px-3 py-1 bg-[#8C704B]/10 text-[#8C704B] rounded-xs border border-[#8C704B]/20 animate-pulse">
                <Radio className="w-3.5 h-3.5 text-[#8C704B] animate-spin" />
                <span className="font-medium truncate max-w-[180px] text-xs">
                  {currentTrackTitle}
                </span>
              </div>
            )}
          </div>

          {/* Search & Account Actions */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            <button
              onClick={onOpenSearch}
              className="flex items-center space-x-2 px-3 sm:px-4 py-2 bg-[#EFECE6] hover:bg-[#E5E0D8] text-[#0A1128] text-xs font-semibold uppercase tracking-[0.1em] rounded-xs border border-[#0A1128]/15 transition-colors"
              aria-label="Search catalog"
            >
              <Search className="w-4 h-4 text-[#8C704B]" />
              <span className="hidden sm:inline">Search</span>
              <kbd className="hidden sm:inline text-[9px] bg-[#F5F2ED] px-1.5 py-0.5 rounded border border-[#0A1128]/20 text-[#0A1128]/70 font-mono">
                ⌘K
              </kbd>
            </button>

            <button
              onClick={onOpenUserAccount}
              className="flex items-center space-x-2 px-3.5 py-2 bg-[#0A1128] hover:bg-[#8C704B] text-[#F5F2ED] text-xs font-semibold uppercase tracking-[0.1em] rounded-xs transition-colors"
              aria-label="User Account"
            >
              <User className="w-4 h-4" />
              <span className="hidden md:inline">Account</span>
            </button>
          </div>
        </div>

        {/* Primary Navigation Tabs */}
        <nav className="flex items-center justify-between overflow-x-auto py-3 no-scrollbar">
          <div className="flex items-center space-x-1 sm:space-x-3 min-w-max">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center space-x-2 px-3.5 py-1.5 text-[11px] uppercase tracking-[0.15em] font-semibold transition-all rounded-xs ${
                    isActive
                      ? 'bg-[#0A1128] text-[#F5F2ED] shadow-xs'
                      : 'text-[#0A1128]/70 hover:text-[#0A1128] hover:bg-[#EFECE6]'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#8C704B]' : 'opacity-60'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="hidden xl:flex items-center text-[10px] uppercase tracking-[0.2em] font-mono text-[#0A1128]/50 pl-4 border-l border-[#0A1128]/10">
            <span>54.1500° N, 4.4833° W</span>
          </div>
        </nav>
      </div>
    </header>
  );
};
