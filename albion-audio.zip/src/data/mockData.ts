import { Track, Album, Artist, EditorialArticle, CuratedCollection, Playlist, UserProfile, AnalyticsMetric } from '../types';

// High-quality public domain / royalty-free audio streams for authentic listening
// backed up by Web Audio synthesis in AudioEngine if needed
const SAMPLE_AUDIO_URLS = [
  'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=celtic-irish-folk-music-113303.mp3',
  'https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=ambient-piano-10781.mp3',
  'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8b7f8e81d.mp3?filename=relaxing-celtic-harp-10118.mp3',
  'https://cdn.pixabay.com/download/audio/2021/11/24/audio_3d19be6a89.mp3?filename=classical-string-quartet-9937.mp3',
  'https://cdn.pixabay.com/download/audio/2022/10/14/audio_993998b671.mp3?filename=electronic-ambient-synth-122941.mp3',
  'https://cdn.pixabay.com/download/audio/2022/03/24/audio_1384f686c5.mp3?filename=folk-acoustic-guitar-10334.mp3'
];

export const MOCK_TRACKS: Track[] = [
  {
    id: 'tr-01',
    title: 'Snaefell Summit Nocturne',
    artistId: 'art-01',
    artistName: 'Elora Vance & The Manx Chamber Ensemble',
    albumId: 'alb-01',
    albumTitle: 'Isle of Man: Echoes Across the Iris Sea',
    coverArt: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop',
    duration: 214,
    audioUrl: SAMPLE_AUDIO_URLS[0],
    year: 2025,
    composer: 'Elora Vance',
    producer: 'Julian Heathcote',
    label: 'Albion Archival Records (Douglas)',
    genre: 'Modern Classical',
    region: 'Isle of Man',
    lyrics: `[Instrumental Opening: Cellos and Irish Sea Wind Flutes]
Over the ridge of Snaefell high,
Where seven kingdoms meet the sky.
The tide rolls softly through Douglas Bay,
As night comes down to close the day.`,
    editorialNotes: 'Recorded in St George\'s Church, Douglas, utilizing historic natural reverberation of Manx stone architecture.',
    playCount: 14280,
    isFavorite: true,
  },
  {
    id: 'tr-02',
    title: 'The Tynwald Gathering (Lament for Peel Castle)',
    artistId: 'art-01',
    artistName: 'Elora Vance & The Manx Chamber Ensemble',
    albumId: 'alb-01',
    albumTitle: 'Isle of Man: Echoes Across the Iris Sea',
    coverArt: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop',
    duration: 268,
    audioUrl: SAMPLE_AUDIO_URLS[2],
    year: 2025,
    composer: 'Traditional (Arr. Vance)',
    producer: 'Julian Heathcote',
    label: 'Albion Archival Records (Douglas)',
    genre: 'Celtic Folk',
    region: 'Isle of Man',
    editorialNotes: 'Features authentic Manx Gaelic harp motifs documented in the 1896 Clague Collection.',
    playCount: 9820,
    isFavorite: false,
  },
  {
    id: 'tr-03',
    title: 'Sheffield Steel & Cold Analog Loops',
    artistId: 'art-02',
    artistName: 'The Sheffield Foundry Collective',
    albumId: 'alb-02',
    albumTitle: 'Sheffield Steel & Synthesizers',
    coverArt: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    duration: 312,
    audioUrl: SAMPLE_AUDIO_URLS[4],
    year: 2024,
    composer: 'Marcus Wright',
    producer: 'Sheffield Audio Guild',
    label: 'Northern Industrial Press',
    genre: 'Electronic',
    region: 'England',
    editorialNotes: 'Constructed using original 1978 Moog synthesizers blended with field recordings from Attercliffe steelworks.',
    playCount: 18940,
    isFavorite: true,
  },
  {
    id: 'tr-04',
    title: 'Don Valley At Twilight',
    artistId: 'art-02',
    artistName: 'The Sheffield Foundry Collective',
    albumId: 'alb-02',
    albumTitle: 'Sheffield Steel & Synthesizers',
    coverArt: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    duration: 198,
    audioUrl: SAMPLE_AUDIO_URLS[1],
    year: 2024,
    composer: 'Marcus Wright & Sarah Lindley',
    producer: 'Sheffield Audio Guild',
    label: 'Northern Industrial Press',
    genre: 'Ambient',
    region: 'England',
    playCount: 11200,
    isFavorite: false,
  },
  {
    id: 'tr-05',
    title: 'The Mist of Skye (Hebridean Ballad)',
    artistId: 'art-03',
    artistName: 'Gallowgate Folk Quartet',
    albumId: 'alb-03',
    albumTitle: 'Highland Mist: Ballads from the Hebrides',
    coverArt: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=800&auto=format&fit=crop',
    duration: 245,
    audioUrl: SAMPLE_AUDIO_URLS[0],
    year: 2025,
    composer: 'Traditional Gaelic',
    producer: 'Alistair MacLeod',
    label: 'Celtic Heritage Society',
    genre: 'Folk',
    region: 'Scotland',
    lyrics: `Gaelic Verse:
Bho na h-Innse Gall gu tìr nam beann,
Tha 'n ceò a' titeam gu ciùin is sgann.
(From the Hebrides to the mountain land,
The mist falls quiet across the sand.)`,
    playCount: 22100,
    isFavorite: true,
  },
  {
    id: 'tr-06',
    title: 'Nocturne for St. Jude’s in D Minor',
    artistId: 'art-04',
    artistName: 'Llandaff Cathedral Choir & Strings',
    albumId: 'alb-04',
    albumTitle: 'Nocturnes for St. Jude’s',
    coverArt: 'https://images.unsplash.com/photo-1519817650390-64a93db51149?q=80&w=800&auto=format&fit=crop',
    duration: 340,
    audioUrl: SAMPLE_AUDIO_URLS[3],
    year: 2026,
    composer: 'Dr. Arthur Pendelton',
    producer: 'Cardiff Choral Archives',
    label: 'Isle Press Recordings',
    genre: 'Classical',
    region: 'Wales',
    playCount: 8400,
    isFavorite: false,
  },
  {
    id: 'tr-07',
    title: 'Cornish Coastline Reel',
    artistId: 'art-05',
    artistName: 'Penzance Coastal Ensemble',
    albumId: 'alb-05',
    albumTitle: 'The North Country Variations',
    coverArt: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=800&auto=format&fit=crop',
    duration: 185,
    audioUrl: SAMPLE_AUDIO_URLS[5],
    year: 2025,
    composer: 'Penzance Heritage Players',
    producer: 'Rupert Croft',
    label: 'Albion Classical',
    genre: 'Folk',
    region: 'Cornwall',
    playCount: 7650,
    isFavorite: false,
  }
];

export const MOCK_ALBUMS: Album[] = [
  {
    id: 'alb-01',
    title: 'Isle of Man: Echoes Across the Iris Sea',
    artistId: 'art-01',
    artistName: 'Elora Vance & The Manx Chamber Ensemble',
    coverArt: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop',
    releaseYear: 2025,
    genre: 'Modern Classical',
    label: 'Albion Archival Records (Douglas)',
    tracks: [MOCK_TRACKS[0], MOCK_TRACKS[1]],
    editorialDescription: 'A landmark archival suite commissioned by the Isle of Man Cultural Trust, blending 19th-century Celtic harp transcriptions with contemporary chamber strings and coastal field recordings.',
    composer: 'Elora Vance',
    producer: 'Julian Heathcote',
    recordingLocation: 'St. George\'s Church, Douglas, Isle of Man',
    catalogNumber: 'ALB-IOM-001',
    featured: true
  },
  {
    id: 'alb-02',
    title: 'Sheffield Steel & Synthesizers',
    artistId: 'art-02',
    artistName: 'The Sheffield Foundry Collective',
    coverArt: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    releaseYear: 2024,
    genre: 'Electronic',
    label: 'Northern Industrial Press',
    tracks: [MOCK_TRACKS[2], MOCK_TRACKS[3]],
    editorialDescription: 'A stark, hypnotic celebration of South Yorkshire\'s industrial legacy, pairing vintage modular synth structures with factory metallic acoustic acoustics.',
    composer: 'Marcus Wright',
    producer: 'Sheffield Audio Guild',
    recordingLocation: 'Kelham Island Studios, Sheffield',
    catalogNumber: 'NIP-2024-09',
    featured: true
  },
  {
    id: 'alb-03',
    title: 'Highland Mist: Ballads from the Hebrides',
    artistId: 'art-03',
    artistName: 'Gallowgate Folk Quartet',
    coverArt: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=800&auto=format&fit=crop',
    releaseYear: 2025,
    genre: 'Folk',
    label: 'Celtic Heritage Society',
    tracks: [MOCK_TRACKS[4]],
    editorialDescription: 'Traditional Scottish Gaelic songs restored from wax cylinders in Edinburgh University archives, rendered with acoustic precision.',
    composer: 'Traditional',
    producer: 'Alistair MacLeod',
    recordingLocation: 'Stornoway Community Hall, Isle of Lewis',
    catalogNumber: 'CHS-SC-882',
    featured: true
  },
  {
    id: 'alb-04',
    title: 'Nocturnes for St. Jude’s',
    artistId: 'art-04',
    artistName: 'Llandaff Cathedral Choir & Strings',
    coverArt: 'https://images.unsplash.com/photo-1519817650390-64a93db51149?q=80&w=800&auto=format&fit=crop',
    releaseYear: 2026,
    genre: 'Classical',
    label: 'Isle Press Recordings',
    tracks: [MOCK_TRACKS[5]],
    editorialDescription: 'Solemn liturgical strings recorded in Cardiff, exploring sacred acoustics and British minimalist composition.',
    composer: 'Dr. Arthur Pendelton',
    producer: 'Cardiff Choral Archives',
    recordingLocation: 'Llandaff Cathedral, Cardiff',
    catalogNumber: 'IPR-WALES-04',
    featured: false
  },
  {
    id: 'alb-05',
    title: 'The North Country Variations',
    artistId: 'art-05',
    artistName: 'Penzance Coastal Ensemble',
    coverArt: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=800&auto=format&fit=crop',
    releaseYear: 2025,
    genre: 'Folk',
    label: 'Albion Classical',
    tracks: [MOCK_TRACKS[6]],
    editorialDescription: 'Maritime violin and acoustic guitar compositions reflecting the rugged beauty of the Cornish peninsula.',
    composer: 'Penzance Heritage Players',
    producer: 'Rupert Croft',
    recordingLocation: 'Minack Open Air Stage, Penzance',
    catalogNumber: 'ALB-CORN-12',
    featured: false
  }
];

export const MOCK_ARTISTS: Artist[] = [
  {
    id: 'art-01',
    name: 'Elora Vance & The Manx Chamber Ensemble',
    region: 'Douglas, Isle of Man',
    genre: 'Modern Classical / Celtic',
    imageUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=800&auto=format&fit=crop',
    biography: 'Formed in Douglas in 2021, Elora Vance leads an ensemble dedicated to preserving and revitalizing Celtic maritime compositions. Their work bridges centuries of island song craft with modern minimalist arrangements.',
    featuredYear: '2025 Isle of Man Cultural Laureate',
    discography: [
      { albumId: 'alb-01', title: 'Isle of Man: Echoes Across the Iris Sea', year: 2025, coverArt: MOCK_ALBUMS[0].coverArt }
    ],
    relatedArtistIds: ['art-03', 'art-04']
  },
  {
    id: 'art-02',
    name: 'The Sheffield Foundry Collective',
    region: 'South Yorkshire, England',
    genre: 'Industrial Electronic',
    imageUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=800&auto=format&fit=crop',
    biography: 'A consortium of sound designers and synth purists based in Sheffield. They utilize analog synthesizers and recorded industrial machinery noise to craft evocative, architectural soundscapes.',
    featuredYear: '2024 Northern Arts Innovation Award',
    discography: [
      { albumId: 'alb-02', title: 'Sheffield Steel & Synthesizers', year: 2024, coverArt: MOCK_ALBUMS[1].coverArt }
    ],
    relatedArtistIds: ['art-01']
  },
  {
    id: 'art-03',
    name: 'Gallowgate Folk Quartet',
    region: 'Glasgow, Scotland',
    genre: 'Gaelic Folk',
    imageUrl: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?q=80&w=800&auto=format&fit=crop',
    biography: 'Renowned for authentic acoustic instrumentation and archival Gaelic balladry, Gallowgate Folk Quartet performs traditional acoustic arrangements across the UK and European cultural festivals.',
    featuredYear: '2025 Scottish Heritage Fellowship',
    discography: [
      { albumId: 'alb-03', title: 'Highland Mist: Ballads from the Hebrides', year: 2025, coverArt: MOCK_ALBUMS[2].coverArt }
    ],
    relatedArtistIds: ['art-01', 'art-05']
  },
  {
    id: 'art-04',
    name: 'Llandaff Cathedral Choir & Strings',
    region: 'Cardiff, Wales',
    genre: 'Choral Classical',
    imageUrl: 'https://images.unsplash.com/photo-1519817650390-64a93db51149?q=80&w=800&auto=format&fit=crop',
    biography: 'Dating back to sacred vocal traditions in Wales, Llandaff Cathedral Choir collaborates with contemporary Welsh string quartets to produce contemplative liturgical recordings.',
    featuredYear: 'Royal Patronage Archival Series',
    discography: [
      { albumId: 'alb-04', title: 'Nocturnes for St. Jude’s', year: 2026, coverArt: MOCK_ALBUMS[3].coverArt }
    ],
    relatedArtistIds: ['art-01']
  },
  {
    id: 'art-05',
    name: 'Penzance Coastal Ensemble',
    region: 'Cornwall, England',
    genre: 'Cornish Folk Acoustic',
    imageUrl: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=800&auto=format&fit=crop',
    biography: 'Drawing inspiration from maritime sea shanties, cliffside gales, and Cornish folk lore, the Penzance Coastal Ensemble performs fingerstyle guitar and fiddle arrangements.',
    featuredYear: '2025 Cornish Cultural Heritage Preservation Award',
    discography: [
      { albumId: 'alb-05', title: 'The North Country Variations', year: 2025, coverArt: MOCK_ALBUMS[4].coverArt }
    ],
    relatedArtistIds: ['art-03']
  }
];

export const MOCK_EDITORIAL_ARTICLES: EditorialArticle[] = [
  {
    id: 'ed-01',
    title: 'The Soundscape of Tynwald Hill: Musical Stewardship in the Iris Sea',
    subtitle: 'How the Isle of Man became an epicenter for preserving Celtic and British acoustic traditions.',
    author: 'Dr. Julian Heathcote',
    authorRole: 'Head of Musicology, Douglas Cultural Institute',
    date: 'August 2026',
    readTime: '6 min read',
    category: 'Essay',
    imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1200&auto=format&fit=crop',
    imageCaption: 'The rugged coastline near Peel Castle, Isle of Man.',
    excerpt: 'Situated at the geographical heart of the British Isles, the Isle of Man has long served as a cultural crossroads where Manx Gaelic, Norse, and Anglo-Saxon musical streams merge.',
    content: [
      'For centuries, the Irish Sea was not a barrier but a highway. Ships traveling between Liverpool, Belfast, Dublin, Glasgow, and Cardiff converged upon the Isle of Man, bringing with them a rich tapestry of fiddles, harps, and vocal traditions.',
      'In our contemporary era, Albion Audio is proud to maintain its headquarters in Douglas, Isle of Man. Here, recording studios utilize the natural limestone acoustics of 19th-century halls to record lossless acoustic performances.',
      'From the annual Tynwald Parliament ceremonies to coastal field recordings of breaking waves on Ramsay beach, the island offers an unhurried, timeless space where music is treated not as ephemeral entertainment, but as enduring cultural stewardship.'
    ],
    featuredAlbumId: 'alb-01',
    regionTag: 'Isle of Man'
  },
  {
    id: 'ed-02',
    title: 'Steel Rhythms & Analog Waves: Sheffield’s Industrial Electronics',
    subtitle: 'Tracing the line from Yorkshire factory floors to contemporary British ambient synthesis.',
    author: 'Eleanor Vance',
    authorRole: 'Senior Curator, British Sound Archive',
    date: 'July 2026',
    readTime: '8 min read',
    category: 'History',
    imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1200&auto=format&fit=crop',
    imageCaption: 'Analog synthesizers inside Kelham Island Recording Guild, Sheffield.',
    excerpt: 'The rhythmic clang of heavy machinery in South Yorkshire gave birth to a uniquely British electronic sensibility—cold, precise, yet imbued with deep soul.',
    content: [
      'In the late 1970s, young musicians in Sheffield turned from guitars toward tape machines and voltage-controlled oscillators. They captured the mechanical resonance of the steel mills, forging a sound that was both futuristic and grounded in working-class craftsmanship.',
      'Today, artists like the Sheffield Foundry Collective continue this heritage. By pairing vintage Moog modular racks with high-resolution spatial recordings, they demonstrate that industrial heritage remains a vital, living artistic current in contemporary Britain.'
    ],
    featuredAlbumId: 'alb-02',
    regionTag: 'England'
  },
  {
    id: 'ed-03',
    title: 'Preserving Gaelic Ballads in the Hebridean Archipelago',
    subtitle: 'Archival techniques and high-fidelity restoration of Scottish island vocal traditions.',
    author: 'Alistair MacLeod',
    authorRole: 'Edinburgh Folk Institute',
    date: 'June 2026',
    readTime: '5 min read',
    category: 'Archive',
    imageUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=1200&auto=format&fit=crop',
    imageCaption: 'The mist-laden peaks of Skye.',
    excerpt: 'Restoring century-old wax cylinders using modern laser optical scanning allows us to hear Gaelic Gaelic songstresses with crystalline clarity.',
    content: [
      'The Gaelic song tradition of the Western Isles relied on oral transmission across generations. Waulking songs, sea ballads, and nocturnal lullabies formed the living fabric of community life.',
      'Through collaborative projects with the Scottish Heritage Society, Albion Audio provides uncompressed 24-bit streams of these historical master recordings alongside full translations and musicological commentary.'
    ],
    featuredAlbumId: 'alb-03',
    regionTag: 'Scotland'
  }
];

export const MOCK_COLLECTIONS: CuratedCollection[] = [
  {
    id: 'col-01',
    title: 'The North',
    subtitle: 'Industrial, Folk & Modern Classical from Yorkshire, Cumbria & Lancashire',
    description: 'A curated selection celebrating the rugged terrain, factory heritage, and timeless acoustic traditions of Northern England.',
    coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    region: 'Northern England',
    trackCount: 18,
    featuredTracks: [MOCK_TRACKS[2], MOCK_TRACKS[3]],
    tags: ['Industrial', 'Synth', 'Post-Rock', 'Northern']
  },
  {
    id: 'col-02',
    title: 'The Celtic Coast',
    subtitle: 'Maritime traditional & harp folk from Isle of Man, Cornwall & Wales',
    description: 'Acoustic ballads, coastal harps, and wind ensembles recorded along the Irish Sea and Celtic coastal sea cliffs.',
    coverImage: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop',
    region: 'Celtic Nations',
    trackCount: 24,
    featuredTracks: [MOCK_TRACKS[0], MOCK_TRACKS[1], MOCK_TRACKS[6]],
    tags: ['Celtic', 'Harp', 'Acoustic', 'Maritime']
  },
  {
    id: 'col-03',
    title: 'Modern Britain',
    subtitle: 'Minimalist strings, piano nocturnes & contemporary British composition',
    description: 'Sophisticated chamber music and quiet piano pieces commissioned from contemporary British conservatories.',
    coverImage: 'https://images.unsplash.com/photo-1519817650390-64a93db51149?q=80&w=800&auto=format&fit=crop',
    region: 'United Kingdom',
    trackCount: 16,
    featuredTracks: [MOCK_TRACKS[0], MOCK_TRACKS[5]],
    tags: ['Classical', 'Piano', 'Strings', 'Minimalism']
  },
  {
    id: 'col-04',
    title: 'Electronic Britain',
    subtitle: 'Modular synthesizers, tape loops & ambient soundscapes',
    description: 'A focus on pioneering British electronic composition, from BBC Radiophonic Workshop influences to modern ambient suites.',
    coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=800&auto=format&fit=crop',
    region: 'UK & Isle of Man',
    trackCount: 20,
    featuredTracks: [MOCK_TRACKS[2], MOCK_TRACKS[3]],
    tags: ['Ambient', 'Modular', 'Electronic', 'Loops']
  },
  {
    id: 'col-05',
    title: 'British Folk',
    subtitle: 'Fingerstyle acoustic guitar, ballads & archival songbooks',
    description: 'Classic fingerpicking and pastoral ballads echoing through the vales of Albion.',
    coverImage: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=800&auto=format&fit=crop',
    region: 'Britain',
    trackCount: 22,
    featuredTracks: [MOCK_TRACKS[4], MOCK_TRACKS[6]],
    tags: ['Folk', 'Guitar', 'Ballads', 'Traditional']
  },
  {
    id: 'col-06',
    title: 'The Isles',
    subtitle: 'Isle of Man, Hebrides, Orkney & Anglesey recordings',
    description: 'Music originating strictly from island archipelagos, captured with coastal spatial reverberation.',
    coverImage: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=800&auto=format&fit=crop',
    region: 'Isle of Man & Scottish Isles',
    trackCount: 14,
    featuredTracks: [MOCK_TRACKS[0], MOCK_TRACKS[4]],
    tags: ['Islands', 'Manx', 'Hebrides', 'Gaelic']
  }
];

export const MOCK_USER_PROFILE: UserProfile = {
  name: 'Thomas Radcliffe',
  location: 'Douglas, Isle of Man',
  joinedDate: 'October 2024',
  membershipTier: 'Patron Member',
  preferredAudioQuality: 'FLAC 24-bit/96kHz',
  themeAccent: 'Forest Green',
  autoPlayNext: true,
  crossfade: 2
};

export const MOCK_ANALYTICS_DATA: AnalyticsMetric[] = [
  { date: 'Mon', streams: 14200, activeListeners: 3840, bandwidthGB: 182, avgDurationMin: 28 },
  { date: 'Tue', streams: 15800, activeListeners: 4120, bandwidthGB: 205, avgDurationMin: 31 },
  { date: 'Wed', streams: 16900, activeListeners: 4450, bandwidthGB: 224, avgDurationMin: 34 },
  { date: 'Thu', streams: 18400, activeListeners: 4900, bandwidthGB: 250, avgDurationMin: 32 },
  { date: 'Fri', streams: 22100, activeListeners: 5800, bandwidthGB: 310, avgDurationMin: 39 },
  { date: 'Sat', streams: 26500, activeListeners: 6950, bandwidthGB: 385, avgDurationMin: 45 },
  { date: 'Sun', streams: 24200, activeListeners: 6300, bandwidthGB: 340, avgDurationMin: 42 }
];
