import { Track } from '../types';

export type RepeatMode = 'off' | 'all' | 'one';

export class AudioEngine {
  private audio: HTMLAudioElement;
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private synthInterval: number | null = null;
  private isSynthFallback = false;

  public currentTrack: Track | null = null;
  public queue: Track[] = [];
  public currentIndex = -1;

  public isPlaying = false;
  public currentTime = 0;
  public duration = 0;
  public volume = 0.85;
  public playbackRate = 1.0;
  public isMuted = false;
  public isShuffle = false;
  public repeatMode: RepeatMode = 'off';
  public bufferedProgress = 0; // 0 to 100%

  private listeners: Set<() => void> = new Set();

  constructor() {
    this.audio = new Audio();
    this.audio.crossOrigin = 'anonymous';
    this.audio.volume = this.volume;

    this.setupAudioListeners();
  }

  private setupAudioListeners() {
    this.audio.addEventListener('timeupdate', () => {
      this.currentTime = this.audio.currentTime;
      this.duration = this.audio.duration || this.currentTrack?.duration || 0;
      this.updateBufferedProgress();
      this.notify();
    });

    this.audio.addEventListener('play', () => {
      this.isPlaying = true;
      this.notify();
    });

    this.audio.addEventListener('pause', () => {
      this.isPlaying = false;
      this.notify();
    });

    this.audio.addEventListener('ended', () => {
      this.handleTrackEnded();
    });

    this.audio.addEventListener('error', (e) => {
      console.warn('HTML5 Audio failed or blocked, engaging Web Audio Synthesizer fallback.', e);
      this.startSynthFallback();
    });

    this.audio.addEventListener('progress', () => {
      this.updateBufferedProgress();
      this.notify();
    });
  }

  private updateBufferedProgress() {
    if (this.audio.buffered.length > 0) {
      const bufferedEnd = this.audio.buffered.end(this.audio.buffered.length - 1);
      const dur = this.audio.duration || this.currentTrack?.duration || 1;
      this.bufferedProgress = Math.min(100, Math.round((bufferedEnd / dur) * 100));
    } else {
      this.bufferedProgress = this.isPlaying ? 85 : 0;
    }
  }

  public subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  public initWebAudio() {
    if (this.audioCtx) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioCtx();
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 64;

      try {
        this.sourceNode = this.audioCtx.createMediaElementSource(this.audio);
        this.sourceNode.connect(this.analyser);
        this.analyser.connect(this.audioCtx.destination);
      } catch (err) {
        console.warn('MediaElementSource already connected or cross-origin restricted:', err);
      }
    } catch (e) {
      console.warn('Web Audio API not supported on this browser', e);
    }
  }

  public setQueue(tracks: Track[], startIndex = 0, autoPlay = true) {
    this.queue = [...tracks];
    this.currentIndex = startIndex;
    if (tracks[startIndex]) {
      this.playTrack(tracks[startIndex], autoPlay);
    }
  }

  public playTrack(track: Track, autoPlay = true) {
    this.initWebAudio();
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }

    this.stopSynthFallback();
    this.currentTrack = track;
    this.duration = track.duration;
    this.currentTime = 0;
    this.audio.src = track.audioUrl;
    this.audio.playbackRate = this.playbackRate;
    this.audio.volume = this.isMuted ? 0 : this.volume;

    if (autoPlay) {
      const playPromise = this.audio.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.warn('Playback prevented by browser policy or missing file. Starting fallback synth mode.', err);
          this.startSynthFallback();
        });
      }
    } else {
      this.isPlaying = false;
      this.notify();
    }
  }

  public togglePlay() {
    this.initWebAudio();
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }

    if (this.isSynthFallback) {
      if (this.isPlaying) {
        this.stopSynthFallback();
      } else {
        this.startSynthFallback();
      }
      return;
    }

    if (!this.currentTrack && this.queue.length > 0) {
      this.playTrack(this.queue[0]);
      return;
    }

    if (this.isPlaying) {
      this.audio.pause();
    } else {
      this.audio.play().catch(() => this.startSynthFallback());
    }
  }

  public seek(seconds: number) {
    this.currentTime = seconds;
    if (this.isSynthFallback) {
      this.notify();
      return;
    }
    this.audio.currentTime = seconds;
    this.notify();
  }

  public setVolume(val: number) {
    this.volume = Math.max(0, Math.min(1, val));
    this.audio.volume = this.isMuted ? 0 : this.volume;
    this.notify();
  }

  public toggleMute() {
    this.isMuted = !this.isMuted;
    this.audio.volume = this.isMuted ? 0 : this.volume;
    this.notify();
  }

  public setPlaybackRate(rate: number) {
    this.playbackRate = rate;
    this.audio.playbackRate = rate;
    this.notify();
  }

  public toggleShuffle() {
    this.isShuffle = !this.isShuffle;
    this.notify();
  }

  public cycleRepeatMode() {
    if (this.repeatMode === 'off') this.repeatMode = 'all';
    else if (this.repeatMode === 'all') this.repeatMode = 'one';
    else this.repeatMode = 'off';
    this.notify();
  }

  public nextTrack() {
    if (this.queue.length === 0) return;
    if (this.isShuffle) {
      const randIndex = Math.floor(Math.random() * this.queue.length);
      this.currentIndex = randIndex;
    } else {
      this.currentIndex = (this.currentIndex + 1) % this.queue.length;
    }
    this.playTrack(this.queue[this.currentIndex]);
  }

  public prevTrack() {
    if (this.queue.length === 0) return;
    if (this.currentTime > 3) {
      this.seek(0);
      return;
    }
    this.currentIndex = (this.currentIndex - 1 + this.queue.length) % this.queue.length;
    this.playTrack(this.queue[this.currentIndex]);
  }

  private handleTrackEnded() {
    if (this.repeatMode === 'one' && this.currentTrack) {
      this.seek(0);
      this.audio.play();
    } else if (this.repeatMode === 'all' || this.currentIndex < this.queue.length - 1) {
      this.nextTrack();
    } else {
      this.isPlaying = false;
      this.notify();
    }
  }

  // Fallback procedural acoustic generator if external URL audio fails
  private startSynthFallback() {
    this.isSynthFallback = true;
    this.isPlaying = true;
    this.notify();

    if (this.synthInterval) clearInterval(this.synthInterval);

    // British & Celtic harmony chord notes (A minor / D minor acoustic chords)
    const notes = [220, 261.63, 329.63, 392.00, 440.00, 523.25, 659.25];

    this.synthInterval = window.setInterval(() => {
      if (!this.isPlaying) return;
      this.currentTime += 1;
      if (this.currentTime >= (this.currentTrack?.duration || 180)) {
        this.handleTrackEnded();
        return;
      }

      if (this.audioCtx && this.volume > 0 && !this.isMuted) {
        try {
          const osc = this.audioCtx.createOscillator();
          const gain = this.audioCtx.createGain();

          const freq = notes[Math.floor(Math.random() * notes.length)];
          osc.frequency.value = freq;
          osc.type = 'sine';

          gain.gain.setValueAtTime(0.08 * this.volume, this.audioCtx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + 1.8);

          osc.connect(gain);
          gain.connect(this.audioCtx.destination);

          osc.start();
          osc.stop(this.audioCtx.currentTime + 1.8);
        } catch {
          // ignore
        }
      }
      this.notify();
    }, 1000);
  }

  private stopSynthFallback() {
    this.isSynthFallback = false;
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
  }

  public getVisualizerData(): Uint8Array {
    if (this.analyser) {
      const bufferLength = this.analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      this.analyser.getByteFrequencyData(dataArray);
      return dataArray;
    }
    // Return subtle simulated wave data if analyzer is not connected
    const simulated = new Uint8Array(32);
    if (this.isPlaying) {
      for (let i = 0; i < 32; i++) {
        simulated[i] = Math.floor(Math.sin(Date.now() / 200 + i) * 60 + 80);
      }
    }
    return simulated;
  }
}

export const globalAudioEngine = new AudioEngine();
