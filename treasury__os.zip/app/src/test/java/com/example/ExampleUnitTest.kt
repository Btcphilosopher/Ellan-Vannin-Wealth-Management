package com.example

import com.example.domain.engine.*
import com.example.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testTgaLedgerInvariant() {
        val inflows = listOf(
            CashFlowItem("IN-1", "2026-10-05", "Tax Receipts", "IRS", 15.0, CashFlowDirection.INFLOW, 100.0, "IRS"),
            CashFlowItem("IN-2", "2026-10-05", "Debt Issuance", "Auction", 50.0, CashFlowDirection.INFLOW, 100.0, "Treasury")
        )
        val outflows = listOf(
            CashFlowItem("OUT-1", "2026-10-05", "Social Security Benefits", "SSA", 20.0, CashFlowDirection.OUTFLOW, 100.0, "SSA"),
            CashFlowItem("OUT-2", "2026-10-05", "Maturing Bill Redemption", "Roll", 40.0, CashFlowDirection.OUTFLOW, 100.0, "Treasury")
        )

        val account = TGAEngine.reconcileDailyCash(
            accountId = "TGA-TEST",
            date = "2026-10-05",
            openingBalanceBillions = 750.0,
            inflows = inflows,
            outflows = outflows
        )

        assertTrue(account.isLedgerBalanced)
        assertEquals(755.0, account.closingBalanceBillions, 0.001)
        assertEquals(5.0, account.fedReserveDrainImpactBillions, 0.001)
    }

    @Test
    fun testDutchAuctionClearing() {
        val nonComp = listOf(NonCompetitiveBid("NC-1", "Retail", 2.0))
        val comp = listOf(
            CompetitiveBid("B1", "D1", "Dealer 1", BidderCategory.PRIMARY_DEALER, 4.35, 10.0),
            CompetitiveBid("B2", "D2", "Dealer 2", BidderCategory.PRIMARY_DEALER, 4.38, 20.0),
            CompetitiveBid("B3", "D3", "Dealer 3", BidderCategory.PRIMARY_DEALER, 4.40, 20.0)
        )

        val auction = AuctionEngine.clearAuction(
            auctionId = "AUC-TEST",
            cusip = "91282TEST1",
            securityType = SecurityType.NOTE_10Y,
            securityName = "10-Year Test Note",
            offeringAmountBillions = 30.0,
            wiYieldPct = 4.37,
            nonCompBids = nonComp,
            competitiveBids = comp,
            announcementDate = "2026-10-01",
            auctionDate = "2026-10-05",
            settlementDate = "2026-10-15",
            maturityDate = "2036-10-15"
        )

        // Offering = 30.0, NonComp = 2.0 -> Competitive Offering = 28.0
        // B1 (10.0 @ 4.35) awarded 10.0
        // B2 (20.0 @ 4.38) awarded 18.0 (pro-rata 90%)
        // B3 (20.0 @ 4.40) awarded 0.0
        // Stop out yield = 4.38
        assertEquals(4.38, auction.stopOutYieldPct, 0.001)
        assertEquals(30.0, auction.totalAwarded, 0.001)
        assertEquals(1.0, auction.tailBasisPoints, 0.001) // 4.38 - 4.37 = 1 bp
    }

    @Test
    fun testMonteCarloVaR() {
        val mc = MonteCarloEngine.runSimulation(iterations = 1000)
        assertTrue(mc.p99InterestCostBillions >= mc.p95InterestCostBillions)
        assertTrue(mc.p95InterestCostBillions >= mc.meanInterestCostBillions)
        assertTrue(mc.distributionBins.isNotEmpty())
    }

    @Test
    fun testYieldCurveAndRepo() {
        val curve = YieldCurveEngine.buildYieldCurve()
        assertEquals(11, curve.size)
        assertTrue(curve.first().parYieldPct > 0.0)
        val repo = YieldCurveEngine.getRepoMarketState()
        assertEquals(4.82, repo.sofrRatePct, 0.01)
    }
}
