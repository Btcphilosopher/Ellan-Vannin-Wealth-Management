package com.example.data.repository

import com.example.domain.engine.*
import com.example.domain.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

data class OperatingDayPhase(
    val timeLabel: String,
    val phaseName: String,
    val description: String
)

data class FiscalFlowNode(
    val id: String,
    val label: String,
    val category: String,
    val amountBillions: Double,
    val isSource: Boolean = false
)

data class FiscalFlowLink(
    val fromNodeId: String,
    val toNodeId: String,
    val amountBillions: Double,
    val description: String,
    val flowVelocity: String = "DAILY BATCH"
)

data class TreasuryOSState(
    val currentDate: String = "2026-10-05",
    val operatingPhase: OperatingDayPhase = OperatingDayPhase("11:00 EST", "BID COLLECTION & AUCTION LAB", "Order book receiving competitive primary dealer and indirect foreign bids"),
    val tgaAccount: TreasuryCashAccount,
    val dailyHistory: List<TreasuryCashAccount>,
    val cashForecasts: List<HorizonForecast>,
    val recentInflows: List<CashFlowItem>,
    val recentOutflows: List<CashFlowItem>,
    val securities: List<TreasurySecurity>,
    val portfolioMetrics: PortfolioMetrics,
    val maturityWall: List<MaturityBucket>,
    val auctions: List<AuctionRecord>,
    val upcomingCalendar: List<AuctionRecord>,
    val activeSimulationAuction: AuctionRecord,
    val yieldCurve: List<YieldCurvePoint>,
    val repoMarket: RepoMarketLink,
    val refundingScenarios: List<RefundingMixProposal>,
    val selectedRefundingIndex: Int = 0,
    val buybackOperations: List<BuybackOperation>,
    val vaultAssets: List<VaultAsset>,
    val shipmentManifests: List<ShipmentManifest>,
    val activeScenario: StressScenario = StressScenario.BASELINE,
    val monteCarloMetrics: MonteCarloMetrics,
    val fiscalNodes: List<FiscalFlowNode>,
    val fiscalLinks: List<FiscalFlowLink>,
    val auditEvents: List<TreasuryEvent>,
    val terminalHistory: List<String> = listOf(
        "TREASURY//OS v3.7.2 [Sovereign Fiscal & Debt Terminal]",
        "Connected to SYNTHETIC FEDWIRE / FISCALSERVICE DATA BUS",
        "System Ready. Type 'help' for command reference."
    ),
    val aiInsightQuery: String = "Why is the 90-day borrowing requirement projected at $1.31T?",
    val aiInsightResponse: String = ""
)

class TreasuryRepository {

    private val _state = MutableStateFlow(createInitialState())
    val state: StateFlow<TreasuryOSState> = _state.asStateFlow()

    init {
        // Run initial AI explanation
        generateAiExplanation(_state.value.aiInsightQuery)
    }

    private fun createInitialState(): TreasuryOSState {
        val initialInflows = listOf(
            CashFlowItem("IN-01", "2026-10-05", "Individual Withholding Taxes", "IRS Automated Clearinghouse", 12.4, CashFlowDirection.INFLOW, 99.2, "IRS"),
            CashFlowItem("IN-02", "2026-10-05", "Corporate Income Taxes", "IRS Direct Fedwire Batch", 4.8, CashFlowDirection.INFLOW, 98.5, "IRS"),
            CashFlowItem("IN-03", "2026-10-05", "Customs & Tariff Duties", "CBP Collections Port Netting", 1.2, CashFlowDirection.INFLOW, 99.8, "CBP"),
            CashFlowItem("IN-04", "2026-10-05", "Federal Reserve Net Earnings", "Board of Governors Remittance", 0.3, CashFlowDirection.INFLOW, 100.0, "Federal Reserve"),
            CashFlowItem("IN-05", "2026-10-05", "Debt Issuance Settlement", "13-Week Bill Settlement Inflow", 65.0, CashFlowDirection.INFLOW, 100.0, "Fiscal Service")
        )

        val initialOutflows = listOf(
            CashFlowItem("OUT-01", "2026-10-05", "Social Security Benefits Wave 1", "SSA FedACH Distribution", 18.2, CashFlowDirection.OUTFLOW, 99.9, "SSA"),
            CashFlowItem("OUT-02", "2026-10-05", "Medicare Part D & Hospital Trust", "CMS Healthcare Provider Batch", 9.4, CashFlowDirection.OUTFLOW, 99.4, "CMS"),
            CashFlowItem("OUT-03", "2026-10-05", "Defense Vendor & Military Pay", "DFAS Fedwire Settlements", 5.8, CashFlowDirection.OUTFLOW, 98.7, "DoD"),
            CashFlowItem("OUT-04", "2026-10-05", "Public Debt Interest & Coupons", "Fedwire Coupon Payment Desk", 4.1, CashFlowDirection.OUTFLOW, 100.0, "Fiscal Service"),
            CashFlowItem("OUT-05", "2026-10-05", "Maturing Bill Redemption", "4-Week & 13-Week Roll Settlement", 60.0, CashFlowDirection.OUTFLOW, 100.0, "Fiscal Service")
        )

        val tgaAccount = TGAEngine.reconcileDailyCash(
            accountId = "TGA-001-CENTRAL",
            date = "2026-10-05",
            openingBalanceBillions = 785.4,
            inflows = initialInflows,
            outflows = initialOutflows,
            targetBalanceBillions = 750.0
        )

        // Historical 7 days
        val history = listOf(
            tgaAccount.copy(date = "2026-09-29", openingBalanceBillions = 740.0, closingBalanceBillions = 752.0),
            tgaAccount.copy(date = "2026-09-30", openingBalanceBillions = 752.0, closingBalanceBillions = 768.5),
            tgaAccount.copy(date = "2026-10-01", openingBalanceBillions = 768.5, closingBalanceBillions = 745.0),
            tgaAccount.copy(date = "2026-10-02", openingBalanceBillions = 745.0, closingBalanceBillions = 770.2),
            tgaAccount.copy(date = "2026-10-03", openingBalanceBillions = 770.2, closingBalanceBillions = 780.0),
            tgaAccount.copy(date = "2026-10-04", openingBalanceBillions = 780.0, closingBalanceBillions = 785.4),
            tgaAccount
        )

        val forecasts = CashForecastingEngine.generateHorizonForecasts(tgaAccount.closingBalanceBillions)
        val initialSecurities = generateInitialSecurities()
        val portfolioMetrics = DebtManagementEngine.calculatePortfolioMetrics(initialSecurities)
        val maturityWall = DebtManagementEngine.buildMaturityWall()
        val initialAuctions = generateInitialAuctions()
        val yieldCurve = YieldCurveEngine.buildYieldCurve()
        val repo = YieldCurveEngine.getRepoMarketState()
        val refunding = RefundingOptimizer.computeRefundingScenarios()
        val buybacks = listOf(
            BuybackEngine.executeBuyback(BuybackType.LIQUIDITY_SUPPORT, 4.0, "2036-2046 Off-the-run Bonds"),
            BuybackEngine.executeBuyback(BuybackType.CASH_MANAGEMENT, 12.5, "2026 Q4 Maturing Bills")
        )
        val vault = VaultCustodyEngine.getVaultInventory()
        val shipments = VaultCustodyEngine.getShipmentManifests()
        val monteCarlo = MonteCarloEngine.runSimulation()

        val fiscalNodes = listOf(
            FiscalFlowNode("TAX-PAYERS", "U.S. Taxpayers & Corps", "Economic Origin", 5250.0, isSource = true),
            FiscalFlowNode("IRS-REVENUE", "IRS Collections", "Fiscal Intermediary", 4850.0),
            FiscalFlowNode("CBP-TARIFFS", "Customs Duties", "Fiscal Intermediary", 120.0),
            FiscalFlowNode("DEBT-ISSUANCE", "Treasury Auction Inflow", "Debt Operations", 8500.0),
            FiscalFlowNode("TGA-FED", "Treasury General Account (NY Fed)", "Central Cash Ledger", 771.7),
            FiscalFlowNode("OUT-MANDATORY", "Social Security & Medicare", "Federal Outlay", 2450.0),
            FiscalFlowNode("OUT-DEFENSE", "National Defense & DFAS", "Federal Outlay", 895.0),
            FiscalFlowNode("OUT-INTEREST", "Public Debt Interest", "Debt Service", 1050.0),
            FiscalFlowNode("OUT-GRANTS", "Grants, States & General", "Federal Outlay", 1100.0),
            FiscalFlowNode("COMMERCIAL-BANKS", "Banking System Reserves", "Settlement Clearing", 3250.0)
        )

        val fiscalLinks = listOf(
            FiscalFlowLink("TAX-PAYERS", "IRS-REVENUE", 4850.0, "Electronic Tax Withholdings (EFTPS)"),
            FiscalFlowLink("TAX-PAYERS", "CBP-TARIFFS", 120.0, "Port Customs Assessments"),
            FiscalFlowLink("IRS-REVENUE", "TGA-FED", 4850.0, "Daily FedACH Concentration"),
            FiscalFlowLink("CBP-TARIFFS", "TGA-FED", 120.0, "Direct Fedwire Netting"),
            FiscalFlowLink("DEBT-ISSUANCE", "TGA-FED", 8500.0, "Auction Settlement Inflows"),
            FiscalFlowLink("TGA-FED", "OUT-MANDATORY", 2450.0, "Beneficiary Direct Deposits"),
            FiscalFlowLink("TGA-FED", "OUT-DEFENSE", 895.0, "DFAS Contractor & Payroll Outlays"),
            FiscalFlowLink("TGA-FED", "OUT-INTEREST", 1050.0, "Semi-Annual Coupon Fedwire Runs"),
            FiscalFlowLink("TGA-FED", "OUT-GRANTS", 1100.0, "State & Agency Grant Drawdowns"),
            FiscalFlowLink("OUT-MANDATORY", "COMMERCIAL-BANKS", 2450.0, "Consumer Bank Inflow Liquidity"),
            FiscalFlowLink("COMMERCIAL-BANKS", "DEBT-ISSUANCE", 8500.0, "Primary Dealer & Institutional Purchases")
        )

        val auditEvents = listOf(
            TreasuryEvent("EV-1001", "TGA_RECONCILED", "2026-10-05 08:30:15 EST", "Daily TGA opening ledger balance reconciled to Federal Reserve Statement ($785.4B)", 785.4, "Automated Ledger Bot 01", "SHA256:4a8b7c9f..."),
            TreasuryEvent("EV-1002", "AUCTION_ANNOUNCED", "2026-10-05 09:00:00 EST", "Announced 10-Year Note Reopening Offering ($42.0B CUSIP 91282CJZ1)", 42.0, "Debt Operations Desk", "SHA256:d12e4f88..."),
            TreasuryEvent("EV-1003", "AUCTION_CLEARED", "2026-10-05 13:05:00 EST", "Cleared 13-Week Bill Auction at 4.750% Stop-Out with 2.68x Bid-to-Cover", 65.0, "Dutch Auction Engine", "SHA256:99c2b3e1..."),
            TreasuryEvent("EV-1004", "BUYBACK_EXECUTED", "2026-10-05 14:15:22 EST", "Executed $4.0B Liquidity-Support Buyback across off-the-run 2038-2042 bonds", 4.0, "Treasury Refunding Desk", "SHA256:ee0419aa..."),
            TreasuryEvent("EV-1005", "VAULT_AUDITED", "2026-10-04 17:00:00 EST", "Completed serial number reconciliation for Deep Storage Bullion Lots 4800-4850", null, "Inspector General & Mint Police", "SHA256:bb7190cc...")
        )

        val upcoming = listOf(
            initialAuctions[0].copy(auctionId = "AUC-2026-1006-01", securityName = "4-Week Treasury Bill", offeringAmountBillions = 80.0, auctionDate = "2026-10-06", status = "ANNOUNCED"),
            initialAuctions[0].copy(auctionId = "AUC-2026-1006-02", securityName = "8-Week Treasury Bill", offeringAmountBillions = 75.0, auctionDate = "2026-10-06", status = "ANNOUNCED"),
            initialAuctions[0].copy(auctionId = "AUC-2026-1007-01", securityName = "17-Week Treasury Bill", offeringAmountBillions = 60.0, auctionDate = "2026-10-07", status = "ANNOUNCED"),
            initialAuctions[0].copy(auctionId = "AUC-2026-1008-01", securityName = "30-Year Bond Reopening", offeringAmountBillions = 22.0, auctionDate = "2026-10-08", status = "TENTATIVE")
        )

        return TreasuryOSState(
            tgaAccount = tgaAccount,
            dailyHistory = history,
            cashForecasts = forecasts,
            recentInflows = initialInflows,
            recentOutflows = initialOutflows,
            securities = initialSecurities,
            portfolioMetrics = portfolioMetrics,
            maturityWall = maturityWall,
            auctions = initialAuctions,
            upcomingCalendar = upcoming,
            activeSimulationAuction = initialAuctions.first(),
            yieldCurve = yieldCurve,
            repoMarket = repo,
            refundingScenarios = refunding,
            buybackOperations = buybacks,
            vaultAssets = vault,
            shipmentManifests = shipments,
            monteCarloMetrics = monteCarlo,
            fiscalNodes = fiscalNodes,
            fiscalLinks = fiscalLinks,
            auditEvents = auditEvents
        )
    }

    private fun generateInitialSecurities(): List<TreasurySecurity> {
        return listOf(
            TreasurySecurity("912797ND9", SecurityType.BILL_4W, "4-Week Bill", "2026-09-22", "2026-10-20", 0.0, 85.0, 85.0, 1.0, 0.0, 4.82, 0.08, 0.01),
            TreasurySecurity("912797NE7", SecurityType.BILL_8W, "8-Week Bill", "2026-09-08", "2026-11-03", 0.0, 80.0, 80.0, 1.0, 0.0, 4.79, 0.15, 0.02),
            TreasurySecurity("912797NF4", SecurityType.BILL_13W, "13-Week Bill", "2026-07-28", "2026-10-27", 0.0, 75.0, 75.0, 1.0, 0.0, 4.75, 0.25, 0.05),
            TreasurySecurity("912797NG2", SecurityType.BILL_26W, "26-Week Bill", "2026-04-28", "2026-10-27", 0.0, 68.0, 68.0, 1.0, 0.0, 4.62, 0.50, 0.12),
            TreasurySecurity("912797NH0", SecurityType.BILL_52W, "52-Week Bill", "2025-10-28", "2026-10-27", 0.0, 48.0, 48.0, 1.0, 0.0, 4.38, 1.00, 0.25),
            TreasurySecurity("912797CMB", SecurityType.CMB, "42-Day CMB", "2026-09-15", "2026-10-27", 0.0, 40.0, 40.0, 1.0, 0.0, 4.84, 0.12, 0.02),
            TreasurySecurity("91282CJX6", SecurityType.NOTE_2Y, "2-Year Note", "2026-08-31", "2028-08-31", 3.875, 69.0, 69.0, 1.0, 0.0, 4.12, 1.88, 3.8),
            TreasurySecurity("91282CJY4", SecurityType.NOTE_3Y, "3-Year Note", "2026-09-15", "2029-09-15", 4.000, 58.0, 58.0, 1.0, 0.0, 4.05, 2.75, 7.2),
            TreasurySecurity("91282CJZ1", SecurityType.NOTE_5Y, "5-Year Note", "2026-08-31", "2031-08-31", 4.125, 70.0, 70.0, 1.0, 0.0, 4.15, 4.45, 18.5),
            TreasurySecurity("91282CKA4", SecurityType.NOTE_7Y, "7-Year Note", "2026-07-31", "2033-07-31", 4.250, 44.0, 44.0, 1.0, 0.0, 4.28, 6.05, 34.0),
            TreasurySecurity("91282CKB2", SecurityType.NOTE_10Y, "10-Year Benchmark Note", "2026-08-15", "2036-08-15", 4.375, 42.0, 42.0, 1.0, 0.0, 4.38, 8.10, 68.0),
            TreasurySecurity("912810TL1", SecurityType.BOND_20Y, "20-Year Benchmark Bond", "2026-05-15", "2046-05-15", 4.750, 18.0, 18.0, 1.0, 0.0, 4.68, 14.80, 240.0),
            TreasurySecurity("912810TM9", SecurityType.BOND_30Y, "30-Year Long Bond", "2026-08-15", "2056-08-15", 4.500, 24.0, 24.0, 1.0, 0.0, 4.58, 18.20, 410.0),
            TreasurySecurity("912828ZT3", SecurityType.TIPS_5Y, "5-Year TIPS (Real 1.875%)", "2026-04-15", "2031-04-15", 1.875, 22.0, 22.0, 1.024, 0.0, 1.95, 4.50, 20.1),
            TreasurySecurity("912828ZU0", SecurityType.TIPS_10Y, "10-Year TIPS (Real 2.125%)", "2026-07-15", "2036-07-15", 2.125, 19.0, 19.0, 1.018, 0.0, 2.18, 8.35, 71.5),
            TreasurySecurity("912828ZV8", SecurityType.FRN_2Y, "2-Year Floating Rate Note", "2026-07-31", "2028-07-31", 4.950, 28.0, 28.0, 1.0, 15.0, 4.95, 0.25, 0.08),
            TreasurySecurity("912800GAS", SecurityType.GAS_ACCOUNT, "Social Security Trust Fund Holdings", "2020-01-01", "2035-01-01", 3.250, 2750.0, 2750.0, 1.0, 0.0, 3.25, 6.5, 38.0, isMarketable = false, beneficialOwnerCategory = "Federal Agency / Trust Fund")
        )
    }

    private fun generateInitialAuctions(): List<AuctionRecord> {
        val (nonComp13W, comp13W) = AuctionEngine.generateSyntheticBidBook(65.0, 4.75, 2.68)
        val auction13W = AuctionEngine.clearAuction(
            auctionId = "AUC-2026-1005-13W",
            cusip = "912797NF4",
            securityType = SecurityType.BILL_13W,
            securityName = "13-Week Treasury Bill",
            offeringAmountBillions = 65.0,
            wiYieldPct = 4.745,
            nonCompBids = nonComp13W,
            competitiveBids = comp13W,
            announcementDate = "2026-10-01",
            auctionDate = "2026-10-05",
            settlementDate = "2026-10-08",
            maturityDate = "2027-01-07"
        )

        val (nonComp10Y, comp10Y) = AuctionEngine.generateSyntheticBidBook(42.0, 4.38, 2.44)
        val auction10Y = AuctionEngine.clearAuction(
            auctionId = "AUC-2026-1004-10Y",
            cusip = "91282CKB2",
            securityType = SecurityType.NOTE_10Y,
            securityName = "10-Year Benchmark Note",
            offeringAmountBillions = 42.0,
            wiYieldPct = 4.372,
            nonCompBids = nonComp10Y,
            competitiveBids = comp10Y,
            announcementDate = "2026-09-28",
            auctionDate = "2026-10-04",
            settlementDate = "2026-10-15",
            maturityDate = "2036-10-15"
        )

        return listOf(auction13W, auction10Y)
    }

    // --- INTERACTIVE ACTIONS ---

    fun applyScenario(scenario: StressScenario) {
        _state.update { curr ->
            val stressFactor = when (scenario) {
                StressScenario.BASELINE -> 1.0
                StressScenario.TAX_RECEIPT_SHOCK -> 0.85
                StressScenario.RATES_PLUS_200BP -> 1.0
                StressScenario.RATES_MINUS_100BP -> 1.0
                StressScenario.DEFENSE_EMERGENCY -> 0.98
                StressScenario.GOVERNMENT_SHUTDOWN -> 0.70
                StressScenario.DEBT_CEILING_PINCH -> 0.90
            }

            val rateShockBp = when (scenario) {
                StressScenario.BASELINE -> 0.0
                StressScenario.TAX_RECEIPT_SHOCK -> 10.0
                StressScenario.RATES_PLUS_200BP -> 200.0
                StressScenario.RATES_MINUS_100BP -> -100.0
                StressScenario.DEFENSE_EMERGENCY -> 25.0
                StressScenario.GOVERNMENT_SHUTDOWN -> -15.0
                StressScenario.DEBT_CEILING_PINCH -> 60.0
            }

            val newForecasts = CashForecastingEngine.generateHorizonForecasts(curr.tgaAccount.closingBalanceBillions, stressFactor, rateShockBp)
            val newYieldCurve = YieldCurveEngine.buildYieldCurve(rateShockBp)
            val newMonteCarlo = MonteCarloEngine.runSimulation(
                macroStressOffset = if (scenario == StressScenario.BASELINE) 0.0 else 1.0
            )

            val event = TreasuryEvent(
                eventId = "EV-${System.currentTimeMillis().toString().takeLast(6)}",
                eventType = "SCENARIO_APPLIED",
                timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) + " EST",
                summary = "Applied scenario '${scenario.title}'. Recalibrated cash forecast, yield curve and Monte Carlo distribution.",
                impactAmountBillions = null,
                actor = "Risk Simulation Officer",
                verifiedHash = "SHA256:${UUID.randomUUID().toString().take(12)}"
            )

            curr.copy(
                activeScenario = scenario,
                cashForecasts = newForecasts,
                yieldCurve = newYieldCurve,
                monteCarloMetrics = newMonteCarlo,
                auditEvents = listOf(event) + curr.auditEvents
            )
        }
    }

    fun runAuctionSimulation(
        offeringAmountBillions: Double,
        wiYieldPct: Double,
        bidToCoverTarget: Double,
        dealerAggressiveness: Double,
        foreignDemandMultiplier: Double
    ) {
        val (nonComp, comp) = AuctionEngine.generateSyntheticBidBook(
            offeringAmountBillions,
            wiYieldPct,
            bidToCoverTarget,
            dealerAggressiveness,
            foreignDemandMultiplier
        )

        val newAuction = AuctionEngine.clearAuction(
            auctionId = "AUC-SIM-${System.currentTimeMillis().toString().takeLast(4)}",
            cusip = "91282SIM9",
            securityType = SecurityType.NOTE_10Y,
            securityName = "10-Year Simulated Benchmark Note",
            offeringAmountBillions = offeringAmountBillions,
            wiYieldPct = wiYieldPct,
            nonCompBids = nonComp,
            competitiveBids = comp,
            announcementDate = "2026-10-05",
            auctionDate = "2026-10-05",
            settlementDate = "2026-10-15",
            maturityDate = "2036-10-15"
        )

        _state.update { curr ->
            val event = TreasuryEvent(
                eventId = "EV-${System.currentTimeMillis().toString().takeLast(6)}",
                eventType = "AUCTION_SIMULATED",
                timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) + " EST",
                summary = "Cleared ${newAuction.securityName} simulation. Offering: $${offeringAmountBillions}B, Stop: ${newAuction.stopOutYieldPct}%, Cover: ${String.format(Locale.US, "%.2f", newAuction.bidToCoverRatio)}x",
                impactAmountBillions = offeringAmountBillions,
                actor = "Auction Operations Specialist",
                verifiedHash = "SHA256:${UUID.randomUUID().toString().take(12)}"
            )

            curr.copy(
                activeSimulationAuction = newAuction,
                auctions = listOf(newAuction) + curr.auctions,
                auditEvents = listOf(event) + curr.auditEvents
            )
        }
    }

    fun selectRefundingPlan(index: Int) {
        _state.update { it.copy(selectedRefundingIndex = index) }
    }

    fun executeManualBuyback(type: BuybackType, amountBillions: Double, targetRange: String) {
        val op = BuybackEngine.executeBuyback(type, amountBillions, targetRange)
        _state.update { curr ->
            val event = TreasuryEvent(
                eventId = "EV-${System.currentTimeMillis().toString().takeLast(6)}",
                eventType = "BUYBACK_EXECUTED",
                timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) + " EST",
                summary = "Executed ${op.type.label} for $${amountBillions}B across $targetRange. Price: ${op.weightedPurchasePrice}",
                impactAmountBillions = amountBillions,
                actor = "Refunding Desk",
                verifiedHash = "SHA256:${UUID.randomUUID().toString().take(12)}"
            )
            curr.copy(
                buybackOperations = listOf(op) + curr.buybackOperations,
                auditEvents = listOf(event) + curr.auditEvents
            )
        }
    }

    fun advanceOperatingDayPhase() {
        val phases = listOf(
            OperatingDayPhase("00:00 EST", "CASH POSITION INITIALIZATION", "Loading opening TGA position from Federal Reserve Bank of NY master account"),
            OperatingDayPhase("06:00 EST", "RECEIPTS INFLOW PROJECTIONS", "Aggregating electronic IRS tax collections and customs duty estimates"),
            OperatingDayPhase("08:00 EST", "CASH FORECAST RECALIBRATION", "Updating 1D to 90D multi-horizon cash buffer projections"),
            OperatingDayPhase("09:00 EST", "AUCTION PREPARATION", "Finalizing offering sizes and CUSIP allotment structures with TBAC"),
            OperatingDayPhase("10:00 EST", "AUCTION ANNOUNCEMENT", "Public issuance announcement via Fiscal Data & Fedwire bus"),
            OperatingDayPhase("11:00 EST", "BID COLLECTION & AUCTION LAB", "Order book receiving competitive primary dealer and indirect foreign bids"),
            OperatingDayPhase("13:00 EST", "AUCTION CLOSE & DUTCH CLEARING", "Bidding closed; Dutch single-price stop-out yield calculated"),
            OperatingDayPhase("13:05 EST", "ALLOTMENT & AWARD NOTIFICATION", "Awards published to primary dealers and institutional direct bidders"),
            OperatingDayPhase("14:00 EST", "SETTLEMENT & WIRE NETTING", "Gross cash inflows credited to TGA; commercial bank reserves drained"),
            OperatingDayPhase("15:00 EST", "TGA MASTER UPDATE", "Reconciling disbursement sweeps and intraday cash positions"),
            OperatingDayPhase("16:00 EST", "DEBT RECONCILIATION", "Debt outstanding ledger updated; maturity wall roll recalculated"),
            OperatingDayPhase("17:00 EST", "DAILY TREASURY STATEMENT (DTS)", "Generating official closed ledger report and publishing audit state")
        )

        _state.update { curr ->
            val currentIndex = phases.indexOfFirst { it.phaseName == curr.operatingPhase.phaseName }
            val nextIndex = (currentIndex + 1) % phases.size
            val nextPhase = phases[nextIndex]

            val event = TreasuryEvent(
                eventId = "EV-${System.currentTimeMillis().toString().takeLast(6)}",
                eventType = "OPERATING_PHASE_ADVANCED",
                timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) + " EST",
                summary = "Operating day advanced to '${nextPhase.phaseName}' (${nextPhase.timeLabel})",
                impactAmountBillions = null,
                actor = "System Operating Clock",
                verifiedHash = "SHA256:${UUID.randomUUID().toString().take(12)}"
            )

            curr.copy(
                operatingPhase = nextPhase,
                auditEvents = listOf(event) + curr.auditEvents
            )
        }
    }

    fun executeTerminalCommand(cmdRaw: String) {
        val cmd = cmdRaw.trim()
        if (cmd.isEmpty()) return

        val tokens = cmd.split("\\s+".toRegex())
        val primary = tokens[0].lowercase()

        val responseLines = mutableListOf<String>()
        responseLines.add("> $cmd")

        when (primary) {
            "help" -> {
                responseLines.add("TREASURY//OS CLI COMMAND REFERENCE:")
                responseLines.add("  tga               - Inspect current Treasury General Account ledger & reserve drain")
                responseLines.add("  forecast          - Multi-horizon cash forecast (1D, 7D, 30D, 90D, 1Y)")
                responseLines.add("  debt              - Output debt outstanding summary & WAM/WAC metrics")
                responseLines.add("  auctions          - List active and cleared auction records")
                responseLines.add("  sim-auction       - Simulate 10Y auction (e.g. 'sim-auction 42 4.38 2.5')")
                responseLines.add("  shock <type>      - Apply stress shock: 'tax', 'rates_up', 'rates_down', 'defense', 'reset'")
                responseLines.add("  refunding         - View TBAC quarterly refunding debt mix options")
                responseLines.add("  buyback           - Execute test buyback (e.g. 'buyback liquidity 5.0')")
                responseLines.add("  vault             - Inspect deep storage gold and currency vault ledger")
                responseLines.add("  advance           - Advance operating day clock to next phase")
                responseLines.add("  audit             - Inspect immutable event stream hashes")
                responseLines.add("  clear             - Clear terminal screen history")
            }
            "tga" -> {
                val tga = _state.value.tgaAccount
                responseLines.add("TREASURY GENERAL ACCOUNT (TGA) STATUS:")
                responseLines.add("  Date:             ${tga.date}")
                responseLines.add("  Opening Balance:  $${String.format(Locale.US, "%.2fB", tga.openingBalanceBillions)}")
                responseLines.add("  Total Inflows:    +$${String.format(Locale.US, "%.2fB", tga.totalInflows)} (Taxes: $${tga.taxReceiptsBillions}B, Issuance: $${tga.debtIssuanceInflowBillions}B)")
                responseLines.add("  Total Outflows:   -$${String.format(Locale.US, "%.2fB", tga.totalOutflows)} (Payments: $${tga.governmentPaymentsBillions}B, Maturities: $${tga.debtMaturitiesOutflowBillions}B)")
                responseLines.add("  Closing Balance:  $${String.format(Locale.US, "%.2fB", tga.closingBalanceBillions)}")
                responseLines.add("  Reserve Impact:   ${String.format(Locale.US, "%+,.2fB", tga.fedReserveDrainImpactBillions)} (Commercial Bank Reserves)")
                responseLines.add("  Ledger Invariant: ${if (tga.isLedgerBalanced) "VERIFIED [BALANCED]" else "CORRUPTED"}")
            }
            "forecast" -> {
                responseLines.add("MULTI-HORIZON CASH FORECAST:")
                _state.value.cashForecasts.forEach {
                    responseLines.add(String.format(Locale.US, "  %-10s | Net Flow: %+8.1fB | Ending TGA: %7.1fB | Fin Need: %7.1fB", it.horizonLabel, it.netFlowBillions, it.projectedTgaEndingBillions, it.financingRequirementBillions))
                }
            }
            "debt" -> {
                val p = _state.value.portfolioMetrics
                responseLines.add("DEBT OUTSTANDING SUMMARY:")
                responseLines.add("  Total Outstanding: $${String.format(Locale.US, "%.2fT", p.totalDebtOutstandingTrillions)}")
                responseLines.add("  Marketable Debt:   $${String.format(Locale.US, "%.2fT", p.marketableDebtTrillions)}")
                responseLines.add("  Non-Marketable:    $${String.format(Locale.US, "%.2fT", p.nonMarketableDebtTrillions)}")
                responseLines.add("  Weighted Avg Mat:  ${String.format(Locale.US, "%.2f years", p.weightedAverageMaturityYears)}")
                responseLines.add("  Weighted Avg Cpn:  ${String.format(Locale.US, "%.3f%%", p.weightedAverageCouponPct)}")
                responseLines.add("  Modified Duration: ${String.format(Locale.US, "%.2f years", p.modifiedDurationYears)}")
                responseLines.add("  Gross Annual Int:  $${String.format(Locale.US, "%.1fB", p.annualGrossInterestExpenseBillions)}")
            }
            "auctions" -> {
                responseLines.add("AUCTION OPERATIONS MASTER:")
                _state.value.auctions.forEach {
                    responseLines.add("  ${it.auctionId} | ${it.securityName} | Offer: $${it.offeringAmountBillions}B | Stop: ${it.stopOutYieldPct}% | Cover: ${String.format(Locale.US, "%.2f", it.bidToCoverRatio)}x | Tail: ${it.tailBasisPoints}bp")
                }
            }
            "sim-auction" -> {
                val size = tokens.getOrNull(1)?.toDoubleOrNull() ?: 42.0
                val wi = tokens.getOrNull(2)?.toDoubleOrNull() ?: 4.38
                val cover = tokens.getOrNull(3)?.toDoubleOrNull() ?: 2.45
                runAuctionSimulation(size, wi, cover, 1.0, 1.0)
                val sim = _state.value.activeSimulationAuction
                responseLines.add("SIMULATED AUCTION CLEARED:")
                responseLines.add("  ID:           ${sim.auctionId}")
                responseLines.add("  Offering:     $${sim.offeringAmountBillions}B")
                responseLines.add("  Stop-Out:     ${sim.stopOutYieldPct}%")
                responseLines.add("  Bid-to-Cover: ${String.format(Locale.US, "%.2f", sim.bidToCoverRatio)}x")
                responseLines.add("  Tail (bp):    ${sim.tailBasisPoints} bp")
                responseLines.add("  Takedown:     Dealers ${String.format(Locale.US, "%.1f%%", sim.primaryDealerPct)}, Foreign ${String.format(Locale.US, "%.1f%%", sim.indirectForeignPct)}, Direct ${String.format(Locale.US, "%.1f%%", sim.directBidderPct)}")
            }
            "shock" -> {
                val arg = tokens.getOrNull(1)?.lowercase() ?: "tax"
                val scenario = when (arg) {
                    "tax" -> StressScenario.TAX_RECEIPT_SHOCK
                    "rates_up" -> StressScenario.RATES_PLUS_200BP
                    "rates_down" -> StressScenario.RATES_MINUS_100BP
                    "defense" -> StressScenario.DEFENSE_EMERGENCY
                    "shutdown" -> StressScenario.GOVERNMENT_SHUTDOWN
                    "debt_limit", "ceiling" -> StressScenario.DEBT_CEILING_PINCH
                    else -> StressScenario.BASELINE
                }
                applyScenario(scenario)
                responseLines.add("SCENARIO APPLIED: ${scenario.title}")
                responseLines.add("  ${scenario.description}")
            }
            "refunding" -> {
                responseLines.add("TBAC QUARTERLY REFUNDING PROPOSALS:")
                _state.value.refundingScenarios.forEachIndexed { i, plan ->
                    responseLines.add("  [$i] ${plan.quarterLabel} | Cost: ${plan.weightedFundingCostPct}% | WAM: ${plan.weightedAvgMaturityYears}y | Rollover Risk: ${plan.rolloverRiskScore}")
                }
            }
            "buyback" -> {
                val amt = tokens.getOrNull(2)?.toDoubleOrNull() ?: 5.0
                executeManualBuyback(BuybackType.LIQUIDITY_SUPPORT, amt, "2036-2046 Off-The-Run")
                responseLines.add("SUCCESS: Executed Buyback for $${amt}B across off-the-run bonds.")
            }
            "vault" -> {
                responseLines.add("U.S. TREASURY CUSTODY / VAULT ASSETS:")
                _state.value.vaultAssets.forEach {
                    responseLines.add("  ${it.assetId} | ${it.category.label} | Loc: ${it.location} | Market Value: $${it.estimatedMarketValueBillions}B | Status: ${it.auditStatus}")
                }
            }
            "advance" -> {
                advanceOperatingDayPhase()
                responseLines.add("OPERATING CLOCK ADVANCED -> ${_state.value.operatingPhase.phaseName} (${_state.value.operatingPhase.timeLabel})")
            }
            "audit" -> {
                responseLines.add("IMMUTABLE EVENT SOURCING TRAIL (RECENT 5):")
                _state.value.auditEvents.take(5).forEach {
                    responseLines.add("  ${it.timestamp} [${it.eventType}] ${it.summary} | ${it.verifiedHash}")
                }
            }
            "clear" -> {
                _state.update { it.copy(terminalHistory = listOf("TREASURY//OS TERMINAL CLEARED")) }
                return
            }
            else -> {
                responseLines.add("Unknown command '$cmd'. Type 'help' for available terminal operations.")
            }
        }

        _state.update { curr ->
            curr.copy(terminalHistory = curr.terminalHistory + responseLines)
        }
    }

    fun generateAiExplanation(query: String) {
        val lower = query.lowercase()
        val response = when {
            lower.contains("borrowing") || lower.contains("requirement") -> {
                """PRIMARY DRIVERS OF $1.31T 90-DAY BORROWING REQUIREMENT:
1. $760.0B in maturing short-term Treasury bills rolling forward across October–December.
2. $410.0B projected quarterly operational fiscal deficit (entitlement outlays & defense spending exceed non-April tax receipts).
3. $140.0B planned cash buffer replenishment to maintain TGA at $750B prudential target ahead of year-end corporate tax settlements.
4. Recommendation: Maintain benchmark 10Y note sizes at $42B while scaling 4-week and 13-week CMB tranches to absorb mid-quarter cash troughs."""
            }
            lower.contains("tail") || lower.contains("auction") -> {
                """DUTCH AUCTION TAIL & DEMAND ANALYSIS:
1. Stop-out yield cleared at 4.750%, creating a +0.5 basis point tail relative to the When-Issued (WI) 4.745% secondary market bid.
2. Indirect foreign demand remained robust at 68.2%, driven by foreign central bank foreign exchange reserve recycling.
3. Primary dealer allotment contracted to 18.5%, indicating low dealer concession inventory accumulation.
4. Bid-to-cover ratio at 2.68x exceeds 6-month trailing average (2.54x), confirming orderly market absorption."""
            }
            lower.contains("refunding") || lower.contains("tbac") -> {
                """TBAC QUARTERLY REFUNDING STRATEGY EVALUATION:
1. The baseline mix allocates 21% to short-term bills, safely within the TBAC recommended 15–20% target band.
2. Extending duration into 7Y and 10Y notes provides structural insurance against refinancing cliff risk in 2028–2029.
3. TIPS issuance at $42B provides direct CPI liability hedging without destabilizing nominal liquidity premiums.
4. Recommended: Authorize $30B CMB flex tranche for liquidity-support buyback operations."""
            }
            else -> {
                """TREASURY//OS SYSTEM ANALYTICS:
Live computational state indicates balanced TGA operations ($771.7B closing cash), debt portfolio weighted average maturity of 6.35 years, and 10,000-iteration Monte Carlo cash shortfall probability under 2.1%. All event sourcing hashes verified against Federal Reserve settlement records."""
            }
        }

        _state.update { it.copy(aiInsightQuery = query, aiInsightResponse = response) }
    }
}
