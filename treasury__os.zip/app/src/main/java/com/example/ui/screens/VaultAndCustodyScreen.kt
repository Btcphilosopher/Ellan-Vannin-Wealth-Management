package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TreasuryOSState
import com.example.ui.components.StatMetricCard
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun VaultAndCustodyScreen(
    state: TreasuryOSState,
    modifier: Modifier = Modifier
) {
    val totalGoldOz = state.vaultAssets.filter { it.category.name.contains("GOLD") }.sumOf { it.quantityOrWeight }
    val totalMarketValue = state.vaultAssets.sumOf { it.estimatedMarketValueBillions }
    val totalStatutoryBook = state.vaultAssets.sumOf { it.statutoryBookValueBillions }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TreasuryNavyDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "TREASURY VAULT & PHYSICAL CUSTODY LEDGER",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = SovereignGoldBright
            )
            Text(
                text = "Physical Gold Reserves, Silver Bullion, Currency Note Inventories & In-Transit Custody",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextMuted
            )
        }

        // Vault Totals Metric Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Total Gold Bullion",
                    value = "${String.format(Locale.US, "%.1fM", totalGoldOz / 1_000_000.0)} oz",
                    subValue = "261.5M Fine Troy Oz Total",
                    badgeText = "DEEP STORAGE",
                    badgeColor = SovereignGoldMuted,
                    valueColor = SovereignGoldBright,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Est. Market Value",
                    value = "$${String.format(Locale.US, "%.1fB", totalMarketValue)}",
                    subValue = "Book Value: $${String.format(Locale.US, "%.2fB", totalStatutoryBook)}",
                    badgeText = "MARKET / STATUTORY",
                    badgeColor = TreasuryNavyElevated,
                    valueColor = TextHighlight,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Vault Custody Asset Registry Table
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "PHYSICAL VAULT ASSET LEDGER (SYNTHETIC DEPOSITORIES)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    state.vaultAssets.forEach { asset ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(0.5.dp, TreasuryNavyBorderSubtle, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.3f)) {
                                Text(
                                    text = asset.category.label,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${asset.location} | Serial: ${asset.serialNumber}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    color = TextMuted
                                )
                                Text(
                                    text = "Audit: ${asset.auditStatus}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 7.5.sp,
                                    color = TreasuryGreenBright
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "$${asset.estimatedMarketValueBillions}B",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SovereignGoldBright
                                )
                                Text(
                                    text = "Book: $${asset.statutoryBookValueBillions}B",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // Active High-Security Cash Shipment Manifests
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SECURITY TRANSIT & SHIPMENT MANIFESTS",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGoldBright
                        )
                        Icon(Icons.Default.LocalShipping, contentDescription = null, tint = SteelBlue, modifier = Modifier.size(16.dp))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    state.shipmentManifests.forEach { ship ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(0.5.dp, TreasuryNavyBorderSubtle)
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${ship.manifestId} — ${ship.assetDescription}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Route: ${ship.originFacility} → ${ship.destinationDepository}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    color = TextMuted
                                )
                                Text(
                                    text = "Escort: ${ship.escortAuthority} | ${ship.timestamp}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 7.5.sp,
                                    color = SteelBlueLight
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (ship.transitStatus.contains("RECEIVED")) TreasuryGreenMuted else SovereignGoldMuted)
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = ship.transitStatus,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextHighlight
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
