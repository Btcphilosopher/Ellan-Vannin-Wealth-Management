package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.engine.MaturityBucket
import com.example.domain.model.HorizonForecast
import com.example.domain.model.YieldCurvePoint
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

@Composable
fun YieldCurveChart(
    points: List<YieldCurvePoint>,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TreasuryNavyDark)
            .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
            .padding(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "U.S. TREASURY BENCHMARK YIELD CURVE",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = SovereignGoldBright
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).background(SteelBlue))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Par Yield", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(modifier = Modifier.size(8.dp).background(SovereignGold))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "When-Issued (WI)", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                val w = size.width
                val h = size.height
                if (points.isEmpty()) return@Canvas

                val minYield = 3.5
                val maxYield = 5.2
                val yieldRange = maxYield - minYield

                // Draw horizontal gridlines (3.5%, 4.0%, 4.5%, 5.0%)
                listOf(4.0, 4.5, 5.0).forEach { yVal ->
                    val y = h - ((yVal - minYield) / yieldRange * h).toFloat()
                    drawLine(
                        color = TreasuryNavyBorderSubtle,
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                    )
                }

                val pathPar = Path()
                val stepX = w / (points.size - 1).coerceAtLeast(1)

                points.forEachIndexed { i, pt ->
                    val x = i * stepX
                    val yPar = h - ((pt.parYieldPct - minYield) / yieldRange * h).toFloat().coerceIn(0f, h)

                    if (i == 0) pathPar.moveTo(x, yPar) else pathPar.lineTo(x, yPar)

                    // Draw When-Issued indicator point
                    val yWi = h - ((pt.whenIssuedYieldPct - minYield) / yieldRange * h).toFloat().coerceIn(0f, h)
                    drawCircle(
                        color = SovereignGold,
                        radius = 3.5f,
                        center = Offset(x, yWi)
                    )

                    // Draw Par curve point
                    drawCircle(
                        color = SteelBlue,
                        radius = 4f,
                        center = Offset(x, yPar)
                    )
                }

                drawPath(
                    path = pathPar,
                    color = SteelBlue,
                    style = Stroke(width = 2.5f)
                )
            }

            // Tenor labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                points.forEach { pt ->
                    Text(
                        text = pt.tenorLabel,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        color = TextMuted
                    )
                }
            }
        }
    }
}

@Composable
fun MaturityWallChart(
    buckets: List<MaturityBucket>,
    modifier: Modifier = Modifier
) {
    val displayBuckets = buckets.take(16) // 2026 to 2041
    val maxPrincipal = displayBuckets.maxOfOrNull { it.totalMaturingBillions } ?: 3500.0

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TreasuryNavyDark)
            .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
            .padding(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DEBT MATURITY WALL (2026–2041)",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = SovereignGoldBright
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).background(StressRed))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Bills", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted)
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(modifier = Modifier.size(6.dp).background(SteelBlue))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Notes", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted)
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(modifier = Modifier.size(6.dp).background(SovereignGold))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Bonds", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                val w = size.width
                val h = size.height
                if (displayBuckets.isEmpty()) return@Canvas

                val barWidth = (w / displayBuckets.size) * 0.7f
                val spacing = (w / displayBuckets.size) * 0.3f

                displayBuckets.forEachIndexed { i, b ->
                    val x = i * (barWidth + spacing) + (spacing / 2f)
                    val totalH = ((b.totalMaturingBillions / maxPrincipal) * h).toFloat().coerceIn(2f, h)

                    val billsRatio = b.billsMaturingBillions / b.totalMaturingBillions
                    val notesRatio = b.notesMaturingBillions / b.totalMaturingBillions
                    val bondsRatio = b.bondsMaturingBillions / b.totalMaturingBillions

                    val billsH = (totalH * billsRatio).toFloat()
                    val notesH = (totalH * notesRatio).toFloat()
                    val bondsH = (totalH * bondsRatio).toFloat()

                    var currY = h

                    // Draw Bills segment (Bottom/High turnover)
                    if (billsH > 0f) {
                        currY -= billsH
                        drawRoundRect(
                            color = StressRed,
                            topLeft = Offset(x, currY),
                            size = Size(barWidth, billsH),
                            cornerRadius = CornerRadius(1f, 1f)
                        )
                    }

                    // Draw Notes segment
                    if (notesH > 0f) {
                        currY -= notesH
                        drawRoundRect(
                            color = SteelBlue,
                            topLeft = Offset(x, currY),
                            size = Size(barWidth, notesH),
                            cornerRadius = CornerRadius(1f, 1f)
                        )
                    }

                    // Draw Bonds segment
                    if (bondsH > 0f) {
                        currY -= bondsH
                        drawRoundRect(
                            color = SovereignGold,
                            topLeft = Offset(x, currY),
                            size = Size(barWidth, bondsH),
                            cornerRadius = CornerRadius(1f, 1f)
                        )
                    }
                }
            }

            // Year axis labels (every other year)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                displayBuckets.forEachIndexed { i, b ->
                    if (i % 2 == 0) {
                        Text(
                            text = "'${b.year.toString().takeLast(2)}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CashForecastEnvelopeChart(
    forecasts: List<HorizonForecast>,
    targetTgaBillions: Double = 750.0,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TreasuryNavyDark)
            .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
            .padding(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TGA TRAJECTORY & 95% CONFIDENCE ENVELOPE",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = SovereignGoldBright
                )
                Text(
                    text = "Target: $${targetTgaBillions.toInt()}B",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = TreasuryGreenBright
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            ) {
                val w = size.width
                val h = size.height
                if (forecasts.isEmpty()) return@Canvas

                val minVal = 200.0
                val maxVal = 1000.0
                val range = maxVal - minVal

                // Target TGA line ($750B)
                val targetY = h - ((targetTgaBillions - minVal) / range * h).toFloat()
                drawLine(
                    color = TreasuryGreen.copy(alpha = 0.6f),
                    start = Offset(0f, targetY),
                    end = Offset(w, targetY),
                    strokeWidth = 1.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                )

                val stepX = w / (forecasts.size - 1).coerceAtLeast(1)

                // Draw confidence envelope polygon
                val upperPath = Path()
                val lowerPath = Path()

                forecasts.forEachIndexed { i, fc ->
                    val x = i * stepX
                    val yUpper = h - ((fc.confidenceHighBillions.coerceIn(minVal, maxVal) - minVal) / range * h).toFloat()
                    val yLower = h - ((fc.confidenceLowBillions.coerceIn(minVal, maxVal) - minVal) / range * h).toFloat()

                    if (i == 0) upperPath.moveTo(x, yUpper) else upperPath.lineTo(x, yUpper)
                    if (i == 0) lowerPath.moveTo(x, yLower) else lowerPath.lineTo(x, yLower)
                }

                // Fill envelope
                val fullEnvelope = Path().apply {
                    addPath(upperPath)
                    forecasts.reversed().forEachIndexed { i, fc ->
                        val origIdx = forecasts.size - 1 - i
                        val x = origIdx * stepX
                        val yLower = h - ((fc.confidenceLowBillions.coerceIn(minVal, maxVal) - minVal) / range * h).toFloat()
                        lineTo(x, yLower)
                    }
                    close()
                }

                drawPath(
                    path = fullEnvelope,
                    color = SteelBlue.copy(alpha = 0.15f)
                )

                // Projected mean line
                val meanPath = Path()
                forecasts.forEachIndexed { i, fc ->
                    val x = i * stepX
                    val yMean = h - ((fc.projectedTgaEndingBillions.coerceIn(minVal, maxVal) - minVal) / range * h).toFloat()
                    if (i == 0) meanPath.moveTo(x, yMean) else meanPath.lineTo(x, yMean)
                    drawCircle(color = SteelBlue, radius = 3.5f, center = Offset(x, yMean))
                }

                drawPath(
                    path = meanPath,
                    color = SteelBlue,
                    style = Stroke(width = 2.5f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                forecasts.forEach { fc ->
                    Text(
                        text = fc.horizonLabel,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.5.sp,
                        color = TextMuted
                    )
                }
            }
        }
    }
}

@Composable
fun MonteCarloHistogramChart(
    bins: List<Pair<Double, Int>>,
    p95: Double,
    p99: Double,
    modifier: Modifier = Modifier
) {
    val maxCount = bins.maxOfOrNull { it.second } ?: 1000

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TreasuryNavyDark)
            .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
            .padding(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "10,000 MONTE CARLO INTEREST EXPENSE (VaR)",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = SovereignGoldBright
                )
                Text(
                    text = "95% VaR: $${p95.toInt()}B | 99% VaR: $${p99.toInt()}B",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 8.5.sp,
                    color = StressRed
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
            ) {
                val w = size.width
                val h = size.height
                if (bins.isEmpty()) return@Canvas

                val barW = (w / bins.size) * 0.8f
                val spacing = (w / bins.size) * 0.2f

                bins.forEachIndexed { i, (centerVal, count) ->
                    val x = i * (barW + spacing) + (spacing / 2f)
                    val barH = ((count.toDouble() / maxCount) * h).toFloat().coerceIn(2f, h)
                    val y = h - barH

                    val isExtremeVaR = centerVal >= p95
                    val barColor = if (isExtremeVaR) StressRed else SteelBlue

                    drawRoundRect(
                        color = barColor,
                        topLeft = Offset(x, y),
                        size = Size(barW, barH),
                        cornerRadius = CornerRadius(2f, 2f)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (bins.isNotEmpty()) {
                    Text(
                        text = "$${bins.first().first.toInt()}B (Low Cost)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        color = TextMuted
                    )
                    Text(
                        text = "$${bins.last().first.toInt()}B (Severe Tail)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        color = StressRed
                    )
                }
            }
        }
    }
}
