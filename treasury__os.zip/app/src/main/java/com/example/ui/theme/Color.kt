package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Sovereign Palette: Washington Fiscal + Wall Street Fixed Income
val TreasuryNavyDark = Color(0xFF070B12)
val TreasuryNavySurface = Color(0xFF0D1527)
val TreasuryNavyCard = Color(0xFF131F37)
val TreasuryNavyElevated = Color(0xFF1A294A)
val TreasuryNavyBorder = Color(0xFF263A63)
val TreasuryNavyBorderSubtle = Color(0xFF1E2E4E)

val SovereignGold = Color(0xFFF59E0B)
val SovereignGoldBright = Color(0xFFFBBF24)
val SovereignGoldMuted = Color(0xFFD97706)

val TreasuryGreen = Color(0xFF10B981)
val TreasuryGreenBright = Color(0xFF34D399)
val TreasuryGreenMuted = Color(0xFF059669)

val SteelBlue = Color(0xFF38BDF8)
val SteelBlueLight = Color(0xFF7DD3FC)
val SteelBlueMuted = Color(0xFF0284C7)

val AccentAmber = Color(0xFFF97316)
val StressRed = Color(0xFFEF4444)
val StressRedDark = Color(0xFF991B1B)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextHighlight = Color(0xFFFFFFFF)

val MonospaceGreen = Color(0xFF00FF66)
val MonospaceAmber = Color(0xFFFFB703)
