package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TreasuryOSState
import com.example.domain.engine.DebtManagementEngine
import com.example.domain.model.SecurityType
import com.example.domain.model.TreasurySecurity
import com.example.ui.components.MaturityWallChart
import com.example.ui.components.StatMetricCard
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun DebtAndSecuritiesScreen(
    state: TreasuryOSState,
    modifier: Modifier = Modifier
) {
    var selectedCategoryFilter by remember { mutableStateOf("All") }
    var rollMaturingAmount by remember { mutableStateOf(100.0) }
    var rollTenorYears by remember { mutableStateOf(10) }

    val categories = listOf("All", "Bills", "Notes", "Bonds", "TIPS", "FRNs", "Non-Marketable")

    val filteredSecurities = remember(selectedCategoryFilter, state.securities) {
        if (selectedCategoryFilter == "All") {
            state.securities
        } else {
            state.securities.filter { it.type.category == selectedCategoryFilter }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TreasuryNavyDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "DEBT MANAGEMENT & SECURITIES REGISTRY",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = SovereignGoldBright
            )
            Text(
                text = "Marketable & Non-Marketable Debt, CUSIP Master, Duration & Rollover",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextMuted
            )
        }

        // Top Portfolio Metrics Summary
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Total Outstanding",
                    value = "$${String.format(Locale.US, "%.2fT", state.portfolioMetrics.totalDebtOutstandingTrillions)}",
                    subValue = "Marketable: $${String.format(Locale.US, "%.2fT", state.portfolioMetrics.marketableDebtTrillions)}",
                    badgeText = "DEBT // CORE",
                    badgeColor = SteelBlueMuted,
                    valueColor = TextHighlight,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Weighted Maturity",
                    value = "${String.format(Locale.US, "%.2f yrs", state.portfolioMetrics.weightedAverageMaturityYears)}",
                    subValue = "Mod Duration: ${String.format(Locale.US, "%.2f yrs", state.portfolioMetrics.modifiedDurationYears)}",
                    badgeText = "PORTFOLIO",
                    badgeColor = SovereignGoldMuted,
                    valueColor = SovereignGoldBright,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Weighted Coupon",
                    value = String.format(Locale.US, "%.3f%%", state.portfolioMetrics.weightedAverageCouponPct),
                    subValue = "Convexity: ${String.format(Locale.US, "%.1f", state.portfolioMetrics.portfolioConvexity)}",
                    badgeText = "WAC",
                    badgeColor = TreasuryNavyElevated,
                    valueColor = SteelBlueLight,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Annual Int Expense",
                    value = "$${state.portfolioMetrics.annualGrossInterestExpenseBillions.toInt()}B / yr",
                    subValue = "Bills Share: ${String.format(Locale.US, "%.1f%%", state.portfolioMetrics.billsSharePct)}",
                    badgeText = "DEBT SERVICE",
                    badgeColor = StressRedDark,
                    valueColor = StressRed,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Debt Maturity Wall
        item {
            MaturityWallChart(buckets = state.maturityWall)
        }

        // Refinance Now vs Later Rolling Calculator
        item {
            val (costNow, costRoll) = DebtManagementEngine.calculateRefinanceComparison(
                maturingAmountBillions = rollMaturingAmount,
                currentFixedRatePct = 4.38,
                expectedFutureRatePct = 3.65,
                tenorYears = rollTenorYears
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "DEBT ROLLING CALCULATOR (LOCK 10Y NOW VS ROLL BILLS)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Analyzing $${rollMaturingAmount.toInt()}B maturing debt over ${rollTenorYears}-year horizon:",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Option A: Fix 10Y Coupon Now (4.38%)", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextMuted)
                            Text("Total 10Y Interest: $${String.format(Locale.US, "%.1fB", costNow)}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SteelBlueLight)
                        }
                        Column {
                            Text("Option B: Roll 1Y Bills then Fix (3.65%)", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextMuted)
                            Text("Total 10Y Interest: $${String.format(Locale.US, "%.1fB", costRoll)}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (costRoll < costNow) TreasuryGreenBright else SovereignGold)
                        }
                    }
                }
            }
        }

        // Security Category Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                categories.forEach { cat ->
                    val isSel = cat == selectedCategoryFilter
                    Button(
                        onClick = { selectedCategoryFilter = cat },
                        modifier = Modifier.height(28.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSel) SovereignGold else TreasuryNavyCard,
                            contentColor = if (isSel) TreasuryNavyDark else TextSecondary
                        ),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Text(cat, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Securities Master Table
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "ACTIVE TREASURY SECURITIES REGISTRY",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TreasuryNavyElevated)
                            .padding(vertical = 4.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("CUSIP / TERM", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(1.4f))
                        Text("MATURITY", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("COUPON", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(0.9f))
                        Text("OUTSTANDING", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("YTM", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(0.8f))
                    }

                    filteredSecurities.forEach { sec ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp, horizontal = 4.dp)
                                .border(0.5.dp, TreasuryNavyBorderSubtle),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.4f)) {
                                Text(sec.cusip, fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(sec.termDescription, fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = SteelBlueLight)
                            }
                            Text(sec.maturityDate, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                            Text(sec.formattedCoupon, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = SovereignGold, modifier = Modifier.weight(0.9f))
                            Text(sec.formattedOutstanding, fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(1f))
                            Text(sec.formattedYield, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TreasuryGreenBright, modifier = Modifier.weight(0.8f))
                        }
                    }
                }
            }
        }
    }
}
