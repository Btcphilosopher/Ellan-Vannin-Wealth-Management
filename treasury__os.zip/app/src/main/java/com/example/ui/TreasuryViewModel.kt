package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.TreasuryOSState
import com.example.data.repository.TreasuryRepository
import com.example.domain.model.BuybackType
import com.example.domain.model.StressScenario
import com.example.ui.components.TerminalTab
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class TreasuryViewModel(
    private val repository: TreasuryRepository = TreasuryRepository()
) : ViewModel() {

    val uiState: StateFlow<TreasuryOSState> = repository.state

    private val _selectedTab = MutableStateFlow(TerminalTab.EXECUTIVE)
    val selectedTab: StateFlow<TerminalTab> = _selectedTab.asStateFlow()

    fun selectTab(tab: TerminalTab) {
        _selectedTab.update { tab }
    }

    fun applyScenario(scenario: StressScenario) {
        repository.applyScenario(scenario)
    }

    fun runAuctionSimulation(
        offering: Double,
        wiYield: Double,
        cover: Double,
        dealerAggressiveness: Double,
        foreignDemand: Double
    ) {
        repository.runAuctionSimulation(offering, wiYield, cover, dealerAggressiveness, foreignDemand)
    }

    fun selectRefundingIndex(index: Int) {
        repository.selectRefundingPlan(index)
    }

    fun executeBuyback(type: BuybackType, amount: Double, range: String) {
        repository.executeManualBuyback(type, amount, range)
    }

    fun advanceOperatingDayPhase() {
        repository.advanceOperatingDayPhase()
    }

    fun executeTerminalCommand(cmd: String) {
        repository.executeTerminalCommand(cmd)
    }

    fun askAi(query: String) {
        repository.generateAiExplanation(query)
    }
}
