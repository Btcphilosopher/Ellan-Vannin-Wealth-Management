package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TreasuryOSState
import com.example.domain.model.BidderCategory
import com.example.ui.components.StatMetricCard
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun AuctionDeskScreen(
    state: TreasuryOSState,
    onRunAuctionSim: (offering: Double, wiYield: Double, cover: Double, dealerAggressiveness: Double, foreignDemand: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var offeringSize by remember { mutableStateOf(42.0) }
    var wiBenchmarkYield by remember { mutableStateOf(4.38) }
    var bidToCoverTarget by remember { mutableStateOf(2.45) }
    var dealerAggressiveness by remember { mutableStateOf(1.0) }
    var foreignDemandMultiplier by remember { mutableStateOf(1.0) }

    val activeAuction = state.activeSimulationAuction

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TreasuryNavyDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "AUCTION OPERATIONS DESK & DUTCH CLEARING LAB",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = SovereignGoldBright
            )
            Text(
                text = "Single-Price Dutch Auction Engine, Bid Validation & Allotment Book",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextMuted
            )
        }

        // Active Auction Metric Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Stop-Out Yield",
                    value = String.format(Locale.US, "%.3f%%", activeAuction.stopOutYieldPct),
                    subValue = "Tail: ${String.format(Locale.US, "%+.1f bp", activeAuction.tailBasisPoints)}",
                    badgeText = "CLEARED",
                    badgeColor = TreasuryGreenMuted,
                    valueColor = SovereignGoldBright,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Bid-To-Cover",
                    value = String.format(Locale.US, "%.2fx", activeAuction.bidToCoverRatio),
                    subValue = "Total Bids: $${activeAuction.totalBidsReceivedBillions.toInt()}B",
                    badgeText = "DEMAND",
                    badgeColor = SteelBlueMuted,
                    valueColor = TextHighlight,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Offering Awarded",
                    value = "$${activeAuction.totalAwarded.toInt()}B",
                    subValue = "Non-Comp: $${activeAuction.nonCompetitiveAwardedBillions.toInt()}B",
                    badgeText = "OFFERING",
                    badgeColor = TreasuryNavyElevated,
                    valueColor = TextHighlight,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Indirect / Foreign",
                    value = String.format(Locale.US, "%.1f%%", activeAuction.indirectForeignPct),
                    subValue = "Primary Dealers: ${String.format(Locale.US, "%.1f%%", activeAuction.primaryDealerPct)}",
                    badgeText = "TAKEDOWN",
                    badgeColor = SteelBlueMuted,
                    valueColor = SteelBlueLight,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Interactive Auction Simulator Lab
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, SovereignGoldMuted, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AUCTION LAB // SIMULATION PARAMETERS",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGoldBright
                        )
                        IconButton(
                            onClick = {
                                offeringSize = 42.0
                                wiBenchmarkYield = 4.38
                                bidToCoverTarget = 2.45
                                dealerAggressiveness = 1.0
                                foreignDemandMultiplier = 1.0
                                onRunAuctionSim(offeringSize, wiBenchmarkYield, bidToCoverTarget, dealerAggressiveness, foreignDemandMultiplier)
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = TextMuted, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Parameter 1: Offering Size
                    Text(
                        text = "Offering Size: $${offeringSize.toInt()}B",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = TextPrimary
                    )
                    Slider(
                        value = offeringSize.toFloat(),
                        onValueChange = { offeringSize = it.toDouble() },
                        valueRange = 10f..100f,
                        steps = 18,
                        colors = SliderDefaults.colors(thumbColor = SovereignGold, activeTrackColor = SovereignGold)
                    )

                    // Parameter 2: When-Issued (WI) Benchmark Yield
                    Text(
                        text = "When-Issued (WI) Benchmark Yield: ${String.format(Locale.US, "%.3f%%", wiBenchmarkYield)}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = TextPrimary
                    )
                    Slider(
                        value = wiBenchmarkYield.toFloat(),
                        onValueChange = { wiBenchmarkYield = it.toDouble() },
                        valueRange = 3.0f..6.0f,
                        colors = SliderDefaults.colors(thumbColor = SteelBlue, activeTrackColor = SteelBlue)
                    )

                    // Parameter 3: Bid-to-Cover Ratio Target
                    Text(
                        text = "Demand Elasticity (Bid-to-Cover): ${String.format(Locale.US, "%.2fx", bidToCoverTarget)}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = TextPrimary
                    )
                    Slider(
                        value = bidToCoverTarget.toFloat(),
                        onValueChange = { bidToCoverTarget = it.toDouble() },
                        valueRange = 1.5f..3.5f,
                        colors = SliderDefaults.colors(thumbColor = TreasuryGreenBright, activeTrackColor = TreasuryGreenBright)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = {
                            onRunAuctionSim(offeringSize, wiBenchmarkYield, bidToCoverTarget, dealerAggressiveness, foreignDemandMultiplier)
                        },
                        modifier = Modifier.fillMaxWidth().height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignGold, contentColor = TreasuryNavyDark),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "CLEAR DUTCH AUCTION SIMULATION",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Auction Bid Book / Order Book
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "COMPETITIVE BID BOOK & ALLOTMENTS (${activeAuction.bids.size} BIDS)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TreasuryNavyElevated)
                            .padding(vertical = 4.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("BIDDER / CATEGORY", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(1.4f))
                        Text("BID YIELD", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(0.8f))
                        Text("BID AMT", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(0.8f))
                        Text("AWARDED", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(0.8f))
                        Text("STATUS", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(0.7f))
                    }

                    activeAuction.bids.take(12).forEach { bid ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp, horizontal = 4.dp)
                                .border(0.5.dp, TreasuryNavyBorderSubtle),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.4f)) {
                                Text(bid.bidderName, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                                Text(bid.category.label, fontFamily = FontFamily.Monospace, fontSize = 7.5.sp, color = TextMuted, maxLines = 1)
                            }
                            Text(String.format(Locale.US, "%.3f%%", bid.yieldOrRatePct), fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextPrimary, modifier = Modifier.weight(0.8f))
                            Text("$${String.format(Locale.US, "%.1fB", bid.bidAmountBillions)}", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextSecondary, modifier = Modifier.weight(0.8f))
                            Text("$${String.format(Locale.US, "%.1fB", bid.allocatedAmountBillions)}", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = if (bid.isAccepted) TreasuryGreenBright else StressRed, modifier = Modifier.weight(0.8f))
                            Text(if (bid.isAccepted) "ALLOT" else "OUT", fontFamily = FontFamily.Monospace, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = if (bid.isAccepted) TreasuryGreenBright else StressRed, modifier = Modifier.weight(0.7f))
                        }
                    }
                }
            }
        }

        // Upcoming Issuance Calendar
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "UPCOMING AUCTION CALENDAR",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    state.upcomingCalendar.forEach { auc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp, horizontal = 4.dp)
                                .border(0.5.dp, TreasuryNavyBorderSubtle),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(auc.securityName, fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text("Auction Date: ${auc.auctionDate}", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted)
                            }
                            Text("$${auc.offeringAmountBillions.toInt()}B", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SovereignGold)
                        }
                    }
                }
            }
        }
    }
}
