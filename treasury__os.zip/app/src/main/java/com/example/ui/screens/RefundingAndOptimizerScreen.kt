package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TreasuryOSState
import com.example.domain.model.BuybackType
import com.example.ui.components.StatMetricCard
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun RefundingAndOptimizerScreen(
    state: TreasuryOSState,
    onSelectRefundingIndex: (Int) -> Unit,
    onExecuteBuyback: (type: BuybackType, amount: Double, range: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var buybackType by remember { mutableStateOf(BuybackType.LIQUIDITY_SUPPORT) }
    var buybackAmount by remember { mutableStateOf(5.0) }
    var buybackMaturityRange by remember { mutableStateOf("2036-2046 Off-The-Run Benchmark Bonds") }

    val selectedPlan = state.refundingScenarios.getOrNull(state.selectedRefundingIndex) ?: state.refundingScenarios.first()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TreasuryNavyDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "TBAC QUARTERLY REFUNDING & ISSUANCE OPTIMIZER",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = SovereignGoldBright
            )
            Text(
                text = "Debt Composition Optimization, Rollover Risk Minimization & Buyback Operations",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextMuted
            )
        }

        // Refunding Metric Highlights
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Quarterly Issuance",
                    value = "$${selectedPlan.totalIssuanceBillions.toInt()}B",
                    subValue = "Bills Share: $${selectedPlan.billsIssuanceBillions.toInt()}B (${String.format(Locale.US, "%.1f%%", (selectedPlan.billsIssuanceBillions / selectedPlan.totalIssuanceBillions) * 100)})",
                    badgeText = "GROSS PROGRAMME",
                    badgeColor = SteelBlueMuted,
                    valueColor = TextHighlight,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Weighted Cost",
                    value = String.format(Locale.US, "%.2f%%", selectedPlan.weightedFundingCostPct),
                    subValue = "WAM: ${String.format(Locale.US, "%.1f yrs", selectedPlan.weightedAvgMaturityYears)}",
                    badgeText = "EXPECTED COST",
                    badgeColor = SovereignGoldMuted,
                    valueColor = SovereignGoldBright,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Rollover Risk Score",
                    value = "${selectedPlan.rolloverRiskScore.toInt()} / 100",
                    subValue = if (selectedPlan.rolloverRiskScore < 40) "Prudent / Low Cliff" else "Elevated Front-End Roll",
                    badgeText = "RISK INDEX",
                    badgeColor = if (selectedPlan.rolloverRiskScore < 40) TreasuryGreenMuted else StressRedDark,
                    valueColor = if (selectedPlan.rolloverRiskScore < 40) TreasuryGreenBright else StressRed,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Liquidity Score",
                    value = "${selectedPlan.liquidityScore.toInt()} / 100",
                    subValue = "Maintains Primary Benchmarks",
                    badgeText = "MARKET DEPTH",
                    badgeColor = TreasuryNavyElevated,
                    valueColor = SteelBlueLight,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Refunding Strategy Proposal Selector
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "SELECT QUARTERLY REFUNDING STRATEGY",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    state.refundingScenarios.forEachIndexed { idx, plan ->
                        val isSel = idx == state.selectedRefundingIndex
                        Surface(
                            color = if (isSel) TreasuryNavyElevated else TreasuryNavyDark,
                            shape = RoundedCornerShape(3.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .border(1.dp, if (isSel) SovereignGold else TreasuryNavyBorderSubtle, RoundedCornerShape(3.dp))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = plan.quarterLabel,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) SovereignGoldBright else TextPrimary
                                    )
                                    Text(
                                        text = "Cost: ${plan.weightedFundingCostPct}% | WAM: ${plan.weightedAvgMaturityYears}y | Rollover: ${plan.rolloverRiskScore.toInt()}",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.5.sp,
                                        color = TextMuted
                                    )
                                }

                                Button(
                                    onClick = { onSelectRefundingIndex(idx) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSel) SovereignGold else TreasuryNavyCard,
                                        contentColor = if (isSel) TreasuryNavyDark else TextSecondary
                                    ),
                                    modifier = Modifier.height(28.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Text(if (isSel) "ACTIVE" else "SELECT", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Detailed Security Issuance Breakdown Table
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "ALLOCATION BY BENCHMARK TENOR (${selectedPlan.quarterLabel})",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val breakdown = listOf(
                        "Treasury Bills (4W-52W)" to selectedPlan.billsIssuanceBillions,
                        "2-Year Notes" to selectedPlan.note2YBillions,
                        "3-Year Notes" to selectedPlan.note3YBillions,
                        "5-Year Notes" to selectedPlan.note5YBillions,
                        "7-Year Notes" to selectedPlan.note7YBillions,
                        "10-Year Notes" to selectedPlan.note10YBillions,
                        "20-Year Bonds" to selectedPlan.bond20YBillions,
                        "30-Year Bonds" to selectedPlan.bond30YBillions,
                        "TIPS (5Y, 10Y, 30Y)" to selectedPlan.tipsIssuanceBillions,
                        "FRNs (2Y Floating Rate)" to selectedPlan.frnIssuanceBillions,
                        "CMB Flex Buffer" to selectedPlan.cmbReserveBillions
                    )

                    breakdown.forEach { (tenor, amt) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .border(0.5.dp, TreasuryNavyBorderSubtle)
                                .padding(horizontal = 6.dp, vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(tenor, fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextPrimary)
                            Text("$${amt.toInt()}B", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SteelBlueLight)
                        }
                    }
                }
            }
        }

        // Treasury Buybacks Operations Desk
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, SovereignGoldMuted, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "TREASURY BUYBACK OPERATIONS DESK",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { buybackType = BuybackType.LIQUIDITY_SUPPORT },
                            modifier = Modifier.weight(1f).height(32.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (buybackType == BuybackType.LIQUIDITY_SUPPORT) SovereignGold else TreasuryNavyDark,
                                contentColor = if (buybackType == BuybackType.LIQUIDITY_SUPPORT) TreasuryNavyDark else TextSecondary
                            )
                        ) {
                            Text("Liquidity Support", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { buybackType = BuybackType.CASH_MANAGEMENT },
                            modifier = Modifier.weight(1f).height(32.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (buybackType == BuybackType.CASH_MANAGEMENT) SovereignGold else TreasuryNavyDark,
                                contentColor = if (buybackType == BuybackType.CASH_MANAGEMENT) TreasuryNavyDark else TextSecondary
                            )
                        ) {
                            Text("Cash Management", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Target Buyback Par: $${buybackAmount.toInt()}B",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = TextPrimary
                    )
                    Slider(
                        value = buybackAmount.toFloat(),
                        onValueChange = { buybackAmount = it.toDouble() },
                        valueRange = 1f..25f,
                        colors = SliderDefaults.colors(thumbColor = SovereignGold, activeTrackColor = SovereignGold)
                    )

                    Button(
                        onClick = { onExecuteBuyback(buybackType, buybackAmount, buybackMaturityRange) },
                        modifier = Modifier.fillMaxWidth().height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SovereignGold, contentColor = TreasuryNavyDark),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "EXECUTE SOVEREIGN BUYBACK OPERATION",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "RECENT BUYBACK TRANSACTIONS:",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.5.sp,
                        color = TextMuted
                    )

                    state.buybackOperations.forEach { bbk ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .border(0.5.dp, TreasuryNavyBorderSubtle)
                                .padding(horizontal = 4.dp, vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("${bbk.operationId} (${bbk.type.label})", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text("Tendered: $${bbk.tenderedAmountBillions}B | Disbursed: $${String.format(Locale.US, "%.1fB", bbk.totalCashDisbursedBillions)}", fontFamily = FontFamily.Monospace, fontSize = 7.5.sp, color = TextMuted)
                            }
                            Text("Accepted: $${bbk.acceptedAmountBillions}B", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TreasuryGreenBright)
                        }
                    }
                }
            }
        }
    }
}
