package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TreasuryOSState
import com.example.domain.model.StressScenario
import com.example.ui.components.MonteCarloHistogramChart
import com.example.ui.components.StatMetricCard
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun RiskAndMonteCarloScreen(
    state: TreasuryOSState,
    onApplyScenario: (StressScenario) -> Unit,
    modifier: Modifier = Modifier
) {
    val mc = state.monteCarloMetrics

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TreasuryNavyDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "MACRO RISK & 10,000 MONTE CARLO ENGINE",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = SovereignGoldBright
            )
            Text(
                text = "Stress Shocks, Value at Risk (VaR), Refinancing Exposure & TGA Buffer Risk",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextMuted
            )
        }

        // Monte Carlo Risk Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Mean Interest Cost",
                    value = "$${mc.meanInterestCostBillions.toInt()}B / yr",
                    subValue = "Expected Annual Debt Service",
                    badgeText = "10,000 RUNS",
                    badgeColor = SteelBlueMuted,
                    valueColor = TextHighlight,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "99% VaR Interest",
                    value = "$${mc.p99InterestCostBillions.toInt()}B / yr",
                    subValue = "95% VaR: $${mc.p95InterestCostBillions.toInt()}B",
                    badgeText = "EXTREME TAIL",
                    badgeColor = StressRedDark,
                    valueColor = StressRed,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Cash Shortfall Prob",
                    value = String.format(Locale.US, "%.2f%%", mc.probCashShortfallPct),
                    subValue = "TGA Drop Below $300B Buffer",
                    badgeText = "LIQUIDITY RISK",
                    badgeColor = if (mc.probCashShortfallPct < 5.0) TreasuryGreenMuted else StressRedDark,
                    valueColor = if (mc.probCashShortfallPct < 5.0) TreasuryGreenBright else StressRed,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Expected Borrowing",
                    value = "$${String.format(Locale.US, "%.2fT", mc.expectedBorrowingRequirementTrillions)}",
                    subValue = "Annual Net Marketable Borrowing",
                    badgeText = "FINANCING",
                    badgeColor = SovereignGoldMuted,
                    valueColor = SovereignGoldBright,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Monte Carlo Histogram Chart
        item {
            MonteCarloHistogramChart(
                bins = mc.distributionBins,
                p95 = mc.p95InterestCostBillions,
                p99 = mc.p99InterestCostBillions
            )
        }

        // Interactive Macro Shock Scenario Suite
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "MACRO STRESS TESTING SUITE",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    StressScenario.values().forEach { scenario ->
                        val isActive = scenario == state.activeScenario

                        Surface(
                            color = if (isActive) TreasuryNavyElevated else TreasuryNavyDark,
                            shape = RoundedCornerShape(3.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .border(1.dp, if (isActive) SovereignGold else TreasuryNavyBorderSubtle, RoundedCornerShape(3.dp))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = scenario.title,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isActive) SovereignGoldBright else TextPrimary
                                    )
                                    Text(
                                        text = scenario.description,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.sp,
                                        color = TextMuted
                                    )
                                }

                                Button(
                                    onClick = { onApplyScenario(scenario) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isActive) SovereignGold else TreasuryNavyCard,
                                        contentColor = if (isActive) TreasuryNavyDark else TextSecondary
                                    ),
                                    modifier = Modifier.height(28.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Text(
                                        text = if (isActive) "ACTIVE" else "APPLY",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
