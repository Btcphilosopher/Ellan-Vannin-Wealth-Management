package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TreasuryOSState
import com.example.ui.components.StatMetricCard
import com.example.ui.components.YieldCurveChart
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun YieldAndMarketScreen(
    state: TreasuryOSState,
    modifier: Modifier = Modifier
) {
    val repo = state.repoMarket

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TreasuryNavyDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "TREASURY YIELD CURVE & REPO MARKET DESK",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = SovereignGoldBright
            )
            Text(
                text = "Par, Zero & Forward Curves, When-Issued Spreads & SOFR / Collateral Depth",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextMuted
            )
        }

        // Repo Market Key Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "SOFR Benchmark",
                    value = String.format(Locale.US, "%.2f%%", repo.sofrRatePct),
                    subValue = "Overnight Repo: ${String.format(Locale.US, "%.2f%%", repo.repoOvernightRatePct)}",
                    badgeText = "SHORT-TERM",
                    badgeColor = SteelBlueMuted,
                    valueColor = TextHighlight,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Repo Specialness",
                    value = String.format(Locale.US, "%.1f bp", repo.specialnessBasisPoints),
                    subValue = "Primary Dealer Inv: $${repo.primaryDealerInventoryBillions}B",
                    badgeText = "COLLATERAL",
                    badgeColor = SovereignGoldMuted,
                    valueColor = SovereignGoldBright,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Yield Curve Chart
        item {
            YieldCurveChart(points = state.yieldCurve)
        }

        // Detailed Yield Curve Table (Par, Zero, Forward, Discount Factor, WI Yield)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "TERM STRUCTURE OF INTEREST RATES",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TreasuryNavyElevated)
                            .padding(vertical = 4.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TENOR", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(0.8f))
                        Text("PAR YIELD", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("ZERO RATE", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("FWD RATE", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("WI SPREAD", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted, modifier = Modifier.weight(1f))
                    }

                    state.yieldCurve.forEach { pt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp, horizontal = 4.dp)
                                .border(0.5.dp, TreasuryNavyBorderSubtle),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(pt.tenorLabel, fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(0.8f))
                            Text(String.format(Locale.US, "%.3f%%", pt.parYieldPct), fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = SteelBlueLight, modifier = Modifier.weight(1f))
                            Text(String.format(Locale.US, "%.3f%%", pt.zeroRatePct), fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                            Text(String.format(Locale.US, "%.3f%%", pt.forwardRatePct), fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                            Text(String.format(Locale.US, "%+.1f bp", pt.wiSpreadBasisPoints), fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = if (pt.wiSpreadBasisPoints >= 0) SovereignGold else TreasuryGreenBright, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // Market Mechanics Explanation Box
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyDark)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "MARKET COUPLING DYNAMICS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "NEW TREASURY ISSUANCE → PRIMARY DEALER INVENTORY → TRIPLATE REPO FUNDING → SOFR CLEARING BENCHMARK → FOREIGN CENTRAL BANK ALLOTMENT",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.5.sp,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}
