package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TreasuryOSState
import com.example.domain.model.CashFlowDirection
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun ReportsAndAuditScreen(
    state: TreasuryOSState,
    modifier: Modifier = Modifier
) {
    var selectedReportType by remember { mutableStateOf("DTS") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TreasuryNavyDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "FISCAL REPORTING & IMMUTABLE AUDIT TRAIL",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = SovereignGoldBright
            )
            Text(
                text = "Daily Treasury Statement (DTS), Monthly Statements & SHA-256 Event Sourcing Log",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextMuted
            )
        }

        // Report Type Selector Tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    "DTS" to "Daily Treasury Statement",
                    "MTS" to "Monthly Treasury Statement",
                    "REFUND" to "Quarterly Refunding Pack",
                    "AUDIT" to "Event Sourcing Audit"
                ).forEach { (code, title) ->
                    val isSel = selectedReportType == code
                    Button(
                        onClick = { selectedReportType = code },
                        modifier = Modifier.weight(1f).height(32.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSel) SovereignGold else TreasuryNavyCard,
                            contentColor = if (isSel) TreasuryNavyDark else TextSecondary
                        ),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Text(code, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Render selected report content
        when (selectedReportType) {
            "DTS" -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(TreasuryNavyCard)
                            .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                            .padding(12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "DAILY TREASURY STATEMENT (DTS)",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SovereignGoldBright
                                    )
                                    Text(
                                        text = "TABLE I — Operating Cash Balance for ${state.currentDate}",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.5.sp,
                                        color = TextMuted
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(TreasuryGreenMuted)
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text("OFFICIAL // PUBLISHED", fontFamily = FontFamily.Monospace, fontSize = 7.5.sp, fontWeight = FontWeight.Bold, color = TextHighlight)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Table of DTS
                            val dtsLines = listOf(
                                "Opening Balance (Federal Reserve Account)" to "$${state.tgaAccount.openingBalanceBillions}B",
                                "Taxes & Electronic Deposit Collections" to "+$${state.tgaAccount.taxReceiptsBillions}B",
                                "Other Agency Collections & Tariffs" to "+$${state.tgaAccount.otherReceiptsBillions}B",
                                "Marketable Treasury Securities Issued" to "+$${state.tgaAccount.debtIssuanceInflowBillions}B",
                                "Gross Federal Government Disbursements" to "-$${state.tgaAccount.governmentPaymentsBillions}B",
                                "Treasury Securities Redeemed / Matured" to "-$${state.tgaAccount.debtMaturitiesOutflowBillions}B",
                                "Public Debt Interest & Coupons Disbursed" to "-$${state.tgaAccount.interestPaymentsOutflowBillions}B",
                                "Closing Balance (Federal Reserve Account)" to "$${state.tgaAccount.closingBalanceBillions}B"
                            )

                            dtsLines.forEach { (desc, amt) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .border(0.5.dp, TreasuryNavyBorderSubtle)
                                        .padding(horizontal = 6.dp, vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(desc, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextPrimary)
                                    Text(amt, fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (amt.startsWith("+")) TreasuryGreenBright else if (amt.startsWith("-")) StressRed else SovereignGold)
                                }
                            }
                        }
                    }
                }
            }
            "MTS" -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(TreasuryNavyCard)
                            .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                            .padding(12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "MONTHLY TREASURY STATEMENT (MTS) SUMMARY",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignGoldBright
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Fiscal Year-To-Date (FY2026) Receipts: $4.85T | Outlays: $6.70T | Net Deficit: $1.85T\nNet Marketable Borrowing Financed: $1.92T | Non-Marketable Trust Fund Inflows: $70B",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.5.sp,
                                color = TextSecondary,
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
            "REFUND" -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(TreasuryNavyCard)
                            .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                            .padding(12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "QUARTERLY REFUNDING STATEMENT & TBAC CHARGES",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignGoldBright
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Treasury intends to maintain nominal coupon auction sizes at current levels over the coming quarter. Buyback program authorized up to $30B for liquidity support and $10B for cash management.",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.5.sp,
                                color = TextSecondary,
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
            "AUDIT" -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(TreasuryNavyCard)
                            .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                            .padding(10.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "IMMUTABLE EVENT SOURCING AUDIT TRAIL",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SovereignGoldBright
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            state.auditEvents.forEach { ev ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                        .border(0.5.dp, TreasuryNavyBorderSubtle)
                                        .padding(horizontal = 6.dp, vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(ev.eventType, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = SovereignGold)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(ev.timestamp, fontFamily = FontFamily.Monospace, fontSize = 7.5.sp, color = TextMuted)
                                        }
                                        Text(ev.summary, fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextPrimary)
                                        Text("Actor: ${ev.actor} | Hash: ${ev.verifiedHash}", fontFamily = FontFamily.Monospace, fontSize = 7.5.sp, color = SteelBlueLight)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
