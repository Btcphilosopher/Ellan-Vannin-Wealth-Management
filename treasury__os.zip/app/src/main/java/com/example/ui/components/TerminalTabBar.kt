package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

enum class TerminalTab(
    val label: String,
    val shortLabel: String,
    val icon: ImageVector
) {
    EXECUTIVE("EXECUTIVE", "EXEC", Icons.Default.Dashboard),
    TGA_CASH("CASH // TGA", "CASH", Icons.Default.AccountBalance),
    DEBT_SECURITIES("DEBT // SECURITIES", "DEBT", Icons.Default.ReceiptLong),
    AUCTION_DESK("AUCTION // LAB", "AUCT", Icons.Default.Gavel),
    REFUNDING("REFUNDING // DESK", "REFUND", Icons.Default.Tune),
    YIELD_MARKET("YIELD // MARKET", "YIELD", Icons.Default.TrendingUp),
    VAULT_CUSTODY("VAULT // CUSTODY", "VAULT", Icons.Default.Lock),
    RISK_SCENARIOS("RISK // MONTE CARLO", "RISK", Icons.Default.Warning),
    AI_TERMINAL("AI // CLI", "CLI", Icons.Default.Terminal),
    REPORTS_AUDIT("REPORTS // AUDIT", "AUDIT", Icons.Default.Assignment)
}

@Composable
fun TerminalTabBar(
    selectedTab: TerminalTab,
    onTabSelected: (TerminalTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = TreasuryNavyDark,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, TreasuryNavyBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TerminalTab.values().forEach { tab ->
                val isSelected = tab == selectedTab

                Button(
                    onClick = { onTabSelected(tab) },
                    modifier = Modifier.height(34.dp),
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) TreasuryNavyElevated else TreasuryNavyCard,
                        contentColor = if (isSelected) SovereignGoldBright else TextSecondary
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(
                            if (isSelected) SovereignGold else TreasuryNavyBorder
                        )
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                ) {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.label,
                        modifier = Modifier.size(13.dp),
                        tint = if (isSelected) SovereignGoldBright else TextMuted
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = tab.label,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}
