package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TreasuryOSState
import com.example.ui.theme.*

@Composable
fun AiAndTerminalScreen(
    state: TreasuryOSState,
    onExecuteCommand: (String) -> Unit,
    onAskAi: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var commandInput by remember { mutableStateOf("") }
    var aiQueryInput by remember { mutableStateOf("") }
    val terminalListState = rememberLazyListState()

    LaunchedEffect(state.terminalHistory.size) {
        terminalListState.animateScrollToItem((state.terminalHistory.size - 1).coerceAtLeast(0))
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TreasuryNavyDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "TREASURY//AI & REPL TERMINAL INTERFACE",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = SovereignGoldBright
            )
            Text(
                text = "Deterministic Sovereign Reasoning, Variance Attribution & Direct CLI Shell",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextMuted
            )
        }

        // TREASURY//AI Institutional Reasoning Box
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, SovereignGoldMuted, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TREASURY//AI REASONING CORE",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGoldBright
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(TreasuryNavyElevated)
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "ZERO-FABRICATION VERIFIED",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 7.5.sp,
                                color = MonospaceGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Preset quick questions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Button(
                            onClick = {
                                aiQueryInput = "Why did borrowing increase this quarter?"
                                onAskAi(aiQueryInput)
                            },
                            modifier = Modifier.weight(1f).height(28.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = TreasuryNavyDark)
                        ) {
                            Text("Borrowing Drivers", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextPrimary)
                        }

                        Button(
                            onClick = {
                                aiQueryInput = "Analyze 13W bill auction tail"
                                onAskAi(aiQueryInput)
                            },
                            modifier = Modifier.weight(1f).height(28.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = TreasuryNavyDark)
                        ) {
                            Text("Auction Tail", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextPrimary)
                        }

                        Button(
                            onClick = {
                                aiQueryInput = "Evaluate TBAC refunding strategy"
                                onAskAi(aiQueryInput)
                            },
                            modifier = Modifier.weight(1f).height(28.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = TreasuryNavyDark)
                        ) {
                            Text("TBAC Strategy", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Question Input
                    OutlinedTextField(
                        value = aiQueryInput,
                        onValueChange = { aiQueryInput = it },
                        placeholder = { Text("Ask sovereign financing or cash variance question...", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = TextPrimary),
                        trailingIcon = {
                            IconButton(onClick = {
                                if (aiQueryInput.isNotBlank()) onAskAi(aiQueryInput)
                            }) {
                                Icon(Icons.Default.Send, contentDescription = "Query", tint = SovereignGold, modifier = Modifier.size(16.dp))
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SovereignGold,
                            unfocusedBorderColor = TreasuryNavyBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // AI Response Output
                    if (state.aiInsightResponse.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(TreasuryNavyDark)
                                .border(1.dp, TreasuryNavyBorderSubtle, RoundedCornerShape(3.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = state.aiInsightResponse,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                lineHeight = 14.sp,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }

        // Full Interactive Terminal CLI REPL
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF04070D))
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = MonospaceGreen, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("TREASURY//OS REPL SHELL", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MonospaceGreen)
                        }
                        Text("Type 'help' for commands", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Terminal History Output
                    LazyColumn(
                        state = terminalListState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(Color(0xFF030509))
                            .border(0.5.dp, Color(0xFF152238))
                            .padding(6.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        items(state.terminalHistory) { line ->
                            Text(
                                text = line,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.5.sp,
                                lineHeight = 12.sp,
                                color = if (line.startsWith(">")) SovereignGoldBright else if (line.contains("ERROR")) StressRed else TextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Terminal Command Line Input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "treasury-os> ",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = MonospaceGreen
                        )

                        OutlinedTextField(
                            value = commandInput,
                            onValueChange = { commandInput = it },
                            placeholder = { Text("e.g. tga, forecast, sim-auction 42 4.38 2.5", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextMuted) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = {
                                if (commandInput.isNotBlank()) {
                                    onExecuteCommand(commandInput)
                                    commandInput = ""
                                }
                            }),
                            modifier = Modifier.weight(1f).height(44.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextHighlight),
                            trailingIcon = {
                                IconButton(onClick = {
                                    if (commandInput.isNotBlank()) {
                                        onExecuteCommand(commandInput)
                                        commandInput = ""
                                    }
                                }) {
                                    Icon(Icons.Default.Send, contentDescription = "Run", tint = MonospaceGreen, modifier = Modifier.size(14.dp))
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MonospaceGreen,
                                unfocusedBorderColor = TreasuryNavyBorder
                            )
                        )
                    }
                }
            }
        }
    }
}
