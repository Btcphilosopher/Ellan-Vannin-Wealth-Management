package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TreasuryOSState
import com.example.domain.model.NumberFormatters
import com.example.domain.model.StressScenario
import com.example.ui.components.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun ExecutiveControlRoomScreen(
    state: TreasuryOSState,
    onNavigateTab: (TerminalTab) -> Unit,
    onApplyScenario: (StressScenario) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TreasuryNavyDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            // Institutional Command Room Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "EXECUTIVE CONTROL ROOM",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )
                    Text(
                        text = "Sovereign Balance Sheet, Cash Liquidity & Debt Operations",
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                // Scenario pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (state.activeScenario == StressScenario.BASELINE) TreasuryGreenMuted else StressRedDark)
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = state.activeScenario.title.uppercase(),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextHighlight
                    )
                }
            }
        }

        // Primary KPI Grid (6 Metric Cards)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "TGA Balance",
                    value = "$${String.format(Locale.US, "%.1fB", state.tgaAccount.closingBalanceBillions)}",
                    subValue = "Target: $${state.tgaAccount.targetBalanceBillions.toInt()}B",
                    badgeText = "PRUDENTIAL",
                    badgeColor = TreasuryGreenMuted,
                    valueColor = TreasuryGreenBright,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Debt Outstanding",
                    value = "$${String.format(Locale.US, "%.2fT", state.portfolioMetrics.totalDebtOutstandingTrillions)}",
                    subValue = "Marketable: $${String.format(Locale.US, "%.2fT", state.portfolioMetrics.marketableDebtTrillions)}",
                    badgeText = "STATUTORY",
                    badgeColor = SteelBlueMuted,
                    valueColor = TextHighlight,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Today Net Cash Flow",
                    value = String.format(Locale.US, "%+,.1fB", state.tgaAccount.netDailyCashFlow),
                    subValue = "In: +$${state.tgaAccount.totalInflows.toInt()}B | Out: -$${state.tgaAccount.totalOutflows.toInt()}B",
                    badgeText = "DAILY RECON",
                    badgeColor = if (state.tgaAccount.isLedgerBalanced) TreasuryGreenMuted else StressRedDark,
                    valueColor = if (state.tgaAccount.netDailyCashFlow >= 0) TreasuryGreenBright else StressRed,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Next 7D Fin Need",
                    value = "$${state.cashForecasts.getOrNull(1)?.financingRequirementBillions?.toInt() ?: 0}B",
                    subValue = "30D Need: $${state.cashForecasts.getOrNull(3)?.financingRequirementBillions?.toInt() ?: 0}B",
                    badgeText = "CASH GAP",
                    badgeColor = SovereignGoldMuted,
                    valueColor = SovereignGoldBright,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMetricCard(
                    label = "Gross Int Expense",
                    value = "$${state.portfolioMetrics.annualGrossInterestExpenseBillions.toInt()}B / yr",
                    subValue = "Avg Coupon: ${String.format(Locale.US, "%.2f%%", state.portfolioMetrics.weightedAverageCouponPct)}",
                    badgeText = "DEBT SERVICE",
                    badgeColor = TreasuryNavyElevated,
                    valueColor = TextHighlight,
                    modifier = Modifier.weight(1f)
                )
                StatMetricCard(
                    label = "Next Auction",
                    value = "$${state.upcomingCalendar.firstOrNull()?.offeringAmountBillions?.toInt() ?: 65}B",
                    subValue = state.upcomingCalendar.firstOrNull()?.securityName ?: "13-Week Bill",
                    badgeText = "OCT 06",
                    badgeColor = SteelBlueMuted,
                    valueColor = SteelBlueLight,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // TGA Trajectory Envelope Chart
        item {
            CashForecastEnvelopeChart(
                forecasts = state.cashForecasts,
                targetTgaBillions = state.tgaAccount.targetBalanceBillions
            )
        }

        // Yield Curve Benchmark
        item {
            YieldCurveChart(points = state.yieldCurve)
        }

        // Maturity Wall Bar Chart
        item {
            MaturityWallChart(buckets = state.maturityWall)
        }

        // Quick Navigation & Desk Launchers
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "CORE OPERATIONS DESKS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onNavigateTab(TerminalTab.TGA_CASH) },
                            modifier = Modifier.weight(1f).height(38.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = TreasuryNavyElevated)
                        ) {
                            Text("CASH // TGA", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextPrimary)
                        }

                        OutlinedButton(
                            onClick = { onNavigateTab(TerminalTab.AUCTION_DESK) },
                            modifier = Modifier.weight(1f).height(38.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = TreasuryNavyElevated)
                        ) {
                            Text("AUCTION LAB", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextPrimary)
                        }

                        OutlinedButton(
                            onClick = { onNavigateTab(TerminalTab.REFUNDING) },
                            modifier = Modifier.weight(1f).height(38.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = TreasuryNavyElevated)
                        ) {
                            Text("REFUNDING", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onNavigateTab(TerminalTab.RISK_SCENARIOS) },
                            modifier = Modifier.weight(1f).height(38.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = TreasuryNavyElevated)
                        ) {
                            Text("RISK // SHOCK", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextPrimary)
                        }

                        OutlinedButton(
                            onClick = { onNavigateTab(TerminalTab.VAULT_CUSTODY) },
                            modifier = Modifier.weight(1f).height(38.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = TreasuryNavyElevated)
                        ) {
                            Text("GOLD VAULT", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextPrimary)
                        }

                        OutlinedButton(
                            onClick = { onNavigateTab(TerminalTab.AI_TERMINAL) },
                            modifier = Modifier.weight(1f).height(38.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = TreasuryNavyElevated)
                        ) {
                            Text("CLI TERMINAL", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SovereignGoldBright)
                        }
                    }
                }
            }
        }
    }
}
