package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val SovereignTerminalColorScheme = darkColorScheme(
    primary = SovereignGold,
    onPrimary = TreasuryNavyDark,
    primaryContainer = TreasuryNavyElevated,
    onPrimaryContainer = SovereignGoldBright,
    secondary = SteelBlue,
    onSecondary = TreasuryNavyDark,
    secondaryContainer = TreasuryNavyCard,
    onSecondaryContainer = SteelBlueLight,
    tertiary = TreasuryGreen,
    onTertiary = TreasuryNavyDark,
    tertiaryContainer = TreasuryNavyCard,
    onTertiaryContainer = TreasuryGreenBright,
    background = TreasuryNavyDark,
    onBackground = TextPrimary,
    surface = TreasuryNavySurface,
    onSurface = TextPrimary,
    surfaceVariant = TreasuryNavyCard,
    onSurfaceVariant = TextSecondary,
    outline = TreasuryNavyBorder,
    outlineVariant = TreasuryNavyBorderSubtle,
    error = StressRed,
    onError = TextHighlight
)

@Composable
fun TreasuryOSTheme(
    darkTheme: Boolean = true, // Force institutional terminal dark theme
    content: @Composable () -> Unit
) {
    val colorScheme = SovereignTerminalColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.surface.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
