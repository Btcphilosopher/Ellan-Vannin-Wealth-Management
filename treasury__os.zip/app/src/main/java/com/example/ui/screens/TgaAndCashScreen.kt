package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.FiscalFlowLink
import com.example.data.repository.FiscalFlowNode
import com.example.data.repository.TreasuryOSState
import com.example.domain.model.CashFlowDirection
import com.example.domain.model.CashFlowItem
import com.example.ui.components.CashForecastEnvelopeChart
import com.example.ui.components.StatMetricCard
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun TgaAndCashScreen(
    state: TreasuryOSState,
    modifier: Modifier = Modifier
) {
    var selectedNode by remember { mutableStateOf<FiscalFlowNode?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TreasuryNavyDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "TREASURY GENERAL ACCOUNT (TGA) & FISCAL CASH DESK",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = SovereignGoldBright
            )
            Text(
                text = "Central Operating Cash Balance, Inflows, Outlays & Banking Reserves",
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp,
                color = TextMuted
            )
        }

        // TGA Ledger Invariant Equation Box
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TGA DAILY RECONCILIATION & INVARIANT",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGoldBright
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (state.tgaAccount.isLedgerBalanced) TreasuryGreenMuted else StressRedDark)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (state.tgaAccount.isLedgerBalanced) "LEDGER BALANCED ✓" else "RECON ERROR ✗",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextHighlight
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Equation Line
                    Text(
                        text = "OPENING ($${state.tgaAccount.openingBalanceBillions}B) + INFLOWS (+$${state.tgaAccount.totalInflows}B) - OUTFLOWS (-$${state.tgaAccount.totalOutflows}B) = CLOSING ($${state.tgaAccount.closingBalanceBillions}B)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Commercial Bank Reserve Drain: ${String.format(Locale.US, "%+,.1fB", state.tgaAccount.fedReserveDrainImpactBillions)}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = SteelBlueLight
                        )
                        Text(
                            text = "Prudential Target: $${state.tgaAccount.targetBalanceBillions.toInt()}B",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = TreasuryGreenBright
                        )
                    }
                }
            }
        }

        // Multi-Horizon Forecast Table
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "MULTI-HORIZON CASH FORECAST (1D TO 1Y)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TreasuryNavyElevated)
                            .padding(vertical = 4.dp, horizontal = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("HORIZON", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextMuted, modifier = Modifier.weight(1.2f))
                        Text("INFLOWS", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("OUTLAYS", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("NET FLOW", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("FIN NEED", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextMuted, modifier = Modifier.weight(1f))
                    }

                    state.cashForecasts.forEach { fc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp, horizontal = 6.dp)
                                .border(0.5.dp, TreasuryNavyBorderSubtle),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(fc.horizonLabel, fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(1.2f))
                            Text("+$${fc.projectedInflowsBillions.toInt()}B", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TreasuryGreenBright, modifier = Modifier.weight(1f))
                            Text("-$${fc.projectedOutflowsBillions.toInt()}B", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = StressRed, modifier = Modifier.weight(1f))
                            Text(String.format(Locale.US, "%+,.0fB", fc.netFlowBillions), fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = if (fc.netFlowBillions >= 0) TreasuryGreenBright else StressRed, modifier = Modifier.weight(1f))
                            Text(if (fc.financingRequirementBillions > 0) "$${fc.financingRequirementBillions.toInt()}B" else "0", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = SovereignGold, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // Cash Envelope Chart
        item {
            CashForecastEnvelopeChart(
                forecasts = state.cashForecasts,
                targetTgaBillions = state.tgaAccount.targetBalanceBillions
            )
        }

        // Fiscal Flow Digital Twin Interactive Nodes
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "FISCAL CASH-FLOW DIGITAL TWIN (NETWORK GRAPH)",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SovereignGoldBright
                        )
                        Text(
                            text = "Tap node to inspect",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.5.sp,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Node list
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.fiscalNodes.forEach { node ->
                            val isSelected = selectedNode?.id == node.id
                            Surface(
                                color = if (isSelected) TreasuryNavyElevated else TreasuryNavyDark,
                                shape = RoundedCornerShape(3.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, if (isSelected) SovereignGold else TreasuryNavyBorderSubtle, RoundedCornerShape(3.dp))
                                    .clickable { selectedNode = if (isSelected) null else node }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = node.label,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) SovereignGoldBright else TextPrimary
                                        )
                                        Text(
                                            text = node.category,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 8.5.sp,
                                            color = TextMuted
                                        )
                                    }
                                    Text(
                                        text = "$${node.amountBillions.toInt()}B",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SteelBlueLight
                                    )
                                }
                            }
                        }
                    }

                    // Node Inspection Detail
                    if (selectedNode != null) {
                        val node = selectedNode!!
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(TreasuryNavyDark)
                                .border(1.dp, SovereignGoldMuted, RoundedCornerShape(3.dp))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(
                                    text = "INSPECTOR: ${node.label}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SovereignGold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Annualized Volume: $${node.amountBillions}B | Model Twin: Synthetic Flow Node\nConnected Fedwire clearing batches update every 15 minutes during operating window.",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.5.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Today's Detailed Receipts & Outlays List
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TreasuryNavyCard)
                    .border(1.dp, TreasuryNavyBorder, RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "TODAY'S TRANSACTIONS (RECEIPTS & DISBURSEMENTS)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SovereignGoldBright
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    (state.recentInflows + state.recentOutflows).forEach { item ->
                        val isInflow = item.direction == CashFlowDirection.INFLOW
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(0.5.dp, TreasuryNavyBorderSubtle, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    imageVector = if (isInflow) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                    contentDescription = null,
                                    tint = if (isInflow) TreasuryGreenBright else StressRed,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = item.category,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "${item.subcategory} (${item.sourceAgency})",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.sp,
                                        color = TextMuted
                                    )
                                }
                            }
                            Text(
                                text = "${if (isInflow) "+" else "-"}$${String.format(Locale.US, "%.1fB", item.amountBillions)}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isInflow) TreasuryGreenBright else StressRed
                            )
                        }
                    }
                }
            }
        }
    }
}
