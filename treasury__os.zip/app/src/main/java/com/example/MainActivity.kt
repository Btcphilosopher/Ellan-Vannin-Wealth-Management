package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.TreasuryViewModel
import com.example.ui.components.TerminalTab
import com.example.ui.components.TerminalTabBar
import com.example.ui.components.TerminalTopBar
import com.example.ui.screens.*
import com.example.ui.theme.TreasuryNavyDark
import com.example.ui.theme.TreasuryOSTheme

class MainActivity : ComponentActivity() {
    private val viewModel: TreasuryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TreasuryOSTheme {
                TreasuryApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun TreasuryApp(
    viewModel: TreasuryViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()

    // Support back press navigation to Executive home tab
    if (selectedTab != TerminalTab.EXECUTIVE) {
        BackHandler {
            viewModel.selectTab(TerminalTab.EXECUTIVE)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TreasuryNavyDark,
        topBar = {
            Column(modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)) {
                TerminalTopBar(
                    operatingPhase = state.operatingPhase,
                    tgaBalanceBillions = state.tgaAccount.closingBalanceBillions,
                    debtOutstandingTrillions = state.portfolioMetrics.totalDebtOutstandingTrillions,
                    onAdvancePhase = { viewModel.advanceOperatingDayPhase() }
                )
                TerminalTabBar(
                    selectedTab = selectedTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )
            }
        },
        bottomBar = {
            Spacer(modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars))
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(TreasuryNavyDark)
        ) {
            when (selectedTab) {
                TerminalTab.EXECUTIVE -> ExecutiveControlRoomScreen(
                    state = state,
                    onNavigateTab = { viewModel.selectTab(it) },
                    onApplyScenario = { viewModel.applyScenario(it) }
                )
                TerminalTab.TGA_CASH -> TgaAndCashScreen(
                    state = state
                )
                TerminalTab.DEBT_SECURITIES -> DebtAndSecuritiesScreen(
                    state = state
                )
                TerminalTab.AUCTION_DESK -> AuctionDeskScreen(
                    state = state,
                    onRunAuctionSim = { off, wi, cov, dlr, fgn ->
                        viewModel.runAuctionSimulation(off, wi, cov, dlr, fgn)
                    }
                )
                TerminalTab.REFUNDING -> RefundingAndOptimizerScreen(
                    state = state,
                    onSelectRefundingIndex = { viewModel.selectRefundingIndex(it) },
                    onExecuteBuyback = { type, amt, range ->
                        viewModel.executeBuyback(type, amt, range)
                    }
                )
                TerminalTab.YIELD_MARKET -> YieldAndMarketScreen(
                    state = state
                )
                TerminalTab.VAULT_CUSTODY -> VaultAndCustodyScreen(
                    state = state
                )
                TerminalTab.RISK_SCENARIOS -> RiskAndMonteCarloScreen(
                    state = state,
                    onApplyScenario = { viewModel.applyScenario(it) }
                )
                TerminalTab.AI_TERMINAL -> AiAndTerminalScreen(
                    state = state,
                    onExecuteCommand = { viewModel.executeTerminalCommand(it) },
                    onAskAi = { viewModel.askAi(it) }
                )
                TerminalTab.REPORTS_AUDIT -> ReportsAndAuditScreen(
                    state = state
                )
            }
        }
    }
}
