package com.example.domain.engine

import com.example.domain.model.ShipmentManifest
import com.example.domain.model.VaultAsset
import com.example.domain.model.VaultAssetCategory

object VaultCustodyEngine {

    /**
     * Returns the synthetic institutional vault inventory records.
     */
    fun getVaultInventory(): List<VaultAsset> {
        return listOf(
            VaultAsset(
                assetId = "GLD-US-001",
                category = VaultAssetCategory.GOLD_DEEP_STORAGE,
                serialNumber = "US-BULLION-KY-4820",
                quantityOrWeight = 147341858.38, // Fine Troy Oz
                purityPct = 99.95,
                location = "Synthetic Depository Alpha (Fort Knox)",
                custodian = "U.S. Mint Police / Custodial Division",
                statutoryBookValueBillions = 6.22, // Statutory book price $42.2222/oz
                estimatedMarketValueBillions = 398.5, // Market valuation ~$2,700/oz
                auditStatus = "ANNUAL AUDIT SEALED & VERIFIED",
                lastReconciliationDate = "2026-09-30"
            ),
            VaultAsset(
                assetId = "GLD-US-002",
                category = VaultAssetCategory.GOLD_DEEP_STORAGE,
                serialNumber = "US-BULLION-NY-1904",
                quantityOrWeight = 54067331.40,
                purityPct = 99.95,
                location = "Synthetic West Point Depository",
                custodian = "U.S. Mint Custodial Operations",
                statutoryBookValueBillions = 2.28,
                estimatedMarketValueBillions = 146.2,
                auditStatus = "JOINT COMMITTEE VERIFIED",
                lastReconciliationDate = "2026-09-30"
            ),
            VaultAsset(
                assetId = "GLD-US-003",
                category = VaultAssetCategory.GOLD_DEEP_STORAGE,
                serialNumber = "US-BULLION-CO-0782",
                quantityOrWeight = 43853015.00,
                purityPct = 99.95,
                location = "Synthetic Denver Mint Vault",
                custodian = "U.S. Mint Custodial Operations",
                statutoryBookValueBillions = 1.85,
                estimatedMarketValueBillions = 118.4,
                auditStatus = "VERIFIED",
                lastReconciliationDate = "2026-09-30"
            ),
            VaultAsset(
                assetId = "GLD-US-004",
                category = VaultAssetCategory.GOLD_WORKING_STOCK,
                serialNumber = "US-BULLION-WS-9912",
                quantityOrWeight = 2783540.00,
                purityPct = 99.99,
                location = "Working Stock Mint Facility",
                custodian = "U.S. Mint Coinage Division",
                statutoryBookValueBillions = 0.12,
                estimatedMarketValueBillions = 7.5,
                auditStatus = "ACTIVE RECONCILIATION",
                lastReconciliationDate = "2026-10-04"
            ),
            VaultAsset(
                assetId = "SLV-US-001",
                category = VaultAssetCategory.SILVER_BULLION,
                serialNumber = "US-SLV-WP-8841",
                quantityOrWeight = 16000000.0,
                purityPct = 99.90,
                location = "Synthetic West Point Bullion Vault",
                custodian = "U.S. Mint Custodial Division",
                statutoryBookValueBillions = 0.02,
                estimatedMarketValueBillions = 0.51,
                auditStatus = "VERIFIED",
                lastReconciliationDate = "2026-09-30"
            ),
            VaultAsset(
                assetId = "FRN-CUR-001",
                category = VaultAssetCategory.CURRENCY_FRN,
                serialNumber = "BEP-BATCH-2026-A100",
                quantityOrWeight = 185000000.0, // Notes count
                purityPct = 100.0,
                location = "Bureau of Engraving and Printing Vault",
                custodian = "Federal Reserve / BEP Custody",
                statutoryBookValueBillions = 18.5,
                estimatedMarketValueBillions = 18.5,
                auditStatus = "SECURITY SERIALIZED",
                lastReconciliationDate = "2026-10-04"
            )
        )
    }

    fun getShipmentManifests(): List<ShipmentManifest> {
        return listOf(
            ShipmentManifest(
                manifestId = "SHP-2026-1004-91",
                originFacility = "BEP Washington Facility",
                destinationDepository = "Federal Reserve Bank of New York Cash Depot",
                assetDescription = "$100 Series 2026 Federal Reserve Notes ($2.4B Face Value)",
                totalValueBillions = 2.4,
                transitStatus = "RECEIVED & RECONCILED",
                escortAuthority = "Federal Reserve Police High-Security Convoy",
                timestamp = "2026-10-04 14:30 EST"
            ),
            ShipmentManifest(
                manifestId = "SHP-2026-1005-02",
                originFacility = "BEP Western Currency Facility (Fort Worth)",
                destinationDepository = "Federal Reserve Bank of Dallas Depository",
                assetDescription = "$50 & $20 Notes Inventory ($850M Face Value)",
                totalValueBillions = 0.85,
                transitStatus = "IN_TRANSIT",
                escortAuthority = "Armored Transport Escort Detachment",
                timestamp = "2026-10-05 08:15 EST"
            )
        )
    }
}
