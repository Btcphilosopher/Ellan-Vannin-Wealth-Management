package com.example.domain.engine

import com.example.domain.model.SecurityLifecycleStatus
import com.example.domain.model.SecurityType
import com.example.domain.model.TreasurySecurity
import kotlin.math.pow

data class MaturityBucket(
    val year: Int,
    val totalMaturingBillions: Double,
    val principalBillions: Double,
    val interestCouponBillions: Double,
    val billsMaturingBillions: Double,
    val notesMaturingBillions: Double,
    val bondsMaturingBillions: Double,
    val tipsMaturingBillions: Double,
    val frnMaturingBillions: Double,
    val countSecurities: Int,
    val avgCouponPct: Double
)

data class PortfolioMetrics(
    val totalDebtOutstandingTrillions: Double,
    val marketableDebtTrillions: Double,
    val nonMarketableDebtTrillions: Double,
    val weightedAverageMaturityYears: Double,
    val weightedAverageCouponPct: Double,
    val modifiedDurationYears: Double,
    val portfolioConvexity: Double,
    val annualGrossInterestExpenseBillions: Double,
    val billsSharePct: Double,
    val notesSharePct: Double,
    val bondsSharePct: Double,
    val tipsSharePct: Double,
    val frnSharePct: Double
)

object DebtManagementEngine {

    /**
     * Aggregates portfolio debt metrics from individual active securities.
     */
    fun calculatePortfolioMetrics(securities: List<TreasurySecurity>): PortfolioMetrics {
        val activeSecurities = securities.filter { it.status == SecurityLifecycleStatus.OUTSTANDING || it.status == SecurityLifecycleStatus.COUPON_ACTIVE }
        val totalOutstanding = activeSecurities.sumOf { it.outstandingBillions }
        
        val marketable = activeSecurities.filter { it.isMarketable }.sumOf { it.outstandingBillions }
        val nonMarketable = activeSecurities.filter { !it.isMarketable }.sumOf { it.outstandingBillions }
        
        var weightedMaturitySum = 0.0
        var weightedCouponSum = 0.0
        var weightedDurationSum = 0.0
        var weightedConvexitySum = 0.0
        var annualInterestSum = 0.0

        var billsTotal = 0.0
        var notesTotal = 0.0
        var bondsTotal = 0.0
        var tipsTotal = 0.0
        var frnTotal = 0.0

        for (sec in activeSecurities) {
            val weight = if (totalOutstanding > 0) sec.outstandingBillions / totalOutstanding else 0.0
            
            // Approximate maturity years
            val maturityYears = when (sec.type) {
                SecurityType.BILL_4W -> 0.08
                SecurityType.BILL_8W -> 0.15
                SecurityType.BILL_13W -> 0.25
                SecurityType.BILL_17W -> 0.33
                SecurityType.BILL_26W -> 0.50
                SecurityType.BILL_52W -> 1.00
                SecurityType.CMB -> 0.12
                SecurityType.NOTE_2Y -> 1.8
                SecurityType.NOTE_3Y -> 2.6
                SecurityType.NOTE_5Y -> 4.2
                SecurityType.NOTE_7Y -> 5.8
                SecurityType.NOTE_10Y -> 8.4
                SecurityType.BOND_20Y -> 16.5
                SecurityType.BOND_30Y -> 24.2
                SecurityType.TIPS_5Y -> 3.9
                SecurityType.TIPS_10Y -> 8.1
                SecurityType.TIPS_30Y -> 22.0
                SecurityType.FRN_2Y -> 1.4
                SecurityType.GAS_ACCOUNT -> 5.0
                SecurityType.SAVINGS_BOND -> 12.0
            }

            weightedMaturitySum += maturityYears * weight
            weightedCouponSum += sec.couponRatePct * weight
            weightedDurationSum += sec.modifiedDurationYears * weight
            weightedConvexitySum += sec.convexity * weight
            
            val secInterest = if (sec.type.category == "TIPS") {
                sec.outstandingBillions * (sec.couponRatePct / 100.0) * sec.inflationIndexRatio
            } else {
                sec.outstandingBillions * (sec.couponRatePct / 100.0)
            }
            annualInterestSum += secInterest

            when (sec.type.category) {
                "Bills" -> billsTotal += sec.outstandingBillions
                "CMBs" -> billsTotal += sec.outstandingBillions
                "Notes" -> notesTotal += sec.outstandingBillions
                "Bonds" -> bondsTotal += sec.outstandingBillions
                "TIPS" -> tipsTotal += sec.outstandingBillions
                "FRNs" -> frnTotal += sec.outstandingBillions
            }
        }

        val totalTrillions = totalOutstanding / 1000.0

        return PortfolioMetrics(
            totalDebtOutstandingTrillions = totalTrillions,
            marketableDebtTrillions = marketable / 1000.0,
            nonMarketableDebtTrillions = nonMarketable / 1000.0,
            weightedAverageMaturityYears = weightedMaturitySum,
            weightedAverageCouponPct = weightedCouponSum,
            modifiedDurationYears = weightedDurationSum,
            portfolioConvexity = weightedConvexitySum,
            annualGrossInterestExpenseBillions = annualInterestSum,
            billsSharePct = if (marketable > 0) (billsTotal / marketable) * 100.0 else 0.0,
            notesSharePct = if (marketable > 0) (notesTotal / marketable) * 100.0 else 0.0,
            bondsSharePct = if (marketable > 0) (bondsTotal / marketable) * 100.0 else 0.0,
            tipsSharePct = if (marketable > 0) (tipsTotal / marketable) * 100.0 else 0.0,
            frnSharePct = if (marketable > 0) (frnTotal / marketable) * 100.0 else 0.0
        )
    }

    /**
     * Builds the 30-year Debt Maturity Wall (2026 to 2056) showing annual rollover walls.
     */
    fun buildMaturityWall(): List<MaturityBucket> {
        val currentYear = 2026
        val baselineData = mapOf(
            2026 to (3120.0 to 980.0), // High bill & short note concentration
            2027 to (2680.0 to 890.0),
            2028 to (2150.0 to 760.0),
            2029 to (1790.0 to 650.0),
            2030 to (1540.0 to 580.0),
            2031 to (1320.0 to 490.0),
            2032 to (1180.0 to 420.0),
            2033 to (980.0 to 380.0),
            2034 to (920.0 to 350.0),
            2035 to (860.0 to 310.0),
            2036 to (790.0 to 290.0),
            2040 to (620.0 to 220.0),
            2045 to (540.0 to 180.0),
            2050 to (480.0 to 140.0),
            2055 to (420.0 to 110.0),
            2056 to (390.0 to 95.0)
        )

        val result = mutableListOf<MaturityBucket>()
        for (year in currentYear..2056) {
            val (basePrincipal, baseInterest) = baselineData[year] ?: run {
                val decay = (0.92).pow((year - 2036).coerceAtLeast(0))
                (650.0 * decay) to (240.0 * decay)
            }

            val bills = if (year == 2026) basePrincipal * 0.45 else if (year == 2027) basePrincipal * 0.10 else 0.0
            val notes = if (year <= 2036) (basePrincipal - bills) * 0.70 else basePrincipal * 0.15
            val bonds = if (year > 2036) (basePrincipal - bills) * 0.75 else (basePrincipal - bills) * 0.15
            val tips = (basePrincipal - bills) * 0.10
            val frn = if (year <= 2028) (basePrincipal - bills) * 0.05 else 0.0

            result.add(
                MaturityBucket(
                    year = year,
                    totalMaturingBillions = basePrincipal + baseInterest,
                    principalBillions = basePrincipal,
                    interestCouponBillions = baseInterest,
                    billsMaturingBillions = bills,
                    notesMaturingBillions = notes,
                    bondsMaturingBillions = bonds,
                    tipsMaturingBillions = tips,
                    frnMaturingBillions = frn,
                    countSecurities = if (year <= 2028) 48 else 22,
                    avgCouponPct = 3.65 + (year - 2026) * 0.03
                )
            )
        }
        return result
    }

    /**
     * Compares "Refinance Now" vs "Refinance Later (Roll short bills)" under forward curve scenario.
     */
    fun calculateRefinanceComparison(
        maturingAmountBillions: Double = 100.0,
        currentFixedRatePct: Double = 4.25,
        expectedFutureRatePct: Double = 3.65,
        tenorYears: Int = 10
    ): Pair<Double, Double> {
        val costFixedNow = maturingAmountBillions * (currentFixedRatePct / 100.0) * tenorYears
        val costRollThenFix = (maturingAmountBillions * (4.80 / 100.0) * 1.0) + (maturingAmountBillions * (expectedFutureRatePct / 100.0) * (tenorYears - 1))
        return Pair(costFixedNow, costRollThenFix)
    }
}
