package com.example.domain.engine

import com.example.domain.model.MonteCarloMetrics
import java.util.Random

object MonteCarloEngine {

    /**
     * Executes 10,000 Monte Carlo paths over future 1-year horizon:
     * Stochastically varies:
     * 1. Short-term and long-term interest rates (Vasicek / Hull-White mean-reverting process)
     * 2. Tax revenue shocks (normal with fat tails)
     * 3. Emergency spending draws
     * 4. Auction demand elasticity
     */
    fun runSimulation(
        iterations: Int = 10000,
        baseDebtTrillions: Double = 35.8,
        baseInterestBillions: Double = 1050.0,
        currentTgaBillions: Double = 750.0,
        macroStressOffset: Double = 0.0
    ): MonteCarloMetrics {
        val random = Random(1337L)
        val interestResults = DoubleArray(iterations)
        var shortfallCount = 0
        val borrowingResults = DoubleArray(iterations)

        for (i in 0 until iterations) {
            // Rate shock sampled from Gaussian
            val rateShock: Double = (random.nextGaussian() * 0.65) + (macroStressOffset * 1.5) // in %
            val receiptShockPct: Double = (random.nextGaussian() * 0.06) - (macroStressOffset * 0.08)
            val spendingDrawBillions: Double = random.nextDouble() * 40.0

            // Interest expense impact on floating and maturing debt (~$9.2T rolls in 1 yr)
            val floatingDebtBillions = 9200.0
            val deltaInterest: Double = (floatingDebtBillions * (rateShock / 100.0)).coerceAtLeast(-250.0)
            val simulatedInterest: Double = baseInterestBillions + deltaInterest
            interestResults[i] = simulatedInterest

            // Cash balance path
            val baselineNetFiscal = -1850.0 // Annual fiscal deficit
            val simulatedDeficit: Double = (baselineNetFiscal * (1.0 - receiptShockPct)) - spendingDrawBillions
            val netBorrowingNeed: Double = -simulatedDeficit + deltaInterest
            borrowingResults[i] = netBorrowingNeed

            // Check if TGA dipped below minimum operational buffer ($300B) without extra borrowing
            val unfinancedTga: Double = currentTgaBillions + simulatedDeficit
            if (unfinancedTga < 300.0) {
                shortfallCount++
            }
        }

        interestResults.sort()
        val meanInterest = interestResults.average()
        val p95Interest = interestResults[(iterations * 0.95).toInt()]
        val p99Interest = interestResults[(iterations * 0.99).toInt()]
        val probShortfallPct = (shortfallCount.toDouble() / iterations.toDouble()) * 100.0
        val meanBorrowingTrillions = borrowingResults.average() / 1000.0

        // Create 12 histogram bins
        val minVal = interestResults.first()
        val maxVal = interestResults.last()
        val binWidth = (maxVal - minVal) / 12.0
        val bins = mutableListOf<Pair<Double, Int>>()
        
        for (b in 0 until 12) {
            val binStart = minVal + b * binWidth
            val binEnd = binStart + binWidth
            val count = interestResults.count { it in binStart..binEnd }
            bins.add(Pair(binStart + (binWidth / 2.0), count))
        }

        return MonteCarloMetrics(
            simulationsRun = iterations,
            meanInterestCostBillions = meanInterest,
            p95InterestCostBillions = p95Interest,
            p99InterestCostBillions = p99Interest,
            probCashShortfallPct = probShortfallPct,
            expectedBorrowingRequirementTrillions = meanBorrowingTrillions,
            distributionBins = bins
        )
    }
}
