package com.example.domain.engine

import com.example.domain.model.RefundingMixProposal

object RefundingOptimizer {

    /**
     * Solves for the optimal quarterly refunding issuance schedule based on TBAC
     * (Treasury Borrowing Advisory Committee) guidelines and objectives:
     * 1. Regular and predictable issuance
     * 2. Lowest borrowing cost over time
     * 3. Minimizing rollover / refinancing cliff risk
     * 4. Maintaining benchmark liquidity across the curve
     */
    fun computeRefundingScenarios(
        grossFinancingRequirementBillions: Double = 840.0,
        targetTgaBufferBillions: Double = 750.0,
        currentBillsSharePct: Double = 22.4
    ): List<RefundingMixProposal> {
        // 1. TBAC Recommended Baseline Mix (Balanced)
        val baseline = RefundingMixProposal(
            quarterLabel = "Q4 Baseline (TBAC Recommended)",
            billsIssuanceBillions = 185.0,
            note2YBillions = 135.0,
            note3YBillions = 120.0,
            note5YBillions = 140.0,
            note7YBillions = 90.0,
            note10YBillions = 84.0,
            bond20YBillions = 32.0,
            bond30YBillions = 48.0,
            tipsIssuanceBillions = 42.0,
            frnIssuanceBillions = 24.0,
            cmbReserveBillions = 30.0,
            totalIssuanceBillions = 890.0,
            weightedFundingCostPct = 4.18,
            weightedAvgMaturityYears = 6.4,
            rolloverRiskScore = 32.0,
            liquidityScore = 94.0
        )

        // 2. Bill-Heavy Strategy (Lowest Initial Cost, High Rollover Risk)
        val billHeavy = RefundingMixProposal(
            quarterLabel = "Front-End Heavy (Bill Focus)",
            billsIssuanceBillions = 310.0,
            note2YBillions = 160.0,
            note3YBillions = 110.0,
            note5YBillions = 100.0,
            note7YBillions = 60.0,
            note10YBillions = 60.0,
            bond20YBillions = 18.0,
            bond30YBillions = 26.0,
            tipsIssuanceBillions = 26.0,
            frnIssuanceBillions = 30.0,
            cmbReserveBillions = 50.0,
            totalIssuanceBillions = 890.0,
            weightedFundingCostPct = 3.92,
            weightedAvgMaturityYears = 4.1,
            rolloverRiskScore = 68.0,
            liquidityScore = 88.0
        )

        // 3. Long-Duration Strategy (Maximum Rollover Protection, Higher Term Premium)
        val longDuration = RefundingMixProposal(
            quarterLabel = "Long Duration (Lock-in Term)",
            billsIssuanceBillions = 110.0,
            note2YBillions = 90.0,
            note3YBillions = 95.0,
            note5YBillions = 130.0,
            note7YBillions = 115.0,
            note10YBillions = 135.0,
            bond20YBillions = 65.0,
            bond30YBillions = 90.0,
            tipsIssuanceBillions = 55.0,
            frnIssuanceBillions = 15.0,
            cmbReserveBillions = 10.0,
            totalIssuanceBillions = 890.0,
            weightedFundingCostPct = 4.48,
            weightedAvgMaturityYears = 9.8,
            rolloverRiskScore = 14.0,
            liquidityScore = 91.0
        )

        return listOf(baseline, billHeavy, longDuration)
    }
}
