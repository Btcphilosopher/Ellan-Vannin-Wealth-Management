package com.example.domain.model

import java.text.NumberFormat
import java.util.Locale

// --- SECURITY & DEBT TYPES ---

enum class SecurityType(val label: String, val category: String) {
    BILL_4W("4-Week Bill", "Bills"),
    BILL_8W("8-Week Bill", "Bills"),
    BILL_13W("13-Week Bill", "Bills"),
    BILL_17W("17-Week Bill", "Bills"),
    BILL_26W("26-Week Bill", "Bills"),
    BILL_52W("52-Week Bill", "Bills"),
    CMB("Cash Mgmt Bill", "CMBs"),
    NOTE_2Y("2-Year Note", "Notes"),
    NOTE_3Y("3-Year Note", "Notes"),
    NOTE_5Y("5-Year Note", "Notes"),
    NOTE_7Y("7-Year Note", "Notes"),
    NOTE_10Y("10-Year Note", "Notes"),
    BOND_20Y("20-Year Bond", "Bonds"),
    BOND_30Y("30-Year Bond", "Bonds"),
    TIPS_5Y("5-Year TIPS", "TIPS"),
    TIPS_10Y("10-Year TIPS", "TIPS"),
    TIPS_30Y("30-Year TIPS", "TIPS"),
    FRN_2Y("2-Year FRN", "FRNs"),
    GAS_ACCOUNT("Govt Account Series", "Non-Marketable"),
    SAVINGS_BOND("U.S. Savings Bond", "Non-Marketable")
}

enum class SecurityLifecycleStatus(val label: String) {
    DESIGN("Design"),
    ANNOUNCED("Announced"),
    AUCTIONED("Auctioned"),
    ALLOTTED("Allotted"),
    ISSUED("Issued"),
    SETTLED("Settled"),
    OUTSTANDING("Outstanding"),
    COUPON_ACTIVE("Coupon Active"),
    REOPENED("Reopened"),
    BUYBACK_TARGETED("Buyback Target"),
    MATURING("Maturing"),
    REDEEMED("Redeemed"),
    RETIRED("Retired")
}

data class TreasurySecurity(
    val cusip: String,
    val type: SecurityType,
    val termDescription: String,
    val issueDate: String,
    val maturityDate: String,
    val couponRatePct: Double,
    val parAmountBillions: Double,
    val outstandingBillions: Double,
    val inflationIndexRatio: Double = 1.0, // For TIPS (Current Ref CPI / Base CPI)
    val spreadBasisPoints: Double = 0.0, // For FRNs (Spread over 13W T-Bill index)
    val currentYieldPct: Double,
    val modifiedDurationYears: Double,
    val convexity: Double,
    val status: SecurityLifecycleStatus = SecurityLifecycleStatus.OUTSTANDING,
    val isMarketable: Boolean = true,
    val beneficialOwnerCategory: String = "Public / Institutional"
) {
    val formattedPar: String get() = String.format(Locale.US, "$%.2fB", parAmountBillions)
    val formattedOutstanding: String get() = String.format(Locale.US, "$%.2fB", outstandingBillions)
    val formattedCoupon: String get() = if (couponRatePct == 0.0) "Zero Coupon" else String.format(Locale.US, "%.3f%%", couponRatePct)
    val formattedYield: String get() = String.format(Locale.US, "%.3f%%", currentYieldPct)
}

// --- TGA & CASH FORECAST ---

data class TreasuryCashAccount(
    val accountId: String = "TGA-001-CENTRAL",
    val date: String,
    val openingBalanceBillions: Double,
    val taxReceiptsBillions: Double,
    val otherReceiptsBillions: Double,
    val debtIssuanceInflowBillions: Double,
    val governmentPaymentsBillions: Double,
    val debtMaturitiesOutflowBillions: Double,
    val interestPaymentsOutflowBillions: Double,
    val otherOutflowsBillions: Double,
    val closingBalanceBillions: Double,
    val targetBalanceBillions: Double = 750.0,
    val minOperationalBufferBillions: Double = 500.0,
    val stressBufferBillions: Double = 850.0,
    val fedReserveDrainImpactBillions: Double
) {
    val totalInflows: Double get() = taxReceiptsBillions + otherReceiptsBillions + debtIssuanceInflowBillions
    val totalOutflows: Double get() = governmentPaymentsBillions + debtMaturitiesOutflowBillions + interestPaymentsOutflowBillions + otherOutflowsBillions
    val netDailyCashFlow: Double get() = totalInflows - totalOutflows
    
    // Invariant check
    val isLedgerBalanced: Boolean
        get() = kotlin.math.abs((openingBalanceBillions + totalInflows - totalOutflows) - closingBalanceBillions) < 0.001
}

enum class CashFlowDirection { INFLOW, OUTFLOW }

data class CashFlowItem(
    val id: String,
    val date: String,
    val category: String,
    val subcategory: String,
    val amountBillions: Double,
    val direction: CashFlowDirection,
    val confidencePct: Double,
    val sourceAgency: String,
    val isForecast: Boolean = false,
    val varianceFromActualPct: Double = 0.0
)

data class HorizonForecast(
    val horizonLabel: String, // 1D, 7D, 14D, 30D, 60D, 90D, 1Y
    val daysOut: Int,
    val projectedInflowsBillions: Double,
    val projectedOutflowsBillions: Double,
    val netFlowBillions: Double,
    val projectedTgaEndingBillions: Double,
    val confidenceLowBillions: Double,
    val confidenceHighBillions: Double,
    val financingRequirementBillions: Double
)

// --- AUCTION & BIDDING ---

enum class BidderCategory(val label: String) {
    PRIMARY_DEALER("Primary Dealers"),
    DIRECT_BIDDER("Direct Bidders"),
    INDIRECT_FOREIGN("Indirect (Foreign Central Banks/Institutions)"),
    MMF_ASSET_MGR("MMFs & Asset Managers")
}

data class CompetitiveBid(
    val bidId: String,
    val bidderId: String,
    val bidderName: String,
    val category: BidderCategory,
    val yieldOrRatePct: Double,
    val bidAmountBillions: Double,
    val isAccepted: Boolean = false,
    val allocatedAmountBillions: Double = 0.0,
    val allocationPercentage: Double = 0.0
)

data class NonCompetitiveBid(
    val bidId: String,
    val bidderName: String,
    val amountBillions: Double,
    val isAllocated: Boolean = true
)

data class AuctionRecord(
    val auctionId: String,
    val cusip: String,
    val securityType: SecurityType,
    val securityName: String,
    val offeringAmountBillions: Double,
    val totalBidsReceivedBillions: Double,
    val nonCompetitiveAwardedBillions: Double,
    val competitiveAwardedBillions: Double,
    val stopOutYieldPct: Double,
    val highYieldPct: Double,
    val lowYieldPct: Double,
    val medianYieldPct: Double,
    val tailBasisPoints: Double, // Stop out minus WI Yield
    val bidToCoverRatio: Double,
    val primaryDealerPct: Double,
    val directBidderPct: Double,
    val indirectForeignPct: Double,
    val announcementDate: String,
    val auctionDate: String,
    val settlementDate: String,
    val maturityDate: String,
    val reopening: Boolean = false,
    val bids: List<CompetitiveBid> = emptyList(),
    val status: String = "SETTLED"
) {
    val totalAwarded: Double get() = nonCompetitiveAwardedBillions + competitiveAwardedBillions
}

// --- REFUNDING, BORROWING & BUYBACKS ---

data class FinancingRequirement(
    val period: String,
    val fiscalDeficitBillions: Double,
    val debtMaturitiesBillions: Double,
    val otherCashNeedsBillions: Double,
    val beginningTgaCashBillions: Double,
    val desiredEndingTgaCashBillions: Double,
    val netMarketableBorrowingRequirementBillions: Double,
    val grossIssuanceRequiredBillions: Double
)

data class RefundingMixProposal(
    val quarterLabel: String,
    val billsIssuanceBillions: Double,
    val note2YBillions: Double,
    val note3YBillions: Double,
    val note5YBillions: Double,
    val note7YBillions: Double,
    val note10YBillions: Double,
    val bond20YBillions: Double,
    val bond30YBillions: Double,
    val tipsIssuanceBillions: Double,
    val frnIssuanceBillions: Double,
    val cmbReserveBillions: Double,
    val totalIssuanceBillions: Double,
    val weightedFundingCostPct: Double,
    val weightedAvgMaturityYears: Double,
    val rolloverRiskScore: Double, // 0 (low) to 100 (high)
    val liquidityScore: Double
)

enum class BuybackType(val label: String) {
    LIQUIDITY_SUPPORT("Liquidity-Support Buyback"),
    CASH_MANAGEMENT("Cash-Management Buyback")
}

data class BuybackOperation(
    val operationId: String,
    val type: BuybackType,
    val announcementDate: String,
    val executionDate: String,
    val maxParAmountBillions: Double,
    val tenderedAmountBillions: Double,
    val acceptedAmountBillions: Double,
    val weightedPurchasePrice: Double,
    val averageYieldPct: Double,
    val totalCashDisbursedBillions: Double,
    val targetMaturityRange: String,
    val debtOutstandingReductionBillions: Double
)

// --- YIELD CURVE & MARKET ---

data class YieldCurvePoint(
    val tenorLabel: String,
    val tenorYears: Double,
    val parYieldPct: Double,
    val zeroRatePct: Double,
    val forwardRatePct: Double,
    val discountFactor: Double,
    val whenIssuedYieldPct: Double,
    val wiSpreadBasisPoints: Double
)

data class RepoMarketLink(
    val sofrRatePct: Double,
    val repoOvernightRatePct: Double,
    val specialnessBasisPoints: Double,
    val primaryDealerInventoryBillions: Double,
    val fciConditions: String = "Neutral",
    val foreignHoldingSharePct: Double = 23.4
)

// --- VAULT & CUSTODY ---

enum class VaultAssetCategory(val label: String, val unit: String) {
    GOLD_DEEP_STORAGE("Deep Storage Gold Bullion", "Fine Troy Oz"),
    GOLD_WORKING_STOCK("Working Stock Gold", "Fine Troy Oz"),
    SILVER_BULLION("Silver Bullion Reserve", "Fine Troy Oz"),
    COIN_RESERVE("Uncirculated Coin Reserve", "Face Value ($)"),
    CURRENCY_FRN("Federal Reserve Notes Inventory", "Face Value ($)"),
    BOOK_ENTRY_GOVT_HOLDINGS("Government Account Series Holdings", "Par Value ($)")
}

data class VaultAsset(
    val assetId: String,
    val category: VaultAssetCategory,
    val serialNumber: String,
    val quantityOrWeight: Double,
    val purityPct: Double,
    val location: String, // Synthetic location
    val custodian: String,
    val statutoryBookValueBillions: Double,
    val estimatedMarketValueBillions: Double,
    val auditStatus: String = "VERIFIED",
    val lastReconciliationDate: String
)

data class ShipmentManifest(
    val manifestId: String,
    val originFacility: String,
    val destinationDepository: String,
    val assetDescription: String,
    val totalValueBillions: Double,
    val transitStatus: String, // PREPARED, DISPATCHED, IN_TRANSIT, RECEIVED, RECONCILED
    val escortAuthority: String,
    val timestamp: String
)

// --- MACRO RISK & SCENARIOS ---

enum class StressScenario(val title: String, val description: String) {
    BASELINE("Baseline Projection", "Scheduled issuance and regular fiscal seasonal flows"),
    TAX_RECEIPT_SHOCK("Tax Receipt Shock (-15%)", "Unexpected revenue shortfall requiring emergency CMB issuance"),
    RATES_PLUS_200BP("Interest Rate Spike (+200bp)", "Rapid monetary tightening increasing borrowing & rollover costs"),
    RATES_MINUS_100BP("Yield Curve Bull Steepening (-100bp)", "Lower refinancing costs with increased bill demand"),
    DEFENSE_EMERGENCY("War/Defense Spending Surge", "Supplemental appropriations of +$150B across 90 days"),
    GOVERNMENT_SHUTDOWN("Statutory Shutdown Scenario", "Discretionary spending frozen, tax collections delayed"),
    DEBT_CEILING_PINCH("Statutory Debt Limit Pinch", "Extraordinary measures active, TGA drawn down to critical limits")
}

data class MonteCarloMetrics(
    val simulationsRun: Int = 10000,
    val meanInterestCostBillions: Double,
    val p95InterestCostBillions: Double,
    val p99InterestCostBillions: Double,
    val probCashShortfallPct: Double,
    val expectedBorrowingRequirementTrillions: Double,
    val distributionBins: List<Pair<Double, Int>> = emptyList()
)

// --- AUDIT & EVENT SOURCING ---

data class TreasuryEvent(
    val eventId: String,
    val eventType: String,
    val timestamp: String,
    val summary: String,
    val impactAmountBillions: Double?,
    val actor: String,
    val verifiedHash: String
)

data class ModelCard(
    val modelId: String,
    val name: String,
    val version: String,
    val purpose: String,
    val methodology: String,
    val keyInputs: String,
    val limitations: String,
    val governanceStatus: String = "APPROVED / VALIDATED"
)

// Helper formatting utilities
object NumberFormatters {
    fun formatBillions(amount: Double): String {
        return if (kotlin.math.abs(amount) >= 1000.0) {
            String.format(Locale.US, "$%.2fT", amount / 1000.0)
        } else {
            String.format(Locale.US, "$%.1fB", amount)
        }
    }
    
    fun formatSignedBillions(amount: Double): String {
        val sign = if (amount > 0) "+" else ""
        return if (kotlin.math.abs(amount) >= 1000.0) {
            String.format(Locale.US, "%s$%.2fT", sign, amount / 1000.0)
        } else {
            String.format(Locale.US, "%s$%.1fB", sign, amount)
        }
    }

    fun formatPct(pct: Double): String {
        return String.format(Locale.US, "%.2f%%", pct)
    }

    fun formatBp(bp: Double): String {
        return String.format(Locale.US, "%.1f bp", bp)
    }
}
