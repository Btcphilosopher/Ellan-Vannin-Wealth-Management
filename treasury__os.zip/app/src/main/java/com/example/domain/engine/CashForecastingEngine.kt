package com.example.domain.engine

import com.example.domain.model.HorizonForecast
import java.util.Locale
import kotlin.math.sqrt

object CashForecastingEngine {

    /**
     * Generates institutional multi-horizon cash forecasts (1D, 7D, 14D, 30D, 60D, 90D, 1Y).
     * Incorporates tax receipt seasonality, mandatory entitlement payment waves, and debt service.
     */
    fun generateHorizonForecasts(
        currentTgaBalanceBillions: Double,
        macroStressFactor: Double = 1.0, // 1.0 = normal baseline, 0.85 = tax shock, 1.15 = expansion
        rateShockBp: Double = 0.0
    ): List<HorizonForecast> {
        val horizons = listOf(
            Triple("1 Day", 1, 14.5 to 16.8),
            Triple("7 Days", 7, 98.0 to 112.4),
            Triple("14 Days", 14, 195.0 to 228.0),
            Triple("30 Days", 30, 410.0 to 485.0),
            Triple("60 Days", 60, 840.0 to 980.0),
            Triple("90 Days", 90, 1310.0 to 1490.0),
            Triple("1 Year", 365, 5250.0 to 6950.0)
        )

        val targetTga = 750.0

        return horizons.map { (label, days, baseInflowsOutflows) ->
            val (baseInflow, baseOutflow) = baseInflowsOutflows
            
            // Adjust inflows for macro receipts stress
            val projectedInflows = baseInflow * macroStressFactor
            
            // Adjust outflows for interest rate shock on floating & rolling debt
            val rateImpact = (rateShockBp / 10000.0) * (days / 365.0) * 8500.0 // Debt subject to reset
            val projectedOutflows = baseOutflow + rateImpact
            
            val netFlow = projectedInflows - projectedOutflows
            val projectedEndingTga = currentTgaBalanceBillions + netFlow
            
            // Standard error expands with square root of time
            val dailyVolatility = 4.2 // $4.2B daily standard deviation
            val horizonStdDev = dailyVolatility * sqrt(days.toDouble())
            
            val confidenceLow = projectedEndingTga - (1.96 * horizonStdDev)
            val confidenceHigh = projectedEndingTga + (1.96 * horizonStdDev)
            
            val financingRequired = if (projectedEndingTga < targetTga) {
                targetTga - projectedEndingTga
            } else {
                0.0
            }

            HorizonForecast(
                horizonLabel = label,
                daysOut = days,
                projectedInflowsBillions = projectedInflows,
                projectedOutflowsBillions = projectedOutflows,
                netFlowBillions = netFlow,
                projectedTgaEndingBillions = projectedEndingTga,
                confidenceLowBillions = confidenceLow,
                confidenceHighBillions = confidenceHigh,
                financingRequirementBillions = financingRequired
            )
        }
    }
}
