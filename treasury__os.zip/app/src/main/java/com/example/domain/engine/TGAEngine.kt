package com.example.domain.engine

import com.example.domain.model.CashFlowDirection
import com.example.domain.model.CashFlowItem
import com.example.domain.model.TreasuryCashAccount
import java.util.Locale
import kotlin.math.abs

object TGAEngine {

    /**
     * Reconciles daily TGA cash movement and verifies fundamental cash invariant:
     * Opening Balance + Inflows - Outflows = Closing Balance
     */
    fun reconcileDailyCash(
        accountId: String,
        date: String,
        openingBalanceBillions: Double,
        inflows: List<CashFlowItem>,
        outflows: List<CashFlowItem>,
        targetBalanceBillions: Double = 750.0
    ): TreasuryCashAccount {
        val taxReceipts = inflows.filter { 
            it.category.contains("Tax", ignoreCase = true) || it.category.contains("Receipt", ignoreCase = true) 
        }.sumOf { it.amountBillions }
        
        val debtIssuance = inflows.filter { 
            !it.category.contains("Tax", ignoreCase = true) && 
            !it.category.contains("Receipt", ignoreCase = true) &&
            (it.category.contains("Issuance", ignoreCase = true) || it.category.contains("Borrowing", ignoreCase = true)) 
        }.sumOf { it.amountBillions }
        
        val otherReceipts = inflows.filter { 
            !it.category.contains("Tax", ignoreCase = true) && 
            !it.category.contains("Receipt", ignoreCase = true) && 
            !it.category.contains("Issuance", ignoreCase = true) &&
            !it.category.contains("Borrowing", ignoreCase = true)
        }.sumOf { it.amountBillions }

        val govPayments = outflows.filter { 
            it.category.contains("Benefit", ignoreCase = true) || 
            it.category.contains("Payroll", ignoreCase = true) || 
            it.category.contains("Defense", ignoreCase = true) || 
            it.category.contains("Grant", ignoreCase = true) ||
            it.category.contains("Discretionary", ignoreCase = true)
        }.sumOf { it.amountBillions }

        val debtMaturities = outflows.filter { 
            !it.category.contains("Benefit", ignoreCase = true) && 
            !it.category.contains("Payroll", ignoreCase = true) && 
            !it.category.contains("Defense", ignoreCase = true) && 
            !it.category.contains("Grant", ignoreCase = true) &&
            !it.category.contains("Discretionary", ignoreCase = true) &&
            (it.category.contains("Maturit", ignoreCase = true) || it.category.contains("Redemption", ignoreCase = true)) 
        }.sumOf { it.amountBillions }

        val interestPayments = outflows.filter { 
            !it.category.contains("Benefit", ignoreCase = true) && 
            !it.category.contains("Payroll", ignoreCase = true) && 
            !it.category.contains("Defense", ignoreCase = true) && 
            !it.category.contains("Grant", ignoreCase = true) &&
            !it.category.contains("Discretionary", ignoreCase = true) &&
            !it.category.contains("Maturit", ignoreCase = true) && 
            !it.category.contains("Redemption", ignoreCase = true) &&
            (it.category.contains("Interest", ignoreCase = true) || it.category.contains("Coupon", ignoreCase = true)) 
        }.sumOf { it.amountBillions }

        val otherOutflows = outflows.filter {
            !it.category.contains("Benefit", ignoreCase = true) &&
            !it.category.contains("Payroll", ignoreCase = true) &&
            !it.category.contains("Defense", ignoreCase = true) &&
            !it.category.contains("Grant", ignoreCase = true) &&
            !it.category.contains("Discretionary", ignoreCase = true) &&
            !it.category.contains("Maturit", ignoreCase = true) &&
            !it.category.contains("Redemption", ignoreCase = true) &&
            !it.category.contains("Interest", ignoreCase = true) &&
            !it.category.contains("Coupon", ignoreCase = true)
        }.sumOf { it.amountBillions }

        val totalInflows = taxReceipts + otherReceipts + debtIssuance
        val totalOutflows = govPayments + debtMaturities + interestPayments + otherOutflows
        val closingBalance = openingBalanceBillions + totalInflows - totalOutflows

        // When TGA balance increases, commercial bank reserve balances at the Federal Reserve drain by the same amount.
        // When TGA balance decreases (payments out), commercial bank reserves increase.
        val reserveDrainImpact = closingBalance - openingBalanceBillions

        val account = TreasuryCashAccount(
            accountId = accountId,
            date = date,
            openingBalanceBillions = openingBalanceBillions,
            taxReceiptsBillions = taxReceipts,
            otherReceiptsBillions = otherReceipts,
            debtIssuanceInflowBillions = debtIssuance,
            governmentPaymentsBillions = govPayments,
            debtMaturitiesOutflowBillions = debtMaturities,
            interestPaymentsOutflowBillions = interestPayments,
            otherOutflowsBillions = otherOutflows,
            closingBalanceBillions = closingBalance,
            targetBalanceBillions = targetBalanceBillions,
            fedReserveDrainImpactBillions = reserveDrainImpact
        )

        // Strict verification
        check(account.isLedgerBalanced) { "TGA Ledger Invariant Violated! Opening: $openingBalanceBillions, Inflows: $totalInflows, Outflows: $totalOutflows, Closing: $closingBalance" }

        return account
    }

    /**
     * Computes the financing gap to restore TGA back to target cash level ($750B).
     */
    fun calculateRequiredCashBufferFinancing(
        currentTgaBillions: Double,
        projectedNetCashFlowNext30DBillions: Double,
        targetTgaBillions: Double = 750.0,
        minBufferBillions: Double = 500.0
    ): Double {
        val projectedEndBalance = currentTgaBillions + projectedNetCashFlowNext30DBillions
        return if (projectedEndBalance < targetTgaBillions) {
            targetTgaBillions - projectedEndBalance
        } else {
            0.0
        }
    }
}
