package com.example.domain.engine

import com.example.domain.model.BuybackOperation
import com.example.domain.model.BuybackType

object BuybackEngine {

    /**
     * Simulates a U.S. Treasury Buyback Operation (Liquidity Support or Cash Management).
     */
    fun executeBuyback(
        type: BuybackType,
        targetParAmountBillions: Double,
        targetMaturityRange: String,
        tenderMultiplier: Double = 3.2
    ): BuybackOperation {
        val tendered = targetParAmountBillions * tenderMultiplier
        val accepted = targetParAmountBillions
        val weightedPrice = if (type == BuybackType.LIQUIDITY_SUPPORT) 98.45 else 99.85
        val avgYield = if (type == BuybackType.LIQUIDITY_SUPPORT) 4.42 else 4.78
        val cashSpent = (accepted * (weightedPrice / 100.0))

        return BuybackOperation(
            operationId = "BBK-${System.currentTimeMillis().toString().takeLast(6)}",
            type = type,
            announcementDate = "2026-10-01",
            executionDate = "2026-10-05",
            maxParAmountBillions = targetParAmountBillions,
            tenderedAmountBillions = tendered,
            acceptedAmountBillions = accepted,
            weightedPurchasePrice = weightedPrice,
            averageYieldPct = avgYield,
            totalCashDisbursedBillions = cashSpent,
            targetMaturityRange = targetMaturityRange,
            debtOutstandingReductionBillions = accepted
        )
    }
}
