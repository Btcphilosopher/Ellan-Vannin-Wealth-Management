package com.example.domain.engine

import com.example.domain.model.*
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object AuctionEngine {

    /**
     * Conducts a single-price Dutch auction for U.S. Treasury securities.
     * All winning competitive and non-competitive bidders pay the same single Stop-Out Yield.
     */
    fun clearAuction(
        auctionId: String,
        cusip: String,
        securityType: SecurityType,
        securityName: String,
        offeringAmountBillions: Double,
        wiYieldPct: Double,
        nonCompBids: List<NonCompetitiveBid>,
        competitiveBids: List<CompetitiveBid>,
        announcementDate: String,
        auctionDate: String,
        settlementDate: String,
        maturityDate: String,
        reopening: Boolean = false
    ): AuctionRecord {
        val totalNonCompAmount = nonCompBids.sumOf { it.amountBillions }
        val competitiveOffering = max(0.0, offeringAmountBillions - totalNonCompAmount)

        // Sort competitive bids ascending by yield (lowest yield = highest bid price = highest priority)
        val sortedBids = competitiveBids.sortedBy { it.yieldOrRatePct }
        val totalCompetitiveBidAmount = sortedBids.sumOf { it.bidAmountBillions }
        val totalBidsReceived = totalNonCompAmount + totalCompetitiveBidAmount

        var cumulativeAllocated = 0.0
        var stopOutYield = wiYieldPct
        val processedBids = mutableListOf<CompetitiveBid>()

        // Find stop-out yield
        var remainingCapacity = competitiveOffering
        var stopOutIndex = -1

        for (i in sortedBids.indices) {
            val bid = sortedBids[i]
            if (cumulativeAllocated + bid.bidAmountBillions <= competitiveOffering) {
                cumulativeAllocated += bid.bidAmountBillions
                stopOutYield = bid.yieldOrRatePct
                stopOutIndex = i
            } else {
                stopOutYield = bid.yieldOrRatePct
                stopOutIndex = i
                break
            }
        }

        // Allocate bids
        val bidsAtStopOut = sortedBids.filter { it.yieldOrRatePct == stopOutYield }
        val amountBidAtStopOut = bidsAtStopOut.sumOf { it.bidAmountBillions }
        val allocatedBeforeStopOut = sortedBids.filter { it.yieldOrRatePct < stopOutYield }.sumOf { it.bidAmountBillions }
        val capacityForStopOut = max(0.0, competitiveOffering - allocatedBeforeStopOut)
        val proRataStopOutPct = if (amountBidAtStopOut > 0.0) min(1.0, capacityForStopOut / amountBidAtStopOut) else 1.0

        for (bid in sortedBids) {
            when {
                bid.yieldOrRatePct < stopOutYield -> {
                    processedBids.add(
                        bid.copy(
                            isAccepted = true,
                            allocatedAmountBillions = bid.bidAmountBillions,
                            allocationPercentage = 100.0
                        )
                    )
                }
                bid.yieldOrRatePct == stopOutYield -> {
                    val allocated = bid.bidAmountBillions * proRataStopOutPct
                    processedBids.add(
                        bid.copy(
                            isAccepted = allocated > 0.0,
                            allocatedAmountBillions = allocated,
                            allocationPercentage = proRataStopOutPct * 100.0
                        )
                    )
                }
                else -> {
                    processedBids.add(
                        bid.copy(
                            isAccepted = false,
                            allocatedAmountBillions = 0.0,
                            allocationPercentage = 0.0
                        )
                    )
                }
            }
        }

        val totalCompetitiveAwarded = processedBids.sumOf { it.allocatedAmountBillions }
        val highYield = sortedBids.firstOrNull()?.yieldOrRatePct ?: stopOutYield
        val lowYield = sortedBids.lastOrNull()?.yieldOrRatePct ?: stopOutYield
        val medianYield = sortedBids.getOrNull(sortedBids.size / 2)?.yieldOrRatePct ?: stopOutYield
        val tailBp = (stopOutYield - wiYieldPct) * 100.0 // Tail = Stop out yield minus When-Issued yield
        val bidToCover = if (offeringAmountBillions > 0) totalBidsReceived / offeringAmountBillions else 0.0

        // Calculate investor takedown shares
        val dealerAwarded = processedBids.filter { it.category == BidderCategory.PRIMARY_DEALER }.sumOf { it.allocatedAmountBillions }
        val directAwarded = processedBids.filter { it.category == BidderCategory.DIRECT_BIDDER }.sumOf { it.allocatedAmountBillions }
        val indirectAwarded = processedBids.filter { it.category == BidderCategory.INDIRECT_FOREIGN }.sumOf { it.allocatedAmountBillions }
        val totalAwarded = max(0.01, totalNonCompAmount + totalCompetitiveAwarded)

        val dealerPct = (dealerAwarded / totalAwarded) * 100.0
        val directPct = (directAwarded / totalAwarded) * 100.0
        val indirectPct = (indirectAwarded / totalAwarded) * 100.0

        return AuctionRecord(
            auctionId = auctionId,
            cusip = cusip,
            securityType = securityType,
            securityName = securityName,
            offeringAmountBillions = offeringAmountBillions,
            totalBidsReceivedBillions = totalBidsReceived,
            nonCompetitiveAwardedBillions = totalNonCompAmount,
            competitiveAwardedBillions = totalCompetitiveAwarded,
            stopOutYieldPct = stopOutYield,
            highYieldPct = highYield,
            lowYieldPct = lowYield,
            medianYieldPct = medianYield,
            tailBasisPoints = tailBp,
            bidToCoverRatio = bidToCover,
            primaryDealerPct = dealerPct,
            directBidderPct = directPct,
            indirectForeignPct = indirectPct,
            announcementDate = announcementDate,
            auctionDate = auctionDate,
            settlementDate = settlementDate,
            maturityDate = maturityDate,
            reopening = reopening,
            bids = processedBids,
            status = "SETTLED"
        )
    }

    /**
     * Generates a realistic synthetic competitive bid book given offering size and market parameters.
     */
    fun generateSyntheticBidBook(
        offeringAmountBillions: Double,
        baseYieldPct: Double,
        bidToCoverTarget: Double = 2.45,
        dealerAggressiveness: Double = 1.0,
        foreignDemandMultiplier: Double = 1.0
    ): Pair<List<NonCompetitiveBid>, List<CompetitiveBid>> {
        val random = Random(42)
        val nonCompTotal = offeringAmountBillions * 0.035 // ~3.5% non-competitive
        val nonCompBids = listOf(
            NonCompetitiveBid("NC-01", "TreasuryDirect Retail Aggregate", nonCompTotal * 0.65),
            NonCompetitiveBid("NC-02", "Small Financial Institutions Group", nonCompTotal * 0.35)
        )

        val targetCompetitiveBidTotal = offeringAmountBillions * bidToCoverTarget
        val competitiveBids = mutableListOf<CompetitiveBid>()

        val primaryDealers = listOf(
            "J.P. Morgan Securities LLC", "Goldman Sachs & Co. LLC", "BofA Securities, Inc.",
            "Morgan Stanley & Co. LLC", "Citigroup Global Markets Inc.", "Barclays Capital Inc.",
            "TD Securities (USA) LLC", "BNP Paribas Securities Corp.", "HSBC Securities (USA) Inc.",
            "Wells Fargo Securities, LLC", "Nomura Securities International, Inc.", "Deutsche Bank Securities Inc."
        )

        val directBidders = listOf(
            "BlackRock Institutional Trust", "Vanguard Group Sovereign Fund", "Fidelity Institutional Cash",
            "PIMCO Government Reserve", "State Street Global Advisors", "CalPERS Treasury Portfolio",
            "Federal Home Loan Bank Group", "MetLife Fixed Income Desk"
        )

        val indirectForeign = listOf(
            "Bank of Japan / MOF Custody Account", "People's Bank of China Central Reserve",
            "Bank of England Official Operations", "Swiss National Bank Reserves",
            "Monetary Authority of Singapore", "Saudi Central Bank (SAMA)",
            "Norges Bank Investment Management", "Bank of Canada Reserve Account"
        )

        val mmfAssetManagers = listOf(
            "Federated Hermes Govt Cash", "Schwab Treasury Money Fund", "Dreyfus Government Cash",
            "Northern Trust Global Treasury", "Invesco Short-Term Bond Desk"
        )

        var bidCount = 1
        // Generate Dealer bids (tends to bracket around market)
        primaryDealers.forEach { dealer ->
            val numBids = random.nextInt(2, 4)
            for (j in 0 until numBids) {
                val spread = (random.nextDouble(-0.03, 0.05) / dealerAggressiveness)
                val amount = random.nextDouble(1.5, 4.5)
                competitiveBids.add(
                    CompetitiveBid(
                        bidId = "BID-${String.format(Locale.US, "%04d", bidCount++)}",
                        bidderId = "DLR-${dealer.hashCode().toString().takeLast(4)}",
                        bidderName = dealer,
                        category = BidderCategory.PRIMARY_DEALER,
                        yieldOrRatePct = baseYieldPct + spread,
                        bidAmountBillions = amount
                    )
                )
            }
        }

        // Generate Indirect / Foreign Central Bank bids (usually aggressive, lower yield)
        indirectForeign.forEach { foreign ->
            val numBids = random.nextInt(1, 3)
            for (j in 0 until numBids) {
                val spread = random.nextDouble(-0.04, 0.02)
                val amount = random.nextDouble(2.0, 6.0) * foreignDemandMultiplier
                competitiveBids.add(
                    CompetitiveBid(
                        bidId = "BID-${String.format(Locale.US, "%04d", bidCount++)}",
                        bidderId = "FOR-${foreign.hashCode().toString().takeLast(4)}",
                        bidderName = foreign,
                        category = BidderCategory.INDIRECT_FOREIGN,
                        yieldOrRatePct = baseYieldPct + spread,
                        bidAmountBillions = amount
                    )
                )
            }
        }

        // Generate Direct Bidders
        directBidders.forEach { direct ->
            val spread = random.nextDouble(-0.02, 0.03)
            val amount = random.nextDouble(1.0, 3.5)
            competitiveBids.add(
                CompetitiveBid(
                    bidId = "BID-${String.format(Locale.US, "%04d", bidCount++)}",
                    bidderId = "DIR-${direct.hashCode().toString().takeLast(4)}",
                    bidderName = direct,
                    category = BidderCategory.DIRECT_BIDDER,
                    yieldOrRatePct = baseYieldPct + spread,
                    bidAmountBillions = amount
                )
            )
        }

        // MMFs / Asset Managers
        mmfAssetManagers.forEach { mmf ->
            val spread = random.nextDouble(-0.015, 0.025)
            val amount = random.nextDouble(1.5, 4.0)
            competitiveBids.add(
                CompetitiveBid(
                    bidId = "BID-${String.format(Locale.US, "%04d", bidCount++)}",
                    bidderId = "MMF-${mmf.hashCode().toString().takeLast(4)}",
                    bidderName = mmf,
                    category = BidderCategory.MMF_ASSET_MGR,
                    yieldOrRatePct = baseYieldPct + spread,
                    bidAmountBillions = amount
                )
            )
        }

        return Pair(nonCompBids, competitiveBids)
    }
}
