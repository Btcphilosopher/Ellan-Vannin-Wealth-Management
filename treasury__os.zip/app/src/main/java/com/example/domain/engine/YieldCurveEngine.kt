package com.example.domain.engine

import com.example.domain.model.RepoMarketLink
import com.example.domain.model.YieldCurvePoint
import kotlin.math.exp
import kotlin.math.ln

object YieldCurveEngine {

    /**
     * Builds the benchmark sovereign yield curve from 1M to 30Y tenors.
     */
    fun buildYieldCurve(
        parallelShiftBp: Double = 0.0,
        steepeningBp: Double = 0.0
    ): List<YieldCurvePoint> {
        val tenors = listOf(
            Triple("1M", 1.0 / 12.0, 4.82),
            Triple("3M", 3.0 / 12.0, 4.75),
            Triple("6M", 6.0 / 12.0, 4.62),
            Triple("1Y", 1.0, 4.38),
            Triple("2Y", 2.0, 4.12),
            Triple("3Y", 3.0, 4.05),
            Triple("5Y", 5.0, 4.15),
            Triple("7Y", 7.0, 4.28),
            Triple("10Y", 10.0, 4.38),
            Triple("20Y", 20.0, 4.68),
            Triple("30Y", 30.0, 4.58)
        )

        return tenors.map { (label, years, baseParYield) ->
            val shift = parallelShiftBp / 100.0
            val slopeAdjustment = (steepeningBp / 100.0) * (years / 30.0)
            val parYield = baseParYield + shift + slopeAdjustment
            
            // Nelson-Siegel derived zero curve and discount factor
            val zeroRate = parYield + (0.05 * ln(1.0 + years))
            val discountFactor = exp(-zeroRate / 100.0 * years)
            val forwardRate = parYield + 0.12 * years.coerceAtMost(5.0)
            
            // When-Issued (WI) market spread (typically -0.5bp to +1.5bp from secondary benchmark)
            val wiSpreadBp = if (years <= 2.0) -0.4 else if (years <= 10.0) 0.6 else 1.2
            val wiYield = parYield + (wiSpreadBp / 100.0)

            YieldCurvePoint(
                tenorLabel = label,
                tenorYears = years,
                parYieldPct = parYield,
                zeroRatePct = zeroRate,
                forwardRatePct = forwardRate,
                discountFactor = discountFactor,
                whenIssuedYieldPct = wiYield,
                wiSpreadBasisPoints = wiSpreadBp
            )
        }
    }

    fun getRepoMarketState(): RepoMarketLink {
        return RepoMarketLink(
            sofrRatePct = 4.82,
            repoOvernightRatePct = 4.80,
            specialnessBasisPoints = 8.5,
            primaryDealerInventoryBillions = 142.5,
            fciConditions = "Neutral / Orderly",
            foreignHoldingSharePct = 23.8
        )
    }
}
