import { NextRequest, NextResponse } from "next/server";
import { GLOBAL_SUMMARY_METRICS, ScenarioInput, ScenarioResult } from "@/lib/mock-data";

export async function POST(req: NextRequest) {
  try {
    const input: ScenarioInput = await req.json();

    // Baseline system sales ($134.8B)
    const baseSalesMillions = GLOBAL_SUMMARY_METRICS.systemwideSales * 1000;
    
    // Calculate traffic & promo lift impact
    const trafficFactor = 1 + ((input.trafficChangePct + input.promotionalLiftPct) / 100);
    const simulatedSalesMillions = baseSalesMillions * trafficFactor;
    const salesDeltaMillions = simulatedSalesMillions - baseSalesMillions;

    // Calculate food cost impact (chicken ~ 15% of food cost, beef ~ 25% of food cost)
    const foodCostChangeImpact = (input.chickenPriceChangePct * 0.15) + (input.beefPriceChangePct * 0.25);
    const laborImpact = input.laborCostChangePct * 0.28; // labor is ~28% of restaurant P&L

    // Basis points margin impact (1% = 100 bps)
    const marginImpactBps = Math.round((-foodCostChangeImpact * 30) - (laborImpact * 28) + (input.trafficChangePct * 40));

    // Remodel capex & return
    const capexPerRemodelMillions = 0.85; // $850k per store
    const totalCapexMillions = input.remodelCount * capexPerRemodelMillions;
    const annualLiftPerRemodel = 0.12; // 12% sales lift post-remodel

    // Calculate franchisee cash flow impact
    const avgFranchiseeStores = 5;
    const franchiseeCashFlowDeltaUSD = Math.round(
      (salesDeltaMillions * 1000000 / GLOBAL_SUMMARY_METRICS.restaurantCount * avgFranchiseeStores * 0.20) - 
      (foodCostChangeImpact * 45000) - 
      (laborImpact * 55000)
    );

    const corporateRoyaltyDeltaMillions = (salesDeltaMillions * 0.04) + (input.remodelCount * annualLiftPerRemodel * 0.04);

    const recommendations: string[] = [];
    if (input.chickenPriceChangePct > 10) {
      recommendations.push("Initiate 12-month forward hedging contract with Keystone Foods for poultry supply.");
    }
    if (input.laborCostChangePct > 5) {
      recommendations.push("Accelerate Next-Gen Dual-Lane Drive-Thru Automated Order Taking (AOT) to offset labor inflation.");
    }
    if (input.remodelCount > 500) {
      recommendations.push("Engage corporate treasury for franchisee low-interest remodel co-financing facility.");
    }
    if (recommendations.length === 0) {
      recommendations.push("Maintain baseline operational posture; monitor competitor promotional cadence.");
    }

    const result: ScenarioResult = {
      simulatedSalesDeltaUSD: Math.round(salesDeltaMillions),
      simulatedMarginChangeBasisPoints: marginImpactBps,
      simulatedFranchiseeCashFlowUSD: franchiseeCashFlowDeltaUSD,
      simulatedCorporateRoyaltyUSD: Math.round(corporateRoyaltyDeltaMillions * 1000000),
      riskSummary: marginImpactBps < -150 
        ? "HIGH RISK: Severe margin compression across franchisee portfolio requires strategic menu pricing adjustments." 
        : marginImpactBps < 0 
        ? "MODERATE RISK: Minor cost headwinds manageable through productivity gains and supply chain efficiency." 
        : "POSITIVE OUTLOOK: Volume expansion and operational efficiencies drive accretive returns across system.",
      recommendations
    };

    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Simulation execution failed." }, { status: 500 });
  }
}
