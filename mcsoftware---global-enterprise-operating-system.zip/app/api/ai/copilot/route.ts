import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";
import { GLOBAL_SUMMARY_METRICS, MOCK_MARKETS, MOCK_FRANCHISEES, MOCK_RESTAURANTS, MOCK_SUPPLIERS, MOCK_EVENTS } from "@/lib/mock-data";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { prompt, persona, entityId } = await req.json();

    let dataScopePrompt = "";

    if (persona === "CORPORATE") {
      dataScopePrompt = `
You are the Corporate AI Copilot for McSOFTWARE (McDonald's Enterprise Operating System).
You have full visibility into global enterprise data:
- Global KPIs: Systemwide Sales: $${GLOBAL_SUMMARY_METRICS.systemwideSales}B, Revenue: $${GLOBAL_SUMMARY_METRICS.revenue}B, Restaurants: ${GLOBAL_SUMMARY_METRICS.restaurantCount} (${(GLOBAL_SUMMARY_METRICS.franchisedRatio * 100).toFixed(1)}% Franchised), Comp Sales Growth: +${GLOBAL_SUMMARY_METRICS.comparableSalesGrowth}%, Active Loyalty Users: ${GLOBAL_SUMMARY_METRICS.loyaltyActiveUsersMillions}M.
- Markets Summary: ${JSON.stringify(MOCK_MARKETS.map(m => ({ id: m.id, name: m.name, sales: `$${m.systemSalesUSD}M`, comp: `+${m.compSalesGrowth}%`, stores: m.restaurantCount })))}
- Franchisee Group Overview: ${JSON.stringify(MOCK_FRANCHISEES.map(f => ({ id: f.id, entity: f.legalEntityName, owner: f.ownerName, territory: f.territory, stores: f.restaurantCount, sales: `$${f.annualSystemSalesUSD}M`, margin: `${f.operatingMarginPercent}%`, status: f.riskStatus })))}
- Suppliers Overview: ${JSON.stringify(MOCK_SUPPLIERS.map(s => ({ id: s.id, name: s.companyName, fulfillment: `${s.fulfillmentRatePercent}%`, risk: s.riskLevel })))}
- Recent System Events: ${JSON.stringify(MOCK_EVENTS.slice(0, 3))}

Provide precise, quantitative executive answers.
Constraint: Always append a JSON block or text block titled "SOURCE DATA CITATION" detailing the scope, date (October 2026), and data points used.
`;
    } else if (persona === "FRANCHISEE") {
      const franchisee = MOCK_FRANCHISEES.find(f => f.id === entityId) || MOCK_FRANCHISEES[0];
      const franchiseeStores = MOCK_RESTAURANTS.filter(r => r.franchiseeId === franchisee.id);

      dataScopePrompt = `
You are the Franchisee AI Copilot for McSOFTWARE, assisting Franchisee Owner ${franchisee.ownerName} (${franchisee.legalEntityName}, ID: ${franchisee.id}).
You ONLY have access to THIS FRANCHISEE'S confidential data:
- Territory: ${franchisee.territory}
- Total Stores: ${franchisee.restaurantCount}
- Annual Sales: $${franchisee.annualSystemSalesUSD}M
- Operating Margin: ${franchisee.operatingMarginPercent}%
- Risk Status: ${franchisee.riskStatus}
- Stores Data: ${JSON.stringify(franchiseeStores.map(r => ({ id: r.id, name: r.name, todaySales: `$${r.todaySalesUSD}`, driveThruTime: `${r.driveThruAvgTimeSeconds}s`, laborActual: r.laborHoursActual, waste: `$${r.wasteCostUSD}`, equipmentAlerts: r.equipments.filter(e => e.status !== 'NORMAL') })))}

STRICT DATA ISOLATION RULE: If asked about another franchisee or overall corporate secrets, politely state that you are restricted to ${franchisee.legalEntityName}'s business boundaries.
`;
    } else {
      // RESTAURANT MANAGER
      const store = MOCK_RESTAURANTS.find(r => r.id === entityId) || MOCK_RESTAURANTS[0];
      dataScopePrompt = `
You are the Restaurant AI Assistant for McSOFTWARE, running on the Edge node of Restaurant ${store.name} (${store.id}).
You assist the Manager on Shift.
Store Context Today:
- Today's Sales: $${store.todaySalesUSD} (${store.todayOrderCount} orders)
- Drive-Thru Speed: ${store.driveThruAvgTimeSeconds} seconds (Target: <210s)
- Kitchen Throughput: ${store.kitchenThroughputOrdersPerHour} orders/hr
- Labor: ${store.laborHoursActual} hrs actual vs ${store.laborHoursScheduled} scheduled
- Food Waste Today: $${store.wasteCostUSD}
- Equipment Alerts: ${JSON.stringify(store.equipments)}

Respond with prioritized, actionable steps for the current shift.
`;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: dataScopePrompt,
        temperature: 0.3,
      }
    });

    return NextResponse.json({
      text: response.text || "No response generated.",
      persona,
      timestamp: new Date().toISOString()
    });

  } catch (error: any) {
    console.error("Gemini Copilot error:", error);
    return NextResponse.json({ error: error?.message || "Failed to query AI Copilot." }, { status: 500 });
  }
}
