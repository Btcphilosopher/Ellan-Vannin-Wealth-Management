import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'McSOFTWARE - Enterprise Operating System',
  description: 'The enterprise digital operating system connecting Corporate HQ, Markets, Franchisees, Restaurants, and Suppliers.',
  openGraph: {
    title: 'McSOFTWARE - Enterprise Operating System',
    description: 'The enterprise digital operating system connecting Corporate HQ, Markets, Franchisees, Restaurants, and Suppliers.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'McSOFTWARE - Enterprise Operating System',
    description: 'The enterprise digital operating system connecting Corporate HQ, Markets, Franchisees, Restaurants, and Suppliers.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <body suppressHydrationWarning className="bg-[#0F172A] text-slate-100 antialiased selection:bg-amber-500 selection:text-slate-900">{children}</body>
    </html>
  );
}
