'use client';

import React, { useState } from 'react';
import { Header, UserRole } from '@/components/Header';
import { CorporateHQView } from '@/components/CorporateHQView';
import { FranchiseeView } from '@/components/FranchiseeView';
import { RestaurantView } from '@/components/RestaurantView';
import { SupplierView } from '@/components/SupplierView';
import { McSimEngineView } from '@/components/McSimEngineView';
import { AICopilotDrawer } from '@/components/AICopilotDrawer';
import { DrilldownModal } from '@/components/DrilldownModal';
import { MOCK_RESTAURANTS, Restaurant } from '@/lib/mock-data';

export default function Page() {
  const [currentRole, setCurrentRole] = useState<UserRole>('CORPORATE');
  const [selectedStore, setSelectedStore] = useState<Restaurant>(MOCK_RESTAURANTS[0]);
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);
  const [isDrilldownOpen, setIsDrilldownOpen] = useState(false);

  const handleSelectRestaurantFromHQ = (store: Restaurant) => {
    setSelectedStore(store);
    setCurrentRole('RESTAURANT');
  };

  const handleSelectStoreById = (id: string) => {
    const store = MOCK_RESTAURANTS.find(r => r.id === id) || MOCK_RESTAURANTS[0];
    setSelectedStore(store);
  };

  const breadcrumbPath = [
    'McDonald\'s Global Corp',
    currentRole === 'CORPORATE' ? 'Executive HQ' :
    currentRole === 'FRANCHISEE' ? `${selectedStore.franchiseeName}` :
    currentRole === 'RESTAURANT' ? `${selectedStore.name}` :
    currentRole === 'SUPPLIER' ? 'Global Supply Chain' : 'McSIM Simulation Engine'
  ];

  return (
    <div className="min-h-screen bg-[#0F172A] text-slate-100 font-sans flex flex-col">
      {/* Top Header Contract */}
      <Header
        currentRole={currentRole}
        onSelectRole={role => setCurrentRole(role)}
        onOpenCopilot={() => setIsCopilotOpen(true)}
        onOpenDrilldown={() => setIsDrilldownOpen(true)}
        selectedBreadcrumbPath={breadcrumbPath}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-[1700px] w-full mx-auto px-4 pt-6">
        {currentRole === 'CORPORATE' && (
          <CorporateHQView
            onSelectRestaurant={handleSelectRestaurantFromHQ}
            onOpenDrilldown={() => setIsDrilldownOpen(true)}
          />
        )}

        {currentRole === 'FRANCHISEE' && (
          <FranchiseeView
            onSelectRestaurant={handleSelectRestaurantFromHQ}
          />
        )}

        {currentRole === 'RESTAURANT' && (
          <RestaurantView
            selectedStore={selectedStore}
            onSelectStoreById={handleSelectStoreById}
          />
        )}

        {currentRole === 'SUPPLIER' && (
          <SupplierView />
        )}

        {currentRole === 'MCSIM' && (
          <McSimEngineView />
        )}
      </main>

      {/* AI Copilot Slide-out Drawer */}
      <AICopilotDrawer
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        currentRole={currentRole}
        selectedEntityId={selectedStore.franchiseeId}
      />

      {/* 6-Tier System Hierarchy Explorer Modal */}
      <DrilldownModal
        isOpen={isDrilldownOpen}
        onClose={() => setIsDrilldownOpen(false)}
        onSelectRestaurant={handleSelectRestaurantFromHQ}
      />
    </div>
  );
}
