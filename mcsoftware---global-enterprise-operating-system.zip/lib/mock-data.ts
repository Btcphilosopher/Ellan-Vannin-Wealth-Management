export interface GlobalKPIs {
  systemwideSales: number; // in USD billions e.g. 132.8B
  revenue: number; // in USD billions
  franchiseRevenue: number; // in USD billions
  restaurantCount: number; // e.g. 46280
  franchisedRatio: number; // e.g. 0.95 (95%)
  comparableSalesGrowth: number; // % e.g. 5.4
  guestCountMillions: number; // e.g. 68.2M daily
  averageCheckUSD: number; // e.g. 11.45
  digitalMixPercent: number; // e.g. 42.8
  loyaltyActiveUsersMillions: number; // e.g. 218.4
  restaurantProfitabilityMargin: number; // % e.g. 19.8
  laborCostPercent: number; // % e.g. 28.2
  foodCostPercent: number; // % e.g. 31.4
  supplyAvailabilityPercent: number; // % e.g. 99.4
  openExceptionsCount: number; // e.g. 142
}

export interface Market {
  id: string;
  name: string;
  segment: 'US' | 'International Operated' | 'International Developmental Licensee';
  region: 'North America' | 'Europe' | 'Asia Pacific' | 'Latin America' | 'Middle East';
  countryCode: string;
  restaurantCount: number;
  systemSalesUSD: number; // Millions
  compSalesGrowth: number;
  activeFranchisees: number;
  complianceScore: number;
  leadExecutive: string;
}

export interface FranchiseeAgreement {
  id: string;
  restaurantId: string;
  restaurantName: string;
  termYears: number;
  commencementDate: string;
  expirationDate: string;
  royaltyRatePercent: number;
  rentType: 'Percentage' | 'Base Plus Percentage' | 'Fixed';
  rentRatePercent: number;
  status: 'ACTIVE' | 'RENEWAL_DUE' | 'UNDER_REVIEW' | 'EXPIRED';
  capitalCommitmentUSD: number;
}

export interface Franchisee {
  id: string;
  legalEntityName: string;
  ownerName: string;
  marketId: string;
  marketName: string;
  territory: string;
  restaurantIds: string[];
  restaurantCount: number;
  annualSystemSalesUSD: number; // Millions
  compSalesGrowth: number;
  operatingMarginPercent: number;
  riskStatus: 'HEALTHY' | 'WATCHLIST' | 'CRITICAL' | 'EXPANDING';
  agreements: FranchiseeAgreement[];
  onboardingStage?: 'APPROVED' | 'IN_TRAINING' | 'OPERATING' | 'EXPANSION';
  supportCasesOpen: number;
  lastVisitDate: string;
  lastVisitScore: number;
}

export interface EquipmentAsset {
  id: string;
  name: string;
  category: 'GRILL' | 'FRYER' | 'FREEZER' | 'BEVERAGE' | 'POS' | 'KIOSK' | 'HVAC';
  serialNumber: string;
  installedDate: string;
  status: 'NORMAL' | 'WARNING' | 'CRITICAL_ALERT' | 'OFFLINE';
  temperatureC?: number;
  telemetryHealth: number; // %
  predictedFailureRisk: 'LOW' | 'MEDIUM' | 'HIGH';
  recommendedMaintenanceDays: number;
}

export interface Restaurant {
  id: string; // e.g. "US-1024"
  name: string;
  marketId: string;
  marketName: string;
  franchiseeId: string;
  franchiseeName: string;
  ownershipType: 'CONVENTIONAL_FRANCHISE' | 'DEVELOPMENTAL_LICENSEE' | 'COMPANY_OPERATED';
  address: string;
  city: string;
  country: string;
  format: 'DRIVE_THRU_FREE_STANDING' | 'URBAN_INLINE' | 'MALL_FOOD_COURT' | 'FLAGSHIP_DIGITAL';
  openingDate: string;
  status: 'OPEN' | 'CLOSED' | 'TEMPORARILY_CLOSED' | 'UNDER_CONSTRUCTION' | 'REMODELLING';
  
  // Daily / Live Metrics
  todaySalesUSD: number;
  todayOrderCount: number;
  averageCheckUSD: number;
  driveThruAvgTimeSeconds: number; // e.g. 222 (3m 42s)
  kitchenThroughputOrdersPerHour: number;
  digitalMixPercent: number;
  laborHoursActual: number;
  laborHoursScheduled: number;
  foodCostActualUSD: number;
  wasteCostUSD: number;
  customerSatisfactionScore: number; // e.g. 4.8 / 5.0
  
  // Equipment / Telemetry
  equipments: EquipmentAsset[];
  
  // Financial Summary
  monthlySalesUSD: number;
  royaltyPayableUSD: number;
  rentPayableUSD: number;
  netMarginPercent: number;
}

export interface Supplier {
  id: string;
  companyName: string;
  category: 'MEAT_POULTRY' | 'PRODUCE_DAIRY' | 'PACKAGING' | 'EQUIPMENT' | 'LOGISTICS';
  countriesServed: string[];
  activeContracts: number;
  fulfillmentRatePercent: number;
  qualityComplianceScore: number;
  openPurchaseOrders: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'ELEVATED';
  primaryDistributionCenter: string;
}

export interface DistributionCenter {
  id: string;
  name: string;
  location: string;
  marketId: string;
  capacityUtilizationPercent: number;
  servicedRestaurantsCount: number;
  inventoryTurnoverDays: number;
  coldChainCompliancePercent: number;
}

export interface SystemEvent {
  id: string;
  timestamp: string;
  eventType: 'OrderCreated' | 'InventoryLow' | 'EquipmentFailure' | 'RoyaltyCalculated' | 'AuditFailed' | 'FranchiseAgreementUpdated' | 'ShipmentDelayed' | 'ShiftStarted';
  source: string;
  entityId: string;
  actor: string;
  description: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
}

export interface ScenarioInput {
  chickenPriceChangePct: number;
  beefPriceChangePct: number;
  laborCostChangePct: number;
  trafficChangePct: number;
  remodelCount: number;
  promotionalLiftPct: number;
}

export interface ScenarioResult {
  simulatedSalesDeltaUSD: number; // Millions
  simulatedMarginChangeBasisPoints: number;
  simulatedFranchiseeCashFlowUSD: number;
  simulatedCorporateRoyaltyUSD: number;
  riskSummary: string;
  recommendations: string[];
}

// Global Markets Sample
export const MOCK_MARKETS: Market[] = [
  { id: 'MKT-US', name: 'United States', segment: 'US', region: 'North America', countryCode: 'US', restaurantCount: 13450, systemSalesUSD: 48500, compSalesGrowth: 4.8, activeFranchisees: 2150, complianceScore: 98.2, leadExecutive: 'Sarah Jenkins' },
  { id: 'MKT-UK', name: 'United Kingdom & Ireland', segment: 'International Operated', region: 'Europe', countryCode: 'GB', restaurantCount: 1420, systemSalesUSD: 6200, compSalesGrowth: 5.6, activeFranchisees: 180, complianceScore: 97.8, leadExecutive: 'Oliver Vance' },
  { id: 'MKT-DE', name: 'Germany', segment: 'International Operated', region: 'Europe', countryCode: 'DE', restaurantCount: 1440, systemSalesUSD: 5100, compSalesGrowth: 3.9, activeFranchisees: 210, complianceScore: 96.5, leadExecutive: 'Klaus Mueller' },
  { id: 'MKT-FR', name: 'France', segment: 'International Operated', region: 'Europe', countryCode: 'FR', restaurantCount: 1530, systemSalesUSD: 6800, compSalesGrowth: 6.1, activeFranchisees: 310, complianceScore: 98.0, leadExecutive: 'Claire Dubois' },
  { id: 'MKT-JP', name: 'Japan', segment: 'International Developmental Licensee', region: 'Asia Pacific', countryCode: 'JP', restaurantCount: 2980, systemSalesUSD: 5400, compSalesGrowth: 7.2, activeFranchisees: 1, complianceScore: 99.1, leadExecutive: 'Kenji Sato' },
  { id: 'MKT-AU', name: 'Australia & NZ', segment: 'International Operated', region: 'Asia Pacific', countryCode: 'AU', restaurantCount: 1020, systemSalesUSD: 4100, compSalesGrowth: 4.2, activeFranchisees: 145, complianceScore: 98.4, leadExecutive: 'Liam O\'Connor' },
  { id: 'MKT-BR', name: 'Brazil (Arcos Dourados)', segment: 'International Developmental Licensee', region: 'Latin America', countryCode: 'BR', restaurantCount: 1120, systemSalesUSD: 3200, compSalesGrowth: 8.4, activeFranchisees: 1, complianceScore: 95.8, leadExecutive: 'Marcelo Silva' },
  { id: 'MKT-CN', name: 'China (CITIC Consortium)', segment: 'International Developmental Licensee', region: 'Asia Pacific', countryCode: 'CN', restaurantCount: 5900, systemSalesUSD: 9800, compSalesGrowth: 9.1, activeFranchisees: 1, complianceScore: 97.0, leadExecutive: 'Zhang Wei' },
];

export const MOCK_FRANCHISEES: Franchisee[] = [
  {
    id: 'FRAN-1042',
    legalEntityName: 'Apex Quick Service Operations LLC',
    ownerName: 'Marcus Vance',
    marketId: 'MKT-US',
    marketName: 'United States',
    territory: 'New York Metro Area',
    restaurantIds: ['US-1024', 'US-1025', 'US-1028', 'US-1031', 'US-1040'],
    restaurantCount: 5,
    annualSystemSalesUSD: 18.5,
    compSalesGrowth: 6.2,
    operatingMarginPercent: 21.4,
    riskStatus: 'HEALTHY',
    agreements: [
      { id: 'AGR-1024', restaurantId: 'US-1024', restaurantName: 'Times Square Flagship #1024', termYears: 20, commencementDate: '2016-04-15', expirationDate: '2036-04-14', royaltyRatePercent: 4.0, rentType: 'Percentage', rentRatePercent: 10.5, status: 'ACTIVE', capitalCommitmentUSD: 450000 },
      { id: 'AGR-1025', restaurantId: 'US-1025', restaurantName: 'Brooklyn Bridge Drive-Thru #1025', termYears: 20, commencementDate: '2018-09-01', expirationDate: '2038-08-31', royaltyRatePercent: 4.0, rentType: 'Percentage', rentRatePercent: 9.8, status: 'ACTIVE', capitalCommitmentUSD: 320000 }
    ],
    supportCasesOpen: 1,
    lastVisitDate: '2026-10-12',
    lastVisitScore: 96.5
  },
  {
    id: 'FRAN-2088',
    legalEntityName: 'Golden Gateway Holdings UK Ltd',
    ownerName: 'Eleanor Sterling',
    marketId: 'MKT-UK',
    marketName: 'United Kingdom & Ireland',
    territory: 'Greater London & Surrey',
    restaurantIds: ['UK-0184', 'UK-0185', 'UK-0190'],
    restaurantCount: 3,
    annualSystemSalesUSD: 11.2,
    compSalesGrowth: 4.1,
    operatingMarginPercent: 18.9,
    riskStatus: 'WATCHLIST',
    agreements: [
      { id: 'AGR-0184', restaurantId: 'UK-0184', restaurantName: 'London Victoria Station #0184', termYears: 20, commencementDate: '2012-06-01', expirationDate: '2032-05-31', royaltyRatePercent: 4.5, rentType: 'Base Plus Percentage', rentRatePercent: 12.0, status: 'ACTIVE', capitalCommitmentUSD: 280000 }
    ],
    supportCasesOpen: 3,
    lastVisitDate: '2026-09-28',
    lastVisitScore: 88.2
  },
  {
    id: 'FRAN-3015',
    legalEntityName: 'Bavaria Fast Food System GmbH',
    ownerName: 'Hans-Peter Weber',
    marketId: 'MKT-DE',
    marketName: 'Germany',
    territory: 'Munich & Upper Bavaria',
    restaurantIds: ['DE-0412', 'DE-0415'],
    restaurantCount: 2,
    annualSystemSalesUSD: 7.8,
    compSalesGrowth: 5.0,
    operatingMarginPercent: 20.1,
    riskStatus: 'HEALTHY',
    agreements: [
      { id: 'AGR-0412', restaurantId: 'DE-0412', restaurantName: 'Munich Marienplatz #0412', termYears: 20, commencementDate: '2015-11-10', expirationDate: '2035-11-09', royaltyRatePercent: 5.0, rentType: 'Percentage', rentRatePercent: 11.0, status: 'ACTIVE', capitalCommitmentUSD: 350000 }
    ],
    supportCasesOpen: 0,
    lastVisitDate: '2026-10-18',
    lastVisitScore: 98.0
  }
];

export const MOCK_RESTAURANTS: Restaurant[] = [
  {
    id: 'US-1024',
    name: 'Times Square Flagship #1024',
    marketId: 'MKT-US',
    marketName: 'United States',
    franchiseeId: 'FRAN-1042',
    franchiseeName: 'Apex Quick Service Operations LLC',
    ownershipType: 'CONVENTIONAL_FRANCHISE',
    address: '1540 Broadway, New York, NY 10036',
    city: 'New York',
    country: 'United States',
    format: 'FLAGSHIP_DIGITAL',
    openingDate: '2016-04-15',
    status: 'OPEN',
    todaySalesUSD: 18450.00,
    todayOrderCount: 1420,
    averageCheckUSD: 12.99,
    driveThruAvgTimeSeconds: 222, // 3m 42s
    kitchenThroughputOrdersPerHour: 145,
    digitalMixPercent: 68.4,
    laborHoursActual: 112,
    laborHoursScheduled: 108,
    foodCostActualUSD: 5410.00,
    wasteCostUSD: 184.20,
    customerSatisfactionScore: 4.8,
    monthlySalesUSD: 485000,
    royaltyPayableUSD: 19400, // 4.0%
    rentPayableUSD: 50925, // 10.5%
    netMarginPercent: 22.4,
    equipments: [
      { id: 'EQ-1024-G1', name: 'Dual-Platen Smart Grill 1', category: 'GRILL', serialNumber: 'GRL-2024-991', installedDate: '2022-03-10', status: 'NORMAL', temperatureC: 178, telemetryHealth: 98, predictedFailureRisk: 'LOW', recommendedMaintenanceDays: 45 },
      { id: 'EQ-1024-F2', name: 'High-Volume Auto Fryer 2', category: 'FRYER', serialNumber: 'FRY-2023-442', installedDate: '2021-08-14', status: 'WARNING', temperatureC: 168, telemetryHealth: 82, predictedFailureRisk: 'MEDIUM', recommendedMaintenanceDays: 12 },
      { id: 'EQ-1024-FZ', name: 'Walk-in Main Freezer', category: 'FREEZER', serialNumber: 'FRZ-2020-001', installedDate: '2020-01-20', status: 'NORMAL', temperatureC: -18.2, telemetryHealth: 99, predictedFailureRisk: 'LOW', recommendedMaintenanceDays: 60 }
    ]
  },
  {
    id: 'US-1025',
    name: 'Brooklyn Bridge Drive-Thru #1025',
    marketId: 'MKT-US',
    marketName: 'United States',
    franchiseeId: 'FRAN-1042',
    franchiseeName: 'Apex Quick Service Operations LLC',
    ownershipType: 'CONVENTIONAL_FRANCHISE',
    address: '420 Flatbush Ave Ave, Brooklyn, NY 11201',
    city: 'New York',
    country: 'United States',
    format: 'DRIVE_THRU_FREE_STANDING',
    openingDate: '2018-09-01',
    status: 'OPEN',
    todaySalesUSD: 14200.00,
    todayOrderCount: 1180,
    averageCheckUSD: 12.03,
    driveThruAvgTimeSeconds: 195, // 3m 15s
    kitchenThroughputOrdersPerHour: 130,
    digitalMixPercent: 54.1,
    laborHoursActual: 92,
    laborHoursScheduled: 90,
    foodCostActualUSD: 4210.00,
    wasteCostUSD: 120.00,
    customerSatisfactionScore: 4.7,
    monthlySalesUSD: 382000,
    royaltyPayableUSD: 15280,
    rentPayableUSD: 37436,
    netMarginPercent: 20.8,
    equipments: [
      { id: 'EQ-1025-G1', name: 'Smart Grill 1', category: 'GRILL', serialNumber: 'GRL-2021-112', installedDate: '2021-05-10', status: 'NORMAL', temperatureC: 177, telemetryHealth: 95, predictedFailureRisk: 'LOW', recommendedMaintenanceDays: 30 },
      { id: 'EQ-1025-F1', name: 'Fryer System 1', category: 'FRYER', serialNumber: 'FRY-2022-098', installedDate: '2022-01-15', status: 'NORMAL', temperatureC: 175, telemetryHealth: 94, predictedFailureRisk: 'LOW', recommendedMaintenanceDays: 40 }
    ]
  },
  {
    id: 'UK-0184',
    name: 'London Victoria Station #0184',
    marketId: 'MKT-UK',
    marketName: 'United Kingdom & Ireland',
    franchiseeId: 'FRAN-2088',
    franchiseeName: 'Golden Gateway Holdings UK Ltd',
    ownershipType: 'CONVENTIONAL_FRANCHISE',
    address: 'Victoria Station Concourse, London SW1V 1JU',
    city: 'London',
    country: 'United Kingdom',
    format: 'URBAN_INLINE',
    openingDate: '2012-06-01',
    status: 'OPEN',
    todaySalesUSD: 12800.00,
    todayOrderCount: 1150,
    averageCheckUSD: 11.13,
    driveThruAvgTimeSeconds: 0,
    kitchenThroughputOrdersPerHour: 122,
    digitalMixPercent: 74.2,
    laborHoursActual: 86,
    laborHoursScheduled: 80,
    foodCostActualUSD: 3950.00,
    wasteCostUSD: 145.00,
    customerSatisfactionScore: 4.5,
    monthlySalesUSD: 320000,
    royaltyPayableUSD: 14400,
    rentPayableUSD: 38400,
    netMarginPercent: 18.2,
    equipments: [
      { id: 'EQ-0184-G1', name: 'Compact Grill Platen', category: 'GRILL', serialNumber: 'GRL-2019-301', installedDate: '2019-10-05', status: 'WARNING', temperatureC: 172, telemetryHealth: 78, predictedFailureRisk: 'MEDIUM', recommendedMaintenanceDays: 8 }
    ]
  }
];

export const MOCK_SUPPLIERS: Supplier[] = [
  { id: 'SUP-01', companyName: 'Keystone Foods Global', category: 'MEAT_POULTRY', countriesServed: ['US', 'CA', 'GB', 'DE', 'FR', 'JP', 'AU'], activeContracts: 14, fulfillmentRatePercent: 99.6, qualityComplianceScore: 99.2, openPurchaseOrders: 42, riskLevel: 'LOW', primaryDistributionCenter: 'DC-US-EAST' },
  { id: 'SUP-02', companyName: 'Martin-Brower Distribution', category: 'LOGISTICS', countriesServed: ['US', 'GB', 'FR', 'BR'], activeContracts: 8, fulfillmentRatePercent: 99.4, qualityComplianceScore: 98.8, openPurchaseOrders: 118, riskLevel: 'LOW', primaryDistributionCenter: 'DC-US-MIDWEST' },
  { id: 'SUP-03', companyName: 'Lopez Foods Inc', category: 'MEAT_POULTRY', countriesServed: ['US', 'MX'], activeContracts: 5, fulfillmentRatePercent: 98.9, qualityComplianceScore: 98.1, openPurchaseOrders: 18, riskLevel: 'LOW', primaryDistributionCenter: 'DC-US-SOUTH' },
  { id: 'SUP-04', companyName: 'Bakkavor Fresh Produce', category: 'PRODUCE_DAIRY', countriesServed: ['GB', 'DE', 'FR'], activeContracts: 6, fulfillmentRatePercent: 97.2, qualityComplianceScore: 96.5, openPurchaseOrders: 24, riskLevel: 'MEDIUM', primaryDistributionCenter: 'DC-UK-CENTRAL' }
];

export const MOCK_EVENTS: SystemEvent[] = [
  { id: 'EVT-9021', timestamp: '2026-10-27 09:32:14 UTC', eventType: 'OrderCreated', source: 'Kiosk-04', entityId: 'US-1024', actor: 'Customer-App', description: 'Digital order #8921 processed ($24.50) via Kiosk-04', severity: 'INFO' },
  { id: 'EVT-9020', timestamp: '2026-10-27 09:28:05 UTC', eventType: 'EquipmentFailure', source: 'Telemetry-Node', entityId: 'US-1024', actor: 'Sensor-Fryer2', description: 'Fryer 2 heating element efficiency dropped below threshold (82%)', severity: 'WARNING' },
  { id: 'EVT-9019', timestamp: '2026-10-27 09:15:00 UTC', eventType: 'InventoryLow', source: 'StockManager', entityId: 'US-1025', actor: 'Automated-Replenishment', description: '10:1 Beef Patties stock level at 18% - Auto-PO generated to Martin-Brower DC', severity: 'WARNING' },
  { id: 'EVT-9018', timestamp: '2026-10-27 08:00:00 UTC', eventType: 'RoyaltyCalculated', source: 'RoyaltyEngine', entityId: 'FRAN-1042', actor: 'System-Cron', description: 'Weekly royalty ($34,680) calculated & queued for ACH debit', severity: 'INFO' },
  { id: 'EVT-9017', timestamp: '2026-10-27 07:30:12 UTC', eventType: 'ShiftStarted', source: 'TimeClock', entityId: 'US-1024', actor: 'Manager-DavidR', description: 'Breakfast to Lunch transition shift opened with 14 crew members on line', severity: 'INFO' }
];

export const GLOBAL_SUMMARY_METRICS: GlobalKPIs = {
  systemwideSales: 134.8, // $134.8 Billion
  revenue: 26.2, // $26.2 Billion Corporate Revenue
  franchiseRevenue: 15.8, // $15.8 Billion Franchise Royalties & Rent
  restaurantCount: 46280,
  franchisedRatio: 0.952, // 95.2%
  comparableSalesGrowth: 5.4,
  guestCountMillions: 69.4,
  averageCheckUSD: 11.85,
  digitalMixPercent: 44.2,
  loyaltyActiveUsersMillions: 218.4,
  restaurantProfitabilityMargin: 20.4,
  laborCostPercent: 27.8,
  foodCostPercent: 30.9,
  supplyAvailabilityPercent: 99.4,
  openExceptionsCount: 142
};
