'use client';

import React from 'react';
import { MOCK_SUPPLIERS, Supplier } from '@/lib/mock-data';
import { Truck, CheckCircle2, ShieldAlert, Package, FileText, AlertCircle } from 'lucide-react';

export function SupplierView() {
  return (
    <div className="space-y-6 pb-12">
      {/* Supplier Portal Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-xl">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">Global Supplier & Distribution Portal</h1>
              <p className="text-xs text-slate-400 mt-0.5">
                First-class integration connecting primary manufacturers, logistics networks, and distribution centers directly to 46,280 restaurants.
              </p>
            </div>
          </div>
          <span className="text-xs font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 px-3 py-1 rounded font-bold">
            NETWORK FULFILLMENT: 99.4%
          </span>
        </div>

        {/* Supplier Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {MOCK_SUPPLIERS.map(sup => (
            <div key={sup.id} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono text-amber-400 uppercase">{sup.id} · {sup.category}</span>
                  <h3 className="text-sm font-bold text-white mt-0.5">{sup.companyName}</h3>
                </div>
                <span className={`px-2 py-0.5 text-[10px] font-mono font-bold rounded ${
                  sup.riskLevel === 'LOW' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                  'bg-amber-950 text-amber-400 border border-amber-800'
                }`}>
                  {sup.riskLevel} RISK
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono text-slate-300 pt-2 border-t border-slate-900">
                <div>
                  <span className="text-[10px] text-slate-400 block">Fulfillment</span>
                  <span className="text-emerald-400 font-bold">{sup.fulfillmentRatePercent}%</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Quality Score</span>
                  <span className="text-white font-bold">{sup.qualityComplianceScore}%</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Open POs</span>
                  <span className="text-amber-400 font-bold">{sup.openPurchaseOrders} Active</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Primary DC</span>
                  <span className="text-slate-300 font-sans truncate block">{sup.primaryDistributionCenter}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
