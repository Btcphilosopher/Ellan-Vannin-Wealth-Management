'use client';

import React, { useState } from 'react';
import { MOCK_MARKETS, MOCK_FRANCHISEES, MOCK_RESTAURANTS, MOCK_EVENTS, Restaurant } from '@/lib/mock-data';
import { X, Layers, ChevronRight, Globe, Building2, Users, Store, Clock, Activity, CheckCircle2 } from 'lucide-react';

interface DrilldownModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRestaurant: (store: Restaurant) => void;
}

export function DrilldownModal({ isOpen, onClose, onSelectRestaurant }: DrilldownModalProps) {
  const [selectedMarketId, setSelectedMarketId] = useState('MKT-US');
  const [selectedFranchiseeId, setSelectedFranchiseeId] = useState('FRAN-1042');
  const [selectedStoreId, setSelectedStoreId] = useState('US-1024');

  if (!isOpen) return null;

  const currentMarket = MOCK_MARKETS.find(m => m.id === selectedMarketId) || MOCK_MARKETS[0];
  const marketFranchisees = MOCK_FRANCHISEES.filter(f => f.marketId === selectedMarketId);
  const currentFranchisee = MOCK_FRANCHISEES.find(f => f.id === selectedFranchiseeId) || marketFranchisees[0] || MOCK_FRANCHISEES[0];
  const franchiseeStores = MOCK_RESTAURANTS.filter(r => r.franchiseeId === currentFranchisee?.id);
  const currentStore = MOCK_RESTAURANTS.find(r => r.id === selectedStoreId) || franchiseeStores[0] || MOCK_RESTAURANTS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-500" />
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight uppercase">
                6-Tier System Hierarchy Explorer
              </h2>
              <p className="text-[10px] text-slate-400 font-mono">
                COMPANY → SEGMENT → MARKET → FRANCHISEE → RESTAURANT → SHIFT & EVENT
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-md hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 6 Columns Hierarchy Browser */}
        <div className="grid grid-cols-1 md:grid-cols-5 divide-y md:divide-y-0 md:divide-x divide-slate-800 flex-1 overflow-y-auto text-xs font-mono">
          
          {/* Tier 1 & 2: Markets */}
          <div className="p-3 space-y-2 bg-slate-950/50">
            <span className="text-[10px] text-slate-500 uppercase font-bold block flex items-center gap-1">
              <Globe className="w-3 h-3 text-amber-400" /> Tier 1: Markets
            </span>
            <div className="space-y-1">
              {MOCK_MARKETS.map(m => (
                <button
                  key={m.id}
                  onClick={() => {
                    setSelectedMarketId(m.id);
                    const firstFran = MOCK_FRANCHISEES.find(f => f.marketId === m.id);
                    if (firstFran) setSelectedFranchiseeId(firstFran.id);
                  }}
                  className={`w-full text-left p-2 rounded transition-colors flex items-center justify-between ${
                    m.id === selectedMarketId ? 'bg-amber-500/20 text-amber-400 font-bold border border-amber-500/40' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span className="truncate">{m.name}</span>
                  <ChevronRight className="w-3 h-3 text-slate-500 shrink-0" />
                </button>
              ))}
            </div>
          </div>

          {/* Tier 3: Franchisees */}
          <div className="p-3 space-y-2 bg-slate-950/30">
            <span className="text-[10px] text-slate-500 uppercase font-bold block flex items-center gap-1">
              <Users className="w-3 h-3 text-amber-400" /> Tier 2: Franchisee
            </span>
            <div className="space-y-1">
              {marketFranchisees.length > 0 ? (
                marketFranchisees.map(f => (
                  <button
                    key={f.id}
                    onClick={() => {
                      setSelectedFranchiseeId(f.id);
                      const firstStore = MOCK_RESTAURANTS.find(r => r.franchiseeId === f.id);
                      if (firstStore) setSelectedStoreId(firstStore.id);
                    }}
                    className={`w-full text-left p-2 rounded transition-colors flex items-center justify-between ${
                      f.id === selectedFranchiseeId ? 'bg-amber-500/20 text-amber-400 font-bold border border-amber-500/40' : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span className="truncate">{f.legalEntityName}</span>
                    <ChevronRight className="w-3 h-3 text-slate-500 shrink-0" />
                  </button>
                ))
              ) : (
                <div className="text-slate-500 p-2 italic text-[11px]">Developmental Licensee Market</div>
              )}
            </div>
          </div>

          {/* Tier 4: Restaurants */}
          <div className="p-3 space-y-2 bg-slate-950/50">
            <span className="text-[10px] text-slate-500 uppercase font-bold block flex items-center gap-1">
              <Store className="w-3 h-3 text-amber-400" /> Tier 3: Restaurant
            </span>
            <div className="space-y-1">
              {franchiseeStores.map(r => (
                <button
                  key={r.id}
                  onClick={() => setSelectedStoreId(r.id)}
                  className={`w-full text-left p-2 rounded transition-colors flex items-center justify-between ${
                    r.id === selectedStoreId ? 'bg-amber-500/20 text-amber-400 font-bold border border-amber-500/40' : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span className="truncate">{r.name}</span>
                  <ChevronRight className="w-3 h-3 text-slate-500 shrink-0" />
                </button>
              ))}
            </div>
          </div>

          {/* Tier 5 & 6: Shift & Events Details (2 cols) */}
          <div className="md:col-span-2 p-4 bg-slate-900 space-y-3">
            <span className="text-[10px] text-slate-500 uppercase font-bold block flex items-center gap-1">
              <Clock className="w-3 h-3 text-emerald-400" /> Tier 4 & 5: Live Shift & Telemetry Events
            </span>

            {currentStore && (
              <div className="space-y-3 bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="font-bold text-white font-sans">{currentStore.name}</span>
                  <span className="text-emerald-400 font-bold">${currentStore.todaySalesUSD.toLocaleString()} Sales</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-slate-500 block">Format:</span>
                    <span className="text-slate-200">{currentStore.format}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Drive-Thru Speed:</span>
                    <span className="text-emerald-400 font-bold">{currentStore.driveThruAvgTimeSeconds}s</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-900 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Recent Shift Events:</span>
                  {MOCK_EVENTS.slice(0, 2).map(e => (
                    <div key={e.id} className="text-[11px] p-2 bg-slate-900 rounded border border-slate-800 text-slate-300">
                      <span className="text-amber-400 font-bold block">{e.eventType} · {e.timestamp}</span>
                      <span>{e.description}</span>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => {
                    onSelectRestaurant(currentStore);
                    onClose();
                  }}
                  className="w-full py-2 bg-amber-500 text-slate-950 font-bold rounded-lg hover:bg-amber-400 transition-colors text-center font-sans"
                >
                  Jump directly to {currentStore.id} Digital Twin
                </button>
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
