'use client';

import React from 'react';
import { Building2, Store, Users, Truck, Cpu, Bot, ChevronRight, Layers, HelpCircle } from 'lucide-react';

export type UserRole = 'CORPORATE' | 'FRANCHISEE' | 'RESTAURANT' | 'SUPPLIER' | 'MCSIM';

interface HeaderProps {
  currentRole: UserRole;
  onSelectRole: (role: UserRole) => void;
  onOpenCopilot: () => void;
  onOpenDrilldown: () => void;
  selectedBreadcrumbPath?: string[];
}

export function Header({
  currentRole,
  onSelectRole,
  onOpenCopilot,
  onOpenDrilldown,
  selectedBreadcrumbPath = ['Global Corporation', 'US Market', 'Apex Franchise Group', 'Store #1024']
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-[#0F172A]/95 backdrop-blur-md border-b border-slate-800 text-slate-100">
      {/* Top Bar Contract - 3 Zones */}
      <div className="max-w-[1700px] mx-auto px-4 h-14 flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded-md bg-amber-500 text-slate-950 font-black flex items-center justify-center text-lg tracking-tighter shadow-sm">
            Mc
          </div>
          <div className="flex flex-col">
            <span className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0">
              McSOFTWARE
            </span>
            <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
              Enterprise Operating System
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links (5 Roles / Views) */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-900/80 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => onSelectRole('CORPORATE')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
              currentRole === 'CORPORATE'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            Corporate HQ
          </button>

          <button
            onClick={() => onSelectRole('FRANCHISEE')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
              currentRole === 'FRANCHISEE'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            Franchisee 360
          </button>

          <button
            onClick={() => onSelectRole('RESTAURANT')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
              currentRole === 'RESTAURANT'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            Restaurant Today
          </button>

          <button
            onClick={() => onSelectRole('SUPPLIER')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
              currentRole === 'SUPPLIER'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            Supplier Network
          </button>

          <button
            onClick={() => onSelectRole('MCSIM')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
              currentRole === 'MCSIM'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            McSIM Engine
          </button>
        </nav>

        {/* Zone 3: Primary Action & AI Copilot */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenDrilldown}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono bg-slate-900 border border-slate-700 rounded-md text-slate-300 hover:border-slate-500 hover:text-white transition-colors"
            title="Drill down system hierarchy"
          >
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            <span>Hierarchy Explorer</span>
          </button>

          <button
            onClick={onOpenCopilot}
            className="px-3 py-1.5 text-xs font-bold bg-amber-500 text-slate-950 rounded-md hover:bg-amber-400 transition-colors flex items-center gap-2 shadow-sm whitespace-nowrap shrink-0"
          >
            <Bot className="w-4 h-4" />
            <span>AI Copilot</span>
          </button>
        </div>

      </div>

      {/* Sub-bar: Global Hierarchy Breadcrumbs */}
      <div className="bg-slate-900/60 border-t border-slate-800/80 px-4 py-1 text-[11px] font-mono text-slate-400 flex items-center justify-between overflow-x-auto">
        <div className="flex items-center gap-1.5 whitespace-nowrap">
          <span className="text-slate-500">HIERARCHY SCOPE:</span>
          {selectedBreadcrumbPath.map((item, idx) => (
            <React.Fragment key={idx}>
              {idx > 0 && <ChevronRight className="w-3 h-3 text-slate-600" />}
              <span className={idx === selectedBreadcrumbPath.length - 1 ? "text-amber-400 font-semibold" : "text-slate-300"}>
                {item}
              </span>
            </React.Fragment>
          ))}
        </div>
        <div className="hidden md:flex items-center gap-4 text-slate-400">
          <span>MODE: <strong className="text-emerald-400 font-sans">LIVE SYSTEM</strong></span>
          <span>STORES: <strong className="text-slate-200">46,280 ACTIVE</strong></span>
          <span>ISOLATION: <strong className="text-amber-400 font-sans">ENFORCED</strong></span>
        </div>
      </div>
    </header>
  );
}
