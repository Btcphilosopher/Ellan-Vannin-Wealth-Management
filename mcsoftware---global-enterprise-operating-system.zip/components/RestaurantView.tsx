'use client';

import React, { useState } from 'react';
import { Restaurant, MOCK_RESTAURANTS } from '@/lib/mock-data';
import { Store, Clock, Zap, AlertTriangle, CheckCircle2, Flame, Thermometer, Layers, Users, Truck, ArrowRight, ShieldAlert } from 'lucide-react';

interface RestaurantViewProps {
  selectedStore?: Restaurant;
  onSelectStoreById?: (id: string) => void;
}

export function RestaurantView({ selectedStore, onSelectStoreById }: RestaurantViewProps) {
  const store = selectedStore || MOCK_RESTAURANTS[0];

  return (
    <div className="space-y-6 pb-12">
      {/* Restaurant Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-xl">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-white tracking-tight">{store.name}</h1>
                <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800 rounded uppercase">
                  {store.status}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                ID: <span className="font-mono text-amber-400">{store.id}</span> · Format: <span className="text-slate-200">{store.format.replace(/_/g, ' ')}</span> · Franchisee: <span className="text-slate-200">{store.franchiseeName}</span>
              </p>
            </div>
          </div>

          {/* Restaurant Selector */}
          <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-lg border border-slate-800">
            <span className="text-xs text-slate-400 font-mono">SELECT STORE:</span>
            <select
              value={store.id}
              onChange={e => onSelectStoreById && onSelectStoreById(e.target.value)}
              className="bg-slate-900 text-xs text-white border border-slate-700 rounded px-2 py-1 focus:outline-none focus:border-amber-500"
            >
              {MOCK_RESTAURANTS.map(r => (
                <option key={r.id} value={r.id}>
                  {r.name} ({r.id})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Today's Live Shift Telemetry */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-3 pt-4">
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Today&apos;s Sales</span>
            <div className="text-lg font-bold font-mono text-white mt-0.5">${store.todaySalesUSD.toLocaleString()}</div>
            <span className="text-[10px] text-slate-400 block mt-0.5">{store.todayOrderCount} orders today</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Drive-Thru Time</span>
            <div className="text-lg font-bold font-mono text-emerald-400 mt-0.5">{store.driveThruAvgTimeSeconds}s</div>
            <span className="text-[10px] text-slate-400 block mt-0.5">Target: &lt;210s</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Kitchen Flow</span>
            <div className="text-lg font-bold font-mono text-amber-400 mt-0.5">{store.kitchenThroughputOrdersPerHour} /hr</div>
            <span className="text-[10px] text-slate-400 block mt-0.5">Orders per hour</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Digital Mix</span>
            <div className="text-lg font-bold font-mono text-white mt-0.5">{store.digitalMixPercent}%</div>
            <span className="text-[10px] text-slate-400 block mt-0.5">Kiosk + App</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Labor Hours</span>
            <div className="text-lg font-bold font-mono text-white mt-0.5">{store.laborHoursActual} hrs</div>
            <span className="text-[10px] text-slate-400 block mt-0.5">Sched: {store.laborHoursScheduled} hrs</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Food Waste</span>
            <div className="text-lg font-bold font-mono text-emerald-400 mt-0.5">${store.wasteCostUSD}</div>
            <span className="text-[10px] text-slate-400 block mt-0.5">1.0% of Sales</span>
          </div>
        </div>
      </div>

      {/* Restaurant Digital Twin Canvas */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-500" />
              Live Restaurant Digital Twin
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Edge node telemetry streaming real-time status from Kitchen, Fryers, Freezers, Drive-Thru, Kiosks, and Delivery.
            </p>
          </div>
          <span className="text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded">
            EDGE SYNC ACTIVE
          </span>
        </div>

        {/* Digital Twin Layout Map */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          
          {/* Kitchen & Cooking Line */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-900 pb-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-amber-500" /> Kitchen Cooking Line
              </span>
              <span className="text-[10px] font-mono text-slate-400">3 ASSETS</span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              {store.equipments.map(eq => (
                <div key={eq.id} className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-white font-bold">{eq.name}</span>
                    <span className={`px-2 py-0.5 text-[9px] rounded font-bold ${
                      eq.status === 'NORMAL' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                      'bg-amber-950 text-amber-400 border border-amber-800'
                    }`}>
                      {eq.status}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                    <span>Temp: <strong className="text-white">{eq.temperatureC ?? 'N/A'}°C</strong></span>
                    <span>Risk: <strong className={eq.predictedFailureRisk === 'LOW' ? 'text-emerald-400' : 'text-amber-400'}>{eq.predictedFailureRisk}</strong></span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Drive-Thru & Kiosk Front Counter */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-900 pb-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-emerald-400" /> Drive-Thru & Kiosks
              </span>
              <span className="text-[10px] font-mono text-slate-400">LANE 1 & 2</span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-white font-bold">Drive-Thru Lane 1</span>
                  <span className="text-emerald-400 font-bold">4 Cars in Queue</span>
                </div>
                <p className="text-[10px] text-slate-400">Average Service Time: 3m 42s (Nominal)</p>
              </div>

              <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-white font-bold">Kiosk Bank (6 Units)</span>
                  <span className="text-emerald-400 font-bold">6/6 ONLINE</span>
                </div>
                <p className="text-[10px] text-slate-400">Digital Order Throughput: 68.4% total mix</p>
              </div>
            </div>
          </div>

          {/* Manager Prioritized Shift Actions */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-900 pb-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-amber-400" /> Manager Prioritized Actions
              </span>
              <span className="text-[10px] font-mono text-amber-400">4 PENDING</span>
            </div>

            <div className="space-y-2 text-xs font-sans">
              <div className="p-2.5 bg-amber-950/40 border border-amber-800/60 rounded-lg space-y-1">
                <div className="flex items-center justify-between text-amber-400 font-bold">
                  <span>1. Fryer 2 Maintenance Alert</span>
                  <span className="text-[10px] font-mono bg-amber-900 px-1.5 py-0.5 rounded text-amber-200">MEDIUM</span>
                </div>
                <p className="text-slate-300 text-[11px]">Efficiency dropped to 82%. Schedule technician inspection within 12 days.</p>
              </div>

              <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg space-y-1">
                <div className="flex items-center justify-between text-white font-bold">
                  <span>2. Inventory Replenishment</span>
                  <span className="text-[10px] font-mono text-slate-400">AUTOMATED</span>
                </div>
                <p className="text-slate-300 text-[11px]">10:1 Beef Patties auto-replenishment PO generated to Martin-Brower DC.</p>
              </div>

              <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg space-y-1">
                <div className="flex items-center justify-between text-white font-bold">
                  <span>3. Lunch Peak Staffing</span>
                  <span className="text-[10px] font-mono text-emerald-400">OPTIMIZED</span>
                </div>
                <p className="text-slate-300 text-[11px]">14 crew members scheduled on line for 11:30 - 14:00 demand surge.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
