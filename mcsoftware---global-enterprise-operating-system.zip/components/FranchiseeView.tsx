'use client';

import React, { useState } from 'react';
import { MOCK_FRANCHISEES, MOCK_RESTAURANTS, Franchisee, Restaurant } from '@/lib/mock-data';
import { Users, Store, TrendingUp, DollarSign, FileText, CheckCircle2, ShieldCheck, AlertCircle, ArrowUpRight, BarChart3, HelpCircle } from 'lucide-react';

interface FranchiseeViewProps {
  onSelectRestaurant: (store: Restaurant) => void;
}

export function FranchiseeView({ onSelectRestaurant }: FranchiseeViewProps) {
  const [selectedFranchiseeId, setSelectedFranchiseeId] = useState<string>('FRAN-1042');
  const franchisee = MOCK_FRANCHISEES.find(f => f.id === selectedFranchiseeId) || MOCK_FRANCHISEES[0];
  const franchiseeStores = MOCK_RESTAURANTS.filter(r => r.franchiseeId === franchisee.id);

  return (
    <div className="space-y-6 pb-12">
      {/* Franchisee Master Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-xl">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-white tracking-tight">{franchisee.legalEntityName}</h1>
                <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800 rounded">
                  {franchisee.riskStatus}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Owner Operator: <strong className="text-slate-200">{franchisee.ownerName}</strong> · Territory: <strong className="text-slate-200">{franchisee.territory}</strong> · ID: <span className="font-mono text-amber-400">{franchisee.id}</span>
              </p>
            </div>
          </div>

          {/* Franchisee Selector (Simulating logged-in Franchisee) */}
          <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-lg border border-slate-800">
            <span className="text-xs text-slate-400 font-mono">SELECT FRANCHISEE:</span>
            <select
              value={selectedFranchiseeId}
              onChange={e => setSelectedFranchiseeId(e.target.value)}
              className="bg-slate-900 text-xs text-white border border-slate-700 rounded px-2 py-1 focus:outline-none focus:border-amber-500"
            >
              {MOCK_FRANCHISEES.map(f => (
                <option key={f.id} value={f.id}>
                  {f.legalEntityName} ({f.ownerName})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Top Business Stat Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Operating Stores</span>
            <div className="text-xl font-bold text-white font-mono mt-0.5">{franchisee.restaurantCount}</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">{franchisee.marketName}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Annual Sales</span>
            <div className="text-xl font-bold text-amber-400 font-mono mt-0.5">${franchisee.annualSystemSalesUSD}M</div>
            <span className="text-[10px] text-emerald-400 flex items-center gap-0.5 mt-0.5">
              <TrendingUp className="w-2.5 h-2.5" /> +{franchisee.compSalesGrowth}% Comp
            </span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Operating Margin</span>
            <div className="text-xl font-bold text-emerald-400 font-mono mt-0.5">{franchisee.operatingMarginPercent}%</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Vs 19.8% Market Peer</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Support Tickets</span>
            <div className="text-xl font-bold text-white font-mono mt-0.5">{franchisee.supportCasesOpen} Open</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Last Visit: {franchisee.lastVisitDate}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono text-slate-400 uppercase">Field Audit Score</span>
            <div className="text-xl font-bold text-white font-mono mt-0.5">{franchisee.lastVisitScore}%</div>
            <span className="text-[10px] text-emerald-400 mt-0.5 block">PASS · Grade A</span>
          </div>
        </div>
      </div>

      {/* Franchisee Portfolio & Restaurant Financial Breakdown */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Store className="w-4 h-4 text-amber-500" />
              Franchisee Restaurant Portfolio Economics
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Individual store P&L economics, sales, labor, food costs, royalties, and net margins.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3 font-sans">Restaurant Name</th>
                <th className="py-2.5 px-3 text-right">Monthly Sales</th>
                <th className="py-2.5 px-3 text-right">Labor Cost</th>
                <th className="py-2.5 px-3 text-right">Food Cost</th>
                <th className="py-2.5 px-3 text-right">Royalty (4%)</th>
                <th className="py-2.5 px-3 text-right">Rent Payable</th>
                <th className="py-2.5 px-3 text-right">Net Margin</th>
                <th className="py-2.5 px-3 text-center font-sans">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-200">
              {franchiseeStores.map(store => (
                <tr key={store.id} className="hover:bg-slate-800/50 transition-colors">
                  <td className="py-3 px-3 font-sans font-bold text-white">
                    {store.name}
                    <span className="block text-[10px] font-mono text-slate-400 font-normal">{store.id} · {store.city}</span>
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-amber-400 font-bold">
                    ${store.monthlySalesUSD.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-300">
                    ${(store.monthlySalesUSD * 0.28).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-300">
                    ${(store.monthlySalesUSD * 0.31).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-300">
                    ${store.royaltyPayableUSD.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-300">
                    ${store.rentPayableUSD.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums text-emerald-400 font-bold">
                    {store.netMarginPercent}%
                  </td>
                  <td className="py-3 px-3 text-center">
                    <button
                      onClick={() => onSelectRestaurant(store)}
                      className="px-2.5 py-1 text-[11px] font-sans font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded hover:bg-amber-500 hover:text-slate-950 transition-colors"
                    >
                      Open Twin
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Franchise Agreements & Commercial Price Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Franchise Agreements & Lease Terms */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="pb-2 border-b border-slate-800">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-500" />
              Active Franchise Agreements & Terms
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Contract terms, royalty commitments, lease structures, and renewal dates.
            </p>
          </div>

          <div className="space-y-3">
            {franchisee.agreements.map(agr => (
              <div key={agr.id} className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2">
                <div className="flex items-center justify-between font-mono text-xs">
                  <span className="text-amber-400 font-bold">{agr.restaurantName}</span>
                  <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 rounded border border-emerald-800 text-[10px]">
                    {agr.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono text-slate-300 pt-1 border-t border-slate-900">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Royalty Rate</span>
                    <span className="text-white font-bold">{agr.royaltyRatePercent}% of Net Sales</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Rent Type</span>
                    <span className="text-white font-bold">{agr.rentType} ({agr.rentRatePercent}%)</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Expiration Date</span>
                    <span className="text-slate-200">{agr.expirationDate}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Capital Commitment</span>
                    <span className="text-amber-400 font-bold">${agr.capitalCommitmentUSD.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Local Commercial Settings & Independent Pricing */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="pb-2 border-b border-slate-800">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              Local Menu Pricing & Commercial Settings
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Franchisees independently set restaurant menu prices. Corporate provides recommendations.
            </p>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-white font-bold block font-sans">Big Mac Extra Value Meal</span>
                <span className="text-[10px] text-slate-400">Market Rec: $9.89 · Store Actual: $10.29</span>
              </div>
              <span className="px-2 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded font-bold">
                Franchisee Set
              </span>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-white font-bold block font-sans">10-pc Chicken McNuggets Meal</span>
                <span className="text-[10px] text-slate-400">Market Rec: $10.49 · Store Actual: $10.49</span>
              </div>
              <span className="px-2 py-1 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded font-bold">
                Aligned
              </span>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-white font-bold block font-sans">Egg McMuffin Meal (Breakfast)</span>
                <span className="text-[10px] text-slate-400">Market Rec: $7.29 · Store Actual: $7.49</span>
              </div>
              <span className="px-2 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded font-bold">
                Franchisee Set
              </span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
