'use client';

import React, { useState } from 'react';
import { GLOBAL_SUMMARY_METRICS, MOCK_MARKETS, MOCK_FRANCHISEES, MOCK_RESTAURANTS, MOCK_EVENTS, Restaurant } from '@/lib/mock-data';
import { Globe, DollarSign, Store, TrendingUp, Users, ShieldAlert, Activity, CheckCircle2, AlertTriangle, ArrowUpRight, Search, FileText, ChevronRight } from 'lucide-react';

interface CorporateHQViewProps {
  onSelectRestaurant: (store: Restaurant) => void;
  onOpenDrilldown: () => void;
}

export function CorporateHQView({ onSelectRestaurant, onOpenDrilldown }: CorporateHQViewProps) {
  const [selectedSegment, setSelectedSegment] = useState<'ALL' | 'US' | 'INTL_OPERATED' | 'INTL_DEV'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [restaurantStatusFilter, setRestaurantStatusFilter] = useState<'ALL' | 'OPEN' | 'REMODELLING' | 'UNDER_CONSTRUCTION'>('ALL');

  const filteredMarkets = MOCK_MARKETS.filter(m => {
    if (selectedSegment === 'US') return m.segment === 'US';
    if (selectedSegment === 'INTL_OPERATED') return m.segment === 'International Operated';
    if (selectedSegment === 'INTL_DEV') return m.segment === 'International Developmental Licensee';
    return true;
  });

  const filteredRestaurants = MOCK_RESTAURANTS.filter(r => {
    const matchesSearch = r.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          r.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          r.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = restaurantStatusFilter === 'ALL' || r.status === restaurantStatusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Executive Command Centre Header & Segment Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              <Globe className="w-5 h-5 text-amber-500" />
              Global Executive Command Centre
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Systemwide real-time operational telemetry across 46,280 global restaurants and 218.4M active loyalty members.
            </p>
          </div>

          {/* Interactive Segment Filter Buttons */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 self-start md:self-auto">
            <button
              onClick={() => setSelectedSegment('ALL')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                selectedSegment === 'ALL' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              All Global Markets
            </button>
            <button
              onClick={() => setSelectedSegment('US')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                selectedSegment === 'US' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              U.S. Market
            </button>
            <button
              onClick={() => setSelectedSegment('INTL_OPERATED')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                selectedSegment === 'INTL_OPERATED' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Int&apos;l Operated
            </button>
            <button
              onClick={() => setSelectedSegment('INTL_DEV')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                selectedSegment === 'INTL_DEV' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Developmental Licensees
            </button>
          </div>
        </div>

        {/* 8 Primary Executive Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 pt-4">
          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Systemwide Sales</span>
            <div className="text-lg font-bold font-mono text-white mt-0.5">${GLOBAL_SUMMARY_METRICS.systemwideSales}B</div>
            <span className="text-[10px] text-emerald-400 flex items-center gap-0.5 mt-0.5">
              <TrendingUp className="w-2.5 h-2.5" /> +5.4% YoY
            </span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Corp Revenue</span>
            <div className="text-lg font-bold font-mono text-amber-400 mt-0.5">${GLOBAL_SUMMARY_METRICS.revenue}B</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Royalties + Rent</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Franchise Revenue</span>
            <div className="text-lg font-bold font-mono text-white mt-0.5">${GLOBAL_SUMMARY_METRICS.franchiseRevenue}B</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">60.3% of Total Rev</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Restaurants</span>
            <div className="text-lg font-bold font-mono text-white mt-0.5">46,280</div>
            <span className="text-[10px] text-emerald-400 mt-0.5 block">95.2% Franchised</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Comp Sales</span>
            <div className="text-lg font-bold font-mono text-emerald-400 mt-0.5">+{GLOBAL_SUMMARY_METRICS.comparableSalesGrowth}%</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">System Avg</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Digital Mix</span>
            <div className="text-lg font-bold font-mono text-white mt-0.5">{GLOBAL_SUMMARY_METRICS.digitalMixPercent}%</div>
            <span className="text-[10px] text-amber-400 mt-0.5 block">App + Kiosk</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Loyalty Active</span>
            <div className="text-lg font-bold font-mono text-white mt-0.5">{GLOBAL_SUMMARY_METRICS.loyaltyActiveUsersMillions}M</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">70 Markets</span>
          </div>

          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800">
            <span className="text-[10px] font-mono uppercase text-slate-400">Supply Avail.</span>
            <div className="text-lg font-bold font-mono text-emerald-400 mt-0.5">{GLOBAL_SUMMARY_METRICS.supplyAvailabilityPercent}%</div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">{GLOBAL_SUMMARY_METRICS.openExceptionsCount} Exceptions</span>
          </div>
        </div>
      </div>

      {/* Main Grid Layout: Markets Table & Global Hierarchy */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Markets Performance Matrix (2 cols) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-amber-500" />
              Global Market Performance Matrix
            </h2>
            <button 
              onClick={onOpenDrilldown}
              className="text-xs text-amber-400 hover:underline flex items-center gap-1 font-mono"
            >
              Hierarchy Drilldown <ChevronRight className="w-3 h-3" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px]">
                  <th className="py-2.5 px-3">Market</th>
                  <th className="py-2.5 px-3">Segment</th>
                  <th className="py-2.5 px-3 text-right">Stores</th>
                  <th className="py-2.5 px-3 text-right">System Sales</th>
                  <th className="py-2.5 px-3 text-right">Comp Sales</th>
                  <th className="py-2.5 px-3 text-right">Compliance</th>
                  <th className="py-2.5 px-3">Lead Executive</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {filteredMarkets.map(m => (
                  <tr key={m.id} className="hover:bg-slate-800/50 transition-colors font-mono">
                    <td className="py-3 px-3 font-semibold font-sans text-white">
                      {m.name}
                    </td>
                    <td className="py-3 px-3 text-slate-400 text-[11px] font-sans">
                      {m.segment}
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums">
                      {m.restaurantCount.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums font-semibold text-amber-400">
                      ${m.systemSalesUSD.toLocaleString()}M
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums text-emerald-400 font-semibold">
                      +{m.compSalesGrowth}%
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums text-slate-300">
                      {m.complianceScore}%
                    </td>
                    <td className="py-3 px-3 font-sans text-slate-300">
                      {m.leadExecutive}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Global Event Bus & Audit Trail (1 col) */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-emerald-400" />
              Global Event Bus Telemetry
            </h2>
            <span className="text-[10px] font-mono bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded border border-emerald-800">
              STREAMING
            </span>
          </div>

          <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
            {MOCK_EVENTS.map(evt => (
              <div key={evt.id} className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 space-y-1.5">
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className={`px-1.5 py-0.5 rounded ${
                    evt.severity === 'CRITICAL' ? 'bg-red-950 text-red-400 border border-red-800' :
                    evt.severity === 'WARNING' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                    'bg-slate-800 text-slate-300'
                  }`}>
                    {evt.eventType}
                  </span>
                  <span className="text-slate-400">{evt.timestamp}</span>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed font-sans">{evt.description}</p>
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1 border-t border-slate-900">
                  <span>SOURCE: {evt.source}</span>
                  <span>ACTOR: {evt.actor}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Global Restaurant Network Explorer & Digital Twins */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Store className="w-4 h-4 text-amber-500" />
              Global Restaurant Network Explorer
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Click any restaurant to view its live Digital Twin, sales, drive-thru telemetry, and equipment status.
            </p>
          </div>

          {/* Search & Status Filters */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search store name, ID, or city..."
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 w-60"
              />
            </div>

            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
              <button
                onClick={() => setRestaurantStatusFilter('ALL')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  restaurantStatusFilter === 'ALL' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
                }`}
              >
                All Statuses
              </button>
              <button
                onClick={() => setRestaurantStatusFilter('OPEN')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  restaurantStatusFilter === 'OPEN' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
                }`}
              >
                Open
              </button>
              <button
                onClick={() => setRestaurantStatusFilter('REMODELLING')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  restaurantStatusFilter === 'REMODELLING' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
                }`}
              >
                Remodelling
              </button>
            </div>
          </div>
        </div>

        {/* Restaurant Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {filteredRestaurants.map(store => (
            <div
              key={store.id}
              onClick={() => onSelectRestaurant(store)}
              className="bg-slate-950 p-4 rounded-xl border border-slate-800 hover:border-amber-500/80 cursor-pointer transition-all hover:scale-[1.01] group space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono text-amber-400 uppercase tracking-wider">{store.id} · {store.format.replace(/_/g, ' ')}</span>
                  <h3 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors mt-0.5">{store.name}</h3>
                  <p className="text-xs text-slate-400">{store.address}</p>
                </div>
                <span className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                  {store.status}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-900 text-xs font-mono">
                <div>
                  <span className="text-[10px] text-slate-400 block">Today&apos;s Sales</span>
                  <span className="text-white font-bold">${store.todaySalesUSD.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Drive-Thru Time</span>
                  <span className="text-emerald-400 font-bold">{store.driveThruAvgTimeSeconds}s</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Franchisee</span>
                  <span className="text-slate-300 font-sans truncate block">{store.franchiseeName}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Digital Mix</span>
                  <span className="text-amber-400 font-bold">{store.digitalMixPercent}%</span>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] text-amber-400 font-semibold pt-1">
                <span>View Store Digital Twin</span>
                <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
