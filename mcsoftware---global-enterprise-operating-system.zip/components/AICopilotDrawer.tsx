'use client';

import React, { useState } from 'react';
import { UserRole } from './Header';
import { Bot, X, Send, Sparkles, Building2, Users, Store, CheckCircle2, ShieldCheck } from 'lucide-react';

interface AICopilotDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: UserRole;
  selectedEntityId?: string;
}

export function AICopilotDrawer({ isOpen, onClose, currentRole, selectedEntityId }: AICopilotDrawerProps) {
  const [persona, setPersona] = useState<'CORPORATE' | 'FRANCHISEE' | 'RESTAURANT'>(
    currentRole === 'FRANCHISEE' ? 'FRANCHISEE' : currentRole === 'RESTAURANT' ? 'RESTAURANT' : 'CORPORATE'
  );

  const [promptInput, setPromptInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string; timestamp: string }>>([
    {
      role: 'assistant',
      text: persona === 'CORPORATE'
        ? "Welcome to the Corporate AI Copilot. I have real-time visibility across all 46,280 global restaurants, supply chains, and market P&Ls. How can I assist executive operations?"
        : persona === 'FRANCHISEE'
        ? "Welcome to your Franchisee AI Assistant. I am sandboxed to your specific business entity, restaurant P&Ls, and equipment telemetry. How can I assist your business today?"
        : "Welcome to the Restaurant Shift Assistant. What priority actions or equipment statuses do you need checked on shift?",
      timestamp: new Date().toLocaleTimeString()
    }
  ]);

  if (!isOpen) return null;

  const handleSendPrompt = async (promptToSend?: string) => {
    const text = promptToSend || promptInput;
    if (!text.trim() || loading) return;

    const userMsg = { role: 'user' as const, text, timestamp: new Date().toLocaleTimeString() };
    setMessages(prev => [...prev, userMsg]);
    setPromptInput('');
    setLoading(true);

    try {
      const res = await fetch('/app/api/ai/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          persona,
          entityId: selectedEntityId || 'FRAN-1042'
        })
      });
      const data = await res.json();
      const botMsg = { role: 'assistant' as const, text: data.text || data.error || 'No response', timestamp: new Date().toLocaleTimeString() };
      setMessages(prev => [...prev, botMsg]);
    } catch (e: any) {
      setMessages(prev => [...prev, { role: 'assistant', text: "Failed to connect to AI Copilot service.", timestamp: new Date().toLocaleTimeString() }]);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = persona === 'CORPORATE' ? [
    "Which markets are underperforming?",
    "Show franchisee groups with rising food costs.",
    "Which equipment assets are generating the most downtime?",
    "What is our global drive-thru speed average today?"
  ] : persona === 'FRANCHISEE' ? [
    "Which of my restaurants performed best today?",
    "What is causing high waste in Store #1024?",
    "What labor level is forecast for tonight's shift?",
    "Show my rent and royalty obligations for this month."
  ] : [
    "What should I deal with first on shift today?",
    "Check Walk-in Freezer and Fryer telemetry.",
    "How is our drive-thru queue time tracking vs target?"
  ];

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border-l border-slate-800 h-full flex flex-col justify-between shadow-2xl">
        
        {/* Drawer Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
                McSOFTWARE AI Copilot
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              </h2>
              <p className="text-[10px] text-slate-400 font-mono">
                Powered by Gemini 3.8 · Grounded Enterprise Intelligence
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-md hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Persona Selector Tabs */}
        <div className="px-4 py-2 bg-slate-950/80 border-b border-slate-800 flex items-center gap-2">
          <span className="text-[10px] font-mono text-slate-500 uppercase">PERSONA:</span>
          <button
            onClick={() => setPersona('CORPORATE')}
            className={`px-2.5 py-1 text-[11px] font-mono rounded flex items-center gap-1 transition-colors ${
              persona === 'CORPORATE' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Building2 className="w-3 h-3" /> Corporate HQ
          </button>

          <button
            onClick={() => setPersona('FRANCHISEE')}
            className={`px-2.5 py-1 text-[11px] font-mono rounded flex items-center gap-1 transition-colors ${
              persona === 'FRANCHISEE' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3 h-3" /> Franchisee (Isolated)
          </button>

          <button
            onClick={() => setPersona('RESTAURANT')}
            className={`px-2.5 py-1 text-[11px] font-mono rounded flex items-center gap-1 transition-colors ${
              persona === 'RESTAURANT' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Store className="w-3 h-3" /> Shift Manager
          </button>
        </div>

        {/* Message Stream */}
        <div className="p-4 flex-1 overflow-y-auto space-y-4">
          {messages.map((m, idx) => (
            <div key={idx} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div className="flex items-center gap-1 text-[10px] text-slate-500 font-mono mb-1">
                <span>{m.role === 'user' ? 'You' : `${persona} Copilot`}</span>
                <span>·</span>
                <span>{m.timestamp}</span>
              </div>
              <div
                className={`p-3.5 rounded-xl text-xs leading-relaxed max-w-[90%] ${
                  m.role === 'user'
                    ? 'bg-amber-500 text-slate-950 font-semibold rounded-br-none'
                    : 'bg-slate-950 text-slate-200 border border-slate-800 rounded-bl-none font-sans whitespace-pre-wrap'
                }`}
              >
                {m.text}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-xs font-mono text-amber-400 p-3 bg-slate-950 rounded-lg border border-slate-800 w-fit">
              <Sparkles className="w-4 h-4 animate-spin text-amber-400" />
              <span>Querying structured enterprise data...</span>
            </div>
          )}
        </div>

        {/* Suggested Prompts & Input Box */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 space-y-3">
          <div className="flex flex-wrap gap-1.5">
            {samplePrompts.map((sp, i) => (
              <button
                key={i}
                onClick={() => handleSendPrompt(sp)}
                className="text-[10px] font-sans px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-full text-slate-300 hover:border-amber-500 hover:text-amber-400 transition-colors text-left"
              >
                &quot;{sp}&quot;
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={promptInput}
              onChange={e => setPromptInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSendPrompt()}
              placeholder={`Ask ${persona.toLowerCase()} copilot anything...`}
              className="flex-1 px-3 py-2 text-xs bg-slate-900 border border-slate-800 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
            <button
              onClick={() => handleSendPrompt()}
              disabled={loading || !promptInput.trim()}
              className="p-2 bg-amber-500 text-slate-950 font-bold rounded-lg hover:bg-amber-400 transition-colors disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
