'use client';

import React, { useState } from 'react';
import { ScenarioInput, ScenarioResult } from '@/lib/mock-data';
import { Cpu, Play, TrendingUp, AlertTriangle, CheckCircle2, RefreshCw, BarChart2, ShieldAlert } from 'lucide-react';

export function McSimEngineView() {
  const [input, setInput] = useState<ScenarioInput>({
    chickenPriceChangePct: 15,
    beefPriceChangePct: 5,
    laborCostChangePct: 8,
    trafficChangePct: 3,
    remodelCount: 500,
    promotionalLiftPct: 2
  });

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ScenarioResult | null>({
    simulatedSalesDeltaUSD: 6740,
    simulatedMarginChangeBasisPoints: -182,
    simulatedFranchiseeCashFlowUSD: -38200,
    simulatedCorporateRoyaltyUSD: 286000000,
    riskSummary: "HIGH RISK: Severe margin compression across franchisee portfolio requires strategic menu pricing adjustments.",
    recommendations: [
      "Initiate 12-month forward hedging contract with Keystone Foods for poultry supply.",
      "Accelerate Next-Gen Dual-Lane Drive-Thru Automated Order Taking (AOT) to offset labor inflation.",
      "Engage corporate treasury for franchisee low-interest remodel co-financing facility."
    ]
  });

  const runSimulation = async () => {
    setLoading(true);
    try {
      const res = await fetch('/app/api/sim/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input)
      });
      const data = await res.json();
      setResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Simulation Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-xl">
              <Cpu className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">McSIM · Business Scenario & Sensitivity Engine</h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Simulate global commodity shocks, labor inflation, promotional lifts, and store modernization campaigns on 46,280 restaurants.
              </p>
            </div>
          </div>

          <button
            onClick={runSimulation}
            disabled={loading}
            className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-lg hover:bg-amber-400 transition-colors flex items-center gap-2 shadow-sm shrink-0 disabled:opacity-50"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
            <span>Run McSIM Vector Simulation</span>
          </button>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
          
          <div className="space-y-2 bg-slate-950 p-3.5 rounded-lg border border-slate-800">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">Chicken / Poultry Price Change</span>
              <span className="text-amber-400 font-bold">{input.chickenPriceChangePct > 0 ? `+${input.chickenPriceChangePct}%` : `${input.chickenPriceChangePct}%`}</span>
            </div>
            <input
              type="range"
              min="-20"
              max="30"
              value={input.chickenPriceChangePct}
              onChange={e => setInput({ ...input, chickenPriceChangePct: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div className="space-y-2 bg-slate-950 p-3.5 rounded-lg border border-slate-800">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">Beef Price Change</span>
              <span className="text-amber-400 font-bold">{input.beefPriceChangePct > 0 ? `+${input.beefPriceChangePct}%` : `${input.beefPriceChangePct}%`}</span>
            </div>
            <input
              type="range"
              min="-20"
              max="30"
              value={input.beefPriceChangePct}
              onChange={e => setInput({ ...input, beefPriceChangePct: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div className="space-y-2 bg-slate-950 p-3.5 rounded-lg border border-slate-800">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">Labor Cost Inflation</span>
              <span className="text-amber-400 font-bold">{input.laborCostChangePct > 0 ? `+${input.laborCostChangePct}%` : `${input.laborCostChangePct}%`}</span>
            </div>
            <input
              type="range"
              min="-10"
              max="25"
              value={input.laborCostChangePct}
              onChange={e => setInput({ ...input, laborCostChangePct: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div className="space-y-2 bg-slate-950 p-3.5 rounded-lg border border-slate-800">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">System Guest Traffic Growth</span>
              <span className="text-emerald-400 font-bold">{input.trafficChangePct > 0 ? `+${input.trafficChangePct}%` : `${input.trafficChangePct}%`}</span>
            </div>
            <input
              type="range"
              min="-15"
              max="20"
              value={input.trafficChangePct}
              onChange={e => setInput({ ...input, trafficChangePct: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div className="space-y-2 bg-slate-950 p-3.5 rounded-lg border border-slate-800">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">Restaurant Remodels Planned</span>
              <span className="text-amber-400 font-bold">{input.remodelCount} Stores</span>
            </div>
            <input
              type="range"
              min="0"
              max="2000"
              step="50"
              value={input.remodelCount}
              onChange={e => setInput({ ...input, remodelCount: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div className="space-y-2 bg-slate-950 p-3.5 rounded-lg border border-slate-800">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-300">Promotional Demand Lift</span>
              <span className="text-emerald-400 font-bold">+{input.promotionalLiftPct}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="15"
              value={input.promotionalLiftPct}
              onChange={e => setInput({ ...input, promotionalLiftPct: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

        </div>
      </div>

      {/* Simulation Output Dashboard */}
      {result && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="pb-3 border-b border-slate-800 flex items-center justify-between">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-amber-500" />
              Simulated System Economic Results
            </h2>
            <span className="text-[10px] font-mono text-amber-400 bg-amber-950 border border-amber-800 px-2 py-0.5 rounded">
              SIMULATION OUTPUT
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Simulated System Sales</span>
              <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
                {result.simulatedSalesDeltaUSD >= 0 ? `+$${result.simulatedSalesDeltaUSD}M` : `-$${Math.abs(result.simulatedSalesDeltaUSD)}M`}
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">Net system volume delta</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Margin Impact</span>
              <div className={`text-xl font-bold font-mono mt-1 ${result.simulatedMarginChangeBasisPoints >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {result.simulatedMarginChangeBasisPoints} bps
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">100 bps = 1.0% margin</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Franchisee Cash Flow</span>
              <div className={`text-xl font-bold font-mono mt-1 ${result.simulatedFranchiseeCashFlowUSD >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {result.simulatedFranchiseeCashFlowUSD >= 0 ? `+$${result.simulatedFranchiseeCashFlowUSD.toLocaleString()}` : `-$${Math.abs(result.simulatedFranchiseeCashFlowUSD).toLocaleString()}`}
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">Per 5-store franchisee group</span>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase">Corporate Royalty Income</span>
              <div className="text-xl font-bold font-mono text-amber-400 mt-1">
                +${(result.simulatedCorporateRoyaltyUSD / 1000000).toFixed(1)}M
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">4.0% Royalty expansion</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider block">Risk Assessment</span>
              <p className="text-xs text-slate-300 leading-relaxed">{result.riskSummary}</p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider block">Strategic Mitigations</span>
              <ul className="space-y-1 text-xs text-slate-300">
                {result.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
