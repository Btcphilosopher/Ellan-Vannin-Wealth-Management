import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  Customer, BankAccount, WDCWallet, LedgerAccount, 
  ReserveAsset, PaymentTransaction, Card, LoanProduct, 
  MarketAsset, ComplianceCase, AuditEvent, ProgrammablePaymentRule,
  ReconciliationReport, PaymentRail, FounderBankSettings
} from '../types/bank';
import { globalLedger } from '../engine/ledger';
import { WDCEngine } from '../engine/wdc';
import { globalReserveEngine } from '../engine/reserves';
import { globalCreditEngine } from '../engine/credit';
import { globalPaymentsEngine } from '../engine/payments';
import { globalComplianceEngine } from '../engine/compliance';
import { globalMarketsEngine } from '../engine/markets';
import { globalBankDigitalTwin } from '../engine/digitalTwin';
import { globalIntelligenceEngine } from '../engine/intelligence';
import { 
  INITIAL_CUSTOMERS, INITIAL_BANK_ACCOUNTS, INITIAL_WDC_WALLETS, 
  INITIAL_CARDS, INITIAL_AUDIT_EVENTS 
} from '../engine/seedData';

interface BankContextType {
  // Navigation & User Context
  activeView: string;
  setActiveView: (view: string) => void;
  activeRole: 'RETAIL' | 'BUSINESS' | 'INSTITUTIONAL' | 'CEO_COMMAND' | 'ISSUER_CONSOLE';
  setActiveRole: (role: 'RETAIL' | 'BUSINESS' | 'INSTITUTIONAL' | 'CEO_COMMAND' | 'ISSUER_CONSOLE') => void;
  
  // Real State
  customers: Customer[];
  bankAccounts: BankAccount[];
  wdcWallets: WDCWallet[];
  ledgerAccounts: LedgerAccount[];
  reserveAssets: ReserveAsset[];
  payments: PaymentTransaction[];
  cards: Card[];
  loans: LoanProduct[];
  rules: ProgrammablePaymentRule[];
  marketAssets: MarketAsset[];
  complianceCases: ComplianceCase[];
  auditEvents: AuditEvent[];
  founderSettings: FounderBankSettings;
  reconciliation: ReconciliationReport;

  // Actions
  mintWDC: (customerId: string, amountUSD: number, accountName: string) => void;
  redeemWDC: (customerId: string, amountWDC: number, targetAccountName: string) => void;
  transferWDC: (fromWalletId: string, toAddress: string, amountWDC: number) => string;
  makePayment: (fromAccId: string, fromAccName: string, toAccId: string, toAccName: string, amount: number, rail: PaymentRail, currency: 'USD' | 'WDC', description: string) => void;
  originateLoan: (customerId: string, name: string, type: LoanProduct['type'], principal: number, termMonths: number, ratePct: number, collateralVal: number) => void;
  executePaymentRule: (ruleId: string) => void;
  createPaymentRule: (rule: Omit<ProgrammablePaymentRule, 'id' | 'createdAt' | 'executionHistory'>) => void;
  updateFounderSettings: (settings: Partial<FounderBankSettings>) => void;
  askIntelligence: (prompt: string) => Promise<any>;
  runFlagshipDemoStep: (stepIndex: number) => void;
  flagshipStep: number;
}

const BankContext = createContext<BankContextType | undefined>(undefined);

export const BankProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeView, setActiveView] = useState<string>('HOME');
  const [activeRole, setActiveRole] = useState<'RETAIL' | 'BUSINESS' | 'INSTITUTIONAL' | 'CEO_COMMAND' | 'ISSUER_CONSOLE'>('RETAIL');

  const [customers] = useState<Customer[]>(INITIAL_CUSTOMERS);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(INITIAL_BANK_ACCOUNTS);
  const [wdcEngine] = useState(() => new WDCEngine(INITIAL_WDC_WALLETS));
  const [wdcWallets, setWdcWallets] = useState<WDCWallet[]>(() => wdcEngine.getWallets());
  const [ledgerAccounts, setLedgerAccounts] = useState<LedgerAccount[]>(() => globalLedger.getAccounts());
  const [reserveAssets, setReserveAssets] = useState<ReserveAsset[]>(() => globalReserveEngine.getAssets());
  const [payments, setPayments] = useState<PaymentTransaction[]>(() => globalPaymentsEngine.getPayments());
  const [cards] = useState<Card[]>(INITIAL_CARDS);
  const [loans, setLoans] = useState<LoanProduct[]>(() => globalCreditEngine.getLoans());
  const [rules, setRules] = useState<ProgrammablePaymentRule[]>(() => globalPaymentsEngine.getRules());
  const [marketAssets, setMarketAssets] = useState<MarketAsset[]>(() => globalMarketsEngine.getAssets());
  const [complianceCases, setComplianceCases] = useState<ComplianceCase[]>(() => globalComplianceEngine.getCases());
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>(INITIAL_AUDIT_EVENTS);
  const [founderSettings, setFounderSettings] = useState<FounderBankSettings>(() => globalBankDigitalTwin.getSettings());
  const [flagshipStep, setFlagshipStep] = useState<number>(0);

  // Automated Reconciliation State
  const [reconciliation, setReconciliation] = useState<ReconciliationReport>({
    timestamp: new Date().toISOString(),
    bankLedgerCash: 1482600000,
    wdcLedgerCirculation: 780000000,
    reserveAssetMarketValue: globalReserveEngine.getTotalMarketValue(),
    totalCustomerUsdBalances: 4800000000,
    totalCustomerWdcBalances: 780000000,
    discrepancyUSD: 0,
    status: 'RECONCILED',
    notes: 'All 4 ledger subsystems perfectly balanced. DR = CR verified.'
  });

  const refreshState = () => {
    setWdcWallets([...wdcEngine.getWallets()]);
    setLedgerAccounts([...globalLedger.getAccounts()]);
    setReserveAssets([...globalReserveEngine.getAssets()]);
    setPayments([...globalPaymentsEngine.getPayments()]);
    setLoans([...globalCreditEngine.getLoans()]);
    setRules([...globalPaymentsEngine.getRules()]);
    setMarketAssets([...globalMarketsEngine.getAssets()]);
    setComplianceCases([...globalComplianceEngine.getCases()]);
  };

  const addAuditEvent = (action: string, entity: string, entityId: string, note: string) => {
    const newAudit: AuditEvent = {
      id: `aud-${Date.now()}`,
      userId: activeRole,
      userRole: activeRole,
      action,
      entity,
      entityId,
      timestamp: new Date().toISOString(),
      authorization: 'VERIFIED_ED25519_PASSKEY',
      ipAddress: '192.168.1.10 (Wildcat Internal)'
    };
    setAuditEvents(prev => [newAudit, ...prev]);
  };

  const mintWDC = (customerId: string, amountUSD: number, accountName: string) => {
    // 1. Deduct USD from customer bank account
    setBankAccounts(prev => prev.map(acc => {
      if (acc.customerId === customerId && acc.type === 'CHECKING') {
        return { ...acc, balance: Math.max(0, acc.balance - amountUSD), availableBalance: Math.max(0, acc.availableBalance - amountUSD) };
      }
      return acc;
    }));

    // 2. Mint WDC via WDC Engine
    const res = wdcEngine.mintWDC(customerId, amountUSD, accountName);

    // 3. Log audit event & payment transaction
    addAuditEvent('WDC_MINT_COMPLETED', 'WDCIssuanceEngine', res.journalRef, `Minted WDC ${amountUSD.toLocaleString()} for USD`);
    globalPaymentsEngine.createPayment(
      'acc-vance-checking', accountName,
      'wdc-wallet-vance', 'WDC Wallet',
      amountUSD, 'WDC', 'WDC', 'USD to WDC Conversion'
    );

    refreshState();
  };

  const redeemWDC = (customerId: string, amountWDC: number, targetAccountName: string) => {
    // 1. Redeem WDC via WDC Engine
    const res = wdcEngine.redeemWDC(customerId, amountWDC, targetAccountName);

    // 2. Credit USD to customer bank account
    setBankAccounts(prev => prev.map(acc => {
      if (acc.customerId === customerId && acc.type === 'CHECKING') {
        return { ...acc, balance: acc.balance + amountWDC, availableBalance: acc.availableBalance + amountWDC };
      }
      return acc;
    }));

    // 3. Log audit event
    addAuditEvent('WDC_REDEMPTION_COMPLETED', 'WDCRedemptionEngine', res.journalRef, `Redeemed WDC ${amountWDC.toLocaleString()} to USD`);
    
    refreshState();
  };

  const transferWDC = (fromWalletId: string, toAddress: string, amountWDC: number): string => {
    const res = wdcEngine.transferWDC(fromWalletId, toAddress, amountWDC);
    addAuditEvent('WDC_TRANSFER_EXECUTED', 'WDCTransferEngine', res.txHash, `Transferred WDC ${amountWDC.toLocaleString()} to ${toAddress}`);
    refreshState();
    return res.txHash;
  };

  const makePayment = (
    fromAccId: string, fromAccName: string,
    toAccId: string, toAccName: string,
    amount: number, rail: PaymentRail,
    currency: 'USD' | 'WDC', description: string
  ) => {
    globalPaymentsEngine.createPayment(fromAccId, fromAccName, toAccId, toAccName, amount, rail, currency, description);
    
    // Update USD account balances if internal/ACH/Wire
    setBankAccounts(prev => prev.map(acc => {
      if (acc.id === fromAccId) {
        return { ...acc, balance: acc.balance - amount, availableBalance: acc.availableBalance - amount };
      }
      if (acc.id === toAccId) {
        return { ...acc, balance: acc.balance + amount, availableBalance: acc.availableBalance + amount };
      }
      return acc;
    }));

    addAuditEvent('PAYMENT_EXECUTED', 'PaymentsEngine', rail, `Paid $${amount} via ${rail}`);
    refreshState();
  };

  const originateLoan = (
    customerId: string, name: string, type: LoanProduct['type'],
    principal: number, termMonths: number, ratePct: number, collateralVal: number
  ) => {
    const loan = globalCreditEngine.originateLoan(customerId, name, type, principal, termMonths, ratePct, collateralVal);
    addAuditEvent('LOAN_ORIGINATED', 'CreditEngine', loan.id, `Originated ${type} of $${principal.toLocaleString()}`);
    refreshState();
  };

  const executePaymentRule = (ruleId: string) => {
    globalPaymentsEngine.executeRule(ruleId);
    addAuditEvent('PROGRAMMABLE_RULE_EXECUTED', 'RulesEngine', ruleId, `Triggered programmable rule ${ruleId}`);
    refreshState();
  };

  const createPaymentRule = (ruleData: Omit<ProgrammablePaymentRule, 'id' | 'createdAt' | 'executionHistory'>) => {
    const newRule = globalPaymentsEngine.createRule(ruleData);
    addAuditEvent('PROGRAMMABLE_RULE_CREATED', 'RulesEngine', newRule.id, `Created rule: ${newRule.name}`);
    refreshState();
  };

  const updateFounderSettings = (updates: Partial<FounderBankSettings>) => {
    globalBankDigitalTwin.updateSettings(updates);
    setFounderSettings(globalBankDigitalTwin.getSettings());
  };

  const askIntelligence = async (prompt: string) => {
    return await globalIntelligenceEngine.queryIntelligence(prompt);
  };

  // Flagship Demo Step Handler (Requirement #65)
  const runFlagshipDemoStep = (stepIndex: number) => {
    setFlagshipStep(stepIndex);
    if (stepIndex === 1) {
      // Step 1: Customer A deposits $10,000 USD
      setBankAccounts(prev => prev.map(acc => {
        if (acc.id === 'acc-vance-checking') {
          return { ...acc, balance: acc.balance + 10000, availableBalance: acc.availableBalance + 10000 };
        }
        return acc;
      }));
      addAuditEvent('DEMO_DEPOSIT', 'CustomerChecking', 'acc-vance-checking', 'Flagship Demo: Deposited $10,000 USD');
    } else if (stepIndex === 2) {
      // Step 2: Convert $4,000 to WDC
      mintWDC('cust-retail-001', 4000, 'Alexander Vance Checking');
    } else if (stepIndex === 3) {
      // Step 3: Send $1,250 WDC to Apex Logistics
      transferWDC('wdc-wallet-vance', 'wdc1qapex94820193820193820192', 1250);
    } else if (stepIndex === 4) {
      // Step 4: Apex redeems $500 WDC back to USD
      redeemWDC('cust-biz-001', 500, 'Apex Operating Cash USD');
    }
  };

  return (
    <BankContext.Provider value={{
      activeView, setActiveView,
      activeRole, setActiveRole,
      customers, bankAccounts, wdcWallets, ledgerAccounts, reserveAssets,
      payments, cards, loans, rules, marketAssets, complianceCases,
      auditEvents, founderSettings, reconciliation,
      mintWDC, redeemWDC, transferWDC, makePayment, originateLoan,
      executePaymentRule, createPaymentRule, updateFounderSettings,
      askIntelligence, runFlagshipDemoStep, flagshipStep
    }}>
      {children}
    </BankContext.Provider>
  );
};

export const useBank = () => {
  const context = useContext(BankContext);
  if (!context) throw new Error('useBank must be used within a BankProvider');
  return context;
};
