import React from 'react';
import { BankProvider, useBank } from './context/BankContext';
import { TopBar } from './components/TopBar';
import { SidebarNav } from './components/SidebarNav';

// Views
import { HomeView } from './components/views/HomeView';
import { AccountsView } from './components/views/AccountsView';
import { PaymentsView } from './components/views/PaymentsView';
import { CardsView } from './components/views/CardsView';
import { DigitalDollarView } from './components/views/DigitalDollarView';
import { TreasuryReservesView } from './components/views/TreasuryReservesView';
import { CreditView } from './components/views/CreditView';
import { MarketsWealthView } from './components/views/MarketsWealthView';
import { BusinessBankingView } from './components/views/BusinessBankingView';
import { MerchantView } from './components/views/MerchantView';
import { ComplianceView } from './components/views/ComplianceView';
import { CeoCommandView } from './components/views/CeoCommandView';
import { IntelligenceView } from './components/views/IntelligenceView';
import { ApiSdkView } from './components/views/ApiSdkView';
import { ReconciliationView } from './components/views/ReconciliationView';

const ViewRouter: React.FC = () => {
  const { activeView } = useBank();

  switch (activeView) {
    case 'HOME':
      return <HomeView />;
    case 'ACCOUNTS':
      return <AccountsView />;
    case 'PAYMENTS':
      return <PaymentsView />;
    case 'CARDS':
      return <CardsView />;
    case 'WDC':
      return <DigitalDollarView />;
    case 'TREASURY':
      return <TreasuryReservesView />;
    case 'CREDIT':
      return <CreditView />;
    case 'MARKETS':
      return <MarketsWealthView />;
    case 'BUSINESS':
      return <BusinessBankingView />;
    case 'MERCHANT':
      return <MerchantView />;
    case 'COMPLIANCE':
      return <ComplianceView />;
    case 'CEO_COMMAND':
      return <CeoCommandView />;
    case 'INTELLIGENCE':
      return <IntelligenceView />;
    case 'API':
      return <ApiSdkView />;
    case 'RECONCILIATION':
      return <ReconciliationView />;
    default:
      return <HomeView />;
  }
};

export default function App() {
  return (
    <BankProvider>
      <div className="min-h-screen bg-[#0b0e14] text-slate-100 flex flex-col font-sans">
        <TopBar />
        <div className="flex flex-1 overflow-hidden">
          <SidebarNav />
          <main className="flex-1 p-6 md:p-8 overflow-y-auto max-w-7xl mx-auto w-full">
            <ViewRouter />
          </main>
        </div>
      </div>
    </BankProvider>
  );
}
