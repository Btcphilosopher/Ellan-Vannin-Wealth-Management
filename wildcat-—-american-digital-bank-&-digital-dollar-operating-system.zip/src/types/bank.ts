/**
 * WILDCAT Financial Systems — Core Data Models
 */

export type AccountType = 
  | 'CHECKING'
  | 'SAVINGS'
  | 'MONEY_MARKET'
  | 'TREASURY'
  | 'PRIVATE_BANKING'
  | 'BUSINESS_CHECKING'
  | 'BUSINESS_SAVINGS';

export type PaymentRail = 'ACH' | 'FEDWIRE' | 'INTERNAL' | 'CARD' | 'CHECK' | 'WDC';

export type PaymentState = 
  | 'CREATED'
  | 'AUTHORIZED'
  | 'PENDING'
  | 'PROCESSING'
  | 'SETTLED'
  | 'FAILED'
  | 'RETURNED'
  | 'REVERSED';

export type CustomerType = 'RETAIL' | 'BUSINESS' | 'INSTITUTIONAL';

export interface Customer {
  id: string;
  name: string;
  email: string;
  type: CustomerType;
  jurisdiction: string;
  city: string;
  state: string;
  kycStatus: 'VERIFIED' | 'PENDING' | 'REJECTED';
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH';
  joinedDate: string;
  taxId: string;
}

export interface BankAccount {
  id: string;
  customerId: string;
  accountNumber: string;
  routingNumber: string;
  type: AccountType;
  name: string;
  balance: number;
  availableBalance: number;
  currency: string;
  createdAt: string;
  status: 'ACTIVE' | 'FROZEN' | 'CLOSED';
}

export interface WDCWallet {
  id: string;
  customerId: string;
  address: string;
  balance: number;
  availableBalance: number;
  pendingBalance: number;
  status: 'ACTIVE' | 'FROZEN' | 'RESTRICTED';
  createdAt: string;
}

export interface LedgerAccount {
  id: string;
  code: string;
  name: string;
  type: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
  balance: number;
}

export interface JournalEntry {
  id: string;
  journalId: string;
  ledgerAccountId: string;
  ledgerAccountCode: string;
  ledgerAccountName: string;
  type: 'DEBIT' | 'CREDIT';
  amount: number;
  description: string;
}

export interface Journal {
  id: string;
  reference: string;
  description: string;
  timestamp: string;
  entries: JournalEntry[];
  authorizedBy: string;
}

export interface PaymentTransaction {
  id: string;
  fromAccountId?: string;
  fromAccountName?: string;
  toAccountId?: string;
  toAccountName?: string;
  amount: number;
  currency: 'USD' | 'WDC';
  rail: PaymentRail;
  state: PaymentState;
  reference: string;
  description: string;
  timestamp: string;
  fee: number;
  stateHistory: { state: PaymentState; timestamp: string; note: string }[];
}

export interface ReserveAsset {
  id: string;
  assetType: 'US_TREASURY_BILL' | 'CASH_EQUIVALENT' | 'FED_RESERVE_BALANCE' | 'SHORT_GOVT_BOND';
  cusipOrId: string;
  faceValue: number;
  marketValue: number;
  maturityDate: string;
  yieldPct: number;
  custodian: string;
  liquidityRating: 'HIGH' | 'MEDIUM' | 'LOW';
  eligibilityPolicy: 'QUALIFIED' | 'UNDER_REVIEW' | 'INELIGIBLE';
  haircutPct: number;
  valuationTime: string;
}

export interface ProgrammablePaymentRule {
  id: string;
  customerId: string;
  name: string;
  triggerType: 'RECURRING_DATE' | 'INVOICE_VERIFIED' | 'DELIVERY_CONFIRMED' | 'ESCROW_APPROVAL' | 'PERCENTAGE_SAVINGS';
  amountOrPct: number;
  isPercentage: boolean;
  destinationAccountOrWallet: string;
  frequencyDays?: number;
  nextExecutionDate?: string;
  status: 'ACTIVE' | 'PAUSED' | 'EXPIRED' | 'COMPLETED';
  requiresApproval: boolean;
  limitAmount: number;
  expiryDate: string;
  createdAt: string;
  executionHistory: { timestamp: string; amountExecuted: number; status: string }[];
}

export interface Card {
  id: string;
  accountId: string;
  customerId: string;
  cardNumber: string;
  cardholderName: string;
  expiry: string;
  cvv: string;
  type: 'DEBIT' | 'CREDIT' | 'VIRTUAL' | 'CORPORATE';
  status: 'ACTIVE' | 'FROZEN' | 'CANCELLED';
  monthlyLimit: number;
  spentThisMonth: number;
  categoriesAllowed: string[];
  travelMode: boolean;
  createdAt: string;
}

export interface LoanProduct {
  id: string;
  customerId: string;
  customerName: string;
  type: 'PERSONAL_LOAN' | 'AUTO_LOAN' | 'MORTGAGE' | 'BUSINESS_LOAN' | 'WORKING_CAPITAL';
  principal: number;
  remainingPrincipal: number;
  interestRatePct: number;
  termMonths: number;
  monthlyPayment: number;
  collateralValue: number;
  probabilityOfDefaultPct: number;
  lossGivenDefaultPct: number;
  expectedLoss: number;
  status: 'APPLICATION' | 'UNDERWRITING' | 'APPROVED' | 'ACTIVE' | 'PAID_OFF' | 'DEFAULTED';
  originationDate: string;
  nextPaymentDueDate: string;
}

export interface MarketAsset {
  symbol: string;
  name: string;
  category: 'EQUITY' | 'TREASURY' | 'CREDIT' | 'BOND' | 'COMMODITY' | 'FX';
  price: number;
  change24hPct: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  orderBook: {
    bids: { price: number; amount: number }[];
    asks: { price: number; amount: number }[];
  };
}

export interface ComplianceCase {
  id: string;
  customerId: string;
  customerName: string;
  type: 'KYC_VERIFICATION' | 'AML_ALERT' | 'SANCTIONS_MATCH' | 'LARGE_TRANSACTION' | 'WDC_FREEZE_REQUEST';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'OPEN' | 'UNDER_INVESTIGATION' | 'RESOLVED' | 'ESCALATED';
  description: string;
  flaggedTimestamp: string;
  assignedOfficer: string;
  rulesTriggered: string[];
}

export interface AuditEvent {
  id: string;
  userId: string;
  userRole: string;
  action: string;
  entity: string;
  entityId: string;
  timestamp: string;
  previousState?: string;
  newState?: string;
  authorization: string;
  ipAddress: string;
}

export interface SystemScenario {
  id: string;
  name: string;
  description: string;
  wdcAdoptionMultiplier: number;
  depositOutflowPct: number;
  wdcRedemptionDemandUSD: number;
  interestRateShockBP: number;
  treasuryYieldChangeBP: number;
  loanDemandMultiplier: number;
}

export interface ReconciliationReport {
  timestamp: string;
  bankLedgerCash: number;
  wdcLedgerCirculation: number;
  reserveAssetMarketValue: number;
  totalCustomerUsdBalances: number;
  totalCustomerWdcBalances: number;
  discrepancyUSD: number;
  status: 'RECONCILED' | 'WARNING' | 'EXCEPTION';
  notes: string;
}

export interface FounderBankSettings {
  bankName: string;
  retailCustomersCount: number;
  businessCustomersCount: number;
  totalDepositsUSD: number;
  totalLoansUSD: number;
  wdcCirculationUSD: number;
  reserveAssetsUSD: number;
  foundingCapitalUSD: number;
  simulationDay: number;
}
