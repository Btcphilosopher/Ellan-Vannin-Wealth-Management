import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { PaymentRail } from '../../types/bank';
import { ArrowLeftRight, CheckCircle2, Clock, Plus, Play } from 'lucide-react';

export const PaymentsView: React.FC = () => {
  const { makePayment, rules, executePaymentRule, createPaymentRule } = useBank();

  // Payment Form State
  const [recipient, setRecipient] = useState<string>('Apex Logistics Infrastructure LLC');
  const [amount, setAmount] = useState<string>('2500');
  const [rail, setRail] = useState<PaymentRail>('ACH');
  const [description, setDescription] = useState<string>('Quarterly Supply Chain Retainer');
  const [notice, setNotice] = useState<string>('');

  // Programmable Rule Form
  const [ruleName, setRuleName] = useState<string>('Monthly Vendor Sweep');
  const [ruleAmount, setRuleAmount] = useState<string>('2000');
  const [ruleTrigger, setRuleTrigger] = useState<any>('RECURRING_DATE');

  const handleSendPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (val > 0) {
      makePayment(
        'acc-vance-checking', 'Alexander Vance Checking',
        'acc-apex-biz', recipient,
        val, rail, 'USD', description
      );
      setNotice(`Payment of $${val.toLocaleString()} via ${rail} settled instantly on the ledger!`);
      setTimeout(() => setNotice(''), 4000);
    }
  };

  const handleCreateRule = (e: React.FormEvent) => {
    e.preventDefault();
    createPaymentRule({
      customerId: 'cust-retail-001',
      name: ruleName,
      triggerType: ruleTrigger,
      amountOrPct: parseFloat(ruleAmount),
      isPercentage: false,
      destinationAccountOrWallet: recipient,
      status: 'ACTIVE',
      requiresApproval: false,
      limitAmount: 10000,
      expiryDate: '2028-12-31'
    });
    setNotice(`Programmable payment rule "${ruleName}" created!`);
    setTimeout(() => setNotice(''), 4000);
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          WILDCAT PAYMENT ENGINE & PROGRAMMABLE MONEY
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          MULTI-RAIL PAYMENTS & AUTOMATED RULES
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          ACH, Fedwire, WDC Digital Dollar, and programmable payment instruction rules
        </p>
      </div>

      {notice && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs rounded flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Send Payment Portal */}
        <form onSubmit={handleSendPayment} className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
          <div className="text-xs font-mono text-amber-400 uppercase font-semibold flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4" />
            <span>Execute Payment Instruction</span>
          </div>

          <div>
            <label className="text-[11px] font-mono text-slate-300 block mb-1">Select Payment Rail</label>
            <div className="grid grid-cols-3 gap-2">
              {(['ACH', 'FEDWIRE', 'WDC', 'INTERNAL', 'CARD', 'CHECK'] as PaymentRail[]).map((r) => (
                <button
                  type="button"
                  key={r}
                  onClick={() => setRail(r)}
                  className={`py-2 text-xs font-mono rounded border transition-colors ${
                    rail === r ? 'bg-amber-500/20 text-amber-300 border-amber-500' : 'bg-[#181e2b] text-slate-400 border-[#262e40]'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[11px] font-mono text-slate-300 block mb-1">Recipient Counterparty / Account</label>
            <input
              type="text"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-mono text-slate-300 block mb-1">Amount ($ USD)</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-mono text-slate-300 block mb-1">Memo / Purpose</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded text-xs font-semibold bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors"
          >
            Authorize & Submit Payment
          </button>
        </form>

        {/* Programmable Payment Rules Engine (Requirement #13) */}
        <div className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
          <div className="text-xs font-mono text-amber-400 uppercase font-semibold flex items-center justify-between">
            <span>Programmable Payment Rules</span>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded">
              Controlled Smart Rules
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Define automated conditional logic rules (triggers, limits, escrow verification, automatic sweeps).
          </p>

          <div className="space-y-3">
            {rules.map((rule) => (
              <div key={rule.id} className="p-3.5 bg-[#181e2b] rounded border border-[#262e40] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-200">{rule.name}</span>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                    {rule.status}
                  </span>
                </div>

                <div className="text-[11px] font-mono text-slate-400">
                  Trigger: <span className="text-amber-300">{rule.triggerType}</span> | Value: <span className="text-slate-200">${rule.amountOrPct}</span>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-[#232a3a] text-[10px] text-slate-400">
                  <span>Target: {rule.destinationAccountOrWallet.slice(0, 20)}...</span>
                  <button
                    onClick={() => {
                      executePaymentRule(rule.id);
                      setNotice(`Executed programmable rule ${rule.name}`);
                    }}
                    className="text-amber-400 hover:underline flex items-center gap-1 font-mono font-semibold"
                  >
                    <Play className="w-3 h-3" />
                    <span>Run Trigger</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
