import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { CreditCard, Lock, Unlock, Plus, Globe, Shield } from 'lucide-react';

export const CardsView: React.FC = () => {
  const { cards } = useBank();
  const [cardList, setCardList] = useState(cards);

  const toggleFreeze = (cardId: string) => {
    setCardList(prev => prev.map(c => {
      if (c.id === cardId) {
        return { ...c, status: c.status === 'ACTIVE' ? 'FROZEN' : 'ACTIVE' };
      }
      return c;
    }));
  };

  const toggleTravel = (cardId: string) => {
    setCardList(prev => prev.map(c => {
      if (c.id === cardId) {
        return { ...c, travelMode: !c.travelMode };
      }
      return c;
    }));
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          WILDCAT CARD INFRASTRUCTURE
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          DEBIT, CREDIT & VIRTUAL CORPORATE CARDS
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          Real-time spending controls, category constraints, travel overrides, and virtual card issuance
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {cardList.map((card) => (
          <div key={card.id} className="bg-[#121722] border border-[#212631] rounded-lg p-6 space-y-5">
            {/* Skeuomorphic Metallic Card Render */}
            <div className="h-48 rounded-xl bg-gradient-to-br from-slate-900 via-[#182030] to-slate-950 border border-[#2a3447] p-5 flex flex-col justify-between shadow-xl relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div className="font-brand text-amber-400 font-bold tracking-widest text-lg">
                  WILDCAT
                </div>
                <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30">
                  {card.type}
                </span>
              </div>

              <div className="font-mono text-lg text-slate-100 tracking-wider">
                {card.cardNumber}
              </div>

              <div className="flex justify-between items-end text-xs font-mono text-slate-300">
                <div>
                  <div className="text-[9px] text-slate-400">CARDHOLDER</div>
                  <div>{card.cardholderName}</div>
                </div>
                <div>
                  <div className="text-[9px] text-slate-400">EXPIRES</div>
                  <div>{card.expiry}</div>
                </div>
              </div>
            </div>

            {/* Controls Bar */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between text-xs font-mono text-slate-300">
                <span>Monthly Limit Spent</span>
                <span className="text-amber-400 font-bold">${card.spentThisMonth.toLocaleString()} / ${card.monthlyLimit.toLocaleString()}</span>
              </div>

              <div className="w-full bg-[#181e2b] h-2 rounded-full overflow-hidden border border-[#262e40]">
                <div 
                  className="bg-amber-500 h-full transition-all" 
                  style={{ width: `${(card.spentThisMonth / card.monthlyLimit) * 100}%` }}
                />
              </div>

              <div className="flex items-center justify-between gap-3 pt-2">
                <button
                  onClick={() => toggleFreeze(card.id)}
                  className={`flex-1 py-2 rounded text-xs font-mono font-medium flex items-center justify-center gap-1.5 transition-colors ${
                    card.status === 'FROZEN' ? 'bg-emerald-600 text-slate-950 font-semibold' : 'bg-[#181e2b] border border-[#262e40] text-slate-300 hover:text-amber-300'
                  }`}
                >
                  {card.status === 'FROZEN' ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5 text-amber-400" />}
                  <span>{card.status === 'FROZEN' ? 'Unfreeze Card' : 'Freeze Card'}</span>
                </button>

                <button
                  onClick={() => toggleTravel(card.id)}
                  className={`flex-1 py-2 rounded text-xs font-mono font-medium flex items-center justify-center gap-1.5 transition-colors ${
                    card.travelMode ? 'bg-amber-500 text-slate-950 font-semibold' : 'bg-[#181e2b] border border-[#262e40] text-slate-300 hover:text-amber-300'
                  }`}
                >
                  <Globe className="w-3.5 h-3.5 text-blue-400" />
                  <span>Travel Mode: {card.travelMode ? 'ON' : 'OFF'}</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
