import React, { useState } from 'react';
import { Code2, Terminal, Copy, Check } from 'lucide-react';

export const ApiSdkView: React.FC = () => {
  const [lang, setLang] = useState<'TS' | 'PYTHON' | 'RUST'>('TS');
  const [copied, setCopied] = useState(false);

  const snippets = {
    TS: `import { WildcatClient } from '@wildcat/sdk';

const client = new WildcatClient({
  apiKey: process.env.WILDCAT_API_KEY,
  environment: 'production-v1'
});

// Mint $50,000 WDC Digital Dollar
const result = await client.wdc.mint({
  customerId: 'cust-biz-001',
  amountUSD: 50000,
  sourceAccount: '1004820912'
});

console.log('Minted WDC Journal:', result.journalRef);`,

    PYTHON: `from wildcat import WildcatClient

client = WildcatClient(
    api_key="wc_live_891028310293",
    environment="production"
)

# Fetch WDC Reserve Coverage Ratio
reserves = client.wdc.get_reserves()
print(f"WDC Reserve Coverage: {reserves.coverage_pct}%")

# Execute Programmable Payment Instruction
tx = client.payments.execute_rule(rule_id="rule-rent-001")
print(f"Settled Tx Hash: {tx.hash}")`,

    RUST: `use wildcat_sdk::WildcatClient;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let client = WildcatClient::new("wc_live_891028310293")?;
    
    // Authoritative ledger transfer
    let tx = client.wdc().transfer(
        "wdc1qvance849201...",
        "wdc1qapex948201...",
        1250.0
    ).await?;
    
    println!("Ledger Journal Ref: {}", tx.journal_ref);
    Ok(())
}`
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(snippets[lang]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          WILDCAT DEVELOPER PLATFORM & INSTITUTIONAL API
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          OPENAPI & HIGH-PERFORMANCE SDKs
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          TypeScript, Python, and Rust client libraries with OAuth abstraction, RBAC, and idempotency keys
        </p>
      </div>

      {/* Code Snippet Box */}
      <div className="bg-[#121722] border border-[#212631] rounded-lg p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-[#212631] pb-3">
          <div className="flex items-center gap-2">
            <Code2 className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-mono font-bold text-slate-200">Wildcat SDK Code Examples</span>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-[#181e2b] p-1 rounded border border-[#262e40]">
              {(['TS', 'PYTHON', 'RUST'] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className={`px-3 py-1 rounded text-[11px] font-mono transition-colors ${
                    lang === l ? 'bg-[#252e42] text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>

            <button
              onClick={handleCopy}
              className="p-1.5 rounded bg-[#181e2b] border border-[#262e40] text-slate-300 hover:text-white"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <pre className="p-4 bg-[#0d1117] rounded border border-[#1e2432] font-mono text-xs text-amber-200/90 overflow-x-auto leading-relaxed">
          <code>{snippets[lang]}</code>
        </pre>
      </div>

      {/* API Endpoint List */}
      <div className="bg-[#121722] border border-[#212631] rounded p-6 space-y-3 font-mono text-xs">
        <div className="text-xs font-mono text-amber-400 uppercase font-semibold">
          REST API v1 Endpoints
        </div>

        <div className="space-y-2">
          <div className="p-2.5 bg-[#181e2b] rounded flex items-center justify-between">
            <span><strong className="text-emerald-400">GET</strong> /api/v1/wdc/supply</span>
            <span className="text-slate-400">Fetch live circulation & reserve coverage</span>
          </div>

          <div className="p-2.5 bg-[#181e2b] rounded flex items-center justify-between">
            <span><strong className="text-amber-400">POST</strong> /api/v1/wdc/mint</span>
            <span className="text-slate-400">Mint WDC and credit target wallet</span>
          </div>

          <div className="p-2.5 bg-[#181e2b] rounded flex items-center justify-between">
            <span><strong className="text-purple-400">POST</strong> /api/v1/wdc/redeem</span>
            <span className="text-slate-400">Burn WDC and redeem for USD cash</span>
          </div>
        </div>
      </div>
    </div>
  );
};
