import React from 'react';
import { useBank } from '../../context/BankContext';
import { 
  ArrowUpRight, ArrowDownLeft, RefreshCw, Send, DollarSign, 
  TrendingUp, Shield, Sparkles, CheckCircle2, Play
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const { 
    bankAccounts, wdcWallets, setActiveView, 
    runFlagshipDemoStep, flagshipStep, mintWDC, redeemWDC 
  } = useBank();

  // Calculate totals
  const checking = bankAccounts.find(a => a.type === 'CHECKING')?.balance || 84240.52;
  const savings = bankAccounts.find(a => a.type === 'SAVINGS')?.balance || 72800.00;
  const wdcVal = wdcWallets.find(w => w.customerId === 'cust-retail-001')?.balance || 24820.42;
  const investments = bankAccounts.find(a => a.type === 'PRIVATE_BANKING')?.balance || 66560.00;
  const totalLiquidAssets = checking + savings + wdcVal + investments;

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#212631] pb-5 gap-4">
        <div>
          <div className="text-xs font-mono text-amber-400 font-semibold tracking-wider uppercase mb-1">
            Alexander Vance · Private Banking Account
          </div>
          <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100">
            TOTAL LIQUID ASSETS
          </h1>
          <p className="text-slate-400 text-xs mt-1">
            Authoritative balance ledger synced with Wildcat Financial Treasury Engine
          </p>
        </div>

        <div className="text-left sm:text-right">
          <div className="font-mono-nums text-3xl md:text-4xl font-extrabold text-slate-100 tracking-tight">
            ${totalLiquidAssets.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-xs text-emerald-400 font-mono flex items-center justify-start sm:justify-end gap-1 mt-0.5">
            <span>↑ +2.48% past 30 days</span>
          </div>
        </div>
      </div>

      {/* Account Cards Grid (Requirement #27) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* CHECKING */}
        <div className="bg-[#121722] border border-[#212631] rounded p-4 relative overflow-hidden group hover:border-slate-700 transition-colors">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1">
            Checking Account
          </div>
          <div className="font-mono-nums text-2xl font-bold text-slate-100 mb-2">
            ${checking.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between border-t border-[#1e2432] pt-2 mt-2">
            <span>Acct ••••9012</span>
            <span className="text-emerald-400 font-mono">100% Available</span>
          </div>
        </div>

        {/* SAVINGS */}
        <div className="bg-[#121722] border border-[#212631] rounded p-4 relative overflow-hidden group hover:border-slate-700 transition-colors">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1">
            Reserve Savings
          </div>
          <div className="font-mono-nums text-2xl font-bold text-slate-100 mb-2">
            ${savings.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between border-t border-[#1e2432] pt-2 mt-2">
            <span>5.15% APY Yield</span>
            <span className="text-slate-300 font-mono">Fed Backed</span>
          </div>
        </div>

        {/* WDC DIGITAL DOLLAR */}
        <div className="bg-gradient-to-br from-[#182030] to-[#111622] border border-amber-500/30 rounded p-4 relative overflow-hidden group hover:border-amber-500/50 transition-colors">
          <div className="text-[11px] font-mono text-amber-400 uppercase tracking-wider mb-1 flex items-center justify-between">
            <span>Wildcat Digital Dollar</span>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-mono">WDC</span>
          </div>
          <div className="font-mono-nums text-2xl font-bold text-amber-300 mb-2">
            WDC {wdcVal.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between border-t border-amber-500/20 pt-2 mt-2">
            <span>1 WDC = $1.00 USD</span>
            <span className="text-emerald-400 font-mono">100% Reserve</span>
          </div>
        </div>

        {/* INVESTMENTS */}
        <div className="bg-[#121722] border border-[#212631] rounded p-4 relative overflow-hidden group hover:border-slate-700 transition-colors">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1">
            Investments & Wealth
          </div>
          <div className="font-mono-nums text-2xl font-bold text-slate-100 mb-2">
            ${investments.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between border-t border-[#1e2432] pt-2 mt-2">
            <span>Private Capital</span>
            <span className="text-emerald-400 font-mono">+4.12% YTD</span>
          </div>
        </div>
      </div>

      {/* Quick Actions Bar */}
      <div className="bg-[#121722] border border-[#212631] rounded p-4">
        <div className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">
          Instant Financial Actions
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          <button
            onClick={() => setActiveView('PAYMENTS')}
            className="p-2.5 rounded bg-[#181e2b] border border-[#262e40] hover:border-amber-500/50 hover:text-amber-300 text-xs text-slate-200 font-medium transition-colors flex flex-col items-center gap-1.5"
          >
            <ArrowUpRight className="w-4 h-4 text-amber-400" />
            <span>Pay & Transfer</span>
          </button>

          <button
            onClick={() => setActiveView('WDC')}
            className="p-2.5 rounded bg-[#181e2b] border border-[#262e40] hover:border-amber-500/50 hover:text-amber-300 text-xs text-slate-200 font-medium transition-colors flex flex-col items-center gap-1.5"
          >
            <Send className="w-4 h-4 text-emerald-400" />
            <span>Send WDC</span>
          </button>

          <button
            onClick={() => mintWDC('cust-retail-001', 1000, 'Checking')}
            className="p-2.5 rounded bg-[#181e2b] border border-[#262e40] hover:border-amber-500/50 hover:text-amber-300 text-xs text-slate-200 font-medium transition-colors flex flex-col items-center gap-1.5"
          >
            <DollarSign className="w-4 h-4 text-blue-400" />
            <span>Convert to WDC</span>
          </button>

          <button
            onClick={() => redeemWDC('cust-retail-001', 500, 'Checking')}
            className="p-2.5 rounded bg-[#181e2b] border border-[#262e40] hover:border-amber-500/50 hover:text-amber-300 text-xs text-slate-200 font-medium transition-colors flex flex-col items-center gap-1.5"
          >
            <RefreshCw className="w-4 h-4 text-purple-400" />
            <span>Redeem to USD</span>
          </button>

          <button
            onClick={() => setActiveView('CREDIT')}
            className="p-2.5 rounded bg-[#181e2b] border border-[#262e40] hover:border-amber-500/50 hover:text-amber-300 text-xs text-slate-200 font-medium transition-colors flex flex-col items-center gap-1.5"
          >
            <TrendingUp className="w-4 h-4 text-amber-400" />
            <span>Borrow Credit</span>
          </button>

          <button
            onClick={() => setActiveView('MARKETS')}
            className="p-2.5 rounded bg-[#181e2b] border border-[#262e40] hover:border-amber-500/50 hover:text-amber-300 text-xs text-slate-200 font-medium transition-colors flex flex-col items-center gap-1.5"
          >
            <Sparkles className="w-4 h-4 text-sky-400" />
            <span>Invest Wealth</span>
          </button>

          <button
            onClick={() => setActiveView('TREASURY')}
            className="p-2.5 rounded bg-[#181e2b] border border-[#262e40] hover:border-amber-500/50 hover:text-amber-300 text-xs text-slate-200 font-medium transition-colors flex flex-col items-center gap-1.5"
          >
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>Treasury Lab</span>
          </button>
        </div>
      </div>

      {/* Flagship Demo Walkthrough Section (Requirement #65) */}
      <div className="bg-[#121722] border border-amber-500/30 rounded p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h2 className="font-brand text-lg font-bold text-slate-100">
              FLAGSHIP OPERATING SYSTEM DEMO
            </h2>
          </div>
          <span className="text-xs font-mono text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded border border-amber-500/20">
            Interactive Full Lifecycle
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed mb-6">
          Experience the complete end-to-end financial lifecycle across Wildcat Bank’s double-entry ledger: from USD deposit, reserve allocation, compliance verification, WDC minting, instant programmable transfer, to business USD redemption.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Step 1 */}
          <div className={`p-4 rounded border transition-all ${
            flagshipStep === 1 ? 'bg-amber-500/10 border-amber-500 text-slate-100' : 'bg-[#181e2b] border-[#262e40] text-slate-400'
          }`}>
            <div className="text-[10px] font-mono uppercase tracking-wider mb-1 text-slate-400">Step 1</div>
            <div className="text-sm font-semibold text-slate-200 mb-1">USD Deposit</div>
            <p className="text-xs text-slate-400 mb-3">Customer A deposits $10,000 USD into checking account.</p>
            <button
              onClick={() => runFlagshipDemoStep(1)}
              className="w-full py-1.5 rounded text-xs font-mono font-medium bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors flex items-center justify-center gap-1"
            >
              {flagshipStep >= 1 ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>Deposit $10k</span>
            </button>
          </div>

          {/* Step 2 */}
          <div className={`p-4 rounded border transition-all ${
            flagshipStep === 2 ? 'bg-amber-500/10 border-amber-500 text-slate-100' : 'bg-[#181e2b] border-[#262e40] text-slate-400'
          }`}>
            <div className="text-[10px] font-mono uppercase tracking-wider mb-1 text-slate-400">Step 2</div>
            <div className="text-sm font-semibold text-slate-200 mb-1">WDC Minting</div>
            <p className="text-xs text-slate-400 mb-3">Convert $4,000 into WDC (Reserves allocated 100%).</p>
            <button
              onClick={() => runFlagshipDemoStep(2)}
              className="w-full py-1.5 rounded text-xs font-mono font-medium bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors flex items-center justify-center gap-1"
            >
              {flagshipStep >= 2 ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>Convert $4k WDC</span>
            </button>
          </div>

          {/* Step 3 */}
          <div className={`p-4 rounded border transition-all ${
            flagshipStep === 3 ? 'bg-amber-500/10 border-amber-500 text-slate-100' : 'bg-[#181e2b] border-[#262e40] text-slate-400'
          }`}>
            <div className="text-[10px] font-mono uppercase tracking-wider mb-1 text-slate-400">Step 3</div>
            <div className="text-sm font-semibold text-slate-200 mb-1">Transfer to Business</div>
            <p className="text-xs text-slate-400 mb-3">Send WDC 1,250 to Apex Logistics Corp.</p>
            <button
              onClick={() => runFlagshipDemoStep(3)}
              className="w-full py-1.5 rounded text-xs font-mono font-medium bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors flex items-center justify-center gap-1"
            >
              {flagshipStep >= 3 ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>Send 1.25k WDC</span>
            </button>
          </div>

          {/* Step 4 */}
          <div className={`p-4 rounded border transition-all ${
            flagshipStep === 4 ? 'bg-amber-500/10 border-amber-500 text-slate-100' : 'bg-[#181e2b] border-[#262e40] text-slate-400'
          }`}>
            <div className="text-[10px] font-mono uppercase tracking-wider mb-1 text-slate-400">Step 4</div>
            <div className="text-sm font-semibold text-slate-200 mb-1">USD Redemption</div>
            <p className="text-xs text-slate-400 mb-3">Apex redeems WDC 500 back to USD cash.</p>
            <button
              onClick={() => runFlagshipDemoStep(4)}
              className="w-full py-1.5 rounded text-xs font-mono font-medium bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors flex items-center justify-center gap-1"
            >
              {flagshipStep >= 4 ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>Redeem $500</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
