import React from 'react';
import { useBank } from '../../context/BankContext';
import { Building2, DollarSign, Layers, ArrowUpRight, CheckCircle2 } from 'lucide-react';

export const BusinessBankingView: React.FC = () => {
  const { bankAccounts, wdcWallets } = useBank();

  const bizAccount = bankAccounts.find(a => a.customerId === 'cust-biz-001') || bankAccounts[3];
  const bizWallet = wdcWallets.find(w => w.customerId === 'cust-biz-001') || wdcWallets[1];

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          WILDCAT ENTERPRISE & CORPORATE BANKING
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          APEX LOGISTICS INFRASTRUCTURE LLC
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          Corporate USD cash operating account, Enterprise WDC Treasury, and automated payroll / supplier payouts
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Operating Cash */}
        <div className="bg-[#121722] border border-[#212631] rounded p-5 space-y-2">
          <div className="text-[11px] font-mono text-slate-400">OPERATING USD CASH</div>
          <div className="font-mono-nums text-3xl font-extrabold text-slate-100">
            ${bizAccount?.balance.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 font-mono">Acct #{bizAccount?.accountNumber}</div>
        </div>

        {/* Corporate WDC Treasury */}
        <div className="bg-gradient-to-br from-[#182030] to-[#111622] border border-amber-500/30 rounded p-5 space-y-2">
          <div className="text-[11px] font-mono text-amber-400 flex items-center justify-between">
            <span>CORPORATE WDC TREASURY</span>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-mono">WDC</span>
          </div>
          <div className="font-mono-nums text-3xl font-extrabold text-amber-300">
            WDC {bizWallet?.balance.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 font-mono">Address: {bizWallet?.address.slice(0, 20)}...</div>
        </div>

        {/* Total Working Capital */}
        <div className="bg-[#121722] border border-[#212631] rounded p-5 space-y-2">
          <div className="text-[11px] font-mono text-slate-400">COMBINED WORKING CAPITAL</div>
          <div className="font-mono-nums text-3xl font-extrabold text-emerald-400">
            ${((bizAccount?.balance || 0) + (bizWallet?.balance || 0)).toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 font-mono">100% Instant Par Liquidity</div>
        </div>
      </div>

      {/* Corporate Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
          <div className="text-xs font-mono text-amber-400 uppercase font-semibold">
            Corporate Payroll & Vendor Payouts
          </div>
          <p className="text-xs text-slate-400">
            Automated batch ACH/WDC payroll instruction dispatching for 1,200 employees and suppliers.
          </p>

          <button
            onClick={() => alert('Executing corporate payroll batch dispatch of $840,000 WDC/USD...')}
            className="w-full py-2.5 rounded text-xs font-semibold bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors"
          >
            Dispatch Monthly Payroll Batch ($840,000)
          </button>
        </div>

        <div className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
          <div className="text-xs font-mono text-amber-400 uppercase font-semibold">
            Supplier Escrow Instructions
          </div>
          <p className="text-xs text-slate-400">
            Smart programmable escrow rules for supplier invoice release upon proof-of-delivery confirmation.
          </p>

          <div className="p-3 bg-[#181e2b] rounded border border-[#262e40] text-xs font-mono text-slate-300">
            Active Escrow: <span className="text-amber-300 font-bold">$250,000 WDC</span> held for AeroDynamics Tech USA Corp
          </div>
        </div>
      </div>
    </div>
  );
};
