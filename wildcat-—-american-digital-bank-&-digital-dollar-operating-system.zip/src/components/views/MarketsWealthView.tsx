import React from 'react';
import { useBank } from '../../context/BankContext';
import { TrendingUp, Compass, LineChart, DollarSign } from 'lucide-react';

export const MarketsWealthView: React.FC = () => {
  const { marketAssets } = useBank();

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          WILDCAT CAPITAL MARKETS & PRIVATE BANKING WEALTH
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          FINANCIAL TERMINAL & INTERNAL MARKETS
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          Deterministic market order book, depth chart, U.S. Equities, Treasuries, and WDC/USD par order book
        </p>
      </div>

      {/* Asset Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {marketAssets.map((asset) => (
          <div key={asset.symbol} className="bg-[#121722] border border-[#212631] rounded p-5 space-y-3">
            <div className="flex justify-between items-center">
              <span className="font-mono font-bold text-amber-300 text-sm">{asset.symbol}</span>
              <span className={`text-xs font-mono font-semibold px-2 py-0.5 rounded ${
                asset.change24hPct >= 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
              }`}>
                {asset.change24hPct >= 0 ? '+' : ''}{asset.change24hPct}%
              </span>
            </div>

            <div className="text-xs font-medium text-slate-300">{asset.name}</div>

            <div className="font-mono-nums text-3xl font-extrabold text-slate-100">
              {asset.symbol === 'WDC/USD' ? `$${asset.price.toFixed(4)}` : `$${asset.price.toLocaleString()}`}
            </div>

            <div className="text-[11px] font-mono text-slate-400 border-t border-[#1d2331] pt-2 flex justify-between">
              <span>High: ${asset.high24h}</span>
              <span>Low: ${asset.low24h}</span>
              <span>Vol: ${(asset.volume24h/1e6).toFixed(0)}M</span>
            </div>
          </div>
        ))}
      </div>

      {/* Order Book Depth Simulation */}
      <div className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
        <div className="text-xs font-mono text-amber-400 uppercase tracking-widest font-semibold">
          Internal Market Order Book (WDC/USD Par Liquidity)
        </div>

        <div className="grid grid-cols-2 gap-6 font-mono text-xs">
          {/* Bids */}
          <div className="p-4 bg-[#181e2b] rounded border border-[#262e40] space-y-2">
            <div className="text-emerald-400 font-bold border-b border-[#262e40] pb-1">BIDS (BUY WDC)</div>
            <div className="space-y-1">
              {marketAssets[0]?.orderBook.bids.map((bid, i) => (
                <div key={i} className="flex justify-between text-slate-300">
                  <span className="text-emerald-400">${bid.price.toFixed(4)}</span>
                  <span>{bid.amount.toLocaleString()} WDC</span>
                </div>
              ))}
            </div>
          </div>

          {/* Asks */}
          <div className="p-4 bg-[#181e2b] rounded border border-[#262e40] space-y-2">
            <div className="text-amber-400 font-bold border-b border-[#262e40] pb-1">ASKS (SELL WDC)</div>
            <div className="space-y-1">
              {marketAssets[0]?.orderBook.asks.map((ask, i) => (
                <div key={i} className="flex justify-between text-slate-300">
                  <span className="text-amber-400">${ask.price.toFixed(4)}</span>
                  <span>{ask.amount.toLocaleString()} WDC</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
