import React from 'react';
import { useBank } from '../../context/BankContext';
import { globalComplianceEngine } from '../../engine/compliance';
import { ShieldCheck, FileText, AlertTriangle, CheckCircle2 } from 'lucide-react';

export const ComplianceView: React.FC = () => {
  const { complianceCases } = useBank();
  const framework = globalComplianceEngine.getFramework();

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          WILDCAT COMPLIANCE OPERATING SYSTEM
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          KYC, CIP, AML & 2026 GENIUS ACT FRAMEWORK
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          Configurable regulatory profile, OCC Banking Circular 104, Federal Reserve Supervision, and BSA/AML monitoring
        </p>
      </div>

      {/* Regulatory Framework Card (Requirement #34 & #62) */}
      <div className="bg-[#121722] border border-amber-500/30 rounded p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-[#212631] pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <h2 className="font-brand text-lg font-bold text-slate-100">
              ACTIVE REGULATORY PROFILE
            </h2>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20">
            {framework.status}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-3 bg-[#181e2b] rounded border border-[#262e40]">
            <div className="text-slate-400">JURISDICTION & ACT</div>
            <div className="text-slate-100 font-bold mt-1">{framework.actName}</div>
          </div>

          <div className="p-3 bg-[#181e2b] rounded border border-[#262e40]">
            <div className="text-slate-400">RESERVE MANDATE</div>
            <div className="text-amber-300 font-bold mt-1">{framework.reserveRequirementPct}.0% Qualified Asset Backing</div>
          </div>

          <div className="p-3 bg-[#181e2b] rounded border border-[#262e40]">
            <div className="text-slate-400">PAR REDEMPTION MANDATE</div>
            <div className="text-emerald-400 font-bold mt-1">Guaranteed &le; {framework.parRedemptionMaxHours} Hours</div>
          </div>
        </div>
      </div>

      {/* Case Management */}
      <div className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
        <div className="text-xs font-mono text-amber-400 uppercase tracking-widest font-semibold">
          Active Compliance & AML Monitoring Cases
        </div>

        <div className="space-y-3">
          {complianceCases.map((c) => (
            <div key={c.id} className="p-4 bg-[#181e2b] rounded border border-[#262e40] space-y-2 text-xs font-mono">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200">{c.customerName} ({c.type})</span>
                <span className={`px-2 py-0.5 rounded text-[10px] ${
                  c.severity === 'CRITICAL' || c.severity === 'HIGH' ? 'bg-red-500/20 text-red-300' : 'bg-amber-500/20 text-amber-300'
                }`}>
                  {c.severity} SEVERITY
                </span>
              </div>

              <p className="text-slate-300">{c.description}</p>

              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-[#252c3d]">
                <span>Flagged: {c.flaggedTimestamp.replace('T', ' ').slice(0, 19)}</span>
                <span>Assigned: {c.assignedOfficer}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
