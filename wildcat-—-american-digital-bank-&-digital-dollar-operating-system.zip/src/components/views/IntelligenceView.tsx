import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { Bot, Send, Sparkles, Database, CheckCircle2, AlertCircle } from 'lucide-react';

export const IntelligenceView: React.FC = () => {
  const { askIntelligence } = useBank();
  const [query, setQuery] = useState<string>('Why did WDC circulation increase?');
  const [response, setResponse] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const sampleQueries = [
    'Why did WDC circulation increase?',
    'Show me today\'s largest liquidity movements',
    'What is driving the increase in reserves?',
    'What happens if WDC redemptions double?',
    'Show me our largest corporate customers',
    'Explain today\'s balance-sheet movement'
  ];

  const handleSearch = async (userPrompt: string) => {
    setLoading(true);
    setQuery(userPrompt);
    const res = await askIntelligence(userPrompt);
    setResponse(res);
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          WILDCAT INTELLIGENCE ENGINE
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          AI BANKING ASSISTANT
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          Analytic intelligence operating on actual double-entry ledger state with strict classification of actual data vs scenario output
        </p>
      </div>

      {/* Query Bar */}
      <div className="bg-[#121722] border border-[#212631] rounded-lg p-6 space-y-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch(query)}
            placeholder="Ask Wildcat Intelligence about ledger, WDC, reserves, or liquidity..."
            className="flex-1 bg-[#181e2b] border border-[#262e40] rounded px-4 py-2.5 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
          />
          <button
            onClick={() => handleSearch(query)}
            disabled={loading}
            className="px-5 py-2.5 rounded bg-amber-500 text-slate-950 font-semibold text-xs hover:bg-amber-400 transition-colors flex items-center gap-1.5 shrink-0"
          >
            <Bot className="w-4 h-4" />
            <span>{loading ? 'Analyzing...' : 'Query'}</span>
          </button>
        </div>

        {/* Sample Suggestions */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-[11px] font-mono text-slate-400">Suggested queries:</span>
          {sampleQueries.map((q) => (
            <button
              key={q}
              onClick={() => handleSearch(q)}
              className="px-2.5 py-1 rounded bg-[#181e2b] border border-[#262e40] text-[11px] font-mono text-slate-300 hover:text-amber-300 hover:border-amber-500/50 transition-colors"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Output Response */}
      {response && (
        <div className="bg-[#121722] border border-amber-500/30 rounded-lg p-6 space-y-5">
          {/* Data Classification Badge (Requirement #42) */}
          <div className="flex items-center justify-between border-b border-[#212631] pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-mono font-bold text-slate-200">Wildcat Intelligence Synthesis</span>
            </div>

            <span className="text-xs font-mono font-bold bg-blue-500/10 text-blue-300 border border-blue-500/30 px-3 py-1 rounded">
              DATA CLASSIFICATION: {response.dataClassification}
            </span>
          </div>

          <p className="text-xs text-slate-200 leading-relaxed font-mono bg-[#181e2b] p-4 rounded border border-[#262e40]">
            {response.answer}
          </p>

          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {response.keyMetrics.map((m: any, i: number) => (
              <div key={i} className="p-3 bg-[#181e2b] rounded border border-[#262e40]">
                <div className="text-[10px] font-mono text-slate-400">{m.label}</div>
                <div className="text-sm font-bold font-mono text-amber-300 mt-0.5">{m.value}</div>
              </div>
            ))}
          </div>

          {/* Follow ups */}
          <div className="pt-2 border-t border-[#212631] space-y-2">
            <div className="text-[11px] font-mono text-slate-400">Follow-up investigations:</div>
            <div className="flex flex-wrap gap-2">
              {response.suggestedFollowUps.map((f: string, i: number) => (
                <button
                  key={i}
                  onClick={() => handleSearch(f)}
                  className="px-2.5 py-1 rounded bg-[#181e2b] border border-[#262e40] text-[11px] font-mono text-amber-400 hover:underline"
                >
                  → {f}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
