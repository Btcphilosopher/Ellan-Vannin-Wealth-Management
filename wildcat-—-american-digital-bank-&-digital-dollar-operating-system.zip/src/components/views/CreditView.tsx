import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { TrendingUp, Plus, Shield, CheckCircle2 } from 'lucide-react';

export const CreditView: React.FC = () => {
  const { loans, originateLoan } = useBank();

  const [loanName, setLoanName] = useState<string>('Apex Logistics Expansion Credit');
  const [loanType, setLoanType] = useState<any>('BUSINESS_LOAN');
  const [principal, setPrincipal] = useState<string>('5000000');
  const [termMonths, setTermMonths] = useState<string>('60');
  const [ratePct, setRatePct] = useState<string>('6.5');
  const [collateralVal, setCollateralVal] = useState<string>('7500000');
  const [notice, setNotice] = useState<string>('');

  const handleOriginate = (e: React.FormEvent) => {
    e.preventDefault();
    const p = parseFloat(principal);
    const t = parseInt(termMonths);
    const r = parseFloat(ratePct);
    const c = parseFloat(collateralVal);

    if (p > 0) {
      originateLoan('cust-biz-001', loanName, loanType, p, t, r, c);
      setNotice(`Originated ${loanType} of $${p.toLocaleString()}! Credit digital twin created.`);
      setTimeout(() => setNotice(''), 4000);
    }
  };

  const totalBookVal = loans.reduce((sum, l) => sum + l.remainingPrincipal, 0);
  const totalExpectedLoss = loans.reduce((sum, l) => sum + l.expectedLoss, 0);

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          WILDCAT LENDING & CREDIT DIGITAL TWIN
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          COMMERCIAL & RETAIL CREDIT ENGINE
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          Probability of Default (PD), Loss Given Default (LGD), and Expected Loss (EL) underwriting digital twins
        </p>
      </div>

      {notice && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs rounded flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Book Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-[#121722] border border-[#212631] rounded">
          <div className="text-[11px] font-mono text-slate-400">TOTAL CREDIT BOOK VALUE</div>
          <div className="font-mono-nums text-2xl font-bold text-slate-100 mt-1">
            ${(totalBookVal/1e6).toFixed(2)}M
          </div>
        </div>

        <div className="p-4 bg-[#121722] border border-[#212631] rounded">
          <div className="text-[11px] font-mono text-slate-400">PORTFOLIO EXPECTED LOSS (EL)</div>
          <div className="font-mono-nums text-2xl font-bold text-amber-300 mt-1">
            ${totalExpectedLoss.toLocaleString()}
          </div>
        </div>

        <div className="p-4 bg-[#121722] border border-[#212631] rounded">
          <div className="text-[11px] font-mono text-slate-400">AVERAGE PORTFOLIO PD</div>
          <div className="font-mono-nums text-2xl font-bold text-emerald-400 mt-1">
            0.52%
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Loan Origination Form */}
        <form onSubmit={handleOriginate} className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
          <div className="text-xs font-mono text-amber-400 uppercase font-semibold flex items-center gap-2">
            <Plus className="w-4 h-4" />
            <span>Originate New Credit Facility</span>
          </div>

          <div>
            <label className="text-[11px] font-mono text-slate-300 block mb-1">Facility Name / Borrower</label>
            <input
              type="text"
              value={loanName}
              onChange={(e) => setLoanName(e.target.value)}
              className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-mono text-slate-300 block mb-1">Product Type</label>
              <select
                value={loanType}
                onChange={(e) => setLoanType(e.target.value)}
                className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
              >
                <option value="BUSINESS_LOAN">Business Loan</option>
                <option value="MORTGAGE">Mortgage</option>
                <option value="WORKING_CAPITAL">Working Capital</option>
                <option value="AUTO_LOAN">Auto Loan</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-mono text-slate-300 block mb-1">Principal Amount ($)</label>
              <input
                type="number"
                value={principal}
                onChange={(e) => setPrincipal(e.target.value)}
                className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-[11px] font-mono text-slate-300 block mb-1">Term (Months)</label>
              <input
                type="number"
                value={termMonths}
                onChange={(e) => setTermMonths(e.target.value)}
                className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-mono text-slate-300 block mb-1">Interest Rate (%)</label>
              <input
                type="number"
                step="0.05"
                value={ratePct}
                onChange={(e) => setRatePct(e.target.value)}
                className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-mono text-slate-300 block mb-1">Collateral ($)</label>
              <input
                type="number"
                value={collateralVal}
                onChange={(e) => setCollateralVal(e.target.value)}
                className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded text-xs font-semibold bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors"
          >
            Underwrite & Originate Facility
          </button>
        </form>

        {/* Credit Digital Twin Facilities Table */}
        <div className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
          <div className="text-xs font-mono text-amber-400 uppercase font-semibold">
            Credit Facilities & Risk Digital Twins
          </div>

          <div className="space-y-3">
            {loans.map((loan) => (
              <div key={loan.id} className="p-4 bg-[#181e2b] rounded border border-[#262e40] space-y-2 font-mono text-xs">
                <div className="flex items-center justify-between text-slate-200">
                  <span className="font-bold">{loan.customerName}</span>
                  <span className="text-amber-300">{loan.type}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-slate-400 text-[11px]">
                  <div>Principal: <span className="text-slate-100">${loan.remainingPrincipal.toLocaleString()}</span></div>
                  <div>Rate: <span className="text-emerald-400">{loan.interestRatePct}%</span></div>
                  <div>Monthly Payment: <span className="text-slate-100">${loan.monthlyPayment.toLocaleString()}</span></div>
                  <div>Collateral: <span className="text-slate-100">${loan.collateralValue.toLocaleString()}</span></div>
                </div>

                <div className="pt-2 border-t border-[#252c3d] flex items-center justify-between text-[10px] text-slate-400">
                  <span>PD: <strong className="text-amber-400">{loan.probabilityOfDefaultPct}%</strong></span>
                  <span>LGD: <strong className="text-slate-300">{loan.lossGivenDefaultPct}%</strong></span>
                  <span>Expected Loss: <strong className="text-amber-300">${loan.expectedLoss}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
