import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { globalReserveEngine } from '../../engine/reserves';
import { Shield, Landmark, AlertTriangle, TrendingUp, Cpu, Activity } from 'lucide-react';

export const TreasuryReservesView: React.FC = () => {
  const { reserveAssets, ledgerAccounts } = useBank();

  // Stress Scenario Lab parameters
  const [redemptionDemand, setRedemptionDemand] = useState<number>(100000000); // $100M
  const [depositOutflowPct, setDepositOutflowPct] = useState<number>(10); // 10%
  const [rateShockBP, setRateShockBP] = useState<number>(200); // +200bp

  const wdcAccount = ledgerAccounts.find(a => a.code === '2020');
  const wdcCirculation = wdcAccount ? wdcAccount.balance : 780000000;
  const totalDeposits = 4800000000;

  const stressResult = globalReserveEngine.runStressTest(
    wdcCirculation,
    totalDeposits,
    redemptionDemand,
    depositOutflowPct,
    rateShockBP
  );

  const totalMarketVal = reserveAssets.reduce((sum, r) => sum + r.marketValue, 0);
  const avgYield = globalReserveEngine.getAverageYield();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          INSTITUTIONAL TREASURY COMMAND CENTRE
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          RESERVE DIGITAL TWIN & LIQUIDITY LAB
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          Real-time reserve asset matching, maturity ladder, and stress scenario engine
        </p>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-[#121722] border border-[#212631] rounded">
          <div className="text-[11px] font-mono text-slate-400">TOTAL RESERVE ASSETS</div>
          <div className="font-mono-nums text-2xl font-bold text-slate-100 mt-1">
            ${(totalMarketVal / 1e6).toFixed(1)}M
          </div>
          <div className="text-[10px] text-emerald-400 font-mono mt-1">100.0% Qualified Assets</div>
        </div>

        <div className="p-4 bg-[#121722] border border-[#212631] rounded">
          <div className="text-[11px] font-mono text-slate-400">WEIGHTED ASSET YIELD</div>
          <div className="font-mono-nums text-2xl font-bold text-amber-300 mt-1">
            {avgYield}%
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-1">Weighted Net Annual Return</div>
        </div>

        <div className="p-4 bg-[#121722] border border-[#212631] rounded">
          <div className="text-[11px] font-mono text-slate-400">WDC CIRCULATION BACKED</div>
          <div className="font-mono-nums text-2xl font-bold text-slate-100 mt-1">
            ${(wdcCirculation / 1e6).toFixed(1)}M
          </div>
          <div className="text-[10px] text-emerald-400 font-mono mt-1">Par Fixed 1:1 USD</div>
        </div>

        <div className="p-4 bg-[#121722] border border-[#212631] rounded">
          <div className="text-[11px] font-mono text-slate-400">LIQUIDITY COVERAGE RATIO</div>
          <div className="font-mono-nums text-2xl font-bold text-emerald-400 mt-1">
            218.4%
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-1">Target Buffer: &gt;120%</div>
        </div>
      </div>

      {/* Reserve Asset Portfolio Table */}
      <div className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
        <div className="text-xs font-mono text-amber-400 uppercase tracking-widest font-semibold flex items-center justify-between">
          <span>Reserve Digital Twin Assets</span>
          <span className="text-[11px] text-slate-400 font-normal">Fed / BNY Mellon Custody</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#212631] text-slate-400">
                <th className="pb-2">ASSET TYPE / CUSIP</th>
                <th className="pb-2">CUSTODIAN</th>
                <th className="pb-2">FACE VALUE</th>
                <th className="pb-2">MARKET VALUE</th>
                <th className="pb-2">MATURITY</th>
                <th className="pb-2">YIELD</th>
                <th className="pb-2">HAIRCUT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1d2331] text-slate-200">
              {reserveAssets.map((asset) => (
                <tr key={asset.id} className="hover:bg-[#181f2d] transition-colors">
                  <td className="py-3">
                    <div className="font-semibold text-slate-100">{asset.assetType.replace(/_/g, ' ')}</div>
                    <div className="text-[10px] text-slate-400">{asset.cusipOrId}</div>
                  </td>
                  <td className="py-3 text-slate-300">{asset.custodian}</td>
                  <td className="py-3 font-mono-nums">${(asset.faceValue/1e6).toFixed(1)}M</td>
                  <td className="py-3 font-mono-nums text-amber-300">${(asset.marketValue/1e6).toFixed(1)}M</td>
                  <td className="py-3 text-slate-300">{asset.maturityDate}</td>
                  <td className="py-3 text-emerald-400">{asset.yieldPct}%</td>
                  <td className="py-3 text-slate-400">{asset.haircutPct}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Liquidity Scenario Lab & Bank Run Simulator (Requirement #15 & #37 & #38) */}
      <div className="bg-[#121722] border border-amber-500/30 rounded p-6 space-y-6">
        <div className="flex items-center justify-between border-b border-[#212631] pb-3">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-amber-400" />
            <h2 className="font-brand text-lg font-bold text-slate-100">
              LIQUIDITY SCENARIO LAB & BANK RUN SIMULATOR
            </h2>
          </div>
          <span className="text-xs font-mono text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded border border-amber-500/20">
            Institutional Stress Twin
          </span>
        </div>

        <p className="text-xs text-slate-400">
          Simulate extreme redemption shocks, bank run deposit outflows, and Federal Reserve interest rate shocks to verify real-time balance sheet resiliency.
        </p>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-[#181e2b] p-5 rounded border border-[#262e40]">
          <div>
            <div className="flex justify-between text-xs font-mono mb-1">
              <span className="text-slate-300">WDC Redemption Demand</span>
              <span className="text-amber-400 font-bold">${(redemptionDemand/1e6).toFixed(0)}M</span>
            </div>
            <input
              type="range"
              min="10000000"
              max="500000000"
              step="10000000"
              value={redemptionDemand}
              onChange={(e) => setRedemptionDemand(parseFloat(e.target.value))}
              className="w-full accent-amber-500"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs font-mono mb-1">
              <span className="text-slate-300">USD Deposit Outflow</span>
              <span className="text-amber-400 font-bold">{depositOutflowPct}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="1"
              value={depositOutflowPct}
              onChange={(e) => setDepositOutflowPct(parseFloat(e.target.value))}
              className="w-full accent-amber-500"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs font-mono mb-1">
              <span className="text-slate-300">Interest Rate Shock</span>
              <span className="text-amber-400 font-bold">+{rateShockBP} BP</span>
            </div>
            <input
              type="range"
              min="0"
              max="500"
              step="25"
              value={rateShockBP}
              onChange={(e) => setRateShockBP(parseFloat(e.target.value))}
              className="w-full accent-amber-500"
            />
          </div>
        </div>

        {/* Stress Result Output */}
        <div className="p-5 rounded bg-[#181e2b] border border-[#262e40] space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-semibold text-slate-200">
              {stressResult.scenarioName}
            </span>
            <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded ${
              stressResult.status === 'NOMINAL' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'
            }`}>
              {stressResult.status}
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <div className="text-[10px] font-mono text-slate-400">REMAINING LIQUID RESERVES</div>
              <div className="font-mono-nums text-xl font-bold text-slate-100">
                ${(stressResult.remainingLiquidReservesUSD/1e6).toFixed(1)}M
              </div>
            </div>

            <div>
              <div className="text-[10px] font-mono text-slate-400">SIMULATED RESERVE COVERAGE</div>
              <div className="font-mono-nums text-xl font-bold text-amber-300">
                {stressResult.reserveRatioPct}%
              </div>
            </div>

            <div>
              <div className="text-[10px] font-mono text-slate-400">SIMULATED LCR RATIO</div>
              <div className="font-mono-nums text-xl font-bold text-emerald-400">
                {stressResult.liquidityCoverageRatioPct}%
              </div>
            </div>

            <div>
              <div className="text-[10px] font-mono text-slate-400">CAPITAL ADEQUACY</div>
              <div className="font-mono-nums text-xl font-bold text-slate-100">
                {stressResult.capitalAdequacyPct}%
              </div>
            </div>
          </div>

          <p className="text-xs font-mono text-slate-300 bg-[#121722] p-3 rounded border border-[#212631]">
            {stressResult.details}
          </p>
        </div>
      </div>
    </div>
  );
};
