import React from 'react';
import { useBank } from '../../context/BankContext';
import { Wallet, ArrowDownRight, ArrowUpRight, Download, Shield } from 'lucide-react';

export const AccountsView: React.FC = () => {
  const { bankAccounts, payments } = useBank();

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          AUTHORITATIVE BANKING ACCOUNTS
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          CHECKING, SAVINGS & TREASURY
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          Double-entry ledger verified deposit accounts with real-time settlement
        </p>
      </div>

      {/* Account Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {bankAccounts.slice(0, 3).map((acc) => (
          <div key={acc.id} className="bg-[#121722] border border-[#212631] rounded p-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono text-amber-400 uppercase font-semibold">{acc.type}</span>
              <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/20">
                {acc.status}
              </span>
            </div>

            <div>
              <div className="text-sm font-semibold text-slate-100">{acc.name}</div>
              <div className="text-xs font-mono text-slate-400 mt-0.5">Acct #{acc.accountNumber} · Routing #{acc.routingNumber}</div>
            </div>

            <div className="border-t border-[#1e2432] pt-3">
              <div className="text-[11px] font-mono text-slate-400">AVAILABLE BALANCE</div>
              <div className="font-mono-nums text-2xl font-extrabold text-slate-100 mt-0.5">
                ${acc.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
              <span>Currency: {acc.currency}</span>
              <button 
                onClick={() => alert(`Downloading official bank statement for account ${acc.accountNumber}...`)}
                className="text-amber-400 hover:underline flex items-center gap-1 font-mono text-[11px]"
              >
                <Download className="w-3 h-3" />
                <span>Statement</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Ledger Transactions */}
      <div className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
        <div className="text-xs font-mono text-amber-400 uppercase tracking-widest font-semibold">
          Recent Bank Ledger Transactions
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#212631] text-slate-400">
                <th className="pb-2">REFERENCE</th>
                <th className="pb-2">DESCRIPTION</th>
                <th className="pb-2">RAIL</th>
                <th className="pb-2">AMOUNT</th>
                <th className="pb-2">STATE</th>
                <th className="pb-2">TIMESTAMP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1d2331] text-slate-200">
              {payments.map((p) => (
                <tr key={p.id} className="hover:bg-[#181f2d]">
                  <td className="py-3 text-amber-300 font-semibold">{p.reference}</td>
                  <td className="py-3 text-slate-200">{p.description}</td>
                  <td className="py-3 text-slate-400">{p.rail}</td>
                  <td className="py-3 font-mono-nums font-bold text-slate-100">${p.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                  <td className="py-3 text-emerald-400">{p.state}</td>
                  <td className="py-3 text-slate-400">{p.timestamp.replace('T', ' ').slice(0, 19)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
