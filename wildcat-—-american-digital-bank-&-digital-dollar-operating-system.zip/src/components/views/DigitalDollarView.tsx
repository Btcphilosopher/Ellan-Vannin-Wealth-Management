import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { 
  DollarSign, Shield, ArrowDownLeft, Send, RefreshCw, 
  Layers, Lock, CheckCircle2, AlertCircle, FileText, Cpu
} from 'lucide-react';

export const DigitalDollarView: React.FC = () => {
  const { 
    wdcWallets, ledgerAccounts, reserveAssets, mintWDC, redeemWDC, 
    transferWDC, activeRole, setActiveRole 
  } = useBank();

  const [activeTab, setActiveTab] = useState<'WALLET' | 'ISSUER' | 'EXPLORER'>('WALLET');
  
  // Mint & Redeem Form State
  const [mintAmount, setMintAmount] = useState<string>('5000');
  const [redeemAmount, setRedeemAmount] = useState<string>('1000');
  const [transferAmount, setTransferAmount] = useState<string>('500');
  const [recipientAddr, setRecipientAddr] = useState<string>('wdc1qapex94820193820193820192');
  const [notice, setNotice] = useState<string>('');

  const wdcAccount = ledgerAccounts.find(a => a.code === '2020');
  const wdcOutstanding = wdcAccount ? wdcAccount.balance : 780000000;
  const reserveTotal = reserveAssets.reduce((sum, r) => sum + r.marketValue, 0);
  const myWallet = wdcWallets.find(w => w.customerId === 'cust-retail-001') || wdcWallets[0];

  const handleMint = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(mintAmount);
    if (val > 0) {
      mintWDC('cust-retail-001', val, 'Checking');
      setNotice(`Successfully minted WDC ${val.toLocaleString()}! Ledger entries posted.`);
      setTimeout(() => setNotice(''), 4000);
    }
  };

  const handleRedeem = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(redeemAmount);
    if (val > 0) {
      redeemWDC('cust-retail-001', val, 'Checking');
      setNotice(`Successfully redeemed WDC ${val.toLocaleString()} to USD Checking!`);
      setTimeout(() => setNotice(''), 4000);
    }
  };

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(transferAmount);
    if (val > 0 && myWallet) {
      const tx = transferWDC(myWallet.id, recipientAddr, val);
      setNotice(`Transferred WDC ${val.toLocaleString()}! Transaction Hash: ${tx.slice(0, 16)}...`);
      setTimeout(() => setNotice(''), 5000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-[#212631] pb-5 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
              WILDCAT OS · PROGRAMMABLE MONEY
            </span>
          </div>
          <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 flex items-center gap-2 mt-1">
            <span>WILDCAT DIGITAL DOLLAR</span>
            <span className="text-xs font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded">
              WDC
            </span>
          </h1>
          <p className="text-slate-400 text-xs mt-1">
            A 1:1 par payment-dollar instrument backed 100% by US Treasury Bills and Fed Reserve Cash
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-[#121722] p-1 rounded border border-[#212631]">
          <button
            onClick={() => setActiveTab('WALLET')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              activeTab === 'WALLET' ? 'bg-[#1e2536] text-amber-300 shadow-sm font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Digital Wallet
          </button>
          <button
            onClick={() => setActiveTab('ISSUER')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              activeTab === 'ISSUER' ? 'bg-[#1e2536] text-amber-300 shadow-sm font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Institutional Issuer Console
          </button>
          <button
            onClick={() => setActiveTab('EXPLORER')}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              activeTab === 'EXPLORER' ? 'bg-[#1e2536] text-amber-300 shadow-sm font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Ledger Explorer
          </button>
        </div>
      </div>

      {notice && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs rounded flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* 1. WALLET TAB */}
      {activeTab === 'WALLET' && (
        <div className="space-y-6">
          {/* Main Wallet Card */}
          <div className="bg-gradient-to-br from-[#161c28] to-[#0f141f] border border-amber-500/30 rounded-lg p-6 relative overflow-hidden">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="text-xs font-mono text-amber-400 uppercase tracking-widest mb-1">
                  Primary Customer Wallet
                </div>
                <div className="font-mono text-xs text-slate-400 bg-[#0d1118] px-3 py-1 rounded inline-block border border-[#212631] mb-3">
                  Address: {myWallet?.address}
                </div>
                <div className="font-mono-nums text-4xl md:text-5xl font-extrabold text-amber-300 tracking-tight">
                  WDC {myWallet?.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
              </div>

              <div className="space-y-2 text-right">
                <div className="text-xs text-slate-400">Available Balance: <span className="font-mono text-slate-200">WDC {myWallet?.availableBalance.toLocaleString()}</span></div>
                <div className="text-xs text-slate-400">Pending Settlement: <span className="font-mono text-slate-200">WDC {myWallet?.pendingBalance.toLocaleString()}</span></div>
                <div className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded border border-emerald-500/20 inline-block">
                  Par Fixed Peg: 1 WDC = $1.00 USD
                </div>
              </div>
            </div>
          </div>

          {/* Action Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Mint WDC Form */}
            <form onSubmit={handleMint} className="bg-[#121722] border border-[#212631] rounded p-5 space-y-4">
              <div className="text-xs font-mono text-amber-400 uppercase font-semibold flex items-center gap-1.5">
                <DollarSign className="w-4 h-4" />
                <span>Mint WDC (USD → WDC)</span>
              </div>
              <p className="text-xs text-slate-400">
                Converts USD checking balance into WDC. Automatically allocates 100% backing in US Treasury Bills.
              </p>
              <div>
                <label className="text-[11px] font-mono text-slate-300 block mb-1">Amount USD</label>
                <input
                  type="number"
                  value={mintAmount}
                  onChange={(e) => setMintAmount(e.target.value)}
                  className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2 rounded text-xs font-medium bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors font-semibold"
              >
                Execute Minting Journal
              </button>
            </form>

            {/* Transfer WDC Form */}
            <form onSubmit={handleTransfer} className="bg-[#121722] border border-[#212631] rounded p-5 space-y-4">
              <div className="text-xs font-mono text-amber-400 uppercase font-semibold flex items-center gap-1.5">
                <Send className="w-4 h-4" />
                <span>Transfer WDC</span>
              </div>
              <div>
                <label className="text-[11px] font-mono text-slate-300 block mb-1">Recipient Address</label>
                <input
                  type="text"
                  value={recipientAddr}
                  onChange={(e) => setRecipientAddr(e.target.value)}
                  className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-[11px] font-mono text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="text-[11px] font-mono text-slate-300 block mb-1">Amount WDC</label>
                <input
                  type="number"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e.target.value)}
                  className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2 rounded text-xs font-medium bg-[#1a2333] border border-[#2e374d] text-amber-300 hover:bg-[#202a3d] transition-colors"
              >
                Send WDC Instruction
              </button>
            </form>

            {/* Redeem WDC Form */}
            <form onSubmit={handleRedeem} className="bg-[#121722] border border-[#212631] rounded p-5 space-y-4">
              <div className="text-xs font-mono text-amber-400 uppercase font-semibold flex items-center gap-1.5">
                <RefreshCw className="w-4 h-4" />
                <span>Redeem WDC (WDC → USD)</span>
              </div>
              <p className="text-xs text-slate-400">
                Burns WDC instrument and credits USD checking account at 1:1 par value.
              </p>
              <div>
                <label className="text-[11px] font-mono text-slate-300 block mb-1">Amount WDC to Redeem</label>
                <input
                  type="number"
                  value={redeemAmount}
                  onChange={(e) => setRedeemAmount(e.target.value)}
                  className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2 rounded text-xs font-medium bg-emerald-600 text-slate-950 hover:bg-emerald-500 transition-colors font-semibold"
              >
                Redeem to USD Checking
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 2. ISSUER CONSOLE TAB (Requirement #7) */}
      {activeTab === 'ISSUER' && (
        <div className="space-y-6">
          <div className="bg-[#121722] border border-[#212631] rounded p-6">
            <div className="text-xs font-mono text-amber-400 uppercase tracking-widest mb-2">
              Institutional Issuance & Reserve Dashboard
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
              <div className="p-4 bg-[#181e2b] rounded border border-[#262e40]">
                <div className="text-[11px] font-mono text-slate-400">WDC OUTSTANDING</div>
                <div className="font-mono-nums text-2xl font-bold text-slate-100 mt-1">
                  ${(wdcOutstanding/1e6).toFixed(1)}M
                </div>
                <div className="text-[10px] text-slate-400 mt-1">Authoritative Liability Code 2020</div>
              </div>

              <div className="p-4 bg-[#181e2b] rounded border border-[#262e40]">
                <div className="text-[11px] font-mono text-slate-400">RESERVE BACKING</div>
                <div className="font-mono-nums text-2xl font-bold text-emerald-400 mt-1">
                  ${(reserveTotal/1e6).toFixed(1)}M
                </div>
                <div className="text-[10px] text-slate-400 mt-1">US T-Bills & Fed Cash Assets</div>
              </div>

              <div className="p-4 bg-[#181e2b] rounded border border-[#262e40]">
                <div className="text-[11px] font-mono text-slate-400">RESERVE COVERAGE RATIO</div>
                <div className="font-mono-nums text-2xl font-bold text-amber-300 mt-1">
                  {((reserveTotal / wdcOutstanding) * 100).toFixed(2)}%
                </div>
                <div className="text-[10px] text-emerald-400 mt-1">100.0% Qualified Backing</div>
              </div>

              <div className="p-4 bg-[#181e2b] rounded border border-[#262e40]">
                <div className="text-[11px] font-mono text-slate-400">NET ISSUANCE TODAY</div>
                <div className="font-mono-nums text-2xl font-bold text-slate-100 mt-1">
                  +$4.3M
                </div>
                <div className="text-[10px] text-slate-400 mt-1">Minted: $12.7M | Redeemed: $8.4M</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. EXPLORER TAB (Requirement #59) */}
      {activeTab === 'EXPLORER' && (
        <div className="bg-[#121722] border border-[#212631] rounded p-6 space-y-4">
          <div className="text-xs font-mono text-amber-400 uppercase tracking-widest">
            Wildcat Digital Dollar Double-Entry Ledger Inspector
          </div>
          <p className="text-xs text-slate-400">
            Authoritative bank ledger transaction records with double-entry debit/credit verification.
          </p>

          <div className="space-y-3">
            <div className="p-4 bg-[#181e2b] rounded border border-[#262e40] font-mono text-xs space-y-2">
              <div className="flex items-center justify-between text-slate-300 border-b border-[#262e40] pb-2">
                <span>TX ID: WDC-MINT-881920</span>
                <span className="text-emerald-400 font-semibold">SETTLED</span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-slate-400">
                <div>From: USD Checking (1004820912)</div>
                <div>To: WDC Wallet (wdc1qvance...)</div>
                <div>Amount: WDC 4,000.00</div>
                <div>Journal: DR Cash (1010) $4k / CR WDC (2020) $4k</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
