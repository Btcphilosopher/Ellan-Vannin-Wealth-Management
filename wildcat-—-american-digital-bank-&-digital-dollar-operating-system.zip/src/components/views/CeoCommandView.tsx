import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { globalBankDigitalTwin } from '../../engine/digitalTwin';
import { Cpu, Play, FastForward, Sliders, Shield } from 'lucide-react';

export const CeoCommandView: React.FC = () => {
  const { founderSettings, updateFounderSettings, ledgerAccounts, reserveAssets } = useBank();

  const [retailCount, setRetailCount] = useState<number>(founderSettings.retailCustomersCount);
  const [deposits, setDeposits] = useState<number>(founderSettings.totalDepositsUSD);
  const [wdcCirc, setWdcCirc] = useState<number>(founderSettings.wdcCirculationUSD);

  const timeline = globalBankDigitalTwin.generateSimulationTimeline();
  const [selectedStageIndex, setSelectedStageIndex] = useState<number>(0);
  const currentStage = timeline[selectedStageIndex];

  const handleApplyFounderConfig = (e: React.FormEvent) => {
    e.preventDefault();
    updateFounderSettings({
      retailCustomersCount: retailCount,
      totalDepositsUSD: deposits,
      wdcCirculationUSD: wdcCirc,
      reserveAssetsUSD: wdcCirc
    });
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          WILDCAT COMMAND · FOUNDER & CEO COCKPIT
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          WILDCAT COMMAND & FINANCIAL DIGITAL TWIN
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          Whole-institution single-screen cockpit with "Build the Bank" forward timeline simulation
        </p>
      </div>

      {/* Whole Bank Cockpit Banner (Requirement #41) */}
      <div className="bg-[#121722] border border-[#212631] rounded-lg p-6 space-y-4">
        <div className="text-xs font-mono text-amber-400 uppercase tracking-widest font-semibold">
          Whole Institution Metrics (Live Digital Twin)
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 font-mono">
          <div className="p-3 bg-[#181e2b] rounded border border-[#262e40]">
            <div className="text-[10px] text-slate-400">TOTAL CUSTOMERS</div>
            <div className="text-lg font-bold text-slate-100">{currentStage.customers.toLocaleString()}</div>
          </div>

          <div className="p-3 bg-[#181e2b] rounded border border-[#262e40]">
            <div className="text-[10px] text-slate-400">DEPOSIT BASE</div>
            <div className="text-lg font-bold text-slate-100">${(currentStage.depositsUSD/1e9).toFixed(2)}B</div>
          </div>

          <div className="p-3 bg-[#181e2b] rounded border border-[#262e40]">
            <div className="text-[10px] text-slate-400">WDC CIRCULATION</div>
            <div className="text-lg font-bold text-amber-300">${(currentStage.wdcCirculationUSD/1e6).toFixed(0)}M</div>
          </div>

          <div className="p-3 bg-[#181e2b] rounded border border-[#262e40]">
            <div className="text-[10px] text-slate-400">RESERVE BACKING</div>
            <div className="text-lg font-bold text-emerald-400">${(currentStage.reserveAssetsUSD/1e6).toFixed(0)}M</div>
          </div>

          <div className="p-3 bg-[#181e2b] rounded border border-[#262e40]">
            <div className="text-[10px] text-slate-400">CREDIT BOOK</div>
            <div className="text-lg font-bold text-slate-100">${(currentStage.loansUSD/1e9).toFixed(2)}B</div>
          </div>

          <div className="p-3 bg-[#181e2b] rounded border border-[#262e40]">
            <div className="text-[10px] text-slate-400">COMMON EQUITY</div>
            <div className="text-lg font-bold text-slate-100">${(currentStage.equityUSD/1e9).toFixed(2)}B</div>
          </div>
        </div>
      </div>

      {/* "BUILD THE BANK" / FOUNDER MODE (Requirement #66 & #67) */}
      <div className="bg-[#121722] border border-amber-500/30 rounded p-6 space-y-6">
        <div className="flex items-center justify-between border-b border-[#212631] pb-3">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-amber-400" />
            <h2 className="font-brand text-lg font-bold text-slate-100">
              BUILD THE BANK — SIMULATION FORWARD ENGINE
            </h2>
          </div>
          <span className="text-xs font-mono text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded border border-amber-500/20">
            Stage: {currentStage.label}
          </span>
        </div>

        {/* Timeline Stage Selector Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {timeline.map((st, idx) => (
            <button
              key={st.day}
              onClick={() => setSelectedStageIndex(idx)}
              className={`p-3 rounded text-left border font-mono transition-all ${
                selectedStageIndex === idx
                  ? 'bg-amber-500 text-slate-950 font-bold border-amber-400 shadow-lg'
                  : 'bg-[#181e2b] text-slate-300 border-[#262e40] hover:border-amber-500/50'
              }`}
            >
              <div className="text-[10px] opacity-80 uppercase">{st.label.split(' ')[0]} {st.label.split(' ')[1]}</div>
              <div className="text-xs font-extrabold mt-1">${(st.depositsUSD/1e9).toFixed(1)}B Dep</div>
            </button>
          ))}
        </div>

        {/* Founder Settings Form */}
        <form onSubmit={handleApplyFounderConfig} className="p-5 bg-[#181e2b] rounded border border-[#262e40] space-y-4">
          <div className="text-xs font-mono text-amber-400 uppercase font-semibold">
            Configure Initial Bank Operating Parameters
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
            <div>
              <label className="text-slate-300 block mb-1">Retail Customer Base</label>
              <input
                type="number"
                value={retailCount}
                onChange={(e) => setRetailCount(parseInt(e.target.value))}
                className="w-full bg-[#121722] border border-[#262e40] rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-300 block mb-1">Total Deposits USD ($)</label>
              <input
                type="number"
                value={deposits}
                onChange={(e) => setDeposits(parseFloat(e.target.value))}
                className="w-full bg-[#121722] border border-[#262e40] rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="text-slate-300 block mb-1">WDC Circulation Target ($)</label>
              <input
                type="number"
                value={wdcCirc}
                onChange={(e) => setWdcCirc(parseFloat(e.target.value))}
                className="w-full bg-[#121722] border border-[#262e40] rounded px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <button
            type="submit"
            className="py-2 px-4 rounded text-xs font-semibold bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors"
          >
            Re-simulate Digital Twin Architecture
          </button>
        </form>
      </div>
    </div>
  );
};
