import React, { useState } from 'react';
import { useBank } from '../../context/BankContext';
import { Store, CheckCircle2, CreditCard, DollarSign } from 'lucide-react';

export const MerchantView: React.FC = () => {
  const { makePayment } = useBank();
  const [amount, setAmount] = useState<string>('1240.00');
  const [payMethod, setPayMethod] = useState<'USD' | 'WDC' | 'CARD'>('WDC');
  const [notice, setNotice] = useState<string>('');

  const handleCharge = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (val > 0) {
      makePayment(
        'acc-vance-checking', 'Alexander Vance Checking',
        'acc-apex-biz', 'Merchant POS Terminal',
        val, payMethod === 'WDC' ? 'WDC' : 'CARD', 'USD', 'POS Merchant Sale'
      );
      setNotice(`Merchant received $${val.toLocaleString()} via ${payMethod}. Instant ledger settlement complete.`);
      setTimeout(() => setNotice(''), 4000);
    }
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-[#212631] pb-5">
        <div className="text-xs font-mono text-amber-400 font-semibold uppercase tracking-wider">
          WILDCAT MERCHANT INFRASTRUCTURE
        </div>
        <h1 className="font-brand text-2xl md:text-3xl font-bold tracking-tight text-slate-100 mt-1">
          MERCHANT ACCEPTANCE & INSTANT POS SETTLEMENT
        </h1>
        <p className="text-slate-400 text-xs mt-1">
          Accept USD, Card, or WDC Digital Dollar with zero interchange friction and zero-delay ledger settlement
        </p>
      </div>

      {notice && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs rounded flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      <div className="max-w-md mx-auto bg-[#121722] border border-[#212631] rounded-lg p-6 space-y-5">
        <div className="text-center space-y-1">
          <Store className="w-8 h-8 text-amber-400 mx-auto" />
          <h2 className="font-brand text-lg font-bold text-slate-100">WILDCAT POS TERMINAL</h2>
          <p className="text-xs text-slate-400 font-mono">Terminal ID: NY-MERCHANT-8819</p>
        </div>

        <form onSubmit={handleCharge} className="space-y-4">
          <div>
            <label className="text-[11px] font-mono text-slate-300 block mb-1">Select Payment Instrument</label>
            <div className="grid grid-cols-3 gap-2">
              {(['WDC', 'USD', 'CARD'] as const).map((m) => (
                <button
                  type="button"
                  key={m}
                  onClick={() => setPayMethod(m)}
                  className={`py-2 text-xs font-mono rounded border transition-colors ${
                    payMethod === m ? 'bg-amber-500/20 text-amber-300 border-amber-500 font-bold' : 'bg-[#181e2b] text-slate-400 border-[#262e40]'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[11px] font-mono text-slate-300 block mb-1">Transaction Amount ($)</label>
            <input
              type="number"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-[#181e2b] border border-[#262e40] rounded px-3 py-2 text-xl font-mono text-center font-bold text-slate-100 focus:outline-none focus:border-amber-500"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded text-xs font-bold bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors uppercase tracking-wider"
          >
            Authorize & Settle $1,240.00
          </button>
        </form>
      </div>
    </div>
  );
};
