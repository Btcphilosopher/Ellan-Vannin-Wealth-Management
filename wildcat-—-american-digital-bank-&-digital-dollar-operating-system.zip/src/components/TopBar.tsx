import React from 'react';
import { useBank } from '../context/BankContext';
import { Shield, Sparkles, Terminal, Activity, Layers } from 'lucide-react';

export const TopBar: React.FC = () => {
  const { activeRole, setActiveRole, reconciliation, runFlagshipDemoStep, flagshipStep, setActiveView } = useBank();

  return (
    <header className="h-16 border-b border-[#212631] bg-[#0f141d] px-6 flex items-center justify-between sticky top-0 z-40">
      {/* Zone 1: Single Brand Element */}
      <div className="flex items-center gap-4">
        <div 
          onClick={() => setActiveView('HOME')}
          className="cursor-pointer flex items-center gap-3 group"
        >
          <div className="w-8 h-8 rounded bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center font-brand font-bold text-slate-950 text-lg shadow-md group-hover:scale-105 transition-transform">
            W
          </div>
          <div>
            <div className="font-brand text-lg font-bold tracking-widest text-slate-100 group-hover:text-amber-400 transition-colors">
              WILDCAT
            </div>
            <div className="text-[10px] tracking-widest font-mono text-slate-400 -mt-1 uppercase">
              Financial Systems
            </div>
          </div>
        </div>

        {/* Ledger Integrity Badge */}
        <div className="hidden lg:flex items-center gap-2 px-2.5 py-1 rounded bg-[#161c27] border border-[#212631] text-xs font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-slate-300">LEDGER:</span>
          <span className="text-emerald-400 font-semibold">{reconciliation.status}</span>
          <span className="text-slate-500 text-[10px]">({reconciliation.status === 'RECONCILED' ? 'DR = CR' : 'CHECK'})</span>
        </div>
      </div>

      {/* Zone 2: Navigation / Quick Flagship Trigger */}
      <div className="hidden md:flex items-center gap-3">
        <button
          onClick={() => {
            setActiveView('HOME');
            runFlagshipDemoStep(1);
          }}
          className="px-3 py-1.5 rounded text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20 transition-all flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Run Flagship Demo {flagshipStep > 0 ? `(Step ${flagshipStep}/4)` : ''}</span>
        </button>

        <button
          onClick={() => setActiveView('INTELLIGENCE')}
          className="px-3 py-1.5 rounded text-xs font-medium bg-[#161c27] text-slate-300 border border-[#212631] hover:text-white transition-all flex items-center gap-1.5"
        >
          <Terminal className="w-3.5 h-3.5 text-blue-400" />
          <span>Wildcat Intelligence</span>
        </button>
      </div>

      {/* Zone 3: Active Profile / Role Selector */}
      <div className="flex items-center gap-3">
        <div className="text-right hidden sm:block">
          <div className="text-xs font-medium text-slate-200">System Operator</div>
          <div className="text-[10px] font-mono text-slate-400">NY-FED-NODE-01</div>
        </div>

        <select
          value={activeRole}
          onChange={(e) => {
            const role = e.target.value as any;
            setActiveRole(role);
            if (role === 'CEO_COMMAND') setActiveView('CEO_COMMAND');
            if (role === 'ISSUER_CONSOLE') setActiveView('WDC');
          }}
          className="bg-[#161c27] border border-[#262c3a] text-slate-200 text-xs rounded px-3 py-1.5 font-medium focus:outline-none focus:border-amber-500"
        >
          <option value="RETAIL">Retail Customer (A. Vance)</option>
          <option value="BUSINESS">Corporate (Apex Logistics)</option>
          <option value="INSTITUTIONAL">Institutional (Manhattan Capital)</option>
          <option value="ISSUER_CONSOLE">WDC Issuer Console</option>
          <option value="CEO_COMMAND">CEO Wildcat Command</option>
        </select>
      </div>
    </header>
  );
};
