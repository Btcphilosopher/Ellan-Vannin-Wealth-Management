import React from 'react';
import { useBank } from '../context/BankContext';
import { 
  Home, Wallet, ArrowLeftRight, CreditCard, DollarSign, 
  Landmark, TrendingUp, Building2, Store, ShieldCheck, 
  Cpu, Bot, Code2, Scale, Compass
} from 'lucide-react';

export const SidebarNav: React.FC = () => {
  const { activeView, setActiveView } = useBank();

  const navItems = [
    { id: 'HOME', label: 'Home', icon: Home, badge: 'Core' },
    { id: 'ACCOUNTS', label: 'Accounts', icon: Wallet },
    { id: 'PAYMENTS', label: 'Payments', icon: ArrowLeftRight },
    { id: 'CARDS', label: 'Cards', icon: CreditCard },
    { id: 'WDC', label: 'WDC Digital Dollar', icon: DollarSign, highlight: true },
    { id: 'TREASURY', label: 'Treasury & Reserves', icon: Landmark },
    { id: 'CREDIT', label: 'Credit & Lending', icon: TrendingUp },
    { id: 'MARKETS', label: 'Markets & Wealth', icon: Compass },
    { id: 'BUSINESS', label: 'Business Banking', icon: Building2 },
    { id: 'MERCHANT', label: 'Merchant Acceptance', icon: Store },
    { id: 'COMPLIANCE', label: 'Compliance & Risk', icon: ShieldCheck },
    { id: 'CEO_COMMAND', label: 'Wildcat Command', icon: Cpu, badge: 'CEO' },
    { id: 'INTELLIGENCE', label: 'Wildcat Intelligence', icon: Bot },
    { id: 'API', label: 'API & Developer SDK', icon: Code2 },
    { id: 'RECONCILIATION', label: 'Ledger Audit', icon: Scale },
  ];

  return (
    <aside className="w-64 bg-[#0d1117] border-r border-[#212631] flex flex-col shrink-0 h-[calc(100vh-4rem)] sticky top-16 select-none overflow-y-auto">
      <div className="p-4 text-[11px] font-mono font-semibold tracking-wider text-slate-400 uppercase border-b border-[#1b202c]">
        Wildcat OS Modules
      </div>

      <nav className="p-2 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded text-xs font-medium transition-colors ${
                isActive
                  ? 'bg-[#1a212f] text-amber-400 font-semibold border-l-2 border-amber-500'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-[#121721]'
              } ${item.highlight ? 'bg-amber-500/5 text-amber-300' : ''}`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-amber-400' : item.highlight ? 'text-amber-400' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge && (
                <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                  item.badge === 'CEO' ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-800 text-slate-400'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Institutional Descriptor Footer */}
      <div className="mt-auto p-4 border-t border-[#1b202c] text-[11px] font-mono text-slate-400 leading-tight">
        <div className="text-slate-300 font-semibold">WILDCAT FINANCIAL</div>
        <div className="text-slate-400 text-[10px]">New York · Chicago · San Francisco</div>
        <div className="mt-2 text-[10px] text-slate-400">Ledger v3.7 · Synthetic Banking Operating System</div>
      </div>
    </aside>
  );
};
