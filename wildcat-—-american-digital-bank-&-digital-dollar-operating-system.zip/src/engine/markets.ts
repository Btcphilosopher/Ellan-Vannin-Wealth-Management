import { MarketAsset } from '../types/bank';
import { INITIAL_MARKET_ASSETS } from './seedData';

export class MarketsEngine {
  private assets: MarketAsset[];

  constructor() {
    this.assets = [...INITIAL_MARKET_ASSETS];
  }

  public getAssets(): MarketAsset[] {
    return [...this.assets];
  }

  public getAssetBySymbol(symbol: string): MarketAsset | undefined {
    return this.assets.find(a => a.symbol === symbol);
  }

  public simulateMarketTick() {
    this.assets.forEach(asset => {
      if (asset.symbol === 'WDC/USD') return; // Par peg
      const changePct = (Math.random() - 0.48) * 0.2;
      asset.price = Number((asset.price * (1 + changePct / 100)).toFixed(2));
      asset.change24hPct = Number((asset.change24hPct + changePct).toFixed(2));
    });
  }
}

export const globalMarketsEngine = new MarketsEngine();
