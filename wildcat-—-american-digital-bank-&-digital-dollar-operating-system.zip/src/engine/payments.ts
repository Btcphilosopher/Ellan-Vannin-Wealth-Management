import { PaymentTransaction, PaymentState, PaymentRail, ProgrammablePaymentRule } from '../types/bank';
import { INITIAL_PAYMENTS, INITIAL_PROGRAMMABLE_RULES } from './seedData';
import { globalLedger } from './ledger';

export class PaymentsEngine {
  private payments: PaymentTransaction[];
  private rules: ProgrammablePaymentRule[];

  constructor() {
    this.payments = [...INITIAL_PAYMENTS];
    this.rules = [...INITIAL_PROGRAMMABLE_RULES];
  }

  public getPayments(): PaymentTransaction[] {
    return [...this.payments];
  }

  public getRules(): ProgrammablePaymentRule[] {
    return [...this.rules];
  }

  public createPayment(
    fromAccountId: string,
    fromAccountName: string,
    toAccountId: string,
    toAccountName: string,
    amount: number,
    rail: PaymentRail,
    currency: 'USD' | 'WDC' = 'USD',
    description: string
  ): PaymentTransaction {
    const timestamp = new Date().toISOString();
    const payment: PaymentTransaction = {
      id: `pay-${Date.now()}`,
      fromAccountId,
      fromAccountName,
      toAccountId,
      toAccountName,
      amount,
      currency,
      rail,
      state: 'CREATED',
      reference: `${rail}-${Date.now().toString().slice(-8)}`,
      description,
      timestamp,
      fee: rail === 'FEDWIRE' ? 15.00 : 0.00,
      stateHistory: [
        { state: 'CREATED', timestamp, note: 'Payment instruction registered' }
      ]
    };

    this.payments.unshift(payment);
    this.advancePaymentState(payment.id, 'AUTHORIZED', '2FA Passkey authorization confirmed');
    this.advancePaymentState(payment.id, 'PENDING', 'Queued for settlement engine');
    this.advancePaymentState(payment.id, 'PROCESSING', 'Submitted to ACH/Fedwire clearing node');
    this.advancePaymentState(payment.id, 'SETTLED', 'Clearing complete. Authoritative ledger updated.');

    // Execute double entry ledger journal
    globalLedger.postJournal(
      payment.reference,
      `Payment ${rail} $${amount.toFixed(2)} from ${fromAccountName} to ${toAccountName}`,
      [
        { accountCode: '2010', type: 'DEBIT', amount },
        { accountCode: '2010', type: 'CREDIT', amount }
      ],
      'PAYMENT_STATE_MACHINE'
    );

    return payment;
  }

  public advancePaymentState(paymentId: string, newState: PaymentState, note: string) {
    const payment = this.payments.find(p => p.id === paymentId);
    if (payment) {
      payment.state = newState;
      payment.stateHistory.push({
        state: newState,
        timestamp: new Date().toISOString(),
        note
      });
    }
  }

  public createRule(rule: Omit<ProgrammablePaymentRule, 'id' | 'createdAt' | 'executionHistory'>): ProgrammablePaymentRule {
    const newRule: ProgrammablePaymentRule = {
      ...rule,
      id: `rule-${Date.now()}`,
      createdAt: new Date().toISOString(),
      executionHistory: []
    };
    this.rules.unshift(newRule);
    return newRule;
  }

  public executeRule(ruleId: string): boolean {
    const rule = this.rules.find(r => r.id === ruleId);
    if (!rule || rule.status !== 'ACTIVE') return false;

    rule.executionHistory.unshift({
      timestamp: new Date().toISOString(),
      amountExecuted: rule.amountOrPct,
      status: 'SETTLED'
    });

    return true;
  }
}

export const globalPaymentsEngine = new PaymentsEngine();
