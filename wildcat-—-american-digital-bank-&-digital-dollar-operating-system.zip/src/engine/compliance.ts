import { ComplianceCase } from '../types/bank';
import { INITIAL_COMPLIANCE_CASES } from './seedData';

export interface RegulatoryFrameworkProfile {
  jurisdiction: string;
  actName: string;
  effectiveYear: number;
  reserveRequirementPct: number;
  monthlyAuditMandatory: boolean;
  parRedemptionMaxHours: number;
  amlReportingThresholdUSD: number;
  status: 'ACTIVE_COMPLIANT' | 'SUPERVISION_NOTICE' | 'NON_COMPLIANT';
}

export class ComplianceEngine {
  private cases: ComplianceCase[];
  private framework: RegulatoryFrameworkProfile;

  constructor() {
    this.cases = [...INITIAL_COMPLIANCE_CASES];
    this.framework = {
      jurisdiction: 'United States Federal (OCC & Federal Reserve)',
      actName: 'GENIUS Act 2026 Payment-Stablecoin Framework & OCC Banking Circular 104',
      effectiveYear: 2026,
      reserveRequirementPct: 100.0,
      monthlyAuditMandatory: true,
      parRedemptionMaxHours: 24,
      amlReportingThresholdUSD: 10000,
      status: 'ACTIVE_COMPLIANT'
    };
  }

  public getCases(): ComplianceCase[] {
    return [...this.cases];
  }

  public getFramework(): RegulatoryFrameworkProfile {
    return { ...this.framework };
  }

  public updateFramework(updates: Partial<RegulatoryFrameworkProfile>) {
    this.framework = { ...this.framework, ...updates };
  }

  public createCase(caseData: Omit<ComplianceCase, 'id' | 'flaggedTimestamp'>): ComplianceCase {
    const c: ComplianceCase = {
      ...caseData,
      id: `cmp-${Date.now().toString().slice(-6)}`,
      flaggedTimestamp: new Date().toISOString()
    };
    this.cases.unshift(c);
    return c;
  }

  public resolveCase(caseId: string, resolutionNote: string) {
    const c = this.cases.find(x => x.id === caseId);
    if (c) {
      c.status = 'RESOLVED';
      c.description += ` | RESOLUTION: ${resolutionNote}`;
    }
  }
}

export const globalComplianceEngine = new ComplianceEngine();
