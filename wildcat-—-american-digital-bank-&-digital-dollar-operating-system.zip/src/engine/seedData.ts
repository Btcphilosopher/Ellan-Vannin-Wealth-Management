import { 
  Customer, BankAccount, WDCWallet, LedgerAccount, 
  ReserveAsset, PaymentTransaction, Card, LoanProduct, 
  MarketAsset, ComplianceCase, AuditEvent, ProgrammablePaymentRule
} from '../types/bank';

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-retail-001',
    name: 'Alexander Vance',
    email: 'a.vance@wildcat.demo',
    type: 'RETAIL',
    jurisdiction: 'US-NY',
    city: 'New York',
    state: 'NY',
    kycStatus: 'VERIFIED',
    riskRating: 'LOW',
    joinedDate: '2027-01-15',
    taxId: '***-**-4819'
  },
  {
    id: 'cust-biz-001',
    name: 'Apex Logistics Infrastructure LLC',
    email: 'treasury@apexlogistics.demo',
    type: 'BUSINESS',
    jurisdiction: 'US-IL',
    city: 'Chicago',
    state: 'IL',
    kycStatus: 'VERIFIED',
    riskRating: 'LOW',
    joinedDate: '2026-11-04',
    taxId: 'XX-XXX9201'
  },
  {
    id: 'cust-inst-001',
    name: 'Manhattan Financial Capital Group',
    email: 'operations@manhattancap.demo',
    type: 'INSTITUTIONAL',
    jurisdiction: 'US-NY',
    city: 'New York',
    state: 'NY',
    kycStatus: 'VERIFIED',
    riskRating: 'LOW',
    joinedDate: '2026-08-20',
    taxId: 'XX-XXX1044'
  },
  {
    id: 'cust-retail-002',
    name: 'Elena Rostova',
    email: 'e.rostova@wildcat.demo',
    type: 'RETAIL',
    jurisdiction: 'US-CA',
    city: 'San Francisco',
    state: 'CA',
    kycStatus: 'VERIFIED',
    riskRating: 'LOW',
    joinedDate: '2027-02-10',
    taxId: '***-**-8201'
  },
  {
    id: 'cust-biz-002',
    name: 'AeroDynamics Tech USA Corp',
    email: 'finance@aerodynamics.demo',
    type: 'BUSINESS',
    jurisdiction: 'US-TX',
    city: 'Austin',
    state: 'TX',
    kycStatus: 'VERIFIED',
    riskRating: 'MEDIUM',
    joinedDate: '2026-12-01',
    taxId: 'XX-XXX3820'
  }
];

export const INITIAL_BANK_ACCOUNTS: BankAccount[] = [
  {
    id: 'acc-vance-checking',
    customerId: 'cust-retail-001',
    accountNumber: '1004820912',
    routingNumber: '021000089',
    type: 'CHECKING',
    name: 'Wildcat Signature Checking',
    balance: 84240.52,
    availableBalance: 84240.52,
    currency: 'USD',
    createdAt: '2027-01-15',
    status: 'ACTIVE'
  },
  {
    id: 'acc-vance-savings',
    customerId: 'cust-retail-001',
    accountNumber: '1004820913',
    routingNumber: '021000089',
    type: 'SAVINGS',
    name: 'Wildcat High-Yield Reserve Savings',
    balance: 72800.00,
    availableBalance: 72800.00,
    currency: 'USD',
    createdAt: '2027-01-15',
    status: 'ACTIVE'
  },
  {
    id: 'acc-vance-treasury',
    customerId: 'cust-retail-001',
    accountNumber: '1004820914',
    routingNumber: '021000089',
    type: 'PRIVATE_BANKING',
    name: 'Private Banking Wealth Mgmt',
    balance: 66560.00,
    availableBalance: 66560.00,
    currency: 'USD',
    createdAt: '2027-01-16',
    status: 'ACTIVE'
  },
  {
    id: 'acc-apex-biz',
    customerId: 'cust-biz-001',
    accountNumber: '8801948201',
    routingNumber: '021000089',
    type: 'BUSINESS_CHECKING',
    name: 'Apex Operating Cash USD',
    balance: 4250000.00,
    availableBalance: 4250000.00,
    currency: 'USD',
    createdAt: '2026-11-04',
    status: 'ACTIVE'
  },
  {
    id: 'acc-apex-savings',
    customerId: 'cust-biz-001',
    accountNumber: '8801948202',
    routingNumber: '021000089',
    type: 'BUSINESS_SAVINGS',
    name: 'Apex Corporate Yield Reserve',
    balance: 18500000.00,
    availableBalance: 18500000.00,
    currency: 'USD',
    createdAt: '2026-11-04',
    status: 'ACTIVE'
  },
  {
    id: 'acc-manhattan-inst',
    customerId: 'cust-inst-001',
    accountNumber: '9902019482',
    routingNumber: '021000089',
    type: 'TREASURY',
    name: 'Institutional Settlement USD Account',
    balance: 142000000.00,
    availableBalance: 142000000.00,
    currency: 'USD',
    createdAt: '2026-08-20',
    status: 'ACTIVE'
  }
];

export const INITIAL_WDC_WALLETS: WDCWallet[] = [
  {
    id: 'wdc-wallet-vance',
    customerId: 'cust-retail-001',
    address: 'wdc1qvance84920193810293819238',
    balance: 24820.42,
    availableBalance: 24820.42,
    pendingBalance: 0,
    status: 'ACTIVE',
    createdAt: '2027-01-15'
  },
  {
    id: 'wdc-wallet-apex',
    customerId: 'cust-biz-001',
    address: 'wdc1qapex94820193820193820192',
    balance: 12500000.00,
    availableBalance: 12500000.00,
    pendingBalance: 0,
    status: 'ACTIVE',
    createdAt: '2026-11-04'
  },
  {
    id: 'wdc-wallet-manhattan',
    customerId: 'cust-inst-001',
    address: 'wdc1qmanhattan9482019283012938',
    balance: 768000000.00,
    availableBalance: 768000000.00,
    pendingBalance: 0,
    status: 'ACTIVE',
    createdAt: '2026-08-20'
  }
];

export const INITIAL_LEDGER_ACCOUNTS: LedgerAccount[] = [
  { id: 'leg-1010', code: '1010', name: 'Cash Reserves & Fed Vault', type: 'ASSET', balance: 1482600000 },
  { id: 'leg-1020', code: '1020', name: 'U.S. Treasury Bills & Govt Securities', type: 'ASSET', balance: 3343400000 },
  { id: 'leg-1030', code: '1030', name: 'Commercial Loan Portfolio', type: 'ASSET', balance: 2100000000 },
  { id: 'leg-2010', code: '2010', name: 'Customer USD Deposits Liability', type: 'LIABILITY', balance: 4800000000 },
  { id: 'leg-2020', code: '2020', name: 'Wildcat Digital Dollar (WDC) Outstanding', type: 'LIABILITY', balance: 780000000 },
  { id: 'leg-3010', code: '3010', name: 'Common Stock & Paid-in Capital', type: 'EQUITY', balance: 1000000000 },
  { id: 'leg-3020', code: '3020', name: 'Retained Earnings', type: 'EQUITY', balance: 346000000 }
];

export const INITIAL_RESERVE_ASSETS: ReserveAsset[] = [
  {
    id: 'res-tbill-001',
    assetType: 'US_TREASURY_BILL',
    cusipOrId: 'US912796XX01',
    faceValue: 400000000,
    marketValue: 398200000,
    maturityDate: '2027-03-31',
    yieldPct: 4.85,
    custodian: 'BNY Mellon Trust',
    liquidityRating: 'HIGH',
    eligibilityPolicy: 'QUALIFIED',
    haircutPct: 0.25,
    valuationTime: '2027-09-27T08:00:00Z'
  },
  {
    id: 'res-cash-001',
    assetType: 'FED_RESERVE_BALANCE',
    cusipOrId: 'FRB-NY-ACCT-0192',
    faceValue: 284400000,
    marketValue: 284400000,
    maturityDate: 'ON_DEMAND',
    yieldPct: 5.15,
    custodian: 'Federal Reserve Bank of New York',
    liquidityRating: 'HIGH',
    eligibilityPolicy: 'QUALIFIED',
    haircutPct: 0.00,
    valuationTime: '2027-09-27T08:00:00Z'
  },
  {
    id: 'res-shortbond-001',
    assetType: 'SHORT_GOVT_BOND',
    cusipOrId: 'US912828YY88',
    faceValue: 100000000,
    marketValue: 100000000,
    maturityDate: '2027-06-15',
    yieldPct: 4.92,
    custodian: 'J.P. Morgan Clearing',
    liquidityRating: 'HIGH',
    eligibilityPolicy: 'QUALIFIED',
    haircutPct: 0.50,
    valuationTime: '2027-09-27T08:00:00Z'
  }
];

export const INITIAL_CARDS: Card[] = [
  {
    id: 'card-vance-sig',
    accountId: 'acc-vance-checking',
    customerId: 'cust-retail-001',
    cardNumber: '4892 •••• •••• 9102',
    cardholderName: 'ALEXANDER VANCE',
    expiry: '09/30',
    cvv: '882',
    type: 'DEBIT',
    status: 'ACTIVE',
    monthlyLimit: 25000,
    spentThisMonth: 3420,
    categoriesAllowed: ['Travel', 'Dining', 'Software', 'General'],
    travelMode: false,
    createdAt: '2027-01-15'
  },
  {
    id: 'card-apex-corp',
    accountId: 'acc-apex-biz',
    customerId: 'cust-biz-001',
    cardNumber: '5201 •••• •••• 4810',
    cardholderName: 'APEX LOGISTICS TREASURY',
    expiry: '12/29',
    cvv: '109',
    type: 'CORPORATE',
    status: 'ACTIVE',
    monthlyLimit: 500000,
    spentThisMonth: 112400,
    categoriesAllowed: ['Fuel', 'Logistics', 'SaaS', 'Vendor Payouts'],
    travelMode: true,
    createdAt: '2026-11-04'
  }
];

export const INITIAL_LOANS: LoanProduct[] = [
  {
    id: 'loan-apex-expansion',
    customerId: 'cust-biz-001',
    customerName: 'Apex Logistics Infrastructure LLC',
    type: 'BUSINESS_LOAN',
    principal: 15000000,
    remainingPrincipal: 12400000,
    interestRatePct: 6.25,
    termMonths: 60,
    monthlyPayment: 291750,
    collateralValue: 22000000,
    probabilityOfDefaultPct: 0.85,
    lossGivenDefaultPct: 25.0,
    expectedLoss: 26350,
    status: 'ACTIVE',
    originationDate: '2026-12-01',
    nextPaymentDueDate: '2027-10-01'
  },
  {
    id: 'loan-vance-mortgage',
    customerId: 'cust-retail-001',
    customerName: 'Alexander Vance',
    type: 'MORTGAGE',
    principal: 1250000,
    remainingPrincipal: 1180000,
    interestRatePct: 5.75,
    termMonths: 360,
    monthlyPayment: 7290,
    collateralValue: 1850000,
    probabilityOfDefaultPct: 0.20,
    lossGivenDefaultPct: 15.0,
    expectedLoss: 354,
    status: 'ACTIVE',
    originationDate: '2027-01-20',
    nextPaymentDueDate: '2027-10-01'
  }
];

export const INITIAL_PROGRAMMABLE_RULES: ProgrammablePaymentRule[] = [
  {
    id: 'rule-rent-001',
    customerId: 'cust-retail-001',
    name: 'Monthly Luxury Residence Transfer',
    triggerType: 'RECURRING_DATE',
    amountOrPct: 4500,
    isPercentage: false,
    destinationAccountOrWallet: 'Manhattan Realty Partners Trust Account',
    frequencyDays: 30,
    nextExecutionDate: '2027-10-01',
    status: 'ACTIVE',
    requiresApproval: false,
    limitAmount: 5000,
    expiryDate: '2028-01-01',
    createdAt: '2027-02-01',
    executionHistory: [
      { timestamp: '2027-09-01T00:00:00Z', amountExecuted: 4500, status: 'SETTLED' },
      { timestamp: '2027-08-01T00:00:00Z', amountExecuted: 4500, status: 'SETTLED' }
    ]
  },
  {
    id: 'rule-apex-supplier-escrow',
    customerId: 'cust-biz-001',
    name: 'AeroDynamics Invoice Release Escrow',
    triggerType: 'INVOICE_VERIFIED',
    amountOrPct: 250000,
    isPercentage: false,
    destinationAccountOrWallet: 'wdc1qAeroDynamicsVendorWallet',
    status: 'ACTIVE',
    requiresApproval: true,
    limitAmount: 500000,
    expiryDate: '2027-12-31',
    createdAt: '2027-03-10',
    executionHistory: [
      { timestamp: '2027-08-15T14:20:00Z', amountExecuted: 250000, status: 'SETTLED' }
    ]
  },
  {
    id: 'rule-vance-auto-save',
    customerId: 'cust-retail-001',
    name: 'Automatic 5% WDC Deposit Sweep',
    triggerType: 'PERCENTAGE_SAVINGS',
    amountOrPct: 5,
    isPercentage: true,
    destinationAccountOrWallet: 'acc-vance-savings',
    status: 'ACTIVE',
    requiresApproval: false,
    limitAmount: 10000,
    expiryDate: '2029-01-01',
    createdAt: '2027-01-20',
    executionHistory: [
      { timestamp: '2027-09-20T10:15:00Z', amountExecuted: 120, status: 'SETTLED' }
    ]
  }
];

export const INITIAL_MARKET_ASSETS: MarketAsset[] = [
  {
    symbol: 'WDC/USD',
    name: 'Wildcat Digital Dollar Par Exchange',
    category: 'FX',
    price: 1.0000,
    change24hPct: 0.00,
    high24h: 1.0001,
    low24h: 0.9999,
    volume24h: 184500000,
    orderBook: {
      bids: [{ price: 1.0000, amount: 5000000 }, { price: 0.9999, amount: 12000000 }],
      asks: [{ price: 1.0000, amount: 5000000 }, { price: 1.0001, amount: 10000000 }]
    }
  },
  {
    symbol: 'UST-03M',
    name: 'U.S. Treasury 3-Month Bill Yield',
    category: 'TREASURY',
    price: 4.88,
    change24hPct: -0.02,
    high24h: 4.91,
    low24h: 4.86,
    volume24h: 1200000000,
    orderBook: {
      bids: [{ price: 4.878, amount: 50000000 }],
      asks: [{ price: 4.882, amount: 45000000 }]
    }
  },
  {
    symbol: 'WDF-EQ',
    name: 'Wildcat American Industrial Capital Index',
    category: 'EQUITY',
    price: 4820.50,
    change24hPct: 1.42,
    high24h: 4840.10,
    low24h: 4790.00,
    volume24h: 940000000,
    orderBook: {
      bids: [{ price: 4820.00, amount: 1200 }, { price: 4818.50, amount: 3400 }],
      asks: [{ price: 4821.00, amount: 1100 }, { price: 4822.50, amount: 2900 }]
    }
  }
];

export const INITIAL_PAYMENTS: PaymentTransaction[] = [
  {
    id: 'pay-vance-001',
    fromAccountId: 'acc-vance-checking',
    fromAccountName: 'Alexander Vance Checking',
    toAccountId: 'acc-apex-biz',
    toAccountName: 'Apex Logistics LLC',
    amount: 1250.00,
    currency: 'USD',
    rail: 'ACH',
    state: 'SETTLED',
    reference: 'ACH-20270926-8910',
    description: 'Quarterly Logistics Retainer',
    timestamp: '2027-09-26T14:32:00Z',
    fee: 0.00,
    stateHistory: [
      { state: 'CREATED', timestamp: '2027-09-26T14:30:00Z', note: 'Instruction submitted' },
      { state: 'AUTHORIZED', timestamp: '2027-09-26T14:30:05Z', note: '2FA Passkey verified' },
      { state: 'PROCESSING', timestamp: '2027-09-26T14:31:00Z', note: 'Submitted to ACH Batch' },
      { state: 'SETTLED', timestamp: '2027-09-26T14:32:00Z', note: 'Fedwire/ACH Clearing complete' }
    ]
  },
  {
    id: 'pay-wdc-mint-001',
    fromAccountId: 'acc-vance-checking',
    fromAccountName: 'Alexander Vance Checking USD',
    toAccountId: 'wdc-wallet-vance',
    toAccountName: 'Alexander Vance WDC Wallet',
    amount: 4000.00,
    currency: 'WDC',
    rail: 'WDC',
    state: 'SETTLED',
    reference: 'WDC-MINT-881920',
    description: 'Convert USD to WDC Digital Dollar',
    timestamp: '2027-09-27T04:15:00Z',
    fee: 0.00,
    stateHistory: [
      { state: 'CREATED', timestamp: '2027-09-27T04:14:50Z', note: 'Minting request generated' },
      { state: 'AUTHORIZED', timestamp: '2027-09-27T04:14:52Z', note: 'Compliance & Reserve check passed' },
      { state: 'SETTLED', timestamp: '2027-09-27T04:15:00Z', note: 'Journal entries created & WDC issued' }
    ]
  }
];

export const INITIAL_COMPLIANCE_CASES: ComplianceCase[] = [
  {
    id: 'cmp-2027-081',
    customerId: 'cust-biz-002',
    customerName: 'AeroDynamics Tech USA Corp',
    type: 'LARGE_TRANSACTION',
    severity: 'MEDIUM',
    status: 'OPEN',
    description: 'Single outbound Wire of $2,500,000 WDC exceeding soft threshold.',
    flaggedTimestamp: '2027-09-26T18:00:00Z',
    assignedOfficer: 'Compliance Officer J. Reynolds',
    rulesTriggered: ['BSA-AML-500K-RULE', 'GENIUS-ACT-2026-REPORTING-RULE']
  }
];

export const INITIAL_AUDIT_EVENTS: AuditEvent[] = [
  {
    id: 'aud-99182',
    userId: 'usr-admin-01',
    userRole: 'CHIEF_ISSUANCE_OFFICER',
    action: 'WDC_ISSUANCE_APPROVED',
    entity: 'WDCIssuanceEngine',
    entityId: 'WDC-MINT-881920',
    timestamp: '2027-09-27T04:14:52Z',
    authorization: 'AUTH_TOKEN_ED25519_VALIDATED',
    ipAddress: '192.168.1.44 (Internal NY Office)'
  },
  {
    id: 'aud-99181',
    userId: 'usr-sys-auto',
    userRole: 'RECONCILIATION_ENGINE',
    action: 'DAILY_RECONCILIATION_VERIFIED',
    entity: 'AuthoritativeLedger',
    entityId: 'REC-20270927',
    timestamp: '2027-09-27T00:00:00Z',
    authorization: 'SYSTEM_AUTHORITATIVE',
    ipAddress: '127.0.0.1 (Ledger Core Node 1)'
  }
];
