import { WDCWallet } from '../types/bank';
import { globalLedger } from './ledger';

export interface WDCSupplyMetrics {
  wdcOutstanding: number;
  reserveValueUSD: number;
  reserveRatioPct: number;
  inCirculation: number;
  heldByBank: number;
  totalRedeemedToday: number;
  totalMintedToday: number;
  netIssuanceToday: number;
}

export class WDCEngine {
  private wallets: Map<string, WDCWallet>;
  private totalMintedToday: number = 12700000;
  private totalRedeemedToday: number = 8400000;

  constructor(initialWallets: WDCWallet[]) {
    this.wallets = new Map();
    initialWallets.forEach(w => this.wallets.set(w.id, { ...w }));
  }

  public getWallets(): WDCWallet[] {
    return Array.from(this.wallets.values());
  }

  public getWalletByCustomer(customerId: string): WDCWallet | undefined {
    return Array.from(this.wallets.values()).find(w => w.customerId === customerId);
  }

  public getWalletById(id: string): WDCWallet | undefined {
    return this.wallets.get(id);
  }

  public getSupplyMetrics(totalReserveMarketValue: number): WDCSupplyMetrics {
    const wdcAccount = globalLedger.getAccountByCode('2020');
    const wdcOutstanding = wdcAccount ? wdcAccount.balance : 780000000;
    
    // In circulation is sum of non-bank customer wallet balances
    let inCirculation = 0;
    this.wallets.forEach(w => {
      inCirculation += w.balance;
    });

    const heldByBank = Math.max(0, wdcOutstanding - inCirculation);
    const reserveRatioPct = wdcOutstanding > 0 ? (totalReserveMarketValue / wdcOutstanding) * 100 : 100.0;

    return {
      wdcOutstanding,
      reserveValueUSD: totalReserveMarketValue,
      reserveRatioPct: Number(reserveRatioPct.toFixed(2)),
      inCirculation,
      heldByBank,
      totalRedeemedToday: this.totalRedeemedToday,
      totalMintedToday: this.totalMintedToday,
      netIssuanceToday: this.totalMintedToday - this.totalRedeemedToday
    };
  }

  /**
   * Minting WDC: Converts USD -> WDC
   */
  public mintWDC(
    customerId: string,
    amountUSD: number,
    usdAccountName: string
  ): { success: boolean; journalRef: string; newBalance: number } {
    const wallet = this.getWalletByCustomer(customerId);
    if (!wallet) throw new Error(`WDC Wallet not found for customer ${customerId}`);

    // Post double-entry journal:
    // DR Cash/Reserves (1010) - $amount
    // CR WDC Outstanding (2020) - $amount
    const journalRef = `WDC-MINT-${Date.now().toString().slice(-6)}`;
    globalLedger.postJournal(
      journalRef,
      `WDC Issuance for Customer ${customerId} via ${usdAccountName}`,
      [
        { accountCode: '1010', type: 'DEBIT', amount: amountUSD },
        { accountCode: '2020', type: 'CREDIT', amount: amountUSD }
      ],
      'WDC_ISSUANCE_ENGINE'
    );

    wallet.balance += amountUSD;
    wallet.availableBalance += amountUSD;
    this.totalMintedToday += amountUSD;

    return {
      success: true,
      journalRef,
      newBalance: wallet.balance
    };
  }

  /**
   * Redemption WDC: Burns WDC -> Returns USD
   */
  public redeemWDC(
    customerId: string,
    amountWDC: number,
    targetUsdAccountName: string
  ): { success: boolean; journalRef: string; newBalance: number } {
    const wallet = this.getWalletByCustomer(customerId);
    if (!wallet) throw new Error(`WDC Wallet not found for customer ${customerId}`);

    if (wallet.availableBalance < amountWDC) {
      throw new Error(`Insufficient WDC balance. Available: WDC ${wallet.availableBalance.toLocaleString()}`);
    }

    // Post double-entry journal:
    // DR WDC Outstanding (2020) - $amount
    // CR Customer USD Deposit (2010) - $amount
    const journalRef = `WDC-BURN-${Date.now().toString().slice(-6)}`;
    globalLedger.postJournal(
      journalRef,
      `WDC Redemption for Customer ${customerId} to ${targetUsdAccountName}`,
      [
        { accountCode: '2020', type: 'DEBIT', amount: amountWDC },
        { accountCode: '2010', type: 'CREDIT', amount: amountWDC }
      ],
      'WDC_REDEMPTION_ENGINE'
    );

    wallet.balance -= amountWDC;
    wallet.availableBalance -= amountWDC;
    this.totalRedeemedToday += amountWDC;

    return {
      success: true,
      journalRef,
      newBalance: wallet.balance
    };
  }

  /**
   * Transfer WDC between wallets
   */
  public transferWDC(
    fromWalletId: string,
    toWalletAddress: string,
    amountWDC: number
  ): { success: boolean; txHash: string } {
    const sender = this.wallets.get(fromWalletId);
    if (!sender) throw new Error('Sender wallet not found');
    if (sender.availableBalance < amountWDC) {
      throw new Error(`Insufficient WDC balance ($${sender.availableBalance.toLocaleString()})`);
    }

    let recipient = Array.from(this.wallets.values()).find(w => w.address === toWalletAddress);
    
    // Auto-create simulated recipient if valid address syntax
    if (!recipient && toWalletAddress.startsWith('wdc1q')) {
      recipient = {
        id: `wdc-wallet-${Date.now()}`,
        customerId: 'cust-biz-002',
        address: toWalletAddress,
        balance: 0,
        availableBalance: 0,
        pendingBalance: 0,
        status: 'ACTIVE',
        createdAt: new Date().toISOString()
      };
      this.wallets.set(recipient.id, recipient);
    }

    if (!recipient) throw new Error('Invalid recipient WDC wallet address');

    sender.balance -= amountWDC;
    sender.availableBalance -= amountWDC;
    recipient.balance += amountWDC;
    recipient.availableBalance += amountWDC;

    const txHash = `0x${Array.from({length: 32}, () => Math.floor(Math.random()*16).toString(16)).join('')}`;
    return { success: true, txHash };
  }
}
