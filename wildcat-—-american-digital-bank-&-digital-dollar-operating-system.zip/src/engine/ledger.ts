import { Journal, JournalEntry, LedgerAccount } from '../types/bank';
import { INITIAL_LEDGER_ACCOUNTS } from './seedData';

export class AuthoritativeLedger {
  private ledgerAccounts: Map<string, LedgerAccount>;
  private journals: Journal[];

  constructor() {
    this.ledgerAccounts = new Map();
    INITIAL_LEDGER_ACCOUNTS.forEach(acc => this.ledgerAccounts.set(acc.code, { ...acc }));
    this.journals = [];
  }

  public getAccounts(): LedgerAccount[] {
    return Array.from(this.ledgerAccounts.values());
  }

  public getAccountByCode(code: string): LedgerAccount | undefined {
    return this.ledgerAccounts.get(code);
  }

  public getJournals(): Journal[] {
    return [...this.journals];
  }

  /**
   * Post a double-entry journal. Enforces sum(Debits) === sum(Credits).
   */
  public postJournal(
    reference: string,
    description: string,
    entries: { accountCode: string; type: 'DEBIT' | 'CREDIT'; amount: number }[],
    authorizedBy: string = 'SYSTEM_LEGAL_ISSUER'
  ): Journal {
    const totalDebits = entries
      .filter(e => e.type === 'DEBIT')
      .reduce((sum, e) => sum + e.amount, 0);
    const totalCredits = entries
      .filter(e => e.type === 'CREDIT')
      .reduce((sum, e) => sum + e.amount, 0);

    // Floating point precision check up to 4 decimals
    if (Math.abs(totalDebits - totalCredits) > 0.0001) {
      throw new Error(
        `Ledger Violation: Debits ($${totalDebits.toFixed(2)}) must equal Credits ($${totalCredits.toFixed(2)}) for ref: ${reference}`
      );
    }

    const journalEntries: JournalEntry[] = entries.map((e, idx) => {
      const acc = this.ledgerAccounts.get(e.accountCode);
      if (!acc) {
        throw new Error(`Invalid Ledger Account Code: ${e.accountCode}`);
      }

      // Update ledger account balance
      // Asset/Expense: Debit increases, Credit decreases
      // Liability/Equity/Revenue: Credit increases, Debit decreases
      if (acc.type === 'ASSET' || acc.type === 'EXPENSE') {
        acc.balance += e.type === 'DEBIT' ? e.amount : -e.amount;
      } else {
        acc.balance += e.type === 'CREDIT' ? e.amount : -e.amount;
      }

      return {
        id: `entry-${Date.now()}-${idx}`,
        journalId: `jnl-${Date.now()}`,
        ledgerAccountId: acc.id,
        ledgerAccountCode: acc.code,
        ledgerAccountName: acc.name,
        type: e.type,
        amount: e.amount,
        description: `${description} (${e.type})`
      };
    });

    const journal: Journal = {
      id: `jnl-${Date.now()}`,
      reference,
      description,
      timestamp: new Date().toISOString(),
      entries: journalEntries,
      authorizedBy
    };

    this.journals.unshift(journal);
    return journal;
  }

  /**
   * Verifies system invariants: Total Assets === Total Liabilities + Total Equity
   */
  public verifyInvariants(): { balanced: boolean; assets: number; liabilities: number; equity: number; discrepancy: number } {
    let assets = 0;
    let liabilities = 0;
    let equity = 0;

    this.ledgerAccounts.forEach(acc => {
      if (acc.type === 'ASSET') assets += acc.balance;
      else if (acc.type === 'LIABILITY') liabilities += acc.balance;
      else if (acc.type === 'EQUITY') equity += acc.balance;
    });

    const discrepancy = Math.abs(assets - (liabilities + equity));
    return {
      balanced: discrepancy < 0.01,
      assets,
      liabilities,
      equity,
      discrepancy
    };
  }
}

export const globalLedger = new AuthoritativeLedger();
