import { FounderBankSettings } from '../types/bank';

export interface DigitalTwinState {
  day: number;
  label: string;
  customers: number;
  depositsUSD: number;
  loansUSD: number;
  wdcCirculationUSD: number;
  reserveAssetsUSD: number;
  equityUSD: number;
  netInterestIncomeUSD: number;
  interchangeRevenueUSD: number;
  operatingCostsUSD: number;
  liquidityRatioPct: number;
}

export class BankDigitalTwin {
  private settings: FounderBankSettings;

  constructor(initialSettings?: Partial<FounderBankSettings>) {
    this.settings = {
      bankName: 'WILDCAT FINANCIAL',
      retailCustomersCount: 250000,
      businessCustomersCount: 18000,
      totalDepositsUSD: 4800000000,
      totalLoansUSD: 2100000000,
      wdcCirculationUSD: 78000000,
      reserveAssetsUSD: 780000000,
      foundingCapitalUSD: 1000000000,
      simulationDay: 1,
      ...initialSettings
    };
  }

  public getSettings(): FounderBankSettings {
    return { ...this.settings };
  }

  public updateSettings(updates: Partial<FounderBankSettings>) {
    this.settings = { ...this.settings, ...updates };
  }

  public generateSimulationTimeline(): DigitalTwinState[] {
    const { retailCustomersCount, totalDepositsUSD, totalLoansUSD, wdcCirculationUSD, reserveAssetsUSD, foundingCapitalUSD } = this.settings;

    const stages = [
      { day: 1, label: 'Day 1 (Launch)', mult: 1.0 },
      { day: 30, label: 'Day 30 (Ramp Up)', mult: 1.08 },
      { day: 90, label: 'Day 90 (Q1 Steady)', mult: 1.25 },
      { day: 365, label: 'Year 1 (Scale)', mult: 1.80 },
      { day: 1095, label: 'Year 3 (Institutional Hub)', mult: 3.40 },
      { day: 1825, label: 'Year 5 (Flagship Bank OS)', mult: 6.20 }
    ];

    return stages.map(st => {
      const cust = Math.round(retailCustomersCount * st.mult);
      const dep = Math.round(totalDepositsUSD * st.mult);
      const loans = Math.round(totalLoansUSD * (1 + (st.mult - 1) * 0.85));
      const wdc = Math.round(wdcCirculationUSD * Math.pow(st.mult, 1.25));
      const res = wdc; // 100% reserve backing
      const equity = Math.round(foundingCapitalUSD + (st.day * 450000));
      const nii = Math.round((loans * 0.052) - (dep * 0.038));
      const interchange = Math.round(cust * 18.50 * (st.day / 30));
      const costs = Math.round(18000000 + (cust * 12.0));
      const lcr = Number(((res + (dep * 0.25)) / (dep * 0.15 + wdc * 0.10) * 100).toFixed(1));

      return {
        day: st.day,
        label: st.label,
        customers: cust,
        depositsUSD: dep,
        loansUSD: loans,
        wdcCirculationUSD: wdc,
        reserveAssetsUSD: res,
        equityUSD: equity,
        netInterestIncomeUSD: nii,
        interchangeRevenueUSD: interchange,
        operatingCostsUSD: costs,
        liquidityRatioPct: Math.min(220, lcr)
      };
    });
  }
}

export const globalBankDigitalTwin = new BankDigitalTwin();
