import { ReserveAsset } from '../types/bank';
import { INITIAL_RESERVE_ASSETS } from './seedData';

export interface StressLabResult {
  scenarioName: string;
  redemptionDemandUSD: number;
  depositOutflowUSD: number;
  remainingLiquidReservesUSD: number;
  reserveRatioPct: number;
  liquidityCoverageRatioPct: number;
  capitalAdequacyPct: number;
  status: 'NOMINAL' | 'ELEVATED' | 'CRITICAL' | 'LIQUIDITY_DEFICIT';
  details: string;
}

export class ReserveEngine {
  private reserveAssets: ReserveAsset[];

  constructor() {
    this.reserveAssets = [...INITIAL_RESERVE_ASSETS];
  }

  public getAssets(): ReserveAsset[] {
    return [...this.reserveAssets];
  }

  public getTotalMarketValue(): number {
    return this.reserveAssets.reduce((sum, a) => sum + a.marketValue, 0);
  }

  public getQualifiedAssetsValue(): number {
    return this.reserveAssets
      .filter(a => a.eligibilityPolicy === 'QUALIFIED')
      .reduce((sum, a) => sum + (a.marketValue * (1 - a.haircutPct / 100)), 0);
  }

  public getAverageYield(): number {
    const totalVal = this.getTotalMarketValue();
    if (totalVal === 0) return 0;
    const weightedYield = this.reserveAssets.reduce((sum, a) => sum + (a.yieldPct * a.marketValue), 0);
    return Number((weightedYield / totalVal).toFixed(2));
  }

  public addAsset(asset: Omit<ReserveAsset, 'id' | 'valuationTime'>): ReserveAsset {
    const newAsset: ReserveAsset = {
      ...asset,
      id: `res-${Date.now()}`,
      valuationTime: new Date().toISOString()
    };
    this.reserveAssets.push(newAsset);
    return newAsset;
  }

  /**
   * Runs institutional Liquidity Scenario Lab & Bank Run Simulation
   */
  public runStressTest(
    wdcCirculationUSD: number,
    totalDepositsUSD: number,
    redemptionDemandUSD: number,
    depositOutflowPct: number,
    rateShockBP: number
  ): StressLabResult {
    const totalReserves = this.getTotalMarketValue();
    const liquidReserves = this.getQualifiedAssetsValue();

    const depositOutflowUSD = totalDepositsUSD * (depositOutflowPct / 100);
    const totalImmediateOutflowUSD = redemptionDemandUSD + depositOutflowUSD;

    // Rate shock impact on market value of fixed-income reserves (-0.15% per 100bp rate hike for short duration)
    const valuationHaircut = (rateShockBP / 100) * 0.0015;
    const adjustedReserves = liquidReserves * (1 - valuationHaircut);

    const remainingReserves = adjustedReserves - totalImmediateOutflowUSD;
    const newWdcCirculation = Math.max(0, wdcCirculationUSD - redemptionDemandUSD);

    const reserveRatioPct = newWdcCirculation > 0 
      ? (remainingReserves / newWdcCirculation) * 100 
      : 100;

    const lcrPct = totalImmediateOutflowUSD > 0 
      ? (adjustedReserves / totalImmediateOutflowUSD) * 100 
      : 250;

    const capitalAdequacyPct = Math.max(0, ((remainingReserves + 346000000) / (totalDepositsUSD - depositOutflowUSD)) * 100);

    let status: 'NOMINAL' | 'ELEVATED' | 'CRITICAL' | 'LIQUIDITY_DEFICIT' = 'NOMINAL';
    let details = 'Reserve liquidity exceeds stress buffer. All redemption obligations fully backed.';

    if (remainingReserves < 0) {
      status = 'LIQUIDITY_DEFICIT';
      details = 'CRITICAL: Severe liquidity shortfall! Liquidation of illiquid assets required to meet redemptions.';
    } else if (reserveRatioPct < 100) {
      status = 'CRITICAL';
      details = 'WARNING: Reserve backing fell below 100% threshold under extreme stress assumptions.';
    } else if (lcrPct < 120) {
      status = 'ELEVATED';
      details = 'ELEVATED RISK: Liquidity Coverage Ratio compressed below target 120% buffer.';
    }

    return {
      scenarioName: `Stress Scenario ($${(redemptionDemandUSD/1e6).toFixed(0)}M WDC Redeem, ${depositOutflowPct}% Outflow, +${rateShockBP}bp)`,
      redemptionDemandUSD,
      depositOutflowUSD,
      remainingLiquidReservesUSD: Math.max(0, remainingReserves),
      reserveRatioPct: Number(reserveRatioPct.toFixed(2)),
      liquidityCoverageRatioPct: Number(lcrPct.toFixed(2)),
      capitalAdequacyPct: Number(capitalAdequacyPct.toFixed(2)),
      status,
      details
    };
  }
}

export const globalReserveEngine = new ReserveEngine();
