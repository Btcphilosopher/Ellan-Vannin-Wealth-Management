import { LoanProduct } from '../types/bank';
import { INITIAL_LOANS } from './seedData';

export class CreditEngine {
  private loans: LoanProduct[];

  constructor() {
    this.loans = [...INITIAL_LOANS];
  }

  public getLoans(): LoanProduct[] {
    return [...this.loans];
  }

  public getTotalLoanBookValue(): number {
    return this.loans.reduce((sum, l) => sum + l.remainingPrincipal, 0);
  }

  public getTotalExpectedLoss(): number {
    return this.loans.reduce((sum, l) => sum + l.expectedLoss, 0);
  }

  public originateLoan(
    customerId: string,
    customerName: string,
    type: LoanProduct['type'],
    principal: number,
    termMonths: number,
    interestRatePct: number,
    collateralValue: number
  ): LoanProduct {
    // Underwriting math
    const r = interestRatePct / 100 / 12;
    const monthlyPayment = (principal * r * Math.pow(1 + r, termMonths)) / (Math.pow(1 + r, termMonths) - 1);
    
    // Risk scoring model
    const LTV = collateralValue > 0 ? (principal / collateralValue) : 1.0;
    const pdPct = Math.min(5.0, Number((0.2 + (LTV * 0.8)).toFixed(2)));
    const lgdPct = collateralValue > principal ? 15.0 : 45.0;
    const expectedLoss = Number((principal * (pdPct / 100) * (lgdPct / 100)).toFixed(2));

    const loan: LoanProduct = {
      id: `loan-${Date.now()}`,
      customerId,
      customerName,
      type,
      principal,
      remainingPrincipal: principal,
      interestRatePct,
      termMonths,
      monthlyPayment: Number(monthlyPayment.toFixed(2)),
      collateralValue,
      probabilityOfDefaultPct: pdPct,
      lossGivenDefaultPct: lgdPct,
      expectedLoss,
      status: 'APPROVED',
      originationDate: new Date().toISOString().split('T')[0],
      nextPaymentDueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0]
    };

    this.loans.unshift(loan);
    return loan;
  }
}

export const globalCreditEngine = new CreditEngine();
