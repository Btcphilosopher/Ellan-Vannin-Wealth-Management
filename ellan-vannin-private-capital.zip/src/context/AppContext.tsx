import React, { createContext, useContext, useState } from 'react';
import { 
  Fund, 
  Deal, 
  CapitalCallNotice, 
  LimitedPartner, 
  NavigationTab 
} from '../types';
import { 
  INITIAL_FUNDS, 
  INITIAL_DEALS, 
  INITIAL_LIMITED_PARTNERS, 
  INITIAL_CAPITAL_CALLS 
} from '../data/initialData';
import { auditLogger } from '../services/auditLogger';

interface AppContextType {
  funds: Fund[];
  selectedFund: Fund;
  setSelectedFund: (fund: Fund) => void;
  deals: Deal[];
  selectedDeal: Deal;
  setSelectedDeal: (deal: Deal) => void;
  selectDealById: (dealId: string) => void;
  activeRole: string;
  setActiveRole: (role: string) => void;
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  capitalCalls: CapitalCallNotice[];
  lps: LimitedPartner[];
  addDeal: (deal: Deal) => void;
  updateDeal: (deal: Deal) => void;
  issueCapitalCall: (notice: CapitalCallNotice) => void;
  updateFund: (fund: Fund) => void;
  isNewDealModalOpen: boolean;
  setIsNewDealModalOpen: (open: boolean) => void;
  isNewCallModalOpen: boolean;
  setIsNewCallModalOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [funds, setFunds] = useState<Fund[]>(INITIAL_FUNDS);
  const [selectedFund, setSelectedFund] = useState<Fund>(INITIAL_FUNDS[0]);
  const [deals, setDeals] = useState<Deal[]>(INITIAL_DEALS);
  const [selectedDeal, setSelectedDeal] = useState<Deal>(INITIAL_DEALS[0]);
  const [activeRole, setActiveRole] = useState<string>('Managing General Partner (GP)');
  const [activeTab, setActiveTab] = useState<NavigationTab>('DASHBOARD');
  const [capitalCalls, setCapitalCalls] = useState<CapitalCallNotice[]>(INITIAL_CAPITAL_CALLS);
  const [lps, setLps] = useState<LimitedPartner[]>(INITIAL_LIMITED_PARTNERS);
  
  // Modals
  const [isNewDealModalOpen, setIsNewDealModalOpen] = useState(false);
  const [isNewCallModalOpen, setIsNewCallModalOpen] = useState(false);

  const selectDealById = (dealId: string) => {
    const found = deals.find(d => d.id === dealId);
    if (found) {
      setSelectedDeal(found);
    }
  };

  const addDeal = (deal: Deal) => {
    setDeals(prev => [deal, ...prev]);
    setSelectedDeal(deal);
  };

  const updateDeal = (updated: Deal) => {
    setDeals(prev => prev.map(d => d.id === updated.id ? updated : d));
    if (selectedDeal.id === updated.id) {
      setSelectedDeal(updated);
    }
  };

  const issueCapitalCall = (notice: CapitalCallNotice) => {
    setCapitalCalls(prev => [notice, ...prev]);

    // Update fund called capital and LP balances
    const updatedFund = {
      ...selectedFund,
      calledCapital: selectedFund.calledCapital + notice.totalAmount,
      uncalledCapital: Math.max(0, selectedFund.uncalledCapital - notice.totalAmount)
    };
    setSelectedFund(updatedFund);
    setFunds(prev => prev.map(f => f.id === updatedFund.id ? updatedFund : f));

    // Update LPs
    setLps(prev => prev.map(lp => {
      const match = notice.lpBreakdown.find(b => b.lpId === lp.id);
      if (match) {
        return {
          ...lp,
          calledCapital: lp.calledCapital + match.amount,
          uncalledCapital: Math.max(0, lp.uncalledCapital - match.amount)
        };
      }
      return lp;
    }));
  };

  const updateFund = (updated: Fund) => {
    setSelectedFund(updated);
    setFunds(prev => prev.map(f => f.id === updated.id ? updated : f));
  };

  return (
    <AppContext.Provider
      value={{
        funds,
        selectedFund,
        setSelectedFund,
        deals,
        selectedDeal,
        setSelectedDeal,
        selectDealById,
        activeRole,
        setActiveRole,
        activeTab,
        setActiveTab,
        capitalCalls,
        lps,
        addDeal,
        updateDeal,
        issueCapitalCall,
        updateFund,
        isNewDealModalOpen,
        setIsNewDealModalOpen,
        isNewCallModalOpen,
        setIsNewCallModalOpen
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
