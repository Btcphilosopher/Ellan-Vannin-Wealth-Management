import { Fund, Deal, LPCommitment, CapitalCall } from '../types';

export const INITIAL_FUNDS: Fund[] = [
  {
    id: 'fund-evwm-1',
    name: 'EVWM Flagship Buyout & Growth Fund I',
    vintage: 2022,
    vintageYear: 2022,
    fundSize: 750, // €750M
    size: 750,
    committedCapital: 750,
    investedCapital: 495,
    calledCapital: 495,
    uncalledCapital: 255,
    realisedProceeds: 142,
    unrealisedValue: 618,
    cash: 52,
    fundDebt: 0,
    nav: 670, // 618 + 52
    investmentPeriodYears: 5,
    fundLifeYears: 10,
    managementFeePercent: 1.75,
    carriedInterestPercent: 20.0,
    preferredReturnPercent: 8.0,
    gpCommitmentPercent: 3.5,
    reinvestmentAllowed: true,
    currency: 'EUR (€)',
    sectors: ['INDUSTRIALS', 'TECHNOLOGY', 'HEALTHCARE', 'INFRASTRUCTURE', 'LOGISTICS'],
    geographies: ['United Kingdom', 'Isle of Man', 'Germany', 'Nordics', 'Switzerland', 'France'],
    targetGrossIRR: 24.0,
    targetNetIRR: 19.5,
    grossIRR: 24.0,
    netIRR: 19.5,
    targetMOIC: 2.5,
    maxLeverageMultiple: 4.5,
    maxSingleDealExposurePercent: 18.0,
    investmentLimits: {
      maxSingleDealPercent: 18.0,
      maxSectorConcentrationPercent: 35.0,
      maxGeographyConcentrationPercent: 40.0
    }
  },
  {
    id: 'fund-evwm-2',
    name: 'EVWM Direct Investment Fund II',
    vintage: 2024,
    vintageYear: 2024,
    fundSize: 1250, // €1.25B
    size: 1250,
    committedCapital: 1100,
    investedCapital: 380,
    calledCapital: 380,
    uncalledCapital: 720,
    realisedProceeds: 0,
    unrealisedValue: 425,
    cash: 95,
    fundDebt: 0,
    nav: 520,
    investmentPeriodYears: 5,
    fundLifeYears: 10,
    managementFeePercent: 1.5,
    carriedInterestPercent: 20.0,
    preferredReturnPercent: 8.0,
    gpCommitmentPercent: 4.0,
    reinvestmentAllowed: true,
    currency: 'EUR (€)',
    sectors: ['INDUSTRIALS', 'ENERGY', 'TECHNOLOGY', 'HEALTHCARE', 'FOOD', 'TRANSPORT'],
    geographies: ['Europe', 'United Kingdom', 'North America', 'Nordics'],
    targetGrossIRR: 25.0,
    targetNetIRR: 20.0,
    grossIRR: 25.0,
    netIRR: 20.0,
    targetMOIC: 2.6,
    maxLeverageMultiple: 4.0,
    maxSingleDealExposurePercent: 15.0,
    investmentLimits: {
      maxSingleDealPercent: 15.0,
      maxSectorConcentrationPercent: 30.0,
      maxGeographyConcentrationPercent: 35.0
    }
  },
  {
    id: 'fund-evwm-infra',
    name: 'EVWM European Infrastructure & Energy Transition Fund',
    vintage: 2023,
    vintageYear: 2023,
    fundSize: 850,
    size: 850,
    committedCapital: 850,
    investedCapital: 520,
    calledCapital: 520,
    uncalledCapital: 330,
    realisedProceeds: 48,
    unrealisedValue: 645,
    cash: 65,
    fundDebt: 0,
    nav: 710,
    investmentPeriodYears: 6,
    fundLifeYears: 12,
    managementFeePercent: 1.25,
    carriedInterestPercent: 15.0,
    preferredReturnPercent: 7.0,
    gpCommitmentPercent: 5.0,
    reinvestmentAllowed: true,
    currency: 'EUR (€)',
    sectors: ['INFRASTRUCTURE', 'ENERGY', 'TRANSPORT', 'LOGISTICS'],
    geographies: ['United Kingdom', 'Nordics', 'Benelux', 'Germany', 'Spain'],
    targetGrossIRR: 18.0,
    targetNetIRR: 14.5,
    grossIRR: 18.0,
    netIRR: 14.5,
    targetMOIC: 2.1,
    maxLeverageMultiple: 5.5,
    maxSingleDealExposurePercent: 20.0,
    investmentLimits: {
      maxSingleDealPercent: 20.0,
      maxSectorConcentrationPercent: 40.0,
      maxGeographyConcentrationPercent: 45.0
    }
  },
  {
    id: 'fund-evwm-industrial',
    name: 'EVWM Industrial Transformation & Engineering Fund',
    vintage: 2023,
    vintageYear: 2023,
    fundSize: 600,
    size: 600,
    committedCapital: 550,
    investedCapital: 310,
    calledCapital: 310,
    uncalledCapital: 240,
    realisedProceeds: 35,
    unrealisedValue: 395,
    cash: 40,
    fundDebt: 0,
    nav: 435,
    investmentPeriodYears: 5,
    fundLifeYears: 10,
    managementFeePercent: 1.75,
    carriedInterestPercent: 20.0,
    preferredReturnPercent: 8.0,
    gpCommitmentPercent: 3.0,
    reinvestmentAllowed: false,
    currency: 'EUR (€)',
    sectors: ['INDUSTRIALS', 'LOGISTICS', 'TRANSPORT'],
    geographies: ['DACH', 'United Kingdom', 'Isle of Man', 'Scandinavia'],
    targetGrossIRR: 22.0,
    targetNetIRR: 17.5,
    grossIRR: 22.0,
    netIRR: 17.5,
    targetMOIC: 2.3,
    maxLeverageMultiple: 3.8,
    maxSingleDealExposurePercent: 16.0,
    investmentLimits: {
      maxSingleDealPercent: 16.0,
      maxSectorConcentrationPercent: 35.0,
      maxGeographyConcentrationPercent: 40.0
    }
  },
  {
    id: 'fund-evwm-tech',
    name: 'EVWM Strategic Technology & Enterprise Software Fund',
    vintage: 2024,
    vintageYear: 2024,
    fundSize: 500,
    size: 500,
    committedCapital: 460,
    investedCapital: 190,
    calledCapital: 190,
    uncalledCapital: 270,
    realisedProceeds: 15,
    unrealisedValue: 240,
    cash: 45,
    fundDebt: 0,
    nav: 285,
    investmentPeriodYears: 4,
    fundLifeYears: 10,
    managementFeePercent: 2.0,
    carriedInterestPercent: 20.0,
    preferredReturnPercent: 8.0,
    gpCommitmentPercent: 4.0,
    reinvestmentAllowed: true,
    currency: 'EUR (€)',
    sectors: ['TECHNOLOGY', 'FINANCIAL SERVICES', 'HEALTHCARE'],
    geographies: ['Western Europe', 'United Kingdom', 'Nordics'],
    targetGrossIRR: 28.0,
    targetNetIRR: 22.5,
    grossIRR: 28.0,
    netIRR: 22.5,
    targetMOIC: 3.0,
    maxLeverageMultiple: 3.0,
    maxSingleDealExposurePercent: 15.0,
    investmentLimits: {
      maxSingleDealPercent: 15.0,
      maxSectorConcentrationPercent: 35.0,
      maxGeographyConcentrationPercent: 40.0
    }
  }
];

export const INITIAL_LP_COMMITMENTS: LPCommitment[] = [
  {
    id: 'lp-01',
    fundId: 'fund-evwm-1',
    lpName: 'Nordic Sovereign Wealth & Pension Pool',
    name: 'Nordic Sovereign Wealth & Pension Pool',
    lpType: 'Sovereign Wealth Fund',
    type: 'Sovereign Wealth Fund',
    domicile: 'Oslo, Norway',
    jurisdiction: 'Oslo, Norway',
    totalCommitment: 200.0,
    commitmentAmount: 200.0,
    calledCapital: 132.0,
    uncalledCapital: 68.0,
    distributionsReceived: 37.8,
    lastCallDate: '2026-06-15'
  },
  {
    id: 'lp-02',
    fundId: 'fund-evwm-1',
    lpName: 'Monegasque & Swiss Multi-Family Office Consortium',
    name: 'Monegasque & Swiss Multi-Family Office Consortium',
    lpType: 'Family Office',
    type: 'Family Office',
    domicile: 'Geneva, Switzerland',
    jurisdiction: 'Geneva, Switzerland',
    totalCommitment: 150.0,
    commitmentAmount: 150.0,
    calledCapital: 99.0,
    uncalledCapital: 51.0,
    distributionsReceived: 28.4,
    lastCallDate: '2026-06-15'
  },
  {
    id: 'lp-03',
    fundId: 'fund-evwm-1',
    lpName: 'Crown Dependencies Institutional Pension Scheme',
    name: 'Crown Dependencies Institutional Pension Scheme',
    lpType: 'Pension Fund',
    type: 'Pension Fund',
    domicile: 'Douglas, Isle of Man',
    jurisdiction: 'Douglas, Isle of Man',
    totalCommitment: 125.0,
    commitmentAmount: 125.0,
    calledCapital: 82.5,
    uncalledCapital: 42.5,
    distributionsReceived: 23.6,
    lastCallDate: '2026-06-15'
  },
  {
    id: 'lp-04',
    fundId: 'fund-evwm-1',
    lpName: 'Abu Dhabi Direct Investment Authority (ADIA Subsidiary)',
    name: 'Abu Dhabi Direct Investment Authority (ADIA Subsidiary)',
    lpType: 'Sovereign Wealth Fund',
    type: 'Sovereign Wealth Fund',
    domicile: 'Abu Dhabi, UAE',
    jurisdiction: 'Abu Dhabi, UAE',
    totalCommitment: 150.0,
    commitmentAmount: 150.0,
    calledCapital: 99.0,
    uncalledCapital: 51.0,
    distributionsReceived: 28.4,
    lastCallDate: '2026-06-15'
  },
  {
    id: 'lp-05',
    fundId: 'fund-evwm-1',
    lpName: 'Oxford & Cambridge Collegiate Endowment Trust',
    name: 'Oxford & Cambridge Collegiate Endowment Trust',
    lpType: 'Endowment',
    type: 'Endowment',
    domicile: 'London, United Kingdom',
    jurisdiction: 'London, United Kingdom',
    totalCommitment: 98.75,
    commitmentAmount: 98.75,
    calledCapital: 65.2,
    uncalledCapital: 33.55,
    distributionsReceived: 18.7,
    lastCallDate: '2026-06-15'
  },
  {
    id: 'lp-06',
    fundId: 'fund-evwm-1',
    lpName: 'Ellan Vannin Capital GP Alignment Vehicle',
    name: 'Ellan Vannin Capital GP Alignment Vehicle',
    lpType: 'GP Commitment',
    type: 'GP Commitment',
    domicile: 'Douglas, Isle of Man',
    jurisdiction: 'Douglas, Isle of Man',
    totalCommitment: 26.25,
    commitmentAmount: 26.25,
    calledCapital: 17.3,
    uncalledCapital: 8.95,
    distributionsReceived: 5.1,
    lastCallDate: '2026-06-15'
  }
];

export const INITIAL_LIMITED_PARTNERS = INITIAL_LP_COMMITMENTS;

export const INITIAL_CAPITAL_CALLS: CapitalCall[] = [
  {
    id: 'cc-001',
    fundId: 'fund-evwm-1',
    callNumber: 1,
    callDate: '2022-04-10',
    dueDate: '2022-04-24',
    purpose: 'Initial Fund Setup, Working Capital & First Direct Acquisition of Aethelgard Precision Industrial',
    investmentAmount: 115.0,
    feeAmount: 13.1,
    expenseAmount: 2.2,
    totalCallAmount: 130.3,
    status: 'Settled',
    lpsParticipating: 6
  },
  {
    id: 'cc-002',
    fundId: 'fund-evwm-1',
    callNumber: 2,
    callDate: '2023-09-18',
    dueDate: '2023-10-02',
    purpose: 'Direct Acquisition of Isle of Man Logistics & Ferry Infrastructure Terminal',
    investmentAmount: 140.0,
    feeAmount: 9.5,
    expenseAmount: 1.8,
    totalCallAmount: 151.3,
    status: 'Settled',
    lpsParticipating: 6
  },
  {
    id: 'cc-003',
    fundId: 'fund-evwm-1',
    callNumber: 3,
    callDate: '2024-11-05',
    dueDate: '2024-11-19',
    purpose: 'Buyout of Helvetia MedTech Devices & Add-on M&A Integration',
    investmentAmount: 135.0,
    feeAmount: 8.2,
    expenseAmount: 1.5,
    totalCallAmount: 144.7,
    status: 'Settled',
    lpsParticipating: 6
  },
  {
    id: 'cc-004',
    fundId: 'fund-evwm-1',
    callNumber: 4,
    callDate: '2026-06-01',
    dueDate: '2026-06-15',
    purpose: 'Growth Capital for Nordic Grid Expansion & Celtic Energy Bolt-On',
    investmentAmount: 65.0,
    feeAmount: 3.2,
    expenseAmount: 0.5,
    totalCallAmount: 68.7,
    status: 'Settled',
    lpsParticipating: 6
  }
];

export const INITIAL_DEALS: Deal[] = [
  // 1. Portfolio Asset - Aethelgard Precision Industrial
  {
    id: 'deal-001',
    fundId: 'fund-evwm-1',
    companyName: 'Aethelgard Precision Industrial',
    sector: 'INDUSTRIALS',
    country: 'Germany',
    city: 'Stuttgart',
    coordinates: [48.7758, 9.1829],
    stage: 'PORTFOLIO',
    isPortfolioCompany: true,
    acquisitionDate: '2022-05-12',
    entryValuationEV: 145.0,
    entryEquity: 78.0,
    currentValuationEV: 215.0,
    currentNetDebt: 42.0,
    currentEquityValue: 173.0,
    headcount: 840,
    leadPartner: 'Tom Quilliam',
    dealTeam: ['Marcus Vance', 'Sarah Sterling', 'Tobias Lind'],
    seller: 'Founder Estate / Family Office',
    adviser: 'Rothschild & Co',
    revenue: 92.5,
    ebitda: 21.8,
    ebitdaMargin: 23.6,
    askingPrice: 145.0,
    proposedValuationEV: 145.0,
    dealSizeEquity: 78.0,
    targetIRR: 24.5,
    targetMOIC: 2.6,
    createdDate: '2022-01-15',
    expectedCloseQuarter: 'Q2 2022',
    screeningScorecard: {
      growth: 82,
      profitability: 88,
      cashFlow: 85,
      competitiveAdvantage: 92,
      management: 84,
      valuation: 79,
      marketSize: 76,
      barriersToEntry: 90,
      recurringRevenue: 80,
      capitalIntensity: 78,
      leverageSuitability: 85,
      exitPotential: 88,
      overallScore: 84,
      notes: 'Global niche leader in micro-tolerance aerospace CNC actuators with 85% sole-source supplier agreements.'
    },
    financialDD: {
      revenueGrowth3YrCAGR: 11.2,
      grossMargin: 46.5,
      ebitdaMargin: 23.6,
      fcfConversion: 74.5,
      leverage: 1.93,
      interestCoverage: 6.8,
      workingCapitalAsPctRevenue: 14.2,
      historicalYears: [
        { year: 2023, revenue: 76.2, cogs: 41.2, grossProfit: 35.0, ebitda: 16.5, ebit: 13.8, interestExpense: 2.8, tax: 2.4, netIncome: 8.6, capex: 2.8, changeInWorkingCapital: 1.1, fcf: 10.2, totalDebt: 60.0, cash: 12.0, netDebt: 48.0 },
        { year: 2024, revenue: 84.0, cogs: 45.1, grossProfit: 38.9, ebitda: 18.9, ebit: 15.9, interestExpense: 2.6, tax: 2.9, netIncome: 10.4, capex: 3.1, changeInWorkingCapital: 1.2, fcf: 12.0, totalDebt: 54.0, cash: 14.5, netDebt: 39.5 },
        { year: 2025, revenue: 92.5, cogs: 49.5, grossProfit: 43.0, ebitda: 21.8, ebit: 18.6, interestExpense: 2.4, tax: 3.5, netIncome: 12.7, capex: 3.4, changeInWorkingCapital: 1.4, fcf: 13.5, totalDebt: 48.0, cash: 18.0, netDebt: 30.0 }
      ],
      redFlags: [
        { title: 'Single CNC Tooling Supplier in Switzerland', description: 'Dual-sourcing initiated in Q3 2024 to eliminate single-point supply risk.', severity: 'MEDIUM', quantifiedImpact: 1.8 }
      ]
    },
    commercialDD: {
      tam: 4200,
      sam: 1100,
      marketGrowthRate: 8.4,
      marketShare: 14.5,
      pricingPower: 'High',
      top5CustomerConcentration: 28.0,
      customerRetentionRate: 98.2,
      supplierConcentration: 22.0,
      barriersToEntryScore: 92,
      marketAttractivenessScore: 89,
      keyCompetitors: [
        { name: 'Moog Precision', marketShare: 22.0, differentiation: 'Legacy hydraulic focus; slower electronic integration' },
        { name: 'Parker Hannifin Aerospace', marketShare: 26.0, differentiation: 'Broad catalog, higher pricing, lower customization' }
      ]
    },
    managementDD: {
      ceoExperienceYears: 24,
      csuiteAlignment: 'Strong Equity Alignment',
      trackRecordScore: 91,
      governanceScore: 88,
      successionPlanInPlace: true,
      keyPersonRisk: 'Low',
      managementQualityScore: 90,
      leadershipTeam: [
        { role: 'CEO', name: 'Dr. Klaus von Berg', tenureYears: 12, equityOwnershipPct: 8.5, assessment: 'Outstanding operational execution, PhD in Mechatronics.' },
        { role: 'CFO', name: 'Helena Meyer, CFA', tenureYears: 5, equityOwnershipPct: 3.0, assessment: 'Rigorous capital discipline, ex-KPMG PE Advisory.' }
      ]
    },
    valuationSuite: {
      dcfValuation: { wacc: 9.8, terminalGrowthRate: 2.5, enterpriseValue: 228.0, equityValue: 186.0, impliedMultiple: 10.5 },
      comparableTradingMultiples: { evEbitdaMultiple: 10.2, evRevenueMultiple: 2.35, peMultiple: 16.5, impliedEV: 222.0 },
      precedentTransactions: { medianMultiple: 10.8, lowMultiple: 8.5, highMultiple: 12.5, impliedEV: 235.0 },
      sotpValuation: {
        divisions: [
          { name: 'Aerospace Actuators', ebitda: 14.5, multiple: 11.0, value: 159.5 },
          { name: 'Industrial High-Precision Valves', ebitda: 7.3, multiple: 9.0, value: 65.7 }
        ],
        totalEV: 225.2
      },
      summaryCases: { lowCaseEV: 190.0, baseCaseEV: 225.0, highCaseEV: 260.0, recommendedEntryEV: 145.0 }
    },
    lboModel: {
      purchasePrice: 145.0,
      entryEbitda: 16.0,
      entryMultiple: 9.06,
      holdingPeriodYears: 5,
      exitMultiple: 10.0,
      revenueGrowthAnnual: 9.5,
      ebitdaMarginExit: 24.5,
      capexAsPctRevenue: 3.5,
      taxRate: 25.0,
      debtTranches: [
        { type: 'Senior Secured A', amount: 55.0, marginOverEuribor: 3.25, baseRate: 3.5, totalRate: 6.75, amortisationPercentAnnual: 8.0, tenorYears: 6, covenantDebtToEbitda: 3.75, covenantInterestCoverage: 3.0 },
        { type: 'Mezzanine', amount: 15.0, marginOverEuribor: 7.5, baseRate: 3.5, totalRate: 11.0, amortisationPercentAnnual: 0, tenorYears: 7, covenantDebtToEbitda: 4.5, covenantInterestCoverage: 2.0 }
      ],
      sourcesAndUses: {
        purchasePrice: 145.0,
        refinancingDebt: 0,
        transactionFees: 4.5,
        financingFees: 2.5,
        minimumCashBuffer: 8.0,
        totalUses: 160.0,
        seniorDebt: 55.0,
        mezzanineDebt: 15.0,
        sponsorEquity: 78.0,
        managementRollover: 12.0,
        totalSources: 160.0
      },
      projectedFinancials: [
        { year: 1, revenue: 76.2, ebitda: 16.5, fcf: 8.5, debtPaid: 5.5, endingDebt: 64.5, cashBalance: 11.0 },
        { year: 2, revenue: 84.0, ebitda: 18.9, fcf: 10.8, debtPaid: 6.5, endingDebt: 58.0, cashBalance: 15.3 },
        { year: 3, revenue: 92.5, ebitda: 21.8, fcf: 13.2, debtPaid: 8.0, endingDebt: 50.0, cashBalance: 20.5 },
        { year: 4, revenue: 101.5, ebitda: 24.5, fcf: 15.5, debtPaid: 9.0, endingDebt: 41.0, cashBalance: 27.0 },
        { year: 5, revenue: 111.0, ebitda: 27.2, fcf: 18.0, debtPaid: 11.0, endingDebt: 30.0, cashBalance: 34.0 }
      ],
      exitEnterpriseValue: 272.0,
      exitNetDebt: -4.0,
      exitEquityValue: 276.0,
      grossProceeds: 239.0,
      grossIRR: 25.8,
      netIRR: 20.8,
      moic: 3.06,
      cashOnCash: 3.06
    },
    icStatus: 'IC APPROVED',
    icVoteCount: { approve: 5, reject: 0, conditional: 0 },
    icComments: [
      { author: 'Tom Quilliam', role: 'FUND MANAGER', comment: 'Model underwrites disciplined margin expansion through direct automation with 0% multiple expansion reliance.', date: '2022-04-18' }
    ],
    dueDiligenceIssues: [
      { id: 'dd-01', category: 'Operational', title: 'Factory Floor Automation Upgrade', description: 'Robotic cell integration to reduce scrap rates by 35%.', severity: 'LOW', owner: 'Marcus Vance', deadline: '2024-12-31', status: 'Resolved / Cleared', financialImpact: 2.4 }
    ],
    dataRoomDocs: [
      { id: 'doc-01', category: 'Financials', name: 'Quality of Earnings Report - PwC.pdf', uploadDate: '2022-03-10', size: '14.8 MB', status: 'REVIEWED', reviewedBy: 'Sarah Sterling', flaggedIssuesCount: 0 },
      { id: 'doc-02', category: 'Legal', name: 'Vendor SPA & Warranty Deeds.pdf', uploadDate: '2022-03-25', size: '22.1 MB', status: 'CLEARED', reviewedBy: 'Legal Counsel', flaggedIssuesCount: 0 }
    ],
    operatingKPIs: {
      revenuePerCustomer: 420.0,
      cac: 24.0,
      ltvToCac: 12.5,
      grossMargin: 46.5,
      ebitdaMargin: 23.6,
      productionCapacityUtilisation: 87.5,
      inventoryTurnoverRatio: 7.2,
      workingCapitalDays: 48,
      revenuePerFTE: 110.1,
      netPromoterScore: 78
    },
    valueCreationInitiatives: [
      { id: 'vc-01', title: 'Automated 5-Axis Robotic CNC Cells', category: 'Automation & AI', description: 'Deploy lights-out CNC machining during night shifts.', ebitdaImpactAnnual: 3.8, oneTimeCost: 4.5, executionTimelineMonths: 18, status: 'Fully Realised', realisedEbitdaToDate: 3.8, owner: 'Operating Partner Vance' },
      { id: 'vc-02', title: 'Direct Aerospace OEM Pricing Surcharge Indexation', category: 'Pricing', description: 'Contractual alloy indexation passed to tier-1 OEMs.', ebitdaImpactAnnual: 2.2, oneTimeCost: 0.2, executionTimelineMonths: 6, status: 'Fully Realised', realisedEbitdaToDate: 2.2, owner: 'Dr. Klaus von Berg' },
      { id: 'vc-03', title: 'US Defense MRO Certification Expansion', category: 'International Expansion', description: 'FAA/ITAR dual-certification to capture transatlantic retrofit contracts.', ebitdaImpactAnnual: 4.5, oneTimeCost: 1.8, executionTimelineMonths: 24, status: 'In Execution', realisedEbitdaToDate: 1.2, owner: 'Sarah Sterling' }
    ],
    esgGovernance: {
      boardIndependencePct: 60.0,
      femaleBoardRepresentationPct: 40.0,
      ghgScope1And2Tonnes: 1420,
      renewableEnergyUsagePct: 82.0,
      lostTimeInjuryFrequency: 0.2,
      whistleblowerComplaintsResolved: 1,
      antiCorruptionAuditPassed: true,
      materialIncidentsCount: 0,
      documentedAuditLog: 'TUV Rheinland ISO 14001, ISO 45001, AS9100D audited May 2025.',
      institutionalESGGrade: 'AAA'
    }
  },

  // 2. Portfolio Asset - Isle of Man Logistics & Marine Port Terminals
  {
    id: 'deal-002',
    fundId: 'fund-evwm-1',
    companyName: 'Isle of Man Marine & Logistics Terminals',
    sector: 'LOGISTICS',
    country: 'Isle of Man',
    city: 'Douglas',
    coordinates: [54.1500, -4.4833],
    stage: 'PORTFOLIO',
    isPortfolioCompany: true,
    acquisitionDate: '2023-10-15',
    entryValuationEV: 175.0,
    entryEquity: 95.0,
    currentValuationEV: 220.0,
    currentNetDebt: 58.0,
    currentEquityValue: 162.0,
    headcount: 520,
    leadPartner: 'Tom Quilliam',
    dealTeam: ['Sir Arthur Kelly', 'Marcus Vance'],
    seller: 'Infrastructure Consortium',
    adviser: 'Lazard',
    revenue: 68.0,
    ebitda: 28.5,
    ebitdaMargin: 41.9,
    askingPrice: 175.0,
    proposedValuationEV: 175.0,
    dealSizeEquity: 95.0,
    targetIRR: 21.0,
    targetMOIC: 2.4,
    createdDate: '2023-04-10',
    expectedCloseQuarter: 'Q4 2023',
    screeningScorecard: {
      growth: 75,
      profitability: 96,
      cashFlow: 94,
      competitiveAdvantage: 98,
      management: 88,
      valuation: 82,
      marketSize: 74,
      barriersToEntry: 99,
      recurringRevenue: 95,
      capitalIntensity: 70,
      leverageSuitability: 92,
      exitPotential: 86,
      overallScore: 89,
      notes: 'Monopolistic essential transport & freight corridor connecting the Irish Sea to Liverpool & Heysham with 30-year concession.'
    },
    financialDD: {
      revenueGrowth3YrCAGR: 7.8,
      grossMargin: 58.0,
      ebitdaMargin: 41.9,
      fcfConversion: 82.0,
      leverage: 2.03,
      interestCoverage: 5.9,
      workingCapitalAsPctRevenue: 8.5,
      historicalYears: [
        { year: 2023, revenue: 58.5, cogs: 24.5, grossProfit: 34.0, ebitda: 24.0, ebit: 19.5, interestExpense: 3.5, tax: 0.0, netIncome: 16.0, capex: 4.5, changeInWorkingCapital: 0.5, fcf: 19.0, totalDebt: 75.0, cash: 8.0, netDebt: 67.0 },
        { year: 2024, revenue: 63.0, cogs: 26.2, grossProfit: 36.8, ebitda: 26.2, ebit: 21.4, interestExpense: 3.4, tax: 0.0, netIncome: 18.0, capex: 4.0, changeInWorkingCapital: 0.6, fcf: 21.6, totalDebt: 70.0, cash: 12.0, netDebt: 58.0 },
        { year: 2025, revenue: 68.0, cogs: 28.0, grossProfit: 40.0, ebitda: 28.5, ebit: 23.5, interestExpense: 3.2, tax: 0.0, netIncome: 20.3, capex: 4.2, changeInWorkingCapital: 0.8, fcf: 23.5, totalDebt: 64.0, cash: 16.0, netDebt: 48.0 }
      ],
      redFlags: []
    },
    commercialDD: {
      tam: 180,
      sam: 110,
      marketGrowthRate: 5.2,
      marketShare: 88.0,
      pricingPower: 'High',
      top5CustomerConcentration: 42.0,
      customerRetentionRate: 99.5,
      supplierConcentration: 15.0,
      barriersToEntryScore: 99,
      marketAttractivenessScore: 92,
      keyCompetitors: []
    },
    managementDD: {
      ceoExperienceYears: 20,
      csuiteAlignment: 'Strong Equity Alignment',
      trackRecordScore: 89,
      governanceScore: 94,
      successionPlanInPlace: true,
      keyPersonRisk: 'Low',
      managementQualityScore: 92,
      leadershipTeam: [
        { role: 'Managing Director', name: 'Capt. Alistair Christian', tenureYears: 14, equityOwnershipPct: 6.0, assessment: 'Master Mariner, deeply trusted by Port Authority.' }
      ]
    },
    valuationSuite: {
      dcfValuation: { wacc: 7.9, terminalGrowthRate: 2.0, enterpriseValue: 245.0, equityValue: 197.0, impliedMultiple: 8.6 },
      comparableTradingMultiples: { evEbitdaMultiple: 8.5, evRevenueMultiple: 3.5, peMultiple: 12.5, impliedEV: 242.0 },
      precedentTransactions: { medianMultiple: 9.0, lowMultiple: 7.8, highMultiple: 10.5, impliedEV: 256.0 },
      sotpValuation: {
        divisions: [
          { name: 'Roll-on/Roll-off Passenger & Cargo', ebitda: 20.0, multiple: 9.0, value: 180.0 },
          { name: 'Cold-Storage & Bonded Warehousing', ebitda: 8.5, multiple: 8.0, value: 68.0 }
        ],
        totalEV: 248.0
      },
      summaryCases: { lowCaseEV: 210.0, baseCaseEV: 245.0, highCaseEV: 275.0, recommendedEntryEV: 175.0 }
    },
    lboModel: {
      purchasePrice: 175.0,
      entryEbitda: 24.0,
      entryMultiple: 7.29,
      holdingPeriodYears: 5,
      exitMultiple: 8.5,
      revenueGrowthAnnual: 6.5,
      ebitdaMarginExit: 43.0,
      capexAsPctRevenue: 4.0,
      taxRate: 0.0, // Isle of Man standard corporate rate
      debtTranches: [
        { type: 'Senior Secured A', amount: 70.0, marginOverEuribor: 2.75, baseRate: 3.5, totalRate: 6.25, amortisationPercentAnnual: 6.0, tenorYears: 7, covenantDebtToEbitda: 3.8, covenantInterestCoverage: 3.5 }
      ],
      sourcesAndUses: {
        purchasePrice: 175.0,
        refinancingDebt: 0,
        transactionFees: 3.5,
        financingFees: 1.5,
        minimumCashBuffer: 5.0,
        totalUses: 185.0,
        seniorDebt: 70.0,
        mezzanineDebt: 10.0,
        sponsorEquity: 95.0,
        managementRollover: 10.0,
        totalSources: 185.0
      },
      projectedFinancials: [
        { year: 1, revenue: 58.5, ebitda: 24.0, fcf: 15.0, debtPaid: 8.0, endingDebt: 72.0, cashBalance: 12.0 },
        { year: 2, revenue: 63.0, ebitda: 26.2, fcf: 17.5, debtPaid: 9.0, endingDebt: 63.0, cashBalance: 16.5 },
        { year: 3, revenue: 68.0, ebitda: 28.5, fcf: 19.8, debtPaid: 10.0, endingDebt: 53.0, cashBalance: 21.3 },
        { year: 4, revenue: 72.5, ebitda: 30.8, fcf: 21.5, debtPaid: 11.0, endingDebt: 42.0, cashBalance: 26.8 },
        { year: 5, revenue: 77.5, ebitda: 33.3, fcf: 23.5, debtPaid: 12.0, endingDebt: 30.0, cashBalance: 33.3 }
      ],
      exitEnterpriseValue: 283.0,
      exitNetDebt: -3.3,
      exitEquityValue: 286.3,
      grossProceeds: 259.0,
      grossIRR: 22.4,
      netIRR: 17.8,
      moic: 2.72,
      cashOnCash: 2.72
    },
    icStatus: 'IC APPROVED',
    icVoteCount: { approve: 5, reject: 0, conditional: 0 },
    icComments: [],
    dueDiligenceIssues: [],
    dataRoomDocs: [],
    operatingKPIs: {
      revenuePerCustomer: 95.0,
      cac: 2.5,
      ltvToCac: 24.0,
      grossMargin: 58.0,
      ebitdaMargin: 41.9,
      productionCapacityUtilisation: 92.0,
      inventoryTurnoverRatio: 18.0,
      workingCapitalDays: 24,
      revenuePerFTE: 130.8,
      netPromoterScore: 84
    },
    valueCreationInitiatives: [
      { id: 'vc-201', title: 'Automated Ro-Ro Smart Gate & OCR Freight Flow', category: 'Automation & AI', description: 'Automated license plate and container scanning reducing gate wait by 65%.', ebitdaImpactAnnual: 1.8, oneTimeCost: 1.2, executionTimelineMonths: 12, status: 'Fully Realised', realisedEbitdaToDate: 1.8, owner: 'Operating Partner Vance' },
      { id: 'vc-202', title: 'On-dock Cold Storage Facility Expansion', category: 'New Products', description: 'Direct pharmaceutical & seafood temperature-controlled storage.', ebitdaImpactAnnual: 2.5, oneTimeCost: 3.5, executionTimelineMonths: 18, status: 'In Execution', realisedEbitdaToDate: 1.0, owner: 'Capt. Alistair Christian' }
    ],
    esgGovernance: {
      boardIndependencePct: 66.0,
      femaleBoardRepresentationPct: 33.0,
      ghgScope1And2Tonnes: 3200,
      renewableEnergyUsagePct: 100.0, // shore-to-ship renewable electricity
      lostTimeInjuryFrequency: 0.0,
      whistleblowerComplaintsResolved: 0,
      antiCorruptionAuditPassed: true,
      materialIncidentsCount: 0,
      documentedAuditLog: 'Green Port Award 2024, ISO 14001 certified.',
      institutionalESGGrade: 'AAA'
    }
  },

  // 3. Pipeline Asset - Nordic Grid Infrastructure
  {
    id: 'deal-003',
    fundId: 'fund-evwm-1',
    companyName: 'Nordic Grid Energy Transition Assets',
    sector: 'ENERGY',
    country: 'Sweden',
    city: 'Stockholm',
    coordinates: [59.3293, 18.0686],
    stage: 'INVESTMENT COMMITTEE',
    leadPartner: 'Sarah Sterling',
    dealTeam: ['Tom Quilliam', 'Tobias Lind'],
    seller: 'Vattenfall Subsidary carve-out',
    adviser: 'Morgan Stanley',
    revenue: 145.0,
    ebitda: 48.0,
    ebitdaMargin: 33.1,
    askingPrice: 380.0,
    proposedValuationEV: 360.0,
    dealSizeEquity: 185.0,
    targetIRR: 22.0,
    targetMOIC: 2.4,
    createdDate: '2025-11-20',
    expectedCloseQuarter: 'Q4 2026',
    screeningScorecard: {
      growth: 88,
      profitability: 92,
      cashFlow: 89,
      competitiveAdvantage: 95,
      management: 90,
      valuation: 76,
      marketSize: 94,
      barriersToEntry: 96,
      recurringRevenue: 98,
      capitalIntensity: 65,
      leverageSuitability: 90,
      exitPotential: 92,
      overallScore: 88,
      notes: 'Critical high-voltage battery storage and smart grid transmission network with long-term CPI-indexed capacity contracts.'
    },
    financialDD: {
      revenueGrowth3YrCAGR: 14.5,
      grossMargin: 52.0,
      ebitdaMargin: 33.1,
      fcfConversion: 71.0,
      leverage: 3.1,
      interestCoverage: 4.8,
      workingCapitalAsPctRevenue: 6.2,
      historicalYears: [
        { year: 2023, revenue: 110.0, cogs: 52.0, grossProfit: 58.0, ebitda: 35.0, ebit: 27.0, interestExpense: 5.5, tax: 4.5, netIncome: 17.0, capex: 12.0, changeInWorkingCapital: 1.5, fcf: 21.0, totalDebt: 160.0, cash: 15.0, netDebt: 145.0 },
        { year: 2024, revenue: 128.0, cogs: 60.0, grossProfit: 68.0, ebitda: 41.5, ebit: 32.5, interestExpense: 6.2, tax: 5.5, netIncome: 20.8, capex: 14.0, changeInWorkingCapital: 1.8, fcf: 24.5, totalDebt: 155.0, cash: 18.0, netDebt: 137.0 },
        { year: 2025, revenue: 145.0, cogs: 69.5, grossProfit: 75.5, ebitda: 48.0, ebit: 38.0, interestExpense: 6.8, tax: 6.5, netIncome: 24.7, capex: 16.0, changeInWorkingCapital: 2.0, fcf: 28.5, totalDebt: 150.0, cash: 22.0, netDebt: 128.0 }
      ],
      redFlags: [
        { title: 'Substation Transformer Delivery Lead Time', description: 'Siemens Energy lead time is 18 months; covered by advance allocation options.', severity: 'MEDIUM', quantifiedImpact: 3.5 }
      ]
    },
    commercialDD: {
      tam: 12000,
      sam: 3400,
      marketGrowthRate: 16.8,
      marketShare: 18.2,
      pricingPower: 'High',
      top5CustomerConcentration: 50.0,
      customerRetentionRate: 100.0,
      supplierConcentration: 30.0,
      barriersToEntryScore: 96,
      marketAttractivenessScore: 94,
      keyCompetitors: [
        { name: 'Ellevio Grid', marketShare: 24.0, differentiation: 'Regulated distribution focus; lower battery storage capability' }
      ]
    },
    managementDD: {
      ceoExperienceYears: 22,
      csuiteAlignment: 'Strong Equity Alignment',
      trackRecordScore: 92,
      governanceScore: 90,
      successionPlanInPlace: true,
      keyPersonRisk: 'Low',
      managementQualityScore: 91,
      leadershipTeam: [
        { role: 'CEO', name: 'Astrid Lindqvist', tenureYears: 8, equityOwnershipPct: 4.5, assessment: 'Ex-ABB VP, proven transformer infrastructure scaler.' }
      ]
    },
    valuationSuite: {
      dcfValuation: { wacc: 7.5, terminalGrowthRate: 2.5, enterpriseValue: 395.0, equityValue: 267.0, impliedMultiple: 8.2 },
      comparableTradingMultiples: { evEbitdaMultiple: 8.0, evRevenueMultiple: 2.65, peMultiple: 15.0, impliedEV: 384.0 },
      precedentTransactions: { medianMultiple: 8.5, lowMultiple: 7.2, highMultiple: 9.8, impliedEV: 408.0 },
      sotpValuation: {
        divisions: [
          { name: 'Grid Frequency Response Assets', ebitda: 32.0, multiple: 8.5, value: 272.0 },
          { name: 'EV Fast-Charging Fleet Hubs', ebitda: 16.0, multiple: 7.5, value: 120.0 }
        ],
        totalEV: 392.0
      },
      summaryCases: { lowCaseEV: 320.0, baseCaseEV: 380.0, highCaseEV: 420.0, recommendedEntryEV: 360.0 }
    },
    lboModel: {
      purchasePrice: 360.0,
      entryEbitda: 48.0,
      entryMultiple: 7.5,
      holdingPeriodYears: 5,
      exitMultiple: 8.2,
      revenueGrowthAnnual: 12.0,
      ebitdaMarginExit: 35.0,
      capexAsPctRevenue: 8.0,
      taxRate: 20.6,
      debtTranches: [
        { type: 'Senior Secured A', amount: 140.0, marginOverEuribor: 2.95, baseRate: 3.5, totalRate: 6.45, amortisationPercentAnnual: 5.0, tenorYears: 7, covenantDebtToEbitda: 3.75, covenantInterestCoverage: 3.2 },
        { type: 'Mezzanine', amount: 35.0, marginOverEuribor: 6.5, baseRate: 3.5, totalRate: 10.0, amortisationPercentAnnual: 0, tenorYears: 8, covenantDebtToEbitda: 4.5, covenantInterestCoverage: 2.2 }
      ],
      sourcesAndUses: {
        purchasePrice: 360.0,
        refinancingDebt: 0,
        transactionFees: 6.5,
        financingFees: 3.5,
        minimumCashBuffer: 15.0,
        totalUses: 385.0,
        seniorDebt: 140.0,
        mezzanineDebt: 35.0,
        sponsorEquity: 185.0,
        managementRollover: 25.0,
        totalSources: 385.0
      },
      projectedFinancials: [
        { year: 1, revenue: 162.4, ebitda: 54.5, fcf: 24.0, debtPaid: 14.0, endingDebt: 161.0, cashBalance: 25.0 },
        { year: 2, revenue: 181.9, ebitda: 62.0, fcf: 28.5, debtPaid: 16.0, endingDebt: 145.0, cashBalance: 37.5 },
        { year: 3, revenue: 203.7, ebitda: 70.5, fcf: 34.0, debtPaid: 18.0, endingDebt: 127.0, cashBalance: 53.5 },
        { year: 4, revenue: 228.1, ebitda: 80.0, fcf: 40.0, debtPaid: 20.0, endingDebt: 107.0, cashBalance: 73.5 },
        { year: 5, revenue: 255.5, ebitda: 89.4, fcf: 46.5, debtPaid: 22.0, endingDebt: 85.0, cashBalance: 98.0 }
      ],
      exitEnterpriseValue: 733.0,
      exitNetDebt: -13.0,
      exitEquityValue: 746.0,
      grossProceeds: 657.0,
      grossIRR: 28.8,
      netIRR: 23.4,
      moic: 3.55,
      cashOnCash: 3.55
    },
    icStatus: 'UNDER REVIEW',
    icVoteCount: { approve: 3, reject: 0, conditional: 1 },
    icComments: [
      { author: 'Lady Eleanor Christian', role: 'INVESTMENT COMMITTEE', comment: 'Require confirmation on Svenska Kraftnät grid connection priority rights before final signing.', date: '2026-08-25' }
    ],
    dueDiligenceIssues: [
      { id: 'dd-301', category: 'Technical', title: 'Grid Connection Queue Confirmation', description: 'Verify Svenska Kraftnät transmission rights through 2035.', severity: 'HIGH', owner: 'Tobias Lind', deadline: '2026-09-15', status: 'Mitigation in Progress', financialImpact: 12.0 }
    ],
    dataRoomDocs: [
      { id: 'doc-301', category: 'Commercial', name: 'Nordic Battery Storage Market Study - Wood Mackenzie.pdf', uploadDate: '2026-07-15', size: '28.4 MB', status: 'REVIEWED', reviewedBy: 'Sarah Sterling', flaggedIssuesCount: 0 }
    ]
  },

  // 4. Pipeline Asset - Helvetia MedTech
  {
    id: 'deal-004',
    fundId: 'fund-evwm-1',
    companyName: 'Helvetia Robotic Surgery & Implants',
    sector: 'HEALTHCARE',
    country: 'Switzerland',
    city: 'Zurich',
    coordinates: [47.3769, 8.5417],
    stage: 'DUE DILIGENCE',
    leadPartner: 'Marcus Vance',
    dealTeam: ['Sarah Sterling', 'Tobias Lind'],
    seller: 'Venture & Growth Syndicate',
    adviser: 'Evercore',
    revenue: 54.0,
    ebitda: 14.5,
    ebitdaMargin: 26.8,
    askingPrice: 165.0,
    proposedValuationEV: 155.0,
    dealSizeEquity: 90.0,
    targetIRR: 26.5,
    targetMOIC: 2.8,
    createdDate: '2026-01-10',
    expectedCloseQuarter: 'Q4 2026',
    screeningScorecard: {
      growth: 94,
      profitability: 82,
      cashFlow: 80,
      competitiveAdvantage: 96,
      management: 92,
      valuation: 75,
      marketSize: 90,
      barriersToEntry: 98,
      recurringRevenue: 85,
      capitalIntensity: 72,
      leverageSuitability: 78,
      exitPotential: 95,
      overallScore: 87,
      notes: 'Proprietary titanium 3D-printed orthopaedic knee/spine implants with CE Mark & FDA 510(k) cleared navigation software.'
    },
    financialDD: {
      revenueGrowth3YrCAGR: 19.5,
      grossMargin: 68.5,
      ebitdaMargin: 26.8,
      fcfConversion: 65.0,
      leverage: 2.2,
      interestCoverage: 5.2,
      workingCapitalAsPctRevenue: 18.0,
      historicalYears: [
        { year: 2023, revenue: 38.0, cogs: 12.0, grossProfit: 26.0, ebitda: 8.5, ebit: 6.5, interestExpense: 1.5, tax: 1.0, netIncome: 4.0, capex: 3.5, changeInWorkingCapital: 1.2, fcf: 4.2, totalDebt: 35.0, cash: 6.0, netDebt: 29.0 },
        { year: 2024, revenue: 45.5, cogs: 14.5, grossProfit: 31.0, ebitda: 11.2, ebit: 8.8, interestExpense: 1.8, tax: 1.4, netIncome: 5.6, capex: 4.0, changeInWorkingCapital: 1.5, fcf: 6.2, totalDebt: 34.0, cash: 8.5, netDebt: 25.5 },
        { year: 2025, revenue: 54.0, cogs: 17.0, grossProfit: 37.0, ebitda: 14.5, ebit: 11.5, interestExpense: 2.0, tax: 1.9, netIncome: 7.6, capex: 4.5, changeInWorkingCapital: 1.8, fcf: 8.5, totalDebt: 32.0, cash: 12.0, netDebt: 20.0 }
      ],
      redFlags: []
    },
    commercialDD: {
      tam: 6500,
      sam: 1400,
      marketGrowthRate: 14.2,
      marketShare: 6.8,
      pricingPower: 'High',
      top5CustomerConcentration: 19.0,
      customerRetentionRate: 97.0,
      supplierConcentration: 20.0,
      barriersToEntryScore: 98,
      marketAttractivenessScore: 95,
      keyCompetitors: [
        { name: 'Stryker Mako', marketShare: 35.0, differentiation: 'High upfront robot cost; Helvetia offers modular surgical arms.' }
      ]
    },
    managementDD: {
      ceoExperienceYears: 18,
      csuiteAlignment: 'Strong Equity Alignment',
      trackRecordScore: 94,
      governanceScore: 89,
      successionPlanInPlace: true,
      keyPersonRisk: 'Moderate',
      managementQualityScore: 92,
      leadershipTeam: [
        { role: 'CEO', name: 'Dr. Beatrix Keller, MD', tenureYears: 7, equityOwnershipPct: 9.0, assessment: 'Former Chief of Orthopaedic Surgery at University Hospital Zurich.' }
      ]
    },
    valuationSuite: {
      dcfValuation: { wacc: 9.2, terminalGrowthRate: 3.0, enterpriseValue: 172.0, equityValue: 148.0, impliedMultiple: 11.8 },
      comparableTradingMultiples: { evEbitdaMultiple: 12.0, evRevenueMultiple: 3.2, peMultiple: 22.0, impliedEV: 174.0 },
      precedentTransactions: { medianMultiple: 12.5, lowMultiple: 10.0, highMultiple: 14.5, impliedEV: 181.0 },
      sotpValuation: {
        divisions: [
          { name: 'Orthopaedic Robotic Navigation Systems', ebitda: 9.5, multiple: 13.0, value: 123.5 },
          { name: 'Bio-compatible Titanium Implants', ebitda: 5.0, multiple: 10.5, value: 52.5 }
        ],
        totalEV: 176.0
      },
      summaryCases: { lowCaseEV: 135.0, baseCaseEV: 165.0, highCaseEV: 195.0, recommendedEntryEV: 155.0 }
    },
    lboModel: {
      purchasePrice: 155.0,
      entryEbitda: 14.5,
      entryMultiple: 10.69,
      holdingPeriodYears: 5,
      exitMultiple: 12.0,
      revenueGrowthAnnual: 16.0,
      ebitdaMarginExit: 30.0,
      capexAsPctRevenue: 4.5,
      taxRate: 15.0,
      debtTranches: [
        { type: 'Senior Secured A', amount: 55.0, marginOverEuribor: 3.5, baseRate: 3.5, totalRate: 7.0, amortisationPercentAnnual: 7.0, tenorYears: 6, covenantDebtToEbitda: 3.8, covenantInterestCoverage: 3.0 }
      ],
      sourcesAndUses: {
        purchasePrice: 155.0,
        refinancingDebt: 0,
        transactionFees: 4.0,
        financingFees: 2.0,
        minimumCashBuffer: 6.0,
        totalUses: 167.0,
        seniorDebt: 55.0,
        mezzanineDebt: 12.0,
        sponsorEquity: 90.0,
        managementRollover: 10.0,
        totalSources: 167.0
      },
      projectedFinancials: [
        { year: 1, revenue: 62.6, ebitda: 17.5, fcf: 9.0, debtPaid: 5.5, endingDebt: 61.5, cashBalance: 9.5 },
        { year: 2, revenue: 72.6, ebitda: 21.2, fcf: 12.0, debtPaid: 6.5, endingDebt: 55.0, cashBalance: 15.0 },
        { year: 3, revenue: 84.3, ebitda: 25.5, fcf: 15.5, debtPaid: 7.5, endingDebt: 47.5, cashBalance: 23.0 },
        { year: 4, revenue: 97.8, ebitda: 30.2, fcf: 19.5, debtPaid: 8.5, endingDebt: 39.0, cashBalance: 34.0 },
        { year: 5, revenue: 113.4, ebitda: 35.5, fcf: 24.0, debtPaid: 10.0, endingDebt: 29.0, cashBalance: 48.0 }
      ],
      exitEnterpriseValue: 426.0,
      exitNetDebt: -19.0,
      exitEquityValue: 445.0,
      grossProceeds: 400.5,
      grossIRR: 34.8,
      netIRR: 28.5,
      moic: 4.45,
      cashOnCash: 4.45
    },
    icStatus: 'DRAFT',
    icVoteCount: { approve: 0, reject: 0, conditional: 0 },
    icComments: [],
    dueDiligenceIssues: [
      { id: 'dd-401', category: 'Legal', title: 'FDA 510(k) Supplemental Audit', description: 'Review software algorithm patent freedom-to-operate in North America.', severity: 'MEDIUM', owner: 'Marcus Vance', deadline: '2026-09-30', status: 'Open', financialImpact: 4.0 }
    ],
    dataRoomDocs: [
      { id: 'doc-401', category: 'Technical', name: 'Orthopaedic Clinical Trials Phase III.pdf', uploadDate: '2026-06-20', size: '42.1 MB', status: 'REVIEWED', reviewedBy: 'Dr. Sarah Sterling', flaggedIssuesCount: 0 }
    ]
  },

  // 5. Pipeline Asset - Celtic Energy Transition
  {
    id: 'deal-005',
    fundId: 'fund-evwm-1',
    companyName: 'Celtic Energy Transition & Wind Logistics',
    sector: 'ENERGY',
    country: 'United Kingdom',
    city: 'Belfast & Douglas',
    coordinates: [54.5973, -5.9301],
    stage: 'SCREENING',
    leadPartner: 'Tom Quilliam',
    dealTeam: ['Sir Arthur Kelly'],
    seller: 'Private Infrastructure Fund',
    adviser: 'Jefferies',
    revenue: 42.0,
    ebitda: 12.0,
    ebitdaMargin: 28.5,
    askingPrice: 85.0,
    proposedValuationEV: 80.0,
    dealSizeEquity: 45.0,
    targetIRR: 23.0,
    targetMOIC: 2.5,
    createdDate: '2026-06-01',
    expectedCloseQuarter: 'Q1 2027',
    screeningScorecard: {
      growth: 86,
      profitability: 84,
      cashFlow: 82,
      competitiveAdvantage: 90,
      management: 80,
      valuation: 85,
      marketSize: 88,
      barriersToEntry: 91,
      recurringRevenue: 92,
      capitalIntensity: 70,
      leverageSuitability: 85,
      exitPotential: 88,
      overallScore: 85,
      notes: 'Offshore wind farm heavy service vessels and turbine maintenance base in Irish Sea.'
    },
    financialDD: {
      revenueGrowth3YrCAGR: 15.0,
      grossMargin: 45.0,
      ebitdaMargin: 28.5,
      fcfConversion: 75.0,
      leverage: 2.5,
      interestCoverage: 4.5,
      workingCapitalAsPctRevenue: 10.0,
      historicalYears: [
        { year: 2024, revenue: 32.0, cogs: 18.0, grossProfit: 14.0, ebitda: 8.5, ebit: 6.5, interestExpense: 1.5, tax: 1.0, netIncome: 4.0, capex: 2.5, changeInWorkingCapital: 0.5, fcf: 4.5, totalDebt: 25.0, cash: 4.0, netDebt: 21.0 },
        { year: 2025, revenue: 42.0, cogs: 23.5, grossProfit: 18.5, ebitda: 12.0, ebit: 9.5, interestExpense: 1.8, tax: 1.5, netIncome: 6.2, capex: 3.0, changeInWorkingCapital: 0.8, fcf: 6.7, totalDebt: 24.0, cash: 6.0, netDebt: 18.0 }
      ],
      redFlags: []
    },
    commercialDD: {
      tam: 2500,
      sam: 650,
      marketGrowthRate: 18.0,
      marketShare: 12.0,
      pricingPower: 'High',
      top5CustomerConcentration: 38.0,
      customerRetentionRate: 98.0,
      supplierConcentration: 25.0,
      barriersToEntryScore: 91,
      marketAttractivenessScore: 88,
      keyCompetitors: []
    },
    managementDD: {
      ceoExperienceYears: 16,
      csuiteAlignment: 'Strong Equity Alignment',
      trackRecordScore: 86,
      governanceScore: 84,
      successionPlanInPlace: false,
      keyPersonRisk: 'Moderate',
      managementQualityScore: 84,
      leadershipTeam: [
        { role: 'CEO', name: 'Sean O’Connor', tenureYears: 6, equityOwnershipPct: 12.0, assessment: 'Strong offshore marine operations pedigree.' }
      ]
    },
    valuationSuite: {
      dcfValuation: { wacc: 8.8, terminalGrowthRate: 2.5, enterpriseValue: 92.0, equityValue: 74.0, impliedMultiple: 7.6 },
      comparableTradingMultiples: { evEbitdaMultiple: 7.5, evRevenueMultiple: 2.1, peMultiple: 12.0, impliedEV: 90.0 },
      precedentTransactions: { medianMultiple: 8.0, lowMultiple: 6.8, highMultiple: 9.5, impliedEV: 96.0 },
      sotpValuation: { divisions: [{ name: 'Service Operation Vessels', ebitda: 8.5, multiple: 8.0, value: 68.0 }, { name: 'Harbour Maintenance Base', ebitda: 3.5, multiple: 7.0, value: 24.5 }], totalEV: 92.5 },
      summaryCases: { lowCaseEV: 70.0, baseCaseEV: 85.0, highCaseEV: 105.0, recommendedEntryEV: 80.0 }
    },
    lboModel: {
      purchasePrice: 80.0,
      entryEbitda: 12.0,
      entryMultiple: 6.67,
      holdingPeriodYears: 5,
      exitMultiple: 7.5,
      revenueGrowthAnnual: 14.0,
      ebitdaMarginExit: 30.0,
      capexAsPctRevenue: 5.0,
      taxRate: 25.0,
      debtTranches: [
        { type: 'Senior Secured A', amount: 32.0, marginOverEuribor: 3.25, baseRate: 3.5, totalRate: 6.75, amortisationPercentAnnual: 8.0, tenorYears: 6, covenantDebtToEbitda: 3.5, covenantInterestCoverage: 3.2 }
      ],
      sourcesAndUses: {
        purchasePrice: 80.0,
        refinancingDebt: 0,
        transactionFees: 2.5,
        financingFees: 1.0,
        minimumCashBuffer: 3.5,
        totalUses: 87.0,
        seniorDebt: 32.0,
        mezzanineDebt: 5.0,
        sponsorEquity: 45.0,
        managementRollover: 5.0,
        totalSources: 87.0
      },
      projectedFinancials: [
        { year: 1, revenue: 47.9, ebitda: 14.0, fcf: 6.5, debtPaid: 3.5, endingDebt: 33.5, cashBalance: 6.5 },
        { year: 2, revenue: 54.6, ebitda: 16.5, fcf: 8.2, debtPaid: 4.0, endingDebt: 29.5, cashBalance: 10.7 },
        { year: 3, revenue: 62.2, ebitda: 19.2, fcf: 10.0, debtPaid: 4.5, endingDebt: 25.0, cashBalance: 16.2 },
        { year: 4, revenue: 70.9, ebitda: 22.0, fcf: 12.0, debtPaid: 5.0, endingDebt: 20.0, cashBalance: 23.2 },
        { year: 5, revenue: 80.8, ebitda: 25.0, fcf: 14.5, debtPaid: 6.0, endingDebt: 14.0, cashBalance: 31.7 }
      ],
      exitEnterpriseValue: 187.5,
      exitNetDebt: -17.7,
      exitEquityValue: 205.2,
      grossProceeds: 184.7,
      grossIRR: 32.6,
      netIRR: 26.4,
      moic: 4.10,
      cashOnCash: 4.10
    },
    icStatus: 'DRAFT',
    icVoteCount: { approve: 0, reject: 0, conditional: 0 },
    icComments: [],
    dueDiligenceIssues: [],
    dataRoomDocs: []
  },

  // 6. Pipeline Asset - Saxon Enterprise SaaS
  {
    id: 'deal-006',
    fundId: 'fund-evwm-tech',
    companyName: 'Saxon Compliance & RegTech Cloud',
    sector: 'TECHNOLOGY',
    country: 'United Kingdom',
    city: 'London & Douglas',
    coordinates: [51.5074, -0.1278],
    stage: 'PORTFOLIO',
    isPortfolioCompany: true,
    acquisitionDate: '2024-03-01',
    entryValuationEV: 95.0,
    entryEquity: 58.0,
    currentValuationEV: 145.0,
    currentNetDebt: 18.0,
    currentEquityValue: 127.0,
    headcount: 240,
    leadPartner: 'Sarah Sterling',
    dealTeam: ['Tom Quilliam'],
    seller: 'Founder & Angel Syndicate',
    adviser: 'Arma Partners',
    revenue: 34.0,
    ebitda: 11.2,
    ebitdaMargin: 32.9,
    askingPrice: 95.0,
    proposedValuationEV: 95.0,
    dealSizeEquity: 58.0,
    targetIRR: 30.0,
    targetMOIC: 3.2,
    createdDate: '2023-11-01',
    expectedCloseQuarter: 'Q1 2024',
    screeningScorecard: {
      growth: 96,
      profitability: 88,
      cashFlow: 92,
      competitiveAdvantage: 95,
      management: 90,
      valuation: 78,
      marketSize: 92,
      barriersToEntry: 94,
      recurringRevenue: 98,
      capitalIntensity: 90,
      leverageSuitability: 75,
      exitPotential: 96,
      overallScore: 91,
      notes: 'Mission-critical AML/KYC automated regulatory screening platform for offshore wealth managers and tier-2 banks.'
    },
    financialDD: {
      revenueGrowth3YrCAGR: 28.5,
      grossMargin: 82.0,
      ebitdaMargin: 32.9,
      fcfConversion: 88.0,
      leverage: 1.6,
      interestCoverage: 9.5,
      workingCapitalAsPctRevenue: -12.0, // negative WC because of upfront annual SaaS billing!
      historicalYears: [
        { year: 2023, revenue: 20.5, cogs: 4.1, grossProfit: 16.4, ebitda: 5.5, ebit: 4.8, interestExpense: 0.8, tax: 0.8, netIncome: 3.2, capex: 1.2, changeInWorkingCapital: -0.8, fcf: 4.3, totalDebt: 25.0, cash: 5.0, netDebt: 20.0 },
        { year: 2024, revenue: 26.8, cogs: 5.2, grossProfit: 21.6, ebitda: 8.0, ebit: 7.2, interestExpense: 0.9, tax: 1.2, netIncome: 5.1, capex: 1.5, changeInWorkingCapital: -1.2, fcf: 6.6, totalDebt: 22.0, cash: 8.0, netDebt: 14.0 },
        { year: 2025, revenue: 34.0, cogs: 6.1, grossProfit: 27.9, ebitda: 11.2, ebit: 10.2, interestExpense: 1.0, tax: 1.8, netIncome: 7.4, capex: 1.8, changeInWorkingCapital: -1.5, fcf: 9.3, totalDebt: 18.0, cash: 12.0, netDebt: 6.0 }
      ],
      redFlags: []
    },
    commercialDD: {
      tam: 4800,
      sam: 950,
      marketGrowthRate: 22.0,
      marketShare: 9.5,
      pricingPower: 'High',
      top5CustomerConcentration: 14.0,
      customerRetentionRate: 118.0, // net revenue retention
      supplierConcentration: 10.0,
      barriersToEntryScore: 94,
      marketAttractivenessScore: 96,
      keyCompetitors: []
    },
    managementDD: {
      ceoExperienceYears: 15,
      csuiteAlignment: 'Strong Equity Alignment',
      trackRecordScore: 92,
      governanceScore: 88,
      successionPlanInPlace: true,
      keyPersonRisk: 'Low',
      managementQualityScore: 90,
      leadershipTeam: [
        { role: 'CEO', name: 'Oliver Saxon', tenureYears: 6, equityOwnershipPct: 14.0, assessment: 'Ex-Palantir engineering lead.' }
      ]
    },
    valuationSuite: {
      dcfValuation: { wacc: 10.2, terminalGrowthRate: 3.5, enterpriseValue: 155.0, equityValue: 149.0, impliedMultiple: 13.8 },
      comparableTradingMultiples: { evEbitdaMultiple: 14.0, evRevenueMultiple: 4.5, peMultiple: 24.0, impliedEV: 153.0 },
      precedentTransactions: { medianMultiple: 15.0, lowMultiple: 11.5, highMultiple: 18.0, impliedEV: 168.0 },
      sotpValuation: { divisions: [{ name: 'Enterprise SaaS Core', ebitda: 9.0, multiple: 15.0, value: 135.0 }, { name: 'Managed Regulatory Analytics', ebitda: 2.2, multiple: 10.0, value: 22.0 }], totalEV: 157.0 },
      summaryCases: { lowCaseEV: 120.0, baseCaseEV: 145.0, highCaseEV: 180.0, recommendedEntryEV: 95.0 }
    },
    lboModel: {
      purchasePrice: 95.0,
      entryEbitda: 8.0,
      entryMultiple: 11.88,
      holdingPeriodYears: 5,
      exitMultiple: 14.0,
      revenueGrowthAnnual: 24.0,
      ebitdaMarginExit: 36.0,
      capexAsPctRevenue: 4.0,
      taxRate: 20.0,
      debtTranches: [
        { type: 'Unitranche', amount: 30.0, marginOverEuribor: 4.5, baseRate: 3.5, totalRate: 8.0, amortisationPercentAnnual: 2.5, tenorYears: 6, covenantDebtToEbitda: 3.5, covenantInterestCoverage: 3.5 }
      ],
      sourcesAndUses: {
        purchasePrice: 95.0,
        refinancingDebt: 0,
        transactionFees: 3.0,
        financingFees: 1.5,
        minimumCashBuffer: 5.0,
        totalUses: 104.5,
        seniorDebt: 30.0,
        mezzanineDebt: 0,
        sponsorEquity: 58.0,
        managementRollover: 16.5,
        totalSources: 104.5
      },
      projectedFinancials: [
        { year: 1, revenue: 33.2, ebitda: 11.0, fcf: 7.5, debtPaid: 3.0, endingDebt: 27.0, cashBalance: 9.5 },
        { year: 2, revenue: 41.2, ebitda: 14.2, fcf: 10.2, debtPaid: 3.5, endingDebt: 23.5, cashBalance: 16.2 },
        { year: 3, revenue: 51.1, ebitda: 18.0, fcf: 13.5, debtPaid: 4.0, endingDebt: 19.5, cashBalance: 25.7 },
        { year: 4, revenue: 63.4, ebitda: 22.8, fcf: 17.5, debtPaid: 4.5, endingDebt: 15.0, cashBalance: 38.7 },
        { year: 5, revenue: 78.6, ebitda: 28.5, fcf: 22.5, debtPaid: 5.0, endingDebt: 10.0, cashBalance: 56.2 }
      ],
      exitEnterpriseValue: 399.0,
      exitNetDebt: -46.2,
      exitEquityValue: 445.2,
      grossProceeds: 346.5,
      grossIRR: 43.0,
      netIRR: 35.2,
      moic: 5.97,
      cashOnCash: 5.97
    },
    icStatus: 'IC APPROVED',
    icVoteCount: { approve: 5, reject: 0, conditional: 0 },
    icComments: [],
    dueDiligenceIssues: [],
    dataRoomDocs: [],
    operatingKPIs: {
      revenuePerCustomer: 48.0,
      cac: 8.5,
      ltvToCac: 18.4,
      grossMargin: 82.0,
      ebitdaMargin: 32.9,
      productionCapacityUtilisation: 95.0,
      inventoryTurnoverRatio: 99.0,
      workingCapitalDays: -42,
      revenuePerFTE: 141.6,
      netPromoterScore: 88
    },
    valueCreationInitiatives: [
      { id: 'vc-601', title: 'Generative AI Audit Copilot Module', category: 'Automation & AI', description: 'Real-time sanction and politically exposed person (PEP) automated risk graph reasoning.', ebitdaImpactAnnual: 3.5, oneTimeCost: 1.2, executionTimelineMonths: 9, status: 'Fully Realised', realisedEbitdaToDate: 3.5, owner: 'Oliver Saxon' },
      { id: 'vc-602', title: 'Tier-1 Swiss Private Bank Distribution Channel', category: 'International Expansion', description: 'Signed strategic distribution with 4 Geneva and Zurich private banks.', ebitdaImpactAnnual: 4.2, oneTimeCost: 0.8, executionTimelineMonths: 12, status: 'In Execution', realisedEbitdaToDate: 2.0, owner: 'Sarah Sterling' }
    ],
    esgGovernance: {
      boardIndependencePct: 75.0,
      femaleBoardRepresentationPct: 50.0,
      ghgScope1And2Tonnes: 85,
      renewableEnergyUsagePct: 100.0,
      lostTimeInjuryFrequency: 0.0,
      whistleblowerComplaintsResolved: 0,
      antiCorruptionAuditPassed: true,
      materialIncidentsCount: 0,
      documentedAuditLog: 'SOC2 Type II, ISO 27001, Cyber Essentials Plus certified.',
      institutionalESGGrade: 'AAA'
    }
  }
];
