export type UserRole = 
  | 'FUND MANAGER'
  | 'INVESTMENT PROFESSIONAL'
  | 'ANALYST'
  | 'PORTFOLIO MANAGER'
  | 'OPERATING PARTNER'
  | 'RISK OFFICER'
  | 'FINANCE'
  | 'INVESTMENT COMMITTEE'
  | 'ADMINISTRATOR';

export type DealStage = 
  | 'LEAD'
  | 'SCREENING'
  | 'INITIAL REVIEW'
  | 'NDA'
  | 'DUE DILIGENCE'
  | 'INVESTMENT COMMITTEE'
  | 'TERM SHEET'
  | 'NEGOTIATION'
  | 'SIGNED'
  | 'CLOSED'
  | 'PORTFOLIO'
  | 'EXIT';

export type Sector = 
  | 'INFRASTRUCTURE'
  | 'ENERGY'
  | 'INDUSTRIALS'
  | 'TECHNOLOGY'
  | 'HEALTHCARE'
  | 'FOOD'
  | 'AGRICULTURE'
  | 'REAL ESTATE'
  | 'TRANSPORT'
  | 'LOGISTICS'
  | 'FINANCIAL SERVICES'
  | 'CONSUMER';

export type ICStatus = 'DRAFT' | 'UNDER REVIEW' | 'IC APPROVED' | 'IC REJECTED' | 'CONDITIONAL APPROVAL';

export type ICVote = 'APPROVE' | 'REJECT' | 'CONDITIONAL' | 'PENDING';

export interface InvestmentCommitteeMember {
  id: string;
  name: string;
  role: string;
  vote: ICVote;
  conditions?: string[];
  comments?: string;
}

export type DocumentStatus = 'REQUESTED' | 'RECEIVED' | 'REVIEWED' | 'ISSUE IDENTIFIED' | 'CLEARED';

export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export interface Fund {
  id: string;
  name: string;
  vintage: number;
  vintageYear?: number;
  fundSize: number; // in millions
  size?: number;
  committedCapital: number;
  investedCapital: number;
  calledCapital?: number;
  uncalledCapital: number;
  realisedProceeds: number;
  unrealisedValue: number;
  cash: number;
  fundDebt: number;
  nav?: number;
  investmentPeriodYears: number;
  fundLifeYears: number;
  managementFeePercent: number;
  carriedInterestPercent: number;
  preferredReturnPercent: number; // hurdle rate
  gpCommitmentPercent: number;
  reinvestmentAllowed: boolean;
  currency: string;
  sectors: Sector[];
  geographies: string[];
  targetGrossIRR: number;
  targetNetIRR: number;
  grossIRR?: number;
  netIRR?: number;
  targetMOIC: number;
  maxLeverageMultiple: number;
  maxSingleDealExposurePercent: number;
  investmentLimits?: {
    maxSingleDealPercent: number;
    maxSectorConcentrationPercent: number;
    maxGeographyConcentrationPercent: number;
  };
}

export interface LPCommitment {
  id: string;
  fundId: string;
  lpName: string;
  name?: string;
  lpType: 'Sovereign Wealth Fund' | 'Pension Fund' | 'Endowment' | 'Family Office' | 'Insurance' | 'GP Commitment';
  type?: string;
  domicile: string;
  jurisdiction?: string;
  totalCommitment: number; // in millions
  commitmentAmount?: number;
  calledCapital: number;
  uncalledCapital: number;
  distributionsReceived: number;
  lastCallDate: string;
}

export type LimitedPartner = LPCommitment;

export interface CapitalCallNotice {
  id: string;
  callNumber: number;
  fundId: string;
  issueDate: string;
  dueDate: string;
  totalAmount: number;
  purpose: string;
  status: 'ISSUED' | 'SETTLED' | 'PENDING' | 'Draft';
  lpBreakdown: {
    lpId: string;
    lpName: string;
    amount: number;
    paidStatus: 'PAID' | 'PENDING' | 'OVERDUE';
  }[];
}

export interface ESGScorecard {
  overallScore: number;
  sfdrClassification: 'ARTICLE_8' | 'ARTICLE_9' | 'ARTICLE_6';
  carbonIntensityTonsPerMillion: number;
  boardDiversityPercent: number;
  netZeroTargetYear: number;
  categories: {
    name: string;
    score: number;
    weight: number;
    status: 'ADVANCED' | 'COMPLIANT' | 'NEEDS_IMPROVEMENT';
  }[];
}

export type NavigationTab =
  | 'DASHBOARD'
  | 'FUND_STRUCTURE'
  | 'CAPITAL_CALLS'
  | 'DEAL_PIPELINE'
  | 'DEAL_SCREENING'
  | 'GEOGRAPHIC_MAP'
  | 'DEAL_COMPARISON'
  | 'DUE_DILIGENCE_SUITE'
  | 'VALUATION_SUITE'
  | 'LBO_ENGINE'
  | 'SOURCES_AND_USES'
  | 'EXIT_SENSITIVITY'
  | 'INVESTMENT_COMMITTEE'
  | 'DIGITAL_TWIN'
  | 'VALUE_CREATION'
  | 'OPERATING_KPIS'
  | 'ADDON_ACQUISITIONS'
  | 'REFINANCING'
  | 'FUND_RETURNS_JCURVE'
  | 'MACRO_SCENARIOS'
  | 'MONTE_CARLO'
  | 'PORTFOLIO_OPTIMIZER'
  | 'INVESTOR_REPORTING'
  | 'ESG_COMPLIANCE'
  | 'AUDIT_LOG'
  | 'FUND_DASHBOARD'
  | 'ESG_GOVERNANCE'
  | 'SCREENING_ENGINE'
  | 'GEO_INVESTMENT_MAP'
  | 'LBO_DEBT_ENGINE'
  | 'SOURCES_USES'
  | 'PORTFOLIO_DIGITAL_TWINS'
  | 'ADD_ON_ACQUISITIONS'
  | 'REFINANCING_ENGINE'
  | 'MACRO_STRESS_TESTING'
  | 'AUDIT_TRAIL';

export interface CapitalCall {
  id: string;
  fundId: string;
  callNumber: number;
  callDate: string;
  dueDate: string;
  purpose: string;
  investmentAmount: number; // in millions
  feeAmount: number;
  expenseAmount: number;
  totalCallAmount: number;
  status: 'Draft' | 'Issued' | 'Settled' | 'Pending Bank Confirmation';
  lpsParticipating: number;
}

export interface ScreeningScorecard {
  growth: number; // 0-100
  profitability: number;
  cashFlow: number;
  competitiveAdvantage: number;
  management: number;
  valuation: number;
  marketSize: number;
  barriersToEntry: number;
  recurringRevenue: number;
  capitalIntensity: number; // higher score = lower intensity/better
  leverageSuitability: number;
  exitPotential: number;
  overallScore: number; // 0-100
  notes: string;
}

export interface FinancialStatementYear {
  year: number;
  revenue: number; // in millions
  cogs: number;
  grossProfit: number;
  ebitda: number;
  ebit: number;
  interestExpense: number;
  tax: number;
  netIncome: number;
  capex: number;
  changeInWorkingCapital: number;
  fcf: number;
  totalDebt: number;
  cash: number;
  netDebt: number;
}

export interface FinancialDD {
  revenueGrowth3YrCAGR: number;
  grossMargin: number;
  ebitdaMargin: number;
  fcfConversion: number; // FCF / EBITDA
  leverage: number; // Net Debt / EBITDA
  interestCoverage: number; // EBIT / Interest
  workingCapitalAsPctRevenue: number;
  historicalYears: FinancialStatementYear[];
  redFlags: {
    title: string;
    description: string;
    severity: Severity;
    quantifiedImpact: number; // in millions
  }[];
}

export interface CommercialDD {
  tam: number; // in millions
  sam: number;
  marketGrowthRate: number; // %
  marketShare: number; // %
  pricingPower: 'High' | 'Medium' | 'Low';
  top5CustomerConcentration: number; // %
  customerRetentionRate: number; // %
  supplierConcentration: number; // %
  barriersToEntryScore: number; // 0-100
  marketAttractivenessScore: number; // 0-100
  keyCompetitors: {
    name: string;
    marketShare: number;
    differentiation: string;
  }[];
}

export interface ManagementDD {
  ceoExperienceYears: number;
  csuiteAlignment: 'Strong Equity Alignment' | 'Moderate' | 'Misaligned';
  trackRecordScore: number; // 0-100
  governanceScore: number; // 0-100
  successionPlanInPlace: boolean;
  keyPersonRisk: 'High' | 'Moderate' | 'Low';
  managementQualityScore: number; // 0-100
  leadershipTeam: {
    role: string;
    name: string;
    tenureYears: number;
    equityOwnershipPct: number;
    assessment: string;
  }[];
}

export interface DebtTranche {
  name?: string;
  type?: 'Senior Secured A' | 'Senior Secured B' | 'Unitranche' | 'Mezzanine' | 'Shareholder Loan' | 'Preferred Equity' | string;
  amount: number; // in millions
  marginOverEuribor?: number; // in %
  baseRate?: number; // Euribor/SOFR in %
  totalRate?: number;
  interestRate?: number;
  amortisationPercentAnnual?: number;
  annualAmortizationPercent?: number;
  tenorYears: number;
  seniority?: number;
  covenantDebtToEbitda?: number;
  covenantInterestCoverage?: number;
}

export interface SourcesAndUses {
  purchasePrice: number;
  refinancingDebt: number;
  transactionFees: number;
  financingFees: number;
  minimumCashBuffer: number;
  totalUses: number;
  seniorDebt: number;
  mezzanineDebt: number;
  sponsorEquity: number;
  managementRollover: number;
  totalSources: number;
}

export interface LBOModel {
  entryEV?: number;
  purchasePrice?: number;
  entryEbitda: number;
  entryMultiple?: number;
  holdingPeriodYears: number;
  exitMultiple: number;
  revenueGrowthAnnual?: number; // %
  revenueGrowthRate?: number;
  ebitdaMarginExit?: number; // %
  ebitdaMargin?: number;
  capexAsPctRevenue?: number; // %
  capexPercentRevenue?: number;
  taxRate?: number; // %
  debtTranches: DebtTranche[];
  sourcesAndUses?: SourcesAndUses;
  sponsorEquity?: number;
  managementRolloverEquity?: number;
  advisoryFees?: number;
  financingFees?: number;
  cashSweepPercent?: number;
  projectedFinancials?: {
    year: number;
    revenue: number;
    ebitda: number;
    fcf: number;
    debtPaid: number;
    endingDebt: number;
    cashBalance: number;
  }[];
  exitEnterpriseValue?: number;
  exitNetDebt?: number;
  exitEquityValue?: number;
  grossProceeds?: number;
  grossIRR?: number;
  netIRR?: number;
  moic?: number;
  cashOnCash?: number;
}

export interface ValuationSuite {
  dcfValuation: {
    wacc: number;
    terminalGrowthRate: number;
    enterpriseValue: number;
    equityValue: number;
    impliedMultiple: number;
  };
  comparableTradingMultiples: {
    evEbitdaMultiple: number;
    evRevenueMultiple: number;
    peMultiple: number;
    impliedEV: number;
  };
  precedentTransactions: {
    medianMultiple: number;
    lowMultiple: number;
    highMultiple: number;
    impliedEV: number;
  };
  sotpValuation: {
    divisions: { name: string; ebitda: number; multiple: number; value: number }[];
    totalEV: number;
  };
  summaryCases: {
    lowCaseEV: number;
    baseCaseEV: number;
    highCaseEV: number;
    recommendedEntryEV: number;
  };
}

export type ValuationModel = ValuationSuite | any;

export interface ValueCreationInitiative {
  id: string;
  title: string;
  category: 'Pricing' | 'Cost Reduction' | 'Procurement' | 'Automation & AI' | 'New Products' | 'International Expansion' | 'Add-on M&A' | 'Working Capital' | 'Capex Optimisation' | 'Technology';
  description: string;
  ebitdaImpactAnnual: number; // in millions
  oneTimeCost: number; // in millions
  executionTimelineMonths: number;
  status: 'Identified' | 'In Execution' | 'Partially Realised' | 'Fully Realised';
  realisedEbitdaToDate: number;
  owner: string;
}

export interface OperatingKPIs {
  revenuePerCustomer: number; // €k
  cac: number; // €k
  ltvToCac: number;
  grossMargin: number;
  ebitdaMargin: number;
  productionCapacityUtilisation: number; // %
  inventoryTurnoverRatio: number;
  workingCapitalDays: number;
  revenuePerFTE: number; // €k
  netPromoterScore: number;
}

export interface ESGGovernance {
  boardIndependencePct: number;
  femaleBoardRepresentationPct: number;
  ghgScope1And2Tonnes: number;
  renewableEnergyUsagePct: number;
  lostTimeInjuryFrequency: number;
  whistleblowerComplaintsResolved: number;
  antiCorruptionAuditPassed: boolean;
  materialIncidentsCount: number;
  documentedAuditLog: string;
  institutionalESGGrade: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB';
}

export interface DueDiligenceIssue {
  id: string;
  category: 'Financial' | 'Legal' | 'Commercial' | 'Tax' | 'Technical' | 'ESG' | 'Management' | 'Operational' | string;
  title: string;
  description?: string;
  severity: Severity | string;
  owner?: string;
  assignedTo?: string;
  deadline?: string;
  status: 'Open' | 'Mitigation in Progress' | 'Resolved / Cleared' | 'Risk Accepted by IC' | 'OPEN' | 'RESOLVED' | 'MITIGATING' | string;
  financialImpact?: number; // in millions
  impact?: string | number;
  mitigant?: string;
  [key: string]: any;
}

export interface DataRoomDocument {
  id: string;
  category: 'Financials' | 'Legal' | 'Commercial' | 'Tax' | 'Operational' | 'Management' | 'Technical' | 'ESG' | 'Valuation' | string;
  name: string;
  uploadDate: string;
  size: string;
  status: DocumentStatus | string;
  reviewedBy: string;
  flaggedIssuesCount: number;
}

export type VirtualDataRoomDoc = DataRoomDocument;

export interface AddOnAcquisition {
  id: string;
  targetName: string;
  sector: Sector | string;
  country: string;
  askingPrice: number; // in millions
  targetRevenue: number;
  targetEbitda: number;
  costSynergies: number;
  revenueSynergies: number;
  integrationCosts: number;
  incrementalDebtNeeded: number;
  incrementalEquityNeeded: number;
  proFormaCombinedEbitda: number;
  proFormaLeverage: number;
  accretionEbitdaPct: number;
  status: 'Evaluating' | 'Due Diligence' | 'Negotiating' | 'Completed' | string;
}

export type AddOnTarget = AddOnAcquisition | any;
export type DigitalTwinState = any;
export type ValueCreationLever = ValueCreationInitiative | any;

export interface Deal {
  id: string;
  fundId?: string;
  companyName: string;
  sector: Sector | string;
  country: string;
  city?: string;
  coordinates?: [number, number]; // lat, lng for map
  stage: DealStage;
  leadPartner: string;
  dealTeam?: string[];
  seller?: string;
  adviser?: string;
  revenue: number; // millions
  ebitda: number;
  ebitdaMargin: number;
  askingPrice?: number;
  proposedValuationEV: number;
  dealSizeEquity: number;
  targetIRR: number;
  targetMOIC: number;
  createdDate?: string;
  sourceDate?: string;
  expectedCloseQuarter?: string;
  screeningScorecard?: ScreeningScorecard;
  scorecard?: any;
  financialDD?: FinancialDD;
  commercialDD?: CommercialDD;
  managementDD?: ManagementDD;
  valuationSuite?: ValuationSuite;
  valuationModel?: any;
  lboModel?: LBOModel;
  icStatus?: ICStatus;
  icVoteCount?: { approve: number; reject: number; conditional: number };
  icComments?: { author: string; role: string; comment: string; date: string }[];
  dueDiligenceIssues?: DueDiligenceIssue[];
  dueDiligenceWorkstreams?: {
    name: string;
    status: string;
    progressPercent: number;
    leadAdvisor: string;
    keyFindings: string;
  }[];
  dataRoomDocs?: DataRoomDocument[];
  // If acquired / portfolio company:
  isPortfolioCompany?: boolean;
  acquisitionDate?: string;
  entryValuationEV?: number;
  entryEquity?: number;
  currentValuationEV?: number;
  currentNetDebt?: number;
  currentEquityValue?: number;
  headcount?: number;
  operatingKPIs?: OperatingKPIs;
  valueCreationInitiatives?: ValueCreationInitiative[];
  addOns?: AddOnAcquisition[];
  esgGovernance?: ESGGovernance;
  esgScorecard?: ESGScorecard;
}

export interface MacroScenario {
  id?: string;
  name: string;
  type?: 'RECESSION' | 'INFLATION SHOCK' | 'RATE SHOCK' | 'ENERGY SHOCK' | 'CURRENCY SHOCK' | 'CREDIT CRISIS' | 'SUPPLY-CHAIN SHOCK' | string;
  description: string;
  revenueImpactPct?: number;
  revenueShockPercent?: number;
  ebitdaMarginDropBps?: number;
  ebitdaMarginShockPercent?: number;
  interestRateIncreaseBps?: number;
  interestRateShockBps?: number;
  multipleCompressionTurns?: number;
  multipleExpansionShock?: number;
  estimatedPortfolioNavDropPct?: number;
}

export interface AuditRecord {
  id: string;
  timestamp: string;
  user: string;
  role: UserRole;
  module: string;
  action: string;
  details: string;
  previousValue?: string;
  newValue?: string;
}

export interface FundPerformanceMetrics {
  nav: number; // in millions
  committedCapital: number;
  investedCapital: number;
  uncalledCapital: number;
  realisedProceeds: number;
  unrealisedValue: number;
  cash: number;
  debt: number;
  grossIRR: number;
  netIRR: number;
  moic: number;
  tvpi: number;
  dpi: number;
  rvpi: number;
  portfolioRiskScore: number; // 0-100 (lower is safer)
}
