import React from 'react';
import { Fund, Deal } from '../types';
import { 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle, 
  PieChart, 
  Layers, 
  TrendingUp, 
  Scale, 
  BellRing,
  Globe,
  Briefcase
} from 'lucide-react';

interface OptimizerProps {
  fund: Fund;
  deals: Deal[];
}

export const PortfolioOptimizerAlerts: React.FC<OptimizerProps> = ({ fund, deals }) => {
  const portfolioDeals = deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO');
  const totalInvested = fund.investedCapital;

  // Concentration calculations
  const sectorWeights: { [key: string]: number } = {};
  const geoWeights: { [key: string]: number } = {};
  const singleAssetWeights: { name: string; weight: number; ev: number }[] = [];

  portfolioDeals.forEach(d => {
    const invested = d.currentEquityValue || d.dealSizeEquity;
    sectorWeights[d.sector] = (sectorWeights[d.sector] || 0) + invested;
    geoWeights[d.country] = (geoWeights[d.country] || 0) + invested;
    singleAssetWeights.push({
      name: d.companyName,
      weight: (invested / (totalInvested || 1)) * 100,
      ev: d.currentValuationEV || d.proposedValuationEV
    });
  });

  // Limits
  const maxSingleAssetLimit = fund.investmentLimits.maxSingleDealPercent; // 15%
  const maxSectorLimit = fund.investmentLimits.maxSectorConcentrationPercent; // 35%
  const maxGeographyLimit = fund.investmentLimits.maxGeographyConcentrationPercent; // 40%

  // Check breaches
  const singleAssetBreaches = singleAssetWeights.filter(a => a.weight > maxSingleAssetLimit);
  const sectorBreaches = Object.entries(sectorWeights).filter(([_, val]) => (val / totalInvested) * 100 > maxSectorLimit);
  const geoBreaches = Object.entries(geoWeights).filter(([_, val]) => (val / totalInvested) * 100 > maxGeographyLimit);

  const hasAnyBreach = singleAssetBreaches.length > 0 || sectorBreaches.length > 0 || geoBreaches.length > 0;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono-num text-[10px] font-bold uppercase">
              LPA Compliance & Risk Control
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Fund: <strong className="text-slate-200">{fund.name}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-amber-400" />
            Portfolio Concentration Optimizer & LPA Covenant Alerts
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated monitoring of LPA statutory exposure thresholds: single-deal limits, sector caps, geographic constraints, and credit covenants.
          </p>
        </div>
      </div>

      {/* Compliance Overview Banner */}
      <div className={`p-4 rounded-2xl border flex items-center justify-between font-mono-num ${
        !hasAnyBreach 
          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' 
          : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
      }`}>
        <div className="flex items-center gap-3">
          {!hasAnyBreach ? <CheckCircle className="w-5 h-5 text-emerald-400" /> : <AlertTriangle className="w-5 h-5 text-rose-400" />}
          <div>
            <span className="font-sans font-bold text-sm">
              {!hasAnyBreach ? '100% LPA Statutory Concentration Compliance' : 'LPA Exposure Limits Approaching/Exceeded'}
            </span>
            <span className="text-xs text-slate-400 block font-sans">
              All portfolio assets conform to institutional Mandate & ILPA Risk Policies.
            </span>
          </div>
        </div>
        <span className="text-xs font-bold px-3 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
          STATUS: COMPLIANT
        </span>
      </div>

      {/* Exposure Limits Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Single Asset Limits */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-1.5">
              <Briefcase className="w-4 h-4 text-amber-400" />
              Single Asset Concentration
            </h3>
            <span className="text-xs font-mono-num text-amber-400 font-bold">Limit: {maxSingleAssetLimit}%</span>
          </div>

          <div className="space-y-3 font-mono-num">
            {singleAssetWeights.map((asset, idx) => {
              const isWarning = asset.weight > maxSingleAssetLimit * 0.85;
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-sans">
                    <span className="text-slate-300 truncate max-w-[170px]">{asset.name}</span>
                    <span className={`font-mono-num font-bold ${isWarning ? 'text-amber-400' : 'text-slate-200'}`}>
                      {asset.weight.toFixed(1)}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full ${isWarning ? 'bg-amber-400' : 'bg-emerald-400'}`}
                      style={{ width: `${Math.min(100, (asset.weight / maxSingleAssetLimit) * 100)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sector Concentration */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-1.5">
              <PieChart className="w-4 h-4 text-sky-400" />
              Sector Concentration
            </h3>
            <span className="text-xs font-mono-num text-sky-400 font-bold">Limit: {maxSectorLimit}%</span>
          </div>

          <div className="space-y-3 font-mono-num">
            {Object.entries(sectorWeights).map(([sector, amount], idx) => {
              const weight = (amount / totalInvested) * 100;
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-sans">
                    <span className="text-slate-300 truncate max-w-[170px]">{sector}</span>
                    <span className="font-mono-num font-bold text-slate-200">{weight.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className="h-full rounded-full bg-sky-400"
                      style={{ width: `${Math.min(100, (weight / maxSectorLimit) * 100)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Geographic Concentration */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-emerald-400" />
              Geographic Concentration
            </h3>
            <span className="text-xs font-mono-num text-emerald-400 font-bold">Limit: {maxGeographyLimit}%</span>
          </div>

          <div className="space-y-3 font-mono-num">
            {Object.entries(geoWeights).map(([geo, amount], idx) => {
              const weight = (amount / totalInvested) * 100;
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-sans">
                    <span className="text-slate-300 truncate max-w-[170px]">{geo}</span>
                    <span className="font-mono-num font-bold text-slate-200">{weight.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className="h-full rounded-full bg-emerald-400"
                      style={{ width: `${Math.min(100, (weight / maxGeographyLimit) * 100)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
};
