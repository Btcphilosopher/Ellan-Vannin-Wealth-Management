import React, { useState } from 'react';
import { Deal, ValueCreationLever } from '../types';
import { 
  TrendingUp, 
  Layers, 
  DollarSign, 
  ArrowUpRight, 
  CheckCircle, 
  Sparkles, 
  Building2,
  Sliders
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Cell 
} from 'recharts';

interface ValueCreationProps {
  deals: Deal[];
  selectedDeal: Deal;
  onSelectDeal: (dealId: string) => void;
  onUpdateDeal: (updated: Deal) => void;
}

const DEFAULT_LEVERS: ValueCreationLever[] = [
  { name: '1. Strategic Pricing Optimization', category: 'PRICING', ebitdaImpact: 2.8, status: 'IN_PROGRESS', description: 'CPI-indexed price restructuring and SKU tiering.' },
  { name: '2. International Market Expansion', category: 'EXPANSION', ebitdaImpact: 3.5, status: 'IN_PROGRESS', description: 'Entry into DACH and Benelux distribution channels.' },
  { name: '3. Cross-Selling & Account Expansion', category: 'COMMERCIAL', ebitdaImpact: 1.8, status: 'IN_PROGRESS', description: 'Bundling telemetry software with industrial hardware.' },
  { name: '4. Digital Transformation & Automation', category: 'DIGITAL', ebitdaImpact: 2.2, status: 'PLANNED', description: 'Automated warehouse sorting & predictive maintenance.' },
  { name: '5. Strategic Buy-and-Build M&A', category: 'M&A', ebitdaImpact: 5.5, status: 'IN_PROGRESS', description: 'Consolidation of 2 regional competitors.' },
  { name: '6. Group Procurement Synergies', category: 'PROCUREMENT', ebitdaImpact: 1.6, status: 'COMPLETED', description: 'Centralized sourcing across EVWM portfolio.' },
  { name: '7. Lean Cost Reduction & OPEX', category: 'EFFICIENCY', ebitdaImpact: 1.4, status: 'COMPLETED', description: 'Rationalization of redundant facility leases.' },
  { name: '8. Working Capital Optimization', category: 'WORKING_CAPITAL', ebitdaImpact: 1.2, status: 'IN_PROGRESS', description: 'Reduction of DSO from 58 days to 42 days.' },
  { name: '9. ESG Decarbonization & Green Premium', category: 'ESG', ebitdaImpact: 1.5, status: 'PLANNED', description: 'ISO 14001 certification and green product line.' },
  { name: '10. C-Suite & Sales Strengthening', category: 'TALENT', ebitdaImpact: 2.0, status: 'COMPLETED', description: 'Appointed Tier-1 Global Head of Sales.' }
];

export const ValueCreationEngine: React.FC<ValueCreationProps> = ({
  deals,
  selectedDeal,
  onSelectDeal,
  onUpdateDeal
}) => {
  const portfolioDeals = deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO');
  const activeCompany = selectedDeal.isPortfolioCompany ? selectedDeal : portfolioDeals[0] || selectedDeal;

  const [levers, setLevers] = useState<ValueCreationLever[]>(
    activeCompany.valueCreationPlan?.levers || DEFAULT_LEVERS
  );

  const baseEbitda = activeCompany.ebitda;
  const exitMultiple = 10.5;

  const totalEbitdaUplift = levers.reduce((sum, l) => sum + (l.ebitdaImpact || 0), 0);
  const targetEbitda = baseEbitda + totalEbitdaUplift;
  const totalEVImpact = totalEbitdaUplift * exitMultiple;

  // Waterfall Chart Data
  const waterfallData = [
    { name: 'Entry EBITDA', value: baseEbitda, isTotal: false },
    ...levers.slice(0, 6).map(l => ({ name: l.name.split('.')[1] || l.name, value: l.ebitdaImpact, isTotal: false })),
    { name: 'Target EBITDA', value: targetEbitda, isTotal: true }
  ];

  const handleLeverImpactChange = (idx: number, newVal: number) => {
    const updated = [...levers];
    updated[idx] = { ...updated[idx], ebitdaImpact: newVal };
    setLevers(updated);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono-num text-[10px] font-bold uppercase">
              100-Day & Long-Term Plan
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Asset: <strong className="text-slate-200">{activeCompany.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-amber-400" />
            10-Pillar Value Creation & EBITDA Bridge Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Operational transformation levers: pricing power, organic growth, procurement synergies, M&A, and EBITDA expansion.
          </p>
        </div>

        {/* Portfolio Deal Switcher */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Target:</label>
          <select
            value={activeCompany.id}
            onChange={(e) => {
              const d = deals.find(x => x.id === e.target.value);
              if (d) {
                onSelectDeal(d.id);
                setLevers(d.valueCreationPlan?.levers || DEFAULT_LEVERS);
              }
            }}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {portfolioDeals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Summary KPI Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono-num">
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-xs font-sans block">Entry EBITDA</span>
          <span className="text-2xl font-bold text-slate-100 mt-1 block">€{baseEbitda.toFixed(1)}M</span>
          <span className="text-[11px] text-slate-400 font-sans">Baseline at Acquisition</span>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-xs font-sans block">Total EBITDA Uplift Target</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">+€{totalEbitdaUplift.toFixed(1)}M</span>
          <span className="text-[11px] text-emerald-400/80 font-sans">+{((totalEbitdaUplift / baseEbitda) * 100).toFixed(0)}% Growth</span>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-xs font-sans block">Transformed Target EBITDA</span>
          <span className="text-2xl font-bold text-amber-300 mt-1 block">€{targetEbitda.toFixed(1)}M</span>
          <span className="text-[11px] text-slate-400 font-sans">At Year 5 Exit</span>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-xs font-sans block">Enterprise Value Expansion</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">+€{totalEVImpact.toFixed(1)}M</span>
          <span className="text-[10px] text-sky-400 font-sans">At {exitMultiple}x Exit Multiple</span>
        </div>
      </div>

      {/* Levers List & EBITDA Waterfall */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: 10 Value Creation Levers List */}
        <div className="lg:col-span-2 space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl">
          <h3 className="font-display font-bold text-base text-slate-100">
            Active 10-Point Operational Levers
          </h3>

          <div className="space-y-3 max-h-[560px] overflow-y-auto pr-1">
            {levers.map((lever, idx) => (
              <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-slate-100">{lever.name}</span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-900 text-amber-400 border border-slate-800">
                      {lever.category}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 font-mono-num">
                    <span className="text-xs text-emerald-400 font-bold">
                      +€{lever.ebitdaImpact.toFixed(1)}M EBITDA
                    </span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400">{lever.description}</p>

                <div className="flex items-center gap-3 pt-1">
                  <input
                    type="range"
                    min="0.0"
                    max="8.0"
                    step="0.1"
                    value={lever.ebitdaImpact}
                    onChange={(e) => handleLeverImpactChange(idx, Number(e.target.value))}
                    className="w-full accent-emerald-500 bg-slate-900 h-1.5 rounded cursor-pointer"
                  />
                  <span className="text-xs font-mono-num text-slate-300 w-12 text-right">
                    €{lever.ebitdaImpact.toFixed(1)}M
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: EBITDA Expansion Waterfall */}
        <div className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-display font-bold text-base text-slate-100">
              EBITDA Bridge Waterfall
            </h3>
            <p className="text-xs text-slate-400">Cumulative impact from Entry to Exit (€M)</p>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={waterfallData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} angle={-25} textAnchor="end" height={50} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '8px', fontSize: '11px' }}
                  formatter={(val: any) => [`€${val}M`, '']}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {waterfallData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.isTotal ? '#f59e0b' : '#10b981'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400">
            <strong>Value Creation Thesis:</strong> 65% of investment return driven by EBITDA expansion rather than multiple expansion.
          </div>
        </div>

      </div>
    </div>
  );
};
