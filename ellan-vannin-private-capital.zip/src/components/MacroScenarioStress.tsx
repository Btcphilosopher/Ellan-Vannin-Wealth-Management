import React, { useState } from 'react';
import { Deal, MacroScenario, Fund } from '../types';
import { runStressTestScenario } from '../services/financialEngine';
import { 
  AlertOctagon, 
  TrendingDown, 
  ShieldAlert, 
  Layers, 
  DollarSign, 
  Activity, 
  HelpCircle, 
  CheckCircle,
  Zap,
  BarChart3
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend 
} from 'recharts';

interface MacroStressProps {
  deals: Deal[];
  fund: Fund;
}

const PREDEFINED_SCENARIOS: MacroScenario[] = [
  {
    name: '1. Global Stagflation (Inflation + Growth Stagnation)',
    revenueShockPercent: -12.0,
    ebitdaMarginShockPercent: -4.5,
    multipleExpansionShock: -2.5,
    interestRateShockBps: 250,
    description: 'High input costs and sticky CPI with rising central bank discount rates.'
  },
  {
    name: '2. Severe European Recession & Demand Shock',
    revenueShockPercent: -20.0,
    ebitdaMarginShockPercent: -6.0,
    multipleExpansionShock: -3.0,
    interestRateShockBps: 0,
    description: 'Deep consumer and industrial demand contraction across Eurozone.'
  },
  {
    name: '3. Central Bank Rate Spike (+300 bps Rate Shock)',
    revenueShockPercent: -5.0,
    ebitdaMarginShockPercent: -2.0,
    multipleExpansionShock: -2.0,
    interestRateShockBps: 300,
    description: 'Aggressive hawkish monetary tightening straining debt service.'
  },
  {
    name: '4. Critical Supply Chain & Logistics Fracture',
    revenueShockPercent: -15.0,
    ebitdaMarginShockPercent: -5.0,
    multipleExpansionShock: -1.0,
    interestRateShockBps: 100,
    description: 'Geopolitical disruptions blocking marine and component freight.'
  },
  {
    name: '5. Energy & Commodity Price Shock',
    revenueShockPercent: -8.0,
    ebitdaMarginShockPercent: -5.5,
    multipleExpansionShock: -1.5,
    interestRateShockBps: 150,
    description: 'Tripled electricity, natural gas and heavy fuel costs.'
  },
  {
    name: '6. High-Tech & SaaS Multiple Compression',
    revenueShockPercent: -6.0,
    ebitdaMarginShockPercent: -3.0,
    multipleExpansionShock: -4.0,
    interestRateShockBps: 200,
    description: 'Public market tech re-rating pulling private software comps down.'
  },
  {
    name: '7. Stricter Environmental & Regulatory Crackdown',
    revenueShockPercent: -4.0,
    ebitdaMarginShockPercent: -3.5,
    multipleExpansionShock: -1.0,
    interestRateShockBps: 50,
    description: 'Mandatory carbon tax levies and retrofitting capex compliance.'
  }
];

export const MacroScenarioStress: React.FC<MacroStressProps> = ({ deals, fund }) => {
  const [selectedScenario, setSelectedScenario] = useState<MacroScenario>(PREDEFINED_SCENARIOS[0]);

  // Run stress tests across all portfolio companies
  const portfolioDeals = deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO');
  const stressResults = portfolioDeals.map(d => runStressTestScenario(d, selectedScenario));

  const totalBaseEV = stressResults.reduce((s, r) => s + r.baseEV, 0);
  const totalShockedEV = stressResults.reduce((s, r) => s + r.shockedEV, 0);
  const totalBaseEquity = stressResults.reduce((s, r) => s + r.baseEquity, 0);
  const totalShockedEquity = stressResults.reduce((s, r) => s + r.shockedEquity, 0);

  const evLossPercent = ((totalShockedEV - totalBaseEV) / (totalBaseEV || 1)) * 100;
  const equityLossPercent = ((totalShockedEquity - totalBaseEquity) / (totalBaseEquity || 1)) * 100;

  const chartData = stressResults.map(r => ({
    name: r.companyName.split(' ')[0],
    baseEV: Number(r.baseEV.toFixed(1)),
    shockedEV: Number(r.shockedEV.toFixed(1)),
    baseEbitda: Number(r.baseEbitda.toFixed(1)),
    shockedEbitda: Number(r.shockedEbitda.toFixed(1)),
    shockedICR: Number(r.shockedICR.toFixed(2))
  }));

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-mono-num text-[10px] font-bold uppercase">
              Macroprudential Stress Lab
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Active Fund: <strong className="text-slate-200">{fund.name}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <AlertOctagon className="w-6 h-6 text-amber-400" />
            7-Scenario Macroeconomic Stress Testing Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional down-side stress analysis: Stagflation, recessions, interest rate spikes, supply chain fractures, and covenant headroom.
          </p>
        </div>
      </div>

      {/* Scenario Switcher Carousel */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-2.5">
        {PREDEFINED_SCENARIOS.map((sc, idx) => {
          const isSelected = selectedScenario.name === sc.name;
          return (
            <button
              key={idx}
              onClick={() => setSelectedScenario(sc)}
              className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-amber-500/20 border-amber-500/50 text-slate-100 shadow-md'
                  : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <div className="flex items-center gap-1.5 font-bold text-xs">
                <Zap className={`w-3.5 h-3.5 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                <span className="truncate">{sc.name.split('.')[1] || sc.name}</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1 line-clamp-2">{sc.description}</p>
            </button>
          );
        })}
      </div>

      {/* Stress Summary KPI Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono-num">
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Base Portfolio EV</span>
          <span className="text-2xl font-bold text-slate-100 mt-1 block">€{totalBaseEV.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">Pre-Shock Mark</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Shocked Portfolio EV</span>
          <span className="text-2xl font-bold text-rose-400 mt-1 block">€{totalShockedEV.toFixed(1)}M</span>
          <span className="text-[10px] text-rose-400 font-sans">{evLossPercent.toFixed(1)}% EV Drawdown</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Base Fund Equity</span>
          <span className="text-2xl font-bold text-slate-100 mt-1 block">€{totalBaseEquity.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">Pre-Shock NAV</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Shocked Fund Equity</span>
          <span className="text-2xl font-bold text-amber-400 mt-1 block">€{totalShockedEquity.toFixed(1)}M</span>
          <span className="text-[10px] text-amber-400 font-sans">{equityLossPercent.toFixed(1)}% NAV Impact</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Interest Rate Shock</span>
          <span className="text-2xl font-bold text-rose-300 mt-1 block">+{selectedScenario.interestRateShockBps} bps</span>
          <span className="text-[10px] text-slate-400 font-sans">Financing Burden</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Covenant Status</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">Survives</span>
          <span className="text-[10px] text-emerald-400 font-sans">Zero Breaches</span>
        </div>
      </div>

      {/* Enterprise Value Before vs After Stress Bar Chart */}
      <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-display font-bold text-base text-slate-100">
              Enterprise Value Resilience: Base vs. Shocked (€M)
            </h3>
            <p className="text-xs text-slate-400">Simulation of asset value under {selectedScenario.name}</p>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '8px', fontSize: '11px' }}
                formatter={(val: any) => [`€${val}M`, '']}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
              <Bar dataKey="baseEV" name="Base Enterprise Value" fill="#38bdf8" radius={[4, 4, 0, 0]} />
              <Bar dataKey="shockedEV" name="Shocked Enterprise Value" fill="#f43f5e" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Asset-by-Asset Stress Table */}
      <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-3">
        <h3 className="font-display font-bold text-base text-slate-100">
          Portfolio Asset Stress Breakdown
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-num">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3">Company</th>
                <th className="py-2.5 px-2 text-right">Base EBITDA</th>
                <th className="py-2.5 px-2 text-right text-rose-300">Shocked EBITDA</th>
                <th className="py-2.5 px-2 text-right">Base EV</th>
                <th className="py-2.5 px-2 text-right text-rose-300">Shocked EV</th>
                <th className="py-2.5 px-2 text-right">Shocked ICR</th>
                <th className="py-2.5 px-2 text-center">Covenant Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {stressResults.map((r, idx) => (
                <tr key={idx} className="hover:bg-slate-800/30">
                  <td className="py-3 px-3 font-sans font-bold text-slate-200">{r.companyName}</td>
                  <td className="py-3 px-2 text-right text-slate-300">€{r.baseEbitda.toFixed(1)}M</td>
                  <td className="py-3 px-2 text-right text-rose-300 font-bold">€{r.shockedEbitda.toFixed(1)}M</td>
                  <td className="py-3 px-2 text-right text-slate-300">€{r.baseEV.toFixed(1)}M</td>
                  <td className="py-3 px-2 text-right text-rose-300 font-bold">€{r.shockedEV.toFixed(1)}M</td>
                  <td className="py-3 px-2 text-right text-amber-300 font-bold">{r.shockedICR.toFixed(2)}x</td>
                  <td className="py-3 px-2 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-sans font-bold border ${
                      r.covenantBreached 
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/40' 
                        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    }`}>
                      {r.covenantBreached ? 'BREACHED' : 'COMPLIANT'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
