import React, { useState } from 'react';
import { Fund, LimitedPartner, Deal } from '../types';
import { 
  FileText, 
  Download, 
  Printer, 
  Layers, 
  Building2, 
  DollarSign, 
  CheckCircle, 
  ShieldCheck,
  Calendar,
  Coins
} from 'lucide-react';

interface ReportingProps {
  fund: Fund;
  lps: LimitedPartner[];
  deals: Deal[];
}

export const InvestorReportingSuite: React.FC<ReportingProps> = ({ fund, lps, deals }) => {
  const [selectedLP, setSelectedLP] = useState<LimitedPartner>(lps[0]);
  const [reportQuarter, setReportQuarter] = useState('Q4 2024');

  const lpOwnershipShare = selectedLP.commitmentAmount / fund.size;
  const lpCalledCapital = selectedLP.calledCapital;
  const lpDistributions = selectedLP.distributionsReceived;
  const lpNAVShare = fund.nav * lpOwnershipShare;
  const lpUncalled = selectedLP.uncalledCapital;
  const lpTVPI = (lpDistributions + lpNAVShare) / (lpCalledCapital || 1);
  const lpDPI = lpDistributions / (lpCalledCapital || 1);

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono-num text-[10px] font-bold uppercase">
              ILPA Institutional Reporting Standard
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Fund: <strong className="text-slate-200">{fund.name}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <FileText className="w-6 h-6 text-amber-400" />
            ILPA Capital Account Statement & Quarterly Reporting Suite
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional investor reporting: ILPA quarterly capital statements, NAV roll-forward bridges, and individual LP performance summaries.
          </p>
        </div>

        {/* LP & Quarter Switchers */}
        <div className="flex items-center gap-3">
          <select
            value={selectedLP.id}
            onChange={(e) => {
              const lp = lps.find(x => x.id === e.target.value);
              if (lp) setSelectedLP(lp);
            }}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {lps.map(lp => (
              <option key={lp.id} value={lp.id}>{lp.name} (€{lp.commitmentAmount}M)</option>
            ))}
          </select>

          <button
            onClick={() => window.print()}
            className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer no-print"
          >
            <Printer className="w-3.5 h-3.5" /> Export ILPA PDF
          </button>
        </div>
      </div>

      {/* Main Statement Canvas */}
      <div className="bg-slate-900/90 text-slate-100 p-8 rounded-2xl border border-slate-800 shadow-2xl space-y-6 max-w-5xl mx-auto">
        
        {/* Document Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-6 gap-4">
          <div>
            <div className="text-xs font-mono-num uppercase tracking-widest text-amber-400 font-bold">
              ELLAN VANNIN PRIVATE CAPITAL • ILPA CAPITAL STATEMENT
            </div>
            <h2 className="font-display font-bold text-2xl text-slate-100 mt-1">
              LIMITED PARTNER CAPITAL ACCOUNT STATEMENT
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Period Ending: <strong>December 31, 2024 ({reportQuarter})</strong> • Accounting Standard: <strong>IFRS / US GAAP Fair Value (ASC 820)</strong>
            </p>
          </div>

          <div className="text-right font-mono-num text-xs bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <span className="text-slate-500 font-sans block">Investor Name</span>
            <span className="font-bold text-slate-100 text-sm block">{selectedLP.name}</span>
            <span className="text-amber-400 text-[11px] block mt-0.5">{selectedLP.type} • {selectedLP.jurisdiction}</span>
          </div>
        </div>

        {/* Capital Summary KPI Matrix */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono-num text-xs">
          <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500 block font-sans">Total Commitment</span>
            <span className="text-slate-100 font-bold text-base mt-0.5 block">€{selectedLP.commitmentAmount.toFixed(2)}M</span>
            <span className="text-slate-400 text-[10px] font-sans">{(lpOwnershipShare * 100).toFixed(2)}% Fund Share</span>
          </div>

          <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500 block font-sans">Paid-In Capital</span>
            <span className="text-slate-100 font-bold text-base mt-0.5 block">€{lpCalledCapital.toFixed(2)}M</span>
            <span className="text-emerald-400 text-[10px] font-sans">{((lpCalledCapital / selectedLP.commitmentAmount) * 100).toFixed(0)}% Drawn</span>
          </div>

          <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500 block font-sans">Ending NAV Share</span>
            <span className="text-amber-300 font-bold text-base mt-0.5 block">€{lpNAVShare.toFixed(2)}M</span>
            <span className="text-slate-400 text-[10px] font-sans">Unrealized Value</span>
          </div>

          <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-slate-500 block font-sans">Net TVPI / Net IRR</span>
            <span className="text-emerald-400 font-bold text-base mt-0.5 block">{lpTVPI.toFixed(2)}x / {fund.netIRR}%</span>
            <span className="text-emerald-400 text-[10px] font-sans">Top Quartile Returns</span>
          </div>
        </div>

        {/* ILPA Capital Account Roll-Forward Bridge */}
        <div className="space-y-3 font-mono-num text-xs">
          <h3 className="font-sans font-bold text-sm text-amber-300 uppercase tracking-wider border-b border-slate-800 pb-1">
            Capital Account Roll-Forward (Quarterly Bridge)
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-2 text-right">Fund Level (€M)</th>
                  <th className="py-2.5 px-2 text-right font-bold text-amber-300">Your Share (€M)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                <tr>
                  <td className="py-2 px-3 font-sans font-medium">Beginning Net Asset Value (Oct 1, 2024)</td>
                  <td className="py-2 px-2 text-right">€{(fund.nav * 0.94).toFixed(2)}M</td>
                  <td className="py-2 px-2 text-right font-bold">€{(lpNAVShare * 0.94).toFixed(2)}M</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-sans font-medium">Capital Contributions (Calls) Received</td>
                  <td className="py-2 px-2 text-right text-emerald-400">+€15.00M</td>
                  <td className="py-2 px-2 text-right text-emerald-400 font-bold">+€{(15.0 * lpOwnershipShare).toFixed(2)}M</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-sans font-medium">Distributions Paid to LPs</td>
                  <td className="py-2 px-2 text-right text-rose-400">-€8.50M</td>
                  <td className="py-2 px-2 text-right text-rose-400 font-bold">-€{(8.5 * lpOwnershipShare).toFixed(2)}M</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-sans font-medium">Net Realized Gain / (Loss)</td>
                  <td className="py-2 px-2 text-right text-emerald-400">+€4.20M</td>
                  <td className="py-2 px-2 text-right text-emerald-400 font-bold">+€{(4.2 * lpOwnershipShare).toFixed(2)}M</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-sans font-medium">Net Unrealized Value Creation / (Depreciation)</td>
                  <td className="py-2 px-2 text-right text-emerald-400">+€18.80M</td>
                  <td className="py-2 px-2 text-right text-emerald-400 font-bold">+€{(18.8 * lpOwnershipShare).toFixed(2)}M</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-sans font-medium">Management Fees Paid</td>
                  <td className="py-2 px-2 text-right text-slate-400">-€2.50M</td>
                  <td className="py-2 px-2 text-right text-slate-400 font-bold">-€{(2.5 * lpOwnershipShare).toFixed(2)}M</td>
                </tr>
                <tr className="bg-slate-950/80 font-bold text-amber-300">
                  <td className="py-3 px-3 font-sans text-sm">Ending Net Asset Value (Dec 31, 2024)</td>
                  <td className="py-3 px-2 text-right text-sm">€{fund.nav.toFixed(2)}M</td>
                  <td className="py-3 px-2 text-right text-sm">€{lpNAVShare.toFixed(2)}M</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Certification Seal */}
        <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span>Certified by Ellan Vannin Fund Administration & External Audit</span>
          </div>
          <span className="font-mono-num text-[11px]">ILPA Reporting Template v3.0 Compliant</span>
        </div>

      </div>
    </div>
  );
};
