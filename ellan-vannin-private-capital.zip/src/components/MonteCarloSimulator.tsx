import React, { useState } from 'react';
import { Fund } from '../types';
import { runMonteCarloSimulation } from '../services/monteCarloEngine';
import { 
  Dices, 
  Play, 
  RotateCcw, 
  TrendingUp, 
  Percent, 
  Layers, 
  HelpCircle,
  Sliders,
  CheckCircle
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Cell 
} from 'recharts';

interface MonteCarloProps {
  fund: Fund;
}

export const MonteCarloSimulator: React.FC<MonteCarloProps> = ({ fund }) => {
  const [numRuns, setNumRuns] = useState<number>(1000);
  const [meanGrowth, setMeanGrowth] = useState<number>(7.5);
  const [volatilityGrowth, setVolatilityGrowth] = useState<number>(4.0);
  const [meanExitMultiple, setMeanExitMultiple] = useState<number>(10.5);
  const [volatilityMultiple, setVolatilityMultiple] = useState<number>(2.0);
  const [isRunning, setIsRunning] = useState(false);

  // Run initial simulation
  const [simulationResult, setSimulationResult] = useState(() => 
    runMonteCarloSimulation(
      fund.netIRR || 20.5,
      2.3,
      numRuns,
      meanGrowth,
      volatilityGrowth,
      meanExitMultiple,
      volatilityMultiple
    )
  );

  const handleRunSimulation = () => {
    setIsRunning(true);
    setTimeout(() => {
      const res = runMonteCarloSimulation(
        fund.netIRR || 20.5,
        2.3,
        numRuns,
        meanGrowth,
        volatilityGrowth,
        meanExitMultiple,
        volatilityMultiple
      );
      setSimulationResult(res);
      setIsRunning(false);
    }, 400);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 font-mono-num text-[10px] font-bold uppercase">
              Stochastic Modeling
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Fund: <strong className="text-slate-200">{fund.name}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <Dices className="w-6 h-6 text-amber-400" />
            1,000-Trial Monte Carlo Return Distribution Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Statistical distribution modeling of fund IRR and MOIC: P10 down-side floor, P50 median expectation, P90 up-side, and Value at Risk (VaR).
          </p>
        </div>

        <button
          onClick={handleRunSimulation}
          disabled={isRunning}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 text-slate-950 font-bold text-xs shadow-lg shadow-amber-950/40 cursor-pointer flex items-center gap-2 transition-all disabled:opacity-50"
        >
          <Play className={`w-3.5 h-3.5 fill-current ${isRunning ? 'animate-spin' : ''}`} />
          {isRunning ? 'Executing Trials...' : 'Run 1,000 Stochastic Trials'}
        </button>
      </div>

      {/* Statistical Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono-num">
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">P10 Downside IRR</span>
          <span className="text-2xl font-bold text-rose-400 mt-1 block">{simulationResult.p10IRR.toFixed(1)}%</span>
          <span className="text-[10px] text-slate-400 font-sans">90% Confidence Floor</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">P50 Expected Median</span>
          <span className="text-2xl font-bold text-amber-400 mt-1 block">{simulationResult.p50IRR.toFixed(1)}%</span>
          <span className="text-[10px] text-slate-400 font-sans">Median Expected Return</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">P90 Bull Case IRR</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">{simulationResult.p90IRR.toFixed(1)}%</span>
          <span className="text-[10px] text-slate-400 font-sans">Top Decile Upside</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">P50 MOIC</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">{simulationResult.p50MOIC.toFixed(2)}x</span>
          <span className="text-[10px] text-slate-400 font-sans">P10: {simulationResult.p10MOIC.toFixed(2)}x • P90: {simulationResult.p90MOIC.toFixed(2)}x</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Value at Risk (VaR 95%)</span>
          <span className="text-2xl font-bold text-slate-200 mt-1 block">€{simulationResult.var95Percent.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">Maximum Capital at Risk</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Loss Probability (&lt;1.0x)</span>
          <span className="text-2xl font-bold text-emerald-300 mt-1 block">{simulationResult.lossProbability.toFixed(1)}%</span>
          <span className="text-[10px] text-emerald-400 font-sans">Near-Zero Capital Loss</span>
        </div>
      </div>

      {/* Histogram & Distribution Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: Stochastic Parameters */}
        <div className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl">
          <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            Gaussian Distribution Parameters
          </h3>

          <div className="space-y-4 font-mono-num">
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Revenue Growth Mean (μ)</span>
                <span className="font-bold text-emerald-400">{meanGrowth.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="15.0"
                step="0.5"
                value={meanGrowth}
                onChange={(e) => setMeanGrowth(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Growth Volatility / Std Dev (σ)</span>
                <span className="font-bold text-slate-200">{volatilityGrowth.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="8.0"
                step="0.5"
                value={volatilityGrowth}
                onChange={(e) => setVolatilityGrowth(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Exit Multiple Mean (μ)</span>
                <span className="font-bold text-sky-400">{meanExitMultiple.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="6.0"
                max="16.0"
                step="0.5"
                value={meanExitMultiple}
                onChange={(e) => setMeanExitMultiple(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Multiple Volatility / Std Dev (σ)</span>
                <span className="font-bold text-slate-200">{volatilityMultiple.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="4.0"
                step="0.25"
                value={volatilityMultiple}
                onChange={(e) => setVolatilityMultiple(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Probability Histogram */}
        <div className="lg:col-span-2 space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display font-bold text-base text-slate-100">
                1,000-Trial Probability Density Histogram (Net IRR)
              </h3>
              <p className="text-xs text-slate-400">Frequency of simulated net fund returns across 1,000 stochastic economic paths</p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={simulationResult.irrHistogram} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="bucket" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '8px', fontSize: '11px' }}
                  formatter={(val: any) => [`${val} trials`, 'Frequency']}
                />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {simulationResult.irrHistogram.map((entry, index) => {
                    const isTarget = entry.bucket.includes('20%') || entry.bucket.includes('22%') || entry.bucket.includes('24%');
                    return (
                      <Cell key={`cell-${index}`} fill={isTarget ? '#10b981' : '#f59e0b'} />
                    );
                  })}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
};
