import React, { useState } from 'react';
import { Deal, Sector } from '../types';
import { 
  Globe2, 
  MapPin, 
  Filter, 
  Building2, 
  TrendingUp, 
  ShieldCheck, 
  Coins, 
  Layers,
  ArrowRight
} from 'lucide-react';

interface GeoMapProps {
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
  onNavigateToTab: (tab: any) => void;
}

export const GeographicOpportunityMap: React.FC<GeoMapProps> = ({
  deals,
  onSelectDeal,
  onNavigateToTab
}) => {
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [selectedStageType, setSelectedStageType] = useState<'ALL' | 'PORTFOLIO' | 'PIPELINE'>('ALL');
  const [activeHoverDeal, setActiveHoverDeal] = useState<Deal | null>(null);

  const filteredDeals = deals.filter(d => {
    const matchSec = selectedSector === 'ALL' || d.sector === selectedSector;
    const matchStage = selectedStageType === 'ALL' || 
      (selectedStageType === 'PORTFOLIO' && (d.isPortfolioCompany || d.stage === 'PORTFOLIO')) ||
      (selectedStageType === 'PIPELINE' && (!d.isPortfolioCompany && d.stage !== 'PORTFOLIO'));
    return matchSec && matchStage;
  });

  // Country clusters
  const countryMap: Record<string, { count: number; totalEV: number; deals: Deal[] }> = {};
  deals.forEach(d => {
    if (!countryMap[d.country]) {
      countryMap[d.country] = { count: 0, totalEV: 0, deals: [] };
    }
    countryMap[d.country].count += 1;
    countryMap[d.country].totalEV += (d.currentValuationEV || d.proposedValuationEV);
    countryMap[d.country].deals.push(d);
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-100 flex items-center gap-2">
            <Globe2 className="w-6 h-6 text-amber-400" />
            Geographic Direct Investment & Opportunity Map
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Spatial distribution of portfolio companies, prospective pipeline targets, and cross-border capital deployment.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex items-center gap-2">
          <select
            value={selectedStageType}
            onChange={(e) => setSelectedStageType(e.target.value as any)}
            aria-label="Filter Map by Stage Type"
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            <option value="ALL">All Assets ({deals.length})</option>
            <option value="PORTFOLIO">Portfolio Companies Only</option>
            <option value="PIPELINE">Prospective Pipeline Only</option>
          </select>

          <select
            value={selectedSector}
            onChange={(e) => setSelectedSector(e.target.value)}
            aria-label="Filter Map by Sector"
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            <option value="ALL">All Sectors</option>
            {Array.from(new Set(deals.map(d => d.sector))).map(sec => (
              <option key={sec} value={sec}>{sec}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Map Visual Canvas & Country Roster */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Interactive Stylized European Grid Canvas */}
        <div className="lg:col-span-2 bg-slate-900/80 p-6 rounded-2xl border border-slate-800/80 shadow-xl space-y-4 relative min-h-[520px] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-semibold">
              <span className="w-3 h-3 rounded-full bg-amber-400 border border-amber-300"></span>
              <span className="text-slate-200">Portfolio Asset</span>
              <span className="w-3 h-3 rounded-full bg-sky-400 border border-sky-300 ml-3"></span>
              <span className="text-slate-200">Pipeline Deal</span>
            </div>
            <span className="text-xs text-slate-400 font-mono-num">{filteredDeals.length} Map Locations</span>
          </div>

          {/* SVG Map Visualizer with stylized geographic nodes */}
          <div className="relative w-full h-96 bg-slate-950/80 rounded-xl border border-slate-800 flex items-center justify-center overflow-hidden">
            {/* Grid overlay */}
            <div 
              className="absolute inset-0 opacity-15"
              style={{
                backgroundImage: 'radial-gradient(#f59e0b 1px, transparent 1px)',
                backgroundSize: '24px 24px'
              }}
            />

            {/* Stylized Node Cluster Plot */}
            <div className="relative w-full h-full p-8">
              {filteredDeals.map((deal, idx) => {
                // Map approximate lat/long coordinates onto 0-100% canvas
                // Europe bounds roughly lat 45 to 60, lng -10 to 20
                const lat = deal.coordinates[0];
                const lng = deal.coordinates[1];
                const topPct = Math.max(10, Math.min(85, ((62 - lat) / 18) * 100));
                const leftPct = Math.max(10, Math.min(88, ((lng + 10) / 30) * 100));

                const isPort = deal.isPortfolioCompany || deal.stage === 'PORTFOLIO';

                return (
                  <div
                    key={deal.id}
                    style={{ top: `${topPct}%`, left: `${leftPct}%` }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group z-20"
                    onMouseEnter={() => setActiveHoverDeal(deal)}
                    onClick={() => {
                      onSelectDeal(deal.id);
                      onNavigateToTab(isPort ? 'PORTFOLIO_DIGITAL_TWINS' : 'INVESTMENT_COMMITTEE');
                    }}
                  >
                    {/* Ripple animation on portfolio companies */}
                    {isPort && (
                      <span className="absolute -inset-2 rounded-full bg-amber-400/20 animate-ping" />
                    )}

                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shadow-lg transition-transform group-hover:scale-125 ${
                      isPort
                        ? 'bg-amber-500 text-slate-950 border-2 border-amber-300 shadow-amber-500/40'
                        : 'bg-sky-600 text-white border-2 border-sky-300 shadow-sky-500/40'
                    }`}>
                      <MapPin className="w-4 h-4" />
                    </div>

                    {/* Tooltip on hover */}
                    <div className="absolute left-1/2 -translate-x-1/2 bottom-10 hidden group-hover:block w-48 p-2.5 rounded-lg bg-slate-900/95 border border-slate-700 shadow-2xl text-xs z-30 pointer-events-none">
                      <div className="font-bold text-slate-100">{deal.companyName}</div>
                      <div className="text-[10px] text-amber-400 font-semibold">{deal.sector} • {deal.city}</div>
                      <div className="mt-1 flex justify-between text-[11px] font-mono-num text-slate-300">
                        <span>EV: €{deal.proposedValuationEV}M</span>
                        <span className="text-emerald-400 font-bold">{deal.targetIRR}% IRR</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Active Hover Detail Bar */}
          {activeHoverDeal && (
            <div className="p-3 rounded-xl bg-slate-950 border border-amber-500/30 flex items-center justify-between text-xs animate-in fade-in">
              <div>
                <span className="font-bold text-slate-100">{activeHoverDeal.companyName}</span>
                <span className="text-slate-400 ml-2">({activeHoverDeal.city}, {activeHoverDeal.country} • {activeHoverDeal.sector})</span>
              </div>
              <div className="flex items-center gap-3 font-mono-num">
                <span>EV: <strong className="text-amber-300">€{activeHoverDeal.proposedValuationEV}M</strong></span>
                <span>EBITDA: <strong className="text-emerald-400">€{activeHoverDeal.ebitda}M</strong></span>
                <button
                  onClick={() => {
                    onSelectDeal(activeHoverDeal.id);
                    onNavigateToTab('DUE_DILIGENCE_SUITE');
                  }}
                  className="px-2.5 py-1 rounded bg-amber-500 text-slate-950 font-bold text-[11px] hover:bg-amber-400 cursor-pointer"
                >
                  Inspect &rarr;
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Country Exposure & Geographic Concentration */}
        <div className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl">
          <div className="border-b border-slate-800 pb-3">
            <h2 className="font-display font-bold text-base text-slate-100">
              Country Allocation Breakdown
            </h2>
            <p className="text-xs text-slate-400">Portfolio & Pipeline Capital by Sovereign Jurisdiction</p>
          </div>

          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
            {Object.keys(countryMap).map(country => {
              const cluster = countryMap[country];
              return (
                <div key={country} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-200">{country}</span>
                    <span className="font-mono-num text-xs font-bold text-amber-400">€{cluster.totalEV.toFixed(1)}M EV</span>
                  </div>

                  <div className="text-[11px] text-slate-400 font-mono-num">
                    {cluster.count} Total Deal Assets ({cluster.deals.filter(d => d.isPortfolioCompany).length} Portfolio, {cluster.deals.filter(d => !d.isPortfolioCompany).length} Pipeline)
                  </div>

                  <div className="space-y-1 pt-1">
                    {cluster.deals.map(d => (
                      <button
                        key={d.id}
                        onClick={() => {
                          onSelectDeal(d.id);
                          onNavigateToTab('DUE_DILIGENCE_SUITE');
                        }}
                        className="w-full text-left text-[11px] px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-300 flex items-center justify-between transition-colors cursor-pointer"
                      >
                        <span className="truncate max-w-[170px]">{d.companyName}</span>
                        <span className="font-mono-num text-[10px] text-slate-400">{d.stage}</span>
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
};
