import React, { useState } from 'react';
import { Deal, ESGScorecard } from '../types';
import { 
  Leaf, 
  ShieldCheck, 
  Users, 
  TrendingUp, 
  Award, 
  CheckCircle2, 
  Sliders, 
  Building2,
  FileCheck
} from 'lucide-react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

interface ESGProps {
  deals: Deal[];
  selectedDeal: Deal;
  onSelectDeal: (dealId: string) => void;
  onUpdateDeal: (updated: Deal) => void;
}

const DEFAULT_ESG: ESGScorecard = {
  overallScore: 84,
  sfdrClassification: 'ARTICLE_8',
  carbonIntensityTonsPerMillion: 42.5,
  boardDiversityPercent: 44.0,
  netZeroTargetYear: 2035,
  categories: [
    { name: 'Environmental: Decarbonization & Clean Energy', score: 88, weight: 35, status: 'ADVANCED' },
    { name: 'Social: Health, Safety & Human Capital', score: 82, weight: 35, status: 'COMPLIANT' },
    { name: 'Governance: Independent Board & Compliance', score: 85, weight: 30, status: 'ADVANCED' }
  ]
};

export const ESGComplianceSuite: React.FC<ESGProps> = ({
  deals,
  selectedDeal,
  onSelectDeal,
  onUpdateDeal
}) => {
  const portfolioDeals = deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO');
  const activeCompany = selectedDeal.isPortfolioCompany ? selectedDeal : portfolioDeals[0] || selectedDeal;

  const [esgData, setEsgData] = useState<ESGScorecard>(
    activeCompany.esgScorecard || DEFAULT_ESG
  );

  const radarData = [
    { subject: 'GHG Decarbonization', score: 88, fullMark: 100 },
    { subject: 'Circular Economy', score: 76, fullMark: 100 },
    { subject: 'Workplace Safety', score: 94, fullMark: 100 },
    { subject: 'Diversity & Inclusion', score: 82, fullMark: 100 },
    { subject: 'Cybersecurity & Privacy', score: 90, fullMark: 100 },
    { subject: 'Board Independence', score: 86, fullMark: 100 }
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono-num text-[10px] font-bold uppercase">
              SFDR Article 8 Compliance
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Asset: <strong className="text-slate-200">{activeCompany.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <Leaf className="w-6 h-6 text-emerald-400" />
            ESG Governance & Decarbonization Roadmap
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional sustainability auditing: SFDR taxonomy classification, Scope 1-3 greenhouse gas tracking, board diversity, and Net-Zero milestones.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Target:</label>
          <select
            value={activeCompany.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {portfolioDeals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName}</option>
            ))}
          </select>
        </div>
      </div>

      {/* ESG Summary KPI Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono-num">
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Overall ESG Score</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">{esgData.overallScore}/100</span>
          <span className="text-[10px] text-emerald-400 font-sans">Tier-1 Rating (AA)</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">SFDR Taxonomy</span>
          <span className="text-lg font-bold text-amber-300 mt-1 block">Article 8</span>
          <span className="text-[10px] text-slate-400 font-sans">Promotes ESG Characteristics</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Carbon Intensity</span>
          <span className="text-2xl font-bold text-slate-100 mt-1 block">{esgData.carbonIntensityTonsPerMillion}</span>
          <span className="text-[10px] text-emerald-400 font-sans">tCO2e / €M Revenue</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Board Diversity</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">{esgData.boardDiversityPercent}%</span>
          <span className="text-[10px] text-sky-400 font-sans">Gender Balanced Board</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Net-Zero Milestone</span>
          <span className="text-2xl font-bold text-emerald-300 mt-1 block">{esgData.netZeroTargetYear}</span>
          <span className="text-[10px] text-emerald-400 font-sans">SBTi-Validated Commitment</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Green Premium Value</span>
          <span className="text-2xl font-bold text-amber-400 mt-1 block">+0.75x</span>
          <span className="text-[10px] text-slate-400 font-sans">Exit Multiple Expansion</span>
        </div>
      </div>

      {/* Radar Chart & Category Audits */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Radar Chart */}
        <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-400" />
            6-Dimension Sustainability Radar
          </h3>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="#1e293b" />
                <PolarAngleAxis dataKey="subject" stroke="#64748b" fontSize={11} />
                <PolarRadiusAxis stroke="#64748b" angle={30} domain={[0, 100]} />
                <Radar name="ESG Performance" dataKey="score" stroke="#10b981" fill="#10b981" fillOpacity={0.4} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Action Roadmap */}
        <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-amber-400" />
            Active Decarbonization Initiatives
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <div className="flex justify-between font-bold text-slate-200">
                <span>100% Renewable Power Purchase Agreement (PPA)</span>
                <span className="text-emerald-400">Completed (Q2 2024)</span>
              </div>
              <p className="text-slate-400">Migrated all 4 industrial operating sites to wind and hydro PPAs, reducing Scope 2 emissions by 84%.</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <div className="flex justify-between font-bold text-slate-200">
                <span>Supply Chain Supplier ESG Auditing (Scope 3)</span>
                <span className="text-amber-400">In Progress (62% Audited)</span>
              </div>
              <p className="text-slate-400">Enforcing strict Code of Conduct and carbon accounting across top 50 direct material vendors.</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <div className="flex justify-between font-bold text-slate-200">
                <span>ISO 14001 & ISO 45001 Certification</span>
                <span className="text-emerald-400">Active Audit Certification</span>
              </div>
              <p className="text-slate-400">Standardized environmental management and workplace occupational health compliance.</p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
