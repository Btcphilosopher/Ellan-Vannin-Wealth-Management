import React from 'react';
import { 
  LayoutDashboard, 
  Landmark, 
  Coins, 
  FileText, 
  ShieldCheck, 
  GitPullRequest, 
  SlidersHorizontal, 
  Globe2, 
  Columns3, 
  SearchCode, 
  Building, 
  Calculator, 
  Scale, 
  Layers, 
  PieChart, 
  Cpu, 
  TrendingUp, 
  Activity, 
  GitMerge, 
  RefreshCw, 
  LineChart, 
  Flame, 
  Dices, 
  AlertTriangle, 
  History,
  Briefcase
} from 'lucide-react';

export type NavTabId =
  | 'FUND_DASHBOARD'
  | 'FUND_STRUCTURE'
  | 'CAPITAL_CALLS'
  | 'INVESTOR_REPORTING'
  | 'ESG_GOVERNANCE'
  | 'DEAL_PIPELINE'
  | 'SCREENING_ENGINE'
  | 'GEO_INVESTMENT_MAP'
  | 'DEAL_COMPARISON'
  | 'DUE_DILIGENCE_SUITE'
  | 'VALUATION_SUITE'
  | 'LBO_DEBT_ENGINE'
  | 'SOURCES_USES'
  | 'EXIT_SENSITIVITY'
  | 'INVESTMENT_COMMITTEE'
  | 'PORTFOLIO_DIGITAL_TWINS'
  | 'VALUE_CREATION'
  | 'OPERATING_KPIS'
  | 'ADD_ON_ACQUISITIONS'
  | 'REFINANCING_ENGINE'
  | 'FUND_RETURNS_JCURVE'
  | 'MACRO_STRESS_TESTING'
  | 'MONTE_CARLO'
  | 'PORTFOLIO_OPTIMIZER'
  | 'AUDIT_TRAIL';

interface SidebarProps {
  activeTab: NavTabId;
  onSelectTab: (tab: NavTabId) => void;
  dealCounts?: {
    pipeline?: number;
    portfolio?: number;
    icPending?: number;
    alerts?: number;
  };
  dealCount?: number;
  portfolioCount?: number;
  activeRole?: string;
  fundName?: string;
}

interface NavSection {
  title: string;
  items: {
    id: NavTabId;
    label: string;
    icon: React.ElementType;
    badge?: string | number;
    badgeColor?: string;
  }[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  dealCounts,
  dealCount,
  portfolioCount
}) => {
  const counts = {
    pipeline: dealCounts?.pipeline ?? dealCount ?? 0,
    portfolio: dealCounts?.portfolio ?? portfolioCount ?? 0,
    icPending: dealCounts?.icPending ?? 0,
    alerts: dealCounts?.alerts ?? 0
  };

  const sections: NavSection[] = [
    {
      title: 'I. Capital & Governance',
      items: [
        { id: 'FUND_DASHBOARD', label: 'Fund Master Dashboard', icon: LayoutDashboard },
        { id: 'FUND_STRUCTURE', label: 'Fund Structure & Terms', icon: Landmark },
        { id: 'CAPITAL_CALLS', label: 'Capital Call Engine', icon: Coins },
        { id: 'INVESTOR_REPORTING', label: 'LP Investor Reporting', icon: FileText },
        { id: 'ESG_GOVERNANCE', label: 'ESG & Governance Audit', icon: ShieldCheck }
      ]
    },
    {
      title: 'II. Deal Origination & Diligence',
      items: [
        { id: 'DEAL_PIPELINE', label: 'Deal Sourcing Pipeline', icon: GitPullRequest, badge: counts.pipeline },
        { id: 'SCREENING_ENGINE', label: 'Investment Screening', icon: SlidersHorizontal },
        { id: 'GEO_INVESTMENT_MAP', label: 'Geographic Opportunity Map', icon: Globe2 },
        { id: 'DEAL_COMPARISON', label: 'Deal Comparison Matrix', icon: Columns3 },
        { id: 'DUE_DILIGENCE_SUITE', label: 'Due Diligence & VDR', icon: SearchCode }
      ]
    },
    {
      title: 'III. Underwriting & Valuation',
      items: [
        { id: 'VALUATION_SUITE', label: 'Valuation Engine (DCF/SOTP)', icon: Calculator },
        { id: 'LBO_DEBT_ENGINE', label: 'LBO & Debt Structuring', icon: Scale },
        { id: 'SOURCES_USES', label: 'Sources & Uses Engine', icon: Layers },
        { id: 'EXIT_SENSITIVITY', label: 'Exit Multiple Sensitivity', icon: PieChart },
        { id: 'INVESTMENT_COMMITTEE', label: 'Investment Committee', icon: Briefcase, badge: counts.icPending, badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30' }
      ]
    },
    {
      title: 'IV. Digital Twin & Value Creation',
      items: [
        { id: 'PORTFOLIO_DIGITAL_TWINS', label: 'Portfolio Digital Twins', icon: Cpu, badge: counts.portfolio },
        { id: 'VALUE_CREATION', label: 'Value Creation Engine', icon: TrendingUp },
        { id: 'OPERATING_KPIS', label: 'Operating KPI Engine', icon: Activity },
        { id: 'ADD_ON_ACQUISITIONS', label: 'Add-on M&A Engine', icon: GitMerge },
        { id: 'REFINANCING_ENGINE', label: 'Refinancing & Recap', icon: RefreshCw }
      ]
    },
    {
      title: 'V. Quantitative Risk & Return',
      items: [
        { id: 'FUND_RETURNS_JCURVE', label: 'Fund Returns & J-Curve', icon: LineChart },
        { id: 'MACRO_STRESS_TESTING', label: 'Macro Stress Testing (7 Shocks)', icon: Flame },
        { id: 'MONTE_CARLO', label: 'Monte Carlo PE Model', icon: Dices },
        { id: 'PORTFOLIO_OPTIMIZER', label: 'Portfolio Optimizer & Alerts', icon: AlertTriangle, badge: counts.alerts > 0 ? `${counts.alerts} Alert` : undefined, badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30' },
        { id: 'AUDIT_TRAIL', label: 'Institutional Audit Trail', icon: History }
      ]
    }
  ];

  return (
    <aside className="w-72 shrink-0 bg-slate-950/90 border-r border-slate-800/80 flex flex-col h-[calc(100vh-61px)] overflow-y-auto no-print">
      <div className="p-3 space-y-5">
        {sections.map((section, idx) => (
          <div key={idx} className="space-y-1">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-300 px-2.5 py-1">
              {section.title}
            </h3>
            <div className="space-y-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-medium transition-all group text-left cursor-pointer ${
                      isActive
                        ? 'bg-amber-500/15 text-amber-200 border border-amber-500/30 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon
                        className={`w-4 h-4 shrink-0 transition-colors ${
                          isActive ? 'text-amber-400' : 'text-slate-400 group-hover:text-slate-200'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    {item.badge !== undefined && (
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full border font-mono-num font-semibold ${
                          item.badgeColor || (isActive ? 'bg-amber-400/20 text-amber-300 border-amber-400/30' : 'bg-slate-800 text-slate-400 border-slate-700')
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer System Status */}
      <div className="mt-auto p-3 border-t border-slate-900 bg-slate-950/90 text-[11px] text-slate-500">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-slate-400 font-medium">EVWM Engine Active</span>
          </div>
          <span className="font-mono-num text-[10px] text-slate-500">v3.7 PE-OS</span>
        </div>
        <p className="mt-1 text-[10px] text-slate-600 leading-tight">
          Strict institutional fiduciary mandate & capital allocation controls active.
        </p>
      </div>
    </aside>
  );
};
