import React, { useState } from 'react';
import { Deal } from '../types';
import { 
  Layers, 
  CheckCircle, 
  AlertTriangle, 
  Coins, 
  Building2, 
  ArrowRight,
  DollarSign,
  PieChart as PieIcon,
  Percent
} from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';

interface SourcesUsesProps {
  deal: Deal;
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
  onUpdateDeal: (updated: Deal) => void;
}

const COLORS = ['#f59e0b', '#10b981', '#6366f1', '#ec4899', '#06b6d4'];

export const SourcesAndUsesEngine: React.FC<SourcesUsesProps> = ({
  deal,
  deals,
  onSelectDeal,
  onUpdateDeal
}) => {
  const [purchasePrice, setPurchasePrice] = useState<number>(deal.proposedValuationEV);
  const [refinancedDebt, setRefinancedDebt] = useState<number>(15.0);
  const [advisoryFees, setAdvisoryFees] = useState<number>(3.5);
  const [financingFees, setFinancingFees] = useState<number>(2.0);
  const [managementRollover, setManagementRollover] = useState<number>(8.0);
  const [seniorDebtA, setSeniorDebtA] = useState<number>(deal.ebitda * 2.5);
  const [seniorDebtB, setSeniorDebtB] = useState<number>(deal.ebitda * 1.5);
  const [mezzanineDebt, setMezzanineDebt] = useState<number>(deal.ebitda * 0.5);

  const totalUses = purchasePrice + refinancedDebt + advisoryFees + financingFees;
  const totalDebtFunded = seniorDebtA + seniorDebtB + mezzanineDebt;
  const sponsorEquityRequired = Math.max(0, totalUses - totalDebtFunded - managementRollover);
  const totalSources = totalDebtFunded + managementRollover + sponsorEquityRequired;

  const isBalanced = Math.abs(totalSources - totalUses) < 0.01;

  const sourcesPieData = [
    { name: 'Senior Debt A', value: Number(seniorDebtA.toFixed(1)) },
    { name: 'Senior Debt B', value: Number(seniorDebtB.toFixed(1)) },
    { name: 'Mezzanine Debt', value: Number(mezzanineDebt.toFixed(1)) },
    { name: 'Management Rollover', value: Number(managementRollover.toFixed(1)) },
    { name: 'Sponsor Equity (EVWM)', value: Number(sponsorEquityRequired.toFixed(1)) }
  ];

  const usesPieData = [
    { name: 'Enterprise Value Purchase', value: Number(purchasePrice.toFixed(1)) },
    { name: 'Refinanced Existing Debt', value: Number(refinancedDebt.toFixed(1)) },
    { name: 'Advisory & Legal DD', value: Number(advisoryFees.toFixed(1)) },
    { name: 'Financing & Arrangement', value: Number(financingFees.toFixed(1)) }
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono-num text-[10px] font-bold uppercase">
              Capital Structuring
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Deal: <strong className="text-slate-200">{deal.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <Layers className="w-6 h-6 text-amber-400" />
            Sources & Uses Capital Balancer
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time equity check calculation, leverage calibration, and debt-to-equity closing reconciliation.
          </p>
        </div>

        {/* Quick Deal Switcher */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Target:</label>
          <select
            value={deal.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {deals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName} (EV: €{d.proposedValuationEV}M)</option>
            ))}
          </select>
        </div>
      </div>

      {/* Balance Indicator Banner */}
      <div className={`p-4 rounded-2xl border flex items-center justify-between font-mono-num ${
        isBalanced 
          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
          : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
      }`}>
        <div className="flex items-center gap-3">
          {isBalanced ? <CheckCircle className="w-5 h-5 text-emerald-400" /> : <AlertTriangle className="w-5 h-5 text-rose-400" />}
          <div>
            <span className="font-sans font-bold text-sm">
              {isBalanced ? 'Sources & Uses Exactly Reconciled' : 'Sources & Uses Unbalanced'}
            </span>
            <span className="text-xs text-slate-400 block font-sans">
              Total Capital Deployed: €{totalUses.toFixed(2)}M • Sponsor Equity: €{sponsorEquityRequired.toFixed(2)}M
            </span>
          </div>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-400 font-sans block">Total Funding</span>
          <span className="text-xl font-bold">€{totalSources.toFixed(2)}M</span>
        </div>
      </div>

      {/* Sources & Uses Dual Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* USES OF FUNDS */}
        <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-display font-bold text-base text-slate-100">
              Uses of Funds (€ Millions)
            </h3>
            <span className="font-mono-num text-xs font-bold text-amber-400">
              Total Uses: €{totalUses.toFixed(1)}M
            </span>
          </div>

          <div className="space-y-3 font-mono-num">
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Enterprise Value Purchase Price</span>
                <span className="text-slate-100 font-bold">€{purchasePrice.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="50"
                max="500"
                step="5"
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Refinance Existing Debt</span>
                <span className="text-slate-100 font-bold">€{refinancedDebt.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                step="1"
                value={refinancedDebt}
                onChange={(e) => setRefinancedDebt(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Advisory, M&A, Accounting & Legal DD</span>
                <span className="text-slate-100 font-bold">€{advisoryFees.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="10.0"
                step="0.25"
                value={advisoryFees}
                onChange={(e) => setAdvisoryFees(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Debt Financing & Arrangement Fees</span>
                <span className="text-slate-100 font-bold">€{financingFees.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="10.0"
                step="0.25"
                value={financingFees}
                onChange={(e) => setFinancingFees(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* SOURCES OF FUNDS */}
        <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-display font-bold text-base text-slate-100">
              Sources of Funds (€ Millions)
            </h3>
            <span className="font-mono-num text-xs font-bold text-emerald-400">
              Total Sources: €{totalSources.toFixed(1)}M
            </span>
          </div>

          <div className="space-y-3 font-mono-num">
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Senior Term Loan A (Amortizing)</span>
                <span className="text-slate-100 font-bold">€{seniorDebtA.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="0"
                max="150"
                step="2.5"
                value={seniorDebtA}
                onChange={(e) => setSeniorDebtA(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Senior Term Loan B (Bullet)</span>
                <span className="text-slate-100 font-bold">€{seniorDebtB.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="0"
                max="150"
                step="2.5"
                value={seniorDebtB}
                onChange={(e) => setSeniorDebtB(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Mezzanine / Subordinated Debt</span>
                <span className="text-slate-100 font-bold">€{mezzanineDebt.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                step="1"
                value={mezzanineDebt}
                onChange={(e) => setMezzanineDebt(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Management Rollover Equity</span>
                <span className="text-slate-100 font-bold">€{managementRollover.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="0"
                max="30"
                step="1"
                value={managementRollover}
                onChange={(e) => setManagementRollover(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between text-xs">
              <span className="font-sans font-bold text-emerald-300">Sponsor Equity Required:</span>
              <span className="font-bold text-emerald-400 text-sm">€{sponsorEquityRequired.toFixed(1)}M ({((sponsorEquityRequired / totalSources) * 100).toFixed(1)}%)</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
