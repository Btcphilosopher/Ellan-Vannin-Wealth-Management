import React, { useState } from 'react';
import { Deal } from '../types';
import { 
  Columns3, 
  Check, 
  Plus, 
  Trash2, 
  TrendingUp, 
  Scale, 
  ShieldAlert, 
  Building2,
  DollarSign
} from 'lucide-react';

interface ComparisonProps {
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
  onNavigateToTab: (tab: any) => void;
}

export const DealComparisonMatrix: React.FC<ComparisonProps> = ({
  deals,
  onSelectDeal,
  onNavigateToTab
}) => {
  const [selectedDealIds, setSelectedDealIds] = useState<string[]>([
    deals[0]?.id || '',
    deals[1]?.id || '',
    deals[2]?.id || '',
    deals[3]?.id || ''
  ].filter(Boolean));

  const comparisonDeals = deals.filter(d => selectedDealIds.includes(d.id));

  const toggleDealSelection = (dealId: string) => {
    if (selectedDealIds.includes(dealId)) {
      if (selectedDealIds.length > 1) {
        setSelectedDealIds(selectedDealIds.filter(id => id !== dealId));
      }
    } else {
      if (selectedDealIds.length < 4) {
        setSelectedDealIds([...selectedDealIds, dealId]);
      }
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-100 flex items-center gap-2">
            <Columns3 className="w-6 h-6 text-amber-400" />
            Institutional Deal Comparison Suite
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Side-by-side comparative underwriting matrix evaluating valuation, returns, leverage capacity, growth, and risks.
          </p>
        </div>
      </div>

      {/* Deal Selector Chips */}
      <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex flex-wrap items-center gap-2">
        <span className="text-xs font-semibold text-slate-400 mr-2">Select Up to 4 Opportunities:</span>
        {deals.map((d) => {
          const isSelected = selectedDealIds.includes(d.id);
          return (
            <button
              key={d.id}
              onClick={() => toggleDealSelection(d.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                isSelected
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              {isSelected ? <Check className="w-3.5 h-3.5 text-amber-400" /> : <Plus className="w-3.5 h-3.5" />}
              {d.companyName}
            </button>
          );
        })}
      </div>

      {/* Comparison Matrix Table */}
      <div className="bg-slate-900/80 rounded-2xl border border-slate-800/80 shadow-2xl overflow-x-auto">
        <table className="w-full text-left text-xs font-mono-num">
          <thead>
            <tr className="bg-slate-950 border-b border-slate-800 font-sans">
              <th className="py-4 px-4 text-slate-400 uppercase text-[11px] font-bold w-64">
                Underwriting Metric
              </th>
              {comparisonDeals.map((deal) => (
                <th key={deal.id} className="py-4 px-4 min-w-[220px]">
                  <div className="font-bold text-sm text-slate-100">{deal.companyName}</div>
                  <div className="text-[11px] font-normal text-amber-400">{deal.sector} • {deal.country}</div>
                  <div className="text-[10px] font-normal text-slate-400 mt-0.5">Stage: {deal.stage}</div>
                </th>
              ))}
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-800/60">
            
            {/* 1. Core Financials & Valuation */}
            <tr className="bg-slate-950/40 font-sans font-bold text-amber-300 text-[11px]">
              <td colSpan={comparisonDeals.length + 1} className="py-2.5 px-4 uppercase tracking-wider">
                I. Valuation & Financial Profile
              </td>
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Revenue (LTM)</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-slate-200 font-semibold">€{d.revenue.toFixed(1)}M</td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">EBITDA (LTM)</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-emerald-400 font-bold">€{d.ebitda.toFixed(1)}M</td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">EBITDA Margin (%)</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-slate-200">{d.ebitdaMargin.toFixed(1)}%</td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Enterprise Value (EV)</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-amber-300 font-bold">€{d.proposedValuationEV.toFixed(1)}M</td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Entry EV/EBITDA Multiple</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-sky-400 font-semibold">
                  {(d.proposedValuationEV / (d.ebitda || 1)).toFixed(2)}x
                </td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Sponsor Equity Check</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-slate-200">€{d.dealSizeEquity.toFixed(1)}M</td>
              ))}
            </tr>

            {/* 2. Projected Returns & Structure */}
            <tr className="bg-slate-950/40 font-sans font-bold text-amber-300 text-[11px]">
              <td colSpan={comparisonDeals.length + 1} className="py-2.5 px-4 uppercase tracking-wider">
                II. Projected Returns & LBO Structure
              </td>
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Target Gross IRR (%)</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-emerald-400 font-bold text-sm">{d.targetIRR.toFixed(1)}%</td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Target MOIC (Gross)</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-sky-300 font-bold text-sm">{d.targetMOIC.toFixed(2)}x</td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Opening Leverage (Debt / EBITDA)</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-slate-300 font-medium">
                  {d.lboModel?.debtTranches ? (d.lboModel.debtTranches.reduce((a, b) => a + b.amount, 0) / (d.ebitda || 1)).toFixed(2) : '2.5'}x
                </td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Exit Multiple Assumed</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-slate-300">
                  {d.lboModel?.exitMultiple || 10.0}x EV/EBITDA
                </td>
              ))}
            </tr>

            {/* 3. Operational & Commercial Scores */}
            <tr className="bg-slate-950/40 font-sans font-bold text-amber-300 text-[11px]">
              <td colSpan={comparisonDeals.length + 1} className="py-2.5 px-4 uppercase tracking-wider">
                III. Underwriting Scores & Due Diligence
              </td>
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">EVWM Composite Score</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4">
                  <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                    {d.screeningScorecard.overallScore} / 100
                  </span>
                </td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Competitive Moat Score</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-slate-200">{d.screeningScorecard.competitiveAdvantage} / 100</td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Management Quality Score</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-slate-200">{d.managementDD?.managementQualityScore || 88} / 100</td>
              ))}
            </tr>

            <tr>
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Identified Risk Issues</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-2.5 px-4 text-rose-400 font-semibold">
                  {d.dueDiligenceIssues?.length || 0} Issues Flagged
                </td>
              ))}
            </tr>

            {/* Actions */}
            <tr className="bg-slate-950 font-sans">
              <td className="py-4 px-4 text-slate-400 font-semibold">Action</td>
              {comparisonDeals.map(d => (
                <td key={d.id} className="py-4 px-4">
                  <button
                    onClick={() => {
                      onSelectDeal(d.id);
                      onNavigateToTab('DUE_DILIGENCE_SUITE');
                    }}
                    className="w-full py-1.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                  >
                    Open Deal Suite &rarr;
                  </button>
                </td>
              ))}
            </tr>

          </tbody>
        </table>
      </div>
    </div>
  );
};
