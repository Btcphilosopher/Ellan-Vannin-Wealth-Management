import React from 'react';
import { Fund, Deal } from '../types';
import { 
  Building2, 
  TrendingUp, 
  ShieldAlert, 
  Coins, 
  DollarSign, 
  PieChart as PieIcon, 
  Globe, 
  ArrowUpRight, 
  ArrowDownRight, 
  CheckCircle2, 
  AlertCircle,
  Briefcase,
  Layers,
  BarChart3
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';

interface DashboardProps {
  fund: Fund;
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
  onNavigateToTab: (tab: any) => void;
}

const SECTOR_COLORS: Record<string, string> = {
  INDUSTRIALS: '#f59e0b',
  ENERGY: '#10b981',
  TECHNOLOGY: '#6366f1',
  HEALTHCARE: '#ec4899',
  INFRASTRUCTURE: '#06b6d4',
  LOGISTICS: '#8b5cf6',
  FOOD: '#84cc16',
  AGRICULTURE: '#eab308',
  'REAL ESTATE': '#f97316',
  TRANSPORT: '#14b8a6',
  'FINANCIAL SERVICES': '#3b82f6',
  CONSUMER: '#d946ef'
};

export const FundMasterDashboard: React.FC<DashboardProps> = ({
  fund,
  deals,
  onSelectDeal,
  onNavigateToTab
}) => {
  const portfolioDeals = deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO');
  const pipelineDeals = deals.filter(d => d.stage !== 'PORTFOLIO' && d.stage !== 'EXIT');

  // Compute live portfolio aggregates
  const totalPortfolioEV = portfolioDeals.reduce((sum, d) => sum + (d.currentValuationEV || d.proposedValuationEV), 0);
  const totalInvestedEquity = portfolioDeals.reduce((sum, d) => sum + (d.entryEquity || d.dealSizeEquity), 0);
  const totalCurrentEquity = portfolioDeals.reduce((sum, d) => sum + (d.currentEquityValue || d.dealSizeEquity), 0);
  const totalNetDebt = portfolioDeals.reduce((sum, d) => sum + (d.currentNetDebt || 0), 0);

  const calculatedNAV = totalCurrentEquity + fund.cash - fund.fundDebt;
  const dpi = fund.investedCapital > 0 ? (fund.realisedProceeds / fund.investedCapital) : 0;
  const rvpi = fund.investedCapital > 0 ? (calculatedNAV / fund.investedCapital) : 0;
  const tvpi = dpi + rvpi;
  const moic = fund.investedCapital > 0 ? ((fund.realisedProceeds + calculatedNAV) / fund.investedCapital) : 1;

  // Sector breakdown data for Pie Chart
  const sectorMap: Record<string, number> = {};
  portfolioDeals.forEach(d => {
    sectorMap[d.sector] = (sectorMap[d.sector] || 0) + (d.currentValuationEV || d.proposedValuationEV);
  });
  const sectorData = Object.keys(sectorMap).map(k => ({
    name: k,
    value: Number(sectorMap[k].toFixed(1))
  }));

  // Geographic breakdown
  const geoMap: Record<string, number> = {};
  portfolioDeals.forEach(d => {
    geoMap[d.country] = (geoMap[d.country] || 0) + (d.currentValuationEV || d.proposedValuationEV);
  });
  const geoData = Object.keys(geoMap).map(k => ({
    country: k,
    value: Number(geoMap[k].toFixed(1)),
    pct: ((geoMap[k] / (totalPortfolioEV || 1)) * 100).toFixed(0)
  }));

  // NAV Progression historical data
  const navHistoryData = [
    { quarter: 'Q1 2023', nav: 210, invested: 200, distributions: 0 },
    { quarter: 'Q2 2023', nav: 285, invested: 260, distributions: 0 },
    { quarter: 'Q3 2023', nav: 340, invested: 310, distributions: 15 },
    { quarter: 'Q4 2023', nav: 410, invested: 380, distributions: 35 },
    { quarter: 'Q1 2024', nav: 460, invested: 410, distributions: 48 },
    { quarter: 'Q2 2024', nav: 520, invested: 450, distributions: 72 },
    { quarter: 'Q3 2024', nav: 580, invested: 480, distributions: 95 },
    { quarter: 'Q4 2024', nav: 610, invested: 495, distributions: 120 },
    { quarter: 'Q1 2025', nav: 645, invested: 495, distributions: 135 },
    { quarter: 'Q2 2025', nav: calculatedNAV, invested: fund.investedCapital, distributions: fund.realisedProceeds }
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner / Fund Identity */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 p-6 rounded-2xl border border-slate-800/80 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold uppercase tracking-wider">
                Vintage {fund.vintage} • {fund.currency}
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-medium">
                Active Investment Period
              </span>
            </div>
            <h1 className="font-display text-2xl lg:text-3xl font-bold text-slate-100 tracking-wide">
              {fund.name}
            </h1>
            <p className="text-xs text-slate-400 max-w-3xl mt-1 leading-relaxed">
              Institutional direct equity vehicle targeting market-leading industrial, critical infrastructure, energy transition, and healthcare platform assets with conservative capital structures and active operational value creation.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onNavigateToTab('CAPITAL_CALLS')}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-all shadow cursor-pointer flex items-center gap-1.5"
            >
              <Coins className="w-4 h-4 text-amber-400" />
              Capital Calls (€{fund.uncalledCapital}M Uncalled)
            </button>
            <button
              onClick={() => onNavigateToTab('INVESTOR_REPORTING')}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-amber-950/40 cursor-pointer flex items-center gap-1.5"
            >
              <BarChart3 className="w-4 h-4" />
              ILPA Quarterly Pack
            </button>
          </div>
        </div>
      </div>

      {/* Primary KPI Grid (16 core institutional metrics) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8 gap-3">
        
        {/* NAV */}
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80 shadow-md">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Fund NAV</div>
          <div className="font-mono-num text-xl font-bold text-amber-300 mt-1">
            €{calculatedNAV.toFixed(1)}M
          </div>
          <div className="text-[10px] text-emerald-400 flex items-center gap-0.5 mt-1 font-medium">
            <ArrowUpRight className="w-3 h-3" /> +€{(calculatedNAV - fund.investedCapital).toFixed(1)}M Value Add
          </div>
        </div>

        {/* Committed Capital */}
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80 shadow-md">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Committed</div>
          <div className="font-mono-num text-xl font-bold text-slate-100 mt-1">
            €{fund.committedCapital}M
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            100% Subscribed
          </div>
        </div>

        {/* Invested Capital */}
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80 shadow-md">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Invested Capital</div>
          <div className="font-mono-num text-xl font-bold text-slate-100 mt-1">
            €{fund.investedCapital}M
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono-num">
            {((fund.investedCapital / fund.committedCapital) * 100).toFixed(0)}% Deployed
          </div>
        </div>

        {/* Uncalled / Dry Powder */}
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80 shadow-md">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Dry Powder</div>
          <div className="font-mono-num text-xl font-bold text-amber-400 mt-1">
            €{fund.uncalledCapital}M
          </div>
          <div className="text-[10px] text-amber-400/80 mt-1">
            Available for Calls
          </div>
        </div>

        {/* Gross IRR */}
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80 shadow-md">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Gross IRR</div>
          <div className="font-mono-num text-xl font-bold text-emerald-400 mt-1">
            {fund.targetGrossIRR.toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Target: ≥20.0%
          </div>
        </div>

        {/* Net IRR */}
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80 shadow-md">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Net IRR</div>
          <div className="font-mono-num text-xl font-bold text-emerald-300 mt-1">
            {fund.targetNetIRR.toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Net of Fees & Carry
          </div>
        </div>

        {/* MOIC */}
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80 shadow-md">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">MOIC / TVPI</div>
          <div className="font-mono-num text-xl font-bold text-sky-400 mt-1">
            {tvpi.toFixed(2)}x
          </div>
          <div className="text-[10px] text-sky-400/80 mt-1 font-mono-num">
            DPI: {dpi.toFixed(2)}x • RVPI: {rvpi.toFixed(2)}x
          </div>
        </div>

        {/* Portfolio Risk */}
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800/80 shadow-md">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Portfolio Risk</div>
          <div className="font-mono-num text-xl font-bold text-emerald-400 mt-1">
            18 / 100
          </div>
          <div className="text-[10px] text-emerald-400/80 mt-1">
            Low Downside Risk
          </div>
        </div>

      </div>

      {/* Main Charts & Allocation Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* NAV Growth & Distribution Waterfall Chart */}
        <div className="lg:col-span-2 bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display font-bold text-base text-slate-100">Fund NAV Progression & Realised Distributions</h2>
              <p className="text-xs text-slate-400">Quarterly progression from inception (€ Millions)</p>
            </div>
            <div className="flex items-center gap-4 text-xs font-mono-num">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                <span className="text-slate-300">Fund NAV</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                <span className="text-slate-300">Distributions</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-600"></span>
                <span className="text-slate-400">Invested Capital</span>
              </div>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={navHistoryData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorNav" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0}/>
                  </linearGradient>
                  <linearGradient id="colorDist" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="quarter" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`€${val}M`, '']}
                />
                <Area type="monotone" dataKey="invested" stroke="#64748b" strokeDasharray="3 3" fillOpacity={0} />
                <Area type="monotone" dataKey="nav" stroke="#f59e0b" strokeWidth={2} fillOpacity={1} fill="url(#colorNav)" />
                <Area type="monotone" dataKey="distributions" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorDist)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sector Exposure Breakdown */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display font-bold text-base text-slate-100">Sector Exposure</h2>
              <p className="text-xs text-slate-400">Total Portfolio EV: €{totalPortfolioEV.toFixed(1)}M</p>
            </div>
            <button
              onClick={() => onNavigateToTab('PORTFOLIO_OPTIMIZER')}
              className="text-xs text-amber-400 hover:text-amber-300 font-medium"
            >
              Analyze Limits &rarr;
            </button>
          </div>

          <div className="h-44 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sectorData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {sectorData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={SECTOR_COLORS[entry.name] || '#94a3b8'} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '8px', fontSize: '11px' }}
                  formatter={(val: any) => [`€${val}M`, 'Enterprise Value']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-1.5 max-h-28 overflow-y-auto pr-1">
            {sectorData.map((sec) => (
              <div key={sec.name} className="flex items-center justify-between text-xs font-mono-num">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: SECTOR_COLORS[sec.name] || '#94a3b8' }} />
                  <span className="text-slate-300 font-sans font-medium text-[11px] truncate max-w-[130px]">{sec.name}</span>
                </div>
                <span className="text-slate-200">€{sec.value}M ({((sec.value / (totalPortfolioEV || 1)) * 100).toFixed(0)}%)</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Active Direct Portfolio Companies (Digital Twins Overview) */}
      <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h2 className="font-display font-bold text-base text-slate-100">Active Direct Portfolio Companies (Digital Twins)</h2>
            <p className="text-xs text-slate-400">Institutional direct investments with live operational telemetry & NAV valuation</p>
          </div>
          <button
            onClick={() => onNavigateToTab('PORTFOLIO_DIGITAL_TWINS')}
            className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30 transition-colors self-start sm:self-auto cursor-pointer"
          >
            Launch Digital Twin Cockpit &rarr;
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold text-[10px]">
                <th className="py-3 px-3">Company / Asset</th>
                <th className="py-3 px-2">Sector & Geo</th>
                <th className="py-3 px-2">Acquisition</th>
                <th className="py-3 px-2 text-right">Revenue</th>
                <th className="py-3 px-2 text-right">EBITDA (Margin)</th>
                <th className="py-3 px-2 text-right">Entry EV</th>
                <th className="py-3 px-2 text-right">Current EV</th>
                <th className="py-3 px-2 text-right">Net Debt</th>
                <th className="py-3 px-2 text-right">Current Equity</th>
                <th className="py-3 px-2 text-right">Target IRR</th>
                <th className="py-3 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono-num">
              {portfolioDeals.map((deal) => {
                const curEV = deal.currentValuationEV || deal.proposedValuationEV;
                const entryEV = deal.entryValuationEV || deal.proposedValuationEV;
                const appreciation = curEV - entryEV;
                const curEquity = deal.currentEquityValue || deal.dealSizeEquity;
                const entryEquity = deal.entryEquity || deal.dealSizeEquity;
                const moicCompany = entryEquity > 0 ? (curEquity / entryEquity).toFixed(2) : '1.00';

                return (
                  <tr key={deal.id} className="hover:bg-slate-800/40 transition-colors group">
                    <td className="py-3 px-3 font-sans">
                      <div className="font-semibold text-slate-100 group-hover:text-amber-300 transition-colors">
                        {deal.companyName}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Lead: {deal.leadPartner} • {deal.headcount || 450} FTEs
                      </div>
                    </td>

                    <td className="py-3 px-2 font-sans">
                      <div className="flex items-center gap-1">
                        <span 
                          className="w-2 h-2 rounded-full shrink-0" 
                          style={{ backgroundColor: SECTOR_COLORS[deal.sector] || '#94a3b8' }}
                        />
                        <span className="text-slate-300 text-[11px] font-medium">{deal.sector}</span>
                      </div>
                      <div className="text-[11px] text-slate-400">{deal.city}, {deal.country}</div>
                    </td>

                    <td className="py-3 px-2 font-sans text-slate-400 text-[11px]">
                      {deal.acquisitionDate || deal.createdDate}
                    </td>

                    <td className="py-3 px-2 text-right text-slate-200">
                      €{deal.revenue.toFixed(1)}M
                    </td>

                    <td className="py-3 px-2 text-right">
                      <span className="text-emerald-400 font-semibold">€{deal.ebitda.toFixed(1)}M</span>
                      <span className="text-slate-400 text-[10px] block">({deal.ebitdaMargin.toFixed(1)}%)</span>
                    </td>

                    <td className="py-3 px-2 text-right text-slate-400">
                      €{entryEV.toFixed(1)}M
                    </td>

                    <td className="py-3 px-2 text-right text-amber-300 font-semibold">
                      €{curEV.toFixed(1)}M
                      {appreciation > 0 && (
                        <span className="text-emerald-400 text-[10px] block">
                          +€{appreciation.toFixed(1)}M
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-2 text-right text-slate-300">
                      €{(deal.currentNetDebt || 0).toFixed(1)}M
                    </td>

                    <td className="py-3 px-2 text-right text-sky-300 font-bold">
                      €{curEquity.toFixed(1)}M
                      <span className="text-slate-400 text-[10px] block font-normal font-sans">
                        {moicCompany}x MOIC
                      </span>
                    </td>

                    <td className="py-3 px-2 text-right text-emerald-400 font-semibold">
                      {deal.targetIRR.toFixed(1)}%
                    </td>

                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => {
                          onSelectDeal(deal.id);
                          onNavigateToTab('PORTFOLIO_DIGITAL_TWINS');
                        }}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-slate-700 hover:border-amber-500/40 text-[11px] font-medium transition-colors cursor-pointer"
                      >
                        Digital Twin
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pipeline Snapshot & Geographic Footprint */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Deal Pipeline Sourcing Funnel */}
        <div className="lg:col-span-2 bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display font-bold text-base text-slate-100">Active Deal Pipeline & Sourcing Funnel</h2>
              <p className="text-xs text-slate-400">{pipelineDeals.length} qualified opportunities under institutional review</p>
            </div>
            <button
              onClick={() => onNavigateToTab('DEAL_PIPELINE')}
              className="text-xs text-amber-400 hover:text-amber-300 font-medium"
            >
              View Full Pipeline &rarr;
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {pipelineDeals.slice(0, 4).map((deal) => (
              <div 
                key={deal.id} 
                className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-amber-500/40 transition-colors cursor-pointer"
                onClick={() => {
                  onSelectDeal(deal.id);
                  onNavigateToTab('INVESTMENT_COMMITTEE');
                }}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">
                    {deal.stage}
                  </span>
                  <span className="text-xs font-mono-num text-slate-400">
                    Target IRR: <strong className="text-emerald-400">{deal.targetIRR}%</strong>
                  </span>
                </div>

                <div className="mt-2">
                  <h3 className="font-bold text-sm text-slate-100 truncate">{deal.companyName}</h3>
                  <p className="text-xs text-slate-400">{deal.sector} • {deal.city}, {deal.country}</p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono-num">
                  <div>
                    <span className="text-slate-500 text-[10px] uppercase block">Valuation (EV)</span>
                    <span className="text-slate-200 font-semibold">€{deal.proposedValuationEV}M</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] uppercase block">EBITDA</span>
                    <span className="text-slate-200">€{deal.ebitda}M</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] uppercase block">Screen Score</span>
                    <span className="text-amber-400 font-bold">{deal.screeningScorecard.overallScore}/100</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Geographic Direct Investment Exposure */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display font-bold text-base text-slate-100">Geographic Exposure</h2>
              <p className="text-xs text-slate-400">Direct asset deployment by country</p>
            </div>
            <button
              onClick={() => onNavigateToTab('GEO_INVESTMENT_MAP')}
              className="text-xs text-amber-400 hover:text-amber-300 font-medium"
            >
              Interactive Map &rarr;
            </button>
          </div>

          <div className="space-y-3 font-mono-num">
            {geoData.map((item) => (
              <div key={item.country} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-sans font-medium text-slate-200">{item.country}</span>
                  <span className="text-slate-300">€{item.value}M ({item.pct}%)</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full" 
                    style={{ width: `${item.pct}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Fully compliant with LP Agreement Single-Country maximum exposure limits (&lt;35%).</span>
          </div>
        </div>

      </div>
    </div>
  );
};
