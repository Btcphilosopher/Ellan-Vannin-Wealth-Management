import React, { useState } from 'react';
import { Fund, CapitalCallNotice, LimitedPartner } from '../types';
import { auditLogger } from '../services/auditLogger';
import { 
  X, 
  Coins, 
  DollarSign, 
  Calendar, 
  FileText, 
  Send, 
  CheckCircle,
  Building2
} from 'lucide-react';

interface NewCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  fund: Fund;
  lps: LimitedPartner[];
  onIssueCall: (notice: CapitalCallNotice) => void;
  activeRole: string;
}

export const NewCapitalCallModal: React.FC<NewCallModalProps> = ({
  isOpen,
  onClose,
  fund,
  lps,
  onIssueCall,
  activeRole
}) => {
  if (!isOpen) return null;

  const [callNumber, setCallNumber] = useState<number>(5);
  const [totalAmount, setTotalAmount] = useState<number>(25.0);
  const [purpose, setPurpose] = useState('Acquisition equity check for Project Apex & follow-on capex');
  const [dueDate, setDueDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 10);
    return d.toISOString().split('T')[0];
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const lpBreakdown = lps.map(lp => ({
      lpId: lp.id,
      lpName: lp.name,
      amount: Number(((lp.commitmentAmount / fund.size) * totalAmount).toFixed(2)),
      paidStatus: 'PENDING' as const
    }));

    const newNotice: CapitalCallNotice = {
      id: `call-${Date.now()}`,
      callNumber,
      fundId: fund.id,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate,
      totalAmount,
      purpose,
      status: 'ISSUED',
      lpBreakdown
    };

    onIssueCall(newNotice);
    auditLogger.log(
      'CAPITAL_CALL_ISSUED',
      `Capital Call #${callNumber} issued for €${totalAmount}M to ${lps.length} LPs (${purpose})`,
      activeRole,
      { callNumber, totalAmount, dueDate }
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl w-full max-w-xl overflow-hidden font-mono-num text-xs">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Coins className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-display text-base font-bold text-slate-100 font-sans">
                Issue Formal ILPA Capital Drawdown Notice
              </h2>
              <p className="text-[11px] text-slate-400 font-sans">
                Issue binding capital call to institutional LPs in {fund.name}.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Call Sequence Number</label>
              <input
                type="number"
                value={callNumber}
                onChange={(e) => setCallNumber(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Total Drawdown (€ Millions)</label>
              <input
                type="number"
                step="0.5"
                value={totalAmount}
                onChange={(e) => setTotalAmount(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-emerald-400 font-bold focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-300 font-sans font-semibold block mb-1">Settlement / Due Date (10 Business Days)</label>
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div>
            <label className="text-slate-300 font-sans font-semibold block mb-1">Call Purpose & Investment Allocation</label>
            <textarea
              rows={3}
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-100 focus:outline-none focus:border-amber-400 text-xs"
            />
          </div>

          {/* LP Pro-Rata Preview */}
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <span className="font-sans font-bold text-slate-300 block text-[11px]">LP Allocation Pro-Rata Preview:</span>
            <div className="max-h-28 overflow-y-auto space-y-1 pr-1 text-[11px] text-slate-400">
              {lps.map(lp => (
                <div key={lp.id} className="flex justify-between">
                  <span className="truncate max-w-[220px] font-sans">{lp.name}</span>
                  <span className="text-slate-200 font-bold">€{((lp.commitmentAmount / fund.size) * totalAmount).toFixed(2)}M</span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3 font-sans">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 cursor-pointer font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 text-slate-950 font-bold shadow-lg shadow-emerald-950/40 cursor-pointer flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" /> Dispatch ILPA Notice
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
