import React, { useState } from 'react';
import { Deal, ValuationModel } from '../types';
import { calculateDCF } from '../services/financialEngine';
import { 
  Calculator, 
  TrendingUp, 
  Layers, 
  Scale, 
  Sliders, 
  BarChart2, 
  CheckCircle,
  HelpCircle
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Cell 
} from 'recharts';

interface ValuationSuiteProps {
  deal: Deal;
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
  onUpdateDeal: (updated: Deal) => void;
}

export const ValuationSuite: React.FC<ValuationSuiteProps> = ({
  deal,
  deals,
  onSelectDeal,
  onUpdateDeal
}) => {
  const [activeMethod, setActiveMethod] = useState<'DCF' | 'COMPS' | 'PRECEDENT' | 'SOTP' | 'FOOTBALL_FIELD'>('DCF');
  const [scenario, setScenario] = useState<'LOW' | 'BASE' | 'HIGH'>('BASE');

  // Interactive DCF inputs
  const [wacc, setWacc] = useState<number>(deal.valuationModel?.wacc || 8.5);
  const [terminalGrowth, setTerminalGrowth] = useState<number>(deal.valuationModel?.terminalGrowthRate || 2.0);
  const [taxRate, setTaxRate] = useState<number>(deal.valuationModel?.taxRate || 22.0);

  // Projected FCF array (5 years)
  const baseEbitda = deal.ebitda;
  const growthMultiplier = scenario === 'HIGH' ? 1.10 : scenario === 'LOW' ? 1.03 : 1.06;
  const projectedFCFs = [
    baseEbitda * 0.70 * Math.pow(growthMultiplier, 1),
    baseEbitda * 0.70 * Math.pow(growthMultiplier, 2),
    baseEbitda * 0.70 * Math.pow(growthMultiplier, 3),
    baseEbitda * 0.70 * Math.pow(growthMultiplier, 4),
    baseEbitda * 0.70 * Math.pow(growthMultiplier, 5)
  ];

  // Perform dynamic DCF calculation
  const dcfResult = calculateDCF(projectedFCFs, wacc / 100, terminalGrowth / 100);
  const impliedEnterpriseValue = dcfResult.enterpriseValue;
  const impliedEquityValue = impliedEnterpriseValue - (deal.currentNetDebt || 0);
  const impliedEbitdaMultiple = impliedEnterpriseValue / (deal.ebitda || 1);

  // Trading Comps valuation average
  const compsAverageMultiple = 11.2;
  const compsImpliedEV = deal.ebitda * compsAverageMultiple;

  // Precedent transactions average
  const precedentAverageMultiple = 12.0;
  const precedentImpliedEV = deal.ebitda * precedentAverageMultiple;

  // SOTP Implied EV
  const sotpImpliedEV = deal.valuationModel?.sotpSegments?.reduce((s, seg) => s + seg.segmentEV, 0) || (deal.proposedValuationEV * 1.05);

  // Football Field Chart Data
  const footballFieldData = [
    { name: 'DCF (WACC 8.5%)', min: impliedEnterpriseValue * 0.9, max: impliedEnterpriseValue * 1.15, mid: impliedEnterpriseValue },
    { name: 'Trading Comps', min: compsImpliedEV * 0.85, max: compsImpliedEV * 1.1, mid: compsImpliedEV },
    { name: 'Precedent M&A', min: precedentImpliedEV * 0.9, max: precedentImpliedEV * 1.15, mid: precedentImpliedEV },
    { name: 'SOTP Valuation', min: sotpImpliedEV * 0.92, max: sotpImpliedEV * 1.08, mid: sotpImpliedEV },
    { name: 'Agreed Entry Price', min: deal.proposedValuationEV, max: deal.proposedValuationEV, mid: deal.proposedValuationEV }
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono-num text-[10px] font-bold uppercase">
              Valuation Lab
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Target: <strong className="text-slate-200">{deal.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <Calculator className="w-6 h-6 text-amber-400" />
            Institutional Valuation & Multiple Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Triangulated valuation suite: Multi-stage DCF, Trading Comps, Precedent M&A Transactions, and Sum-of-the-Parts (SOTP).
          </p>
        </div>

        {/* Deal Quick Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Target:</label>
          <select
            value={deal.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {deals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName} (EV: €{d.proposedValuationEV}M)</option>
            ))}
          </select>
        </div>
      </div>

      {/* Valuation Methodology Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveMethod('DCF')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
              activeMethod === 'DCF'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" /> Discounted Cash Flow (DCF)
          </button>

          <button
            onClick={() => setActiveMethod('COMPS')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
              activeMethod === 'COMPS'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Scale className="w-3.5 h-3.5" /> Public Trading Comparables
          </button>

          <button
            onClick={() => setActiveMethod('PRECEDENT')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
              activeMethod === 'PRECEDENT'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" /> Precedent M&A Transactions
          </button>

          <button
            onClick={() => setActiveMethod('SOTP')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
              activeMethod === 'SOTP'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" /> Sum-of-the-Parts (SOTP)
          </button>

          <button
            onClick={() => setActiveMethod('FOOTBALL_FIELD')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
              activeMethod === 'FOOTBALL_FIELD'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5 text-amber-400" /> Football Field Triangulation
          </button>
        </div>

        {/* Low / Base / High Scenario Toggle */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setScenario('LOW')}
            className={`px-2.5 py-1 rounded font-semibold cursor-pointer ${
              scenario === 'LOW' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'text-slate-400'
            }`}
          >
            Downside (Low)
          </button>
          <button
            onClick={() => setScenario('BASE')}
            className={`px-2.5 py-1 rounded font-semibold cursor-pointer ${
              scenario === 'BASE' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'text-slate-400'
            }`}
          >
            Base Case
          </button>
          <button
            onClick={() => setScenario('HIGH')}
            className={`px-2.5 py-1 rounded font-semibold cursor-pointer ${
              scenario === 'HIGH' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'text-slate-400'
            }`}
          >
            Upside (High)
          </button>
        </div>
      </div>

      {/* Tab Content 1: DCF */}
      {activeMethod === 'DCF' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* DCF Parameter Sliders */}
          <div className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl">
            <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              WACC & Growth Calibration
            </h3>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">Weighted Average Cost of Capital (WACC)</span>
                  <span className="font-mono-num font-bold text-amber-400">{wacc.toFixed(2)}%</span>
                </div>
                <input
                  type="range"
                  min="6.0"
                  max="14.0"
                  step="0.25"
                  value={wacc}
                  onChange={(e) => setWacc(Number(e.target.value))}
                  className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono-num">
                  <span>6.0% (Low Risk)</span>
                  <span>14.0% (Distressed)</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">Terminal Growth Rate (g)</span>
                  <span className="font-mono-num font-bold text-emerald-400">{terminalGrowth.toFixed(2)}%</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="4.0"
                  step="0.25"
                  value={terminalGrowth}
                  onChange={(e) => setTerminalGrowth(Number(e.target.value))}
                  className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono-num">
                  <span>1.0% (GDP Floor)</span>
                  <span>4.0% (Secular Growth)</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">Corporate Effective Tax Rate</span>
                  <span className="font-mono-num font-bold text-slate-200">{taxRate.toFixed(1)}%</span>
                </div>
                <input
                  type="range"
                  min="15.0"
                  max="30.0"
                  step="1.0"
                  value={taxRate}
                  onChange={(e) => setTaxRate(Number(e.target.value))}
                  className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 space-y-1.5">
              <div className="flex justify-between font-mono-num">
                <span>PV of 5-Yr Forecast:</span>
                <span className="text-slate-200">€{dcfResult.pvOfFCF.toFixed(1)}M ({(dcfResult.pvOfFCF / (dcfResult.enterpriseValue || 1) * 100).toFixed(0)}%)</span>
              </div>
              <div className="flex justify-between font-mono-num">
                <span>PV of Terminal Value:</span>
                <span className="text-slate-200">€{dcfResult.pvTerminalValue.toFixed(1)}M ({(dcfResult.pvTerminalValue / (dcfResult.enterpriseValue || 1) * 100).toFixed(0)}%)</span>
              </div>
            </div>
          </div>

          {/* DCF Output Summary */}
          <div className="lg:col-span-2 space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="font-display font-bold text-base text-slate-100">
                    DCF Valuation Summary ({scenario} Scenario)
                  </h3>
                  <p className="text-xs text-slate-400">Gordon Growth Model Terminal Value methodology</p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 uppercase block">Agreed Entry EV</span>
                  <span className="text-xs font-mono-num font-bold text-slate-300">€{deal.proposedValuationEV}M</span>
                </div>
              </div>

              {/* Big KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4 font-mono-num">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-xs font-sans block">Implied Enterprise Value</span>
                  <span className="text-2xl font-bold text-amber-300 mt-1 block">
                    €{impliedEnterpriseValue.toFixed(1)}M
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {impliedEbitdaMultiple.toFixed(2)}x EBITDA Multiple
                  </span>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-xs font-sans block">Implied Equity Value</span>
                  <span className="text-2xl font-bold text-emerald-400 mt-1 block">
                    €{impliedEquityValue.toFixed(1)}M
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Net Debt: €{(deal.currentNetDebt || 0).toFixed(1)}M
                  </span>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-xs font-sans block">Entry Premium / Discount</span>
                  <span className={`text-2xl font-bold mt-1 block ${
                    deal.proposedValuationEV <= impliedEnterpriseValue ? 'text-emerald-400' : 'text-rose-400'
                  }`}>
                    {deal.proposedValuationEV <= impliedEnterpriseValue ? '-' : '+'}
                    {Math.abs(((deal.proposedValuationEV - impliedEnterpriseValue) / impliedEnterpriseValue) * 100).toFixed(1)}%
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {deal.proposedValuationEV <= impliedEnterpriseValue ? 'Acquisition at discount' : 'Acquisition at premium'}
                  </span>
                </div>
              </div>

              {/* 5-Year Forecast Table */}
              <div className="mt-5 space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  5-Year Projected Free Cash Flows (€M)
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono-num">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 text-[10px]">
                        <th className="py-2 px-3">Year</th>
                        <th className="py-2 px-2 text-right">Year 1</th>
                        <th className="py-2 px-2 text-right">Year 2</th>
                        <th className="py-2 px-2 text-right">Year 3</th>
                        <th className="py-2 px-2 text-right">Year 4</th>
                        <th className="py-2 px-2 text-right">Year 5</th>
                        <th className="py-2 px-3 text-right">Terminal Value</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      <tr>
                        <td className="py-2.5 px-3 font-sans font-medium text-slate-300">Unlevered FCF</td>
                        {projectedFCFs.map((fcf, i) => (
                          <td key={i} className="py-2.5 px-2 text-right text-emerald-400 font-semibold">
                            €{fcf.toFixed(1)}M
                          </td>
                        ))}
                        <td className="py-2.5 px-3 text-right text-amber-300 font-bold">
                          €{dcfResult.terminalValue.toFixed(1)}M
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>DCF sensitivity adheres to EVWM conservative hurdle rate and long-term GDP floor.</span>
            </div>
          </div>

        </div>
      )}

      {/* Tab Content 2: Public Trading Comps */}
      {activeMethod === 'COMPS' && (
        <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="font-display font-bold text-base text-slate-100">
                Public Market Trading Comparables
              </h3>
              <p className="text-xs text-slate-400">Peer group multiple benchmarking (LTM & NTM EV/EBITDA)</p>
            </div>
            <span className="font-mono-num text-xs font-bold text-amber-400">
              Peer Mean: {compsAverageMultiple}x EV/EBITDA
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono-num">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                  <th className="py-2.5 px-3">Peer Company</th>
                  <th className="py-2.5 px-2">Ticker / Exch</th>
                  <th className="py-2.5 px-2 text-right">Market Cap</th>
                  <th className="py-2.5 px-2 text-right">EV</th>
                  <th className="py-2.5 px-2 text-right">EV/Revenue</th>
                  <th className="py-2.5 px-2 text-right">EV/EBITDA</th>
                  <th className="py-2.5 px-2 text-right">EBITDA Margin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {deal.valuationModel?.tradingComps?.map((comp, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-sans font-medium text-slate-200">{comp.peerName}</td>
                    <td className="py-3 px-2 text-slate-400">{comp.ticker}</td>
                    <td className="py-3 px-2 text-right text-slate-300">€{comp.marketCap}M</td>
                    <td className="py-3 px-2 text-right text-slate-300">€{comp.ev}M</td>
                    <td className="py-3 px-2 text-right text-slate-300">{comp.evRevenue.toFixed(1)}x</td>
                    <td className="py-3 px-2 text-right font-bold text-amber-400">{comp.evEbitda.toFixed(1)}x</td>
                    <td className="py-3 px-2 text-right text-emerald-400">{comp.ebitdaMargin.toFixed(1)}%</td>
                  </tr>
                )) || (
                  <tr>
                    <td colSpan={7} className="py-4 text-center text-slate-500 font-sans">
                      No public peers configured.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab Content 5: Football Field Triangulation */}
      {activeMethod === 'FOOTBALL_FIELD' && (
        <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="font-display font-bold text-base text-slate-100">
                Valuation Football Field Range Comparison
              </h3>
              <p className="text-xs text-slate-400">Comprehensive triangulation across all 4 underwriting methodologies (€M Enterprise Value)</p>
            </div>
            <div className="text-right">
              <span className="text-xs text-amber-400 font-mono-num font-bold">
                Agreed Entry Price: €{deal.proposedValuationEV}M
              </span>
            </div>
          </div>

          <div className="space-y-4 font-mono-num">
            {footballFieldData.map((item) => {
              const minRange = 100;
              const maxRange = 500;
              const leftPct = ((item.min - minRange) / (maxRange - minRange)) * 100;
              const widthPct = Math.max(3, ((item.max - item.min) / (maxRange - minRange)) * 100);

              return (
                <div key={item.name} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-sans">
                    <span className="font-semibold text-slate-200">{item.name}</span>
                    <span className="text-slate-400 font-mono-num">
                      €{item.min.toFixed(1)}M – €{item.max.toFixed(1)}M (Mid: €{item.mid.toFixed(1)}M)
                    </span>
                  </div>

                  <div className="relative h-6 bg-slate-950 rounded-lg border border-slate-800 overflow-hidden">
                    {/* Range bar */}
                    <div 
                      className="absolute top-1 bottom-1 bg-gradient-to-r from-amber-500/60 to-amber-400/90 rounded border border-amber-300 flex items-center justify-center text-[10px] font-bold text-slate-950 shadow"
                      style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                    >
                      €{item.mid.toFixed(0)}M
                    </div>

                    {/* Agreed Entry Price Marker */}
                    <div 
                      className="absolute top-0 bottom-0 w-0.5 bg-rose-500 z-10"
                      style={{ left: `${((deal.proposedValuationEV - minRange) / (maxRange - minRange)) * 100}%` }}
                      title={`Agreed Entry Price: €${deal.proposedValuationEV}M`}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 flex items-center gap-2 text-xs text-slate-400">
            <span className="w-3 h-0.5 bg-rose-500"></span>
            <span>Red vertical line marks the sponsor's negotiated entry Enterprise Value (€{deal.proposedValuationEV}M).</span>
          </div>
        </div>
      )}
    </div>
  );
};
