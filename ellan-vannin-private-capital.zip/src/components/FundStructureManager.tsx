import React, { useState } from 'react';
import { Fund, LPCommitment, Sector } from '../types';
import { 
  Landmark, 
  Settings, 
  Check, 
  ShieldCheck, 
  Coins, 
  Clock, 
  Percent, 
  Layers,
  FileCheck,
  Building,
  Plus
} from 'lucide-react';

interface FundStructureProps {
  funds?: Fund[];
  selectedFund?: Fund;
  fund?: Fund;
  onUpdateFund?: (updated: Fund) => void;
  onSelectFund?: (fund: Fund) => void;
  lpCommitments?: LPCommitment[];
  lps?: any[];
}

const ALL_SECTORS: Sector[] = [
  'INFRASTRUCTURE',
  'ENERGY',
  'INDUSTRIALS',
  'TECHNOLOGY',
  'HEALTHCARE',
  'FOOD',
  'AGRICULTURE',
  'REAL ESTATE',
  'TRANSPORT',
  'LOGISTICS',
  'FINANCIAL SERVICES',
  'CONSUMER'
];

export const FundStructureManager: React.FC<FundStructureProps> = ({
  funds = [],
  selectedFund: propSelectedFund,
  fund: propFund,
  onUpdateFund,
  onSelectFund,
  lpCommitments,
  lps
}) => {
  const activeFund = propFund || propSelectedFund || funds[0] || { id: 'f-1', name: 'EVWM Flagship Fund I', sectors: [] };
  const [formData, setFormData] = useState<Fund>({ ...activeFund, sectors: activeFund.sectors || [] });
  const [savedSuccess, setSavedSuccess] = useState(false);

  const lpsList = lpCommitments || lps || [];
  const fundLPs = lpsList.filter(lp => lp.fundId === activeFund?.id || !lp.fundId);
  const totalLpCommitted = fundLPs.reduce((s, lp) => s + (lp.totalCommitment || lp.commitmentAmount || 0), 0);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateFund?.(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const toggleSector = (sector: Sector) => {
    const sectors = formData.sectors || [];
    if (sectors.includes(sector)) {
      setFormData({
        ...formData,
        sectors: sectors.filter(s => s !== sector)
      });
    } else {
      setFormData({
        ...formData,
        sectors: [...sectors, sector]
      });
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Multi-Fund Selector Cards */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-100 flex items-center gap-2">
            <Landmark className="w-6 h-6 text-amber-400" />
            Fund Structure & Legal Mandate Engine
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Configure institutional LPA parameters, waterfall terms, hurdle rate, GP commitments, and investment period covenants.
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold animate-in fade-in">
            <Check className="w-4 h-4" /> LPA Configuration Persisted
          </div>
        )}
      </div>

      {/* Fund Selectors */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {funds.map((f) => {
          const isSelected = f.id === activeFund?.id;
          return (
            <button
              key={f.id}
              onClick={() => {
                onSelectFund?.(f);
                setFormData({ ...f });
              }}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                isSelected 
                  ? 'bg-amber-500/15 border-amber-500/50 shadow-lg shadow-amber-950/40' 
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-800/60'
              }`}
            >
              <div className="text-[10px] uppercase font-bold text-amber-400">
                Vintage {f.vintage}
              </div>
              <div className="font-bold text-xs text-slate-100 mt-1 line-clamp-1">
                {f.name}
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono-num text-slate-400 mt-2">
                <span>Size: €{f.fundSize}M</span>
                <span className="text-emerald-400 font-semibold">{f.targetGrossIRR}% IRR</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Config Form & LP Register */}
      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Form Parameters */}
        <div className="lg:col-span-2 space-y-6 bg-slate-900/80 p-6 rounded-2xl border border-slate-800/80 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
              <Settings className="w-4 h-4 text-amber-400" />
              LPA Economic & Commercial Terms
            </h2>
            <span className="text-xs text-slate-400 font-mono-num">
              Fund Identifier: <strong className="text-slate-200">{formData.id}</strong>
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Fund Legal Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Base Currency</label>
              <input
                type="text"
                value={formData.currency}
                onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Target Fund Size (€M)</label>
              <input
                type="number"
                value={formData.fundSize}
                onChange={(e) => setFormData({ ...formData, fundSize: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Committed Capital (€M)</label>
              <input
                type="number"
                value={formData.committedCapital}
                onChange={(e) => setFormData({ ...formData, committedCapital: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Investment Period (Years)</label>
              <input
                type="number"
                step="0.5"
                value={formData.investmentPeriodYears}
                onChange={(e) => setFormData({ ...formData, investmentPeriodYears: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Fund Legal Life (Years)</label>
              <input
                type="number"
                value={formData.fundLifeYears}
                onChange={(e) => setFormData({ ...formData, fundLifeYears: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Management Fee (%)</label>
              <input
                type="number"
                step="0.05"
                value={formData.managementFeePercent}
                onChange={(e) => setFormData({ ...formData, managementFeePercent: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Carried Interest (%)</label>
              <input
                type="number"
                step="0.5"
                value={formData.carriedInterestPercent}
                onChange={(e) => setFormData({ ...formData, carriedInterestPercent: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Preferred Return / Hurdle Rate (%)</label>
              <input
                type="number"
                step="0.25"
                value={formData.preferredReturnPercent}
                onChange={(e) => setFormData({ ...formData, preferredReturnPercent: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">GP Commitment Alignment (%)</label>
              <input
                type="number"
                step="0.25"
                value={formData.gpCommitmentPercent}
                onChange={(e) => setFormData({ ...formData, gpCommitmentPercent: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Target Gross / Net IRR (%)</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  step="0.5"
                  value={formData.targetGrossIRR}
                  onChange={(e) => setFormData({ ...formData, targetGrossIRR: Number(e.target.value) })}
                  className="w-1/2 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100"
                  placeholder="Gross"
                />
                <input
                  type="number"
                  step="0.5"
                  value={formData.targetNetIRR}
                  onChange={(e) => setFormData({ ...formData, targetNetIRR: Number(e.target.value) })}
                  className="w-1/2 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100"
                  placeholder="Net"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Max Single Asset Exposure (%)</label>
              <input
                type="number"
                step="1.0"
                value={formData.maxSingleDealExposurePercent}
                onChange={(e) => setFormData({ ...formData, maxSingleDealExposurePercent: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono-num text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

          </div>

          {/* Sectors Mandate Selection */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <label className="text-xs font-semibold text-slate-300 block">
              Authorized Sector Strategy Mandates
            </label>
            <div className="flex flex-wrap gap-1.5">
              {ALL_SECTORS.map((sector) => {
                const isSelected = formData.sectors.includes(sector);
                return (
                  <button
                    type="button"
                    key={sector}
                    onClick={() => toggleSector(sector)}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-slate-950 text-slate-500 border border-slate-800 hover:text-slate-300'
                    }`}
                  >
                    {sector}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Reinvestment policy toggle */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
            <div>
              <div className="text-xs font-semibold text-slate-200">Reinvestment of Realised Capital (Recycling)</div>
              <div className="text-[11px] text-slate-400">Permits recycling of capital returned during first 3 years of investment period.</div>
            </div>
            <input
              type="checkbox"
              checked={formData.reinvestmentAllowed}
              onChange={(e) => setFormData({ ...formData, reinvestmentAllowed: e.target.checked })}
              className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
            />
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold text-xs shadow-lg shadow-amber-950/40 transition-all cursor-pointer"
            >
              Save LPA Terms
            </button>
          </div>
        </div>

        {/* Right Col: LP Commitment Registry */}
        <div className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
                <Building className="w-4 h-4 text-amber-400" />
                LP Commitment Registry
              </h2>
              <p className="text-[11px] text-slate-400">Total: €{totalLpCommitted.toFixed(1)}M across {fundLPs.length} institutional partners</p>
            </div>
          </div>

          <div className="space-y-2.5 max-h-[520px] overflow-y-auto pr-1">
            {fundLPs.map((lp) => {
              const callPct = ((lp.calledCapital / lp.totalCommitment) * 100).toFixed(0);
              return (
                <div key={lp.id} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-semibold text-xs text-slate-100">{lp.lpName}</div>
                      <div className="text-[10px] text-amber-400 font-medium">{lp.lpType} • {lp.domicile}</div>
                    </div>
                    <span className="font-mono-num text-xs font-bold text-slate-200">
                      €{lp.totalCommitment.toFixed(1)}M
                    </span>
                  </div>

                  <div className="space-y-1 font-mono-num text-[11px]">
                    <div className="flex justify-between text-slate-400 text-[10px]">
                      <span>Called: €{lp.calledCapital.toFixed(1)}M ({callPct}%)</span>
                      <span className="text-amber-400">Uncalled: €{lp.uncalledCapital.toFixed(1)}M</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: `${callPct}%` }} />
                    </div>
                    <div className="flex justify-between text-slate-500 text-[10px] pt-1">
                      <span>Distributions: €{lp.distributionsReceived.toFixed(1)}M</span>
                      <span>Last Call: {lp.lastCallDate}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </form>
    </div>
  );
};
