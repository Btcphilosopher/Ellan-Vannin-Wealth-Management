import React, { useState } from 'react';
import { Deal, DealStage, Sector } from '../types';
import { 
  GitPullRequest, 
  Search, 
  Filter, 
  ArrowRight, 
  Building2, 
  DollarSign, 
  TrendingUp, 
  ChevronRight,
  SlidersHorizontal,
  LayoutGrid,
  List,
  Sparkles,
  MapPin
} from 'lucide-react';

interface PipelineProps {
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
  onUpdateDealStage: (dealId: string, newStage: DealStage) => void;
  onNavigateToTab: (tab: any) => void;
  onOpenNewDealModal: () => void;
}

const ALL_STAGES: DealStage[] = [
  'LEAD',
  'SCREENING',
  'INITIAL REVIEW',
  'NDA',
  'DUE DILIGENCE',
  'INVESTMENT COMMITTEE',
  'TERM SHEET',
  'NEGOTIATION',
  'SIGNED',
  'CLOSED',
  'PORTFOLIO',
  'EXIT'
];

export const DealPipelineView: React.FC<PipelineProps> = ({
  deals,
  onSelectDeal,
  onUpdateDealStage,
  onNavigateToTab,
  onOpenNewDealModal
}) => {
  const [viewMode, setViewMode] = useState<'KANBAN' | 'TABLE'>('KANBAN');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [selectedStageFilter, setSelectedStageFilter] = useState<string>('ALL');

  const filteredDeals = deals.filter(d => {
    const matchesSearch = d.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          d.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          d.seller.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSector = selectedSector === 'ALL' || d.sector === selectedSector;
    const matchesStage = selectedStageFilter === 'ALL' || d.stage === selectedStageFilter;
    return matchesSearch && matchesSector && matchesStage;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Top Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-100 flex items-center gap-2">
            <GitPullRequest className="w-6 h-6 text-amber-400" />
            Direct Deal Sourcing & Pipeline Lifecycle Engine
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Tracking {deals.length} total direct investment opportunities across all 12 institutional lifecycle stages.
          </p>
        </div>

        {/* View mode toggle & Action buttons */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="bg-slate-900 p-1 rounded-lg border border-slate-800 flex items-center gap-1">
            <button
              onClick={() => setViewMode('KANBAN')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'KANBAN' 
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" /> Kanban Pipeline
            </button>
            <button
              onClick={() => setViewMode('TABLE')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'TABLE' 
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <List className="w-3.5 h-3.5" /> Matrix Ledger
            </button>
          </div>

          <button
            onClick={onOpenNewDealModal}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold text-xs shadow-lg shadow-amber-950/40 cursor-pointer"
          >
            + Originate Deal
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            placeholder="Search company, seller, adviser, or city..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950/80 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        <div className="flex items-center gap-2">
          {/* Sector Filter */}
          <select
            value={selectedSector}
            onChange={(e) => setSelectedSector(e.target.value)}
            aria-label="Filter by Sector"
            className="bg-slate-950 border border-slate-800 text-slate-300 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            <option value="ALL">All Sectors ({deals.length})</option>
            {Array.from(new Set(deals.map(d => d.sector))).map(sec => (
              <option key={sec} value={sec}>{sec}</option>
            ))}
          </select>

          {/* Quick Clear */}
          {(searchQuery || selectedSector !== 'ALL') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedSector('ALL');
              }}
              className="text-xs text-amber-400 hover:text-amber-300 px-2 py-1"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Kanban View */}
      {viewMode === 'KANBAN' ? (
        <div className="flex gap-4 overflow-x-auto pb-4 pt-1">
          {ALL_STAGES.map((stage) => {
            const stageDeals = filteredDeals.filter(d => d.stage === stage);
            const totalStageEV = stageDeals.reduce((sum, d) => sum + d.proposedValuationEV, 0);

            return (
              <div 
                key={stage}
                className="w-80 shrink-0 bg-slate-900/60 rounded-xl border border-slate-800/80 flex flex-col max-h-[750px]"
              >
                {/* Stage Header */}
                <div className="p-3 border-b border-slate-800 bg-slate-900/90 rounded-t-xl">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[11px] uppercase tracking-wider text-amber-300">
                      {stage}
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono-num text-[10px] font-bold">
                      {stageDeals.length}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono-num mt-1">
                    Pipeline EV: €{totalStageEV.toFixed(1)}M
                  </div>
                </div>

                {/* Deal Cards in Stage */}
                <div className="p-2.5 space-y-2.5 overflow-y-auto flex-1">
                  {stageDeals.map((deal) => (
                    <div
                      key={deal.id}
                      onClick={() => {
                        onSelectDeal(deal.id);
                        onNavigateToTab('DUE_DILIGENCE_SUITE');
                      }}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-500/50 hover:bg-slate-900/90 transition-all cursor-pointer shadow-md group"
                    >
                      <div className="flex items-start justify-between">
                        <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                          {deal.sector}
                        </span>
                        <span className="text-[11px] font-mono-num font-bold text-amber-400">
                          Score: {deal.screeningScorecard.overallScore}/100
                        </span>
                      </div>

                      <h3 className="font-bold text-xs text-slate-100 group-hover:text-amber-200 mt-2 truncate">
                        {deal.companyName}
                      </h3>

                      <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                        <span>{deal.city}, {deal.country}</span>
                      </div>

                      <div className="mt-3 pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-1 text-[11px] font-mono-num">
                        <div>
                          <span className="text-slate-500 text-[10px] block">Revenue / EBITDA</span>
                          <span className="text-slate-200">€{deal.revenue}M / <strong className="text-emerald-400">€{deal.ebitda}M</strong></span>
                        </div>
                        <div className="text-right">
                          <span className="text-slate-500 text-[10px] block">Valuation (EV)</span>
                          <span className="text-amber-300 font-semibold">€{deal.proposedValuationEV}M</span>
                        </div>
                      </div>

                      <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                        <span>Target: <strong className="text-emerald-400 font-mono-num">{deal.targetIRR}% IRR</strong></span>
                        <span>{deal.targetMOIC}x MOIC</span>
                      </div>

                      {/* Stage Mover Selector */}
                      <div 
                        className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <span className="text-[10px] text-slate-500">Move:</span>
                        <select
                          value={deal.stage}
                          onChange={(e) => onUpdateDealStage(deal.id, e.target.value as DealStage)}
                          className="bg-slate-900 border border-slate-800 text-slate-300 text-[10px] px-1.5 py-0.5 rounded focus:outline-none focus:border-amber-400"
                        >
                          {ALL_STAGES.map(s => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  ))}

                  {stageDeals.length === 0 && (
                    <div className="text-center py-8 text-slate-600 text-xs italic">
                      No deals at this stage
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Tabular Matrix Ledger View */
        <div className="bg-slate-900/80 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 uppercase text-[10px] font-semibold tracking-wider">
                <tr>
                  <th className="py-3 px-4">Company</th>
                  <th className="py-3 px-3">Sector & Geo</th>
                  <th className="py-3 px-3">Stage</th>
                  <th className="py-3 px-3 text-right">Revenue</th>
                  <th className="py-3 px-3 text-right">EBITDA</th>
                  <th className="py-3 px-3 text-right">Valuation (EV)</th>
                  <th className="py-3 px-3 text-right">Equity Check</th>
                  <th className="py-3 px-3 text-right">Target IRR</th>
                  <th className="py-3 px-3 text-center">Screen Score</th>
                  <th className="py-3 px-3">Seller / Adviser</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono-num">
                {filteredDeals.map((deal) => (
                  <tr 
                    key={deal.id} 
                    className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                    onClick={() => {
                      onSelectDeal(deal.id);
                      onNavigateToTab('DUE_DILIGENCE_SUITE');
                    }}
                  >
                    <td className="py-3 px-4 font-sans">
                      <div className="font-semibold text-slate-100">{deal.companyName}</div>
                      <div className="text-[11px] text-slate-400">{deal.leadPartner}</div>
                    </td>

                    <td className="py-3 px-3 font-sans">
                      <div className="text-slate-200 font-medium">{deal.sector}</div>
                      <div className="text-[11px] text-slate-400">{deal.city}, {deal.country}</div>
                    </td>

                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-sans font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                        {deal.stage}
                      </span>
                    </td>

                    <td className="py-3 px-3 text-right text-slate-200">€{deal.revenue.toFixed(1)}M</td>
                    <td className="py-3 px-3 text-right text-emerald-400 font-semibold">€{deal.ebitda.toFixed(1)}M</td>
                    <td className="py-3 px-3 text-right text-amber-300 font-bold">€{deal.proposedValuationEV.toFixed(1)}M</td>
                    <td className="py-3 px-3 text-right text-slate-300">€{deal.dealSizeEquity.toFixed(1)}M</td>
                    <td className="py-3 px-3 text-right text-emerald-400 font-semibold">{deal.targetIRR.toFixed(1)}%</td>

                    <td className="py-3 px-3 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-800 text-amber-400 border border-amber-500/30">
                        {deal.screeningScorecard.overallScore}/100
                      </span>
                    </td>

                    <td className="py-3 px-3 font-sans text-[11px] text-slate-400">
                      <div>{deal.seller}</div>
                      <div className="text-slate-500">{deal.adviser}</div>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectDeal(deal.id);
                          onNavigateToTab('INVESTMENT_COMMITTEE');
                        }}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold border border-slate-700"
                      >
                        IC Memo
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
