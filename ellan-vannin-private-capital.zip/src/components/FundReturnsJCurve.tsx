import React, { useState } from 'react';
import { Fund } from '../types';
import { calculateFundCashFlows } from '../services/financialEngine';
import { 
  LineChart as ChartIcon, 
  TrendingUp, 
  Layers, 
  DollarSign, 
  HelpCircle, 
  CheckCircle,
  Coins,
  ArrowDownRight,
  ArrowUpRight
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Legend, 
  AreaChart, 
  Area 
} from 'recharts';

interface JCurveProps {
  fund: Fund;
}

export const FundReturnsJCurve: React.FC<JCurveProps> = ({ fund }) => {
  const [targetNetIRR, setTargetNetIRR] = useState<number>(20.5);
  const [targetGrossMOIC, setTargetGrossMOIC] = useState<number>(2.4);
  const [managementFeeRate, setManagementFeeRate] = useState<number>(2.0);

  // Calculate simulated 10-year fund cash flows & J-Curve
  const cashFlowTimeline = calculateFundCashFlows(fund);

  const jCurveChartData = cashFlowTimeline.map(cf => ({
    year: `Y${cf.year}`,
    capitalCalled: Number(cf.capitalCalled.toFixed(1)),
    distributions: Number(cf.distributions.toFixed(1)),
    netCashFlow: Number(cf.netCashFlow.toFixed(1)),
    cumulativeNetCashFlow: Number(cf.cumulativeNetCashFlow.toFixed(1)),
    nav: Number(cf.nav.toFixed(1)),
    totalValue: Number((cf.cumulativeNetCashFlow + cf.nav).toFixed(1))
  }));

  const totalCalled = cashFlowTimeline.reduce((s, c) => s + c.capitalCalled, 0);
  const totalDistributed = cashFlowTimeline.reduce((s, c) => s + c.distributions, 0);
  const fundDPI = totalDistributed / (totalCalled || 1);
  const fundRVPI = (fund.nav) / (totalCalled || 1);
  const fundTVPI = fundDPI + fundRVPI;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono-num text-[10px] font-bold uppercase">
              10-Year Fund Life Cycle
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Fund: <strong className="text-slate-200">{fund.name}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <ChartIcon className="w-6 h-6 text-amber-400" />
            10-Year Fund J-Curve & Cash Flow Simulator
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Model LP capital drawdowns, value creation trough, harvesting distributions, and ILPA top-quartile benchmark tracking.
          </p>
        </div>
      </div>

      {/* Return Multiples Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono-num">
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Fund Net IRR</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">{fund.netIRR.toFixed(1)}%</span>
          <span className="text-[10px] text-emerald-400 font-sans">Top Quartile (Cambridge PE)</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Fund Net TVPI</span>
          <span className="text-2xl font-bold text-amber-300 mt-1 block">{fundTVPI.toFixed(2)}x</span>
          <span className="text-[10px] text-slate-400 font-sans">Total Value to Paid-In</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Fund DPI</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">{fundDPI.toFixed(2)}x</span>
          <span className="text-[10px] text-sky-400 font-sans">Distributed to Paid-In</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Fund RVPI</span>
          <span className="text-2xl font-bold text-slate-200 mt-1 block">{fundRVPI.toFixed(2)}x</span>
          <span className="text-[10px] text-slate-400 font-sans">Residual Value to Paid-In</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Total Capital Called</span>
          <span className="text-2xl font-bold text-slate-100 mt-1 block">€{totalCalled.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">{((totalCalled / fund.size) * 100).toFixed(0)}% of Commitment</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Total Distributed</span>
          <span className="text-2xl font-bold text-emerald-300 mt-1 block">€{totalDistributed.toFixed(1)}M</span>
          <span className="text-[10px] text-emerald-400 font-sans">Returned to LP Base</span>
        </div>
      </div>

      {/* J-Curve Chart Area */}
      <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-display font-bold text-base text-slate-100">
              Institutional J-Curve: Cumulative Net Cash Flows vs. Portfolio NAV (€M)
            </h3>
            <p className="text-xs text-slate-400">Illustrates investment trough (Y1-Y3), NAV growth (Y3-Y7), and cash distributions (Y6-Y10)</p>
          </div>
          <span className="text-xs font-mono-num text-amber-400 font-bold">10-Year Life Cycle</span>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={jCurveChartData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
              <defs>
                <linearGradient id="colorNAV" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0}/>
                </linearGradient>
                <linearGradient id="colorCum" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="year" stroke="#64748b" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '8px', fontSize: '11px' }}
                formatter={(val: any) => [`€${val}M`, '']}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
              <Area type="monotone" dataKey="nav" name="Portfolio NAV" stroke="#f59e0b" strokeWidth={2} fill="url(#colorNAV)" />
              <Area type="monotone" dataKey="cumulativeNetCashFlow" name="Cumulative LP Cash Flow (J-Curve)" stroke="#10b981" strokeWidth={2} fill="url(#colorCum)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Cash Flow Table */}
      <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-3">
        <h3 className="font-display font-bold text-base text-slate-100">
          Year-by-Year Capital Flow Schedule
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-center text-xs font-mono-num">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3 text-left font-sans">Year</th>
                <th className="py-2.5 px-2 text-right">Capital Called</th>
                <th className="py-2.5 px-2 text-right">Distributions</th>
                <th className="py-2.5 px-2 text-right">Net Flow</th>
                <th className="py-2.5 px-2 text-right">Cumulative Flow</th>
                <th className="py-2.5 px-2 text-right font-bold text-amber-400">Ending NAV</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {cashFlowTimeline.map((cf) => (
                <tr key={cf.year} className="hover:bg-slate-800/30">
                  <td className="py-2.5 px-3 text-left font-sans font-bold text-slate-200">Year {cf.year}</td>
                  <td className="py-2.5 px-2 text-right text-rose-300">{cf.capitalCalled > 0 ? `-€${cf.capitalCalled.toFixed(1)}M` : '—'}</td>
                  <td className="py-2.5 px-2 text-right text-emerald-300">{cf.distributions > 0 ? `+€${cf.distributions.toFixed(1)}M` : '—'}</td>
                  <td className={`py-2.5 px-2 text-right ${cf.netCashFlow >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {cf.netCashFlow >= 0 ? '+' : ''}€{cf.netCashFlow.toFixed(1)}M
                  </td>
                  <td className={`py-2.5 px-2 text-right font-bold ${cf.cumulativeNetCashFlow >= 0 ? 'text-emerald-400' : 'text-slate-400'}`}>
                    €{cf.cumulativeNetCashFlow.toFixed(1)}M
                  </td>
                  <td className="py-2.5 px-2 text-right font-bold text-amber-300">€{cf.nav.toFixed(1)}M</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
