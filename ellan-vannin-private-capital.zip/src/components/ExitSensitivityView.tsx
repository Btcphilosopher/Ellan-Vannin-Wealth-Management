import React, { useState } from 'react';
import { Deal } from '../types';
import { calculateSensitivityMatrix } from '../services/financialEngine';
import { 
  PieChart as PieIcon, 
  TrendingUp, 
  Layers, 
  Scale, 
  HelpCircle,
  Clock,
  Sparkles
} from 'lucide-react';

interface ExitSensitivityProps {
  deal: Deal;
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
}

export const ExitSensitivityView: React.FC<ExitSensitivityProps> = ({
  deal,
  deals,
  onSelectDeal
}) => {
  const [metricMode, setMetricMode] = useState<'IRR' | 'MOIC'>('IRR');
  const [entryEV, setEntryEV] = useState<number>(deal.proposedValuationEV);
  const [entryEbitda, setEntryEbitda] = useState<number>(deal.ebitda);
  const [sponsorEquity, setSponsorEquity] = useState<number>(deal.dealSizeEquity);
  const [revenueGrowth, setRevenueGrowth] = useState<number>(6.0);
  const [ebitdaMargin, setEbitdaMargin] = useState<number>(deal.ebitdaMargin);

  const exitMultiples = [7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0];
  const holdingPeriods = [3, 4, 5, 6, 7];

  const sensitivityMatrix = calculateSensitivityMatrix(
    entryEV,
    entryEbitda,
    sponsorEquity,
    revenueGrowth,
    ebitdaMargin,
    exitMultiples,
    holdingPeriods
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono-num text-[10px] font-bold uppercase">
              Sensitivity Lab
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Deal: <strong className="text-slate-200">{deal.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <PieIcon className="w-6 h-6 text-amber-400" />
            Exit Multiple & Holding Period 2D Sensitivity Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Two-dimensional underwriting return matrix evaluating sponsor returns across varying exit multiples and hold durations.
          </p>
        </div>

        {/* Quick Deal Switcher & Metric Mode Toggle */}
        <div className="flex items-center gap-3">
          <div className="bg-slate-900 p-1 rounded-lg border border-slate-800 flex items-center gap-1 text-xs">
            <button
              onClick={() => setMetricMode('IRR')}
              className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
                metricMode === 'IRR' 
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Gross IRR (%)
            </button>
            <button
              onClick={() => setMetricMode('MOIC')}
              className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
                metricMode === 'MOIC' 
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              MOIC Multiple (x)
            </button>
          </div>

          <select
            value={deal.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {deals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Sensitivity Matrix Heatmap Table */}
      <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="font-display font-bold text-base text-slate-100">
              Sponsor {metricMode === 'IRR' ? 'Gross IRR (%)' : 'Gross MOIC (x)'} Heatmap
            </h3>
            <p className="text-xs text-slate-400">
              Assumes Entry EV: €{entryEV}M • Entry EBITDA: €{entryEbitda}M • Sponsor Equity: €{sponsorEquity}M
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs font-mono-num">
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-emerald-500/30 border border-emerald-400" /> &gt;25% IRR</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-amber-500/30 border border-amber-400" /> 18-25% Target</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-rose-500/30 border border-rose-400" /> &lt;18% Sub-Target</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-center text-xs font-mono-num">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-3 px-4 text-left font-sans font-bold">Exit EV/EBITDA</th>
                {holdingPeriods.map(hp => (
                  <th key={hp} className="py-3 px-3">
                    {hp} Year Hold
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {sensitivityMatrix.map((row) => (
                <tr key={row.exitMultiple} className="hover:bg-slate-800/20">
                  <td className="py-3 px-4 text-left font-sans font-bold text-slate-200 bg-slate-950/60">
                    {row.exitMultiple.toFixed(1)}x Multiple
                  </td>
                  {row.holdingPeriods.map((col) => {
                    const val = metricMode === 'IRR' ? col.irr : col.moic;
                    const isHigh = metricMode === 'IRR' ? val >= 25 : val >= 2.5;
                    const isTarget = metricMode === 'IRR' ? (val >= 18 && val < 25) : (val >= 2.0 && val < 2.5);
                    
                    const bgClass = isHigh
                      ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30'
                      : isTarget
                      ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30'
                      : 'bg-slate-950 text-slate-400 border border-slate-800/60';

                    return (
                      <td key={col.years} className="py-3 px-3">
                        <div className={`py-1.5 px-2 rounded-lg ${bgClass}`}>
                          {metricMode === 'IRR' ? `${val.toFixed(1)}%` : `${val.toFixed(2)}x`}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
