import React, { useState } from 'react';
import { Deal, DigitalTwinState } from '../types';
import { auditLogger } from '../services/auditLogger';
import { 
  Cpu, 
  TrendingUp, 
  Activity, 
  Sliders, 
  DollarSign, 
  ArrowUpRight, 
  RefreshCw, 
  CheckCircle, 
  Layers, 
  Building2,
  Sparkles
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip 
} from 'recharts';

interface DigitalTwinProps {
  deals: Deal[];
  selectedDeal: Deal;
  onSelectDeal: (dealId: string) => void;
  onUpdateDeal: (updated: Deal) => void;
}

export const PortfolioDigitalTwins: React.FC<DigitalTwinProps> = ({
  deals,
  selectedDeal,
  onSelectDeal,
  onUpdateDeal
}) => {
  const portfolioDeals = deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO');
  const activeCompany = selectedDeal.isPortfolioCompany ? selectedDeal : portfolioDeals[0] || selectedDeal;

  // Local Digital Twin state modifiers
  const [activeRevenue, setActiveRevenue] = useState<number>(activeCompany.revenue);
  const [activeEbitdaMargin, setActiveEbitdaMargin] = useState<number>(activeCompany.ebitdaMargin);
  const [activeMultiple, setActiveMultiple] = useState<number>(
    (activeCompany.currentValuationEV || activeCompany.proposedValuationEV) / (activeCompany.ebitda || 1)
  );
  const [activeNetDebt, setActiveNetDebt] = useState<number>(activeCompany.currentNetDebt || 25.0);
  const [syncSuccess, setSyncSuccess] = useState(false);

  // Compute live simulated values
  const simulatedEbitda = (activeRevenue * (activeEbitdaMargin / 100));
  const simulatedEV = simulatedEbitda * activeMultiple;
  const simulatedEquity = Math.max(0, simulatedEV - activeNetDebt);

  const entryEV = activeCompany.entryValuationEV || activeCompany.proposedValuationEV;
  const entryEquity = activeCompany.entryEquity || activeCompany.dealSizeEquity;
  const totalValueCreation = simulatedEV - entryEV;
  const currentMOIC = entryEquity > 0 ? (simulatedEquity / entryEquity) : 1.0;

  // Sync to Fund NAV
  const handlePropagateToFund = () => {
    const updatedDeal: Deal = {
      ...activeCompany,
      revenue: activeRevenue,
      ebitda: simulatedEbitda,
      ebitdaMargin: activeEbitdaMargin,
      currentValuationEV: simulatedEV,
      currentEquityValue: simulatedEquity,
      currentNetDebt: activeNetDebt
    };

    onUpdateDeal(updatedDeal);
    setSyncSuccess(true);

    auditLogger.log(
      'VALUATION_UPDATE',
      `Digital Twin synced for ${activeCompany.companyName}: New EV €${simulatedEV.toFixed(1)}M, Equity €${simulatedEquity.toFixed(1)}M`,
      'Portfolio Management',
      { dealId: activeCompany.id, newEV: simulatedEV, newEquity: simulatedEquity }
    );

    setTimeout(() => setSyncSuccess(false), 3000);
  };

  // Historical quarterly telemetry
  const quarterlyTelemetry = [
    { q: 'Q1 2024', rev: activeRevenue * 0.88, ebitda: simulatedEbitda * 0.84, ev: simulatedEV * 0.85 },
    { q: 'Q2 2024', rev: activeRevenue * 0.91, ebitda: simulatedEbitda * 0.89, ev: simulatedEV * 0.88 },
    { q: 'Q3 2024', rev: activeRevenue * 0.94, ebitda: simulatedEbitda * 0.93, ev: simulatedEV * 0.92 },
    { q: 'Q4 2024', rev: activeRevenue * 0.97, ebitda: simulatedEbitda * 0.96, ev: simulatedEV * 0.96 },
    { q: 'Q1 2025', rev: activeRevenue, ebitda: simulatedEbitda, ev: simulatedEV }
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono-num text-[10px] font-bold uppercase">
              Operational Telemetry
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Digital Twin: <strong className="text-slate-200">{activeCompany.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <Cpu className="w-6 h-6 text-amber-400" />
            Portfolio Company Digital Twin Cockpit
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time operating parameter simulation, live valuation feedback, and bidirectional Fund NAV synchronization.
          </p>
        </div>

        {/* Portfolio Company Switcher */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Asset Twin:</label>
          <select
            value={activeCompany.id}
            onChange={(e) => {
              const d = deals.find(x => x.id === e.target.value);
              if (d) {
                onSelectDeal(d.id);
                setActiveRevenue(d.revenue);
                setActiveEbitdaMargin(d.ebitdaMargin);
                setActiveMultiple((d.currentValuationEV || d.proposedValuationEV) / (d.ebitda || 1));
                setActiveNetDebt(d.currentNetDebt || 20);
              }
            }}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {portfolioDeals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName} ({d.sector})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Real-time KPI Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono-num">
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Simulated Revenue</span>
          <span className="text-2xl font-bold text-slate-100 mt-1 block">€{activeRevenue.toFixed(1)}M</span>
          <span className="text-[10px] text-emerald-400 font-sans">+8.4% YoY Growth</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Simulated EBITDA</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">€{simulatedEbitda.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">{activeEbitdaMargin.toFixed(1)}% Margin</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Simulated EV</span>
          <span className="text-2xl font-bold text-amber-300 mt-1 block">€{simulatedEV.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">{activeMultiple.toFixed(1)}x EBITDA</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Net Debt Balance</span>
          <span className="text-2xl font-bold text-slate-200 mt-1 block">€{activeNetDebt.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">{(activeNetDebt / (simulatedEbitda || 1)).toFixed(1)}x Leverage</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Simulated Equity Value</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">€{simulatedEquity.toFixed(1)}M</span>
          <span className="text-[10px] text-sky-400 font-sans">EVWM Ownership Stake</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Current MOIC</span>
          <span className="text-2xl font-bold text-emerald-300 mt-1 block">{currentMOIC.toFixed(2)}x</span>
          <span className="text-[10px] text-emerald-400 font-sans">+€{totalValueCreation.toFixed(1)}M EV Creation</span>
        </div>
      </div>

      {/* Twin Operational Controls & Telemetry Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: Digital Twin Interactive Sliders */}
        <div className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl">
          <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            Operational Telemetry Sliders
          </h3>

          <div className="space-y-4 font-mono-num">
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Annual Run-Rate Revenue</span>
                <span className="font-bold text-slate-100">€{activeRevenue.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="50"
                max="400"
                step="1"
                value={activeRevenue}
                onChange={(e) => setActiveRevenue(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">EBITDA Margin (%)</span>
                <span className="font-bold text-emerald-400">{activeEbitdaMargin.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="45"
                step="0.5"
                value={activeEbitdaMargin}
                onChange={(e) => setActiveEbitdaMargin(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Market Valuation Multiple</span>
                <span className="font-bold text-amber-400">{activeMultiple.toFixed(1)}x EV/EBITDA</span>
              </div>
              <input
                type="range"
                min="6"
                max="18"
                step="0.25"
                value={activeMultiple}
                onChange={(e) => setActiveMultiple(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Net Debt Position</span>
                <span className="font-bold text-slate-200">€{activeNetDebt.toFixed(1)}M</span>
              </div>
              <input
                type="range"
                min="0"
                max="120"
                step="1"
                value={activeNetDebt}
                onChange={(e) => setActiveNetDebt(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 space-y-3">
            {syncSuccess && (
              <div className="p-2.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-semibold flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle className="w-4 h-4" /> Live Fund NAV Recalculated!
              </div>
            )}

            <button
              onClick={handlePropagateToFund}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 text-slate-950 font-bold text-xs shadow-lg shadow-amber-950/40 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Sync Telemetry to Master Fund NAV
            </button>
          </div>
        </div>

        {/* Right 2 Cols: Historical & Projected Operational Chart */}
        <div className="lg:col-span-2 space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display font-bold text-base text-slate-100">
                Quarterly Operational Telemetry & EV Expansion
              </h3>
              <p className="text-xs text-slate-400">Quarter-on-quarter revenue, EBITDA, and mark-to-market Enterprise Value</p>
            </div>
            <span className="text-xs font-mono-num text-emerald-400 font-bold">
              Current EV: €{simulatedEV.toFixed(1)}M
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={quarterlyTelemetry} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0.0}/>
                  </linearGradient>
                  <linearGradient id="colorEV" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="q" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`€${val}M`, '']}
                />
                <Area type="monotone" dataKey="rev" name="Revenue" stroke="#38bdf8" strokeWidth={2} fill="url(#colorRev)" />
                <Area type="monotone" dataKey="ev" name="Enterprise Value" stroke="#f59e0b" strokeWidth={2} fill="url(#colorEV)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
};
