import React, { useState } from 'react';
import { Fund, CapitalCall, LPCommitment } from '../types';
import { 
  Coins, 
  FileText, 
  Calendar, 
  DollarSign, 
  Send, 
  Printer, 
  CheckCircle, 
  PlusCircle,
  Building2,
  Clock
} from 'lucide-react';

interface CapitalCallProps {
  fund?: Fund;
  selectedFund?: Fund;
  capitalCalls?: any[];
  notices?: any[];
  lpCommitments?: any[];
  lps?: any[];
  onIssueCapitalCall?: (newCall: any) => void;
  onIssueCall?: (newCall: any) => void;
}

export const CapitalCallEngine: React.FC<CapitalCallProps> = ({
  fund: propFund,
  selectedFund,
  capitalCalls: propCapitalCalls,
  notices,
  lpCommitments: propLpCommitments,
  lps,
  onIssueCapitalCall,
  onIssueCall
}) => {
  const fund = propFund || selectedFund || { id: 'f-1', committedCapital: 1000, investedCapital: 400 };
  const calls = propCapitalCalls || notices || [];
  const lpsList = propLpCommitments || lps || [];

  const fundLPs = lpsList.filter(lp => lp.fundId === fund?.id || !lp.fundId);
  const [selectedCall, setSelectedCall] = useState<any>(calls[calls.length - 1] || calls[0] || {});
  const [showNoticePreview, setShowNoticePreview] = useState(false);

  const totalCalledFund = fund.investedCapital;
  const totalRemainingCommitment = fund.committedCapital - totalCalledFund;

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-100 flex items-center gap-2">
            <Coins className="w-6 h-6 text-amber-400" />
            Institutional Capital Call Engine
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Drawdown execution system, pro-rata LP allocation schedules, and ILPA-compliant formal drawdown notices.
          </p>
        </div>

        <button
          onClick={() => setShowNoticePreview(!showNoticePreview)}
          className="px-4 py-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-semibold hover:bg-amber-500/30 transition-all flex items-center gap-2 cursor-pointer self-start md:self-auto"
        >
          <FileText className="w-4 h-4" />
          {showNoticePreview ? 'Show Drawdown Ledger' : 'Preview Formal LP Notice Letter'}
        </button>
      </div>

      {/* Summary KPI Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <div className="text-xs text-slate-400 font-medium uppercase">Total Fund Commitment</div>
          <div className="font-mono-num text-xl font-bold text-slate-100 mt-1">€{fund.committedCapital}.0M</div>
          <div className="text-[11px] text-slate-400 mt-1">{fundLPs.length} Institutional LPs</div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <div className="text-xs text-slate-400 font-medium uppercase">Total Called Capital</div>
          <div className="font-mono-num text-xl font-bold text-emerald-400 mt-1">€{fund.investedCapital}.0M</div>
          <div className="text-[11px] text-emerald-400 mt-1 font-mono-num">
            {((fund.investedCapital / fund.committedCapital) * 100).toFixed(1)}% of Total
          </div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <div className="text-xs text-slate-400 font-medium uppercase">Uncalled Dry Powder</div>
          <div className="font-mono-num text-xl font-bold text-amber-400 mt-1">€{fund.uncalledCapital}.0M</div>
          <div className="text-[11px] text-amber-400/80 mt-1">Available for Direct Deployments</div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
          <div className="text-xs text-slate-400 font-medium uppercase">Historical Notices Issued</div>
          <div className="font-mono-num text-xl font-bold text-sky-400 mt-1">{calls.length} Calls</div>
          <div className="text-[11px] text-sky-400/80 mt-1">100% On-Time Settlement</div>
        </div>
      </div>

      {!showNoticePreview ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left 2 Cols: Historical Capital Calls Table */}
          <div className="lg:col-span-2 space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl">
            <h2 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              Capital Drawdown Call History
            </h2>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] font-semibold">
                    <th className="py-2.5 px-3">Call #</th>
                    <th className="py-2.5 px-2">Issue Date</th>
                    <th className="py-2.5 px-2">Due Date</th>
                    <th className="py-2.5 px-2">Purpose / Asset</th>
                    <th className="py-2.5 px-2 text-right">Investment</th>
                    <th className="py-2.5 px-2 text-right">Fees & Exp</th>
                    <th className="py-2.5 px-2 text-right">Total Call</th>
                    <th className="py-2.5 px-2 text-center">Status</th>
                    <th className="py-2.5 px-2 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono-num">
                  {calls.map((call) => (
                    <tr 
                      key={call.id} 
                      className={`hover:bg-slate-800/40 transition-colors cursor-pointer ${
                        selectedCall?.id === call.id ? 'bg-amber-500/10' : ''
                      }`}
                      onClick={() => setSelectedCall(call)}
                    >
                      <td className="py-3 px-3 font-sans font-bold text-slate-100">
                        #{call.callNumber}
                      </td>
                      <td className="py-3 px-2 text-slate-300">{call.callDate}</td>
                      <td className="py-3 px-2 text-amber-300 font-semibold">{call.dueDate}</td>
                      <td className="py-3 px-2 font-sans text-slate-300 max-w-[200px] truncate" title={call.purpose}>
                        {call.purpose}
                      </td>
                      <td className="py-3 px-2 text-right text-slate-200">€{call.investmentAmount.toFixed(1)}M</td>
                      <td className="py-3 px-2 text-right text-slate-400">€{(call.feeAmount + call.expenseAmount).toFixed(1)}M</td>
                      <td className="py-3 px-2 text-right font-bold text-amber-400">€{call.totalCallAmount.toFixed(1)}M</td>
                      <td className="py-3 px-2 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-sans font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          {call.status}
                        </span>
                      </td>
                      <td className="py-3 px-2 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedCall(call);
                            setShowNoticePreview(true);
                          }}
                          className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] border border-slate-700"
                        >
                          Notice Letter
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right Col: LP Drawdown Allocation Schedule for Selected Call */}
          <div className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl">
            <div>
              <h2 className="font-display font-bold text-base text-slate-100">
                Call #{selectedCall?.callNumber || 1} Pro-Rata LP Allocation
              </h2>
              <p className="text-xs text-slate-400">
                Total Call: <strong className="text-amber-400 font-mono-num">€{selectedCall?.totalCallAmount.toFixed(1)}M</strong>
              </p>
            </div>

            <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
              {fundLPs.map((lp) => {
                const lpSharePct = lp.totalCommitment / (fund.committedCapital || 1);
                const lpCallAmount = (selectedCall?.totalCallAmount || 0) * lpSharePct;

                return (
                  <div key={lp.id} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs font-mono-num space-y-1">
                    <div className="flex items-center justify-between font-sans">
                      <span className="font-semibold text-slate-200 truncate max-w-[180px]">{lp.lpName}</span>
                      <span className="text-[10px] font-bold text-amber-400">{(lpSharePct * 100).toFixed(2)}% Share</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300 pt-1">
                      <span className="text-slate-400 text-[11px] font-sans">Amount Due:</span>
                      <span className="text-emerald-400 font-bold text-sm">€{lpCallAmount.toFixed(2)}M</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-500 text-[10px] pt-0.5">
                      <span>Commitment: €{lp.totalCommitment.toFixed(1)}M</span>
                      <span>Rem. After Call: €{(lp.uncalledCapital).toFixed(1)}M</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      ) : (
        /* Formal ILPA Capital Call Notice Letter Preview */
        <div className="bg-white text-slate-900 p-8 rounded-2xl shadow-2xl border border-slate-300 max-w-4xl mx-auto space-y-6 print:p-0 print:border-0 print:shadow-none">
          <div className="flex items-center justify-between border-b border-slate-300 pb-4">
            <div>
              <div className="text-lg font-bold font-serif tracking-wide text-slate-950">
                ELLAN VANNIN PRIVATE CAPITAL MANAGEMENT LIMITED
              </div>
              <div className="text-xs text-slate-600">
                Athol Street, Douglas, Isle of Man IM1 1LB • Regulated by Isle of Man Financial Services Authority
              </div>
            </div>
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 rounded bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 no-print cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" /> Print Notice Letter
            </button>
          </div>

          <div className="flex justify-between text-xs text-slate-700">
            <div>
              <p className="font-bold">TO: ALL LIMITED PARTNERS</p>
              <p>Fund: {fund.name} (Vintage {fund.vintage})</p>
              <p>Notice Date: {selectedCall.callDate}</p>
            </div>
            <div className="text-right">
              <p className="font-bold text-rose-700">PAYMENT DUE DATE: {selectedCall.dueDate}</p>
              <p>Drawdown Notice Ref: EVWM-CALL-{selectedCall.callNumber.toString().padStart(3, '0')}</p>
              <p>Currency: EUR (€)</p>
            </div>
          </div>

          <div className="text-xs leading-relaxed text-slate-800 space-y-3">
            <p>
              Dear Limited Partner,
            </p>
            <p>
              In accordance with Clause 4.2 of the Limited Partnership Agreement of <strong>{fund.name}</strong>, notice is hereby given that a Capital Drawdown is called on your commitment as detailed in the summary table below.
            </p>
            <p>
              <strong>Purpose of Drawdown:</strong> {selectedCall.purpose}
            </p>
          </div>

          {/* Breakdown Table */}
          <div className="border border-slate-300 rounded-lg overflow-hidden text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-100 border-b border-slate-300 font-bold text-slate-800">
                <tr>
                  <th className="p-2.5">Component</th>
                  <th className="p-2.5 text-right">Aggregate Fund Amount</th>
                  <th className="p-2.5 text-right">Percentage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr>
                  <td className="p-2.5">1. Direct Portfolio Acquisition & Investment</td>
                  <td className="p-2.5 text-right font-mono font-semibold">€{selectedCall.investmentAmount.toFixed(2)}M</td>
                  <td className="p-2.5 text-right">{((selectedCall.investmentAmount / selectedCall.totalCallAmount) * 100).toFixed(1)}%</td>
                </tr>
                <tr>
                  <td className="p-2.5">2. Management Fees (Quarterly)</td>
                  <td className="p-2.5 text-right font-mono font-semibold">€{selectedCall.feeAmount.toFixed(2)}M</td>
                  <td className="p-2.5 text-right">{((selectedCall.feeAmount / selectedCall.totalCallAmount) * 100).toFixed(1)}%</td>
                </tr>
                <tr>
                  <td className="p-2.5">3. Partnership Due Diligence & Legal Expenses</td>
                  <td className="p-2.5 text-right font-mono font-semibold">€{selectedCall.expenseAmount.toFixed(2)}M</td>
                  <td className="p-2.5 text-right">{((selectedCall.expenseAmount / selectedCall.totalCallAmount) * 100).toFixed(1)}%</td>
                </tr>
                <tr className="bg-slate-50 font-bold">
                  <td className="p-2.5">TOTAL CAPITAL DRAWDOWN</td>
                  <td className="p-2.5 text-right font-mono text-slate-950">€{selectedCall.totalCallAmount.toFixed(2)}M</td>
                  <td className="p-2.5 text-right">100.0%</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Banking Instructions */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-300 text-xs space-y-1.5">
            <h4 className="font-bold text-slate-900">BANK SETTLEMENT INSTRUCTIONS:</h4>
            <div className="grid grid-cols-2 gap-2 text-slate-700">
              <div><strong>Beneficiary:</strong> Ellan Vannin Capital Master Client Escrow Account</div>
              <div><strong>Bank:</strong> Barclays Bank PLC, Douglas Branch</div>
              <div><strong>IBAN:</strong> GB42 BARC 2026 8839 1049 82</div>
              <div><strong>SWIFT/BIC:</strong> BARCGB22</div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-300 flex justify-between text-xs text-slate-600">
            <div>
              <p className="font-bold text-slate-900">Signed on behalf of the General Partner:</p>
              <p className="font-serif italic text-sm mt-1">Tom Quilliam</p>
              <p>Managing General Partner, Ellan Vannin Private Capital</p>
            </div>
            <div className="text-right">
              <p>Inquiries: treasury@ellanvannincapital.com</p>
              <p>Compliance Officer: compliance@ellanvannincapital.com</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
