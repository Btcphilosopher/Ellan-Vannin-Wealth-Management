import React, { useState } from 'react';
import { Deal, ScreeningScorecard } from '../types';
import { 
  SlidersHorizontal, 
  RotateCcw, 
  Award, 
  CheckCircle2, 
  TrendingUp, 
  AlertTriangle,
  Scale,
  Sparkles
} from 'lucide-react';

interface ScreeningEngineProps {
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
  onNavigateToTab: (tab: any) => void;
}

interface FactorWeight {
  key: keyof Omit<ScreeningScorecard, 'overallScore' | 'notes'>;
  label: string;
  weight: number; // percentage (sums to 100)
  category: 'Commercial' | 'Financial' | 'Structural' | 'Strategic';
}

const DEFAULT_WEIGHTS: FactorWeight[] = [
  { key: 'growth', label: 'Revenue Growth Track Record', weight: 8, category: 'Commercial' },
  { key: 'profitability', label: 'EBITDA Margin & Unit Economics', weight: 10, category: 'Financial' },
  { key: 'cashFlow', label: 'Free Cash Flow Conversion', weight: 12, category: 'Financial' },
  { key: 'competitiveAdvantage', label: 'Moat & Pricing Power', weight: 12, category: 'Commercial' },
  { key: 'management', label: 'Management Track Record & Alignment', weight: 10, category: 'Strategic' },
  { key: 'valuation', label: 'Entry Valuation Multiple', weight: 10, category: 'Financial' },
  { key: 'marketSize', label: 'Addressable Market (TAM/SAM)', weight: 6, category: 'Commercial' },
  { key: 'barriersToEntry', label: 'Regulatory & Tech Barriers', weight: 8, category: 'Commercial' },
  { key: 'recurringRevenue', label: 'Recurring Revenue & Retention', weight: 8, category: 'Commercial' },
  { key: 'capitalIntensity', label: 'Low Capex / Capital Light', weight: 6, category: 'Financial' },
  { key: 'leverageSuitability', label: 'Debt Capacity & DSCR Headroom', weight: 4, category: 'Structural' },
  { key: 'exitPotential', label: 'M&A Sponsor / Strategic Liquidity', weight: 6, category: 'Strategic' }
];

export const DealScreeningEngine: React.FC<ScreeningEngineProps> = ({
  deals,
  onSelectDeal,
  onNavigateToTab
}) => {
  const [weights, setWeights] = useState<FactorWeight[]>(DEFAULT_WEIGHTS);

  // Recalculate composite score for each deal based on current weights
  const totalWeight = weights.reduce((s, w) => s + w.weight, 0);

  const calculateDynamicScore = (scorecard: ScreeningScorecard): number => {
    let weightedSum = 0;
    weights.forEach(w => {
      const score = (scorecard[w.key] as number) || 50;
      weightedSum += score * (w.weight / 100);
    });
    return Number(weightedSum.toFixed(1));
  };

  const scoredDeals = deals.map(d => ({
    ...d,
    dynamicScore: calculateDynamicScore(d.screeningScorecard)
  })).sort((a, b) => b.dynamicScore - a.dynamicScore);

  const handleWeightChange = (key: keyof Omit<ScreeningScorecard, 'overallScore' | 'notes'>, newWeight: number) => {
    setWeights(weights.map(w => w.key === key ? { ...w, weight: Math.max(0, Math.min(30, newWeight)) } : w));
  };

  const handleResetWeights = () => {
    setWeights(DEFAULT_WEIGHTS);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-100 flex items-center gap-2">
            <SlidersHorizontal className="w-6 h-6 text-amber-400" />
            Automated Investment Screening & Ranking Engine
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Institutional 12-factor underwriting scorecard with customizable Investment Committee factor weighting.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleResetWeights}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset IC Baseline Weights
          </button>
        </div>
      </div>

      {/* Main Grid: Factor Weight Sliders & Ranked Deal Leaderboard */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: IC Factor Weight Adjuster */}
        <div className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="font-display font-bold text-base text-slate-100 flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-amber-400" />
                IC Weight Matrix (Total: {totalWeight}%)
              </h2>
              <p className="text-[11px] text-slate-400">Calibrate screening weights to current market cycle</p>
            </div>
            {totalWeight !== 100 && (
              <span className="text-[10px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                Sum != 100%
              </span>
            )}
          </div>

          <div className="space-y-3 max-h-[580px] overflow-y-auto pr-1">
            {weights.map((w) => (
              <div key={w.key} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300 font-medium truncate max-w-[200px]">{w.label}</span>
                  <span className="font-mono-num font-bold text-amber-400">{w.weight}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="25"
                  step="1"
                  value={w.weight}
                  onChange={(e) => handleWeightChange(w.key, Number(e.target.value))}
                  className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Right 2 Cols: Dynamically Ranked Deal Pipeline */}
        <div className="lg:col-span-2 space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800/80 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                Underwriting Score & Pipeline Priority Matrix
              </h2>
              <p className="text-xs text-slate-400">Ranked from highest composite institutional fit (0–100)</p>
            </div>
            <span className="text-xs text-slate-400 font-mono-num">
              {scoredDeals.length} Opportunities Evaluated
            </span>
          </div>

          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
            {scoredDeals.map((deal, rank) => {
              const isApproved = deal.stage === 'PORTFOLIO' || deal.stage === 'INVESTMENT COMMITTEE';
              const badgeBg = deal.dynamicScore >= 85 
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                : deal.dynamicScore >= 75
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                : 'bg-slate-800 text-slate-400 border-slate-700';

              return (
                <div 
                  key={deal.id}
                  onClick={() => {
                    onSelectDeal(deal.id);
                    onNavigateToTab('DUE_DILIGENCE_SUITE');
                  }}
                  className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-amber-500/40 hover:bg-slate-900/80 transition-all cursor-pointer shadow group"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-xs font-mono-num font-bold text-slate-300">
                        #{rank + 1}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-sm text-slate-100 group-hover:text-amber-300 transition-colors">
                            {deal.companyName}
                          </h3>
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                            {deal.sector}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400">
                          {deal.city}, {deal.country} • Stage: <strong className="text-slate-300">{deal.stage}</strong>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 shrink-0 font-mono-num">
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block uppercase">EV / Multiple</span>
                        <span className="text-xs text-slate-200 font-semibold">€{deal.proposedValuationEV}M ({ (deal.proposedValuationEV / (deal.ebitda || 1)).toFixed(1) }x)</span>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block uppercase">Target IRR</span>
                        <span className="text-xs text-emerald-400 font-bold">{deal.targetIRR}%</span>
                      </div>

                      <div className={`px-3 py-1.5 rounded-xl border text-center font-bold text-sm ${badgeBg}`}>
                        {deal.dynamicScore}
                        <span className="text-[10px] font-normal block font-sans">EVWM Score</span>
                      </div>
                    </div>
                  </div>

                  {/* Factor Score Pills Breakdown */}
                  <div className="mt-3 pt-2.5 border-t border-slate-800/60 grid grid-cols-3 sm:grid-cols-6 gap-2 text-[10px] font-mono-num text-center">
                    <div className="bg-slate-900/90 p-1 rounded">
                      <span className="text-slate-500 block">Moat</span>
                      <span className="text-slate-200 font-bold">{deal.screeningScorecard.competitiveAdvantage}</span>
                    </div>
                    <div className="bg-slate-900/90 p-1 rounded">
                      <span className="text-slate-500 block">Cash Flow</span>
                      <span className="text-slate-200 font-bold">{deal.screeningScorecard.cashFlow}</span>
                    </div>
                    <div className="bg-slate-900/90 p-1 rounded">
                      <span className="text-slate-500 block">Recurring</span>
                      <span className="text-slate-200 font-bold">{deal.screeningScorecard.recurringRevenue}</span>
                    </div>
                    <div className="bg-slate-900/90 p-1 rounded">
                      <span className="text-slate-500 block">Mgmt</span>
                      <span className="text-slate-200 font-bold">{deal.screeningScorecard.management}</span>
                    </div>
                    <div className="bg-slate-900/90 p-1 rounded">
                      <span className="text-slate-500 block">Barriers</span>
                      <span className="text-slate-200 font-bold">{deal.screeningScorecard.barriersToEntry}</span>
                    </div>
                    <div className="bg-slate-900/90 p-1 rounded">
                      <span className="text-slate-500 block">Exit</span>
                      <span className="text-slate-200 font-bold">{deal.screeningScorecard.exitPotential}</span>
                    </div>
                  </div>

                  {deal.screeningScorecard.notes && (
                    <div className="mt-2 text-[11px] text-slate-400 italic">
                      &ldquo;{deal.screeningScorecard.notes}&rdquo;
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
};
