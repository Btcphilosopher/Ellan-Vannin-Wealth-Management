import React, { useState } from 'react';
import { Deal, LBOModel, DebtTranche } from '../types';
import { calculateLBO } from '../services/financialEngine';
import { 
  Scale, 
  Layers, 
  TrendingUp, 
  Coins, 
  Sliders, 
  ArrowRight, 
  PlusCircle, 
  Trash2, 
  CheckCircle,
  AlertTriangle,
  PieChart
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend 
} from 'recharts';

interface LBOEngineProps {
  deal: Deal;
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
  onUpdateDeal: (updated: Deal) => void;
}

export const LBOEngine: React.FC<LBOEngineProps> = ({
  deal,
  deals,
  onSelectDeal,
  onUpdateDeal
}) => {
  // LBO State Parameters
  const [entryEV, setEntryEV] = useState<number>(deal.lboModel?.entryEV || deal.proposedValuationEV);
  const [entryEbitda, setEntryEbitda] = useState<number>(deal.lboModel?.entryEbitda || deal.ebitda);
  const [holdingPeriod, setHoldingPeriod] = useState<number>(deal.lboModel?.holdingPeriodYears || 5);
  const [revenueGrowth, setRevenueGrowth] = useState<number>(deal.lboModel?.revenueGrowthRate || 6.0);
  const [ebitdaMargin, setEbitdaMargin] = useState<number>(deal.lboModel?.ebitdaMargin || deal.ebitdaMargin);
  const [exitMultiple, setExitMultiple] = useState<number>(deal.lboModel?.exitMultiple || 10.0);
  const [cashSweepPercent, setCashSweepPercent] = useState<number>(deal.lboModel?.cashSweepPercent || 50.0);
  const [capexPercentRev, setCapexPercentRev] = useState<number>(deal.lboModel?.capexPercentRevenue || 3.5);

  // Debt Tranches
  const defaultTranches: DebtTranche[] = deal.lboModel?.debtTranches || [
    { name: 'Senior Term Loan A (Amortizing)', amount: entryEbitda * 2.0, interestRate: 5.5, tenorYears: 6, annualAmortizationPercent: 10.0, seniority: 1 },
    { name: 'Senior Term Loan B (Bullet)', amount: entryEbitda * 1.5, interestRate: 6.75, tenorYears: 7, annualAmortizationPercent: 1.0, seniority: 2 },
    { name: 'Subordinated Mezzanine / PIK', amount: entryEbitda * 0.5, interestRate: 9.5, tenorYears: 8, annualAmortizationPercent: 0.0, seniority: 3 }
  ];
  const [tranches, setTranches] = useState<DebtTranche[]>(defaultTranches);

  // Advisory & Financing fees
  const advisoryFees = deal.lboModel?.advisoryFees || 3.5;
  const financingFees = deal.lboModel?.financingFees || 2.0;

  // Calculate Sources and Uses
  const totalDebt = tranches.reduce((sum, t) => sum + t.amount, 0);
  const totalUses = entryEV + advisoryFees + financingFees;
  const sponsorEquity = Math.max(0, totalUses - totalDebt);
  const leverageMultiple = totalDebt / (entryEbitda || 1);

  // Run dynamic LBO Calculation Engine
  const currentLBOInput: LBOModel = {
    entryEV,
    entryEbitda,
    holdingPeriodYears: holdingPeriod,
    revenueGrowthRate: revenueGrowth,
    ebitdaMargin,
    exitMultiple,
    debtTranches: tranches,
    sponsorEquity,
    managementRolloverEquity: deal.lboModel?.managementRolloverEquity || 5.0,
    advisoryFees,
    financingFees,
    cashSweepPercent,
    capexPercentRevenue: capexPercentRev
  };

  const lboResult = calculateLBO(currentLBOInput);

  // Chart data for Debt Paydown vs Enterprise Value growth
  const debtPaydownData = lboResult.debtSchedule.map(ds => ({
    year: `Year ${ds.year}`,
    beginningDebt: Number(ds.beginningDebt.toFixed(1)),
    endingDebt: Number(ds.endingDebt.toFixed(1)),
    interestPaid: Number(ds.interestPaid.toFixed(1)),
    fcfGenerated: Number(ds.fcfGenerated.toFixed(1)),
    dscr: Number(ds.dscr.toFixed(2))
  }));

  const handleUpdateTranche = (index: number, field: keyof DebtTranche, val: any) => {
    const updated = [...tranches];
    updated[index] = { ...updated[index], [field]: val };
    setTranches(updated);
  };

  const handleAddTranche = () => {
    const newTranche: DebtTranche = {
      name: 'Revolving Credit Facility (RCF)',
      amount: 10.0,
      interestRate: 5.0,
      tenorYears: 5,
      annualAmortizationPercent: 0,
      seniority: 1
    };
    setTranches([...tranches, newTranche]);
  };

  const handleRemoveTranche = (index: number) => {
    if (tranches.length > 1) {
      setTranches(tranches.filter((_, i) => i !== index));
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono-num text-[10px] font-bold uppercase">
              Financial Engineering Lab
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Underwriting Asset: <strong className="text-slate-200">{deal.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <Scale className="w-6 h-6 text-amber-400" />
            LBO Debt Structuring & Cash Sweep Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional leverage optimizer: multi-tier debt tranches, Sources & Uses balancer, cash sweep, DSCR covenants, and sponsor returns.
          </p>
        </div>

        {/* Quick Deal Switcher */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Target:</label>
          <select
            value={deal.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {deals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName} (EV: €{d.proposedValuationEV}M)</option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Highlight Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono-num">
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Sponsor Gross IRR</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">{lboResult.grossIRR.toFixed(1)}%</span>
          <span className="text-[10px] text-slate-400 font-sans">EVWM Target: ≥20%</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Sponsor MOIC</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">{lboResult.moic.toFixed(2)}x</span>
          <span className="text-[10px] text-slate-400 font-sans">Money-on-Invested-Cap</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Opening Leverage</span>
          <span className="text-2xl font-bold text-amber-400 mt-1 block">{leverageMultiple.toFixed(2)}x</span>
          <span className="text-[10px] text-slate-400 font-sans">Debt / EBITDA</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Sponsor Equity Check</span>
          <span className="text-2xl font-bold text-slate-100 mt-1 block">€{sponsorEquity.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">{((sponsorEquity / totalUses) * 100).toFixed(0)}% of Uses</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Exit Enterprise Value</span>
          <span className="text-2xl font-bold text-amber-300 mt-1 block">€{lboResult.exitEV.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">{exitMultiple.toFixed(1)}x Exit Multiple</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Exit Equity Proceeds</span>
          <span className="text-2xl font-bold text-emerald-300 mt-1 block">€{lboResult.exitEquityValue.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">After Debt Repayment</span>
        </div>
      </div>

      {/* Main Structuring Controls & Sources & Uses Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col: Macro & Operational Underwriting Drivers */}
        <div className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl">
          <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            LBO Assumptions & Levers
          </h3>

          <div className="space-y-3.5">
            
            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Holding Period</span>
                <span className="font-mono-num font-bold text-amber-400">{holdingPeriod} Years</span>
              </div>
              <input
                type="range"
                min="3"
                max="8"
                step="1"
                value={holdingPeriod}
                onChange={(e) => setHoldingPeriod(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Revenue Growth Rate (% p.a.)</span>
                <span className="font-mono-num font-bold text-emerald-400">+{revenueGrowth.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="15.0"
                step="0.5"
                value={revenueGrowth}
                onChange={(e) => setRevenueGrowth(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Exit EV/EBITDA Multiple</span>
                <span className="font-mono-num font-bold text-sky-400">{exitMultiple.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="6.0"
                max="16.0"
                step="0.25"
                value={exitMultiple}
                onChange={(e) => setExitMultiple(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Cash Sweep (% of FCF to Senior Debt)</span>
                <span className="font-mono-num font-bold text-amber-400">{cashSweepPercent.toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={cashSweepPercent}
                onChange={(e) => setCashSweepPercent(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Capex (% of Revenue)</span>
                <span className="font-mono-num font-bold text-slate-200">{capexPercentRev.toFixed(1)}%</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="8.0"
                step="0.5"
                value={capexPercentRev}
                onChange={(e) => setCapexPercentRev(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

          </div>
        </div>

        {/* Right 2 Cols: Sources & Uses Balancer and Debt Tranches Configuration */}
        <div className="lg:col-span-2 space-y-6 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl">
          
          {/* Sources and Uses Equal Balance Table */}
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                Sources & Uses of Funds (Exact Balancer)
              </h3>
              <span className="text-xs font-mono-num font-bold text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" /> Balanced: €{totalUses.toFixed(1)}M
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono-num">
              {/* Sources */}
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <div className="font-sans font-bold text-slate-200 text-xs flex justify-between border-b border-slate-800 pb-1">
                  <span>SOURCES OF FUNDS</span>
                  <span>AMOUNT (€M)</span>
                </div>
                {tranches.map((t, idx) => (
                  <div key={idx} className="flex justify-between text-slate-300">
                    <span className="font-sans truncate max-w-[180px]">{t.name}</span>
                    <span className="font-bold text-slate-100">€{t.amount.toFixed(1)}M</span>
                  </div>
                ))}
                <div className="flex justify-between text-emerald-400 pt-1 border-t border-slate-800/80">
                  <span className="font-sans font-semibold">Sponsor Equity (Ellan Vannin)</span>
                  <span className="font-bold">€{sponsorEquity.toFixed(1)}M</span>
                </div>
                <div className="flex justify-between font-bold text-amber-300 pt-1 border-t border-slate-800">
                  <span className="font-sans">TOTAL SOURCES</span>
                  <span>€{(totalDebt + sponsorEquity).toFixed(1)}M</span>
                </div>
              </div>

              {/* Uses */}
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <div className="font-sans font-bold text-slate-200 text-xs flex justify-between border-b border-slate-800 pb-1">
                  <span>USES OF FUNDS</span>
                  <span>AMOUNT (€M)</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span className="font-sans">Acquisition Enterprise Value</span>
                  <span className="font-bold text-slate-100">€{entryEV.toFixed(1)}M</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span className="font-sans">Advisory, Legal & DD Fees</span>
                  <span>€{advisoryFees.toFixed(1)}M</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span className="font-sans">Debt Financing & Arrangement Fees</span>
                  <span>€{financingFees.toFixed(1)}M</span>
                </div>
                <div className="flex justify-between font-bold text-amber-300 pt-3 border-t border-slate-800">
                  <span className="font-sans">TOTAL USES</span>
                  <span>€{totalUses.toFixed(1)}M</span>
                </div>
              </div>
            </div>
          </div>

          {/* Debt Tranches Structuring Table */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h4 className="font-sans font-bold text-xs text-slate-200 uppercase tracking-wider">
                Multi-Tranche Debt Structure & Covenants
              </h4>
              <button
                onClick={handleAddTranche}
                className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-semibold cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" /> Add Debt Tranche
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono-num">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                    <th className="py-2 px-3">Tranche Name</th>
                    <th className="py-2 px-2 text-right">Principal (€M)</th>
                    <th className="py-2 px-2 text-right">Interest Rate</th>
                    <th className="py-2 px-2 text-right">Tenor</th>
                    <th className="py-2 px-2 text-right">Amortization</th>
                    <th className="py-2 px-2 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {tranches.map((t, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-3 font-sans">
                        <input
                          type="text"
                          value={t.name}
                          onChange={(e) => handleUpdateTranche(idx, 'name', e.target.value)}
                          className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 w-full"
                        />
                      </td>
                      <td className="py-2.5 px-2 text-right">
                        <input
                          type="number"
                          step="1.0"
                          value={t.amount}
                          onChange={(e) => handleUpdateTranche(idx, 'amount', Number(e.target.value))}
                          className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-100 text-right w-20"
                        />
                      </td>
                      <td className="py-2.5 px-2 text-right">
                        <input
                          type="number"
                          step="0.25"
                          value={t.interestRate}
                          onChange={(e) => handleUpdateTranche(idx, 'interestRate', Number(e.target.value))}
                          className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-amber-400 text-right w-16"
                        />
                      </td>
                      <td className="py-2.5 px-2 text-right">
                        <input
                          type="number"
                          value={t.tenorYears}
                          onChange={(e) => handleUpdateTranche(idx, 'tenorYears', Number(e.target.value))}
                          className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-300 text-right w-14"
                        />
                      </td>
                      <td className="py-2.5 px-2 text-right">
                        <input
                          type="number"
                          step="1.0"
                          value={t.annualAmortizationPercent}
                          onChange={(e) => handleUpdateTranche(idx, 'annualAmortizationPercent', Number(e.target.value))}
                          className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-300 text-right w-16"
                        />
                      </td>
                      <td className="py-2.5 px-2 text-center">
                        <button
                          onClick={() => handleRemoveTranche(idx)}
                          className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

      </div>

      {/* Debt Paydown Schedule Chart & Debt Service Coverage Ratio (DSCR) */}
      <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-display font-bold text-base text-slate-100">
              5-Year Debt Amortization & Debt Service Coverage (DSCR)
            </h3>
            <p className="text-xs text-slate-400">Total debt reduction from operating cash sweep (€M)</p>
          </div>
          <div className="flex items-center gap-3 text-xs font-mono-num">
            <span className="text-amber-400 font-bold">Initial Debt: €{totalDebt.toFixed(1)}M</span>
            <span className="text-slate-500">&rarr;</span>
            <span className="text-emerald-400 font-bold">
              Exit Debt: €{lboResult.debtSchedule[lboResult.debtSchedule.length - 1]?.endingDebt.toFixed(1) || 0}M
            </span>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={debtPaydownData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="year" stroke="#64748b" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '8px', fontSize: '12px' }}
                formatter={(val: any) => [`€${val}M`, '']}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
              <Bar dataKey="beginningDebt" name="Beginning Debt" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              <Bar dataKey="endingDebt" name="Ending Debt" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="fcfGenerated" name="FCF Generated" fill="#38bdf8" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
