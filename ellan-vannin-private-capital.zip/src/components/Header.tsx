import React from 'react';
import { Fund, UserRole } from '../types';
import { 
  Building2, 
  ShieldCheck, 
  TrendingUp, 
  Coins, 
  Scale, 
  Layers, 
  Printer, 
  PlusCircle, 
  Bell, 
  Search,
  ChevronDown
} from 'lucide-react';

interface HeaderProps {
  funds: Fund[];
  selectedFund: Fund;
  onSelectFund: (fund: Fund) => void;
  activeRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  metrics: {
    nav: number;
    grossIRR: number;
    netIRR: number;
    moic: number;
    tvpi: number;
    dpi: number;
    rvpi: number;
    uncalled: number;
  };
  onOpenNewDealModal: () => void;
  onOpenCapitalCallModal: () => void;
  onPrint: () => void;
}

const ROLES: UserRole[] = [
  'FUND MANAGER',
  'INVESTMENT PROFESSIONAL',
  'ANALYST',
  'PORTFOLIO MANAGER',
  'OPERATING PARTNER',
  'RISK OFFICER',
  'FINANCE',
  'INVESTMENT COMMITTEE',
  'ADMINISTRATOR'
];

export const Header: React.FC<HeaderProps> = ({
  funds,
  selectedFund,
  onSelectFund,
  activeRole,
  onChangeRole,
  metrics,
  onOpenNewDealModal,
  onOpenCapitalCallModal,
  onPrint
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur border-b border-slate-800/80 text-slate-100 px-4 lg:px-6 py-2.5 shadow-2xl">
      <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-3">
        
        {/* Brand & Fund Selector */}
        <div className="flex items-center justify-between xl:justify-start gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 p-0.5 shadow-lg shadow-amber-950/50 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[7px] flex items-center justify-center">
                <span className="font-display text-amber-400 font-bold text-lg tracking-widest">EV</span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-sm tracking-wider text-amber-200">ELLAN VANNIN</span>
                <span className="text-[10px] uppercase tracking-widest px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 font-medium">
                  Private Capital
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Institutional PE & Portfolio Platform</p>
            </div>
          </div>

          {/* Fund Selector Dropdown */}
          <div className="relative group">
            <select
              value={selectedFund.id}
              onChange={(e) => {
                const found = funds.find(f => f.id === e.target.value);
                if (found) onSelectFund(found);
              }}
              aria-label="Select Fund"
              className="appearance-none bg-slate-900/90 hover:bg-slate-800/90 text-xs font-semibold text-slate-200 pl-3 pr-8 py-1.5 rounded-lg border border-slate-700/80 focus:outline-none focus:ring-1 focus:ring-amber-400 transition-colors cursor-pointer"
            >
              {funds.map((f) => (
                <option key={f.id} value={f.id} className="bg-slate-900 text-slate-200">
                  {f.name} (€{f.fundSize}M)
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        {/* Live Institutional Metric Ticker */}
        <div className="flex items-center gap-2 lg:gap-3 overflow-x-auto py-1 px-2 rounded-lg bg-slate-900/60 border border-slate-800/60 font-mono-num text-xs">
          <div className="flex items-center gap-1.5 px-2 border-r border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase font-sans font-medium">Fund NAV:</span>
            <span className="font-semibold text-amber-300">€{metrics.nav.toFixed(1)}M</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 border-r border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase font-sans font-medium">Gross IRR:</span>
            <span className="font-semibold text-emerald-400">{metrics.grossIRR.toFixed(1)}%</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 border-r border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase font-sans font-medium">Net IRR:</span>
            <span className="font-semibold text-emerald-300">{metrics.netIRR.toFixed(1)}%</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 border-r border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase font-sans font-medium">MOIC:</span>
            <span className="font-semibold text-sky-400">{metrics.moic.toFixed(2)}x</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 border-r border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase font-sans font-medium">TVPI:</span>
            <span className="font-semibold text-indigo-300">{metrics.tvpi.toFixed(2)}x</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 border-r border-slate-800">
            <span className="text-slate-400 text-[10px] uppercase font-sans font-medium">DPI:</span>
            <span className="font-semibold text-slate-200">{metrics.dpi.toFixed(2)}x</span>
          </div>

          <div className="flex items-center gap-1.5 px-2">
            <span className="text-slate-400 text-[10px] uppercase font-sans font-medium">Dry Powder:</span>
            <span className="font-semibold text-amber-400">€{metrics.uncalled.toFixed(1)}M</span>
          </div>
        </div>

        {/* Role Switcher & Actions */}
        <div className="flex items-center justify-end gap-2.5">
          {/* Role selector */}
          <div className="flex items-center gap-1.5 bg-slate-900/80 px-2.5 py-1 rounded-lg border border-slate-800 text-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[10px] text-slate-400 uppercase hidden sm:inline">Role:</span>
            <select
              value={activeRole}
              onChange={(e) => onChangeRole(e.target.value as UserRole)}
              aria-label="Active User Role"
              className="bg-transparent text-amber-300 font-medium text-xs focus:outline-none cursor-pointer"
            >
              {ROLES.map((r) => (
                <option key={r} value={r} className="bg-slate-900 text-slate-200">
                  {r}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Action buttons */}
          <button
            onClick={onOpenNewDealModal}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold transition-all shadow-sm active:scale-95 cursor-pointer"
            title="Originate / Screen New Deal"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Originate Deal</span>
          </button>

          <button
            onClick={onOpenCapitalCallModal}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-all active:scale-95 cursor-pointer"
            title="Generate Capital Call Notice"
          >
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">Capital Call</span>
          </button>

          <button
            onClick={onPrint}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/80 transition-colors cursor-pointer"
            title="Print / Export Institutional Report"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>

      </div>
    </header>
  );
};
