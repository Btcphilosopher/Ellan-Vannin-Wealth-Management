import React, { useState } from 'react';
import { Deal } from '../types';
import { 
  Activity, 
  Users, 
  TrendingUp, 
  BarChart2, 
  CheckCircle2, 
  DollarSign, 
  Clock, 
  ShieldCheck,
  Building2
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid 
} from 'recharts';

interface OperatingKPIProps {
  deals: Deal[];
  selectedDeal: Deal;
  onSelectDeal: (dealId: string) => void;
}

export const OperatingKPIEngine: React.FC<OperatingKPIProps> = ({
  deals,
  selectedDeal,
  onSelectDeal
}) => {
  const portfolioDeals = deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO');
  const activeCompany = selectedDeal.isPortfolioCompany ? selectedDeal : portfolioDeals[0] || selectedDeal;

  // Operational metrics
  const headcount = activeCompany.headcount || 450;
  const revenuePerEmployee = (activeCompany.revenue * 1000000) / headcount;
  const capacityUtilization = 86.5;
  const customerRetentionRate = 96.2;
  const dso = 42; // Days sales outstanding
  const nps = 68; // Net promoter score

  const historicalTrends = [
    { period: '2022', revPerEmp: 280, capacity: 78, retention: 93 },
    { period: '2023', revPerEmp: 310, capacity: 81, retention: 94 },
    { period: '2024', revPerEmp: 345, capacity: 84, retention: 95 },
    { period: '2025 (YTD)', revPerEmp: Number((revenuePerEmployee / 1000).toFixed(0)), capacity: capacityUtilization, retention: customerRetentionRate }
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono-num text-[10px] font-bold uppercase">
              Micro-Operational Analytics
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Asset: <strong className="text-slate-200">{activeCompany.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <Activity className="w-6 h-6 text-amber-400" />
            Operating KPI & Unit Economics Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Operational efficiency telemetry: capacity utilization, revenue per FTE, customer retention, and working capital cycles.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Target:</label>
          <select
            value={activeCompany.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {portfolioDeals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName}</option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono-num">
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Total Headcount (FTE)</span>
          <span className="text-2xl font-bold text-slate-100 mt-1 block">{headcount}</span>
          <span className="text-[10px] text-emerald-400 font-sans">+18 Hired YTD</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Revenue / FTE</span>
          <span className="text-2xl font-bold text-amber-300 mt-1 block">€{(revenuePerEmployee / 1000).toFixed(0)}k</span>
          <span className="text-[10px] text-emerald-400 font-sans">+12% vs Peer Median</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Capacity Utilization</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">{capacityUtilization}%</span>
          <span className="text-[10px] text-slate-400 font-sans">Optimal Operational Band</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Gross Retention</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">{customerRetentionRate}%</span>
          <span className="text-[10px] text-sky-400 font-sans">Sticky Client Contracts</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">DSO (Cash Cycle)</span>
          <span className="text-2xl font-bold text-slate-200 mt-1 block">{dso} Days</span>
          <span className="text-[10px] text-emerald-400 font-sans">-16 Days vs Acquisition</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Net Promoter Score</span>
          <span className="text-2xl font-bold text-amber-400 mt-1 block">+{nps}</span>
          <span className="text-[10px] text-emerald-400 font-sans">World-Class NPS</span>
        </div>
      </div>

      {/* Charts & Operational Benchmarks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div className="lg:col-span-2 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <h3 className="font-display font-bold text-base text-slate-100">
            Productivity & Capacity Progression
          </h3>
          
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={historicalTrends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="period" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '8px', fontSize: '11px' }}
                />
                <Line type="monotone" dataKey="capacity" name="Capacity (%)" stroke="#f59e0b" strokeWidth={2} dot={{ fill: '#f59e0b' }} />
                <Line type="monotone" dataKey="retention" name="Retention (%)" stroke="#10b981" strokeWidth={2} dot={{ fill: '#10b981' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Operating Governance Status */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl space-y-3">
          <h3 className="font-display font-bold text-base text-slate-100">
            Operational Audit Matrix
          </h3>
          <div className="space-y-2 text-xs">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">ERP / IT Infrastructure</span>
              <span className="text-emerald-400 font-bold">Cloud SAP S/4HANA</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">Supply Chain Redundancy</span>
              <span className="text-emerald-400 font-bold">Dual-Source (100%)</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">Safety & Incident Rate (LTIR)</span>
              <span className="text-emerald-400 font-bold">0.12 (Zero Lost Time)</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
