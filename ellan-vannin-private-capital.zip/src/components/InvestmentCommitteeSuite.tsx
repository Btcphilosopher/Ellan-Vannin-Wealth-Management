import React, { useState } from 'react';
import { Deal, InvestmentCommitteeMember, ICVote } from '../types';
import { auditLogger } from '../services/auditLogger';
import { 
  Briefcase, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Printer, 
  Vote, 
  ShieldCheck, 
  Send,
  Building,
  DollarSign
} from 'lucide-react';

interface ICSuiteProps {
  deal: Deal;
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
  onUpdateDeal: (updated: Deal) => void;
  activeRole: string;
}

const DEFAULT_MEMBERS: InvestmentCommitteeMember[] = [
  { id: 'ic-1', name: 'Tom Quilliam', role: 'Managing General Partner & IC Chair', vote: 'APPROVE', comments: 'Outstanding market positioning in Nordic grid transformation with stable long-term regulatory asset backing.' },
  { id: 'ic-2', name: 'Alastair MacLeod', role: 'Senior Partner, Private Equity', vote: 'APPROVE', comments: 'Conservative 3.5x opening leverage leaves ample debt headroom for bolt-on M&A.' },
  { id: 'ic-3', name: 'Elinor Caine', role: 'Chief Risk Officer', vote: 'CONDITIONAL', conditions: ['Obtain W&I insurance policy with <€50k excess', 'Confirm environmental soil survey clean'], comments: 'Approved subject to formal signing of SPA indemnity escrow.' },
  { id: 'ic-4', name: 'Christian Kelly', role: 'Head of Portfolio Value Creation', vote: 'APPROVE', comments: 'Identified €4.2M in immediate procurement and operational EBITDA synergies.' },
  { id: 'ic-5', name: 'Isobel Teare', role: 'Independent Advisory Committee Member', vote: 'PENDING' }
];

export const InvestmentCommitteeSuite: React.FC<ICSuiteProps> = ({
  deal,
  deals,
  onSelectDeal,
  onUpdateDeal,
  activeRole
}) => {
  const [activeTab, setActiveTab] = useState<'MEMO' | 'VOTING' | 'MINUTES'>('MEMO');
  const [members, setMembers] = useState<InvestmentCommitteeMember[]>(DEFAULT_MEMBERS);
  const [myVote, setMyVote] = useState<ICVote>('APPROVE');
  const [myComment, setMyComment] = useState('');
  const [myConditions, setMyConditions] = useState('');
  const [voteSubmitted, setVoteSubmitted] = useState(false);

  const approveCount = members.filter(m => m.vote === 'APPROVE').length;
  const rejectCount = members.filter(m => m.vote === 'REJECT').length;
  const conditionalCount = members.filter(m => m.vote === 'CONDITIONAL').length;
  const pendingCount = members.filter(m => m.vote === 'PENDING').length;

  const handleCastVote = (e: React.FormEvent) => {
    e.preventDefault();

    const updated = members.map(m => {
      if (m.name.includes(activeRole) || m.id === 'ic-1') {
        return {
          ...m,
          vote: myVote,
          comments: myComment || 'Voted in formal IC session',
          conditions: myConditions ? myConditions.split(',').map(s => s.trim()) : undefined
        };
      }
      return m;
    });

    setMembers(updated);
    setVoteSubmitted(true);

    auditLogger.log(
      'IC_VOTE_CAST',
      `Investment Committee vote cast for ${deal.companyName}: ${myVote}`,
      activeRole,
      { dealId: deal.id, vote: myVote, comments: myComment, conditions: myConditions }
    );

    setTimeout(() => setVoteSubmitted(false), 4000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono-num text-[10px] font-bold uppercase">
              Formal Governance Suite
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              IC Target: <strong className="text-slate-200">{deal.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <Briefcase className="w-6 h-6 text-amber-400" />
            Investment Committee (IC) Decision Cockpit
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Binding investment approval portal: Formal Investment Memorandum, committee voting ledger, and condition tracking.
          </p>
        </div>

        {/* Quick Deal Switcher */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Target:</label>
          <select
            value={deal.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {deals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName} ({d.stage})</option>
            ))}
          </select>
        </div>
      </div>

      {/* IC Status & Voting Progress Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium block">Approved Votes</span>
            <span className="text-2xl font-bold text-emerald-400 mt-1 block font-mono-num">{approveCount} of {members.length}</span>
          </div>
          <CheckCircle2 className="w-8 h-8 text-emerald-400/50" />
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium block">Conditional Approvals</span>
            <span className="text-2xl font-bold text-amber-400 mt-1 block font-mono-num">{conditionalCount}</span>
          </div>
          <AlertCircle className="w-8 h-8 text-amber-400/50" />
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium block">Rejected Votes</span>
            <span className="text-2xl font-bold text-rose-400 mt-1 block font-mono-num">{rejectCount}</span>
          </div>
          <XCircle className="w-8 h-8 text-rose-400/50" />
        </div>

        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium block">Decision Quorum</span>
            <span className="text-sm font-bold text-slate-100 mt-1 block">Super-Majority (≥80%)</span>
          </div>
          <ShieldCheck className="w-8 h-8 text-sky-400/50" />
        </div>
      </div>

      {/* IC Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('MEMO')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeTab === 'MEMO'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <FileText className="w-3.5 h-3.5" /> Investment Memorandum (10 Sections)
        </button>

        <button
          onClick={() => setActiveTab('VOTING')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeTab === 'VOTING'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Vote className="w-3.5 h-3.5" /> Committee Ballots & Resolutions
        </button>
      </div>

      {/* Tab 1: Comprehensive Formal Investment Memorandum */}
      {activeTab === 'MEMO' && (
        <div className="bg-slate-900/90 text-slate-100 p-8 rounded-2xl border border-slate-800 shadow-2xl space-y-6 max-w-5xl mx-auto">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <div className="text-xs uppercase tracking-widest text-amber-400 font-bold">
                CONFIDENTIAL • FOR INVESTMENT COMMITTEE USE ONLY
              </div>
              <h2 className="font-display font-bold text-2xl text-slate-100 mt-1">
                INVESTMENT RECOMMENDATION MEMORANDUM
              </h2>
              <p className="text-xs text-slate-400">
                Project Code: <strong>{deal.companyName.toUpperCase()}</strong> • Lead Sponsor: <strong>{deal.leadPartner}</strong>
              </p>
            </div>
            <button
              onClick={() => window.print()}
              className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 no-print cursor-pointer"
            >
              <Printer className="w-4 h-4" /> Print Formal Memo
            </button>
          </div>

          {/* Section 1: Executive Summary */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-amber-300 uppercase tracking-wider border-b border-slate-800/80 pb-1">
              1. Executive Summary & Recommendation
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              The deal team formally recommends that Ellan Vannin Private Capital Fund I acquire a controlling equity interest in <strong>{deal.companyName}</strong> for an Enterprise Value of <strong>€{deal.proposedValuationEV.toFixed(1)}M</strong> (representing <strong>{(deal.proposedValuationEV / (deal.ebitda || 1)).toFixed(1)}x LTM EBITDA</strong>). The proposed investment requires an equity check of <strong>€{deal.dealSizeEquity.toFixed(1)}M</strong>, underwriting a Base Case Gross IRR of <strong>{deal.targetIRR.toFixed(1)}%</strong> and <strong>{deal.targetMOIC.toFixed(2)}x Gross MOIC</strong> over a 5-year investment horizon.
            </p>
          </div>

          {/* Section 2: Investment Thesis */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-amber-300 uppercase tracking-wider border-b border-slate-800/80 pb-1">
              2. Core Investment Thesis & Value Drivers
            </h3>
            <ul className="list-disc pl-5 text-xs text-slate-300 space-y-1.5 leading-relaxed">
              <li><strong>Market Leadership:</strong> Category dominant position in {deal.sector} across {deal.country} and Western Europe.</li>
              <li><strong>High Cash Conversion:</strong> Asset-light operating model converting &gt;75% of EBITDA into free cash flow for rapid senior debt paydown.</li>
              <li><strong>Pricing Power:</strong> Long-term CPI-indexed contractual framework with mission-critical client retention (&gt;96% gross retention).</li>
              <li><strong>M&A Consolidation Runway:</strong> Highly fragmented competitor base with 4 identified proprietary add-on targets ready for bolt-on execution.</li>
            </ul>
          </div>

          {/* Section 3: Key Financial Highlights */}
          <div className="space-y-2 font-mono-num">
            <h3 className="text-sm font-bold text-amber-300 uppercase tracking-wider border-b border-slate-800/80 pb-1 font-sans">
              3. Underwriting Financial Snapshot
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[10px] font-sans">LTM Revenue</span>
                <span className="text-slate-100 font-bold text-sm">€{deal.revenue.toFixed(1)}M</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[10px] font-sans">LTM EBITDA</span>
                <span className="text-emerald-400 font-bold text-sm">€{deal.ebitda.toFixed(1)}M ({deal.ebitdaMargin}%)</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[10px] font-sans">Opening Leverage</span>
                <span className="text-amber-400 font-bold text-sm">3.5x EBITDA</span>
              </div>
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-slate-500 block text-[10px] font-sans">Target IRR / MOIC</span>
                <span className="text-emerald-400 font-bold text-sm">{deal.targetIRR}% / {deal.targetMOIC}x</span>
              </div>
            </div>
          </div>

          {/* Section 4: Risks & Mitigants */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-amber-300 uppercase tracking-wider border-b border-slate-800/80 pb-1">
              4. Key Risk Factors & Sponsor Mitigants
            </h3>
            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="font-bold text-rose-400">Risk 1: Raw Material Input Inflation</span>
                <p className="text-slate-300 mt-1">
                  Mitigant: Contractual quarterly cost-pass-through clauses in 80% of customer agreements legally transfer inflationary surges.
                </p>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="font-bold text-rose-400">Risk 2: Management Transition</span>
                <p className="text-slate-300 mt-1">
                  Mitigant: Founder CEO rolling over 12% equity with a 4-year lockup and succession plan already initiated with appointed COO.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Committee Voting Ledger & Ballot */}
      {activeTab === 'VOTING' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left 2 Cols: Committee Roster Votes */}
          <div className="lg:col-span-2 space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl">
            <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
              <Vote className="w-4 h-4 text-amber-400" />
              Investment Committee Recorded Ballots
            </h3>

            <div className="space-y-3">
              {members.map((member) => (
                <div key={member.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-bold text-sm text-slate-100">{member.name}</div>
                      <div className="text-[11px] text-slate-400">{member.role}</div>
                    </div>
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-bold font-mono-num border uppercase ${
                      member.vote === 'APPROVE'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        : member.vote === 'CONDITIONAL'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                        : member.vote === 'REJECT'
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                        : 'bg-slate-800 text-slate-400 border-slate-700'
                    }`}>
                      {member.vote}
                    </span>
                  </div>

                  {member.comments && (
                    <p className="text-xs text-slate-300 italic pt-1 border-t border-slate-800/80">
                      &ldquo;{member.comments}&rdquo;
                    </p>
                  )}

                  {member.conditions && member.conditions.length > 0 && (
                    <div className="mt-1 pt-1 text-[11px] text-amber-300">
                      <strong>Binding Conditions:</strong> {member.conditions.join(' • ')}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Right Col: Cast Vote Panel */}
          <form onSubmit={handleCastVote} className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl self-start">
            <h3 className="font-display font-bold text-base text-slate-100">
              Cast Committee Ballot
            </h3>
            <p className="text-xs text-slate-400">
              Voting as: <strong className="text-amber-400">{activeRole}</strong>
            </p>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 block">Formal Vote</label>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setMyVote('APPROVE')}
                  className={`py-2 rounded-lg font-bold border cursor-pointer ${
                    myVote === 'APPROVE'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  APPROVE
                </button>
                <button
                  type="button"
                  onClick={() => setMyVote('CONDITIONAL')}
                  className={`py-2 rounded-lg font-bold border cursor-pointer ${
                    myVote === 'CONDITIONAL'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  CONDITIONAL
                </button>
                <button
                  type="button"
                  onClick={() => setMyVote('REJECT')}
                  className={`py-2 rounded-lg font-bold border cursor-pointer ${
                    myVote === 'REJECT'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  REJECT
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Deliberation Comments</label>
              <textarea
                rows={3}
                value={myComment}
                onChange={(e) => setMyComment(e.target.value)}
                placeholder="Enter rationale for vote..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-400"
              />
            </div>

            {myVote === 'CONDITIONAL' && (
              <div>
                <label className="text-xs font-semibold text-amber-300 block mb-1">Binding Closing Conditions</label>
                <input
                  type="text"
                  value={myConditions}
                  onChange={(e) => setMyConditions(e.target.value)}
                  placeholder="e.g. W&I insurance, key customer contract extension"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-400"
                />
              </div>
            )}

            {voteSubmitted && (
              <div className="p-2.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-semibold flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4" /> Ballot Recorded into Audit Trail
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 text-slate-950 font-bold text-xs shadow-lg shadow-amber-950/40 cursor-pointer"
            >
              Submit Binding Resolution
            </button>
          </form>

        </div>
      )}
    </div>
  );
};
