import React, { useState } from 'react';
import { Deal, AddOnTarget } from '../types';
import { 
  GitMerge, 
  Plus, 
  TrendingUp, 
  Layers, 
  DollarSign, 
  CheckCircle, 
  Scale,
  Sparkles,
  Building2
} from 'lucide-react';

interface AddOnProps {
  deals: Deal[];
  selectedDeal: Deal;
  onSelectDeal: (dealId: string) => void;
  onUpdateDeal: (updated: Deal) => void;
}

const DEFAULT_BOLT_ONS: AddOnTarget[] = [
  { id: 'target-1', name: 'Nordic Grid Solutions AB', targetRevenue: 32.0, targetEbitda: 5.4, purchasePrice: 42.0, synergiesEbitda: 2.1, status: 'DILIGENCE', strategicFit: 'Provides geographic expansion into Swedish offshore transmission and adds 22 high-voltage engineers.' },
  { id: 'target-2', name: 'Baltic Cable Technologies', targetRevenue: 18.0, targetEbitda: 3.2, purchasePrice: 24.0, synergiesEbitda: 1.2, status: 'SCREENING', strategicFit: 'Direct proprietary supplier integration eliminating external sub-contractor margin.' }
];

export const AddOnAcquisitionEngine: React.FC<AddOnProps> = ({
  deals,
  selectedDeal,
  onSelectDeal,
  onUpdateDeal
}) => {
  const portfolioDeals = deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO');
  const activeCompany = selectedDeal.isPortfolioCompany ? selectedDeal : portfolioDeals[0] || selectedDeal;

  const [targets, setTargets] = useState<AddOnTarget[]>(
    activeCompany.addOnTargets || DEFAULT_BOLT_ONS
  );

  // Standalone Base Platform
  const baseRevenue = activeCompany.revenue;
  const baseEbitda = activeCompany.ebitda;
  const baseEV = activeCompany.currentValuationEV || activeCompany.proposedValuationEV;

  // Add-on Totals
  const totalTargetRevenue = targets.reduce((s, t) => s + t.targetRevenue, 0);
  const totalTargetEbitda = targets.reduce((s, t) => s + t.targetEbitda, 0);
  const totalSynergies = targets.reduce((s, t) => s + t.synergiesEbitda, 0);
  const totalPurchasePrice = targets.reduce((s, t) => s + t.purchasePrice, 0);

  // Combined Pro-Forma Platform
  const proFormaRevenue = baseRevenue + totalTargetRevenue;
  const proFormaEbitda = baseEbitda + totalTargetEbitda + totalSynergies;
  const platformExitMultiple = 11.5; // Multiple arbitrage
  const proFormaEV = proFormaEbitda * platformExitMultiple;
  const netValueCreated = proFormaEV - (baseEV + totalPurchasePrice);

  const handleAddTarget = () => {
    const newT: AddOnTarget = {
      id: `target-${Date.now()}`,
      name: 'New Bolt-on Target (Confidential)',
      targetRevenue: 15.0,
      targetEbitda: 2.5,
      purchasePrice: 18.0,
      synergiesEbitda: 1.0,
      status: 'SCREENING',
      strategicFit: 'Regional expansion bolt-on'
    };
    setTargets([...targets, newT]);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono-num text-[10px] font-bold uppercase">
              Buy-and-Build Strategy
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Platform Asset: <strong className="text-slate-200">{activeCompany.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <GitMerge className="w-6 h-6 text-amber-400" />
            Add-on M&A & Multiple Arbitrage Modeler
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Model bolt-on acquisitions, calculate post-synergy pro-forma EBITDA, and harvest platform multiple arbitrage.
          </p>
        </div>

        {/* Quick Deal Switcher */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Platform:</label>
          <select
            value={activeCompany.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {portfolioDeals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Pro-Forma Summary KPI Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono-num">
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Pro-Forma Revenue</span>
          <span className="text-2xl font-bold text-slate-100 mt-1 block">€{proFormaRevenue.toFixed(1)}M</span>
          <span className="text-[10px] text-emerald-400 font-sans">+€{totalTargetRevenue.toFixed(1)}M Acquired</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Pro-Forma EBITDA</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">€{proFormaEbitda.toFixed(1)}M</span>
          <span className="text-[10px] text-emerald-400 font-sans">Incl. €{totalSynergies.toFixed(1)}M Synergies</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Target Multiple (Blended)</span>
          <span className="text-2xl font-bold text-amber-400 mt-1 block">
            {(totalPurchasePrice / (totalTargetEbitda || 1)).toFixed(1)}x
          </span>
          <span className="text-[10px] text-slate-400 font-sans">Entry Multiple on Add-ons</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Platform Exit Multiple</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">{platformExitMultiple}x</span>
          <span className="text-[10px] text-sky-400 font-sans">Multiple Arbitrage Premium</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Pro-Forma EV</span>
          <span className="text-2xl font-bold text-amber-300 mt-1 block">€{proFormaEV.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">Combined Group Valuation</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Arbitrage Value Created</span>
          <span className="text-2xl font-bold text-emerald-300 mt-1 block">+€{netValueCreated.toFixed(1)}M</span>
          <span className="text-[10px] text-emerald-400 font-sans">Net Sponsor Value Add</span>
        </div>
      </div>

      {/* Targets Table & Pro-Forma Bridge */}
      <div className="space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="font-display font-bold text-base text-slate-100">
              Active Add-on M&A Pipeline Targets
            </h3>
            <p className="text-xs text-slate-400">Proprietary consolidation pipeline under review</p>
          </div>

          <button
            onClick={handleAddTarget}
            className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> Originate Add-on
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-num">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="py-2.5 px-3">Target Name</th>
                <th className="py-2.5 px-2 text-right">Revenue (€M)</th>
                <th className="py-2.5 px-2 text-right">EBITDA (€M)</th>
                <th className="py-2.5 px-2 text-right">Price (€M)</th>
                <th className="py-2.5 px-2 text-right">Post-Synergy Multiple</th>
                <th className="py-2.5 px-2 text-right">Run-Rate Synergies</th>
                <th className="py-2.5 px-2 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {targets.map((t) => {
                const postSynergyMult = t.purchasePrice / (t.targetEbitda + t.synergiesEbitda);
                return (
                  <tr key={t.id} className="hover:bg-slate-800/30">
                    <td className="py-3 px-3 font-sans">
                      <div className="font-bold text-slate-100">{t.name}</div>
                      <div className="text-[11px] text-slate-400">{t.strategicFit}</div>
                    </td>
                    <td className="py-3 px-2 text-right text-slate-300">€{t.targetRevenue.toFixed(1)}M</td>
                    <td className="py-3 px-2 text-right text-slate-300">€{t.targetEbitda.toFixed(1)}M</td>
                    <td className="py-3 px-2 text-right text-amber-300 font-bold">€{t.purchasePrice.toFixed(1)}M</td>
                    <td className="py-3 px-2 text-right font-bold text-emerald-400">{postSynergyMult.toFixed(1)}x</td>
                    <td className="py-3 px-2 text-right text-emerald-300">+€{t.synergiesEbitda.toFixed(1)}M</td>
                    <td className="py-3 px-2 text-center">
                      <span className="px-2 py-0.5 rounded text-[10px] font-sans font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        {t.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
