import React, { useState } from 'react';
import { Deal } from '../types';
import { 
  RefreshCw, 
  Coins, 
  TrendingUp, 
  DollarSign, 
  AlertTriangle, 
  CheckCircle, 
  Sliders,
  Scale
} from 'lucide-react';

interface RefinancingProps {
  deals: Deal[];
  selectedDeal: Deal;
  onSelectDeal: (dealId: string) => void;
}

export const RefinancingEngine: React.FC<RefinancingProps> = ({
  deals,
  selectedDeal,
  onSelectDeal
}) => {
  const portfolioDeals = deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO');
  const activeCompany = selectedDeal.isPortfolioCompany ? selectedDeal : portfolioDeals[0] || selectedDeal;

  // Refinancing parameters
  const [currentEbitda, setCurrentEbitda] = useState<number>(activeCompany.ebitda);
  const [currentDebt, setCurrentDebt] = useState<number>(activeCompany.currentNetDebt || 20.0);
  const [targetLeverageMultiple, setTargetLeverageMultiple] = useState<number>(4.0); // e.g. 4.0x
  const [newInterestRate, setNewInterestRate] = useState<number>(5.75); // %
  const [interestRateShockBps, setInterestRateShockBps] = useState<number>(150); // bps

  // Calculations
  const newDebtCapacity = currentEbitda * targetLeverageMultiple;
  const grossProceedsRaised = Math.max(0, newDebtCapacity - currentDebt);
  const refinancingFees = grossProceedsRaised * 0.02;
  const netDividendDistribution = Math.max(0, grossProceedsRaised - refinancingFees);

  // Interest burden
  const annualInterestBase = (newDebtCapacity * (newInterestRate / 100));
  const annualInterestShocked = (newDebtCapacity * ((newInterestRate + (interestRateShockBps / 100)) / 100));
  const interestCoverageBase = currentEbitda / (annualInterestBase || 1);
  const interestCoverageShocked = currentEbitda / (annualInterestShocked || 1);

  // DPI impact
  const entryEquity = activeCompany.entryEquity || activeCompany.dealSizeEquity;
  const dpiGenerated = entryEquity > 0 ? (netDividendDistribution / entryEquity) : 0;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono-num text-[10px] font-bold uppercase">
              Capital Structure Refinancing
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              Asset: <strong className="text-slate-200">{activeCompany.companyName}</strong>
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <RefreshCw className="w-6 h-6 text-amber-400" />
            Refinancing & Dividend Recapitalization Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Model debt capacity expansion, dividend recaps, accelerated LP liquidity (DPI), and interest rate shock sensitivity.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Target:</label>
          <select
            value={activeCompany.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {portfolioDeals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Recap Summary KPI Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono-num">
        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">New Gross Debt</span>
          <span className="text-2xl font-bold text-slate-100 mt-1 block">€{newDebtCapacity.toFixed(1)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">{targetLeverageMultiple.toFixed(1)}x Debt / EBITDA</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Net Dividend Proceeds</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">€{netDividendDistribution.toFixed(1)}M</span>
          <span className="text-[10px] text-emerald-400 font-sans">Distributed to Fund LPs</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">DPI Acceleration</span>
          <span className="text-2xl font-bold text-sky-400 mt-1 block">+{dpiGenerated.toFixed(2)}x</span>
          <span className="text-[10px] text-sky-400 font-sans">Immediate Capital Returned</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Base Annual Interest</span>
          <span className="text-2xl font-bold text-slate-200 mt-1 block">€{annualInterestBase.toFixed(2)}M</span>
          <span className="text-[10px] text-slate-400 font-sans">At {newInterestRate.toFixed(2)}% Coupon</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Base ICR Coverage</span>
          <span className="text-2xl font-bold text-emerald-400 mt-1 block">{interestCoverageBase.toFixed(2)}x</span>
          <span className="text-[10px] text-slate-400 font-sans">Covenant Floor: 2.5x</span>
        </div>

        <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 shadow">
          <span className="text-slate-400 text-[11px] font-sans block">Shocked ICR (+{interestRateShockBps}bps)</span>
          <span className={`text-2xl font-bold mt-1 block ${interestCoverageShocked >= 2.5 ? 'text-amber-300' : 'text-rose-400'}`}>
            {interestCoverageShocked.toFixed(2)}x
          </span>
          <span className="text-[10px] text-slate-400 font-sans">Stress Test Headroom</span>
        </div>
      </div>

      {/* Recap Controls & Covenants */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <div className="space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl">
          <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            Refinancing & Leverage Levers
          </h3>

          <div className="space-y-4 font-mono-num">
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Target Recap Leverage Multiple</span>
                <span className="font-bold text-amber-400">{targetLeverageMultiple.toFixed(1)}x EBITDA</span>
              </div>
              <input
                type="range"
                min="2.0"
                max="5.5"
                step="0.25"
                value={targetLeverageMultiple}
                onChange={(e) => setTargetLeverageMultiple(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">New Term Debt Margin / Interest Rate (%)</span>
                <span className="font-bold text-slate-100">{newInterestRate.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min="3.5"
                max="9.0"
                step="0.25"
                value={newInterestRate}
                onChange={(e) => setNewInterestRate(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-300">Macro Interest Rate Shock (Basis Points)</span>
                <span className="font-bold text-rose-400">+{interestRateShockBps} bps</span>
              </div>
              <input
                type="range"
                min="0"
                max="400"
                step="25"
                value={interestRateShockBps}
                onChange={(e) => setInterestRateShockBps(Number(e.target.value))}
                className="w-full accent-rose-500 bg-slate-950 h-1.5 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Covenant & Liquidity Safeguards */}
        <div className="space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl">
          <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
            <Scale className="w-4 h-4 text-amber-400" />
            Lender Covenant Headroom Matrix
          </h3>

          <div className="space-y-3 text-xs font-mono-num">
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-sans font-bold text-slate-200 block">Leverage Covenant Limit</span>
                <span className="text-[11px] text-slate-400">Senior Net Debt / EBITDA</span>
              </div>
              <div className="text-right">
                <span className="text-slate-100 font-bold">Max 4.75x</span>
                <span className="text-emerald-400 text-[10px] block font-sans">Compliant ({targetLeverageMultiple}x)</span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-sans font-bold text-slate-200 block">Minimum Interest Coverage (ICR)</span>
                <span className="text-[11px] text-slate-400">EBITDA / Net Interest</span>
              </div>
              <div className="text-right">
                <span className="text-slate-100 font-bold">Min 2.50x</span>
                <span className={`text-[10px] block font-sans ${interestCoverageShocked >= 2.5 ? 'text-emerald-400' : 'text-rose-400 font-bold'}`}>
                  {interestCoverageShocked >= 2.5 ? 'Safe Headroom' : 'Potential Breach Under Shock'}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-sans font-bold text-slate-200 block">Minimum Liquidity Cushion</span>
                <span className="text-[11px] text-slate-400">Cash + Undrawn RCF</span>
              </div>
              <div className="text-right">
                <span className="text-slate-100 font-bold">€15.0M</span>
                <span className="text-emerald-400 text-[10px] block font-sans">€22.5M Available</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
