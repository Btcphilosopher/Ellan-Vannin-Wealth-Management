import React, { useState } from 'react';
import { Deal, DueDiligenceIssue, VirtualDataRoomDoc } from '../types';
import { 
  SearchCode, 
  FileText, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  Lock, 
  Download, 
  FolderOpen, 
  PlusCircle,
  Building2,
  Scale,
  Users
} from 'lucide-react';

interface DDProps {
  deal: Deal;
  deals: Deal[];
  onSelectDeal: (dealId: string) => void;
  onUpdateDeal: (updated: Deal) => void;
  onNavigateToTab: (tab: any) => void;
}

export const DueDiligenceSuite: React.FC<DDProps> = ({
  deal,
  deals,
  onSelectDeal,
  onUpdateDeal,
  onNavigateToTab
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'FINANCIAL' | 'COMMERCIAL' | 'MANAGEMENT' | 'VDR' | 'ISSUES'>('FINANCIAL');
  const [newIssueDesc, setNewIssueDesc] = useState('');
  const [newIssueCategory, setNewIssueCategory] = useState<'FINANCIAL' | 'LEGAL' | 'COMMERCIAL' | 'TAX' | 'ESG'>('FINANCIAL');
  const [newIssueSeverity, setNewIssueSeverity] = useState<'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'>('MEDIUM');

  const handleAddIssue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIssueDesc.trim()) return;

    const newIssue: DueDiligenceIssue = {
      id: `issue-${Date.now()}`,
      category: newIssueCategory,
      title: newIssueDesc,
      severity: newIssueSeverity,
      impact: 'Potential value adjustment or indemnity requirement in SPA',
      mitigant: 'Holdback escrow or warranty insurance under review',
      status: 'OPEN',
      assignedTo: 'Deal Team'
    };

    const updatedDeal: Deal = {
      ...deal,
      dueDiligenceIssues: [...(deal.dueDiligenceIssues || []), newIssue]
    };

    onUpdateDeal(updatedDeal);
    setNewIssueDesc('');
  };

  const handleToggleIssueStatus = (issueId: string) => {
    const updatedIssues = (deal.dueDiligenceIssues || []).map(i => {
      if (i.id === issueId) {
        return {
          ...i,
          status: (i.status === 'RESOLVED' ? 'OPEN' : 'RESOLVED') as any
        };
      }
      return i;
    });

    onUpdateDeal({
      ...deal,
      dueDiligenceIssues: updatedIssues
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header & Deal Selector */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono-num text-[10px] font-bold uppercase">
              {deal.stage}
            </span>
            <span className="text-xs text-slate-400 font-mono-num">
              EVWM Underwriting ID: {deal.id}
            </span>
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-100 mt-1 flex items-center gap-2">
            <SearchCode className="w-6 h-6 text-amber-400" />
            Due Diligence & Virtual Data Room (VDR) Suite
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional multi-track diligence repository: Financial Q&E, Commercial Strategy, Management Audit & Secure VDR.
          </p>
        </div>

        {/* Deal Quick Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400">Target:</label>
          <select
            value={deal.id}
            onChange={(e) => onSelectDeal(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer"
          >
            {deals.map(d => (
              <option key={d.id} value={d.id}>{d.companyName} ({d.stage})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Diligence Sub-Tab Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveSubTab('FINANCIAL')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeSubTab === 'FINANCIAL'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <FileText className="w-3.5 h-3.5" /> Financial Quality of Earnings (QoE)
        </button>

        <button
          onClick={() => setActiveSubTab('COMMERCIAL')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeSubTab === 'COMMERCIAL'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" /> Commercial & Market DD
        </button>

        <button
          onClick={() => setActiveSubTab('MANAGEMENT')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeSubTab === 'MANAGEMENT'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" /> Management Assessment
        </button>

        <button
          onClick={() => setActiveSubTab('ISSUES')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeSubTab === 'ISSUES'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" /> Diligence Risk Matrix ({deal.dueDiligenceIssues?.length || 0})
        </button>

        <button
          onClick={() => setActiveSubTab('VDR')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeSubTab === 'VDR'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Lock className="w-3.5 h-3.5 text-amber-400" /> Virtual Data Room (VDR)
        </button>
      </div>

      {/* Sub-Tab 1: Financial Quality of Earnings (QoE) */}
      {activeSubTab === 'FINANCIAL' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono-num">
            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
              <div className="text-slate-400 text-xs font-sans">Reported EBITDA</div>
              <div className="text-xl font-bold text-slate-100 mt-1">€{deal.ebitda}M</div>
              <div className="text-[11px] text-slate-400 mt-1">LTM Management Accounts</div>
            </div>

            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
              <div className="text-slate-400 text-xs font-sans">Adjusted Quality EBITDA</div>
              <div className="text-xl font-bold text-emerald-400 mt-1">
                €{(deal.financialDD?.adjustedEBITDA || deal.ebitda * 0.96).toFixed(1)}M
              </div>
              <div className="text-[11px] text-emerald-400/80 mt-1">Post-Diligence Normalization</div>
            </div>

            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
              <div className="text-slate-400 text-xs font-sans">Working Capital Target</div>
              <div className="text-xl font-bold text-amber-400 mt-1">
                €{(deal.financialDD?.workingCapitalTarget || 14.5).toFixed(1)}M
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Normalized NWC Peg</div>
            </div>

            <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 shadow">
              <div className="text-slate-400 text-xs font-sans">Maintenance Capex</div>
              <div className="text-xl font-bold text-sky-400 mt-1">
                €{(deal.financialDD?.maintenanceCapex || 6.2).toFixed(1)}M
              </div>
              <div className="text-[11px] text-slate-400 mt-1">Verified Annual Base Capex</div>
            </div>
          </div>

          <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
            <h3 className="font-display font-bold text-base text-slate-100">
              EBITDA Bridge & Quality of Earnings Adjustments
            </h3>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono-num">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                    <th className="py-2.5 px-3">Adjustment Description</th>
                    <th className="py-2.5 px-2">Type</th>
                    <th className="py-2.5 px-2 text-right">EBITDA Impact</th>
                    <th className="py-2.5 px-3 font-sans">Diligence Note / Reference</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {deal.financialDD?.ebitdaAdjustments?.map((adj, i) => (
                    <tr key={i} className="hover:bg-slate-800/30">
                      <td className="py-3 px-3 font-sans font-medium text-slate-200">{adj.description}</td>
                      <td className="py-3 px-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-sans font-semibold ${
                          adj.type === 'ADD_BACK' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                        }`}>
                          {adj.type}
                        </span>
                      </td>
                      <td className={`py-3 px-2 text-right font-bold ${
                        adj.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {adj.amount >= 0 ? `+€${adj.amount.toFixed(2)}M` : `-€${Math.abs(adj.amount).toFixed(2)}M`}
                      </td>
                      <td className="py-3 px-3 font-sans text-slate-400 text-[11px]">
                        Audited by Big 4 Transaction Advisory Services
                      </td>
                    </tr>
                  )) || (
                    <tr>
                      <td colSpan={4} className="py-4 text-center text-slate-500 font-sans">
                        No custom EBITDA adjustments logged.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 2: Commercial & Market DD */}
      {activeSubTab === 'COMMERCIAL' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl">
            <h3 className="font-display font-bold text-base text-slate-100">
              Commercial Due Diligence (CDD) Findings
            </h3>
            
            <div className="grid grid-cols-2 gap-4 text-xs font-mono-num">
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 text-[11px] font-sans block">Total Addressable Market (TAM)</span>
                <span className="text-lg font-bold text-slate-100 mt-1 block">€{deal.commercialDD?.tam || 4500}M</span>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 text-[11px] font-sans block">Market Growth Rate (CAGR)</span>
                <span className="text-lg font-bold text-emerald-400 mt-1 block">+{deal.commercialDD?.marketGrowthRate || 8.5}% p.a.</span>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 text-[11px] font-sans block">Market Share Ranking</span>
                <span className="text-lg font-bold text-amber-400 mt-1 block">{deal.commercialDD?.marketShare || 'Top 2 Player'}</span>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400 text-[11px] font-sans block">Top 10 Customer Concentration</span>
                <span className="text-lg font-bold text-slate-200 mt-1 block">{deal.commercialDD?.customerConcentrationTop10 || 28}%</span>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Pricing Power & Moat</h4>
              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                {deal.commercialDD?.pricingPowerNotes || 'Strong contractual indexation to CPI and input costs with multi-year take-or-pay agreements across 75% of customer volume.'}
              </p>
            </div>
          </div>

          <div className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl">
            <h3 className="font-display font-bold text-base text-slate-100">Competitor Landscape</h3>
            <div className="space-y-2">
              {deal.commercialDD?.competitors?.map((comp, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs">
                  <div className="font-bold text-slate-200">{comp}</div>
                  <div className="text-slate-400 text-[11px] mt-0.5">Tier 1 Competitor in {deal.country}</div>
                </div>
              )) || (
                <div className="text-xs text-slate-500">No competitors listed.</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 3: Management Assessment */}
      {activeSubTab === 'MANAGEMENT' && (
        <div className="bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="font-display font-bold text-base text-slate-100">
                C-Suite Executive Roster & Incentivization
              </h3>
              <p className="text-xs text-slate-400">Management retention, track record, rollover equity & MIP pooling</p>
            </div>
            <span className="px-3 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold font-mono-num">
              Quality Score: {deal.managementDD?.managementQualityScore || 90}/100
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {deal.managementDD?.keyExecutives?.map((exec, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-100">{exec.name}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-900 text-amber-400 border border-slate-800">
                    {exec.role}
                  </span>
                </div>
                <div className="text-xs text-slate-400">Tenure: <strong className="text-slate-300">{exec.tenureYears} Years</strong></div>
                <div className="text-xs text-slate-400">Rollover Equity: <strong className="text-emerald-400">{exec.rolloverEquityPercent}%</strong></div>
                <p className="text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">{exec.background}</p>
              </div>
            ))}
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs font-mono-num">
            <div>
              <span className="font-bold text-slate-200">Management Incentive Plan (MIP) Pool:</span>
              <span className="text-slate-400 ml-2">Allocated post-acquisition sweet equity</span>
            </div>
            <span className="text-sm font-bold text-amber-400">
              {deal.managementDD?.mipPoolPercent || 8.0}% of Total Equity
            </span>
          </div>
        </div>
      )}

      {/* Sub-Tab 4: Diligence Issues Risk Matrix */}
      {activeSubTab === 'ISSUES' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl">
            <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              Active Diligence Risk Tracker & Mitigants
            </h3>

            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
              {(deal.dueDiligenceIssues || []).map((issue) => (
                <div 
                  key={issue.id} 
                  className={`p-4 rounded-xl border transition-all ${
                    issue.status === 'RESOLVED' 
                      ? 'bg-slate-950/40 border-slate-800/60 opacity-60' 
                      : 'bg-slate-950 border-slate-800 hover:border-amber-500/40'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${
                        issue.severity === 'CRITICAL' || issue.severity === 'HIGH'
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                          : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      }`}>
                        {issue.severity}
                      </span>
                      <span className="text-xs font-semibold text-slate-400 uppercase">
                        [{issue.category}]
                      </span>
                      <h4 className="font-bold text-xs text-slate-100">{issue.title}</h4>
                    </div>

                    <button
                      onClick={() => handleToggleIssueStatus(issue.id)}
                      className={`px-2.5 py-1 rounded text-[11px] font-semibold flex items-center gap-1 cursor-pointer ${
                        issue.status === 'RESOLVED'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {issue.status}
                    </button>
                  </div>

                  <div className="mt-2 text-xs text-slate-400 space-y-1">
                    <div><strong>Potential Impact:</strong> {issue.impact}</div>
                    <div className="text-amber-300"><strong>Mitigant:</strong> {issue.mitigant}</div>
                  </div>
                </div>
              ))}

              {(!deal.dueDiligenceIssues || deal.dueDiligenceIssues.length === 0) && (
                <div className="text-center py-8 text-slate-500 text-xs">
                  No issues flagged. Deal due diligence clean.
                </div>
              )}
            </div>
          </div>

          {/* Add New Issue Form */}
          <form onSubmit={handleAddIssue} className="space-y-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl self-start">
            <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
              <PlusCircle className="w-4 h-4 text-amber-400" />
              Log Diligence Issue
            </h3>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Issue Description</label>
              <textarea
                rows={3}
                value={newIssueDesc}
                onChange={(e) => setNewIssueDesc(e.target.value)}
                placeholder="e.g. Historic tax deduction audit under inquiry..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Category</label>
                <select
                  value={newIssueCategory}
                  onChange={(e) => setNewIssueCategory(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="FINANCIAL">FINANCIAL</option>
                  <option value="LEGAL">LEGAL</option>
                  <option value="COMMERCIAL">COMMERCIAL</option>
                  <option value="TAX">TAX</option>
                  <option value="ESG">ESG</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Severity</label>
                <select
                  value={newIssueSeverity}
                  onChange={(e) => setNewIssueSeverity(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="LOW">LOW</option>
                  <option value="MEDIUM">MEDIUM</option>
                  <option value="HIGH">HIGH</option>
                  <option value="CRITICAL">CRITICAL</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 text-slate-950 font-bold text-xs shadow-lg shadow-amber-950/40 cursor-pointer"
            >
              + Log to Issue Matrix
            </button>
          </form>
        </div>
      )}

      {/* Sub-Tab 5: Virtual Data Room (VDR) */}
      {activeSubTab === 'VDR' && (
        <div className="space-y-4 bg-slate-900/80 p-6 rounded-2xl border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
                <Lock className="w-4 h-4 text-amber-400" />
                Virtual Data Room (VDR) - {deal.companyName}
              </h3>
              <p className="text-xs text-slate-400">Encrypted institutional repository with audit logging of document access</p>
            </div>
            <span className="text-xs text-slate-400 font-mono-num">
              {deal.virtualDataRoom?.length || 0} Documents Uploaded
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {deal.virtualDataRoom?.map((doc) => (
              <div 
                key={doc.id}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-500/40 transition-colors flex items-center justify-between group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center shrink-0">
                    <FileText className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-xs text-slate-100 truncate">{doc.title}</div>
                    <div className="text-[10px] text-slate-400 font-mono-num mt-0.5">
                      {doc.category} • {doc.sizeMb}MB • {doc.uploadDate}
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => alert(`Simulating secure VDR download for ${doc.title}`)}
                  className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-amber-300 border border-slate-800 cursor-pointer"
                  title="Download Document"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
