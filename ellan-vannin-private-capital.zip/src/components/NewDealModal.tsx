import React, { useState } from 'react';
import { Deal, DealStage } from '../types';
import { auditLogger } from '../services/auditLogger';
import { 
  X, 
  Building2, 
  DollarSign, 
  MapPin, 
  Briefcase, 
  Sparkles, 
  PlusCircle, 
  TrendingUp 
} from 'lucide-react';

interface NewDealModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddDeal: (deal: Deal) => void;
  activeRole: string;
}

export const NewDealModal: React.FC<NewDealModalProps> = ({
  isOpen,
  onClose,
  onAddDeal,
  activeRole
}) => {
  if (!isOpen) return null;

  const [companyName, setCompanyName] = useState('');
  const [sector, setSector] = useState('Energy Infrastructure & Transition');
  const [country, setCountry] = useState('United Kingdom');
  const [revenue, setRevenue] = useState<number>(45.0);
  const [ebitda, setEbitda] = useState<number>(9.0);
  const [ebitdaMargin, setEbitdaMargin] = useState<number>(20.0);
  const [valuationEV, setValuationEV] = useState<number>(75.0);
  const [equityCheck, setEquityCheck] = useState<number>(45.0);
  const [stage, setStage] = useState<DealStage>('SOURCING');
  const [leadPartner, setLeadPartner] = useState('Alastair MacLeod');
  const [targetIRR, setTargetIRR] = useState<number>(22.0);
  const [targetMOIC, setTargetMOIC] = useState<number>(2.4);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyName.trim()) return;

    const newDeal: Deal = {
      id: `deal-${Date.now()}`,
      companyName,
      sector,
      country,
      revenue,
      ebitda,
      ebitdaMargin,
      proposedValuationEV: valuationEV,
      dealSizeEquity: equityCheck,
      stage,
      leadPartner,
      targetIRR,
      targetMOIC,
      sourceDate: new Date().toISOString().split('T')[0],
      scorecard: {
        marketAttractiveness: 8.0,
        competitiveMoat: 8.5,
        financialProfile: 7.5,
        managementQuality: 8.0,
        esgFeasibility: 8.5,
        downsideProtection: 8.0,
        overallScore: 8.1
      },
      dueDiligenceWorkstreams: [
        { name: 'Quality of Earnings (QoE)', status: 'IN_PROGRESS', progressPercent: 30, leadAdvisor: 'KPMG', keyFindings: 'Initial review of EBITDA adjustments underway.' },
        { name: 'Legal & SPA Drafting', status: 'NOT_STARTED', progressPercent: 0, leadAdvisor: 'Freshfields', keyFindings: 'Awaiting LOI acceptance.' },
        { name: 'Commercial & Market Study', status: 'IN_PROGRESS', progressPercent: 40, leadAdvisor: 'Bain & Co', keyFindings: 'Customer interviews scheduled.' }
      ]
    };

    onAddDeal(newDeal);
    auditLogger.log(
      'DEAL_CREATED',
      `New investment opportunity originated: ${companyName} (€${valuationEV}M EV) by ${leadPartner}`,
      activeRole,
      { dealId: newDeal.id, valuationEV, sector }
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden font-mono-num text-xs">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <PlusCircle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-display text-base font-bold text-slate-100 font-sans">
                Originate Proprietary Investment Opportunity
              </h2>
              <p className="text-[11px] text-slate-400 font-sans">
                Register new direct PE opportunity into the Ellan Vannin underwriting pipeline.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Company / Target Name</label>
              <input
                type="text"
                required
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="e.g. Apex High-Voltage Systems"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Sector Classification</label>
              <select
                value={sector}
                onChange={(e) => setSector(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-400 cursor-pointer"
              >
                <option value="Energy Infrastructure & Transition">Energy Infrastructure & Transition</option>
                <option value="Industrial Automation & Robotics">Industrial Automation & Robotics</option>
                <option value="B2B Mission-Critical Software">B2B Mission-Critical Software</option>
                <option value="Healthcare & Life Sciences">Healthcare & Life Sciences</option>
                <option value="Specialty Food & Bio-Agritech">Specialty Food & Bio-Agritech</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Country / HQ Geography</label>
              <select
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-400 cursor-pointer"
              >
                <option value="United Kingdom">United Kingdom</option>
                <option value="Isle of Man">Isle of Man</option>
                <option value="Sweden">Sweden</option>
                <option value="Norway">Norway</option>
                <option value="Denmark">Denmark</option>
                <option value="Germany">Germany</option>
                <option value="Netherlands">Netherlands</option>
                <option value="France">France</option>
              </select>
            </div>

            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Lead Partner / Sponsor</label>
              <select
                value={leadPartner}
                onChange={(e) => setLeadPartner(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-400 cursor-pointer"
              >
                <option value="Alastair MacLeod">Alastair MacLeod (Senior Partner)</option>
                <option value="Tom Quilliam">Tom Quilliam (Managing GP)</option>
                <option value="Christian Kelly">Christian Kelly (Value Creation Head)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">LTM Revenue (€M)</label>
              <input
                type="number"
                step="0.5"
                value={revenue}
                onChange={(e) => setRevenue(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">LTM EBITDA (€M)</label>
              <input
                type="number"
                step="0.5"
                value={ebitda}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setEbitda(val);
                  if (revenue > 0) setEbitdaMargin(Number(((val / revenue) * 100).toFixed(1)));
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">EBITDA Margin (%)</label>
              <input
                type="number"
                step="0.1"
                value={ebitdaMargin}
                onChange={(e) => setEbitdaMargin(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Enterprise Value (€M)</label>
              <input
                type="number"
                step="1.0"
                value={valuationEV}
                onChange={(e) => setValuationEV(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-amber-300 font-bold focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Equity Check Required (€M)</label>
              <input
                type="number"
                step="1.0"
                value={equityCheck}
                onChange={(e) => setEquityCheck(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-emerald-400 font-bold focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Target Gross IRR (%)</label>
              <input
                type="number"
                step="0.5"
                value={targetIRR}
                onChange={(e) => setTargetIRR(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-emerald-400 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Target Gross MOIC (x)</label>
              <input
                type="number"
                step="0.1"
                value={targetMOIC}
                onChange={(e) => setTargetMOIC(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sky-400 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-slate-300 font-sans font-semibold block mb-1">Initial Pipeline Stage</label>
              <select
                value={stage}
                onChange={(e) => setStage(e.target.value as DealStage)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-400 cursor-pointer"
              >
                <option value="SOURCING">Sourcing</option>
                <option value="SCREENING">Screening</option>
                <option value="DUE_DILIGENCE">Due Diligence</option>
                <option value="INVESTMENT_COMMITTEE">Investment Committee</option>
              </select>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3 font-sans">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 cursor-pointer font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 text-slate-950 font-bold shadow-lg shadow-amber-950/40 cursor-pointer flex items-center gap-1.5"
            >
              <PlusCircle className="w-3.5 h-3.5" /> Underwrite Opportunity
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
