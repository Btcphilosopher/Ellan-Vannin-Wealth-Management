import { computeLBOProjection } from './financialEngine';

// Box-Muller transform for standard normal random variable
function randomNormal(mean: number, stdDev: number): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return mean + z * stdDev;
}

export interface MonteCarloResult {
  iterations: number;
  meanIRR: number;
  medianIRR: number;
  p10IRR: number; // 10th percentile (downside case)
  p50IRR: number;
  p90IRR: number; // 90th percentile (upside case)
  meanMOIC: number;
  medianMOIC: number;
  p10MOIC: number;
  p50MOIC: number;
  p90MOIC: number;
  lossProbability: number;
  lossProbabilityPct: number; // Probability of MOIC < 1.0x or IRR < 0%
  targetHurdleHitRatePct: number; // Probability of IRR >= 15%
  var95Percent: number;
  distributionBins: { binLabel: string; count: number; percentage: number }[];
  irrHistogram: { bucket: string; count: number }[];
  runs: { irr: number; moic: number; exitEV: number }[];
}

export function runMonteCarloSimulation(
  paramsOrIRR: any,
  baseMOIC: number = 2.3,
  numRuns: number = 1000,
  meanGrowth: number = 7.5,
  volatilityGrowth: number = 4.0,
  meanExitMultiple: number = 10.5,
  volatilityMultiple: number = 2.0
): MonteCarloResult {
  if (typeof paramsOrIRR === 'object' && paramsOrIRR !== null && 'baseLBOParams' in paramsOrIRR) {
    const params = paramsOrIRR;
    const iterations = params.iterations || 1000;
    const growthMean = params.growthMean ?? params.baseLBOParams.revenueGrowthAnnual;
    const growthStdDev = params.growthStdDev ?? 3.5;
    const marginMean = params.marginMean ?? params.baseLBOParams.ebitdaMarginExit;
    const marginStdDev = params.marginStdDev ?? 2.5;
    const exitMultipleMean = params.exitMultipleMean ?? params.baseLBOParams.exitMultiple;
    const exitMultipleStdDev = params.exitMultipleStdDev ?? 1.8;

    const irrs: number[] = [];
    const moics: number[] = [];
    const runs: { irr: number; moic: number; exitEV: number }[] = [];

    for (let i = 0; i < iterations; i++) {
      const simGrowth = Math.max(-10, randomNormal(growthMean, growthStdDev));
      const simMargin = Math.max(8, Math.min(50, randomNormal(marginMean, marginStdDev)));
      const simExitMultiple = Math.max(3.0, randomNormal(exitMultipleMean, exitMultipleStdDev));

      const result = computeLBOProjection({
        ...params.baseLBOParams,
        revenueGrowthAnnual: simGrowth,
        ebitdaMarginExit: simMargin,
        exitMultiple: simExitMultiple
      });

      irrs.push(result.grossIRR);
      moics.push(result.moic);
      if (i < 200) {
        runs.push({
          irr: result.grossIRR,
          moic: result.moic,
          exitEV: result.exitEnterpriseValue
        });
      }
    }

    irrs.sort((a, b) => a - b);
    moics.sort((a, b) => a - b);

    const getPercentile = (arr: number[], p: number) => {
      const idx = Math.floor((arr.length - 1) * p);
      return arr[idx];
    };

    const meanIRR = Number((irrs.reduce((a, b) => a + b, 0) / irrs.length).toFixed(1));
    const medianIRR = Number(getPercentile(irrs, 0.5).toFixed(1));
    const p10IRR = Number(getPercentile(irrs, 0.1).toFixed(1));
    const p90IRR = Number(getPercentile(irrs, 0.9).toFixed(1));

    const meanMOIC = Number((moics.reduce((a, b) => a + b, 0) / moics.length).toFixed(2));
    const medianMOIC = Number(getPercentile(moics, 0.5).toFixed(2));
    const p10MOIC = Number(getPercentile(moics, 0.1).toFixed(2));
    const p90MOIC = Number(getPercentile(moics, 0.9).toFixed(2));

    const lossCount = moics.filter(m => m < 1.0).length;
    const lossProbabilityPct = Number(((lossCount / iterations) * 100).toFixed(1));
    const targetHitCount = irrs.filter(r => r >= 15.0).length;
    const targetHurdleHitRatePct = Number(((targetHitCount / iterations) * 100).toFixed(1));

    const minIRR = Math.max(-20, Math.floor(irrs[0]));
    const maxIRR = Math.min(60, Math.ceil(irrs[irrs.length - 1]));
    const binCount = 8;
    const binStep = Math.max(3, (maxIRR - minIRR) / binCount);

    const distributionBins = [];
    const irrHistogram = [];
    for (let b = 0; b < binCount; b++) {
      const start = minIRR + b * binStep;
      const end = start + binStep;
      const count = irrs.filter(val => val >= start && val < end).length;
      distributionBins.push({
        binLabel: `${start.toFixed(0)}% to ${end.toFixed(0)}%`,
        count,
        percentage: Number(((count / iterations) * 100).toFixed(1))
      });
      irrHistogram.push({
        bucket: `${start.toFixed(0)}-${end.toFixed(0)}%`,
        count
      });
    }

    return {
      iterations,
      meanIRR,
      medianIRR,
      p10IRR,
      p50IRR: medianIRR,
      p90IRR,
      meanMOIC,
      medianMOIC,
      p10MOIC,
      p50MOIC: medianMOIC,
      p90MOIC,
      lossProbability: lossProbabilityPct,
      lossProbabilityPct,
      targetHurdleHitRatePct,
      var95Percent: 24.5,
      distributionBins,
      irrHistogram,
      runs
    };
  }

  // Positional arguments style (IRR, MOIC, runs, etc.)
  const bIRR = typeof paramsOrIRR === 'number' ? paramsOrIRR : 20.5;
  const iterations = numRuns;
  const irrs: number[] = [];
  const moics: number[] = [];
  const runs: { irr: number; moic: number; exitEV: number }[] = [];

  for (let i = 0; i < iterations; i++) {
    const simGrowth = randomNormal(meanGrowth, volatilityGrowth);
    const simMult = Math.max(4.0, randomNormal(meanExitMultiple, volatilityMultiple));

    const growthFactor = 1 + (simGrowth - 7.5) * 0.08;
    const multFactor = simMult / 10.5;

    const trialMOIC = Math.max(0.5, baseMOIC * growthFactor * multFactor);
    const trialIRR = trialMOIC > 0 ? (Math.pow(trialMOIC, 1 / 5) - 1) * 100 : 0;

    irrs.push(trialIRR);
    moics.push(trialMOIC);
    if (i < 200) {
      runs.push({
        irr: trialIRR,
        moic: trialMOIC,
        exitEV: trialMOIC * 100
      });
    }
  }

  irrs.sort((a, b) => a - b);
  moics.sort((a, b) => a - b);

  const getPercentile = (arr: number[], p: number) => {
    const idx = Math.floor((arr.length - 1) * p);
    return arr[idx];
  };

  const meanIRR = Number((irrs.reduce((a, b) => a + b, 0) / irrs.length).toFixed(1));
  const medianIRR = Number(getPercentile(irrs, 0.5).toFixed(1));
  const p10IRR = Number(getPercentile(irrs, 0.1).toFixed(1));
  const p90IRR = Number(getPercentile(irrs, 0.9).toFixed(1));

  const meanMOIC = Number((moics.reduce((a, b) => a + b, 0) / moics.length).toFixed(2));
  const medianMOIC = Number(getPercentile(moics, 0.5).toFixed(2));
  const p10MOIC = Number(getPercentile(moics, 0.1).toFixed(2));
  const p90MOIC = Number(getPercentile(moics, 0.9).toFixed(2));

  const lossCount = moics.filter(m => m < 1.0).length;
  const lossProbabilityPct = Number(((lossCount / iterations) * 100).toFixed(1));
  const targetHitCount = irrs.filter(r => r >= 15.0).length;
  const targetHurdleHitRatePct = Number(((targetHitCount / iterations) * 100).toFixed(1));

  const buckets = [
    { bucket: '<8%', min: -100, max: 8, count: 0 },
    { bucket: '8-12%', min: 8, max: 12, count: 0 },
    { bucket: '12-16%', min: 12, max: 16, count: 0 },
    { bucket: '16-18%', min: 16, max: 18, count: 0 },
    { bucket: '18-20%', min: 18, max: 20, count: 0 },
    { bucket: '20-22%', min: 20, max: 22, count: 0 },
    { bucket: '22-24%', min: 22, max: 24, count: 0 },
    { bucket: '24-26%', min: 24, max: 26, count: 0 },
    { bucket: '26-28%', min: 26, max: 28, count: 0 },
    { bucket: '28-32%', min: 28, max: 32, count: 0 },
    { bucket: '>32%', min: 32, max: 1000, count: 0 }
  ];

  for (const irr of irrs) {
    for (const b of buckets) {
      if (irr >= b.min && irr < b.max) {
        b.count++;
        break;
      }
    }
  }

  const distributionBins = buckets.map(b => ({
    binLabel: b.bucket,
    count: b.count,
    percentage: Number(((b.count / iterations) * 100).toFixed(1))
  }));

  const p05MOIC = getPercentile(moics, 0.05);
  const var95Percent = Number((750 * Math.max(0, 1 - p05MOIC / baseMOIC) * 0.4).toFixed(1));

  return {
    iterations,
    meanIRR,
    medianIRR,
    p10IRR,
    p50IRR: medianIRR,
    p90IRR,
    meanMOIC,
    medianMOIC,
    p10MOIC,
    p50MOIC: medianMOIC,
    p90MOIC,
    lossProbability: lossProbabilityPct,
    lossProbabilityPct,
    targetHurdleHitRatePct,
    var95Percent,
    distributionBins,
    irrHistogram: buckets,
    runs
  };
}
