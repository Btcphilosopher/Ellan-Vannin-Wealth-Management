import { AuditRecord, UserRole } from '../types';

export type AuditLogEntry = AuditRecord;

let AUDIT_RECORDS: AuditRecord[] = [
  {
    id: 'aud-001',
    timestamp: '2026-08-30 14:15:22 GMT',
    user: 'Tom Quilliam',
    role: 'FUND MANAGER',
    module: 'Fund Accounting',
    action: 'Capital Call Notice Issued',
    details: 'Issued Capital Call #04 for €65.0M for Celtic Energy Transition acquisition.',
    previousValue: 'Draft',
    newValue: 'Issued'
  },
  {
    id: 'aud-002',
    timestamp: '2026-08-29 11:42:10 GMT',
    user: 'Lady Eleanor Christian',
    role: 'INVESTMENT COMMITTEE',
    module: 'Investment Committee',
    action: 'IC Approval Signed',
    details: 'Approved Project Aethelgard Precision Industrial LBO at €145.0M EV with 3.2x senior debt leverage.',
    previousValue: 'UNDER REVIEW',
    newValue: 'IC APPROVED'
  },
  {
    id: 'aud-003',
    timestamp: '2026-08-28 09:30:45 GMT',
    user: 'Marcus Vance',
    role: 'OPERATING PARTNER',
    module: 'Portfolio Digital Twin',
    action: 'Value Creation Plan Updated',
    details: 'Added AI Automated Quality Inspection initiative to Isle of Man Logistics Twin (+€4.2M EBITDA impact).',
    previousValue: 'Identified',
    newValue: 'In Execution'
  },
  {
    id: 'aud-004',
    timestamp: '2026-08-27 16:20:00 GMT',
    user: 'Sir Arthur Kelly',
    role: 'RISK OFFICER',
    module: 'Macro Scenario Stress',
    action: 'Covenant Sensitivity Run',
    details: 'Ran +400bps Rate Shock test across 6 portfolio assets. Helvetia MedTech confirmed DSCR headroom at 2.1x.',
    previousValue: 'Normal',
    newValue: 'Passed Audit'
  }
];

export function getAuditLogs(): AuditRecord[] {
  return [...AUDIT_RECORDS];
}

export function logAuditEvent(params: {
  user: string;
  role: UserRole;
  module: string;
  action: string;
  details: string;
  previousValue?: string;
  newValue?: string;
}): AuditRecord {
  const newRecord: AuditRecord = {
    id: `aud-${Date.now().toString().slice(-6)}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' GMT',
    user: params.user,
    role: params.role,
    module: params.module,
    action: params.action,
    details: params.details,
    previousValue: params.previousValue,
    newValue: params.newValue
  };

  AUDIT_RECORDS.unshift(newRecord);
  return newRecord;
}

export const auditLogger = {
  log: (action: string, details: string, user: string = 'Tom Quilliam', meta?: any) => {
    return logAuditEvent({
      user,
      role: 'INVESTMENT COMMITTEE' as any,
      module: 'Investment Committee',
      action,
      details: meta ? `${details} | ${JSON.stringify(meta)}` : details
    });
  },
  getLogs: getAuditLogs
};

