import { DebtTranche, SourcesAndUses } from '../types';

/**
 * Calculates accurate IRR using Newton-Raphson method
 * @param cashFlows Array of numbers (Period 0 is negative outlay)
 * @param guess Initial guess (default 0.15 = 15%)
 */
export function calculateIRR(cashFlows: number[], guess: number = 0.15): number {
  if (!cashFlows || cashFlows.length < 2) return 0;
  
  // Check if there are both positive and negative cash flows
  const hasPositive = cashFlows.some(cf => cf > 0);
  const hasNegative = cashFlows.some(cf => cf < 0);
  if (!hasPositive || !hasNegative) return 0;

  const MAX_ITERATIONS = 100;
  const PRECISION = 0.00001;
  let rate = guess;

  for (let i = 0; i < MAX_ITERATIONS; i++) {
    let npv = 0;
    let dNpv = 0;

    for (let t = 0; t < cashFlows.length; t++) {
      const denom = Math.pow(1 + rate, t);
      if (denom === 0) break;
      npv += cashFlows[t] / denom;
      if (t > 0) {
        dNpv -= (t * cashFlows[t]) / Math.pow(1 + rate, t + 1);
      }
    }

    if (Math.abs(npv) < PRECISION) {
      return rate * 100; // return as percentage
    }

    if (Math.abs(dNpv) < 0.000001) break;

    const newRate = rate - npv / dNpv;
    if (newRate <= -0.999 || isNaN(newRate) || !isFinite(newRate)) {
      rate = guess / 2;
      break;
    }
    rate = newRate;
  }

  // Fallback simplified CAGR if Newton-Raphson diverges
  const initial = Math.abs(cashFlows[0]);
  const final = cashFlows[cashFlows.length - 1];
  const years = cashFlows.length - 1;
  if (initial > 0 && final > 0 && years > 0) {
    return (Math.pow(final / initial, 1 / years) - 1) * 100;
  }

  return rate * 100;
}

/**
 * Calculates standard PE Fund Multiples (TVPI, DPI, RVPI, MOIC)
 */
export function calculateFundRatios(
  investedCapital: number,
  realisedProceeds: number,
  unrealisedNAV: number
) {
  if (investedCapital <= 0) {
    return { tvpi: 1.0, dpi: 0.0, rvpi: 1.0, moic: 1.0 };
  }

  const dpi = realisedProceeds / investedCapital;
  const rvpi = unrealisedNAV / investedCapital;
  const tvpi = dpi + rvpi;
  const moic = (realisedProceeds + unrealisedNAV) / investedCapital;

  return {
    tvpi: Number(tvpi.toFixed(2)),
    dpi: Number(dpi.toFixed(2)),
    rvpi: Number(rvpi.toFixed(2)),
    moic: Number(moic.toFixed(2)),
  };
}

/**
 * Executes a full Leveraged Buyout (LBO) 5-year waterfall projection
 */
export function computeLBOProjection(params: {
  purchasePrice: number;
  entryEbitda: number;
  holdingPeriodYears: number;
  exitMultiple: number;
  revenueGrowthAnnual: number; // e.g. 8%
  ebitdaMarginExit: number; // e.g. 24%
  capexAsPctRevenue: number; // e.g. 3.5%
  taxRate: number; // e.g. 22%
  debtTranches: DebtTranche[];
  sourcesAndUses: SourcesAndUses;
}) {
  const {
    purchasePrice,
    entryEbitda,
    holdingPeriodYears,
    exitMultiple,
    revenueGrowthAnnual,
    ebitdaMarginExit,
    capexAsPctRevenue,
    taxRate,
    debtTranches,
    sourcesAndUses
  } = params;

  let currentRevenue = entryEbitda / (ebitdaMarginExit / 100);
  let currentEbitda = entryEbitda;
  
  let totalDebt = debtTranches.reduce((acc, t) => acc + t.amount, 0);
  let initialSponsorEquity = sourcesAndUses.sponsorEquity;
  let cashBalance = sourcesAndUses.minimumCashBuffer;

  const projectedFinancials = [];
  const sponsorCashFlows = [-initialSponsorEquity];

  for (let year = 1; year <= holdingPeriodYears; year++) {
    currentRevenue = currentRevenue * (1 + revenueGrowthAnnual / 100);
    const marginProgression = (ebitdaMarginExit / 100 - (entryEbitda / (currentRevenue / (1 + revenueGrowthAnnual / 100)))) * (year / holdingPeriodYears);
    const effectiveMargin = (entryEbitda / (currentRevenue / Math.pow(1 + revenueGrowthAnnual / 100, year))) + marginProgression;
    currentEbitda = currentRevenue * Math.min(0.40, Math.max(0.10, effectiveMargin));

    const capex = currentRevenue * (capexAsPctRevenue / 100);
    const wcChange = (currentRevenue * 0.12) * (revenueGrowthAnnual / 100); // WC growth requirement
    
    // Total interest across all tranches
    const totalInterest = debtTranches.reduce((sum, tranche) => {
      const trancheShare = totalDebt > 0 ? (tranche.amount / debtTranches.reduce((a, b) => a + b.amount, 0)) : 0;
      const currentTrancheBalance = totalDebt * trancheShare;
      return sum + currentTrancheBalance * (tranche.totalRate / 100);
    }, 0);

    const ebit = currentEbitda - capex * 0.8; // approx depreciation
    const ebt = Math.max(0, ebit - totalInterest);
    const tax = ebt * (taxRate / 100);

    // Free cash flow available for debt paydown (Unlevered cash flow minus interest and tax)
    const fcf = Math.max(0, currentEbitda - capex - wcChange - tax - totalInterest);

    // Mandatory + Excess Cash Sweep Debt Paydown
    const mandatoryAmort = debtTranches.reduce((sum, t) => sum + (t.amount * (t.amortisationPercentAnnual / 100)), 0);
    const debtPaid = Math.min(totalDebt, Math.max(mandatoryAmort, fcf * 0.85));

    totalDebt = Math.max(0, totalDebt - debtPaid);
    cashBalance += Math.max(0, fcf - debtPaid);

    projectedFinancials.push({
      year,
      revenue: Number(currentRevenue.toFixed(1)),
      ebitda: Number(currentEbitda.toFixed(1)),
      fcf: Number(fcf.toFixed(1)),
      debtPaid: Number(debtPaid.toFixed(1)),
      endingDebt: Number(totalDebt.toFixed(1)),
      cashBalance: Number(cashBalance.toFixed(1))
    });

    if (year < holdingPeriodYears) {
      sponsorCashFlows.push(0); // standard buy-and-hold no interim dividends unless recap
    }
  }

  const finalEbitda = projectedFinancials[projectedFinancials.length - 1]?.ebitda || entryEbitda;
  const exitEnterpriseValue = finalEbitda * exitMultiple;
  const exitNetDebt = Math.max(0, totalDebt - cashBalance);
  const exitEquityValue = Math.max(0, exitEnterpriseValue - exitNetDebt);

  // Sponsor equity share (assuming management rollover retains their % of equity)
  const sponsorEquityPct = sourcesAndUses.sponsorEquity / (sourcesAndUses.sponsorEquity + sourcesAndUses.managementRollover || 1);
  const grossProceeds = exitEquityValue * sponsorEquityPct;

  sponsorCashFlows.push(grossProceeds);

  const grossIRR = calculateIRR(sponsorCashFlows);
  const netIRR = Math.max(0, grossIRR * 0.82 - 1.5); // after 1.5% mgmt fee & 20% carry above 8% hurdle
  const moic = initialSponsorEquity > 0 ? Number((grossProceeds / initialSponsorEquity).toFixed(2)) : 1.0;
  const cashOnCash = moic;

  return {
    projectedFinancials,
    exitEnterpriseValue: Number(exitEnterpriseValue.toFixed(1)),
    exitNetDebt: Number(exitNetDebt.toFixed(1)),
    exitEquityValue: Number(exitEquityValue.toFixed(1)),
    grossProceeds: Number(grossProceeds.toFixed(1)),
    grossIRR: Number(grossIRR.toFixed(1)),
    netIRR: Number(netIRR.toFixed(1)),
    moic,
    cashOnCash
  };
}

/**
 * Calculates a 2D Exit Multiple vs Holding Period Sensitivity Grid
 */
export function generateSensitivityMatrix(
  baseLBOParams: Parameters<typeof computeLBOProjection>[0]
) {
  const holdingPeriods = [3, 4, 5, 6, 7];
  const exitMultiples = [
    Number((baseLBOParams.exitMultiple * 0.8).toFixed(1)),
    Number((baseLBOParams.exitMultiple * 0.9).toFixed(1)),
    Number((baseLBOParams.exitMultiple * 1.0).toFixed(1)),
    Number((baseLBOParams.exitMultiple * 1.1).toFixed(1)),
    Number((baseLBOParams.exitMultiple * 1.2).toFixed(1)),
  ];

  const grid: {
    multiple: number;
    results: {
      holdingPeriod: number;
      irr: number;
      moic: number;
      grossProceeds: number;
    }[];
  }[] = [];

  for (const multiple of exitMultiples) {
    const rowResults = [];
    for (const hp of holdingPeriods) {
      const projection = computeLBOProjection({
        ...baseLBOParams,
        holdingPeriodYears: hp,
        exitMultiple: multiple
      });
      rowResults.push({
        holdingPeriod: hp,
        irr: projection.grossIRR,
        moic: projection.moic,
        grossProceeds: projection.grossProceeds
      });
    }
    grid.push({
      multiple,
      results: rowResults
    });
  }

  return {
    holdingPeriods,
    exitMultiples,
    grid
  };
}

/**
 * Computes Discounted Cash Flow (DCF) Valuation with Terminal Value
 */
export function computeDCFValuation(params: {
  baseFCF: number;
  growthYears1to5: number; // % e.g. 9%
  wacc: number; // % e.g. 10.5%
  terminalGrowthRate: number; // % e.g. 2.5%
  netDebt: number;
}) {
  const { baseFCF, growthYears1to5, wacc, terminalGrowthRate, netDebt } = params;
  const waccDecimal = wacc / 100;
  const gDecimal = terminalGrowthRate / 100;

  let pvOfFCF = 0;
  let currentFCF = baseFCF;
  const forecast = [];

  for (let t = 1; t <= 5; t++) {
    currentFCF = currentFCF * (1 + growthYears1to5 / 100);
    const discountFactor = Math.pow(1 + waccDecimal, t);
    const discountedValue = currentFCF / discountFactor;
    pvOfFCF += discountedValue;
    forecast.push({ year: t, fcf: currentFCF, pv: discountedValue });
  }

  // Terminal value Gordon Growth model
  const terminalYearFCF = currentFCF * (1 + gDecimal);
  const terminalValue = terminalYearFCF / Math.max(0.01, waccDecimal - gDecimal);
  const pvTerminalValue = terminalValue / Math.pow(1 + waccDecimal, 5);

  const enterpriseValue = pvOfFCF + pvTerminalValue;
  const equityValue = Math.max(0, enterpriseValue - netDebt);

  return {
    enterpriseValue: Number(enterpriseValue.toFixed(1)),
    equityValue: Number(equityValue.toFixed(1)),
    pvOfFCF: Number(pvOfFCF.toFixed(1)),
    pvTerminalValue: Number(pvTerminalValue.toFixed(1)),
    forecast
  };
}

export function calculateDCF(
  fcfs: number[],
  wacc: number,
  terminalGrowthRate: number,
  netDebt: number = 0
) {
  const waccDecimal = wacc / 100;
  const gDecimal = terminalGrowthRate / 100;

  let pvOfFCF = 0;
  const forecast = [];

  for (let t = 0; t < fcfs.length; t++) {
    const fcf = fcfs[t];
    const discountFactor = Math.pow(1 + waccDecimal, t + 1);
    const discountedValue = fcf / discountFactor;
    pvOfFCF += discountedValue;
    forecast.push({ year: t + 1, fcf, pv: discountedValue });
  }

  const finalFCF = fcfs[fcfs.length - 1] || 10;
  const terminalYearFCF = finalFCF * (1 + gDecimal);
  const terminalValue = terminalYearFCF / Math.max(0.005, waccDecimal - gDecimal);
  const pvTerminalValue = terminalValue / Math.pow(1 + waccDecimal, fcfs.length);

  const enterpriseValue = pvOfFCF + pvTerminalValue;
  const equityValue = Math.max(0, enterpriseValue - netDebt);

  return {
    enterpriseValue: Number(enterpriseValue.toFixed(1)),
    equityValue: Number(equityValue.toFixed(1)),
    pvOfFCF: Number(pvOfFCF.toFixed(1)),
    pvTerminalValue: Number(pvTerminalValue.toFixed(1)),
    terminalValue: Number(pvTerminalValue.toFixed(1)),
    pvForecast: forecast,
    forecast
  };
}

export function calculateLBO(params: any) {
  const {
    entryEV = 100,
    entryEbitda = 10,
    holdingPeriodYears = 5,
    revenueGrowthRate = 6.0,
    ebitdaMargin = 20.0,
    exitMultiple = 10.0,
    debtTranches = [],
    sponsorEquity = 40,
    managementRolloverEquity = 5.0,
    cashSweepPercent = 50.0,
    capexPercentRevenue = 3.5,
    taxRate = 22.0
  } = params;

  let currentRevenue = entryEbitda / (Math.max(1, ebitdaMargin) / 100);
  let currentEbitda = entryEbitda;
  let totalDebt = (debtTranches || []).reduce((acc: number, t: any) => acc + (t.amount || 0), 0);
  let endingDebt = totalDebt;

  const debtSchedule = [];
  const revenueSchedule = [];
  const cashFlows = [-sponsorEquity];

  for (let y = 1; y <= holdingPeriodYears; y++) {
    const beginningDebt = endingDebt;
    currentRevenue = currentRevenue * (1 + revenueGrowthRate / 100);
    currentEbitda = currentRevenue * (ebitdaMargin / 100);

    const capex = currentRevenue * (capexPercentRevenue / 100);
    const interestPaid = beginningDebt * 0.065;
    const ebt = Math.max(0, currentEbitda - capex - interestPaid);
    const tax = ebt * (taxRate / 100);
    const fcfGenerated = Math.max(0, currentEbitda - capex - interestPaid - tax);

    const debtPaid = Math.min(beginningDebt, fcfGenerated * (cashSweepPercent / 100));
    endingDebt = Math.max(0, beginningDebt - debtPaid);

    const dscr = interestPaid > 0 ? (currentEbitda - capex) / interestPaid : 3.5;

    debtSchedule.push({
      year: y,
      beginningDebt,
      endingDebt,
      interestPaid,
      debtPaid,
      fcfGenerated,
      dscr
    });

    revenueSchedule.push({
      year: y,
      revenue: currentRevenue,
      ebitda: currentEbitda
    });

    if (y < holdingPeriodYears) {
      cashFlows.push(0);
    }
  }

  const exitEV = currentEbitda * exitMultiple;
  const exitNetDebt = endingDebt;
  const exitEquityValue = Math.max(0, exitEV - exitNetDebt);
  const totalEquityAtEntry = sponsorEquity + managementRolloverEquity || 1;
  const sponsorShare = sponsorEquity / totalEquityAtEntry;
  const grossProceeds = exitEquityValue * sponsorShare;

  cashFlows.push(grossProceeds);

  const grossIRR = calculateIRR(cashFlows);
  const netIRR = Math.max(0, grossIRR * 0.80 - 1.5);
  const moic = sponsorEquity > 0 ? grossProceeds / sponsorEquity : 1.0;

  return {
    exitEV,
    exitEnterpriseValue: exitEV,
    exitNetDebt,
    exitDebt: endingDebt,
    exitCash: 10,
    exitEquityValue,
    grossProceeds,
    grossIRR,
    netIRR,
    moic,
    cashOnCash: moic,
    debtSchedule,
    revenueSchedule,
    returns: {
      irr: grossIRR,
      moic,
      proceeds: grossProceeds,
      entryEquity: sponsorEquity
    }
  };
}

export function runMonteCarloSimulation(
  baseIRROrParams: number | any,
  baseMOIC: number = 2.3,
  numRuns: number = 1000,
  meanGrowth: number = 7.5,
  volatilityGrowth: number = 4.0,
  meanExitMultiple: number = 10.5,
  volatilityMultiple: number = 2.0
) {
  let bIRR = typeof baseIRROrParams === 'number' ? baseIRROrParams : (baseIRROrParams.baseIRR || 20.5);
  let bMOIC = typeof baseIRROrParams === 'number' ? baseMOIC : (baseIRROrParams.baseMOIC || 2.3);
  let runs = typeof baseIRROrParams === 'number' ? numRuns : (baseIRROrParams.numRuns || 1000);
  let mGrowth = typeof baseIRROrParams === 'number' ? meanGrowth : (baseIRROrParams.meanGrowth || 7.5);
  let vGrowth = typeof baseIRROrParams === 'number' ? volatilityGrowth : (baseIRROrParams.volatilityGrowth || 4.0);
  let mMult = typeof baseIRROrParams === 'number' ? meanExitMultiple : (baseIRROrParams.meanExitMultiple || 10.5);
  let vMult = typeof baseIRROrParams === 'number' ? volatilityMultiple : (baseIRROrParams.volatilityMultiple || 2.0);

  const simulatedIRRs: number[] = [];
  const simulatedMOICs: number[] = [];

  for (let i = 0; i < runs; i++) {
    // Box-Muller transform for Gaussian random variable
    const u1 = Math.max(0.0001, Math.random());
    const u2 = Math.random();
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    const z1 = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2);

    const randomGrowth = mGrowth + z0 * vGrowth;
    const randomMult = Math.max(4.0, mMult + z1 * vMult);

    const growthFactor = 1 + (randomGrowth - 7.5) * 0.08;
    const multFactor = randomMult / 10.5;

    const trialMOIC = Math.max(0.5, bMOIC * growthFactor * multFactor);
    const trialIRR = trialMOIC > 0 ? (Math.pow(trialMOIC, 1 / 5) - 1) * 100 : 0;

    simulatedIRRs.push(trialIRR);
    simulatedMOICs.push(trialMOIC);
  }

  simulatedIRRs.sort((a, b) => a - b);
  simulatedMOICs.sort((a, b) => a - b);

  const p10Idx = Math.floor(runs * 0.10);
  const p50Idx = Math.floor(runs * 0.50);
  const p90Idx = Math.floor(runs * 0.90);
  const p05Idx = Math.floor(runs * 0.05);

  const p10IRR = simulatedIRRs[p10Idx] || 12.0;
  const p50IRR = simulatedIRRs[p50Idx] || bIRR;
  const p90IRR = simulatedIRRs[p90Idx] || 28.5;

  const p10MOIC = simulatedMOICs[p10Idx] || 1.6;
  const p50MOIC = simulatedMOICs[p50Idx] || bMOIC;
  const p90MOIC = simulatedMOICs[p90Idx] || 3.1;

  const var95Percent = 750 * Math.max(0, (1 - simulatedMOICs[p05Idx] / bMOIC)) * 0.4;
  const lossTrials = simulatedMOICs.filter(m => m < 1.0).length;
  const lossProbability = (lossTrials / runs) * 100;

  // Build 12 histogram buckets between 0% and 36%
  const buckets = [
    { bucket: '<8%', min: -100, max: 8, count: 0 },
    { bucket: '8-12%', min: 8, max: 12, count: 0 },
    { bucket: '12-16%', min: 12, max: 16, count: 0 },
    { bucket: '16-18%', min: 16, max: 18, count: 0 },
    { bucket: '18-20%', min: 18, max: 20, count: 0 },
    { bucket: '20-22%', min: 20, max: 22, count: 0 },
    { bucket: '22-24%', min: 22, max: 24, count: 0 },
    { bucket: '24-26%', min: 24, max: 26, count: 0 },
    { bucket: '26-28%', min: 26, max: 28, count: 0 },
    { bucket: '28-32%', min: 28, max: 32, count: 0 },
    { bucket: '>32%', min: 32, max: 1000, count: 0 }
  ];

  for (const irr of simulatedIRRs) {
    for (const b of buckets) {
      if (irr >= b.min && irr < b.max) {
        b.count++;
        break;
      }
    }
  }

  return {
    p10IRR,
    p50IRR,
    p90IRR,
    p10MOIC,
    p50MOIC,
    p90MOIC,
    var95Percent,
    lossProbability,
    irrHistogram: buckets,
    simulatedIRRs,
    simulatedMOICs
  };
}


export function calculateSensitivityMatrix(
  entryEV: number,
  entryEbitda: number,
  sponsorEquity: number,
  revenueGrowth: number,
  ebitdaMargin: number,
  exitMultiples: number[],
  holdingPeriods: number[]
) {
  const matrix = [];

  for (const multiple of exitMultiples) {
    const holdingPeriodCols = [];

    for (const hp of holdingPeriods) {
      // Approximate EBITDA growth over hp years
      const terminalEbitda = entryEbitda * Math.pow(1 + revenueGrowth / 100, hp);
      const exitEV = terminalEbitda * multiple;
      // Assume 50% debt paydown across hold
      const initialDebt = Math.max(0, entryEV - sponsorEquity);
      const paidDownDebt = initialDebt * (1 - (hp * 0.12));
      const exitNetDebt = Math.max(0, paidDownDebt);
      const exitEquity = Math.max(0, exitEV - exitNetDebt);

      const moic = sponsorEquity > 0 ? Number((exitEquity / sponsorEquity).toFixed(2)) : 1.0;
      const irr = hp > 0 && moic > 0 ? Number(((Math.pow(moic, 1 / hp) - 1) * 100).toFixed(1)) : 0;

      holdingPeriodCols.push({
        years: hp,
        irr: Math.max(0, irr),
        moic: Math.max(0, moic)
      });
    }

    matrix.push({
      exitMultiple: multiple,
      holdingPeriods: holdingPeriodCols
    });
  }

  return matrix;
}

export function calculateFundCashFlows(fund: any) {
  const fundSize = fund.fundSize || fund.committedCapital || fund.size || 750;
  const timeline = [];

  // Typical PE J-Curve 10-year deployment & realization profile
  const callPcts = [0.20, 0.30, 0.25, 0.15, 0.10, 0.0, 0.0, 0.0, 0.0, 0.0];
  const distPcts = [0.0, 0.0, 0.05, 0.12, 0.22, 0.35, 0.45, 0.40, 0.25, 0.15];
  const navGrowth = [0.18, 0.42, 0.65, 0.82, 0.95, 0.85, 0.60, 0.35, 0.15, 0.0];

  let cumulativeCalled = 0;
  let cumulativeDist = 0;
  let cumulativeNet = 0;

  for (let y = 1; y <= 10; y++) {
    const idx = y - 1;
    const capitalCalled = fundSize * (callPcts[idx] || 0);
    const distributions = fundSize * (distPcts[idx] || 0) * 1.35; // with gains
    const netCashFlow = distributions - capitalCalled;

    cumulativeCalled += capitalCalled;
    cumulativeDist += distributions;
    cumulativeNet += netCashFlow;

    const nav = fundSize * (navGrowth[idx] || 0) * 1.25;

    timeline.push({
      year: y,
      capitalCalled,
      distributions,
      netCashFlow,
      cumulativeNetCashFlow: cumulativeNet,
      nav: Math.max(0, nav)
    });
  }

  return timeline;
}

export function runStressTestScenario(deal: any, scenario: any) {
  const baseEV = deal.currentValuationEV || deal.proposedValuationEV || 100;
  const baseEquity = deal.currentEquityValue || deal.dealSizeEquity || 60;
  const baseDebt = deal.currentNetDebt || Math.max(0, baseEV - baseEquity);
  const baseRevenue = deal.revenue || 100;
  const baseEbitda = deal.ebitda || 20;

  const revShock = scenario.revenueShockPercent ?? (scenario.revenueImpactPct ? -Math.abs(scenario.revenueImpactPct) : -10);
  const marginShock = scenario.ebitdaMarginShockPercent ?? (scenario.ebitdaMarginDropBps ? -scenario.ebitdaMarginDropBps / 100 : -3);
  const multipleShock = scenario.multipleExpansionShock ?? (scenario.multipleCompressionTurns ? -Math.abs(scenario.multipleCompressionTurns) : -2);
  const rateShockBps = scenario.interestRateShockBps ?? scenario.interestRateIncreaseBps ?? 200;

  const shockedRevenue = baseRevenue * (1 + revShock / 100);
  const baseMargin = (baseEbitda / (baseRevenue || 1)) * 100;
  const shockedMargin = Math.max(5, baseMargin + marginShock);
  const shockedEbitda = shockedRevenue * (shockedMargin / 100);

  const baseMultiple = baseEbitda > 0 ? baseEV / baseEbitda : 10;
  const shockedMultiple = Math.max(4, baseMultiple + multipleShock);
  const shockedEV = shockedEbitda * shockedMultiple;
  const shockedEquity = Math.max(0, shockedEV - baseDebt);

  const baseInterest = baseDebt * 0.055;
  const shockedInterest = baseDebt * (0.055 + rateShockBps / 10000);
  const shockedICR = shockedInterest > 0 ? shockedEbitda / shockedInterest : 4.0;

  return {
    dealId: deal.id,
    companyName: deal.companyName,
    baseEV,
    shockedEV,
    baseEquity,
    shockedEquity,
    baseEbitda,
    shockedEbitda,
    baseICR: baseInterest > 0 ? baseEbitda / baseInterest : 4.5,
    shockedICR,
    covenantBreach: shockedICR < 2.0,
    equityLossPct: baseEquity > 0 ? ((shockedEquity - baseEquity) / baseEquity) * 100 : 0
  };
}





