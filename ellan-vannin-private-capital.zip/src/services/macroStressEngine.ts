import { Deal, MacroScenario } from '../types';

export const DEFAULT_MACRO_SCENARIOS: MacroScenario[] = [
  {
    id: 'scen-recession',
    name: 'Severe Global Recession',
    type: 'RECESSION',
    description: 'Deep European contraction: -3.5% GDP, top-line contraction, corporate capex freezes.',
    revenueImpactPct: -14.0,
    ebitdaMarginDropBps: 280,
    interestRateIncreaseBps: 0,
    multipleCompressionTurns: 2.2,
    estimatedPortfolioNavDropPct: -21.5
  },
  {
    id: 'scen-rate-shock',
    name: 'Persistent High-Rate Regime (+400bps)',
    type: 'RATE SHOCK',
    description: 'Central banks keep terminal rates elevated. Base rates jump +400bps, squeezing interest coverage.',
    revenueImpactPct: -3.0,
    ebitdaMarginDropBps: 80,
    interestRateIncreaseBps: 400,
    multipleCompressionTurns: 1.8,
    estimatedPortfolioNavDropPct: -16.2
  },
  {
    id: 'scen-inflation-shock',
    name: 'Stagflationary Cost Spike',
    type: 'INFLATION SHOCK',
    description: 'Input cost surge and wage inflation without full customer pass-through pricing power.',
    revenueImpactPct: 2.0,
    ebitdaMarginDropBps: 350,
    interestRateIncreaseBps: 200,
    multipleCompressionTurns: 1.5,
    estimatedPortfolioNavDropPct: -18.0
  },
  {
    id: 'scen-energy-shock',
    name: 'European Energy & Commodity Crisis',
    type: 'ENERGY SHOCK',
    description: 'Severe natural gas & electricity grid disruption impacting heavy manufacturing and logistics.',
    revenueImpactPct: -6.5,
    ebitdaMarginDropBps: 320,
    interestRateIncreaseBps: 100,
    multipleCompressionTurns: 1.2,
    estimatedPortfolioNavDropPct: -14.8
  },
  {
    id: 'scen-credit-crisis',
    name: 'Leveraged Loan & Refinancing Freeze',
    type: 'CREDIT CRISIS',
    description: 'Syndicated debt markets lock up; refinancing spreads widen by +450bps, limiting exit liquidity.',
    revenueImpactPct: -5.0,
    ebitdaMarginDropBps: 150,
    interestRateIncreaseBps: 350,
    multipleCompressionTurns: 2.8,
    estimatedPortfolioNavDropPct: -24.0
  },
  {
    id: 'scen-supply-chain',
    name: 'Critical Supply Chain Bottleneck',
    type: 'SUPPLY-CHAIN SHOCK',
    description: 'Maritime trade lane disruption and component shortages inflating working capital days by 35%.',
    revenueImpactPct: -8.0,
    ebitdaMarginDropBps: 210,
    interestRateIncreaseBps: 50,
    multipleCompressionTurns: 1.0,
    estimatedPortfolioNavDropPct: -11.5
  },
  {
    id: 'scen-currency-shock',
    name: 'Major FX Devaluation & Volatility',
    type: 'CURRENCY SHOCK',
    description: 'Severe GBP/EUR/USD unhedged swings impacting cross-border revenues and debt service.',
    revenueImpactPct: -4.5,
    ebitdaMarginDropBps: 140,
    interestRateIncreaseBps: 150,
    multipleCompressionTurns: 0.8,
    estimatedPortfolioNavDropPct: -9.2
  }
];

export interface StressTestCompanyResult {
  companyName: string;
  sector: string;
  originalRevenue: number;
  stressedRevenue: number;
  originalEbitda: number;
  stressedEbitda: number;
  originalEV: number;
  stressedEV: number;
  originalEquity: number;
  stressedEquity: number;
  covenantBreached: boolean;
  interestCoverageStressed: number;
  status: 'Resilient' | 'Moderate Impact' | 'Severe Distress' | 'Covenant Breach';
}

export function stressTestPortfolio(
  portfolioDeals: Deal[],
  scenario: MacroScenario
): {
  companyResults: StressTestCompanyResult[];
  originalTotalEV: number;
  stressedTotalEV: number;
  originalTotalEquity: number;
  stressedTotalEquity: number;
  portfolioLossPct: number;
  covenantsAtRiskCount: number;
} {
  let originalTotalEV = 0;
  let stressedTotalEV = 0;
  let originalTotalEquity = 0;
  let stressedTotalEquity = 0;
  let covenantsAtRiskCount = 0;

  const companyResults: StressTestCompanyResult[] = portfolioDeals.map(deal => {
    const origRev = deal.revenue;
    const origEbitda = deal.ebitda;
    const origEV = deal.currentValuationEV || deal.proposedValuationEV;
    const origNetDebt = deal.currentNetDebt || (origEV - deal.dealSizeEquity);
    const origEquity = Math.max(0, origEV - origNetDebt);

    // Apply revenue shock
    const stressedRev = origRev * (1 + scenario.revenueImpactPct / 100);

    // Apply EBITDA margin drop
    const origMargin = origEbitda / origRev;
    const stressedMargin = Math.max(0.04, origMargin - scenario.ebitdaMarginDropBps / 10000);
    const stressedEbitda = Math.max(1.0, stressedRev * stressedMargin);

    // Apply Multiple compression
    const origImpliedMultiple = origEV / origEbitda;
    const stressedMultiple = Math.max(4.0, origImpliedMultiple - scenario.multipleCompressionTurns);
    const stressedEV = stressedEbitda * stressedMultiple;

    // Stressed interest & debt
    const baseInterestRate = 0.065 + scenario.interestRateIncreaseBps / 10000;
    const stressedInterestExpense = origNetDebt * baseInterestRate;
    const stressedInterestCoverage = stressedInterestExpense > 0 ? stressedEbitda / stressedInterestExpense : 10;

    const stressedEquity = Math.max(0, stressedEV - origNetDebt);

    // Check covenant: Debt/EBITDA <= 4.2x and Interest Coverage >= 1.75x
    const stressedLeverage = origNetDebt / stressedEbitda;
    const covenantBreached = stressedLeverage > 4.25 || stressedInterestCoverage < 1.75;
    if (covenantBreached) covenantsAtRiskCount++;

    let status: StressTestCompanyResult['status'] = 'Resilient';
    const equityDropPct = origEquity > 0 ? ((origEquity - stressedEquity) / origEquity) * 100 : 0;
    
    if (covenantBreached) {
      status = 'Covenant Breach';
    } else if (equityDropPct > 30) {
      status = 'Severe Distress';
    } else if (equityDropPct > 12) {
      status = 'Moderate Impact';
    }

    originalTotalEV += origEV;
    stressedTotalEV += stressedEV;
    originalTotalEquity += origEquity;
    stressedTotalEquity += stressedEquity;

    return {
      companyName: deal.companyName,
      sector: deal.sector,
      originalRevenue: Number(origRev.toFixed(1)),
      stressedRevenue: Number(stressedRev.toFixed(1)),
      originalEbitda: Number(origEbitda.toFixed(1)),
      stressedEbitda: Number(stressedEbitda.toFixed(1)),
      originalEV: Number(origEV.toFixed(1)),
      stressedEV: Number(stressedEV.toFixed(1)),
      originalEquity: Number(origEquity.toFixed(1)),
      stressedEquity: Number(stressedEquity.toFixed(1)),
      covenantBreached,
      interestCoverageStressed: Number(stressedInterestCoverage.toFixed(2)),
      status
    };
  });

  const portfolioLossPct = originalTotalEquity > 0 
    ? Number((((originalTotalEquity - stressedTotalEquity) / originalTotalEquity) * 100).toFixed(1))
    : 0;

  return {
    companyResults,
    originalTotalEV: Number(originalTotalEV.toFixed(1)),
    stressedTotalEV: Number(stressedTotalEV.toFixed(1)),
    originalTotalEquity: Number(originalTotalEquity.toFixed(1)),
    stressedTotalEquity: Number(stressedTotalEquity.toFixed(1)),
    portfolioLossPct,
    covenantsAtRiskCount
  };
}
