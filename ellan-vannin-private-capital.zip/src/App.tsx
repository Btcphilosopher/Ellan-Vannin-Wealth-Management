import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/Sidebar';
import { FundMasterDashboard } from './components/FundMasterDashboard';
import { FundStructureManager } from './components/FundStructureManager';
import { CapitalCallEngine } from './components/CapitalCallEngine';
import { DealPipelineView } from './components/DealPipelineView';
import { DealScreeningEngine } from './components/DealScreeningEngine';
import { GeographicOpportunityMap } from './components/GeographicOpportunityMap';
import { DealComparisonMatrix } from './components/DealComparisonMatrix';
import { DueDiligenceSuite } from './components/DueDiligenceSuite';
import { ValuationSuite } from './components/ValuationSuite';
import { LBOEngine } from './components/LBOEngine';
import { SourcesAndUsesEngine } from './components/SourcesAndUsesEngine';
import { ExitSensitivityView } from './components/ExitSensitivityView';
import { InvestmentCommitteeSuite } from './components/InvestmentCommitteeSuite';
import { PortfolioDigitalTwins } from './components/PortfolioDigitalTwins';
import { ValueCreationEngine } from './components/ValueCreationEngine';
import { OperatingKPIEngine } from './components/OperatingKPIEngine';
import { AddOnAcquisitionEngine } from './components/AddOnAcquisitionEngine';
import { RefinancingEngine } from './components/RefinancingEngine';
import { FundReturnsJCurve } from './components/FundReturnsJCurve';
import { MacroScenarioStress } from './components/MacroScenarioStress';
import { MonteCarloSimulator } from './components/MonteCarloSimulator';
import { PortfolioOptimizerAlerts } from './components/PortfolioOptimizerAlerts';
import { InvestorReportingSuite } from './components/InvestorReportingSuite';
import { ESGComplianceSuite } from './components/ESGComplianceSuite';
import { AuditLogViewer } from './components/AuditLogViewer';
import { NewDealModal } from './components/NewDealModal';
import { NewCapitalCallModal } from './components/NewCapitalCallModal';

import { 
  PlusCircle, 
  Coins, 
  Menu, 
  X, 
  Building2, 
  ShieldCheck, 
  ChevronDown, 
  UserCheck, 
  Search,
  Bell
} from 'lucide-react';

const AppContent: React.FC = () => {
  const {
    funds,
    selectedFund,
    setSelectedFund,
    deals,
    selectedDeal,
    setSelectedDeal,
    selectDealById,
    activeRole,
    setActiveRole,
    activeTab,
    setActiveTab,
    capitalCalls,
    lps,
    addDeal,
    updateDeal,
    issueCapitalCall,
    updateFund,
    isNewDealModalOpen,
    setIsNewDealModalOpen,
    isNewCallModalOpen,
    setIsNewCallModalOpen
  } = useApp();

  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  // Role Switcher Options
  const ROLES = [
    'Managing General Partner (GP)',
    'Senior Investment Director',
    'Chief Risk Officer (CRO)',
    'Head of Portfolio Value Creation',
    'Institutional Limited Partner (LP Advisory Committee)'
  ];

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-sans">
      
      {/* Desktop & Mobile Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-40 transform md:relative md:translate-x-0 transition-transform duration-300 ease-in-out ${
        isMobileNavOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <Sidebar
          activeTab={activeTab}
          onSelectTab={(tab) => {
            setActiveTab(tab);
            setIsMobileNavOpen(false);
          }}
          dealCounts={{
            pipeline: deals.filter(d => !d.isPortfolioCompany && d.stage !== 'PORTFOLIO' && d.stage !== 'EXIT').length,
            portfolio: deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO').length,
            icPending: deals.filter(d => d.stage === 'INVESTMENT COMMITTEE' || d.icStatus === 'UNDER REVIEW').length,
            alerts: 3
          }}
          dealCount={deals.length}
          portfolioCount={deals.filter(d => d.isPortfolioCompany || d.stage === 'PORTFOLIO').length}
          activeRole={activeRole}
          fundName={selectedFund?.name || 'EVWM Flagship Fund I'}
        />
      </div>

      {/* Mobile backdrop */}
      {isMobileNavOpen && (
        <div
          onClick={() => setIsMobileNavOpen(false)}
          className="fixed inset-0 bg-black/60 z-30 md:hidden backdrop-blur-xs"
        />
      )}

      {/* Main App Work Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden min-w-0">
        
        {/* Institutional Top Navigation Bar */}
        <header className="h-16 bg-slate-950/90 border-b border-slate-800/80 px-4 md:px-6 flex items-center justify-between z-20 backdrop-blur-md shrink-0">
          
          {/* Left: Mobile Toggle & Fund Switcher */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileNavOpen(!isMobileNavOpen)}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-900 md:hidden cursor-pointer"
            >
              {isMobileNavOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            {/* Fund Selector Dropdown */}
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-mono-num font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>NAV: €{selectedFund.nav.toFixed(1)}M</span>
              </div>

              <select
                value={selectedFund.id}
                onChange={(e) => {
                  const f = funds.find(x => x.id === e.target.value);
                  if (f) setSelectedFund(f);
                }}
                className="bg-slate-900 border border-slate-800 text-slate-200 text-xs font-bold px-3 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer max-w-[200px] sm:max-w-none truncate"
              >
                {funds.map(f => (
                  <option key={f.id} value={f.id}>{f.name} (€{f.size}M • {f.vintageYear})</option>
                ))}
              </select>
            </div>
          </div>

          {/* Right: Quick Action CTAs & Role Switcher */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Quick Action: Originate Deal */}
            <button
              onClick={() => setIsNewDealModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-sm shadow-amber-950/40 cursor-pointer transition-all"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Originate Deal</span>
            </button>

            {/* Quick Action: Issue Capital Call */}
            <button
              onClick={() => setIsNewCallModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-emerald-400 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all"
            >
              <Coins className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Issue Capital Call</span>
            </button>

            {/* Persona / Institutional Role Switcher */}
            <div className="relative group">
              <select
                value={activeRole}
                onChange={(e) => setActiveRole(e.target.value)}
                className="bg-slate-900 border border-slate-800 text-slate-300 text-[11px] font-semibold px-2.5 py-1.5 rounded-lg focus:outline-none focus:border-amber-400 cursor-pointer max-w-[140px] sm:max-w-[220px] truncate"
              >
                {ROLES.map(role => (
                  <option key={role} value={role}>{role}</option>
                ))}
              </select>
            </div>

          </div>
        </header>

        {/* Scrollable View Container */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 bg-slate-950">
          <div className="max-w-7xl mx-auto">
            {(activeTab === 'DASHBOARD' || activeTab === 'FUND_DASHBOARD') && (
              <FundMasterDashboard
                fund={selectedFund}
                deals={deals}
                onSelectDeal={(dealId) => {
                  selectDealById(dealId);
                  setActiveTab('DUE_DILIGENCE_SUITE');
                }}
                onNavigate={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'FUND_STRUCTURE' && (
              <FundStructureManager
                funds={funds}
                selectedFund={selectedFund}
                fund={selectedFund}
                lps={lps}
                lpCommitments={lps}
                onUpdateFund={updateFund}
              />
            )}

            {activeTab === 'CAPITAL_CALLS' && (
              <CapitalCallEngine
                fund={selectedFund}
                selectedFund={selectedFund}
                lps={lps}
                lpCommitments={lps}
                capitalCalls={capitalCalls}
                notices={capitalCalls}
                onIssueCall={issueCapitalCall}
                onIssueCapitalCall={issueCapitalCall}
              />
            )}

            {activeTab === 'DEAL_PIPELINE' && (
              <DealPipelineView
                deals={deals}
                onSelectDeal={(deal) => {
                  setSelectedDeal(deal);
                  setActiveTab('DUE_DILIGENCE_SUITE');
                }}
                onUpdateDeal={updateDeal}
              />
            )}

            {(activeTab === 'DEAL_SCREENING' || activeTab === 'SCREENING_ENGINE') && (
              <DealScreeningEngine
                deals={deals}
                onSelectDeal={(dealId) => {
                  selectDealById(dealId);
                  setActiveTab('DUE_DILIGENCE_SUITE');
                }}
                onUpdateDeal={updateDeal}
              />
            )}

            {(activeTab === 'GEOGRAPHIC_MAP' || activeTab === 'GEO_INVESTMENT_MAP') && (
              <GeographicOpportunityMap
                deals={deals}
                onSelectDeal={(deal) => {
                  setSelectedDeal(deal);
                  setActiveTab('DUE_DILIGENCE_SUITE');
                }}
              />
            )}

            {activeTab === 'DEAL_COMPARISON' && (
              <DealComparisonMatrix
                deals={deals}
                onSelectDeal={(dealId) => {
                  selectDealById(dealId);
                  setActiveTab('DUE_DILIGENCE_SUITE');
                }}
              />
            )}

            {activeTab === 'DUE_DILIGENCE_SUITE' && (
              <DueDiligenceSuite
                deal={selectedDeal}
                deals={deals}
                onSelectDeal={selectDealById}
                onUpdateDeal={updateDeal}
              />
            )}

            {activeTab === 'VALUATION_SUITE' && (
              <ValuationSuite
                deal={selectedDeal}
                deals={deals}
                onSelectDeal={selectDealById}
                onUpdateDeal={updateDeal}
              />
            )}

            {(activeTab === 'LBO_ENGINE' || activeTab === 'LBO_DEBT_ENGINE') && (
              <LBOEngine
                deal={selectedDeal}
                deals={deals}
                onSelectDeal={selectDealById}
                onUpdateDeal={updateDeal}
              />
            )}

            {(activeTab === 'SOURCES_AND_USES' || activeTab === 'SOURCES_USES') && (
              <SourcesAndUsesEngine
                deal={selectedDeal}
                deals={deals}
                onSelectDeal={selectDealById}
                onUpdateDeal={updateDeal}
              />
            )}

            {activeTab === 'EXIT_SENSITIVITY' && (
              <ExitSensitivityView
                deal={selectedDeal}
                deals={deals}
                onSelectDeal={selectDealById}
              />
            )}

            {activeTab === 'INVESTMENT_COMMITTEE' && (
              <InvestmentCommitteeSuite
                deal={selectedDeal}
                deals={deals}
                onSelectDeal={selectDealById}
                onUpdateDeal={updateDeal}
                activeRole={activeRole}
              />
            )}

            {(activeTab === 'DIGITAL_TWIN' || activeTab === 'PORTFOLIO_DIGITAL_TWINS') && (
              <PortfolioDigitalTwins
                deals={deals}
                selectedDeal={selectedDeal}
                onSelectDeal={selectDealById}
                onUpdateDeal={updateDeal}
              />
            )}

            {activeTab === 'VALUE_CREATION' && (
              <ValueCreationEngine
                deals={deals}
                selectedDeal={selectedDeal}
                onSelectDeal={selectDealById}
                onUpdateDeal={updateDeal}
              />
            )}

            {activeTab === 'OPERATING_KPIS' && (
              <OperatingKPIEngine
                deals={deals}
                selectedDeal={selectedDeal}
                onSelectDeal={selectDealById}
              />
            )}

            {(activeTab === 'ADDON_ACQUISITIONS' || activeTab === 'ADD_ON_ACQUISITIONS') && (
              <AddOnAcquisitionEngine
                deals={deals}
                selectedDeal={selectedDeal}
                onSelectDeal={selectDealById}
                onUpdateDeal={updateDeal}
              />
            )}

            {(activeTab === 'REFINANCING' || activeTab === 'REFINANCING_ENGINE') && (
              <RefinancingEngine
                deals={deals}
                selectedDeal={selectedDeal}
                onSelectDeal={selectDealById}
              />
            )}

            {activeTab === 'FUND_RETURNS_JCURVE' && (
              <FundReturnsJCurve
                fund={selectedFund}
              />
            )}

            {(activeTab === 'MACRO_SCENARIOS' || activeTab === 'MACRO_STRESS_TESTING') && (
              <MacroScenarioStress
                deals={deals}
                fund={selectedFund}
              />
            )}

            {activeTab === 'MONTE_CARLO' && (
              <MonteCarloSimulator
                fund={selectedFund}
              />
            )}

            {activeTab === 'PORTFOLIO_OPTIMIZER' && (
              <PortfolioOptimizerAlerts
                fund={selectedFund}
                deals={deals}
              />
            )}

            {activeTab === 'INVESTOR_REPORTING' && (
              <InvestorReportingSuite
                fund={selectedFund}
                lps={lps}
                deals={deals}
              />
            )}

            {(activeTab === 'ESG_COMPLIANCE' || activeTab === 'ESG_GOVERNANCE') && (
              <ESGComplianceSuite
                deals={deals}
                selectedDeal={selectedDeal}
                onSelectDeal={selectDealById}
                onUpdateDeal={updateDeal}
              />
            )}

            {(activeTab === 'AUDIT_LOG' || activeTab === 'AUDIT_TRAIL') && (
              <AuditLogViewer />
            )}
          </div>
        </main>

      </div>

      {/* Global Modals */}
      <NewDealModal
        isOpen={isNewDealModalOpen}
        onClose={() => setIsNewDealModalOpen(false)}
        onAddDeal={addDeal}
        activeRole={activeRole}
      />

      <NewCapitalCallModal
        isOpen={isNewCallModalOpen}
        onClose={() => setIsNewCallModalOpen(false)}
        fund={selectedFund}
        lps={lps}
        onIssueCall={issueCapitalCall}
        activeRole={activeRole}
      />

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
