package com.example

import com.example.domain.model.*
import com.example.engine.FedBalanceSheetEngine
import com.example.engine.HaircutEngine
import com.example.engine.RepoEconomicsEngine
import com.example.engine.SrpAuctionSimulator
import org.junit.Assert.*
import org.junit.Test

class RepoEconomicsUnitTest {

    @Test
    fun testRepoEconomicsCalculation() {
        // Collateral = $10B, Haircut = 1.0%, Repo Rate = 4.00%, Term = 1 Day
        val result = RepoEconomicsEngine.calculateRepoEconomics(
            collateralMarketValue = 10_000_000_000.0,
            haircutPct = 1.0,
            repoRatePct = 4.00,
            termDays = 1
        )

        // Eligible Collateral = $10B * (1 - 0.01) = $9.9B
        assertEquals(9_900_000_000.0, result.eligibleCollateralValue, 1.0)
        assertEquals(9_900_000_000.0, result.cashAdvanced, 1.0)

        // Repo Interest = $9.9B * 0.04 * (1 / 360) = $1,100,000.00
        val expectedInterest = 9_900_000_000.0 * 0.04 * (1.0 / 360.0)
        assertEquals(expectedInterest, result.repoInterestAmount, 0.01)

        // Repurchase Price = Cash + Interest
        assertEquals(result.cashAdvanced + result.repoInterestAmount, result.repurchasePrice, 0.01)

        // Effective Funding Cost should match 4.00%
        assertEquals(4.00, result.effectiveFundingCostPct, 0.001)

        // Hash must be non-empty
        assertNotNull(result.calculationHash)
    }

    @Test
    fun testBalanceSheetInvariants() {
        val baseSheet = FedBalanceSheet()
        assertTrue("Initial Balance Sheet must reconcile", baseSheet.isReconciled)
        assertEquals(0.0, baseSheet.discrepancyBln, 0.01)

        // Simulate balance sheet shock
        val stressedSheet = FedBalanceSheetEngine.simulateBalanceSheetShock(
            baseSheet = baseSheet,
            srpRepoChangeBln = 35.0,
            onRrpChangeBln = -20.0,
            treasuryPurchaseSaleBln = 50.0,
            reserveDrainBln = 10.0
        )

        assertTrue("Stressed Balance Sheet must preserve Assets == Liab + Capital invariant", stressedSheet.isReconciled)
    }

    @Test
    fun testHaircutShockSimulation() {
        val counterparties = listOf(
            Counterparty(
                id = "CP-001",
                name = "Dealer A",
                shortName = "DLR-A",
                type = CounterpartyType.PRIMARY_DEALER,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 50.0,
                treasuryInventoryBillions = 100.0,
                agencyInventoryBillions = 20.0,
                mbsInventoryBillions = 30.0,
                repoCapacityBillions = 140.0,
                collateralEncumberedBillions = 100.0,
                riskScore = 10
            )
        )

        val result = HaircutEngine.simulateHaircutShock(counterparties, 50.0) // 50 bps = 0.5%
        assertTrue("Capacity loss must be greater than zero", result.systemCapacityLossBln > 0.0)
    }

    @Test
    fun testSrpPropositionValidation() {
        val cp = Counterparty(
            id = "CP-001",
            name = "Eligible Primary Dealer",
            shortName = "EPD",
            type = CounterpartyType.PRIMARY_DEALER,
            srpEligible = true,
            onRrpEligible = true,
            capitalBillions = 50.0,
            treasuryInventoryBillions = 100.0,
            agencyInventoryBillions = 20.0,
            mbsInventoryBillions = 30.0,
            repoCapacityBillions = 140.0,
            collateralEncumberedBillions = 20.0,
            riskScore = 10
        )

        val facility = RepoFacility(
            facilityId = "FAC-SRP",
            name = "Standing Repo",
            operationSchedule = "08:15-08:30 ET",
            ratePct = 4.00,
            allotmentMethod = OperationMode.FULL_ALLOTMENT,
            aggregateLimitBln = 500.0,
            propositionLimitBln = 50.0,
            eligibleCounterpartyTypes = listOf(CounterpartyType.PRIMARY_DEALER),
            eligibleCollateral = listOf(CollateralType.TREASURY_NOTE),
            settlementMethod = ClearingMethod.FEDTRADE_PLUS
        )

        val validProp = Proposition(
            propositionId = "PROP-1",
            operationId = "OP-1",
            counterpartyId = cp.id,
            counterpartyName = cp.name,
            securityType = CollateralType.TREASURY_NOTE,
            cusip = "91282CJZ5",
            propositionAmountBln = 10.0,
            submittedRate = 4.00,
            submittedTime = "08:20 ET"
        )

        val (status, reason) = SrpAuctionSimulator.validateProposition(validProp, cp, facility, 500.0)
        assertEquals(PropositionStatus.ACCEPTED, status)
        assertNull(reason)
    }
}
