package com.example.domain.model

import java.util.UUID

enum class TransactionType(val displayName: String, val code: String) {
    REPO("Standard Repo", "REPO"),
    REVERSE_REPO("Reverse Repo", "R_REPO"),
    SRP("Standing Repo Facility", "SRP"),
    ON_RRP("Overnight Reverse Repo", "ON_RRP"),
    PRIVATE_REPO("Private Bilateral", "PVT_REPO"),
    TRIPARTY("Tri-Party Repo", "TRIPARTY"),
    BILATERAL("Bilateral DVP", "BILATERAL")
}

enum class SettlementStatus(val displayName: String) {
    CREATED("Created"),
    VALIDATED("Validated"),
    MATCHED("Matched"),
    SETTLED("Settled"),
    ACTIVE("Active"),
    MATURING("Maturing"),
    RETURNED("Returned"),
    FAILED("Failed")
}

enum class ClearingMethod(val displayName: String) {
    TRIPARTY_BNY("BNY Mellon Tri-Party"),
    FICC_DVP("FICC DVP Cleared"),
    BILATERAL_DIRECT("Bilateral Direct Custody"),
    FEDTRADE_PLUS("FedTrade Plus (Fed Operations)")
}

enum class CollateralType(val displayName: String, val category: String, val standardHaircutPct: Double) {
    TREASURY_BILL("U.S. Treasury Bills (<= 1Y)", "Treasury", 0.5),
    TREASURY_NOTE("U.S. Treasury Notes (2Y-10Y)", "Treasury", 1.0),
    TREASURY_BOND("U.S. Treasury Bonds (10Y-30Y)", "Treasury", 2.0),
    TIPS("Treasury Inflation-Protected", "Treasury", 1.5),
    FRN("Floating Rate Notes", "Treasury", 0.75),
    AGENCY_DEBT("Agency Debentures (Fannie/Freddie/FHLB)", "Agency", 2.0),
    AGENCY_MBS("Agency MBS Pools (Uniform MBS)", "Agency MBS", 3.0)
}

enum class CounterpartyType(val displayName: String) {
    PRIMARY_DEALER("Primary Dealer"),
    BANK("Depository Institution / Bank"),
    MMF("Money Market Mutual Fund"),
    GSE("Government-Sponsored Enterprise"),
    BROKER_DEALER("Non-Primary Broker Dealer"),
    FOREIGN_BANK_BRANCH("Foreign Banking Org (FBO)")
}

enum class EligibilityStatus(val displayName: String) {
    ELIGIBLE("Active & Eligible"),
    INACTIVE("Temporarily Inactive"),
    PENDING("Application Pending"),
    REMOVED("Suspended / Removed")
}

data class CollateralSecurity(
    val cusip: String,
    val securityName: String,
    val assetType: CollateralType,
    val issuer: String,
    val maturityYears: Double,
    val couponRate: Double,
    val cleanPrice: Double,
    val dirtyPrice: Double,
    val outstandingBillions: Double,
    val haircutPct: Double,
    val isFedEligible: Boolean = true,
    val liquidityScore: Int = 95, // 1 - 100
    val specialnessBps: Double = 0.0, // GC vs Special spread in bps
    val impliedRepoRate: Double = 3.90
)

data class Counterparty(
    val id: String,
    val name: String,
    val shortName: String,
    val type: CounterpartyType,
    val srpEligible: Boolean,
    val onRrpEligible: Boolean,
    val capitalBillions: Double,
    val treasuryInventoryBillions: Double,
    val agencyInventoryBillions: Double,
    val mbsInventoryBillions: Double,
    val repoCapacityBillions: Double,
    val collateralEncumberedBillions: Double,
    val riskScore: Int, // 1 to 100 (lower is safer)
    val dailyOnRrpLimitBillions: Double = 160.0
) {
    val totalCollateralBillions: Double
        get() = treasuryInventoryBillions + agencyInventoryBillions + mbsInventoryBillions

    val freeCollateralBillions: Double
        get() = (totalCollateralBillions - collateralEncumberedBillions).coerceAtLeast(0.0)

    val fundingUtilizationPct: Double
        get() = if (repoCapacityBillions > 0) ((collateralEncumberedBillions / repoCapacityBillions) * 100).coerceIn(0.0, 100.0) else 0.0
}

data class RepoTransaction(
    val repoId: String,
    val transactionType: TransactionType,
    val counterpartyId: String,
    val counterpartyName: String,
    val cashAmount: Double, // in USD
    val collateralMarketValue: Double, // in USD
    val collateralType: CollateralType,
    val cusip: String,
    val haircutPct: Double, // e.g. 1.0% = 0.01
    val repoRatePct: Double, // e.g. 4.00% = 0.04
    val termDays: Int = 1, // overnight = 1
    val startDate: String,
    val maturityDate: String,
    val settlementDate: String,
    val marginRequirementPct: Double = 100.0, // 100% standard
    val clearingMethod: ClearingMethod = ClearingMethod.TRIPARTY_BNY,
    val settlementAgent: String = "Bank of New York Mellon",
    val status: SettlementStatus = SettlementStatus.SETTLED,
    val failReason: String? = null
)

data class RepoEconomicsResult(
    val collateralMarketValue: Double,
    val haircutPct: Double,
    val eligibleCollateralValue: Double,
    val cashAdvanced: Double,
    val repoRatePct: Double,
    val termDays: Int,
    val repoInterestAmount: Double,
    val repurchasePrice: Double,
    val effectiveFundingCostPct: Double,
    val collateralCoverageRatio: Double,
    val marginRequirementAmount: Double,
    val haircutImpactAmount: Double,
    val marginCallAmount: Double,
    val calculationHash: String = UUID.randomUUID().toString().take(8).uppercase()
)

data class MoneyMarketRates(
    val effr: Double = 3.88,
    val sofr: Double = 3.92,
    val gcRepo: Double = 3.88,
    val srpRate: Double = 4.00,
    val onRrpRate: Double = 3.75,
    val iorb: Double = 3.90,
    val tBill3m: Double = 3.98,
    val tNote10y: Double = 4.15,
    val sofrP1: Double = 3.78,
    val sofrP25: Double = 3.88,
    val sofrMedian: Double = 3.92,
    val sofrP75: Double = 3.95,
    val sofrP99: Double = 4.08,
    val sofrVolumeBln: Double = 1840.0
) {
    val sofrMinusIorbBps: Double get() = (sofr - iorb) * 100
    val sofrMinusSrpBps: Double get() = (sofr - srpRate) * 100
    val sofrMinusOnRrpBps: Double get() = (sofr - onRrpRate) * 100
    val sofrMinusEffrBps: Double get() = (sofr - effr) * 100
    val effrMinusIorbBps: Double get() = (effr - iorb) * 100
}

data class PolicyParameters(
    val versionId: String = "POL-2026-SEP17-REF",
    val effectiveDate: String = "September 17, 2026",
    val targetRangeLow: Double = 3.75,
    val targetRangeHigh: Double = 4.00,
    val iorbRate: Double = 3.90,
    val srpRate: Double = 4.00,
    val onRrpRate: Double = 3.75,
    val onRrpCounterpartyLimitBln: Double = 160.0,
    val srpAggregateLimitBln: Double = 500.0,
    val morningSrpWindow: String = "08:15 – 08:30 ET",
    val afternoonSrpWindow: String = "13:30 – 13:45 ET",
    val is2026Reference: Boolean = true
)

enum class OperationMode {
    FULL_ALLOTMENT,
    PRO_RATA,
    COMPETITIVE_AUCTION,
    FIXED_RATE
}

data class RepoFacility(
    val facilityId: String,
    val name: String,
    val operationSchedule: String,
    val ratePct: Double,
    val allotmentMethod: OperationMode,
    val aggregateLimitBln: Double,
    val propositionLimitBln: Double,
    val eligibleCounterpartyTypes: List<CounterpartyType>,
    val eligibleCollateral: List<CollateralType>,
    val settlementMethod: ClearingMethod
)

enum class PropositionStatus {
    SUBMITTED,
    ACCEPTED,
    PARTIALLY_ACCEPTED,
    REJECTED
}

data class Proposition(
    val propositionId: String,
    val operationId: String,
    val counterpartyId: String,
    val counterpartyName: String,
    val securityType: CollateralType,
    val cusip: String,
    val propositionAmountBln: Double,
    val submittedRate: Double,
    val submittedTime: String,
    val status: PropositionStatus = PropositionStatus.SUBMITTED,
    val awardAmountBln: Double = 0.0,
    val rejectionReason: String? = null
)

data class OperationResult(
    val operationId: String,
    val operationName: String,
    val operationDate: String,
    val scheduleWindow: String,
    val ratePct: Double,
    val totalSubmittedBln: Double,
    val totalAwardedBln: Double,
    val treasuryAwardedBln: Double,
    val agencyAwardedBln: Double,
    val mbsAwardedBln: Double,
    val participatingCount: Int,
    val status: String = "Settled - Same Day Tri-Party"
) {
    val utilizationPct: Double
        get() = if (totalSubmittedBln > 0) (totalAwardedBln / totalSubmittedBln) * 100 else 0.0
}

data class FedBalanceSheet(
    val asOfDate: String = "2026-10-05",
    // Assets (in Billions USD)
    val treasuriesBln: Double = 4320.0,
    val agencyMbsBln: Double = 2240.0,
    val srpRepoBln: Double = 42.5,
    val loansBln: Double = 18.2,
    val otherAssetsBln: Double = 285.3,
    
    // Liabilities (in Billions USD)
    val reserveBalancesBln: Double = 3210.0,
    val currencyInCirculationBln: Double = 2340.0,
    val onRrpBln: Double = 118.0,
    val tgaAccountBln: Double = 845.0,
    val otherLiabilitiesBln: Double = 345.0,
    val capitalBln: Double = 48.0
) {
    val totalAssetsBln: Double
        get() = treasuriesBln + agencyMbsBln + srpRepoBln + loansBln + otherAssetsBln

    val totalLiabilitiesAndCapitalBln: Double
        get() = reserveBalancesBln + currencyInCirculationBln + onRrpBln + tgaAccountBln + otherLiabilitiesBln + capitalBln

    val discrepancyBln: Double
        get() = totalAssetsBln - totalLiabilitiesAndCapitalBln

    val isReconciled: Boolean
        get() = Math.abs(discrepancyBln) < 0.01
}

data class SomaPortfolio(
    val totalHoldingsBln: Double = 6560.0,
    val treasuryBillsBln: Double = 210.0,
    val treasuryNotesBln: Double = 2840.0,
    val treasuryBondsBln: Double = 1270.0,
    val agencyMbsBln: Double = 2240.0,
    val monthlyRunoffCapBln: Double = 60.0,
    val actualMonthlyRunoffBln: Double = 42.0,
    val monthlyReinvestmentBln: Double = 18.0,
    val weightedAverageMaturityYears: Double = 6.4
)

data class LiquidityEngineState(
    val reserveSupplyBln: Double = 3210.0,
    val aggregateCollateralBln: Double = 8940.0,
    val haircutAdjustedCollateralBln: Double = 8810.0,
    val totalFundingCapacityBln: Double = 7650.0,
    val dealerFundingGapBln: Double = 14.2,
    val collateralGapBln: Double = 8.5,
    val stressFundingNeedBln: Double = 32.0,
    val marketLiquidityIndex: Double = 84.5 // 0-100
)

data class SettlementException(
    val exceptionId: String,
    val transactionId: String,
    val counterpartyName: String,
    val exceptionType: String,
    val timestamp: String,
    val severity: String, // HIGH, MEDIUM, LOW
    val details: String,
    val suggestedAction: String,
    var resolved: Boolean = false
)

data class StressScenario(
    val id: String,
    val code: String,
    val title: String,
    val description: String,
    val treasuryHaircutShockPct: Double,
    val repoRateShockBps: Double,
    val mbsHaircutShockPct: Double,
    val dealerLiquidityDropPct: Double,
    val reserveDrainBln: Double,
    val onRrpShiftBln: Double,
    val expectedImpactSummary: String
)

data class ContagionSimulationResult(
    val defaultingCounterparty: String,
    val initialLossBln: Double,
    val collateralLiquidatedBln: Double,
    val replacementCostBln: Double,
    val repoRateSpikeBps: Double,
    val systemLiquidityLossBln: Double,
    val fedFacilityDrawBln: Double,
    val cascadeRounds: Int,
    val affectedCounterparties: List<Pair<String, Double>> // Name to Loss ($B)
)

data class ModelCard(
    val modelId: String,
    val name: String,
    val version: String,
    val purpose: String,
    val methodology: String,
    val assumptions: String,
    val limitations: String,
    val validationStatus: String = "VALIDATED & AUDITED",
    val authorGroup: String = "Federal Reserve System Operations & Research Group",
    val calculationCount: Long = 142850
)

data class AuditCalculation(
    val calculationId: String,
    val modelName: String,
    val timestamp: String,
    val inputsSummary: String,
    val resultSummary: String,
    val verificationHash: String,
    val deterministicReplaySuccess: Boolean = true
)

data class ResearchQuery(
    val queryId: String,
    val question: String,
    val category: String,
    val modelExplanation: String,
    val metricImpacts: List<Pair<String, String>>,
    val dataProvenance: String
)
