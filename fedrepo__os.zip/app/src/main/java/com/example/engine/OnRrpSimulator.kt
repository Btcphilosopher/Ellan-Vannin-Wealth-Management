package com.example.engine

import com.example.domain.model.Counterparty
import com.example.domain.model.CounterpartyType
import com.example.domain.model.RepoTransaction
import com.example.domain.model.TransactionType
import com.example.domain.model.SettlementStatus
import com.example.domain.model.CollateralType
import java.text.SimpleDateFormat
import java.util.*

object OnRrpSimulator {

    data class OnRrpSubmission(
        val submissionId: String,
        val counterpartyId: String,
        val counterpartyName: String,
        val counterpartyType: CounterpartyType,
        val requestedAmountBln: Double,
        val acceptedAmountBln: Double,
        val offeringRatePct: Double,
        val allocatedTreasuryCusip: String,
        val status: String
    )

    data class OnRrpExecutionResult(
        val totalAcceptedBln: Double,
        val mmfTotalBln: Double,
        val gseTotalBln: Double,
        val primaryDealerTotalBln: Double,
        val bankTotalBln: Double,
        val participatingCount: Int,
        val treasuryCollateralAllocatedBln: Double,
        val submissions: List<OnRrpSubmission>,
        val reserveDrainImpactBln: Double
    )

    /**
     * Executes ON RRP operation across institutional participants.
     * Enforces $160B per counterparty limit (or custom limit).
     */
    fun executeOnRrpDailyOperation(
        counterparties: List<Counterparty>,
        offeringRatePct: Double = 3.75,
        counterpartyLimitBln: Double = 160.0
    ): OnRrpExecutionResult {
        val eligibleParticipants = counterparties.filter { it.onRrpEligible }
        val submissions = mutableListOf<OnRrpSubmission>()
        
        var totalAccepted = 0.0
        var mmfTotal = 0.0
        var gseTotal = 0.0
        var dealerTotal = 0.0
        var bankTotal = 0.0

        val sampleCusips = listOf("912797HB1", "912797HA3", "91282CJZ5", "91282CKA8")

        for (cp in eligibleParticipants) {
            // MMFs are the heaviest ON RRP participants, followed by GSEs and Banks
            val baseDemandRatio = when (cp.type) {
                CounterpartyType.MMF -> 0.45
                CounterpartyType.GSE -> 0.30
                CounterpartyType.PRIMARY_DEALER -> 0.05
                CounterpartyType.BANK -> 0.10
                else -> 0.02
            }

            // Demand scaled by counterparty capital/liquidity
            val requested = (cp.capitalBillions * 1.5 * baseDemandRatio).coerceIn(0.5, 180.0)
            val accepted = Math.min(requested, counterpartyLimitBln)
            val status = if (accepted < requested) "Capped at Limit ($${counterpartyLimitBln}B)" else "Fully Accepted"

            val assignedCusip = sampleCusips[submissions.size % sampleCusips.size]

            submissions.add(
                OnRrpSubmission(
                    submissionId = "ONRRP-SUB-${submissions.size + 1}",
                    counterpartyId = cp.id,
                    counterpartyName = cp.name,
                    counterpartyType = cp.type,
                    requestedAmountBln = requested,
                    acceptedAmountBln = accepted,
                    offeringRatePct = offeringRatePct,
                    allocatedTreasuryCusip = assignedCusip,
                    status = status
                )
            )

            totalAccepted += accepted
            when (cp.type) {
                CounterpartyType.MMF -> mmfTotal += accepted
                CounterpartyType.GSE -> gseTotal += accepted
                CounterpartyType.PRIMARY_DEALER -> dealerTotal += accepted
                CounterpartyType.BANK -> bankTotal += accepted
                else -> {}
            }
        }

        return OnRrpExecutionResult(
            totalAcceptedBln = totalAccepted,
            mmfTotalBln = mmfTotal,
            gseTotalBln = gseTotal,
            primaryDealerTotalBln = dealerTotal,
            bankTotalBln = bankTotal,
            participatingCount = submissions.count { it.acceptedAmountBln > 0 },
            treasuryCollateralAllocatedBln = totalAccepted,
            submissions = submissions.sortedByDescending { it.acceptedAmountBln },
            reserveDrainImpactBln = totalAccepted
        )
    }
}
