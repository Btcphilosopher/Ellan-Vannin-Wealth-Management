package com.example.engine

import com.example.domain.model.FedBalanceSheet
import com.example.domain.model.SomaPortfolio

object FedBalanceSheetEngine {

    /**
     * Recomputes Federal Reserve Balance Sheet based on open market operations,
     * repo/reverse repo facility usage, and Treasury reinvestments.
     * Core Invariant: Total Assets == Total Liabilities + Capital.
     */
    fun simulateBalanceSheetShock(
        baseSheet: FedBalanceSheet,
        srpRepoChangeBln: Double,
        onRrpChangeBln: Double,
        treasuryPurchaseSaleBln: Double,
        reserveDrainBln: Double
    ): FedBalanceSheet {
        // Adjust Assets
        val newTreasuries = (baseSheet.treasuriesBln + treasuryPurchaseSaleBln).coerceAtLeast(0.0)
        val newSrpRepo = (baseSheet.srpRepoBln + srpRepoChangeBln).coerceAtLeast(0.0)
        val newAssets = newTreasuries + baseSheet.agencyMbsBln + newSrpRepo + baseSheet.loansBln + baseSheet.otherAssetsBln

        // Adjust Liabilities
        val newOnRrp = (baseSheet.onRrpBln + onRrpChangeBln).coerceAtLeast(0.0)
        
        // Double-entry balancing mechanism:
        // Assets Change = Liabilities Change
        // deltaAssets = (newTreasuries - baseSheet.treasuriesBln) + (newSrpRepo - baseSheet.srpRepoBln)
        val deltaAssets = (newTreasuries - baseSheet.treasuriesBln) + (newSrpRepo - baseSheet.srpRepoBln)
        val deltaNonReserveLiabilities = (newOnRrp - baseSheet.onRrpBln) - reserveDrainBln

        // Reserve Balances act as the primary liquidity buffer / clearing account
        val newReserves = (baseSheet.reserveBalancesBln + deltaAssets - deltaNonReserveLiabilities).coerceAtLeast(500.0)

        // Ensure Capital remains fixed or balanced
        val currentTotalLiabWithoutOther = newReserves + baseSheet.currencyInCirculationBln + newOnRrp + baseSheet.tgaAccountBln + baseSheet.capitalBln
        val balancingOtherLiabilities = (newAssets - currentTotalLiabWithoutOther).coerceAtLeast(0.0)

        return FedBalanceSheet(
            asOfDate = "2026-10-05 (Simulated)",
            treasuriesBln = newTreasuries,
            agencyMbsBln = baseSheet.agencyMbsBln,
            srpRepoBln = newSrpRepo,
            loansBln = baseSheet.loansBln,
            otherAssetsBln = baseSheet.otherAssetsBln,
            reserveBalancesBln = newReserves,
            currencyInCirculationBln = baseSheet.currencyInCirculationBln,
            onRrpBln = newOnRrp,
            tgaAccountBln = baseSheet.tgaAccountBln,
            otherLiabilitiesBln = balancingOtherLiabilities,
            capitalBln = baseSheet.capitalBln
        )
    }

    /**
     * Models SOMA portfolio runoff and monthly reinvestment dynamics.
     */
    fun simulateSomaRunoff(
        basePortfolio: SomaPortfolio,
        treasuryCapBln: Double = 60.0,
        mbsCapBln: Double = 35.0,
        maturingTreasuriesBln: Double = 75.0,
        maturingMbsBln: Double = 18.0
    ): SomaPortfolio {
        val treasuryRunoff = Math.min(maturingTreasuriesBln, treasuryCapBln)
        val treasuryReinvestment = maturingTreasuriesBln - treasuryRunoff

        val mbsRunoff = Math.min(maturingMbsBln, mbsCapBln)
        val mbsReinvestment = maturingMbsBln - mbsRunoff

        val totalRunoff = treasuryRunoff + mbsRunoff
        val totalReinvestment = treasuryReinvestment + mbsReinvestment

        val newTreasuries = (basePortfolio.treasuryBillsBln + basePortfolio.treasuryNotesBln + basePortfolio.treasuryBondsBln) - treasuryRunoff
        val newMbs = basePortfolio.agencyMbsBln - mbsRunoff

        return basePortfolio.copy(
            totalHoldingsBln = newTreasuries + newMbs,
            monthlyRunoffCapBln = treasuryCapBln + mbsCapBln,
            actualMonthlyRunoffBln = totalRunoff,
            monthlyReinvestmentBln = totalReinvestment
        )
    }
}
