package com.example.engine

import com.example.domain.model.*
import java.text.SimpleDateFormat
import java.util.*

object SrpAuctionSimulator {

    /**
     * Validates a single proposition submitted by a counterparty for a Standing Repo Operation.
     */
    fun validateProposition(
        proposition: Proposition,
        counterparty: Counterparty,
        facility: RepoFacility,
        availableFacilityLimitBln: Double
    ): Pair<PropositionStatus, String?> {
        // 1. Check Counterparty Eligibility
        if (!counterparty.srpEligible) {
            return Pair(PropositionStatus.REJECTED, "Counterparty is not on the Standing Repo Facility Master Agreement list.")
        }
        
        // 2. Check Counterparty Type against Facility Eligibility
        if (!facility.eligibleCounterpartyTypes.contains(counterparty.type)) {
            return Pair(PropositionStatus.REJECTED, "Institution type ${counterparty.type.displayName} is ineligible for this operation.")
        }

        // 3. Check Minimum Denomination ($1M = 0.001B)
        if (proposition.propositionAmountBln < 0.001) {
            return Pair(PropositionStatus.REJECTED, "Proposition amount is below minimum denomination ($1,000,000).")
        }

        // 4. Check Per-Counterparty Proposition Limit
        if (proposition.propositionAmountBln > facility.propositionLimitBln) {
            return Pair(PropositionStatus.REJECTED, "Proposition exceeds per-counterparty facility limit of $${facility.propositionLimitBln}B.")
        }

        // 5. Check Collateral Eligibility
        if (!facility.eligibleCollateral.contains(proposition.securityType)) {
            return Pair(PropositionStatus.REJECTED, "Collateral type ${proposition.securityType.displayName} is not eligible for this facility.")
        }

        // 6. Check Counterparty Free Collateral
        val requiredCollateral = proposition.propositionAmountBln / (1.0 - proposition.securityType.standardHaircutPct / 100.0)
        if (requiredCollateral > counterparty.freeCollateralBillions) {
            return Pair(PropositionStatus.REJECTED, "Insufficient unencumbered collateral: Needs $${String.format("%.2f", requiredCollateral)}B, Available: $${String.format("%.2f", counterparty.freeCollateralBillions)}B.")
        }

        return Pair(PropositionStatus.ACCEPTED, null)
    }

    /**
     * Executes the Standing Repo Auction / Operation allotment engine.
     */
    fun executeOperation(
        operationId: String,
        operationName: String,
        scheduleWindow: String,
        facility: RepoFacility,
        propositions: List<Proposition>,
        counterpartiesMap: Map<String, Counterparty>
    ): Pair<OperationResult, List<Proposition>> {
        val validatedPropositions = mutableListOf<Proposition>()
        var remainingCapacityBln = facility.aggregateLimitBln
        
        var totalSubmittedBln = 0.0
        var totalAwardedBln = 0.0
        var treasuryAwardedBln = 0.0
        var agencyAwardedBln = 0.0
        var mbsAwardedBln = 0.0
        val participatingCounterpartyIds = mutableSetOf<String>()

        // 1. Validate all propositions
        for (prop in propositions) {
            val cp = counterpartiesMap[prop.counterpartyId]
            totalSubmittedBln += prop.propositionAmountBln
            
            if (cp == null) {
                validatedPropositions.add(prop.copy(status = PropositionStatus.REJECTED, rejectionReason = "Counterparty ID not found in Federal Reserve registry."))
                continue
            }

            val (status, reason) = validateProposition(prop, cp, facility, remainingCapacityBln)
            if (status == PropositionStatus.REJECTED) {
                validatedPropositions.add(prop.copy(status = status, rejectionReason = reason))
            } else {
                validatedPropositions.add(prop.copy(status = PropositionStatus.ACCEPTED))
            }
        }

        // 2. Allotment calculation based on Operation Mode
        val acceptedProps = validatedPropositions.filter { it.status == PropositionStatus.ACCEPTED }
        val acceptedTotalBln = acceptedProps.sumOf { it.propositionAmountBln }

        val finalProps = mutableListOf<Proposition>()

        when (facility.allotmentMethod) {
            OperationMode.FULL_ALLOTMENT, OperationMode.FIXED_RATE -> {
                // If total accepted <= facility limit, allot 100%
                val scalingFactor = if (acceptedTotalBln <= facility.aggregateLimitBln) 1.0 else facility.aggregateLimitBln / acceptedTotalBln

                for (p in validatedPropositions) {
                    if (p.status == PropositionStatus.ACCEPTED) {
                        val award = p.propositionAmountBln * scalingFactor
                        totalAwardedBln += award
                        participatingCounterpartyIds.add(p.counterpartyId)

                        when (p.securityType) {
                            CollateralType.TREASURY_BILL, CollateralType.TREASURY_NOTE, CollateralType.TREASURY_BOND, CollateralType.TIPS, CollateralType.FRN -> treasuryAwardedBln += award
                            CollateralType.AGENCY_DEBT -> agencyAwardedBln += award
                            CollateralType.AGENCY_MBS -> mbsAwardedBln += award
                        }

                        finalProps.add(
                            p.copy(
                                awardAmountBln = award,
                                status = if (scalingFactor == 1.0) PropositionStatus.ACCEPTED else PropositionStatus.PARTIALLY_ACCEPTED
                            )
                        )
                    } else {
                        finalProps.add(p)
                    }
                }
            }

            OperationMode.PRO_RATA -> {
                val factor = if (acceptedTotalBln > 0) (facility.aggregateLimitBln / acceptedTotalBln).coerceAtMost(1.0) else 1.0
                for (p in validatedPropositions) {
                    if (p.status == PropositionStatus.ACCEPTED) {
                        val award = p.propositionAmountBln * factor
                        totalAwardedBln += award
                        participatingCounterpartyIds.add(p.counterpartyId)
                        when (p.securityType) {
                            CollateralType.TREASURY_BILL, CollateralType.TREASURY_NOTE, CollateralType.TREASURY_BOND, CollateralType.TIPS, CollateralType.FRN -> treasuryAwardedBln += award
                            CollateralType.AGENCY_DEBT -> agencyAwardedBln += award
                            CollateralType.AGENCY_MBS -> mbsAwardedBln += award
                        }
                        finalProps.add(p.copy(awardAmountBln = award, status = if (factor >= 1.0) PropositionStatus.ACCEPTED else PropositionStatus.PARTIALLY_ACCEPTED))
                    } else {
                        finalProps.add(p)
                    }
                }
            }

            OperationMode.COMPETITIVE_AUCTION -> {
                // Rank propositions by submitted rate descending (highest rate gets priority)
                val sortedProps = acceptedProps.sortedByDescending { it.submittedRate }
                val allocatedMap = mutableMapOf<String, Double>()
                var cap = facility.aggregateLimitBln

                for (p in sortedProps) {
                    val allot = Math.min(p.propositionAmountBln, cap)
                    allocatedMap[p.propositionId] = allot
                    cap -= allot
                }

                for (p in validatedPropositions) {
                    if (p.status == PropositionStatus.ACCEPTED) {
                        val award = allocatedMap[p.propositionId] ?: 0.0
                        totalAwardedBln += award
                        if (award > 0) participatingCounterpartyIds.add(p.counterpartyId)
                        when (p.securityType) {
                            CollateralType.TREASURY_BILL, CollateralType.TREASURY_NOTE, CollateralType.TREASURY_BOND, CollateralType.TIPS, CollateralType.FRN -> treasuryAwardedBln += award
                            CollateralType.AGENCY_DEBT -> agencyAwardedBln += award
                            CollateralType.AGENCY_MBS -> mbsAwardedBln += award
                        }
                        finalProps.add(
                            p.copy(
                                awardAmountBln = award,
                                status = if (award == p.propositionAmountBln) PropositionStatus.ACCEPTED else if (award > 0) PropositionStatus.PARTIALLY_ACCEPTED else PropositionStatus.REJECTED,
                                rejectionReason = if (award == 0.0) "Rate cut-off: Allotment capacity exhausted." else null
                            )
                        )
                    } else {
                        finalProps.add(p)
                    }
                }
            }
        }

        val result = OperationResult(
            operationId = operationId,
            operationName = operationName,
            operationDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
            scheduleWindow = scheduleWindow,
            ratePct = facility.ratePct,
            totalSubmittedBln = totalSubmittedBln,
            totalAwardedBln = totalAwardedBln,
            treasuryAwardedBln = treasuryAwardedBln,
            agencyAwardedBln = agencyAwardedBln,
            mbsAwardedBln = mbsAwardedBln,
            participatingCount = participatingCounterpartyIds.size
        )

        return Pair(result, finalProps)
    }
}
