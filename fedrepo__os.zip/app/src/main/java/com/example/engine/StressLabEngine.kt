package com.example.engine

import com.example.domain.model.*

object StressLabEngine {

    val PRELOADED_SCENARIOS = listOf(
        StressScenario(
            id = "SCEN-001",
            code = "001",
            title = "Treasury Market Selloff",
            description = "Yield curve shifts +75bps across 2Y-10Y, dirty prices fall 2.8%, repo collateral value contracts.",
            treasuryHaircutShockPct = 0.50,
            repoRateShockBps = 35.0,
            mbsHaircutShockPct = 1.00,
            dealerLiquidityDropPct = 12.0,
            reserveDrainBln = 45.0,
            onRrpShiftBln = -30.0,
            expectedImpactSummary = "Treasury collateral values drop ~$250B across primary dealers. Haircuts widen 50bps, triggering $18B in margin calls. SOFR drifts 15bps above IORB."
        ),
        StressScenario(
            id = "SCEN-002",
            code = "002",
            title = "Repo Rate Spike (Year-End Turn)",
            description = "Quarter-end/year-end balance sheet window dressing causes GC repo rates to spike to SRP ceiling.",
            treasuryHaircutShockPct = 0.25,
            repoRateShockBps = 65.0,
            mbsHaircutShockPct = 0.50,
            dealerLiquidityDropPct = 25.0,
            reserveDrainBln = 15.0,
            onRrpShiftBln = 60.0,
            expectedImpactSummary = "SOFR spikes +65bps above target corridor. Standing Repo Facility (SRP) utilization surges to $145B as primary dealers tap Fed backstop."
        ),
        StressScenario(
            id = "SCEN-003",
            code = "003",
            title = "Systemic Haircut Shock",
            description = "Clearing houses and bilateral counterparties mandate +100bps haircut across all sovereign and agency collateral.",
            treasuryHaircutShockPct = 1.00,
            repoRateShockBps = 40.0,
            mbsHaircutShockPct = 2.00,
            dealerLiquidityDropPct = 30.0,
            reserveDrainBln = 20.0,
            onRrpShiftBln = -15.0,
            expectedImpactSummary = "Tri-party and bilateral funding capacity drops by $188B. Margin call cascade across non-primary broker dealers."
        ),
        StressScenario(
            id = "SCEN-004",
            code = "004",
            title = "Dealer Balance-Sheet Constraint",
            description = "Supplementary Leverage Ratio (SLR) constraints force top 5 primary dealers to compress overnight repo intermediation.",
            treasuryHaircutShockPct = 0.20,
            repoRateShockBps = 50.0,
            mbsHaircutShockPct = 0.75,
            dealerLiquidityDropPct = 40.0,
            reserveDrainBln = 0.0,
            onRrpShiftBln = 40.0,
            expectedImpactSummary = "Dealer repo capacity contracts 40%. Cash borrowers migrate to bilateral peer-to-peer markets with wide bid-ask spreads."
        ),
        StressScenario(
            id = "SCEN-005",
            code = "005",
            title = "Agency MBS Volatility Shock",
            description = "Prepayment volatility and interest rate spread widening trigger 200bps haircut spike on Agency MBS pools.",
            treasuryHaircutShockPct = 0.0,
            repoRateShockBps = 25.0,
            mbsHaircutShockPct = 2.00,
            dealerLiquidityDropPct = 18.0,
            reserveDrainBln = 10.0,
            onRrpShiftBln = 0.0,
            expectedImpactSummary = "MBS financing spreads widen 35bps over SOFR. Real Estate Investment Trusts (mREITs) face heavy margin calls."
        ),
        StressScenario(
            id = "SCEN-006",
            code = "006",
            title = "ON RRP Rapid Drain",
            description = "MMFs shift $100B cash from Fed ON RRP facility into Treasury Bills and private tri-party repo.",
            treasuryHaircutShockPct = 0.0,
            repoRateShockBps = -12.0,
            mbsHaircutShockPct = 0.0,
            dealerLiquidityDropPct = -10.0,
            reserveDrainBln = -100.0, // Reserves increase by 100B
            onRrpShiftBln = -100.0,
            expectedImpactSummary = "ON RRP balance falls to $18B. Bank reserve balances increase +$100B, expanding dealer cash liquidity and depressing overnight repo rates toward ON RRP floor."
        ),
        StressScenario(
            id = "SCEN-007",
            code = "007",
            title = "TGA Tax Date Reserve Drain",
            description = "Treasury General Account (TGA) swells +$150B following corporate tax payments, draining bank reserve balances.",
            treasuryHaircutShockPct = 0.15,
            repoRateShockBps = 28.0,
            mbsHaircutShockPct = 0.25,
            dealerLiquidityDropPct = 22.0,
            reserveDrainBln = 150.0,
            onRrpShiftBln = -25.0,
            expectedImpactSummary = "Reserve balances drop to $3.06T. Federal funds EFFR firming up against IORB, interbank lending volume increases."
        ),
        StressScenario(
            id = "SCEN-008",
            code = "008",
            title = "Quantitative Easing / Reserve Injection",
            description = "Federal Reserve purchases $80B Treasuries in open market operations, injecting reserves into banking system.",
            treasuryHaircutShockPct = -0.10,
            repoRateShockBps = -15.0,
            mbsHaircutShockPct = -0.20,
            dealerLiquidityDropPct = -20.0,
            reserveDrainBln = -80.0,
            onRrpShiftBln = 35.0,
            expectedImpactSummary = "Reserve balances rise to $3.29T. Funding spreads compress, collateral scarcity emerges in on-the-run Treasury benchmarks."
        ),
        StressScenario(
            id = "SCEN-009",
            code = "009",
            title = "Primary Dealer Default & Fire-Sale",
            description = "Top Tier-2 Primary Dealer defaults on $35B tri-party repo obligations during morning settlement.",
            treasuryHaircutShockPct = 0.75,
            repoRateShockBps = 55.0,
            mbsHaircutShockPct = 1.50,
            dealerLiquidityDropPct = 35.0,
            reserveDrainBln = 25.0,
            onRrpShiftBln = 20.0,
            expectedImpactSummary = "Tri-party clearing agent exercises collateral liquidation rights. Repo rate contagion spreads across peer dealers. Fed activates emergency lending backstops."
        ),
        StressScenario(
            id = "SCEN-010",
            code = "010",
            title = "Fedwire & Settlement Gridlock",
            description = "Operational network outage at major settlement agent delays 40% of morning tri-party DVP allocations.",
            treasuryHaircutShockPct = 0.30,
            repoRateShockBps = 45.0,
            mbsHaircutShockPct = 0.50,
            dealerLiquidityDropPct = 50.0,
            reserveDrainBln = 0.0,
            onRrpShiftBln = 0.0,
            expectedImpactSummary = "Settlement fails surge past $42B. Overnight fail penalties accrue at TMPG standard rates (max(0, 300bps - EFFR))."
        ),
        StressScenario(
            id = "SCEN-011",
            code = "011",
            title = "Collateral Shortage / Squeeze",
            description = "Foreign central bank demand and short positions cause extreme collateral scarcity in 10Y Note benchmarks.",
            treasuryHaircutShockPct = 0.0,
            repoRateShockBps = -40.0,
            mbsHaircutShockPct = 0.0,
            dealerLiquidityDropPct = 5.0,
            reserveDrainBln = 0.0,
            onRrpShiftBln = 0.0,
            expectedImpactSummary = "10Y Treasury repo rate plunges into deep specials (trading at 0.50%, 340bps below GC). Fails-to-deliver spike as short sellers struggle to borrow collateral."
        ),
        StressScenario(
            id = "SCEN-012",
            code = "012",
            title = "Systemic Funding Freeze",
            description = "Simultaneous liquidity shock: Global risk-off, money market fund redemptions, and haircut doubling.",
            treasuryHaircutShockPct = 1.50,
            repoRateShockBps = 95.0,
            mbsHaircutShockPct = 3.00,
            dealerLiquidityDropPct = 65.0,
            reserveDrainBln = 120.0,
            onRrpShiftBln = 85.0,
            expectedImpactSummary = "Private repo markets seize. Standing Repo Facility (SRP) operates at 100% capacity ($500B full allotment). Fed emergency dollar swap lines utilized."
        )
    )

    /**
     * Executes Counterparty Default & Contagion Simulation.
     */
    fun simulateCounterpartyDefault(
        defaultingCounterparty: Counterparty,
        allCounterparties: List<Counterparty>
    ): ContagionSimulationResult {
        val totalExposureBln = defaultingCounterparty.collateralEncumberedBillions
        val collateralMarketValBln = defaultingCounterparty.totalCollateralBillions * 0.70
        val haircutRecoveryBln = collateralMarketValBln * 0.98 // 2% liquidation slip
        val replacementCostBln = (totalExposureBln - haircutRecoveryBln).coerceAtLeast(0.5)

        val affectedList = mutableListOf<Pair<String, Double>>()
        val peerDealers = allCounterparties.filter { it.id != defaultingCounterparty.id && it.type == CounterpartyType.PRIMARY_DEALER }

        var contagionLossTotal = replacementCostBln
        for ((idx, peer) in peerDealers.take(5).withIndex()) {
            val peerLoss = replacementCostBln * (0.35 / (idx + 1))
            contagionLossTotal += peerLoss
            affectedList.add(Pair(peer.name, peerLoss))
        }

        val repoRateSpikeBps = (totalExposureBln * 1.2).coerceIn(15.0, 85.0)
        val systemLiquidityLoss = totalExposureBln * 1.8
        val fedFacilityDraw = Math.min(systemLiquidityLoss * 0.6, 250.0)

        return ContagionSimulationResult(
            defaultingCounterparty = defaultingCounterparty.name,
            initialLossBln = totalExposureBln,
            collateralLiquidatedBln = haircutRecoveryBln,
            replacementCostBln = replacementCostBln,
            repoRateSpikeBps = repoRateSpikeBps,
            systemLiquidityLossBln = systemLiquidityLoss,
            fedFacilityDrawBln = fedFacilityDraw,
            cascadeRounds = 3,
            affectedCounterparties = affectedList
        )
    }

    /**
     * Calculates Herfindahl-Hirschman Index (HHI) for collateral concentration.
     */
    fun calculateCollateralConcentration(securities: List<CollateralSecurity>): Pair<Double, String> {
        val totalOutstanding = securities.sumOf { it.outstandingBillions }
        if (totalOutstanding == 0.0) return Pair(0.0, "Low Concentration")

        var hhi = 0.0
        for (sec in securities) {
            val sharePct = (sec.outstandingBillions / totalOutstanding) * 100.0
            hhi += sharePct * sharePct
        }

        val evaluation = when {
            hhi < 1500 -> "Unconcentrated / High Diversification"
            hhi in 1500.0..2500.0 -> "Moderate Collateral Concentration"
            else -> "High Concentration / Systemic Bottleneck"
        }
        return Pair(hhi, evaluation)
    }
}
