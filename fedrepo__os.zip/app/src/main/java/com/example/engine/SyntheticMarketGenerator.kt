package com.example.engine

import com.example.domain.model.*

object SyntheticMarketGenerator {

    fun generateCounterparties(): List<Counterparty> {
        return listOf(
            Counterparty(
                id = "CP-PD-001",
                name = "J.P. Morgan Securities LLC",
                shortName = "JPM Sec",
                type = CounterpartyType.PRIMARY_DEALER,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 85.0,
                treasuryInventoryBillions = 320.0,
                agencyInventoryBillions = 95.0,
                mbsInventoryBillions = 140.0,
                repoCapacityBillions = 450.0,
                collateralEncumberedBillions = 310.0,
                riskScore = 12
            ),
            Counterparty(
                id = "CP-PD-002",
                name = "Goldman Sachs & Co. LLC",
                shortName = "GS & Co",
                type = CounterpartyType.PRIMARY_DEALER,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 68.0,
                treasuryInventoryBillions = 260.0,
                agencyInventoryBillions = 70.0,
                mbsInventoryBillions = 110.0,
                repoCapacityBillions = 380.0,
                collateralEncumberedBillions = 245.0,
                riskScore = 14
            ),
            Counterparty(
                id = "CP-PD-003",
                name = "BofA Securities, Inc.",
                shortName = "BofA Sec",
                type = CounterpartyType.PRIMARY_DEALER,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 72.0,
                treasuryInventoryBillions = 290.0,
                agencyInventoryBillions = 85.0,
                mbsInventoryBillions = 125.0,
                repoCapacityBillions = 410.0,
                collateralEncumberedBillions = 280.0,
                riskScore = 13
            ),
            Counterparty(
                id = "CP-PD-004",
                name = "Morgan Stanley & Co. LLC",
                shortName = "MS & Co",
                type = CounterpartyType.PRIMARY_DEALER,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 58.0,
                treasuryInventoryBillions = 220.0,
                agencyInventoryBillions = 60.0,
                mbsInventoryBillions = 95.0,
                repoCapacityBillions = 330.0,
                collateralEncumberedBillions = 210.0,
                riskScore = 15
            ),
            Counterparty(
                id = "CP-PD-005",
                name = "Citigroup Global Markets Inc.",
                shortName = "Citi GM",
                type = CounterpartyType.PRIMARY_DEALER,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 62.0,
                treasuryInventoryBillions = 240.0,
                agencyInventoryBillions = 75.0,
                mbsInventoryBillions = 105.0,
                repoCapacityBillions = 360.0,
                collateralEncumberedBillions = 230.0,
                riskScore = 16
            ),
            Counterparty(
                id = "CP-PD-006",
                name = "Barclays Capital Inc.",
                shortName = "Barclays",
                type = CounterpartyType.PRIMARY_DEALER,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 45.0,
                treasuryInventoryBillions = 180.0,
                agencyInventoryBillions = 50.0,
                mbsInventoryBillions = 80.0,
                repoCapacityBillions = 270.0,
                collateralEncumberedBillions = 175.0,
                riskScore = 18
            ),
            Counterparty(
                id = "CP-PD-007",
                name = "BNP Paribas Securities Corp.",
                shortName = "BNP Par",
                type = CounterpartyType.PRIMARY_DEALER,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 42.0,
                treasuryInventoryBillions = 165.0,
                agencyInventoryBillions = 45.0,
                mbsInventoryBillions = 70.0,
                repoCapacityBillions = 250.0,
                collateralEncumberedBillions = 160.0,
                riskScore = 17
            ),
            Counterparty(
                id = "CP-PD-008",
                name = "Wells Fargo Securities, LLC",
                shortName = "Wells Fargo",
                type = CounterpartyType.PRIMARY_DEALER,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 50.0,
                treasuryInventoryBillions = 210.0,
                agencyInventoryBillions = 65.0,
                mbsInventoryBillions = 90.0,
                repoCapacityBillions = 310.0,
                collateralEncumberedBillions = 195.0,
                riskScore = 14
            ),
            Counterparty(
                id = "CP-BK-001",
                name = "JPMorgan Chase Bank, N.A.",
                shortName = "JPMC Bank",
                type = CounterpartyType.BANK,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 310.0,
                treasuryInventoryBillions = 450.0,
                agencyInventoryBillions = 180.0,
                mbsInventoryBillions = 320.0,
                repoCapacityBillions = 650.0,
                collateralEncumberedBillions = 220.0,
                riskScore = 8
            ),
            Counterparty(
                id = "CP-BK-002",
                name = "The Bank of New York Mellon",
                shortName = "BNY Mellon",
                type = CounterpartyType.BANK,
                srpEligible = true,
                onRrpEligible = true,
                capitalBillions = 42.0,
                treasuryInventoryBillions = 140.0,
                agencyInventoryBillions = 60.0,
                mbsInventoryBillions = 90.0,
                repoCapacityBillions = 220.0,
                collateralEncumberedBillions = 85.0,
                riskScore = 9
            ),
            Counterparty(
                id = "CP-MMF-001",
                name = "Federated Hermes Government Obligations Fund",
                shortName = "Federated Gov",
                type = CounterpartyType.MMF,
                srpEligible = false,
                onRrpEligible = true,
                capitalBillions = 145.0,
                treasuryInventoryBillions = 90.0,
                agencyInventoryBillions = 30.0,
                mbsInventoryBillions = 0.0,
                repoCapacityBillions = 160.0,
                collateralEncumberedBillions = 0.0,
                riskScore = 5
            ),
            Counterparty(
                id = "CP-MMF-002",
                name = "Fidelity Government Money Market Fund",
                shortName = "Fidelity Gov",
                type = CounterpartyType.MMF,
                srpEligible = false,
                onRrpEligible = true,
                capitalBillions = 280.0,
                treasuryInventoryBillions = 175.0,
                agencyInventoryBillions = 65.0,
                mbsInventoryBillions = 0.0,
                repoCapacityBillions = 220.0,
                collateralEncumberedBillions = 0.0,
                riskScore = 4
            ),
            Counterparty(
                id = "CP-MMF-003",
                name = "Vanguard Federal Money Market Fund",
                shortName = "Vanguard Fed",
                type = CounterpartyType.MMF,
                srpEligible = false,
                onRrpEligible = true,
                capitalBillions = 260.0,
                treasuryInventoryBillions = 160.0,
                agencyInventoryBillions = 70.0,
                mbsInventoryBillions = 0.0,
                repoCapacityBillions = 210.0,
                collateralEncumberedBillions = 0.0,
                riskScore = 4
            ),
            Counterparty(
                id = "CP-MMF-004",
                name = "BlackRock Liquidity FedFund",
                shortName = "BlackRock Fed",
                type = CounterpartyType.MMF,
                srpEligible = false,
                onRrpEligible = true,
                capitalBillions = 180.0,
                treasuryInventoryBillions = 110.0,
                agencyInventoryBillions = 45.0,
                mbsInventoryBillions = 0.0,
                repoCapacityBillions = 170.0,
                collateralEncumberedBillions = 0.0,
                riskScore = 5
            ),
            Counterparty(
                id = "CP-GSE-001",
                name = "Federal Home Loan Bank of San Francisco",
                shortName = "FHLB SF",
                type = CounterpartyType.GSE,
                srpEligible = false,
                onRrpEligible = true,
                capitalBillions = 95.0,
                treasuryInventoryBillions = 80.0,
                agencyInventoryBillions = 40.0,
                mbsInventoryBillions = 15.0,
                repoCapacityBillions = 120.0,
                collateralEncumberedBillions = 25.0,
                riskScore = 6
            ),
            Counterparty(
                id = "CP-GSE-002",
                name = "Federal National Mortgage Association (Fannie Mae)",
                shortName = "Fannie Mae",
                type = CounterpartyType.GSE,
                srpEligible = false,
                onRrpEligible = true,
                capitalBillions = 110.0,
                treasuryInventoryBillions = 75.0,
                agencyInventoryBillions = 55.0,
                mbsInventoryBillions = 60.0,
                repoCapacityBillions = 140.0,
                collateralEncumberedBillions = 35.0,
                riskScore = 6
            )
        )
    }

    fun generateCollateralSecurities(): List<CollateralSecurity> {
        return listOf(
            CollateralSecurity("912797HB1", "US Treasury Bill 13W 2026-12-31", CollateralType.TREASURY_BILL, "U.S. Department of the Treasury", 0.25, 0.00, 99.02, 99.02, 95.0, 0.50, true, 99, 0.0, 3.88),
            CollateralSecurity("912797HA3", "US Treasury Bill 26W 2027-03-25", CollateralType.TREASURY_BILL, "U.S. Department of the Treasury", 0.50, 0.00, 98.05, 98.05, 88.0, 0.50, true, 98, 0.0, 3.89),
            CollateralSecurity("91282CJZ5", "US Treasury Note 2Y 4.125% 2028-09-30", CollateralType.TREASURY_NOTE, "U.S. Department of the Treasury", 2.00, 4.125, 99.85, 100.22, 65.0, 1.00, true, 97, 0.0, 3.90),
            CollateralSecurity("91282CKA8", "US Treasury Note 5Y 3.875% 2031-09-30", CollateralType.TREASURY_NOTE, "U.S. Department of the Treasury", 5.00, 3.875, 99.10, 99.45, 72.0, 1.00, true, 96, 0.0, 3.91),
            CollateralSecurity("91282CKB6", "US Treasury Note 10Y 4.000% 2036-08-15 (OTR)", CollateralType.TREASURY_NOTE, "U.S. Department of the Treasury", 10.00, 4.00, 99.50, 100.12, 110.0, 1.50, true, 99, 45.0, 3.45), // In high demand / Specials
            CollateralSecurity("912810TK9", "US Treasury Bond 30Y 4.250% 2056-08-15", CollateralType.TREASURY_BOND, "U.S. Department of the Treasury", 30.00, 4.25, 98.20, 99.05, 48.0, 2.00, true, 92, 0.0, 3.92),
            CollateralSecurity("912828ZF9", "US TIPS 10Y 1.875% 2036-07-15", CollateralType.TIPS, "U.S. Department of the Treasury", 10.00, 1.875, 99.30, 99.70, 32.0, 1.50, true, 88, 0.0, 3.91),
            CollateralSecurity("912828ZG7", "US FRN 2Y SOFR+0.22% 2028-07-31", CollateralType.FRN, "U.S. Department of the Treasury", 2.00, 4.14, 100.02, 100.15, 28.0, 0.75, true, 90, 0.0, 3.90),
            CollateralSecurity("3137EA9N2", "Federal Home Loan Bank Debenture 4.000% 2029-06-15", CollateralType.AGENCY_DEBT, "FHLB", 3.00, 4.00, 99.40, 99.80, 22.0, 2.00, true, 85, 0.0, 3.95),
            CollateralSecurity("31418DYG5", "Fannie Mae Benchmark Note 3.875% 2030-01-15", CollateralType.AGENCY_DEBT, "FNMA", 4.00, 3.875, 99.15, 99.60, 26.0, 2.00, true, 86, 0.0, 3.95),
            CollateralSecurity("01F0306A1", "UMBS 30Y Pool 5.500% Oct 2026", CollateralType.AGENCY_MBS, "Uniform MBS (Fannie/Freddie)", 30.00, 5.50, 99.75, 100.35, 85.0, 3.00, true, 82, 0.0, 3.98),
            CollateralSecurity("01F0306B9", "UMBS 30Y Pool 6.000% Oct 2026", CollateralType.AGENCY_MBS, "Uniform MBS (Fannie/Freddie)", 30.00, 6.00, 100.40, 101.10, 92.0, 3.00, true, 84, 0.0, 3.97)
        )
    }

    fun generateInitialRepoTransactions(): List<RepoTransaction> {
        return listOf(
            RepoTransaction(
                repoId = "TX-REPO-2026-001",
                transactionType = TransactionType.SRP,
                counterpartyId = "CP-PD-001",
                counterpartyName = "J.P. Morgan Securities LLC",
                cashAmount = 15_000_000_000.0,
                collateralMarketValue = 15_151_515_150.0,
                collateralType = CollateralType.TREASURY_NOTE,
                cusip = "91282CJZ5",
                haircutPct = 1.00,
                repoRatePct = 4.00,
                termDays = 1,
                startDate = "2026-10-05",
                maturityDate = "2026-10-06",
                settlementDate = "2026-10-05",
                clearingMethod = ClearingMethod.FEDTRADE_PLUS,
                settlementAgent = "Federal Reserve Bank of New York",
                status = SettlementStatus.SETTLED
            ),
            RepoTransaction(
                repoId = "TX-REPO-2026-002",
                transactionType = TransactionType.SRP,
                counterpartyId = "CP-PD-002",
                counterpartyName = "Goldman Sachs & Co. LLC",
                cashAmount = 12_500_000_000.0,
                collateralMarketValue = 12_626_262_600.0,
                collateralType = CollateralType.TREASURY_NOTE,
                cusip = "91282CKA8",
                haircutPct = 1.00,
                repoRatePct = 4.00,
                termDays = 1,
                startDate = "2026-10-05",
                maturityDate = "2026-10-06",
                settlementDate = "2026-10-05",
                clearingMethod = ClearingMethod.FEDTRADE_PLUS,
                settlementAgent = "Federal Reserve Bank of New York",
                status = SettlementStatus.SETTLED
            ),
            RepoTransaction(
                repoId = "TX-REPO-2026-003",
                transactionType = TransactionType.ON_RRP,
                counterpartyId = "CP-MMF-001",
                counterpartyName = "Federated Hermes Government Obligations Fund",
                cashAmount = 45_000_000_000.0,
                collateralMarketValue = 45_000_000_000.0,
                collateralType = CollateralType.TREASURY_BILL,
                cusip = "912797HB1",
                haircutPct = 0.00,
                repoRatePct = 3.75,
                termDays = 1,
                startDate = "2026-10-05",
                maturityDate = "2026-10-06",
                settlementDate = "2026-10-05",
                clearingMethod = ClearingMethod.TRIPARTY_BNY,
                settlementAgent = "Bank of New York Mellon",
                status = SettlementStatus.SETTLED
            ),
            RepoTransaction(
                repoId = "TX-REPO-2026-004",
                transactionType = TransactionType.TRIPARTY,
                counterpartyId = "CP-PD-003",
                counterpartyName = "BofA Securities, Inc.",
                cashAmount = 8_200_000_000.0,
                collateralMarketValue = 8_453_608_247.0,
                collateralType = CollateralType.AGENCY_MBS,
                cusip = "01F0306A1",
                haircutPct = 3.00,
                repoRatePct = 3.95,
                termDays = 1,
                startDate = "2026-10-05",
                maturityDate = "2026-10-06",
                settlementDate = "2026-10-05",
                clearingMethod = ClearingMethod.TRIPARTY_BNY,
                settlementAgent = "Bank of New York Mellon",
                status = SettlementStatus.SETTLED
            ),
            RepoTransaction(
                repoId = "TX-REPO-2026-005",
                transactionType = TransactionType.BILATERAL,
                counterpartyId = "CP-PD-004",
                counterpartyName = "Morgan Stanley & Co. LLC",
                cashAmount = 5_000_000_000.0,
                collateralMarketValue = 5_050_505_050.0,
                collateralType = CollateralType.TREASURY_NOTE,
                cusip = "91282CKB6",
                haircutPct = 1.00,
                repoRatePct = 3.45, // Specials rate
                termDays = 7,
                startDate = "2026-10-05",
                maturityDate = "2026-10-12",
                settlementDate = "2026-10-05",
                clearingMethod = ClearingMethod.FICC_DVP,
                settlementAgent = "Depository Trust & Clearing Corporation (FICC)",
                status = SettlementStatus.ACTIVE
            ),
            RepoTransaction(
                repoId = "TX-REPO-2026-006",
                transactionType = TransactionType.TRIPARTY,
                counterpartyId = "CP-PD-006",
                counterpartyName = "Barclays Capital Inc.",
                cashAmount = 3_500_000_000.0,
                collateralMarketValue = 3_571_428_571.0,
                collateralType = CollateralType.AGENCY_DEBT,
                cusip = "3137EA9N2",
                haircutPct = 2.00,
                repoRatePct = 3.94,
                termDays = 1,
                startDate = "2026-10-05",
                maturityDate = "2026-10-06",
                settlementDate = "2026-10-05",
                clearingMethod = ClearingMethod.TRIPARTY_BNY,
                settlementAgent = "Bank of New York Mellon",
                status = SettlementStatus.FAILED,
                failReason = "Counterparty Segregated Collateral Shortfall"
            )
        )
    }

    fun generateModelCards(): List<ModelCard> {
        return listOf(
            ModelCard(
                modelId = "MOD-REPO-001",
                name = "Institutional Repo Pricing & Haircut Engine",
                version = "v3.7.2",
                purpose = "Computes repurchase prices, eligible collateral haircuts, margin requirements, and effective funding costs using money market Actual/360 conventions.",
                methodology = "Actual/360 Money Market Interest Formula + Basel III Collateral Haircut Hierarchy.",
                assumptions = "Constant intraday interest rates; immediate DVP tri-party execution; uniform haircut schedules per collateral tier.",
                limitations = "Excludes intraday negative interest rate spikes and cross-border currency conversion basis.",
                calculationCount = 284910
            ),
            ModelCard(
                modelId = "MOD-CORR-002",
                name = "Federal Reserve Money-Market Corridor Transmission Model",
                version = "v2.4.0",
                purpose = "Simulates short-term wholesale interest rate dynamics (SOFR, EFFR, GC Repo) bounded by Standing Repo (ceiling) and ON RRP (floor).",
                methodology = "Arbitrage bounds + Supply-Demand Liquidity Elasticity Function relative to Reserve Balances and IORB.",
                assumptions = "Non-bank cash providers face ON RRP access constraints; primary dealers are balance-sheet constrained.",
                limitations = "Simulated research approximation; does not predict discretionary FOMC decisions.",
                calculationCount = 192400
            ),
            ModelCard(
                modelId = "MOD-BAL-003",
                name = "Federal Reserve Balance Sheet Digital Twin",
                version = "v4.1.0",
                purpose = "Enforces double-entry balance sheet conservation invariants (Total Assets == Total Liabilities + Capital) across open market and facility operations.",
                methodology = "T-Account Reserve Accounting + SOMA Runoff / Reinvestment Cash Flow Algorithms.",
                assumptions = "TGA balances exogenous; currency demand inelastic in the short run.",
                limitations = "Consolidated Federal Reserve System level; ignores individual district reserve bank allocations.",
                calculationCount = 89320
            ),
            ModelCard(
                modelId = "MOD-STRESS-004",
                name = "Systemic Repo Contagion & Liquidity Cascade Engine",
                version = "v3.1.5",
                purpose = "Quantifies counterparty default cascades, haircut fire-sales, and facility drawdowns under severe funding stress scenarios.",
                methodology = "NetworkX Graph Propagation Matrix + Eisenberg-Noe clearing model variant for bilateral/triparty exposures.",
                assumptions = "Fire-sale price impact is quadratic in liquidation volume relative to daily average volume (ADV).",
                limitations = "Historical parameter calibrations may break during unprecedented liquidity regimes.",
                calculationCount = 64110
            )
        )
    }

    fun generateResearchQueries(): List<ResearchQuery> {
        return listOf(
            ResearchQuery(
                queryId = "RES-001",
                question = "How sensitive is repo funding to a 1% Treasury haircut?",
                category = "Collateral & Haircuts",
                modelExplanation = "A +100bps haircut shock across Treasury collateral decreases eligible collateral values by 1.0%. Across the ~$8.94T aggregate collateral base in the repo system, this removes ~$89.4B of instantaneous borrowing capacity. Primary dealers with high leverage face immediate margin calls totaling ~$18.2B, forcing asset liquidations or increased utilization of the Fed's Standing Repo Facility (SRP).",
                metricImpacts = listOf(
                    "System Capacity Loss" to "-$89.4B (-1.0%)",
                    "Margin Calls Triggered" to "+$18.2B",
                    "SOFR Spread Impact" to "+14 bps widening",
                    "SRP Facility Draw" to "+$42.5B estimated"
                ),
                dataProvenance = "Model: MOD-REPO-001 & HaircutEngine v3.7.2. Source: Simulated Systemic Tri-Party Dataset."
            ),
            ResearchQuery(
                queryId = "RES-002",
                question = "Which collateral type has the largest synthetic funding impact?",
                category = "Collateral Composition",
                modelExplanation = "Agency MBS pools exhibit the largest synthetic funding sensitivity due to their higher baseline haircut (3.0%), greater duration volatility, and lower secondary market liquidity relative to on-the-run Treasuries. When haircut shocks occur, MBS funding capacity drops 2.5x faster than Treasury Bills.",
                metricImpacts = listOf(
                    "MBS Haircut Sensitivity" to "2.5x vs T-Bills",
                    "Average MBS Spread to SOFR" to "+8 to +15 bps",
                    "Liquidity Score" to "82/100 (Treasuries: 98/100)",
                    "Encumbered Ratio" to "74% across Primary Dealers"
                ),
                dataProvenance = "Model: MOD-REPO-001. Source: SIFMA & FedTrade synthetic operations registry."
            ),
            ResearchQuery(
                queryId = "RES-003",
                question = "What happens to reserve balances when ON RRP usage falls?",
                category = "Reserve Accounting",
                modelExplanation = "When counterparties (primarily Money Market Mutual Funds) reduce their balances at the Fed's Overnight Reverse Repo Facility (ON RRP), cash is redeployed into the private money markets (Treasury Bills or private repo). Because ON RRP is a Fed liability, a decline in ON RRP balances mechanically shifts liabilities into Bank Reserve Balances on a dollar-for-dollar basis (assuming TGA and other liabilities remain constant).",
                metricImpacts = listOf(
                    "ON RRP Shift" to "-$100B",
                    "Reserve Balances" to "+$100B injection",
                    "Interbank Liquidity" to "+3.1% buffer expansion",
                    "Overnight GC Repo" to "Pushes rates down toward ON RRP floor"
                ),
                dataProvenance = "Model: MOD-BAL-003. Federal Reserve Balance Sheet Digital Twin."
            ),
            ResearchQuery(
                queryId = "RES-004",
                question = "Show the relationship between SOFR and IORB.",
                category = "Monetary Transmission",
                modelExplanation = "Interest on Reserve Balances (IORB, 3.90%) sets a key benchmark for depository institutions. Secured Overnight Financing Rate (SOFR, 3.92%) reflects actual private repo transactions. When reserve balances are abundant, SOFR trades slightly below or near IORB. When reserves become scarce or repo collateral supply swells, SOFR trades above IORB as dealers pay higher rates to fund inventories.",
                metricImpacts = listOf(
                    "Current SOFR - IORB Spread" to "+2 bps (3.92% vs 3.90%)",
                    "Corridor Range" to "Floor: ON RRP (3.75%) | Ceiling: SRP (4.00%)",
                    "Transmission Efficiency" to "99.4% pass-through",
                    "Dispersion (P99 - P1)" to "30 bps (3.78% to 4.08%)"
                ),
                dataProvenance = "Model: MOD-CORR-002. NY Fed SOFR Publication Architecture Reference."
            ),
            ResearchQuery(
                queryId = "RES-005",
                question = "Replay the liquidity shock scenario.",
                category = "Stress & Scenarios",
                modelExplanation = "Replaying Scenario SCEN-012 (Systemic Funding Freeze): 1) Treasury dirty prices drop 3.2%; 2) Haircuts double across all tiers; 3) Private repo volume drops 45%; 4) Margin calls spike to $48B; 5) Primary dealers tap SRP for $142B; 6) SOFR pushes to the 4.00% SRP ceiling, stabilizing interbank settlement.",
                metricImpacts = listOf(
                    "Initial Shock" to "Haircut +150bps / Yields +65bps",
                    "Dealer Funding Shortfall" to "$65.2B",
                    "Fed Facility Activation" to "Full Allotment SRP $142.0B",
                    "Resolution Time" to "Settled same-day via tri-party FedTrade"
                ),
                dataProvenance = "Model: MOD-STRESS-004. Stress Lab Deterministic Replay Engine."
            )
        )
    }
}
