package com.example.engine

import com.example.domain.model.CollateralType
import com.example.domain.model.RepoEconomicsResult
import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.roundToLong

object RepoEconomicsEngine {

    /**
     * Executes institutional repo financial arithmetic adhering to U.S. money market
     * Actual/360 day-count conventions and collateral haircut mathematics.
     */
    fun calculateRepoEconomics(
        collateralMarketValue: Double,
        haircutPct: Double,
        repoRatePct: Double,
        termDays: Int = 1,
        requestedCashAmount: Double? = null,
        marginRequirementPct: Double = 100.0
    ): RepoEconomicsResult {
        // 1. Eligible Collateral Value = Market Value * (1 - Haircut)
        val eligibleCollateralValue = collateralMarketValue * (1.0 - (haircutPct / 100.0))
        
        // 2. Cash Advanced (if specified, capped at eligible collateral, or defaults to eligible value)
        val cashAdvanced = requestedCashAmount ?: eligibleCollateralValue
        
        // 3. Repo Interest = Cash Advanced * Rate * (Term / 360)  [Actual/360 Money Market convention]
        val repoInterestAmount = cashAdvanced * (repoRatePct / 100.0) * (termDays.toDouble() / 360.0)
        
        // 4. Repurchase Price = Cash Advanced + Repo Interest
        val repurchasePrice = cashAdvanced + repoInterestAmount
        
        // 5. Effective Annualized Funding Cost %
        val effectiveFundingCostPct = if (cashAdvanced > 0) {
            (repoInterestAmount / cashAdvanced) * (360.0 / termDays.toDouble()) * 100.0
        } else 0.0
        
        // 6. Collateral Coverage Ratio = Market Value / Cash Advanced
        val collateralCoverageRatio = if (cashAdvanced > 0) collateralMarketValue / cashAdvanced else 0.0
        
        // 7. Margin Requirement Amount
        val marginRequirementAmount = cashAdvanced * (marginRequirementPct / 100.0)
        
        // 8. Haircut Impact = Market Value - Eligible Collateral Value
        val haircutImpactAmount = collateralMarketValue - eligibleCollateralValue
        
        // 9. Margin Call = max(0, Margin Requirement - Eligible Collateral)
        val marginCallAmount = max(0.0, marginRequirementAmount - eligibleCollateralValue)
        
        // Deterministic Verification Hash for Auditability
        val rawInput = "$collateralMarketValue|$haircutPct|$repoRatePct|$termDays|$cashAdvanced"
        val hash = generateHash(rawInput)

        return RepoEconomicsResult(
            collateralMarketValue = collateralMarketValue,
            haircutPct = haircutPct,
            eligibleCollateralValue = eligibleCollateralValue,
            cashAdvanced = cashAdvanced,
            repoRatePct = repoRatePct,
            termDays = termDays,
            repoInterestAmount = repoInterestAmount,
            repurchasePrice = repurchasePrice,
            effectiveFundingCostPct = effectiveFundingCostPct,
            collateralCoverageRatio = collateralCoverageRatio,
            marginRequirementAmount = marginRequirementAmount,
            haircutImpactAmount = haircutImpactAmount,
            marginCallAmount = marginCallAmount,
            calculationHash = hash
        )
    }

    /**
     * Calculates required collateral market value for a given cash borrowing requirement.
     */
    fun calculateRequiredCollateral(
        targetCashAmount: Double,
        haircutPct: Double
    ): Double {
        val divisor = 1.0 - (haircutPct / 100.0)
        return if (divisor > 0) targetCashAmount / divisor else 0.0
    }

    /**
     * Evaluates collateral substitution impact:
     * Calculates margin delta when swapping Security A with Security B.
     */
    fun evaluateCollateralSwap(
        outgoingValue: Double,
        outgoingHaircut: Double,
        incomingValue: Double,
        incomingHaircut: Double,
        cashAdvanced: Double
    ): Pair<Double, String> {
        val outgoingEligible = outgoingValue * (1.0 - outgoingHaircut / 100.0)
        val incomingEligible = incomingValue * (1.0 - incomingHaircut / 100.0)
        val deltaEligible = incomingEligible - outgoingEligible
        val newCoverage = incomingValue / cashAdvanced
        
        val summary = if (deltaEligible >= 0) {
            "Collateral Upgrade / Safe: +$${formatCurrency(deltaEligible)} eligible capacity. Coverage: ${String.format("%.2f", newCoverage * 100)}%"
        } else {
            "Collateral Downgrade: Shortfall of -$${formatCurrency(-deltaEligible)}. Margin Call Required."
        }
        return Pair(deltaEligible, summary)
    }

    private fun generateHash(input: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(input.toByteArray())
        return bytes.take(4).joinToString("") { "%02X".format(it) }
    }

    private fun formatCurrency(amt: Double): String {
        return if (amt >= 1_000_000_000) String.format("%.2fB", amt / 1_000_000_000)
        else if (amt >= 1_000_000) String.format("%.2fM", amt / 1_000_000)
        else String.format("%.2f", amt)
    }
}
