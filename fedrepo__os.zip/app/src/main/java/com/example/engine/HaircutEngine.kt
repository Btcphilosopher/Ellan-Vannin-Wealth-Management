package com.example.engine

import com.example.domain.model.CollateralType
import com.example.domain.model.Counterparty

object HaircutEngine {

    /**
     * Computes base haircut for a security based on collateral category, maturity, and liquidity.
     */
    fun getBaseHaircut(
        type: CollateralType,
        maturityYears: Double,
        liquidityScore: Int = 95
    ): Double {
        val base = when (type) {
            CollateralType.TREASURY_BILL -> 0.50
            CollateralType.TREASURY_NOTE -> if (maturityYears <= 5.0) 1.00 else 1.50
            CollateralType.TREASURY_BOND -> if (maturityYears <= 20.0) 2.00 else 2.50
            CollateralType.TIPS -> 1.50
            CollateralType.FRN -> 0.75
            CollateralType.AGENCY_DEBT -> 2.00
            CollateralType.AGENCY_MBS -> 3.00
        }
        
        // Liquidity modifier: less liquid collateral incurs higher haircut
        val liquidityPenalty = if (liquidityScore < 80) (80 - liquidityScore) * 0.05 else 0.0
        return (base + liquidityPenalty).coerceIn(0.25, 15.0)
    }

    /**
     * Simulates haircut shock scenario (+25bp, +50bp, +100bp, or custom shift) across counterparties.
     * Computes total dollar funding capacity loss and margin calls triggered.
     */
    fun simulateHaircutShock(
        counterparties: List<Counterparty>,
        shockBps: Double
    ): HaircutShockResult {
        val shockPct = shockBps / 100.0 // e.g., 50 bps = 0.5%
        
        var originalTotalCapacityBln = 0.0
        var stressedTotalCapacityBln = 0.0
        var totalMarginCallsBln = 0.0
        val counterpartyImpacts = mutableListOf<CounterpartyHaircutImpact>()

        for (cp in counterparties) {
            val treasuryBaseHaircut = 1.0 // average
            val agencyBaseHaircut = 2.0
            val mbsBaseHaircut = 3.0

            val origEligibleTreasury = cp.treasuryInventoryBillions * (1.0 - treasuryBaseHaircut / 100.0)
            val origEligibleAgency = cp.agencyInventoryBillions * (1.0 - agencyBaseHaircut / 100.0)
            val origEligibleMbs = cp.mbsInventoryBillions * (1.0 - mbsBaseHaircut / 100.0)
            val origTotalEligible = origEligibleTreasury + origEligibleAgency + origEligibleMbs

            val stressedEligibleTreasury = cp.treasuryInventoryBillions * (1.0 - (treasuryBaseHaircut + shockPct) / 100.0)
            val stressedEligibleAgency = cp.agencyInventoryBillions * (1.0 - (agencyBaseHaircut + shockPct) / 100.0)
            val stressedEligibleMbs = cp.mbsInventoryBillions * (1.0 - (mbsBaseHaircut + shockPct) / 100.0)
            val stressedTotalEligible = stressedEligibleTreasury + stressedEligibleAgency + stressedEligibleMbs

            val capacityLoss = origTotalEligible - stressedTotalEligible
            val marginCall = (cp.collateralEncumberedBillions - stressedTotalEligible).coerceAtLeast(0.0)

            originalTotalCapacityBln += origTotalEligible
            stressedTotalCapacityBln += stressedTotalEligible
            totalMarginCallsBln += marginCall

            counterpartyImpacts.add(
                CounterpartyHaircutImpact(
                    counterpartyName = cp.name,
                    counterpartyType = cp.type.displayName,
                    originalEligibleBln = origTotalEligible,
                    stressedEligibleBln = stressedTotalEligible,
                    capacityLossBln = capacityLoss,
                    marginCallBln = marginCall
                )
            )
        }

        return HaircutShockResult(
            shockBps = shockBps,
            originalTotalCapacityBln = originalTotalCapacityBln,
            stressedTotalCapacityBln = stressedTotalCapacityBln,
            systemCapacityLossBln = originalTotalCapacityBln - stressedTotalCapacityBln,
            totalMarginCallsBln = totalMarginCallsBln,
            counterpartyImpacts = counterpartyImpacts.sortedByDescending { it.capacityLossBln }
        )
    }

    data class CounterpartyHaircutImpact(
        val counterpartyName: String,
        val counterpartyType: String,
        val originalEligibleBln: Double,
        val stressedEligibleBln: Double,
        val capacityLossBln: Double,
        val marginCallBln: Double
    )

    data class HaircutShockResult(
        val shockBps: Double,
        val originalTotalCapacityBln: Double,
        val stressedTotalCapacityBln: Double,
        val systemCapacityLossBln: Double,
        val totalMarginCallsBln: Double,
        val counterpartyImpacts: List<CounterpartyHaircutImpact>
    )
}
