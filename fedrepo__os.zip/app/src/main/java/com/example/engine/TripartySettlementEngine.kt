package com.example.engine

import com.example.domain.model.*
import java.text.SimpleDateFormat
import java.util.*

object TripartySettlementEngine {

    data class SettlementStep(
        val stepNumber: Int,
        val title: String,
        val description: String,
        val status: String,
        val timestamp: String
    )

    data class TripartyWorkflow(
        val transactionId: String,
        val counterpartyName: String,
        val cashAmountBln: Double,
        val collateralCusip: String,
        val collateralValueBln: Double,
        val tripartyAgent: String = "Bank of New York Mellon",
        val currentStatus: SettlementStatus,
        val steps: List<SettlementStep>,
        val exception: SettlementException? = null
    )

    /**
     * Generates a step-by-step triparty settlement lifecycle audit trail.
     */
    fun buildSettlementWorkflow(tx: RepoTransaction): TripartyWorkflow {
        val timeFormat = SimpleDateFormat("HH:mm:ss 'ET'", Locale.US)
        val now = System.currentTimeMillis()

        val steps = listOf(
            SettlementStep(1, "Trade Creation", "Bilateral or FedTrade Plus trade instruction injected.", "COMPLETED", timeFormat.format(Date(now - 180000))),
            SettlementStep(2, "Fedwire / Triparty Matching", "Matched Cash Borrower with Cash Lender via BNY Mellon AccessEdge.", "COMPLETED", timeFormat.format(Date(now - 120000))),
            SettlementStep(3, "Collateral Eligibility & Valuation", "Eligible collateral ${tx.collateralType.displayName} (CUSIP: ${tx.cusip}) priced & haircut verified (${tx.haircutPct}%).", "COMPLETED", timeFormat.format(Date(now - 60000))),
            SettlementStep(4, "Triparty Custody Allocation", "Collateral tagged in Triparty Segregated Custody Account.", "COMPLETED", timeFormat.format(Date(now - 30000))),
            SettlementStep(5, "Cash Delivery vs Payment (DVP)", "$${String.format("%.2f", tx.cashAmount / 1_000_000_000)}B Cash credited simultaneously against collateral pledge.", if (tx.status == SettlementStatus.FAILED) "FAILED" else "COMPLETED", timeFormat.format(Date(now))),
            SettlementStep(6, "Active Position & Daily Accrual", "Repo open: Accruing interest at ${tx.repoRatePct}% (Actual/360).", if (tx.status == SettlementStatus.SETTLED || tx.status == SettlementStatus.ACTIVE) "ACTIVE" else "PENDING", timeFormat.format(Date(now + 10000))),
            SettlementStep(7, "Maturity / Unwind / Return", "Next-day triparty unwind: Repurchase cash returned, collateral released.", "SCHEDULED FOR 08:30 ET NEXT DAY", "PENDING")
        )

        val exception = if (tx.status == SettlementStatus.FAILED) {
            SettlementException(
                exceptionId = "EXC-${tx.repoId.takeLast(4)}",
                transactionId = tx.repoId,
                counterpartyName = tx.counterpartyName,
                exceptionType = tx.failReason ?: "Insufficient Collateral in Custody",
                timestamp = timeFormat.format(Date()),
                severity = "HIGH",
                details = "Triparty allocation failed during DVP settlement batch. Counterparty sub-account has insufficient unencumbered CUSIP ${tx.cusip}.",
                suggestedAction = "Initiate Collateral Substitution or Inject Excess Cash into Settlement Account."
            )
        } else null

        return TripartyWorkflow(
            transactionId = tx.repoId,
            counterpartyName = tx.counterpartyName,
            cashAmountBln = tx.cashAmount / 1_000_000_000.0,
            collateralCusip = tx.cusip,
            collateralValueBln = tx.collateralMarketValue / 1_000_000_000.0,
            currentStatus = tx.status,
            steps = steps,
            exception = exception
        )
    }

    /**
     * Resolves a settlement exception via automated collateral substitution or cash injection.
     */
    fun resolveException(exception: SettlementException): Pair<RepoTransaction, String> {
        val resolvedTx = RepoTransaction(
            repoId = exception.transactionId,
            transactionType = TransactionType.TRIPARTY,
            counterpartyId = "CP-RESOLVED",
            counterpartyName = exception.counterpartyName,
            cashAmount = 2_500_000_000.0,
            collateralMarketValue = 2_550_000_000.0,
            collateralType = CollateralType.TREASURY_BILL,
            cusip = "912797HB1",
            haircutPct = 0.50,
            repoRatePct = 3.90,
            termDays = 1,
            startDate = "2026-10-05",
            maturityDate = "2026-10-06",
            settlementDate = "2026-10-05",
            clearingMethod = ClearingMethod.TRIPARTY_BNY,
            status = SettlementStatus.SETTLED
        )
        return Pair(resolvedTx, "Exception ${exception.exceptionId} resolved successfully. Substituted eligible collateral CUSIP 912797HB1. Trade settled.")
    }
}
