package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun DollarPlumbingFlow(
    srpTotalBln: Double,
    onRrpTotalBln: Double,
    totalRepoBln: Double,
    reservesBln: Double,
    modifier: Modifier = Modifier
) {
    var selectedNode by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .testTag("dollar_plumbing_flow_box")
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCard)
            .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DOLLAR FINANCIAL SYSTEM PLUMBING FLOW",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "TAP NODE FOR DETAIL",
                    color = TerminalSky,
                    fontSize = 9.5.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Interactive Schematic Flow Chart
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Top: Federal Reserve Central Bank
                FlowNode(
                    title = "FEDERAL RESERVE (OPEN MARKET DESK)",
                    subtitle = "System Open Market Account (SOMA) | Reserve Balances: $${String.format("%.2f", reservesBln / 1000.0)}T",
                    accent = TerminalSky,
                    isSelected = selectedNode == "FED",
                    onClick = { selectedNode = if (selectedNode == "FED") null else "FED" }
                )

                Text(text = "│    ┌───────────────┴───────────────┐    │", color = TerminalBorder, fontSize = 10.sp, fontFamily = FontFamily.Monospace)

                // Mid Tier: Facilities (SRP & ON RRP)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    FlowNode(
                        title = "STANDING REPO (SRP)",
                        subtitle = "Rate: 4.00% | Bal: $${String.format("%.1f", srpTotalBln)}B",
                        accent = CorridorCeiling,
                        isSelected = selectedNode == "SRP",
                        modifier = Modifier.weight(1f),
                        onClick = { selectedNode = if (selectedNode == "SRP") null else "SRP" }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FlowNode(
                        title = "ON REVERSE REPO (ON RRP)",
                        subtitle = "Rate: 3.75% | Bal: $${String.format("%.1f", onRrpTotalBln)}B",
                        accent = CorridorFloor,
                        isSelected = selectedNode == "ONRRP",
                        modifier = Modifier.weight(1f),
                        onClick = { selectedNode = if (selectedNode == "ONRRP") null else "ONRRP" }
                    )
                }

                Text(text = "↓                                ↓", color = TerminalBorder, fontSize = 10.sp, fontFamily = FontFamily.Monospace)

                // Intermediaries: Primary Dealers vs MMFs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    FlowNode(
                        title = "PRIMARY DEALERS & BANKS",
                        subtitle = "Cash Borrowers | Collateral Providers",
                        accent = TerminalCyan,
                        isSelected = selectedNode == "DEALERS",
                        modifier = Modifier.weight(1f),
                        onClick = { selectedNode = if (selectedNode == "DEALERS") null else "DEALERS" }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FlowNode(
                        title = "MMFs & GSEs",
                        subtitle = "Cash Lenders | Alternative to Private GC",
                        accent = TerminalAmber,
                        isSelected = selectedNode == "MMFS",
                        modifier = Modifier.weight(1f),
                        onClick = { selectedNode = if (selectedNode == "MMFS") null else "MMFS" }
                    )
                }

                Text(text = "└───────────────┬───────────────┘", color = TerminalBorder, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text(text = "↓", color = TerminalSky, fontSize = 12.sp, fontFamily = FontFamily.Monospace)

                // Broad Repo Market Clearing
                FlowNode(
                    title = "TRIPARTY & BILATERAL REPO MARKET",
                    subtitle = "Total Volume: $${String.format("%.2f", totalRepoBln / 1000.0)}T | Tri-Party Agent: BNY Mellon | FICC DVP Clearing",
                    accent = TerminalEmerald,
                    isSelected = selectedNode == "MARKET",
                    onClick = { selectedNode = if (selectedNode == "MARKET") null else "MARKET" }
                )

                Text(text = "┌───────────────┴───────────────┐", color = TerminalBorder, fontSize = 10.sp, fontFamily = FontFamily.Monospace)

                // Collateral Tiers
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CollateralTierPill(name = "TREASURIES", sub = "Bills / Notes / Bonds", haircut = "0.5%–2.0%", isSelected = selectedNode == "TREASURY", onClick = { selectedNode = if (selectedNode == "TREASURY") null else "TREASURY" }, modifier = Modifier.weight(1f))
                    CollateralTierPill(name = "AGENCY DEBT", sub = "Fannie / Freddie / FHLB", haircut = "2.0%", isSelected = selectedNode == "AGENCY", onClick = { selectedNode = if (selectedNode == "AGENCY") null else "AGENCY" }, modifier = Modifier.weight(1f))
                    CollateralTierPill(name = "AGENCY MBS", sub = "Uniform MBS Pools", haircut = "3.0%", isSelected = selectedNode == "MBS", onClick = { selectedNode = if (selectedNode == "MBS") null else "MBS" }, modifier = Modifier.weight(1f))
                }
            }

            // Explanatory Panel for Selected Node
            if (selectedNode != null) {
                NodeDetailExploration(node = selectedNode!!)
            }
        }
    }
}

@Composable
private fun FlowNode(
    title: String,
    subtitle: String,
    accent: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) accent.copy(alpha = 0.2f) else TerminalCard)
            .border(1.dp, if (isSelected) accent else TerminalBorder, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                color = if (isSelected) TextPrimary else TextHighlight,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                color = if (isSelected) accent else TextSecondary,
                fontSize = 8.5.sp,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun CollateralTierPill(
    name: String,
    sub: String,
    haircut: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isSelected) TerminalSky.copy(alpha = 0.2f) else TerminalCard)
            .border(1.dp, if (isSelected) TerminalSky else TerminalBorder, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(text = name, color = TextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(text = sub, color = TextMuted, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
            Text(text = "Haircut: $haircut", color = TerminalSky, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun NodeDetailExploration(node: String) {
    val (title, text) = when (node) {
        "FED" -> "Federal Reserve Balance Sheet & SOMA" to "The Open Market Desk implements FOMC monetary policy via standing facilities and outright asset purchases. Reserve balances serve as the core settlement medium for the banking system."
        "SRP" -> "Standing Repo Facility (Ceiling Control)" to "Provides overnight liquidity at 4.00% against Treasuries, Agency debt, and Agency MBS. Backstops money market rates during liquidity strains or window dressing."
        "ONRRP" -> "Overnight Reverse Repo Facility (Floor Control)" to "Allows Money Market Funds and GSEs to place excess cash at 3.75% with a $160B per counterparty limit, anchoring the lower boundary of overnight interest rates."
        "DEALERS" -> "Primary Dealer Intermediation" to "Primary dealers intermediate cash and securities across tri-party and bilateral markets, managing inventories and funding costs subject to Supplementary Leverage Ratios."
        "MMFS" -> "Money Market Funds & GSE Cash Supply" to "Institutional cash providers seek risk-free overnight yield. When private repo rates fall below ON RRP (3.75%), MMF cash flows into the Fed facility."
        "MARKET" -> "Repo Market Microstructure" to "General Collateral (GC) and Specials trading settled same-day via BNY Mellon tri-party infrastructure and DTCC/FICC netting."
        "TREASURY" -> "Treasury Collateral Baseline" to "0.5%–2.0% standard haircuts. High liquidity benchmark collateral eligible for all Federal Reserve operations."
        "AGENCY" -> "Agency Debt Collateral" to "2.0% standard haircut. Debentures of Fannie Mae, Freddie Mac, and Federal Home Loan Banks."
        "MBS" -> "Agency Mortgage-Backed Securities" to "3.0% standard haircut. Uniform MBS pools eligible for Fed operations with slightly wider financing spreads."
        else -> "" to ""
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalCardElevated)
            .border(1.dp, TerminalSky.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(text = "NODE INSPECTION: $title", color = TerminalSky, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(text = text, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Default)
        }
    }
}
