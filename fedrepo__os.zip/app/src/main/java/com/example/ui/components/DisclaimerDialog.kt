package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun DisclaimerDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .testTag("disclaimer_dialog_box")
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(TerminalSurface)
                .border(1.dp, TerminalBorder, RoundedCornerShape(12.dp))
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(TerminalAmber)
                    )
                    Text(
                        text = "FEDREPO//OS REGULATORY & RESEARCH NOTICE",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalCardElevated)
                        .padding(10.dp)
                ) {
                    Text(
                        text = "FEDREPO//OS IS AN INDEPENDENT FINANCIAL-RESEARCH AND SIMULATION PLATFORM. IT IS NOT A FEDERAL RESERVE SYSTEM, FEDERAL RESERVE BANK, NEW YORK FED SYSTEM OR FEDTRADE SYSTEM.\n\nALL TRADING, COUNTERPARTIES, BALANCES AND TRANSACTION DATA ARE SYNTHETIC AND DESIGNED EXCLUSIVELY FOR FINANCIAL COMPUTATION, QUANTITATIVE RESEARCH AND OPERATIONAL MODELING.",
                        color = TerminalAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 16.sp
                    )
                }

                Text(
                    text = "CURRENT 2026 REFERENCE CONFIGURATION:",
                    color = TerminalSky,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Text(
                    text = "• FOMC Target Range: 3.75% – 4.00%\n• Interest on Reserve Balances (IORB): 3.90%\n• Standing Repo Facility (SRP): 4.00% (Same-Day Tri-Party)\n• Overnight Reverse Repo (ON RRP): 3.75%\n• ON RRP Daily Counterparty Limit: $160 Billion\n• Morning Operation: 08:15–08:30 ET\n• Afternoon Operation: 13:30–13:45 ET\n• Eligible Collateral: Treasury, Agency Debt, Agency MBS",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 17.sp
                )

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dismiss_disclaimer_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalSky)
                ) {
                    Text("ACKNOWLEDGE & ENTER TERMINAL", color = TerminalBackground, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
