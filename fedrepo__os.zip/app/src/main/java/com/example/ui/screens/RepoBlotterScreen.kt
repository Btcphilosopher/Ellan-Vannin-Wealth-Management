package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun RepoBlotterScreen(
    state: TerminalUiState,
    viewModel: FedRepoViewModel,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf<TransactionType?>(null) }
    var showCalculator by remember { mutableStateOf(true) }
    var selectedTransaction by remember { mutableStateOf<RepoTransaction?>(null) }

    var inputCollateralBln by remember { mutableStateOf("10.0") }
    var inputHaircutPct by remember { mutableStateOf("1.0") }
    var inputRepoRatePct by remember { mutableStateOf("4.00") }
    var inputTermDays by remember { mutableStateOf("1") }

    LazyColumn(
        modifier = modifier
            .testTag("repo_blotter_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CANONICAL REPO BLOTTER & ECONOMICS ENGINE",
                    color = TextPrimary,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${state.repoTransactions.size} ACTIVE POSITIONS",
                    color = TerminalSky,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Repo Economics Calculator & Trade Ticket Creator
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "REPO FINANCIAL ARITHMETIC ENGINE (ACTUAL/360)",
                            color = TerminalSky,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalCardElevated)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "HASH: ${state.calcResult.calculationHash}",
                                color = TerminalEmerald,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Numeric Input Fields
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = inputCollateralBln,
                            onValueChange = {
                                inputCollateralBln = it
                                val num = it.toDoubleOrNull() ?: 10.0
                                viewModel.updateCalculator(collateralValue = num * 1_000_000_000.0)
                            },
                            label = { Text("Collateral (\$B)", fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                            modifier = Modifier.weight(1f).testTag("calc_input_collateral"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalSky,
                                unfocusedBorderColor = TerminalBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = inputHaircutPct,
                            onValueChange = {
                                inputHaircutPct = it
                                val num = it.toDoubleOrNull() ?: 1.0
                                viewModel.updateCalculator(haircutPct = num)
                            },
                            label = { Text("Haircut (%)", fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                            modifier = Modifier.weight(1f).testTag("calc_input_haircut"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalSky,
                                unfocusedBorderColor = TerminalBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = inputRepoRatePct,
                            onValueChange = {
                                inputRepoRatePct = it
                                val num = it.toDoubleOrNull() ?: 4.0
                                viewModel.updateCalculator(repoRatePct = num)
                            },
                            label = { Text("Rate (%)", fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                            modifier = Modifier.weight(1f).testTag("calc_input_rate"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalSky,
                                unfocusedBorderColor = TerminalBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = inputTermDays,
                            onValueChange = {
                                inputTermDays = it
                                val num = it.toIntOrNull() ?: 1
                                viewModel.updateCalculator(termDays = num)
                            },
                            label = { Text("Days", fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                            modifier = Modifier.weight(0.7f).testTag("calc_input_term"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalSky,
                                unfocusedBorderColor = TerminalBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                    }

                    // Calculation Results Grid
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(TerminalSurface)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        CalcRow(label = "Collateral Market Value", value = "$${String.format("%.2fB", state.calcResult.collateralMarketValue / 1e9)}")
                        CalcRow(label = "Haircut Impact (-${state.calcResult.haircutPct}%)", value = "-$${String.format("%.2fM", state.calcResult.haircutImpactAmount / 1e6)}", color = TerminalAmber)
                        CalcRow(label = "Eligible Collateral Value", value = "$${String.format("%.2fB", state.calcResult.eligibleCollateralValue / 1e9)}", color = TerminalSky, isBold = true)
                        CalcRow(label = "Cash Advanced (Opening Principal)", value = "$${String.format("%.2fB", state.calcResult.cashAdvanced / 1e9)}", isBold = true)
                        CalcRow(label = "Repo Interest [Cash × Rate × (T/360)]", value = "$${String.format("%.2f", state.calcResult.repoInterestAmount)} ($${String.format("%.3fM", state.calcResult.repoInterestAmount / 1e6)})", color = TerminalEmerald)
                        CalcRow(label = "Repurchase Price (Maturity Cash)", value = "$${String.format("%.2fB", state.calcResult.repurchasePrice / 1e9)}", color = TextHighlight, isBold = true)
                        CalcRow(label = "Effective Annualized Funding Cost", value = "${String.format("%.4f", state.calcResult.effectiveFundingCostPct)}%")
                        CalcRow(label = "Collateral Coverage Ratio", value = "${String.format("%.2f", state.calcResult.collateralCoverageRatio * 100)}%")
                    }
                }
            }
        }

        // Blotter Filter Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == null,
                    onClick = { selectedFilter = null },
                    label = { Text("ALL (${state.repoTransactions.size})", fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
                )
                TransactionType.values().forEach { type ->
                    val count = state.repoTransactions.count { it.transactionType == type }
                    FilterChip(
                        selected = selectedFilter == type,
                        onClick = { selectedFilter = type },
                        label = { Text("${type.code} ($count)", fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
                    )
                }
            }
        }

        // Active Repo Transactions
        val filteredTx = if (selectedFilter == null) state.repoTransactions else state.repoTransactions.filter { it.transactionType == selectedFilter }
        items(filteredTx) { tx ->
            RepoTransactionCard(
                tx = tx,
                onClick = { selectedTransaction = tx }
            )
        }
    }
}

@Composable
private fun CalcRow(
    label: String,
    value: String,
    color: Color = TextPrimary,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = color, fontSize = 10.5.sp, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun RepoTransactionCard(
    tx: RepoTransaction,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCard)
            .border(1.dp, if (tx.status == SettlementStatus.FAILED) TerminalCrimson else TerminalBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = tx.repoId, color = TerminalSky, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(TerminalCardElevated)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(text = tx.transactionType.code, color = TextHighlight, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }

                StatusPill(status = tx.status)
            }

            Text(text = tx.counterpartyName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "CASH ADVANCED", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                    Text(text = "$${String.format("%.2fB", tx.cashAmount / 1e9)}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Column {
                    Text(text = "COLLATERAL VALUE", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                    Text(text = "$${String.format("%.2fB", tx.collateralMarketValue / 1e9)}", color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
                Column {
                    Text(text = "HAIRCUT", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                    Text(text = "${tx.haircutPct}%", color = TerminalAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Column {
                    Text(text = "RATE", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                    Text(text = "${String.format("%.2f", tx.repoRatePct)}%", color = TerminalEmerald, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "CUSIP: ${tx.cusip} (${tx.collateralType.category})", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = "CLEARING: ${tx.clearingMethod.displayName}", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }

            if (tx.failReason != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalCrimson.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(text = "FAIL REASON: ${tx.failReason}", color = TerminalCrimson, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun StatusPill(status: SettlementStatus) {
    val (color, bg) = when (status) {
        SettlementStatus.SETTLED, SettlementStatus.ACTIVE -> TerminalEmerald to TerminalEmerald.copy(alpha = 0.2f)
        SettlementStatus.FAILED -> TerminalCrimson to TerminalCrimson.copy(alpha = 0.2f)
        SettlementStatus.MATCHED, SettlementStatus.VALIDATED -> TerminalSky to TerminalSky.copy(alpha = 0.2f)
        else -> TerminalAmber to TerminalAmber.copy(alpha = 0.2f)
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .border(1.dp, color, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text = status.displayName.uppercase(), color = color, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
