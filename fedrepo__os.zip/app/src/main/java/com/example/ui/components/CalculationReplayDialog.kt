package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.model.AuditCalculation
import com.example.ui.theme.*

@Composable
fun CalculationReplayDialog(
    auditTrail: List<AuditCalculation>,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .testTag("calculation_replay_dialog_box")
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(TerminalSurface)
                .border(1.dp, TerminalBorder, RoundedCornerShape(12.dp))
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DETERMINISTIC CALCULATION AUDIT TRAIL",
                        color = TerminalSky,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "${auditTrail.size} ENTRIES",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(auditTrail) { audit ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(TerminalCard)
                                .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                                .padding(10.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = audit.calculationId, color = TerminalSky, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Text(text = audit.timestamp, color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text(text = "MODEL: ${audit.modelName}", color = TextHighlight, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                Text(text = "INPUT: ${audit.inputsSummary}", color = TextSecondary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                Text(text = "OUTPUT: ${audit.resultSummary}", color = TerminalEmerald, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "HASH: ${audit.verificationHash}", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                                    Text(text = "REPLAY: [DETERMINISTIC OK]", color = TerminalEmerald, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalCardElevated)
                ) {
                    Text("CLOSE AUDIT LOG", color = TextPrimary, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
