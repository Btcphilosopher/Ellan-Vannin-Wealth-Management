package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.MoneyMarketRates
import com.example.domain.model.PolicyParameters
import com.example.ui.theme.*

@Composable
fun CorridorVisualizer(
    rates: MoneyMarketRates,
    policy: PolicyParameters,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag("money_market_corridor_box")
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCard)
            .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "MONEY-MARKET POLICY CORRIDOR",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "TARGET [${String.format("%.2f", policy.targetRangeLow)}% – ${String.format("%.2f", policy.targetRangeHigh)}%]",
                        color = TerminalSky,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "DISPERSION 30 bps",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Corridor Ladder Elements
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // 1. Standing Repo Facility (Ceiling)
                CorridorTierRow(
                    tierName = "SRP CEILING (STANDING REPO)",
                    rate = rates.srpRate,
                    spreadBps = rates.sofrMinusSrpBps,
                    color = CorridorCeiling,
                    description = "Fed liquidity backstop for Primary Dealers & Banks",
                    isCeiling = true
                )

                // 2. SOFR (Secured Overnight Financing Rate)
                CorridorTierRow(
                    tierName = "SOFR (MARKET CLEARING REPO)",
                    rate = rates.sofr,
                    spreadBps = rates.sofrMinusIorbBps,
                    color = CorridorClearing,
                    description = "Broad Treasury-backed private repo benchmark ($${rates.sofrVolumeBln.toInt()}B volume)",
                    isHighlight = true
                )

                // 3. EFFR (Effective Federal Funds Rate)
                CorridorTierRow(
                    tierName = "EFFR (FED FUNDS)",
                    rate = rates.effr,
                    spreadBps = rates.effrMinusIorbBps,
                    color = CorridorBenchmark,
                    description = "Unsecured interbank overnight lending rate"
                )

                // 4. IORB (Interest on Reserve Balances)
                CorridorTierRow(
                    tierName = "IORB (RESERVE ANCHOR)",
                    rate = rates.iorb,
                    spreadBps = 0.0,
                    color = CorridorDeposit,
                    description = "Administered benchmark rate paid on bank reserve balances"
                )

                // 5. ON RRP (Overnight Reverse Repo Floor)
                CorridorTierRow(
                    tierName = "ON RRP FLOOR (REVERSE REPO)",
                    rate = rates.onRrpRate,
                    spreadBps = rates.sofrMinusOnRrpBps,
                    color = CorridorFloor,
                    description = "Liquidity absorption floor for MMFs & GSEs ($160B limit)",
                    isFloor = true
                )
            }

            // Key Spread Metrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SpreadPill(label = "SOFR - IORB", bps = rates.sofrMinusIorbBps)
                SpreadPill(label = "SOFR - ON RRP", bps = rates.sofrMinusOnRrpBps)
                SpreadPill(label = "SOFR - SRP", bps = rates.sofrMinusSrpBps)
                SpreadPill(label = "EFFR - IORB", bps = rates.effrMinusIorbBps)
            }
        }
    }
}

@Composable
private fun CorridorTierRow(
    tierName: String,
    rate: Double,
    spreadBps: Double,
    color: Color,
    description: String,
    isCeiling: Boolean = false,
    isFloor: Boolean = false,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(if (isHighlight) color.copy(alpha = 0.15f) else Color.Transparent)
            .border(if (isHighlight) 1.dp else 0.dp, if (isHighlight) color else Color.Transparent, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(24.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color)
            )
            Column {
                Text(
                    text = tierName,
                    color = if (isHighlight) TextPrimary else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = description,
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (spreadBps != 0.0) {
                Text(
                    text = "${if (spreadBps > 0) "+" else ""}${String.format("%.1f", spreadBps)} bp",
                    color = if (spreadBps > 0) TerminalEmerald else TerminalAmber,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(
                text = "${String.format("%.2f", rate)}%",
                color = color,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun SpreadPill(label: String, bps: Double) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = label,
                color = TextSecondary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "${if (bps > 0) "+" else ""}${String.format("%.0f", bps)}bp",
                color = if (bps >= 0) TerminalSky else TerminalAmber,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
