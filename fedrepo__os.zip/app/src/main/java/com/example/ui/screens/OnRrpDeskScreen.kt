package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.CounterpartyType
import com.example.ui.components.MetricCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun OnRrpDeskScreen(
    state: TerminalUiState,
    viewModel: FedRepoViewModel,
    modifier: Modifier = Modifier
) {
    val executionResult = state.onRrpExecutionResult

    LazyColumn(
        modifier = modifier
            .testTag("on_rrp_desk_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "OVERNIGHT REVERSE REPO FACILITY (ON RRP)",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "ADMINISTERED FLOOR FOR NON-BANK MONEY-MARKET CASH",
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CorridorFloor.copy(alpha = 0.2f))
                        .border(1.dp, CorridorFloor, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "OFFERING: ${String.format("%.2f", state.policyParameters.onRrpRate)}%",
                        color = CorridorFloor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Key Facility Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    label = "CURRENT BALANCE",
                    value = "$${String.format("%.1f", state.balanceSheet.onRrpBln)}B",
                    subValue = "Fed Liability",
                    accentColor = CorridorFloor,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    label = "DAILY CP LIMIT",
                    value = "$${state.policyParameters.onRrpCounterpartyLimitBln.toInt()}B",
                    subValue = "Per Counterparty",
                    accentColor = TerminalSky,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    label = "OFFERING RATE",
                    value = "${String.format("%.2f", state.policyParameters.onRrpRate)}%",
                    subValue = "Policy Floor",
                    accentColor = CorridorFloor,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Facility Action Box
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "SIMULATE DAILY ON RRP OPERATIONS",
                        color = TerminalSky,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Text(
                        text = "The Federal Reserve sells Treasury securities from SOMA to eligible MMFs, GSEs, Primary Dealers, and Banks, absorbing cash from the financial system and repurchasing securities the following business day.",
                        color = TextHighlight,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Default
                    )

                    Button(
                        onClick = { viewModel.runOnRrpOperation() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("run_on_rrp_operation_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = CorridorFloor)
                    ) {
                        Text(
                            text = "EXECUTE DAILY ON RRP OPERATION CYCLE",
                            color = TerminalBackground,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Execution Results Breakdown
        if (executionResult != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(TerminalSurface)
                        .border(1.dp, TerminalEmerald, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "OPERATION RESULTS SUMMARY", color = TerminalEmerald, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(text = "TOTAL: $${String.format("%.2f", executionResult.totalAcceptedBln)}B", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            CatCol(label = "MMFs (80%)", amount = executionResult.mmfTotalBln)
                            CatCol(label = "GSEs (15%)", amount = executionResult.gseTotalBln)
                            CatCol(label = "Primary Dealers", amount = executionResult.primaryDealerTotalBln)
                            CatCol(label = "Banks", amount = executionResult.bankTotalBln)
                        }

                        Text(
                            text = "SOMA Treasury Collateral Allocated: $${String.format("%.2f", executionResult.treasuryCollateralAllocatedBln)}B | Reserve Balance Drain: -$${String.format("%.2f", executionResult.reserveDrainImpactBln)}B",
                            color = TextSecondary,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            item {
                Text(
                    text = "COUNTERPARTY ALLOTMENT BLOTTER",
                    color = TextPrimary,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            items(executionResult.submissions) { sub ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalCard)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(text = sub.counterpartyName, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
                            Text(text = "Type: ${sub.counterpartyType.displayName} | Allocated CUSIP: ${sub.allocatedTreasuryCusip}", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "Requested: $${String.format("%.1f", sub.requestedAmountBln)}B -> Accepted: $${String.format("%.1f", sub.acceptedAmountBln)}B @ ${sub.offeringRatePct}%", color = TerminalEmerald, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalCardElevated)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = sub.status, color = TextHighlight, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CatCol(label: String, amount: Double) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
        Text(text = "$${String.format("%.1f", amount)}B", color = TextHighlight, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
