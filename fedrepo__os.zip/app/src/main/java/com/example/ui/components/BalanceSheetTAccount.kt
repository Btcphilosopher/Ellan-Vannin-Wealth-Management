package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.FedBalanceSheet
import com.example.ui.theme.*

@Composable
fun BalanceSheetTAccount(
    sheet: FedBalanceSheet,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .testTag("fed_balance_sheet_box")
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCard)
            .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Header with Invariant Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "FEDERAL RESERVE BALANCE SHEET DIGITAL TWIN",
                        color = TextPrimary,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Balance Sheet Invariant Checker Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (sheet.isReconciled) TerminalEmerald.copy(alpha = 0.2f) else TerminalCrimson.copy(alpha = 0.2f))
                        .border(1.dp, if (sheet.isReconciled) TerminalEmerald else TerminalCrimson, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (sheet.isReconciled) "ASSETS == LIAB + CAPITAL [RECONCILED]" else "DISCREPANCY: $${String.format("%.2f", sheet.discrepancyBln)}B",
                        color = if (sheet.isReconciled) TerminalEmerald else TerminalCrimson,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // T-Account Two Column Layout
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Left Pane: ASSETS
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = "ASSETS ($${String.format("%.1f", sheet.totalAssetsBln)}B)",
                        color = TerminalSky,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    TAccountItem(label = "U.S. Treasuries (SOMA)", amountBln = sheet.treasuriesBln)
                    TAccountItem(label = "Agency MBS (SOMA)", amountBln = sheet.agencyMbsBln)
                    TAccountItem(label = "Standing Repo (SRP)", amountBln = sheet.srpRepoBln, isHighlight = true)
                    TAccountItem(label = "Discount Window / Loans", amountBln = sheet.loansBln)
                    TAccountItem(label = "Other Fed Assets", amountBln = sheet.otherAssetsBln)
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(TerminalBorder))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "TOTAL ASSETS", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text(text = "$${String.format("%.1f", sheet.totalAssetsBln)}B", color = TerminalSky, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }

                // Vertical Divider
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .fillMaxHeight()
                        .background(TerminalBorder)
                )

                // Right Pane: LIABILITIES + CAPITAL
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = "LIABILITIES & CAPITAL ($${String.format("%.1f", sheet.totalLiabilitiesAndCapitalBln)}B)",
                        color = TerminalAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    TAccountItem(label = "Reserve Balances (Banks)", amountBln = sheet.reserveBalancesBln, isHighlight = true)
                    TAccountItem(label = "Currency in Circulation", amountBln = sheet.currencyInCirculationBln)
                    TAccountItem(label = "ON RRP (Reverse Repo)", amountBln = sheet.onRrpBln, isHighlight = true)
                    TAccountItem(label = "Treasury General Acc (TGA)", amountBln = sheet.tgaAccountBln)
                    TAccountItem(label = "Other Liabilities", amountBln = sheet.otherLiabilitiesBln)
                    TAccountItem(label = "Capital & Surplus", amountBln = sheet.capitalBln)

                    Spacer(modifier = Modifier.height(4.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(TerminalBorder))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "TOTAL LIAB + CAP", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text(text = "$${String.format("%.1f", sheet.totalLiabilitiesAndCapitalBln)}B", color = TerminalAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
private fun TAccountItem(
    label: String,
    amountBln: Double,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = if (isHighlight) TextHighlight else TextSecondary,
            fontSize = 9.5.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "$${String.format("%.1f", amountBln)}B",
            color = if (isHighlight) TerminalEmerald else TextPrimary,
            fontSize = 9.5.sp,
            fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace
        )
    }
}
