package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FEDREPO//OS Institutional Terminal Color Palette
val TerminalBackground = Color(0xFF0A0E17)     // Deep Graphite Navy
val TerminalSurface = Color(0xFF0F172A)        // Slate 900
val TerminalCard = Color(0xFF1E293B)           // Slate 800
val TerminalCardElevated = Color(0xFF273549)   // Elevated container
val TerminalBorder = Color(0xFF334155)         // Crisp border

val TerminalCyan = Color(0xFF22D3EE)           // Cyan accent
val TerminalSky = Color(0xFF38BDF8)            // Primary sky blue
val TerminalEmerald = Color(0xFF10B981)        // Settled / normal / verified
val TerminalAmber = Color(0xFFF59E0B)          // Specials / warning / margin alert
val TerminalCrimson = Color(0xFFEF4444)        // Risk shock / failure / limit breach
val TerminalPurple = Color(0xFFA855F7)         // SOMA / Fed Balance Sheet

val TextPrimary = Color(0xFFF8FAFC)            // Crisp warm white
val TextSecondary = Color(0xFF94A3B8)          // Slate secondary
val TextMuted = Color(0xFF64748B)              // Slate muted
val TextHighlight = Color(0xFFE2E8F0)          // High contrast white-slate

val CorridorCeiling = Color(0xFFEF4444)        // SRP Ceiling
val CorridorClearing = Color(0xFF38BDF8)       // SOFR
val CorridorBenchmark = Color(0xFF22D3EE)      // EFFR
val CorridorDeposit = Color(0xFF10B981)        // IORB
val CorridorFloor = Color(0xFFF59E0B)          // ON RRP Floor
