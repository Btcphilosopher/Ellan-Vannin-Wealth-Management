package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.model.ModelCard
import com.example.ui.theme.*

@Composable
fun ModelCardDialog(
    modelCard: ModelCard,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .testTag("model_card_dialog_box")
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(TerminalSurface)
                .border(1.dp, TerminalBorder, RoundedCornerShape(12.dp))
                .padding(18.dp)
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MODEL GOVERNANCE CARD",
                        color = TerminalSky,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(TerminalEmerald.copy(alpha = 0.2f))
                            .border(1.dp, TerminalEmerald, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = modelCard.validationStatus,
                            color = TerminalEmerald,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Text(
                    text = "${modelCard.name} [${modelCard.version}]",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Text(text = "MODEL ID: ${modelCard.modelId} | AUDITED CALCULATIONS: ${modelCard.calculationCount}", color = TextSecondary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)

                DetailSection(title = "PURPOSE & SCOPE", content = modelCard.purpose)
                DetailSection(title = "MATHEMATICAL METHODOLOGY", content = modelCard.methodology)
                DetailSection(title = "CORE ASSUMPTIONS", content = modelCard.assumptions)
                DetailSection(title = "SYSTEMIC LIMITATIONS", content = modelCard.limitations)
                DetailSection(title = "GOVERNANCE & AUTHOR", content = modelCard.authorGroup)

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dismiss_model_card_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalCardElevated)
                ) {
                    Text("CLOSE GOVERNANCE CARD", color = TextPrimary, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun DetailSection(title: String, content: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(text = title, color = TerminalSky, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(text = content, color = TextHighlight, fontSize = 11.sp, fontFamily = FontFamily.Default)
    }
}
