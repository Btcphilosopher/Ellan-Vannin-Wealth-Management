package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.engine.RepoEconomicsEngine
import com.example.ui.theme.*
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun CollateralOsScreen(
    state: TerminalUiState,
    viewModel: FedRepoViewModel,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var selectedInstitutionId by remember { mutableStateOf("CP-PD-001") }
    var swapResultText by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .testTag("collateral_os_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "COLLATERAL OS // TREASURY & AGENCY INVENTORY",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "FED ELIGIBILITY, HAIRCUT VALUATION & DIGITAL TWIN ENGINE",
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalCardElevated)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${state.collateralSecurities.size} CUSIPs",
                        color = TerminalSky,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Haircut Shock Simulator
        item {
            val shockResult = state.haircutShockResult
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "HAIRCUT STRESS & CAPACITY SENSITIVITY ENGINE",
                            color = TerminalSky,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "+${state.haircutShockBps.toInt()} BPS SHIFT",
                            color = TerminalAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Shock Preset Selector Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val presets = listOf(25.0, 50.0, 100.0, 150.0)
                        presets.forEach { bps ->
                            val isSel = state.haircutShockBps == bps
                            Button(
                                onClick = { viewModel.updateHaircutShock(bps) },
                                modifier = Modifier.weight(1f).testTag("haircut_preset_${bps.toInt()}"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSel) TerminalSky else TerminalSurface
                                ),
                                contentPadding = PaddingValues(vertical = 4.dp)
                            ) {
                                Text(
                                    text = "+${bps.toInt()} bp",
                                    color = if (isSel) TerminalBackground else TextPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    // Haircut Shock Impact Metrics
                    if (shockResult != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(TerminalSurface)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "CAPACITY REDUCTION", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                                Text(text = "-$${String.format("%.2fB", shockResult.systemCapacityLossBln)}", color = TerminalCrimson, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                            Column {
                                Text(text = "TOTAL MARGIN CALLS", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                                Text(text = "$${String.format("%.2fB", shockResult.totalMarginCallsBln)}", color = TerminalAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                            Column {
                                Text(text = "STRESSED CAPACITY", color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                                Text(text = "$${String.format("%.1fB", shockResult.stressedTotalCapacityBln)}", color = TextHighlight, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // Institution Collateral Digital Twin
        item {
            val institution = state.counterparties.find { it.id == selectedInstitutionId } ?: state.counterparties.first()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "INSTITUTION COLLATERAL DIGITAL TWIN",
                            color = TerminalSky,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        // Button to switch institution
                        Button(
                            onClick = {
                                val idx = state.counterparties.indexOfFirst { it.id == selectedInstitutionId }
                                val next = (idx + 1) % state.counterparties.size
                                selectedInstitutionId = state.counterparties[next].id
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalCardElevated),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("CYCLE FIRM", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Text(
                        text = "${institution.name} [${institution.type.displayName}]",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TwinStat(label = "Treasury Inv", value = "$${String.format("%.1fB", institution.treasuryInventoryBillions)}")
                        TwinStat(label = "Agency Inv", value = "$${String.format("%.1fB", institution.agencyInventoryBillions)}")
                        TwinStat(label = "Agency MBS", value = "$${String.format("%.1fB", institution.mbsInventoryBillions)}")
                        TwinStat(label = "Total Collateral", value = "$${String.format("%.1fB", institution.totalCollateralBillions)}", isHighlight = true)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TwinStat(label = "Encumbered", value = "$${String.format("%.1fB", institution.collateralEncumberedBillions)}", color = TerminalAmber)
                        TwinStat(label = "Free Collateral", value = "$${String.format("%.1fB", institution.freeCollateralBillions)}", color = TerminalEmerald)
                        TwinStat(label = "Repo Capacity", value = "$${String.format("%.1fB", institution.repoCapacityBillions)}")
                        TwinStat(label = "Utilization", value = "${String.format("%.1f", institution.fundingUtilizationPct)}%", color = TerminalSky)
                    }
                }
            }
        }

        // Collateral Substitution / Upgrade Simulator
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalSky.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "COLLATERAL SUBSTITUTION & UPGRADE WORKBENCH",
                        color = TerminalSky,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Text(
                        text = "Simulate replacing $10B Agency MBS (3% haircut) with $10B U.S. Treasury Bills (0.5% haircut) in an active tri-party repo trade:",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Default
                    )

                    Button(
                        onClick = {
                            val (delta, summary) = RepoEconomicsEngine.evaluateCollateralSwap(
                                outgoingValue = 10_000_000_000.0,
                                outgoingHaircut = 3.0,
                                incomingValue = 10_000_000_000.0,
                                incomingHaircut = 0.5,
                                cashAdvanced = 9_700_000_000.0
                            )
                            swapResultText = summary
                        },
                        modifier = Modifier.fillMaxWidth().testTag("simulate_collateral_swap_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalSky)
                    ) {
                        Text("EVALUATE MBS -> TREASURY COLLATERAL UPGRADE", color = TerminalBackground, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    if (swapResultText != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalEmerald.copy(alpha = 0.15f))
                                .padding(8.dp)
                        ) {
                            Text(text = swapResultText!!, color = TerminalEmerald, fontSize = 10.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Securities Inventory Filter
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { selectedCategory = null },
                    label = { Text("ALL (${state.collateralSecurities.size})", fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
                )
                listOf("Treasury", "Agency", "Agency MBS").forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
                    )
                }
            }
        }

        // Securities List
        val filteredSec = if (selectedCategory == null) state.collateralSecurities else state.collateralSecurities.filter { it.assetType.category == selectedCategory }
        items(filteredSec) { sec ->
            CollateralSecurityCard(sec = sec)
        }
    }
}

@Composable
private fun TwinStat(label: String, value: String, color: Color = TextPrimary, isHighlight: Boolean = false) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = color, fontSize = 11.5.sp, fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.Normal, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun CollateralSecurityCard(sec: CollateralSecurity) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalCard)
            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = sec.cusip, color = TerminalSky, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(TerminalCardElevated)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(text = sec.assetType.category, color = TextHighlight, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                Text(text = "Haircut: ${sec.haircutPct}%", color = TerminalAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }

            Text(text = sec.securityName, color = TextPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Outstanding: $${sec.outstandingBillions.toInt()}B", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = "Price: ${sec.cleanPrice}", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = "Liquidity: ${sec.liquidityScore}/100", color = TerminalEmerald, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                if (sec.specialnessBps > 0) {
                    Text(text = "SPECIAL: +${sec.specialnessBps.toInt()}bp", color = TerminalAmber, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
