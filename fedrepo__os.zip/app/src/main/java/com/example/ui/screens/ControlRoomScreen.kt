package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.MoneyMarketRates
import com.example.domain.model.PolicyParameters
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalTab
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun ControlRoomScreen(
    state: TerminalUiState,
    onNavigateToTab: (TerminalTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .testTag("control_room_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MONEY-MARKET CONTROL ROOM",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
            )
            Text(
                text = "EFF. DATE: ${state.policyParameters.effectiveDate.uppercase()}",
                color = TextSecondary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        // Top Metrics Grid: Key Interest Rates & System Quantities
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    label = "SOFR (CLEARING)",
                    value = "${String.format("%.2f", state.rates.sofr)}%",
                    subValue = "+${String.format("%.0f", state.rates.sofrMinusIorbBps)}bp vs IORB",
                    accentColor = CorridorClearing,
                    tag = "metric_sofr",
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab(TerminalTab.RATES_SOFR) }
                )
                MetricCard(
                    label = "EFFR (FED FUNDS)",
                    value = "${String.format("%.2f", state.rates.effr)}%",
                    subValue = "${String.format("%.0f", state.rates.effrMinusIorbBps)}bp vs IORB",
                    accentColor = CorridorBenchmark,
                    tag = "metric_effr",
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab(TerminalTab.RATES_SOFR) }
                )
                MetricCard(
                    label = "IORB (DEPOSIT)",
                    value = "${String.format("%.2f", state.rates.iorb)}%",
                    subValue = "Target 3.75-4.00%",
                    accentColor = CorridorDeposit,
                    tag = "metric_iorb",
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab(TerminalTab.RATES_SOFR) }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    label = "STANDING REPO (SRP)",
                    value = "${String.format("%.2f", state.rates.srpRate)}%",
                    subValue = "$${String.format("%.1f", state.balanceSheet.srpRepoBln)}B Drawn",
                    accentColor = CorridorCeiling,
                    tag = "metric_srp",
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab(TerminalTab.SRP_FACILITY) }
                )
                MetricCard(
                    label = "ON RRP FLOOR",
                    value = "${String.format("%.2f", state.rates.onRrpRate)}%",
                    subValue = "$${String.format("%.1f", state.balanceSheet.onRrpBln)}B Bal",
                    accentColor = CorridorFloor,
                    tag = "metric_on_rrp",
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab(TerminalTab.ON_RRP_FACILITY) }
                )
                MetricCard(
                    label = "RESERVE BALANCES",
                    value = "$${String.format("%.2f", state.balanceSheet.reserveBalancesBln / 1000.0)}T",
                    subValue = "Ample Liquidity",
                    accentColor = TerminalSky,
                    tag = "metric_reserves",
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab(TerminalTab.RESERVES_SOMA) }
                )
            }
        }

        // 1. Dynamic Money Market Corridor
        CorridorVisualizer(
            rates = state.rates,
            policy = state.policyParameters,
            modifier = Modifier.fillMaxWidth()
        )

        // 2. Dollar Financial System Plumbing Flow Architecture
        DollarPlumbingFlow(
            srpTotalBln = state.balanceSheet.srpRepoBln,
            onRrpTotalBln = state.balanceSheet.onRrpBln,
            totalRepoBln = state.rates.sofrVolumeBln,
            reservesBln = state.balanceSheet.reserveBalancesBln,
            modifier = Modifier.fillMaxWidth()
        )

        // 3. Federal Reserve Balance Sheet T-Account Digital Twin
        BalanceSheetTAccount(
            sheet = state.balanceSheet,
            modifier = Modifier.fillMaxWidth()
        )

        // Footer Tagline
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "FEDREPO//OS — CASH. COLLATERAL. RATES. RESERVES. LIQUIDITY.",
                    color = TextSecondary,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "MODEL THE FUNDING SYSTEM.",
                    color = TerminalSky,
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}
