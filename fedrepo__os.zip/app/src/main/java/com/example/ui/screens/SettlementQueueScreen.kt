package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.SettlementException
import com.example.engine.TripartySettlementEngine
import com.example.ui.theme.*
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun SettlementQueueScreen(
    state: TerminalUiState,
    viewModel: FedRepoViewModel,
    modifier: Modifier = Modifier
) {
    val failedTx = state.repoTransactions.find { it.status == com.example.domain.model.SettlementStatus.FAILED }
    val activeTx = state.repoTransactions.firstOrNull()
    val workflow = activeTx?.let { TripartySettlementEngine.buildSettlementWorkflow(it) }

    LazyColumn(
        modifier = modifier
            .testTag("settlement_queue_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TRIPARTY SETTLEMENT & FAIL MANAGEMENT DESK",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "BNY MELLON / FEDWIRE DVP SETTLEMENT PIPELINE",
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (state.settlementExceptions.isNotEmpty()) TerminalCrimson.copy(alpha = 0.2f) else TerminalEmerald.copy(alpha = 0.2f))
                        .border(1.dp, if (state.settlementExceptions.isNotEmpty()) TerminalCrimson else TerminalEmerald, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (state.settlementExceptions.isNotEmpty()) "${state.settlementExceptions.size} EXCEPTIONS" else "ALL MATCHED",
                        color = if (state.settlementExceptions.isNotEmpty()) TerminalCrimson else TerminalEmerald,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Operational Fail Queue & Resolution Workbench
        if (state.settlementExceptions.isNotEmpty()) {
            item {
                Text(
                    text = "OPERATIONAL EXCEPTION QUEUE (ACTIVE FAILS)",
                    color = TerminalCrimson,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            items(state.settlementExceptions) { exc ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(TerminalCard)
                        .border(1.dp, TerminalCrimson, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "${exc.exceptionId} | ${exc.counterpartyName}", color = TextPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(TerminalCrimson.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(text = "SEVERITY: ${exc.severity}", color = TerminalCrimson, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Text(text = "EXCEPTION TYPE: ${exc.exceptionType}", color = TerminalAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text(text = exc.details, color = TextHighlight, fontSize = 10.5.sp, fontFamily = FontFamily.Default)
                        Text(text = "SUGGESTED ACTION: ${exc.suggestedAction}", color = TerminalSky, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)

                        Button(
                            onClick = { viewModel.resolveException(exc) },
                            modifier = Modifier.fillMaxWidth().testTag("resolve_exception_${exc.exceptionId}"),
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalEmerald)
                        ) {
                            Text("RESOLVE VIA COLLATERAL SUBSTITUTION & DVP RETRY", color = TerminalBackground, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Triparty Lifecycle Pipeline Diagram
        if (workflow != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(TerminalCard)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "TRIPARTY SETTLEMENT LIFECYCLE AUDIT TRAIL",
                            color = TerminalSky,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = "Transaction: ${workflow.transactionId} (${workflow.counterpartyName}) | Cash: $${String.format("%.2fB", workflow.cashAmountBln)} | Agent: ${workflow.tripartyAgent}",
                            color = TextSecondary,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        workflow.steps.forEach { step ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(TerminalSurface)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                    Text(text = "${step.stepNumber}.", color = TerminalSky, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Column {
                                        Text(text = step.title, color = TextPrimary, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        Text(text = step.description, color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Default)
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = step.status, color = if (step.status == "COMPLETED" || step.status == "ACTIVE") TerminalEmerald else TerminalAmber, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    Text(text = step.timestamp, color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
