package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Counterparty
import com.example.domain.model.CounterpartyType
import com.example.ui.theme.*
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun CounterpartiesScreen(
    state: TerminalUiState,
    viewModel: FedRepoViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTypeFilter by remember { mutableStateOf<CounterpartyType?>(null) }

    LazyColumn(
        modifier = modifier
            .testTag("counterparties_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "COUNTERPARTY REGISTRY & ELIGIBILITY DATABASE",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "FED STANDING REPO & ON RRP MASTER AGREEMENT PARTICIPANTS",
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalCardElevated)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${state.counterparties.size} INSTITUTIONS",
                        color = TerminalSky,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Type Filter Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedTypeFilter == null,
                    onClick = { selectedTypeFilter = null },
                    label = { Text("ALL (${state.counterparties.size})", fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
                )
                CounterpartyType.values().forEach { type ->
                    val count = state.counterparties.count { it.type == type }
                    if (count > 0) {
                        FilterChip(
                            selected = selectedTypeFilter == type,
                            onClick = { selectedTypeFilter = type },
                            label = { Text("${type.displayName.take(15)} ($count)", fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
                        )
                    }
                }
            }
        }

        // Counterparties List
        val filteredList = if (selectedTypeFilter == null) state.counterparties else state.counterparties.filter { it.type == selectedTypeFilter }
        items(filteredList) { cp ->
            CounterpartyItemCard(cp = cp)
        }
    }
}

@Composable
private fun CounterpartyItemCard(cp: Counterparty) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCard)
            .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = cp.id, color = TerminalSky, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(text = cp.name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(TerminalCardElevated)
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(text = cp.type.displayName, color = TextHighlight, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                }
            }

            // Eligibility Badges
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                EligibilityBadge(label = "SRP (STANDING REPO)", isEligible = cp.srpEligible)
                EligibilityBadge(label = "ON RRP FACILITY", isEligible = cp.onRrpEligible)
                Text(text = "Risk Score: ${cp.riskScore}/100", color = if (cp.riskScore < 15) TerminalEmerald else TerminalAmber, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }

            // Inventory & Capacity Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TerminalSurface)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CpStat(label = "CAPITAL", value = "$${cp.capitalBillions.toInt()}B")
                CpStat(label = "TREASURY INV", value = "$${cp.treasuryInventoryBillions.toInt()}B")
                CpStat(label = "FREE COLLATERAL", value = "$${String.format("%.1f", cp.freeCollateralBillions)}B", color = TerminalEmerald)
                CpStat(label = "REPO CAPACITY", value = "$${cp.repoCapacityBillions.toInt()}B")
                CpStat(label = "UTILIZATION", value = "${String.format("%.0f", cp.fundingUtilizationPct)}%", color = TerminalSky)
            }
        }
    }
}

@Composable
private fun EligibilityBadge(label: String, isEligible: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(if (isEligible) TerminalEmerald.copy(alpha = 0.2f) else TerminalBorder.copy(alpha = 0.3f))
            .padding(horizontal = 4.dp, vertical = 1.dp)
    ) {
        Text(
            text = if (isEligible) "✓ $label" else "✕ $label",
            color = if (isEligible) TerminalEmerald else TextMuted,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun CpStat(label: String, value: String, color: androidx.compose.ui.graphics.Color = TextPrimary) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = color, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
