package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun SrpFacilityScreen(
    state: TerminalUiState,
    viewModel: FedRepoViewModel,
    modifier: Modifier = Modifier
) {
    var amountInput by remember { mutableStateOf("15.0") }
    var rateInput by remember { mutableStateOf("4.00") }

    LazyColumn(
        modifier = modifier
            .testTag("srp_facility_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Facility Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "STANDING REPO FACILITY (SRP) TERMINAL",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "FEDTRADE PLUS OPERATIONS ARCHITECTURE (NY FED REFERENCE)",
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CorridorCeiling.copy(alpha = 0.2f))
                        .border(1.dp, CorridorCeiling, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "RATE: ${String.format("%.2f", state.policyParameters.srpRate)}%",
                        color = CorridorCeiling,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Operation Schedule & Configuration Matrix
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "OPERATIONAL SPECIFICATIONS (CONFIGURABLE POLICY OBJECT)",
                        color = TerminalSky,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SpecCol(title = "MORNING OP", value = state.policyParameters.morningSrpWindow)
                        SpecCol(title = "AFTERNOON OP", value = state.policyParameters.afternoonSrpWindow)
                        SpecCol(title = "SETTLEMENT", value = "Same-Day (T+0) Triparty")
                        SpecCol(title = "AGGREGATE CAP", value = "$${state.policyParameters.srpAggregateLimitBln.toInt()}B")
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SpecCol(title = "PROPOSITION CAP", value = "$50B / Counterparty")
                        SpecCol(title = "MIN SIZE", value = "$1,000,000")
                        SpecCol(title = "COLLATERAL", value = "Treasury, Agency, MBS")
                        SpecCol(title = "ALLOTMENT MODE", value = state.srpOperationMode.name)
                    }
                }
            }
        }

        // Counterparty Submission Terminal (FedTrade Plus Window)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalSky.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "COUNTERPARTY PROPOSITION WINDOW (FEDTRADE PLUS)",
                            color = TerminalSky,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "SIMULATOR ACTIVE",
                            color = TerminalEmerald,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Counterparty Selector Dropdown / Row
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "SUBMITTING COUNTERPARTY:", color = TextSecondary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                        val primaryDealers = state.counterparties.filter { it.srpEligible }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(TerminalSurface)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val activeCp = primaryDealers.find { it.id == state.srpSelectedCounterpartyId } ?: primaryDealers.first()
                            Column {
                                Text(text = activeCp.name, color = TextPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(text = "Type: ${activeCp.type.displayName} | Free Collateral: $${String.format("%.1f", activeCp.freeCollateralBillions)}B", color = TextSecondary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                            }

                            // Cycle through dealers button
                            Button(
                                onClick = {
                                    val idx = primaryDealers.indexOfFirst { it.id == state.srpSelectedCounterpartyId }
                                    val nextIdx = (idx + 1) % primaryDealers.size
                                    viewModel.setSrpSubmissionInputs(counterpartyId = primaryDealers[nextIdx].id)
                                },
                                modifier = Modifier.testTag("srp_cycle_counterparty_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = TerminalCardElevated),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("CHANGE CP", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    // Collateral Security Type Selector
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(text = "COLLATERAL TYPE PLEDGED:", color = TextSecondary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val types = listOf(CollateralType.TREASURY_NOTE, CollateralType.TREASURY_BILL, CollateralType.AGENCY_MBS, CollateralType.AGENCY_DEBT)
                            types.forEach { type ->
                                val isSel = state.srpSelectedCollateralType == type
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSel) TerminalSky else TerminalSurface)
                                        .border(1.dp, if (isSel) TerminalSky else TerminalBorder, RoundedCornerShape(4.dp))
                                        .clickable { viewModel.setSrpSubmissionInputs(collateralType = type) }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = type.name.replace("_", " "),
                                        color = if (isSel) TerminalBackground else TextPrimary,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    // Amount & Rate Inputs + Allotment Mode
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = amountInput,
                            onValueChange = {
                                amountInput = it
                                val num = it.toDoubleOrNull() ?: 15.0
                                viewModel.setSrpSubmissionInputs(amountBln = num)
                            },
                            label = { Text("Amount (\$B)", fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                            modifier = Modifier.weight(1f).testTag("srp_input_amount"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalSky,
                                unfocusedBorderColor = TerminalBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = rateInput,
                            onValueChange = {
                                rateInput = it
                                val num = it.toDoubleOrNull() ?: 4.00
                                viewModel.setSrpSubmissionInputs(ratePct = num)
                            },
                            label = { Text("Rate (%)", fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                            modifier = Modifier.weight(1f).testTag("srp_input_rate"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalSky,
                                unfocusedBorderColor = TerminalBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )

                        // Mode Selector (Full Allotment vs Pro-Rata vs Competitive)
                        Button(
                            onClick = {
                                val nextMode = when (state.srpOperationMode) {
                                    OperationMode.FULL_ALLOTMENT -> OperationMode.PRO_RATA
                                    OperationMode.PRO_RATA -> OperationMode.COMPETITIVE_AUCTION
                                    OperationMode.COMPETITIVE_AUCTION -> OperationMode.FULL_ALLOTMENT
                                    else -> OperationMode.FULL_ALLOTMENT
                                }
                                viewModel.setSrpSubmissionInputs(mode = nextMode)
                            },
                            modifier = Modifier.align(Alignment.CenterVertically).testTag("srp_mode_toggle_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalCardElevated)
                        ) {
                            Text(text = state.srpOperationMode.name.take(8), fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    // Submit Proposition Button
                    Button(
                        onClick = { viewModel.submitSrpProposition() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("srp_submit_proposition_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalSky)
                    ) {
                        Text(
                            text = "TRANSMIT PROPOSITION TO OPEN MARKET DESK",
                            color = TerminalBackground,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Recent Propositions Queue
        item {
            Text(
                text = "PROPOSITIONS & AWARDS LOG",
                color = TextPrimary,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(state.srpRecentPropositions) { prop ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(text = prop.propositionId, color = TerminalSky, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(text = prop.counterpartyName, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text(text = "Security: ${prop.securityType.displayName} (CUSIP: ${prop.cusip})", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "Submitted: $${String.format("%.1f", prop.propositionAmountBln)}B @ ${prop.submittedRate}% | Awarded: $${String.format("%.1f", prop.awardAmountBln)}B", color = TerminalEmerald, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                    }

                    PropStatusBadge(status = prop.status)
                }
            }
        }
    }
}

@Composable
private fun SpecCol(title: String, value: String) {
    Column {
        Text(text = title, color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = TextHighlight, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun PropStatusBadge(status: PropositionStatus) {
    val (color, bg) = when (status) {
        PropositionStatus.ACCEPTED -> TerminalEmerald to TerminalEmerald.copy(alpha = 0.2f)
        PropositionStatus.PARTIALLY_ACCEPTED -> TerminalAmber to TerminalAmber.copy(alpha = 0.2f)
        PropositionStatus.REJECTED -> TerminalCrimson to TerminalCrimson.copy(alpha = 0.2f)
        PropositionStatus.SUBMITTED -> TerminalSky to TerminalSky.copy(alpha = 0.2f)
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .border(1.dp, color, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text = status.name, color = color, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
