package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.MoneyMarketRates
import com.example.ui.components.CorridorVisualizer
import com.example.ui.components.MetricCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun RatesAndSofrScreen(
    state: TerminalUiState,
    viewModel: FedRepoViewModel,
    modifier: Modifier = Modifier
) {
    var customSrp by remember { mutableStateOf(state.policyParameters.srpRate) }
    var customOnRrp by remember { mutableStateOf(state.policyParameters.onRrpRate) }
    var customIorb by remember { mutableStateOf(state.policyParameters.iorbRate) }

    LazyColumn(
        modifier = modifier
            .testTag("rates_and_sofr_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "RATES & SOFR RESEARCH TERMINAL",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "NEW YORK FED PUBLICATION ARCHITECTURE & SPREAD ANALYTICS",
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalCardElevated)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "VOLUME: $${state.rates.sofrVolumeBln.toInt()}B",
                        color = TerminalEmerald,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // SOFR Distribution Percentiles Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "SOFR DISTRIBUTION PERCENTILES (VOLUME WEIGHTED)",
                        color = TerminalSky,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(TerminalSurface)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PercentileCol(pName = "1st Percentile", rate = state.rates.sofrP1)
                        PercentileCol(pName = "25th Percentile", rate = state.rates.sofrP25)
                        PercentileCol(pName = "50th (Median)", rate = state.rates.sofrMedian, isHighlight = true)
                        PercentileCol(pName = "75th Percentile", rate = state.rates.sofrP75)
                        PercentileCol(pName = "99th Percentile", rate = state.rates.sofrP99)
                    }

                    Text(
                        text = "Dispersion Index (P99 - P1): ${String.format("%.0f", (state.rates.sofrP99 - state.rates.sofrP1) * 100)} bps | Daily Triparty & Cleared DVP Volume: $${state.rates.sofrVolumeBln.toInt()} Billion",
                        color = TextSecondary,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Corridor Visualizer
        item {
            CorridorVisualizer(rates = state.rates, policy = state.policyParameters)
        }

        // Term Repo Funding Curve
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "TREASURY FINANCING & TERM REPO CURVE",
                        color = TerminalSky,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        CurvePoint(tenor = "ON", rate = state.rates.sofr, spread = "0bp")
                        CurvePoint(tenor = "1W", rate = state.rates.sofr + 0.02, spread = "+2bp")
                        CurvePoint(tenor = "1M", rate = state.rates.sofr + 0.05, spread = "+5bp")
                        CurvePoint(tenor = "3M", rate = state.rates.tBill3m, spread = "+6bp")
                        CurvePoint(tenor = "6M", rate = 4.02, spread = "+10bp")
                        CurvePoint(tenor = "12M", rate = 4.08, spread = "+16bp")
                    }
                }
            }
        }

        // Specials & Treasury Basis Engine
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SPECIALS ENGINE & CHEAPEST-TO-DELIVER (CTD) BASIS",
                            color = TerminalAmber,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(text = "GC REPO: ${state.rates.gcRepo}%", color = TextHighlight, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SpecialRow(cusip = "91282CKB6", name = "US 10Y Note 4.000% 2036 (OTR)", specialRate = 3.45, specialnessBps = 43.0, impliedRepo = 3.42, ctdRank = "#1 CTD")
                        SpecialRow(cusip = "91282CKA8", name = "US 5Y Note 3.875% 2031", specialRate = 3.82, specialnessBps = 6.0, impliedRepo = 3.80, ctdRank = "#2 CTD")
                        SpecialRow(cusip = "91282CJZ5", name = "US 2Y Note 4.125% 2028", specialRate = 3.88, specialnessBps = 0.0, impliedRepo = 3.88, ctdRank = "GC")
                    }
                }
            }
        }

        // Dynamic Policy Parameter Tuning Sandbox
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalSky.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "POLICY RATE TRANSMISSION SANDBOX",
                        color = TerminalSky,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Adjust administered policy rates to simulate immediate money-market corridor transmission:",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Default
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = {
                                customSrp += 0.25
                                customOnRrp += 0.25
                                customIorb += 0.25
                                viewModel.updatePolicyParameters(srp = customSrp, onRrp = customOnRrp, iorb = customIorb)
                            },
                            modifier = Modifier.weight(1f).testTag("policy_hike_25_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalCardElevated)
                        ) {
                            Text("+25 bps HIKE", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }

                        Button(
                            onClick = {
                                customSrp -= 0.25
                                customOnRrp -= 0.25
                                customIorb -= 0.25
                                viewModel.updatePolicyParameters(srp = customSrp, onRrp = customOnRrp, iorb = customIorb)
                            },
                            modifier = Modifier.weight(1f).testTag("policy_cut_25_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalCardElevated)
                        ) {
                            Text("-25 bps CUT", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }

                        Button(
                            onClick = {
                                viewModel.resetTo2026ReferencePolicy()
                                customSrp = 4.00
                                customOnRrp = 3.75
                                customIorb = 3.90
                            },
                            modifier = Modifier.weight(1f).testTag("policy_reset_ref_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalSky)
                        ) {
                            Text("RESET 2026", color = TerminalBackground, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PercentileCol(pName: String, rate: Double, isHighlight: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = pName, color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(text = "${String.format("%.2f", rate)}%", color = if (isHighlight) CorridorClearing else TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun CurvePoint(tenor: String, rate: Double, spread: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = tenor, color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(text = "${String.format("%.2f", rate)}%", color = TerminalSky, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(text = spread, color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun SpecialRow(cusip: String, name: String, specialRate: Double, specialnessBps: Double, impliedRepo: Double, ctdRank: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalSurface)
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = "$cusip | $name", color = TextPrimary, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(text = "Special Repo: ${String.format("%.2f", specialRate)}% | Implied Repo: ${String.format("%.2f", impliedRepo)}%", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (specialnessBps > 0) {
                Text(text = "+${specialnessBps.toInt()} bp Special", color = TerminalAmber, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(TerminalCardElevated)
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(text = ctdRank, color = TextHighlight, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
