package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BalanceSheetTAccount
import com.example.ui.components.MetricCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun ReservesAndSomaScreen(
    state: TerminalUiState,
    viewModel: FedRepoViewModel,
    modifier: Modifier = Modifier
) {
    val soma = state.somaPortfolio
    val sheet = state.balanceSheet

    LazyColumn(
        modifier = modifier
            .testTag("reserves_and_soma_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "RESERVES & SOMA DIGITAL TWIN",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "SYSTEM OPEN MARKET ACCOUNT HOLDINGS & DOUBLE-ENTRY ACCOUNTING",
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalEmerald.copy(alpha = 0.2f))
                        .border(1.dp, TerminalEmerald, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "CONSERVATION OK",
                        color = TerminalEmerald,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Key Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    label = "TOTAL SOMA",
                    value = "$${String.format("%.2f", soma.totalHoldingsBln / 1000.0)}T",
                    subValue = "Securities Held",
                    accentColor = TerminalPurple,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    label = "RESERVE BALANCES",
                    value = "$${String.format("%.2f", sheet.reserveBalancesBln / 1000.0)}T",
                    subValue = "Depository Inst",
                    accentColor = TerminalSky,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    label = "ON RRP DRAIN",
                    value = "$${String.format("%.1f", sheet.onRrpBln)}B",
                    subValue = "Non-Bank Cash",
                    accentColor = CorridorFloor,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Balance Sheet T-Account
        item {
            BalanceSheetTAccount(sheet = sheet)
        }

        // SOMA Portfolio Breakdown Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "SOMA ASSET CLASS & MATURITY PROFILE",
                        color = TerminalPurple,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(TerminalSurface)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SomaStat(label = "Treasury Bills", value = "$${soma.treasuryBillsBln.toInt()}B")
                        SomaStat(label = "Treasury Notes", value = "$${soma.treasuryNotesBln.toInt()}B")
                        SomaStat(label = "Treasury Bonds", value = "$${soma.treasuryBondsBln.toInt()}B")
                        SomaStat(label = "Agency MBS", value = "$${soma.agencyMbsBln.toInt()}B")
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(TerminalSurface)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SomaStat(label = "Monthly Runoff Cap", value = "$${soma.monthlyRunoffCapBln.toInt()}B/mo")
                        SomaStat(label = "Actual Runoff", value = "$${soma.actualMonthlyRunoffBln.toInt()}B/mo", color = TerminalAmber)
                        SomaStat(label = "Reinvestment", value = "$${soma.monthlyReinvestmentBln.toInt()}B/mo", color = TerminalEmerald)
                        SomaStat(label = "Weighted Maturity", value = "${soma.weightedAverageMaturityYears} Years")
                    }
                }
            }
        }
    }
}

@Composable
private fun SomaStat(label: String, value: String, color: androidx.compose.ui.graphics.Color = TextPrimary) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = color, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
