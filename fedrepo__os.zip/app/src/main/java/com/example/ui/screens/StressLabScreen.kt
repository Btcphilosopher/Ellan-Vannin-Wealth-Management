package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.StressScenario
import com.example.engine.StressLabEngine
import com.example.ui.theme.*
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun StressLabScreen(
    state: TerminalUiState,
    viewModel: FedRepoViewModel,
    modifier: Modifier = Modifier
) {
    var selectedScenarioId by remember { mutableStateOf<String?>(state.activeScenario?.id ?: "SCEN-001") }

    LazyColumn(
        modifier = modifier
            .testTag("stress_lab_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MARKET STRESS LAB & CONTAGION SIMULATOR",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "12 PRELOADED CENTRAL-BANK SYSTEMIC STRESS SCENARIOS",
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (state.activeScenario != null) TerminalCrimson.copy(alpha = 0.2f) else TerminalCardElevated)
                        .border(1.dp, if (state.activeScenario != null) TerminalCrimson else TerminalBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = state.activeScenario?.code?.let { "ACTIVE: SCEN-$it" } ?: "BASELINE",
                        color = if (state.activeScenario != null) TerminalCrimson else TextSecondary,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Active Scenario Status Card
        if (state.activeScenario != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(TerminalSurface)
                        .border(1.dp, TerminalCrimson, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "STRESS CONDITION ACTIVE: ${state.activeScenario!!.title.uppercase()}", color = TerminalCrimson, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Button(
                                onClick = { viewModel.resetTo2026ReferencePolicy() },
                                colors = ButtonDefaults.buttonColors(containerColor = TerminalCardElevated),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("CLEAR STRESS", fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                        Text(text = state.activeScenario!!.expectedImpactSummary, color = TextHighlight, fontSize = 11.sp, fontFamily = FontFamily.Default)
                    }
                }
            }
        }

        // Counterparty Default & Contagion Simulation Workbench
        item {
            val contagion = state.contagionResult
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "COUNTERPARTY DEFAULT & NETWORK CONTAGION SIMULATOR",
                        color = TerminalSky,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Text(
                        text = "Simulate morning settlement default of a Tier-2 Primary Dealer. Calculates collateral fire-sale slip, replacement costs, repo rate spikes, and secondary dealer loss cascades:",
                        color = TextSecondary,
                        fontSize = 10.5.sp,
                        fontFamily = FontFamily.Default
                    )

                    Button(
                        onClick = { viewModel.simulateCounterpartyDefault("CP-PD-006") },
                        modifier = Modifier.fillMaxWidth().testTag("simulate_default_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalCrimson)
                    ) {
                        Text("SIMULATE DEFAULT OF BARCLAYS CAPITAL INC. ($35B)", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }

                    if (contagion != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(TerminalSurface)
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(text = "CONTAGION CASCADE RESULTS (${contagion.cascadeRounds} ROUNDS):", color = TerminalCrimson, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(text = "• Defaulting Exposure: $${String.format("%.1fB", contagion.initialLossBln)}", color = TextHighlight, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "• Collateral Liquidated (98% recovery): $${String.format("%.1fB", contagion.collateralLiquidatedBln)}", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "• Repo Rate Spike: +${String.format("%.1f", contagion.repoRateSpikeBps)} bps across money market", color = TerminalAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(text = "• System Liquidity Loss: $${String.format("%.1fB", contagion.systemLiquidityLossBln)}", color = TerminalCrimson, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(text = "• Fed Emergency Standing Repo Draw: $${String.format("%.1fB", contagion.fedFacilityDrawBln)}", color = TerminalSky, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Liquidity Cascade Visual Chain
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "SYSTEMIC LIQUIDITY CASCADE SEQUENCE",
                        color = TerminalAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Text(
                        text = "1. Market Shock (Yield Spike) → 2. Collateral Value Drops (-2.8%) → 3. Haircuts Widen (+50bps) → 4. Dealer Capacity Contracts (-$188B) → 5. Margin Calls ($18B) → 6. Private Repo Rates Surge → 7. Standing Repo (SRP) Tapped at 4.00% Backstop.",
                        color = TextHighlight,
                        fontSize = 10.5.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Preloaded Scenarios Library Header
        item {
            Text(
                text = "PRELOADED SCENARIO LIBRARY (SELECT & RUN)",
                color = TextPrimary,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        // List of 12 Preloaded Stress Scenarios
        items(StressLabEngine.PRELOADED_SCENARIOS) { scen ->
            ScenarioCard(
                scen = scen,
                isActive = state.activeScenario?.id == scen.id,
                onRun = { viewModel.applyStressScenario(scen) }
            )
        }
    }
}

@Composable
private fun ScenarioCard(
    scen: StressScenario,
    isActive: Boolean,
    onRun: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(TerminalCard)
            .border(1.dp, if (isActive) TerminalCrimson else TerminalBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(TerminalCardElevated)
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(text = "SCEN-${scen.code}", color = TerminalSky, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Text(text = scen.title, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }

                Button(
                    onClick = onRun,
                    modifier = Modifier.testTag("run_scen_${scen.code}"),
                    colors = ButtonDefaults.buttonColors(containerColor = if (isActive) TerminalCrimson else TerminalCardElevated),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(text = if (isActive) "ACTIVE" else "EXECUTE", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }

            Text(text = scen.description, color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Default)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Haircut: +${(scen.treasuryHaircutShockPct * 100).toInt()}bp", color = TerminalAmber, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = "Rate: ${if (scen.repoRateShockBps >= 0) "+" else ""}${scen.repoRateShockBps.toInt()}bp", color = if (scen.repoRateShockBps > 0) TerminalCrimson else TerminalEmerald, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(text = "Reserves: ${if (scen.reserveDrainBln != 0.0) "-$${scen.reserveDrainBln.toInt()}B" else "Neutral"}", color = TextHighlight, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
