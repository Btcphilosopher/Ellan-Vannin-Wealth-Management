package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TerminalDarkColorScheme = darkColorScheme(
    primary = TerminalSky,
    onPrimary = TerminalBackground,
    primaryContainer = TerminalCardElevated,
    onPrimaryContainer = TextPrimary,
    secondary = TerminalCyan,
    onSecondary = TerminalBackground,
    secondaryContainer = TerminalCard,
    onSecondaryContainer = TextPrimary,
    tertiary = TerminalEmerald,
    onTertiary = TerminalBackground,
    background = TerminalBackground,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalCard,
    onSurfaceVariant = TextSecondary,
    outline = TerminalBorder,
    error = TerminalCrimson,
    onError = Color.White
)

@Composable
fun FedRepoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TerminalDarkColorScheme,
        typography = Typography,
        content = content
    )
}
