package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ModelCard
import com.example.domain.model.ResearchQuery
import com.example.ui.components.CalculationReplayDialog
import com.example.ui.components.ModelCardDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalUiState

@Composable
fun ResearchAiScreen(
    state: TerminalUiState,
    viewModel: FedRepoViewModel,
    modifier: Modifier = Modifier
) {
    var queryInput by remember { mutableStateOf("") }
    var selectedModelCard by remember { mutableStateOf<ModelCard?>(null) }
    var showAuditDialog by remember { mutableStateOf(false) }

    if (selectedModelCard != null) {
        ModelCardDialog(modelCard = selectedModelCard!!, onDismiss = { selectedModelCard = null })
    }

    if (showAuditDialog) {
        CalculationReplayDialog(auditTrail = state.auditTrail, onDismiss = { showAuditDialog = false })
    }

    LazyColumn(
        modifier = modifier
            .testTag("research_ai_screen")
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "FEDREPO//AI RESEARCH TERMINAL",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "DOLLAR PLUMBING QUANTITATIVE REASONING & MODEL GOVERNANCE",
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = { showAuditDialog = true },
                    modifier = Modifier.testTag("open_audit_trail_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalCardElevated),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("AUDIT LOG", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // Model Governance Cards Shelf
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(text = "MODEL GOVERNANCE CARDS (TAP TO INSPECT)", color = TerminalSky, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    state.modelCards.forEach { card ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(TerminalCard)
                                .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                                .clickable { selectedModelCard = card }
                                .padding(8.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(text = card.modelId, color = TerminalSky, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(text = card.name.take(18) + "...", color = TextPrimary, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace)
                                Text(text = "VERIFIED", color = TerminalEmerald, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // Preloaded Research Questions Quick Launcher
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(text = "BENCHMARK RESEARCH QUERIES", color = TerminalAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                state.researchQueries.forEach { q ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(TerminalCard)
                            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                            .clickable { viewModel.sendResearchQuery(q.question) }
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "[${q.category.uppercase()}]", color = TerminalSky, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(text = "\"${q.question}\"", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Default)
                            }
                            Text(text = "RUN ▶", color = TerminalEmerald, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Interactive AI Chat & Query Box
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalSky.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "INTERACTIVE REASONING AGENT (FEDREPO//AI)",
                        color = TerminalSky,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = queryInput,
                            onValueChange = { queryInput = it },
                            placeholder = { Text("Ask a question about repo, haircuts, reserves, or SOMA...", fontSize = 10.5.sp) },
                            modifier = Modifier.weight(1f).testTag("ai_query_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalSky,
                                unfocusedBorderColor = TerminalBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                if (queryInput.isNotBlank()) {
                                    viewModel.sendResearchQuery(queryInput)
                                    queryInput = ""
                                }
                            },
                            modifier = Modifier.testTag("send_query_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalSky)
                        ) {
                            Text("SEND", color = TerminalBackground, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Chat / Response Stream
        items(state.chatMessages.reversed()) { (role, message) ->
            val isUser = role == "USER"
            val isSystem = role == "SYSTEM"
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isUser) TerminalCardElevated else TerminalCard)
                    .border(1.dp, if (isUser) TerminalSky else TerminalBorder, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isUser) "RESEARCHER PROMPT" else if (isSystem) "SYSTEM PROTOCOL" else "FEDREPO//AI QUANTITATIVE OUTPUT",
                            color = if (isUser) TerminalSky else if (isSystem) TerminalAmber else TerminalEmerald,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(text = state.simulationTimeEt, color = TextMuted, fontSize = 8.5.sp, fontFamily = FontFamily.Monospace)
                    }

                    Text(
                        text = message,
                        color = TextPrimary,
                        fontSize = 11.5.sp,
                        fontFamily = FontFamily.Default,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}
