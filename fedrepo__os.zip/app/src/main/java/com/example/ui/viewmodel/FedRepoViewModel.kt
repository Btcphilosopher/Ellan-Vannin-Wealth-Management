package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.model.*
import com.example.engine.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class TerminalTab(val title: String, val shortcut: String) {
    CONTROL_ROOM("CONTROL ROOM", "HOME"),
    REPO_BLOTTER("REPO / R_REPO", "REPO"),
    SRP_FACILITY("STANDING REPO", "SRP"),
    ON_RRP_FACILITY("ON RRP DESK", "ON RRP"),
    COLLATERAL_OS("COLLATERAL OS", "COLLATERAL"),
    SETTLEMENT_QUEUE("SETTLEMENT & FAILS", "SETTLE"),
    RATES_SOFR("RATES & SOFR", "RATES"),
    RESERVES_SOMA("RESERVES & SOMA", "SOMA"),
    STRESS_LAB("STRESS LAB", "STRESS"),
    COUNTERPARTIES("COUNTERPARTIES", "CP"),
    RESEARCH_AI("RESEARCH // AI", "RESEARCH")
}

data class TerminalUiState(
    val currentTab: TerminalTab = TerminalTab.CONTROL_ROOM,
    val simulationTimeEt: String = "08:15 ET",
    val isSimulationClockRunning: Boolean = false,
    val policyParameters: PolicyParameters = PolicyParameters(),
    val rates: MoneyMarketRates = MoneyMarketRates(),
    val balanceSheet: FedBalanceSheet = FedBalanceSheet(),
    val somaPortfolio: SomaPortfolio = SomaPortfolio(),
    val liquidityState: LiquidityEngineState = LiquidityEngineState(),
    val counterparties: List<Counterparty> = emptyList(),
    val collateralSecurities: List<CollateralSecurity> = emptyList(),
    val repoTransactions: List<RepoTransaction> = emptyList(),
    val settlementExceptions: List<SettlementException> = emptyList(),
    val modelCards: List<ModelCard> = emptyList(),
    val researchQueries: List<ResearchQuery> = emptyList(),
    
    // Calculator State
    val calcCollateralValue: Double = 10_000_000_000.0,
    val calcHaircutPct: Double = 1.0,
    val calcRepoRatePct: Double = 4.00,
    val calcTermDays: Int = 1,
    val calcMarginReqPct: Double = 100.0,
    val calcResult: RepoEconomicsResult = RepoEconomicsEngine.calculateRepoEconomics(10_000_000_000.0, 1.0, 4.00, 1),
    
    // SRP Submission State
    val srpSelectedCounterpartyId: String = "CP-PD-001",
    val srpSelectedCollateralType: CollateralType = CollateralType.TREASURY_NOTE,
    val srpPropositionAmountBln: Double = 15.0,
    val srpSubmittedRatePct: Double = 4.00,
    val srpOperationMode: OperationMode = OperationMode.FULL_ALLOTMENT,
    val srpRecentPropositions: List<Proposition> = emptyList(),
    val srpRecentOperationResults: List<OperationResult> = emptyList(),
    
    // ON RRP State
    val onRrpOfferingRatePct: Double = 3.75,
    val onRrpCounterpartyLimitBln: Double = 160.0,
    val onRrpExecutionResult: OnRrpSimulator.OnRrpExecutionResult? = null,
    
    // Haircut Stress State
    val haircutShockBps: Double = 50.0,
    val haircutShockResult: HaircutEngine.HaircutShockResult? = null,
    
    // Active Stress Scenario
    val activeScenario: StressScenario? = null,
    val contagionResult: ContagionSimulationResult? = null,
    val selectedDefaultCounterpartyId: String = "CP-PD-006",
    
    // AI Assistant Chat
    val chatMessages: List<Pair<String, String>> = emptyList(), // Pair(Role, Message)
    val isAiThinking: Boolean = false,
    
    // Status banner
    val systemStatusMessage: String = "FEDREPO//OS initialized. 2026 Reference Policy Active (SRP 4.00%, ON RRP 3.75%, IORB 3.90%).",
    val auditTrail: List<AuditCalculation> = emptyList()
)

class FedRepoViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(TerminalUiState())
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    init {
        initializeTerminal()
    }

    private fun initializeTerminal() {
        val counterparties = SyntheticMarketGenerator.generateCounterparties()
        val securities = SyntheticMarketGenerator.generateCollateralSecurities()
        val initialTx = SyntheticMarketGenerator.generateInitialRepoTransactions()
        val modelCards = SyntheticMarketGenerator.generateModelCards()
        val queries = SyntheticMarketGenerator.generateResearchQueries()

        // Generate initial settlement exceptions
        val exceptions = initialTx.filter { it.status == SettlementStatus.FAILED }.mapNotNull { tx ->
            TripartySettlementEngine.buildSettlementWorkflow(tx).exception
        }

        val initialHaircutResult = HaircutEngine.simulateHaircutShock(counterparties, 50.0)

        val initialPropositions = listOf(
            Proposition("PROP-001", "OP-SRP-MORNING", "CP-PD-001", "J.P. Morgan Securities LLC", CollateralType.TREASURY_NOTE, "91282CJZ5", 15.0, 4.00, "08:18 ET", PropositionStatus.ACCEPTED, 15.0),
            Proposition("PROP-002", "OP-SRP-MORNING", "CP-PD-002", "Goldman Sachs & Co. LLC", CollateralType.TREASURY_NOTE, "91282CKA8", 12.5, 4.00, "08:22 ET", PropositionStatus.ACCEPTED, 12.5),
            Proposition("PROP-003", "OP-SRP-MORNING", "CP-PD-003", "BofA Securities, Inc.", CollateralType.AGENCY_MBS, "01F0306A1", 8.2, 4.00, "08:25 ET", PropositionStatus.ACCEPTED, 8.2)
        )

        val initialResults = listOf(
            OperationResult("OP-SRP-MORNING", "Standing Repo Facility (Morning)", "2026-10-05", "08:15 – 08:30 ET", 4.00, 35.7, 35.7, 27.5, 0.0, 8.2, 3)
        )

        val initialChat = listOf(
            "SYSTEM" to "FEDREPO//OS Research Assistant ready. Model: Federal Reserve Open Market Operations & Collateral Digital Twin. Type or select a quantitative query.",
            "ASSISTANT" to "Welcome to FEDREPO//OS. Current Policy Reference (Eff. Sept 17, 2026): Fed Funds Target 3.75%–4.00%, IORB 3.90%, Standing Repo (SRP) 4.00%, ON RRP 3.75% ($160B limit). All operations model actual money market and tri-party settlement conventions."
        )

        _uiState.update { state ->
            state.copy(
                counterparties = counterparties,
                collateralSecurities = securities,
                repoTransactions = initialTx,
                settlementExceptions = exceptions,
                modelCards = modelCards,
                researchQueries = queries,
                haircutShockResult = initialHaircutResult,
                srpRecentPropositions = initialPropositions,
                srpRecentOperationResults = initialResults,
                chatMessages = initialChat,
                auditTrail = listOf(
                    AuditCalculation("AUD-INIT-001", "MOD-REPO-001", "08:00:00 ET", "Repo Market Initialization", "Validated 6 active positions, $44.2B cash settled", "SHA256:7B8F9A", true),
                    AuditCalculation("AUD-INIT-002", "MOD-BAL-003", "08:05:00 ET", "Balance Sheet Double-Entry Invariant Check", "Assets $6,906.0B == Liabilities+Capital $6,906.0B [OK]", "SHA256:4C2D1E", true)
                )
            )
        }
    }

    fun selectTab(tab: TerminalTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun updateCalculator(
        collateralValue: Double = _uiState.value.calcCollateralValue,
        haircutPct: Double = _uiState.value.calcHaircutPct,
        repoRatePct: Double = _uiState.value.calcRepoRatePct,
        termDays: Int = _uiState.value.calcTermDays,
        marginReqPct: Double = _uiState.value.calcMarginReqPct
    ) {
        val result = RepoEconomicsEngine.calculateRepoEconomics(
            collateralMarketValue = collateralValue,
            haircutPct = haircutPct,
            repoRatePct = repoRatePct,
            termDays = termDays,
            marginRequirementPct = marginReqPct
        )

        val newAudit = AuditCalculation(
            calculationId = "AUD-CALC-${System.currentTimeMillis().toString().takeLast(6)}",
            modelName = "MOD-REPO-001 (Repo Economics Engine)",
            timestamp = _uiState.value.simulationTimeEt,
            inputsSummary = "Val: $${String.format("%.2fB", collateralValue / 1e9)}, Haircut: ${haircutPct}%, Rate: ${repoRatePct}%, Term: ${termDays}D",
            resultSummary = "Cash: $${String.format("%.2fB", result.cashAdvanced / 1e9)}, Int: $${String.format("%.2fM", result.repoInterestAmount / 1e6)}, Repurchase: $${String.format("%.2fB", result.repurchasePrice / 1e9)}",
            verificationHash = result.calculationHash,
            deterministicReplaySuccess = true
        )

        _uiState.update {
            it.copy(
                calcCollateralValue = collateralValue,
                calcHaircutPct = haircutPct,
                calcRepoRatePct = repoRatePct,
                calcTermDays = termDays,
                calcMarginReqPct = marginReqPct,
                calcResult = result,
                auditTrail = listOf(newAudit) + it.auditTrail.take(30)
            )
        }
    }

    fun setSrpSubmissionInputs(
        counterpartyId: String = _uiState.value.srpSelectedCounterpartyId,
        collateralType: CollateralType = _uiState.value.srpSelectedCollateralType,
        amountBln: Double = _uiState.value.srpPropositionAmountBln,
        ratePct: Double = _uiState.value.srpSubmittedRatePct,
        mode: OperationMode = _uiState.value.srpOperationMode
    ) {
        _uiState.update {
            it.copy(
                srpSelectedCounterpartyId = counterpartyId,
                srpSelectedCollateralType = collateralType,
                srpPropositionAmountBln = amountBln,
                srpSubmittedRatePct = ratePct,
                srpOperationMode = mode
            )
        }
    }

    fun submitSrpProposition() {
        val state = _uiState.value
        val cp = state.counterparties.find { it.id == state.srpSelectedCounterpartyId } ?: return
        val matchingSec = state.collateralSecurities.find { it.assetType == state.srpSelectedCollateralType }
        val cusip = matchingSec?.cusip ?: "91282CJZ5"

        val propId = "PROP-${(state.srpRecentPropositions.size + 1).toString().padStart(3, '0')}"
        val newProp = Proposition(
            propositionId = propId,
            operationId = "OP-SRP-${System.currentTimeMillis().toString().takeLast(4)}",
            counterpartyId = cp.id,
            counterpartyName = cp.name,
            securityType = state.srpSelectedCollateralType,
            cusip = cusip,
            propositionAmountBln = state.srpPropositionAmountBln,
            submittedRate = state.srpSubmittedRatePct,
            submittedTime = state.simulationTimeEt,
            status = PropositionStatus.SUBMITTED
        )

        val facility = RepoFacility(
            facilityId = "FAC-SRP-001",
            name = "Standing Repo Facility (FedTrade Plus)",
            operationSchedule = "08:15 – 08:30 ET",
            ratePct = state.policyParameters.srpRate,
            allotmentMethod = state.srpOperationMode,
            aggregateLimitBln = state.policyParameters.srpAggregateLimitBln,
            propositionLimitBln = 50.0,
            eligibleCounterpartyTypes = listOf(CounterpartyType.PRIMARY_DEALER, CounterpartyType.BANK),
            eligibleCollateral = listOf(CollateralType.TREASURY_BILL, CollateralType.TREASURY_NOTE, CollateralType.TREASURY_BOND, CollateralType.TIPS, CollateralType.FRN, CollateralType.AGENCY_DEBT, CollateralType.AGENCY_MBS),
            settlementMethod = ClearingMethod.FEDTRADE_PLUS
        )

        val cpMap = state.counterparties.associateBy { it.id }
        val allPropsToProcess = state.srpRecentPropositions + newProp
        val (opResult, updatedProps) = SrpAuctionSimulator.executeOperation(
            operationId = "OP-SRP-EXEC-${System.currentTimeMillis().toString().takeLast(4)}",
            operationName = "Standing Repo Operation (${state.srpOperationMode.name})",
            scheduleWindow = state.policyParameters.morningSrpWindow,
            facility = facility,
            propositions = allPropsToProcess,
            counterpartiesMap = cpMap
        )

        // If accepted, also create an actual RepoTransaction and adjust balance sheet
        val latestAccepted = updatedProps.find { it.propositionId == propId && (it.status == PropositionStatus.ACCEPTED || it.status == PropositionStatus.PARTIALLY_ACCEPTED) }
        val updatedTransactions = if (latestAccepted != null) {
            val awardedCash = latestAccepted.awardAmountBln * 1_000_000_000.0
            val reqCollateral = awardedCash / (1.0 - state.srpSelectedCollateralType.standardHaircutPct / 100.0)
            val newTx = RepoTransaction(
                repoId = "TX-SRP-${System.currentTimeMillis().toString().takeLast(5)}",
                transactionType = TransactionType.SRP,
                counterpartyId = cp.id,
                counterpartyName = cp.name,
                cashAmount = awardedCash,
                collateralMarketValue = reqCollateral,
                collateralType = state.srpSelectedCollateralType,
                cusip = cusip,
                haircutPct = state.srpSelectedCollateralType.standardHaircutPct,
                repoRatePct = state.policyParameters.srpRate,
                termDays = 1,
                startDate = "2026-10-05",
                maturityDate = "2026-10-06",
                settlementDate = "2026-10-05",
                clearingMethod = ClearingMethod.FEDTRADE_PLUS,
                settlementAgent = "Federal Reserve Bank of New York",
                status = SettlementStatus.SETTLED
            )
            listOf(newTx) + state.repoTransactions
        } else {
            state.repoTransactions
        }

        // Adjust Fed Balance Sheet
        val newSrpRepoTotal = opResult.totalAwardedBln
        val updatedBalanceSheet = FedBalanceSheetEngine.simulateBalanceSheetShock(
            baseSheet = state.balanceSheet,
            srpRepoChangeBln = if (latestAccepted != null) latestAccepted.awardAmountBln else 0.0,
            onRrpChangeBln = 0.0,
            treasuryPurchaseSaleBln = 0.0,
            reserveDrainBln = 0.0
        )

        val statusMsg = if (latestAccepted != null) {
            "Proposition $propId awarded $${String.format("%.2f", latestAccepted.awardAmountBln)}B at ${state.policyParameters.srpRate}%. Trade settled via FedTrade Plus."
        } else {
            val rejected = updatedProps.find { it.propositionId == propId }
            "Proposition $propId rejected: ${rejected?.rejectionReason ?: "Validation failure."}"
        }

        _uiState.update {
            it.copy(
                srpRecentPropositions = updatedProps,
                srpRecentOperationResults = listOf(opResult) + it.srpRecentOperationResults.take(10),
                repoTransactions = updatedTransactions,
                balanceSheet = updatedBalanceSheet,
                systemStatusMessage = statusMsg
            )
        }
    }

    fun runOnRrpOperation() {
        val state = _uiState.value
        val result = OnRrpSimulator.executeOnRrpDailyOperation(
            counterparties = state.counterparties,
            offeringRatePct = state.policyParameters.onRrpRate,
            counterpartyLimitBln = state.policyParameters.onRrpCounterpartyLimitBln
        )

        // Adjust Fed balance sheet with new ON RRP total
        val updatedBalanceSheet = FedBalanceSheetEngine.simulateBalanceSheetShock(
            baseSheet = state.balanceSheet,
            srpRepoChangeBln = 0.0,
            onRrpChangeBln = result.totalAcceptedBln - state.balanceSheet.onRrpBln,
            treasuryPurchaseSaleBln = 0.0,
            reserveDrainBln = 0.0
        )

        _uiState.update {
            it.copy(
                onRrpExecutionResult = result,
                balanceSheet = updatedBalanceSheet,
                systemStatusMessage = "ON RRP Operation executed: $${String.format("%.2f", result.totalAcceptedBln)}B absorbed across ${result.participatingCount} counterparties. Bank reserves adjusted."
            )
        }
    }

    fun updateHaircutShock(shockBps: Double) {
        val result = HaircutEngine.simulateHaircutShock(_uiState.value.counterparties, shockBps)
        _uiState.update {
            it.copy(
                haircutShockBps = shockBps,
                haircutShockResult = result,
                systemStatusMessage = "Haircut shock +${shockBps.toInt()}bps simulated: System funding capacity loss -$${String.format("%.2f", result.systemCapacityLossBln)}B."
            )
        }
    }

    fun resolveException(exception: SettlementException) {
        val (resolvedTx, message) = TripartySettlementEngine.resolveException(exception)
        _uiState.update { state ->
            val updatedExceptions = state.settlementExceptions.filter { it.exceptionId != exception.exceptionId }
            val updatedTx = state.repoTransactions.map { tx ->
                if (tx.repoId == exception.transactionId) resolvedTx else tx
            }
            state.copy(
                settlementExceptions = updatedExceptions,
                repoTransactions = updatedTx,
                systemStatusMessage = message
            )
        }
    }

    fun applyStressScenario(scenario: StressScenario) {
        val state = _uiState.value
        val stressedRates = state.rates.copy(
            sofr = state.rates.sofr + (scenario.repoRateShockBps / 100.0),
            gcRepo = state.rates.gcRepo + (scenario.repoRateShockBps / 100.0),
            effr = (state.rates.effr + (scenario.repoRateShockBps / 150.0)).coerceAtMost(state.policyParameters.srpRate + 0.15)
        )

        val stressedSheet = FedBalanceSheetEngine.simulateBalanceSheetShock(
            baseSheet = state.balanceSheet,
            srpRepoChangeBln = if (scenario.repoRateShockBps > 30) 35.0 else 0.0,
            onRrpChangeBln = scenario.onRrpShiftBln,
            treasuryPurchaseSaleBln = 0.0,
            reserveDrainBln = scenario.reserveDrainBln
        )

        val haircutResult = HaircutEngine.simulateHaircutShock(state.counterparties, scenario.treasuryHaircutShockPct * 100)

        _uiState.update {
            it.copy(
                activeScenario = scenario,
                rates = stressedRates,
                balanceSheet = stressedSheet,
                haircutShockResult = haircutResult,
                systemStatusMessage = "Scenario ${scenario.code} (${scenario.title}) activated: ${scenario.expectedImpactSummary}"
            )
        }
    }

    fun simulateCounterpartyDefault(counterpartyId: String) {
        val state = _uiState.value
        val cp = state.counterparties.find { it.id == counterpartyId } ?: return
        val result = StressLabEngine.simulateCounterpartyDefault(cp, state.counterparties)

        _uiState.update {
            it.copy(
                selectedDefaultCounterpartyId = counterpartyId,
                contagionResult = result,
                systemStatusMessage = "Counterparty default simulation executed for ${cp.name}. Initial exposure $${String.format("%.2f", result.initialLossBln)}B, contagion loss $${String.format("%.2f", result.systemLiquidityLossBln)}B."
            )
        }
    }

    fun updatePolicyParameters(
        targetLow: Double = _uiState.value.policyParameters.targetRangeLow,
        targetHigh: Double = _uiState.value.policyParameters.targetRangeHigh,
        iorb: Double = _uiState.value.policyParameters.iorbRate,
        srp: Double = _uiState.value.policyParameters.srpRate,
        onRrp: Double = _uiState.value.policyParameters.onRrpRate,
        onRrpLimitBln: Double = _uiState.value.policyParameters.onRrpCounterpartyLimitBln
    ) {
        val newPolicy = _uiState.value.policyParameters.copy(
            targetRangeLow = targetLow,
            targetRangeHigh = targetHigh,
            iorbRate = iorb,
            srpRate = srp,
            onRrpRate = onRrp,
            onRrpCounterpartyLimitBln = onRrpLimitBln,
            is2026Reference = false
        )

        // Dynamic market rates transmission
        val marketSofr = ((srp + onRrp) / 2.0 + (iorb - 3.90) * 0.8).coerceIn(onRrp, srp)
        val marketEffr = (iorb - 0.02).coerceIn(targetLow, targetHigh)

        val updatedRates = _uiState.value.rates.copy(
            srpRate = srp,
            onRrpRate = onRrp,
            iorb = iorb,
            sofr = marketSofr,
            effr = marketEffr,
            gcRepo = marketSofr - 0.04
        )

        _uiState.update {
            it.copy(
                policyParameters = newPolicy,
                rates = updatedRates,
                systemStatusMessage = "Policy parameters updated: SRP ${srp}%, ON RRP ${onRrp}%, IORB ${iorb}%. Market corridor re-centered."
            )
        }
    }

    fun resetTo2026ReferencePolicy() {
        val ref = PolicyParameters()
        val refRates = MoneyMarketRates()
        _uiState.update {
            it.copy(
                policyParameters = ref,
                rates = refRates,
                systemStatusMessage = "Reset to September 17, 2026 Reference Configuration: Target 3.75%–4.00%, IORB 3.90%, SRP 4.00%, ON RRP 3.75% ($160B limit)."
            )
        }
    }

    fun sendResearchQuery(query: String) {
        val currentMessages = _uiState.value.chatMessages
        val newMessages = currentMessages + ("USER" to query)
        _uiState.update { it.copy(chatMessages = newMessages, isAiThinking = true) }

        viewModelScope.launch {
            delay(400) // Fast realistic quantitative processing
            val matchingQuery = _uiState.value.researchQueries.find {
                query.contains(it.category, ignoreCase = true) || it.question.contains(query, ignoreCase = true) || query.contains(it.queryId, ignoreCase = true)
            }

            val response = if (matchingQuery != null) {
                """
                [SIMULATION RESULT — NOT A FEDERAL RESERVE FORECAST]
                ANALYSIS: ${matchingQuery.modelExplanation}
                
                METRIC IMPACTS:
                ${matchingQuery.metricImpacts.joinToString("\n") { "• ${it.first}: ${it.second}" }}
                
                PROVENANCE: ${matchingQuery.dataProvenance}
                """.trimIndent()
            } else {
                """
                [SIMULATION RESULT — NOT A FEDERAL RESERVE FORECAST]
                ANALYSIS: In the Federal Reserve repo ecosystem, policy rate transmission operates through the corridor bounded by the Standing Repo Facility (4.00% ceiling) and the Overnight Reverse Repo Facility (3.75% floor). When cash liquidity is ample, SOFR (currently 3.92%) and EFFR (3.88%) trade near IORB (3.90%). 
                
                Collateral constraints or haircut widenings compress dealer balance-sheet capacity, putting upward pressure on private repo rates until the SRP is tapped.
                
                PROVENANCE: FEDREPO//OS Quantitative Core v3.7 (Data as of 2026-10-05).
                """.trimIndent()
            }

            _uiState.update {
                it.copy(
                    chatMessages = it.chatMessages + ("ASSISTANT" to response),
                    isAiThinking = false
                )
            }
        }
    }

    fun advanceSimulationTime(stepMinutes: Int = 15) {
        val times = listOf("07:30 ET", "08:00 ET", "08:15 ET", "08:30 ET", "08:31 ET", "08:35 ET", "09:00 ET", "10:00 ET", "13:30 ET", "13:45 ET", "14:00 ET", "16:00 ET")
        val currentIdx = times.indexOf(_uiState.value.simulationTimeEt)
        val nextIdx = if (currentIdx in 0 until times.size - 1) currentIdx + 1 else 0
        val nextTime = times[nextIdx]

        _uiState.update {
            it.copy(
                simulationTimeEt = nextTime,
                systemStatusMessage = "Operational clock advanced to $nextTime."
            )
        }
    }
}
