package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.DisclaimerDialog
import com.example.ui.components.NavigationTabBar
import com.example.ui.components.TerminalTopBar
import com.example.ui.screens.*
import com.example.ui.theme.TerminalBackground
import com.example.ui.viewmodel.FedRepoViewModel
import com.example.ui.viewmodel.TerminalTab

@Composable
fun FedRepoTerminalApp(
    viewModel: FedRepoViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showDisclaimerDialog by remember { mutableStateOf(false) }

    // Handle back button: if not on Control Room, return to Control Room
    BackHandler(enabled = state.currentTab != TerminalTab.CONTROL_ROOM) {
        viewModel.selectTab(TerminalTab.CONTROL_ROOM)
    }

    if (showDisclaimerDialog) {
        DisclaimerDialog(onDismiss = { showDisclaimerDialog = false })
    }

    Scaffold(
        modifier = Modifier
            .testTag("fedrepo_terminal_scaffold")
            .fillMaxSize()
            .background(TerminalBackground),
        topBar = {
            Column {
                TerminalTopBar(
                    simulationTimeEt = state.simulationTimeEt,
                    systemStatusMessage = state.systemStatusMessage,
                    onAdvanceTime = { viewModel.advanceSimulationTime() },
                    onResetPolicy = { viewModel.resetTo2026ReferencePolicy() },
                    onShowDisclaimer = { showDisclaimerDialog = true }
                )
                NavigationTabBar(
                    selectedTab = state.currentTab,
                    onTabSelected = { viewModel.selectTab(it) },
                    exceptionCount = state.settlementExceptions.size
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(TerminalBackground)
        ) {
            when (state.currentTab) {
                TerminalTab.CONTROL_ROOM -> ControlRoomScreen(
                    state = state,
                    onNavigateToTab = { viewModel.selectTab(it) }
                )
                TerminalTab.REPO_BLOTTER -> RepoBlotterScreen(
                    state = state,
                    viewModel = viewModel
                )
                TerminalTab.SRP_FACILITY -> SrpFacilityScreen(
                    state = state,
                    viewModel = viewModel
                )
                TerminalTab.ON_RRP_FACILITY -> OnRrpDeskScreen(
                    state = state,
                    viewModel = viewModel
                )
                TerminalTab.COLLATERAL_OS -> CollateralOsScreen(
                    state = state,
                    viewModel = viewModel
                )
                TerminalTab.SETTLEMENT_QUEUE -> SettlementQueueScreen(
                    state = state,
                    viewModel = viewModel
                )
                TerminalTab.RATES_SOFR -> RatesAndSofrScreen(
                    state = state,
                    viewModel = viewModel
                )
                TerminalTab.RESERVES_SOMA -> ReservesAndSomaScreen(
                    state = state,
                    viewModel = viewModel
                )
                TerminalTab.STRESS_LAB -> StressLabScreen(
                    state = state,
                    viewModel = viewModel
                )
                TerminalTab.COUNTERPARTIES -> CounterpartiesScreen(
                    state = state,
                    viewModel = viewModel
                )
                TerminalTab.RESEARCH_AI -> ResearchAiScreen(
                    state = state,
                    viewModel = viewModel
                )
            }
        }
    }
}
