package com.example.data.local

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey val id: String,
    val passengerName: String,
    val originName: String,
    val originAddress: String,
    val originLat: Double,
    val originLng: Double,
    val destName: String,
    val destAddress: String,
    val destLat: Double,
    val destLng: Double,
    val passengerCount: Int,
    val baggageCount: Int,
    val totalDurationMinutes: Int,
    val totalPrice: Double,
    val carbonSavedKg: Double,
    val state: String,
    val currentLegIndex: Int,
    val scheduledTimeMillis: Long,
    val createdTimeMillis: Long,
    val assignedAircraftId: String?,
    val assignedDriverId: String?,
    val qrCodeToken: String,
    val disruptionNotice: String?
)

@Entity(tableName = "reservations")
data class ReservationEntity(
    @PrimaryKey val id: String,
    val originName: String,
    val destinationName: String,
    val scheduledDate: String,
    val scheduledTime: String,
    val passengerCount: Int,
    val mode: String,
    val price: Double,
    val status: String
)

@Entity(tableName = "support_tickets")
data class SupportTicketEntity(
    @PrimaryKey val id: String,
    val tripId: String?,
    val category: String,
    val subject: String,
    val description: String,
    val status: String,
    val timestamp: Long
)

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY createdTimeMillis DESC")
    fun getAllTrips(): Flow<List<TripEntity>>

    @Query("SELECT * FROM trips WHERE id = :id LIMIT 1")
    fun getTripByIdFlow(id: String): Flow<TripEntity?>

    @Query("SELECT * FROM trips WHERE id = :id LIMIT 1")
    suspend fun getTripById(id: String): TripEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(trip: TripEntity)

    @Query("DELETE FROM trips WHERE id = :id")
    suspend fun deleteTrip(id: String)
}

@Dao
interface ReservationDao {
    @Query("SELECT * FROM reservations ORDER BY id DESC")
    fun getAllReservations(): Flow<List<ReservationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReservation(reservation: ReservationEntity)

    @Query("DELETE FROM reservations WHERE id = :id")
    suspend fun deleteReservation(id: String)
}

@Dao
interface SupportTicketDao {
    @Query("SELECT * FROM support_tickets ORDER BY timestamp DESC")
    fun getAllTickets(): Flow<List<SupportTicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: SupportTicketEntity)
}
