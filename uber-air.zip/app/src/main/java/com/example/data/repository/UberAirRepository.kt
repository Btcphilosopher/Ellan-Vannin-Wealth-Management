package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.ReservationEntity
import com.example.data.local.SupportTicketEntity
import com.example.data.local.TripEntity
import com.example.data.models.Aircraft
import com.example.data.models.LocationPoint
import com.example.data.models.PriceQuote
import com.example.data.models.Reservation
import com.example.data.models.SupportTicket
import com.example.data.models.TicketCategory
import com.example.data.models.TicketStatus
import com.example.data.models.Trip
import com.example.data.models.TripLeg
import com.example.data.models.TripState
import com.example.data.models.Vertiport
import com.example.simulation.LondonNetwork
import com.example.simulation.UamSimulator
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map

class UberAirRepository(
    private val db: AppDatabase,
    val simulator: UamSimulator = UamSimulator()
) {
    val activeTrip: StateFlow<Trip?> = simulator.activeTrip
    val aircraftList: StateFlow<List<Aircraft>> = simulator.aircraftList
    val vertiports: StateFlow<List<Vertiport>> = simulator.vertiports
    val systemMetrics: StateFlow<UamSimulator.SystemMetrics> = simulator.systemMetrics
    val disruptionMessage: StateFlow<String?> = simulator.disruptionMessage

    // Room persistent flows
    val allTripsFromDb: Flow<List<TripEntity>> = db.tripDao().getAllTrips()
    val allReservations: Flow<List<ReservationEntity>> = db.reservationDao().getAllReservations()
    val allSupportTickets: Flow<List<SupportTicketEntity>> = db.supportTicketDao().getAllTickets()

    fun getQuotes(origin: LocationPoint, dest: LocationPoint, passengerCount: Int): List<PriceQuote> {
        return LondonNetwork.calculateQuotes(origin, dest, passengerCount)
    }

    suspend fun createAndBookTrip(
        origin: LocationPoint,
        dest: LocationPoint,
        passengerCount: Int,
        baggageCount: Int
    ): Trip {
        val trip = LondonNetwork.createMultimodalTrip(origin, dest, passengerCount, baggageCount)
        simulator.setActiveTrip(trip)

        // Save to Room DB
        val entity = TripEntity(
            id = trip.id,
            passengerName = trip.passengerName,
            originName = trip.origin.name,
            originAddress = trip.origin.address,
            originLat = trip.origin.lat,
            originLng = trip.origin.lng,
            destName = trip.destination.name,
            destAddress = trip.destination.address,
            destLat = trip.destination.lat,
            destLng = trip.destination.lng,
            passengerCount = trip.passengerCount,
            baggageCount = trip.baggageCount,
            totalDurationMinutes = trip.totalDurationMinutes,
            totalPrice = trip.totalPrice,
            carbonSavedKg = trip.carbonSavedKg,
            state = trip.state.name,
            currentLegIndex = trip.currentLegIndex,
            scheduledTimeMillis = trip.scheduledTimeMillis,
            createdTimeMillis = trip.createdTimeMillis,
            assignedAircraftId = trip.assignedAircraftId,
            assignedDriverId = trip.assignedDriverId,
            qrCodeToken = trip.qrCodeToken,
            disruptionNotice = trip.disruptionNotice
        )
        db.tripDao().insertOrUpdate(entity)
        return trip
    }

    suspend fun createReservation(
        originName: String,
        destName: String,
        date: String,
        time: String,
        passengerCount: Int,
        price: Double
    ) {
        val res = ReservationEntity(
            id = "res_${System.currentTimeMillis()}",
            originName = originName,
            destinationName = destName,
            scheduledDate = date,
            scheduledTime = time,
            passengerCount = passengerCount,
            mode = "Uber Air",
            price = price,
            status = "CONFIRMED"
        )
        db.reservationDao().insertReservation(res)
    }

    suspend fun createSupportTicket(category: TicketCategory, subject: String, description: String, tripId: String? = null) {
        val ticket = SupportTicketEntity(
            id = "tkt_${System.currentTimeMillis()}",
            tripId = tripId,
            category = category.name,
            subject = subject,
            description = description,
            status = TicketStatus.OPEN.name,
            timestamp = System.currentTimeMillis()
        )
        db.supportTicketDao().insertTicket(ticket)
    }

    fun advanceActiveTripState() {
        val trip = simulator.activeTrip.value
        if (trip != null) {
            simulator.advanceTripStateMachine(trip)
        }
    }

    fun cancelActiveTrip() {
        val trip = simulator.activeTrip.value
        if (trip != null) {
            simulator.setActiveTrip(trip.copy(state = TripState.CANCELLED))
        }
    }
}
