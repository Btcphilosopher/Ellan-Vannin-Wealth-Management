package com.example.data.models

import java.util.UUID

data class LocationPoint(
    val name: String,
    val address: String,
    val code: String? = null,
    val lat: Double,
    val lng: Double
)

enum class VertiportStatus {
    AVAILABLE, BUSY, CONGESTED, MAINTENANCE, CLOSED
}

data class Vertiport(
    val id: String,
    val name: String,
    val code: String,
    val address: String,
    val lat: Double,
    val lng: Double,
    val totalPads: Int = 4,
    val availablePads: Int = 3,
    val status: VertiportStatus = VertiportStatus.AVAILABLE
)

enum class PadStatus {
    AVAILABLE, RESERVED, OCCUPIED, CHARGING, MAINTENANCE
}

data class Pad(
    val id: String,
    val vertiportId: String,
    val padName: String,
    val status: PadStatus = PadStatus.AVAILABLE,
    val currentAircraftId: String? = null
)

data class AircraftType(
    val model: String = "Joby S4 eVTOL",
    val capacity: Int = 4,
    val maxRangeKm: Double = 240.0,
    val maxSpeedMph: Int = 200
)

enum class AircraftStatus {
    AVAILABLE, POSITIONING, BOARDING, DEPARTING, AIRBORNE, APPROACHING, LANDED, CHARGING, MAINTENANCE, UNAVAILABLE
}

data class Aircraft(
    val id: String,
    val registration: String, // e.g. UA-204
    val model: String = "Joby S4 eVTOL",
    val capacity: Int = 4,
    val batteryPercentage: Int, // 0-100
    val status: AircraftStatus = AircraftStatus.AVAILABLE,
    val currentLat: Double,
    val currentLng: Double,
    val targetLat: Double = currentLat,
    val targetLng: Double = currentLng,
    val heading: Float = 0f,
    val speedMph: Int = 0,
    val altitudeFt: Int = 0,
    val pilotName: String = "Capt. Sarah Jenkins",
    val healthStatus: String = "100% Nominal",
    val vertiportId: String? = null
)

data class Driver(
    val id: String,
    val name: String,
    val vehicleModel: String = "Tesla Model Y",
    val licensePlate: String = "UBER-842",
    val rating: Double = 4.96,
    val currentLat: Double,
    val currentLng: Double
)

enum class LegType {
    GROUND_PICKUP, AIR_FLIGHT, GROUND_DROPOFF
}

enum class LegStatus {
    PENDING, DISPATCHED, EN_ROUTE, ARRIVED, IN_PROGRESS, COMPLETED
}

data class TripLeg(
    val id: String = UUID.randomUUID().toString(),
    val legOrder: Int,
    val type: LegType,
    val modeName: String, // "Uber Black", "Uber Air"
    val origin: LocationPoint,
    val destination: LocationPoint,
    val distanceKm: Double,
    val durationMinutes: Int,
    val price: Double,
    val departureTime: String,
    val arrivalTime: String,
    val vehicleRegOrModel: String,
    val status: LegStatus = LegStatus.PENDING
)

enum class TripState {
    REQUESTED,
    QUOTED,
    BOOKED,
    GROUND_DISPATCHED,
    GROUND_ARRIVING,
    AT_VERTIPORT,
    CHECKED_IN,
    BOARDING,
    DEPARTED,
    AIRBORNE,
    APPROACHING,
    LANDED,
    GROUND_DROPOFF_DISPATCHED,
    COMPLETED,
    CANCELLED,
    DISRUPTED
}

data class Trip(
    val id: String = UUID.randomUUID().toString(),
    val passengerName: String = "Tom",
    val origin: LocationPoint,
    val destination: LocationPoint,
    val passengerCount: Int = 1,
    val baggageCount: Int = 1,
    val totalDurationMinutes: Int,
    val totalPrice: Double,
    val carbonSavedKg: Double = 3.2,
    val currentLegIndex: Int = 0,
    val state: TripState = TripState.BOOKED,
    val legs: List<TripLeg>,
    val createdTimeMillis: Long = System.currentTimeMillis(),
    val scheduledTimeMillis: Long = System.currentTimeMillis(),
    val assignedAircraftId: String? = "UA-204",
    val assignedDriverId: String? = "DRV-102",
    val qrCodeToken: String = "UBER-AIR-${UUID.randomUUID().toString().take(8).uppercase()}",
    val disruptionNotice: String? = null
)

data class Reservation(
    val id: String = UUID.randomUUID().toString(),
    val originName: String,
    val destinationName: String,
    val scheduledDate: String,
    val scheduledTime: String,
    val passengerCount: Int,
    val mode: String = "Uber Air",
    val price: Double,
    val status: String = "CONFIRMED"
)

enum class TicketCategory {
    TRIP_ISSUE, BOOKING, PAYMENT, VERTIPORT, FLIGHT, BAGGAGE, SAFETY
}

enum class TicketStatus {
    OPEN, ASSIGNED, IN_PROGRESS, RESOLVED, CLOSED
}

data class SupportTicket(
    val id: String = UUID.randomUUID().toString(),
    val tripId: String? = null,
    val category: TicketCategory,
    val subject: String,
    val description: String,
    val status: TicketStatus = TicketStatus.OPEN,
    val timestamp: Long = System.currentTimeMillis()
)

data class PriceQuote(
    val id: String,
    val mode: String, // "Uber Air", "Uber Black", "Uber Comfort", "UberX"
    val durationMinutes: Int,
    val price: Double,
    val timeSavedMinutes: Int = 0,
    val description: String,
    val isAirOption: Boolean = false,
    val breakdownAir: Double = 0.0,
    val breakdownPickup: Double = 0.0,
    val breakdownDropoff: Double = 0.0,
    val carbonSavedKg: Double = 0.0
)
