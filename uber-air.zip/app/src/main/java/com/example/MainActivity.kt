package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.simulation.LondonNetwork
import com.example.ui.CustomerScreenState
import com.example.ui.UberAirViewModel
import com.example.ui.components.AppPlatformMode
import com.example.ui.components.UberMapView
import com.example.ui.components.UberTopBar
import com.example.ui.screens.customer.ActivityScreen
import com.example.ui.screens.customer.BookingFlowScreen
import com.example.ui.screens.customer.HomeScreen
import com.example.ui.screens.customer.LiveTripScreen
import com.example.ui.screens.customer.ReserveScreen
import com.example.ui.screens.customer.RouteComparisonScreen
import com.example.ui.screens.customer.SafetySupportScreen
import com.example.ui.screens.operations.OperationsDeskScreen
import com.example.ui.theme.UberAirTheme
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberGrey900
import com.example.ui.theme.UberWhite

class MainActivity : ComponentActivity() {

    private val viewModel: UberAirViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            UberAirTheme {
                UberAirApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun UberAirApp(viewModel: UberAirViewModel) {
    val platformMode by viewModel.platformMode.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

    val origin by viewModel.origin.collectAsStateWithLifecycle()
    val destination by viewModel.destination.collectAsStateWithLifecycle()
    val selectedQuote by viewModel.selectedQuote.collectAsStateWithLifecycle()

    val activeTrip by viewModel.activeTrip.collectAsStateWithLifecycle()
    val aircraftList by viewModel.aircraftList.collectAsStateWithLifecycle()
    val vertiports by viewModel.vertiports.collectAsStateWithLifecycle()
    val systemMetrics by viewModel.systemMetrics.collectAsStateWithLifecycle()
    val disruptionMsg by viewModel.disruptionMessage.collectAsStateWithLifecycle()
    val savedTrips by viewModel.savedTripsFromDb.collectAsStateWithLifecycle()

    // BackHandler for secondary screens
    if (currentScreen != CustomerScreenState.HOME || platformMode != AppPlatformMode.CUSTOMER_APP) {
        BackHandler {
            if (platformMode == AppPlatformMode.OPERATIONS_DESK) {
                viewModel.setPlatformMode(AppPlatformMode.CUSTOMER_APP)
            } else {
                viewModel.navigateToScreen(CustomerScreenState.HOME)
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            UberTopBar(
                currentMode = platformMode,
                onModeChange = { viewModel.setPlatformMode(it) },
                activeFlightsCount = systemMetrics.activeFlights
            )
        },
        bottomBar = {
            if (platformMode == AppPlatformMode.CUSTOMER_APP && (currentScreen == CustomerScreenState.HOME || currentScreen == CustomerScreenState.ACTIVITY || currentScreen == CustomerScreenState.SAFETY_SUPPORT)) {
                NavigationBar(
                    containerColor = UberBlack,
                    contentColor = UberWhite,
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    NavigationBarItem(
                        selected = currentScreen == CustomerScreenState.HOME,
                        onClick = { viewModel.navigateToScreen(CustomerScreenState.HOME) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home", fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = UberBlack,
                            selectedTextColor = UberWhite,
                            indicatorColor = UberWhite,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_tab_home")
                    )

                    NavigationBarItem(
                        selected = currentScreen == CustomerScreenState.ACTIVITY,
                        onClick = { viewModel.navigateToScreen(CustomerScreenState.ACTIVITY) },
                        icon = { Icon(Icons.Default.History, contentDescription = "Activity") },
                        label = { Text("Activity", fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = UberBlack,
                            selectedTextColor = UberWhite,
                            indicatorColor = UberWhite,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_tab_activity")
                    )

                    NavigationBarItem(
                        selected = currentScreen == CustomerScreenState.SAFETY_SUPPORT,
                        onClick = { viewModel.navigateToScreen(CustomerScreenState.SAFETY_SUPPORT) },
                        icon = { Icon(Icons.Default.Security, contentDescription = "Safety") },
                        label = { Text("Safety", fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = UberBlack,
                            selectedTextColor = UberWhite,
                            indicatorColor = UberWhite,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_tab_safety")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(UberBlack)
        ) {
            AnimatedContent(
                targetState = Pair(platformMode, currentScreen),
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { (mode, screen) ->
                if (mode == AppPlatformMode.OPERATIONS_DESK) {
                    OperationsDeskScreen(
                        aircraftList = aircraftList,
                        vertiports = vertiports,
                        metrics = systemMetrics,
                        disruptionMsg = disruptionMsg,
                        onTriggerDisruption = { viewModel.triggerDisruption() },
                        onClearDisruption = { viewModel.clearDisruption() },
                        onTriggerSurge = { viewModel.triggerSurge() },
                        onResetDemand = { viewModel.resetDemand() }
                    )
                } else {
                    when (screen) {
                        CustomerScreenState.HOME -> {
                            Box(modifier = Modifier.fillMaxSize()) {
                                // Background Map View
                                UberMapView(
                                    vertiports = vertiports,
                                    aircraftList = aircraftList,
                                    activeTrip = activeTrip
                                )

                                HomeScreen(
                                    activeTrip = activeTrip,
                                    onDestinationSelect = { dest -> viewModel.selectDestination(dest) },
                                    onViewLiveTrip = { viewModel.navigateToScreen(CustomerScreenState.LIVE_TRIP) },
                                    onOpenReserve = { viewModel.navigateToScreen(CustomerScreenState.RESERVE) },
                                    onOpenActivity = { viewModel.navigateToScreen(CustomerScreenState.ACTIVITY) },
                                    onOpenSafety = { viewModel.navigateToScreen(CustomerScreenState.SAFETY_SUPPORT) }
                                )
                            }
                        }

                        CustomerScreenState.ROUTE_COMPARISON -> {
                            RouteComparisonScreen(
                                origin = origin,
                                destination = destination,
                                onSelectOption = { quote -> viewModel.selectPriceQuote(quote) },
                                onBack = { viewModel.navigateToScreen(CustomerScreenState.HOME) }
                            )
                        }

                        CustomerScreenState.BOOKING_FLOW -> {
                            if (selectedQuote != null) {
                                BookingFlowScreen(
                                    origin = origin,
                                    destination = destination,
                                    priceQuote = selectedQuote!!,
                                    onConfirmBooking = { passengers, baggage ->
                                        viewModel.confirmBooking(passengers, baggage)
                                    },
                                    onBack = { viewModel.navigateToScreen(CustomerScreenState.ROUTE_COMPARISON) }
                                )
                            }
                        }

                        CustomerScreenState.RESERVE -> {
                            ReserveScreen(
                                onConfirmReservation = { date, time, orig, dest ->
                                    viewModel.createReservation(date, time, orig, dest)
                                },
                                onBack = { viewModel.navigateToScreen(CustomerScreenState.HOME) }
                            )
                        }

                        CustomerScreenState.LIVE_TRIP -> {
                            if (activeTrip != null) {
                                LiveTripScreen(
                                    trip = activeTrip!!,
                                    onAdvanceStep = { viewModel.advanceTripStep() },
                                    onTriggerDisruption = { viewModel.triggerDisruption() },
                                    onCancelTrip = { viewModel.cancelActiveTrip() },
                                    onBack = { viewModel.navigateToScreen(CustomerScreenState.HOME) }
                                )
                            } else {
                                viewModel.navigateToScreen(CustomerScreenState.HOME)
                            }
                        }

                        CustomerScreenState.ACTIVITY -> {
                            ActivityScreen(
                                trips = savedTrips,
                                onBack = { viewModel.navigateToScreen(CustomerScreenState.HOME) }
                            )
                        }

                        CustomerScreenState.SAFETY_SUPPORT -> {
                            SafetySupportScreen(
                                onSubmitTicket = { cat, sub, desc -> viewModel.submitSupportTicket(cat, sub, desc) },
                                onBack = { viewModel.navigateToScreen(CustomerScreenState.HOME) }
                            )
                        }
                    }
                }
            }
        }
    }
}
