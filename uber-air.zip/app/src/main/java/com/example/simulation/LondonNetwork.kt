package com.example.simulation

import com.example.data.models.Aircraft
import com.example.data.models.AircraftStatus
import com.example.data.models.LegStatus
import com.example.data.models.LegType
import com.example.data.models.LocationPoint
import com.example.data.models.Pad
import com.example.data.models.PadStatus
import com.example.data.models.PriceQuote
import com.example.data.models.Trip
import com.example.data.models.TripLeg
import com.example.data.models.TripState
import com.example.data.models.Vertiport
import com.example.data.models.VertiportStatus
import java.util.UUID
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object LondonNetwork {

    // Common London Landmarks
    val MAYFAIR_HOME = LocationPoint(
        name = "Home (Mayfair)",
        address = "14 Berkeley Square, London W1J 6EB",
        lat = 51.5095,
        lng = -0.1465
    )

    val CANARY_WHARF_OFFICE = LocationPoint(
        name = "Canary Wharf Office",
        address = "1 Canada Square, London E14 5AA",
        code = "CYF",
        lat = 51.5048,
        lng = -0.0187
    )

    val HEATHROW_AIRPORT = LocationPoint(
        name = "Heathrow Airport (T5)",
        address = "Terminal 5, Hounslow TW6 2GA",
        code = "LHR",
        lat = 51.4700,
        lng = -0.4543
    )

    val LONDON_CITY_AIRPORT = LocationPoint(
        name = "London City Airport",
        address = "Royal Docks, London E16 2PX",
        code = "LCY",
        lat = 51.5052,
        lng = 0.0552
    )

    val KENSINGTON = LocationPoint(
        name = "Kensington High St",
        address = "Kensington, London W8 5SA",
        lat = 51.5010,
        lng = -0.1920
    )

    val CITY_OF_LONDON = LocationPoint(
        name = "Bank / City of London",
        address = "Threadneedle St, London EC2R 8AH",
        lat = 51.5134,
        lng = -0.0889
    )

    val DEFAULT_LOCATIONS = listOf(
        MAYFAIR_HOME,
        CANARY_WHARF_OFFICE,
        HEATHROW_AIRPORT,
        LONDON_CITY_AIRPORT,
        KENSINGTON,
        CITY_OF_LONDON
    )

    // Vertiport Network Nodes
    val VERTIPORTS = listOf(
        Vertiport(
            id = "vp_canary",
            name = "Canary Wharf Vertiport",
            code = "CYF",
            address = "South Dock Waterside, E14 4AS",
            lat = 51.5020,
            lng = -0.0210,
            totalPads = 4,
            availablePads = 3
        ),
        Vertiport(
            id = "vp_battersea",
            name = "Battersea Skyport",
            code = "BAT",
            address = "Bridges Court Rd, SW11 3BE",
            lat = 51.4691,
            lng = -0.1712,
            totalPads = 4,
            availablePads = 2
        ),
        Vertiport(
            id = "vp_heathrow",
            name = "Heathrow West Vertiport",
            code = "LHR",
            address = "Southern Perimeter Rd, TW6 3AQ",
            lat = 51.4660,
            lng = -0.4480,
            totalPads = 6,
            availablePads = 4
        ),
        Vertiport(
            id = "vp_city_airport",
            name = "London City Vertiport",
            code = "LCY",
            address = "King George V Docks, E16 2PX",
            lat = 51.5040,
            lng = 0.0580,
            totalPads = 4,
            availablePads = 3
        ),
        Vertiport(
            id = "vp_stratford",
            name = "Stratford East Vertiport",
            code = "STR",
            address = "Olympic Park East, E20 1GL",
            lat = 51.5430,
            lng = -0.0100,
            totalPads = 3,
            availablePads = 2
        ),
        Vertiport(
            id = "vp_west_hub",
            name = "Paddington Central Vertiport",
            code = "PAD",
            address = "Sheldon Square, W2 6PY",
            lat = 51.5190,
            lng = -0.1780,
            totalPads = 4,
            availablePads = 3
        )
    )

    // Find nearest vertiport to a coordinate
    fun findNearestVertiport(lat: Double, lng: Double): Vertiport {
        return VERTIPORTS.minByOrNull { calculateDistanceKm(lat, lng, it.lat, it.lng) }
            ?: VERTIPORTS.first()
    }

    fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0 // Radius of earth in km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    // Calculate Quotes for comparison screen
    fun calculateQuotes(
        origin: LocationPoint,
        destination: LocationPoint,
        passengerCount: Int
    ): List<PriceQuote> {
        val distKm = calculateDistanceKm(origin.lat, origin.lng, destination.lat, destination.lng)

        // Ground times & prices
        val uberXDuration = (distKm * 2.8 + 12).toInt().coerceAtLeast(15)
        val uberXPrice = (12.0 + distKm * 1.8 * passengerCount).coerceAtLeast(18.0)

        val uberComfortDuration = (uberXDuration * 0.92).toInt().coerceAtLeast(14)
        val uberComfortPrice = uberXPrice * 1.35

        val uberBlackDuration = (uberXDuration * 0.82).toInt().coerceAtLeast(12)
        val uberBlackPrice = uberXPrice * 1.85

        // Uber Air calculation
        val vpOrigin = findNearestVertiport(origin.lat, origin.lng)
        val vpDest = findNearestVertiport(destination.lat, destination.lng)

        val pickupDist = calculateDistanceKm(origin.lat, origin.lng, vpOrigin.lat, vpOrigin.lng)
        val airDist = calculateDistanceKm(vpOrigin.lat, vpOrigin.lng, vpDest.lat, vpDest.lng)
        val dropoffDist = calculateDistanceKm(vpDest.lat, vpDest.lng, destination.lat, destination.lng)

        val pickupTime = (pickupDist * 2.2 + 4).toInt().coerceAtLeast(5)
        val flightTime = (airDist / 3.0 + 4).toInt().coerceAtLeast(6)
        val dropoffTime = (dropoffDist * 2.2 + 3).toInt().coerceAtLeast(4)

        val totalAirDuration = pickupTime + flightTime + dropoffTime
        val timeSaved = (uberXDuration - totalAirDuration).coerceAtLeast(10)

        val pickupCost = 12.0 + pickupDist * 1.5
        val flightCost = 48.0 + airDist * 3.2
        val dropoffCost = 10.0 + dropoffDist * 1.5
        val totalAirPrice = (pickupCost + flightCost + dropoffCost) * passengerCount

        return listOf(
            PriceQuote(
                id = "quote_air",
                mode = "Uber Air",
                durationMinutes = totalAirDuration,
                price = (totalAirPrice * 100).toInt() / 100.0,
                timeSavedMinutes = timeSaved,
                description = "eVTOL Flight (${vpOrigin.code} → ${vpDest.code}) + Uber Black Ground Transfers",
                isAirOption = true,
                breakdownAir = (flightCost * passengerCount * 100).toInt() / 100.0,
                breakdownPickup = (pickupCost * passengerCount * 100).toInt() / 100.0,
                breakdownDropoff = (dropoffCost * passengerCount * 100).toInt() / 100.0,
                carbonSavedKg = 3.4 * passengerCount
            ),
            PriceQuote(
                id = "quote_black",
                mode = "Uber Black",
                durationMinutes = uberBlackDuration,
                price = (uberBlackPrice * 100).toInt() / 100.0,
                description = "Premium luxury vehicle with professional chauffeur",
                isAirOption = false
            ),
            PriceQuote(
                id = "quote_comfort",
                mode = "Uber Comfort",
                durationMinutes = uberComfortDuration,
                price = (uberComfortPrice * 100).toInt() / 100.0,
                description = "Top-rated drivers and newer, spacious cars",
                isAirOption = false
            ),
            PriceQuote(
                id = "quote_x",
                mode = "UberX",
                durationMinutes = uberXDuration,
                price = (uberXPrice * 100).toInt() / 100.0,
                description = "Affordable everyday rides",
                isAirOption = false
            )
        )
    }

    // Generate full multimodal trip
    fun createMultimodalTrip(
        origin: LocationPoint,
        destination: LocationPoint,
        passengerCount: Int = 1,
        baggageCount: Int = 1,
        scheduledTimeMillis: Long = System.currentTimeMillis()
    ): Trip {
        val vpOrigin = findNearestVertiport(origin.lat, origin.lng)
        val vpDest = findNearestVertiport(destination.lat, destination.lng)

        val pickupDist = calculateDistanceKm(origin.lat, origin.lng, vpOrigin.lat, vpOrigin.lng)
        val airDist = calculateDistanceKm(vpOrigin.lat, vpOrigin.lng, vpDest.lat, vpDest.lng)
        val dropoffDist = calculateDistanceKm(vpDest.lat, vpDest.lng, destination.lat, destination.lng)

        val pickupTime = (pickupDist * 2.2 + 4).toInt().coerceAtLeast(5)
        val flightTime = (airDist / 3.0 + 4).toInt().coerceAtLeast(6)
        val dropoffTime = (dropoffDist * 2.2 + 3).toInt().coerceAtLeast(4)

        val vpOriginLocation = LocationPoint(
            name = vpOrigin.name,
            address = vpOrigin.address,
            code = vpOrigin.code,
            lat = vpOrigin.lat,
            lng = vpOrigin.lng
        )

        val vpDestLocation = LocationPoint(
            name = vpDest.name,
            address = vpDest.address,
            code = vpDest.code,
            lat = vpDest.lat,
            lng = vpDest.lng
        )

        val leg1 = TripLeg(
            legOrder = 1,
            type = LegType.GROUND_PICKUP,
            modeName = "Uber Black",
            origin = origin,
            destination = vpOriginLocation,
            distanceKm = pickupDist,
            durationMinutes = pickupTime,
            price = 18.0,
            departureTime = "08:20",
            arrivalTime = "08:32",
            vehicleRegOrModel = "Tesla Model Y (UBER-842)",
            status = LegStatus.DISPATCHED
        )

        val leg2 = TripLeg(
            legOrder = 2,
            type = LegType.AIR_FLIGHT,
            modeName = "Uber Air",
            origin = vpOriginLocation,
            destination = vpDestLocation,
            distanceKm = airDist,
            durationMinutes = flightTime,
            price = 62.0,
            departureTime = "08:38",
            arrivalTime = "08:48",
            vehicleRegOrModel = "Joby S4 eVTOL (UA-204)",
            status = LegStatus.PENDING
        )

        val leg3 = TripLeg(
            legOrder = 3,
            type = LegType.GROUND_DROPOFF,
            modeName = "Uber Black",
            origin = vpDestLocation,
            destination = destination,
            distanceKm = dropoffDist,
            durationMinutes = dropoffTime,
            price = 14.0,
            departureTime = "08:50",
            arrivalTime = "08:58",
            vehicleRegOrModel = "Audi e-tron (UBER-991)",
            status = LegStatus.PENDING
        )

        val totalDuration = pickupTime + flightTime + dropoffTime + 6 // includes vertiport checkin
        val totalPrice = 94.0 * passengerCount

        return Trip(
            origin = origin,
            destination = destination,
            passengerCount = passengerCount,
            baggageCount = baggageCount,
            totalDurationMinutes = totalDuration,
            totalPrice = totalPrice,
            carbonSavedKg = 3.8 * passengerCount,
            currentLegIndex = 0,
            state = TripState.BOOKED,
            legs = listOf(leg1, leg2, leg3),
            scheduledTimeMillis = scheduledTimeMillis
        )
    }

    // Default synthetic fleet
    fun generateSyntheticAircraftFleet(): List<Aircraft> {
        val list = mutableListOf<Aircraft>()
        val regs = listOf(
            "UA-204", "UA-101", "UA-102", "UA-105", "UA-208",
            "UA-301", "UA-305", "UA-402", "UA-501", "UA-602",
            "UA-701", "UA-802"
        )
        val pilots = listOf(
            "Capt. Sarah Jenkins", "Capt. Marcus Vance", "Capt. Elena Rostova",
            "Capt. David Kim", "Capt. James Sterling", "Capt. Amanda Chen"
        )

        VERTIPORTS.forEachIndexed { index, vp ->
            val reg1 = regs[index % regs.size]
            val reg2 = regs[(index + 6) % regs.size]

            list.add(
                Aircraft(
                    id = "ac_$index" + "_a",
                    registration = reg1,
                    batteryPercentage = (70..100).random(),
                    status = if (index % 3 == 0) AircraftStatus.CHARGING else AircraftStatus.AVAILABLE,
                    currentLat = vp.lat + (0.001 * (index % 2)),
                    currentLng = vp.lng + (0.001 * (index % 3)),
                    pilotName = pilots[index % pilots.size],
                    vertiportId = vp.id
                )
            )

            list.add(
                Aircraft(
                    id = "ac_$index" + "_b",
                    registration = reg2,
                    batteryPercentage = (45..90).random(),
                    status = AircraftStatus.AIRBORNE,
                    currentLat = vp.lat + 0.015,
                    currentLng = vp.lng + 0.02,
                    targetLat = VERTIPORTS[(index + 1) % VERTIPORTS.size].lat,
                    targetLng = VERTIPORTS[(index + 1) % VERTIPORTS.size].lng,
                    speedMph = 145,
                    altitudeFt = 1200,
                    pilotName = pilots[(index + 2) % pilots.size]
                )
            )
        }
        return list
    }
}
