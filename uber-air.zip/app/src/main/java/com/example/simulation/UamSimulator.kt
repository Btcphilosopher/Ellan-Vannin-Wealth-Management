package com.example.simulation

import com.example.data.models.Aircraft
import com.example.data.models.AircraftStatus
import com.example.data.models.Driver
import com.example.data.models.LegStatus
import com.example.data.models.Trip
import com.example.data.models.TripState
import com.example.data.models.Vertiport
import com.example.data.models.VertiportStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.atan2

class UamSimulator {

    private val scope = CoroutineScope(Dispatchers.Default)
    private var simJob: Job? = null

    // State Flows
    private val _aircraftList = MutableStateFlow<List<Aircraft>>(emptyList())
    val aircraftList: StateFlow<List<Aircraft>> = _aircraftList.asStateFlow()

    private val _vertiports = MutableStateFlow<List<Vertiport>>(LondonNetwork.VERTIPORTS)
    val vertiports: StateFlow<List<Vertiport>> = _vertiports.asStateFlow()

    private val _drivers = MutableStateFlow<List<Driver>>(emptyList())
    val drivers: StateFlow<List<Driver>> = _drivers.asStateFlow()

    private val _activeTrip = MutableStateFlow<Trip?>(null)
    val activeTrip: StateFlow<Trip?> = _activeTrip.asStateFlow()

    private val _disruptionMessage = MutableStateFlow<String?>(null)
    val disruptionMessage: StateFlow<String?> = _disruptionMessage.asStateFlow()

    private val _systemMetrics = MutableStateFlow(
        SystemMetrics(
            activeFlights = 27,
            availableFleet = 41,
            vertiportCapacityPercent = 68,
            tripsCompletedToday = 1284,
            delaysCount = 2
        )
    )
    val systemMetrics: StateFlow<SystemMetrics> = _systemMetrics.asStateFlow()

    data class SystemMetrics(
        val activeFlights: Int,
        val availableFleet: Int,
        val vertiportCapacityPercent: Int,
        val tripsCompletedToday: Int,
        val delaysCount: Int
    )

    init {
        // Initialize synthetic state
        _aircraftList.value = LondonNetwork.generateSyntheticAircraftFleet()
        _drivers.value = listOf(
            Driver("d1", "Michael Sterling", "Tesla Model Y", "UBER-842", 4.96, 51.5080, -0.1400),
            Driver("d2", "Amara Vance", "Mercedes EQE", "UBER-991", 4.98, 51.5030, -0.0250),
            Driver("d3", "David Chen", "BMW i7", "UBER-118", 4.94, 51.4680, -0.4500)
        )
        startSimulationLoop()
    }

    fun setActiveTrip(trip: Trip?) {
        _activeTrip.value = trip
    }

    fun startSimulationLoop() {
        simJob?.cancel()
        simJob = scope.launch {
            while (true) {
                delay(1000)
                tickSimulation()
            }
        }
    }

    private fun tickSimulation() {
        // 1. Move airborne aircraft
        _aircraftList.value = _aircraftList.value.map { ac ->
            if (ac.status == AircraftStatus.AIRBORNE) {
                val dist = LondonNetwork.calculateDistanceKm(ac.currentLat, ac.currentLng, ac.targetLat, ac.targetLng)
                if (dist < 0.5) {
                    // Landed
                    ac.copy(
                        status = AircraftStatus.LANDED,
                        currentLat = ac.targetLat,
                        currentLng = ac.targetLng,
                        speedMph = 0,
                        altitudeFt = 0
                    )
                } else {
                    // Move towards target
                    val stepRatio = 0.04
                    val newLat = ac.currentLat + (ac.targetLat - ac.currentLat) * stepRatio
                    val newLng = ac.currentLng + (ac.targetLng - ac.currentLng) * stepRatio
                    val heading = Math.toDegrees(atan2(ac.targetLng - ac.currentLng, ac.targetLat - ac.currentLat)).toFloat()
                    val newBattery = (ac.batteryPercentage - 1).coerceAtLeast(15)

                    ac.copy(
                        currentLat = newLat,
                        currentLng = newLng,
                        heading = heading,
                        speedMph = 145,
                        altitudeFt = 1200,
                        batteryPercentage = newBattery
                    )
                }
            } else if (ac.status == AircraftStatus.CHARGING) {
                val newBattery = (ac.batteryPercentage + 2).coerceAtMost(100)
                val newStatus = if (newBattery >= 100) AircraftStatus.AVAILABLE else AircraftStatus.CHARGING
                ac.copy(batteryPercentage = newBattery, status = newStatus)
            } else {
                ac
            }
        }

        // 2. Advance active trip state machine if active
        val currentTrip = _activeTrip.value
        if (currentTrip != null && currentTrip.state != TripState.COMPLETED && currentTrip.state != TripState.CANCELLED) {
            advanceTripStateMachine(currentTrip)
        }
    }

    fun advanceTripStateMachine(trip: Trip) {
        val nextState = when (trip.state) {
            TripState.BOOKED -> TripState.GROUND_DISPATCHED
            TripState.GROUND_DISPATCHED -> TripState.GROUND_ARRIVING
            TripState.GROUND_ARRIVING -> TripState.AT_VERTIPORT
            TripState.AT_VERTIPORT -> TripState.CHECKED_IN
            TripState.CHECKED_IN -> TripState.BOARDING
            TripState.BOARDING -> TripState.DEPARTED
            TripState.DEPARTED -> TripState.AIRBORNE
            TripState.AIRBORNE -> TripState.APPROACHING
            TripState.APPROACHING -> TripState.LANDED
            TripState.LANDED -> TripState.GROUND_DROPOFF_DISPATCHED
            TripState.GROUND_DROPOFF_DISPATCHED -> TripState.COMPLETED
            else -> trip.state
        }

        val updatedLegs = trip.legs.mapIndexed { idx, leg ->
            when (nextState) {
                TripState.GROUND_DISPATCHED, TripState.GROUND_ARRIVING -> {
                    if (idx == 0) leg.copy(status = LegStatus.IN_PROGRESS) else leg
                }
                TripState.AT_VERTIPORT, TripState.CHECKED_IN, TripState.BOARDING -> {
                    if (idx == 0) leg.copy(status = LegStatus.COMPLETED)
                    else if (idx == 1) leg.copy(status = LegStatus.DISPATCHED)
                    else leg
                }
                TripState.DEPARTED, TripState.AIRBORNE, TripState.APPROACHING -> {
                    if (idx <= 0) leg.copy(status = LegStatus.COMPLETED)
                    else if (idx == 1) leg.copy(status = LegStatus.IN_PROGRESS)
                    else leg
                }
                TripState.LANDED, TripState.GROUND_DROPOFF_DISPATCHED -> {
                    if (idx <= 1) leg.copy(status = LegStatus.COMPLETED)
                    else if (idx == 2) leg.copy(status = LegStatus.IN_PROGRESS)
                    else leg
                }
                TripState.COMPLETED -> leg.copy(status = LegStatus.COMPLETED)
                else -> leg
            }
        }

        val currentLegIdx = when (nextState) {
            TripState.GROUND_DISPATCHED, TripState.GROUND_ARRIVING -> 0
            TripState.AT_VERTIPORT, TripState.CHECKED_IN, TripState.BOARDING, TripState.DEPARTED, TripState.AIRBORNE, TripState.APPROACHING -> 1
            TripState.LANDED, TripState.GROUND_DROPOFF_DISPATCHED, TripState.COMPLETED -> 2
            else -> 0
        }

        _activeTrip.value = trip.copy(
            state = nextState,
            currentLegIndex = currentLegIdx,
            legs = updatedLegs
        )
    }

    fun triggerDisruptionScenario() {
        val trip = _activeTrip.value
        val msg = "NOTICE: Canary Wharf Vertiport Pad 2 experiencing heavy congestion. Flight route automatically redirected via Battersea Skyport."
        _disruptionMessage.value = msg

        if (trip != null) {
            _activeTrip.value = trip.copy(
                state = TripState.DISRUPTED,
                disruptionNotice = msg
            )
        }

        _systemMetrics.value = _systemMetrics.value.copy(delaysCount = _systemMetrics.value.delaysCount + 1)
    }

    fun clearDisruption() {
        _disruptionMessage.value = null
        val trip = _activeTrip.value
        if (trip != null && trip.state == TripState.DISRUPTED) {
            _activeTrip.value = trip.copy(
                state = TripState.AIRBORNE,
                disruptionNotice = null
            )
        }
    }

    fun triggerPeakDemandSurge() {
        _systemMetrics.value = SystemMetrics(
            activeFlights = 38,
            availableFleet = 18,
            vertiportCapacityPercent = 92,
            tripsCompletedToday = 1840,
            delaysCount = 4
        )
    }

    fun resetDemand() {
        _systemMetrics.value = SystemMetrics(
            activeFlights = 27,
            availableFleet = 41,
            vertiportCapacityPercent = 68,
            tripsCompletedToday = 1284,
            delaysCount = 2
        )
    }
}
