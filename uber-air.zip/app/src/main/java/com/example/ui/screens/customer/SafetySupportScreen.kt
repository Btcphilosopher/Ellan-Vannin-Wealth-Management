package com.example.ui.screens.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.models.TicketCategory
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberBlue
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberGrey900
import com.example.ui.theme.UberWhite

@Composable
fun SafetySupportScreen(
    onSubmitTicket: (category: TicketCategory, subject: String, desc: String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var subjectInput by remember { mutableStateOf("") }
    var descInput by remember { mutableStateOf("") }
    var ticketSubmittedMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UberBlack)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("safety_support_screen")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("safety_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = UberWhite
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Safety & Support",
                    style = MaterialTheme.typography.titleLarge,
                    color = UberWhite,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Pilot details, share trip & support tickets",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Safety Features Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = UberGrey900),
            border = androidx.compose.foundation.BorderStroke(1.dp, UberGrey800)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = "Safety", tint = UberBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Uber Air Safety Centre", style = MaterialTheme.typography.titleMedium, color = UberWhite, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("ASSIGNED PILOT", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Text("Capt. Sarah Jenkins", style = MaterialTheme.typography.titleMedium, color = UberWhite)
                    }
                    Column {
                        Text("AIRCRAFT REG", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Text("UA-204 (Joby S4)", style = MaterialTheme.typography.titleMedium, color = UberWhite)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { /* Share URL */ },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = UberGrey800, contentColor = UberWhite)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Share Live Trip with Emergency Contacts")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Support Ticket Submission Form
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = UberGrey900),
            border = androidx.compose.foundation.BorderStroke(1.dp, UberGrey800)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SupportAgent, contentDescription = "Support", tint = UberWhite)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Contact 24/7 Air Operations Support", style = MaterialTheme.typography.titleMedium, color = UberWhite, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = subjectInput,
                    onValueChange = { subjectInput = it },
                    label = { Text("Subject / Issue") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("support_subject_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = UberWhite,
                        unfocusedTextColor = UberWhite,
                        focusedBorderColor = UberWhite,
                        unfocusedBorderColor = UberGrey800
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = descInput,
                    onValueChange = { descInput = it },
                    label = { Text("Describe what happened...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .testTag("support_desc_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = UberWhite,
                        unfocusedTextColor = UberWhite,
                        focusedBorderColor = UberWhite,
                        unfocusedBorderColor = UberGrey800
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (subjectInput.isNotBlank()) {
                            onSubmitTicket(TicketCategory.SAFETY, subjectInput, descInput)
                            ticketSubmittedMsg = "Support ticket submitted! Ticket #TKT-${System.currentTimeMillis().toString().takeLast(6)}"
                            subjectInput = ""
                            descInput = ""
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("submit_ticket_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = UberWhite, contentColor = UberBlack)
                ) {
                    Text("Submit Support Ticket", fontWeight = FontWeight.Bold)
                }

                if (ticketSubmittedMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(ticketSubmittedMsg!!, color = UberBlue, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
