package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val UberDarkColorScheme = darkColorScheme(
    primary = UberWhite,
    onPrimary = UberBlack,
    primaryContainer = UberGrey800,
    onPrimaryContainer = UberWhite,
    secondary = UberGrey200,
    onSecondary = UberBlack,
    background = UberBlack,
    onBackground = UberWhite,
    surface = UberGrey900,
    onSurface = UberWhite,
    surfaceVariant = UberGrey800,
    onSurfaceVariant = UberGrey200,
    outline = UberGrey700,
    error = UberRed,
    onError = UberWhite
)

private val UberLightColorScheme = lightColorScheme(
    primary = UberBlack,
    onPrimary = UberWhite,
    primaryContainer = UberGrey100,
    onPrimaryContainer = UberBlack,
    secondary = UberGrey700,
    onSecondary = UberWhite,
    background = UberWhite,
    onBackground = UberBlack,
    surface = UberOffWhite,
    onSurface = UberBlack,
    surfaceVariant = UberGrey100,
    onSurfaceVariant = UberGrey700,
    outline = UberGrey200,
    error = UberRed,
    onError = UberWhite
)

@Composable
fun UberAirTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) UberDarkColorScheme else UberLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
