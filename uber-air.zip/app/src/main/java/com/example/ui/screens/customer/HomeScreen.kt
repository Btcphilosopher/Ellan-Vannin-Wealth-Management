package com.example.ui.screens.customer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalAirport
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.LocationPoint
import com.example.data.models.Trip
import com.example.data.models.TripState
import com.example.simulation.LondonNetwork
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberBlue
import com.example.ui.theme.UberGreen
import com.example.ui.theme.UberGrey100
import com.example.ui.theme.UberGrey200
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberGrey900
import com.example.ui.theme.UberOffWhite
import com.example.ui.theme.UberWhite

@Composable
fun HomeScreen(
    activeTrip: Trip?,
    onDestinationSelect: (LocationPoint) -> Unit,
    onViewLiveTrip: () -> Unit,
    onOpenReserve: () -> Unit,
    onOpenActivity: () -> Unit,
    onOpenSafety: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Text(
                text = "Good morning",
                style = MaterialTheme.typography.titleMedium,
                color = UberWhite.copy(alpha = 0.8f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Main "Where to?" Search Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onDestinationSelect(LondonNetwork.CANARY_WHARF_OFFICE) }
                    .testTag("where_to_card"),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = UberWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = UberBlack,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "Where to?",
                        style = MaterialTheme.typography.headlineLarge,
                        color = UberBlack,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Row(
                        modifier = Modifier
                            .background(UberGrey100, shape = RoundedCornerShape(16.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Air,
                            contentDescription = "Air Mode",
                            tint = UberBlack,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Now",
                            style = MaterialTheme.typography.labelLarge,
                            color = UberBlack,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Shortcut Chips Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ShortcutChip(
                    icon = Icons.Default.Work,
                    label = "Work",
                    onClick = { onDestinationSelect(LondonNetwork.CANARY_WHARF_OFFICE) },
                    testTag = "shortcut_work"
                )
                ShortcutChip(
                    icon = Icons.Default.LocalAirport,
                    label = "Airport",
                    onClick = { onDestinationSelect(LondonNetwork.HEATHROW_AIRPORT) },
                    testTag = "shortcut_airport"
                )
                ShortcutChip(
                    icon = Icons.Default.FlightTakeoff,
                    label = "Reserve",
                    onClick = onOpenReserve,
                    testTag = "shortcut_reserve"
                )
                ShortcutChip(
                    icon = Icons.Default.History,
                    label = "Recent",
                    onClick = onOpenActivity,
                    testTag = "shortcut_recent"
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Active Trip Banner Card if present
            if (activeTrip != null && activeTrip.state != TripState.COMPLETED && activeTrip.state != TripState.CANCELLED) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .clickable { onViewLiveTrip() }
                        .testTag("active_trip_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = UberWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(UberGreen, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "LIVE UBER AIR TRIP",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = UberBlack,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = activeTrip.state.name.replace("_", " "),
                                style = MaterialTheme.typography.labelSmall,
                                color = UberBlue,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "${activeTrip.origin.name} → ${activeTrip.destination.name}",
                            style = MaterialTheme.typography.titleLarge,
                            color = UberBlack,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "ETA: ${activeTrip.totalDurationMinutes} min • eVTOL Flight + Ground Transfer",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = onViewLiveTrip,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("view_live_trip_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = UberBlack, contentColor = UberWhite),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("View Trip Details & Flight Tracker", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShortcutChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(8.dp)
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .background(UberGrey900, CircleShape)
                .border(1.dp, UberGrey800, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = UberWhite,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = UberWhite,
            fontWeight = FontWeight.Medium
        )
    }
}
