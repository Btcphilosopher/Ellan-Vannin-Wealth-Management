package com.example.ui.screens.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.LocationPoint
import com.example.data.models.PriceQuote
import com.example.simulation.LondonNetwork
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberBlue
import com.example.ui.theme.UberGreen
import com.example.ui.theme.UberGrey100
import com.example.ui.theme.UberGrey200
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberGrey900
import com.example.ui.theme.UberWhite

@Composable
fun RouteComparisonScreen(
    origin: LocationPoint,
    destination: LocationPoint,
    passengerCount: Int = 1,
    onSelectOption: (PriceQuote) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val quotes = remember(origin, destination, passengerCount) {
        LondonNetwork.calculateQuotes(origin, destination, passengerCount)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UberBlack)
            .padding(16.dp)
            .testTag("route_comparison_screen")
    ) {
        // Header Nav
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = UberWhite
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "${origin.name} → ${destination.name}",
                    style = MaterialTheme.typography.titleLarge,
                    color = UberWhite,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Multimodal Route Comparison • $passengerCount Rider",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Options List
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(quotes) { quote ->
                QuoteCard(
                    quote = quote,
                    onClick = { onSelectOption(quote) }
                )
            }
        }
    }
}

@Composable
fun QuoteCard(
    quote: PriceQuote,
    onClick: () -> Unit
) {
    val isAir = quote.isAirOption

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("quote_card_${quote.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isAir) UberWhite else UberGrey900
        ),
        border = if (isAir) null else androidx.compose.foundation.BorderStroke(1.dp, UberGrey800),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isAir) 8.dp else 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Air Highlight Tag
            if (isAir) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .background(UberBlack, shape = RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Air,
                            contentDescription = "Uber Air",
                            tint = UberWhite,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "UBER AIR",
                            style = MaterialTheme.typography.labelSmall,
                            color = UberWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        modifier = Modifier
                            .background(UberGreen, shape = RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "SAVE ${quote.timeSavedMinutes} MIN",
                            style = MaterialTheme.typography.labelSmall,
                            color = UberWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }

            // Main Info Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isAir) Icons.Default.FlightTakeoff else Icons.Default.DirectionsCar,
                        contentDescription = quote.mode,
                        tint = if (isAir) UberBlack else UberWhite,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = quote.mode,
                            style = MaterialTheme.typography.titleLarge,
                            color = if (isAir) UberBlack else UberWhite,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = quote.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isAir) Color.DarkGray else Color.Gray
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "£${String.format("%.2f", quote.price)}",
                        style = MaterialTheme.typography.titleLarge,
                        color = if (isAir) UberBlack else UberWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${quote.durationMinutes} min",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isAir) UberBlack else UberWhite,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (isAir) {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("select_uber_air_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = UberBlack, contentColor = UberWhite),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Select Uber Air", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
