package com.example.ui.screens.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberGrey900
import com.example.ui.theme.UberWhite

@Composable
fun ReserveScreen(
    onConfirmReservation: (date: String, time: String, origin: String, dest: String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedDate by remember { mutableStateOf("Tomorrow (Fri, Sep 26)") }
    var selectedTime by remember { mutableStateOf("07:30 AM") }
    var originInput by remember { mutableStateOf("Mayfair Home") }
    var destInput by remember { mutableStateOf("Heathrow Airport T5") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UberBlack)
            .padding(16.dp)
            .testTag("reserve_screen")
    ) {
        // Nav Top
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("reserve_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = UberWhite
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Reserve Uber Air",
                    style = MaterialTheme.typography.titleLarge,
                    color = UberWhite,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Schedule up to 90 days in advance",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = UberGrey900),
            border = androidx.compose.foundation.BorderStroke(1.dp, UberGrey800)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                OutlinedTextField(
                    value = originInput,
                    onValueChange = { originInput = it },
                    label = { Text("Pickup Location") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reserve_origin_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = UberWhite,
                        unfocusedTextColor = UberWhite,
                        focusedBorderColor = UberWhite,
                        unfocusedBorderColor = UberGrey800
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = destInput,
                    onValueChange = { destInput = it },
                    label = { Text("Destination") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reserve_dest_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = UberWhite,
                        unfocusedTextColor = UberWhite,
                        focusedBorderColor = UberWhite,
                        unfocusedBorderColor = UberGrey800
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Date Selection Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = "Date", tint = UberWhite)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Date", style = MaterialTheme.typography.titleMedium, color = UberWhite)
                    }
                    Text(
                        text = selectedDate,
                        style = MaterialTheme.typography.titleMedium,
                        color = UberWhite,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Time Selection Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Schedule, contentDescription = "Time", tint = UberWhite)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Time", style = MaterialTheme.typography.titleMedium, color = UberWhite)
                    }
                    Text(
                        text = selectedTime,
                        style = MaterialTheme.typography.titleMedium,
                        color = UberWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = { onConfirmReservation(selectedDate, selectedTime, originInput, destInput) },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("confirm_reservation_button"),
            colors = ButtonDefaults.buttonColors(containerColor = UberWhite, contentColor = UberBlack),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("Confirm Reserve Uber Air", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}
