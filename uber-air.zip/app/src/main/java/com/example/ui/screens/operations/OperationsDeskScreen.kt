package com.example.ui.screens.operations

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Aircraft
import com.example.data.models.AircraftStatus
import com.example.data.models.Vertiport
import com.example.simulation.UamSimulator
import com.example.ui.components.UberMapView
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberBlue
import com.example.ui.theme.UberGreen
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberGrey900
import com.example.ui.theme.UberRed
import com.example.ui.theme.UberWhite

enum class OpsTab {
    LIVE_MAP, FLEET_MANAGER, VERTIPORTS, SCENARIOS
}

@Composable
fun OperationsDeskScreen(
    aircraftList: List<Aircraft>,
    vertiports: List<Vertiport>,
    metrics: UamSimulator.SystemMetrics,
    disruptionMsg: String?,
    onTriggerDisruption: () -> Unit,
    onClearDisruption: () -> Unit,
    onTriggerSurge: () -> Unit,
    onResetDemand: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(OpsTab.LIVE_MAP) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UberBlack)
            .padding(16.dp)
            .testTag("operations_desk_screen")
    ) {
        // Operations Title Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "UBER AIR OPERATIONS CONTROL",
                    style = MaterialTheme.typography.titleMedium,
                    color = UberWhite,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "London Urban Air Mobility Dispatch Engine",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // System Metrics Banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricPill("ACTIVE FLIGHTS", "${metrics.activeFlights}", UberBlue, Modifier.weight(1f))
            MetricPill("FLEET READY", "${metrics.availableFleet}", UberGreen, Modifier.weight(1f))
            MetricPill("VERTIPORT CAP", "${metrics.vertiportCapacityPercent}%", UberWhite, Modifier.weight(1f))
            MetricPill("TRIPS TODAY", "${metrics.tripsCompletedToday}", UberWhite, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Ops Sub-Tabs Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(UberGrey900, RoundedCornerShape(12.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OpsTabItem("Network Map", OpsTab.LIVE_MAP, selectedTab) { selectedTab = it }
            OpsTabItem("Fleet (${aircraftList.size})", OpsTab.FLEET_MANAGER, selectedTab) { selectedTab = it }
            OpsTabItem("Vertiports (${vertiports.size})", OpsTab.VERTIPORTS, selectedTab) { selectedTab = it }
            OpsTabItem("Scenarios", OpsTab.SCENARIOS, selectedTab) { selectedTab = it }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Content Area
        Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
                OpsTab.LIVE_MAP -> {
                    UberMapView(
                        vertiports = vertiports,
                        aircraftList = aircraftList,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(16.dp))
                    )
                }

                OpsTab.FLEET_MANAGER -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(aircraftList) { ac ->
                            AircraftRowItem(ac = ac)
                        }
                    }
                }

                OpsTab.VERTIPORTS -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(vertiports) { vp ->
                            VertiportRowItem(vp = vp)
                        }
                    }
                }

                OpsTab.SCENARIOS -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = UberGrey900)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Disruption & Rerouting Simulator", style = MaterialTheme.typography.titleMedium, color = UberWhite, fontWeight = FontWeight.Bold)
                                Text("Simulate vertiport pad congestion to trigger automated multimodal trip rerouting.", color = Color.Gray)

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = onTriggerDisruption,
                                        colors = ButtonDefaults.buttonColors(containerColor = UberRed, contentColor = UberWhite),
                                        modifier = Modifier.testTag("ops_trigger_disruption_button")
                                    ) {
                                        Text("Trigger Reroute Scenario")
                                    }

                                    OutlinedButton(
                                        onClick = onClearDisruption,
                                        modifier = Modifier.testTag("ops_clear_disruption_button")
                                    ) {
                                        Text("Clear Disruption", color = UberWhite)
                                    }
                                }
                            }
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = UberGrey900)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Demand Surge Simulator", style = MaterialTheme.typography.titleMedium, color = UberWhite, fontWeight = FontWeight.Bold)
                                Text("Simulate Friday 17:30 peak commute demand spike across London network.", color = Color.Gray)

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = onTriggerSurge,
                                        colors = ButtonDefaults.buttonColors(containerColor = UberWhite, contentColor = UberBlack),
                                        modifier = Modifier.testTag("ops_trigger_surge_button")
                                    ) {
                                        Text("Trigger Peak Surge")
                                    }

                                    OutlinedButton(
                                        onClick = onResetDemand,
                                        modifier = Modifier.testTag("ops_reset_demand_button")
                                    ) {
                                        Text("Reset Demand", color = UberWhite)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricPill(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(UberGrey900, RoundedCornerShape(12.dp))
            .border(1.dp, UberGrey800, RoundedCornerShape(12.dp))
            .padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium, color = color, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 9.sp)
        }
    }
}

@Composable
fun OpsTabItem(label: String, tab: OpsTab, currentTab: OpsTab, onSelect: (OpsTab) -> Unit) {
    val selected = tab == currentTab
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) UberWhite else Color.Transparent)
            .clickable { onSelect(tab) }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) UberBlack else UberWhite,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun AircraftRowItem(ac: Aircraft) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = UberGrey900)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.FlightTakeoff, contentDescription = ac.registration, tint = UberWhite)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(ac.registration, style = MaterialTheme.typography.titleMedium, color = UberWhite, fontWeight = FontWeight.Bold)
                    Text("${ac.model} • Pilot: ${ac.pilotName}", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = ac.status.name,
                    style = MaterialTheme.typography.labelSmall,
                    color = when (ac.status) {
                        AircraftStatus.AIRBORNE -> UberBlue
                        AircraftStatus.CHARGING -> Color(0xFFFFC043)
                        AircraftStatus.AVAILABLE -> UberGreen
                        else -> UberWhite
                    },
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Battery: ${ac.batteryPercentage}%",
                    style = MaterialTheme.typography.bodyMedium,
                    color = UberWhite
                )
            }
        }
    }
}

@Composable
fun VertiportRowItem(vp: Vertiport) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = UberGrey900)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = vp.name, tint = UberBlue)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("${vp.name} (${vp.code})", style = MaterialTheme.typography.titleMedium, color = UberWhite, fontWeight = FontWeight.Bold)
                    Text(vp.address, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${vp.availablePads} / ${vp.totalPads} Pads Free",
                    style = MaterialTheme.typography.labelMedium,
                    color = UberWhite,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = vp.status.name,
                    style = MaterialTheme.typography.labelSmall,
                    color = UberGreen
                )
            }
        }
    }
}
