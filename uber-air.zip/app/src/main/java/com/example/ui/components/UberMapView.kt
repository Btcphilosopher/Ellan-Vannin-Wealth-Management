package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.models.Aircraft
import com.example.data.models.LocationPoint
import com.example.data.models.Trip
import com.example.data.models.Vertiport
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberBlue
import com.example.ui.theme.UberGreen
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberGrey900
import com.example.ui.theme.UberWhite
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun UberMapView(
    modifier: Modifier = Modifier,
    vertiports: List<Vertiport>,
    aircraftList: List<Aircraft>,
    activeTrip: Trip? = null,
    selectedLocation: LocationPoint? = null,
    onVertiportClick: (Vertiport) -> Unit = {}
) {
    // Map view bounds around London (Lat: 51.45 to 51.56, Lng: -0.48 to 0.08)
    val minLat = 51.440
    val maxLat = 51.560
    val minLng = -0.480
    val maxLng = 0.080

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    // Map themes
    val mapBgColor = UberBlack
    val riverColor = Color(0xFF14243B)
    val roadColor = Color(0xFF1A1A1A)
    val airCorridorColor = Color(0x66276EF1)
    val activeRouteColor = UberWhite

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(mapBgColor)
            .testTag("uber_map_view")
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.8f, 3.5f)
                    offsetX += pan.x
                    offsetY += pan.y
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasW = size.width
            val canvasH = size.height

            // Lat/Lng conversion helpers
            fun latLngToOffset(lat: Double, lng: Double): Offset {
                val normX = ((lng - minLng) / (maxLng - minLng)).toFloat()
                val normY = (1f - ((lat - minLat) / (maxLat - minLat))).toFloat()

                val x = normX * canvasW * scale + offsetX
                val y = normY * canvasH * scale + offsetY
                return Offset(x, y)
            }

            // 1. Draw River Thames curve
            val thamesPath = Path().apply {
                val p1 = latLngToOffset(51.480, -0.450)
                val p2 = latLngToOffset(51.465, -0.220)
                val p3 = latLngToOffset(51.502, -0.120)
                val p4 = latLngToOffset(51.504, -0.010)
                val p5 = latLngToOffset(51.505, 0.070)

                moveTo(p1.x, p1.y)
                quadraticTo(p2.x, p2.y, p3.x, p3.y)
                quadraticTo(p4.x, p4.y, p5.x, p5.y)
            }
            drawPath(
                path = thamesPath,
                color = riverColor,
                style = Stroke(width = 28f * scale, cap = StrokeCap.Round)
            )

            // 2. Draw Major Road Network
            val road1 = Path().apply {
                val p1 = latLngToOffset(51.515, -0.400)
                val p2 = latLngToOffset(51.512, -0.080)
                val p3 = latLngToOffset(51.540, 0.050)
                moveTo(p1.x, p1.y)
                lineTo(p2.x, p2.y)
                lineTo(p3.x, p3.y)
            }
            drawPath(road1, color = roadColor, style = Stroke(width = 8f * scale))

            val road2 = Path().apply {
                val p1 = latLngToOffset(51.450, -0.180)
                val p2 = latLngToOffset(51.512, -0.080)
                moveTo(p1.x, p1.y)
                lineTo(p2.x, p2.y)
            }
            drawPath(road2, color = roadColor, style = Stroke(width = 6f * scale))

            // 3. Draw Air Corridor Grid
            for (i in 0 until vertiports.size) {
                for (j in i + 1 until vertiports.size) {
                    val vpA = latLngToOffset(vertiports[i].lat, vertiports[i].lng)
                    val vpB = latLngToOffset(vertiports[j].lat, vertiports[j].lng)

                    drawLine(
                        color = airCorridorColor,
                        start = vpA,
                        end = vpB,
                        strokeWidth = 3f * scale,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f)
                    )
                }
            }

            // 4. Draw Active Multimodal Route if present
            if (activeTrip != null) {
                val originPt = latLngToOffset(activeTrip.origin.lat, activeTrip.origin.lng)
                val destPt = latLngToOffset(activeTrip.destination.lat, activeTrip.destination.lng)

                val airLeg = activeTrip.legs.firstOrNull { it.type.name == "AIR_FLIGHT" }
                if (airLeg != null) {
                    val vpOriginPt = latLngToOffset(airLeg.origin.lat, airLeg.origin.lng)
                    val vpDestPt = latLngToOffset(airLeg.destination.lat, airLeg.destination.lng)

                    // Ground leg 1
                    drawLine(
                        color = Color.Gray,
                        start = originPt,
                        end = vpOriginPt,
                        strokeWidth = 6f * scale,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )

                    // Air Leg
                    drawLine(
                        color = activeRouteColor,
                        start = vpOriginPt,
                        end = vpDestPt,
                        strokeWidth = 8f * scale
                    )

                    // Ground leg 2
                    drawLine(
                        color = Color.Gray,
                        start = vpDestPt,
                        end = destPt,
                        strokeWidth = 6f * scale,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                }

                // Draw Origin / Destination Markers
                drawCircle(color = UberWhite, radius = 10f * scale, center = originPt)
                drawCircle(color = UberBlack, radius = 6f * scale, center = originPt)

                drawCircle(color = UberWhite, radius = 12f * scale, center = destPt)
                drawCircle(color = UberGreen, radius = 7f * scale, center = destPt)
            }

            // 5. Draw Vertiport Hub Badges
            vertiports.forEach { vp ->
                val pt = latLngToOffset(vp.lat, vp.lng)

                // Outer pulsing ring
                drawCircle(color = UberBlue.copy(alpha = 0.25f), radius = 22f * scale, center = pt)
                drawCircle(color = UberGrey900, radius = 14f * scale, center = pt)
                drawCircle(color = UberWhite, radius = 14f * scale, center = pt, style = Stroke(width = 3f))

                // Inner badge
                val textPaint = android.graphics.Paint().apply {
                    color = android.graphics.Color.WHITE
                    textSize = 12f * scale
                    isFakeBoldText = true
                    textAlign = android.graphics.Paint.Align.CENTER
                }
                drawContext.canvas.nativeCanvas.drawText(
                    vp.code,
                    pt.x,
                    pt.y + (4f * scale),
                    textPaint
                )
            }

            // 6. Draw Aircraft Fleet Markers
            aircraftList.forEach { ac ->
                val pt = latLngToOffset(ac.currentLat, ac.currentLng)

                rotate(degrees = ac.heading, pivot = pt) {
                    // eVTOL aircraft icon path
                    val acPath = Path().apply {
                        moveTo(pt.x, pt.y - 12f * scale) // nose
                        lineTo(pt.x + 8f * scale, pt.y + 10f * scale) // right wing
                        lineTo(pt.x, pt.y + 5f * scale)
                        lineTo(pt.x - 8f * scale, pt.y + 10f * scale) // left wing
                        close()
                    }
                    val acColor = if (ac.registration == "UA-204") UberGreen else UberBlue
                    drawPath(acPath, color = acColor)
                }
            }
        }
    }
}
