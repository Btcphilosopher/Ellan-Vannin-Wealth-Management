package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val UberBlack = Color(0xFF000000)
val UberWhite = Color(0xFFFFFFFF)
val UberOffWhite = Color(0xFFF6F6F6)
val UberGrey100 = Color(0xFFEEEEEE)
val UberGrey200 = Color(0xFFE2E2E2)
val UberGrey500 = Color(0xFF8C8C8C)
val UberGrey700 = Color(0xFF333333)
val UberGrey800 = Color(0xFF1E1E1E)
val UberGrey900 = Color(0xFF121212)

val UberBlue = Color(0xFF276EF1)
val UberGreen = Color(0xFF05A357)
val UberAmber = Color(0xFFFFC043)
val UberRed = Color(0xFFE11900)
