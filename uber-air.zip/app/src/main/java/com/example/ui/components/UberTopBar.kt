package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberBlue
import com.example.ui.theme.UberGreen
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberGrey900
import com.example.ui.theme.UberWhite

enum class AppPlatformMode {
    CUSTOMER_APP, OPERATIONS_DESK
}

@Composable
fun UberTopBar(
    currentMode: AppPlatformMode,
    onModeChange: (AppPlatformMode) -> Unit,
    activeFlightsCount: Int = 27,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(UberBlack)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("uber_top_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Mode Switch Pill
            Row(
                modifier = Modifier
                    .background(UberGrey900, shape = RoundedCornerShape(24.dp))
                    .border(1.dp, UberGrey800, shape = RoundedCornerShape(24.dp))
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Customer Tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (currentMode == AppPlatformMode.CUSTOMER_APP) UberWhite else Color.Transparent
                        )
                        .clickable { onModeChange(AppPlatformMode.CUSTOMER_APP) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("mode_switch_customer"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Rider App",
                            tint = if (currentMode == AppPlatformMode.CUSTOMER_APP) UberBlack else UberWhite,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Rider",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (currentMode == AppPlatformMode.CUSTOMER_APP) UberBlack else UberWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Ops Desk Tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (currentMode == AppPlatformMode.OPERATIONS_DESK) UberWhite else Color.Transparent
                        )
                        .clickable { onModeChange(AppPlatformMode.OPERATIONS_DESK) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("mode_switch_operations"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = "Ops Desk",
                            tint = if (currentMode == AppPlatformMode.OPERATIONS_DESK) UberBlack else UberWhite,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Ops Desk",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (currentMode == AppPlatformMode.OPERATIONS_DESK) UberBlack else UberWhite,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Live Network Status Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(UberGrey900, shape = RoundedCornerShape(16.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(UberGreen, shape = CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Air,
                    contentDescription = "Live Network",
                    tint = UberBlue,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "$activeFlightsCount eVTOLs Air",
                    style = MaterialTheme.typography.labelSmall,
                    color = UberWhite,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
