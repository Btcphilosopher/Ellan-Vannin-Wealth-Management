package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.TripEntity
import com.example.data.models.Aircraft
import com.example.data.models.LocationPoint
import com.example.data.models.PriceQuote
import com.example.data.models.TicketCategory
import com.example.data.models.Trip
import com.example.data.models.Vertiport
import com.example.data.repository.UberAirRepository
import com.example.simulation.LondonNetwork
import com.example.simulation.UamSimulator
import com.example.ui.components.AppPlatformMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class CustomerScreenState {
    HOME, ROUTE_COMPARISON, BOOKING_FLOW, RESERVE, LIVE_TRIP, ACTIVITY, SAFETY_SUPPORT
}

class UberAirViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = UberAirRepository(db)

    // Platform mode switch
    private val _platformMode = MutableStateFlow(AppPlatformMode.CUSTOMER_APP)
    val platformMode: StateFlow<AppPlatformMode> = _platformMode.asStateFlow()

    // Screen navigation state
    private val _currentScreen = MutableStateFlow(CustomerScreenState.HOME)
    val currentScreen: StateFlow<CustomerScreenState> = _currentScreen.asStateFlow()

    // Selection states
    private val _origin = MutableStateFlow(LondonNetwork.MAYFAIR_HOME)
    val origin: StateFlow<LocationPoint> = _origin.asStateFlow()

    private val _destination = MutableStateFlow(LondonNetwork.CANARY_WHARF_OFFICE)
    val destination: StateFlow<LocationPoint> = _destination.asStateFlow()

    private val _selectedQuote = MutableStateFlow<PriceQuote?>(null)
    val selectedQuote: StateFlow<PriceQuote?> = _selectedQuote.asStateFlow()

    // Simulator State Flows from Repository
    val activeTrip: StateFlow<Trip?> = repository.activeTrip
    val aircraftList: StateFlow<List<Aircraft>> = repository.aircraftList
    val vertiports: StateFlow<List<Vertiport>> = repository.vertiports
    val systemMetrics: StateFlow<UamSimulator.SystemMetrics> = repository.systemMetrics
    val disruptionMessage: StateFlow<String?> = repository.disruptionMessage

    val savedTripsFromDb: StateFlow<List<TripEntity>> = repository.allTripsFromDb
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setPlatformMode(mode: AppPlatformMode) {
        _platformMode.value = mode
    }

    fun navigateToScreen(screen: CustomerScreenState) {
        _currentScreen.value = screen
    }

    fun selectDestination(dest: LocationPoint) {
        _destination.value = dest
        _origin.value = LondonNetwork.MAYFAIR_HOME
        _currentScreen.value = CustomerScreenState.ROUTE_COMPARISON
    }

    fun selectPriceQuote(quote: PriceQuote) {
        _selectedQuote.value = quote
        _currentScreen.value = CustomerScreenState.BOOKING_FLOW
    }

    fun confirmBooking(passengerCount: Int, baggageCount: Int) {
        viewModelScope.launch {
            repository.createAndBookTrip(_origin.value, _destination.value, passengerCount, baggageCount)
            _currentScreen.value = CustomerScreenState.LIVE_TRIP
        }
    }

    fun createReservation(date: String, time: String, originName: String, destName: String) {
        viewModelScope.launch {
            repository.createReservation(originName, destName, date, time, 1, 94.0)
            _currentScreen.value = CustomerScreenState.ACTIVITY
        }
    }

    fun submitSupportTicket(category: TicketCategory, subject: String, desc: String) {
        viewModelScope.launch {
            repository.createSupportTicket(category, subject, desc, activeTrip.value?.id)
        }
    }

    fun advanceTripStep() {
        repository.advanceActiveTripState()
    }

    fun cancelActiveTrip() {
        repository.cancelActiveTrip()
        _currentScreen.value = CustomerScreenState.HOME
    }

    fun triggerDisruption() {
        repository.simulator.triggerDisruptionScenario()
    }

    fun clearDisruption() {
        repository.simulator.clearDisruption()
    }

    fun triggerSurge() {
        repository.simulator.triggerPeakDemandSurge()
    }

    fun resetDemand() {
        repository.simulator.resetDemand()
    }
}
