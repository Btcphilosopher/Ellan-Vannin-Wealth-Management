package com.example.ui.screens.customer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.LocationPoint
import com.example.data.models.PriceQuote
import com.example.simulation.LondonNetwork
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberBlue
import com.example.ui.theme.UberGreen
import com.example.ui.theme.UberGrey100
import com.example.ui.theme.UberGrey200
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberGrey900
import com.example.ui.theme.UberWhite

@Composable
fun BookingFlowScreen(
    origin: LocationPoint,
    destination: LocationPoint,
    priceQuote: PriceQuote,
    onConfirmBooking: (passengerCount: Int, baggageCount: Int) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var passengerCount by remember { mutableIntStateOf(1) }
    var baggageCount by remember { mutableIntStateOf(1) }
    var selectedPaymentMethod by remember { mutableStateOf("Uber Cash (Balance: £140.00)") }
    var isBreakdownExpanded by remember { mutableStateOf(false) }

    val vpOrigin = remember(origin) { LondonNetwork.findNearestVertiport(origin.lat, origin.lng) }
    val vpDest = remember(destination) { LondonNetwork.findNearestVertiport(destination.lat, destination.lng) }

    val totalPrice = priceQuote.price * passengerCount

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UberBlack)
            .padding(16.dp)
            .testTag("booking_flow_screen")
    ) {
        // Nav Top
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("booking_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = UberWhite
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Confirm Uber Air Journey",
                    style = MaterialTheme.typography.titleLarge,
                    color = UberWhite,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${origin.name} → ${destination.name}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
            // Multimodal Continuous Timeline
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = UberGrey900),
                border = androidx.compose.foundation.BorderStroke(1.dp, UberGrey800)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "ONE UBER TRIP",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Leg 1: Ground Pickup
                    MultimodalLegItem(
                        icon = Icons.Default.DirectionsCar,
                        modeName = "Uber Black (Ground Pickup)",
                        time = "08:20",
                        detail = "${origin.name} → ${vpOrigin.name}",
                        isAir = false
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Leg 2: Air Flight
                    MultimodalLegItem(
                        icon = Icons.Default.FlightTakeoff,
                        modeName = "Uber Air (eVTOL Flight)",
                        time = "08:38",
                        detail = "${vpOrigin.code} Vertiport → ${vpDest.code} Vertiport (12 min in air)",
                        isAir = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Leg 3: Ground Dropoff
                    MultimodalLegItem(
                        icon = Icons.Default.DirectionsCar,
                        modeName = "Uber Black (Ground Dropoff)",
                        time = "08:50",
                        detail = "${vpDest.name} → ${destination.name}",
                        isAir = false
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Passenger & Baggage Config
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = UberGrey900),
                border = androidx.compose.foundation.BorderStroke(1.dp, UberGrey800)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Passengers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = "Passengers", tint = UberWhite)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Passengers", style = MaterialTheme.typography.titleMedium, color = UberWhite)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            (1..4).forEach { count ->
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .padding(2.dp)
                                        .clip(CircleShape)
                                        .background(if (passengerCount == count) UberWhite else UberGrey800)
                                        .clickable { passengerCount = count }
                                        .testTag("passenger_count_$count"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$count",
                                        color = if (passengerCount == count) UberBlack else UberWhite,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = UberGrey800)
                    Spacer(modifier = Modifier.height(16.dp))

                    // Baggage
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Luggage, contentDescription = "Baggage", tint = UberWhite)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Cabin Baggage", style = MaterialTheme.typography.titleMedium, color = UberWhite)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            (1..3).forEach { count ->
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .padding(2.dp)
                                        .clip(CircleShape)
                                        .background(if (baggageCount == count) UberWhite else UberGrey800)
                                        .clickable { baggageCount = count }
                                        .testTag("baggage_count_$count"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$count",
                                        color = if (baggageCount == count) UberBlack else UberWhite,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Fare Breakdown Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = UberGrey900),
                border = androidx.compose.foundation.BorderStroke(1.dp, UberGrey800)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isBreakdownExpanded = !isBreakdownExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Upfront Price Breakdown",
                            style = MaterialTheme.typography.titleMedium,
                            color = UberWhite,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "£${String.format("%.2f", totalPrice)}",
                                style = MaterialTheme.typography.titleLarge,
                                color = UberWhite,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = if (isBreakdownExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Expand",
                                tint = UberWhite
                            )
                        }
                    }

                    AnimatedVisibility(visible = isBreakdownExpanded) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            HorizontalDivider(color = UberGrey800)
                            Spacer(modifier = Modifier.height(8.dp))

                            PriceLine("Uber Air eVTOL Leg", priceQuote.breakdownAir * passengerCount)
                            PriceLine("Ground Pickup (Uber Black)", priceQuote.breakdownPickup * passengerCount)
                            PriceLine("Ground Dropoff (Uber Black)", priceQuote.breakdownDropoff * passengerCount)
                            PriceLine("Vertiport Terminal Fee", 4.0 * passengerCount)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Confirm Button
        Button(
            onClick = { onConfirmBooking(passengerCount, baggageCount) },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("confirm_uber_air_booking_button"),
            colors = ButtonDefaults.buttonColors(containerColor = UberWhite, contentColor = UberBlack),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "Confirm Uber Air • £${String.format("%.2f", totalPrice)}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun MultimodalLegItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modeName: String,
    time: String,
    detail: String,
    isAir: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (isAir) UberWhite else UberGrey800,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = modeName,
            tint = if (isAir) UberBlack else UberWhite,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = modeName,
                style = MaterialTheme.typography.titleMedium,
                color = if (isAir) UberBlack else UberWhite,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = detail,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isAir) Color.DarkGray else Color.Gray
            )
        }
        Text(
            text = time,
            style = MaterialTheme.typography.labelLarge,
            color = if (isAir) UberBlack else UberWhite,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun PriceLine(label: String, amount: Double) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
        Text("£${String.format("%.2f", amount)}", style = MaterialTheme.typography.bodyMedium, color = UberWhite)
    }
}
