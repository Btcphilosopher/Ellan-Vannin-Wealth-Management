package com.example.ui.screens.customer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Trip
import com.example.data.models.TripState
import com.example.ui.components.BoardingPassCard
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberBlue
import com.example.ui.theme.UberGreen
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberGrey900
import com.example.ui.theme.UberRed
import com.example.ui.theme.UberWhite

@Composable
fun LiveTripScreen(
    trip: Trip,
    onAdvanceStep: () -> Unit,
    onTriggerDisruption: () -> Unit,
    onCancelTrip: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showBoardingPass by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(UberBlack)
            .testTag("live_trip_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header Nav
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("live_trip_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = UberWhite
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "LIVE TRIP MODE",
                        style = MaterialTheme.typography.labelSmall,
                        color = UberGreen,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${trip.origin.name} → ${trip.destination.name}",
                        style = MaterialTheme.typography.titleLarge,
                        color = UberWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Disruption Banner if active
            if (trip.disruptionNotice != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .testTag("disruption_notice_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = UberRed)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Disruption", tint = UberWhite)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = trip.disruptionNotice,
                            style = MaterialTheme.typography.bodyMedium,
                            color = UberWhite,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Current State Spotlight Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = UberGrey900),
                border = androidx.compose.foundation.BorderStroke(1.dp, UberGrey800)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "CURRENT TRIP STAGE",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = trip.state.name.replace("_", " "),
                        style = MaterialTheme.typography.displayMedium,
                        color = UberWhite,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = when (trip.state) {
                            TripState.BOOKED, TripState.GROUND_DISPATCHED -> "Uber Black driver en route to pick you up."
                            TripState.GROUND_ARRIVING -> "Driver approaching pickup location."
                            TripState.AT_VERTIPORT -> "Arrived at Vertiport. Proceed to check-in gate."
                            TripState.CHECKED_IN -> "Check-in verified. Boarding starting on Pad 02."
                            TripState.BOARDING -> "Boarding Joby S4 eVTOL aircraft (UA-204)."
                            TripState.DEPARTED, TripState.AIRBORNE -> "In-Flight at 1,200 ft. Cruising at 145 mph."
                            TripState.APPROACHING, TripState.LANDED -> "Landing at destination Vertiport."
                            TripState.GROUND_DROPOFF_DISPATCHED -> "Ground pickup waiting at landing gate."
                            TripState.COMPLETED -> "Arrived at final destination! Thank you for flying Uber Air."
                            else -> "Trip active."
                        },
                        style = MaterialTheme.typography.bodyLarge,
                        color = UberWhite.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // In-Flight Metrics if Airborne
                    if (trip.state == TripState.AIRBORNE || trip.state == TripState.DEPARTED) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(UberBlack, shape = RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("SPEED", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text("145 mph", style = MaterialTheme.typography.titleMedium, color = UberWhite, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("ALTITUDE", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text("1,200 ft", style = MaterialTheme.typography.titleMedium, color = UberWhite, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("AIRCRAFT", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text("UA-204", style = MaterialTheme.typography.titleMedium, color = UberBlue, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons
            Button(
                onClick = { showBoardingPass = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("open_boarding_pass_button"),
                colors = ButtonDefaults.buttonColors(containerColor = UberWhite, contentColor = UberBlack),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.QrCode, contentDescription = "QR Pass")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Show Digital Boarding Pass", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Interactive Simulator Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onAdvanceStep,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("advance_trip_step_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Simulate Next Step", color = UberWhite, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onTriggerDisruption,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("trigger_disruption_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Trigger Reroute", color = UberRed, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onCancelTrip,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("cancel_active_trip_button"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Cancel Trip", color = UberWhite)
            }
        }

        // Digital Boarding Pass Modal Overlay
        if (showBoardingPass) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                BoardingPassCard(
                    trip = trip,
                    onClose = { showBoardingPass = false }
                )
            }
        }
    }
}
