package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Trip
import com.example.ui.theme.UberBlack
import com.example.ui.theme.UberGrey100
import com.example.ui.theme.UberGrey200
import com.example.ui.theme.UberGrey800
import com.example.ui.theme.UberWhite

@Composable
fun BoardingPassCard(
    trip: Trip,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("boarding_pass_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = UberWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "UBER AIR",
                    style = MaterialTheme.typography.titleLarge,
                    color = UberBlack,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "BOARDING PASS",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Airport / Vertiport Codes
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val airLeg = trip.legs.firstOrNull { it.type.name == "AIR_FLIGHT" }
                val originCode = airLeg?.origin?.code ?: "VP1"
                val destCode = airLeg?.destination?.code ?: "VP2"

                Column {
                    Text(
                        text = originCode,
                        style = MaterialTheme.typography.displayMedium,
                        color = UberBlack,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = airLeg?.origin?.name ?: "Vertiport A",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }

                Icon(
                    imageVector = Icons.Default.FlightTakeoff,
                    contentDescription = "Flight",
                    tint = UberBlack,
                    modifier = Modifier.size(28.dp)
                )

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = destCode,
                        style = MaterialTheme.typography.displayMedium,
                        color = UberBlack,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = airLeg?.destination?.name ?: "Vertiport B",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = UberGrey200, thickness = 1.dp)
            Spacer(modifier = Modifier.height(16.dp))

            // Metadata Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("PASSENGER", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text(trip.passengerName, style = MaterialTheme.typography.titleMedium, color = UberBlack)
                }
                Column {
                    Text("FLIGHT", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text("UA-8421", style = MaterialTheme.typography.titleMedium, color = UberBlack)
                }
                Column {
                    Text("PAD", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text("PAD 02", style = MaterialTheme.typography.titleMedium, color = UberBlack)
                }
                Column {
                    Text("SEAT", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text("01A", style = MaterialTheme.typography.titleMedium, color = UberBlack)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Synthetic Canvas QR Code
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .background(UberGrey100, shape = RoundedCornerShape(12.dp))
                    .border(1.dp, UberGrey200, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Canvas(modifier = Modifier.size(90.dp)) {
                        val gridSize = 8
                        val cellSize = size.width / gridSize
                        for (r in 0 until gridSize) {
                            for (c in 0 until gridSize) {
                                if ((r + c * 3 + trip.id.hashCode()) % 2 == 0 || (r == 0 || c == 0 || r == gridSize - 1 || c == gridSize - 1)) {
                                    drawRect(
                                        color = UberBlack,
                                        topLeft = Offset(c * cellSize, r * cellSize),
                                        size = Size(cellSize - 2, cellSize - 2)
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = trip.qrCodeToken,
                            style = MaterialTheme.typography.labelLarge,
                            color = UberBlack,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "SCAN AT VERTIPORT GATE",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onClose,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("close_boarding_pass_button"),
                colors = ButtonDefaults.buttonColors(containerColor = UberBlack, contentColor = UberWhite),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Close Boarding Pass", fontWeight = FontWeight.Bold)
            }
        }
    }
}
