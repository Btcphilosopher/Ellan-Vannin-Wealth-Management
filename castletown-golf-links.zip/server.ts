import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

// Parse request bodies
app.use(express.json());

// Lazy-initialized Gemini Client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is required but not configured. Please add it to your secrets or environment variables.");
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// In-memory mock database for bookings, scores, and shop orders
const bookings: any[] = [];
const memberScores: any[] = [];
const contactEnquiries: any[] = [];

// API: Get Live Isle of Man Course Conditions (Surrounded by Irish Sea)
app.get("/api/conditions", (req, res) => {
  // Return realistic live course parameters for a premium links course on Langness Peninsula
  res.json({
    windSpeed: "18 mph",
    windDirection: "SW (Prevailing)",
    tide: "High Tide at 10:42 AM (3.2m swell)",
    sunrise: "05:44 AM",
    sunset: "09:21 PM",
    greenSpeed: "10.5 (Stimp)",
    courseStatus: "Open (Temp Greens: None)",
    weatherSummary: "Partly cloudy with coastal breeze, excellent visibility",
    temperature: "17°C",
    humidity: "74%",
    barometer: "1016 hPa",
    forecast: [
      { time: "09:00", temp: "15°C", wind: "14 mph SW", cond: "Sunny" },
      { time: "12:00", temp: "17°C", wind: "18 mph SW", cond: "Partly Cloudy" },
      { time: "15:00", temp: "18°C", wind: "21 mph SW", cond: "Cloudy" },
      { time: "18:00", temp: "16°C", wind: "19 mph W", cond: "Light Showers" },
      { time: "21:00", temp: "14°C", wind: "15 mph WNW", cond: "Clear" }
    ]
  });
});

// API: Submit a Tee Time booking
app.post("/api/bookings", (req, res) => {
  const { date, time, players, name, email, phone, rate, notes, caddieCount, cartCount } = req.body;
  if (!date || !time || !name || !email) {
    return res.status(400).json({ error: "Missing required booking details." });
  }

  const newBooking = {
    id: `CTL-${Math.floor(100000 + Math.random() * 900000)}`,
    date,
    time,
    players: Number(players) || 1,
    name,
    email,
    phone,
    rate: Number(rate) || 220, // Default championship green fee £220
    caddieCount: Number(caddieCount) || 0,
    cartCount: Number(cartCount) || 0,
    total: (Number(rate) || 220) * (Number(players) || 1) + (Number(caddieCount) || 0) * 50 + (Number(cartCount) || 0) * 40,
    status: "Confirmed",
    createdAt: new Date().toISOString()
  };

  bookings.push(newBooking);
  res.status(201).json(newBooking);
});

// API: Get existing bookings
app.get("/api/bookings", (req, res) => {
  res.json(bookings);
});

// API: Submit Contact/Enquiry Form (Corporate, Event, Membership)
app.post("/api/enquiries", (req, res) => {
  const { name, email, phone, type, message, interest } = req.body;
  if (!name || !email || !type) {
    return res.status(400).json({ error: "Name, email, and enquiry type are required." });
  }
  const newEnquiry = {
    id: `ENQ-${Math.floor(10000 + Math.random() * 90000)}`,
    name,
    email,
    phone,
    type, // "membership", "corporate", "event", "academy"
    interest, // package level
    message,
    status: "Received",
    createdAt: new Date().toISOString()
  };
  contactEnquiries.push(newEnquiry);
  res.status(201).json(newEnquiry);
});

// API: Member Handicap Tracker (Enter Score)
app.post("/api/scores", (req, res) => {
  const { memberId, name, date, courseRating, slopeRating, score } = req.body;
  if (!memberId || !score) {
    return res.status(400).json({ error: "Member ID and score are required." });
  }
  // Calculate handicap differential: (Score - Course Rating) * 113 / Slope Rating
  const cr = Number(courseRating) || 72.8;
  const slope = Number(slopeRating) || 135;
  const differential = ((Number(score) - cr) * 113) / slope;

  const newScore = {
    id: `SCR-${Math.floor(1000 + Math.random() * 9000)}`,
    memberId,
    name: name || "Member",
    date: date || new Date().toISOString().split("T")[0],
    score: Number(score),
    differential: parseFloat(differential.toFixed(1)),
    createdAt: new Date().toISOString()
  };
  memberScores.push(newScore);
  res.status(201).json(newScore);
});

// API: Get Member Scores
app.get("/api/scores/:memberId", (req, res) => {
  const filtered = memberScores.filter(s => s.memberId === req.params.memberId);
  res.json(filtered);
});

// API: Gemini AI Visitor Concierge Chat
app.post("/api/chat", async (req, res) => {
  const { message, history } = req.body;
  if (!message) {
    return res.status(400).json({ error: "Message is required." });
  }

  try {
    const ai = getGeminiClient();
    
    const systemInstruction = `You are the exclusive AI Concierge for Castletown Golf Links, a world-class premier championship golf course located on the dramatic Langness Peninsula of the Isle of Man, surrounded by the Irish Sea.

Your personality is polite, refined, professional, and knowledgeable—embodying understated British luxury (similar to the standard of Aman Resorts, Rolex, or the Four Seasons). Speak with confidence, grace, and impeccable manners. Keep answers concise, highly informative, and luxurious in tone. Do not use generic AI buzzwords like "supercharge", "empower", or "revolutionary".

KEY INFORMATION ABOUT CASTLETOWN GOLF LINKS:
- Design: Originally laid out in 1892 by Old Tom Morris (the legendary Scottish open champion), then updated/redesigned in the 1940s by Mackenzie Ross (who also restored Turnberry).
- Course Details: 18-hole championship links. Par 72, 6,730 yards from the back tees. Surprising coastal routing where the Irish Sea is visible from every single hole.
- Signature Hole: The famous 17th hole ("The Gully") which requires a heroic carry over an inlet of the Atlantic Ocean (the Irish Sea) to a clifftop green, framed by the historic Langness Lighthouse.
- Landmark: Langness Lighthouse and the historic ruin of Derby Fort (built in 1540 on Derby Haven) are right beside the links.
- Facilities: The Clubhouse features 'The 1892 Restaurant' (fine local Manx seafood and dining), 'The Oak Bar' (exceptional single-malts, peated scotch, and Irish whiskies), and a bespoke wine cellar.
- Accommodation: Luxury links lodges and coastal suites offering sea views, private terraces, roll-top copper tubs, and premium golf-and-spa packages.
- Golf Academy: Led by PGA Head Professional. Features a high-tech TrackMan 4 simulator studio, putting laboratory, and custom video analysis.
- Green Fees:
  - Visitor Day Fee: £220 (Summer) / £120 (Winter).
  - Includes full access to practice range, short-game green, and lockers.
- Membership packages:
  - Full Membership: £2,200/year (unlimited golf, tournament access, club matches).
  - Country Membership: £1,400/year (for UK mainland residents, up to 15 rounds).
  - International Membership: £950/year (for overseas residents, up to 10 rounds).
- Dress Code: Traditional golf attire is required. Collared shirts, tailored golf shorts or trousers, and soft-spiked golf shoes. Denim, cargo shorts, and collarless shirts are not permitted on the course.

Help the visitor with any enquiries about booking a tee time, exploring memberships, weather forecasts, the history of the course, how to play specific holes, lodging, and dining options. Keep responses beautifully formatted.`;

    // Process chat history into standard Gemini SDK parts if provided
    let contents: any = [];
    if (history && Array.isArray(history)) {
      history.forEach((turn: any) => {
        contents.push({
          role: turn.role === "user" ? "user" : "model",
          parts: [{ text: turn.text }]
        });
      });
    }
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini AI Concierge Error:", error);
    res.status(500).json({ 
      error: error.message || "An error occurred while generating the response. Please check your Gemini API configuration." 
    });
  }
});

// Set up Vite and static file serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in development mode with Vite middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in production mode serving static dist...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Castletown Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
