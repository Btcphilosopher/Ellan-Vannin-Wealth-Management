export interface Hole {
  number: number;
  name: string;
  par: number;
  yardsBlue: number;
  yardsWhite: number;
  yardsRed: number;
  handicap: number;
  description: string;
  strategy: string;
  greenContours: string; // "Sloping back-to-front", "Bi-level plateau", etc.
  prevailingWind: string; // "Crosswind from Atlantic", "In-your-face from West", etc.
  signature: boolean;
  image: string;
}

export interface Booking {
  id?: string;
  date: string;
  time: string;
  players: number;
  name: string;
  email: string;
  phone: string;
  rate: number;
  total?: number;
  caddieCount: number;
  cartCount: number;
  status?: string;
}

export interface MembershipPackage {
  id: string;
  name: string;
  price: string;
  description: string;
  benefits: string[];
  eligibility: string;
  iconName: string;
}

export interface MenuItem {
  name: string;
  description: string;
  price: string;
  category: "starter" | "main" | "dessert" | "whisky" | "wine";
}

export interface LodgingSuite {
  id: string;
  name: string;
  description: string;
  pricePerNight: number;
  amenities: string[];
  views: string;
  image: string;
}

export interface ShopItem {
  id: string;
  name: string;
  category: "apparel" | "equipment" | "accessories" | "art" | "gifts";
  price: number;
  description: string;
  image: string;
  sizes?: string[];
  rating: number;
}

export interface CourseConditions {
  windSpeed: string;
  windDirection: string;
  tide: string;
  sunrise: string;
  sunset: string;
  greenSpeed: string;
  courseStatus: string;
  weatherSummary: string;
  temperature: string;
  humidity: string;
  barometer: string;
  forecast: Array<{
    time: string;
    temp: string;
    wind: string;
    cond: string;
  }>;
}

export interface Tournament {
  id: string;
  name: string;
  date: string;
  type: string;
  status: "upcoming" | "live" | "completed";
  scoringUrl?: string;
  slots: number;
  registeredPlayers?: number;
}
