import React, { useState } from "react";
import { Utensils, Compass, Eye, ShieldAlert, Award, Star } from "lucide-react";
import { menuItems } from "../data";

export default function Clubhouse() {
  const [activeMenuTab, setActiveMenuTab] = useState<"starter" | "main" | "dessert" | "whisky" | "wine">("main");

  const filteredMenu = menuItems.filter((item) => item.category === activeMenuTab);

  const menuTabs = [
    { label: "Starters", category: "starter" },
    { label: "Mains & Seafood", category: "main" },
    { label: "Desserts", category: "dessert" },
    { label: "Single-Malt Cellar", category: "whisky" },
    { label: "Grand Cru Cellar", category: "wine" }
  ];

  return (
    <div className="bg-[#fcfbf9] text-[#0a1f2c] min-h-screen">
      
      {/* Immersive Intro Hero banner */}
      <section className="relative h-[50vh] min-h-[350px] flex items-center justify-center overflow-hidden bg-[#0a1f2c]">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1600&q=80"
            alt="Clubhouse fine dining room interior overlooking the coastline"
            className="w-full h-full object-cover opacity-65"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#fcfbf9] via-transparent to-black/30" />
        </div>
        <div className="relative z-10 text-center space-y-3 px-6 text-white md:text-[#0a1f2c] mt-12">
          <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block">
            THE CLUBHOUSE & GASTRONOMY
          </span>
          <h2 className="font-serif text-4xl md:text-6xl uppercase tracking-tight font-semibold">
            Coastal Hospitality
          </h2>
          <p className="font-serif italic text-base max-w-xl mx-auto text-gray-200 md:text-gray-600">
            Dine overlooking the 18th green as the sun sets over Derby Haven bay. Savour fresh local Manx scallops, hand-dived crab, and our private label single-malts.
          </p>
        </div>
      </section>

      {/* 2. Restaurant Split Section */}
      <section className="max-w-6xl mx-auto px-6 py-16 md:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left: Beautiful food image */}
          <div className="lg:col-span-7">
            <div className="relative aspect-[4/3] rounded-xl overflow-hidden shadow-2xl border border-gray-100 bg-[#0a1f2c]">
              <img
                src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80"
                alt="Seafood scallops starter dish"
                className="w-full h-full object-cover opacity-90"
              />
              <div className="absolute bottom-6 left-6 bg-black/60 backdrop-blur-sm px-4 py-3 rounded text-white border border-white/10 text-xs">
                <span className="text-[#8c7355] uppercase font-bold font-sans tracking-widest block text-[9px] mb-1">SIGNATURE DISH</span>
                <p className="font-serif italic font-bold">Pan-Seared Queenies in Herb Butter</p>
              </div>
            </div>
          </div>

          {/* Right: Descriptive story */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex items-center gap-2">
              <span className="h-[1px] w-8 bg-[#8c7355]" />
              <span className="font-sans text-[11px] font-bold uppercase tracking-widest text-[#8c7355]">
                The 1892 Restaurant
              </span>
            </div>
            
            <h3 className="font-serif text-3xl font-medium uppercase tracking-tight">
              A Culinary Link <br />to the Island
            </h3>
            
            <p className="font-sans text-sm text-gray-600 leading-relaxed">
              Named after the year of our founding, The 1892 Restaurant champions local Manx fishermen and heritage farmers. Our menu revolves with the seasons, pairing pure ocean bounty with rare pedigree meats like Manx Loaghtan Lamb.
            </p>

            <div className="border-t border-gray-100 pt-6 grid grid-cols-2 gap-4 text-xs font-sans">
              <div>
                <span className="text-gray-400 font-bold uppercase tracking-widest block">DRESS CODE</span>
                <p className="text-gray-600 mt-1">Smart casual (Tailored trousers, collar shirts)</p>
              </div>
              <div>
                <span className="text-gray-400 font-bold uppercase tracking-widest block">HOURS</span>
                <p className="text-gray-600 mt-1">Lunch: 12-3 PM <br />Dinner: 6-10 PM</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 3. Interactive Menu Board */}
      <section className="bg-[#0a1f2c] text-white py-16 md:py-24 border-t border-[#8c7355]/10">
        <div className="max-w-4xl mx-auto px-6">
          
          {/* Header */}
          <div className="text-center max-w-xl mx-auto mb-12 space-y-3">
            <span className="font-sans text-[10px] font-bold text-[#8c7355] uppercase tracking-[0.3em] block">
              ESTABLISHED CELLARS & KITCHENS
            </span>
            <h3 className="font-serif text-2xl md:text-4xl uppercase tracking-tight font-semibold">
              The Clubhouse Menus
            </h3>
            <p className="font-serif italic text-sm text-gray-400">
              Browse our curated dining menus and rare single-malt scotches. Please inform your server of any dietary needs when booking.
            </p>
          </div>

          {/* Tab Navigation row */}
          <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-12 border-b border-white/5 no-scrollbar">
            {menuTabs.map((tab) => (
              <button
                key={tab.category}
                onClick={() => setActiveMenuTab(tab.category as any)}
                className={`flex-shrink-0 px-5 py-2.5 rounded-full font-sans text-[11px] font-bold uppercase tracking-widest border transition-all ${
                  activeMenuTab === tab.category
                    ? "bg-[#8c7355] border-transparent text-[#0a1f2c] font-extrabold shadow"
                    : "border-white/10 text-gray-400 hover:border-white/30 hover:text-white"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Menus Grid List */}
          <div className="space-y-6 animate-fade-in">
            {filteredMenu.map((item, idx) => (
              <div
                key={idx}
                className="group flex flex-col sm:flex-row sm:items-baseline justify-between p-4 rounded-lg hover:bg-white/5 border border-transparent hover:border-white/5 transition-all duration-200"
              >
                <div className="space-y-1 sm:max-w-[75%]">
                  <div className="flex items-center gap-2">
                    <h4 className="font-serif text-lg font-bold text-white group-hover:text-[#8c7355] transition-colors">
                      {item.name}
                    </h4>
                    {/* Visual marker for single malt cellar */}
                    {activeMenuTab === "whisky" && (
                      <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
                    )}
                  </div>
                  <p className="text-xs text-gray-400 font-sans leading-relaxed">
                    {item.description}
                  </p>
                </div>
                <div className="mt-2 sm:mt-0">
                  <span className="font-serif text-lg font-bold text-[#8c7355] sm:text-right block">
                    {item.price}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Wine / Dining cellar reservation notice */}
          <div className="mt-12 bg-black/40 border border-[#8c7355]/20 p-6 rounded-lg text-center space-y-4">
            <span className="font-sans text-[9px] font-bold text-[#8c7355] uppercase tracking-widest flex items-center justify-center gap-1.5">
              <Award className="h-4 w-4" />
              Private Dining & Whisky Flights Available
            </span>
            <p className="text-xs text-gray-400 font-sans max-w-md mx-auto">
              Reserve our hand-carved Walnut Boardroom for private celebrations of up to 14 guests, complete with a customized 5-course seafood tasting menu and whisky flight.
            </p>
            <button
              onClick={() => {
                alert("Please complete the corporate or general contact enquiry on our portal to arrange a private dining experience.");
              }}
              className="text-[#8c7355] hover:text-white font-sans text-[10px] font-bold uppercase tracking-widest transition-colors inline-block"
            >
              Enquire About Dining Booking &rarr;
            </button>
          </div>

        </div>
      </section>

    </div>
  );
}
