import React, { useState, useRef, useEffect } from "react";
import { MessageSquare, X, Send, Award, HelpCircle, Calendar, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Message {
  role: "user" | "model";
  text: string;
}

export default function AIConcierge() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "model",
      text: "Welcome to Castletown Golf Links. I am your personal Links Concierge. How may I assist you today? I can guide you through booking a championship tee time, exploring our exclusive membership categories, scheduling lessons in the TrackMan academy, or reserving your luxury coastal suite."
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isLoading]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!message.trim() || isLoading) return;

    const userText = message;
    setMessage("");
    setMessages((prev) => [...prev, { role: "user", text: userText }]);
    setIsLoading(true);
    setErrorMsg(null);

    try {
      // Build the payload with previous history (max last 10 messages for token health)
      const chatHistory = messages.slice(-10).map(m => ({
        role: m.role,
        text: m.text
      }));

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userText, history: chatHistory })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to connect to the concierge.");
      }

      setMessages((prev) => [...prev, { role: "model", text: data.text }]);
    } catch (err: any) {
      console.warn("AI Concierge fallback triggered:", err.message);
      // Beautiful offline simulation for local preview in case API key is missing
      setTimeout(() => {
        let reply = "Thank you for asking. I'm currently in high-luxury offline assistance mode. ";
        const promptLower = userText.toLowerCase();

        if (promptLower.includes("book") || promptLower.includes("tee") || promptLower.includes("price") || promptLower.includes("fee")) {
          reply += "Our standard summer visitor green fee is £220 per round, which includes full access to our lockers, driving range, and chipping green. You can book directly in the 'Book a Tee Time' section of our website, or let our booking manager know at bookings@castletown.im. Would you like me to help you navigate there?";
        } else if (promptLower.includes("member") || promptLower.includes("join")) {
          reply += "We offer Full (£2,200/yr), Country (£1,400/yr), and International (£950/yr) membership packages. Members receive priority booking, official WHS handicap indexing, and a 15% discount on clubhouse dining. You can view the full comparison on our 'Membership' tab.";
        } else if (promptLower.includes("hole") || promptLower.includes("gully") || promptLower.includes("lighthouse")) {
          reply += "Castletown is famous for its coastal layout. Our signature hole is the par-4 17th ('The Gully'), which requires a dramatic carry over an inlet of the Irish Sea toward the Langness Lighthouse. It is truly one of the most memorable holes in Great Britain.";
        } else if (promptLower.includes("stay") || promptLower.includes("lodge") || promptLower.includes("hotel") || promptLower.includes("accommodation")) {
          reply += "Our luxury Links Lodges and Suites start at £380 per night. The signature 'Old Tom Morris Suite' features stunning views of the 18th green and a private copper soaking tub. Please explore the 'Stay' tab for packages and instant booking.";
        } else if (promptLower.includes("dress") || promptLower.includes("wear")) {
          reply += "Our dress code requires traditional golf attire: collared shirts, tailored trousers or golf shorts, and soft-spiked golf shoes. Denim, cargo wear, and tracksuits are not permitted on the course or in the dining room.";
        } else if (promptLower.includes("weather") || promptLower.includes("wind") || promptLower.includes("tide")) {
          reply += "Being on the Langness Peninsula, our links are heavily shaped by the Irish Sea. The prevailing winds are South-Westerly, typically averaging 15-20 mph. Check out our Live Conditions tab in the Member Portal for real-time wind speeds, tides, and green speeds!";
        } else {
          reply += "Our links course, designed by Old Tom Morris and refined by Mackenzie Ross, offers 18 holes of pure seaside golf on the Isle of Man. For direct booking inquiries, corporate packages, or restaurant tables, please use the navigation tabs at the top or email concierge@castletown.im.";
        }

        setMessages((prev) => [...prev, { role: "model", text: reply }]);
      }, 800);
    } finally {
      setIsLoading(false);
    }
  };

  const handleChipClick = (chipText: string) => {
    setMessage(chipText);
    setTimeout(() => {
      // Small delay to let state update, then submit
      const button = document.getElementById("concierge-submit-btn");
      if (button) button.click();
    }, 50);
  };

  return (
    <>
      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={() => setIsOpen(true)}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-[#8c7355] text-white shadow-2xl transition-all duration-300 hover:scale-110 hover:bg-[#a8864c] active:scale-95 group border border-[#cfae73]"
          aria-label="Open AI Concierge"
          id="concierge-trigger"
        >
          <MessageSquare className="h-6 w-6 transition-transform group-hover:rotate-12" />
          <span className="absolute -top-1 -right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-amber-500 text-[9px] text-white font-bold items-center justify-center">AI</span>
          </span>
        </button>
      </div>

      {/* Floating Chat Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.95 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="fixed bottom-6 right-6 z-50 flex h-[600px] w-[400px] flex-col rounded-2xl bg-[#0a1f2c] border border-[#8c7355]/30 shadow-2xl overflow-hidden"
            id="concierge-panel"
          >
            {/* Header */}
            <div className="flex items-center justify-between bg-gradient-to-r from-[#0a1f2c] to-[#0a1f2c] p-4 border-b border-[#8c7355]/20">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#8c7355]/10 border border-[#8c7355]/30 text-[#8c7355]">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-serif font-semibold text-white tracking-wide text-sm">Links AI Concierge</h3>
                  <p className="text-[11px] text-[#8c7355] uppercase tracking-widest font-sans font-medium">Castletown Golf Links</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="rounded-full p-1 text-gray-400 hover:bg-white/10 hover:text-white transition-colors"
                aria-label="Close Chat"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-white/10">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-[#8c7355] text-white rounded-tr-none"
                        : "bg-[#172f26] text-gray-100 border border-white/5 rounded-tl-none font-serif"
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex justify-start">
                  <div className="flex items-center gap-1 max-w-[85%] rounded-2xl rounded-tl-none bg-[#172f26] border border-white/5 px-4 py-3 text-gray-100">
                    <span className="h-2 w-2 rounded-full bg-[#8c7355] animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="h-2 w-2 rounded-full bg-[#8c7355] animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="h-2 w-2 rounded-full bg-[#8c7355] animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Suggestion Chips */}
            <div className="p-3 bg-[#0a1b15]/60 border-t border-[#8c7355]/10 flex gap-2 overflow-x-auto no-scrollbar">
              <button
                onClick={() => handleChipClick("How much are visitor green fees?")}
                className="flex-shrink-0 text-[11px] bg-[#143025] hover:bg-[#1f4a39] text-[#8c7355] border border-[#8c7355]/20 rounded-full px-3 py-1.5 transition-colors font-sans"
              >
                Green Fees?
              </button>
              <button
                onClick={() => handleChipClick("Tell me about the signature 17th hole.")}
                className="flex-shrink-0 text-[11px] bg-[#143025] hover:bg-[#1f4a39] text-[#8c7355] border border-[#8c7355]/20 rounded-full px-3 py-1.5 transition-colors font-sans"
              >
                Signature 17th
              </button>
              <button
                onClick={() => handleChipClick("What luxury lodging suites do you have?")}
                className="flex-shrink-0 text-[11px] bg-[#143025] hover:bg-[#1f4a39] text-[#8c7355] border border-[#8c7355]/20 rounded-full px-3 py-1.5 transition-colors font-sans"
              >
                Luxury Lodging?
              </button>
              <button
                onClick={() => handleChipClick("What is the club dress code?")}
                className="flex-shrink-0 text-[11px] bg-[#143025] hover:bg-[#1f4a39] text-[#8c7355] border border-[#8c7355]/20 rounded-full px-3 py-1.5 transition-colors font-sans"
              >
                Dress Code?
              </button>
            </div>

            {/* Input Footer */}
            <form
              onSubmit={handleSendMessage}
              className="p-3 bg-[#0a1f2c] border-t border-[#8c7355]/20 flex gap-2 items-center"
            >
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Inquire with the concierge..."
                className="flex-1 bg-[#143025] text-white border border-[#8c7355]/20 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-[#8c7355] placeholder:text-gray-500 font-sans"
                disabled={isLoading}
              />
              <button
                type="submit"
                id="concierge-submit-btn"
                className="h-10 w-10 flex items-center justify-center rounded-xl bg-[#8c7355] hover:bg-[#a8864c] text-white transition-colors focus:outline-none disabled:bg-gray-700"
                disabled={isLoading}
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
