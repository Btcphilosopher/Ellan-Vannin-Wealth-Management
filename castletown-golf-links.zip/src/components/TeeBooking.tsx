import React, { useState } from "react";
import { Calendar as CalendarIcon, Users, Check, Gift, ShieldAlert, Sparkles, Trophy, ShoppingBag } from "lucide-react";

export default function TeeBooking() {
  const [date, setDate] = useState<string>("2026-08-15");
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [playersCount, setPlayersCount] = useState<number>(4);
  const [caddiesCount, setCaddiesCount] = useState<number>(0);
  const [buggiesCount, setBuggiesCount] = useState<number>(0);
  
  // Booking contact info
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  
  const [isBooked, setIsBooked] = useState(false);
  const [bookingCode, setBookingCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Available slots
  const teeTimes = [
    { time: "07:30", available: true },
    { time: "08:10", available: true },
    { time: "08:50", available: false },
    { time: "09:30", available: true },
    { time: "10:10", available: true },
    { time: "11:20", available: true },
    { time: "12:00", available: false },
    { time: "13:30", available: true },
    { time: "14:10", available: true },
    { time: "15:00", available: true }
  ];

  // Dynamic green fee based on date
  const getRateAndSeason = () => {
    const month = new Date(date).getMonth(); // 0-11
    // April (3) to October (9) is Summer season
    const isSummer = month >= 3 && month <= 9;
    return {
      rate: isSummer ? 220 : 120,
      season: isSummer ? "Championship Summer Day Fee" : "Winter Links Green Fee"
    };
  };

  const { rate, season } = getRateAndSeason();
  const baseTotal = rate * playersCount;
  const caddieTotal = caddiesCount * 50; // £50 per caddie
  const buggyTotal = buggiesCount * 40;  // £40 per buggy
  const grandTotal = baseTotal + caddieTotal + buggyTotal;

  const handleSubmitBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTime) {
      alert("Please select an available tee time slot.");
      return;
    }
    setIsLoading(true);

    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date,
          time: selectedTime,
          players: playersCount,
          name,
          email,
          phone,
          rate,
          caddieCount: caddiesCount,
          cartCount: buggiesCount,
          notes
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Booking failed");
      }

      setBookingCode(data.id);
      setIsBooked(true);
    } catch (err: any) {
      alert(err.message || "An error occurred during booking. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-[#fcfbf9] text-[#0a1f2c] min-h-screen py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block">
            Online Tee Reservations
          </span>
          <h2 className="font-serif text-3xl md:text-5xl uppercase tracking-tight font-medium">
            Book a Championship Round
          </h2>
          <p className="font-serif italic text-base text-gray-500">
            Secure your presence on the Isle of Man's premier links course. Players are advised to check local wind and tides on their member portal prior to play.
          </p>
        </div>

        {isBooked ? (
          /* Booking Success Screen */
          <div className="max-w-2xl mx-auto bg-white border border-[#8c7355]/20 rounded-xl p-10 shadow-2xl text-center space-y-8 animate-fade-in">
            <div className="h-16 w-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border border-emerald-200">
              <Check className="h-8 w-8 stroke-[3]" />
            </div>
            
            <div className="space-y-2">
              <span className="font-sans text-[11px] font-bold text-emerald-600 uppercase tracking-widest block">RESERVATION CONFIRMED</span>
              <h3 className="font-serif text-2xl font-bold">Your tee time is secured</h3>
              <p className="font-sans text-xs text-gray-500">A confirmation email with instructions has been dispatched to {email}.</p>
            </div>

            {/* Receipt Summary */}
            <div className="bg-[#fcfbf9] rounded-lg p-6 border border-gray-100 text-left space-y-4 font-serif">
              <div className="flex justify-between border-b border-gray-200 pb-3">
                <span className="text-gray-500">Reservation Reference:</span>
                <span className="font-bold text-[#8c7355] tracking-wider">{bookingCode}</span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-400 text-xs block">DATE</span>
                  <p className="font-bold">{date}</p>
                </div>
                <div>
                  <span className="text-gray-400 text-xs block">TEE TIME</span>
                  <p className="font-bold">{selectedTime}</p>
                </div>
                <div>
                  <span className="text-gray-400 text-xs block">PLAYERS</span>
                  <p className="font-bold">{playersCount} Golfers</p>
                </div>
                <div>
                  <span className="text-gray-400 text-xs block">RATE SCALE</span>
                  <p className="font-bold">£{rate} / round</p>
                </div>
              </div>
              
              {/* Optional items summary */}
              {(caddiesCount > 0 || buggiesCount > 0) && (
                <div className="border-t border-gray-100 pt-3 text-xs space-y-1 text-gray-500">
                  {caddiesCount > 0 && <p>• {caddiesCount} Premium Caddie(s) booked (£{caddiesCount * 50})</p>}
                  {buggiesCount > 0 && <p>• {buggiesCount} Electric Buggy(ies) booked (£{buggiesCount * 40})</p>}
                </div>
              )}

              <div className="border-t border-gray-200 pt-3 flex justify-between items-baseline">
                <span className="text-sm font-sans font-bold uppercase tracking-wider text-gray-500">TOTAL DUE AT CLUBHOUSE:</span>
                <span className="text-2xl font-bold text-[#0a1f2c]">£{grandTotal}</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => {
                  setIsBooked(false);
                  setName("");
                  setEmail("");
                  setPhone("");
                  setSelectedTime("");
                  setCaddiesCount(0);
                  setBuggiesCount(0);
                }}
                className="bg-[#0a1f2c] hover:bg-[#8c7355] text-white hover:text-[#0a1f2c] px-8 py-3.5 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all duration-300 w-full"
              >
                Book Another Tee Time
              </button>
            </div>
          </div>
        ) : (
          /* Interactive Booking Calendar & Setup Grid */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* Left Box: Setup and Times selection */}
            <div className="lg:col-span-7 bg-white rounded-xl border border-gray-100 p-8 shadow-xl space-y-8">
              
              {/* Step 1: Date & Players */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold font-sans uppercase tracking-widest text-gray-400 mb-2">
                    Select Date
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-[#fcfbf9] border border-gray-200 rounded px-4 py-3 text-sm font-sans focus:outline-none focus:border-[#8c7355]"
                      min="2026-08-01"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold font-sans uppercase tracking-widest text-gray-400 mb-2">
                    Number of Players
                  </label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4].map((n) => (
                      <button
                        key={n}
                        type="button"
                        onClick={() => setPlayersCount(n)}
                        className={`flex-1 py-3 rounded text-sm font-sans font-bold border transition-all ${
                          playersCount === n
                            ? "bg-[#8c7355] border-transparent text-[#0a1f2c]"
                            : "bg-[#fcfbf9] border-gray-200 text-[#0a1f2c] hover:border-gray-400"
                        }`}
                      >
                        {n} {n === 1 ? "Player" : "Players"}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Step 2: Tee Times Grid */}
              <div className="space-y-3">
                <label className="block text-xs font-bold font-sans uppercase tracking-widest text-gray-400">
                  Select Departure Tee Time ({season})
                </label>
                <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
                  {teeTimes.map((slot) => (
                    <button
                      key={slot.time}
                      type="button"
                      disabled={!slot.available}
                      onClick={() => setSelectedTime(slot.time)}
                      className={`py-3.5 rounded text-sm font-bold font-sans border transition-all flex flex-col items-center justify-center ${
                        !slot.available
                          ? "bg-gray-100 border-gray-100 text-gray-300 cursor-not-allowed"
                          : selectedTime === slot.time
                          ? "bg-[#0a1f2c] border-transparent text-white scale-105 shadow"
                          : "bg-[#fcfbf9] border-gray-200 text-[#0a1f2c] hover:border-[#8c7355] hover:text-[#8c7355]"
                      }`}
                    >
                      <span>{slot.time}</span>
                      <span className="text-[9px] font-normal uppercase tracking-widest mt-1 opacity-60">
                        {slot.available ? "Open" : "Booked"}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 3: Elite Extras (Caddie & Buggy rentals) */}
              <div className="border-t border-gray-100 pt-6 space-y-4">
                <span className="text-xs font-bold font-sans uppercase tracking-[0.2em] text-[#8c7355] block">
                  Clubhouse Service Customization
                </span>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Caddie Hire */}
                  <div className="flex items-center justify-between bg-[#fcfbf9] border border-gray-100 p-4 rounded-lg">
                    <div>
                      <h4 className="font-serif font-bold text-sm">Professional Caddie</h4>
                      <p className="text-xs text-gray-400 mt-1">£50 / caddie • Expert course mapping</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setCaddiesCount(prev => Math.max(0, prev - 1))}
                        className="h-8 w-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-600 hover:border-gray-400 font-bold"
                      >
                        -
                      </button>
                      <span className="font-bold text-sm">{caddiesCount}</span>
                      <button
                        type="button"
                        onClick={() => setCaddiesCount(prev => Math.min(playersCount, prev + 1))}
                        className="h-8 w-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-600 hover:border-gray-400 font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  {/* Electric Buggy */}
                  <div className="flex items-center justify-between bg-[#fcfbf9] border border-gray-100 p-4 rounded-lg">
                    <div>
                      <h4 className="font-serif font-bold text-sm">Electric Links Buggy</h4>
                      <p className="text-xs text-gray-400 mt-1">£40 / GPS pre-loaded electric cart</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setBuggiesCount(prev => Math.max(0, prev - 1))}
                        className="h-8 w-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-600 hover:border-gray-400 font-bold"
                      >
                        -
                      </button>
                      <span className="font-bold text-sm">{buggiesCount}</span>
                      <button
                        type="button"
                        onClick={() => setBuggiesCount(prev => Math.min(Math.ceil(playersCount / 2), prev + 1))}
                        className="h-8 w-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-600 hover:border-gray-400 font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>

                </div>

              </div>

            </div>

            {/* Right Box: Visitor Details & Checkout Summary */}
            <div className="lg:col-span-5 space-y-8 bg-[#0a1f2c] text-white border border-white/5 rounded-xl p-8 shadow-2xl">
              
              <h3 className="font-serif text-2xl text-white tracking-tight border-b border-white/10 pb-4">
                Booking Checkout
              </h3>

              {/* Checkout Calculation Panel */}
              <div className="space-y-3 font-serif text-sm">
                
                <div className="flex justify-between text-gray-400">
                  <span>Selected Date:</span>
                  <span className="text-white font-sans">{date}</span>
                </div>

                <div className="flex justify-between text-gray-400">
                  <span>Departure Time:</span>
                  <span className={selectedTime ? "text-[#8c7355] font-sans font-bold" : "text-gray-600 italic"}>
                    {selectedTime || "Not Selected"}
                  </span>
                </div>

                <div className="flex justify-between border-t border-white/5 pt-3 text-gray-400">
                  <span>Green Fees ({playersCount} Golfers):</span>
                  <span className="text-white">£{baseTotal}</span>
                </div>

                {caddiesCount > 0 && (
                  <div className="flex justify-between text-gray-400">
                    <span>Professional Caddies ({caddiesCount}):</span>
                    <span className="text-white">£{caddieTotal}</span>
                  </div>
                )}

                {buggiesCount > 0 && (
                  <div className="flex justify-between text-gray-400">
                    <span>Electric Cart Rentals ({buggiesCount}):</span>
                    <span className="text-white">£{buggyTotal}</span>
                  </div>
                )}

                <div className="flex justify-between border-t border-white/10 pt-4 text-[#8c7355] text-lg font-bold">
                  <span>Total Due at Clubhouse:</span>
                  <span className="text-white">£{grandTotal}</span>
                </div>

              </div>

              {/* Secure Booking Form */}
              <form onSubmit={handleSubmitBooking} className="space-y-4 border-t border-white/5 pt-6 font-sans">
                
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                    Lead Golfer Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sir Richard Watson"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-[#143025] text-white border border-white/10 rounded px-4 py-2.5 text-sm focus:outline-none focus:border-[#8c7355]"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="richard@watson.co.uk"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-[#143025] text-white border border-white/10 rounded px-4 py-2.5 text-sm focus:outline-none focus:border-[#8c7355]"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+44 7624 123456"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-[#143025] text-white border border-white/10 rounded px-4 py-2.5 text-sm focus:outline-none focus:border-[#8c7355]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                    Special Accommodations / Dietary Notes
                  </label>
                  <textarea
                    rows={2}
                    placeholder="e.g., left-handed club rentals required, dietary restriction for seafood, etc."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full bg-[#143025] text-white border border-white/10 rounded px-4 py-2.5 text-xs focus:outline-none focus:border-[#8c7355] resize-none"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isLoading || !selectedTime}
                    className="w-full bg-[#8c7355] hover:bg-white text-[#0a1f2c] hover:text-[#0a1f2c] py-3 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all duration-300 disabled:bg-gray-700 disabled:text-gray-400 disabled:cursor-not-allowed"
                  >
                    {isLoading ? "Authenticating Reservation..." : "Confirm & Book Tee Time"}
                  </button>
                </div>

                <div className="flex items-center justify-center gap-2 text-[9px] text-gray-400 uppercase tracking-widest">
                  <ShieldAlert className="h-3 w-3 text-[#8c7355]" />
                  <span>No prepayment required. Settle directly at course.</span>
                </div>

              </form>

            </div>

          </div>
        )}

      </div>
    </div>
  );
}
