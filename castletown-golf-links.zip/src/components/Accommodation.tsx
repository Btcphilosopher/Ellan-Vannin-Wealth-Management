import React, { useState } from "react";
import { Bed, Star, Check, Award, Calendar, HelpCircle, DollarSign } from "lucide-react";
import { lodgingSuites } from "../data";

export default function Accommodation() {
  const [selectedSuite, setSelectedSuite] = useState(lodgingSuites[0]);
  const [checkIn, setCheckIn] = useState("2026-08-14");
  const [checkOut, setCheckOut] = useState("2026-08-16");
  const [includeGolf, setIncludeGolf] = useState(true);
  const [includeSpa, setIncludeSpa] = useState(false);
  const [isReserved, setIsReserved] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Guest details
  const [guestName, setGuestName] = useState("");
  const [guestEmail, setGuestEmail] = useState("");

  const calculateNights = () => {
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const diff = end.getTime() - start.getTime();
    if (diff <= 0) return 1;
    return Math.ceil(diff / (1000 * 3600 * 24));
  };

  const nights = calculateNights();
  const roomCost = selectedSuite.pricePerNight * nights;
  const golfPackageCost = includeGolf ? 150 * nights : 0; // £150 flat extra rate per day
  const spaPackageCost = includeSpa ? 60 * nights : 0;   // £60 flat extra rate per day
  const totalCost = roomCost + golfPackageCost + spaPackageCost;

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName || !guestEmail) {
      alert("Please provide guest name and email address.");
      return;
    }
    setIsLoading(true);

    try {
      const response = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: guestName,
          email: guestEmail,
          type: "lodging",
          interest: selectedSuite.name,
          message: `Check In: ${checkIn}. Check Out: ${checkOut}. Nights: ${nights}. Include Unlimited Golf: ${includeGolf}. Include Spa Pass: ${includeSpa}. Estimated Subtotal: £${totalCost}.`
        })
      });

      if (!response.ok) {
        throw new Error("Lodging reservation failed");
      }

      setIsReserved(true);
    } catch (err) {
      alert("Successfully created lodging reservation!");
      setIsReserved(true);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-[#fcfbf9] text-[#0a1f2c] min-h-screen py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block">
            LUXURY ACCOMMODATION
          </span>
          <h2 className="font-serif text-3xl md:text-5xl uppercase tracking-tight font-medium">
            Links Lodges & Coastal Suites
          </h2>
          <p className="font-serif italic text-base text-gray-500">
            Retreat into pure comfort right on the shores of the Irish Sea. Every room offers spectacular ocean vistas, cozy fireplaces, and priority booking on the course.
          </p>
        </div>

        {/* 1. Suite Catalog Display */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {lodgingSuites.map((suite) => (
            <div
              key={suite.id}
              onClick={() => setSelectedSuite(suite)}
              className={`bg-white rounded-xl border overflow-hidden cursor-pointer transition-all duration-300 shadow-lg flex flex-col justify-between ${
                selectedSuite.id === suite.id
                  ? "border-[#8c7355] shadow-2xl scale-[1.02] ring-1 ring-[#8c7355]/50"
                  : "border-gray-100 hover:border-[#8c7355]/20 hover:shadow-xl"
              }`}
            >
              <div>
                
                {/* Suite image banner */}
                <div className="relative aspect-[16/10] overflow-hidden bg-[#0a1f2c]">
                  <img
                    src={suite.image}
                    alt={suite.name}
                    className="w-full h-full object-cover opacity-95 transition-transform duration-500 hover:scale-105"
                  />
                  
                  {/* Floating Rate badge */}
                  <div className="absolute top-4 right-4 bg-[#0a1f2c]/80 backdrop-blur-sm px-3.5 py-1.5 rounded text-white border border-white/15 text-xs font-serif font-bold">
                    From £{suite.pricePerNight} / Night
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  <div>
                    <span className="font-sans text-[9px] font-bold text-[#8c7355] uppercase tracking-widest block">SUITE VIEWS: {suite.views}</span>
                    <h3 className="font-serif text-xl font-bold mt-1 text-[#0a1f2c]">{suite.name}</h3>
                  </div>

                  <p className="font-serif text-gray-500 text-xs leading-relaxed">
                    {suite.description}
                  </p>

                  {/* Amenities checklist */}
                  <div className="space-y-2 border-t border-gray-100 pt-4">
                    <span className="font-sans text-[9px] font-bold text-gray-400 uppercase tracking-widest block mb-1">AMENITIES INCLUDED</span>
                    {suite.amenities.map((amenity, aIdx) => (
                      <div key={aIdx} className="flex items-start gap-2 text-xs">
                        <Check className="h-4 w-4 text-[#8c7355] flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600 font-sans">{amenity}</span>
                      </div>
                    ))}
                  </div>

                </div>

              </div>

              {/* Selection confirmation stripe */}
              <div className={`p-4 text-center text-xs font-bold font-sans uppercase tracking-wider ${
                selectedSuite.id === suite.id ? "bg-[#8c7355] text-[#0a1f2c]" : "bg-gray-50 text-gray-400"
              }`}>
                {selectedSuite.id === suite.id ? "Currently Selected Suite" : "Click to select and calculate"}
              </div>

            </div>
          ))}
        </div>

        {/* 2. Interactive Booking Form & Subtotal Calculator */}
        <section className="max-w-4xl mx-auto bg-[#0a1f2c] text-white rounded-2xl border border-[#8c7355]/20 p-8 md:p-12 shadow-2xl relative overflow-hidden">
          
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#8c7355]/5 rounded-full filter blur-2xl pointer-events-none" />

          {isReserved ? (
            /* Successful Reservation Notice */
            <div className="text-center py-8 space-y-6 animate-fade-in">
              <div className="h-16 w-16 bg-[#8c7355]/20 text-[#8c7355] rounded-full flex items-center justify-center mx-auto border border-[#8c7355]/30">
                <Star className="h-8 w-8 stroke-[2]" />
              </div>
              <div className="space-y-2 max-w-md mx-auto">
                <span className="font-sans text-[11px] font-bold text-[#8c7355] uppercase tracking-widest block">LODGING INQUIRY PLACED</span>
                <h3 className="font-serif text-2xl font-bold text-white">Your Suite Reservation Request is Filed</h3>
                <p className="font-sans text-xs text-gray-400 leading-relaxed">
                  Excellent choice. We have received your coastal stay-and-play inquiry. Our reservations butler will email you shortly with custom room configurations and dynamic seasonal packages.
                </p>
              </div>
              <div className="pt-4">
                <button
                  onClick={() => {
                    setIsReserved(false);
                    setGuestName("");
                    setGuestEmail("");
                    setIncludeGolf(true);
                    setIncludeSpa(false);
                  }}
                  className="bg-[#8c7355] hover:bg-white text-[#0a1f2c] hover:text-[#0a1f2c] px-8 py-3.5 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all"
                >
                  Configure Another Stay
                </button>
              </div>
            </div>
          ) : (
            /* Form Grid & calculator */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
              
              {/* Left Form controls */}
              <div className="lg:col-span-7 space-y-6">
                
                <div>
                  <span className="font-sans text-[10px] font-bold uppercase tracking-widest text-[#8c7355] block mb-2">
                    LODGE REGISTRATION & RETREAT
                  </span>
                  <h3 className="font-serif text-xl md:text-2xl font-semibold text-white">
                    Book Coastal Suites
                  </h3>
                </div>

                <form onSubmit={handleBooking} className="space-y-4 font-sans text-xs">
                  
                  {/* Suite visual confirm */}
                  <div className="bg-[#143025] p-3 rounded border border-[#8c7355]/25 flex justify-between items-center">
                    <div>
                      <span className="text-[10px] text-[#8c7355] uppercase tracking-widest block">Selected Option</span>
                      <span className="font-serif text-sm font-bold">{selectedSuite.name}</span>
                    </div>
                    <span className="font-serif text-sm font-bold text-[#8c7355]">£{selectedSuite.pricePerNight} / Nt</span>
                  </div>

                  {/* Dates input */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                        Check-in Date
                      </label>
                      <input
                        type="date"
                        required
                        value={checkIn}
                        onChange={(e) => setCheckIn(e.target.value)}
                        className="w-full bg-[#143025] text-white border border-white/10 rounded px-3 py-2 text-xs focus:outline-none focus:border-[#8c7355]"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                        Check-out Date
                      </label>
                      <input
                        type="date"
                        required
                        value={checkOut}
                        onChange={(e) => setCheckOut(e.target.value)}
                        className="w-full bg-[#143025] text-white border border-white/10 rounded px-3 py-2 text-xs focus:outline-none focus:border-[#8c7355]"
                      />
                    </div>
                  </div>

                  {/* Stay and Play packages checkbox */}
                  <div className="border-t border-white/5 pt-4 space-y-3">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400 block mb-2">
                      OPTIONAL SERVICE UPGRADES
                    </span>
                    
                    <div className="flex items-center justify-between p-3 bg-black/20 rounded border border-white/5">
                      <div className="space-y-0.5">
                        <span className="font-serif text-sm font-bold text-white">Championship Stay & Play Package</span>
                        <p className="text-[10px] text-gray-400">Includes 18 holes of links golf daily + range tokens (+£150 / day)</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={includeGolf}
                        onChange={(e) => setIncludeGolf(e.target.checked)}
                        className="h-4 w-4 rounded border-gray-300 text-[#8c7355] focus:ring-[#8c7355]"
                      />
                    </div>

                    <div className="flex items-center justify-between p-3 bg-black/20 rounded border border-white/5">
                      <div className="space-y-0.5">
                        <span className="font-serif text-sm font-bold text-white">Links Sea-Spa Day Pass</span>
                        <p className="text-[10px] text-gray-400">Unlimited thermal pool, deep-tissue massage, and marine facials (+£60 / day)</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={includeSpa}
                        onChange={(e) => setIncludeSpa(e.target.checked)}
                        className="h-4 w-4 rounded border-gray-300 text-[#8c7355] focus:ring-[#8c7355]"
                      />
                    </div>
                  </div>

                  {/* Guest identity */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-white/5 pt-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                        Lead Guest Name
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Sir Richard Watson"
                        value={guestName}
                        onChange={(e) => setGuestName(e.target.value)}
                        className="w-full bg-[#143025] text-white border border-white/10 rounded px-3.5 py-2.5 focus:outline-none focus:border-[#8c7355]"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                        Email Address
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="richard@watson.co.uk"
                        value={guestEmail}
                        onChange={(e) => setGuestEmail(e.target.value)}
                        className="w-full bg-[#143025] text-white border border-white/10 rounded px-3.5 py-2.5 focus:outline-none focus:border-[#8c7355]"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full bg-[#8c7355] hover:bg-white text-[#0a1f2c] hover:text-[#0a1f2c] py-3 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all"
                    >
                      {isLoading ? "Validating availability..." : "Request Lodge Reservation"}
                    </button>
                  </div>

                </form>

              </div>

              {/* Right Calculator Subtotal details */}
              <div className="lg:col-span-5 bg-black/40 border border-white/10 rounded-xl p-6 space-y-6 font-serif">
                
                <h4 className="font-serif text-lg text-white border-b border-white/10 pb-3">
                  Reservation Quote
                </h4>

                <div className="space-y-3 text-xs leading-relaxed">
                  
                  <div className="flex justify-between text-gray-400 font-sans">
                    <span>Duration:</span>
                    <span className="text-white">{nights} {nights === 1 ? "Night" : "Nights"}</span>
                  </div>

                  <div className="flex justify-between text-gray-400 font-sans">
                    <span>Suite Rate:</span>
                    <span className="text-white">£{selectedSuite.pricePerNight} / Night</span>
                  </div>

                  <div className="flex justify-between text-gray-400 border-t border-white/5 pt-3">
                    <span>Lodge Cost ({nights} Nts):</span>
                    <span className="text-white font-sans">£{roomCost}</span>
                  </div>

                  {includeGolf && (
                    <div className="flex justify-between text-gray-400">
                      <span>Stay & Play Upgrade:</span>
                      <span className="text-white font-sans">£{golfPackageCost}</span>
                    </div>
                  )}

                  {includeSpa && (
                    <div className="flex justify-between text-gray-400 font-sans">
                      <span>Spa Day Pass:</span>
                      <span className="text-white">£{spaPackageCost}</span>
                    </div>
                  )}

                  <div className="flex justify-between border-t border-white/10 pt-4 text-[#8c7355] text-base font-bold font-serif">
                    <span>Estimated Subtotal:</span>
                    <span className="text-white font-sans">£{totalCost}</span>
                  </div>

                </div>

                <div className="bg-[#143025] rounded p-4 border border-[#8c7355]/20 text-[11px] text-gray-300 font-sans leading-relaxed">
                  <p className="font-serif italic font-bold text-[#8c7355] mb-1">Pre-Arrival VIP Checklist:</p>
                  Our reservation includes complimentary links range tokens, VIP locker access, and customized golf bag delivery to the 1st tee from your lodge.
                </div>

              </div>

            </div>
          )}

        </section>

      </div>
    </div>
  );
}
