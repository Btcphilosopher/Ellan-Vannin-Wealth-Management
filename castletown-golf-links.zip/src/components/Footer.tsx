import React, { useState } from "react";
import { Mail, Compass, Phone, ShieldCheck, Instagram, Facebook } from "lucide-react";

interface FooterProps {
  setActiveView: (view: string) => void;
}

export default function Footer({ setActiveView }: FooterProps) {
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setIsSubscribed(true);
    setNewsletterEmail("");
  };

  const linksGroup1 = [
    { label: "Book a Tee Time", view: "booking" },
    { label: "Interactive Hole Map", view: "course" },
    { label: "Members Hub", view: "portal" },
    { label: "Championship Outings", view: "corporate" }
  ];

  const linksGroup2 = [
    { label: "Clubhouse Gastronomy", view: "clubhouse" },
    { label: "Lodges & Coastal Suites", view: "accommodation" },
    { label: "PGA Golf Academy", view: "academy" },
    { label: "Luxury Pro Shop", view: "shop" }
  ];

  return (
    <footer className="bg-[#0a1f2c] border-t border-[#8c7355]/25 text-white py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-6 space-y-16">
        
        {/* Upper Split Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
          
          {/* Brand Col */}
          <div className="md:col-span-4 space-y-4">
            <h3 className="font-serif text-2xl tracking-widest font-semibold text-white uppercase">
              Castletown
            </h3>
            <span className="font-serif italic text-[#8c7355] text-sm block">
              Est. 1892 • Isle of Man
            </span>
            <p className="font-sans text-xs text-gray-400 leading-relaxed max-w-sm">
              Castletown Golf Links sits on the spectacular Langness Peninsula, surrounded by the Irish Sea. It provides an unmatched, world-class championship links experience.
            </p>
            <div className="flex items-center gap-3 pt-2 text-gray-400">
              <a href="https://instagram.com" target="_blank" rel="noreferrer" className="hover:text-[#8c7355] transition-colors">
                <Instagram className="h-4 w-4" />
              </a>
              <a href="https://facebook.com" target="_blank" rel="noreferrer" className="hover:text-[#8c7355] transition-colors">
                <Facebook className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Quick Links Group 1 */}
          <div className="md:col-span-2 space-y-4 text-xs font-sans">
            <h4 className="text-[#8c7355] font-bold uppercase tracking-widest text-[10px]">
              Championship
            </h4>
            <ul className="space-y-2.5 text-gray-400">
              {linksGroup1.map((link, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => {
                      setActiveView(link.view);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="hover:text-[#8c7355] transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links Group 2 */}
          <div className="md:col-span-2 space-y-4 text-xs font-sans">
            <h4 className="text-[#8c7355] font-bold uppercase tracking-widest text-[10px]">
              The Resort
            </h4>
            <ul className="space-y-2.5 text-gray-400">
              {linksGroup2.map((link, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => {
                      setActiveView(link.view);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="hover:text-[#8c7355] transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Coordinates & Newsletter Col */}
          <div className="md:col-span-4 space-y-6">
            
            <div className="space-y-3 font-sans text-xs">
              <h4 className="text-[#8c7355] font-bold uppercase tracking-widest text-[10px]">
                The Clubhouse Lodge
              </h4>
              <p className="text-gray-400 leading-relaxed flex items-start gap-2">
                <Compass className="h-4 w-4 text-[#8c7355] flex-shrink-0 mt-0.5" />
                <span>Derbyhaven, Castletown IM9 1UA, Isle of Man</span>
              </p>
              <p className="text-gray-400 flex items-center gap-2">
                <Phone className="h-4 w-4 text-[#8c7355] flex-shrink-0" />
                <span>+44 1624 822211</span>
              </p>
            </div>

            {/* Newsletter Subscription */}
            <div className="space-y-3">
              <h4 className="text-[#8c7355] font-bold uppercase tracking-widest text-[10px] font-sans">
                THE CASTLETOWN DISPATCH
              </h4>
              <p className="text-[11px] text-gray-400 font-serif italic">
                Subscribe to receive seasonal greens updates, WHS tournament schedules, and lodging events.
              </p>

              {isSubscribed ? (
                <div className="bg-white/5 border border-[#8c7355]/20 p-3 rounded-none text-center text-xs font-sans font-bold text-[#8c7355] uppercase tracking-wider animate-fade-in">
                  Welcome to the Club Dispatch.
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex gap-2 font-sans text-xs">
                  <input
                    type="email"
                    required
                    placeholder="clint@royalmanx.com"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    className="flex-1 bg-[#0a1f2c] text-white border border-white/10 rounded-none px-3 py-2 focus:outline-none focus:border-[#8c7355]"
                  />
                  <button
                    type="submit"
                    className="bg-[#8c7355] hover:bg-white text-white hover:text-[#0a1f2c] px-4 py-2 rounded-none font-bold uppercase tracking-widest transition-colors flex items-center gap-1.5"
                  >
                    <Mail className="h-3.5 w-3.5" />
                    Join
                  </button>
                </form>
              )}
            </div>

          </div>

        </div>

        {/* Lower row: Copyright, terms, disclaimer */}
        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between text-[10px] text-gray-500 font-sans tracking-wide">
          <p>© 2026 Castletown Golf Links. All Rights Reserved. Redesigned by the Isle of Man Golf Society.</p>
          <div className="flex gap-4 mt-4 md:mt-0">
            <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#8c7355] transition-colors">Privacy Policy</a>
            <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#8c7355] transition-colors">Terms of Play</a>
            <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#8c7355] transition-colors flex items-center gap-1">
              <ShieldCheck className="h-3 w-3 text-[#8c7355]" />
              R&A SafeGolf Accredited
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
}
