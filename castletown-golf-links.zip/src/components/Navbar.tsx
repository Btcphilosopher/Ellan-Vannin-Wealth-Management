import React, { useState } from "react";
import { Menu, X, ChevronDown, Shield, Trophy, ShoppingBag, Landmark, Key, PhoneCall, HelpCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface NavbarProps {
  activeView: string;
  setActiveView: (view: string) => void;
}

export default function Navbar({ activeView, setActiveView }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  // Nav categories matching prompt
  const menuItems = [
    {
      label: "The Course",
      view: "course",
      submenu: [
        { label: "18-Hole Tour", view: "course" },
        { label: "Interactive Map", view: "course" },
        { label: "Course Status & Conditions", view: "portal" }
      ]
    },
    {
      label: "Experience",
      view: "clubhouse",
      submenu: [
        { label: "Luxury Clubhouse", view: "clubhouse" },
        { label: "Restaurant & Whisky Bar", view: "clubhouse" },
        { label: "Golf Lodges & Stay", view: "stay" },
        { label: "TrackMan Academy", view: "academy" }
      ]
    },
    {
      label: "Visit",
      view: "booking",
      submenu: [
        { label: "Book a Tee Time", view: "booking" },
        { label: "Championship Events", view: "events" },
        { label: "Luxury Pro Shop", view: "shop" }
      ]
    },
    {
      label: "Membership",
      view: "membership",
      submenu: [
        { label: "Membership Packages", view: "membership" },
        { label: "Online Application", view: "membership" },
        { label: "Private Member Portal", view: "portal" }
      ]
    },
    { label: "Corporate", view: "corporate" },
    { label: "Contact", view: "contact" }
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#f5f2ed]/95 backdrop-blur-md border-b border-[#0a1f2c]/10 shadow-sm px-6 md:px-12 py-4 transition-all duration-300">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* Brand Logo & Crest */}
        <button
          onClick={() => {
            setActiveView("home");
            setIsOpen(false);
          }}
          className="flex items-center gap-1 text-left focus:outline-none group"
          id="nav-logo"
        >
          <div className="w-8 h-8 border-2 border-[#8c7355] flex items-center justify-center transform rotate-45 mr-3 transition-transform duration-500 group-hover:rotate-[225deg]">
            <span className="text-[10px] font-bold -rotate-45 text-[#8c7355]">CGL</span>
          </div>
          <div>
            <span className="font-serif italic tracking-widest text-xl text-[#0a1f2c] block leading-none">
              Castletown
            </span>
            <span className="text-[9px] tracking-[0.25em] text-[#8c7355] block uppercase font-sans font-semibold mt-1">
              Est. 1892 • Isle of Man
            </span>
          </div>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-8">
          {menuItems.map((item) => (
            <div
              key={item.label}
              className="relative group"
              onMouseEnter={() => item.submenu ? setActiveDropdown(item.label) : null}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button
                onClick={() => {
                  setActiveView(item.view);
                  setActiveDropdown(null);
                }}
                className={`flex items-center gap-1 font-sans text-[11px] font-medium uppercase tracking-[0.2em] transition-colors duration-200 py-2 ${
                  activeView === item.view ? "text-[#8c7355]" : "text-[#0a1f2c]/80 hover:text-[#8c7355]"
                }`}
              >
                {item.label}
                {item.submenu && <ChevronDown className="h-3 w-3 transition-transform duration-300 group-hover:rotate-180" />}
              </button>

              {/* Sophisticated Submenu Dropdown */}
              {item.submenu && activeDropdown === item.label && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 w-60 bg-[#f5f2ed] border border-[#0a1f2c]/10 rounded-none shadow-2xl p-2 z-50 animate-fade-in">
                  {item.submenu.map((sub) => (
                    <button
                      key={sub.label}
                      onClick={() => {
                        setActiveView(sub.view);
                        setActiveDropdown(null);
                      }}
                      className="w-full text-left font-serif text-[13px] text-[#0a1f2c]/80 hover:text-[#8c7355] hover:bg-[#0a1f2c]/5 rounded-none px-4 py-2.5 transition-all duration-150"
                    >
                      {sub.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Desktop Action Button */}
        <div className="hidden lg:flex items-center gap-4">
          <button
            onClick={() => setActiveView("portal")}
            className={`font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-colors ${
              activeView === "portal" ? "text-[#8c7355]" : "text-[#0a1f2c]/80 hover:text-[#8c7355]"
            } flex items-center gap-1.5`}
            title="Member Portal"
          >
            <Key className="h-3.5 w-3.5" />
            Portal
          </button>
          
          <button
            onClick={() => setActiveView("shop")}
            className={`font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-colors ${
              activeView === "shop" ? "text-[#8c7355]" : "text-[#0a1f2c]/80 hover:text-[#8c7355]"
            } flex items-center gap-1.5 mr-2`}
            title="Luxury Shop"
          >
            <ShoppingBag className="h-3.5 w-3.5" />
            Shop
          </button>

          <button
            onClick={() => setActiveView("booking")}
            className="bg-[#0a1f2c] text-white hover:bg-[#8c7355] px-6 py-2.5 rounded-none font-sans text-[11px] uppercase tracking-[0.2em] transition-all duration-300 border border-[#0a1f2c]"
            id="book-tee-cta"
          >
            Book a Tee Time
          </button>
        </div>

        {/* Mobile Navigation Trigger */}
        <div className="lg:hidden flex items-center gap-4">
          <button
            onClick={() => setActiveView("booking")}
            className="bg-[#0a1f2c] text-white px-4 py-2 rounded-none font-sans text-[10px] font-bold uppercase tracking-[0.15em]"
          >
            Book
          </button>
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="text-[#0a1f2c] hover:text-[#8c7355] transition-colors"
            aria-label="Toggle Menu"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden w-full overflow-hidden bg-[#f5f2ed] border-t border-[#0a1f2c]/10 mt-4"
          >
            <div className="py-6 px-4 space-y-6">
              {menuItems.map((item) => (
                <div key={item.label} className="space-y-2">
                  <button
                    onClick={() => {
                      if (!item.submenu) {
                        setActiveView(item.view);
                        setIsOpen(false);
                      } else {
                        setActiveDropdown(activeDropdown === item.label ? null : item.label);
                      }
                    }}
                    className="w-full text-left font-serif text-lg text-[#0a1f2c] font-semibold flex items-center justify-between"
                  >
                    <span>{item.label}</span>
                    {item.submenu && <ChevronDown className={`h-4 w-4 transition-transform ${activeDropdown === item.label ? "rotate-180" : ""}`} />}
                  </button>

                  {item.submenu && activeDropdown === item.label && (
                    <div className="pl-4 space-y-2 border-l border-[#8c7355]/30 py-1">
                      {item.submenu.map((sub) => (
                        <button
                          key={sub.label}
                          onClick={() => {
                            setActiveView(sub.view);
                            setIsOpen(false);
                          }}
                          className="block w-full text-left font-sans text-[13px] text-[#0a1f2c]/60 hover:text-[#8c7355] py-1.5"
                        >
                          {sub.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              <div className="pt-4 border-t border-[#0a1f2c]/10 space-y-4">
                <button
                  onClick={() => {
                    setActiveView("portal");
                    setIsOpen(false);
                  }}
                  className="flex items-center gap-2 text-[#0a1f2c]/80 font-sans text-sm font-semibold"
                >
                  <Key className="h-4 w-4 text-[#8c7355]" />
                  Member Portal
                </button>
                <button
                  onClick={() => {
                    setActiveView("shop");
                    setIsOpen(false);
                  }}
                  className="flex items-center gap-2 text-[#0a1f2c]/80 font-sans text-sm font-semibold"
                >
                  <ShoppingBag className="h-4 w-4 text-[#8c7355]" />
                  Pro Shop e-Commerce
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
