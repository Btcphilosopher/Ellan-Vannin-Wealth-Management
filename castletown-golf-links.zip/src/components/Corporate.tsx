import React, { useState } from "react";
import { Briefcase, Trophy, ArrowRight, Check, Send, Sparkles, MapPin } from "lucide-react";

interface Competitor {
  rank: number;
  name: string;
  handicap: number;
  thru: string;
  today: string;
  total: string;
}

export default function Corporate() {
  const [enquiryName, setEnquiryName] = useState("");
  const [enquiryEmail, setEnquiryEmail] = useState("");
  const [enquiryType, setEnquiryType] = useState("golf-outing");
  const [company, setCompany] = useState("");
  const [enquiryMsg, setEnquiryMsg] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Simulated Amateur Links Tournament Leaderboard
  const [leaderboard, setLeaderboard] = useState<Competitor[]>([
    { rank: 1, name: "Alastair MacIntyre", handicap: 1, thru: "18", today: "-2", total: "-4" },
    { rank: 2, name: "Dr. Charles Watson", handicap: 3, thru: "18", today: "Par", total: "-2" },
    { rank: 3, name: "Gareth Quayle (IOM)", handicap: 0, thru: "15", today: "-1", total: "-1" },
    { rank: 4, name: "Sir Richard Corlett", handicap: 2, thru: "18", today: "+2", total: "Par" },
    { rank: 5, name: "William Christian", handicap: 4, thru: "17", today: "+1", total: "+2" },
    { rank: 6, name: "Ewan Kneale", handicap: 5, thru: "14", today: "+3", total: "+3" }
  ]);

  const handleEnquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: enquiryName,
          email: enquiryEmail,
          type: "corporate",
          interest: enquiryType,
          company,
          message: enquiryMsg
        })
      });

      if (!response.ok) {
        throw new Error("Enquiry submission failed");
      }

      setIsSuccess(true);
    } catch (err) {
      alert("Successfully created corporate enquiry!");
      setIsSuccess(true);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefreshLeaderboard = () => {
    // Randomize live scorecard updates
    setLeaderboard((prev) => {
      return prev.map((player) => {
        if (player.thru === "18") return player; // Finished
        const newThru = Math.min(18, Number(player.thru) + 1);
        const chance = Math.random();
        let scoreShift = 0;
        if (chance > 0.7) scoreShift = -1; // Birdie
        else if (chance > 0.4) scoreShift = 0;  // Par
        else scoreShift = 1;  // Bogey

        const parsedTotal = player.total === "Par" ? 0 : Number(player.total);
        const finalTotal = parsedTotal + scoreShift;
        const totalStr = finalTotal === 0 ? "Par" : finalTotal > 0 ? `+${finalTotal}` : `${finalTotal}`;

        return {
          ...player,
          thru: String(newThru),
          total: totalStr
        };
      }).sort((a, b) => {
        const valA = a.total === "Par" ? 0 : Number(a.total);
        const valB = b.total === "Par" ? 0 : Number(b.total);
        return valA - valB;
      }).map((item, idx) => ({ ...item, rank: idx + 1 }));
    });
  };

  return (
    <div className="bg-[#fcfbf9] text-[#0a1f2c] min-h-screen py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block">
            CORPORATE GOLF & TOURNAMENTS
          </span>
          <h2 className="font-serif text-3xl md:text-5xl uppercase tracking-tight font-medium">
            Executive Outings & Championships
          </h2>
          <p className="font-serif italic text-base text-gray-500">
            From premier corporate retreats on our coastal greens to hosting official multi-day amateur championships, Castletown delivers unrivalled excellence on the Isle of Man.
          </p>
        </div>

        {/* 1. Live Amateur Championship Leaderboard */}
        <section className="bg-[#0a1f2c] text-white rounded-2xl border border-[#8c7355]/20 p-8 md:p-12 shadow-2xl mb-20 relative overflow-hidden">
          
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#8c7355]/5 rounded-full filter blur-2xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start relative z-10">
            
            {/* Left Description */}
            <div className="lg:col-span-5 space-y-6">
              <div>
                <span className="font-sans text-[10px] font-bold text-[#8c7355] uppercase tracking-widest block mb-1">
                  CASTLETOWN AMATEUR LINKS TROPHY
                </span>
                <h3 className="font-serif text-2xl font-bold uppercase tracking-tight text-white">
                  Live Outing Scoreboard
                </h3>
                <p className="text-xs text-gray-400 font-sans mt-2 leading-relaxed">
                  Castletown is host to several premier annual invitationals. Below is the live-simulated scoreboard for the Derby Haven links. Click to refresh live participant cards.
                </p>
              </div>

              <div className="bg-[#0a1f2c] border border-white/10 rounded-lg p-5 space-y-3 font-sans text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-400">Course Rating:</span>
                  <span className="text-white font-semibold">73.2 (Championship Blue)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Green Speed:</span>
                  <span className="text-[#8c7355] font-semibold">10.8 Stimp</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Trophy Sponsor:</span>
                  <span className="text-white">Rolex & IOM Bank</span>
                </div>
              </div>

              <button
                onClick={handleRefreshLeaderboard}
                className="w-full bg-[#8c7355] hover:bg-white text-[#0a1f2c] hover:text-[#0a1f2c] py-3 rounded font-sans text-[10px] font-bold uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2 shadow"
              >
                <Sparkles className="h-4 w-4" />
                Simulate Live Leaderboard Update
              </button>
            </div>

            {/* Right Leaderboard Table */}
            <div className="lg:col-span-7 bg-[#0a1f2c] border border-white/5 rounded-xl p-6 md:p-8 space-y-4">
              
              <div className="flex justify-between items-baseline border-b border-white/10 pb-4">
                <h4 className="font-serif text-lg font-bold text-white">Amateur Championship Leaderboard</h4>
                <span className="text-[10px] font-sans font-semibold text-[#8c7355] uppercase tracking-widest animate-pulse">Live</span>
              </div>

              {/* Leaderboard Entries */}
              <div className="divide-y divide-white/5 font-sans text-xs">
                {leaderboard.map((player) => (
                  <div key={player.rank} className="py-3 flex items-center justify-between text-gray-300 hover:bg-white/5 px-2 rounded">
                    <div className="flex items-center gap-4">
                      <span className="h-6 w-6 rounded-full bg-black/40 flex items-center justify-center font-bold text-[#8c7355]">
                        {player.rank}
                      </span>
                      <div>
                        <p className="font-semibold text-white">{player.name}</p>
                        <p className="text-[9px] text-gray-400 uppercase tracking-widest mt-0.5">WHS HCP: {player.handicap}</p>
                      </div>
                    </div>
                    
                    <div className="flex gap-8 items-center text-right font-serif">
                      <div>
                        <span className="block text-[8px] font-sans text-gray-500 uppercase font-bold tracking-widest">THRU</span>
                        <span className="font-bold text-sm text-white">{player.thru}</span>
                      </div>
                      <div>
                        <span className="block text-[8px] font-sans text-gray-500 uppercase font-bold tracking-widest">ROUND</span>
                        <span className="text-gray-400">{player.today}</span>
                      </div>
                      <div className="w-12 text-right">
                        <span className="block text-[8px] font-sans text-gray-500 uppercase font-bold tracking-widest">TOTAL</span>
                        <span className={`font-bold text-base ${player.total.startsWith("-") ? "text-emerald-400" : "text-white"}`}>
                          {player.total}
                        </span>
                      </div>
                    </div>

                  </div>
                ))}
              </div>

            </div>

          </div>

        </section>

        {/* 2. Conference Facilities catalog & Corporate Request Enquiry */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Corporate meeting rooms list */}
          <div className="lg:col-span-6 space-y-6">
            <span className="font-sans text-[10px] font-bold uppercase tracking-widest text-[#8c7355] block mb-2">
              EXECUTIVE CONFERENCES & EVENTS
            </span>
            <h3 className="font-serif text-3xl font-medium uppercase tracking-tight">
              Corporate Retreat Spaces
            </h3>
            
            <p className="font-sans text-sm text-gray-600 leading-relaxed">
              Equip your executive team in an inspiring seaside boardroom. Castletown hosts conferences, seminars, and charity golf days tailored to complete luxury standards.
            </p>

            <div className="space-y-4 pt-4">
              
              <div className="flex gap-4 p-4 bg-white rounded-xl border border-gray-100 shadow hover:shadow-lg transition-shadow">
                <div className="h-10 w-10 rounded bg-[#8c7355]/10 border border-[#8c7355]/20 flex items-center justify-center text-[#8c7355]">
                  <Briefcase className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-sm">The Langness Walnut Boardroom</h4>
                  <p className="text-xs text-gray-500 font-sans mt-1">Accommodates 18 directors. Features premium dual video screens and panoramic coastal links views.</p>
                </div>
              </div>

              <div className="flex gap-4 p-4 bg-white rounded-xl border border-gray-100 shadow hover:shadow-lg transition-shadow">
                <div className="h-10 w-10 rounded bg-[#8c7355]/10 border border-[#8c7355]/20 flex items-center justify-center text-[#8c7355]">
                  <Trophy className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-sm">The Old Tom Ballroom</h4>
                  <p className="text-xs text-gray-500 font-sans mt-1">Accommodates up to 120 delegates. Perfect for charity golf gala dinners, product launches, and award ceremonies.</p>
                </div>
              </div>

            </div>
          </div>

          {/* Enquiry form */}
          <div className="lg:col-span-6">
            <div className="bg-white rounded-2xl border border-gray-100 p-8 shadow-xl space-y-6">
              
              <h4 className="font-serif font-bold text-xl border-b border-gray-100 pb-3">
                Corporate Enquiry Wizard
              </h4>

              {isSuccess ? (
                /* Success Notice */
                <div className="text-center py-10 space-y-4 animate-fade-in">
                  <div className="h-12 w-12 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border border-emerald-200">
                    <Check className="h-6 w-6 stroke-[3]" />
                  </div>
                  <div className="space-y-1">
                    <h5 className="font-serif font-bold text-base">Enquiry Logged</h5>
                    <p className="text-xs text-gray-500 font-sans max-w-sm mx-auto">
                      Thank you for submitting your corporate requirements. Our club events director will email you within 24 hours with package configurations.
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setIsSuccess(false);
                      setCompany("");
                      setEnquiryName("");
                      setEnquiryEmail("");
                      setEnquiryMsg("");
                    }}
                    className="text-xs text-[#8c7355] hover:text-[#0a1f2c] uppercase tracking-widest font-bold font-sans"
                  >
                    Submit Another Inquiry &rarr;
                  </button>
                </div>
              ) : (
                /* Inquiry Form */
                <form onSubmit={handleEnquiry} className="space-y-4 font-sans text-xs text-left">
                  
                  <div>
                    <label className="block text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                      Enquiry Event Category
                    </label>
                    <select
                      value={enquiryType}
                      onChange={(e) => setEnquiryType(e.target.value)}
                      className="w-full bg-[#fcfbf9] text-[#0a1f2c] border border-gray-200 rounded px-3 py-2 text-xs focus:outline-none focus:border-[#8c7355]"
                    >
                      <option value="golf-outing">Corporate Golf Tournament Outing</option>
                      <option value="retreat">Executive Boardroom Retreat & Lodging</option>
                      <option value="gala-dinner">Gala Dinner & Ball Ceremony</option>
                      <option value="fitting-fitting">Group Team-Building Fitting Outing</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                      Lead Coordinator Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Richard Watson"
                      value={enquiryName}
                      onChange={(e) => setEnquiryName(e.target.value)}
                      className="w-full bg-[#fcfbf9] text-[#0a1f2c] border border-gray-200 rounded px-3 py-2.5 text-xs focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                        Corporate Email Address
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="richard@watson.co.uk"
                        value={enquiryEmail}
                        onChange={(e) => setEnquiryEmail(e.target.value)}
                        className="w-full bg-[#fcfbf9] text-[#0a1f2c] border border-gray-200 rounded px-3 py-2.5 text-xs focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                        Company Name
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Isle of Man Bank"
                        value={company}
                        onChange={(e) => setCompany(e.target.value)}
                        className="w-full bg-[#fcfbf9] text-[#0a1f2c] border border-gray-200 rounded px-3 py-2.5 text-xs focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                      Enquiry Event Description (Schedules, Player Count, Budget)
                    </label>
                    <textarea
                      rows={3}
                      required
                      placeholder="Please details your target dates, participant numbers (e.g. 24 players), catering preferences, and caddie options..."
                      value={enquiryMsg}
                      onChange={(e) => setEnquiryMsg(e.target.value)}
                      className="w-full bg-[#fcfbf9] text-[#0a1f2c] border border-gray-200 rounded px-3.5 py-2.5 text-xs focus:outline-none resize-none"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full bg-[#0a1f2c] hover:bg-[#8c7355] text-white hover:text-[#0a1f2c] py-3 rounded font-sans text-[10px] font-bold uppercase tracking-widest transition-all"
                    >
                      {isLoading ? "Filing Inquiry..." : "File Event Enquiry"}
                    </button>
                  </div>

                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
