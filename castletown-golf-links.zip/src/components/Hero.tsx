import React from "react";
import { Compass, Calendar, Award } from "lucide-react";
import { motion } from "motion/react";

interface HeroProps {
  setActiveView: (view: string) => void;
}

export default function Hero({ setActiveView }: HeroProps) {
  return (
    <section className="relative min-h-[750px] lg:h-[85vh] bg-[#f5f2ed] text-[#0a1f2c] border-b border-[#0a1f2c]/10 flex flex-col justify-between overflow-hidden">
      
      <div className="flex-grow flex relative">
        
        {/* Left vertical artistic gutter (visible on lg screens) */}
        <div className="hidden lg:flex absolute left-0 top-0 h-full w-[120px] border-r border-[#0a1f2c]/10 items-center justify-center bg-[#f5f2ed] z-20">
          <span className="vertical-rl rotate-180 text-[10px] uppercase tracking-[0.6em] text-[#8c7355] font-semibold">
            THE CHAMPIONSHIP LINKS OF THE ISLE OF MAN
          </span>
        </div>

        {/* Content & Splitting Container */}
        <div className="w-full lg:pl-[120px] flex flex-col lg:flex-row">
          
          {/* Left Column: Artistic Typography & Description */}
          <div className="w-full lg:w-3/5 p-8 md:p-16 lg:p-24 flex flex-col justify-center relative z-10">
            
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-3"
            >
              <span className="inline-block text-[11px] uppercase tracking-[0.3em] text-[#8c7355] font-bold mb-1">
                ESTABLISHED 1892 • BY OLD TOM MORRIS
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.15 }}
              className="font-serif text-[48px] md:text-[76px] lg:text-[84px] leading-[0.95] text-[#0a1f2c] mb-6 tracking-tight uppercase"
            >
              Where <br/>
              <span className="italic text-[#8c7355]">Heritage</span> <br/>
              Meets the Sea
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.3 }}
              className="max-w-md text-[#0a1f2c]/80 text-[14px] md:text-[16px] font-sans leading-relaxed mb-8"
            >
              Experience one of Britain’s finest championship links. Preserving raw peninsular craftsmanship on the Langness Peninsula, surrounded by the wild tides of the Irish Sea.
            </motion.p>

            {/* Premium Button Controls & Aesthetic Lines */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.45 }}
              className="space-y-6"
            >
              <div className="flex flex-wrap gap-4 items-center">
                <button
                  onClick={() => setActiveView("booking")}
                  className="bg-[#0a1f2c] text-white hover:bg-[#8c7355] px-6 py-3 text-[11px] uppercase tracking-[0.2em] transition-all duration-300"
                >
                  Book a Tee Time
                </button>

                <button
                  onClick={() => setActiveView("membership")}
                  className="bg-transparent text-[#0a1f2c] border border-[#0a1f2c]/20 hover:border-[#0a1f2c] px-6 py-3 text-[11px] uppercase tracking-[0.2em] transition-all duration-300"
                >
                  Explore Membership
                </button>
              </div>

              <div className="flex space-x-6 items-center pt-2">
                <div className="w-12 h-[1px] bg-[#0a1f2c]/30"></div>
                <button
                  onClick={() => setActiveView("course")}
                  className="text-[11px] uppercase tracking-[0.3em] font-bold flex items-center group text-[#0a1f2c] hover:text-[#8c7355] transition-colors"
                >
                  Virtual Course Tour 
                  <span className="ml-2 group-hover:translate-x-2 transition-transform">→</span>
                </button>
              </div>
            </motion.div>

          </div>

          {/* Right Column: Overlay Polaroid and Dark Canvas */}
          <div className="w-full lg:w-2/5 min-h-[380px] lg:min-h-0 relative bg-[#0a1f2c] overflow-hidden flex items-center">
            
            {/* Background Texture with Mix Blend */}
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?q=80&w=1000&auto=format&fit=crop')] bg-cover bg-center opacity-40 mix-blend-overlay"></div>
            
            {/* Rotating floating offset Polaroid Card (only fully styled on md/lg screens, adjusted on mobile) */}
            <div className="absolute top-12 left-1/2 -translate-x-1/2 lg:-left-20 lg:translate-x-0 w-[280px] md:w-[320px] h-[340px] md:h-[380px] bg-[#f5f2ed] p-1.5 shadow-2xl transform lg:rotate-3 transition-transform duration-500 hover:rotate-0 z-20">
              <div className="w-full h-full bg-[url('https://images.unsplash.com/photo-1535131749006-b7f58c99034b?q=80&w=1000&auto=format&fit=crop')] bg-cover bg-center"></div>
              
              {/* Overlapping small signature badge */}
              <div className="absolute -bottom-6 -right-6 bg-[#0a1f2c] text-white p-5 shadow-lg hidden md:block">
                <span className="block text-[28px] font-serif leading-none text-[#8c7355]">17</span>
                <span className="block text-[9px] uppercase tracking-[0.2em] mt-1 text-gray-300">Signature Hole</span>
              </div>
            </div>

            {/* Bottom-right parameters block */}
            <div className="absolute bottom-6 right-6 lg:bottom-12 lg:right-12 text-[#f5f2ed]/80 z-20 font-sans hidden md:block">
              <div className="flex space-x-10">
                <div>
                  <span className="block text-[9px] uppercase tracking-widest text-[#8c7355] mb-1">Par</span>
                  <span className="block text-xl font-serif text-white">72</span>
                </div>
                <div>
                  <span className="block text-[9px] uppercase tracking-widest text-[#8c7355] mb-1">Yards</span>
                  <span className="block text-xl font-serif text-white">6,712</span>
                </div>
                <div>
                  <span className="block text-[9px] uppercase tracking-widest text-[#8c7355] mb-1">CR</span>
                  <span className="block text-xl font-serif text-white">73.5</span>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* Sub-footer metadata bar inside hero section */}
      <div className="w-full h-14 border-t border-[#0a1f2c]/10 px-6 lg:px-12 flex items-center justify-between text-[10px] uppercase tracking-[0.2em] font-semibold text-[#0a1f2c]/60 z-20 bg-[#f5f2ed]">
        <div className="flex flex-wrap gap-x-8 gap-y-1">
          <div className="flex items-center">
            <div className="w-2 h-2 rounded-full bg-[#2d4a3e] mr-3 animate-pulse"></div>
            Course Condition: Excellent
          </div>
          <div className="hidden sm:block">Wind: SW 14mph</div>
          <div className="hidden sm:block">Green Speed: 10.5</div>
        </div>
        <div className="flex space-x-4">
          <span className="text-[#8c7355]">Isle of Man Golf</span>
        </div>
      </div>

    </section>
  );
}
