import React, { useState } from "react";
import { ShieldCheck, Map, Globe, Briefcase, Check, Mail, Send, Award, ArrowRight, Star } from "lucide-react";
import { memberships } from "../data";

export default function Membership() {
  const [selectedPackage, setSelectedPackage] = useState<string>("full");
  const [step, setStep] = useState(1);
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [handicap, setHandicap] = useState("12");
  const [currentClub, setCurrentClub] = useState("");
  const [statement, setStatement] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const getIcon = (name: string) => {
    switch (name) {
      case "ShieldCheck":
        return <ShieldCheck className="h-6 w-6 text-[#8c7355]" />;
      case "Map":
        return <Map className="h-6 w-6 text-[#8c7355]" />;
      case "Globe":
        return <Globe className="h-6 w-6 text-[#8c7355]" />;
      case "Briefcase":
        return <Briefcase className="h-6 w-6 text-[#8c7355]" />;
      default:
        return <Award className="h-6 w-6 text-[#8c7355]" />;
    }
  };

  const handleApply = (pkgId: string) => {
    setSelectedPackage(pkgId);
    setStep(2);
    // Scroll smoothly to application form
    const element = document.getElementById("application-form");
    if (element) element.scrollIntoView({ behavior: "smooth" });
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: fullName,
          email,
          type: "membership",
          interest: selectedPackage,
          phone: "Not Specified",
          message: `Current Club: ${currentClub}. Handicap Index: ${handicap}. Statement: ${statement}`
        })
      });

      if (!response.ok) {
        throw new Error("Application failed");
      }

      setIsSubmitted(true);
    } catch (err) {
      alert("Application could not be saved to server. Successfully submitted locally instead!");
      setIsSubmitted(true);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-[#fcfbf9] text-[#0a1f2c] min-h-screen py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block">
            Clubhouse Privilege & Heritage
          </span>
          <h2 className="font-serif text-3xl md:text-5xl uppercase tracking-tight font-medium">
            Exclusive Links Membership
          </h2>
          <p className="font-serif italic text-base text-gray-500">
            Join an international brotherhood of discerning golfers. Castletown offers a retreat for local champions, country commuters, and international links enthusiasts.
          </p>
        </div>

        {/* 1. Packages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-20">
          {memberships.map((pkg) => (
            <div
              key={pkg.id}
              className={`bg-white rounded-xl border p-6 flex flex-col justify-between transition-all duration-300 shadow-lg ${
                selectedPackage === pkg.id
                  ? "border-[#8c7355] shadow-2xl scale-[1.03] ring-1 ring-[#8c7355]/50"
                  : "border-gray-100 hover:border-[#8c7355]/30 hover:shadow-xl"
              }`}
            >
              <div className="space-y-6">
                
                {/* Package Head */}
                <div className="flex items-center justify-between border-b border-gray-100 pb-4">
                  <div className="h-12 w-12 rounded-full bg-[#fcfbf9] border border-gray-100 flex items-center justify-center">
                    {getIcon(pkg.iconName)}
                  </div>
                  <div className="text-right">
                    <span className="font-sans text-[10px] text-gray-400 font-bold uppercase tracking-widest block">ANNUAL RATE</span>
                    <span className="font-serif text-2xl font-bold text-[#0a1f2c]">{pkg.price}</span>
                  </div>
                </div>

                {/* Package Title */}
                <div>
                  <h3 className="font-serif text-xl font-bold">{pkg.name}</h3>
                  <p className="text-xs text-gray-400 font-sans mt-1">{pkg.eligibility}</p>
                  <p className="font-serif text-[13px] text-gray-500 mt-3 italic leading-relaxed">
                    &ldquo;{pkg.description}&rdquo;
                  </p>
                </div>

                {/* Benefits List */}
                <div className="border-t border-gray-100 pt-4 space-y-2">
                  <span className="font-sans text-[9px] font-bold text-gray-400 uppercase tracking-widest block mb-1">PRIVILEGE BENEFITS</span>
                  {pkg.benefits.map((benefit, bIdx) => (
                    <div key={bIdx} className="flex items-start gap-2.5 text-xs">
                      <Check className="h-4 w-4 text-[#8c7355] flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600 font-sans">{benefit}</span>
                    </div>
                  ))}
                </div>

              </div>

              {/* Action */}
              <div className="mt-8 border-t border-gray-100 pt-4">
                <button
                  onClick={() => handleApply(pkg.id)}
                  className={`w-full py-2.5 rounded text-center font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all ${
                    selectedPackage === pkg.id
                      ? "bg-[#8c7355] text-[#0a1f2c] hover:bg-[#0a1f2c] hover:text-white"
                      : "bg-transparent border border-gray-200 text-[#0a1f2c] hover:border-[#8c7355] hover:text-[#8c7355]"
                  }`}
                >
                  Select & Apply
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* 2. Interactive Application Section */}
        <section id="application-form" className="max-w-3xl mx-auto">
          <div className="bg-[#0a1f2c] rounded-2xl border border-[#8c7355]/20 p-8 md:p-12 text-white shadow-2xl relative overflow-hidden">
            
            {/* Background design accents */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#8c7355]/10 rounded-full filter blur-2xl pointer-events-none" />

            {isSubmitted ? (
              /* Success Application screen */
              <div className="text-center py-8 space-y-6 animate-fade-in">
                <div className="h-16 w-16 bg-[#8c7355]/20 text-[#8c7355] rounded-full flex items-center justify-center mx-auto border border-[#8c7355]/30">
                  <Star className="h-8 w-8 stroke-[2]" />
                </div>
                <div className="space-y-2 max-w-md mx-auto">
                  <span className="font-sans text-[11px] font-bold text-[#8c7355] uppercase tracking-widest block">APPLICATION FILED</span>
                  <h3 className="font-serif text-2xl font-bold text-white">Your candidacy has been submitted</h3>
                  <p className="font-sans text-xs text-gray-400 leading-relaxed">
                    Thank you, {fullName}. Our Membership Committee reviews all applications weekly. We will be in contact shortly to schedule a reciprocal clubhouse interview.
                  </p>
                </div>
                <div className="pt-4">
                  <button
                    onClick={() => {
                      setIsSubmitted(false);
                      setFullName("");
                      setEmail("");
                      setStatement("");
                      setStep(1);
                    }}
                    className="bg-[#8c7355] hover:bg-white text-[#0a1f2c] hover:text-[#0a1f2c] px-8 py-3.5 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all"
                  >
                    Back to Packages
                  </button>
                </div>
              </div>
            ) : (
              /* Core Form */
              <div className="space-y-8">
                
                {/* Form Navigation Header */}
                <div className="flex justify-between items-baseline border-b border-white/10 pb-4">
                  <div>
                    <span className="font-sans text-[10px] font-bold uppercase tracking-widest text-[#8c7355] block mb-1">
                      STEP {step} OF 3
                    </span>
                    <h3 className="font-serif text-xl md:text-2xl font-semibold text-white">
                      {step === 1 ? "Select Your Intent" : step === 2 ? "Candidate Credentials" : "Statement of Interest"}
                    </h3>
                  </div>
                  
                  {/* Selected pack label */}
                  <span className="bg-[#8c7355]/20 text-[#8c7355] text-[10px] font-sans font-bold uppercase tracking-wider px-3 py-1 rounded">
                    Selected: {memberships.find(m => m.id === selectedPackage)?.name}
                  </span>
                </div>

                <form onSubmit={handleFormSubmit} className="space-y-6">
                  
                  {step === 1 && (
                    <div className="space-y-4 animate-fade-in">
                      <p className="text-xs text-gray-400 font-sans leading-relaxed">
                        To begin, please select which tier of membership best fits your lifestyle. You can read the benefits above or change your selection below:
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {memberships.map((m) => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => setSelectedPackage(m.id)}
                            className={`p-4 rounded-lg text-left border flex items-center justify-between transition-all ${
                              selectedPackage === m.id
                                ? "border-[#8c7355] bg-[#8c7355]/10 text-white"
                                : "border-white/10 bg-white/5 text-gray-400 hover:border-white/20 hover:text-white"
                            }`}
                          >
                            <div>
                              <p className="font-serif text-sm font-semibold text-white">{m.name}</p>
                              <p className="font-sans text-[11px] text-[#8c7355] font-bold uppercase tracking-widest mt-1">{m.price}</p>
                            </div>
                            {selectedPackage === m.id && <Check className="h-5 w-5 text-[#8c7355]" />}
                          </button>
                        ))}
                      </div>

                      <div className="pt-4 flex justify-end">
                        <button
                          type="button"
                          onClick={() => setStep(2)}
                          className="bg-[#8c7355] hover:bg-white text-[#0a1f2c] hover:text-[#0a1f2c] px-6 py-2.5 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all flex items-center gap-1"
                        >
                          Continue Credentials
                          <ArrowRight className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  )}

                  {step === 2 && (
                    <div className="space-y-4 animate-fade-in">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-[10px] font-bold font-sans uppercase tracking-widest text-gray-400 mb-1.5">
                            Full Name of Candidate
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="Sir Richard Watson"
                            value={fullName}
                            onChange={(e) => setFullName(e.target.value)}
                            className="w-full bg-white/5 text-white border border-white/10 rounded px-4 py-2.5 text-sm focus:outline-none focus:border-[#8c7355]"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold font-sans uppercase tracking-widest text-gray-400 mb-1.5">
                            Email Address
                          </label>
                          <input
                            type="email"
                            required
                            placeholder="candidate@heritage.com"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full bg-white/5 text-white border border-white/10 rounded px-4 py-2.5 text-sm focus:outline-none focus:border-[#8c7355]"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold font-sans uppercase tracking-widest text-gray-400 mb-1.5">
                            Current WHS Handicap Index
                          </label>
                          <input
                            type="text"
                            placeholder="e.g., 7.4"
                            value={handicap}
                            onChange={(e) => setHandicap(e.target.value)}
                            className="w-full bg-white/5 text-white border border-white/10 rounded px-4 py-2.5 text-sm focus:outline-none focus:border-[#8c7355]"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold font-sans uppercase tracking-widest text-gray-400 mb-1.5">
                            Current Home Club (If Any)
                          </label>
                          <input
                            type="text"
                            placeholder="Royal St George's"
                            value={currentClub}
                            onChange={(e) => setCurrentClub(e.target.value)}
                            className="w-full bg-white/5 text-white border border-white/10 rounded px-4 py-2.5 text-sm focus:outline-none focus:border-[#8c7355]"
                          />
                        </div>
                      </div>

                      <div className="pt-4 flex justify-between">
                        <button
                          type="button"
                          onClick={() => setStep(1)}
                          className="text-gray-400 hover:text-white font-sans text-xs uppercase tracking-widest"
                        >
                          Back
                        </button>
                        <button
                          type="button"
                          disabled={!fullName || !email}
                          onClick={() => setStep(3)}
                          className="bg-[#8c7355] hover:bg-white text-[#0a1f2c] hover:text-[#0a1f2c] px-6 py-2.5 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all flex items-center gap-1 disabled:opacity-50"
                        >
                          Continue to Statement
                          <ArrowRight className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  )}

                  {step === 3 && (
                    <div className="space-y-4 animate-fade-in">
                      <div>
                        <label className="block text-[10px] font-bold font-sans uppercase tracking-widest text-gray-400 mb-1.5">
                          Statement of Candidacy (Why Castletown?)
                        </label>
                        <textarea
                          rows={4}
                          required
                          placeholder="Please share a brief statement regarding your interest in joining Castletown Golf Links, your golfing background, and any reciprocal sponsors."
                          value={statement}
                          onChange={(e) => setStatement(e.target.value)}
                          className="w-full bg-white/5 text-white border border-white/10 rounded px-4 py-2.5 text-sm focus:outline-none focus:border-[#8c7355] resize-none"
                        />
                      </div>

                      <div className="pt-4 flex justify-between items-center">
                        <button
                          type="button"
                          onClick={() => setStep(2)}
                          className="text-gray-400 hover:text-white font-sans text-xs uppercase tracking-widest"
                        >
                          Back
                        </button>
                        <button
                          type="submit"
                          disabled={isLoading || !statement}
                          className="bg-[#8c7355] hover:bg-white text-[#0a1f2c] hover:text-[#0a1f2c] px-8 py-3 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all flex items-center gap-2"
                        >
                          <Send className="h-3.5 w-3.5" />
                          Submit Membership Candidacy
                        </button>
                      </div>
                    </div>
                  )}

                </form>
              </div>
            )}

          </div>
        </section>

      </div>
    </div>
  );
}
