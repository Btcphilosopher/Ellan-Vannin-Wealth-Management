import React from "react";
import { Trophy, Wind, Shield, Flag, Award } from "lucide-react";

interface FeaturesBandProps {
  setActiveView: (view: string) => void;
}

export default function FeaturesBand({ setActiveView }: FeaturesBandProps) {
  const highlights = [
    {
      icon: <Trophy className="h-5 w-5" />,
      title: "Championship Course",
      desc: "A world-class links experience.",
      view: "course"
    },
    {
      icon: <Wind className="h-5 w-5" />,
      title: "Breathtaking Setting",
      desc: "Spectacular coastal views in every direction.",
      view: "portal"
    },
    {
      icon: <Shield className="h-5 w-5" />,
      title: "Heritage & Tradition",
      desc: "A proud golfing heritage, reimagined for today.",
      view: "home"
    },
    {
      icon: <Flag className="h-5 w-5" />,
      title: "Premium Facilities",
      desc: "Exceptional amenities and unrivalled hospitality.",
      view: "clubhouse"
    },
    {
      icon: <Award className="h-5 w-5" />,
      title: "Exclusive Experiences",
      desc: "Tailored moments for discerning golfers.",
      view: "membership"
    }
  ];

  return (
    <section className="bg-[#0a1f2c] border-y border-[#8c7355]/25 py-12 md:py-16 text-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 md:gap-4 divide-y md:divide-y-0 md:divide-x divide-[#8c7355]/20">
          {highlights.map((item, idx) => (
            <button
              key={idx}
              onClick={() => setActiveView(item.view)}
              className="flex flex-col items-center text-center p-4 focus:outline-none group transition-all duration-300 hover:-translate-y-1 w-full"
            >
              {/* Bronze/Gold Icon Frame */}
              <div className="text-[#8c7355] mb-5 p-3 border border-[#8c7355]/30 bg-[#f5f2ed]/5 transform rotate-45 transition-all duration-300 group-hover:bg-[#8c7355]/10 group-hover:border-[#8c7355] group-hover:scale-105">
                <div className="-rotate-45">
                  {item.icon}
                </div>
              </div>
              
              {/* Title in serif */}
              <h3 className="font-serif text-[12px] font-semibold tracking-[0.15em] text-white uppercase mb-2 group-hover:text-[#8c7355] transition-colors">
                {item.title}
              </h3>
              
              {/* Description in subtle sans */}
              <p className="text-[11px] leading-relaxed text-gray-400 font-sans px-2">
                {item.desc}
              </p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
