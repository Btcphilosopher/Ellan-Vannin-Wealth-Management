import React, { useState } from "react";
import { GraduationCap, Award, Video, Star, HelpCircle, Check, ArrowRight, Settings } from "lucide-react";

interface SwingIssue {
  miss: string;
  label: string;
  diagnosis: string;
  pathFace: string;
  tip: string;
  drill: string;
  drillSteps: string[];
}

export default function Academy() {
  const [selectedMiss, setSelectedMiss] = useState<string>("slice");

  const swingIssues: Record<string, SwingIssue> = {
    slice: {
      miss: "slice",
      label: "The Banana Slice",
      diagnosis: "The ball starts slightly left, then curves violently to the right (for right-handed golfers), losing major distance and finding the heavy gorse bushes.",
      pathFace: "Out-to-In Swing Path with a Clubface that is OPEN relative to the swing path at impact.",
      tip: "Focus on closing your shoulder alignment at set up and letting your hands roll over. Release the toe of the club toward the sky on your follow-through.",
      drill: "The Under-The-Arm Headcover Drill",
      drillSteps: [
        "Place an empty golf headcover under your right armpit (for righties).",
        "Take small, half-swings, keeping the headcover pinched securely against your torso.",
        "This forces your arms to swing in connection with your body rotation, neutralizing the out-to-in 'over the top' motion."
      ]
    },
    hook: {
      miss: "hook",
      label: "The Snap Hook",
      diagnosis: "The ball curves rapidly to the left (for right-handed golfers), diving low and fast into the hazard or left-side dunes.",
      pathFace: "In-to-Out Swing Path with a Clubface that is closed relative to the path at impact.",
      tip: "Weaken your grip slightly by rotating both hands toward the target. Ensure your hips rotate open at impact instead of sliding sideways.",
      drill: "The Open Toe Release Drill",
      drillSteps: [
        "Take a normal stance, but flare your lead foot open about 30 degrees.",
        "On the downswing, focus on rotating your lead hip out of the way, keeping your chest pointing at the ball slightly longer.",
        "This slows down overactive hands, holding the face square rather than closing it prematurely."
      ]
    },
    push: {
      miss: "push",
      label: "The Straight Push / Block",
      diagnosis: "The ball flies straight out to the right (for righties) with no curvature, missing the fairway entirely in a straight block.",
      pathFace: "In-to-Out Swing Path with a Clubface that is open to the target line, but square to the path.",
      tip: "Check your feet and hip alignment. Often a push is caused by aligning your body too far right. Ensure your chest rotates fully through to the target on the finish.",
      drill: "The Alignment Rod Alignment Drill",
      drillSteps: [
        "Lay an alignment rod parallel to your target line, and a second rod parallel to your feet.",
        "Make sure your shoulders, hips, and feet are perfectly square to the rods.",
        "On downswing, ensure your hands drop inside the line rather than getting stuck behind your hips."
      ]
    },
    pull: {
      miss: "pull",
      label: "The Straight Pull",
      diagnosis: "The ball flies dead straight to the left (for righties) on a straight path into the left-side hazards, with no curve.",
      pathFace: "Out-to-In Swing Path with a Clubface that is closed to the target line, but square to the swing path.",
      tip: "Ensure you are not reaching too far at setup. Pulls are often caused by standing too close or reaching, forcing an over-the-top hand path.",
      drill: "The Tee Gate Drill",
      drillSteps: [
        "Stick a tee in the ground 2 inches outside your ball, and a second tee 2 inches inside.",
        "Swing through the gate. If you hit the outside tee, you are coming over-the-top (pull path).",
        "Focus on sweeping the ball cleanly through the gate from the inside."
      ]
    },
    thin: {
      miss: "thin",
      label: "The Thin / Bladed Top",
      diagnosis: "The club strikes the top half of the ball, sending a low, skulling missile along the ground, often overshooting the greens.",
      pathFace: "Low Point of the swing is behind the ball or too shallow; club is ascending at impact.",
      tip: "Keep your spine angle constant throughout the swing. Avoid lifting your head or chest on the downswing to 'help' the ball into the air.",
      drill: "The Penny-on-the-Turf Drill",
      drillSteps: [
        "Place a small coin (or a leaf) 1 inch directly in front of your golf ball.",
        "During your swing, ignore the ball and focus entirely on striking the coin off the turf.",
        "This shift forces your hands forward and encourages a downward strike through the ball."
      ]
    },
    fat: {
      miss: "fat",
      label: "The Fat / Chunk Shot",
      diagnosis: "The club strikes the turf behind the ball, digging a large divot and leaving the ball well short of the target.",
      pathFace: "Weight remains on the back foot on the downswing, causing the low point to occur early.",
      tip: "Ensure your weight shifts dynamically onto your lead leg during the transition. Your chest should be directly over the ball at impact.",
      drill: "The Back-Foot Step Drill",
      drillSteps: [
        "Take a normal stance, but lift your back heel slightly off the ground.",
        "At the top of your backswing, lift your back foot entirely, balancing on your front leg.",
        "Initiate the downswing by stepping forward firmly, ensuring 90% of your weight finishes on the lead side."
      ]
    }
  };

  const currentSwing = swingIssues[selectedMiss];

  const coachingPackages = [
    {
      name: "PGA Swing Diagnosis Session",
      price: "£85",
      duration: "50 Minutes",
      features: [
        "High-Speed camera video analysis",
        "TrackMan 4 launch monitor metrics",
        "Personalized email lesson recap with drills",
        "Targeted club-gapping optimization"
      ]
    },
    {
      name: "The TrackMan Simulator Bundle",
      price: "£290",
      duration: "4 x 50 Min Package",
      features: [
        "Comprehensive swing-path recalibration",
        "High-tech putting laboratory analysis",
        "Tide-and-wind course simulation",
        "Custom club fitting & yardage matrix"
      ]
    },
    {
      name: "Links Master Coach Intensive",
      price: "£450",
      duration: "Half-Day Masterclass",
      features: [
        "9-hole playing lesson with PGA Head Pro",
        "On-course wind strategy guidance",
        "Chipping and sand-save short game lab",
        "Premium lunch at The 1892 Restaurant included"
      ]
    }
  ];

  return (
    <div className="bg-[#fcfbf9] text-[#0a1f2c] min-h-screen py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block">
            Castletown Golf Academy
          </span>
          <h2 className="font-serif text-3xl md:text-5xl uppercase tracking-tight font-medium">
            Professional Instruction
          </h2>
          <p className="font-serif italic text-base text-gray-500">
            Unleash your full potential using advanced TrackMan 4 launch monitors, high-speed camera swing analysis, and expert coaching from PGA Master Professionals.
          </p>
        </div>

        {/* 1. Interactive Swing Analysis & Diagnosis Widget */}
        <section className="bg-[#0a1f2c] text-white rounded-2xl border border-[#8c7355]/20 p-8 md:p-12 shadow-2xl mb-20 relative overflow-hidden">
          
          <div className="absolute top-0 left-0 w-32 h-32 bg-[#8c7355]/5 rounded-full filter blur-2xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start relative z-10">
            
            {/* Widget Left Col: Selector and general description */}
            <div className="lg:col-span-5 space-y-6">
              <div>
                <span className="font-sans text-[10px] font-bold text-[#8c7355] uppercase tracking-widest block mb-1">
                  INTERACTIVE PGA DICTIONARY
                </span>
                <h3 className="font-serif text-2xl font-bold uppercase tracking-tight text-white">
                  Links Swing Diagnostics
                </h3>
                <p className="text-xs text-gray-400 font-sans mt-2 leading-relaxed">
                  Select your most common misfire on the links. Our virtual PGA trainer will diagnose the physical mechanics and prescribe target adjustments.
                </p>
              </div>

              {/* Selector Buttons */}
              <div className="grid grid-cols-2 gap-3 font-sans">
                {Object.values(swingIssues).map((item) => (
                  <button
                    key={item.miss}
                    type="button"
                    onClick={() => setSelectedMiss(item.miss)}
                    className={`py-3.5 px-4 text-xs font-bold uppercase tracking-wider rounded-lg border text-center transition-all ${
                      selectedMiss === item.miss
                        ? "bg-[#8c7355] border-transparent text-[#0a1f2c] scale-105 shadow"
                        : "border-white/10 bg-white/5 text-gray-400 hover:border-white/20 hover:text-white"
                    }`}
                  >
                    {item.label.replace("The ", "")}
                  </button>
                ))}
              </div>
            </div>

            {/* Widget Right Col: Dynamic Diagnosis Results */}
            <div className="lg:col-span-7 bg-[#0a1f2c] border border-white/10 rounded-xl p-8 space-y-6">
              
              {/* Heading */}
              <div className="border-b border-white/10 pb-4 flex items-center justify-between">
                <div>
                  <span className="font-sans text-[10px] text-[#8c7355] font-bold uppercase tracking-widest">PGA DIAGNOSIS REPORT</span>
                  <h4 className="font-serif text-2xl text-white font-bold mt-1">{currentSwing.label}</h4>
                </div>
                <div className="h-10 w-10 rounded-full bg-[#8c7355]/10 border border-[#8c7355]/30 flex items-center justify-center text-[#8c7355]">
                  <Settings className="h-5 w-5 animate-spin-slow" />
                </div>
              </div>

              {/* Diagnosis Details */}
              <div className="space-y-4">
                
                <div>
                  <span className="block font-sans text-[10px] font-bold text-gray-400 uppercase tracking-widest">THE PHYSICAL ERROR</span>
                  <p className="font-serif text-sm text-gray-200 mt-1 leading-relaxed">
                    {currentSwing.diagnosis}
                  </p>
                </div>

                <div>
                  <span className="block font-sans text-[10px] font-bold text-gray-400 uppercase tracking-widest">FACE & PATH RELATIONSHIP</span>
                  <p className="font-sans text-xs text-[#8c7355] font-bold mt-1 tracking-wide uppercase">
                    {currentSwing.pathFace}
                  </p>
                </div>

                <div className="border-t border-white/5 pt-4">
                  <span className="block font-sans text-[10px] font-bold text-gray-400 uppercase tracking-widest">PRO COACH ADVICE</span>
                  <p className="font-serif text-sm italic text-gray-300 mt-1 leading-relaxed pl-4 border-l border-[#8c7355]">
                    &ldquo;{currentSwing.tip}&rdquo;
                  </p>
                </div>

                {/* Drill section */}
                <div className="border-t border-white/15 pt-4 space-y-2">
                  <span className="block font-sans text-[10px] font-bold text-gray-400 uppercase tracking-widest">RECOMMENDED DRILL: {currentSwing.drill}</span>
                  <div className="space-y-2 pl-1">
                    {currentSwing.drillSteps.map((step, idx) => (
                      <div key={idx} className="flex gap-2.5 text-xs text-gray-300">
                        <span className="text-[#8c7355] font-bold font-sans">{idx + 1}.</span>
                        <p className="font-sans leading-relaxed">{step}</p>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>

          </div>

        </section>

        {/* 2. Coaching Packages Catalog */}
        <div className="space-y-6">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="font-sans text-[9px] font-bold text-[#8c7355] uppercase tracking-widest block mb-2">CURRICULUM RATE CARD</span>
            <h3 className="font-serif text-2xl md:text-3xl uppercase tracking-tight">Coaching Programmes</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {coachingPackages.map((pkg, idx) => (
              <div key={idx} className="bg-white border border-gray-100 rounded-xl p-8 flex flex-col justify-between shadow-lg transition-transform duration-300 hover:-translate-y-1">
                <div className="space-y-6">
                  
                  {/* Head */}
                  <div className="flex justify-between items-baseline border-b border-gray-100 pb-4">
                    <span className="font-sans text-xs font-bold text-gray-400 uppercase tracking-widest">{pkg.duration}</span>
                    <span className="font-serif text-2xl font-bold text-[#0a1f2c]">{pkg.price}</span>
                  </div>

                  {/* Title */}
                  <h4 className="font-serif text-xl font-bold">{pkg.name}</h4>

                  {/* Features */}
                  <div className="space-y-2">
                    {pkg.features.map((feature, fIdx) => (
                      <div key={fIdx} className="flex items-center gap-2 text-xs text-gray-600 font-sans">
                        <Check className="h-4 w-4 text-[#8c7355] flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>

                </div>

                <div className="mt-8 pt-4 border-t border-gray-100">
                  <button
                    onClick={() => {
                      alert(`Thank you. Please book or schedule the "${pkg.name}" course by speaking with our PGA Head Professional via phone (+44 1624 822211) or utilizing the general Contact enquiry.`);
                    }}
                    className="w-full py-2.5 bg-[#0a1f2c] hover:bg-[#8c7355] text-white hover:text-[#0a1f2c] rounded font-sans text-[11px] font-bold uppercase tracking-widest transition-all"
                  >
                    Schedule Lesson
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
