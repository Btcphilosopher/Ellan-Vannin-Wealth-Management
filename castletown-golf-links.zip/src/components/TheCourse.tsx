import React, { useState } from "react";
import { Play, MapPin, Compass, Wind, Layers, Trophy, Download, ChevronLeft, ChevronRight, X } from "lucide-react";
import { holesData } from "../data";
import { motion, AnimatePresence } from "motion/react";

export default function TheCourse() {
  const [selectedHoleIdx, setSelectedHoleIdx] = useState(16); // Default to signature 17th
  const [isVideoOpen, setIsVideoOpen] = useState(false);
  const currentHole = holesData[selectedHoleIdx];

  const handleNextHole = () => {
    setSelectedHoleIdx((prev) => (prev + 1) % 18);
  };

  const handlePrevHole = () => {
    setSelectedHoleIdx((prev) => (prev - 1 + 18) % 18);
  };

  return (
    <div className="bg-[#fcfbf9] text-[#0a1f2c] min-h-screen">
      
      {/* 1. Masterpiece Section (Reproduces the split panel in the Mockup) */}
      <section className="max-w-7xl mx-auto px-6 py-16 md:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Side Content */}
          <div className="lg:col-span-5 space-y-6">
            <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block">
              The Course
            </span>
            <h2 className="font-serif text-3xl md:text-5xl tracking-tight uppercase leading-tight font-medium">
              A Masterpiece <br />of Links Golf
            </h2>
            <p className="font-sans text-sm text-gray-600 leading-relaxed max-w-md">
              Castletown Golf Course has been thoughtfully redeveloped to create one of the finest links courses in the British Isles. Pure, natural, and unforgettable, with spectacular coastal views in every direction.
            </p>
            <div className="pt-2">
              <button
                onClick={() => {
                  const element = document.getElementById("interactive-tour-guide");
                  if (element) element.scrollIntoView({ behavior: "smooth" });
                }}
                className="bg-transparent hover:bg-[#0a1f2c] text-[#0a1f2c] hover:text-white border border-[#0a1f2c] px-8 py-3.5 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all duration-300"
              >
                Explore the Course
              </button>
            </div>
          </div>

          {/* Right Side Video Overlay Panel */}
          <div className="lg:col-span-7">
            <div className="relative aspect-[16/9] w-full overflow-hidden rounded-xl shadow-2xl group border border-gray-200 bg-[#0a1f2c]">
              <img
                src="https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?auto=format&fit=crop&w=1200&q=80"
                alt="Castletown links course landscape with historical fort"
                className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-black/15 group-hover:bg-black/30 transition-all duration-300" />
              
              {/* Play Button Trigger */}
              <button
                onClick={() => setIsVideoOpen(true)}
                className="absolute inset-0 flex flex-col items-center justify-center text-white focus:outline-none"
              >
                <div className="h-16 w-16 flex items-center justify-center rounded-full bg-white/20 hover:bg-white text-white hover:text-[#0a1f2c] border border-white/40 transition-all duration-300 scale-100 hover:scale-110 shadow-2xl mb-4">
                  <Play className="h-6 w-6 fill-current translate-x-0.5" />
                </div>
                <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-white">
                  Watch the Film
                </span>
              </button>
            </div>
          </div>

        </div>
      </section>

      {/* 2. Interactive 18-Hole Tour Guide */}
      <section id="interactive-tour-guide" className="bg-[#0a1f2c] text-white py-16 md:py-24 border-t border-[#8c7355]/10">
        <div className="max-w-7xl mx-auto px-6">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row items-start md:items-end justify-between mb-12 gap-6">
            <div>
              <span className="font-sans text-[10px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block mb-2">
                Interactive Fly-over Tour
              </span>
              <h2 className="font-serif text-3xl md:text-5xl uppercase tracking-tight font-medium">
                The 18-Hole Guide
              </h2>
            </div>
            
            {/* Download Button */}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                alert("Downloadable yardage booklet and strategy guidebook saved directly to your device.");
              }}
              className="flex items-center gap-2 bg-[#8c7355]/15 hover:bg-[#8c7355] text-[#8c7355] hover:text-[#0a1f2c] border border-[#8c7355]/30 hover:border-transparent px-5 py-2.5 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all duration-300"
            >
              <Download className="h-4 w-4" />
              Download Yardage Guide (PDF)
            </a>
          </div>

          {/* 18-Hole Circular Selector Row */}
          <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-12 no-scrollbar border-b border-white/5">
            {holesData.map((hole, idx) => (
              <button
                key={hole.number}
                onClick={() => setSelectedHoleIdx(idx)}
                className={`flex-shrink-0 h-11 w-11 rounded-full flex items-center justify-center font-sans text-xs font-bold border transition-all duration-200 ${
                  selectedHoleIdx === idx
                    ? "bg-[#8c7355] border-transparent text-[#0a1f2c] scale-110 shadow-lg"
                    : "border-white/10 text-gray-400 hover:border-white/35 hover:text-white"
                }`}
              >
                {hole.number}
              </button>
            ))}
          </div>

          {/* Immersive Hole Detail Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* Left Col: Cinematic Hole Visualizer with strategy details */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xl shadow-2xl border border-white/10">
                <img
                  src={currentHole.image}
                  alt={currentHole.name}
                  className="w-full h-full object-cover opacity-80"
                />
                
                {/* Wind / Compass Visual Float Overlay */}
                <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-sm p-3 rounded border border-white/10 text-[11px] font-sans text-gray-300">
                  <div className="flex items-center gap-2 text-[#8c7355] uppercase tracking-widest font-bold mb-1">
                    <Compass className="h-4 w-4" />
                    Wind Factor
                  </div>
                  <p>{currentHole.prevailingWind}</p>
                </div>

                {/* Signature View Label */}
                {currentHole.signature && (
                  <div className="absolute bottom-4 left-4 bg-[#8c7355] text-[#0a1f2c] text-[10px] font-bold uppercase tracking-[0.25em] px-3 py-1.5 rounded flex items-center gap-1.5">
                    <Trophy className="h-3.5 w-3.5" />
                    Signature Hole
                  </div>
                )}

                {/* Hole Navigation Floating Buttons */}
                <div className="absolute bottom-4 right-4 flex gap-2">
                  <button
                    onClick={handlePrevHole}
                    className="h-10 w-10 flex items-center justify-center rounded bg-black/60 hover:bg-[#8c7355] text-white hover:text-[#0a1f2c] transition-all"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </button>
                  <button
                    onClick={handleNextHole}
                    className="h-10 w-10 flex items-center justify-center rounded bg-black/60 hover:bg-[#8c7355] text-white hover:text-[#0a1f2c] transition-all"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </button>
                </div>
              </div>

              {/* Digital Interactive Map / Wind gauge mock visualizer */}
              <div className="bg-[#0a1f2c] rounded-xl border border-white/5 p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-gray-400 text-[11px] font-sans uppercase tracking-widest">
                    <Layers className="h-4 w-4 text-[#8c7355]" />
                    Green Contours
                  </div>
                  <p className="font-serif text-[13px] text-gray-200">{currentHole.greenContours}</p>
                </div>

                <div className="space-y-2 border-t md:border-t-0 md:border-l border-white/5 md:pl-6">
                  <div className="flex items-center gap-2 text-gray-400 text-[11px] font-sans uppercase tracking-widest">
                    <Wind className="h-4 w-4 text-[#8c7355]" />
                    Ideal Wind Route
                  </div>
                  <p className="font-serif text-[13px] text-gray-200">Play standard low runner. Avoid aerial shots when wind is above 15 knots.</p>
                </div>

                <div className="space-y-2 border-t md:border-t-0 md:border-l border-white/5 md:pl-6">
                  <div className="flex items-center gap-2 text-gray-400 text-[11px] font-sans uppercase tracking-widest">
                    <MapPin className="h-4 w-4 text-[#8c7355]" />
                    Signature View
                  </div>
                  <p className="font-serif text-[13px] text-gray-200">Looking out to sea. Langness lighthouse on the horizon.</p>
                </div>

              </div>

            </div>

            {/* Right Col: Scorecard, Strategy Details */}
            <div className="lg:col-span-5 space-y-8 bg-[#0a1f2c] border border-white/5 rounded-xl p-8 shadow-2xl">
              
              {/* Hole Header */}
              <div className="border-b border-white/10 pb-6 flex items-baseline justify-between">
                <div>
                  <h3 className="font-serif text-3xl font-semibold uppercase text-white">
                    Hole {currentHole.number}
                  </h3>
                  <p className="font-serif italic text-lg text-[#8c7355] mt-1">
                    &ldquo;{currentHole.name}&rdquo;
                  </p>
                </div>
                <div className="text-right">
                  <span className="font-sans text-[11px] font-bold text-gray-400 uppercase tracking-widest">HANDICAP INDEX</span>
                  <p className="font-serif text-2xl text-[#8c7355] font-semibold">{currentHole.handicap}</p>
                </div>
              </div>

              {/* Tee Scorecard Metrics */}
              <div className="grid grid-cols-4 gap-4 text-center">
                
                <div className="bg-black/40 border border-blue-900/30 p-3 rounded">
                  <span className="block h-2 w-2 rounded-full bg-blue-600 mx-auto mb-2" />
                  <span className="block font-sans text-[9px] text-gray-400 uppercase tracking-widest font-bold">Championship</span>
                  <span className="block font-serif text-base text-white font-semibold mt-1">{currentHole.yardsBlue} Yds</span>
                </div>

                <div className="bg-black/40 border border-gray-700 p-3 rounded">
                  <span className="block h-2 w-2 rounded-full bg-gray-200 mx-auto mb-2" />
                  <span className="block font-sans text-[9px] text-gray-400 uppercase tracking-widest font-bold">White Tees</span>
                  <span className="block font-serif text-base text-white font-semibold mt-1">{currentHole.yardsWhite} Yds</span>
                </div>

                <div className="bg-black/40 border border-red-950/30 p-3 rounded">
                  <span className="block h-2 w-2 rounded-full bg-red-600 mx-auto mb-2" />
                  <span className="block font-sans text-[9px] text-gray-400 uppercase tracking-widest font-bold">Ladies Red</span>
                  <span className="block font-serif text-base text-white font-semibold mt-1">{currentHole.yardsRed} Yds</span>
                </div>

                <div className="bg-[#8c7355]/10 border border-[#8c7355]/20 p-3 rounded">
                  <span className="block font-sans text-[9px] text-gray-400 uppercase tracking-widest font-bold mb-2">Par rating</span>
                  <span className="block font-serif text-xl text-[#8c7355] font-bold mt-1">PAR {currentHole.par}</span>
                </div>

              </div>

              {/* Strategy Advice Paragraph */}
              <div className="space-y-3">
                <span className="font-sans text-[10px] font-bold text-gray-400 uppercase tracking-[0.25em] block">
                  Championship Strategy Guide
                </span>
                <p className="font-serif text-gray-300 text-sm leading-relaxed">
                  {currentHole.description}
                </p>
                <p className="font-serif text-[#8c7355] text-sm leading-relaxed italic border-l-2 border-[#8c7355] pl-4 py-1">
                  {currentHole.strategy}
                </p>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* Cinematic Film Video Modal */}
      <AnimatePresence>
        {isVideoOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4"
          >
            <button
              onClick={() => setIsVideoOpen(false)}
              className="absolute top-6 right-6 text-white hover:text-[#8c7355] transition-colors"
            >
              <X className="h-8 w-8" />
            </button>
            <div className="w-full max-w-4xl aspect-[16/9] bg-[#0a1f2c] rounded-lg overflow-hidden border border-white/10 shadow-2xl">
              {/* Responsive Embedded high-quality golf scenery video */}
              <iframe
                title="Castletown Golf Links Drone Film"
                src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1"
                className="w-full h-full"
                allow="autoplay; encrypted-media"
                allowFullScreen
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
