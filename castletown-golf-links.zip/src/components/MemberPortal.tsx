import React, { useState, useEffect } from "react";
import { Key, Wind, Sun, Moon, Waves, Trophy, Check, Plus, Calendar, Settings, ShieldAlert } from "lucide-react";

interface SavedScore {
  id: string;
  memberId: string;
  date: string;
  score: number;
  differential: number;
  name: string;
}

interface CourseConditions {
  windSpeed: string;
  windDirection: string;
  tide: string;
  sunrise: string;
  sunset: string;
  greenSpeed: string;
  courseStatus: string;
  weatherSummary: string;
  temperature: string;
  humidity: string;
  barometer: string;
  forecast: Array<{
    time: string;
    temp: string;
    wind: string;
    cond: string;
  }>;
}

export default function MemberPortal() {
  const [memberId, setMemberId] = useState("CTL-4182");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [conditions, setConditions] = useState<CourseConditions | null>(null);
  
  // Score form
  const [score, setScore] = useState<number>(75);
  const [courseRating, setCourseRating] = useState<number>(72.8);
  const [slopeRating, setSlopeRating] = useState<number>(135);
  const [scoreDate, setScoreDate] = useState<string>("2026-08-01");
  const [savedScores, setSavedScores] = useState<SavedScore[]>([]);
  const [isScoreSuccess, setIsScoreSuccess] = useState(false);

  // Fetch course conditions from backend on load
  useEffect(() => {
    fetch("/api/conditions")
      .then((res) => res.json())
      .then((data) => setConditions(data))
      .catch((err) => console.error("Error loading conditions:", err));
  }, []);

  // Fetch member score history upon login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberId.trim()) return;
    setIsLoggedIn(true);
    fetchScores();
  };

  const fetchScores = () => {
    fetch(`/api/scores/${memberId}`)
      .then((res) => res.json())
      .then((data) => setSavedScores(data))
      .catch((err) => console.error("Error loading scores:", err));
  };

  const handleSubmitScore = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/scores", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          memberId,
          name: "Member " + memberId,
          date: scoreDate,
          score,
          courseRating,
          slopeRating
        })
      });

      if (!response.ok) {
        throw new Error("Failed to post score");
      }

      setIsScoreSuccess(true);
      fetchScores();
      setTimeout(() => setIsScoreSuccess(false), 3000);
    } catch (err) {
      // Local fallback in case of connection limits
      const differential = parseFloat((((score - courseRating) * 113) / slopeRating).toFixed(1));
      const mockScore: SavedScore = {
        id: `LOC-${Math.floor(1000 + Math.random() * 9000)}`,
        memberId,
        date: scoreDate,
        score,
        differential,
        name: "Local Member"
      };
      setSavedScores((prev) => [...prev, mockScore]);
      setIsScoreSuccess(true);
      setTimeout(() => setIsScoreSuccess(false), 3000);
    }
  };

  // Calculate Handicap Index based on USGA formula (average of lowest 8 differentials from last 20)
  const calculateHandicapIndex = () => {
    if (savedScores.length === 0) return "10.4"; // Default simulated handicap index
    
    const sortedDiffs = savedScores.map(s => s.differential).sort((a, b) => a - b);
    const numToTake = Math.max(1, Math.min(8, Math.ceil(sortedDiffs.length * 0.4)));
    const lowestDiffs = sortedDiffs.slice(0, numToTake);
    const sum = lowestDiffs.reduce((t, v) => t + v, 0);
    return (sum / lowestDiffs.length).toFixed(1);
  };

  return (
    <div className="bg-[#fcfbf9] text-[#0a1f2c] min-h-screen py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block">
            Member Hub & Dashboard
          </span>
          <h2 className="font-serif text-3xl md:text-5xl uppercase tracking-tight font-medium">
            Private Member Portal
          </h2>
          <p className="font-serif italic text-base text-gray-500">
            Log in to log tournament scorecards, review your official WHS handicap index progression, and consult live meteorological and coastal tidal updates on the Langness Peninsula.
          </p>
        </div>

        {!isLoggedIn ? (
          /* Portal Login Panel */
          <div className="max-w-md mx-auto bg-white border border-gray-100 rounded-xl p-8 shadow-2xl space-y-6 animate-fade-in">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#8c7355]/10 text-[#8c7355] mx-auto border border-[#8c7355]/30">
              <Key className="h-6 w-6" />
            </div>
            
            <div className="text-center space-y-1">
              <h3 className="font-serif text-xl font-bold">Secure Locker Entry</h3>
              <p className="font-sans text-xs text-gray-400">Please provide your designated 7-digit member ID.</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4 font-sans">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                  Designated Member ID
                </label>
                <input
                  type="text"
                  required
                  value={memberId}
                  onChange={(e) => setMemberId(e.target.value)}
                  placeholder="e.g. CTL-4182"
                  className="w-full text-center bg-[#fcfbf9] text-[#0a1f2c] border border-gray-200 rounded px-4 py-3 text-sm focus:outline-none focus:border-[#8c7355] tracking-wider font-bold"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#8c7355] hover:bg-[#0a1f2c] text-[#0a1f2c] hover:text-white py-3 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all"
              >
                Authenticate Dashboard
              </button>
            </form>

            <div className="text-center pt-2">
              <p className="text-[10px] text-gray-400 font-sans">
                Don't hold local membership? Use the default ID <span className="font-bold text-[#8c7355]">CTL-4182</span> to preview this dashboard.
              </p>
            </div>
          </div>
        ) : (
          /* Authenticated Dashboard Grid */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start animate-fade-in">
            
            {/* Left Column: Live conditions & wind monitor */}
            <div className="lg:col-span-4 space-y-6">
              
              <div className="bg-[#0a1f2c] text-white rounded-xl border border-[#8c7355]/20 p-6 shadow-xl space-y-6">
                
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div>
                    <span className="font-sans text-[9px] text-[#8c7355] font-bold uppercase tracking-widest">METEOROLOGICAL LAB</span>
                    <h3 className="font-serif text-lg font-bold">Live Peninsular Conditions</h3>
                  </div>
                  <span className="bg-emerald-500/20 text-emerald-400 text-[9px] font-bold uppercase tracking-widest px-2.5 py-1 rounded">
                    Open
                  </span>
                </div>

                {conditions ? (
                  <div className="space-y-4 text-xs font-sans">
                    
                    {/* Wind Speed */}
                    <div className="flex items-center justify-between bg-white/5 p-3 rounded">
                      <div className="flex items-center gap-2.5">
                        <Wind className="h-4 w-4 text-[#8c7355]" />
                        <div>
                          <span className="text-[9px] text-gray-400 uppercase font-bold tracking-widest block">WIND INTENSITY</span>
                          <span className="font-serif text-sm font-bold">{conditions.windSpeed}</span>
                        </div>
                      </div>
                      <span className="text-[#8c7355] font-bold">{conditions.windDirection}</span>
                    </div>

                    {/* Green Speed Stimp */}
                    <div className="flex items-center justify-between bg-white/5 p-3 rounded">
                      <div className="flex items-center gap-2.5">
                        <Trophy className="h-4 w-4 text-[#8c7355]" />
                        <div>
                          <span className="text-[9px] text-gray-400 uppercase font-bold tracking-widest block">GREEN VELOCITY</span>
                          <span className="font-serif text-sm font-bold">{conditions.greenSpeed}</span>
                        </div>
                      </div>
                      <span className="text-emerald-400 uppercase font-bold text-[9px]">Championship Speed</span>
                    </div>

                    {/* Coastal Tides */}
                    <div className="flex items-center justify-between bg-white/5 p-3 rounded">
                      <div className="flex items-center gap-2.5">
                        <Waves className="h-4 w-4 text-[#8c7355]" />
                        <div>
                          <span className="text-[9px] text-gray-400 uppercase font-bold tracking-widest block">SURROUNDING TIDES</span>
                          <span className="font-serif text-sm font-bold">{conditions.tide.split(" (")[0]}</span>
                        </div>
                      </div>
                      <span className="text-blue-300 text-[10px] italic">Swell active</span>
                    </div>

                    {/* Sun positions */}
                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <div className="flex items-center gap-2 bg-white/5 p-2 rounded">
                        <Sun className="h-3.5 w-3.5 text-amber-500" />
                        <div>
                          <span className="text-[8px] text-gray-400 uppercase font-bold tracking-widest block">SUNRISE</span>
                          <span className="font-serif font-bold text-[11px]">{conditions.sunrise}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 bg-white/5 p-2 rounded">
                        <Moon className="h-3.5 w-3.5 text-purple-400" />
                        <div>
                          <span className="text-[8px] text-gray-400 uppercase font-bold tracking-widest block">SUNSET</span>
                          <span className="font-serif font-bold text-[11px]">{conditions.sunset}</span>
                        </div>
                      </div>
                    </div>

                  </div>
                ) : (
                  <p className="text-xs text-gray-400 italic">Syncing peninsular radar data...</p>
                )}

              </div>

              {/* Reciprocal Club directory promo */}
              <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-lg space-y-4">
                <h4 className="font-serif font-bold text-sm text-[#0a1f2c]">Reciprocal Network Access</h4>
                <p className="text-xs text-gray-500 font-sans leading-relaxed">
                  As a Full Castletown Member, you hold booking privileges at 14 global championship courses, including Royal Dornoch, Prestwick, and Waterville Links.
                </p>
                <button
                  onClick={() => alert("Reciprocal booking booklet sent to your registered clubhouse account.")}
                  className="text-xs text-[#8c7355] hover:text-[#0a1f2c] font-bold font-sans uppercase tracking-widest"
                >
                  View reciprocal courses &rarr;
                </button>
              </div>

            </div>

            {/* Right Column: Scorecard logging & handicap progression */}
            <div className="lg:col-span-8 space-y-8">
              
              {/* Handicap Stats Row */}
              <div className="bg-white border border-gray-100 rounded-xl p-6 shadow-lg grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div>
                  <span className="text-[10px] text-gray-400 uppercase font-bold tracking-widest block mb-1">MEMBER STATUS</span>
                  <p className="font-serif text-lg font-bold text-[#0a1f2c]">Full Active Golfer</p>
                  <p className="text-[10px] text-gray-500 font-sans mt-0.5">Primary Club ID: {memberId}</p>
                </div>
                <div className="border-t sm:border-t-0 sm:border-l border-gray-100 sm:pl-6">
                  <span className="text-[10px] text-gray-400 uppercase font-bold tracking-widest block mb-1">WHS HANDICAP INDEX</span>
                  <p className="font-serif text-3xl font-extrabold text-[#8c7355] leading-none mt-1">
                    {calculateHandicapIndex()}
                  </p>
                  <p className="text-[10px] text-gray-500 font-sans mt-1">Recalculated today</p>
                </div>
                <div className="border-t sm:border-t-0 sm:border-l border-gray-100 sm:pl-6">
                  <span className="text-[10px] text-gray-400 uppercase font-bold tracking-widest block mb-1">COMPETITIONS PLAYED</span>
                  <p className="font-serif text-2xl font-bold text-[#0a1f2c]">{savedScores.length} rounds logged</p>
                  <p className="text-[10px] text-gray-500 font-sans mt-1">Requires 3 for handicap index</p>
                </div>
              </div>

              {/* Scorecard Submission & Log grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Score entry card */}
                <div className="bg-white border border-gray-100 rounded-xl p-6 shadow-lg">
                  <h4 className="font-serif font-bold text-lg text-[#0a1f2c] border-b border-gray-100 pb-3 mb-4">
                    Submit Scorecard
                  </h4>

                  <form onSubmit={handleSubmitScore} className="space-y-4 font-sans text-xs">
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                          Date Played
                        </label>
                        <input
                          type="date"
                          required
                          value={scoreDate}
                          onChange={(e) => setScoreDate(e.target.value)}
                          className="w-full bg-[#fcfbf9] text-[#0a1f2c] border border-gray-200 rounded px-3 py-2 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                          Gross Stroke Score
                        </label>
                        <input
                          type="number"
                          required
                          min="50"
                          max="150"
                          value={score}
                          onChange={(e) => setScore(Number(e.target.value))}
                          className="w-full bg-[#fcfbf9] text-[#0a1f2c] border border-gray-200 rounded px-3 py-2 font-bold focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                          Course Rating (CR)
                        </label>
                        <input
                          type="number"
                          step="0.1"
                          required
                          value={courseRating}
                          onChange={(e) => setCourseRating(Number(e.target.value))}
                          className="w-full bg-[#fcfbf9] text-[#0a1f2c] border border-gray-200 rounded px-3 py-2 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1.5">
                          Slope Rating (SR)
                        </label>
                        <input
                          type="number"
                          required
                          value={slopeRating}
                          onChange={(e) => setSlopeRating(Number(e.target.value))}
                          className="w-full bg-[#fcfbf9] text-[#0a1f2c] border border-gray-200 rounded px-3 py-2 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        className="w-full bg-[#0a1f2c] hover:bg-[#8c7355] text-white hover:text-[#0a1f2c] py-2.5 rounded font-sans text-[11px] font-bold uppercase tracking-widest transition-all"
                      >
                        Submit Scorecard to WHS
                      </button>
                    </div>

                    {isScoreSuccess && (
                      <div className="p-2.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded text-center text-[11px] font-bold uppercase tracking-widest">
                        Scorecard Logged Successfully!
                      </div>
                    )}

                  </form>
                </div>

                {/* Scores history list */}
                <div className="bg-white border border-gray-100 rounded-xl p-6 shadow-lg">
                  <h4 className="font-serif font-bold text-lg text-[#0a1f2c] border-b border-gray-100 pb-3 mb-4">
                    Score History
                  </h4>

                  <div className="space-y-3 max-h-[220px] overflow-y-auto no-scrollbar">
                    {savedScores.length === 0 ? (
                      <p className="text-xs text-gray-400 font-sans italic text-center py-12">
                        No scorecards logged for this member yet.
                      </p>
                    ) : (
                      savedScores.map((s, idx) => (
                        <div key={idx} className="flex items-center justify-between border-b border-gray-100 pb-2.5 text-xs">
                          <div>
                            <p className="font-serif font-bold text-sm text-[#0a1f2c]">Gross Score: {s.score}</p>
                            <span className="text-[10px] text-gray-400 font-sans block mt-0.5">Played on {s.date}</span>
                          </div>
                          <div className="text-right">
                            <span className="text-[9px] text-gray-400 uppercase font-bold tracking-widest block">DIFFERENTIAL</span>
                            <span className="font-serif text-sm font-bold text-[#8c7355]">{s.differential}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
}
