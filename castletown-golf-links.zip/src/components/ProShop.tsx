import React, { useState } from "react";
import { ShoppingBag, Star, Plus, Minus, Trash2, Check, X, Award, HelpCircle } from "lucide-react";
import { shopItems } from "../data";

interface CartItem {
  itemId: string;
  quantity: number;
  selectedSize?: string;
}

export default function ProShop() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutSuccess, setIsCheckoutSuccess] = useState(false);
  const [checkoutCode, setCheckoutCode] = useState("");

  const categories = [
    { label: "All Curations", value: "all" },
    { label: "Apparel", value: "apparel" },
    { label: "Equipment", value: "equipment" },
    { label: "Art Prints", value: "art" },
    { label: "Accessories & Gifts", value: "accessories" }
  ];

  const filteredItems = selectedCategory === "all"
    ? shopItems
    : shopItems.filter((item) => item.category === selectedCategory || (selectedCategory === "accessories" && item.category === "gifts"));

  const getCartTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const getCartSubtotal = () => {
    return cart.reduce((total, cartItem) => {
      const itemDetails = shopItems.find(i => i.id === cartItem.itemId);
      if (!itemDetails) return total;
      return total + (itemDetails.price * cartItem.quantity);
    }, 0);
  };

  const handleAddToCart = (itemId: string, size?: string) => {
    setCart((prev) => {
      const existing = prev.find(i => i.itemId === itemId && i.selectedSize === size);
      if (existing) {
        return prev.map(i => (i.itemId === itemId && i.selectedSize === size) ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { itemId, quantity: 1, selectedSize: size }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQty = (itemId: string, size: string | undefined, delta: number) => {
    setCart((prev) => {
      return prev.map(i => {
        if (i.itemId === itemId && i.selectedSize === size) {
          const newQty = Math.max(1, i.quantity + delta);
          return { ...i, quantity: newQty };
        }
        return i;
      });
    });
  };

  const handleRemoveItem = (itemId: string, size?: string) => {
    setCart((prev) => prev.filter(i => !(i.itemId === itemId && i.selectedSize === size)));
  };

  const handleCheckout = () => {
    setCheckoutCode(`PRO-${Math.floor(100000 + Math.random() * 900000)}`);
    setCart([]);
    setIsCartOpen(false);
    setIsCheckoutSuccess(true);
  };

  return (
    <div className="bg-[#fcfbf9] text-[#0a1f2c] min-h-screen py-16 md:py-24 relative">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row items-center justify-between mb-16 gap-6">
          <div className="text-left space-y-3">
            <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block">
              THE LUXURY PRO SHOP
            </span>
            <h2 className="font-serif text-3xl md:text-5xl uppercase tracking-tight font-medium">
              Championship Curations
            </h2>
            <p className="font-serif italic text-sm text-gray-500 max-w-xl">
              Equip yourself with premium technical links-wear, crested golf balls, hand-blown crystal glassware, and original prints of the dramatic 17th hole.
            </p>
          </div>

          {/* Cart Status Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-2 bg-[#0a1f2c] text-white hover:bg-[#8c7355] hover:text-[#0a1f2c] px-6 py-3 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all shadow-lg relative"
          >
            <ShoppingBag className="h-4 w-4" />
            Shopping Cart ({getCartTotalItems()})
            {getCartTotalItems() > 0 && (
              <span className="absolute -top-1 -right-1 bg-amber-500 text-white rounded-full h-5 w-5 flex items-center justify-center text-[10px] font-bold">
                {getCartTotalItems()}
              </span>
            )}
          </button>
        </div>

        {isCheckoutSuccess ? (
          /* Checkout Success Overlay Banner */
          <div className="max-w-xl mx-auto bg-white border border-[#8c7355]/20 rounded-xl p-10 shadow-2xl text-center space-y-6 mb-20 animate-fade-in">
            <div className="h-16 w-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border border-emerald-200">
              <Check className="h-8 w-8 stroke-[3]" />
            </div>
            <div className="space-y-2">
              <span className="font-sans text-[10px] font-bold text-emerald-600 uppercase tracking-widest block">ORDER PLACED</span>
              <h3 className="font-serif text-2xl font-bold">Your Clubhouse Pickup Order is Secured</h3>
              <p className="font-sans text-xs text-gray-400">Please quote your reference order code at the Pro Shop front counter upon arrival.</p>
            </div>
            <div className="bg-[#fcfbf9] rounded-lg p-4 border border-gray-100 font-mono text-sm inline-block">
              <span className="text-gray-400 block text-[10px]">PICKUP REFERENCE</span>
              <p className="font-bold text-lg text-[#8c7355] tracking-wider mt-1">{checkoutCode}</p>
            </div>
            <div className="pt-2">
              <button
                onClick={() => setIsCheckoutSuccess(false)}
                className="bg-[#0a1f2c] hover:bg-[#8c7355] text-white hover:text-[#0a1f2c] px-8 py-3 rounded font-sans text-[11px] font-bold uppercase tracking-widest transition-all w-full"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        ) : null}

        {/* Category Filters row */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-12 border-b border-gray-100 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setSelectedCategory(cat.value)}
              className={`flex-shrink-0 px-5 py-2.5 rounded-full font-sans text-[11px] font-bold uppercase tracking-widest border transition-all ${
                selectedCategory === cat.value
                  ? "bg-[#8c7355] border-transparent text-[#0a1f2c] font-extrabold shadow"
                  : "border-gray-200 text-gray-400 hover:border-[#8c7355]/30 hover:text-[#0a1f2c]"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Catalog Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <div key={item.id} className="bg-white rounded-xl border border-gray-100 overflow-hidden shadow hover:shadow-xl transition-all duration-300 flex flex-col justify-between group">
              <div>
                
                {/* Image */}
                <div className="relative aspect-square bg-[#0a1f2c] overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-95"
                  />
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded text-[#0a1f2c] text-[10px] font-sans font-bold uppercase tracking-widest">
                    {item.category}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-3">
                  <div className="flex items-center gap-1.5 text-amber-500 text-xs">
                    <Star className="h-3.5 w-3.5 fill-current" />
                    <span className="font-sans font-bold text-gray-500 text-[10px]">{item.rating.toFixed(1)} / 5.0</span>
                  </div>
                  
                  <h3 className="font-serif text-lg font-bold group-hover:text-[#8c7355] transition-colors">
                    {item.name}
                  </h3>

                  <p className="font-sans text-[11px] text-gray-500 leading-relaxed line-clamp-2">
                    {item.description}
                  </p>
                </div>

              </div>

              {/* Price & Action Row */}
              <div className="p-6 pt-0 border-t border-gray-50 flex items-center justify-between">
                <span className="font-serif text-xl font-bold text-[#0a1f2c]">
                  £{item.price}
                </span>

                <button
                  onClick={() => handleAddToCart(item.id, item.sizes ? item.sizes[1] || "M" : undefined)}
                  className="bg-[#0a1f2c] hover:bg-[#8c7355] text-white hover:text-[#0a1f2c] px-4 py-2 rounded font-sans text-[10px] font-bold uppercase tracking-widest transition-all"
                >
                  Add To Cart
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Slide-out Cart Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsCartOpen(false)} />

          <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-md bg-white text-[#0a1f2c] shadow-2xl flex flex-col justify-between">
              
              {/* Cart Head */}
              <div className="p-6 bg-[#0a1f2c] text-white flex items-center justify-between border-b border-[#8c7355]/20">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="h-5 w-5 text-[#8c7355]" />
                  <h3 className="font-serif text-lg font-bold">Luxury Cart</h3>
                </div>
                <button onClick={() => setIsCartOpen(false)} className="text-gray-400 hover:text-white transition-colors">
                  <X className="h-6 w-6" />
                </button>
              </div>

              {/* Cart Body (Scroll list) */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin">
                {cart.length === 0 ? (
                  <div className="text-center py-24 space-y-4">
                    <div className="h-12 w-12 rounded-full bg-gray-50 border border-gray-100 flex items-center justify-center mx-auto text-gray-300">
                      <ShoppingBag className="h-5 w-5" />
                    </div>
                    <p className="font-serif italic text-sm text-gray-400">Your shopping bag is empty.</p>
                  </div>
                ) : (
                  cart.map((cartItem, idx) => {
                    const itemDetails = shopItems.find(i => i.id === cartItem.itemId);
                    if (!itemDetails) return null;
                    return (
                      <div key={idx} className="flex items-center justify-between border-b border-gray-100 pb-4 last:border-0 last:pb-0">
                        <div className="flex items-center gap-4">
                          <img
                            src={itemDetails.image}
                            alt={itemDetails.name}
                            className="h-16 w-16 object-cover rounded bg-[#0a1f2c]"
                          />
                          <div>
                            <h4 className="font-serif font-bold text-sm leading-tight text-[#0a1f2c]">{itemDetails.name}</h4>
                            {cartItem.selectedSize && (
                              <span className="text-[10px] text-gray-400 font-sans block mt-0.5">Size: {cartItem.selectedSize}</span>
                            )}
                            <span className="text-xs font-serif font-semibold text-[#8c7355] mt-1 block">£{itemDetails.price}</span>
                          </div>
                        </div>

                        {/* Qty edit & delete */}
                        <div className="flex flex-col items-end gap-2">
                          <div className="flex items-center gap-2.5 border border-gray-200 rounded px-2 py-1 bg-gray-50">
                            <button
                              onClick={() => handleUpdateQty(cartItem.itemId, cartItem.selectedSize, -1)}
                              className="text-gray-500 hover:text-[#0a1f2c]"
                            >
                              <Minus className="h-3.5 w-3.5" />
                            </button>
                            <span className="text-xs font-bold text-[#0a1f2c]">{cartItem.quantity}</span>
                            <button
                              onClick={() => handleUpdateQty(cartItem.itemId, cartItem.selectedSize, 1)}
                              className="text-gray-500 hover:text-[#0a1f2c]"
                            >
                              <Plus className="h-3.5 w-3.5" />
                            </button>
                          </div>
                          <button
                            onClick={() => handleRemoveItem(cartItem.itemId, cartItem.selectedSize)}
                            className="text-gray-400 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Cart Footer */}
              {cart.length > 0 && (
                <div className="p-6 border-t border-gray-100 bg-[#fcfbf9] space-y-4">
                  <div className="flex justify-between items-baseline font-serif">
                    <span className="text-gray-500 text-sm">Estimated Subtotal:</span>
                    <span className="text-2xl font-bold text-[#0a1f2c]">£{getCartSubtotal()}</span>
                  </div>
                  <p className="text-[10px] text-gray-400 font-sans leading-relaxed">
                    Clubhouse pickup option only. Purchases will be beautifully prepared in wood-fiber custom boxes stamped with the Castletown seal.
                  </p>
                  <button
                    onClick={handleCheckout}
                    className="w-full bg-[#8c7355] hover:bg-[#0a1f2c] text-[#0a1f2c] hover:text-white py-3 rounded font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all duration-300"
                  >
                    Confirm & Reserve pickup
                  </button>
                </div>
              )}

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
