import { Hole, MembershipPackage, MenuItem, LodgingSuite, ShopItem, Tournament } from "./types";

// 18 Holes of Castletown Golf Links (Standard Par 72 Championship Routing)
export const holesData: Hole[] = [
  {
    number: 1,
    name: "Derby Haven",
    par: 4,
    yardsBlue: 412,
    yardsWhite: 395,
    yardsRed: 345,
    handicap: 7,
    description: "A wide, inviting opening hole running parallel to Derby Haven bay. Watch for the beach on your right.",
    strategy: "Aim left of the fairway bunker. A solid drive leaves a short iron to a green that slopes gently back to front. Avoid going right, as the beach and bay await erratic slices.",
    greenContours: "Slight slope back-to-front, guarded by a deep bunker on the right side.",
    prevailingWind: "Lef-to-right crosswind off the bay, pushing balls toward the shore.",
    signature: false,
    image: "https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 2,
    name: "Fort Island",
    par: 4,
    yardsBlue: 375,
    yardsWhite: 358,
    yardsRed: 310,
    handicap: 13,
    description: "A gorgeous dogleg-right wrapping around the rocky shoreline. Historic Derby Fort is visible in the distance.",
    strategy: "A conservative tee shot with a long iron or hybrid is safest. Aggressive players can try to cut the corner over the rocks, but any push is lost to the sea.",
    greenContours: "Two-tiered green with a significant ridge running through the middle.",
    prevailingWind: "Strong headwind from the South-West.",
    signature: false,
    image: "https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 3,
    name: "The Fort",
    par: 3,
    yardsBlue: 165,
    yardsWhite: 148,
    yardsRed: 122,
    handicap: 17,
    description: "An exquisite short hole playing directly toward the historic 1540 Derby Fort ruins. Pure coastal drama.",
    strategy: "Club selection is vital. The green is heavily protected by sod-wall bunkers. If the wind is howling off the bay, hold a low punch shot underneath the breeze.",
    greenContours: "Plateau green with sharp drop-offs on the left and back.",
    prevailingWind: "Gale-force ocean wind off the Irish Sea, usually from the right.",
    signature: false,
    image: "https://images.unsplash.com/photo-1622390817349-db3f746be7a0?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 4,
    name: "Old Tom's Legacy",
    par: 5,
    yardsBlue: 520,
    yardsWhite: 502,
    yardsRed: 440,
    handicap: 5,
    description: "The first par 5, designed originally by Old Tom Morris. A true double-dogleg that demands strategic positioning.",
    strategy: "Drives should favor the right side. The second shot must navigate a narrow corridor between hummocks and dunes. A precision wedge is needed to hold the shallow green.",
    greenContours: "Classic bowl-shaped green that funnels slightly off-center shots back toward the middle.",
    prevailingWind: "Typically downwind, making it reachable in two for long hitters.",
    signature: false,
    image: "https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 5,
    name: "Langness Point",
    par: 4,
    yardsBlue: 432,
    yardsWhite: 410,
    yardsRed: 360,
    handicap: 1,
    description: "The toughest par 4 on the front nine. Plays directly toward the rugged rocky headland of Langness.",
    strategy: "A formidable tee shot over gorse bushes is required. The approach is to a raised green framed by deep sea-breezes and steep links banks.",
    greenContours: "Large green with severe undulation, sloping left to right.",
    prevailingWind: "Direct headwind. Often plays like a par 5 when the wind is up.",
    signature: false,
    image: "https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 6,
    name: "Dune View",
    par: 4,
    yardsBlue: 388,
    yardsWhite: 370,
    yardsRed: 320,
    handicap: 9,
    description: "A sweeping dogleg that takes players inland slightly through a series of natural sandy blowouts and tall fescue grass.",
    strategy: "Avoid the deep bunker on the corner of the dogleg. A high, soft approach is necessary to hold the elevated, undulating green surface.",
    greenContours: "Slopes back to front with a heavy false front that rejects short approaches.",
    prevailingWind: "Cross-breeze off the sand dunes.",
    signature: false,
    image: "https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 7,
    name: "The Gorse",
    par: 4,
    yardsBlue: 360,
    yardsWhite: 342,
    yardsRed: 295,
    handicap: 15,
    description: "A shorter par 4 but surrounded by thick, blooming yellow gorse bushes that swallow any offline tee shots.",
    strategy: "Position is more important than distance. Hit a hybrid or 3-wood to leave a wedge into a wide, shallow green. Don't pull it left.",
    greenContours: "Relatively flat but very firm; balls tend to bounce and run off the back.",
    prevailingWind: "Lef-to-right crosswind, pushing balls towards the gorse hazard.",
    signature: false,
    image: "https://images.unsplash.com/photo-1622390817349-db3f746be7a0?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 8,
    name: "Sea Breeze",
    par: 3,
    yardsBlue: 188,
    yardsWhite: 172,
    yardsRed: 140,
    handicap: 11,
    description: "A majestic par 3 with stunning, uninterrupted views of the open ocean. The green is carved out of a natural hollow.",
    strategy: "Aim for the center of the green regardless of pin position. The surrounding dunes will help funnel slightly offline shots back onto the putting surface.",
    greenContours: "Slightly concave center, protected by high mounds on both sides.",
    prevailingWind: "A heavy, moist wind blowing directly in off the Irish Sea.",
    signature: false,
    image: "https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 9,
    name: "Lighthouse Turn",
    par: 5,
    yardsBlue: 545,
    yardsWhite: 525,
    yardsRed: 475,
    handicap: 3,
    description: "A magnificent par 5 that wraps around the tip of the peninsula. The iconic Langness Lighthouse watches over your swing.",
    strategy: "A monster tee shot down the center is rewarded. The second shot must avoid a series of pot bunkers scattered across the fairway around 100 yards out.",
    greenContours: "Large, double-green shared with another hole, containing subtle rolls.",
    prevailingWind: "Strong tailwind, making it reachable in two for aggressive players.",
    signature: false,
    image: "https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 10,
    name: "The Lighthouse",
    par: 4,
    yardsBlue: 410,
    yardsWhite: 390,
    yardsRed: 335,
    handicap: 8,
    description: "Beginning the back nine under the shadow of the red-and-white striped Langness Lighthouse. Highly scenic.",
    strategy: "Drive should find the left-center of the fairway. The approach plays uphill to a green tucked into the rocky cliffs, demanding a precise carry.",
    greenContours: "Steep slope back-to-front, making downhill putts lightning fast.",
    prevailingWind: "Headwind coming directly from the South cliffs.",
    signature: false,
    image: "https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 11,
    name: "Mackenzie Ross",
    par: 4,
    yardsBlue: 445,
    yardsWhite: 420,
    yardsRed: 372,
    handicap: 2,
    description: "Named after the architect who restored the course. A grueling, long par 4 with a severe narrow green entry.",
    strategy: "Only an elite drive will suffice. The fairway is narrow and bordered by deep fescue grass. The second shot requires a long iron or hybrid to a elevated green.",
    greenContours: "Long and narrow, with a steep slope off the left side into deep grassy hollows.",
    prevailingWind: "Strong crosswind blowing left-to-right toward the coastline.",
    signature: false,
    image: "https://images.unsplash.com/photo-1622390817349-db3f746be7a0?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 12,
    name: "The Chasm",
    par: 3,
    yardsBlue: 145,
    yardsWhite: 130,
    yardsRed: 105,
    handicap: 18,
    description: "A short, terrifying par 3 playing over a deep rocky coastal crevice where waves crash far below.",
    strategy: "Ignore the chasm! Take one extra club to ensure you clear the hazard. Any shot hit left or short will end up in the saltwater.",
    greenContours: "Shallow but wide green, sloping toward the sea at the back.",
    prevailingWind: "Sudden gusty updrafts off the cliffs.",
    signature: false,
    image: "https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 13,
    name: "Snaefell View",
    par: 5,
    yardsBlue: 532,
    yardsWhite: 512,
    yardsRed: 460,
    handicap: 10,
    description: "On a clear day, the Isle of Man's highest peak, Snaefell, is visible on the horizon. A stunning par 5.",
    strategy: "A wide fairway allows for big drives. The second shot should lay up to 80 yards, avoiding a sneaky cross-bunker. Pitch onto the green with spin.",
    greenContours: "Very receptive and relatively flat, making it an excellent birdie opportunity.",
    prevailingWind: "Slight tailwind off the mountains.",
    signature: false,
    image: "https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 14,
    name: "The Reef",
    par: 4,
    yardsBlue: 395,
    yardsWhite: 378,
    yardsRed: 325,
    handicap: 12,
    description: "A dogleg-left where a rocky reef extends into the ocean along the entire left side of the fairway.",
    strategy: "Play to the right center. A draw is the perfect shape here. Uphill approach is longer than it looks—take half a club extra.",
    greenContours: "Uphill green with three distinct tiers; putting to the wrong tier is a certain three-putt.",
    prevailingWind: "Right-to-left wind pushing balls toward the reef.",
    signature: false,
    image: "https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 15,
    name: "Hummocks",
    par: 4,
    yardsBlue: 340,
    yardsWhite: 320,
    yardsRed: 285,
    handicap: 16,
    description: "A short, classic links hole dominated by heavy grassy hummocks and mounds that create highly unpredictable bounces.",
    strategy: "A lay-up shot is wise. Long hitters can attempt to drive the green, but the narrow entrance is protected by a gauntlet of five deep pot bunkers.",
    greenContours: "Highly undulating green resembling a potato chip, with several subtle pin locations.",
    prevailingWind: "Swirling winds between the inland dunes.",
    signature: false,
    image: "https://images.unsplash.com/photo-1622390817349-db3f746be7a0?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 16,
    name: "Langness Bay",
    par: 4,
    yardsBlue: 455,
    yardsWhite: 432,
    yardsRed: 380,
    handicap: 4,
    description: "A spectacular, brutal par 4 along the bay edge. One of the most demanding tee shots in links golf.",
    strategy: "The beach hugs the entire left side. Drive must hold the right-hand fairway which slopes left toward the beach. A brilliant long iron approach is required.",
    greenContours: "Slightly elevated dome green that rejects running shots that aren't perfectly struck.",
    prevailingWind: "Strong coastal wind coming directly off the bay on the left.",
    signature: false,
    image: "https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 17,
    name: "The Gully",
    par: 4,
    yardsBlue: 428,
    yardsWhite: 405,
    yardsRed: 350,
    handicap: 6,
    description: "Our world-famous Signature Hole. A breathtaking carry over a deep ocean inlet to an elevated, clifftop green.",
    strategy: "A heroic drive is required. Choose your line carefully: a bolder line over the ocean gully shortens the approach, while playing safe to the right leaves a long, difficult iron shot over rugged terrain.",
    greenContours: "Stunning clifftop green sloping back-to-right, surrounded by dramatic rock dropoffs.",
    prevailingWind: "Lethal, unpredictable gusts directly off the open sea, making line selection critical.",
    signature: true,
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80"
  },
  {
    number: 18,
    name: "Old Castletown",
    par: 5,
    yardsBlue: 510,
    yardsWhite: 495,
    yardsRed: 430,
    handicap: 14,
    description: "The finishing hole playing directly back toward the grand luxury Clubhouse. A majestic par 5.",
    strategy: "A great drive sets up a chance to reach in two. However, the green is guarded by deep cross-bunkers and a stone wall. Play smart to finish with a birdie.",
    greenContours: "Large flat putting surface, perfect for rolling in a long championship-winning putt.",
    prevailingWind: "Favorable wind blowing towards the Clubhouse.",
    signature: false,
    image: "https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?auto=format&fit=crop&w=1200&q=80"
  }
];

// Membership Tiers
export const memberships: MembershipPackage[] = [
  {
    id: "full",
    name: "Full Membership",
    price: "£2,200",
    description: "Unlimited, elite-tier access to our championship course, training academy, and member-only events.",
    benefits: [
      "Unlimited year-round green fees",
      "Official WHS Handicap indexing",
      "Priority tee-time bookings (14 days advance)",
      "Access to all club board competitions & matches",
      "15% discount in Pro Shop and Clubhouse dining",
      "Full locker access and practice range tokens"
    ],
    eligibility: "Open to local and international golfers who wish to call Castletown their primary club.",
    iconName: "ShieldCheck"
  },
  {
    id: "country",
    name: "Country Membership",
    price: "£1,400",
    description: "Perfect for residents of the UK mainland or Isle of Man visitors who play regularly during the year.",
    benefits: [
      "Up to 15 full rounds of golf per year",
      "Official handicap maintenance via the club",
      "7-day advance tee-time bookings",
      "Access to selected member tournaments",
      "10% discount in Pro Shop and Clubhouse dining",
      "Complimentary access to the TrackMan studio"
    ],
    eligibility: "Must reside permanently outside the Isle of Man (UK/Irish mainland).",
    iconName: "Map"
  },
  {
    id: "international",
    name: "International Membership",
    price: "£950",
    description: "An exclusive package for overseas golfers wishing to hold prestigious membership at a historic links.",
    benefits: [
      "Up to 10 full rounds of golf per year",
      "Exclusive Castletown bag tag and member crest",
      "Concierge lodging booking support",
      "Access to our worldwide reciprocal club network",
      "10% dining and pro shop discounts",
      "Guest rate privileges for up to 3 guests per round"
    ],
    eligibility: "Must reside permanently outside the UK and Isle of Man.",
    iconName: "Globe"
  },
  {
    id: "corporate",
    name: "Corporate Membership",
    price: "£5,500",
    description: "Unrivalled corporate entertainment packages combining championship golf, luxury lodges, and boardroom facilities.",
    benefits: [
      "Four designated member wildcards",
      "Unrestricted tee bookings (21 days advance)",
      "Complimentary annual 12-person corporate golf day",
      "20% discount on luxury golf lodge accommodation",
      "Free use of the Private Boardroom and Dining Hall",
      "Branded tee-marker options and website directory listing"
    ],
    eligibility: "Registered businesses and corporate entities.",
    iconName: "Briefcase"
  }
];

// Dining and Bar Menus
export const menuItems: MenuItem[] = [
  {
    name: "Manx Queenies (Scallops)",
    description: "Local Isle of Man queen scallops pan-seared in crispy pancetta, garlic herb butter, and a splash of single-malt whisky.",
    price: "£16.50",
    category: "starter"
  },
  {
    name: "Langness Coast Crab Cocktail",
    description: "Freshly caught local brown crab meat layered with organic avocado, heirloom tomatoes, and custom cognac Marie Rose sauce.",
    price: "£14.00",
    category: "starter"
  },
  {
    name: "Pan-Roasted Atlantic Cod",
    description: "Sustainably sourced thick-cut cod served over sea-salted samphire, crushed jersey royals, and a delicate saffron cream sauce.",
    price: "£28.00",
    category: "main"
  },
  {
    name: "The 18th Hole Aged Ribeye",
    description: "35-day dry-aged Manx beef ribeye cooked to perfection on open-fire charcoal, served with truffle chips and green peppercorn jus.",
    price: "£36.50",
    category: "main"
  },
  {
    name: "Manx Loaghtan Lamb Rump",
    description: "Rare heritage lamb loin roasted with rosemary and honey, parsnip puree, and a rich red wine and wild blackberry reduction.",
    price: "£32.00",
    category: "main"
  },
  {
    name: "Sticky Toffee Castletown Pudding",
    description: "Warm dates pudding soaked in a rich, velvety single-malt toffee sauce, served with local vanilla bean ice cream.",
    price: "£9.50",
    category: "dessert"
  },
  {
    name: "Isle of Man Creamery Cheese Board",
    description: "Selection of artisanal local cheeses served with homemade damson chutney, sea-salt crackers, and honeycombs.",
    price: "£12.50",
    category: "dessert"
  },
  {
    name: "Bunnahabhain 18 Year Old",
    description: "Elegant Islay single-malt with sweet fruit, nuts, sea salt, and a rich, coastal peat smoke finish.",
    price: "£18.00",
    category: "whisky"
  },
  {
    name: "Taliskers 25 Year Old",
    description: "Classic maritime single-malt with heavy pepper notes, rich wood-smoke, and salted caramel undertones.",
    price: "£28.00",
    category: "whisky"
  },
  {
    name: "Laphroaig Lore",
    description: "Rich, deep peated scotch aged in sherry casks, packing a punch of ocean brine, peat ash, and dark chocolate sweetness.",
    price: "£22.00",
    category: "whisky"
  },
  {
    name: "Chateau Margaux 2015",
    description: "An extraordinary red Bordeaux with deep complexities of blackcurrants, violets, and subtle cedarwood notes.",
    price: "£120.00",
    category: "wine"
  },
  {
    name: "Puligny-Montrachet 2021",
    description: "Prestigious white Burgundy offering crisp flint minerality, vibrant citrus fruits, and a buttery hazelnut toast finish.",
    price: "£45.00",
    category: "wine"
  }
];

// Luxury Lodging Suites
export const lodgingSuites: LodgingSuite[] = [
  {
    id: "old-tom",
    name: "The Old Tom Morris Suite",
    description: "Our signature luxury suite named after our original architect. Features rich oak paneling, private fireplace, and panoramic views of the 1st and 18th fairways.",
    pricePerNight: 450,
    amenities: [
      "Super King organic linen bed",
      "Roll-top copper soaking tub with sea-views",
      "Private outdoor terrace with gas firepit",
      "Personalised golf-bag butler and shoe valet",
      "Complimentary vintage whisky decanter bar"
    ],
    views: "Championship 18th Green & Irish Sea",
    image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=80"
  },
  {
    id: "langness",
    name: "The Langness Peninsula Lodge",
    description: "A private, free-standing stone luxury lodge nestled within the coastal sand dunes. Experience total isolation, coastal winds, and the sound of waves breaking on the rocks.",
    pricePerNight: 550,
    amenities: [
      "Fully private 2-bedroom coastal cottage",
      "Private kitchen with personal chef booking available",
      "State-of-the-art golf storage and drying room",
      "Direct beach path access",
      "Panoramic glass walls overlooking the ocean"
    ],
    views: "Rocky Coastline & Langness Lighthouse",
    image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=1200&q=80"
  },
  {
    id: "championship",
    name: "The Open Championship Suite",
    description: "Modern Scandinavian minimalism meets classic British golf heritage. Designed with clean limestone, neutral tones, and spacious light.",
    pricePerNight: 380,
    amenities: [
      "King-size pillow-top luxury mattress",
      "En-suite Italian marble rainfall shower",
      "Daily complimentary greens-token and driving range balls",
      "Premium Bang & Olufsen sound system",
      "Private workspace overlooking Derby Haven bay"
    ],
    views: "Derby Haven Bay & Yacht Anchorage",
    image: "https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=1200&q=80"
  }
];

// Premium e-commerce Pro Shop Items
export const shopItems: ShopItem[] = [
  {
    id: "cap-logo",
    name: "Castletown Merino Logo Cap",
    category: "apparel",
    price: 45,
    description: "Crafted from fine Manx-wool merino blend. Keeps your head warm in heavy coastal winds, with a beautifully embroidered gold Castletown crest.",
    image: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&w=800&q=80",
    sizes: ["One Size"],
    rating: 4.8
  },
  {
    id: "links-jacket",
    name: "The Langness Windbreaker Pro",
    category: "apparel",
    price: 180,
    description: "A highly wind-resistant, waterproof stretch-membrane shell developed specifically for coastal links conditions. Zero restriction on your backswing.",
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=800&q=80",
    sizes: ["S", "M", "L", "XL", "XXL"],
    rating: 4.9
  },
  {
    id: "golf-towel",
    name: "Castletown Jacquard Club Towel",
    category: "accessories",
    price: 30,
    description: "Heavyweight 100% cotton golf towel featuring a woven map of the Langness Peninsula and our crest. Highly absorbent.",
    image: "https://images.unsplash.com/photo-1628149455678-16f37bc392f4?auto=format&fit=crop&w=800&q=80",
    rating: 4.7
  },
  {
    id: "gully-print",
    name: "The 17th Gully Fine Art Print",
    category: "art",
    price: 120,
    description: "A limited-edition, signed landscape print of the signature 17th hole at golden hour. Captured by award-winning links photographer Richard Watson.",
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
    rating: 5.0
  },
  {
    id: "balls-crested",
    name: "Titleist Pro V1 - Castletown Crest (Dozen)",
    category: "equipment",
    price: 65,
    description: "The gold-standard titleist balls custom-stamped with the premium gold Castletown Golf links shield. Pack of 12.",
    image: "https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?auto=format&fit=crop&w=800&q=80",
    rating: 4.9
  },
  {
    id: "whisky-glass",
    name: "Derby Fort Crystal Whisky Tumbler",
    category: "gifts",
    price: 55,
    description: "Hand-blown lead-free crystal tumbler. The base of the glass contains a beautifully laser-etched 3D outline of the historic Derby Fort ruins.",
    image: "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=800&q=80",
    rating: 4.8
  }
];

// Championship Tournaments Calendar
export const tournaments: Tournament[] = [
  {
    id: "iom-am",
    name: "The Isle of Man Amateur Championship",
    date: "2026-06-12",
    type: "Championship Strokeplay",
    status: "completed",
    slots: 120,
    registeredPlayers: 120
  },
  {
    id: "links-trophy",
    name: "The Castletown Links Trophy (Elite Amateur)",
    date: "2026-08-15",
    type: "WAGR Ranking 72-Hole Medal",
    status: "upcoming",
    slots: 96,
    registeredPlayers: 84
  },
  {
    id: "derby-pro-am",
    name: "The Derby Fort Pro-Am Pro Tour",
    date: "2026-09-02",
    type: "Professional & Amateur Stableford",
    status: "upcoming",
    slots: 40,
    registeredPlayers: 32
  },
  {
    id: "member-autumn",
    name: "The Member's Autumn Gold Medal",
    date: "2026-10-11",
    type: "Club Handicap Trophy",
    status: "upcoming",
    slots: 150,
    registeredPlayers: 95
  }
];
