import React, { useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import FeaturesBand from "./components/FeaturesBand";
import TheCourse from "./components/TheCourse";
import TeeBooking from "./components/TeeBooking";
import Membership from "./components/Membership";
import Clubhouse from "./components/Clubhouse";
import Accommodation from "./components/Accommodation";
import Academy from "./components/Academy";
import ProShop from "./components/ProShop";
import MemberPortal from "./components/MemberPortal";
import Corporate from "./components/Corporate";
import AIConcierge from "./components/AIConcierge";
import Footer from "./components/Footer";
import { Compass, Award, Star, History, Eye, Check, ArrowRight } from "lucide-react";

export default function App() {
  const [activeView, setActiveView] = useState<string>("home");

  const renderActiveView = () => {
    switch (activeView) {
      case "course":
        return <TheCourse />;
      case "booking":
        return <TeeBooking />;
      case "membership":
        return <Membership />;
      case "clubhouse":
        return <Clubhouse />;
      case "accommodation":
        return <Accommodation />;
      case "academy":
        return <Academy />;
      case "shop":
        return <ProShop />;
      case "portal":
      case "portal-login":
        return <MemberPortal />;
      case "corporate":
        return <Corporate />;
      case "home":
      default:
        return (
          /* Interactive Luxury Home Portal Content */
          <div className="bg-[#f5f2ed] text-[#0a1f2c] animate-fade-in">
            
            {/* Cinematic Hero Section */}
            <Hero setActiveView={setActiveView} />
            
            {/* Premium Highlights Band */}
            <FeaturesBand setActiveView={setActiveView} />

            {/* 3. Storytelling Section: "The Spirit of Langness" */}
            <section className="max-w-6xl mx-auto px-6 py-20 md:py-28">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                
                {/* Left side: Beautiful overlapping image grids representing rugged nature */}
                <div className="relative aspect-[4/3] rounded-none overflow-hidden shadow-2xl border border-[#0a1f2c]/10 bg-[#0a1f2c]">
                  <img
                    src="https://images.unsplash.com/photo-1531804055935-76f44d7c3621?auto=format&fit=crop&w=1200&q=80"
                    alt="Scenic green ocean cliffs with ancient stone walls"
                    className="w-full h-full object-cover opacity-80 scale-105 hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a1f2c]/40 to-transparent" />
                  
                  {/* Absolute Badge */}
                  <div className="absolute bottom-6 left-6 bg-[#f5f2ed]/95 backdrop-blur-sm p-4 rounded-none shadow-xl max-w-xs border border-[#0a1f2c]/10">
                    <span className="text-[#8c7355] text-[9px] font-bold font-sans uppercase tracking-widest block mb-1">FOUNDED IN 1892</span>
                    <p className="font-serif italic text-xs leading-relaxed text-[#0a1f2c]/85">
                      "Of all the courses I have encountered, none sits in harmony with wild ocean contours as proudly as Castletown."
                    </p>
                    <span className="font-sans text-[9px] font-bold text-[#0a1f2c]/40 block mt-2">— Old Tom Morris, Champion Designer</span>
                  </div>
                </div>

                {/* Right side: Elegant descriptive prose */}
                <div className="space-y-6">
                  
                  <div className="space-y-2">
                    <span className="font-sans text-[11px] font-bold uppercase tracking-[0.3em] text-[#8c7355] block">
                      The Spirit of Langness
                    </span>
                    <h2 className="font-serif text-3xl md:text-5xl uppercase tracking-tight leading-tight font-medium text-[#0a1f2c]">
                      Pure Links.<br />Unspoiled Nature.
                    </h2>
                  </div>

                  <p className="font-sans text-sm text-[#0a1f2c]/70 leading-relaxed">
                    Set on a narrow, rock-bound peninsula on the southern tip of the Isle of Man, Castletown is a golf destination unlike any other. Here, championship links golf is defined by the shifting winds of the Irish Sea, sea-spray cliffs, and fescue-covered dunes.
                  </p>

                  {/* Curated feature blocks */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                    
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-[#8c7355]">
                        <History className="h-5 w-5" />
                        <h4 className="font-serif text-sm font-bold uppercase tracking-wider text-[#0a1f2c]">Old Tom's Design</h4>
                      </div>
                      <p className="text-xs text-[#0a1f2c]/60 font-sans leading-relaxed">
                        Originally plotted in 1892, with layout refinements by four-time Open Champion Old Tom Morris, preserving natural linkways.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-[#8c7355]">
                        <Compass className="h-5 w-5" />
                        <h4 className="font-serif text-sm font-bold uppercase tracking-wider text-[#0a1f2c]">Wild Oceanside Play</h4>
                      </div>
                      <p className="text-xs text-[#0a1f2c]/60 font-sans leading-relaxed">
                        Surrounded by Derby Haven and Castletown Bay, requiring strategic shot-making over rugged chasms and waves.
                      </p>
                    </div>

                  </div>

                  <div className="pt-4">
                    <button
                      onClick={() => {
                        setActiveView("course");
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }}
                      className="bg-transparent hover:bg-[#0a1f2c] text-[#0a1f2c] hover:text-white border border-[#0a1f2c] px-8 py-3.5 rounded-none font-sans text-[11px] font-bold uppercase tracking-[0.2em] transition-all duration-300"
                    >
                      Virtual Course Tour &rarr;
                    </button>
                  </div>

                </div>

              </div>
            </section>

            {/* 4. Guest Experience Spotlights */}
            <section className="bg-[#0a1f2c] text-white py-20 md:py-28 border-t border-[#8c7355]/15">
              <div className="max-w-6xl mx-auto px-6">
                
                {/* Section Header */}
                <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
                  <span className="font-sans text-[10px] font-bold text-[#8c7355] uppercase tracking-[0.3em] block">
                    AN UNRIVALLED ESCAPE
                  </span>
                  <h3 className="font-serif text-2xl md:text-4xl uppercase tracking-tight font-semibold">
                    The Castletown Experience
                  </h3>
                  <p className="font-serif italic text-sm text-gray-300">
                    A destination built for complete escapism. Beyond our championship course, we provide unparalleled hospitality, fine gastronomy, and private golf lodging.
                  </p>
                </div>

                {/* Spotlight Grid Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  
                  {/* Card 1: Clubhouse Gastronomy */}
                  <div className="bg-[#0a1f2c] border border-[#8c7355]/20 rounded-none overflow-hidden shadow-sm hover:border-[#8c7355] transition-all flex flex-col justify-between group">
                    <div className="relative aspect-[16/10] overflow-hidden">
                      <img
                        src="https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80"
                        alt="Fine dining table"
                        className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div className="p-6 space-y-4">
                      <h4 className="font-serif text-lg font-bold text-white group-hover:text-[#8c7355] transition-colors">The 1892 Restaurant</h4>
                      <p className="text-xs text-gray-300 font-sans leading-relaxed">
                        Dine overlooking Derby Haven bay. Savour fresh local hand-dived Manx queenies, wild sea bass, and our private collection of peated single malts.
                      </p>
                      <button
                        onClick={() => {
                          setActiveView("clubhouse");
                          window.scrollTo({ top: 0, behavior: "smooth" });
                        }}
                        className="text-[#8c7355] hover:text-white font-sans text-[10px] font-bold uppercase tracking-widest transition-colors flex items-center gap-1"
                      >
                        Explore Dining Menu
                        <ArrowRight className="h-3 w-3" />
                      </button>
                    </div>
                  </div>

                  {/* Card 2: Lodges */}
                  <div className="bg-[#0a1f2c] border border-[#8c7355]/20 rounded-none overflow-hidden shadow-sm hover:border-[#8c7355] transition-all flex flex-col justify-between group">
                    <div className="relative aspect-[16/10] overflow-hidden">
                      <img
                        src="https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80"
                        alt="Luxury hotel bedroom suite"
                        className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div className="p-6 space-y-4">
                      <h4 className="font-serif text-lg font-bold text-white group-hover:text-[#8c7355] transition-colors">Golf Lodges & Suites</h4>
                      <p className="text-xs text-gray-300 font-sans leading-relaxed">
                        Unwind in complete luxury in our suites right on the shore. Features fireplaces, panoramic sea views, and priority morning tee times.
                      </p>
                      <button
                        onClick={() => {
                          setActiveView("accommodation");
                          window.scrollTo({ top: 0, behavior: "smooth" });
                        }}
                        className="text-[#8c7355] hover:text-white font-sans text-[10px] font-bold uppercase tracking-widest transition-colors flex items-center gap-1"
                      >
                        Explore Accommodation
                        <ArrowRight className="h-3 w-3" />
                      </button>
                    </div>
                  </div>

                  {/* Card 3: Coaching */}
                  <div className="bg-[#0a1f2c] border border-[#8c7355]/20 rounded-none overflow-hidden shadow-sm hover:border-[#8c7355] transition-all flex flex-col justify-between group">
                    <div className="relative aspect-[16/10] overflow-hidden">
                      <img
                        src="https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&w=800&q=80"
                        alt="Golf club hitting ball"
                        className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div className="p-6 space-y-4">
                      <h4 className="font-serif text-lg font-bold text-white group-hover:text-[#8c7355] transition-colors">The Golf Academy</h4>
                      <p className="text-xs text-gray-300 font-sans leading-relaxed">
                        Refine your swing with PGA Master Professionals. Our indoor TrackMan 4 studio and coastal range prepare you for pure peninsular play.
                      </p>
                      <button
                        onClick={() => {
                          setActiveView("academy");
                          window.scrollTo({ top: 0, behavior: "smooth" });
                        }}
                        className="text-[#8c7355] hover:text-white font-sans text-[10px] font-bold uppercase tracking-widest transition-colors flex items-center gap-1"
                      >
                        PGA Swing Diagnostics
                        <ArrowRight className="h-3 w-3" />
                      </button>
                    </div>
                  </div>

                </div>

              </div>
            </section>

          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#f5f2ed] text-[#0a1f2c]">
      
      {/* 1. Header Navigation Component */}
      <Navbar activeView={activeView} setActiveView={setActiveView} />

      {/* 2. Main Page Router Panel */}
      <main className="flex-grow">
        {renderActiveView()}
      </main>

      {/* 3. Floating AI Concierge Agent */}
      <AIConcierge />

      {/* 4. Luxury Dark Footer */}
      <Footer setActiveView={setActiveView} />

    </div>
  );
}
