'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { Calculator, Download, Play, ShieldCheck, ArrowRight, FileText } from 'lucide-react';

export function RoyaltiesModule() {
  const { 
    royaltyRuns, 
    runNewRoyaltyCalculation, 
    artists, 
    advances, 
    formatCurrency 
  } = useMusicOS();

  const [selectedArtistId, setSelectedArtistId] = useState(artists[0]?.id || 'ART-001');
  const [grossInputUSD, setGrossInputUSD] = useState(500000);
  const [periodLabel, setPeriodLabel] = useState('2026-H2');
  const [calculatedRun, setCalculatedRun] = useState<any>(null);

  const handleRunWaterfall = (e: React.FormEvent) => {
    e.preventDefault();
    const run = runNewRoyaltyCalculation(selectedArtistId, grossInputUSD, periodLabel);
    setCalculatedRun(run);
  };

  const handleExportCSV = async (run: any) => {
    try {
      const res = await fetch('/api/export/statement', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ statementData: run, format: 'csv' })
      });
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Royalty_Statement_${run.artistName.replace(/\s+/g, '_')}_${run.periodLabel}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (err) {
      console.error("CSV Export failed:", err);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Calculator className="w-5 h-5 text-amber-400" />
            <span>Deterministic Royalty Waterfall & Recoupment Amortisation Engine</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Gross Receipts − Platform Fees (30%) − Distribution (5%) = Net Receipts × Royalty Rate − Recoupment Applied = Payable Balance
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono px-3 py-1 bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 rounded-full">
            100% Reproducible Ledger Math
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Waterfall Run Executor */}
        <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
          <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
            <Play className="w-4 h-4 text-amber-400" />
            <span>Execute New Royalty Run</span>
          </h3>

          <form onSubmit={handleRunWaterfall} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Select Roster Artist</label>
              <select
                value={selectedArtistId}
                onChange={(e) => setSelectedArtistId(e.target.value)}
                className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
              >
                {artists.map(a => (
                  <option key={a.id} value={a.id}>{a.stageName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Gross Ingested Receipts (USD)</label>
              <input
                type="number"
                required
                step="1000"
                value={grossInputUSD}
                onChange={(e) => setGrossInputUSD(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white font-mono focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Accounting Statement Period</label>
              <input
                type="text"
                required
                value={periodLabel}
                onChange={(e) => setPeriodLabel(e.target.value)}
                placeholder="2026-H2"
                className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white font-mono focus:outline-none focus:border-amber-400"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg shadow-md transition flex items-center justify-center space-x-2 text-xs"
            >
              <Calculator className="w-4 h-4" />
              <span>Execute Waterfall Calculation</span>
            </button>
          </form>
        </div>

        {/* Advances & Recoupment Ledger Overview */}
        <div className="lg:col-span-2 bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
          <h3 className="text-sm font-semibold text-white">Artist Advance Recoupment Amortisation Balances</h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300 font-medium">
              <thead className="bg-[#161b22] text-slate-400 uppercase text-[10px] tracking-wider border-b border-[#30363d]">
                <tr>
                  <th className="py-3 px-4">Artist ID</th>
                  <th className="py-3 px-4">Advance Category</th>
                  <th className="py-3 px-4">Original Advance</th>
                  <th className="py-3 px-4">Recouped Amount</th>
                  <th className="py-3 px-4">Unrecouped Balance</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#21262d] font-mono">
                {advances.map((adv) => {
                  const isFullyRecouped = adv.remainingBalanceUSD <= 0;
                  return (
                    <tr key={adv.id} className="hover:bg-[#181e2b] transition">
                      <td className="py-3.5 px-4 font-bold text-white">{adv.artistId}</td>
                      <td className="py-3.5 px-4 text-slate-300">{adv.category}</td>
                      <td className="py-3.5 px-4">{formatCurrency(adv.originalAmountUSD)}</td>
                      <td className="py-3.5 px-4 text-emerald-400">{formatCurrency(adv.currentRecoupedAmountUSD)}</td>
                      <td className="py-3.5 px-4 font-bold text-amber-300">{formatCurrency(adv.remainingBalanceUSD)}</td>
                      <td className="py-3.5 px-4">
                        {isFullyRecouped ? (
                          <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                            FULLY RECOUPED
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                            UNRECOUPED
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

      </div>

      {/* Calculated Runs & Statements Table */}
      <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
        <h3 className="text-sm font-semibold text-white">Calculated Royalty Runs & Statement History</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 font-medium">
            <thead className="bg-[#161b22] text-slate-400 uppercase text-[10px] tracking-wider border-b border-[#30363d]">
              <tr>
                <th className="py-3 px-4">Run ID / Period</th>
                <th className="py-3 px-4">Artist Name</th>
                <th className="py-3 px-4">Gross Revenue</th>
                <th className="py-3 px-4">Net Receipts</th>
                <th className="py-3 px-4">Rate %</th>
                <th className="py-3 px-4">Earned Royalty</th>
                <th className="py-3 px-4">Recoupment Applied</th>
                <th className="py-3 px-4">Payable Balance</th>
                <th className="py-3 px-4">Export Statement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d] font-mono">
              {royaltyRuns.map((run) => (
                <tr key={run.id} className="hover:bg-[#181e2b] transition">
                  <td className="py-3.5 px-4 font-bold text-white">{run.id} ({run.periodLabel})</td>
                  <td className="py-3.5 px-4 text-slate-200 font-sans font-semibold">{run.artistName}</td>
                  <td className="py-3.5 px-4">{formatCurrency(run.grossRevenueUSD)}</td>
                  <td className="py-3.5 px-4">{formatCurrency(run.netReceiptsUSD)}</td>
                  <td className="py-3.5 px-4 text-amber-300">{run.contractRoyaltyRatePercent}%</td>
                  <td className="py-3.5 px-4">{formatCurrency(run.grossEarnedRoyaltyUSD)}</td>
                  <td className="py-3.5 px-4 text-amber-400">{formatCurrency(run.recoupmentDeductedUSD)}</td>
                  <td className="py-3.5 px-4 font-bold text-emerald-400">{formatCurrency(run.payableRoyaltyUSD)}</td>
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => handleExportCSV(run)}
                      className="flex items-center space-x-1 text-xs text-amber-400 hover:text-amber-300 font-sans font-semibold"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export CSV</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
