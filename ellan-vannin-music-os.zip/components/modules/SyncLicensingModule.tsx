'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { SyncOpportunity } from '../../lib/domain/types';
import { Clapperboard, CheckCircle2, AlertTriangle, Plus, Film, Tv, ShieldCheck, X } from 'lucide-react';

export function SyncLicensingModule() {
  const { syncOpportunities, addSyncOpportunity, formatCurrency } = useMusicOS();
  const [showAddModal, setShowAddModal] = useState(false);

  // New Sync Brief State
  const [title, setTitle] = useState('Netflix Sci-Fi Thriller Trailer');
  const [clientName, setClientName] = useState('Netflix Global Licensing');
  const [mediaType, setMediaType] = useState<'FILM' | 'TELEVISION' | 'ADVERTISING' | 'GAME' | 'TRAILER'>('TRAILER');
  const [briefDescription, setBriefDescription] = useState('High-tension dark orchestral beat for 60s teaser.');
  const [budgetFeeUSD, setBudgetFeeUSD] = useState(95000);

  const handleCreateSync = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    const newSync: SyncOpportunity = {
      id: `SYNC-${Date.now()}`,
      title,
      clientName,
      mediaType,
      briefDescription,
      budgetFeeUSD,
      targetTerritories: ['WW'],
      masterCleared: true,
      publishingCleared: true,
      status: 'PITCHED',
      pitchTrackTitle: 'Isle of Glass (Synth Remix)',
      cueSheetSubmitted: false
    };

    addSyncOpportunity(newSync);
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Clapperboard className="w-5 h-5 text-amber-400" />
            <span>Institutional Sync Licensing & Cue Sheet Clearance Engine</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Dual Master & Publishing Clearance Gate, Film/TV/Commercial Brief Pitching & Cue Sheet Registry
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center space-x-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2.5 rounded-lg text-xs transition shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>Ingest New Sync Brief</span>
        </button>
      </div>

      {/* Sync Opportunities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {syncOpportunities.map((sync) => {
          const fullyCleared = sync.masterCleared && sync.publishingCleared;
          return (
            <div key={sync.id} className="bg-[#121721] border border-[#21262d] rounded-xl p-5 hover:border-amber-500/40 transition space-y-4 shadow-lg">
              
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-base font-bold text-white">{sync.title}</h3>
                  <p className="text-xs text-slate-400">{sync.clientName} • {sync.mediaType}</p>
                </div>

                <span className={`px-2.5 py-1 text-[10px] font-mono font-bold rounded ${
                  sync.status === 'LICENSED' 
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' 
                    : 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                }`}>
                  {sync.status}
                </span>
              </div>

              <p className="text-xs text-slate-300 italic bg-[#161b22] p-3 rounded border border-[#30363d]">
                &quot;{sync.briefDescription}&quot;
              </p>

              {/* Clearance Gate Status */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className={`p-2.5 rounded border ${
                  sync.masterCleared ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-red-500/10 border-red-500/30 text-red-300'
                }`}>
                  <span className="font-bold block">Master Right Cleared:</span>
                  <span className="font-mono text-[11px]">{sync.masterCleared ? '✓ CLEARED' : '⚠ PENDING'}</span>
                </div>

                <div className={`p-2.5 rounded border ${
                  sync.publishingCleared ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                }`}>
                  <span className="font-bold block">Publishing Cleared:</span>
                  <span className="font-mono text-[11px]">{sync.publishingCleared ? '✓ CLEARED' : '⚠ UNRESOLVED'}</span>
                </div>
              </div>

              <div className="flex justify-between items-center text-xs pt-2 border-t border-[#21262d]">
                <span className="text-slate-400 font-mono">Synced Track: <span className="text-amber-300 font-semibold">{sync.pitchTrackTitle || '—'}</span></span>
                <span className="font-bold text-amber-400 font-mono text-sm">{formatCurrency(sync.budgetFeeUSD)}</span>
              </div>

            </div>
          );
        })}
      </div>

      {/* New Sync Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#121721] border border-[#30363d] rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl">
            <div className="flex justify-between items-center border-b border-[#21262d] pb-3">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <Clapperboard className="w-5 h-5 text-amber-400" />
                <span>Ingest Sync Brief & Pitch</span>
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSync} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Sync Opportunity / Project Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Client / Agency Name</label>
                  <input
                    type="text"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Media Type</label>
                  <select
                    value={mediaType}
                    onChange={(e) => setMediaType(e.target.value as any)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="FILM">FILM</option>
                    <option value="TELEVISION">TELEVISION</option>
                    <option value="ADVERTISING">ADVERTISING</option>
                    <option value="GAME">GAME</option>
                    <option value="TRAILER">TRAILER</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Budget License Fee (USD)</label>
                <input
                  type="number"
                  value={budgetFeeUSD}
                  onChange={(e) => setBudgetFeeUSD(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white font-mono focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Sync Brief Description & Creative Direction</label>
                <textarea
                  rows={3}
                  value={briefDescription}
                  onChange={(e) => setBriefDescription(e.target.value)}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#161b22] border border-[#30363d] text-slate-300 rounded-lg font-medium hover:bg-[#1c212c]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg shadow"
                >
                  Pitch Track & Save Brief
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
