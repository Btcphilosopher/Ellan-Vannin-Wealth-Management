'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { simulateDigitalTwinWhatIf } from '../../lib/domain/math';
import { GitBranch, Play, Sparkles, TrendingUp, DollarSign, Activity } from 'lucide-react';

export function DigitalTwinModule() {
  const { digitalTwinState, artists, formatCurrency } = useMusicOS();

  const [streamDeltaPercent, setStreamDeltaPercent] = useState(25);
  const [newArtistAdvanceUSD, setNewArtistAdvanceUSD] = useState(150000);
  const [catalogueAcquisitionCostUSD, setCatalogueAcquisitionCostUSD] = useState(0);
  const [synclicensePipelineUSD, setSynclicensePipelineUSD] = useState(120000);

  const simulationResult = simulateDigitalTwinWhatIf(digitalTwinState, {
    streamVolumeMultiplier: 1 + streamDeltaPercent / 100,
    dspPayOutRateChangePercent: 0,
    newArtistSigningsCount: newArtistAdvanceUSD > 0 ? 1 : 0,
    marketingBudgetMultiplier: 1,
    catalogueAcquisitionInvestmentUSD: catalogueAcquisitionCostUSD
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <GitBranch className="w-5 h-5 text-amber-400" />
            <span>Interactive Label Digital Twin What-If Simulator</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Simulate macroeconomic shifts, stream spikes, catalogue acquisitions & advance commitments before capital deployment.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono px-3 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-full">
            State Machine Active
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Sliders Control Panel */}
        <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
          <h3 className="text-sm font-semibold text-white flex items-center space-x-2 border-b border-[#21262d] pb-3">
            <Play className="w-4 h-4 text-amber-400" />
            <span>Digital Twin Simulation Variables</span>
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Catalogue Global Stream Growth</span>
                <span className="font-mono text-amber-400 font-bold">{streamDeltaPercent > 0 ? `+${streamDeltaPercent}%` : `${streamDeltaPercent}%`}</span>
              </div>
              <input
                type="range"
                min="-50"
                max="100"
                step="5"
                value={streamDeltaPercent}
                onChange={(e) => setStreamDeltaPercent(parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-[#161b22]"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>New Artist Signing Advance (USD)</span>
                <span className="font-mono text-amber-400 font-bold">${newArtistAdvanceUSD.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1000000"
                step="25000"
                value={newArtistAdvanceUSD}
                onChange={(e) => setNewArtistAdvanceUSD(parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-[#161b22]"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Catalogue Acquisition Outflow (USD)</span>
                <span className="font-mono text-amber-400 font-bold">${catalogueAcquisitionCostUSD.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="0"
                max="5000000"
                step="100000"
                value={catalogueAcquisitionCostUSD}
                onChange={(e) => setCatalogueAcquisitionCostUSD(parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-[#161b22]"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Sync Licensing Pipeline Realized (USD)</span>
                <span className="font-mono text-amber-400 font-bold">${synclicensePipelineUSD.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="0"
                max="500000"
                step="25000"
                value={synclicensePipelineUSD}
                onChange={(e) => setSynclicensePipelineUSD(parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-[#161b22]"
              />
            </div>
          </div>
        </div>

        {/* Simulation Delta Outputs */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-sm font-semibold text-white">Simulated Output Deltas vs Baseline</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-2">
              <span className="text-xs text-slate-400 uppercase tracking-wider block">Projected Gross Revenue</span>
              <div className="text-2xl font-extrabold text-white font-mono">{formatCurrency(simulationResult.projectedGrossRevenueUSD)}</div>
              <div className={`text-xs font-mono font-bold ${
                simulationResult.revenueDeltaPercent >= 0 ? 'text-emerald-400' : 'text-red-400'
              }`}>
                {simulationResult.revenueDeltaPercent >= 0 ? '+' : ''}{simulationResult.revenueDeltaPercent.toFixed(1)}% vs Current Baseline
              </div>
            </div>

            <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-2">
              <span className="text-xs text-slate-400 uppercase tracking-wider block">Projected Catalogue DCF Value</span>
              <div className="text-2xl font-extrabold text-amber-300 font-mono">{formatCurrency(simulationResult.projectedCatalogueValuationUSD)}</div>
              <div className={`text-xs font-mono font-bold ${
                simulationResult.valuationDeltaPercent >= 0 ? 'text-emerald-400' : 'text-red-400'
              }`}>
                {simulationResult.valuationDeltaPercent >= 0 ? '+' : ''}{simulationResult.valuationDeltaPercent.toFixed(1)}% Valuation Impact
              </div>
            </div>

            <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-2">
              <span className="text-xs text-slate-400 uppercase tracking-wider block">Projected Net Operating Profit</span>
              <div className="text-2xl font-extrabold text-emerald-400 font-mono">{formatCurrency(simulationResult.projectedNetProfitUSD)}</div>
              <div className="text-xs text-slate-400">Estimated annual net receipts</div>
            </div>

            <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-2">
              <span className="text-xs text-slate-400 uppercase tracking-wider block">Projected Cash Reserve</span>
              <div className="text-2xl font-extrabold text-white font-mono">{formatCurrency(simulationResult.projectedCashReserveUSD)}</div>
              <div className="text-xs text-amber-400 font-mono">
                Base Reserve: {formatCurrency(digitalTwinState.cashReserveUSD)}
              </div>
            </div>

          </div>

          {/* AI Decision twin summary */}
          <div className="bg-[#121721] p-5 rounded-xl border border-amber-500/30 flex items-start space-x-3">
            <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs text-slate-300 space-y-1">
              <span className="font-bold text-amber-300 block">Digital Twin Decision Summary:</span>
              <p>
                &quot;Simulated scenario yields a {simulationResult.revenueDeltaPercent >= 0 ? '+' : ''}{simulationResult.revenueDeltaPercent.toFixed(1)}% revenue shift, creating a projected catalogue valuation of {formatCurrency(simulationResult.projectedCatalogueValuationUSD)} with a net cash reserve of {formatCurrency(simulationResult.projectedCashReserveUSD)}.&quot;
              </p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
