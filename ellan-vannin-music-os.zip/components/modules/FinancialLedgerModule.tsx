'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { AccountCode, JournalLine, JournalTransaction } from '../../lib/domain/types';
import { BookOpen, Plus, ShieldCheck, AlertCircle, CheckCircle2, X } from 'lucide-react';

export function FinancialLedgerModule() {
  const { journalTransactions, addJournalTransaction, formatCurrency, role } = useMusicOS();
  const [showAddModal, setShowAddModal] = useState(false);
  const [postError, setPostError] = useState<string | null>(null);

  // New Transaction Form State
  const [reference, setReference] = useState('DSP-REC-2026-003');
  const [description, setDescription] = useState('Apple Music Q1 2026 Digital Ingestion Revenue');

  const [lines, setLines] = useState<JournalLine[]>([
    { accountCode: '1100_RECEIVABLES_DSP', accountName: 'DSP Receivables (Apple)', debitUSD: 310000, creditUSD: 0 },
    { accountCode: '4010_REVENUE_STREAMING', accountName: 'Streaming Revenue', debitUSD: 0, creditUSD: 310000 }
  ]);

  const accountOptions: { code: AccountCode; name: string }[] = [
    { code: '1010_CASH', name: '1010 Cash & Bank Equivalents' },
    { code: '1100_RECEIVABLES_DSP', name: '1100 DSP Receivables' },
    { code: '1200_CATALOGUE_ASSETS', name: '1200 Master Catalogue Assets' },
    { code: '1300_PUBLISHING_ASSETS', name: '1300 Publishing Rights Assets' },
    { code: '2010_ROYALTY_LIABILITIES_ARTIST', name: '2010 Artist Royalty Liabilities' },
    { code: '2030_UNEARNED_ADVANCES', name: '2030 Artist Unearned Advances' },
    { code: '4010_REVENUE_STREAMING', name: '4010 Streaming Revenue' },
    { code: '4030_REVENUE_SYNC', name: '4030 Sync Licensing Revenue' },
    { code: '5010_EXPENSE_ROYALTIES', name: '5010 Royalty Expense' },
    { code: '5020_EXPENSE_MARKETING', name: '5020 Marketing Expense' },
  ];

  const updateLine = (index: number, field: keyof JournalLine, value: any) => {
    const updated = [...lines];
    updated[index] = { ...updated[index], [field]: value };
    setLines(updated);
  };

  const totalDebit = lines.reduce((acc, l) => acc + (Number(l.debitUSD) || 0), 0);
  const totalCredit = lines.reduce((acc, l) => acc + (Number(l.creditUSD) || 0), 0);
  const isBalanced = Math.abs(totalDebit - totalCredit) < 0.01;

  const handlePostTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    setPostError(null);

    const newTx: JournalTransaction = {
      id: `TX-${Date.now()}`,
      transactionDate: new Date().toISOString().split('T')[0],
      reference,
      description,
      lines,
      isBalanced,
      createdRole: role,
      createdAt: new Date().toISOString()
    };

    const res = addJournalTransaction(newTx);
    if (!res.success) {
      setPostError(res.message);
      return;
    }

    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-amber-400" />
            <span>Double-Entry General Financial Ledger</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Hard Accounting Invariant: TOTAL DEBITS == TOTAL CREDITS. Unbalanced Transactions Rejected by Kernel.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center space-x-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2.5 rounded-lg text-xs transition shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>Post Balanced Journal Transaction</span>
        </button>
      </div>

      {/* Journal Transactions Table */}
      <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
        <h3 className="text-sm font-semibold text-white">General Ledger Journal Entries</h3>

        <div className="space-y-4">
          {journalTransactions.map((tx) => (
            <div key={tx.id} className="bg-[#161b22] border border-[#30363d] rounded-xl p-4 space-y-3">
              <div className="flex justify-between items-start text-xs border-b border-[#30363d] pb-2">
                <div>
                  <span className="font-bold text-white font-mono">{tx.reference}</span>
                  <span className="text-slate-400 ml-2">({tx.transactionDate})</span>
                  <p className="text-slate-300 font-medium mt-0.5">{tx.description}</p>
                </div>

                <div className="text-right">
                  <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    VERIFIED BALANCED DEBITS = CREDITS
                  </span>
                  <div className="text-[10px] text-slate-400 mt-1 font-mono">Posted by: {tx.createdRole}</div>
                </div>
              </div>

              {/* Journal Lines */}
              <table className="w-full text-left text-xs text-slate-300 font-mono">
                <thead className="text-[10px] text-slate-400 uppercase tracking-wider">
                  <tr>
                    <th className="py-1">Account Code & Name</th>
                    <th className="py-1 text-right">Debit (USD)</th>
                    <th className="py-1 text-right">Credit (USD)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#21262d]">
                  {tx.lines.map((l, idx) => (
                    <tr key={idx}>
                      <td className="py-1.5 text-white font-medium">{l.accountCode} — {l.accountName}</td>
                      <td className="py-1.5 text-right font-bold text-amber-300">
                        {l.debitUSD > 0 ? formatCurrency(l.debitUSD) : '—'}
                      </td>
                      <td className="py-1.5 text-right font-bold text-emerald-400">
                        {l.creditUSD > 0 ? formatCurrency(l.creditUSD) : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      </div>

      {/* New Journal Entry Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#121721] border border-[#30363d] rounded-2xl max-w-xl w-full p-6 space-y-5 shadow-2xl">
            <div className="flex justify-between items-center border-b border-[#21262d] pb-3">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <BookOpen className="w-5 h-5 text-amber-400" />
                <span>Post General Ledger Journal Transaction</span>
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {postError && (
              <div className="bg-red-500/10 border border-red-500/40 text-red-300 p-3 rounded-lg text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{postError}</span>
              </div>
            )}

            <form onSubmit={handlePostTransaction} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Journal Reference *</label>
                  <input
                    type="text"
                    required
                    value={reference}
                    onChange={(e) => setReference(e.target.value)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Transaction Description *</label>
                  <input
                    type="text"
                    required
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Lines Input */}
              <div className="space-y-3 border-t border-b border-[#21262d] py-3 font-mono">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider font-sans">Journal Entry Lines</h4>
                  <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded ${
                    isBalanced ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/10 text-red-400 border border-red-500/30'
                  }`}>
                    Debits (${totalDebit.toLocaleString()}) == Credits (${totalCredit.toLocaleString()})
                  </span>
                </div>

                {lines.map((line, idx) => (
                  <div key={idx} className="grid grid-cols-3 gap-3 bg-[#161b22] p-2.5 rounded border border-[#30363d] items-center">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5 font-sans">Account</label>
                      <select
                        value={line.accountCode}
                        onChange={(e) => updateLine(idx, 'accountCode', e.target.value)}
                        className="w-full bg-[#1c212c] border border-[#30363d] text-white p-1.5 rounded text-xs"
                      >
                        {accountOptions.map(a => (
                          <option key={a.code} value={a.code}>{a.name}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5 font-sans">Debit (USD)</label>
                      <input
                        type="number"
                        value={line.debitUSD}
                        onChange={(e) => updateLine(idx, 'debitUSD', parseFloat(e.target.value) || 0)}
                        className="w-full bg-[#1c212c] border border-[#30363d] text-amber-300 font-bold p-1.5 rounded text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-400 mb-0.5 font-sans">Credit (USD)</label>
                      <input
                        type="number"
                        value={line.creditUSD}
                        onChange={(e) => updateLine(idx, 'creditUSD', parseFloat(e.target.value) || 0)}
                        className="w-full bg-[#1c212c] border border-[#30363d] text-emerald-400 font-bold p-1.5 rounded text-xs"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#161b22] border border-[#30363d] text-slate-300 rounded-lg font-medium hover:bg-[#1c212c]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!isBalanced}
                  className={`px-5 py-2 font-bold rounded-lg shadow ${
                    isBalanced 
                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 cursor-pointer' 
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  Post to Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
