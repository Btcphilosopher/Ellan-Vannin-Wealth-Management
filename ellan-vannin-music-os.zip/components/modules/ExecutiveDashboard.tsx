'use client';

import React from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { 
  TrendingUp, 
  Users, 
  Disc, 
  DollarSign, 
  ShieldCheck, 
  Sparkles, 
  Briefcase,
  PieChart as PieIcon,
  Activity,
  Award
} from 'lucide-react';

export function ExecutiveDashboard() {
  const { 
    role, 
    artists, 
    masters, 
    releases, 
    formatCurrency, 
    valuationReport, 
    digitalTwinState,
    royaltyRuns,
    setActiveTab 
  } = useMusicOS();

  // Aggregate Metrics
  const totalStreams = artists.reduce((acc, a) => acc + a.metrics.totalStreams, 0);
  const totalLtmRevenue = artists.reduce((acc, a) => acc + a.metrics.catalogueLTMRevenueUSD, 0);
  const totalActiveArtists = artists.length;
  const catalogueBaseValuation = valuationReport.baseValuationUSD;

  // Stream Trend Data (Synthetic 6-month historical trajectory)
  const streamData = [
    { month: 'Mar', streams: 38000000, revenue: 145000 },
    { month: 'Apr', streams: 42000000, revenue: 160000 },
    { month: 'May', streams: 47000000, revenue: 182000 },
    { month: 'Jun', streams: 51000000, revenue: 198000 },
    { month: 'Jul', streams: 56000000, revenue: 215000 },
    { month: 'Aug', streams: 61000000, revenue: 240000 },
  ];

  // Revenue Breakdown By Source
  const revenueBySource = [
    { name: 'DSP Streaming', value: 68, color: '#f59e0b' },
    { name: 'Sync Licensing', value: 16, color: '#10b981' },
    { name: 'Publishing Performance', value: 10, color: '#3b82f6' },
    { name: 'Physical Products', value: 6, color: '#8b5cf6' },
  ];

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#161b22] via-[#1c2330] to-[#161b22] p-6 rounded-xl border border-[#30363d] shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <h1 className="text-2xl font-bold text-white tracking-wide">Executive Command Centre</h1>
            <span className="text-xs font-mono px-2.5 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-full font-medium">
              Role: {role.replace(/_/g, ' ')}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time Institutional Operating Twin — Unified Rights, Cashflow, Recoupment & Valuation Overview
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button 
            onClick={() => setActiveTab('DIGITAL_TWIN')}
            className="flex items-center space-x-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 px-3.5 py-2 rounded-lg text-xs font-semibold transition"
          >
            <Activity className="w-4 h-4 text-amber-400" />
            <span>Simulate Digital Twin</span>
          </button>
          <button 
            onClick={() => setActiveTab('AI_COPILOT')}
            className="flex items-center space-x-2 bg-amber-500 text-slate-950 font-bold px-3.5 py-2 rounded-lg text-xs shadow-md hover:bg-amber-400 transition"
          >
            <Sparkles className="w-4 h-4" />
            <span>AI Executive Brief</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total Catalogue LTM Revenue */}
        <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Catalogue LTM Revenue</p>
              <h3 className="text-2xl font-extrabold text-white mt-1.5 font-mono">{formatCurrency(totalLtmRevenue)}</h3>
            </div>
            <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-400">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-center text-xs text-emerald-400 font-medium">
            <TrendingUp className="w-3.5 h-3.5 mr-1" />
            <span>+18.4% YoY Growth</span>
            <span className="text-slate-500 ml-2">vs. previous period</span>
          </div>
        </div>

        {/* Catalogue Base Valuation */}
        <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Catalogue Valuation (DCF)</p>
              <h3 className="text-2xl font-extrabold text-amber-300 mt-1.5 font-mono">{formatCurrency(catalogueBaseValuation)}</h3>
            </div>
            <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-400">
              <Briefcase className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-center text-xs text-amber-300 font-medium">
            <span>11.1x LTM Multiple</span>
            <span className="text-slate-500 ml-2">(8.5% Discount Rate)</span>
          </div>
        </div>

        {/* Global Streams */}
        <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Annual Stream Consumption</p>
              <h3 className="text-2xl font-extrabold text-white mt-1.5 font-mono">{(totalStreams / 1000000).toFixed(1)}M</h3>
            </div>
            <div className="p-2.5 bg-blue-500/10 border border-blue-500/20 rounded-lg text-blue-400">
              <Activity className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-center text-xs text-slate-400 font-medium">
            <span>Across 6 DSP Partners</span>
          </div>
        </div>

        {/* Active Roster & Masters */}
        <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Roster & Masters</p>
              <h3 className="text-2xl font-extrabold text-white mt-1.5 font-mono">{totalActiveArtists} Artists / {masters.length} Masters</h3>
            </div>
            <div className="p-2.5 bg-purple-500/10 border border-purple-500/20 rounded-lg text-purple-400">
              <Disc className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-center text-xs text-emerald-400 font-medium">
            <ShieldCheck className="w-3.5 h-3.5 mr-1" />
            <span>100% Technical QC Passed</span>
          </div>
        </div>

      </div>

      {/* Analytics Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Stream & Revenue Consumption Curve */}
        <div className="lg:col-span-2 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Monthly Stream Trajectory & Net Revenue</h3>
              <p className="text-xs text-slate-400">Multi-DSP Consumption Velocity Across Catalogue</p>
            </div>
            <span className="text-xs font-mono text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded">
              DSP Ingestion Active
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={streamData}>
                <defs>
                  <linearGradient id="streamGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" stroke="#6e7681" tickLine={false} fontSize={12} />
                <YAxis stroke="#6e7681" tickLine={false} fontSize={12} tickFormatter={(v) => `${(v/1000000).toFixed(0)}M`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#161b22', borderColor: '#30363d', borderRadius: '8px', color: '#fff' }}
                  formatter={(value: any) => [`${(Number(value)/1000000).toFixed(1)}M Streams`, 'Streams']}
                />
                <Area type="monotone" dataKey="streams" stroke="#f59e0b" strokeWidth={2.5} fillOpacity={1} fill="url(#streamGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Revenue Allocation Mix */}
        <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-sm font-semibold text-white">Revenue Sources Mix</h3>
              <PieIcon className="w-4 h-4 text-slate-400" />
            </div>
            <p className="text-xs text-slate-400 mb-4">Institutional Revenue Diversification Index</p>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={revenueBySource}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={70}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {revenueBySource.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#161b22', borderColor: '#30363d', borderRadius: '8px', color: '#fff' }}
                    formatter={(v: any) => [`${v}%`, 'Share']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-2">
            {revenueBySource.map((item) => (
              <div key={item.name} className="flex items-center space-x-2 text-xs">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></span>
                <span className="text-slate-300 font-medium">{item.name}</span>
                <span className="text-slate-400 font-mono">({item.value}%)</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Roster Spotlight Table */}
      <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Institutional Roster & Recoupment Overview</h3>
            <p className="text-xs text-slate-400">Canonical Artist Financials & Recoupment Amortisation Status</p>
          </div>
          <button 
            onClick={() => setActiveTab('ARTISTS_ROSTER')}
            className="text-xs font-semibold text-amber-400 hover:text-amber-300 transition"
          >
            View Full Roster →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 font-medium">
            <thead className="bg-[#161b22] text-slate-400 uppercase text-[10px] tracking-wider border-b border-[#30363d]">
              <tr>
                <th className="py-3 px-4">Artist</th>
                <th className="py-3 px-4">Stage</th>
                <th className="py-3 px-4">Monthly Listeners</th>
                <th className="py-3 px-4">Catalogue LTM Revenue</th>
                <th className="py-3 px-4">A&R Status</th>
                <th className="py-3 px-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {artists.map((artist) => (
                <tr key={artist.id} className="hover:bg-[#181e2b] transition">
                  <td className="py-3.5 px-4 font-semibold text-white flex items-center space-x-2">
                    <span className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs border border-amber-500/30">
                      {artist.stageName.charAt(0)}
                    </span>
                    <div>
                      <div>{artist.stageName}</div>
                      <div className="text-[10px] text-slate-400 font-normal">{artist.legalName}</div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-blue-500/10 text-blue-300 border border-blue-500/30">
                      {artist.careerStage}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono">{artist.metrics.monthlyListeners.toLocaleString()}</td>
                  <td className="py-3.5 px-4 font-mono font-semibold text-amber-300">
                    {formatCurrency(artist.metrics.catalogueLTMRevenueUSD)}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                      {artist.aandrStatus}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <button 
                      onClick={() => setActiveTab('ROYALTIES_RECOUPMENT')}
                      className="text-xs text-amber-400 hover:underline font-medium"
                    >
                      Royalty Ledger →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
