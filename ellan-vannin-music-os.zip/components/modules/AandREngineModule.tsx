'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { ARCandidate, ARScoringWeights } from '../../lib/domain/types';
import { Compass, Sliders, Sparkles, Plus, Award, CheckCircle2, AlertTriangle, X } from 'lucide-react';

export function AandREngineModule() {
  const { arCandidates, arWeights, updateARWeights, addARCandidate } = useMusicOS();
  const [showScoutModal, setShowScoutModal] = useState(false);

  // New Scout Candidate Form
  const [artistName, setArtistName] = useState('');
  const [genre, setGenre] = useState('Indie Electronic');
  const [location, setLocation] = useState('London, UK');
  const [scoutName, setScoutName] = useState('A&R Executive Julian Vance');
  const [demoTrack, setDemoTrack] = useState('Cascade (Rough Demo)');
  const [notes, setNotes] = useState('Strong viral TikTok audio traction + editorial playlist potential.');

  const [ratings, setRatings] = useState({
    artisticQuality: 8,
    audienceGrowth: 8,
    engagement: 7,
    commercialPotential: 8,
    cataloguePotential: 7,
    internationalPotential: 7,
    livePotential: 8,
    syncPotential: 9
  });

  const handleRatingChange = (key: keyof typeof ratings, val: number) => {
    setRatings(prev => ({ ...prev, [key]: val }));
  };

  const handleWeightChange = (key: keyof ARScoringWeights, val: number) => {
    const updated = { ...arWeights, [key]: val };
    updateARWeights(updated);
  };

  const handleScoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!artistName) return;

    const newCandidate: ARCandidate = {
      id: `AR-${Date.now()}`,
      artistName,
      genre,
      location,
      scoutName,
      submittedDemoTrackTitle: demoTrack,
      ratings,
      calculatedScore: 0,
      recommendation: ratings.artisticQuality >= 8 ? 'HIGHLY_RECOMMENDED' : 'DEVELOPMENT_DEAL',
      notes
    };

    addARCandidate(newCandidate);
    setShowScoutModal(false);
    setArtistName('');
    setNotes('');
  };

  // Sum of weights validation
  const totalWeight = Object.values(arWeights).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Compass className="w-5 h-5 text-amber-400" />
            <span>Institutional A&R Decision-Support Engine</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configurable Scoring Model: 0.20 × Artistic + 0.15 × Audience + 0.15 × Engagement + 0.15 × Commercial + 0.10 × Catalogue + 0.10 × Int&apos;l + 0.10 × Live + 0.05 × Sync
          </p>
        </div>

        <button
          onClick={() => setShowScoutModal(true)}
          className="flex items-center space-x-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2.5 rounded-lg text-xs transition shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>Submit Demo / Scout Talent</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Configurable Weightings Matrix */}
        <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
          <div className="flex justify-between items-center border-b border-[#21262d] pb-3">
            <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>A&R Scoring Weights Config</span>
            </h3>
            <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
              Math.abs(totalWeight - 1.0) < 0.01 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/10 text-red-400 border border-red-500/30'
            }`}>
              Σ = {totalWeight.toFixed(2)} / 1.00
            </span>
          </div>

          <p className="text-xs text-slate-400">
            Adjust internal decision weights to reflect label strategy (e.g. higher sync priority for catalogue deals, or higher viral engagement for pop roster).
          </p>

          <div className="space-y-3 text-xs">
            {Object.entries(arWeights).map(([key, value]) => (
              <div key={key} className="space-y-1">
                <div className="flex justify-between text-slate-300">
                  <span className="capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                  <span className="font-mono text-amber-400 font-semibold">{(value * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="0.40"
                  step="0.05"
                  value={value}
                  onChange={(e) => handleWeightChange(key as keyof ARScoringWeights, parseFloat(e.target.value))}
                  className="w-full accent-amber-500 bg-[#161b22]"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Scout Candidate Pipeline Cards */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-sm font-semibold text-white">Active A&R Scouting Candidates & Talent Scores</h3>

          <div className="space-y-4">
            {arCandidates.map((candidate) => (
              <div key={candidate.id} className="bg-[#121721] p-5 rounded-xl border border-[#21262d] hover:border-amber-500/40 transition space-y-4">
                
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center space-x-3">
                      <h4 className="text-lg font-bold text-white">{candidate.artistName}</h4>
                      <span className="text-xs font-mono px-2.5 py-0.5 rounded bg-[#161b22] text-slate-300 border border-[#30363d]">
                        {candidate.genre} • {candidate.location}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      Submitted Demo: <span className="text-amber-300 font-medium">&quot;{candidate.submittedDemoTrackTitle}&quot;</span> • Scouted by {candidate.scoutName}
                    </p>
                  </div>

                  <div className="text-right">
                    <div className="text-2xl font-extrabold font-mono text-amber-400">{candidate.calculatedScore.toFixed(2)} / 10</div>
                    <span className={`inline-block mt-1 text-[10px] font-mono font-bold px-2.5 py-0.5 rounded border ${
                      candidate.recommendation === 'HIGHLY_RECOMMENDED'
                        ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                        : 'bg-blue-500/10 text-blue-300 border-blue-500/30'
                    }`}>
                      {candidate.recommendation.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>

                {/* Individual Ratings Bar Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-[#161b22] p-3 rounded-lg border border-[#30363d] text-[11px]">
                  <div>
                    <span className="text-slate-400">Artistic Quality:</span>
                    <span className="font-mono text-white font-semibold ml-1.5">{candidate.ratings.artisticQuality}/10</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Audience Growth:</span>
                    <span className="font-mono text-white font-semibold ml-1.5">{candidate.ratings.audienceGrowth}/10</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Engagement:</span>
                    <span className="font-mono text-white font-semibold ml-1.5">{candidate.ratings.engagement}/10</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Commercial:</span>
                    <span className="font-mono text-white font-semibold ml-1.5">{candidate.ratings.commercialPotential}/10</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Catalogue Value:</span>
                    <span className="font-mono text-white font-semibold ml-1.5">{candidate.ratings.cataloguePotential}/10</span>
                  </div>
                  <div>
                    <span className="text-slate-400">International:</span>
                    <span className="font-mono text-white font-semibold ml-1.5">{candidate.ratings.internationalPotential}/10</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Live Power:</span>
                    <span className="font-mono text-white font-semibold ml-1.5">{candidate.ratings.livePotential}/10</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Sync Potential:</span>
                    <span className="font-mono text-white font-semibold ml-1.5">{candidate.ratings.syncPotential}/10</span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 italic bg-[#181e2b] p-2.5 rounded border border-[#262c3a]">
                  &quot;{candidate.notes}&quot;
                </p>

              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Scout Modal */}
      {showScoutModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#121721] border border-[#30363d] rounded-2xl max-w-xl w-full p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-[#21262d] pb-3">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <Compass className="w-5 h-5 text-amber-400" />
                <span>Submit A&R Demo / Talent Candidate</span>
              </h3>
              <button onClick={() => setShowScoutModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleScoutSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Artist / Group Name *</label>
                  <input
                    type="text"
                    required
                    value={artistName}
                    onChange={(e) => setArtistName(e.target.value)}
                    placeholder="e.g. Solstice Arc"
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Genre</label>
                  <input
                    type="text"
                    value={genre}
                    onChange={(e) => setGenre(e.target.value)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Demo Track Title</label>
                  <input
                    type="text"
                    value={demoTrack}
                    onChange={(e) => setDemoTrack(e.target.value)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Scout / A&R Lead</label>
                  <input
                    type="text"
                    value={scoutName}
                    onChange={(e) => setScoutName(e.target.value)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Ratings Sliders (1-10) */}
              <div className="border-t border-b border-[#21262d] py-3 my-2 space-y-3">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">A&R Talent Evaluation Matrix (1 - 10)</h4>
                
                <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                  {Object.entries(ratings).map(([key, val]) => (
                    <div key={key}>
                      <div className="flex justify-between text-slate-300 mb-1">
                        <span className="capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                        <span className="font-mono text-amber-300 font-bold">{val}</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="10"
                        value={val}
                        onChange={(e) => handleRatingChange(key as keyof typeof ratings, parseInt(e.target.value))}
                        className="w-full accent-amber-500 bg-[#161b22]"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">A&R Scout Notes & Commercial Assessment</label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-3 border-t border-[#21262d]">
                <button
                  type="button"
                  onClick={() => setShowScoutModal(false)}
                  className="px-4 py-2 bg-[#161b22] border border-[#30363d] text-slate-300 rounded-lg font-medium hover:bg-[#1c212c]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg shadow"
                >
                  Compute Score & Submit Candidate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
