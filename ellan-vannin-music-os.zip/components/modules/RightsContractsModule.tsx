'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { FileCheck, ShieldCheck, Lock, Clock, FileText, AlertTriangle } from 'lucide-react';

export function RightsContractsModule() {
  const { contracts, rights, formatCurrency } = useMusicOS();

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <FileCheck className="w-5 h-5 text-amber-400" />
            <span>Structured Contract Vault & Time-Bounded Rights Registry</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Immutable Executed Agreements, Royalty Rates, Advance Commitments & Time-Bounded Master/Publishing Rights
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono px-3 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-full flex items-center space-x-1">
            <Lock className="w-3 h-3 mr-1 text-amber-400" />
            <span>Immutable Ledger Provenance</span>
          </span>
        </div>
      </div>

      {/* Contracts Grid */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-white">Executed Commercial Agreements</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {contracts.map((contract) => (
            <div key={contract.id} className="bg-[#121721] border border-[#21262d] rounded-xl p-5 hover:border-amber-500/40 transition space-y-4 shadow-lg">
              
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-base font-bold text-white">{contract.title}</h4>
                  <div className="text-xs font-mono text-amber-300 mt-0.5">{contract.contractNumber}</div>
                </div>

                <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  {contract.status}
                </span>
              </div>

              {/* Commercial Terms Summary */}
              <div className="bg-[#161b22] p-4 rounded-lg border border-[#30363d] space-y-2.5 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Master Royalty Rate:</span>
                  <span className="font-mono font-bold text-amber-300">{contract.royaltyRateMasterPercent}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Sync Royalty Rate:</span>
                  <span className="font-mono font-bold text-emerald-400">{contract.royaltyRateSyncPercent}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Initial Recording Advance:</span>
                  <span className="font-mono font-bold text-white">{formatCurrency(contract.advanceAmountUSD)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Term Length / Territory:</span>
                  <span className="font-mono text-slate-200">{contract.termYears} Years ({contract.territory})</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Cross-Collateralised:</span>
                  <span className={`font-mono font-bold ${contract.crossCollateralised ? 'text-amber-400' : 'text-slate-400'}`}>
                    {contract.crossCollateralised ? 'YES (Explicit Clause)' : 'NO (Uncollateralised)'}
                  </span>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 flex items-center justify-between pt-2 border-t border-[#21262d]">
                <span>Effective Date: {contract.effectiveDate}</span>
                <span className="text-amber-400 font-mono">Provenanced Execution ID: {contract.id}</span>
              </div>

            </div>
          ))}
        </div>
      </div>

      {/* Rights Vault */}
      <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
        <h3 className="text-sm font-semibold text-white">Time-Bounded Rights Registry & Provenance Logs</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 font-medium">
            <thead className="bg-[#161b22] text-slate-400 uppercase text-[10px] tracking-wider border-b border-[#30363d]">
              <tr>
                <th className="py-3 px-4">Right ID / Asset</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Rightsholder Owner</th>
                <th className="py-3 px-4">Share %</th>
                <th className="py-3 px-4">Territory</th>
                <th className="py-3 px-4">Contract Reference</th>
                <th className="py-3 px-4">Confidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {rights.map((rgt) => (
                <tr key={rgt.id} className="hover:bg-[#181e2b] transition font-mono">
                  <td className="py-3.5 px-4 font-bold text-white">{rgt.id} ({rgt.assetId})</td>
                  <td className="py-3.5 px-4 text-amber-300 font-semibold">{rgt.category}</td>
                  <td className="py-3.5 px-4 text-slate-200">{rgt.ownerName}</td>
                  <td className="py-3.5 px-4 font-bold text-amber-400">{rgt.percentage}%</td>
                  <td className="py-3.5 px-4">{rgt.territory}</td>
                  <td className="py-3.5 px-4 text-slate-400">{rgt.sourceDocumentRef}</td>
                  <td className="py-3.5 px-4 text-emerald-400 font-bold">{(rgt.confidenceScore * 100).toFixed(0)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
