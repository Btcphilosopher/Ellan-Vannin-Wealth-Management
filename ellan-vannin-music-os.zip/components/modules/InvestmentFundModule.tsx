'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { InvestmentDeal } from '../../lib/domain/types';
import { Briefcase, Plus, X } from 'lucide-react';

export function InvestmentFundModule() {
  const { investmentDeals, updateInvestmentDealStatus, formatCurrency } = useMusicOS();
  const [showAddModal, setShowAddModal] = useState(false);

  // Form State
  const [targetAssetTitle, setTargetAssetTitle] = useState('70s Soul & Funk Publishing Catalogue');
  const [purchasePriceUSD, setPurchasePriceUSD] = useState(2400000);
  const [expectedLTMRevenueUSD, setExpectedLTMRevenueUSD] = useState(260000);
  const [projectedIrrPercent, setProjectedIrrPercent] = useState(13.8);

  const handleCreateDeal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetAssetTitle) return;
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Briefcase className="w-5 h-5 text-amber-400" />
            <span>Music Investment Fund & Catalogue Acquisition Pipeline</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Institutional Catalogue Acquisition Pipeline, DCF Valuation Benchmarks & Investment Committee Clearances
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center space-x-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2.5 rounded-lg text-xs transition shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>Submit Acquisition Deal</span>
        </button>
      </div>

      {/* Deals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {investmentDeals.map((deal) => {
          const multiple = deal.expectedLTMRevenueUSD > 0 
            ? (deal.purchasePriceUSD / deal.expectedLTMRevenueUSD).toFixed(1) 
            : 'N/A';

          return (
            <div key={deal.id} className="bg-[#121721] border border-[#21262d] rounded-xl p-5 hover:border-amber-500/40 transition space-y-4 shadow-lg">
              
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-bold text-white">{deal.targetAssetTitle}</h3>
                  <span className="text-xs font-mono text-amber-300">{deal.dealType.replace(/_/g, ' ')}</span>
                </div>

                <span className={`px-2.5 py-1 text-[10px] font-mono font-bold rounded ${
                  deal.icStatus === 'APPROVED' ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30' :
                  deal.icStatus === 'ACQUIRED' ? 'bg-blue-500/15 text-blue-300 border border-blue-500/30' :
                  'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                }`}>
                  IC STATUS: {deal.icStatus}
                </span>
              </div>

              {/* Metrics Matrix */}
              <div className="bg-[#161b22] p-4 rounded-lg border border-[#30363d] grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block">Purchase Price:</span>
                  <span className="font-mono font-bold text-white text-sm">{formatCurrency(deal.purchasePriceUSD)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Expected LTM Revenue:</span>
                  <span className="font-mono font-bold text-amber-300 text-sm">{formatCurrency(deal.expectedLTMRevenueUSD)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Implied Multiple:</span>
                  <span className="font-mono font-bold text-emerald-400 text-sm">{multiple}x LTM</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Projected 10-Yr IRR:</span>
                  <span className="font-mono font-bold text-amber-400 text-sm">{deal.projectedIrrPercent}%</span>
                </div>
              </div>

              {/* IC Voting / Approval Actions */}
              <div className="flex justify-between items-center text-xs pt-2 border-t border-[#21262d]">
                <span className="text-slate-400 font-mono">
                  Lead Partner: <span className="text-white font-bold">{deal.leadPartner}</span>
                </span>
                <div className="flex space-x-2">
                  {deal.icStatus !== 'APPROVED' && deal.icStatus !== 'ACQUIRED' && (
                    <button
                      onClick={() => updateInvestmentDealStatus(deal.id, 'APPROVED')}
                      className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded font-mono text-[10px] hover:bg-emerald-500/30 transition"
                    >
                      Approve Deal
                    </button>
                  )}
                  {deal.icStatus === 'APPROVED' && (
                    <button
                      onClick={() => updateInvestmentDealStatus(deal.id, 'ACQUIRED')}
                      className="px-2.5 py-1 bg-blue-500/20 text-blue-300 border border-blue-500/40 rounded font-mono text-[10px] hover:bg-blue-500/30 transition"
                    >
                      Mark Acquired
                    </button>
                  )}
                </div>
              </div>

            </div>
          );
        })}
      </div>

      {/* New Deal Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#121721] border border-[#30363d] rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl">
            <div className="flex justify-between items-center border-b border-[#21262d] pb-3">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <Briefcase className="w-5 h-5 text-amber-400" />
                <span>Submit Acquisition Deal to IC</span>
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateDeal} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Target Asset Title *</label>
                <input
                  type="text"
                  required
                  value={targetAssetTitle}
                  onChange={(e) => setTargetAssetTitle(e.target.value)}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Purchase Price (USD)</label>
                  <input
                    type="number"
                    value={purchasePriceUSD}
                    onChange={(e) => setPurchasePriceUSD(parseFloat(e.target.value) || 0)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Expected LTM Revenue (USD)</label>
                  <input
                    type="number"
                    value={expectedLTMRevenueUSD}
                    onChange={(e) => setExpectedLTMRevenueUSD(parseFloat(e.target.value) || 0)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white font-mono focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Projected 10-Yr Internal Rate of Return (IRR %)</label>
                <input
                  type="number"
                  step="0.1"
                  value={projectedIrrPercent}
                  onChange={(e) => setProjectedIrrPercent(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white font-mono focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#161b22] border border-[#30363d] text-slate-300 rounded-lg font-medium hover:bg-[#1c212c]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg shadow"
                >
                  Submit to Investment Committee
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
