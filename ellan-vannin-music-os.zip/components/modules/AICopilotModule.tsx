'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { Sparkles, Send, Bot, User, RefreshCw, Compass, FileCheck, TrendingUp, ShieldAlert } from 'lucide-react';

export function AICopilotModule() {
  const { role, artists, masters, valuationReport, anomalies } = useMusicOS();

  const [prompt, setPrompt] = useState('');
  const [taskType, setTaskType] = useState<'AANDR_EVALUATION' | 'CONTRACT_ANALYSIS' | 'VALUATION_SYNTHESIS' | 'ANOMALY_EXPLANATION'>('AANDR_EVALUATION');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Array<{ sender: 'USER' | 'COPILOT'; text: string; timestamp: string }>>([
    {
      sender: 'COPILOT',
      text: `Greetings ${role.replace(/_/g, ' ')}. I am your institutional Gemini 3.6 Music OS Decision Copilot. Ask me to synthesize catalogue DCF valuations, evaluate A&R scouting submissions, parse contract rights clauses, or explain royalty anomalies.`,
      timestamp: new Date().toLocaleTimeString()
    }
  ]);

  const handleSendPrompt = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || loading) return;

    const userMessage = prompt;
    setPrompt('');
    setMessages(prev => [...prev, { sender: 'USER', text: userMessage, timestamp: new Date().toLocaleTimeString() }]);
    setLoading(true);

    try {
      const response = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userMessage,
          taskType,
          contextData: {
            role,
            totalArtists: artists.length,
            totalMasters: masters.length,
            baseValuationUSD: valuationReport.baseValuationUSD,
            openAnomalies: anomalies.filter(a => a.status !== 'RESOLVED').length
          }
        })
      });

      const data = await response.json();
      setMessages(prev => [
        ...prev,
        {
          sender: 'COPILOT',
          text: data.analysis || "Analysis complete.",
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          sender: 'COPILOT',
          text: "Apologies, the AI Copilot API encountered a transient network issue.",
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const presetQueries = [
    { label: "Synthesize DCF Valuation Impact", type: "VALUATION_SYNTHESIS" as const, query: "Provide an executive summary of our $1.6M LTM catalogue valuation at an 8.5% discount rate." },
    { label: "Evaluate A&R Scouting Pipeline", type: "AANDR_EVALUATION" as const, query: "Assess the top candidate in our A&R scouting pipeline for sync licensing potential." },
    { label: "Inspect Open Anomaly Alerts", type: "ANOMALY_EXPLANATION" as const, query: "Explain the active anomaly alerts regarding duplicate ISRCs or streaming spikes." },
    { label: "Analyze Contract Rights Terms", type: "CONTRACT_ANALYSIS" as const, query: "Summarize the cross-collateralisation clauses and master royalty rates across our executed agreements." }
  ];

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>Gemini 3.6 AI Executive Decision Assistant</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Decision-Support Only • Never autonomously signs contracts, changes ownership, pays royalties, or alters audit history
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono px-3 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-full">
            Gemini 3.6 Flash Active
          </span>
        </div>
      </div>

      {/* Preset Action Chips */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {presetQueries.map((pq) => (
          <button
            key={pq.label}
            onClick={() => {
              setTaskType(pq.type);
              setPrompt(pq.query);
            }}
            className="bg-[#121721] p-3 rounded-xl border border-[#21262d] hover:border-amber-500/40 text-left transition space-y-1 group"
          >
            <div className="text-xs font-bold text-white group-hover:text-amber-400">{pq.label}</div>
            <div className="text-[10px] text-slate-400 line-clamp-1">{pq.query}</div>
          </button>
        ))}
      </div>

      {/* Chat Container */}
      <div className="bg-[#121721] rounded-xl border border-[#21262d] flex flex-col h-[500px] overflow-hidden">
        
        {/* Messages List */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4 font-sans text-xs">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start space-x-3 ${m.sender === 'USER' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'COPILOT' && (
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div className={`max-w-2xl rounded-xl p-4 space-y-1 ${
                m.sender === 'USER' 
                  ? 'bg-amber-500 text-slate-950 font-medium' 
                  : 'bg-[#161b22] text-slate-200 border border-[#30363d]'
              }`}>
                <div className="flex justify-between items-center text-[10px] opacity-75 mb-1 font-mono">
                  <span>{m.sender === 'USER' ? 'Executive User' : 'Gemini 3.6 Copilot'}</span>
                  <span>{m.timestamp}</span>
                </div>
                <div className="whitespace-pre-wrap leading-relaxed">{m.text}</div>
              </div>

              {m.sender === 'USER' && (
                <div className="w-8 h-8 rounded-lg bg-slate-800 text-white flex items-center justify-center shrink-0 mt-0.5 border border-slate-700">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center space-x-2 text-xs text-amber-400 font-mono italic">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Analyzing canonical domain context with Gemini 3.6...</span>
            </div>
          )}
        </div>

        {/* Prompt Input Form */}
        <form onSubmit={handleSendPrompt} className="p-4 bg-[#161b22] border-t border-[#21262d] flex gap-3">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Ask AI Copilot for valuation synthesis, A&R candidate evaluation, or royalty clause parsing..."
            className="flex-1 bg-[#0b0e14] border border-[#30363d] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 font-medium"
          />

          <button
            type="submit"
            disabled={loading || !prompt.trim()}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800 text-slate-950 font-bold rounded-xl shadow flex items-center space-x-2 text-xs transition"
          >
            <Send className="w-4 h-4" />
            <span>Synthesize</span>
          </button>
        </form>

      </div>

    </div>
  );
}
