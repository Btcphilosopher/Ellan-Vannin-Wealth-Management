'use client';

import React from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { Share2, Calendar, CheckCircle2, ShieldCheck, Globe, Music, ExternalLink } from 'lucide-react';

export function ReleasesModule() {
  const { releases } = useMusicOS();

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Share2 className="w-5 h-5 text-amber-400" />
            <span>Institutional Release Management & DSP Delivery</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Global Release Planning Calendar, UPC Catalogue Registry, Pre-Save Analytics & Multi-DSP Ingestion Status
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono px-3 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-full">
            Active DDEX Delivery Pipeline
          </span>
        </div>
      </div>

      {/* Releases Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {releases.map((rel) => (
          <div key={rel.id} className="bg-[#121721] border border-[#21262d] rounded-xl p-5 hover:border-amber-500/40 transition space-y-4 shadow-lg">
            
            <div className="flex space-x-4">
              <img
                src={rel.coverArtworkUrl}
                alt={rel.title}
                referrerPolicy="no-referrer"
                className="w-24 h-24 rounded-lg object-cover border border-[#30363d] shadow-md"
              />

              <div className="flex-1 space-y-1">
                <div className="flex justify-between items-start">
                  <h3 className="text-lg font-bold text-white">{rel.title}</h3>
                  <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">
                    {rel.status}
                  </span>
                </div>

                <p className="text-xs text-slate-300 font-medium">{rel.artistName}</p>
                
                <div className="text-[11px] font-mono text-amber-400 pt-1">
                  UPC: {rel.upc} • Format: {rel.releaseType}
                </div>

                <div className="text-xs text-slate-400 flex items-center space-x-2">
                  <Calendar className="w-3.5 h-3.5 text-amber-400" />
                  <span>Release Date: {rel.releaseDate}</span>
                </div>
              </div>
            </div>

            {/* Pre-save & DSP Pipeline */}
            <div className="bg-[#161b22] p-3.5 rounded-lg border border-[#30363d] space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Pre-Save Campaign Count:</span>
                <span className="font-mono font-bold text-white">{rel.preSaveCount.toLocaleString()} Pre-Saves</span>
              </div>

              <div className="pt-2 border-t border-[#21262d]">
                <span className="text-slate-400 text-[11px] block mb-1">Delivered DSP Partners:</span>
                <div className="flex flex-wrap gap-1.5">
                  {rel.dspsDelivered.map((dsp) => (
                    <span key={dsp} className="px-2 py-0.5 text-[10px] font-mono bg-[#1c212c] text-emerald-300 border border-emerald-500/30 rounded">
                      ✓ {dsp}
                    </span>
                  ))}
                </div>
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
