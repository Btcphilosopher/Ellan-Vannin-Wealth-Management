'use client';

import React from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { ShieldCheck, ShieldAlert, CheckCircle2, Lock, FileText, AlertTriangle } from 'lucide-react';

export function FraudAuditModule() {
  const { auditLogs, anomalies, resolveAnomaly } = useMusicOS();

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <span>Append-Only Audit Trail & Anomaly Detection Engine</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Institutional Audit Verification, Immutable Log Hashes, Rights Conflict Alerts & Stream Spike Anomaly Inspections
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono px-3 py-1 bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 rounded-full flex items-center space-x-1">
            <Lock className="w-3 h-3 mr-1 text-emerald-400" />
            <span>Tamper-Evident Hash Chain Active</span>
          </span>
        </div>
      </div>

      {/* Anomalies Grid */}
      <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
        <h3 className="text-sm font-semibold text-white flex items-center space-x-2">
          <ShieldAlert className="w-4 h-4 text-amber-400" />
          <span>Explainable Anomaly Alerts & Rights Conflict Inspections</span>
        </h3>

        <div className="space-y-3">
          {anomalies.map((anom) => (
            <div key={anom.id} className="bg-[#161b22] border border-[#30363d] rounded-xl p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-0.5 text-[10px] font-mono font-bold rounded ${
                    anom.severity === 'HIGH' ? 'bg-red-500/15 text-red-300 border border-red-500/30' :
                    anom.severity === 'MEDIUM' ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30' : 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
                  }`}>
                    {anom.severity} SEVERITY
                  </span>
                  <span className="text-xs font-mono font-bold text-white">{anom.category} • {anom.title}</span>
                </div>

                <p className="text-xs text-slate-300 font-medium">{anom.explanation}</p>
                <div className="text-[10px] text-slate-400 font-mono">Entity Ref: {anom.affectedEntityId} • Detected: {anom.timestamp}</div>
              </div>

              {anom.status !== 'RESOLVED' ? (
                <button
                  onClick={() => resolveAnomaly(anom.id)}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg shadow shrink-0"
                >
                  Mark Resolved
                </button>
              ) : (
                <span className="text-xs font-mono text-emerald-400 font-bold shrink-0">
                  ✓ RESOLVED
                </span>
              )}

            </div>
          ))}
        </div>
      </div>

      {/* Append-Only Audit Log */}
      <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
        <h3 className="text-sm font-semibold text-white">Append-Only System Action Ledger (Tamper-Evident)</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 font-mono">
            <thead className="bg-[#161b22] text-slate-400 uppercase text-[10px] tracking-wider border-b border-[#30363d]">
              <tr>
                <th className="py-3 px-4">Log ID / Timestamp</th>
                <th className="py-3 px-4">Actor Role</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Entity ID</th>
                <th className="py-3 px-4">Reason / Justification</th>
                <th className="py-3 px-4">Verification Hash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-[#181e2b] transition">
                  <td className="py-3.5 px-4 font-bold text-white">{log.id}</td>
                  <td className="py-3.5 px-4 text-amber-300">{log.actorRole}</td>
                  <td className="py-3.5 px-4 text-slate-200">{log.action}</td>
                  <td className="py-3.5 px-4 text-slate-400">{log.entityId}</td>
                  <td className="py-3.5 px-4 font-sans text-slate-300">{log.reason}</td>
                  <td className="py-3.5 px-4 text-emerald-400 font-bold">{(log.hash || '0x4f82a901e82b7c41').slice(0, 16)}...</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
