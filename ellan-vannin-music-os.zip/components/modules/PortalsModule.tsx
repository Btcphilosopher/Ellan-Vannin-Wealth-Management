'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { UserCheck, DollarSign, Download, Disc, Music, Activity } from 'lucide-react';

export function PortalsModule() {
  const { artists, masters, royaltyRuns, formatCurrency } = useMusicOS();
  const [selectedArtistId, setSelectedArtistId] = useState(artists[0]?.id || 'ART-001');

  const selectedArtist = artists.find(a => a.id === selectedArtistId) || artists[0];
  const artistMasters = masters.filter(m => m.artistId === selectedArtist.id);
  const artistRoyaltyRuns = royaltyRuns.filter(r => r.artistId === selectedArtist.id);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <UserCheck className="w-5 h-5 text-amber-400" />
            <span>Dedicated Artist & Label Management Portal</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Transparent Royalty Statements, Master Delivery Status, Streaming Analytics & Contract Terms Access
          </p>
        </div>

        {/* Artist Switcher */}
        <div className="flex items-center space-x-2 bg-[#161b22] border border-[#30363d] px-3 py-1.5 rounded-lg">
          <span className="text-xs text-slate-400">Viewing Portal For:</span>
          <select
            value={selectedArtistId}
            onChange={(e) => setSelectedArtistId(e.target.value)}
            className="bg-transparent text-xs font-bold text-amber-400 focus:outline-none cursor-pointer"
          >
            {artists.map(a => (
              <option key={a.id} value={a.id} className="bg-[#161b22] text-white">{a.stageName}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Artist Profile Spotlight */}
      <div className="bg-[#121721] p-6 rounded-xl border border-[#21262d] space-y-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center font-extrabold text-2xl text-slate-950 shadow-xl">
              {selectedArtist.stageName.charAt(0)}
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white">{selectedArtist.stageName}</h3>
              <p className="text-xs text-slate-400">{selectedArtist.legalName} • {selectedArtist.primaryTerritory}</p>
              <div className="text-xs font-mono text-amber-400 mt-1">Career Stage: {selectedArtist.careerStage}</div>
            </div>
          </div>

          <div className="text-right space-y-1">
            <div className="text-xs text-slate-400 uppercase tracking-wider">Catalogue LTM Revenue</div>
            <div className="text-2xl font-extrabold text-amber-300 font-mono">{formatCurrency(selectedArtist.metrics.catalogueLTMRevenueUSD)}</div>
          </div>
        </div>

        {/* Statement History */}
        <div className="pt-4 border-t border-[#21262d] space-y-3">
          <h4 className="text-sm font-semibold text-white">Royalty Statements & Downloadable Ledger PDFs</h4>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300 font-mono">
              <thead className="bg-[#161b22] text-slate-400 uppercase text-[10px] tracking-wider border-b border-[#30363d]">
                <tr>
                  <th className="py-2.5 px-4">Period</th>
                  <th className="py-2.5 px-4">Gross Ingested</th>
                  <th className="py-2.5 px-4">Net Receipts</th>
                  <th className="py-2.5 px-4">Rate %</th>
                  <th className="py-2.5 px-4">Earned Royalty</th>
                  <th className="py-2.5 px-4">Recoupment Applied</th>
                  <th className="py-2.5 px-4">Payable Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#21262d]">
                {artistRoyaltyRuns.map((r) => (
                  <tr key={r.id} className="hover:bg-[#181e2b] transition">
                    <td className="py-3 px-4 font-bold text-white">{r.periodLabel}</td>
                    <td className="py-3 px-4">{formatCurrency(r.grossRevenueUSD)}</td>
                    <td className="py-3 px-4">{formatCurrency(r.netReceiptsUSD)}</td>
                    <td className="py-3 px-4 text-amber-300">{r.contractRoyaltyRatePercent}%</td>
                    <td className="py-3 px-4">{formatCurrency(r.grossEarnedRoyaltyUSD)}</td>
                    <td className="py-3 px-4 text-amber-400">{formatCurrency(r.recoupmentDeductedUSD)}</td>
                    <td className="py-3 px-4 font-bold text-emerald-400">{formatCurrency(r.payableRoyaltyUSD)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  );
}
