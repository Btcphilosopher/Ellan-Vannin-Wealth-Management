'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { calculateCatalogueDCFValuation } from '../../lib/domain/math';
import { TrendingUp, Sliders, DollarSign, Activity, AlertCircle } from 'lucide-react';

export function CatalogueValuationModule() {
  const { valuationReport, formatCurrency } = useMusicOS();

  const [ltmRevenueUSD, setLtmRevenueUSD] = useState(valuationReport.ltmRevenueUSD);
  const [discountRatePercent, setDiscountRatePercent] = useState(8.5);
  const [terminalGrowthPercent, setTerminalGrowthPercent] = useState(2.0);
  const [annualDecayPercent, setAnnualDecayPercent] = useState(3.0);
  const [projectionYears, setProjectionYears] = useState(10);

  const calculatedValuation = calculateCatalogueDCFValuation({
    ltmRevenueUSD,
    discountRatePercent,
    terminalGrowthRatePercent: terminalGrowthPercent,
    annualDecayRatePercent: annualDecayPercent,
    projectionYears
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-amber-400" />
            <span>Catalogue DCF Valuation & Multi-Scenario Model</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            PV = Σ(CFt / (1+r)^t) + Terminal Value. Configurable Discount Rates, Royalty Decay & Multiple Benchmarks
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono px-3 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-full">
            Institutional Fund Standard
          </span>
        </div>
      </div>

      {/* Main Controls & Valuation Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* DCF Parameter Sliders */}
        <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
          <h3 className="text-sm font-semibold text-white flex items-center space-x-2 border-b border-[#21262d] pb-3">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>DCF Valuation Model Parameters</span>
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Catalogue LTM Revenue (USD)</span>
                <span className="font-mono text-amber-400 font-bold">${ltmRevenueUSD.toLocaleString()}</span>
              </div>
              <input
                type="number"
                step="50000"
                value={ltmRevenueUSD}
                onChange={(e) => setLtmRevenueUSD(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2 text-white font-mono"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Discount Rate (r)</span>
                <span className="font-mono text-amber-400 font-bold">{discountRatePercent}%</span>
              </div>
              <input
                type="range"
                min="4.0"
                max="16.0"
                step="0.5"
                value={discountRatePercent}
                onChange={(e) => setDiscountRatePercent(parseFloat(e.target.value))}
                className="w-full accent-amber-500 bg-[#161b22]"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Annual Royalty Decay Rate</span>
                <span className="font-mono text-amber-400 font-bold">{annualDecayPercent}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="10.0"
                step="0.5"
                value={annualDecayPercent}
                onChange={(e) => setAnnualDecayPercent(parseFloat(e.target.value))}
                className="w-full accent-amber-500 bg-[#161b22]"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Terminal Growth Rate (g)</span>
                <span className="font-mono text-amber-400 font-bold">{terminalGrowthPercent}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="4.0"
                step="0.25"
                value={terminalGrowthPercent}
                onChange={(e) => setTerminalGrowthPercent(parseFloat(e.target.value))}
                className="w-full accent-amber-500 bg-[#161b22]"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Projection Horizon</span>
                <span className="font-mono text-amber-400 font-bold">{projectionYears} Years</span>
              </div>
              <input
                type="range"
                min="5"
                max="20"
                step="1"
                value={projectionYears}
                onChange={(e) => setProjectionYears(parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-[#161b22]"
              />
            </div>
          </div>
        </div>

        {/* Calculated Scenarios Grid */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-sm font-semibold text-white">Multi-Scenario Catalogue Valuation Matrix</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {calculatedValuation.scenarios.map((sc) => (
              <div key={sc.scenarioName} className="bg-[#121721] p-5 rounded-xl border border-[#21262d] hover:border-amber-500/40 transition space-y-3">
                <div className="flex justify-between items-center">
                  <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded ${
                    sc.scenarioName === 'BASE' ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30' :
                    sc.scenarioName === 'BULL' ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30' :
                    sc.scenarioName === 'BEAR' ? 'bg-blue-500/15 text-blue-300 border border-blue-500/30' : 'bg-red-500/15 text-red-300 border border-red-500/30'
                  }`}>
                    {sc.scenarioName} CASE SCENARIO
                  </span>
                  <span className="text-xs font-mono text-slate-400">Rate: {sc.discountRatePercent}%</span>
                </div>

                <div>
                  <div className="text-xs text-slate-400 uppercase tracking-wider">Net Present Value (NPV)</div>
                  <div className="text-2xl font-extrabold text-white font-mono mt-1">{formatCurrency(sc.netPresentValueUSD)}</div>
                </div>

                <div className="bg-[#161b22] p-3 rounded-lg border border-[#30363d] flex justify-between items-center text-xs">
                  <span className="text-slate-400">Implied LTM Multiple:</span>
                  <span className="font-mono font-bold text-amber-300 text-sm">{sc.impliedMultiple}x</span>
                </div>
              </div>
            ))}
          </div>

          <p className="text-xs text-slate-400 italic bg-[#121721] p-4 rounded-xl border border-[#21262d]">
            &quot;Note: Valuation outputs are non-binding decision-support indicators grounded in Discounted Cash Flow math, streaming decay curves, and terminal growth assumptions.&quot;
          </p>
        </div>

      </div>

    </div>
  );
}
