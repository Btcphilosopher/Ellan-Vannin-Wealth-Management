'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { Artist, CareerStage } from '../../lib/domain/types';
import { Users, Plus, Globe, Music, BarChart2, ShieldCheck, X } from 'lucide-react';

export function ArtistsRosterModule() {
  const { artists, addArtist, formatCurrency } = useMusicOS();
  const [showAddModal, setShowAddModal] = useState(false);

  // New Artist Form State
  const [stageName, setStageName] = useState('');
  const [legalName, setLegalName] = useState('');
  const [genre, setGenre] = useState('Pop / Electronic');
  const [primaryTerritory, setPrimaryTerritory] = useState('GB');
  const [careerStage, setCareerStage] = useState<CareerStage>('SIGNED');
  const [biography, setBiography] = useState('');

  const handleCreateArtist = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stageName || !legalName) return;

    const newArtist: Artist = {
      id: `ART-${Date.now()}`,
      stageName,
      legalName,
      genre: genre.split(',').map(s => s.trim()),
      primaryTerritory,
      careerStage,
      biography: biography || 'Newly signed artist to Ellan Vannin Records.',
      labelId: 'LBL-EVR-001',
      socialAccounts: {
        instagram: `@${stageName.toLowerCase().replace(/\s+/g, '')}`
      },
      metrics: {
        monthlyListeners: 100000,
        totalStreams: 500000,
        socialFollowers: 25000,
        engagementRatePercent: 5.0,
        catalogueLTMRevenueUSD: 45000
      },
      aandrStatus: 'ACTIVE_ROSTER',
      createdAt: new Date().toISOString()
    };

    addArtist(newArtist);
    setShowAddModal(false);
    setStageName('');
    setLegalName('');
    setBiography('');
  };

  const careerStagesList: CareerStage[] = [
    'DISCOVERY', 'DEVELOPMENT', 'SIGNED', 'RECORDING', 'PRE_RELEASE', 'RELEASED', 'BREAKOUT', 'ESTABLISHED', 'LEGACY', 'CATALOGUE'
  ];

  return (
    <div className="space-y-6">
      
      {/* Top Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Users className="w-5 h-5 text-amber-400" />
            <span>Institutional Artist Roster</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Canonical Artist Identity Management, Career Stages, Audience Metrics & Contract Associations
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center space-x-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2.5 rounded-lg text-xs transition shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>Sign & Onboard Artist</span>
        </button>
      </div>

      {/* Roster Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {artists.map((artist) => (
          <div key={artist.id} className="bg-[#121721] border border-[#21262d] rounded-xl p-5 hover:border-amber-500/40 transition flex flex-col justify-between space-y-4 shadow-lg">
            
            {/* Card Header */}
            <div>
              <div className="flex justify-between items-start">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center font-bold text-lg text-slate-950 shadow-md">
                    {artist.stageName.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">{artist.stageName}</h3>
                    <p className="text-xs text-slate-400">{artist.legalName}</p>
                  </div>
                </div>

                <span className="px-2.5 py-1 text-[10px] font-mono font-semibold rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  {artist.careerStage}
                </span>
              </div>

              <p className="text-xs text-slate-300 mt-3 line-clamp-2 italic">
                &quot;{artist.biography}&quot;
              </p>
            </div>

            {/* Metrics Breakdown */}
            <div className="bg-[#161b22] p-3.5 rounded-lg border border-[#30363d] space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Monthly Listeners:</span>
                <span className="font-mono font-semibold text-white">{artist.metrics.monthlyListeners.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Total Global Streams:</span>
                <span className="font-mono font-semibold text-white">{(artist.metrics.totalStreams / 1000000).toFixed(1)}M</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Catalogue LTM Revenue:</span>
                <span className="font-mono font-bold text-amber-400">{formatCurrency(artist.metrics.catalogueLTMRevenueUSD)}</span>
              </div>
            </div>

            {/* Footer Attributes */}
            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-[#21262d]">
              <div className="flex items-center space-x-2">
                <Globe className="w-3.5 h-3.5 text-amber-400" />
                <span>Territory: {artist.primaryTerritory}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Music className="w-3.5 h-3.5 text-amber-400" />
                <span>{artist.genre.join(', ')}</span>
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* Add/Sign Artist Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#121721] border border-[#30363d] rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl">
            <div className="flex justify-between items-center border-b border-[#21262d] pb-3">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <Users className="w-5 h-5 text-amber-400" />
                <span>Institutional Artist Onboarding</span>
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateArtist} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Stage Name / Band Name *</label>
                <input
                  type="text"
                  required
                  value={stageName}
                  onChange={(e) => setStageName(e.target.value)}
                  placeholder="e.g. Isla Nova"
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Legal Identity / Company Name *</label>
                <input
                  type="text"
                  required
                  value={legalName}
                  onChange={(e) => setLegalName(e.target.value)}
                  placeholder="e.g. Isla Nova Music Rights Ltd"
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Primary Territory</label>
                  <input
                    type="text"
                    value={primaryTerritory}
                    onChange={(e) => setPrimaryTerritory(e.target.value)}
                    placeholder="GB, US, DE, WW..."
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Career Stage</label>
                  <select
                    value={careerStage}
                    onChange={(e) => setCareerStage(e.target.value as CareerStage)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  >
                    {careerStagesList.map(st => (
                      <option key={st} value={st}>{st}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Genres (comma separated)</label>
                <input
                  type="text"
                  value={genre}
                  onChange={(e) => setGenre(e.target.value)}
                  placeholder="Synth Pop, Indie Electronic"
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Artist Biography & Background</label>
                <textarea
                  rows={3}
                  value={biography}
                  onChange={(e) => setBiography(e.target.value)}
                  placeholder="A&R background summary..."
                  className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-3 border-t border-[#21262d]">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#161b22] border border-[#30363d] text-slate-300 rounded-lg font-medium hover:bg-[#1c212c]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg shadow"
                >
                  Confirm Sign & Onboard
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
