'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { Composition } from '../../lib/domain/types';
import { FileMusic, Globe, User, ShieldCheck, Plus, Check, X } from 'lucide-react';

export function PublishingModule() {
  const { compositions } = useMusicOS();

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <FileMusic className="w-5 h-5 text-amber-400" />
            <span>Publishing Engine & Composition Splits</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Songwriter Performance/Mechanical Split Verification, ISWC Identifiers, IPI Registry & PRO Society Registrations
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-mono px-3 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-full">
            PRO Partners: PRS, ASCAP, BMI, GEMA, SACEM, JASRAC
          </span>
        </div>
      </div>

      {/* Compositions List */}
      <div className="space-y-4">
        {compositions.map((comp) => (
          <div key={comp.id} className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
            
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center space-x-3">
                  <h3 className="text-lg font-bold text-white">{comp.title}</h3>
                  <span className="text-xs font-mono px-2.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">
                    ISWC: {comp.iswc}
                  </span>
                </div>
                {comp.alternativeTitles.length > 0 && (
                  <p className="text-xs text-slate-400 mt-1">
                    Alt Titles: {comp.alternativeTitles.join(', ')}
                  </p>
                )}
              </div>

              <span className="px-2.5 py-1 text-[10px] font-mono font-bold rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                PRO STATUS: {comp.registrationStatus} ({comp.registeredPro})
              </span>
            </div>

            {/* Writer Splits Table */}
            <div className="bg-[#161b22] p-4 rounded-lg border border-[#30363d] space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Songwriter Share Allocations (100% Split Rule Verified)</h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {comp.writerShares.map((writer, idx) => (
                  <div key={idx} className="bg-[#1c212c] p-3 rounded border border-[#30363d] flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-white flex items-center space-x-1.5">
                        <User className="w-3.5 h-3.5 text-amber-400" />
                        <span>{writer.songwriterName}</span>
                      </div>
                      <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                        IPI: {writer.ipiNumber} • PRO: {writer.proAffiliation}
                      </div>
                    </div>

                    <div className="text-right font-mono text-xs">
                      <div className="text-amber-300 font-bold">Perf: {writer.performanceSharePercent}%</div>
                      <div className="text-emerald-400 font-bold">Mech: {writer.mechanicalSharePercent}%</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Publisher Shares Table */}
            <div className="bg-[#161b22] p-4 rounded-lg border border-[#30363d] space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Publisher Administration Shares</h4>

              <div className="space-y-2 text-xs">
                {comp.publisherShares.map((pub, idx) => (
                  <div key={idx} className="flex justify-between items-center bg-[#1c212c] p-2.5 rounded border border-[#30363d]">
                    <div className="font-medium text-white flex items-center space-x-2">
                      <Globe className="w-3.5 h-3.5 text-amber-400" />
                      <span>{pub.publisherName} ({pub.ipiNumber})</span>
                    </div>
                    <div className="font-mono text-amber-400 font-bold">{pub.sharePercent}% Share ({pub.territory})</div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}
