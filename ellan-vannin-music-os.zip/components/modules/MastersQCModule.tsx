'use client';

import React, { useState } from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { Master, MasterAudioFormat, MasterVersionType } from '../../lib/domain/types';
import { validateMasterTechnicalQC } from '../../lib/domain/math';
import { Disc, ShieldCheck, AlertCircle, Plus, FileAudio, Check, X } from 'lucide-react';

export function MastersQCModule() {
  const { masters, addMaster, artists } = useMusicOS();
  const [showAddModal, setShowAddModal] = useState(false);

  // New Master Form State
  const [title, setTitle] = useState('');
  const [isrc, setIsrc] = useState('GB-EVR-25-00103');
  const [artistId, setArtistId] = useState(artists[0]?.id || 'ART-001');
  const [versionType, setVersionType] = useState<MasterVersionType>('ORIGINAL');
  const [audioFormat, setAudioFormat] = useState<MasterAudioFormat>('HI_RES_24_96');
  const [durationSeconds, setDurationSeconds] = useState(210);
  const [sampleRateHz, setSampleRateHz] = useState(96000);
  const [bitDepth, setBitDepth] = useState(24);
  const [truePeakDbfs, setTruePeakDbfs] = useState(-0.3);
  const [clippingDetected, setClippingDetected] = useState(false);

  const selectedArtist = artists.find(a => a.id === artistId) || artists[0];

  const handleCreateMaster = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !isrc) return;

    // Run technical QC engine
    const qcResult = validateMasterTechnicalQC({
      sampleRateHz,
      bitDepth,
      durationSeconds,
      truePeakDbfs,
      clippingDetected,
      isrc,
      format: audioFormat
    });

    const newMaster: Master = {
      id: `MST-${Date.now()}`,
      isrc,
      title,
      versionType,
      artistId: selectedArtist.id,
      artistName: selectedArtist.stageName,
      featuredArtists: [],
      producerName: 'Ellan Vannin In-House Studio',
      engineerName: 'Marcus Bell',
      recordingDate: new Date().toISOString().split('T')[0],
      releaseDate: new Date().toISOString().split('T')[0],
      durationSeconds,
      audioFormat,
      technicalQC: qcResult,
      labelId: 'LBL-EVR-001',
      contractId: 'CTR-2024-001',
      compositionId: 'CMP-001',
      ownershipPercentage: 100,
      rightsOwnerIds: ['LBL-EVR-001'],
      deliveredToDistribution: qcResult.qcPassed
    };

    addMaster(newMaster);
    setShowAddModal(false);
    setTitle('');
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Disc className="w-5 h-5 text-amber-400" />
            <span>Canonical Master Database & Technical Audio QC</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Red-Book Standard Verification, ISRC Registry, True Peak Clipping Inspection & Broadcast Delivery Pipelines
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center space-x-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2.5 rounded-lg text-xs transition shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>Ingest & QC New Master</span>
        </button>
      </div>

      {/* Masters Database Table */}
      <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 font-medium">
            <thead className="bg-[#161b22] text-slate-400 uppercase text-[10px] tracking-wider border-b border-[#30363d]">
              <tr>
                <th className="py-3 px-4">Master Title / ISRC</th>
                <th className="py-3 px-4">Artist</th>
                <th className="py-3 px-4">Version</th>
                <th className="py-3 px-4">Format & Specs</th>
                <th className="py-3 px-4">True Peak</th>
                <th className="py-3 px-4">Technical QC Status</th>
                <th className="py-3 px-4">Distribution</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {masters.map((master) => (
                <tr key={master.id} className="hover:bg-[#181e2b] transition">
                  <td className="py-3.5 px-4 font-semibold text-white">
                    <div className="flex items-center space-x-2">
                      <FileAudio className="w-4 h-4 text-amber-400" />
                      <div>
                        <div>{master.title}</div>
                        <div className="text-[10px] font-mono text-amber-300">{master.isrc}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-medium text-slate-200">{master.artistName}</td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-slate-800 text-slate-300 border border-slate-700">
                      {master.versionType}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-300">
                    {master.audioFormat} • {master.technicalQC.sampleRateHz / 1000}kHz / {master.technicalQC.bitDepth}bit
                  </td>
                  <td className="py-3.5 px-4 font-mono">
                    <span className={master.technicalQC.truePeakDbfs > 0 ? 'text-red-400 font-bold' : 'text-slate-300'}>
                      {master.technicalQC.truePeakDbfs} dBFS
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    {master.technicalQC.qcPassed ? (
                      <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 text-[10px] font-mono font-bold rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                        <ShieldCheck className="w-3 h-3" />
                        <span>PASSED QC</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 text-[10px] font-mono font-bold rounded bg-red-500/10 text-red-400 border border-red-500/30">
                        <AlertCircle className="w-3 h-3" />
                        <span>QC REJECTED</span>
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4">
                    {master.deliveredToDistribution ? (
                      <span className="text-[10px] font-mono text-blue-400 font-semibold">DELIVERED</span>
                    ) : (
                      <span className="text-[10px] font-mono text-slate-500">PENDING</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Ingest Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#121721] border border-[#30363d] rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-2xl">
            <div className="flex justify-between items-center border-b border-[#21262d] pb-3">
              <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                <Disc className="w-5 h-5 text-amber-400" />
                <span>Ingest Master & Technical QC Pipeline</span>
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateMaster} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Master Track Title *</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Echoes of Ramsay"
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">ISRC Identifier *</label>
                  <input
                    type="text"
                    required
                    value={isrc}
                    onChange={(e) => setIsrc(e.target.value)}
                    placeholder="GB-EVR-25-00103"
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Artist</label>
                  <select
                    value={artistId}
                    onChange={(e) => setArtistId(e.target.value)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  >
                    {artists.map(a => (
                      <option key={a.id} value={a.id}>{a.stageName}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Version Type</label>
                  <select
                    value={versionType}
                    onChange={(e) => setVersionType(e.target.value as MasterVersionType)}
                    className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="ORIGINAL">ORIGINAL</option>
                    <option value="REMIX">REMIX</option>
                    <option value="INSTRUMENTAL">INSTRUMENTAL</option>
                    <option value="ACOUSTIC">ACOUSTIC</option>
                    <option value="CLEAN">CLEAN</option>
                    <option value="EXPLICIT">EXPLICIT</option>
                  </select>
                </div>
              </div>

              {/* Technical Specifications */}
              <div className="border-t border-b border-[#21262d] py-3 space-y-3">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">Audio Technical QC Inspection Specs</h4>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1">Sample Rate (Hz)</label>
                    <select
                      value={sampleRateHz}
                      onChange={(e) => setSampleRateHz(parseInt(e.target.value))}
                      className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2 text-white font-mono"
                    >
                      <option value={96000}>96,000 Hz (24/96 Hi-Res)</option>
                      <option value={48000}>48,000 Hz (Broadcast)</option>
                      <option value={44100}>44,100 Hz (CD Standard)</option>
                      <option value={22050}>22,050 Hz (QC FAIL TEST)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-300 mb-1">Bit Depth</label>
                    <select
                      value={bitDepth}
                      onChange={(e) => setBitDepth(parseInt(e.target.value))}
                      className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2 text-white font-mono"
                    >
                      <option value={24}>24-bit Studio Master</option>
                      <option value={16}>16-bit Red Book</option>
                      <option value={8}>8-bit (QC FAIL TEST)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 mb-1">True Peak (dBFS)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={truePeakDbfs}
                      onChange={(e) => setTruePeakDbfs(parseFloat(e.target.value))}
                      className="w-full bg-[#161b22] border border-[#30363d] rounded-lg p-2 text-white font-mono"
                    />
                  </div>

                  <div className="flex items-center space-x-2 pt-5">
                    <input
                      type="checkbox"
                      id="clipCheck"
                      checked={clippingDetected}
                      onChange={(e) => setClippingDetected(e.target.checked)}
                      className="accent-amber-500 w-4 h-4"
                    />
                    <label htmlFor="clipCheck" className="text-slate-300 font-medium cursor-pointer">
                      Simulate Clipping Detected
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#161b22] border border-[#30363d] text-slate-300 rounded-lg font-medium hover:bg-[#1c212c]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg shadow"
                >
                  Execute QC & Register Master
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
