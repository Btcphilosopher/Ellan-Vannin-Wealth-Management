'use client';

import React from 'react';
import { useMusicOS } from '../../lib/context/MusicOSContext';
import { Megaphone, DollarSign, Package, Video, TrendingUp } from 'lucide-react';

export function MarketingPhysicalModule() {
  const { formatCurrency } = useMusicOS();

  const marketingCampaigns = [
    {
      id: 'MKT-001',
      title: 'Isla Nova "Echoes of Ramsay" Global Pre-Release',
      channel: 'TikTok Audio / Instagram Reels + Spotify Marquee',
      budgetUSD: 45000,
      spentUSD: 38500,
      streamsGenerated: 8500000,
      calculatedROI: '3.8x',
      status: 'ACTIVE'
    },
    {
      id: 'MKT-002',
      title: 'Mona Lisa Overdrive "Cyberspace" Vinyl Pre-Order',
      channel: 'Bandcamp Direct + NME / Pitchfork Editorial PR',
      budgetUSD: 25000,
      spentUSD: 24000,
      streamsGenerated: 3200000,
      calculatedROI: '2.9x',
      status: 'COMPLETED'
    }
  ];

  const physicalInventory = [
    {
      sku: 'VINYL-EVR-001-LP',
      title: 'Echoes of Ramsay — 180g Heavyweight Amber Marble LP',
      unitsManufactured: 2500,
      unitsSold: 1850,
      unitCostUSD: 7.20,
      retailPriceUSD: 32.00,
      cogsUSD: 13320,
      grossProfitUSD: 45880
    },
    {
      sku: 'CD-EVR-001-DIGI',
      title: 'Echoes of Ramsay — Collector Digipak CD + Booklet',
      unitsManufactured: 1000,
      unitsSold: 620,
      unitCostUSD: 2.10,
      retailPriceUSD: 16.00,
      cogsUSD: 1302,
      grossProfitUSD: 8618
    }
  ];

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 rounded-xl border border-[#21262d]">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <Megaphone className="w-5 h-5 text-amber-400" />
            <span>Marketing Campaign ROI & Physical Inventory / COGS</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Attributed Streaming Conversion ROI, Music Video Deliverables & Physical Manufacturing Economics
          </p>
        </div>
      </div>

      {/* Marketing Campaigns Table */}
      <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
        <h3 className="text-sm font-semibold text-white">Active Marketing Campaigns & Attributed Conversion</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 font-medium">
            <thead className="bg-[#161b22] text-slate-400 uppercase text-[10px] tracking-wider border-b border-[#30363d]">
              <tr>
                <th className="py-3 px-4">Campaign Title</th>
                <th className="py-3 px-4">Channels</th>
                <th className="py-3 px-4">Budget</th>
                <th className="py-3 px-4">Spent</th>
                <th className="py-3 px-4">Streams Generated</th>
                <th className="py-3 px-4">Attributed ROI</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {marketingCampaigns.map((m) => (
                <tr key={m.id} className="hover:bg-[#181e2b] transition font-mono">
                  <td className="py-3.5 px-4 font-bold text-white font-sans">{m.title}</td>
                  <td className="py-3.5 px-4 text-slate-300 font-sans text-[11px]">{m.channel}</td>
                  <td className="py-3.5 px-4">{formatCurrency(m.budgetUSD)}</td>
                  <td className="py-3.5 px-4 text-amber-300">{formatCurrency(m.spentUSD)}</td>
                  <td className="py-3.5 px-4">{(m.streamsGenerated / 1000000).toFixed(1)}M</td>
                  <td className="py-3.5 px-4 font-bold text-emerald-400">{m.calculatedROI}</td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                      {m.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Physical Inventory & COGS */}
      <div className="bg-[#121721] p-5 rounded-xl border border-[#21262d] space-y-4">
        <h3 className="text-sm font-semibold text-white">Physical Product Manufacturing & COGS Accounting</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 font-medium">
            <thead className="bg-[#161b22] text-slate-400 uppercase text-[10px] tracking-wider border-b border-[#30363d]">
              <tr>
                <th className="py-3 px-4">SKU / Product Title</th>
                <th className="py-3 px-4">Units Mfd / Sold</th>
                <th className="py-3 px-4">Unit Cost</th>
                <th className="py-3 px-4">Retail Price</th>
                <th className="py-3 px-4">Total COGS</th>
                <th className="py-3 px-4">Gross Profit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d] font-mono">
              {physicalInventory.map((p) => (
                <tr key={p.sku} className="hover:bg-[#181e2b] transition">
                  <td className="py-3.5 px-4 font-bold text-white font-sans">
                    <div>{p.title}</div>
                    <div className="text-[10px] text-amber-400 font-mono">{p.sku}</div>
                  </td>
                  <td className="py-3.5 px-4">{p.unitsManufactured.toLocaleString()} / {p.unitsSold.toLocaleString()}</td>
                  <td className="py-3.5 px-4">{formatCurrency(p.unitCostUSD)}</td>
                  <td className="py-3.5 px-4">{formatCurrency(p.retailPriceUSD)}</td>
                  <td className="py-3.5 px-4 text-amber-400">{formatCurrency(p.cogsUSD)}</td>
                  <td className="py-3.5 px-4 font-bold text-emerald-400">{formatCurrency(p.grossProfitUSD)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
