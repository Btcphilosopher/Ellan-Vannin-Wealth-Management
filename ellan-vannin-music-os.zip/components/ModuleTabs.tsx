'use client';

import React from 'react';
import { useMusicOS, MainTab } from '../lib/context/MusicOSContext';
import {
  BarChart3,
  Users,
  Compass,
  Disc,
  FileMusic,
  Share2,
  FileCheck,
  Calculator,
  BookOpen,
  Clapperboard,
  TrendingUp,
  Landmark,
  Briefcase,
  GitBranch,
  Megaphone,
  ShieldCheck,
  UserCheck,
  Sparkles
} from 'lucide-react';

interface TabItem {
  id: MainTab;
  label: string;
  category: 'COMMAND' | 'CREATIVE_RECORDING' | 'RIGHTS_FINANCE' | 'INVESTMENT_ANALYTICS' | 'SYSTEM';
  icon: React.ReactNode;
}

export function ModuleTabs() {
  const { activeTab, setActiveTab } = useMusicOS();

  const tabs: TabItem[] = [
    // Executive Command
    { id: 'EXECUTIVE_DASHBOARD', label: 'Executive Centre', category: 'COMMAND', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'ARTISTS_ROSTER', label: 'Artists & Roster', category: 'COMMAND', icon: <Users className="w-4 h-4" /> },
    { id: 'AANDR_ENGINE', label: 'A&R Engine', category: 'COMMAND', icon: <Compass className="w-4 h-4" /> },

    // Creative & Catalog
    { id: 'RECORDING_MASTERS', label: 'Masters & QC', category: 'CREATIVE_RECORDING', icon: <Disc className="w-4 h-4" /> },
    { id: 'COMPOSITIONS_PUBLISHING', label: 'Compositions', category: 'CREATIVE_RECORDING', icon: <FileMusic className="w-4 h-4" /> },
    { id: 'RELEASES_DISTRIBUTION', label: 'Releases & DSP', category: 'CREATIVE_RECORDING', icon: <Share2 className="w-4 h-4" /> },
    { id: 'MARKETING_PHYSICAL', label: 'Marketing & Physical', category: 'CREATIVE_RECORDING', icon: <Megaphone className="w-4 h-4" /> },

    // Rights, Financials & Accounting
    { id: 'RIGHTS_CONTRACTS', label: 'Rights & Vault', category: 'RIGHTS_FINANCE', icon: <FileCheck className="w-4 h-4" /> },
    { id: 'ROYALTIES_RECOUPMENT', label: 'Royalty & Waterfall', category: 'RIGHTS_FINANCE', icon: <Calculator className="w-4 h-4" /> },
    { id: 'FINANCIAL_LEDGER', label: 'Double-Entry Ledger', category: 'RIGHTS_FINANCE', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'SYNC_LICENSING', label: 'Sync & Licensing', category: 'RIGHTS_FINANCE', icon: <Clapperboard className="w-4 h-4" /> },

    // Valuation, Investment & Digital Twin
    { id: 'CATALOGUE_VALUATION', label: 'Catalogue DCF Valuation', category: 'INVESTMENT_ANALYTICS', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'INVESTMENT_FUND', label: 'Music Investment Fund', category: 'INVESTMENT_ANALYTICS', icon: <Briefcase className="w-4 h-4" /> },
    { id: 'DIGITAL_TWIN', label: 'Label Digital Twin', category: 'INVESTMENT_ANALYTICS', icon: <GitBranch className="w-4 h-4" /> },
    { id: 'DSP_ANALYTICS', label: 'DSP Ingestion Analytics', category: 'INVESTMENT_ANALYTICS', icon: <Landmark className="w-4 h-4" /> },

    // Portals, Audit & AI
    { id: 'PORTALS', label: 'Portals (Artist/Label)', category: 'SYSTEM', icon: <UserCheck className="w-4 h-4" /> },
    { id: 'FRAUD_AUDIT', label: 'Audit & Anomaly Engine', category: 'SYSTEM', icon: <ShieldCheck className="w-4 h-4" /> },
    { id: 'AI_COPILOT', label: 'AI Decision Assistant', category: 'SYSTEM', icon: <Sparkles className="w-4 h-4" /> },
  ];

  return (
    <nav className="bg-[#121721] border-b border-[#21262d] px-4 sm:px-6 lg:px-8 overflow-x-auto scrollbar-none">
      <div className="flex space-x-1 py-2 min-w-max">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-xs font-medium transition-all ${
                isActive
                  ? 'bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-sm font-semibold'
                  : 'text-slate-300 hover:bg-[#1c212c] hover:text-slate-100 border border-transparent'
              }`}
            >
              <span className={isActive ? 'text-amber-400' : 'text-slate-400'}>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
