'use client';

import React from 'react';
import { useMusicOS } from '../lib/context/MusicOSContext';
import { Currency, Role } from '../lib/domain/types';
import { 
  Building2, 
  ShieldAlert, 
  DollarSign, 
  UserCheck, 
  Sparkles,
  Search,
  Activity,
  Layers
} from 'lucide-react';

export function Navbar() {
  const { 
    role, 
    setRole, 
    currency, 
    setCurrency, 
    anomalies, 
    auditLogs,
    setActiveTab,
    activeTab
  } = useMusicOS();

  const openAnomaliesCount = anomalies.filter(a => a.status !== 'RESOLVED').length;

  const rolesList: { id: Role; label: string; icon: string }[] = [
    { id: 'EXECUTIVE_CEO', label: 'CEO / Board', icon: '👑' },
    { id: 'FINANCE_CFO', label: 'CFO / Finance', icon: '🏛️' },
    { id: 'AANDR_DIRECTOR', label: 'A&R Director', icon: '🎧' },
    { id: 'ROYALTY_DIRECTOR', label: 'Royalty Director', icon: '⚖️' },
    { id: 'HEAD_OF_CATALOGUE', label: 'Head of Catalogue', icon: '📚' },
    { id: 'INVESTMENT_COMMITTEE', label: 'Investment Fund', icon: '💼' },
    { id: 'ARTIST_PORTAL', label: 'Artist Portal (View)', icon: '🎤' },
    { id: 'LABEL_PORTAL', label: 'Label Admin', icon: '🏢' },
  ];

  const currenciesList: Currency[] = ['GBP', 'USD', 'EUR', 'JPY', 'CHF', 'CAD', 'AUD'];

  return (
    <header className="bg-[#0b0e14] border-b border-[#21262d] text-slate-100 sticky top-0 z-50 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Identity */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('EXECUTIVE_DASHBOARD')}>
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 p-0.5 shadow-lg flex items-center justify-center">
              <div className="w-full h-full bg-[#0b0e14] rounded-[7px] flex items-center justify-center">
                <span className="font-extrabold text-amber-400 tracking-tighter text-lg">EV</span>
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-wider text-white">ELLAN VANNIN</span>
                <span className="text-xs font-mono px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded">MUSIC OS v3.6</span>
              </div>
              <p className="text-[10px] text-slate-400 tracking-wide uppercase font-medium">Institutional Operating System for Music Industry & Funds</p>
            </div>
          </div>

          {/* Controls: Currency, Role Selector, Anomalies, Copilot Shortcut */}
          <div className="flex items-center space-x-3">
            
            {/* Currency Selector */}
            <div className="flex items-center space-x-1.5 bg-[#161b22] border border-[#30363d] rounded-md px-2.5 py-1">
              <DollarSign className="w-3.5 h-3.5 text-amber-400" />
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as Currency)}
                className="bg-transparent text-xs font-mono font-medium text-slate-200 focus:outline-none cursor-pointer"
              >
                {currenciesList.map(c => (
                  <option key={c} value={c} className="bg-[#161b22] text-slate-200">{c}</option>
                ))}
              </select>
            </div>

            {/* Role Access Selector */}
            <div className="flex items-center space-x-1.5 bg-[#161b22] border border-[#30363d] rounded-md px-2.5 py-1">
              <UserCheck className="w-3.5 h-3.5 text-amber-400" />
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as Role)}
                className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer"
              >
                {rolesList.map(r => (
                  <option key={r.id} value={r.id} className="bg-[#161b22] text-slate-200">
                    {r.icon} {r.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Anomaly Alerts Trigger */}
            <button
              onClick={() => setActiveTab('FRAUD_AUDIT')}
              className={`flex items-center space-x-1.5 text-xs font-medium px-2.5 py-1 rounded-md border transition ${
                openAnomaliesCount > 0 
                  ? 'bg-amber-500/10 text-amber-300 border-amber-500/40 hover:bg-amber-500/20' 
                  : 'bg-[#161b22] text-slate-400 border-[#30363d] hover:text-slate-200'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              <span>{openAnomaliesCount} Alerts</span>
            </button>

            {/* Gemini AI Copilot Shortcut */}
            <button
              onClick={() => setActiveTab('AI_COPILOT')}
              className={`flex items-center space-x-1.5 text-xs font-medium px-3 py-1 rounded-md border transition ${
                activeTab === 'AI_COPILOT'
                  ? 'bg-amber-500 text-slate-950 font-semibold border-amber-400 shadow-md'
                  : 'bg-gradient-to-r from-amber-500/20 to-amber-600/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>AI Decision Copilot</span>
            </button>

          </div>

        </div>
      </div>
    </header>
  );
}
