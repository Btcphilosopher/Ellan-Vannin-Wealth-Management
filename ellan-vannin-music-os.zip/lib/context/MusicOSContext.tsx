'use client';

import React, { createContext, useContext, useState, useCallback } from 'react';
import {
  Currency,
  Role,
  Artist,
  Master,
  Composition,
  Release,
  Contract,
  RightRecord,
  Advance,
  RecoupmentLedgerEntry,
  JournalTransaction,
  RoyaltyCalculationRun,
  SyncOpportunity,
  CatalogueValuationReport,
  InvestmentDeal,
  DigitalTwinState,
  WhatIfScenarioInput,
  WhatIfScenarioOutput,
  ARCandidate,
  ARScoringWeights,
  AuditLogEntry,
  AnomalyAlert
} from '../domain/types';

import {
  SEED_LABEL,
  SEED_PUBLISHER,
  SEED_ARTISTS,
  SEED_MASTERS,
  SEED_COMPOSITIONS,
  SEED_RELEASES,
  SEED_CONTRACTS,
  SEED_RIGHTS,
  SEED_ADVANCES,
  SEED_JOURNAL_TRANSACTIONS,
  SEED_ROYALTY_RUNS,
  SEED_SYNC_OPPORTUNITIES,
  SEED_CATALOGUE_VALUATION,
  SEED_INVESTMENT_DEALS,
  SEED_DIGITAL_TWIN_STATE,
  SEED_AR_CANDIDATES,
  DEFAULT_AR_WEIGHTS,
  SEED_AUDIT_LOGS,
  SEED_ANOMALIES
} from '../domain/seedData';

import {
  calculateRoyaltyWaterfall,
  validateJournalTransaction,
  validateMasterTechnicalQC,
  calculateARScore,
  simulateDigitalTwinWhatIf,
  calculateCatalogueDCFValuation
} from '../domain/math';

export type MainTab = 
  | 'EXECUTIVE_DASHBOARD'
  | 'ARTISTS_ROSTER'
  | 'AANDR_ENGINE'
  | 'RECORDING_MASTERS'
  | 'COMPOSITIONS_PUBLISHING'
  | 'RELEASES_DISTRIBUTION'
  | 'RIGHTS_CONTRACTS'
  | 'ROYALTIES_RECOUPMENT'
  | 'FINANCIAL_LEDGER'
  | 'SYNC_LICENSING'
  | 'DSP_ANALYTICS'
  | 'CATALOGUE_VALUATION'
  | 'INVESTMENT_FUND'
  | 'DIGITAL_TWIN'
  | 'MARKETING_PHYSICAL'
  | 'FRAUD_AUDIT'
  | 'PORTALS'
  | 'AI_COPILOT';

interface MusicOSContextType {
  role: Role;
  setRole: (role: Role) => void;
  currency: Currency;
  setCurrency: (curr: Currency) => void;
  activeTab: MainTab;
  setActiveTab: (tab: MainTab) => void;
  
  // Data States
  artists: Artist[];
  masters: Master[];
  compositions: Composition[];
  releases: Release[];
  contracts: Contract[];
  rights: RightRecord[];
  advances: Advance[];
  journalTransactions: JournalTransaction[];
  royaltyRuns: RoyaltyCalculationRun[];
  syncOpportunities: SyncOpportunity[];
  valuationReport: CatalogueValuationReport;
  investmentDeals: InvestmentDeal[];
  digitalTwinState: DigitalTwinState;
  arCandidates: ARCandidate[];
  arWeights: ARScoringWeights;
  auditLogs: AuditLogEntry[];
  anomalies: AnomalyAlert[];

  // Actions & Mutations
  addArtist: (artist: Artist) => void;
  addMaster: (master: Master) => void;
  addJournalTransaction: (tx: JournalTransaction) => { success: boolean; message: string };
  runNewRoyaltyCalculation: (artistId: string, grossUSD: number, period: string) => RoyaltyCalculationRun;
  addSyncOpportunity: (sync: SyncOpportunity) => void;
  updateInvestmentDealStatus: (dealId: string, status: InvestmentDeal['icStatus']) => void;
  updateARWeights: (weights: ARScoringWeights) => void;
  addARCandidate: (candidate: ARCandidate) => void;
  runDigitalTwinSim: (input: WhatIfScenarioInput) => WhatIfScenarioOutput;
  resolveAnomaly: (anomalyId: string) => void;
  currencySymbol: string;
  formatCurrency: (amountUSD: number) => string;
}

const MusicOSContext = createContext<MusicOSContextType | undefined>(undefined);

export function MusicOSProvider({ children }: { children: React.ReactNode }) {
  const [role, setRole] = useState<Role>('EXECUTIVE_CEO');
  const [currency, setCurrency] = useState<Currency>('GBP');
  const [activeTab, setActiveTab] = useState<MainTab>('EXECUTIVE_DASHBOARD');

  const [artists, setArtists] = useState<Artist[]>(SEED_ARTISTS);
  const [masters, setMasters] = useState<Master[]>(SEED_MASTERS);
  const [compositions, setCompositions] = useState<Composition[]>(SEED_COMPOSITIONS);
  const [releases, setReleases] = useState<Release[]>(SEED_RELEASES);
  const [contracts, setContracts] = useState<Contract[]>(SEED_CONTRACTS);
  const [rights, setRights] = useState<RightRecord[]>(SEED_RIGHTS);
  const [advances, setAdvances] = useState<Advance[]>(SEED_ADVANCES);
  const [journalTransactions, setJournalTransactions] = useState<JournalTransaction[]>(SEED_JOURNAL_TRANSACTIONS);
  const [royaltyRuns, setRoyaltyRuns] = useState<RoyaltyCalculationRun[]>(SEED_ROYALTY_RUNS);
  const [syncOpportunities, setSyncOpportunities] = useState<SyncOpportunity[]>(SEED_SYNC_OPPORTUNITIES);
  const [valuationReport, setValuationReport] = useState<CatalogueValuationReport>(SEED_CATALOGUE_VALUATION);
  const [investmentDeals, setInvestmentDeals] = useState<InvestmentDeal[]>(SEED_INVESTMENT_DEALS);
  const [digitalTwinState, setDigitalTwinState] = useState<DigitalTwinState>(SEED_DIGITAL_TWIN_STATE);
  const [arCandidates, setArCandidates] = useState<ARCandidate[]>(SEED_AR_CANDIDATES);
  const [arWeights, setArWeights] = useState<ARScoringWeights>(DEFAULT_AR_WEIGHTS);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(SEED_AUDIT_LOGS);
  const [anomalies, setAnomalies] = useState<AnomalyAlert[]>(SEED_ANOMALIES);

  // Currency Formatter
  const currencySymbols: Record<Currency, string> = {
    GBP: '£',
    USD: '$',
    EUR: '€',
    JPY: '¥',
    CHF: 'CHF ',
    CAD: 'CA$',
    AUD: 'A$'
  };

  const currencyRatesUSD: Record<Currency, number> = {
    USD: 1.0,
    GBP: 0.78,
    EUR: 0.92,
    JPY: 148.5,
    CHF: 0.88,
    CAD: 1.36,
    AUD: 1.52
  };

  const formatCurrency = (amountUSD: number): string => {
    const rate = currencyRatesUSD[currency];
    const converted = amountUSD * rate;
    const sym = currencySymbols[currency];

    if (currency === 'JPY') {
      return `${sym}${Math.round(converted).toLocaleString()}`;
    }
    return `${sym}${converted.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const logAudit = useCallback((action: string, entityType: string, entityId: string, reason: string) => {
    const timestamp = Date.now();
    const isoString = new Date(timestamp).toISOString();
    const hash = `0x${timestamp.toString(16)}${Math.random().toString(16).slice(2, 10)}`;
    const newLog: AuditLogEntry = {
      id: `AUD-${timestamp}`,
      timestamp: isoString,
      actorRole: role,
      actorEmail: `${role.toLowerCase()}@ellanvannin.com`,
      action,
      entityType,
      entityId,
      reason,
      ipAddress: '10.0.42.1',
      hash
    };
    setAuditLogs(prev => [newLog, ...prev]);
  }, [role]);

  const addArtist = (artist: Artist) => {
    setArtists(prev => [artist, ...prev]);
    logAudit('CREATE_ARTIST', 'Artist', artist.id, `Signed/added artist ${artist.stageName}`);
  };

  const addMaster = (master: Master) => {
    setMasters(prev => [master, ...prev]);
    logAudit('CREATE_MASTER', 'Master', master.id, `Created master recording ${master.title} (${master.isrc})`);
  };

  const addJournalTransaction = (tx: JournalTransaction) => {
    const validation = validateJournalTransaction(tx);
    if (!validation.isBalanced) {
      return {
        success: false,
        message: `Transaction rejected! Unbalanced debits (${validation.totalDebit}) vs credits (${validation.totalCredit}). Difference: ${validation.difference} USD.`
      };
    }

    setJournalTransactions(prev => [tx, ...prev]);
    logAudit('POST_JOURNAL_TRANSACTION', 'JournalTransaction', tx.id, `Posted balanced ledger transaction ${tx.reference}`);
    return { success: true, message: 'Ledger transaction successfully posted and verified.' };
  };

  const runNewRoyaltyCalculation = useCallback((artistId: string, grossUSD: number, period: string) => {
    const artist = artists.find(a => a.id === artistId) || artists[0];
    const contract = contracts.find(c => c.primaryArtistId === artistId) || contracts[0];
    const advance = advances.find(a => a.artistId === artistId) || { remainingBalanceUSD: 0 };

    const calc = calculateRoyaltyWaterfall({
      grossRevenueUSD: grossUSD,
      platformFeePercent: 30,
      distributionFeePercent: 5,
      taxRatePercent: 0,
      artistRoyaltyRatePercent: contract.royaltyRateMasterPercent || 20,
      unrecoupedAdvanceBalanceUSD: advance.remainingBalanceUSD || 0
    });

    const timestamp = Date.now();
    const isoString = new Date(timestamp).toISOString();

    const newRun: RoyaltyCalculationRun = {
      id: `ROY-${timestamp}`,
      periodLabel: period,
      artistId: artist.id,
      artistName: artist.stageName,
      contractId: contract.id,
      grossRevenueUSD: grossUSD,
      platformFeesUSD: calc.platformFeesUSD,
      distributionFeesUSD: calc.distributionFeesUSD,
      netReceiptsUSD: calc.netReceiptsUSD,
      contractRoyaltyRatePercent: contract.royaltyRateMasterPercent,
      grossEarnedRoyaltyUSD: calc.grossEarnedRoyaltyUSD,
      recoupmentDeductedUSD: calc.recoupmentAppliedUSD,
      payableRoyaltyUSD: calc.payableRoyaltyUSD,
      unrecoupedBalanceUSD: calc.remainingUnrecoupedBalanceUSD,
      statementStatus: 'CALCULATED',
      calculatedAt: isoString
    };

    setRoyaltyRuns(prev => [newRun, ...prev]);
    
    // Update advance remaining balance if recoupment was applied
    if (calc.recoupmentAppliedUSD > 0 && advance) {
      setAdvances(prev => prev.map(a => a.artistId === artistId ? { ...a, remainingBalanceUSD: calc.remainingUnrecoupedBalanceUSD } : a));
    }

    logAudit('CALCULATE_ROYALTY', 'RoyaltyRun', newRun.id, `Executed deterministic royalty waterfall for ${artist.stageName} (${period})`);
    return newRun;
  }, [artists, contracts, advances, logAudit]);

  const addSyncOpportunity = (sync: SyncOpportunity) => {
    setSyncOpportunities(prev => [sync, ...prev]);
    logAudit('CREATE_SYNC_BRIEF', 'SyncOpportunity', sync.id, `Created sync brief for ${sync.title}`);
  };

  const updateInvestmentDealStatus = (dealId: string, status: InvestmentDeal['icStatus']) => {
    setInvestmentDeals(prev => prev.map(d => d.id === dealId ? { ...d, icStatus: status } : d));
    logAudit('UPDATE_DEAL_STATUS', 'InvestmentDeal', dealId, `Investment Committee updated deal status to ${status}`);
  };

  const updateARWeights = (weights: ARScoringWeights) => {
    setArWeights(weights);
    // Recalculate candidate scores
    setArCandidates(prev => prev.map(c => ({ ...c, calculatedScore: calculateARScore(c, weights) })));
    logAudit('UPDATE_AANDR_WEIGHTS', 'ARWeights', 'AR-GLOBAL', 'Updated A&R Scoring Decision Weights');
  };

  const addARCandidate = (candidate: ARCandidate) => {
    const score = calculateARScore(candidate, arWeights);
    const withScore = { ...candidate, calculatedScore: score };
    setArCandidates(prev => [withScore, ...prev]);
    logAudit('ADD_AANDR_CANDIDATE', 'ARCandidate', candidate.id, `Scouted candidate ${candidate.artistName} with score ${score}`);
  };

  const runDigitalTwinSim = (input: WhatIfScenarioInput) => {
    return simulateDigitalTwinWhatIf(digitalTwinState, input);
  };

  const resolveAnomaly = (anomalyId: string) => {
    setAnomalies(prev => prev.map(a => a.id === anomalyId ? { ...a, status: 'RESOLVED' } : a));
    logAudit('RESOLVE_ANOMALY', 'AnomalyAlert', anomalyId, 'Resolved system alert');
  };

  return (
    <MusicOSContext.Provider value={{
      role,
      setRole,
      currency,
      setCurrency,
      activeTab,
      setActiveTab,
      artists,
      masters,
      compositions,
      releases,
      contracts,
      rights,
      advances,
      journalTransactions,
      royaltyRuns,
      syncOpportunities,
      valuationReport,
      investmentDeals,
      digitalTwinState,
      arCandidates,
      arWeights,
      auditLogs,
      anomalies,
      addArtist,
      addMaster,
      addJournalTransaction,
      runNewRoyaltyCalculation,
      addSyncOpportunity,
      updateInvestmentDealStatus,
      updateARWeights,
      addARCandidate,
      runDigitalTwinSim,
      resolveAnomaly,
      currencySymbol: currencySymbols[currency],
      formatCurrency
    }}>
      {children}
    </MusicOSContext.Provider>
  );
}

export function useMusicOS() {
  const context = useContext(MusicOSContext);
  if (!context) {
    throw new Error('useMusicOS must be used within a MusicOSProvider');
  }
  return context;
}
