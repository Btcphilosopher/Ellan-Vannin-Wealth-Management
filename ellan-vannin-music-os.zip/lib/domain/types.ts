// ELLAN VANNIN MUSIC OS - CANONICAL DOMAIN TYPES
// Institutional Operating System for Record Labels, Publishers, Artists & Music Investment Firms

export type Currency = 'GBP' | 'USD' | 'EUR' | 'JPY' | 'CHF' | 'CAD' | 'AUD';

export type CareerStage = 
  | 'DISCOVERY'
  | 'DEVELOPMENT'
  | 'SIGNED'
  | 'RECORDING'
  | 'PRE_RELEASE'
  | 'RELEASED'
  | 'BREAKOUT'
  | 'ESTABLISHED'
  | 'LEGACY'
  | 'CATALOGUE';

export type Role = 
  | 'EXECUTIVE_CEO'
  | 'FINANCE_CFO'
  | 'AANDR_DIRECTOR'
  | 'ROYALTY_DIRECTOR'
  | 'HEAD_OF_CATALOGUE'
  | 'HEAD_OF_PUBLISHING'
  | 'ARTIST_MANAGER'
  | 'INVESTMENT_COMMITTEE'
  | 'ARTIST_PORTAL'
  | 'LABEL_PORTAL'
  | 'AUDITOR';

// ----------------------------------------------------
// 1. IDENTITY ENTITIES
// ----------------------------------------------------

export interface Artist {
  id: string;
  stageName: string;
  legalName: string;
  genre: string[];
  primaryTerritory: string;
  careerStage: CareerStage;
  biography: string;
  labelId: string;
  publisherId?: string;
  distributorId?: string;
  socialAccounts: {
    spotifyId?: string;
    appleMusicId?: string;
    instagram?: string;
    youtubeChannelId?: string;
    tiktokHandle?: string;
  };
  metrics: {
    monthlyListeners: number;
    totalStreams: number;
    socialFollowers: number;
    engagementRatePercent: number;
    catalogueLTMRevenueUSD: number;
  };
  aandrStatus: 'SCOUTING' | 'UNDER_REVIEW' | 'CONTRACT_OFFERED' | 'ACTIVE_ROSTER' | 'CATALOGUE_ONLY';
  createdAt: string;
}

export interface Label {
  id: string;
  name: string;
  code: string;
  parentCompany: string;
  currency: Currency;
  territory: string;
  catalogSizeMasters: number;
  catalogSizeCompositions: number;
}

export interface Publisher {
  id: string;
  name: string;
  ipiNumber: string;
  proAffiliation: 'PRS' | 'ASCAP' | 'BMI' | 'GEMA' | 'SACEM' | 'JASRAC';
  territory: string;
}

export interface Songwriter {
  id: string;
  legalName: string;
  stageName?: string;
  ipiNumber: string;
  proAffiliation: string;
  publisherId?: string;
}

// ----------------------------------------------------
// 2. MASTER & RECORDING ENTITIES
// ----------------------------------------------------

export type MasterAudioFormat = 'WAV' | 'FLAC' | 'AIFF' | 'MP3_320' | 'AAC_256' | 'HI_RES_24_96';
export type MasterVersionType = 'ORIGINAL' | 'REMIX' | 'INSTRUMENTAL' | 'ACOUSTIC' | 'CLEAN' | 'EXPLICIT' | 'LIVE' | 'RADIO_EDIT';

export interface MasterTechnicalQC {
  sampleRateHz: number; // e.g. 44100, 48000, 96000
  bitDepth: number; // 16, 24, 32
  channels: 'STEREO' | 'MONO' | 'DOLBY_ATMOS';
  durationSeconds: number;
  truePeakDbfs: number; // e.g. -0.3
  clippingDetected: boolean;
  silenceAtStartMs: number;
  silenceAtEndMs: number;
  isrcValid: boolean;
  qcPassed: boolean;
  qcCheckedAt: string;
  qcNotes: string[];
}

export interface Master {
  id: string;
  isrc: string;
  title: string;
  versionType: MasterVersionType;
  artistId: string;
  artistName: string;
  featuredArtists: string[];
  producerName: string;
  engineerName: string;
  recordingDate: string;
  releaseDate: string;
  durationSeconds: number;
  audioFormat: MasterAudioFormat;
  technicalQC: MasterTechnicalQC;
  labelId: string;
  contractId: string;
  compositionId: string;
  ownershipPercentage: number; // Label share, e.g. 100 or 50
  rightsOwnerIds: string[];
  deliveredToDistribution: boolean;
  audioFileUrl?: string;
  artworkUrl?: string;
}

// ----------------------------------------------------
// 3. COMPOSITION & PUBLISHING
// ----------------------------------------------------

export interface WriterShare {
  songwriterId: string;
  songwriterName: string;
  ipiNumber: string;
  performanceSharePercent: number; // e.g., 50%
  mechanicalSharePercent: number; // e.g., 50%
  proAffiliation: string;
}

export interface PublisherShare {
  publisherId: string;
  publisherName: string;
  ipiNumber: string;
  sharePercent: number;
  territory: string;
}

export interface Composition {
  id: string;
  iswc: string;
  title: string;
  alternativeTitles: string[];
  lyrics?: string;
  writerShares: WriterShare[];
  publisherShares: PublisherShare[];
  registeredPro: string;
  registrationStatus: 'PENDING' | 'REGISTERED' | 'DISPUTED' | 'REJECTED';
  registrationDate?: string;
  createdAt: string;
}

// ----------------------------------------------------
// 4. RELEASES & DISTRIBUTION
// ----------------------------------------------------

export type ReleaseType = 'SINGLE' | 'EP' | 'ALBUM' | 'DELUXE' | 'COMPILATION' | 'REISSUE';
export type ReleaseStatus = 'PLANNING' | 'AANDR_APPROVED' | 'MASTER_APPROVED' | 'METADATA_LOCKED' | 'DELIVERED' | 'LIVE' | 'TAKEDOWN';

export interface Release {
  id: string;
  upc: string;
  title: string;
  releaseType: ReleaseType;
  artistId: string;
  artistName: string;
  labelId: string;
  releaseDate: string;
  status: ReleaseStatus;
  coverArtworkUrl: string;
  masterIds: string[];
  territories: string[]; // e.g. ["WW"] or ["US", "GB", "DE"]
  genre: string;
  preSaveCount: number;
  dspsDelivered: string[]; // e.g. ["SPOTIFY", "APPLE", "AMAZON", "DEEZER", "TIDAL"]
}

// ----------------------------------------------------
// 5. CONTRACTS & RIGHTS
// ----------------------------------------------------

export type ContractType = 
  | 'ARTIST_RECORDING'
  | 'PUBLISHING_ADMIN'
  | 'DISTRIBUTION'
  | 'SYNC_LICENSE'
  | 'PRODUCER_AGREEMENT'
  | 'CATALOGUE_ACQUISITION';

export interface Contract {
  id: string;
  contractNumber: string;
  title: string;
  contractType: ContractType;
  primaryArtistId: string;
  labelId: string;
  effectiveDate: string;
  termYears: number;
  territory: string;
  royaltyRateMasterPercent: number; // e.g. 20%
  royaltyRateSyncPercent: number; // e.g. 50%
  advanceAmountUSD: number; // e.g. 250000
  recoupableExpensesCategory: string[]; // e.g. ["RECORDING", "VIDEO", "INDEPENDENT_PROMO_50"]
  crossCollateralised: boolean;
  status: 'DRAFT' | 'EXECUTED' | 'EXPIRED' | 'TERMINATED';
  documentUrl?: string;
  executedAt: string;
}

export type RightCategory = 
  | 'MASTER'
  | 'COMPOSITION'
  | 'PUBLISHING'
  | 'MECHANICAL'
  | 'PERFORMANCE'
  | 'NEIGHBOURING'
  | 'SYNC'
  | 'DIGITAL'
  | 'PHYSICAL';

export interface RightRecord {
  id: string;
  assetId: string; // Master ID or Composition ID
  category: RightCategory;
  ownerName: string;
  percentage: number;
  territory: string;
  startDate: string;
  endDate?: string;
  contractId: string;
  sourceDocumentRef: string;
  confidenceScore: number; // 0 to 1
  status: 'ACTIVE' | 'EXPIRED' | 'DISPUTED';
}

// ----------------------------------------------------
// 6. ADVANCES & RECOUPMENT
// ----------------------------------------------------

export type AdvanceCategory = 'RECORDING' | 'MARKETING' | 'TOUR_SUPPORT' | 'VIDEO' | 'PRODUCER';

export interface Advance {
  id: string;
  contractId: string;
  artistId: string;
  category: AdvanceCategory;
  originalAmountUSD: number;
  currentRecoupedAmountUSD: number;
  remainingBalanceUSD: number;
  issuedDate: string;
  isRecoupable: boolean;
  priorityOrder: number;
}

export interface RecoupmentLedgerEntry {
  id: string;
  artistId: string;
  contractId: string;
  entryDate: string;
  description: string;
  amountUSD: number;
  type: 'ADVANCE_ISSUED' | 'EXPENSE_LOGGED' | 'ROYALTY_CREDITED' | 'RECOUPMENT_APPLIED';
  balanceAfterUSD: number;
}

// ----------------------------------------------------
// 7. FINANCIAL DOUBLE-ENTRY ACCOUNTING
// ----------------------------------------------------

export type AccountCode = 
  | '1010_CASH'
  | '1100_RECEIVABLES_DSP'
  | '1200_CATALOGUE_ASSETS'
  | '1300_PUBLISHING_ASSETS'
  | '1400_INVENTORY_PHYSICAL'
  | '2010_ROYALTY_LIABILITIES_ARTIST'
  | '2020_PAYABLES_SUPPLIERS'
  | '2030_UNEARNED_ADVANCES'
  | '3010_RETAINED_EARNINGS'
  | '4010_REVENUE_STREAMING'
  | '4020_REVENUE_PHYSICAL'
  | '4030_REVENUE_SYNC'
  | '4040_REVENUE_PUBLISHING'
  | '5010_EXPENSE_ROYALTIES'
  | '5020_EXPENSE_MARKETING'
  | '5030_EXPENSE_RECORDING'
  | '5040_EXPENSE_DISTRIBUTION';

export interface JournalLine {
  accountCode: AccountCode;
  accountName: string;
  debitUSD: number;
  creditUSD: number;
}

export interface JournalTransaction {
  id: string;
  transactionDate: string;
  reference: string;
  description: string;
  lines: JournalLine[];
  isBalanced: boolean; // Sum(debits) === Sum(credits)
  createdRole: string;
  createdAt: string;
}

// ----------------------------------------------------
// 8. ROYALTIES & STATEMENTS
// ----------------------------------------------------

export interface RoyaltyCalculationRun {
  id: string;
  periodLabel: string; // e.g. "2026-H1" or "2026-Q2"
  artistId: string;
  artistName: string;
  contractId: string;
  grossRevenueUSD: number;
  platformFeesUSD: number; // e.g. 30% DSP cut
  distributionFeesUSD: number; // e.g. 5% distributor cut
  netReceiptsUSD: number;
  contractRoyaltyRatePercent: number; // e.g. 20%
  grossEarnedRoyaltyUSD: number;
  recoupmentDeductedUSD: number;
  payableRoyaltyUSD: number;
  unrecoupedBalanceUSD: number;
  statementStatus: 'CALCULATED' | 'APPROVED' | 'PAID';
  calculatedAt: string;
}

// ----------------------------------------------------
// 9. PUBLISHING & SYNC LICENSING
// ----------------------------------------------------

export interface SyncOpportunity {
  id: string;
  title: string;
  clientName: string; // e.g. "HBO / Warner Discovery"
  mediaType: 'FILM' | 'TELEVISION' | 'ADVERTISING' | 'GAME' | 'TRAILER';
  briefDescription: string;
  budgetFeeUSD: number;
  targetTerritories: string[];
  masterCleared: boolean;
  publishingCleared: boolean;
  status: 'BRIEF_RECEIVED' | 'PITCHED' | 'SHORTLISTED' | 'LICENSED' | 'REJECTED';
  pitchTrackId?: string;
  pitchTrackTitle?: string;
  cueSheetSubmitted: boolean;
}

// ----------------------------------------------------
// 10. DSP REPORTS & METRICS
// ----------------------------------------------------

export interface DSPDailyMetric {
  date: string;
  dspName: 'SPOTIFY' | 'APPLE_MUSIC' | 'AMAZON' | 'YOUTUBE' | 'DEEZER' | 'TIDAL';
  trackId: string;
  trackTitle: string;
  artistName: string;
  streams: number;
  listeners: number;
  saves: number;
  playlistPlacementsCount: number;
  grossRevenueUSD: number;
  territory: string;
}

// ----------------------------------------------------
// 11. CATALOGUE VALUATION & INVESTMENT
// ----------------------------------------------------

export interface ValuationParameters {
  discountRatePercent: number; // e.g. 8.5%
  terminalGrowthRatePercent: number; // e.g. 2.0%
  annualDecayRatePercent: number; // e.g. 4.0%
  projectionYears: number; // e.g. 10
  ltmRevenueUSD: number; // Last Twelve Months Revenue
}

export interface ValuationScenarioResult {
  scenarioName: 'BASE' | 'BULL' | 'BEAR' | 'STRESS';
  discountRatePercent: number;
  projectedCashFlowsUSD: number[];
  terminalValueUSD: number;
  netPresentValueUSD: number; // NPV
  impliedMultiple: number; // Valuation / LTM Revenue
}

export interface CatalogueValuationReport {
  catalogueId: string;
  catalogueName: string;
  valuationDate: string;
  ltmRevenueUSD: number;
  baseValuationUSD: number;
  bullValuationUSD: number;
  bearValuationUSD: number;
  scenarios: ValuationScenarioResult[];
  methodologiesUsed: string[];
  analystNotes: string;
}

export interface InvestmentDeal {
  id: string;
  targetAssetTitle: string; // e.g., "The Midnight Echoes Catalogue Acquisition"
  dealType: 'CATALOGUE_ACQUISITION' | 'MASTER_BUYOUT' | 'PUBLISHING_JV' | 'ARTIST_FINANCING';
  purchasePriceUSD: number;
  expectedLTMRevenueUSD: number;
  projectedIrrPercent: number; // Internal Rate of Return e.g. 14.8%
  npvUSD: number;
  paybackPeriodYears: number;
  icStatus: 'PROPOSED' | 'RESEARCH' | 'DUE_DILIGENCE' | 'IC_REVIEW' | 'APPROVED' | 'REJECTED' | 'ACQUIRED';
  leadPartner: string;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH';
  targetClosingDate: string;
}

// ----------------------------------------------------
// 12. DIGITAL TWIN & SCENARIOS
// ----------------------------------------------------

export interface DigitalTwinState {
  totalActiveArtists: number;
  totalMastersCount: number;
  annualStreamsTotal: number;
  annualGrossRevenueUSD: number;
  annualNetProfitUSD: number;
  artistRecoupmentRatePercent: number;
  totalCatalogueValuationUSD: number;
  cashReserveUSD: number;
}

export interface WhatIfScenarioInput {
  streamVolumeMultiplier: number; // e.g. 1.25 (+25%)
  dspPayOutRateChangePercent: number; // e.g. -5%
  newArtistSigningsCount: number;
  marketingBudgetMultiplier: number; // e.g. 1.30 (+30%)
  catalogueAcquisitionInvestmentUSD: number;
}

export interface WhatIfScenarioOutput {
  projectedGrossRevenueUSD: number;
  projectedNetProfitUSD: number;
  projectedRecoupedArtistsCount: number;
  projectedCatalogueValuationUSD: number;
  projectedCashReserveUSD: number;
  revenueDeltaPercent: number;
  valuationDeltaPercent: number;
}

// ----------------------------------------------------
// 13. A&R SCORING MODEL
// ----------------------------------------------------

export interface ARScoringWeights {
  artisticQuality: number; // Default 0.20
  audienceGrowth: number; // Default 0.15
  engagement: number; // Default 0.15
  commercialPotential: number; // Default 0.15
  cataloguePotential: number; // Default 0.10
  internationalPotential: number; // Default 0.10
  livePotential: number; // Default 0.10
  syncPotential: number; // Default 0.05
}

export interface ARCandidate {
  id: string;
  artistName: string;
  genre: string;
  location: string;
  scoutName: string;
  submittedDemoTrackTitle: string;
  ratings: {
    artisticQuality: number; // 1 - 10
    audienceGrowth: number;
    engagement: number;
    commercialPotential: number;
    cataloguePotential: number;
    internationalPotential: number;
    livePotential: number;
    syncPotential: number;
  };
  calculatedScore: number; // 0 - 10
  recommendation: 'HIGHLY_RECOMMENDED' | 'DEVELOPMENT_DEAL' | 'PASS' | 'MONITOR';
  notes: string;
}

// ----------------------------------------------------
// 14. AUDIT & ANOMALY
// ----------------------------------------------------

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actorRole: string;
  actorEmail: string;
  action: string;
  entityType: string;
  entityId: string;
  beforeState?: string;
  afterState?: string;
  reason: string;
  ipAddress: string;
  hash?: string;
}

export interface AnomalyAlert {
  id: string;
  timestamp: string;
  severity: 'HIGH' | 'MEDIUM' | 'LOW';
  category: 'DUPLICATE_ISRC' | 'ROYALTY_SPIKE' | 'UNBALANCED_LEDGER' | 'RIGHTS_CONFLICT' | 'DSP_REPORT_DISCREPANCY';
  title: string;
  explanation: string;
  affectedEntityId: string;
  status: 'OPEN' | 'INVESTIGATING' | 'RESOLVED' | 'DISMISSED';
}
