// ELLAN VANNIN MUSIC OS - SYNTHETIC INSTITUTIONAL DEMONSTRATION DATASET
// All data is fictional for ELLAN VANNIN RECORDS.

import {
  Artist,
  Label,
  Publisher,
  Master,
  Composition,
  Release,
  Contract,
  RightRecord,
  Advance,
  RecoupmentLedgerEntry,
  JournalTransaction,
  RoyaltyCalculationRun,
  SyncOpportunity,
  DSPDailyMetric,
  CatalogueValuationReport,
  InvestmentDeal,
  DigitalTwinState,
  ARCandidate,
  ARScoringWeights,
  AuditLogEntry,
  AnomalyAlert
} from './types';

export const SEED_LABEL: Label = {
  id: 'LBL-EVR-001',
  name: 'ELLAN VANNIN RECORDS',
  code: 'EVR',
  parentCompany: 'EV Music Group Group PLC',
  currency: 'GBP',
  territory: 'WW',
  catalogSizeMasters: 120,
  catalogSizeCompositions: 185
};

export const SEED_PUBLISHER: Publisher = {
  id: 'PUB-EVP-001',
  name: 'Ellan Vannin Publishing Ltd',
  ipiNumber: 'IPI-009841235-9',
  proAffiliation: 'PRS',
  territory: 'WW'
};

export const SEED_ARTISTS: Artist[] = [
  {
    id: 'ART-001',
    stageName: 'Elora Vance',
    legalName: 'Elora Catherine Vance',
    genre: ['Electronic', 'Synth Pop', 'Indie Pop'],
    primaryTerritory: 'GB',
    careerStage: 'BREAKOUT',
    biography: 'Elora Vance is an acclaimed Manx electronic pop producer and songstress whose platinum-certified album "Isle of Glass" captured over 140M global streams.',
    labelId: 'LBL-EVR-001',
    publisherId: 'PUB-EVP-001',
    distributorId: 'DIST-ORCHARD-01',
    socialAccounts: {
      spotifyId: '4XmKz9eW392x',
      appleMusicId: 'ra.10928374',
      instagram: '@eloravance',
      youtubeChannelId: 'UC_EloraVanceMusic'
    },
    metrics: {
      monthlyListeners: 3450000,
      totalStreams: 142800000,
      socialFollowers: 890000,
      engagementRatePercent: 4.8,
      catalogueLTMRevenueUSD: 840000
    },
    aandrStatus: 'ACTIVE_ROSTER',
    createdAt: '2024-02-15T10:00:00Z'
  },
  {
    id: 'ART-002',
    stageName: 'Mona & The Isle',
    legalName: 'Mona & The Isle Band Ltd',
    genre: ['Indie Rock', 'Alternative'],
    primaryTerritory: 'US',
    careerStage: 'ESTABLISHED',
    biography: '4-piece alternative rock juggernaut with 3 top-10 UK charts and sold-out European headline tours.',
    labelId: 'LBL-EVR-001',
    publisherId: 'PUB-EVP-001',
    distributorId: 'DIST-ORCHARD-01',
    socialAccounts: {
      spotifyId: '7LpM9qW12x',
      instagram: '@monaandtheisle',
      youtubeChannelId: 'UC_MonaAndTheIsle'
    },
    metrics: {
      monthlyListeners: 1850000,
      totalStreams: 88500000,
      socialFollowers: 410000,
      engagementRatePercent: 3.2,
      catalogueLTMRevenueUSD: 520000
    },
    aandrStatus: 'ACTIVE_ROSTER',
    createdAt: '2023-08-10T10:00:00Z'
  },
  {
    id: 'ART-003',
    stageName: 'Kaelen Roth',
    legalName: 'Kaelen Arthur Roth',
    genre: ['Modern Classical', 'Ambient', 'Cinematic'],
    primaryTerritory: 'DE',
    careerStage: 'LEGACY',
    biography: 'Neoclassical composer and BAFTA-nominated score producer whose peaceful piano and ambient works anchor high-value sync licensing catalogues.',
    labelId: 'LBL-EVR-001',
    publisherId: 'PUB-EVP-001',
    distributorId: 'DIST-ORCHARD-01',
    socialAccounts: {
      spotifyId: '12KaelenRoth',
      youtubeChannelId: 'UC_KaelenRothOfficial'
    },
    metrics: {
      monthlyListeners: 920000,
      totalStreams: 62000000,
      socialFollowers: 125000,
      engagementRatePercent: 2.1,
      catalogueLTMRevenueUSD: 310000
    },
    aandrStatus: 'CATALOGUE_ONLY',
    createdAt: '2021-01-20T10:00:00Z'
  }
];

export const SEED_COMPOSITIONS: Composition[] = [
  {
    id: 'CMP-001',
    iswc: 'T-034.523.891-2',
    title: 'Isle of Glass',
    alternativeTitles: ['Glass Island', 'Isle of Glass (Acoustic)'],
    lyrics: 'Silver tides upon the shore, neon shadows at my door...',
    writerShares: [
      {
        songwriterId: 'SW-001',
        songwriterName: 'Elora Vance',
        ipiNumber: 'IPI-008923412-1',
        performanceSharePercent: 50,
        mechanicalSharePercent: 50,
        proAffiliation: 'PRS'
      },
      {
        songwriterId: 'SW-002',
        songwriterName: 'Liam Corlett',
        ipiNumber: 'IPI-007129834-5',
        performanceSharePercent: 50,
        mechanicalSharePercent: 50,
        proAffiliation: 'ASCAP'
      }
    ],
    publisherShares: [
      {
        publisherId: 'PUB-EVP-001',
        publisherName: 'Ellan Vannin Publishing Ltd',
        ipiNumber: 'IPI-009841235-9',
        sharePercent: 100,
        territory: 'WW'
      }
    ],
    registeredPro: 'PRS',
    registrationStatus: 'REGISTERED',
    registrationDate: '2025-01-15',
    createdAt: '2025-01-10T00:00:00Z'
  },
  {
    id: 'CMP-002',
    iswc: 'T-034.523.892-3',
    title: 'Northern Lights',
    alternativeTitles: ['Aurora Coast'],
    lyrics: 'Cold wind screaming through the street, beat of hearts that never sleep...',
    writerShares: [
      {
        songwriterId: 'SW-003',
        songwriterName: 'Mona Quayle',
        ipiNumber: 'IPI-006512398-0',
        performanceSharePercent: 100,
        mechanicalSharePercent: 100,
        proAffiliation: 'PRS'
      }
    ],
    publisherShares: [
      {
        publisherId: 'PUB-EVP-001',
        publisherName: 'Ellan Vannin Publishing Ltd',
        ipiNumber: 'IPI-009841235-9',
        sharePercent: 100,
        territory: 'WW'
      }
    ],
    registeredPro: 'PRS',
    registrationStatus: 'REGISTERED',
    registrationDate: '2024-05-20',
    createdAt: '2024-05-01T00:00:00Z'
  }
];

export const SEED_MASTERS: Master[] = [
  {
    id: 'MST-001',
    isrc: 'GB-EVR-25-00101',
    title: 'Isle of Glass',
    versionType: 'ORIGINAL',
    artistId: 'ART-001',
    artistName: 'Elora Vance',
    featuredArtists: [],
    producerName: 'Julian Thorne',
    engineerName: 'Marcus Bell',
    recordingDate: '2024-11-12',
    releaseDate: '2025-02-14',
    durationSeconds: 218,
    audioFormat: 'HI_RES_24_96',
    technicalQC: {
      sampleRateHz: 96000,
      bitDepth: 24,
      channels: 'STEREO',
      durationSeconds: 218,
      truePeakDbfs: -0.2,
      clippingDetected: false,
      silenceAtStartMs: 150,
      silenceAtEndMs: 300,
      isrcValid: true,
      qcPassed: true,
      qcCheckedAt: '2025-01-10T14:30:00Z',
      qcNotes: ['Passed mastering peak inspection.', '24bit/96kHz WAV broadcast master verified.']
    },
    labelId: 'LBL-EVR-001',
    contractId: 'CTR-2024-001',
    compositionId: 'CMP-001',
    ownershipPercentage: 100,
    rightsOwnerIds: ['LBL-EVR-001'],
    deliveredToDistribution: true
  },
  {
    id: 'MST-002',
    isrc: 'GB-EVR-25-00102',
    title: 'Isle of Glass (Synth Remix)',
    versionType: 'REMIX',
    artistId: 'ART-001',
    artistName: 'Elora Vance',
    featuredArtists: ['CyberPulse'],
    producerName: 'CyberPulse',
    engineerName: 'CyberPulse',
    recordingDate: '2025-02-01',
    releaseDate: '2025-03-01',
    durationSeconds: 245,
    audioFormat: 'WAV',
    technicalQC: {
      sampleRateHz: 44100,
      bitDepth: 16,
      channels: 'STEREO',
      durationSeconds: 245,
      truePeakDbfs: -0.1,
      clippingDetected: false,
      silenceAtStartMs: 100,
      silenceAtEndMs: 200,
      isrcValid: true,
      qcPassed: true,
      qcCheckedAt: '2025-02-10T10:15:00Z',
      qcNotes: ['Club master verified.']
    },
    labelId: 'LBL-EVR-001',
    contractId: 'CTR-2024-001',
    compositionId: 'CMP-001',
    ownershipPercentage: 100,
    rightsOwnerIds: ['LBL-EVR-001'],
    deliveredToDistribution: true
  },
  {
    id: 'MST-003',
    isrc: 'GB-EVR-24-00045',
    title: 'Northern Lights',
    versionType: 'ORIGINAL',
    artistId: 'ART-002',
    artistName: 'Mona & The Isle',
    featuredArtists: [],
    producerName: 'Gareth Vance',
    engineerName: 'Sarah Jenkins',
    recordingDate: '2024-03-10',
    releaseDate: '2024-06-01',
    durationSeconds: 204,
    audioFormat: 'WAV',
    technicalQC: {
      sampleRateHz: 48000,
      bitDepth: 24,
      channels: 'STEREO',
      durationSeconds: 204,
      truePeakDbfs: -0.4,
      clippingDetected: false,
      silenceAtStartMs: 180,
      silenceAtEndMs: 400,
      isrcValid: true,
      qcPassed: true,
      qcCheckedAt: '2024-04-15T09:00:00Z',
      qcNotes: ['Broadcast WAV master approved.']
    },
    labelId: 'LBL-EVR-001',
    contractId: 'CTR-2023-009',
    compositionId: 'CMP-002',
    ownershipPercentage: 100,
    rightsOwnerIds: ['LBL-EVR-001'],
    deliveredToDistribution: true
  }
];

export const SEED_RELEASES: Release[] = [
  {
    id: 'REL-001',
    upc: '5060123984012',
    title: 'Isle of Glass',
    releaseType: 'ALBUM',
    artistId: 'ART-001',
    artistName: 'Elora Vance',
    labelId: 'LBL-EVR-001',
    releaseDate: '2025-02-14',
    status: 'LIVE',
    coverArtworkUrl: 'https://picsum.photos/seed/eloravacance/600/600',
    masterIds: ['MST-001', 'MST-002'],
    territories: ['WW'],
    genre: 'Synth Pop',
    preSaveCount: 24500,
    dspsDelivered: ['SPOTIFY', 'APPLE_MUSIC', 'AMAZON', 'DEEZER', 'TIDAL', 'YOUTUBE']
  },
  {
    id: 'REL-002',
    upc: '5060123984099',
    title: 'Northern Lights',
    releaseType: 'EP',
    artistId: 'ART-002',
    artistName: 'Mona & The Isle',
    labelId: 'LBL-EVR-001',
    releaseDate: '2024-06-01',
    status: 'LIVE',
    coverArtworkUrl: 'https://picsum.photos/seed/monaisle/600/600',
    masterIds: ['MST-003'],
    territories: ['WW'],
    genre: 'Indie Rock',
    preSaveCount: 12800,
    dspsDelivered: ['SPOTIFY', 'APPLE_MUSIC', 'AMAZON', 'DEEZER', 'TIDAL']
  }
];

export const SEED_CONTRACTS: Contract[] = [
  {
    id: 'CTR-2024-001',
    contractNumber: 'EVR-REC-2024-EV01',
    title: 'Exclusive Master Recording Agreement - Elora Vance',
    contractType: 'ARTIST_RECORDING',
    primaryArtistId: 'ART-001',
    labelId: 'LBL-EVR-001',
    effectiveDate: '2024-02-01',
    termYears: 5,
    territory: 'WW',
    royaltyRateMasterPercent: 22.0,
    royaltyRateSyncPercent: 50.0,
    advanceAmountUSD: 250000,
    recoupableExpensesCategory: ['RECORDING', 'VIDEO_50', 'INDEPENDENT_PROMO_50', 'TOUR_SUPPORT'],
    crossCollateralised: false,
    status: 'EXECUTED',
    executedAt: '2024-02-01T12:00:00Z'
  },
  {
    id: 'CTR-2023-009',
    contractNumber: 'EVR-REC-2023-MI09',
    title: 'Exclusive Recording Agreement - Mona & The Isle',
    contractType: 'ARTIST_RECORDING',
    primaryArtistId: 'ART-002',
    labelId: 'LBL-EVR-001',
    effectiveDate: '2023-08-01',
    termYears: 4,
    territory: 'WW',
    royaltyRateMasterPercent: 20.0,
    royaltyRateSyncPercent: 50.0,
    advanceAmountUSD: 150000,
    recoupableExpensesCategory: ['RECORDING', 'TOUR_SUPPORT'],
    crossCollateralised: false,
    status: 'EXECUTED',
    executedAt: '2023-08-01T10:00:00Z'
  }
];

export const SEED_RIGHTS: RightRecord[] = [
  {
    id: 'RGT-001',
    assetId: 'MST-001',
    category: 'MASTER',
    ownerName: 'ELLAN VANNIN RECORDS',
    percentage: 100,
    territory: 'WW',
    startDate: '2024-02-01',
    contractId: 'CTR-2024-001',
    sourceDocumentRef: 'EVR-REC-2024-EV01 Clause 4.1',
    confidenceScore: 1.0,
    status: 'ACTIVE'
  },
  {
    id: 'RGT-002',
    assetId: 'CMP-001',
    category: 'PUBLISHING',
    ownerName: 'Ellan Vannin Publishing Ltd',
    percentage: 100,
    territory: 'WW',
    startDate: '2024-02-01',
    contractId: 'CTR-2024-001',
    sourceDocumentRef: 'EVR-PUB-2024-EV01 Clause 2.3',
    confidenceScore: 0.98,
    status: 'ACTIVE'
  }
];

export const SEED_ADVANCES: Advance[] = [
  {
    id: 'ADV-001',
    contractId: 'CTR-2024-001',
    artistId: 'ART-001',
    category: 'RECORDING',
    originalAmountUSD: 250000,
    currentRecoupedAmountUSD: 184200,
    remainingBalanceUSD: 65800,
    issuedDate: '2024-02-05',
    isRecoupable: true,
    priorityOrder: 1
  },
  {
    id: 'ADV-002',
    contractId: 'CTR-2023-009',
    artistId: 'ART-002',
    category: 'RECORDING',
    originalAmountUSD: 150000,
    currentRecoupedAmountUSD: 150000,
    remainingBalanceUSD: 0,
    issuedDate: '2023-08-05',
    isRecoupable: true,
    priorityOrder: 1
  }
];

export const SEED_JOURNAL_TRANSACTIONS: JournalTransaction[] = [
  {
    id: 'TX-2026-001',
    transactionDate: '2026-01-15',
    reference: 'DSP-DSP-SPOTIFY-2025Q4',
    description: 'Q4 2025 Spotify Digital Streaming Ingestion Net Receipts',
    lines: [
      { accountCode: '1100_RECEIVABLES_DSP', accountName: 'DSP Receivables (Spotify)', debitUSD: 420000, creditUSD: 0 },
      { accountCode: '4010_REVENUE_STREAMING', accountName: 'Streaming Revenue', debitUSD: 0, creditUSD: 420000 }
    ],
    isBalanced: true,
    createdRole: 'FINANCE_CFO',
    createdAt: '2026-01-15T16:00:00Z'
  },
  {
    id: 'TX-2026-002',
    transactionDate: '2026-01-20',
    reference: 'ROY-RUN-2025Q4-ART001',
    description: 'Elora Vance Q4 2025 Royalty Allocation & Recoupment Amortisation',
    lines: [
      { accountCode: '5010_EXPENSE_ROYALTIES', accountName: 'Royalty Expense', debitUSD: 92400, creditUSD: 0 },
      { accountCode: '2030_UNEARNED_ADVANCES', accountName: 'Artist Unearned Advances (Recoupment)', debitUSD: 0, creditUSD: 92400 }
    ],
    isBalanced: true,
    createdRole: 'ROYALTY_DIRECTOR',
    createdAt: '2026-01-20T11:30:00Z'
  }
];

export const SEED_ROYALTY_RUNS: RoyaltyCalculationRun[] = [
  {
    id: 'ROY-2026-H1-01',
    periodLabel: '2026-H1',
    artistId: 'ART-001',
    artistName: 'Elora Vance',
    contractId: 'CTR-2024-001',
    grossRevenueUSD: 420000,
    platformFeesUSD: 126000,
    distributionFeesUSD: 14700,
    netReceiptsUSD: 279300,
    contractRoyaltyRatePercent: 22.0,
    grossEarnedRoyaltyUSD: 61446,
    recoupmentDeductedUSD: 61446,
    payableRoyaltyUSD: 0,
    unrecoupedBalanceUSD: 4354,
    statementStatus: 'APPROVED',
    calculatedAt: '2026-02-01T09:00:00Z'
  },
  {
    id: 'ROY-2026-H1-02',
    periodLabel: '2026-H1',
    artistId: 'ART-002',
    artistName: 'Mona & The Isle',
    contractId: 'CTR-2023-009',
    grossRevenueUSD: 260000,
    platformFeesUSD: 78000,
    distributionFeesUSD: 9100,
    netReceiptsUSD: 172900,
    contractRoyaltyRatePercent: 20.0,
    grossEarnedRoyaltyUSD: 34580,
    recoupmentDeductedUSD: 0,
    payableRoyaltyUSD: 34580,
    unrecoupedBalanceUSD: 0,
    statementStatus: 'PAID',
    calculatedAt: '2026-02-01T09:30:00Z'
  }
];

export const SEED_SYNC_OPPORTUNITIES: SyncOpportunity[] = [
  {
    id: 'SYNC-001',
    title: 'Cyberpunk Drama Series - Main Theme Sync',
    clientName: 'HBO / Warner Bros Television',
    mediaType: 'TELEVISION',
    briefDescription: 'High-energy futuristic synth-pop track required for episode 1 opening sequence.',
    budgetFeeUSD: 85000,
    targetTerritories: ['WW'],
    masterCleared: true,
    publishingCleared: true,
    status: 'LICENSED',
    pitchTrackId: 'MST-001',
    pitchTrackTitle: 'Isle of Glass',
    cueSheetSubmitted: true
  },
  {
    id: 'SYNC-002',
    title: 'Luxury EV Global Commercial Campaign',
    clientName: 'Audi Global Creative Agency',
    mediaType: 'ADVERTISING',
    briefDescription: 'Cinematic ambient piano crescendo conveying elegant momentum and sustainable power.',
    budgetFeeUSD: 120000,
    targetTerritories: ['WW'],
    masterCleared: true,
    publishingCleared: false,
    status: 'SHORTLISTED',
    pitchTrackId: 'MST-003',
    pitchTrackTitle: 'Northern Lights',
    cueSheetSubmitted: false
  }
];

export const SEED_CATALOGUE_VALUATION: CatalogueValuationReport = {
  catalogueId: 'CAT-EVR-MASTER-01',
  catalogueName: 'Ellan Vannin Master Catalogue (120 Masters)',
  valuationDate: '2026-09-01',
  ltmRevenueUSD: 1670000,
  baseValuationUSD: 18520000,
  bullValuationUSD: 23150000,
  bearValuationUSD: 14200000,
  scenarios: [
    {
      scenarioName: 'BASE',
      discountRatePercent: 8.5,
      projectedCashFlowsUSD: [1620000, 1570000, 1520000, 1475000, 1430000],
      terminalValueUSD: 17200000,
      netPresentValueUSD: 18520000,
      impliedMultiple: 11.1
    },
    {
      scenarioName: 'BULL',
      discountRatePercent: 7.5,
      projectedCashFlowsUSD: [1800000, 1850000, 1910000, 1980000, 2050000],
      terminalValueUSD: 22100000,
      netPresentValueUSD: 23150000,
      impliedMultiple: 13.8
    },
    {
      scenarioName: 'BEAR',
      discountRatePercent: 10.5,
      projectedCashFlowsUSD: [1500000, 1410000, 1320000, 1240000, 1160000],
      terminalValueUSD: 11800000,
      netPresentValueUSD: 14200000,
      impliedMultiple: 8.5
    },
    {
      scenarioName: 'STRESS',
      discountRatePercent: 12.5,
      projectedCashFlowsUSD: [1350000, 1210000, 1090000, 980000, 880000],
      terminalValueUSD: 8500000,
      netPresentValueUSD: 10900000,
      impliedMultiple: 6.5
    }
  ],
  methodologiesUsed: ['Discounted Cash Flow (DCF)', 'LTM Revenue Multiple (11.1x)', 'Historical Royalty Stream Decay Matrix'],
  analystNotes: 'Strong streaming resilience in Elora Vance & Mona & The Isle catalogues provides stable high-margin cash flow.'
};

export const SEED_INVESTMENT_DEALS: InvestmentDeal[] = [
  {
    id: 'DEAL-2026-01',
    targetAssetTitle: 'The Midnight Echoes 1980s Post-Punk Catalogue Acquisition',
    dealType: 'CATALOGUE_ACQUISITION',
    purchasePriceUSD: 4200000,
    expectedLTMRevenueUSD: 390000,
    projectedIrrPercent: 14.8,
    npvUSD: 1150000,
    paybackPeriodYears: 6.8,
    icStatus: 'IC_REVIEW',
    leadPartner: 'Arthur Pendelton (Head of Capital)',
    riskRating: 'MEDIUM',
    targetClosingDate: '2026-10-15'
  },
  {
    id: 'DEAL-2026-02',
    targetAssetTitle: 'Solstice Sound Ambient Publishing Library Buyout',
    dealType: 'PUBLISHING_JV',
    purchasePriceUSD: 1850000,
    expectedLTMRevenueUSD: 210000,
    projectedIrrPercent: 16.2,
    npvUSD: 620000,
    paybackPeriodYears: 5.4,
    icStatus: 'DUE_DILIGENCE',
    leadPartner: 'Sarah Jenkins (Investment Director)',
    riskRating: 'LOW',
    targetClosingDate: '2026-11-01'
  }
];

export const SEED_DIGITAL_TWIN_STATE: DigitalTwinState = {
  totalActiveArtists: 3,
  totalMastersCount: 120,
  annualStreamsTotal: 293300000,
  annualGrossRevenueUSD: 1670000,
  annualNetProfitUSD: 634000,
  artistRecoupmentRatePercent: 66.7,
  totalCatalogueValuationUSD: 18520000,
  cashReserveUSD: 3450000
};

export const SEED_AR_CANDIDATES: ARCandidate[] = [
  {
    id: 'AR-CAND-001',
    artistName: 'Solstice Arc',
    genre: 'Cinematic Synth',
    location: 'Manchester, UK',
    scoutName: 'A&R Analyst Mark Sterling',
    submittedDemoTrackTitle: 'Neon Echoes (Demo 2)',
    ratings: {
      artisticQuality: 9,
      audienceGrowth: 8,
      engagement: 8,
      commercialPotential: 9,
      cataloguePotential: 8,
      internationalPotential: 7,
      livePotential: 7,
      syncPotential: 9
    },
    calculatedScore: 8.35,
    recommendation: 'HIGHLY_RECOMMENDED',
    notes: 'Exceptional synth production, strong Spotify algorithmic traction (+40% MoM listener growth), high sync suitability.'
  },
  {
    id: 'AR-CAND-002',
    artistName: 'The High Tide',
    genre: 'Post-Indie Rock',
    location: 'Dublin, IE',
    scoutName: 'Senior A&R Rep Clara Flynn',
    submittedDemoTrackTitle: 'Wasted Summer',
    ratings: {
      artisticQuality: 7,
      audienceGrowth: 6,
      engagement: 7,
      commercialPotential: 7,
      cataloguePotential: 6,
      internationalPotential: 5,
      livePotential: 9,
      syncPotential: 5
    },
    calculatedScore: 6.70,
    recommendation: 'DEVELOPMENT_DEAL',
    notes: 'Strong live draw in UK/Ireland festivals. Requires production development for streaming optimization.'
  }
];

export const DEFAULT_AR_WEIGHTS: ARScoringWeights = {
  artisticQuality: 0.20,
  audienceGrowth: 0.15,
  engagement: 0.15,
  commercialPotential: 0.15,
  cataloguePotential: 0.10,
  internationalPotential: 0.10,
  livePotential: 0.10,
  syncPotential: 0.05
};

export const SEED_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: 'AUD-901',
    timestamp: '2026-09-11T08:14:00Z',
    actorRole: 'ROYALTY_DIRECTOR',
    actorEmail: 'royalty@ellanvannin.com',
    action: 'ROYALTY_STATEMENT_APPROVED',
    entityType: 'RoyaltyCalculationRun',
    entityId: 'ROY-2026-H1-01',
    reason: 'Approved 2026-H1 Elora Vance statement following audit verification.',
    ipAddress: '192.168.1.104'
  },
  {
    id: 'AUD-902',
    timestamp: '2026-09-10T14:22:10Z',
    actorRole: 'FINANCE_CFO',
    actorEmail: 'cfo@ellanvannin.com',
    action: 'JOURNAL_TRANSACTION_POSTED',
    entityType: 'JournalTransaction',
    entityId: 'TX-2026-001',
    reason: 'Posted Q4 2025 Spotify Ingestion Revenue Ledger Transaction.',
    ipAddress: '192.168.1.101'
  }
];

export const SEED_ANOMALIES: AnomalyAlert[] = [
  {
    id: 'ANO-001',
    timestamp: '2026-09-10T02:00:00Z',
    severity: 'MEDIUM',
    category: 'DSP_REPORT_DISCREPANCY',
    title: 'Unexpected Stream Spike in Germany (DSP Ingestion)',
    explanation: 'German Spotify streams jumped +240% in a 48h period for "Isle of Glass". Algorithm playlist placement confirmed on "TagesHits". No fraud detected.',
    affectedEntityId: 'MST-001',
    status: 'INVESTIGATING'
  },
  {
    id: 'ANO-002',
    timestamp: '2026-09-08T18:30:00Z',
    severity: 'LOW',
    category: 'RIGHTS_CONFLICT',
    title: 'Territorial Publishing Overlap (GEMA vs PRS)',
    explanation: 'Identified minor 1.2% mechanical right claim overlap in German territory for track "Northern Lights". Automatically flagged for publisher clearance.',
    affectedEntityId: 'CMP-002',
    status: 'OPEN'
  }
];
