// ELLAN VANNIN MUSIC OS - DETERMINISTIC MATHEMATICAL & FINANCIAL ENGINES
// All calculations are exact, reproducible, and verifiable.

import {
  ARScoringWeights,
  ARCandidate,
  JournalTransaction,
  MasterTechnicalQC,
  MasterAudioFormat,
  RoyaltyCalculationRun,
  ValuationParameters,
  ValuationScenarioResult,
  WhatIfScenarioInput,
  WhatIfScenarioOutput,
  DigitalTwinState
} from './types';

/**
 * 1. DOUBLE-ENTRY LEDGER VALIDATION
 * Invariant: TOTAL DEBITS = TOTAL CREDITS
 */
export function validateJournalTransaction(tx: JournalTransaction): { isBalanced: boolean; totalDebit: number; totalCredit: number; difference: number } {
  let totalDebit = 0;
  let totalCredit = 0;

  for (const line of tx.lines) {
    totalDebit += Math.round((line.debitUSD || 0) * 100); // work in cents to avoid IEEE 754 precision issues
    totalCredit += Math.round((line.creditUSD || 0) * 100);
  }

  const diffCents = totalDebit - totalCredit;
  const isBalanced = diffCents === 0;

  return {
    isBalanced,
    totalDebit: totalDebit / 100,
    totalCredit: totalCredit / 100,
    difference: diffCents / 100
  };
}

/**
 * 2. DETERMINISTIC ROYALTY CALCULATION
 * GrossRevenue - PlatformFees - DistributionFees - Taxes = NetReceipts
 * NetReceipts * RoyaltyRate = ArtistEarnedRoyalty
 * Payable = max(0, ArtistEarnedRoyalty - RecoupmentApplied)
 */
export function calculateRoyaltyWaterfall(params: {
  grossRevenueUSD: number;
  platformFeePercent: number; // e.g., 30% for DSP
  distributionFeePercent: number; // e.g., 5%
  taxRatePercent: number; // e.g., 0% or withholding
  artistRoyaltyRatePercent: number; // e.g., 20%
  unrecoupedAdvanceBalanceUSD: number;
}): {
  platformFeesUSD: number;
  distributionFeesUSD: number;
  taxDeductionsUSD: number;
  netReceiptsUSD: number;
  grossEarnedRoyaltyUSD: number;
  recoupmentAppliedUSD: number;
  payableRoyaltyUSD: number;
  remainingUnrecoupedBalanceUSD: number;
} {
  const gross = Math.max(0, params.grossRevenueUSD);
  const platformFees = gross * (params.platformFeePercent / 100);
  const distributionFees = (gross - platformFees) * (params.distributionFeePercent / 100);
  const netReceipts = Math.max(0, gross - platformFees - distributionFees);
  
  const taxDeductions = netReceipts * (params.taxRatePercent / 100);
  const royaltyBase = netReceipts - taxDeductions;
  
  const grossEarnedRoyalty = royaltyBase * (params.artistRoyaltyRatePercent / 100);
  
  // Recoupment application
  const recoupmentApplied = Math.min(grossEarnedRoyalty, Math.max(0, params.unrecoupedAdvanceBalanceUSD));
  const payableRoyalty = Math.max(0, grossEarnedRoyalty - recoupmentApplied);
  const remainingUnrecoupedBalanceUSD = Math.max(0, params.unrecoupedAdvanceBalanceUSD - recoupmentApplied);

  return {
    platformFeesUSD: Number(platformFees.toFixed(2)),
    distributionFeesUSD: Number(distributionFees.toFixed(2)),
    taxDeductionsUSD: Number(taxDeductions.toFixed(2)),
    netReceiptsUSD: Number(netReceipts.toFixed(2)),
    grossEarnedRoyaltyUSD: Number(grossEarnedRoyalty.toFixed(2)),
    recoupmentAppliedUSD: Number(recoupmentApplied.toFixed(2)),
    payableRoyaltyUSD: Number(payableRoyalty.toFixed(2)),
    remainingUnrecoupedBalanceUSD: Number(remainingUnrecoupedBalanceUSD.toFixed(2))
  };
}

/**
 * 3. TECHNICAL QC VALIDATION FOR MASTERS
 */
export function validateMasterTechnicalQC(audioSpecs: {
  sampleRateHz: number;
  bitDepth: number;
  durationSeconds: number;
  truePeakDbfs: number;
  clippingDetected: boolean;
  isrc: string;
  format: MasterAudioFormat;
}): MasterTechnicalQC {
  const notes: string[] = [];
  let qcPassed = true;

  if (audioSpecs.sampleRateHz < 44100) {
    notes.push('CRITICAL: Sample rate below red-book standard (44.1kHz).');
    qcPassed = false;
  }
  if (audioSpecs.bitDepth < 16) {
    notes.push('CRITICAL: Bit depth below 16-bit standard.');
    qcPassed = false;
  }
  if (audioSpecs.clippingDetected || audioSpecs.truePeakDbfs > 0) {
    notes.push('WARNING: Digital clipping or true peak over 0.0 dBFS detected.');
    qcPassed = false;
  }
  if (audioSpecs.durationSeconds < 10) {
    notes.push('WARNING: Track duration unreasonably short (<10s).');
    qcPassed = false;
  }

  // Check ISRC standard format regex e.g. GB-A12-26-00001
  const isrcRegex = /^[A-Z]{2}-?[A-Z0-9]{3}-?\d{2}-?\d{5}$/i;
  const isrcValid = isrcRegex.test(audioSpecs.isrc);
  if (!isrcValid) {
    notes.push('CRITICAL: Invalid ISRC code structure.');
    qcPassed = false;
  }

  return {
    sampleRateHz: audioSpecs.sampleRateHz,
    bitDepth: audioSpecs.bitDepth,
    channels: 'STEREO',
    durationSeconds: audioSpecs.durationSeconds,
    truePeakDbfs: audioSpecs.truePeakDbfs,
    clippingDetected: audioSpecs.clippingDetected,
    silenceAtStartMs: 120,
    silenceAtEndMs: 450,
    isrcValid,
    qcPassed,
    qcCheckedAt: new Date().toISOString(),
    qcNotes: notes.length > 0 ? notes : ['All technical QC specs conform to institutional master delivery standards.']
  };
}

/**
 * 4. CATALOGUE DISCOUNTED CASH FLOW (DCF) & MULTIPLE VALUATION
 * PV = Sum( CF_t / (1 + r)^t ) + TerminalValue / (1 + r)^N
 */
export function calculateCatalogueDCFValuation(params: ValuationParameters): CatalogueValuationReportSummary {
  const ltm = params.ltmRevenueUSD;
  const N = params.projectionYears;

  const scenarios: ValuationScenarioResult[] = [
    runValuationScenario('BASE', ltm, N, 0.085, 0.02, 0.03),
    runValuationScenario('BULL', ltm, N, 0.075, 0.03, 0.01),
    runValuationScenario('BEAR', ltm, N, 0.105, 0.01, 0.06),
    runValuationScenario('STRESS', ltm, N, 0.125, 0.00, 0.10)
  ];

  const baseValuation = scenarios.find(s => s.scenarioName === 'BASE')!.netPresentValueUSD;
  const bullValuation = scenarios.find(s => s.scenarioName === 'BULL')!.netPresentValueUSD;
  const bearValuation = scenarios.find(s => s.scenarioName === 'BEAR')!.netPresentValueUSD;

  return {
    ltmRevenueUSD: ltm,
    baseValuationUSD: baseValuation,
    bullValuationUSD: bullValuation,
    bearValuationUSD: bearValuation,
    scenarios
  };
}

export interface CatalogueValuationReportSummary {
  ltmRevenueUSD: number;
  baseValuationUSD: number;
  bullValuationUSD: number;
  bearValuationUSD: number;
  scenarios: ValuationScenarioResult[];
}

function runValuationScenario(
  name: 'BASE' | 'BULL' | 'BEAR' | 'STRESS',
  ltmRevenueUSD: number,
  years: number,
  discountRate: number,
  terminalGrowth: number,
  annualDecay: number
): ValuationScenarioResult {
  const cashFlows: number[] = [];
  let currentCF = ltmRevenueUSD;
  let npv = 0;

  for (let t = 1; t <= years; t++) {
    currentCF = currentCF * (1 - annualDecay);
    cashFlows.push(Number(currentCF.toFixed(2)));
    npv += currentCF / Math.pow(1 + discountRate, t);
  }

  // Terminal value calculation via Gordon Growth model
  const lastCF = cashFlows[cashFlows.length - 1];
  const terminalVal = (lastCF * (1 + terminalGrowth)) / (discountRate - terminalGrowth);
  const discountedTerminalVal = terminalVal / Math.pow(1 + discountRate, years);

  const totalNPV = npv + discountedTerminalVal;

  return {
    scenarioName: name,
    discountRatePercent: Number((discountRate * 100).toFixed(2)),
    projectedCashFlowsUSD: cashFlows,
    terminalValueUSD: Number(terminalVal.toFixed(2)),
    netPresentValueUSD: Number(totalNPV.toFixed(2)),
    impliedMultiple: Number((totalNPV / ltmRevenueUSD).toFixed(2))
  };
}

/**
 * 5. NEWTON-RAPHSON IRR SOLVER
 * Calculates Internal Rate of Return (IRR) where NPV = 0
 */
export function calculateInternalRateOfReturn(purchasePriceUSD: number, expectedAnnualCashFlowsUSD: number[]): number {
  let rate = 0.10; // Initial guess 10%
  const maxIterations = 100;
  const tolerance = 0.00001;

  for (let iter = 0; iter < maxIterations; iter++) {
    let npv = -purchasePriceUSD;
    let derivativeNPV = 0;

    for (let t = 0; t < expectedAnnualCashFlowsUSD.length; t++) {
      const year = t + 1;
      const cf = expectedAnnualCashFlowsUSD[t];
      npv += cf / Math.pow(1 + rate, year);
      derivativeNPV -= (year * cf) / Math.pow(1 + rate, year + 1);
    }

    if (Math.abs(npv) < tolerance) {
      return Number((rate * 100).toFixed(2));
    }

    if (Math.abs(derivativeNPV) < 0.000001) break;

    rate = rate - npv / derivativeNPV;
  }

  return Number((rate * 100).toFixed(2));
}

/**
 * 6. CONFIGURABLE A&R SCORING MODEL
 */
export function calculateARScore(candidate: ARCandidate, weights: ARScoringWeights): number {
  const r = candidate.ratings;
  const score = 
    weights.artisticQuality * r.artisticQuality +
    weights.audienceGrowth * r.audienceGrowth +
    weights.engagement * r.engagement +
    weights.commercialPotential * r.commercialPotential +
    weights.cataloguePotential * r.cataloguePotential +
    weights.internationalPotential * r.internationalPotential +
    weights.livePotential * r.livePotential +
    weights.syncPotential * r.syncPotential;

  return Number(score.toFixed(2));
}

/**
 * 7. DIGITAL TWIN WHAT-IF SIMULATOR
 */
export function simulateDigitalTwinWhatIf(
  current: DigitalTwinState,
  input: WhatIfScenarioInput
): WhatIfScenarioOutput {
  const projectedGross = current.annualGrossRevenueUSD * input.streamVolumeMultiplier * (1 + input.dspPayOutRateChangePercent / 100);
  const additionalCatRev = input.catalogueAcquisitionInvestmentUSD > 0 ? input.catalogueAcquisitionInvestmentUSD * 0.12 : 0;
  
  const totalGross = projectedGross + additionalCatRev;
  const projectedNet = totalGross * 0.38 - (current.totalActiveArtists * 15000 * input.marketingBudgetMultiplier);

  const revenueDelta = ((totalGross - current.annualGrossRevenueUSD) / current.annualGrossRevenueUSD) * 100;

  const newValuation = current.totalCatalogueValuationUSD * (1 + (revenueDelta / 100) * 0.7) + input.catalogueAcquisitionInvestmentUSD * 1.2;
  const valuationDelta = ((newValuation - current.totalCatalogueValuationUSD) / current.totalCatalogueValuationUSD) * 100;

  const newCashReserve = current.cashReserveUSD - input.catalogueAcquisitionInvestmentUSD + (projectedNet > 0 ? projectedNet * 0.5 : projectedNet);

  return {
    projectedGrossRevenueUSD: Number(totalGross.toFixed(2)),
    projectedNetProfitUSD: Number(projectedNet.toFixed(2)),
    projectedRecoupedArtistsCount: Math.round(current.totalActiveArtists * (current.artistRecoupmentRatePercent / 100) * 1.15),
    projectedCatalogueValuationUSD: Number(newValuation.toFixed(2)),
    projectedCashReserveUSD: Number(newCashReserve.toFixed(2)),
    revenueDeltaPercent: Number(revenueDelta.toFixed(2)),
    valuationDeltaPercent: Number(valuationDelta.toFixed(2))
  };
}
