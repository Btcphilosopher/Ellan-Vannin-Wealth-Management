import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { statementData, format } = await req.json();

    if (!statementData) {
      return NextResponse.json({ error: "Missing statementData payload" }, { status: 400 });
    }

    if (format === 'csv') {
      const csvLines = [
        `"ROYALTY STATEMENT — ELLAN VANNIN RECORDS"`,
        `"Period","${statementData.periodLabel}"`,
        `"Artist","${statementData.artistName}"`,
        `"Contract","${statementData.contractId}"`,
        `"Gross Revenue USD","${statementData.grossRevenueUSD}"`,
        `"Platform Fees USD","${statementData.platformFeesUSD}"`,
        `"Distribution Fees USD","${statementData.distributionFeesUSD}"`,
        `"Net Receipts USD","${statementData.netReceiptsUSD}"`,
        `"Contract Royalty Rate","${statementData.contractRoyaltyRatePercent}%"`,
        `"Gross Earned Royalty USD","${statementData.grossEarnedRoyaltyUSD}"`,
        `"Recoupment Deducted USD","${statementData.recoupmentDeductedUSD}"`,
        `"Payable Royalty USD","${statementData.payableRoyaltyUSD}"`,
        `"Unrecouped Balance USD","${statementData.unrecoupedBalanceUSD}"`
      ];

      return new NextResponse(csvLines.join('\n'), {
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': `attachment; filename="Royalty_Statement_${statementData.artistName.replace(/\s+/g, '_')}_${statementData.periodLabel}.csv"`
        }
      });
    }

    // Default JSON export
    return NextResponse.json(statementData);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
