import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Ellan Vannin Music OS — Institutional Operating System',
  description: 'Institutional Operating System for Record Labels, Music Groups, Publishers, Artists and Music Investment Firms',
  openGraph: {
    title: 'Ellan Vannin Music OS — Institutional Operating System',
    description: 'Institutional Operating System for Record Labels, Music Groups, Publishers, Artists and Music Investment Firms',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Ellan Vannin Music OS — Institutional Operating System',
    description: 'Institutional Operating System for Record Labels, Music Groups, Publishers, Artists and Music Investment Firms',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
