'use client';

import React from 'react';
import { MusicOSProvider, useMusicOS } from '../lib/context/MusicOSContext';
import { Navbar } from '../components/Navbar';
import { ModuleTabs } from '../components/ModuleTabs';

// Module Views
import { ExecutiveDashboard } from '../components/modules/ExecutiveDashboard';
import { ArtistsRosterModule } from '../components/modules/ArtistsRosterModule';
import { AandREngineModule } from '../components/modules/AandREngineModule';
import { MastersQCModule } from '../components/modules/MastersQCModule';
import { PublishingModule } from '../components/modules/PublishingModule';
import { ReleasesModule } from '../components/modules/ReleasesModule';
import { MarketingPhysicalModule } from '../components/modules/MarketingPhysicalModule';
import { RightsContractsModule } from '../components/modules/RightsContractsModule';
import { RoyaltiesModule } from '../components/modules/RoyaltiesModule';
import { FinancialLedgerModule } from '../components/modules/FinancialLedgerModule';
import { SyncLicensingModule } from '../components/modules/SyncLicensingModule';
import { CatalogueValuationModule } from '../components/modules/CatalogueValuationModule';
import { InvestmentFundModule } from '../components/modules/InvestmentFundModule';
import { DigitalTwinModule } from '../components/modules/DigitalTwinModule';
import { FraudAuditModule } from '../components/modules/FraudAuditModule';
import { PortalsModule } from '../components/modules/PortalsModule';
import { AICopilotModule } from '../components/modules/AICopilotModule';

function MainOSContent() {
  const { activeTab } = useMusicOS();

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {activeTab === 'EXECUTIVE_DASHBOARD' && <ExecutiveDashboard />}
      {activeTab === 'ARTISTS_ROSTER' && <ArtistsRosterModule />}
      {activeTab === 'AANDR_ENGINE' && <AandREngineModule />}
      {activeTab === 'RECORDING_MASTERS' && <MastersQCModule />}
      {activeTab === 'COMPOSITIONS_PUBLISHING' && <PublishingModule />}
      {activeTab === 'RELEASES_DISTRIBUTION' && <ReleasesModule />}
      {activeTab === 'MARKETING_PHYSICAL' && <MarketingPhysicalModule />}
      {activeTab === 'RIGHTS_CONTRACTS' && <RightsContractsModule />}
      {activeTab === 'ROYALTIES_RECOUPMENT' && <RoyaltiesModule />}
      {activeTab === 'FINANCIAL_LEDGER' && <FinancialLedgerModule />}
      {activeTab === 'SYNC_LICENSING' && <SyncLicensingModule />}
      {activeTab === 'CATALOGUE_VALUATION' && <CatalogueValuationModule />}
      {activeTab === 'INVESTMENT_FUND' && <InvestmentFundModule />}
      {activeTab === 'DIGITAL_TWIN' && <DigitalTwinModule />}
      {activeTab === 'DSP_ANALYTICS' && <ExecutiveDashboard />}
      {activeTab === 'PORTALS' && <PortalsModule />}
      {activeTab === 'FRAUD_AUDIT' && <FraudAuditModule />}
      {activeTab === 'AI_COPILOT' && <AICopilotModule />}
    </main>
  );
}

export default function EllanVanninMusicOSApp() {
  return (
    <MusicOSProvider>
      <div className="min-h-screen bg-[#0b0e14] text-slate-100 font-sans selection:bg-amber-500 selection:text-slate-950">
        <Navbar />
        <ModuleTabs />
        <MainOSContent />
      </div>
    </MusicOSProvider>
  );
}
