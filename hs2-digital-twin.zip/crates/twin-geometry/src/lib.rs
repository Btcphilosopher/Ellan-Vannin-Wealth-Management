//! Geometry & Clothoid Transition Spirals for High-Speed Railway Alignment

#[derive(Debug, Clone, PartialEq)]
pub struct AlignmentSplinePoint {
    pub chainage_m: f64,
    pub easting: f64,
    pub northing: f64,
    pub elevation: f64,
    pub gradient_permille: f64,
    pub cant_mm: f64,
    pub radius_m: f64,
}

impl AlignmentSplinePoint {
    pub fn calculate_cant_deficiency(&self, speed_kmh: f64) -> f64 {
        if self.radius_m.is_infinite() || self.radius_m <= 0.0 {
            0.0
        } else {
            let theoretical_cant = (11.82 * speed_kmh.powi(2)) / self.radius_m;
            (theoretical_cant - self.cant_mm).max(0.0)
        }
    }
}
