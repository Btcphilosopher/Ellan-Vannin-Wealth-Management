//! Rail Subsystems Domain Physics & Signalling Logic

pub struct DavisEquation {
    pub a: f64, // Mechanical rolling resistance (N)
    pub b: f64, // Flange friction & damping (N/(m/s))
    pub c: f64, // Aerodynamic drag coefficient (N/(m/s)^2)
}

impl DavisEquation {
    pub fn hs2_class_895_default() -> Self {
        Self {
            a: 4800.0,
            b: 120.0,
            c: 8.4,
        }
    }

    pub fn calculate_resistance_n(&self, velocity_ms: f64) -> f64 {
        self.a + self.b * velocity_ms + self.c * velocity_ms.powi(2)
    }
}
