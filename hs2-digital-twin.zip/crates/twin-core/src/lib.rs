//! Universal Asset Model and Lifecycle State Machine for HS2 Digital Twin
//! Label: SYNTHETIC HS2-LIKE DEMONSTRATION DATA — NOT OFFICIAL HS2 DATA

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use uuid::Uuid;

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct AssetId(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Discipline {
    Civils,
    Track,
    Ole,
    Power,
    Signalling,
    Telecoms,
    Stations,
    Tunnels,
    Drainage,
    Environment,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum LifecycleState {
    Designed,
    Planned,
    UnderConstruction,
    AsBuilt,
    Commissioned,
    Operational,
    OutOfService,
    UnderMaintenance,
    Decommissioned,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum InformationStatus {
    Wip,
    Shared,
    Published,
    Archived,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GeoReference {
    pub latitude: f64,
    pub longitude: f64,
    pub elevation_m: f64,
    pub bng_easting: f64,
    pub bng_northing: f64,
    pub chainage_m: f64,
    pub route_section_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Asset {
    pub asset_id: AssetId,
    pub parent_id: Option<AssetId>,
    pub discipline: Discipline,
    pub name: String,
    pub description: String,
    pub uniclass_code: String,
    pub location: GeoReference,
    pub lifecycle_state: LifecycleState,
    pub information_status: InformationStatus,
    pub confidence: f64,
    pub properties: HashMap<String, serde_json::Value>,
    pub created_at: DateTime<Utc>,
    pub last_updated: DateTime<Utc>,
}
