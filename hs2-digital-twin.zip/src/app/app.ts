// ============================================================================
// HS2 DIGITAL TWIN — MAIN ENGINEERING WORKSTATION ROOT COMPONENT
// Sober, dense, precise British civil & railway systems digital engineering platform.
// ============================================================================

import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStoreService, MainNavigationTab } from './services/digital-twin-store.service';
import { Discipline } from './models/digital-twin.types';
import { SHMTelemetryService } from './services/shm-telemetry.service';
import { SpatialTwin3D } from './components/spatial-twin-3d/spatial-twin-3d';
import { RouteProfileView } from './components/route-profile-view/route-profile-view';
import { AssetInspector } from './components/asset-inspector/asset-inspector';
import { Programme4DView } from './components/programme-4d-view/programme-4d-view';
import { CostCarbon5D } from './components/cost-carbon-5d/cost-carbon-5d';
import { RailSystemsView } from './components/rail-systems-view/rail-systems-view';
import { OperationsTelemetryView } from './components/operations-telemetry-view/operations-telemetry-view';
import { ScenarioSandboxView } from './components/scenario-sandbox-view/scenario-sandbox-view';
import { CDEGovernanceView } from './components/cde-governance-view/cde-governance-view';
import { RustArchitectureView } from './components/rust-architecture-view/rust-architecture-view';
import { ReportGeneratorModal } from './components/report-generator-modal/report-generator-modal';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule,
    SpatialTwin3D,
    RouteProfileView,
    AssetInspector,
    Programme4DView,
    CostCarbon5D,
    RailSystemsView,
    OperationsTelemetryView,
    ScenarioSandboxView,
    CDEGovernanceView,
    RustArchitectureView,
    ReportGeneratorModal
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  public store = inject(DigitalTwinStoreService);
  public shmService = inject(SHMTelemetryService);

  public showReportModal = signal<boolean>(false);
  public isSidebarCollapsed = signal<boolean>(false);

  public navItems: { id: MainNavigationTab; label: string; icon: string; badge?: string }[] = [
    { id: 'overview', label: 'Overview & Health', icon: 'dashboard' },
    { id: '3d-twin', label: '3D Spatial Twin', icon: 'view_in_ar', badge: 'WebGL' },
    { id: 'route', label: 'Route & Alignment', icon: 'linear_scale' },
    { id: 'assets', label: 'Asset Register', icon: 'account_tree' },
    { id: 'programme-4d', label: '4D Programme', icon: 'calendar_month', badge: 'Rehearsal' },
    { id: 'cost-carbon-5d', label: '5D Cost & Carbon', icon: 'eco' },
    { id: 'rail-systems', label: 'Rail Systems', icon: 'bolt' },
    { id: 'sensors-shm', label: 'Live Operations & SHM', icon: 'stacked_line_chart', badge: 'Live' },
    { id: 'scenarios', label: 'What-If Scenarios', icon: 'science' },
    { id: 'cde-governance', label: 'CDE & ISO 19650', icon: 'verified_user' },
    { id: 'rust-architecture', label: 'Rust Crates & CLI', icon: 'code' }
  ];

  public onSearchChange(e: Event): void {
    const val = (e.target as HTMLInputElement).value;
    this.store.searchQuery.set(val);
  }

  public onDisciplineFilterChange(e: Event): void {
    const val = (e.target as HTMLSelectElement).value as Discipline | 'ALL';
    this.store.selectedDisciplineFilter.set(val);
  }
}
