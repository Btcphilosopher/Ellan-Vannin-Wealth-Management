// ============================================================================
// LINEAR REFERENCING & GEOSPATIAL ENGINE
// Strict mathematical alignment calculations for High-Speed Rail Corridor
// Chainage <-> BNG OSGB36 Easting/Northing <-> WGS84 Lat/Lng <-> Elevation
// ============================================================================

import { Injectable } from '@angular/core';

export interface AlignmentStationPoint {
  chainage_m: number;
  chainage_formatted: string;
  easting: number;
  northing: number;
  latitude: number;
  longitude: number;
  elevation_m: number;
  gradient_permille: number;
  cant_mm: number;
  radius_m: number; // Infinity for straight
  speed_limit_kmh: number;
  description: string;
}

@Injectable({
  providedIn: 'root'
})
export class LinearReferencingService {
  // Key alignment control points along the 100km Phase 1 corridor
  private readonly ALIGNMENT_WAYPOINTS: AlignmentStationPoint[] = [
    { chainage_m: 0, chainage_formatted: 'CH 00+000', easting: 529500, northing: 182800, latitude: 51.5284, longitude: -0.1332, elevation_m: 24.0, gradient_permille: 0.0, cant_mm: 0, radius_m: Infinity, speed_limit_kmh: 110, description: 'London Euston Terminal' },
    { chainage_m: 7800, chainage_formatted: 'CH 07+800', easting: 521900, northing: 182100, latitude: 51.5238, longitude: -0.2441, elevation_m: 22.4, gradient_permille: 5.2, cant_mm: 40, radius_m: 5200, speed_limit_kmh: 230, description: 'Old Oak Common Super-Hub' },
    { chainage_m: 21500, chainage_formatted: 'CH 21+500', easting: 505700, northing: 188300, latitude: 51.5834, longitude: -0.4782, elevation_m: 48.6, gradient_permille: 3.1, cant_mm: 90, radius_m: 6500, speed_limit_kmh: 360, description: 'Colne Valley Viaduct South' },
    { chainage_m: 24900, chainage_formatted: 'CH 24+900', easting: 502900, northing: 190200, latitude: 51.6001, longitude: -0.5186, elevation_m: 51.2, gradient_permille: -1.2, cant_mm: 90, radius_m: 6500, speed_limit_kmh: 360, description: 'Colne Valley Viaduct North' },
    { chainage_m: 26000, chainage_formatted: 'CH 26+000', easting: 502000, northing: 191000, latitude: 51.6074, longitude: -0.5317, elevation_m: 54.0, gradient_permille: 12.5, cant_mm: 0, radius_m: Infinity, speed_limit_kmh: 360, description: 'Chiltern Tunnel South Portal' },
    { chainage_m: 34200, chainage_formatted: 'CH 34+200', easting: 496100, northing: 198200, latitude: 51.6742, longitude: -0.6124, elevation_m: 110.5, gradient_permille: 8.0, cant_mm: 0, radius_m: Infinity, speed_limit_kmh: 360, description: 'Amersham Vent Shaft & TFS 02' },
    { chainage_m: 42000, chainage_formatted: 'CH 42+000', easting: 490500, northing: 204600, latitude: 51.7328, longitude: -0.6934, elevation_m: 128.0, gradient_permille: -6.4, cant_mm: 0, radius_m: Infinity, speed_limit_kmh: 360, description: 'Chiltern Tunnel North Portal' },
    { chainage_m: 53200, chainage_formatted: 'CH 53+200', easting: 487200, northing: 206400, latitude: 51.7482, longitude: -0.7381, elevation_m: 142.1, gradient_permille: 2.0, cant_mm: 110, radius_m: 5800, speed_limit_kmh: 360, description: 'Wendover Dean Viaduct' },
    { chainage_m: 64500, chainage_formatted: 'CH 64+500', easting: 477400, northing: 215100, latitude: 51.8284, longitude: -0.8765, elevation_m: 104.0, gradient_permille: -4.5, cant_mm: 60, radius_m: 7200, speed_limit_kmh: 360, description: 'Aylesbury Vale Cuttings' },
    { chainage_m: 74500, chainage_formatted: 'CH 74+500', easting: 468900, northing: 223500, latitude: 51.9056, longitude: -0.9984, elevation_m: 88.0, gradient_permille: 1.0, cant_mm: 0, radius_m: Infinity, speed_limit_kmh: 360, description: 'Calvert Deep Cutting & Infrastructure Maintenance Depot' },
    { chainage_m: 85000, chainage_formatted: 'CH 85+000', easting: 442500, northing: 248600, latitude: 52.1332, longitude: -1.3780, elevation_m: 115.0, gradient_permille: 6.0, cant_mm: 120, radius_m: 5400, speed_limit_kmh: 360, description: 'Burton Green Tunnel' },
    { chainage_m: 92000, chainage_formatted: 'CH 92+000', easting: 418900, northing: 283500, latitude: 52.4491, longitude: -1.7225, elevation_m: 95.0, gradient_permille: -3.2, cant_mm: 80, radius_m: 6000, speed_limit_kmh: 360, description: 'Birmingham Interchange Station' },
    { chainage_m: 98500, chainage_formatted: 'CH 98+500', easting: 407700, northing: 286800, latitude: 52.4795, longitude: -1.8872, elevation_m: 98.6, gradient_permille: 0.0, cant_mm: 0, radius_m: Infinity, speed_limit_kmh: 140, description: 'Birmingham Curzon Street Terminal' },
    { chainage_m: 100000, chainage_formatted: 'CH 100+000', easting: 405500, northing: 288200, latitude: 52.4920, longitude: -1.9180, elevation_m: 94.0, gradient_permille: 0.0, cant_mm: 0, radius_m: Infinity, speed_limit_kmh: 110, description: 'Handsacre Junction Main Line Connection' }
  ];

  /**
   * Calculate exact track geometry and spatial coordinates for any given chainage
   */
  public getPointAtChainage(chainage_m: number): AlignmentStationPoint {
    const clampedCh = Math.max(0, Math.min(100000, chainage_m));

    // Find bounding waypoints
    let idx = 0;
    for (let i = 0; i < this.ALIGNMENT_WAYPOINTS.length - 1; i++) {
      if (clampedCh >= this.ALIGNMENT_WAYPOINTS[i].chainage_m && clampedCh <= this.ALIGNMENT_WAYPOINTS[i + 1].chainage_m) {
        idx = i;
        break;
      }
    }

    const p0 = this.ALIGNMENT_WAYPOINTS[idx];
    const p1 = this.ALIGNMENT_WAYPOINTS[Math.min(idx + 1, this.ALIGNMENT_WAYPOINTS.length - 1)];

    const span = p1.chainage_m - p0.chainage_m;
    const t = span > 0 ? (clampedCh - p0.chainage_m) / span : 0;

    // Cubic smooth interpolation for Easting/Northing/Lat/Lng
    const smoothT = t * t * (3 - 2 * t);

    const easting = p0.easting + (p1.easting - p0.easting) * smoothT;
    const northing = p0.northing + (p1.northing - p0.northing) * smoothT;
    const latitude = p0.latitude + (p1.latitude - p0.latitude) * smoothT;
    const longitude = p0.longitude + (p1.longitude - p0.longitude) * smoothT;
    const elevation_m = p0.elevation_m + (p1.elevation_m - p0.elevation_m) * t;
    const gradient_permille = p0.gradient_permille + (p1.gradient_permille - p0.gradient_permille) * t;
    const cant_mm = p0.cant_mm + (p1.cant_mm - p0.cant_mm) * t;
    const speed_limit_kmh = p0.speed_limit_kmh + (p1.speed_limit_kmh - p0.speed_limit_kmh) * t;
    const radius_m = t < 0.5 ? p0.radius_m : p1.radius_m;

    return {
      chainage_m: clampedCh,
      chainage_formatted: this.formatChainage(clampedCh),
      easting,
      northing,
      latitude,
      longitude,
      elevation_m,
      gradient_permille,
      cant_mm,
      radius_m,
      speed_limit_kmh: Math.round(speed_limit_kmh),
      description: `Chainage ${this.formatChainage(clampedCh)} (${p0.description} -> ${p1.description})`
    };
  }

  /**
   * Format chainage meters into standard UK engineering notation (e.g. 43250 -> "CH 43+250")
   */
  public formatChainage(meters: number): string {
    const km = Math.floor(meters / 1000);
    const m = Math.floor(meters % 1000);
    const kmStr = km < 10 ? `0${km}` : `${km}`;
    const mStr = m < 10 ? `00${m}` : m < 100 ? `0${m}` : `${m}`;
    return `CH ${kmStr}+${mStr}`;
  }

  /**
   * Parse engineering chainage notation (e.g. "43+250" or "CH 43+250" or 43.25) into meters
   */
  public parseChainage(input: string): number {
    const clean = input.replace(/CH/i, '').trim();
    if (clean.includes('+')) {
      const parts = clean.split('+');
      const km = parseFloat(parts[0]) || 0;
      const m = parseFloat(parts[1]) || 0;
      return km * 1000 + m;
    }
    const val = parseFloat(clean);
    if (!isNaN(val)) {
      return val > 1000 ? val : val * 1000;
    }
    return 0;
  }

  /**
   * Calculate Cant Deficiency (I) in mm:
   * I = (11.82 * V^2 / R) - D
   * where V is speed in km/h, R is curve radius in meters, D is applied cant in mm.
   */
  public calculateCantDeficiency(speed_kmh: number, radius_m: number, cant_mm: number): number {
    if (radius_m === Infinity || radius_m <= 0) return 0;
    const theoreticalCant = (11.82 * Math.pow(speed_kmh, 2)) / radius_m;
    return Math.max(0, theoreticalCant - cant_mm);
  }

  /**
   * Find nearest route chainage from given WGS84 Coordinates
   */
  public worldPositionToChainage(lat: number, lng: number): { chainage_m: number; distance_offset_m: number } {
    let bestCh = 0;
    let minSqDist = Infinity;

    // Coarse scan along 100km corridor in 500m steps
    for (let ch = 0; ch <= 100000; ch += 500) {
      const pt = this.getPointAtChainage(ch);
      const dLat = pt.latitude - lat;
      const dLng = pt.longitude - lng;
      const sqDist = dLat * dLat + dLng * dLng;
      if (sqDist < minSqDist) {
        minSqDist = sqDist;
        bestCh = ch;
      }
    }

    // Fine scan in 5m steps
    let refinedCh = bestCh;
    for (let ch = Math.max(0, bestCh - 600); ch <= Math.min(100000, bestCh + 600); ch += 5) {
      const pt = this.getPointAtChainage(ch);
      const dLat = pt.latitude - lat;
      const dLng = pt.longitude - lng;
      const sqDist = dLat * dLat + dLng * dLng;
      if (sqDist < minSqDist) {
        minSqDist = sqDist;
        refinedCh = ch;
      }
    }

    const approxOffsetMeters = Math.sqrt(minSqDist) * 111000;
    return { chainage_m: refinedCh, distance_offset_m: approxOffsetMeters };
  }

  /**
   * Retrieve all alignment waypoints for synoptic chart generation
   */
  public getAlignmentWaypoints(): AlignmentStationPoint[] {
    return this.ALIGNMENT_WAYPOINTS;
  }
}
