// ============================================================================
// WHAT-IF SCENARIO & IMPACT PROPAGATION ENGINE
// Clones the digital twin state, applies perturbations, traverses the
// dependency graph (CIVILS -> TRACK -> OLE -> POWER -> SIGNALLING -> TRAINS),
// and outputs explainable multi-discipline impact propagation.
// ============================================================================

import { Injectable, signal, computed, inject } from '@angular/core';
import { SimulationScenario } from '../models/digital-twin.types';
import { SYNTHETIC_SCENARIOS } from './synthetic-hs2-corridor.data';
import { SHMTelemetryService } from './shm-telemetry.service';

export interface ScenarioExecutionStep {
  step_number: number;
  phase_name: string;
  trigger_time_offset_min: number;
  description: string;
  affected_asset_name: string;
  system_response: string;
  operational_impact: string;
  decision_rule: string;
  completed: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class ScenarioEngineService {
  private shmService = inject(SHMTelemetryService);

  public scenarios = signal<SimulationScenario[]>(SYNTHETIC_SCENARIOS);
  public activeScenarioId = signal<string | null>(null);
  public activeScenarioSteps = signal<ScenarioExecutionStep[]>([]);
  public currentStepIndex = signal<number>(0);
  public isRehearsalPlaying = signal<boolean>(false);

  private playbackTimer: ReturnType<typeof setInterval> | null = null;

  public activeScenario = computed(() => {
    const id = this.activeScenarioId();
    if (!id) return null;
    return this.scenarios().find(s => s.scenario_id === id) || null;
  });

  /**
   * Activate and run a specific scenario
   */
  public selectScenario(scenarioId: string): void {
    this.activeScenarioId.set(scenarioId);
    this.currentStepIndex.set(0);
    this.stopPlayback();

    const scenario = this.scenarios().find(s => s.scenario_id === scenarioId);
    if (!scenario) return;

    if (scenarioId === 'SCN-FLOOD-CALVERT-01') {
      this.activeScenarioSteps.set([
        {
          step_number: 1,
          phase_name: 'ENVIRONMENTAL SURGE',
          trigger_time_offset_min: 0,
          description: 'Intense 35 mm/h convective cloudburst over Buckinghamshire Oxford Clay cutting.',
          affected_asset_name: 'Calvert Clay Cutting & Earthworks Slopes (CIV-CUT-CALVERT-01)',
          system_response: 'Weather station WXT536 logs 35mm/h precipitation rate. Crest drainage culvert capacity reaches 92%.',
          operational_impact: 'All trains operating under nominal 360 km/h speed.',
          decision_rule: 'RULE-ENV-001: Precipitation > 25 mm/h raises geotechnical sensor polling frequency to 10 seconds.',
          completed: true
        },
        {
          step_number: 2,
          phase_name: 'GEOTECHNICAL ANOMALY TRIGGER',
          trigger_time_offset_min: 15,
          description: 'Pore water pressure in shear plane increases to 52.4 kPa. EWMA envelope breached.',
          affected_asset_name: 'Piezometer VW2100 (SENS-PIEZO-CALVERT-01)',
          system_response: 'CUSUM statistic crosses 0.75 threshold. Digital Twin issues Stage 1 Geotechnical Amber Warning.',
          operational_impact: 'Factor of safety drops from 1.48 to 1.29.',
          decision_rule: 'RULE-GEO-004: Pore pressure > 50 kPa requires automatic precautionary speed restriction calculation.',
          completed: false
        },
        {
          step_number: 3,
          phase_name: 'AUTOMATED OPERATIONAL RESTRICTION (TSR)',
          trigger_time_offset_min: 22,
          description: 'ETCS Radio Block Centre RBC-02 transmits Dynamic Temporary Speed Restriction (TSR 80 km/h) from CH 73+000 to CH 77+000.',
          affected_asset_name: 'Chilterns Route Radio Block Centre (SIG-RBC-CHILTERNS-01)',
          system_response: 'Train on-board ETCS DMI displays 80 km/h braking intervention curve. Train 1Z14 decelerates automatically.',
          operational_impact: 'Down line train delay +6.4 minutes. Timetable conflict resolution algorithm adjusts headway.',
          decision_rule: 'RULE-OPS-012: SIL 4 ETCS dynamic MA update broadcast to all approaching train units.',
          completed: false
        },
        {
          step_number: 4,
          phase_name: 'EMERGENCY MAINTENANCE DISPATCH',
          trigger_time_offset_min: 40,
          description: 'Calvert Infrastructure Maintenance Depot deploys civils response crew to inspect drainage outfall and clear culvert weir.',
          affected_asset_name: 'Calvert Infrastructure Maintenance Depot (CIV-CUT-CALVERT-01)',
          system_response: 'Work order WO-2026-981 dispatched. Handheld mobile digital twin logs weir clearance & auxiliary pump activation.',
          operational_impact: 'Pore water pressure begins downward dissipation slope (-1.4 kPa/h).',
          decision_rule: 'RULE-MNT-008: Physical inspection mandatory before TSR speed elevation.',
          completed: false
        },
        {
          step_number: 5,
          phase_name: 'VERIFICATION & RETURN TO NOMINAL SPEED',
          trigger_time_offset_min: 75,
          description: 'Pore pressure dissipates below 48 kPa. Principal Geotechnical Engineer signs off digital twin inspection certificate.',
          affected_asset_name: 'Calvert Clay Cutting & Earthworks Slopes (CIV-CUT-CALVERT-01)',
          system_response: 'RBC-02 withdraws TSR 80 km/h restriction. Nominal 360 km/h line speed restored.',
          operational_impact: 'Full timetable recovery within 2 service cycles. Complete audit record generated.',
          decision_rule: 'RULE-GEO-009: Factor of safety >= 1.45 verified via sensor baseline reconciliation.',
          completed: false
        }
      ]);

      // Inject anomaly reading to sensor
      this.shmService.injectAnomaly('SENS-PIEZO-CALVERT-01', 54.2);
    } else if (scenarioId === 'SCN-POWER-OUTAGE-02') {
      this.activeScenarioSteps.set([
        {
          step_number: 1,
          phase_name: 'GRID BULK SUPPLY INFEED TRIP',
          trigger_time_offset_min: 0,
          description: 'National Grid 400kV supply circuit tripped at Amersham TFS 02 due to external transmission line fault.',
          affected_asset_name: 'Amersham Main Traction Feeder Substation (POW-SUB-AMERSHAM-01)',
          system_response: 'Primary 52kV circuit breakers open on under-voltage protection (T < 40ms).',
          operational_impact: 'Chiltern Tunnel 25kV catenary section unpowered.',
          decision_rule: 'RULE-POW-002: Loss of primary infeed triggers SCADA auto-transfer sequence.',
          completed: true
        },
        {
          step_number: 2,
          phase_name: 'AUTO-RECLOSE & FEEDING ZONE EXTENSION',
          trigger_time_offset_min: 2,
          description: 'Motorized sectioning switch at Neutral Section CH 48+000 closes, bridging traction load to Calvert Substation TFS 03.',
          affected_asset_name: 'Overhead Line Neutral Section (OLE-PORTAL-CVV-P28)',
          system_response: '25kV power restored to Chiltern Tunnel catenary in 1.4 seconds.',
          operational_impact: 'Pantograph voltage dips to 23.4 kV (above 22.5 kV TSI minimum limit).',
          decision_rule: 'RULE-POW-005: Extended feeding zone mode active with train acceleration power limiting.',
          completed: false
        },
        {
          step_number: 3,
          phase_name: 'TRAIN ACCELERATION POWER CAPPING',
          trigger_time_offset_min: 5,
          description: 'Signalling & Traffic Management System limits simultaneous 360 km/h train acceleration draw to 8.0 MW per unit.',
          affected_asset_name: 'High-Speed Train Fleet Class 895 (TRN-895-001)',
          system_response: 'Substation thermal load stabilized at 84% on Calvert TFS.',
          operational_impact: 'Train delay +2.1 minutes.',
          decision_rule: 'RULE-OPS-022: Dynamic traction power shedding avoids secondary substation overload.',
          completed: false
        }
      ]);
    } else {
      this.activeScenarioSteps.set([
        {
          step_number: 1,
          phase_name: 'CLIMATE TEMPERATURE ELEVATION',
          trigger_time_offset_min: 0,
          description: 'Ambient air temperature reaches 41°C. Un-shaded slab track rail surface heats to 61°C.',
          affected_asset_name: 'Up Line Non-Ballasted Slab Track (TRK-SLAB-CVV-UP)',
          system_response: 'Embedded fiber DTS temp sensor triggers Critical Rail Temperature alert (CRT 59°C).',
          operational_impact: 'Longitudinal compressive stress reaches -82.4 MPa.',
          decision_rule: 'RULE-TRK-003: Rail temperature > CRT imposes 160 km/h speed restriction.',
          completed: true
        },
        {
          step_number: 2,
          phase_name: 'PRECAUTIONARY SPEED RESTRICTION & OLE SAG AUDIT',
          trigger_time_offset_min: 15,
          description: 'ETCS Level 2 enforces 160 km/h restriction across Colne Valley Viaduct.',
          affected_asset_name: 'Colne Valley Viaduct (CIV-VIAD-COLNE-01)',
          system_response: 'OLE auto-tensioner weights monitored to ensure contact wire stagger remains within ±200mm.',
          operational_impact: 'Service delay +8.8 minutes. Drone inspection launched.',
          decision_rule: 'RULE-OPS-030: Heatwave operational protocol Level 3.',
          completed: false
        }
      ]);
    }
  }

  public nextStep(): void {
    const current = this.currentStepIndex();
    const steps = [...this.activeScenarioSteps()];
    if (current < steps.length - 1) {
      steps[current].completed = true;
      this.currentStepIndex.set(current + 1);
      steps[current + 1].completed = true;
      this.activeScenarioSteps.set(steps);
    } else {
      this.stopPlayback();
    }
  }

  public togglePlayback(): void {
    if (this.isRehearsalPlaying()) {
      this.stopPlayback();
    } else {
      this.startPlayback();
    }
  }

  public startPlayback(): void {
    this.isRehearsalPlaying.set(true);
    if (this.playbackTimer) clearInterval(this.playbackTimer);

    this.playbackTimer = setInterval(() => {
      const idx = this.currentStepIndex();
      const steps = this.activeScenarioSteps();
      if (idx < steps.length - 1) {
        this.nextStep();
      } else {
        this.stopPlayback();
      }
    }, 4000);
  }

  public stopPlayback(): void {
    this.isRehearsalPlaying.set(false);
    if (this.playbackTimer) {
      clearInterval(this.playbackTimer);
      this.playbackTimer = null;
    }
  }

  public resetScenario(): void {
    this.stopPlayback();
    this.activeScenarioId.set(null);
    this.activeScenarioSteps.set([]);
    this.currentStepIndex.set(0);
    this.shmService.resetToBaseline();
  }
}
