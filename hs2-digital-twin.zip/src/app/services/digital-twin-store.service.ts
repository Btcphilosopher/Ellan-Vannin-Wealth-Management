// ============================================================================
// MASTER DIGITAL TWIN REACTIVE STATE STORE
// Central domain hub coordinating Assets, Linear Referencing, 4D Time Machine,
// 3D Visualizer layers, Physics Kinematics, CDE Documents & System Logs.
// ============================================================================

import { Injectable, signal, computed, inject } from '@angular/core';
import {
  Asset,
  AssetId,
  Discipline,
  LifecycleState,
  TrainDigitalTwin,
  ConstructionActivity,
  AssetCostCarbon,
  Defect,
  TestingCommissioningItem,
  MaintenanceRecord,
  CDEDocument,
  DigitalTwinEvent,
  TwinDataQualityManifest
} from '../models/digital-twin.types';

import {
  SYNTHETIC_CORRIDOR_ASSETS,
  SYNTHETIC_TRAINS,
  SYNTHETIC_CONSTRUCTION_PROGRAMME,
  SYNTHETIC_COST_CARBON,
  SYNTHETIC_DEFECTS,
  SYNTHETIC_TESTS,
  SYNTHETIC_MAINTENANCE,
  SYNTHETIC_CDE_DOCUMENTS,
  SYNTHETIC_EVENTS,
  SYNTHETIC_QUALITY_MANIFEST
} from './synthetic-hs2-corridor.data';

import { LinearReferencingService } from './linear-referencing.service';
import { PhysicsSimulationService } from './physics-simulation.service';

export interface LayerVisibilityState {
  civils: boolean;
  track: boolean;
  ole: boolean;
  power: boolean;
  signalling: boolean;
  telecoms: boolean;
  stations: boolean;
  tunnels: boolean;
  drainage: boolean;
  environment: boolean;
  sensors: boolean;
  trains: boolean;
  terrain: boolean;
}

export type MainNavigationTab =
  | 'overview'
  | 'route'
  | '3d-twin'
  | 'assets'
  | 'programme-4d'
  | 'cost-carbon-5d'
  | 'rail-systems'
  | 'sensors-shm'
  | 'operations'
  | 'maintenance'
  | 'testing'
  | 'scenarios'
  | 'cde-governance'
  | 'reports'
  | 'rust-architecture';

@Injectable({
  providedIn: 'root'
})
export class DigitalTwinStoreService {
  private linearRefService = inject(LinearReferencingService);
  private physicsService = inject(PhysicsSimulationService);

  // Active View Tab
  public activeTab = signal<MainNavigationTab>('overview');

  // Master Entity Collections
  public assets = signal<Asset[]>(SYNTHETIC_CORRIDOR_ASSETS);
  public trains = signal<TrainDigitalTwin[]>(SYNTHETIC_TRAINS);
  public programme = signal<ConstructionActivity[]>(SYNTHETIC_CONSTRUCTION_PROGRAMME);
  public costCarbon = signal<AssetCostCarbon[]>(SYNTHETIC_COST_CARBON);
  public defects = signal<Defect[]>(SYNTHETIC_DEFECTS);
  public tests = signal<TestingCommissioningItem[]>(SYNTHETIC_TESTS);
  public maintenance = signal<MaintenanceRecord[]>(SYNTHETIC_MAINTENANCE);
  public documents = signal<CDEDocument[]>(SYNTHETIC_CDE_DOCUMENTS);
  public events = signal<DigitalTwinEvent[]>(SYNTHETIC_EVENTS);
  public qualityManifest = signal<TwinDataQualityManifest>(SYNTHETIC_QUALITY_MANIFEST);

  // Selected State
  public selectedAssetId = signal<AssetId | null>('CIV-VIAD-COLNE-01');
  public currentChainageM = signal<number>(22800); // Default around Colne Valley / P28
  public timeSliderYear = signal<number>(2026.75); // 4D Time slider (2022.0 to 2030.0)
  public isTimeReplayPlaying = signal<boolean>(false);

  // Search & Filter State
  public searchQuery = signal<string>('');
  public selectedDisciplineFilter = signal<Discipline | 'ALL'>('ALL');
  public selectedLifecycleFilter = signal<LifecycleState | 'ALL'>('ALL');

  // 3D Viewport Layer Visibility
  public layers = signal<LayerVisibilityState>({
    civils: true,
    track: true,
    ole: true,
    power: true,
    signalling: true,
    telecoms: true,
    stations: true,
    tunnels: true,
    drainage: true,
    environment: true,
    sensors: true,
    trains: true,
    terrain: true
  });

  // Derived Computed Signals
  public selectedAsset = computed(() => {
    const id = this.selectedAssetId();
    if (!id) return null;
    return this.assets().find(a => a.asset_id === id) || null;
  });

  public filteredAssets = computed(() => {
    const query = this.searchQuery().toLowerCase().trim();
    const disc = this.selectedDisciplineFilter();
    const life = this.selectedLifecycleFilter();

    return this.assets().filter(a => {
      if (disc !== 'ALL' && a.discipline !== disc) return false;
      if (life !== 'ALL' && a.lifecycle_state !== life) return false;
      if (!query) return true;

      return (
        a.name.toLowerCase().includes(query) ||
        a.asset_id.toLowerCase().includes(query) ||
        a.uniclass_code.toLowerCase().includes(query) ||
        a.location.chainage_formatted.toLowerCase().includes(query)
      );
    });
  });

  public currentChainagePoint = computed(() => {
    return this.linearRefService.getPointAtChainage(this.currentChainageM());
  });

  public assetsNearCurrentChainage = computed(() => {
    const ch = this.currentChainageM();
    const radius = 2500; // 2.5 km inspection window
    return this.assets().filter(a => Math.abs(a.location.chainage_m - ch) <= radius);
  });

  // Live Simulation Timer
  private simulationInterval: ReturnType<typeof setInterval> | null = null;
  private timeReplayInterval: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.startLiveSimulation();
  }

  /**
   * Continuous train simulation loop running Davis TPM physics
   */
  private startLiveSimulation(): void {
    if (this.simulationInterval) clearInterval(this.simulationInterval);

    this.simulationInterval = setInterval(() => {
      const currentTrains = this.trains();
      const updated = currentTrains.map(trn => {
        const pt = this.linearRefService.getPointAtChainage(trn.current_chainage_m);
        const result = this.physicsService.simulateTrainStep(
          trn,
          pt.speed_limit_kmh,
          pt.gradient_permille,
          pt.radius_m,
          1.0
        );

        // Wrap around corridor bounds (0 to 100km)
        let ch = result.new_chainage_m;
        let speed = result.new_speed_kmh;
        if (ch >= 99500) {
          ch = 1000;
          speed = 90;
        }

        return {
          ...trn,
          current_chainage_m: ch,
          current_speed_kmh: Math.round(speed * 10) / 10,
          acceleration_ms2: result.acceleration_ms2,
          power_draw_mw: result.electrical_power_mw,
          regenerative_braking_mw: result.regenerative_power_mw,
          pantograph_voltage_kv: result.pantograph_voltage_kv,
          traction_current_a: result.traction_current_a
        };
      });

      this.trains.set(updated);
    }, 1000);
  }

  // --------------------------------------------------------------------------
  // ACTION DISPATCHERS
  // --------------------------------------------------------------------------

  public selectAsset(assetId: AssetId): void {
    this.selectedAssetId.set(assetId);
    const asset = this.assets().find(a => a.asset_id === assetId);
    if (asset) {
      this.currentChainageM.set(asset.location.chainage_m);
    }
  }

  public setChainage(chainage_m: number): void {
    this.currentChainageM.set(Math.max(0, Math.min(100000, chainage_m)));
  }

  public toggleLayer(layerKey: keyof LayerVisibilityState): void {
    this.layers.update(l => ({ ...l, [layerKey]: !l[layerKey] }));
  }

  public setTimeSlider(year: number): void {
    this.timeSliderYear.set(year);
  }

  public toggleTimeReplay(): void {
    if (this.isTimeReplayPlaying()) {
      this.isTimeReplayPlaying.set(false);
      if (this.timeReplayInterval) clearInterval(this.timeReplayInterval);
    } else {
      this.isTimeReplayPlaying.set(true);
      this.timeReplayInterval = setInterval(() => {
        let yr = this.timeSliderYear() + 0.05;
        if (yr > 2030.0) yr = 2022.0;
        this.timeSliderYear.set(Math.round(yr * 100) / 100);
      }, 300);
    }
  }

  public setTab(tab: MainNavigationTab): void {
    this.activeTab.set(tab);
  }

  public addAuditEvent(event: DigitalTwinEvent): void {
    this.events.update(list => [event, ...list]);
  }
}
