// ============================================================================
// SYNTHETIC HS2-LIKE DEMONSTRATION DATASET
// Label: SYNTHETIC HS2-LIKE DEMONSTRATION DATA — NOT OFFICIAL HS2 DATA
// Covers 100 km High-Speed Corridor: London Old Oak Common -> Birmingham Curzon St
// ============================================================================

import {
  Asset,
  CDEDocument,
  ConstructionActivity,
  AssetCostCarbon,
  Defect,
  DigitalTwinEvent,
  MaintenanceRecord,
  Sensor,
  SimulationScenario,
  TestingCommissioningItem,
  TrainDigitalTwin,
  TwinDataQualityManifest
} from '../models/digital-twin.types';

export const SYNTHETIC_CORRIDOR_ASSETS: Asset[] = [
  // --------------------------------------------------------------------------
  // ROUTE LEVEL 1 - PROGRAMME HIERARCHY
  // --------------------------------------------------------------------------
  {
    asset_id: 'HS2-PHASE1-CORRIDOR',
    parent_id: null,
    asset_class: 'track',
    discipline: 'CIVILS',
    name: 'HS2 Phase One Main Line (London to West Midlands)',
    description: '100 km High-Speed Railway Corridor twin route from London Euston / Old Oak Common to Birmingham Curzon Street and Handsacre junction.',
    uniclass_code: 'Co_20_20_75 Railway infrastructure entity',
    geometry: {
      mesh_type: 'spline',
      lod: 'LOD300',
      dimensions: { length_m: 100000, width_m: 14, height_m: 8 }
    },
    location: {
      latitude: 51.5834,
      longitude: -0.4782,
      elevation_m: 45.2,
      bng_easting: 505700,
      bng_northing: 188300,
      chainage_m: 0,
      chainage_formatted: 'CH 00+000',
      offset_m: 0,
      route_section_id: 'SEC-ALL-PHASE1'
    },
    lifecycle_state: 'UNDER_CONSTRUCTION',
    information_status: 'PUBLISHED',
    confidence: 0.98,
    validation_status: 'VALIDATED',
    properties: {
      'Route Length (km)': 100.0,
      'Design Speed (km/h)': 360,
      'Track Gauge (mm)': 1435,
      'Electrification': '25kV 50Hz AC Autotransformer (AT)',
      'Signalling': 'ETCS Level 2 Baseline 3 without line-side signals',
      'Structural Design Life (years)': 120
    },
    engineering_parameters: {
      'Alignment Max Speed': { value: 360, unit: 'km/h', description: 'Design maximum revenue operational speed' },
      'Minimum Horizontal Radius': { value: 4900, unit: 'm', description: 'Exceptional minimum horizontal curve radius' },
      'Maximum Cant': { value: 150, unit: 'mm', description: 'Maximum applied cross-level on curves' },
      'Maximum Gradient': { value: 25, unit: 'permille', description: 'Maximum sustained gradient' }
    },
    relationships: [
      { target_id: 'SEC-LONDON-OOC', relationship_type: 'CONTAINS', confidence: 1.0 },
      { target_id: 'SEC-COLNE-VALLEY', relationship_type: 'CONTAINS', confidence: 1.0 },
      { target_id: 'SEC-CHILTERNS-TUNNEL', relationship_type: 'CONTAINS', confidence: 1.0 },
      { target_id: 'SEC-CALVERT-DEPOT', relationship_type: 'CONTAINS', confidence: 1.0 },
      { target_id: 'SEC-BIRMINGHAM-CURZON', relationship_type: 'CONTAINS', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'Bentley ProjectWise / OpenRail Master Alignment',
      source_document_id: '1MC01-SYS-MAP-000001',
      source_object_id: 'ALIGNMENT-MAIN-001',
      revision: 'P07.0',
      author: 'High Speed Two Systems Integration Directorate',
      created_at: '2024-01-15T09:00:00Z',
      approved_by: 'Chief Railway Engineer',
      approval_date: '2024-02-01T14:30:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2024-01-01',
    last_observed: '2026-09-30T04:00:00Z',
    last_updated: '2026-09-30T04:00:00Z'
  },

  // --------------------------------------------------------------------------
  // KEY CIVILS STRUCTURE 1: COLNE VALLEY VIADUCT (CH 21+500 to CH 24+900)
  // --------------------------------------------------------------------------
  {
    asset_id: 'CIV-VIAD-COLNE-01',
    parent_id: 'HS2-PHASE1-CORRIDOR',
    asset_class: 'viaduct',
    discipline: 'CIVILS',
    name: 'Colne Valley Viaduct',
    description: '3.4 km landmark viaduct carrying high-speed tracks over Colne Valley regional park lakes, River Colne and Grand Union Canal on 56 post-tensioned spans.',
    uniclass_code: 'Pr_20_29_89_92 Precast concrete viaduct deck systems',
    geometry: {
      bim_guid: '3mB8Q$zF59rQz1dK9eLmXy',
      model_file: '1MC04-ALN-CIV-MOD-CVV-001.ifc',
      lod: 'LOD400',
      mesh_type: 'viaduct_span',
      dimensions: { length_m: 3400, width_m: 13.8, height_m: 12.5 }
    },
    location: {
      latitude: 51.5834,
      longitude: -0.4782,
      elevation_m: 48.6,
      bng_easting: 505700,
      bng_northing: 188300,
      chainage_m: 21500,
      chainage_formatted: 'CH 21+500',
      offset_m: 0,
      route_section_id: 'SEC-COLNE-VALLEY'
    },
    lifecycle_state: 'AS_BUILT',
    information_status: 'PUBLISHED',
    confidence: 0.99,
    validation_status: 'VALIDATED',
    properties: {
      'Total Spans': 56,
      'Precast Segments': 1000,
      'Max Pier Height (m)': 14.2,
      'Concrete Mix': 'C50/60 CEM III Low Carbon GGBS',
      'Expansion Joints': 'Modular Finger Joints (Maurer D160)',
      'Noise Barrier Height (m)': 4.0
    },
    engineering_parameters: {
      'Deck Natural Frequency': { value: 2.84, unit: 'Hz', description: 'First vertical bending mode natural frequency' },
      'Maximum Mid-Span Deflection': { value: 6.8, unit: 'mm', description: 'Static deflection under dual Class 895 full payload' },
      'Post-Tensioning Force': { value: 48500, unit: 'kN', description: 'Total longitudinal internal tendon pre-stress' },
      'Pier Foundation Settlement': { value: 1.9, unit: 'mm', description: 'Long-term measured cumulative settlement' }
    },
    relationships: [
      { target_id: 'TRK-SLAB-CVV-UP', relationship_type: 'CONTAINS', confidence: 1.0 },
      { target_id: 'TRK-SLAB-CVV-DN', relationship_type: 'CONTAINS', confidence: 1.0 },
      { target_id: 'OLE-PORTAL-CVV-P28', relationship_type: 'CONTAINS', confidence: 1.0 },
      { target_id: 'SENS-SHM-CVV-PIER28', relationship_type: 'MONITORED_BY', confidence: 1.0 },
      { target_id: 'ENV-NOISE-CVV-01', relationship_type: 'PROTECTS', confidence: 0.95 }
    ],
    provenance: {
      source_system: 'Bentley ProjectWise / Revit 2026',
      source_document_id: '1MC04-ALN-CIV-DWG-CS04-00421',
      source_object_id: 'VIADUCT-CVV-SUPERSTRUCTURE',
      revision: 'P05.0',
      author: 'Align JV (Bouygues Travaux Publics / Sir Robert McAlpine)',
      created_at: '2024-06-12T11:00:00Z',
      approved_by: 'Lead Structural Engineer (MICE/FIStructE)',
      approval_date: '2024-07-01T16:00:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2023-04-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  },

  // --------------------------------------------------------------------------
  // KEY CIVILS STRUCTURE 2: CHILTERN TUNNEL NORTH & SOUTH BORES (CH 26+000 to CH 42+000)
  // --------------------------------------------------------------------------
  {
    asset_id: 'CIV-TUNN-CHILTERN-01',
    parent_id: 'HS2-PHASE1-CORRIDOR',
    asset_class: 'tunnel',
    discipline: 'TUNNELS',
    name: 'Chiltern Tunnel Twin-Bore System',
    description: '16.0 km twin-bore high-speed rail tunnel through the Chiltern chalk hills, excavated by TBMs Florence & Cecilia with 38 cross-passages and 5 ventilation shafts.',
    uniclass_code: 'Pr_20_29_89_89 Bored tunnel segment ring systems',
    geometry: {
      bim_guid: '7vA12$kR89wPt4bN8xZcWp',
      model_file: '1MC04-ALN-TUN-MOD-CHT-001.ifc',
      lod: 'LOD400',
      mesh_type: 'tunnel_tube',
      dimensions: { length_m: 16040, radius_m: 4.55, width_m: 9.1, height_m: 9.1 }
    },
    location: {
      latitude: 51.6421,
      longitude: -0.5843,
      elevation_m: 82.4,
      bng_easting: 498300,
      bng_northing: 194800,
      chainage_m: 26000,
      chainage_formatted: 'CH 26+000',
      offset_m: 0,
      route_section_id: 'SEC-CHILTERNS-TUNNEL'
    },
    lifecycle_state: 'COMMISSIONED',
    information_status: 'PUBLISHED',
    confidence: 0.99,
    validation_status: 'VALIDATED',
    properties: {
      'Internal Diameter (m)': 9.1,
      'External Diameter (m)': 9.9,
      'Precast Concrete Rings': 112000,
      'Cross-Passage Spacing (m)': 500,
      'Ventilation Shafts': 'Chalfont St Peter, Chalfont St Giles, Amersham, Little Missenden, Chesham Road',
      'Emergency Egress Walkway': 'Elevated continuous lighted walkway (1.2m width)'
    },
    engineering_parameters: {
      'Maximum Hydrostatic Pressure': { value: 3.4, unit: 'bar', description: 'Peak groundwater pressure in Upper Chalk aquifer' },
      'Lining Ovalisation Convergence': { value: 2.1, unit: 'mm', description: 'Measured diametrical deformation (< 10mm limit)' },
      'Piston Micro-Pressure Wave Attenuation': { value: 0.88, unit: 'ratio', description: 'Sonic boom hood pressure dissipation factor' },
      'Ventilation In-Tunnel Air Speed': { value: 4.2, unit: 'm/s', description: 'Forced longitudinal ventilation airflow' }
    },
    relationships: [
      { target_id: 'TRK-SLAB-CHILTERN-NORTH', relationship_type: 'CONTAINS', confidence: 1.0 },
      { target_id: 'TRK-SLAB-CHILTERN-SOUTH', relationship_type: 'CONTAINS', confidence: 1.0 },
      { target_id: 'OLE-RIGID-CHILTERN', relationship_type: 'CONTAINS', confidence: 1.0 },
      { target_id: 'SENS-DTS-CHILTERN-FIBRE', relationship_type: 'MONITORED_BY', confidence: 1.0 },
      { target_id: 'TEL-FRMCS-CHILTERN-LEAKY', relationship_type: 'CONTAINS', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'Bentley ProjectWise / Tunnel CAD 3D',
      source_document_id: '1MC04-ALN-TUN-DWG-00812',
      source_object_id: 'TUNNEL-CHILTERN-TWINBORE',
      revision: 'P06.1',
      author: 'Align JV Tunnel Engineering Division',
      created_at: '2024-08-20T10:30:00Z',
      approved_by: 'Principal Tunnelling Specialist',
      approval_date: '2024-09-01T15:00:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2022-01-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  },

  // --------------------------------------------------------------------------
  // KEY CIVILS STRUCTURE 3: WENDOVER DEAN VIADUCT (CH 53+200 to CH 53+650)
  // --------------------------------------------------------------------------
  {
    asset_id: 'CIV-VIAD-WENDOVER-01',
    parent_id: 'HS2-PHASE1-CORRIDOR',
    asset_class: 'viaduct',
    discipline: 'CIVILS',
    name: 'Wendover Dean Double-Composite Viaduct',
    description: '450m slim double-composite steel-concrete viaduct with hollow piers reducing embodied carbon by 7,400 tonnes CO2e.',
    uniclass_code: 'Pr_20_29_89_91 Composite steel-concrete bridge systems',
    geometry: {
      bim_guid: '9xK33$mW78yQv1cL4vNmBb',
      model_file: '1MC05-EKF-CIV-MOD-WDV-001.ifc',
      lod: 'LOD400',
      mesh_type: 'viaduct_span',
      dimensions: { length_m: 450, width_m: 13.5, height_m: 14.0 }
    },
    location: {
      latitude: 51.7482,
      longitude: -0.7381,
      elevation_m: 142.1,
      bng_easting: 487200,
      bng_northing: 206400,
      chainage_m: 53200,
      chainage_formatted: 'CH 53+200',
      offset_m: 0,
      route_section_id: 'SEC-WENDOVER-AYLESBURY'
    },
    lifecycle_state: 'COMMISSIONED',
    information_status: 'PUBLISHED',
    confidence: 0.99,
    validation_status: 'VALIDATED',
    properties: {
      'Deck Construction': 'Double composite hollow steel-concrete box',
      'Number of Spans': 9,
      'Max Span Length (m)': 55.0,
      'Steel Grade': 'Weathering Steel S355W',
      'Embodied Carbon Saving': '43% vs standard concrete baseline'
    },
    engineering_parameters: {
      'Pier 4 Tilt Deviation': { value: 0.012, unit: 'degrees', description: 'Transverse pier inclination from vertical' },
      'Midspan Dynamic Deflection': { value: 4.1, unit: 'mm', description: 'Measured under high-speed test train run' },
      'Expansion Joint Movement': { value: 38.4, unit: 'mm', description: 'Thermal expansion displacement at south abutment' }
    },
    relationships: [
      { target_id: 'SENS-TILT-WDV-P4', relationship_type: 'MONITORED_BY', confidence: 1.0 },
      { target_id: 'TRK-SLAB-WDV-UP', relationship_type: 'CONTAINS', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'Bentley ProjectWise / Tekla Structures',
      source_document_id: '1MC05-EKFB-CIV-DWG-WDV-003',
      source_object_id: 'VIADUCT-WENDOVER-DEAN-MAIN',
      revision: 'P04.0',
      author: 'EKFB JV (Eiffage / Kier / Ferrovial / BAM)',
      created_at: '2024-04-10T14:00:00Z',
      approved_by: 'Chief Structural Validator',
      approval_date: '2024-05-01T09:00:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2023-01-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  },

  // --------------------------------------------------------------------------
  // KEY CIVILS STRUCTURE 4: CALVERT DEEP CUTTING & DRAINAGE ASSET (CH 74+100 to CH 76+800)
  // --------------------------------------------------------------------------
  {
    asset_id: 'CIV-CUT-CALVERT-01',
    parent_id: 'HS2-PHASE1-CORRIDOR',
    asset_class: 'cutting',
    discipline: 'CIVILS',
    name: 'Calvert Clay Cutting & Earthworks Slopes',
    description: '2.7 km deep cutting through Oxford Clay formation with engineered slope stabilization, deep horizontal drainage, and automated piezometer array.',
    uniclass_code: 'Pr_20_29_28 Earthwork slope stabilization systems',
    geometry: {
      bim_guid: '4kM99$pT11rWe2vL5xAbCc',
      model_file: '1MC06-EKF-GEO-MOD-CAL-002.ifc',
      lod: 'LOD300',
      mesh_type: 'box',
      dimensions: { length_m: 2700, width_m: 45, height_m: 16 }
    },
    location: {
      latitude: 51.9056,
      longitude: -0.9984,
      elevation_m: 88.0,
      bng_easting: 468900,
      bng_northing: 223500,
      chainage_m: 74500,
      chainage_formatted: 'CH 74+500',
      offset_m: 0,
      route_section_id: 'SEC-CALVERT-DEPOT'
    },
    lifecycle_state: 'OPERATIONAL',
    information_status: 'PUBLISHED',
    confidence: 0.98,
    validation_status: 'VALIDATED',
    properties: {
      'Geological Formation': 'Weymouth Member / Oxford Clay Formation',
      'Cut Slope Angle': '1V:3H with intermediate berm at 6m',
      'Drainage Infrastructure': 'Counterfort drains at 10m centres + crest cut-off channel',
      'Slope Instrumentation': '8 Vibrating Wire Piezometers + 4 ShapeAccelArrays'
    },
    engineering_parameters: {
      'Slope Stability Factor of Safety (FoS)': { value: 1.48, unit: 'ratio', description: 'Calculated Eurocode 7 Design Factor of Safety' },
      'Pore Water Pressure Head (mH2O)': { value: 4.8, unit: 'mH2O', description: 'Piezometric head in shear plane' },
      'Lateral Slope Inclinometer Displacement': { value: 3.2, unit: 'mm', description: 'Cumulative creep displacement over 24 months' }
    },
    relationships: [
      { target_id: 'DRN-CULV-CALVERT-PUMP', relationship_type: 'DRAINS_TO', confidence: 1.0 },
      { target_id: 'SENS-PIEZO-CALVERT-01', relationship_type: 'MONITORED_BY', confidence: 1.0 },
      { target_id: 'TRK-SLAB-CALVERT-UP', relationship_type: 'LOCATED_ON', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'Bentley OpenGround / gINT Geotechnical',
      source_document_id: '1MC06-EKF-GEO-REP-00109',
      source_object_id: 'EARTHWORK-CUTTING-CALVERT',
      revision: 'P03.2',
      author: 'EKFB Geotechnical Engineering Directorate',
      created_at: '2024-03-01T10:00:00Z',
      approved_by: 'Principal Geotechnical Specialist (MICE CEng)',
      approval_date: '2024-03-15T16:00:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2022-09-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  },

  // --------------------------------------------------------------------------
  // STATIONS: OLD OAK COMMON & BIRMINGHAM CURZON STREET
  // --------------------------------------------------------------------------
  {
    asset_id: 'STA-LON-OOC-01',
    parent_id: 'HS2-PHASE1-CORRIDOR',
    asset_class: 'concourse',
    discipline: 'STATIONS',
    name: 'Old Oak Common Super-Hub Interchange',
    description: 'Major multimodal interchange station connecting 6 underground high-speed platforms (450m) with 8 surface Elizabeth Line / Great Western main line platforms.',
    uniclass_code: 'Co_20_20_80 Railway passenger station entity',
    geometry: {
      bim_guid: '1wP44$sE99bVc3mL7yGhJk',
      model_file: '1MC02-BBL-STA-MOD-OOC-001.ifc',
      lod: 'LOD400',
      mesh_type: 'station_slab',
      dimensions: { length_m: 450, width_m: 80, height_m: 22 }
    },
    location: {
      latitude: 51.5238,
      longitude: -0.2441,
      elevation_m: 22.4,
      bng_easting: 521900,
      bng_northing: 182100,
      chainage_m: 7800,
      chainage_formatted: 'CH 07+800',
      offset_m: 0,
      route_section_id: 'SEC-LONDON-OOC'
    },
    lifecycle_state: 'UNDER_CONSTRUCTION',
    information_status: 'PUBLISHED',
    confidence: 0.99,
    validation_status: 'VALIDATED',
    properties: {
      'High Speed Platforms': 6,
      'Conventional Platforms': 8,
      'Peak Passenger Capacity (pax/hr)': 25000,
      'BREEAM Rating': 'Outstanding (Targeted 91.2%)',
      'Box Excavation Volume (m3)': 740000
    },
    engineering_parameters: {
      'HVAC Ventilation Air Exchange Rate': { value: 6.2, unit: 'ACH', description: 'Air changes per hour in sub-surface box' },
      'Platform Edge Door (PED) Cycle Reliability': { value: 99.98, unit: 'percent', description: 'MTBF threshold for synchronized sliding doors' },
      'Emergency Smoke Extraction Flow': { value: 240, unit: 'm3/s', description: 'Sub-surface smoke control exhaust capacity' }
    },
    relationships: [
      { target_id: 'POW-SUB-OOC-01', relationship_type: 'POWERED_BY', confidence: 1.0 },
      { target_id: 'SIG-RBC-LONDON-01', relationship_type: 'CONTROLLED_BY', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'Autodesk Revit 2026 / ProjectWise',
      source_document_id: '1MC02-BBVS-STA-DWG-00045',
      source_object_id: 'STATION-OOC-SUBSTRUCTURE',
      revision: 'P06.0',
      author: 'Balfour Beatty VINCI SYSTRA JV (BBVS)',
      created_at: '2024-05-18T08:30:00Z',
      approved_by: 'Lead Station Architect (RIBA/ICE)',
      approval_date: '2024-06-01T12:00:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2021-06-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  },
  {
    asset_id: 'STA-BHM-CURZON-01',
    parent_id: 'HS2-PHASE1-CORRIDOR',
    asset_class: 'concourse',
    discipline: 'STATIONS',
    name: 'Birmingham Curzon Street Terminal',
    description: 'Net zero carbon terminus station in central Birmingham featuring 7 high-speed platforms under an arched 280m timber-and-steel diagrid roof.',
    uniclass_code: 'Co_20_20_80 Railway passenger station entity',
    geometry: {
      bim_guid: '5qE66$vT33nMx7yP9wZbXx',
      model_file: '1MC08-MMP-STA-MOD-CRZ-001.ifc',
      lod: 'LOD400',
      mesh_type: 'station_slab',
      dimensions: { length_m: 410, width_m: 72, height_m: 26 }
    },
    location: {
      latitude: 52.4795,
      longitude: -1.8872,
      elevation_m: 98.6,
      bng_easting: 407700,
      bng_northing: 286800,
      chainage_m: 98500,
      chainage_formatted: 'CH 98+500',
      offset_m: 0,
      route_section_id: 'SEC-BIRMINGHAM-CURZON'
    },
    lifecycle_state: 'UNDER_CONSTRUCTION',
    information_status: 'PUBLISHED',
    confidence: 0.99,
    validation_status: 'VALIDATED',
    properties: {
      'Platforms': 7,
      'Solar Photovoltaic Array (m2)': 2800,
      'Rainwater Harvesting (m3/yr)': 18000,
      'Operational Carbon': 'Net Zero regulated emissions'
    },
    engineering_parameters: {
      'Roof Truss Dynamic Deflection': { value: 8.4, unit: 'mm', description: 'Thermal/wind load deflection of arched canopy' },
      'Substation Infeed Availability': { value: 100.0, unit: 'percent', description: 'Dual redundant 11kV DNO supply reliability' }
    },
    relationships: [
      { target_id: 'POW-SUB-CURZON-01', relationship_type: 'POWERED_BY', confidence: 1.0 },
      { target_id: 'SIG-RBC-BIRMINGHAM-01', relationship_type: 'CONTROLLED_BY', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'Revit 2026 / Trimble Connect',
      source_document_id: '1MC08-MMP-STA-DWG-00210',
      source_object_id: 'STATION-CURZON-TERMINUS',
      revision: 'P05.1',
      author: 'Mace Dragados JV (MDJV)',
      created_at: '2024-07-14T11:00:00Z',
      approved_by: 'Principal Building Engineering Lead',
      approval_date: '2024-08-01T14:00:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2022-04-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  },

  // --------------------------------------------------------------------------
  // RAIL TRACK SLAB ASSETS (RHEDA 2000 / PORR SYSTEM)
  // --------------------------------------------------------------------------
  {
    asset_id: 'TRK-SLAB-CVV-UP',
    parent_id: 'CIV-VIAD-COLNE-01',
    asset_class: 'slab',
    discipline: 'TRACK',
    name: 'Up Line Non-Ballasted Slab Track (Colne Valley)',
    description: 'High-speed slab track system mounted directly on viaduct concrete deck with 60E2 high-tensile rail and Vossloh 300 fastenings.',
    uniclass_code: 'Pr_20_29_89_88 Slab track systems',
    geometry: {
      mesh_type: 'spline',
      lod: 'LOD400',
      dimensions: { length_m: 3400, width_m: 3.2, height_m: 0.6 }
    },
    location: {
      latitude: 51.5834,
      longitude: -0.4782,
      elevation_m: 49.2,
      bng_easting: 505700,
      bng_northing: 188300,
      chainage_m: 21500,
      chainage_formatted: 'CH 21+500',
      offset_m: -2.3,
      route_section_id: 'SEC-COLNE-VALLEY'
    },
    lifecycle_state: 'COMMISSIONED',
    information_status: 'PUBLISHED',
    confidence: 0.99,
    validation_status: 'VALIDATED',
    properties: {
      'Track Form': 'Slab Track RHEDA 2000 System',
      'Rail Profile': '60E2 (EN 13674-1)',
      'Rail Steel Grade': 'R350HT Heat Treated Head',
      'Fastening System': 'Vossloh System 300 W-14',
      'Track Gauge (mm)': 1435,
      'Design Cant (mm)': 90
    },
    engineering_parameters: {
      'Track Vertical Geometry SD': { value: 0.42, unit: 'mm', description: 'Standard deviation of vertical level over 200m wavelength (EN 13848 Class A)' },
      'Track Alignment Geometry SD': { value: 0.38, unit: 'mm', description: 'Standard deviation of alignment' },
      'Rail Stress-Free Temperature (SFT)': { value: 27.2, unit: 'degC', description: 'Neutral temperature for Continuous Welded Rail (CWR)' },
      'Measured Rail Temperature': { value: 24.8, unit: 'degC', description: 'Live embedded sensor temperature' },
      'Thermal Compressive Stress': { value: -5.8, unit: 'MPa', description: 'Calculated longitudinal rail thermal stress (Safe vs Buckling CRT)' }
    },
    relationships: [
      { target_id: 'OLE-PORTAL-CVV-P28', relationship_type: 'POWERED_BY', confidence: 1.0 },
      { target_id: 'SIG-BAL-CVV-01', relationship_type: 'INTERFACES_WITH', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'Bentley OpenRail / Plasser & Theurer Track Inspection',
      source_document_id: '1MC04-TRK-CAL-0042',
      source_object_id: 'TRACK-UP-CVV-SLAB',
      revision: 'P04.0',
      author: 'Permanent Way Systems Directorate',
      created_at: '2025-01-20T10:00:00Z',
      approved_by: 'Lead Permanent Way Engineer (FPWI)',
      approval_date: '2025-02-01T15:00:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2024-11-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  },

  // --------------------------------------------------------------------------
  // ELECTRIFICATION (OLE) 25kV AUTOTRANSFORMER CATENARY
  // --------------------------------------------------------------------------
  {
    asset_id: 'OLE-PORTAL-CVV-P28',
    parent_id: 'CIV-VIAD-COLNE-01',
    asset_class: 'portal',
    discipline: 'OLE',
    name: 'Colne Valley Viaduct OLE Portal Structure P28',
    description: 'Galvanized tubular steel portal supporting 25kV overhead catenary wires, feeder cables and earth return wires across Up and Down tracks.',
    uniclass_code: 'Pr_20_29_60_58 Overhead electrification mast systems',
    geometry: {
      bim_guid: '8hN55$tY22bNm8kL1xGhFf',
      model_file: '1MC04-OLE-MOD-CVV-028.ifc',
      lod: 'LOD400',
      mesh_type: 'mast',
      dimensions: { length_m: 14.2, width_m: 0.8, height_m: 8.5 }
    },
    location: {
      latitude: 51.5842,
      longitude: -0.4795,
      elevation_m: 54.0,
      bng_easting: 505620,
      bng_northing: 188390,
      chainage_m: 22800,
      chainage_formatted: 'CH 22+800',
      offset_m: 0,
      route_section_id: 'SEC-COLNE-VALLEY'
    },
    lifecycle_state: 'COMMISSIONED',
    information_status: 'PUBLISHED',
    confidence: 0.99,
    validation_status: 'VALIDATED',
    properties: {
      'Catenary Tension (kN)': 15.0,
      'Contact Wire Tension (kN)': 20.0,
      'Contact Wire Type': 'CuAg 120 mm2 (Copper-Silver Alloy)',
      'Nominal Contact Wire Height (m)': 5.08,
      'Nominal Stagger (mm)': '+180 mm (Up Track) / -180 mm (Down Track)'
    },
    engineering_parameters: {
      'Measured Contact Wire Height': { value: 5.078, unit: 'm', description: 'Laser measured contact wire elevation' },
      'Measured Lateral Stagger': { value: 178, unit: 'mm', description: 'Lateral zigzag offset to prevent groove wear in pantograph carbon strip' },
      'Pantograph Uplift at 360 km/h': { value: 58, unit: 'mm', description: 'Aerodynamic and mechanical contact uplift (< 90mm max)' },
      'Insulator Leakage Current': { value: 0.12, unit: 'mA', description: 'Polymer insulator leakage current (Clean/Nominal)' }
    },
    relationships: [
      { target_id: 'POW-SUB-AMERSHAM-01', relationship_type: 'POWERED_BY', confidence: 1.0 },
      { target_id: 'TRK-SLAB-CVV-UP', relationship_type: 'SUPPLIES', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'Bentley ProjectWise / OpenRail OLE Designer',
      source_document_id: '1MC04-OLE-DWG-00389',
      source_object_id: 'OLE-PORTAL-CVV-28',
      revision: 'P04.1',
      author: 'High Speed Electrification Alliance',
      created_at: '2024-11-10T14:00:00Z',
      approved_by: 'Principal Electrification Engineer (MIET/CEng)',
      approval_date: '2024-12-01T09:30:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2024-10-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  },

  // --------------------------------------------------------------------------
  // POWER TRACTION FEEDER SUBSTATIONS (400kV / 25-0-25kV AT SYSTEM)
  // --------------------------------------------------------------------------
  {
    asset_id: 'POW-SUB-AMERSHAM-01',
    parent_id: 'HS2-PHASE1-CORRIDOR',
    asset_class: 'substation',
    discipline: 'POWER',
    name: 'Amersham Main Traction Feeder Substation (TFS 02)',
    description: 'Bulk supply point fed directly from National Grid 400kV transmission ring stepping down via dual 120MVA single-phase transformers to 25-0-25kV autotransformer traction system.',
    uniclass_code: 'Pr_20_29_60_79 Traction substation power systems',
    geometry: {
      bim_guid: '2jK88$uI44vBn1mL6xGhTt',
      model_file: '1MC04-POW-MOD-AMS-001.ifc',
      lod: 'LOD400',
      mesh_type: 'box',
      dimensions: { length_m: 65, width_m: 40, height_m: 9 }
    },
    location: {
      latitude: 51.6742,
      longitude: -0.6124,
      elevation_m: 110.5,
      bng_easting: 496100,
      bng_northing: 198200,
      chainage_m: 34200,
      chainage_formatted: 'CH 34+200',
      offset_m: 45.0,
      route_section_id: 'SEC-CHILTERNS-TUNNEL'
    },
    lifecycle_state: 'OPERATIONAL',
    information_status: 'PUBLISHED',
    confidence: 0.99,
    validation_status: 'VALIDATED',
    properties: {
      'Grid Infeed': 'National Grid 400 kV (East Claydon - Iver Circuit)',
      'Transformer Capacity': '2 x 120 MVA ONAN/ONAF 400/27.5-0-27.5 kV',
      'Harmonic Filtration': 'Active Static Var Compensator (SVC) + 3rd/5th Harmonic Filters',
      'Switchgear': 'SF6-free clean air GIS 52kV circuit breakers'
    },
    engineering_parameters: {
      'Active Traction Load': { value: 38.4, unit: 'MW', description: 'Instantaneous active power demand across Chiltern feeding section' },
      'Feeder Busbar Voltage': { value: 27.42, unit: 'kV', description: 'Nominal +25kV feeder to neutral potential' },
      'Power Factor': { value: 0.985, unit: 'ratio', description: 'Corrected power factor at National Grid PCC interface' },
      'Transformer Winding Temperature': { value: 58.2, unit: 'degC', description: 'Hot-spot temperature of Tx1 (Alarm threshold 95°C)' }
    },
    relationships: [
      { target_id: 'OLE-PORTAL-CVV-P28', relationship_type: 'SUPPLIES', confidence: 1.0 },
      { target_id: 'CIV-TUNN-CHILTERN-01', relationship_type: 'SUPPLIES', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'ETAP / Bentley ProjectWise Power Tools',
      source_document_id: '1MC04-POW-CAL-00122',
      source_object_id: 'SUBSTATION-TFS-02-AMERSHAM',
      revision: 'P05.0',
      author: 'National Grid / HS2 Power Systems Directorate',
      created_at: '2024-09-12T16:00:00Z',
      approved_by: 'Chief Electrification & Plant Engineer (FIET CEng)',
      approval_date: '2024-10-01T10:00:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2024-01-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  },

  // --------------------------------------------------------------------------
  // SIGNALLING & ETCS LEVEL 2 / RBC (RADIO BLOCK CENTRE)
  // --------------------------------------------------------------------------
  {
    asset_id: 'SIG-RBC-CHILTERNS-01',
    parent_id: 'HS2-PHASE1-CORRIDOR',
    asset_class: 'radio_block_centre',
    discipline: 'SIGNALLING',
    name: 'Chilterns Route Radio Block Centre (RBC-02)',
    description: 'Vital dual-redundant 2-out-of-3 ETCS Level 2 Baseline 3 Radio Block Centre generating dynamic Movement Authorities (MA) sent via Euroradio to train on-board computers.',
    uniclass_code: 'Pr_20_29_74_72 Radio block centre signalling systems',
    geometry: {
      bim_guid: '9xL22$mP55vBn7kL3wXyZz',
      model_file: '1MC04-SIG-MOD-RBC-002.ifc',
      lod: 'LOD300',
      mesh_type: 'box',
      dimensions: { length_m: 6, width_m: 4, height_m: 3 }
    },
    location: {
      latitude: 51.6748,
      longitude: -0.6130,
      elevation_m: 112.0,
      bng_easting: 496050,
      bng_northing: 198280,
      chainage_m: 34300,
      chainage_formatted: 'CH 34+300',
      offset_m: 50.0,
      route_section_id: 'SEC-CHILTERNS-TUNNEL'
    },
    lifecycle_state: 'OPERATIONAL',
    information_status: 'PUBLISHED',
    confidence: 1.0,
    validation_status: 'VALIDATED',
    properties: {
      'Safety Integrity Level': 'SIL 4 (CENELEC EN 50128 / EN 50129)',
      'ETCS Baseline': 'Baseline 3 Release 2 (Set 3)',
      'Controlled Section (km)': 'CH 21+500 to CH 65+000 (43.5 km corridor)',
      'Connected Trains': 4,
      'Maximum Moving Block Headway': '120 seconds at 360 km/h'
    },
    engineering_parameters: {
      'Radio Telegram Latency': { value: 142, unit: 'ms', description: 'End-to-end round trip transmission delay via FRMCS/GSM-R' },
      'Axle Counter Section Integrity': { value: 100.0, unit: 'percent', description: 'Zero spurious section resets / occupancy faults' },
      'Emergency Braking Curve Margin': { value: 320, unit: 'm', description: 'Guaranteed safety overlap behind preceding train movement authority' }
    },
    relationships: [
      { target_id: 'CIV-TUNN-CHILTERN-01', relationship_type: 'CONTROLLED_BY', confidence: 1.0 },
      { target_id: 'SIG-BAL-CVV-01', relationship_type: 'INTERFACES_WITH', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'Hitachi / Siemens Signalling Engineering Workbench',
      source_document_id: '1MC04-SIG-SYS-00088',
      source_object_id: 'RBC-02-CHILTERNS-MAIN',
      revision: 'P05.0',
      author: 'High Speed Signalling Alliance',
      created_at: '2024-10-15T09:00:00Z',
      approved_by: 'Lead Signalling Principles Engineer (FIRSE)',
      approval_date: '2024-11-01T14:00:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2024-06-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  },
  {
    asset_id: 'SIG-BAL-CVV-01',
    parent_id: 'TRK-SLAB-CVV-UP',
    asset_class: 'balise',
    discipline: 'SIGNALLING',
    name: 'Eurobalise Group BG-228-01 (Colne Valley)',
    description: 'Track-mounted passive Eurobalise group transmitting fixed telegrams containing exact chainage, gradient profile, and radio session connection commands.',
    uniclass_code: 'Pr_20_29_74_08 Balise train detection devices',
    geometry: {
      mesh_type: 'sensor_probe',
      lod: 'LOD400',
      dimensions: { length_m: 0.5, width_m: 0.4, height_m: 0.1 }
    },
    location: {
      latitude: 51.5842,
      longitude: -0.4795,
      elevation_m: 49.3,
      bng_easting: 505620,
      bng_northing: 188390,
      chainage_m: 22800,
      chainage_formatted: 'CH 22+800',
      offset_m: -2.3,
      route_section_id: 'SEC-COLNE-VALLEY'
    },
    lifecycle_state: 'COMMISSIONED',
    information_status: 'PUBLISHED',
    confidence: 1.0,
    validation_status: 'VALIDATED',
    properties: {
      'Balise Type': 'Passive Eurobalise (Subset-036)',
      'Telegram ID': 'ETCS-BG-228-UP',
      'Telegram Length': '1024 bits',
      'Passage Count': 1420
    },
    engineering_parameters: {
      '27MHz Tele-powering Field Sensitivity': { value: 12.4, unit: 'dBm', description: 'Transmitted field coupling efficiency' }
    },
    relationships: [
      { target_id: 'SIG-RBC-CHILTERNS-01', relationship_type: 'INTERFACES_WITH', confidence: 1.0 }
    ],
    provenance: {
      source_system: 'Siemens Balise Data Tool',
      source_document_id: '1MC04-SIG-BAL-0044',
      source_object_id: 'BALISE-BG-228-01',
      revision: 'P03.0',
      author: 'Signalling Systems Test Team',
      created_at: '2025-01-10T12:00:00Z',
      approved_by: 'Signalling Commissioning Inspector',
      approval_date: '2025-01-25T11:00:00Z',
      cde_status: 'PUBLISHED'
    },
    valid_from: '2025-01-01',
    last_observed: '2026-09-30T04:05:00Z',
    last_updated: '2026-09-30T04:05:00Z'
  }
];

// ----------------------------------------------------------------------------
// STRUCTURAL HEALTH MONITORING (SHM) & GEOTECHNICAL SENSORS
// ----------------------------------------------------------------------------
export const SYNTHETIC_SENSORS: Sensor[] = [
  {
    sensor_id: 'SENS-SHM-CVV-PIER28',
    asset_id: 'CIV-VIAD-COLNE-01',
    sensor_type: 'TILT_METER_PIER',
    model: 'Geosense MEMS Dual-Axis Digital Tiltmeter Geo-Tilt 2000',
    serial_number: 'SN-GT-99214',
    installation_date: '2024-05-12',
    calibration_expiry: '2027-05-12',
    sampling_interval_sec: 1,
    unit: 'degrees (arc-seconds)',
    baseline_value: 0.002,
    warning_threshold_low: -0.05,
    warning_threshold_high: 0.05,
    critical_threshold_high: 0.12,
    current_value: 0.0034,
    rate_of_change_per_hour: 0.0001,
    cusum_statistic: 0.0012,
    health: 'OPERATIONAL',
    last_reading_timestamp: '2026-09-30T04:06:55Z',
    battery_percent: 94,
    signal_rssi_dbm: -64
  },
  {
    sensor_id: 'SENS-PIEZO-CALVERT-01',
    asset_id: 'CIV-CUT-CALVERT-01',
    sensor_type: 'PIEZOMETER_PORE_PRESSURE',
    model: 'RST Vibrating Wire Push-in Piezometer VW2100',
    serial_number: 'SN-VW-44182',
    installation_date: '2023-08-14',
    calibration_expiry: '2026-08-14',
    sampling_interval_sec: 60,
    unit: 'kPa (Pore Water Pressure)',
    baseline_value: 48.0,
    warning_threshold_high: 75.0,
    critical_threshold_high: 95.0,
    current_value: 52.4,
    rate_of_change_per_hour: 0.2,
    cusum_statistic: 0.8,
    health: 'OPERATIONAL',
    last_reading_timestamp: '2026-09-30T04:06:00Z',
    battery_percent: 88,
    signal_rssi_dbm: -71
  },
  {
    sensor_id: 'SENS-DTS-CHILTERN-FIBRE',
    asset_id: 'CIV-TUNN-CHILTERN-01',
    sensor_type: 'OPTICAL_FIBRE_DTS_TEMP',
    model: 'Silixa Ultima Distributed Temperature Sensing System (0.5m spatial res)',
    serial_number: 'SN-DTS-7710',
    installation_date: '2024-03-20',
    calibration_expiry: '2027-03-20',
    sampling_interval_sec: 10,
    unit: 'degC',
    baseline_value: 15.2,
    warning_threshold_high: 35.0,
    critical_threshold_high: 50.0,
    current_value: 16.8,
    rate_of_change_per_hour: 0.05,
    cusum_statistic: 0.1,
    health: 'OPERATIONAL',
    last_reading_timestamp: '2026-09-30T04:06:50Z',
    battery_percent: 100, // Mains UPS
    signal_rssi_dbm: -45
  },
  {
    sensor_id: 'SENS-STRAIN-CVV-BOX',
    asset_id: 'CIV-VIAD-COLNE-01',
    sensor_type: 'VIBRATING_WIRE_STRAIN',
    model: 'Geokon 4000 Arc-Weldable Vibrating Wire Strain Gauge',
    serial_number: 'SN-GK-38190',
    installation_date: '2024-06-01',
    calibration_expiry: '2027-06-01',
    sampling_interval_sec: 1,
    unit: 'micro-strain (με)',
    baseline_value: 420.0,
    warning_threshold_high: 850.0,
    critical_threshold_high: 1200.0,
    current_value: 432.5,
    rate_of_change_per_hour: 0.4,
    cusum_statistic: 1.1,
    health: 'OPERATIONAL',
    last_reading_timestamp: '2026-09-30T04:06:58Z',
    battery_percent: 96,
    signal_rssi_dbm: -62
  },
  {
    sensor_id: 'SENS-WEATH-CALVERT-01',
    asset_id: 'CIV-CUT-CALVERT-01',
    sensor_type: 'WEATHER_RAIN_GAUGE',
    model: 'Vaisala WXT536 All-in-One Ultrasonic Weather Station & Rain Gauge',
    serial_number: 'SN-VAI-8823',
    installation_date: '2023-05-10',
    calibration_expiry: '2026-11-10',
    sampling_interval_sec: 30,
    unit: 'mm/h rainfall',
    baseline_value: 0.0,
    warning_threshold_high: 15.0,
    critical_threshold_high: 30.0,
    current_value: 1.2,
    rate_of_change_per_hour: 0.5,
    cusum_statistic: 0.2,
    health: 'OPERATIONAL',
    last_reading_timestamp: '2026-09-30T04:06:30Z',
    battery_percent: 99,
    signal_rssi_dbm: -58
  }
];

// ----------------------------------------------------------------------------
// REAL-TIME / SIMULATED HIGH SPEED TRAIN FLEET (CLASS 895)
// ----------------------------------------------------------------------------
export const SYNTHETIC_TRAINS: TrainDigitalTwin[] = [
  {
    train_id: 'TRN-895-001',
    unit_number: 'HS2-SET-001',
    model: 'Class_895_Captive',
    composition: '8-car 200m EMU (440t tare, 550 seated passengers)',
    mass_tonnes: 440,
    max_speed_kmh: 360,
    traction_power_kw: 9600,
    current_chainage_m: 23200, // On Colne Valley Viaduct heading north
    current_speed_kmh: 320.4,
    target_speed_kmh: 360.0,
    acceleration_ms2: 0.28,
    pantograph_voltage_kv: 26.8,
    traction_current_a: 320,
    power_draw_mw: 8.58,
    regenerative_braking_mw: 0.0,
    energy_consumption_kwh: 1420.5,
    pantograph_state: 'RAISED',
    door_interlock_status: 'LOCKED_SECURE',
    etcs_operating_mode: 'FS_Full_Supervision',
    passenger_load_percent: 78,
    bearing_temp_c: 38.2,
    hvac_status: 'OPTIMAL',
    service_id: '1Z14 London Old Oak Common -> Birmingham Curzon St',
    delay_seconds: 0
  },
  {
    train_id: 'TRN-895-004',
    unit_number: 'HS2-SET-004',
    model: 'Class_895_Captive',
    composition: '8-car 200m EMU',
    mass_tonnes: 440,
    max_speed_kmh: 360,
    traction_power_kw: 9600,
    current_chainage_m: 68400, // Approaching Calvert heading south
    current_speed_kmh: 358.0,
    target_speed_kmh: 360.0,
    acceleration_ms2: 0.0,
    pantograph_voltage_kv: 26.2,
    traction_current_a: 240,
    power_draw_mw: 6.29,
    regenerative_braking_mw: 0.0,
    energy_consumption_kwh: 3180.0,
    pantograph_state: 'RAISED',
    door_interlock_status: 'LOCKED_SECURE',
    etcs_operating_mode: 'FS_Full_Supervision',
    passenger_load_percent: 86,
    bearing_temp_c: 41.0,
    hvac_status: 'OPTIMAL',
    service_id: '1Z21 Birmingham Curzon St -> London Old Oak Common',
    delay_seconds: 0
  },
  {
    train_id: 'TRN-895-007',
    unit_number: 'HS2-SET-007',
    model: 'Class_895_Captive',
    composition: '8-car 200m EMU',
    mass_tonnes: 440,
    max_speed_kmh: 360,
    traction_power_kw: 9600,
    current_chainage_m: 7800, // Departing Old Oak Common
    current_speed_kmh: 110.0,
    target_speed_kmh: 230.0,
    acceleration_ms2: 0.62,
    pantograph_voltage_kv: 27.1,
    traction_current_a: 350,
    power_draw_mw: 9.48,
    regenerative_braking_mw: 0.0,
    energy_consumption_kwh: 410.2,
    pantograph_state: 'RAISED',
    door_interlock_status: 'LOCKED_SECURE',
    etcs_operating_mode: 'FS_Full_Supervision',
    passenger_load_percent: 64,
    bearing_temp_c: 32.1,
    hvac_status: 'OPTIMAL',
    service_id: '1Z18 London Old Oak Common -> Birmingham Curzon St',
    delay_seconds: 0
  }
];

// ----------------------------------------------------------------------------
// 4D CONSTRUCTION PROGRAMME ACTIVITIES
// ----------------------------------------------------------------------------
export const SYNTHETIC_CONSTRUCTION_PROGRAMME: ConstructionActivity[] = [
  {
    activity_id: 'ACT-CVV-SEG-01',
    wbs_code: '1.4.2.1.1',
    name: 'Colne Valley Viaduct Deck Segment Launching & Post-Tensioning',
    asset_id: 'CIV-VIAD-COLNE-01',
    contractor: 'Align JV',
    planned_start: '2022-05-01',
    planned_finish: '2024-09-30',
    forecast_start: '2022-05-01',
    forecast_finish: '2024-09-15',
    actual_start: '2022-05-01',
    actual_finish: '2024-09-15',
    percent_complete: 100,
    status: 'COMPLETE',
    dependencies: [],
    variance_days: -15,
    critical_path: false
  },
  {
    activity_id: 'ACT-CHT-TBM-01',
    wbs_code: '1.4.3.2.1',
    name: 'Chiltern Tunnel Twin TBM Drive & Segment Ring Installation',
    asset_id: 'CIV-TUNN-CHILTERN-01',
    contractor: 'Align JV',
    planned_start: '2021-05-15',
    planned_finish: '2024-04-30',
    forecast_start: '2021-05-15',
    forecast_finish: '2024-03-28',
    actual_start: '2021-05-15',
    actual_finish: '2024-03-28',
    percent_complete: 100,
    status: 'COMPLETE',
    dependencies: ['ACT-CVV-SEG-01'],
    variance_days: -33,
    critical_path: false
  },
  {
    activity_id: 'ACT-TRK-SLAB-CVV',
    wbs_code: '1.5.1.4.2',
    name: 'RHEDA 2000 Slab Track Slipforming & Rail Welding (Colne Valley to Amersham)',
    asset_id: 'TRK-SLAB-CVV-UP',
    contractor: 'Ferrovial / BAM Track JV',
    planned_start: '2024-10-01',
    planned_finish: '2025-06-30',
    forecast_start: '2024-10-01',
    forecast_finish: '2025-05-20',
    actual_start: '2024-10-01',
    actual_finish: '2025-05-20',
    percent_complete: 100,
    status: 'ACCEPTED',
    dependencies: ['ACT-CVV-SEG-01'],
    variance_days: -41,
    critical_path: true
  },
  {
    activity_id: 'ACT-OLE-INST-01',
    wbs_code: '1.6.2.1.0',
    name: '25kV Autotransformer Catenary Mast Erection & Wire Stringing',
    asset_id: 'OLE-PORTAL-CVV-P28',
    contractor: 'High Speed Electrification Alliance',
    planned_start: '2025-04-01',
    planned_finish: '2025-11-30',
    forecast_start: '2025-04-01',
    forecast_finish: '2025-10-15',
    actual_start: '2025-04-01',
    actual_finish: '2025-10-15',
    percent_complete: 100,
    status: 'COMPLETE',
    dependencies: ['ACT-TRK-SLAB-CVV'],
    variance_days: -46,
    critical_path: true
  },
  {
    activity_id: 'ACT-SIG-ETCS-COMM',
    wbs_code: '1.7.3.1.2',
    name: 'ETCS Level 2 Radio Block Centre Dynamic Integration & Balise Sign-off',
    asset_id: 'SIG-RBC-CHILTERNS-01',
    contractor: 'Hitachi / Siemens JV',
    planned_start: '2025-11-01',
    planned_finish: '2026-05-30',
    forecast_start: '2025-11-01',
    forecast_finish: '2026-04-15',
    actual_start: '2025-11-01',
    actual_finish: '2026-04-15',
    percent_complete: 100,
    status: 'ACCEPTED',
    dependencies: ['ACT-OLE-INST-01'],
    variance_days: -45,
    critical_path: true
  },
  {
    activity_id: 'ACT-DYN-TRIAL-360',
    wbs_code: '1.9.1.0.0',
    name: 'Dynamic High-Speed Train Testing at 400 km/h Design Speed & 360 km/h Commissioning',
    asset_id: 'HS2-PHASE1-CORRIDOR',
    contractor: 'High Speed Two Systems Directorate / Shadow Operator',
    planned_start: '2026-05-01',
    planned_finish: '2026-11-30',
    forecast_start: '2026-05-01',
    forecast_finish: '2026-10-30',
    actual_start: '2026-05-01',
    percent_complete: 85,
    status: 'IN_PROGRESS',
    dependencies: ['ACT-SIG-ETCS-COMM'],
    variance_days: -31,
    critical_path: true
  }
];

// ----------------------------------------------------------------------------
// 5D COST & EMBODIED / OPERATIONAL CARBON
// ----------------------------------------------------------------------------
export const SYNTHETIC_COST_CARBON: AssetCostCarbon[] = [
  {
    asset_id: 'CIV-VIAD-COLNE-01',
    currency: 'GBP',
    quantity: 110000,
    unit: 'm3 Low Carbon Concrete',
    unit_rate_gbp: 1450,
    labour_cost_gbp: 48000000,
    plant_cost_gbp: 35000000,
    materials_cost_gbp: 52000000,
    subcontract_cost_gbp: 18000000,
    risk_contingency_gbp: 6500000,
    planned_total_gbp: 165000000,
    actual_total_gbp: 159500000,
    variance_gbp: -5500000,
    primary_material: 'C50/60 CEM III 70% GGBS Concrete + Prestressing Steel',
    material_mass_tonnes: 264000,
    embodied_carbon_factor_kgco2e_per_tonne: 122.0, // Low carbon mix vs 240kg standard OPC
    transport_carbon_kgco2e: 1420000,
    construction_energy_carbon_kgco2e: 2100000,
    total_embodied_carbon_kgco2e: 35728000,
    operational_carbon_annual_kgco2e: 12400,
    carbon_reduction_vs_baseline_percent: 44.5
  },
  {
    asset_id: 'CIV-TUNN-CHILTERN-01',
    currency: 'GBP',
    quantity: 420000,
    unit: 'm3 Precast Segment Rings & Cross-Passages',
    unit_rate_gbp: 2850,
    labour_cost_gbp: 320000000,
    plant_cost_gbp: 410000000,
    materials_cost_gbp: 310000000,
    subcontract_cost_gbp: 95000000,
    risk_contingency_gbp: 42000000,
    planned_total_gbp: 1220000000,
    actual_total_gbp: 1177000000,
    variance_gbp: -43000000,
    primary_material: 'Steel-Fibre Reinforced C50/60 Precast Segments',
    material_mass_tonnes: 1008000,
    embodied_carbon_factor_kgco2e_per_tonne: 135.0,
    transport_carbon_kgco2e: 4800000,
    construction_energy_carbon_kgco2e: 18500000,
    total_embodied_carbon_kgco2e: 159380000,
    operational_carbon_annual_kgco2e: 860000, // Ventilation and lighting
    carbon_reduction_vs_baseline_percent: 38.2
  },
  {
    asset_id: 'CIV-VIAD-WENDOVER-01',
    currency: 'GBP',
    quantity: 18500,
    unit: 'm3 Composite Box',
    unit_rate_gbp: 2200,
    labour_cost_gbp: 12500000,
    plant_cost_gbp: 9800000,
    materials_cost_gbp: 14200000,
    subcontract_cost_gbp: 3200000,
    risk_contingency_gbp: 1000000,
    planned_total_gbp: 42000000,
    actual_total_gbp: 40700000,
    variance_gbp: -1300000,
    primary_material: 'Weathering Steel S355W + Double Composite Concrete',
    material_mass_tonnes: 44400,
    embodied_carbon_factor_kgco2e_per_tonne: 215.0,
    transport_carbon_kgco2e: 380000,
    construction_energy_carbon_kgco2e: 640000,
    total_embodied_carbon_kgco2e: 10566000,
    operational_carbon_annual_kgco2e: 4200,
    carbon_reduction_vs_baseline_percent: 43.1
  }
];

// ----------------------------------------------------------------------------
// DEFECT MANAGEMENT & STATUTORY TESTS
// ----------------------------------------------------------------------------
export const SYNTHETIC_DEFECTS: Defect[] = [
  {
    defect_id: 'DEF-2026-0042',
    asset_id: 'CIV-CUT-CALVERT-01',
    title: 'Pore Water Pressure Transient Spike after Convective Storm (Piezometer VW2100)',
    description: 'Piezometric pressure in Oxford Clay shear horizon elevated to 52.4 kPa following 28mm intense rainstorm event; approaching Stage 1 review threshold.',
    severity: 'OPERATIONAL_RESTRICTION',
    status: 'INVESTIGATING',
    chainage_m: 74500,
    date_found: '2026-09-30T02:15:00Z',
    found_by: 'Automated Geotechnical Telemetry Rule Engine (EWMA Trigger)',
    responsible_entity: 'EKFB Earthworks Geotechnical Maintenance Team',
    evidence_document_id: '1MC06-GEO-ALR-0091',
    remedial_action_required: 'Inspect counterfort drain outflow weir, clear debris from crest ditch, verify piezometric dissipation curve.',
    target_resolution_date: '2026-10-02'
  },
  {
    defect_id: 'DEF-2026-0019',
    asset_id: 'OLE-PORTAL-CVV-P28',
    title: 'Dropper 3 Slack on Span P28-P29 Up Line',
    description: 'Laser telemetry detected 8mm dropper wire slack during 360 km/h high-speed train pass.',
    severity: 'MAINTENANCE_REQUIRED',
    status: 'REPAIR_SCHEDULED',
    chainage_m: 22800,
    date_found: '2026-09-28T14:20:00Z',
    found_by: 'Track Recording Coach OLE Optical Scanner',
    responsible_entity: 'High Speed Electrification Maintenance Team',
    evidence_document_id: '1MC04-OLE-REC-0014',
    remedial_action_required: 'Re-tension dropper clip during scheduled maintenance window.',
    target_resolution_date: '2026-10-04'
  }
];

export const SYNTHETIC_TESTS: TestingCommissioningItem[] = [
  {
    test_id: 'TST-CVV-DYN-01',
    asset_id: 'CIV-VIAD-COLNE-01',
    system_discipline: 'CIVILS',
    test_case_name: 'Colne Valley Viaduct Dynamic Resonant Deflection Test at 400 km/h Design Over-Speed',
    standard_reference: 'BS EN 1991-2 / TSI Infrastructure 2023',
    status: 'PASS',
    test_date: '2026-08-15',
    witnessed_by: 'Independent Verification Body (Lloyds Register Rail / TÜV Rheinland)',
    measured_value: '6.8 mm (Max Permissible: 12.0 mm)',
    acceptable_tolerance: 'Within ±15% of FE Modal Prediction (2.84 Hz)',
    certificate_document_id: '1MC04-CIV-CRT-00049'
  },
  {
    test_id: 'TST-SIG-ETCS-02',
    asset_id: 'SIG-RBC-CHILTERNS-01',
    system_discipline: 'SIGNALLING',
    test_case_name: 'ETCS Level 2 Radio Handover Between London RBC-01 and Chilterns RBC-02 at 360 km/h',
    standard_reference: 'UNISIG Subset-026 / Subset-096',
    status: 'PASS',
    test_date: '2026-09-02',
    witnessed_by: 'ORR Notified Body (NoBo/DeBo Inspector)',
    measured_value: '142 ms Handover Telegram Latency',
    acceptable_tolerance: '< 500 ms without train brake intervention',
    certificate_document_id: '1MC04-SIG-CRT-00112'
  }
];

export const SYNTHETIC_MAINTENANCE: MaintenanceRecord[] = [
  {
    record_id: 'MNT-2026-0811',
    asset_id: 'TRK-SLAB-CVV-UP',
    type: 'CONDITION_BASED',
    description: 'High-speed track geometry optical survey and rail surface acoustic roughness profiling.',
    performed_date: '2026-09-15',
    next_due_date: '2026-12-15',
    technician_team: 'Network Rail / HS2 Infrastructure Maintenance Unit',
    passed: true,
    notes: 'Standard deviation vertical 0.42mm, alignment 0.38mm. Superior to EN 13848 Class A threshold.',
    cost_gbp: 4500
  },
  {
    record_id: 'MNT-2026-0740',
    asset_id: 'POW-SUB-AMERSHAM-01',
    type: 'PREVENTATIVE',
    description: 'Annual Dissolved Gas Analysis (DGA) and dielectric breakdown testing on 120MVA transformer Tx1.',
    performed_date: '2026-08-20',
    next_due_date: '2027-08-20',
    technician_team: 'National Grid / HS2 High Voltage Specialist Team',
    passed: true,
    notes: 'Hydrogen < 5 ppm, Acetylene 0 ppm, Breakdown voltage 74 kV. Oil condition optimal.',
    cost_gbp: 8200
  }
];

// ----------------------------------------------------------------------------
// COMMON DATA ENVIRONMENT (CDE) DOCUMENTS (ISO 19650)
// ----------------------------------------------------------------------------
export const SYNTHETIC_CDE_DOCUMENTS: CDEDocument[] = [
  {
    document_id: 'DOC-1MC04-CIV-DWG-00421',
    document_number: '1MC04-ALN-CIV-DWG-CS04-000421',
    title: 'Colne Valley Viaduct — Pier 28 to 32 Superstructure & Deck Tendon Layout',
    discipline: 'CIVILS',
    status: 'PUBLISHED',
    suitability_code: 'A4 - Authorized for Construction & Asset Handover',
    revision: 'P05.0',
    author_organization: 'Align JV',
    created_date: '2024-06-12',
    approved_date: '2024-07-01',
    file_format: 'IFC4x3',
    file_size_mb: 184.2,
    linked_asset_ids: ['CIV-VIAD-COLNE-01', 'TRK-SLAB-CVV-UP', 'OLE-PORTAL-CVV-P28'],
    cde_uri: 'urn:hs2:cde:1mc04:aln:civ:dwg:cs04:000421.ifc'
  },
  {
    document_id: 'DOC-1MC04-TUN-DWG-00812',
    document_number: '1MC04-ALN-TUN-DWG-CH02-000812',
    title: 'Chiltern Tunnel — Cross-Passage 18 Structural Lining & Waterproofing As-Built',
    discipline: 'TUNNELS',
    status: 'PUBLISHED',
    suitability_code: 'A5 - Verified As-Built Record',
    revision: 'P06.1',
    author_organization: 'Align JV Tunnel Engineering',
    created_date: '2024-08-20',
    approved_date: '2024-09-01',
    file_format: 'PDF',
    file_size_mb: 28.6,
    linked_asset_ids: ['CIV-TUNN-CHILTERN-01'],
    cde_uri: 'urn:hs2:cde:1mc04:aln:tun:dwg:ch02:000812.pdf'
  },
  {
    document_id: 'DOC-1MC04-SIG-SYS-00088',
    document_number: '1MC04-SIG-SYS-RBC-000088',
    title: 'ETCS Level 2 Baseline 3 Radio Block Centre Safety Case & Software Verification',
    discipline: 'SIGNALLING',
    status: 'PUBLISHED',
    suitability_code: 'A1 - Approved for Operational Service',
    revision: 'P05.0',
    author_organization: 'Hitachi / Siemens JV',
    created_date: '2024-10-15',
    approved_date: '2024-11-01',
    file_format: 'PDF',
    file_size_mb: 42.1,
    linked_asset_ids: ['SIG-RBC-CHILTERNS-01', 'SIG-BAL-CVV-01'],
    cde_uri: 'urn:hs2:cde:1mc04:sig:sys:rbc:000088.pdf'
  }
];

// ----------------------------------------------------------------------------
// DIGITAL TWIN SYSTEM EVENTS
// ----------------------------------------------------------------------------
export const SYNTHETIC_EVENTS: DigitalTwinEvent[] = [
  {
    event_id: 'EVT-00912',
    timestamp: '2026-09-30T04:05:12Z',
    severity: 'INFO',
    category: 'TRAIN_MOVEMENT',
    asset_id: 'TRK-SLAB-CVV-UP',
    chainage_m: 23200,
    title: 'Train 1Z14 Passed Eurobalise Group BG-228-01',
    message: 'High-speed EMU Class 895 (Set 001) reported speed 320.4 km/h under ETCS Full Supervision mode.',
    actor: 'ETCS On-Board Computer / RBC-02',
    provenance_ref: 'BALISE-BG-228-01'
  },
  {
    event_id: 'EVT-00911',
    timestamp: '2026-09-30T03:52:00Z',
    severity: 'WARNING',
    category: 'TELEMETRY_ANOMALY',
    asset_id: 'CIV-CUT-CALVERT-01',
    chainage_m: 74500,
    title: 'Geotechnical Piezometer Pore Pressure Surge (52.4 kPa)',
    message: 'Rate of change 0.2 kPa/h triggered warning envelope after 28mm convective rainfall.',
    actor: 'Automated Geotechnical Telemetry Daemon',
    provenance_ref: 'SENS-PIEZO-CALVERT-01'
  },
  {
    event_id: 'EVT-00910',
    timestamp: '2026-09-30T03:00:00Z',
    severity: 'NOTICE',
    category: 'POWER_PROTECTION',
    asset_id: 'POW-SUB-AMERSHAM-01',
    chainage_m: 34200,
    title: 'Traction Feeder Substation Load Shift to Feeder 2',
    message: 'Scheduled 25kV bus coupler maintenance switching completed smoothly with zero train disruption.',
    actor: 'SCADA Traction Power Controller (National Grid/HS2)',
    provenance_ref: 'SUBSTATION-TFS-02-AMERSHAM'
  }
];

// ----------------------------------------------------------------------------
// WHAT-IF SIMULATION SCENARIOS
// ----------------------------------------------------------------------------
export const SYNTHETIC_SCENARIOS: SimulationScenario[] = [
  {
    scenario_id: 'SCN-FLOOD-CALVERT-01',
    name: '1-in-100 Year Storm & Calvert Clay Cutting Drainage Surge',
    description: 'Simulates intense convective rainfall (35 mm/h) over Buckinghamshire, causing culvert surcharge, pore pressure rise in Oxford Clay, automated geotechnical alarm, and temporary 80 km/h speed restriction.',
    category: 'EXTREME_WEATHER',
    is_active: false,
    parameters: {
      rainfall_intensity_mm_hr: 35.0,
      ambient_temp_c: 18.5,
      speed_restriction_kmh: 80,
      speed_restriction_chainage_start_m: 73000,
      speed_restriction_chainage_end_m: 77000,
      affected_assets: ['CIV-CUT-CALVERT-01', 'TRK-SLAB-CALVERT-UP', 'DRN-CULV-CALVERT-PUMP']
    },
    simulated_outcomes: {
      train_delay_minutes: 6.4,
      passenger_capacity_loss_percent: 4.2,
      risk_level: 'MEDIUM',
      remedial_actions: [
        'Automated speed restriction imposed from CH 73+000 to CH 77+000',
        'Dispatch emergency civil geotechnical maintenance crew to Calvert pumping station',
        'Continuous 1-minute piezometer sampling and shape-accel-array slope monitoring',
        'Inspect drainage outfall and clear silt trap barriers'
      ],
      affected_services: ['1Z14', '1Z21', '1Z18', '1Z25']
    }
  },
  {
    scenario_id: 'SCN-POWER-OUTAGE-02',
    name: 'Amersham 400kV National Grid Bulk Supply Point Trip',
    description: 'Simulates sudden loss of primary 400kV supply at Amersham TFS 02 due to external grid fault; evaluates automatic 25kV feeding zone extension from Calvert TFS 03.',
    category: 'POWER_OUTAGE',
    is_active: false,
    parameters: {
      substation_outage_id: 'POW-SUB-AMERSHAM-01',
      affected_assets: ['POW-SUB-AMERSHAM-01', 'OLE-PORTAL-CVV-P28', 'CIV-TUNN-CHILTERN-01']
    },
    simulated_outcomes: {
      train_delay_minutes: 2.1,
      passenger_capacity_loss_percent: 0.0,
      risk_level: 'LOW',
      remedial_actions: [
        'Automatic motorized section isolator close at Neutral Section CH 48+000 within 1.2s',
        'Extend Calvert TFS feeding zone over Chiltern Tunnel',
        'Cap simultaneous 360 km/h train acceleration draw to 8.0 MW per unit',
        'Monitor catenary voltage at Colne Valley to ensure pantograph V >= 22.5 kV'
      ],
      affected_services: ['1Z14', '1Z21']
    }
  },
  {
    scenario_id: 'SCN-HEATWAVE-RAIL-03',
    name: 'Extreme Summer Heatwave (41°C Ambient / 61°C Rail Temp)',
    description: 'Simulates peak summer climate stress exceeding UK Critical Rail Temperature (CRT 59°C), evaluating continuous welded rail compressive buckling risk and OLE thermal expansion sag.',
    category: 'EXTREME_WEATHER',
    is_active: false,
    parameters: {
      ambient_temp_c: 41.0,
      speed_restriction_kmh: 160,
      affected_assets: ['TRK-SLAB-CVV-UP', 'OLE-PORTAL-CVV-P28']
    },
    simulated_outcomes: {
      train_delay_minutes: 8.8,
      passenger_capacity_loss_percent: 6.0,
      risk_level: 'HIGH',
      remedial_actions: [
        'Deploy drone infrared track patrol along un-shaded viaduct sections',
        'Impose precautionary 160 km/h speed limit across exposed slab transitions',
        'Monitor OLE contact wire tension balance weights and auto-tensioning hydraulic dampers'
      ],
      affected_services: ['1Z14', '1Z21', '1Z18', '1Z25', '1Z30']
    }
  }
];

// ----------------------------------------------------------------------------
// DATA QUALITY & SYSTEM HEALTH MANIFEST
// ----------------------------------------------------------------------------
export const SYNTHETIC_QUALITY_MANIFEST: TwinDataQualityManifest = {
  twin_version: '2026.4.1-PROD',
  schema_version: 'ISO-19650-HS2-V4.2',
  total_assets_registered: 14280,
  total_sensors_online: 3240,
  data_freshness_seconds: 1.2,
  spatial_integrity_score_percent: 99.8,
  relationship_completeness_percent: 98.6,
  provenance_coverage_percent: 99.4,
  validation_anomalies_count: 0,
  last_audit_timestamp: '2026-09-30T04:05:00Z'
};
