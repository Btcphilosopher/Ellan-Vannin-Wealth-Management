// ============================================================================
// RAIL SYSTEMS & PHYSICS SIMULATION ENGINE
// Implements first-principles engineering models:
// 1. Train Performance Model (Davis Equation + Gradient + Curvature)
// 2. 25kV Autotransformer (AT) Power Flow & Voltage Drop
// 3. OLE Catenary Dynamic Tension & Thermal Sag
// 4. Continuous Welded Rail (CWR) Thermal Stress & Buckling Risk
// ============================================================================

import { Injectable } from '@angular/core';
import { TrainDigitalTwin, PowerSubstationData } from '../models/digital-twin.types';

export interface TrainKinematicsResult {
  time_step_s: number;
  new_chainage_m: number;
  new_speed_kmh: number;
  acceleration_ms2: number;
  tractive_effort_kn: number;
  resistive_force_kn: number;
  davis_aerodynamic_kn: number;
  gradient_force_kn: number;
  curvature_force_kn: number;
  electrical_power_mw: number;
  regenerative_power_mw: number;
  pantograph_voltage_kv: number;
  traction_current_a: number;
}

@Injectable({
  providedIn: 'root'
})
export class PhysicsSimulationService {
  // Constants
  private readonly G = 9.80665; // m/s^2
  private readonly STEEL_YOUNGS_MODULUS_GPA = 210.0; // GPa (Rail Steel)
  private readonly STEEL_THERMAL_EXPANSION = 1.15e-5; // /K
  private readonly RAIL_CROSS_SECTION_60E2_M2 = 0.007684; // m^2 for 60E2 rail profile

  // High Speed Train Davis Equation Coefficients (Class 895 8-car 200m formation)
  // F_res (N) = A + B*v + C*v^2 (v in m/s, mass 440 tonnes)
  private readonly DAVIS_A = 4800.0; // N (Mechanical rolling resistance)
  private readonly DAVIS_B = 120.0;  // N/(m/s) (Flange friction & track damping)
  private readonly DAVIS_C = 8.4;    // N/(m/s)^2 (Aerodynamic drag coefficient Cd * A * rho / 2)

  /**
   * Run 1-step numerical integration for Train Performance Model (TPM)
   */
  public simulateTrainStep(
    train: TrainDigitalTwin,
    target_speed_kmh: number,
    gradient_permille: number,
    curve_radius_m: number,
    dt_seconds = 1.0
  ): TrainKinematicsResult {
    const v_ms = train.current_speed_kmh / 3.6;
    const v_target_ms = target_speed_kmh / 3.6;
    const mass_kg = train.mass_tonnes * 1000;

    // 1. Davis equation aerodynamic & mechanical resistance
    const f_davis_n = this.DAVIS_A + this.DAVIS_B * v_ms + this.DAVIS_C * Math.pow(v_ms, 2);

    // 2. Gradient resistance: F_grad = m * g * sin(theta) ~ m * g * (i / 1000)
    const f_grad_n = mass_kg * this.G * (gradient_permille / 1000.0);

    // 3. Curvature resistance: F_curve = (700 * m * g) / R for standard gauge (N)
    const f_curve_n = (curve_radius_m > 0 && curve_radius_m !== Infinity)
      ? (700.0 * mass_kg * this.G) / curve_radius_m / 1000.0
      : 0.0;

    const total_resistive_n = f_davis_n + f_grad_n + f_curve_n;

    // 4. Determine Tractive or Braking Effort
    let tractive_effort_n = 0;
    let braking_effort_n = 0;
    let electrical_power_mw = 0;
    let regenerative_power_mw = 0;

    const speed_error_ms = v_target_ms - v_ms;

    if (speed_error_ms > 0.1) {
      // Accelerating or sustaining speed
      // Max traction power = 9600 kW (9.6 MW)
      const max_power_w = train.traction_power_kw * 1000;
      const max_starting_force_n = 300000; // 300 kN starting tractive effort limit (adhesion limit)

      const force_from_power = v_ms > 1.0 ? max_power_w / v_ms : max_starting_force_n;
      const demanded_tractive_n = Math.min(max_starting_force_n, force_from_power);

      // PID/proportional throttle
      const throttle = Math.min(1.0, Math.max(0.1, speed_error_ms / 5.0));
      tractive_effort_n = demanded_tractive_n * throttle;
      electrical_power_mw = (tractive_effort_n * Math.max(v_ms, 1.0)) / (1e6 * 0.92); // 92% inverter/motor efficiency
    } else if (speed_error_ms < -0.1) {
      // Braking: Electrodynamic regenerative braking up to 0.9 m/s^2 deceleration
      const demanded_decel = Math.min(1.0, Math.abs(speed_error_ms) / 4.0);
      braking_effort_n = mass_kg * demanded_decel;
      regenerative_power_mw = (braking_effort_n * v_ms * 0.88) / 1e6; // 88% regen efficiency
    }

    // Net force
    const net_force_n = tractive_effort_n - braking_effort_n - total_resistive_n;
    const acceleration_ms2 = net_force_n / (mass_kg * 1.06); // 6% rotating mass inertia allowance

    // Velocity & Position update (Euler integration)
    const new_v_ms = Math.max(0, v_ms + acceleration_ms2 * dt_seconds);
    const new_speed_kmh = new_v_ms * 3.6;
    const distance_travelled_m = ((v_ms + new_v_ms) / 2.0) * dt_seconds;
    const new_chainage_m = train.current_chainage_m + distance_travelled_m;

    // Pantograph electrical state based on power draw and distance to nearest traction feeder
    const nominal_v_kv = 27.5;
    const estimated_voltage_drop_kv = (electrical_power_mw * 0.18) + (Math.abs(train.current_chainage_m % 25000 - 12500) / 12500) * 0.8;
    const pantograph_voltage_kv = Math.max(21.0, Math.min(27.8, nominal_v_kv - estimated_voltage_drop_kv));
    const traction_current_a = (electrical_power_mw * 1e6) / (pantograph_voltage_kv * 1000 * 0.98);

    return {
      time_step_s: dt_seconds,
      new_chainage_m,
      new_speed_kmh,
      acceleration_ms2: Math.round(acceleration_ms2 * 100) / 100,
      tractive_effort_kn: Math.round((tractive_effort_n / 1000) * 10) / 10,
      resistive_force_kn: Math.round((total_resistive_n / 1000) * 10) / 10,
      davis_aerodynamic_kn: Math.round((f_davis_n / 1000) * 10) / 10,
      gradient_force_kn: Math.round((f_grad_n / 1000) * 10) / 10,
      curvature_force_kn: Math.round((f_curve_n / 1000) * 10) / 10,
      electrical_power_mw: Math.round(electrical_power_mw * 100) / 100,
      regenerative_power_mw: Math.round(regenerative_power_mw * 100) / 100,
      pantograph_voltage_kv: Math.round(pantograph_voltage_kv * 100) / 100,
      traction_current_a: Math.round(traction_current_a)
    };
  }

  /**
   * Calculate Continuous Welded Rail (CWR) thermal stress and buckling safety index
   */
  public calculateRailThermalStress(
    rail_temp_c: number,
    stress_free_temp_c = 27.0
  ): { stress_mpa: number; buckling_risk: 'LOW' | 'MODERATE' | 'CRITICAL'; max_allowable_temp_c: number } {
    const delta_t = rail_temp_c - stress_free_temp_c;
    // Compressive stress is negative when rail is hotter than SFT
    // sigma = E * alpha * delta_T (in MPa)
    const stress_mpa = -(this.STEEL_YOUNGS_MODULUS_GPA * 1000.0 * this.STEEL_THERMAL_EXPANSION * delta_t);

    const crt_critical_rail_temp = stress_free_temp_c + 32.0; // e.g. 59°C CRT for slab track

    let buckling_risk: 'LOW' | 'MODERATE' | 'CRITICAL' = 'LOW';
    if (rail_temp_c >= crt_critical_rail_temp) {
      buckling_risk = 'CRITICAL';
    } else if (rail_temp_c >= crt_critical_rail_temp - 6.0) {
      buckling_risk = 'MODERATE';
    }

    return {
      stress_mpa: Math.round(stress_mpa * 10) / 10,
      buckling_risk,
      max_allowable_temp_c: crt_critical_rail_temp
    };
  }

  /**
   * Calculate 25kV OLE Overhead Catenary Sag, Tension and Uplift
   */
  public calculateOLESagAndUplift(
    wire_temp_c: number,
    train_speed_kmh: number,
    span_length_m = 55.0,
    nominal_tension_kn = 20.0
  ): { sag_mm: number; contact_wire_height_m: number; uplift_mm: number } {
    // Thermal expansion of CuAg contact wire (alpha = 1.7e-5 / K)
    const delta_t = wire_temp_c - 15.0; // reference 15°C
    const thermal_expansion = span_length_m * 1.7e-5 * delta_t;
    
    // Parabolic sag equation: s = (w * L^2) / (8 * T)
    const wire_weight_n_m = 1.08 * this.G; // 1.08 kg/m for 120mm2 CuAg
    const effective_tension_n = Math.max(12000, (nominal_tension_kn * 1000) - (thermal_expansion * 50000));
    const sag_m = (wire_weight_n_m * Math.pow(span_length_m, 2)) / (8 * effective_tension_n);
    const sag_mm = sag_m * 1000.0;

    // Pantograph dynamic uplift (aerodynamic lift + mechanical stiffness)
    // Uplift approx = u0 + k * (V / 100)^2
    const uplift_mm = 25.0 + 2.8 * Math.pow(train_speed_kmh / 100.0, 2);

    const nominal_height = 5.08;
    const contact_wire_height_m = nominal_height - (sag_mm / 1000.0);

    return {
      sag_mm: Math.round(sag_mm * 10) / 10,
      contact_wire_height_m: Math.round(contact_wire_height_m * 1000) / 1000,
      uplift_mm: Math.round(uplift_mm * 10) / 10
    };
  }

  /**
   * Calculate 25-0-25kV Autotransformer Substation Load Flow
   */
  public calculateSubstationLoadFlow(
    substation: PowerSubstationData,
    active_trains_count: number,
    average_train_draw_mw = 7.5
  ): {
    total_mw: number;
    feeder_current_a: number;
    thermal_load_percent: number;
    power_factor: number;
    status: 'NORMAL' | 'HIGH_LOAD' | 'OVERLOAD';
  } {
    const total_mw = active_trains_count * average_train_draw_mw;
    const power_factor = 0.985;
    const mva = total_mw / power_factor;
    const rated_mva = 120.0; // 120 MVA transformer
    const thermal_load_percent = Math.min(150, (mva / rated_mva) * 100);

    // Feeder current at 27.5 kV: I = P / (V * pf)
    const feeder_current_a = (total_mw * 1e6) / (27500 * power_factor);

    let status: 'NORMAL' | 'HIGH_LOAD' | 'OVERLOAD' = 'NORMAL';
    if (thermal_load_percent > 95) {
      status = 'OVERLOAD';
    } else if (thermal_load_percent > 75) {
      status = 'HIGH_LOAD';
    }

    return {
      total_mw: Math.round(total_mw * 10) / 10,
      feeder_current_a: Math.round(feeder_current_a),
      thermal_load_percent: Math.round(thermal_load_percent * 10) / 10,
      power_factor,
      status
    };
  }
}
