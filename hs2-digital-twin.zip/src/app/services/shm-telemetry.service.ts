// ============================================================================
// STRUCTURAL HEALTH MONITORING (SHM) & TELEMETRY STREAM SERVICE
// Generates live telemetry with realistic geotechnical/structural physics noise,
// runs EWMA & CUSUM statistical anomaly detection, and monitors sensor health.
// ============================================================================

import { Injectable, signal, computed } from '@angular/core';
import { Sensor } from '../models/digital-twin.types';
import { SYNTHETIC_SENSORS } from './synthetic-hs2-corridor.data';

export interface TelemetryStreamRecord {
  timestamp: string;
  sensor_id: string;
  value: number;
  ewma_filtered: number;
  cusum_score: number;
  is_anomaly: boolean;
  rate_of_change: number;
}

@Injectable({
  providedIn: 'root'
})
export class SHMTelemetryService {
  // Master sensor state signal
  public sensors = signal<Sensor[]>(SYNTHETIC_SENSORS);

  // Time-series history buffers for charts (keyed by sensor_id)
  public historyMap = signal<Record<string, TelemetryStreamRecord[]>>({});

  // Active alarms signal
  public activeSensorAlerts = computed(() => {
    return this.sensors().filter(s => {
      if (s.critical_threshold_high && s.current_value >= s.critical_threshold_high) return true;
      if (s.warning_threshold_high && s.current_value >= s.warning_threshold_high) return true;
      if (s.warning_threshold_low && s.current_value <= s.warning_threshold_low) return true;
      return false;
    });
  });

  private intervalId: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.initializeHistoryBuffers();
    this.startStreaming();
  }

  private initializeHistoryBuffers(): void {
    const initialMap: Record<string, TelemetryStreamRecord[]> = {};
    const now = Date.now();

    this.sensors().forEach(s => {
      const records: TelemetryStreamRecord[] = [];
      let currentVal = s.baseline_value;
      let ewma = currentVal;
      let cusum = 0;

      // Seed 30 historical points in 10-second intervals
      for (let i = 30; i >= 0; i--) {
        const t = new Date(now - i * 10000).toISOString();
        const noise = (Math.random() - 0.5) * (s.baseline_value * 0.02 || 0.001);
        currentVal = s.baseline_value + noise;
        ewma = 0.2 * currentVal + 0.8 * ewma;
        const diff = currentVal - s.baseline_value;
        cusum = Math.max(0, cusum + diff - 0.05);

        records.push({
          timestamp: t,
          sensor_id: s.sensor_id,
          value: Math.round(currentVal * 1000) / 1000,
          ewma_filtered: Math.round(ewma * 1000) / 1000,
          cusum_score: Math.round(cusum * 100) / 100,
          is_anomaly: s.warning_threshold_high ? currentVal > s.warning_threshold_high : false,
          rate_of_change: 0.01
        });
      }
      initialMap[s.sensor_id] = records;
    });

    this.historyMap.set(initialMap);
  }

  private startStreaming(): void {
    if (this.intervalId) clearInterval(this.intervalId);

    this.intervalId = setInterval(() => {
      this.tick();
    }, 2000);
  }

  /**
   * Periodic telemetry cycle updating sensor readings & statistical envelopes
   */
  public tick(): void {
    const currentList = this.sensors();
    const history = { ...this.historyMap() };
    const nowStr = new Date().toISOString();

    const updated = currentList.map(s => {
      // Dynamic simulated fluctuation
      let noiseStd = s.baseline_value * 0.015;
      if (s.sensor_type === 'TILT_METER_PIER') noiseStd = 0.0003;
      if (s.sensor_type === 'PIEZOMETER_PORE_PRESSURE') noiseStd = 0.35;
      if (s.sensor_type === 'VIBRATING_WIRE_STRAIN') noiseStd = 1.2;

      const randomDrift = (Math.random() - 0.48) * noiseStd;
      const newVal = Math.max(0, s.current_value + randomDrift);

      // EWMA calculation: S_t = alpha * Y_t + (1 - alpha) * S_{t-1}
      const alpha = 0.25;
      const historyArr = history[s.sensor_id] || [];
      const prevEwma = historyArr.length > 0 ? historyArr[historyArr.length - 1].ewma_filtered : s.baseline_value;
      const newEwma = alpha * newVal + (1 - alpha) * prevEwma;

      // CUSUM calculation: C+_t = max(0, C+_{t-1} + (Y_t - mu) - k)
      const slackK = 0.05 * (s.baseline_value || 1);
      const prevCusum = s.cusum_statistic || 0;
      const newCusum = Math.max(0, prevCusum + (newVal - s.baseline_value) - slackK);

      const rateOfChange = (newVal - (historyArr[historyArr.length - 1]?.value || newVal)) * 1800; // per hour

      const isAnomaly = s.warning_threshold_high ? newVal >= s.warning_threshold_high : false;

      // Append to buffer (keep max 40 points)
      const newRec: TelemetryStreamRecord = {
        timestamp: nowStr,
        sensor_id: s.sensor_id,
        value: Math.round(newVal * 1000) / 1000,
        ewma_filtered: Math.round(newEwma * 1000) / 1000,
        cusum_score: Math.round(newCusum * 100) / 100,
        is_anomaly: isAnomaly,
        rate_of_change: Math.round(rateOfChange * 100) / 100
      };

      const updatedBuffer = [...historyArr.slice(-39), newRec];
      history[s.sensor_id] = updatedBuffer;

      return {
        ...s,
        current_value: Math.round(newVal * 1000) / 1000,
        rate_of_change_per_hour: Math.round(rateOfChange * 100) / 100,
        cusum_statistic: Math.round(newCusum * 100) / 100,
        last_reading_timestamp: nowStr
      };
    });

    this.sensors.set(updated);
    this.historyMap.set(history);
  }

  /**
   * Manually inject an environmental or physical surge into a sensor for scenario validation
   */
  public injectAnomaly(sensor_id: string, target_value: number): void {
    const list = this.sensors().map(s => {
      if (s.sensor_id === sensor_id) {
        return {
          ...s,
          current_value: target_value,
          rate_of_change_per_hour: (target_value - s.current_value) * 10
        };
      }
      return s;
    });
    this.sensors.set(list);
  }

  /**
   * Reset all sensors to pristine calibrated baseline values
   */
  public resetToBaseline(): void {
    const list = this.sensors().map(s => ({
      ...s,
      current_value: s.baseline_value,
      cusum_statistic: 0,
      rate_of_change_per_hour: 0
    }));
    this.sensors.set(list);
  }
}
