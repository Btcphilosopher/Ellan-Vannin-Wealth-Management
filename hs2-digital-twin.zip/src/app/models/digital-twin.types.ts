// ============================================================================
// HS2 DIGITAL TWIN — CORE DOMAIN TYPE SYSTEM & SCHEMAS
// Strict ISO 19650 / Railway Systems Engineering Domain Definition
// Label: SYNTHETIC HS2-LIKE DEMONSTRATION DATA — NOT OFFICIAL HS2 DATA
// ============================================================================

export type AssetId = string;
export type DocumentId = string;
export type SensorId = string;
export type DefectId = string;
export type TestId = string;
export type TrainId = string;
export type ScenarioId = string;

/**
 * Fundamental Railway Asset Classes matching Section 5
 */
export type CivilAssetType =
  | 'bridge'
  | 'viaduct'
  | 'tunnel'
  | 'portal'
  | 'cutting'
  | 'embankment'
  | 'retaining_wall'
  | 'earthwork'
  | 'culvert'
  | 'drainage_asset'
  | 'watercourse';

export type RailAssetType =
  | 'track'
  | 'rail'
  | 'sleeper'
  | 'slab'
  | 'ballast'
  | 'point'
  | 'crossing'
  | 'rail_joint';

export type ElectrificationAssetType =
  | 'overhead_line'
  | 'mast'
  | 'portal'
  | 'cantilever'
  | 'insulator'
  | 'transformer'
  | 'substation'
  | 'switchgear'
  | 'neutral_section'
  | 'autotransformer';

export type PowerAssetType =
  | 'HV_cable'
  | 'LV_cable'
  | 'transformer'
  | 'switchboard'
  | 'breaker'
  | 'substation'
  | 'UPS'
  | 'battery';

export type SignallingAssetType =
  | 'balise'
  | 'radio_block_centre'
  | 'interlocking'
  | 'axle_counter'
  | 'train_detection'
  | 'signalling_controller'
  | 'etcs_marker';

export type TelecomsAssetType =
  | 'fibre'
  | 'radio'
  | 'antenna'
  | 'network_switch'
  | 'data_centre'
  | 'telecoms_room'
  | 'frmcs_base_station';

export type StationAssetType =
  | 'platform'
  | 'concourse'
  | 'escalator'
  | 'lift'
  | 'door'
  | 'ventilation'
  | 'fire_system'
  | 'MEP'
  | 'building_envelope';

export type EnvironmentAssetType =
  | 'habitat'
  | 'water_body'
  | 'woodland'
  | 'noise_monitor'
  | 'air_quality_sensor'
  | 'weather_station'
  | 'ecological_asset'
  | 'landscape_bund';

export type AssetClass =
  | CivilAssetType
  | RailAssetType
  | ElectrificationAssetType
  | PowerAssetType
  | SignallingAssetType
  | TelecomsAssetType
  | StationAssetType
  | EnvironmentAssetType;

export type Discipline =
  | 'CIVILS'
  | 'TRACK'
  | 'OLE'
  | 'POWER'
  | 'SIGNALLING'
  | 'TELECOMS'
  | 'STATIONS'
  | 'TUNNELS'
  | 'DRAINAGE'
  | 'ENVIRONMENT'
  | 'SYSTEMS_INTEGRATION';

export type LifecycleState =
  | 'DESIGNED'
  | 'PLANNED'
  | 'UNDER_CONSTRUCTION'
  | 'AS_BUILT'
  | 'COMMISSIONED'
  | 'OPERATIONAL'
  | 'OUT_OF_SERVICE'
  | 'UNDER_MAINTENANCE'
  | 'DECOMMISSIONED';

export type InformationStatus =
  | 'WIP'          // Work In Progress (ISO 19650)
  | 'SHARED'       // Shared for coordination
  | 'PUBLISHED'    // Authorized for construction / operations
  | 'ARCHIVED';    // Historical reference

export type ValidationStatus =
  | 'VALIDATED'
  | 'WARNING'
  | 'FAILED'
  | 'PENDING_REVIEW';

export type RelationshipType =
  | 'CONTAINS'
  | 'PART_OF'
  | 'LOCATED_ON'
  | 'CONNECTED_TO'
  | 'POWERED_BY'
  | 'CONTROLLED_BY'
  | 'MONITORED_BY'
  | 'MAINTAINED_BY'
  | 'DEPENDS_ON'
  | 'PROTECTS'
  | 'DRAINS_TO'
  | 'SUPPLIES'
  | 'SERVES'
  | 'ADJACENT_TO'
  | 'INTERFACES_WITH';

export interface AssetRelationship {
  target_id: AssetId;
  relationship_type: RelationshipType;
  description?: string;
  confidence: number;
}

/**
 * British National Grid (OSGB36) and WGS84 Georeferencing
 */
export interface GeoReference {
  latitude: number;            // WGS84 decimal degrees (e.g. 51.5834)
  longitude: number;           // WGS84 decimal degrees (e.g. -0.4782)
  elevation_m: number;         // Height above ordnance datum Newlyn (m)
  bng_easting?: number;        // British National Grid Easting (m)
  bng_northing?: number;       // British National Grid Northing (m)
  chainage_m: number;          // Continuous route chainage along alignment (m)
  chainage_formatted: string;  // e.g. "CH 43+250"
  offset_m: number;            // Lateral offset from centerline (m, +ve right)
  route_section_id: string;    // e.g. "SEC-CHILTERNS-02"
}

export interface GeometryReference {
  bim_guid?: string;           // IFC 4x3 Globally Unique Identifier
  model_file?: string;         // e.g. "CVV-CIV-MOD-0042.ifc"
  layer_name?: string;
  lod?: 'LOD100' | 'LOD200' | 'LOD300' | 'LOD400' | 'LOD500';
  bounding_box?: {
    min_x: number; min_y: number; min_z: number;
    max_x: number; max_y: number; max_z: number;
  };
  mesh_type?: 'spline' | 'box' | 'cylinder' | 'viaduct_span' | 'tunnel_tube' | 'mast' | 'sensor_probe' | 'station_slab';
  dimensions?: {
    length_m?: number;
    width_m?: number;
    height_m?: number;
    radius_m?: number;
  };
}

export interface Provenance {
  source_system: string;       // e.g. "Bentley ProjectWise / OpenRail"
  source_document_id: string;  // e.g. "1MC04-B-DWG-00234"
  source_object_id: string;    // Element ID in authoring software
  revision: string;            // e.g. "P04.2"
  author: string;              // e.g. "Align JV Civils Team"
  created_at: string;
  approved_by?: string;
  approval_date?: string;
  cde_status: InformationStatus;
}

export type PropertySet = Record<string, string | number | boolean | null>;

/**
 * Universal Digital Twin Asset Model
 */
export interface Asset {
  asset_id: AssetId;
  parent_id?: AssetId | null;
  asset_class: AssetClass;
  discipline: Discipline;
  name: string;
  description: string;
  uniclass_code: string;       // e.g. "Pr_20_29_89_88 Track slab systems"
  geometry: GeometryReference;
  location: GeoReference;
  lifecycle_state: LifecycleState;
  information_status: InformationStatus;
  confidence: number;          // 0.0 to 1.0
  validation_status: ValidationStatus;
  properties: PropertySet;
  engineering_parameters: Record<string, { value: number | string; unit: string; description: string }>;
  relationships: AssetRelationship[];
  provenance: Provenance;
  valid_from: string;
  valid_to?: string;
  last_observed: string;
  last_updated: string;
}

/**
 * Track Engineering Physics & Geometry
 */
export interface TrackEngineeringData {
  rail_profile: '60E2' | '60E1' | '56E1';
  rail_steel_grade: 'R260' | 'R350HT' | 'R400HT';
  track_form: 'Slab_Track_RHEDA2000' | 'Slab_Track_PORR' | 'Ballasted_HighSpeed';
  sleeper_spacing_m: number;
  design_speed_kmh: number;
  actual_gauge_mm: number;      // nominal 1435 mm
  cant_mm: number;              // actual cross-level (mm)
  cant_deficiency_mm: number;   // I = 11.82 * V^2 / R - D
  curvature_radius_m: number;   // Infinity for tangent track
  gradient_permille: number;    // % or ‰ (vertical alignment)
  rail_temperature_c: number;
  stress_free_temperature_c: number; // typically 27°C in UK
  thermal_stress_mpa: number;   // E * alpha * delta_T
  buckling_risk_index: 'LOW' | 'MODERATE' | 'CRITICAL';
  vertical_geometry_sd_mm: number; // Standard deviation of level (ISO track quality)
  alignment_geometry_sd_mm: number;
}

/**
 * Overhead Line Electrification (OLE) 25kV AC Engineering Data
 */
export interface OLEEngineeringData {
  system_type: 'AT_25kV_50Hz' | 'Classic_25kV';
  contact_wire_height_m: number;  // nominal 4.70m - 5.08m
  contact_wire_stagger_mm: number;// lateral zigzag e.g. +200mm / -200mm
  contact_wire_tension_kn: number;// typically 20 kN for 360 km/h
  catenary_wire_tension_kn: number; // typically 15 kN
  span_length_m: number;
  contact_wire_wear_percent: number;
  pantograph_uplift_mm: number;
  dropper_condition: 'HEALTHY' | 'SLACK' | 'BROKEN';
  insulator_cleanliness: 'CLEAN' | 'POLLUTED' | 'FLASHOVER_RISK';
  electrical_section_id: string;
  is_energized: boolean;
  neutral_section: boolean;
}

/**
 * Power Distribution Network (25-0-25kV Autotransformer)
 */
export interface PowerSubstationData {
  substation_id: string;
  name: string;
  type: 'BSP_400kV_TFS' | 'TFS_Traction_Feeder' | 'ATS_Autotransformer_Site' | 'MP_Midpoint_Sectioning';
  grid_infeed_voltage_kv: number;  // 400 kV or 132 kV
  catenary_feeder_voltage_kv: number; // 25.0 kV
  feeder_current_a: number;
  active_power_mw: number;
  reactive_power_mvar: number;
  power_factor: number;
  transformer_temp_c: number;
  thermal_loading_percent: number;
  circuit_breaker_status: 'CLOSED' | 'TRIPPED' | 'OPEN_MAINTENANCE';
  backup_ups_battery_percent: number;
}

/**
 * Signalling & Train Control (ETCS Level 2 / Baseline 3)
 */
export interface SignallingZoneData {
  zone_id: string;
  rbc_id: string; // Radio Block Centre ID
  interlocking_state: 'LOCKED' | 'PROCEED' | 'RESTRICTED' | 'OCCUPIED' | 'FAULT';
  movement_authority_end_chainage_m: number;
  active_train_id?: string;
  axle_counter_status: 'CLEAR' | 'OCCUPIED' | 'DISTURBED';
  balise_count: number;
  radio_coverage_margin_db: number;
  emergency_brake_intervention_curve_active: boolean;
}

/**
 * Rolling Stock / High-Speed Train Digital Twin
 */
export interface TrainDigitalTwin {
  train_id: TrainId;
  unit_number: string;          // e.g. "HS2-SET-014"
  model: 'Class_895_Captive' | 'Class_890_Classic_Compatible';
  composition: string;          // "8-car 200m EMU formation"
  mass_tonnes: number;          // 440 t tare
  max_speed_kmh: number;        // 360 km/h in revenue, 400 km/h design
  traction_power_kw: number;    // 9600 kW
  
  // Real-time kinematic & electrical state
  current_chainage_m: number;
  current_speed_kmh: number;
  target_speed_kmh: number;
  acceleration_ms2: number;
  pantograph_voltage_kv: number;
  traction_current_a: number;
  power_draw_mw: number;
  regenerative_braking_mw: number;
  energy_consumption_kwh: number;
  pantograph_state: 'RAISED' | 'LOWERED' | 'ARCING';
  door_interlock_status: 'LOCKED_SECURE' | 'RELEASED' | 'OBSTRUCTION';
  etcs_operating_mode: 'FS_Full_Supervision' | 'OS_On_Sight' | 'SR_Staff_Responsible' | 'TR_Trip';
  passenger_load_percent: number;
  bearing_temp_c: number;
  hvac_status: 'OPTIMAL' | 'REDUCED_CAPACITY';
  service_id: string;           // e.g. "1Z42 London Euston -> Birmingham Curzon St"
  delay_seconds: number;
}

/**
 * Structural Health Monitoring & Environmental Sensors
 */
export type SensorType =
  | 'PIEZOMETER_PORE_PRESSURE'
  | 'INCLINOMETER_SLOPE_TILT'
  | 'VIBRATING_WIRE_STRAIN'
  | 'OPTICAL_FIBRE_DTS_TEMP'
  | 'TILT_METER_PIER'
  | 'ACCELEROMETER_VIBRATION'
  | 'WEATHER_RAIN_GAUGE'
  | 'ANEMOMETER_WIND_SPEED'
  | 'RAIL_TEMP_PROBE'
  | 'CRACK_DISPLACEMENT_LVDT'
  | 'WATER_LEVEL_RADAR'
  | 'CABLE_CURRENT_CT';

export type SensorHealth = 'OPERATIONAL' | 'DEGRADED_ACCURACY' | 'BATTERY_LOW' | 'COMMUNICATION_FAULT' | 'OFFLINE';

export interface Sensor {
  sensor_id: SensorId;
  asset_id: AssetId;
  sensor_type: SensorType;
  model: string;
  serial_number: string;
  installation_date: string;
  calibration_expiry: string;
  sampling_interval_sec: number;
  unit: string;
  baseline_value: number;
  warning_threshold_low?: number;
  warning_threshold_high?: number;
  critical_threshold_high?: number;
  current_value: number;
  rate_of_change_per_hour: number;
  cusum_statistic: number;
  health: SensorHealth;
  last_reading_timestamp: string;
  battery_percent: number;
  signal_rssi_dbm: number;
}

export interface SensorReading {
  sensor_id: SensorId;
  timestamp: string;
  value: number;
  raw_value?: number;
  is_anomaly: boolean;
  anomaly_confidence?: number;
}

/**
 * 4D Construction Programme Item
 */
export interface ConstructionActivity {
  activity_id: string;
  wbs_code: string;             // e.g. "1.3.4.2.1"
  name: string;
  asset_id: AssetId;
  contractor: string;           // e.g. "Align JV (Bouygues/Volker/Sir Robert McAlpine)"
  planned_start: string;
  planned_finish: string;
  forecast_start: string;
  forecast_finish: string;
  actual_start?: string;
  actual_finish?: string;
  percent_complete: number;
  status: 'NOT_STARTED' | 'PLANNED' | 'IN_PROGRESS' | 'PART_COMPLETE' | 'COMPLETE' | 'INSPECTED' | 'ACCEPTED' | 'REWORK';
  dependencies: string[];
  variance_days: number;
  critical_path: boolean;
}

/**
 * 5D Cost & Carbon Item
 */
export interface AssetCostCarbon {
  asset_id: AssetId;
  currency: 'GBP';
  quantity: number;
  unit: string;                 // e.g. "m3", "tonnes", "linear_m"
  unit_rate_gbp: number;
  labour_cost_gbp: number;
  plant_cost_gbp: number;
  materials_cost_gbp: number;
  subcontract_cost_gbp: number;
  risk_contingency_gbp: number;
  planned_total_gbp: number;
  actual_total_gbp: number;
  variance_gbp: number;
  
  // Carbon accounting
  primary_material: string;     // e.g. "Low-carbon GGBS Concrete C50/60"
  material_mass_tonnes: number;
  embodied_carbon_factor_kgco2e_per_tonne: number;
  transport_carbon_kgco2e: number;
  construction_energy_carbon_kgco2e: number;
  total_embodied_carbon_kgco2e: number;
  operational_carbon_annual_kgco2e: number;
  carbon_reduction_vs_baseline_percent: number;
}

/**
 * Maintenance & Defect Management
 */
export interface Defect {
  defect_id: DefectId;
  asset_id: AssetId;
  title: string;
  description: string;
  severity: 'CRITICAL_SAFETY' | 'OPERATIONAL_RESTRICTION' | 'MAINTENANCE_REQUIRED' | 'MINOR_COSMETIC';
  status: 'IDENTIFIED' | 'INVESTIGATING' | 'REPAIR_SCHEDULED' | 'WORK_IN_PROGRESS' | 'VERIFIED_CLOSED';
  chainage_m: number;
  date_found: string;
  found_by: string;
  responsible_entity: string;
  evidence_document_id?: string;
  remedial_action_required: string;
  target_resolution_date: string;
  resolved_date?: string;
}

export interface MaintenanceRecord {
  record_id: string;
  asset_id: AssetId;
  type: 'PREVENTATIVE' | 'CORRECTIVE' | 'CONDITION_BASED' | 'STATUTORY_INSPECTION' | 'TAMPING_REPAIR';
  description: string;
  performed_date: string;
  next_due_date: string;
  technician_team: string;
  passed: boolean;
  notes: string;
  cost_gbp: number;
}

export interface TestingCommissioningItem {
  test_id: TestId;
  asset_id: AssetId;
  system_discipline: Discipline;
  test_case_name: string;
  standard_reference: string;    // e.g. "NR/L2/SIG/30014 / TSI ENE"
  status: 'NOT_TESTED' | 'PLANNED' | 'IN_PROGRESS' | 'PASS' | 'FAIL' | 'RETEST' | 'ACCEPTED';
  test_date: string;
  witnessed_by: string;
  measured_value?: string;
  acceptable_tolerance?: string;
  certificate_document_id?: string;
}

/**
 * Common Data Environment (CDE) Document Object (ISO 19650)
 */
export interface CDEDocument {
  document_id: DocumentId;
  document_number: string;      // e.g. "1MC04-ALN-CIV-DWG-CS04-000421"
  title: string;
  discipline: Discipline;
  status: InformationStatus;
  suitability_code: string;     // e.g. "S4 - For Review and Acceptance"
  revision: string;             // e.g. "P03"
  author_organization: string;
  created_date: string;
  approved_date?: string;
  file_format: 'IFC4x3' | 'PDF' | 'DWG' | 'DGN' | 'GEOJSON' | 'PARQUET' | 'STEP';
  file_size_mb: number;
  linked_asset_ids: AssetId[];
  cde_uri: string;
}

/**
 * Digital Twin System Event & Audit Trail
 */
export type EventSeverity = 'INFO' | 'NOTICE' | 'WARNING' | 'CRITICAL' | 'ALARM';

export interface DigitalTwinEvent {
  event_id: string;
  timestamp: string;
  severity: EventSeverity;
  category:
    | 'ASSET_STATE'
    | 'CONSTRUCTION'
    | 'TELEMETRY_ANOMALY'
    | 'SIGNALLING_INTERLOCKING'
    | 'POWER_PROTECTION'
    | 'TRAIN_MOVEMENT'
    | 'ENVIRONMENTAL_SURGE'
    | 'MAINTENANCE_POSSESSION'
    | 'AUDIT_CHANGE';
  asset_id?: AssetId;
  chainage_m?: number;
  title: string;
  message: string;
  actor: string;
  provenance_ref?: string;
}

/**
 * What-If Simulation Scenario Specification
 */
export interface SimulationScenario {
  scenario_id: ScenarioId;
  name: string;
  description: string;
  category: 'EXTREME_WEATHER' | 'POWER_OUTAGE' | 'TRACK_SETTLEMENT' | 'TRAIN_BREAKDOWN' | 'CONSTRUCTION_POSSESSION';
  triggered_at?: string;
  is_active: boolean;
  parameters: {
    rainfall_intensity_mm_hr?: number;
    ambient_temp_c?: number;
    substation_outage_id?: string;
    speed_restriction_kmh?: number;
    speed_restriction_chainage_start_m?: number;
    speed_restriction_chainage_end_m?: number;
    affected_assets: AssetId[];
  };
  simulated_outcomes: {
    train_delay_minutes: number;
    passenger_capacity_loss_percent: number;
    risk_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
    remedial_actions: string[];
    affected_services: string[];
  };
}

/**
 * System Health & Validation Manifest
 */
export interface TwinDataQualityManifest {
  twin_version: string;
  schema_version: string;
  total_assets_registered: number;
  total_sensors_online: number;
  data_freshness_seconds: number;
  spatial_integrity_score_percent: number;
  relationship_completeness_percent: number;
  provenance_coverage_percent: number;
  validation_anomalies_count: number;
  last_audit_timestamp: string;
}
