// ============================================================================
// UNIVERSAL ASSET INSPECTOR COMPONENT
// Multi-discipline deep inspection: BIM, GIS, Engineering Parameters,
// Design vs As-Built, Sensors, Maintenance, Defects, Cost, Carbon & Graph.
// ============================================================================

import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStoreService } from '../../services/digital-twin-store.service';
import { SHMTelemetryService } from '../../services/shm-telemetry.service';

@Component({
  selector: 'app-asset-inspector',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      @if (store.selectedAsset(); as asset) {
        <!-- Asset Header Summary Card -->
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl relative overflow-hidden">
          <div class="absolute top-0 right-0 w-48 h-48 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>

          <div class="flex flex-wrap items-start justify-between gap-3 border-b border-slate-800 pb-3 mb-3">
            <div class="space-y-1">
              <div class="flex items-center gap-2">
                <span class="px-2 py-0.5 bg-cyan-500/20 text-cyan-300 font-mono text-xs rounded font-bold uppercase">
                  {{ asset.discipline }}
                </span>
                <span class="text-xs font-mono text-slate-400">UNICLASS: {{ asset.uniclass_code }}</span>
                <span class="px-1.5 py-0.5 bg-slate-800 text-slate-300 font-mono text-[10px] rounded">
                  BIM GUID: {{ asset.geometry.bim_guid || 'N/A' }}
                </span>
              </div>
              <h1 class="text-xl font-bold text-white tracking-wide">{{ asset.name }}</h1>
              <p class="text-xs text-slate-300 max-w-3xl leading-relaxed">{{ asset.description }}</p>
            </div>

            <div class="flex flex-col items-end gap-1.5 font-mono text-xs">
              <div class="flex items-center gap-1.5">
                <span class="text-slate-400">STATE:</span>
                <span class="px-2 py-0.5 rounded font-bold"
                  [class.bg-emerald-500/20]="asset.lifecycle_state === 'OPERATIONAL' || asset.lifecycle_state === 'COMMISSIONED'"
                  [class.text-emerald-300]="asset.lifecycle_state === 'OPERATIONAL' || asset.lifecycle_state === 'COMMISSIONED'"
                  [class.bg-amber-500/20]="asset.lifecycle_state === 'UNDER_CONSTRUCTION'"
                  [class.text-amber-300]="asset.lifecycle_state === 'UNDER_CONSTRUCTION'">
                  {{ asset.lifecycle_state }}
                </span>
              </div>
              <div class="flex items-center gap-1.5">
                <span class="text-slate-400">CONFIDENCE:</span>
                <span class="text-cyan-300 font-bold">{{ (asset.confidence * 100).toFixed(0) }}%</span>
                <span class="px-1.5 py-0.2 bg-slate-800 text-emerald-400 rounded text-[10px]">ISO 19650 {{ asset.information_status }}</span>
              </div>
            </div>
          </div>

          <!-- Fast Coordinate Reference Grid -->
          <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 font-mono text-xs bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <div>
              <span class="text-slate-400 block text-[10px]">ROUTE CHAINAGE</span>
              <span class="text-cyan-300 font-bold">{{ asset.location.chainage_formatted }}</span>
            </div>
            <div>
              <span class="text-slate-400 block text-[10px]">ELEVATION</span>
              <span class="text-white font-bold">{{ asset.location.elevation_m.toFixed(1) }} m AOD</span>
            </div>
            <div>
              <span class="text-slate-400 block text-[10px]">BNG EASTING</span>
              <span class="text-slate-300">{{ asset.location.bng_easting || 'N/A' }}</span>
            </div>
            <div>
              <span class="text-slate-400 block text-[10px]">BNG NORTHING</span>
              <span class="text-slate-300">{{ asset.location.bng_northing || 'N/A' }}</span>
            </div>
            <div>
              <span class="text-slate-400 block text-[10px]">WGS84 LAT/LNG</span>
              <span class="text-slate-300">{{ asset.location.latitude.toFixed(4) }}, {{ asset.location.longitude.toFixed(4) }}</span>
            </div>
            <div>
              <span class="text-slate-400 block text-[10px]">ROUTE SECTION</span>
              <span class="text-slate-300">{{ asset.location.route_section_id }}</span>
            </div>
          </div>
        </div>

        <!-- 3-Column Engineering Detail Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <!-- Column 1: Engineering Parameters & Properties -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow space-y-3">
            <div class="flex items-center gap-2 font-mono text-xs font-bold text-cyan-400 border-b border-slate-800 pb-2">
              <mat-icon class="text-sm">settings_input_component</mat-icon>
              <span>ENGINEERING PARAMETERS & LIMITS</span>
            </div>

            <div class="space-y-2 font-mono text-xs">
              @for (entry of getEngineeringParamEntries(asset.engineering_parameters); track entry.key) {
                <div class="bg-slate-950 p-2.5 rounded border border-slate-800/80">
                  <div class="flex items-center justify-between text-slate-300">
                    <span class="text-slate-400">{{ entry.key }}</span>
                    <span class="text-white font-bold">{{ entry.value.value }} {{ entry.value.unit }}</span>
                  </div>
                  <p class="text-[10px] text-slate-400 mt-1 font-sans">{{ entry.value.description }}</p>
                </div>
              }
            </div>

            <!-- Asset Specific Properties -->
            <div class="pt-2 border-t border-slate-800">
              <div class="text-[11px] font-mono font-bold text-slate-300 mb-2">DESIGN ATTRIBUTES:</div>
              <div class="space-y-1 font-mono text-xs">
                @for (prop of getPropertyEntries(asset.properties); track prop.key) {
                  <div class="flex items-center justify-between py-1 border-b border-slate-800/40">
                    <span class="text-slate-400 text-[11px]">{{ prop.key }}:</span>
                    <span class="text-slate-200 text-[11px] font-bold">{{ prop.val }}</span>
                  </div>
                }
              </div>
            </div>
          </div>

          <!-- Column 2: Live Telemetry, SHM & Defects -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow space-y-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <div class="flex items-center gap-2 font-mono text-xs font-bold text-cyan-400">
                <mat-icon class="text-sm">sensors</mat-icon>
                <span>MONITORED TELEMETRY & SHM PROBES</span>
              </div>
              <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            </div>

            <!-- Linked Sensors -->
            <div class="space-y-2">
              @if (linkedSensors().length === 0) {
                <div class="p-3 bg-slate-950 border border-slate-800 rounded text-xs text-slate-400 font-mono text-center">
                  No direct telemetry probes assigned to this sub-element.
                </div>
              }
              @for (sensor of linkedSensors(); track sensor.sensor_id) {
                <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                  <div class="flex items-center justify-between font-mono text-xs mb-1">
                    <span class="text-slate-300 font-bold truncate">{{ sensor.model }}</span>
                    <span class="px-1.5 py-0.2 rounded text-[10px] font-bold"
                      [class.bg-emerald-500/20]="sensor.health === 'OPERATIONAL'"
                      [class.text-emerald-300]="sensor.health === 'OPERATIONAL'">
                      {{ sensor.health }}
                    </span>
                  </div>
                  <div class="flex items-baseline justify-between font-mono">
                    <span class="text-[11px] text-slate-400">{{ sensor.sensor_type }}</span>
                    <span class="text-base font-bold text-cyan-300">
                      {{ sensor.current_value }} <span class="text-xs text-slate-400">{{ sensor.unit }}</span>
                    </span>
                  </div>
                  <div class="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800 text-[10px] font-mono text-slate-400">
                    <div>BASELINE: {{ sensor.baseline_value }} {{ sensor.unit }}</div>
                    <div>CUSUM SCORE: {{ sensor.cusum_statistic }}</div>
                  </div>
                </div>
              }
            </div>

            <!-- Linked Defects & Closeout Status -->
            <div class="pt-2 border-t border-slate-800">
              <div class="flex items-center justify-between text-[11px] font-mono font-bold text-slate-300 mb-2">
                <span>ACTIVE DEFECTS / LOGS:</span>
                <span class="text-rose-400 font-bold">{{ linkedDefects().length }} Recorded</span>
              </div>
              <div class="space-y-2">
                @for (defect of linkedDefects(); track defect.defect_id) {
                  <div class="bg-rose-950/20 border border-rose-800/40 p-2.5 rounded text-xs font-mono">
                    <div class="flex items-center justify-between text-rose-300 font-bold mb-1">
                      <span>{{ defect.defect_id }}</span>
                      <span class="px-1 bg-rose-500/20 text-rose-300 rounded text-[9px]">{{ defect.severity }}</span>
                    </div>
                    <div class="text-white font-bold mb-1">{{ defect.title }}</div>
                    <p class="text-[11px] text-slate-300 font-sans mb-1.5">{{ defect.description }}</p>
                    <div class="text-[10px] text-slate-400 border-t border-rose-900/30 pt-1">
                      REMEDY: {{ defect.remedial_action_required }}
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>

          <!-- Column 3: Provenance, Relationships & 5D Cost/Carbon -->
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow space-y-3">
            <div class="flex items-center gap-2 font-mono text-xs font-bold text-cyan-400 border-b border-slate-800 pb-2">
              <mat-icon class="text-sm">hub</mat-icon>
              <span>RELATIONSHIP GRAPH & DEPENDENCIES</span>
            </div>

            <!-- First-Class Engineering Relationships -->
            <div class="space-y-1.5 font-mono text-xs max-h-48 overflow-y-auto">
              @for (rel of asset.relationships; track rel.target_id) {
                <button
                  type="button"
                  (click)="store.selectAsset(rel.target_id)"
                  class="w-full text-left p-2 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded flex items-center justify-between cursor-pointer transition">
                  <div>
                    <span class="text-cyan-400 font-bold text-[11px]">{{ rel.relationship_type }} &rarr;</span>
                    <span class="text-slate-200 ml-1.5">{{ rel.target_id }}</span>
                  </div>
                  <span class="text-[10px] text-slate-400">{{ (rel.confidence * 100).toFixed(0) }}% conf</span>
                </button>
              }
            </div>

            <!-- 5D Cost & Carbon summary if present -->
            @if (linkedCostCarbon(); as cc) {
              <div class="pt-2 border-t border-slate-800">
                <div class="text-[11px] font-mono font-bold text-slate-300 mb-2">5D COST & CARBON AUDIT:</div>
                <div class="bg-slate-950 p-2.5 rounded border border-slate-800 font-mono text-xs space-y-1.5">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-400">ACTUAL COST:</span>
                    <span class="text-emerald-400 font-bold">£{{ (cc.actual_total_gbp / 1e6).toFixed(2) }}M</span>
                  </div>
                  <div class="flex items-center justify-between">
                    <span class="text-slate-400">EMBODIED CO2e:</span>
                    <span class="text-cyan-300 font-bold">{{ (cc.total_embodied_carbon_kgco2e / 1000).toFixed(1) }} tCO2e</span>
                  </div>
                  <div class="flex items-center justify-between text-[11px]">
                    <span class="text-slate-400">SAVING VS BASELINE:</span>
                    <span class="text-emerald-400 font-bold">-{{ cc.carbon_reduction_vs_baseline_percent }}%</span>
                  </div>
                </div>
              </div>
            }

            <!-- Provenance & CDE ISO 19650 -->
            <div class="pt-2 border-t border-slate-800 font-mono text-xs space-y-1">
              <div class="text-[11px] font-bold text-slate-300 mb-1">PROVENANCE & AUDIT CHAIN:</div>
              <div class="text-slate-400 text-[10px]">SOURCE SYSTEM: <span class="text-slate-200">{{ asset.provenance.source_system }}</span></div>
              <div class="text-slate-400 text-[10px]">DOCUMENT REF: <span class="text-cyan-300">{{ asset.provenance.source_document_id }}</span> (Rev {{ asset.provenance.revision }})</div>
              <div class="text-slate-400 text-[10px]">AUTHOR: <span class="text-slate-200">{{ asset.provenance.author }}</span></div>
              <div class="text-slate-400 text-[10px]">APPROVED BY: <span class="text-slate-200">{{ asset.provenance.approved_by || 'Pending Sign-off' }}</span></div>
            </div>
          </div>
        </div>
      } @else {
        <div class="h-full flex items-center justify-center p-12 text-slate-400 font-mono text-sm">
          Please select an asset in the 3D Twin, Route Profile or Asset Register to view its complete engineering dossier.
        </div>
      }
    </div>
  `
})
export class AssetInspector {
  public store = inject(DigitalTwinStoreService);
  public shmService = inject(SHMTelemetryService);

  public linkedSensors = computed(() => {
    const asset = this.store.selectedAsset();
    if (!asset) return [];
    return this.shmService.sensors().filter(s => s.asset_id === asset.asset_id);
  });

  public linkedDefects = computed(() => {
    const asset = this.store.selectedAsset();
    if (!asset) return [];
    return this.store.defects().filter(d => d.asset_id === asset.asset_id);
  });

  public linkedCostCarbon = computed(() => {
    const asset = this.store.selectedAsset();
    if (!asset) return null;
    return this.store.costCarbon().find(c => c.asset_id === asset.asset_id) || null;
  });

  public getEngineeringParamEntries(params: Record<string, { value: number | string; unit: string; description: string }>): { key: string; value: { value: number | string; unit: string; description: string } }[] {
    if (!params) return [];
    return Object.keys(params).map(k => ({ key: k, value: params[k] }));
  }

  public getPropertyEntries(props: Record<string, string | number | boolean | null>): { key: string; val: string | number | boolean | null }[] {
    if (!props) return [];
    return Object.keys(props).map(k => ({ key: k, val: props[k] }));
  }
}
