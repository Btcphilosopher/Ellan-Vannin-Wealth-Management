// ============================================================================
// 5D COST & CARBON DIGITAL TWIN VIEW
// Bill of Quantities, Embodied & Operational Carbon accounting,
// low-carbon concrete GGBS factors, and lifecycle carbon savings.
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStoreService } from '../../services/digital-twin-store.service';

@Component({
  selector: 'app-cost-carbon-5d',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      <!-- 5D Cost & Carbon Executive Header -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow">
          <span class="text-xs font-mono text-slate-400 block">TOTAL COMMITTED COST (5D)</span>
          <div class="text-xl font-bold font-mono text-white mt-1">£{{ (totalPlannedCost / 1e6).toFixed(1) }}M</div>
          <span class="text-[11px] font-mono text-emerald-400">Actual vs Planned: -£{{ (totalCostVariance / 1e6).toFixed(1) }}M (Under Budget)</span>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow">
          <span class="text-xs font-mono text-slate-400 block">EMBODIED CARBON (TOTAL)</span>
          <div class="text-xl font-bold font-mono text-cyan-300 mt-1">{{ (totalEmbodiedCarbonTonnes).toLocaleString() }} tCO2e</div>
          <span class="text-[11px] font-mono text-slate-400">Average 142 kgCO2e / tonne material</span>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow">
          <span class="text-xs font-mono text-slate-400 block">CARBON SAVINGS VS BASELINE</span>
          <div class="text-xl font-bold font-mono text-emerald-400 mt-1">-42.8%</div>
          <span class="text-[11px] font-mono text-emerald-300">Saved 148,000 tCO2e via GGBS & Hollow Piers</span>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow">
          <span class="text-xs font-mono text-slate-400 block">OPERATIONAL RAIL ENERGY</span>
          <div class="text-xl font-bold font-mono text-indigo-300 mt-1">100% Zero-Carbon</div>
          <span class="text-[11px] font-mono text-indigo-400">Certified REGO 25kV Traction Supply</span>
        </div>
      </div>

      <!-- Cost Breakdown Table by Major Work Packages -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-mono text-xs font-bold text-cyan-400">
            <mat-icon class="text-sm">account_balance_wallet</mat-icon>
            <span>5D COST ELEMENT HIERARCHY & BILL OF QUANTITIES (BoQ)</span>
          </div>
          <span class="text-xs font-mono text-slate-400">SYNTHETIC AUDITED DEMONSTRATION COST</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left font-mono text-xs">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th class="p-2.5">ASSET ID</th>
                <th class="p-2.5">PRIMARY MATERIAL & QUANTITY</th>
                <th class="p-2.5">LABOUR</th>
                <th class="p-2.5">PLANT</th>
                <th class="p-2.5">MATERIALS</th>
                <th class="p-2.5">TOTAL ACTUAL</th>
                <th class="p-2.5">VARIANCE</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-300">
              @for (item of store.costCarbon(); track item.asset_id) {
                <tr class="hover:bg-slate-800/50 transition">
                  <td class="p-2.5 text-cyan-300 font-bold">{{ item.asset_id }}</td>
                  <td class="p-2.5 text-white font-medium">
                    {{ item.quantity.toLocaleString() }} {{ item.unit }}
                    <span class="block text-[10px] text-slate-400">{{ item.primary_material }}</span>
                  </td>
                  <td class="p-2.5">£{{ (item.labour_cost_gbp / 1e6).toFixed(1) }}M</td>
                  <td class="p-2.5">£{{ (item.plant_cost_gbp / 1e6).toFixed(1) }}M</td>
                  <td class="p-2.5">£{{ (item.materials_cost_gbp / 1e6).toFixed(1) }}M</td>
                  <td class="p-2.5 text-white font-bold">£{{ (item.actual_total_gbp / 1e6).toFixed(2) }}M</td>
                  <td class="p-2.5 font-bold text-emerald-400">-£{{ (Math.abs(item.variance_gbp) / 1e6).toFixed(1) }}M</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Carbon Factor Sensitivity & Material Intensity Analysis -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-mono text-xs font-bold text-cyan-400">
            <mat-icon class="text-sm">eco</mat-icon>
            <span>CARBON DIGITAL TWIN & MATERIAL SENSITIVITY ENVELOPE</span>
          </div>
          <span class="text-xs font-mono text-slate-400">PAS 2080 INFRASTRUCTURE CARBON COMPLIANT</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          @for (item of store.costCarbon(); track item.asset_id) {
            <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800 font-mono text-xs space-y-2">
              <div class="flex items-center justify-between border-b border-slate-800 pb-1.5">
                <span class="text-cyan-300 font-bold">{{ item.asset_id }}</span>
                <span class="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 rounded text-[10px] font-bold">
                  -{{ item.carbon_reduction_vs_baseline_percent }}% CO2e
                </span>
              </div>
              <div class="space-y-1 text-[11px]">
                <div class="flex justify-between text-slate-400">
                  <span>TOTAL EMBODIED:</span>
                  <span class="text-white font-bold">{{ (item.total_embodied_carbon_kgco2e / 1000).toLocaleString() }} tCO2e</span>
                </div>
                <div class="flex justify-between text-slate-400">
                  <span>FACTOR:</span>
                  <span class="text-slate-200">{{ item.embodied_carbon_factor_kgco2e_per_tonne }} kgCO2e/t</span>
                </div>
                <div class="flex justify-between text-slate-400">
                  <span>TRANSPORT:</span>
                  <span class="text-slate-200">{{ (item.transport_carbon_kgco2e / 1000).toFixed(0) }} tCO2e</span>
                </div>
                <div class="flex justify-between text-slate-400">
                  <span>ANNUAL OPS:</span>
                  <span class="text-slate-200">{{ (item.operational_carbon_annual_kgco2e / 1000).toFixed(1) }} tCO2e/yr</span>
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class CostCarbon5D {
  public store = inject(DigitalTwinStoreService);
  public Math = Math;

  public get totalPlannedCost(): number {
    return this.store.costCarbon().reduce((acc, c) => acc + c.planned_total_gbp, 0);
  }

  public get totalCostVariance(): number {
    return Math.abs(this.store.costCarbon().reduce((acc, c) => acc + c.variance_gbp, 0));
  }

  public get totalEmbodiedCarbonTonnes(): number {
    return Math.round(this.store.costCarbon().reduce((acc, c) => acc + c.total_embodied_carbon_kgco2e, 0) / 1000);
  }
}
