// ============================================================================
// ROUTE PROFILE & LINEAR REFERENCING SYNOPTIC VIEW
// High-precision elevation, gradient, curvature, speed limit & cant profile
// with interactive chainage scrubber across the 100km corridor.
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStoreService } from '../../services/digital-twin-store.service';
import { LinearReferencingService } from '../../services/linear-referencing.service';

@Component({
  selector: 'app-route-profile-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 bg-cyan-500/20 text-cyan-300 font-mono text-xs rounded font-bold">LINEAR REFERENCING</span>
            <h2 class="text-lg font-bold text-white tracking-wide">HS2 Main Line Alignment Profile & Geometry</h2>
          </div>
          <p class="text-xs text-slate-400 mt-0.5">Continuous 100 km High-Speed corridor from London Euston (CH 00+000) to Birmingham Curzon Street (CH 98+500)</p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs bg-slate-900 border border-slate-800 rounded-lg p-2">
          <span class="text-slate-400">LOCATOR:</span>
          <input
            type="number"
            [value]="store.currentChainageM()"
            (input)="onManualChainageInput($event)"
            min="0"
            max="100000"
            step="100"
            class="w-24 bg-slate-800 border border-slate-700 text-cyan-300 font-bold px-2 py-1 rounded text-center focus:outline-none focus:border-cyan-500" />
          <span class="text-white font-bold">{{ store.currentChainagePoint().chainage_formatted }}</span>
        </div>
      </div>

      <!-- Interactive Synoptic Corridor Track Ribbon (0 - 100km) -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-lg">
        <div class="flex items-center justify-between text-xs font-mono text-slate-400 mb-2">
          <span class="flex items-center gap-1"><mat-icon class="text-xs text-cyan-400">tune</mat-icon> CLICK OR DRAG TO POSITION DIGITAL TWIN INSPECTION CURSOR</span>
          <span class="text-cyan-400 font-bold">{{ (store.currentChainageM() / 1000).toFixed(2) }} km of 100.00 km</span>
        </div>

        <!-- Track ribbon track slider -->
        <button
          type="button"
          class="relative w-full h-14 bg-slate-950 border border-slate-800 rounded-lg overflow-hidden cursor-pointer text-left focus:outline-none focus:border-cyan-500"
          (click)="onRibbonClick($event)">
          <!-- Base Track Lines -->
          <div class="absolute top-1/2 left-0 right-0 h-1 bg-slate-800 -translate-y-1/2"></div>
          <div class="absolute top-1/2 left-0 right-0 h-0.5 bg-cyan-900/60 -translate-y-1/2"></div>

          <!-- Major Civil Assets on Ribbon -->
          @for (wp of waypoints; track wp.chainage_m) {
            <div
              class="absolute top-0 bottom-0 flex flex-col items-center justify-between py-1 group -translate-x-1/2 pointer-events-none"
              [style.left.%]="(wp.chainage_m / 100000) * 100">
              <div class="w-1.5 h-1.5 rounded-full bg-slate-500 group-hover:bg-cyan-400"></div>
              <span class="text-[9px] font-mono text-slate-400 group-hover:text-cyan-300 whitespace-nowrap -rotate-45 origin-bottom-left select-none">
                {{ wp.description.split(' ')[0] }}
              </span>
              <div class="w-0.5 h-2 bg-slate-700"></div>
            </div>
          }

          <!-- Live Trains on Ribbon -->
          @for (trn of store.trains(); track trn.train_id) {
            <div
              class="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-20 pointer-events-none"
              [style.left.%]="(trn.current_chainage_m / 100000) * 100">
              <div class="flex items-center gap-1 px-1.5 py-0.5 bg-cyan-500 text-slate-950 rounded shadow-md font-mono text-[9px] font-bold">
                <mat-icon class="text-[10px]">train</mat-icon>
                <span>{{ trn.unit_number.replace('HS2-SET-', 'T') }} ({{ trn.current_speed_kmh.toFixed(0) }}k)</span>
              </div>
            </div>
          }

          <!-- Active Chainage Cursor Indicator -->
          <div
            class="absolute top-0 bottom-0 w-1 bg-rose-500 z-30 shadow-[0_0_12px_rgba(244,63,94,0.9)] -translate-x-1/2 pointer-events-none"
            [style.left.%]="(store.currentChainageM() / 100000) * 100">
            <div class="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-rose-500 rotate-45"></div>
          </div>
        </button>

        <!-- Key Station & Landmark Pins -->
        <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 mt-3 text-[11px] font-mono">
          <button (click)="store.setChainage(0)" class="p-2 bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 rounded text-left transition">
            <div class="text-cyan-400 font-bold">CH 00+000</div>
            <div class="text-slate-300 truncate">London Euston</div>
          </button>
          <button (click)="store.setChainage(7800)" class="p-2 bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 rounded text-left transition">
            <div class="text-cyan-400 font-bold">CH 07+800</div>
            <div class="text-slate-300 truncate">Old Oak Common</div>
          </button>
          <button (click)="store.setChainage(22800)" class="p-2 bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 rounded text-left transition">
            <div class="text-cyan-400 font-bold">CH 22+800</div>
            <div class="text-slate-300 truncate">Colne Valley Viaduct</div>
          </button>
          <button (click)="store.setChainage(26000)" class="p-2 bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 rounded text-left transition">
            <div class="text-cyan-400 font-bold">CH 26+000</div>
            <div class="text-slate-300 truncate">Chiltern Tunnel 16km</div>
          </button>
          <button (click)="store.setChainage(74500)" class="p-2 bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 rounded text-left transition">
            <div class="text-cyan-400 font-bold">CH 74+500</div>
            <div class="text-slate-300 truncate">Calvert Deep Cutting</div>
          </button>
          <button (click)="store.setChainage(98500)" class="p-2 bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 rounded text-left transition">
            <div class="text-cyan-400 font-bold">CH 98+500</div>
            <div class="text-slate-300 truncate">Curzon St Birmingham</div>
          </button>
        </div>
      </div>

      <!-- Elevation Profile & Track Geometry Synoptic Chart -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-lg space-y-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-mono text-sm font-bold text-white">
            <mat-icon class="text-cyan-400">show_chart</mat-icon>
            <span>ENGINEERING LONGITUDINAL PROFILE & GEOMETRY ENVELOPES</span>
          </div>
          <span class="text-xs font-mono text-slate-400">DATUM: ORDNANCE DATUM NEWLYN (ODN)</span>
        </div>

        <!-- SVG Longitudinal Elevation & Gradient Chart -->
        <div class="relative w-full h-56 bg-slate-950 border border-slate-800 rounded-lg p-2 overflow-hidden">
          <svg class="w-full h-full" viewBox="0 0 1000 200" preserveAspectRatio="none">
            <defs>
              <linearGradient id="elevationGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#06b6d4" stop-opacity="0.35"/>
                <stop offset="100%" stop-color="#06b6d4" stop-opacity="0.0"/>
              </linearGradient>
            </defs>

            <!-- Horizontal Grid lines (50m, 100m, 150m) -->
            <line x1="0" y1="160" x2="1000" y2="160" stroke="#1e293b" stroke-width="1" stroke-dasharray="4"/>
            <line x1="0" y1="100" x2="1000" y2="100" stroke="#1e293b" stroke-width="1" stroke-dasharray="4"/>
            <line x1="0" y1="40" x2="1000" y2="40" stroke="#1e293b" stroke-width="1" stroke-dasharray="4"/>

            <text x="10" y="155" fill="#64748b" font-family="monospace" font-size="10">50 m</text>
            <text x="10" y="95" fill="#64748b" font-family="monospace" font-size="10">100 m</text>
            <text x="10" y="35" fill="#64748b" font-family="monospace" font-size="10">150 m ODN</text>

            <!-- Tunnel subterranean shaded zones (Chiltern Tunnel 26k-42k) -->
            <rect x="260" y="20" width="160" height="170" fill="#3b82f6" fill-opacity="0.08" stroke="#3b82f6" stroke-opacity="0.3" stroke-dasharray="4"/>
            <text x="270" y="35" fill="#60a5fa" font-family="monospace" font-size="9">CHILTERN TUNNEL 16km</text>

            <!-- Colne Valley Viaduct elevated deck span (21.5k - 24.9k) -->
            <rect x="215" y="100" width="34" height="20" fill="#f59e0b" fill-opacity="0.2" stroke="#f59e0b" stroke-opacity="0.6"/>
            <text x="215" y="95" fill="#fbbf24" font-family="monospace" font-size="9">COLNE VALLEY VIADUCT</text>

            <!-- Elevation Area Path -->
            <path [attr.d]="elevationAreaSvgPath" fill="url(#elevationGrad)"/>
            <!-- Elevation Line Path -->
            <path [attr.d]="elevationLineSvgPath" fill="none" stroke="#22d3ee" stroke-width="2.5"/>

            <!-- Active Chainage Cursor Line -->
            <line
              [attr.x1]="(store.currentChainageM() / 100000) * 1000"
              y1="0"
              [attr.x2]="(store.currentChainageM() / 100000) * 1000"
              y2="200"
              stroke="#f43f5e"
              stroke-width="2"/>
            <circle
              [attr.cx]="(store.currentChainageM() / 100000) * 1000"
              [attr.cy]="200 - (store.currentChainagePoint().elevation_m / 160) * 180"
              r="4.5"
              fill="#f43f5e"
              stroke="#ffffff"
              stroke-width="1.5"/>
          </svg>
        </div>

        <!-- Engineering Geometry Parameters Breakdown Grid -->
        <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 font-mono text-xs">
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span class="text-slate-400 block text-[10px]">LINE GRADIENT</span>
            <span class="text-lg font-bold"
              [class.text-emerald-400]="store.currentChainagePoint().gradient_permille >= 0"
              [class.text-amber-400]="store.currentChainagePoint().gradient_permille < 0">
              {{ store.currentChainagePoint().gradient_permille > 0 ? '+' : '' }}{{ store.currentChainagePoint().gradient_permille.toFixed(1) }} ‰
            </span>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span class="text-slate-400 block text-[10px]">APPLIED CANT (D)</span>
            <span class="text-lg font-bold text-cyan-300">{{ store.currentChainagePoint().cant_mm }} mm</span>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span class="text-slate-400 block text-[10px]">HORIZONTAL RADIUS (R)</span>
            <span class="text-lg font-bold text-slate-200">
              {{ formatRadius(store.currentChainagePoint().radius_m) }}
            </span>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span class="text-slate-400 block text-[10px]">CANT DEFICIENCY (I)</span>
            <span class="text-lg font-bold text-indigo-300">
              {{ cantDeficiency.toFixed(1) }} mm
            </span>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span class="text-slate-400 block text-[10px]">DESIGN SPEED LIMIT</span>
            <span class="text-lg font-bold text-emerald-400">{{ store.currentChainagePoint().speed_limit_kmh }} km/h</span>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span class="text-slate-400 block text-[10px]">BNG COORDINATES</span>
            <span class="text-xs font-bold text-slate-300 block">E {{ store.currentChainagePoint().easting.toFixed(0) }}</span>
            <span class="text-xs font-bold text-slate-300 block">N {{ store.currentChainagePoint().northing.toFixed(0) }}</span>
          </div>
        </div>
      </div>

      <!-- Assets Located Within Vicinity of Current Chainage -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-lg space-y-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-mono text-sm font-bold text-white">
            <mat-icon class="text-cyan-400">near_me</mat-icon>
            <span>ENGINEERING ASSETS WITHIN VICINITY (±2.5 km of {{ store.currentChainagePoint().chainage_formatted }})</span>
          </div>
          <span class="text-xs font-mono px-2 py-0.5 bg-slate-800 text-slate-300 rounded">
            {{ store.assetsNearCurrentChainage().length }} Assets Found
          </span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          @for (asset of store.assetsNearCurrentChainage(); track asset.asset_id) {
            <button
              type="button"
              (click)="store.selectAsset(asset.asset_id)"
              class="w-full text-left p-3 bg-slate-950 border rounded-lg cursor-pointer transition flex flex-col justify-between"
              [class.border-cyan-500]="store.selectedAssetId() === asset.asset_id"
              [class.border-slate-800]="store.selectedAssetId() !== asset.asset_id"
              [class.hover:border-slate-700]="store.selectedAssetId() !== asset.asset_id">
              <div>
                <div class="flex items-start justify-between gap-2 mb-1.5">
                  <span class="px-1.5 py-0.5 bg-slate-800 text-cyan-300 font-mono text-[10px] rounded font-bold">
                    {{ asset.discipline }}
                  </span>
                  <span class="text-slate-400 font-mono text-[11px] font-bold">
                    {{ asset.location.chainage_formatted }}
                  </span>
                </div>
                <h4 class="font-bold text-white text-sm truncate">{{ asset.name }}</h4>
                <p class="text-xs text-slate-400 line-clamp-2 mt-1">{{ asset.description }}</p>
              </div>

              <div class="flex items-center justify-between pt-2 mt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
                <span>{{ asset.asset_id }}</span>
                <span class="px-1.5 py-0.2 rounded text-[10px]"
                  [class.text-emerald-400]="asset.validation_status === 'VALIDATED'"
                  [class.text-amber-400]="asset.validation_status === 'WARNING'">
                  {{ asset.validation_status }}
                </span>
              </div>
            </button>
          }
        </div>
      </div>
    </div>
  `
})
export class RouteProfileView {
  public store = inject(DigitalTwinStoreService);
  private linearRef = inject(LinearReferencingService);

  public formatRadius(r: number): string {
    return (!isFinite(r) || r >= 100000) ? 'Tangent (Straight)' : `R = ${r} m`;
  }

  public waypoints = this.linearRef.getAlignmentWaypoints();

  public get cantDeficiency(): number {
    const pt = this.store.currentChainagePoint();
    return this.linearRef.calculateCantDeficiency(pt.speed_limit_kmh, pt.radius_m, pt.cant_mm);
  }

  public get elevationLineSvgPath(): string {
    const pts = this.waypoints.map(wp => {
      const x = (wp.chainage_m / 100000) * 1000;
      const y = 200 - (wp.elevation_m / 160) * 180;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });
    return `M ${pts.join(' L ')}`;
  }

  public get elevationAreaSvgPath(): string {
    const pts = this.waypoints.map(wp => {
      const x = (wp.chainage_m / 100000) * 1000;
      const y = 200 - (wp.elevation_m / 160) * 180;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });
    return `M 0,200 L ${pts.join(' L ')} L 1000,200 Z`;
  }

  public onRibbonClick(e: MouseEvent): void {
    const target = e.currentTarget as HTMLElement;
    const rect = target.getBoundingClientRect();
    const clickRatio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    this.store.setChainage(clickRatio * 100000);
  }

  public onManualChainageInput(e: Event): void {
    const val = parseFloat((e.target as HTMLInputElement).value);
    if (!isNaN(val)) {
      this.store.setChainage(val);
    }
  }
}
