// ============================================================================
// 4D CONSTRUCTION PROGRAMME & DIGITAL REHEARSAL
// WBS hierarchy, schedule variance, critical path, 4D time slider (2022 - 2030)
// and automated digital rehearsal sequence.
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStoreService } from '../../services/digital-twin-store.service';

@Component({
  selector: 'app-programme-4d-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      <!-- 4D Time Machine Controller Card -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl">
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3 mb-3">
          <div>
            <div class="flex items-center gap-2">
              <span class="px-2 py-0.5 bg-cyan-500/20 text-cyan-300 font-mono text-xs rounded font-bold">4D PROGRAMME ENGINE</span>
              <h2 class="text-lg font-bold text-white tracking-wide">Temporal Construction State & Rehearsal</h2>
            </div>
            <p class="text-xs text-slate-400 mt-0.5">Replay the physical development of the railway from ground-breaking through testing and revenue operations.</p>
          </div>

          <div class="flex items-center gap-2">
            <button
              (click)="store.toggleTimeReplay()"
              class="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-mono text-xs font-bold rounded-lg shadow transition flex items-center gap-1.5">
              <mat-icon class="text-sm">{{ store.isTimeReplayPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
              <span>{{ store.isTimeReplayPlaying() ? 'PAUSE REPLAY' : '4D DIGITAL REHEARSAL' }}</span>
            </button>
            <span class="px-3 py-1.5 bg-slate-950 border border-slate-700 font-mono text-xs font-bold text-cyan-300 rounded-lg">
              YEAR {{ store.timeSliderYear().toFixed(2) }} ({{ getFormattedDateFromYear(store.timeSliderYear()) }})
            </span>
          </div>
        </div>

        <!-- Time Slider Bar -->
        <div class="space-y-2">
          <input
            type="range"
            min="2022"
            max="2030"
            step="0.05"
            [value]="store.timeSliderYear()"
            (input)="onTimeSliderInput($event)"
            class="w-full accent-cyan-500 h-2 bg-slate-800 rounded-lg cursor-pointer" />

          <div class="flex items-center justify-between font-mono text-[10px] text-slate-400">
            <span>2022 (EARTHWORKS)</span>
            <span>2024 (CIVILS & TUNNELLING)</span>
            <span>2025 (TRACK & OLE)</span>
            <span>2026 (DYNAMIC TESTING 400k)</span>
            <span>2028 (COMMISSIONING)</span>
            <span>2030 (FULL OPERATIONS)</span>
          </div>
        </div>
      </div>

      <!-- WBS Construction Activity Schedule Table -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-mono text-xs font-bold text-cyan-400">
            <mat-icon class="text-sm">schedule</mat-icon>
            <span>WORK BREAKDOWN STRUCTURE (WBS) & CRITICAL PATH STATUS</span>
          </div>
          <span class="text-xs font-mono text-slate-400">PLANNED VS FORECAST COMPLETION</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left font-mono text-xs">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th class="p-2.5">WBS</th>
                <th class="p-2.5">ACTIVITY DESCRIPTION</th>
                <th class="p-2.5">CONTRACTOR</th>
                <th class="p-2.5">PLANNED DATES</th>
                <th class="p-2.5">PROGRESS</th>
                <th class="p-2.5">VARIANCE</th>
                <th class="p-2.5">STATUS</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-300">
              @for (act of store.programme(); track act.activity_id) {
                <tr class="hover:bg-slate-800/50 transition">
                  <td class="p-2.5 text-cyan-300 font-bold">{{ act.wbs_code }}</td>
                  <td class="p-2.5 text-white font-medium">
                    {{ act.name }}
                    @if (act.critical_path) {
                      <span class="ml-1.5 px-1 bg-rose-500/20 text-rose-300 rounded text-[9px] font-bold">CRITICAL</span>
                    }
                  </td>
                  <td class="p-2.5 text-slate-400">{{ act.contractor }}</td>
                  <td class="p-2.5 text-slate-400">{{ act.planned_start }} &rarr; {{ act.planned_finish }}</td>
                  <td class="p-2.5">
                    <div class="flex items-center gap-2">
                      <div class="w-20 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div class="bg-cyan-400 h-full rounded-full" [style.width.%]="act.percent_complete"></div>
                      </div>
                      <span class="text-[11px] font-bold">{{ act.percent_complete }}%</span>
                    </div>
                  </td>
                  <td class="p-2.5 font-bold"
                    [class.text-emerald-400]="act.variance_days <= 0"
                    [class.text-rose-400]="act.variance_days > 0">
                    {{ act.variance_days <= 0 ? act.variance_days + 'd (AHEAD)' : '+' + act.variance_days + 'd (DELAY)' }}
                  </td>
                  <td class="p-2.5">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-emerald-500/20]="act.status === 'COMPLETE' || act.status === 'ACCEPTED'"
                      [class.text-emerald-300]="act.status === 'COMPLETE' || act.status === 'ACCEPTED'"
                      [class.bg-cyan-500/20]="act.status === 'IN_PROGRESS'"
                      [class.text-cyan-300]="act.status === 'IN_PROGRESS'">
                      {{ act.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class Programme4DView {
  public store = inject(DigitalTwinStoreService);

  public onTimeSliderInput(e: Event): void {
    const val = parseFloat((e.target as HTMLInputElement).value);
    if (!isNaN(val)) {
      this.store.setTimeSlider(val);
    }
  }

  public getFormattedDateFromYear(yearFloat: number): string {
    const year = Math.floor(yearFloat);
    const month = Math.floor((yearFloat - year) * 12) + 1;
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[month - 1] || 'Jan'} ${year}`;
  }
}
