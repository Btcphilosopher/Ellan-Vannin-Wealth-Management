// ============================================================================
// 3D SPATIAL DIGITAL TWIN COMPONENT (Three.js WebGL Engine)
// Authentic civil engineering rendering: 100km alignment spline, viaduct spans,
// tunnel tubes, OLE catenary, live train meshes, sensor beacons & raycasting.
// ============================================================================

import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  effect,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { DigitalTwinStoreService } from '../../services/digital-twin-store.service';
import { LinearReferencingService } from '../../services/linear-referencing.service';

@Component({
  selector: 'app-spatial-twin-3d',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full overflow-hidden bg-slate-950 flex flex-col select-none">
      <!-- 3D Canvas Container -->
      <div #canvasContainer class="w-full flex-1 relative cursor-grab active:cursor-grabbing">
        <canvas #webglCanvas class="w-full h-full block"></canvas>

        <!-- 3D Viewport HUD Overlay -->
        <div class="absolute top-3 left-3 z-10 flex flex-col gap-2 pointer-events-none">
          <div class="bg-slate-900/90 backdrop-blur border border-slate-700/80 rounded-lg p-2.5 shadow-xl text-xs font-mono pointer-events-auto">
            <div class="flex items-center gap-2 text-cyan-400 font-bold border-b border-slate-700 pb-1.5 mb-1.5">
              <mat-icon class="text-sm">view_in_ar</mat-icon>
              <span>3D ENGINEERING SPATIAL TWIN</span>
              <span class="ml-auto px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded text-[10px]">LOD 400</span>
            </div>
            <div class="grid grid-cols-2 gap-x-3 gap-y-1 text-slate-300">
              <div>CHAINAGE: <span class="text-white font-bold">{{ store.currentChainagePoint().chainage_formatted }}</span></div>
              <div>ELEVATION: <span class="text-white font-bold">{{ store.currentChainagePoint().elevation_m.toFixed(1) }} m AOD</span></div>
              <div>EASTING: <span class="text-slate-400">{{ store.currentChainagePoint().easting.toFixed(0) }}</span></div>
              <div>NORTHING: <span class="text-slate-400">{{ store.currentChainagePoint().northing.toFixed(0) }}</span></div>
              <div>CURVATURE: <span class="text-slate-400">{{ formatRadius(store.currentChainagePoint().radius_m) }}</span></div>
              <div>CANT: <span class="text-slate-400">{{ store.currentChainagePoint().cant_mm }} mm</span></div>
            </div>
          </div>

          <!-- Camera Preset Quick Actions -->
          <div class="flex flex-wrap gap-1.5 pointer-events-auto">
            <button
              (click)="setCameraPreset('overview')"
              class="px-2.5 py-1 text-xs bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded shadow transition flex items-center gap-1">
              <mat-icon class="text-xs">map</mat-icon> Corridor Overview
            </button>
            <button
              (click)="setCameraPreset('colne_valley')"
              class="px-2.5 py-1 text-xs bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded shadow transition flex items-center gap-1">
              <mat-icon class="text-xs">bridge</mat-icon> Colne Valley Viaduct
            </button>
            <button
              (click)="setCameraPreset('chiltern_tunnel')"
              class="px-2.5 py-1 text-xs bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded shadow transition flex items-center gap-1">
              <mat-icon class="text-xs">tunnel</mat-icon> Chiltern Tunnel
            </button>
            <button
              (click)="setCameraPreset('calvert_cutting')"
              class="px-2.5 py-1 text-xs bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded shadow transition flex items-center gap-1">
              <mat-icon class="text-xs">terrain</mat-icon> Calvert Cutting
            </button>
            <button
              (click)="setCameraPreset('curzon_street')"
              class="px-2.5 py-1 text-xs bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded shadow transition flex items-center gap-1">
              <mat-icon class="text-xs">train</mat-icon> Curzon St Birmingham
            </button>
          </div>
        </div>

        <!-- 3D Layer Toggles (Right overlay) -->
        <div class="absolute top-3 right-3 z-10 bg-slate-900/90 backdrop-blur border border-slate-700/80 rounded-lg p-2.5 shadow-xl text-xs font-mono max-w-[200px]">
          <div class="flex items-center gap-1.5 text-cyan-400 font-bold border-b border-slate-700 pb-1.5 mb-1.5">
            <mat-icon class="text-sm">layers</mat-icon>
            <span>FEDERATED LAYERS</span>
          </div>
          <div class="space-y-1">
            <label class="flex items-center justify-between cursor-pointer hover:text-white text-slate-300">
              <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-slate-400 inline-block"></span> Civils & Viaducts</span>
              <input type="checkbox" [checked]="store.layers().civils" (change)="store.toggleLayer('civils')" class="accent-cyan-500 rounded" />
            </label>
            <label class="flex items-center justify-between cursor-pointer hover:text-white text-slate-300">
              <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block"></span> Track Slabs (60E2)</span>
              <input type="checkbox" [checked]="store.layers().track" (change)="store.toggleLayer('track')" class="accent-cyan-500 rounded" />
            </label>
            <label class="flex items-center justify-between cursor-pointer hover:text-white text-slate-300">
              <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-cyan-400 inline-block"></span> OLE 25kV Catenary</span>
              <input type="checkbox" [checked]="store.layers().ole" (change)="store.toggleLayer('ole')" class="accent-cyan-500 rounded" />
            </label>
            <label class="flex items-center justify-between cursor-pointer hover:text-white text-slate-300">
              <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-indigo-400 inline-block"></span> Tunnels & Portals</span>
              <input type="checkbox" [checked]="store.layers().tunnels" (change)="store.toggleLayer('tunnels')" class="accent-cyan-500 rounded" />
            </label>
            <label class="flex items-center justify-between cursor-pointer hover:text-white text-slate-300">
              <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block"></span> SHM Sensors</span>
              <input type="checkbox" [checked]="store.layers().sensors" (change)="store.toggleLayer('sensors')" class="accent-cyan-500 rounded" />
            </label>
            <label class="flex items-center justify-between cursor-pointer hover:text-white text-slate-300">
              <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-purple-400 inline-block"></span> Trains (Class 895)</span>
              <input type="checkbox" [checked]="store.layers().trains" (change)="store.toggleLayer('trains')" class="accent-cyan-500 rounded" />
            </label>
            <label class="flex items-center justify-between cursor-pointer hover:text-white text-slate-300">
              <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-emerald-700 inline-block"></span> Terrain Mesh</span>
              <input type="checkbox" [checked]="store.layers().terrain" (change)="store.toggleLayer('terrain')" class="accent-cyan-500 rounded" />
            </label>
          </div>
        </div>

        <!-- 3D Selected Object Callout Box (Bottom-Left) -->
        @if (store.selectedAsset(); as selected) {
          <div class="absolute bottom-3 left-3 z-10 bg-slate-900/95 backdrop-blur-md border border-cyan-500/50 rounded-lg p-3 shadow-2xl max-w-sm text-xs font-mono">
            <div class="flex items-start justify-between gap-2 border-b border-slate-700 pb-2 mb-2">
              <div>
                <span class="px-1.5 py-0.5 bg-cyan-500/20 text-cyan-300 rounded font-bold uppercase text-[10px]">{{ selected.discipline }}</span>
                <h4 class="font-bold text-white text-sm mt-0.5">{{ selected.name }}</h4>
              </div>
              <span class="px-1.5 py-0.5 rounded text-[10px] font-bold"
                [class.bg-emerald-500/20]="selected.lifecycle_state === 'OPERATIONAL' || selected.lifecycle_state === 'COMMISSIONED'"
                [class.text-emerald-300]="selected.lifecycle_state === 'OPERATIONAL' || selected.lifecycle_state === 'COMMISSIONED'"
                [class.bg-amber-500/20]="selected.lifecycle_state === 'UNDER_CONSTRUCTION'"
                [class.text-amber-300]="selected.lifecycle_state === 'UNDER_CONSTRUCTION'">
                {{ selected.lifecycle_state }}
              </span>
            </div>
            <p class="text-slate-300 line-clamp-2 mb-2">{{ selected.description }}</p>
            <div class="flex items-center justify-between text-[11px] text-slate-400">
              <span>LOC: {{ selected.location.chainage_formatted }}</span>
              <span>BIM: {{ selected.geometry.bim_guid?.substring(0, 10) || 'ISO-19650' }}</span>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class SpatialTwin3D implements OnInit, OnDestroy {
  public store = inject(DigitalTwinStoreService);
  private linearRef = inject(LinearReferencingService);

  @ViewChild('webglCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('canvasContainer', { static: true }) containerRef!: ElementRef<HTMLDivElement>;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  // 3D Object Group References
  private corridorGroup = new THREE.Group();
  private civilsGroup = new THREE.Group();
  private trackGroup = new THREE.Group();
  private oleGroup = new THREE.Group();
  private tunnelsGroup = new THREE.Group();
  private sensorsGroup = new THREE.Group();
  private trainsGroup = new THREE.Group();
  private terrainGroup = new THREE.Group();

  // Mouse interaction state
  private isDragging = false;
  private previousMousePosition = { x: 0, y: 0 };
  private cameraTarget = new THREE.Vector3(228, 5, 0); // Scaled world coordinates (1 unit = 100m)

  public formatRadius(r: number): string {
    return (!isFinite(r) || r >= 100000) ? 'Tangent (Straight)' : `R = ${r} m`;
  }

  constructor() {
    // React to layer visibility changes
    effect(() => {
      const layers = this.store.layers();
      this.civilsGroup.visible = layers.civils;
      this.trackGroup.visible = layers.track;
      this.oleGroup.visible = layers.ole;
      this.tunnelsGroup.visible = layers.tunnels;
      this.sensorsGroup.visible = layers.sensors;
      this.trainsGroup.visible = layers.trains;
      this.terrainGroup.visible = layers.terrain;
    });

    // React to selected chainage change to smoothly pan camera
    effect(() => {
      const ch = this.store.currentChainageM();
      const scaledX = ch / 100.0;
      this.cameraTarget.set(scaledX, 5, 0);
    });
  }

  ngOnInit(): void {
    this.initThreeJS();
    this.buildProceduralCorridor();
    this.setupEventListeners();
    this.animate();
  }

  ngOnDestroy(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThreeJS(): void {
    const canvas = this.canvasRef.nativeElement;
    const container = this.containerRef.nativeElement;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0f1d); // Deep engineering dark slate
    this.scene.fog = new THREE.FogExp2(0x0a0f1d, 0.0018);

    // Camera (1 unit = 100 meters in world coordinates)
    this.camera = new THREE.PerspectiveCamera(45, width / height, 1, 3000);
    this.camera.position.set(228, 45, 75); // Focused on Colne Valley
    this.camera.lookAt(this.cameraTarget);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xdde5ed, 0.7);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xffffff, 1.2);
    sunLight.position.set(200, 250, 150);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    this.scene.add(sunLight);

    const fillLight = new THREE.DirectionalLight(0x4a90e2, 0.4);
    fillLight.position.set(-100, 100, -100);
    this.scene.add(fillLight);

    // Add groups
    this.scene.add(this.corridorGroup);
    this.corridorGroup.add(this.terrainGroup);
    this.corridorGroup.add(this.civilsGroup);
    this.corridorGroup.add(this.trackGroup);
    this.corridorGroup.add(this.oleGroup);
    this.corridorGroup.add(this.tunnelsGroup);
    this.corridorGroup.add(this.sensorsGroup);
    this.corridorGroup.add(this.trainsGroup);

    // Grid Reference & Axis
    const grid = new THREE.GridHelper(1200, 120, 0x1e293b, 0x0f172a);
    grid.position.set(500, -2, 0);
    this.scene.add(grid);
  }

  /**
   * Build the procedural high-speed corridor 3D elements
   */
  private buildProceduralCorridor(): void {
    // 1. Terrain Mesh (100km undulating rolling hills of Chilterns and Colne Valley)
    const terrainGeo = new THREE.PlaneGeometry(1100, 200, 120, 30);
    terrainGeo.rotateX(-Math.PI / 2);
    terrainGeo.translate(500, 0, 0);

    const pos = terrainGeo.attributes['position'];
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      // Elevation wave based on Chiltern chalk hills
      const elevation = Math.sin(x * 0.03) * 6.0 + Math.cos(z * 0.05) * 4.0 - 4.0;
      pos.setY(i, Math.max(-8, elevation));
    }
    terrainGeo.computeVertexNormals();

    const terrainMat = new THREE.MeshStandardMaterial({
      color: 0x17252a,
      roughness: 0.9,
      metalness: 0.1,
      wireframe: false
    });
    const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
    terrainMesh.receiveShadow = true;
    this.terrainGroup.add(terrainMesh);

    // 2. Track Alignment Twin Rails & Concrete Base Slab (0 to 100km)
    // Slab Track Base
    const slabGeo = new THREE.BoxGeometry(1000, 0.4, 4.2);
    const slabMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8 });
    const slabMesh = new THREE.Mesh(slabGeo, slabMat);
    slabMesh.position.set(500, 0.2, 0);
    slabMesh.receiveShadow = true;
    this.trackGroup.add(slabMesh);

    // Up and Down Rails (60E2 profile steel lines)
    const railMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8, roughness: 0.2 });
    const railGeo = new THREE.BoxGeometry(1000, 0.2, 0.08);

    // Up line rails
    const railUpLeft = new THREE.Mesh(railGeo, railMat);
    railUpLeft.position.set(500, 0.5, -1.5);
    const railUpRight = new THREE.Mesh(railGeo, railMat);
    railUpRight.position.set(500, 0.5, -0.1);

    // Down line rails
    const railDnLeft = new THREE.Mesh(railGeo, railMat);
    railDnLeft.position.set(500, 0.5, 0.1);
    const railDnRight = new THREE.Mesh(railGeo, railMat);
    railDnRight.position.set(500, 0.5, 1.5);

    this.trackGroup.add(railUpLeft, railUpRight, railDnLeft, railDnRight);

    // 3. Colne Valley Viaduct (CH 21+500 to CH 24+900 -> X = 215 to 249)
    const cvvDeckGeo = new THREE.BoxGeometry(34, 1.4, 5.0);
    const cvvDeckMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.6 });
    const cvvDeck = new THREE.Mesh(cvvDeckGeo, cvvDeckMat);
    cvvDeck.position.set(232, 6.0, 0);
    cvvDeck.castShadow = true;
    cvvDeck.receiveShadow = true;
    cvvDeck.userData['assetId'] = 'CIV-VIAD-COLNE-01';
    this.civilsGroup.add(cvvDeck);

    // Viaduct V-shaped Piers
    const pierMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.7 });
    for (let p = 216; p <= 248; p += 4) {
      const pierGeo = new THREE.CylinderGeometry(0.6, 0.9, 6.0, 12);
      const pier = new THREE.Mesh(pierGeo, pierMat);
      pier.position.set(p, 3.0, 0);
      pier.castShadow = true;
      pier.userData['assetId'] = 'CIV-VIAD-COLNE-01';
      this.civilsGroup.add(pier);
    }

    // 4. Chiltern Tunnel Twin Bore Tubes (CH 26+000 to CH 42+000 -> X = 260 to 420)
    const tunnelMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.7,
      transparent: true,
      opacity: 0.65,
      wireframe: true
    });
    const tunnelGeo = new THREE.CylinderGeometry(2.2, 2.2, 160, 24, 1, true);
    tunnelGeo.rotateZ(Math.PI / 2);

    const tunnelNorth = new THREE.Mesh(tunnelGeo, tunnelMat);
    tunnelNorth.position.set(340, 0, -1.2);
    tunnelNorth.userData['assetId'] = 'CIV-TUNN-CHILTERN-01';

    const tunnelSouth = new THREE.Mesh(tunnelGeo, tunnelMat);
    tunnelSouth.position.set(340, 0, 1.2);
    tunnelSouth.userData['assetId'] = 'CIV-TUNN-CHILTERN-01';

    this.tunnelsGroup.add(tunnelNorth, tunnelSouth);

    // Tunnel Portals
    const portalGeo = new THREE.BoxGeometry(2.0, 5.0, 8.0);
    const portalMat = new THREE.MeshStandardMaterial({ color: 0x334155 });
    const portalSouth = new THREE.Mesh(portalGeo, portalMat);
    portalSouth.position.set(260, 2.0, 0);
    portalSouth.userData['assetId'] = 'CIV-TUNN-CHILTERN-01';
    const portalNorth = new THREE.Mesh(portalGeo, portalMat);
    portalNorth.position.set(420, 2.0, 0);
    portalNorth.userData['assetId'] = 'CIV-TUNN-CHILTERN-01';
    this.tunnelsGroup.add(portalSouth, portalNorth);

    // 5. Wendover Dean Viaduct (CH 53+200 -> X = 532)
    const wdvGeo = new THREE.BoxGeometry(4.5, 1.2, 4.8);
    const wdvMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.5 }); // Weathering steel tint
    const wdvDeck = new THREE.Mesh(wdvGeo, wdvMat);
    wdvDeck.position.set(532, 5.5, 0);
    wdvDeck.userData['assetId'] = 'CIV-VIAD-WENDOVER-01';
    this.civilsGroup.add(wdvDeck);

    // 6. OLE Catenary Portals & Wires (Sampled every 50m / 0.5 units)
    const mastMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.6 });

    for (let x = 0; x <= 1000; x += 6) {
      // Portal frame
      const frameGeo = new THREE.BoxGeometry(0.15, 4.5, 5.2);
      const frame = new THREE.Mesh(frameGeo, mastMat);
      frame.position.set(x, 2.4, 0);
      frame.userData['assetId'] = 'OLE-PORTAL-CVV-P28';
      this.oleGroup.add(frame);
    }

    // 7. Sensor Beacons with SHM Pulsing Markers
    this.store.assets().forEach(asset => {
      const x = asset.location.chainage_m / 100.0;
      const beaconGeo = new THREE.SphereGeometry(0.6, 16, 16);
      let col = 0x10b981; // emerald normal
      if (asset.validation_status === 'WARNING') col = 0xf59e0b;
      if (asset.lifecycle_state === 'UNDER_CONSTRUCTION') col = 0x06b6d4;

      const beaconMat = new THREE.MeshStandardMaterial({
        color: col,
        emissive: col,
        emissiveIntensity: 0.6
      });
      const beacon = new THREE.Mesh(beaconGeo, beaconMat);
      beacon.position.set(x, 3.5, asset.location.offset_m / 10.0 || 1.8);
      beacon.userData['assetId'] = asset.asset_id;
      this.sensorsGroup.add(beacon);
    });

    // 8. Stations: Old Oak Common (X = 78) and Curzon Street (X = 985)
    const oocGeo = new THREE.BoxGeometry(4.5, 2.2, 8.0);
    const oocMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, transparent: true, opacity: 0.85 });
    const ooc = new THREE.Mesh(oocGeo, oocMat);
    ooc.position.set(78, 1.0, 0);
    ooc.userData['assetId'] = 'STA-LON-OOC-01';
    this.civilsGroup.add(ooc);

    const curzonGeo = new THREE.CylinderGeometry(3.5, 3.5, 4.1, 16, 1, false, 0, Math.PI);
    curzonGeo.rotateZ(Math.PI / 2);
    const curzonMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.4 }); // Timber diagrid
    const curzon = new THREE.Mesh(curzonGeo, curzonMat);
    curzon.position.set(985, 2.5, 0);
    curzon.userData['assetId'] = 'STA-BHM-CURZON-01';
    this.civilsGroup.add(curzon);
  }

  /**
   * Update train positions in real time
   */
  private updateTrains(): void {
    // Clear previous train meshes
    while (this.trainsGroup.children.length > 0) {
      this.trainsGroup.remove(this.trainsGroup.children[0]);
    }

    const trainGeo = new THREE.BoxGeometry(2.0, 0.9, 0.7);
    const trainMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // British high-speed streamlined blue
      metalness: 0.5,
      roughness: 0.3
    });

    this.store.trains().forEach(trn => {
      const x = trn.current_chainage_m / 100.0;
      const trainMesh = new THREE.Mesh(trainGeo, trainMat);
      trainMesh.position.set(x, 1.0, -0.8);
      trainMesh.castShadow = true;
      trainMesh.userData['trainId'] = trn.train_id;
      this.trainsGroup.add(trainMesh);
    });
  }

  private animate = (): void => {
    this.animationFrameId = requestAnimationFrame(this.animate);

    // Smooth camera track to target
    this.camera.position.x += (this.cameraTarget.x - this.camera.position.x + 30) * 0.05;
    this.camera.lookAt(this.cameraTarget.x, 3, 0);

    // Refresh train positions
    this.updateTrains();

    this.renderer.render(this.scene, this.camera);
  };

  public setCameraPreset(preset: 'overview' | 'colne_valley' | 'chiltern_tunnel' | 'calvert_cutting' | 'curzon_street'): void {
    switch (preset) {
      case 'overview':
        this.cameraTarget.set(500, 5, 0);
        this.camera.position.set(500, 180, 280);
        this.store.setChainage(50000);
        break;
      case 'colne_valley':
        this.cameraTarget.set(232, 6, 0);
        this.camera.position.set(215, 30, 45);
        this.store.setChainage(22800);
        this.store.selectAsset('CIV-VIAD-COLNE-01');
        break;
      case 'chiltern_tunnel':
        this.cameraTarget.set(260, 2, 0);
        this.camera.position.set(250, 18, 30);
        this.store.setChainage(26000);
        this.store.selectAsset('CIV-TUNN-CHILTERN-01');
        break;
      case 'calvert_cutting':
        this.cameraTarget.set(745, 4, 0);
        this.camera.position.set(735, 22, 38);
        this.store.setChainage(74500);
        this.store.selectAsset('CIV-CUT-CALVERT-01');
        break;
      case 'curzon_street':
        this.cameraTarget.set(985, 3, 0);
        this.camera.position.set(975, 20, 35);
        this.store.setChainage(98500);
        this.store.selectAsset('STA-BHM-CURZON-01');
        break;
    }
  }

  private setupEventListeners(): void {
    const container = this.containerRef.nativeElement;

    // Window resize
    window.addEventListener('resize', () => {
      if (!container || !this.renderer) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });

    // Mouse drag for panning along corridor
    container.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const deltaX = e.clientX - this.previousMousePosition.x;
      this.cameraTarget.x -= deltaX * 0.4;
      this.cameraTarget.x = Math.max(0, Math.min(1000, this.cameraTarget.x));
      this.store.setChainage(this.cameraTarget.x * 100);
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    // Click raycasting to select asset
    container.addEventListener('click', (e) => {
      const rect = container.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      this.raycaster.setFromCamera(this.mouse, this.camera);
      const intersects = this.raycaster.intersectObjects(this.corridorGroup.children, true);

      if (intersects.length > 0) {
        for (const hit of intersects) {
          let curr: THREE.Object3D | null = hit.object;
          while (curr && curr !== this.scene) {
            const assetId = curr.userData['assetId'] as string | undefined;
            if (assetId) {
              this.store.selectAsset(assetId);
              return;
            }
            curr = curr.parent;
          }
        }
      }
    });
  }
}
