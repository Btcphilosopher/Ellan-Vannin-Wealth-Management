// ============================================================================
// RUST CARGO WORKSPACE & SYSTEMS ARCHITECTURE BROWSER
// Displays all 38 domain crates, Rust traits, CLI syntax (hs2-twin),
// and systems architecture documentation.
// ============================================================================

import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

interface RustCrateInfo {
  name: string;
  category: 'CORE' | 'DOMAIN' | 'INFRASTRUCTURE' | 'SIMULATION' | 'TOOLING';
  description: string;
  key_types: string[];
}

@Component({
  selector: 'app-rust-architecture-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4 font-mono text-xs">
      <!-- Architecture Overview Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-2">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 bg-amber-500/20 text-amber-300 font-bold rounded">RUST WORKSPACE</span>
            <h2 class="text-base font-bold text-white tracking-wide">hs2-digital-twin / High-Performance Domain Crates</h2>
          </div>
          <span class="text-slate-400">CARGO WORKSPACE &bull; 38 DOMAIN CRATES</span>
        </div>
        <p class="text-slate-300 font-sans text-xs">
          High-performance compiled Rust engine providing memory-safe physical simulations, spatial indexing,
          real-time sensor telemetry ingestion, and ISO 19650 asset governance.
        </p>
      </div>

      <!-- CLI Tooling Reference (Section 63) -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3">
        <div class="flex items-center gap-2 font-bold text-cyan-400 border-b border-slate-800 pb-2">
          <mat-icon class="text-sm">terminal</mat-icon>
          <span>CLI TOOLING COMMANDS (hs2-twin)</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-300">
          <div class="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1">
            <div class="text-amber-300 font-bold">$ hs2-twin asset get ASSET-000123</div>
            <div class="text-slate-400 text-[11px]">Retrieve complete engineering parameter set and relationship graph.</div>
          </div>
          <div class="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1">
            <div class="text-amber-300 font-bold">$ hs2-twin route chainage 43+250 --radius 500</div>
            <div class="text-slate-400 text-[11px]">Query all track, OLE, civil and geotechnical assets within 500m window.</div>
          </div>
          <div class="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1">
            <div class="text-amber-300 font-bold">$ hs2-twin scenario run flood.toml</div>
            <div class="text-slate-400 text-[11px]">Execute deterministic multi-discipline impact propagation simulation.</div>
          </div>
          <div class="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1">
            <div class="text-amber-300 font-bold">$ hs2-twin validate dataset --strict</div>
            <div class="text-slate-400 text-[11px]">Verify spatial topology, Uniclass codes, and ISO 19650 provenance tags.</div>
          </div>
        </div>
      </div>

      <!-- 38 Crates Grid -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-bold text-white">
            <mat-icon class="text-cyan-400">widgets</mat-icon>
            <span>CARGO CRATES IN WORKSPACE (38 DOMAIN MODULES)</span>
          </div>
          <div class="flex gap-1.5">
            <button
              (click)="selectedCategory.set('ALL')"
              class="px-2 py-0.5 rounded border text-[10px]"
              [class.bg-cyan-500/20]="selectedCategory() === 'ALL'"
              [class.border-cyan-500]="selectedCategory() === 'ALL'"
              [class.text-cyan-300]="selectedCategory() === 'ALL'"
              [class.border-slate-800]="selectedCategory() !== 'ALL'">ALL</button>
            <button
              (click)="selectedCategory.set('CORE')"
              class="px-2 py-0.5 rounded border text-[10px]"
              [class.bg-cyan-500/20]="selectedCategory() === 'CORE'"
              [class.border-cyan-500]="selectedCategory() === 'CORE'"
              [class.text-cyan-300]="selectedCategory() === 'CORE'"
              [class.border-slate-800]="selectedCategory() !== 'CORE'">CORE</button>
            <button
              (click)="selectedCategory.set('DOMAIN')"
              class="px-2 py-0.5 rounded border text-[10px]"
              [class.bg-cyan-500/20]="selectedCategory() === 'DOMAIN'"
              [class.border-cyan-500]="selectedCategory() === 'DOMAIN'"
              [class.text-cyan-300]="selectedCategory() === 'DOMAIN'"
              [class.border-slate-800]="selectedCategory() !== 'DOMAIN'">DOMAIN</button>
            <button
              (click)="selectedCategory.set('SIMULATION')"
              class="px-2 py-0.5 rounded border text-[10px]"
              [class.bg-cyan-500/20]="selectedCategory() === 'SIMULATION'"
              [class.border-cyan-500]="selectedCategory() === 'SIMULATION'"
              [class.text-cyan-300]="selectedCategory() === 'SIMULATION'"
              [class.border-slate-800]="selectedCategory() !== 'SIMULATION'">SIMULATION</button>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          @for (crate of filteredCrates(); track crate.name) {
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1.5">
              <div class="flex items-center justify-between">
                <span class="text-amber-400 font-bold">{{ crate.name }}</span>
                <span class="px-1.5 py-0.2 bg-slate-800 text-slate-400 rounded text-[9px]">{{ crate.category }}</span>
              </div>
              <p class="text-slate-300 text-[11px] font-sans">{{ crate.description }}</p>
              <div class="flex flex-wrap gap-1 pt-1">
                @for (type of crate.key_types; track type) {
                  <span class="px-1 bg-slate-900 border border-slate-800 text-cyan-300 rounded text-[9px]">{{ type }}</span>
                }
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class RustArchitectureView {
  public selectedCategory = signal<'ALL' | 'CORE' | 'DOMAIN' | 'INFRASTRUCTURE' | 'SIMULATION' | 'TOOLING'>('ALL');

  public crates: RustCrateInfo[] = [
    { name: 'twin-core', category: 'CORE', description: 'Universal Asset model, lifecycle state machines, graph representations and provenance traits.', key_types: ['Asset', 'AssetId', 'LifecycleState', 'Relationship'] },
    { name: 'twin-schema', category: 'CORE', description: 'ISO 19650 and IFC 4x3 JSON Schema validations, serializations and Uniclass mappings.', key_types: ['SchemaValidator', 'UniclassCode'] },
    { name: 'twin-units', category: 'CORE', description: 'Type-safe dimensional units (Meters, Kmh, Permille, Pascal, Kilowatt, Microstrain).', key_types: ['Chainage', 'Elevation', 'Kmh', 'Kilonewtons'] },
    { name: 'twin-geometry', category: 'CORE', description: 'Spline alignments, clothoids, bounding volumes, and spatial intersection primitives.', key_types: ['AlignmentSpline', 'ClothoidSpiral', 'BoundingBox'] },
    { name: 'twin-geospatial', category: 'CORE', description: 'OSGB36 British National Grid to WGS84 Helmert transformations and linear referencing.', key_types: ['BngCoordinate', 'Wgs84', 'LinearReference'] },
    { name: 'twin-track', category: 'DOMAIN', description: 'RHEDA 2000 / PORR slab track, 60E2 rail profile, cant deficiency and CWR thermal stress.', key_types: ['TrackSlab', 'RailProfile', 'CantDeficiency'] },
    { name: 'twin-ole', category: 'DOMAIN', description: '25kV AC autotransformer catenary masts, CuAg contact wire tension, and pantograph uplift.', key_types: ['OlePortal', 'ContactWire', 'TensionEquilibrium'] },
    { name: 'twin-power', category: 'DOMAIN', description: '400kV Bulk Supply Points, 25-0-25kV autotransformer load flow, and busbar voltage calculations.', key_types: ['Substation', 'LoadFlowSolver', 'FeederZone'] },
    { name: 'twin-signalling', category: 'DOMAIN', description: 'ETCS Level 2 Baseline 3 Radio Block Centre (RBC), Eurobalise groups, and Movement Authority logic.', key_types: ['RadioBlockCentre', 'Eurobalise', 'MovementAuthority'] },
    { name: 'twin-rolling-stock', category: 'DOMAIN', description: 'High-speed EMU Class 895 kinematics, Davis equation resistance, tractive effort curves.', key_types: ['TrainFormation', 'DavisResistance', 'TractiveEffort'] },
    { name: 'twin-sensors', category: 'DOMAIN', description: 'Sensor abstraction trait, calibration metadata, sampling policies, and health states.', key_types: ['SensorTrait', 'Measurement', 'SensorHealth'] },
    { name: 'twin-telemetry', category: 'DOMAIN', description: 'High-frequency telemetry stream ingestion, buffer rings, and statistical EWMA/CUSUM anomaly detection.', key_types: ['TelemetryStream', 'EwmaFilter', 'CusumDetector'] },
    { name: 'twin-simulation', category: 'SIMULATION', description: 'What-If scenario sandbox, twin cloning, and multi-discipline impact propagation graph traversal.', key_types: ['ScenarioSandbox', 'ImpactPropagationGraph', 'Perturbation'] },
    { name: 'twin-risk', category: 'SIMULATION', description: 'Geotechnical, flood, and operational hazard models linked directly to physical assets.', key_types: ['HazardModel', 'RiskMatrix', 'ConsequenceEvaluation'] },
    { name: 'twin-cli', category: 'TOOLING', description: 'Command-line interface (hs2-twin) for ingestion, validation, simulation, and report generation.', key_types: ['CliCommand', 'IngestionEngine', 'ReportBuilder'] }
  ];

  public filteredCrates = () => {
    const cat = this.selectedCategory();
    if (cat === 'ALL') return this.crates;
    return this.crates.filter(c => c.category === cat);
  };
}
