// ============================================================================
// WHAT-IF SCENARIO SANDBOX & IMPACT PROPAGATION
// Step-by-step digital twin feedback loop execution:
// Physical Railway -> Sensor Anomaly -> Twin Assessment -> Decision -> Recovery
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ScenarioEngineService } from '../../services/scenario-engine.service';
import { DigitalTwinStoreService } from '../../services/digital-twin-store.service';

@Component({
  selector: 'app-scenario-sandbox-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      <!-- Scenario Selector Cards -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-bold text-white">
            <mat-icon class="text-cyan-400">science</mat-icon>
            <span>WHAT-IF SCENARIO SIMULATION ENGINE & DIGITAL REHEARSAL</span>
          </div>
          <span class="text-slate-400">ISOLATED DIGITAL TWIN CLONE (LIVE TWIN UNMODIFIED)</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
          @for (scn of scenarioEngine.scenarios(); track scn.scenario_id) {
            <button
              type="button"
              (click)="scenarioEngine.selectScenario(scn.scenario_id)"
              class="w-full text-left p-3.5 bg-slate-950 border rounded-lg cursor-pointer transition flex flex-col justify-between"
              [class.border-cyan-500]="scenarioEngine.activeScenarioId() === scn.scenario_id"
              [class.border-slate-800]="scenarioEngine.activeScenarioId() !== scn.scenario_id">
              <div>
                <div class="flex items-center justify-between gap-2 mb-1.5">
                  <span class="px-1.5 py-0.5 bg-cyan-500/20 text-cyan-300 font-bold rounded text-[10px]">
                    {{ scn.category }}
                  </span>
                  <span class="text-[10px] font-bold"
                    [class.text-amber-400]="scn.simulated_outcomes.risk_level === 'MEDIUM'"
                    [class.text-rose-400]="scn.simulated_outcomes.risk_level === 'HIGH'"
                    [class.text-emerald-400]="scn.simulated_outcomes.risk_level === 'LOW'">
                    {{ scn.simulated_outcomes.risk_level }} RISK
                  </span>
                </div>
                <h4 class="font-bold text-white text-sm mt-1">{{ scn.name }}</h4>
                <p class="text-xs text-slate-400 font-sans mt-1 line-clamp-2">{{ scn.description }}</p>
              </div>

              <div class="flex items-center justify-between pt-2 mt-2 border-t border-slate-800/80 text-[11px] text-slate-400">
                <span>Delay: +{{ scn.simulated_outcomes.train_delay_minutes }} min</span>
                <span class="text-cyan-300 font-bold">SELECT &rarr;</span>
              </div>
            </button>
          }
        </div>
      </div>

      <!-- Active Scenario Step-by-Step Closed-Loop Execution -->
      @if (scenarioEngine.activeScenario(); as scn) {
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-4 font-mono text-xs">
          <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <span class="text-[10px] text-cyan-400 font-bold">ACTIVE SIMULATION:</span>
              <h3 class="text-base font-bold text-white">{{ scn.name }}</h3>
            </div>

            <div class="flex items-center gap-2">
              <button
                (click)="scenarioEngine.togglePlayback()"
                class="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-lg transition flex items-center gap-1">
                <mat-icon class="text-sm">{{ scenarioEngine.isRehearsalPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
                <span>{{ scenarioEngine.isRehearsalPlaying() ? 'PAUSE' : 'STEP-BY-STEP RUN' }}</span>
              </button>
              <button
                (click)="scenarioEngine.nextStep()"
                class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-lg border border-slate-700 transition">
                NEXT STEP &rarr;
              </button>
              <button
                (click)="scenarioEngine.resetScenario()"
                class="px-3 py-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 font-bold rounded-lg border border-rose-800/60 transition">
                RESET
              </button>
            </div>
          </div>

          <!-- Digital Twin Feedback Loop Sequence Steps -->
          <div class="space-y-3">
            @for (step of scenarioEngine.activeScenarioSteps(); track step.step_number) {
              <div
                class="p-3.5 rounded-lg border transition space-y-2"
                [class.bg-slate-950]="!step.completed && scenarioEngine.currentStepIndex() !== $index"
                [class.border-slate-800]="!step.completed && scenarioEngine.currentStepIndex() !== $index"
                [class.bg-cyan-950/20]="scenarioEngine.currentStepIndex() === $index"
                [class.border-cyan-500]="scenarioEngine.currentStepIndex() === $index"
                [class.bg-emerald-950/10]="step.completed && scenarioEngine.currentStepIndex() > $index"
                [class.border-emerald-800/60]="step.completed && scenarioEngine.currentStepIndex() > $index">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs"
                      [class.bg-cyan-500]="scenarioEngine.currentStepIndex() === $index"
                      [class.text-slate-950]="scenarioEngine.currentStepIndex() === $index"
                      [class.bg-emerald-500/20]="step.completed && scenarioEngine.currentStepIndex() > $index"
                      [class.text-emerald-300]="step.completed && scenarioEngine.currentStepIndex() > $index"
                      [class.bg-slate-800]="!step.completed && scenarioEngine.currentStepIndex() !== $index"
                      [class.text-slate-400]="!step.completed && scenarioEngine.currentStepIndex() !== $index">
                      {{ step.step_number }}
                    </span>
                    <span class="font-bold text-white text-sm">{{ step.phase_name }}</span>
                  </div>
                  <span class="text-slate-400 text-[11px]">T+{{ step.trigger_time_offset_min }} MIN</span>
                </div>

                <p class="text-xs text-slate-300 font-sans leading-relaxed">{{ step.description }}</p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-2 pt-2 border-t border-slate-800/80 text-[11px]">
                  <div><span class="text-slate-400">SYSTEM RESPONSE:</span> <span class="text-cyan-300">{{ step.system_response }}</span></div>
                  <div><span class="text-slate-400">OPERATIONAL IMPACT:</span> <span class="text-amber-300">{{ step.operational_impact }}</span></div>
                  <div class="col-span-2 text-[10px] text-slate-400"><span class="text-emerald-400">DECISION ENVELOPE:</span> {{ step.decision_rule }}</div>
                </div>
              </div>
            }
          </div>
        </div>
      }
    </div>
  `
})
export class ScenarioSandboxView {
  public scenarioEngine = inject(ScenarioEngineService);
  public store = inject(DigitalTwinStoreService);
}
