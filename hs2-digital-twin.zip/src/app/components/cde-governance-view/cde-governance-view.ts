// ============================================================================
// COMMON DATA ENVIRONMENT (CDE), GOVERNANCE & AUDIT TRAIL
// ISO 19650 information containers, Uniclass 2015 tables, data quality audits,
// immutable audit ledger, and role-based access security.
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStoreService } from '../../services/digital-twin-store.service';

@Component({
  selector: 'app-cde-governance-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      <!-- Data Quality & System Health Manifest -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono text-xs">
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow">
          <span class="text-slate-400 block text-[10px]">SPATIAL & TOPOLOGICAL INTEGRITY</span>
          <div class="text-xl font-bold text-emerald-400 mt-1">{{ store.qualityManifest().spatial_integrity_score_percent }}%</div>
          <span class="text-[10px] text-slate-400">Zero NaN / Zero invalid coordinates</span>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow">
          <span class="text-slate-400 block text-[10px]">RELATIONSHIP GRAPH COMPLETENESS</span>
          <div class="text-xl font-bold text-cyan-300 mt-1">{{ store.qualityManifest().relationship_completeness_percent }}%</div>
          <span class="text-[10px] text-slate-400">No orphan civil/rail assets detected</span>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow">
          <span class="text-slate-400 block text-[10px]">ISO 19650 PROVENANCE COVERAGE</span>
          <div class="text-xl font-bold text-indigo-300 mt-1">{{ store.qualityManifest().provenance_coverage_percent }}%</div>
          <span class="text-[10px] text-slate-400">Full author / revision sign-off chain</span>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-xl p-3.5 shadow">
          <span class="text-slate-400 block text-[10px]">TELEMETRY FRESHNESS</span>
          <div class="text-xl font-bold text-emerald-400 mt-1">&lt; {{ store.qualityManifest().data_freshness_seconds }}s lag</div>
          <span class="text-[10px] text-slate-400">3,240 edge IoT sensors reporting</span>
        </div>
      </div>

      <!-- ISO 19650 Common Data Environment (CDE) Document Registry -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-bold text-white">
            <mat-icon class="text-cyan-400">folder_special</mat-icon>
            <span>ISO 19650 COMMON DATA ENVIRONMENT (CDE) DOCUMENT REGISTRY</span>
          </div>
          <span class="text-slate-400">AUTHORIZED INFORMATION CONTAINERS</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th class="p-2.5">DOC NUMBER</th>
                <th class="p-2.5">TITLE & DESCRIPTION</th>
                <th class="p-2.5">DISCIPLINE</th>
                <th class="p-2.5">STATUS</th>
                <th class="p-2.5">REVISION</th>
                <th class="p-2.5">AUTHOR JV</th>
                <th class="p-2.5">FORMAT</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-300">
              @for (doc of store.documents(); track doc.document_id) {
                <tr class="hover:bg-slate-800/50 transition">
                  <td class="p-2.5 text-cyan-300 font-bold">{{ doc.document_number }}</td>
                  <td class="p-2.5 text-white font-medium">{{ doc.title }}</td>
                  <td class="p-2.5 text-slate-400">{{ doc.discipline }}</td>
                  <td class="p-2.5">
                    <span class="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded font-bold text-[10px]">
                      {{ doc.status }} ({{ doc.suitability_code.split(' ')[0] }})
                    </span>
                  </td>
                  <td class="p-2.5 text-slate-300 font-bold">{{ doc.revision }}</td>
                  <td class="p-2.5 text-slate-400">{{ doc.author_organization }}</td>
                  <td class="p-2.5 text-cyan-300 font-bold">{{ doc.file_format }} ({{ doc.file_size_mb }}MB)</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Immutable System Audit Trail Ledger -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-bold text-white">
            <mat-icon class="text-cyan-400">history</mat-icon>
            <span>IMMUTABLE SYSTEM AUDIT TRAIL & ENGINEERING EVENT STREAM</span>
          </div>
          <span class="text-slate-400">TAMPER-EVIDENT TIMESTAMPED EVENTS</span>
        </div>

        <div class="space-y-2">
          @for (evt of store.events(); track evt.event_id) {
            <div class="p-2.5 bg-slate-950 border border-slate-800 rounded-lg flex items-start justify-between gap-3">
              <div class="space-y-0.5">
                <div class="flex items-center gap-2">
                  <span class="text-cyan-400 font-bold text-[11px]">{{ evt.timestamp }}</span>
                  <span class="px-1.5 py-0.2 rounded text-[10px] font-bold"
                    [class.bg-emerald-500/20]="evt.severity === 'INFO'"
                    [class.text-emerald-300]="evt.severity === 'INFO'"
                    [class.bg-amber-500/20]="evt.severity === 'WARNING'"
                    [class.text-amber-300]="evt.severity === 'WARNING'"
                    [class.bg-cyan-500/20]="evt.severity === 'NOTICE'"
                    [class.text-cyan-300]="evt.severity === 'NOTICE'">
                    {{ evt.severity }}
                  </span>
                  <span class="text-white font-bold text-xs">{{ evt.title }}</span>
                </div>
                <p class="text-slate-300 text-[11px] font-sans">{{ evt.message }}</p>
              </div>
              <div class="text-[10px] text-slate-400 text-right whitespace-nowrap">
                <div>ACTOR: {{ evt.actor }}</div>
                <div>REF: {{ evt.provenance_ref || 'N/A' }}</div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class CDEGovernanceView {
  public store = inject(DigitalTwinStoreService);
}
