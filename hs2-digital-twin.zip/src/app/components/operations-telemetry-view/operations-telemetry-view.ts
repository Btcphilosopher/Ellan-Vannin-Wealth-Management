// ============================================================================
// OPERATIONS & LIVE TELEMETRY DASHBOARD
// Real-time train tracking, pantograph electrical telemetry, timetable headway,
// and live Structural Health Monitoring (SHM) waveforms.
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStoreService } from '../../services/digital-twin-store.service';
import { SHMTelemetryService } from '../../services/shm-telemetry.service';
import { LinearReferencingService } from '../../services/linear-referencing.service';

@Component({
  selector: 'app-operations-telemetry-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      <!-- High Speed Train Fleet Live Kinematics Table -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-bold text-white">
            <mat-icon class="text-cyan-400">train</mat-icon>
            <span>LIVE CORRIDOR TRAIN DISPATCHER (CLASS 895 CAPTIVE FLEET)</span>
          </div>
          <span class="flex items-center gap-1.5 text-emerald-400 font-bold">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            ETCS FULL SUPERVISION ACTIVE
          </span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th class="p-2.5">TRAIN ID / UNIT</th>
                <th class="p-2.5">SERVICE / ROUTE</th>
                <th class="p-2.5">CHAINAGE</th>
                <th class="p-2.5">SPEED (km/h)</th>
                <th class="p-2.5">POWER (MW)</th>
                <th class="p-2.5">PANTO VOLTAGE</th>
                <th class="p-2.5">PASSENGER LOAD</th>
                <th class="p-2.5">SCHEDULE</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 text-slate-300">
              @for (trn of store.trains(); track trn.train_id) {
                <tr class="hover:bg-slate-800/50 transition cursor-pointer"
                  (click)="store.setChainage(trn.current_chainage_m)">
                  <td class="p-2.5 text-cyan-300 font-bold flex items-center gap-1.5">
                    <mat-icon class="text-sm">directions_railway</mat-icon>
                    {{ trn.unit_number }}
                  </td>
                  <td class="p-2.5 text-white font-medium">{{ trn.service_id }}</td>
                  <td class="p-2.5 text-slate-300 font-bold">{{ linearRef.formatChainage(trn.current_chainage_m) }}</td>
                  <td class="p-2.5">
                    <span class="text-emerald-400 font-bold text-sm">{{ trn.current_speed_kmh.toFixed(1) }}</span>
                    <span class="text-[10px] text-slate-400"> / {{ trn.target_speed_kmh }}</span>
                  </td>
                  <td class="p-2.5 font-bold text-amber-300">{{ trn.power_draw_mw.toFixed(2) }} MW</td>
                  <td class="p-2.5 text-cyan-300 font-bold">{{ trn.pantograph_voltage_kv.toFixed(2) }} kV</td>
                  <td class="p-2.5">
                    <div class="flex items-center gap-2">
                      <div class="w-14 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div class="bg-cyan-400 h-full rounded-full" [style.width.%]="trn.passenger_load_percent"></div>
                      </div>
                      <span>{{ trn.passenger_load_percent }}%</span>
                    </div>
                  </td>
                  <td class="p-2.5 text-emerald-400 font-bold">ON TIME</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Live Structural Health Monitoring (SHM) Telemetry Waveforms -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-2 font-bold text-white">
            <mat-icon class="text-cyan-400">stacked_line_chart</mat-icon>
            <span>LIVE STRUCTURAL HEALTH MONITORING (SHM) TELEMETRY WAVEFORMS</span>
          </div>
          <span class="text-xs text-slate-400">POLLING: 1000ms &bull; EWMA / CUSUM ENVELOPE</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (sensor of shmService.sensors(); track sensor.sensor_id) {
            <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800 space-y-2">
              <div class="flex items-center justify-between border-b border-slate-800 pb-1.5">
                <span class="text-cyan-300 font-bold truncate">{{ sensor.model.split(' ')[0] }} ({{ sensor.sensor_id }})</span>
                <span class="px-1.5 py-0.2 rounded text-[10px] font-bold"
                  [class.bg-emerald-500/20]="sensor.health === 'OPERATIONAL'"
                  [class.text-emerald-300]="sensor.health === 'OPERATIONAL'">
                  {{ sensor.health }}
                </span>
              </div>

              <div class="flex items-baseline justify-between">
                <span class="text-[11px] text-slate-400">{{ sensor.sensor_type }}</span>
                <span class="text-base font-bold text-white">
                  {{ sensor.current_value }} <span class="text-xs text-cyan-300">{{ sensor.unit }}</span>
                </span>
              </div>

              <!-- Sparkline SVG Waveform -->
              <div class="h-16 w-full bg-slate-900/60 rounded border border-slate-800/80 p-1">
                <svg class="w-full h-full" viewBox="0 0 200 50" preserveAspectRatio="none">
                  @if (getSensorSparkline(sensor.sensor_id); as pathData) {
                    <path [attr.d]="pathData" fill="none" stroke="#06b6d4" stroke-width="1.8"/>
                  }
                </svg>
              </div>

              <div class="grid grid-cols-2 gap-2 text-[10px] text-slate-400 pt-1 border-t border-slate-800/80">
                <div>RATE: {{ sensor.rate_of_change_per_hour }}/hr</div>
                <div>CUSUM: {{ sensor.cusum_statistic }}</div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class OperationsTelemetryView {
  public store = inject(DigitalTwinStoreService);
  public shmService = inject(SHMTelemetryService);
  public linearRef = inject(LinearReferencingService);

  public getSensorSparkline(sensor_id: string): string {
    const history = this.shmService.historyMap()[sensor_id] || [];
    if (history.length < 2) return 'M 0,25 L 200,25';

    const vals = history.map(h => h.value);
    const min = Math.min(...vals) * 0.95;
    const max = Math.max(...vals) * 1.05 || 1.0;
    const range = max - min || 1;

    const points = history.map((h, i) => {
      const x = (i / (history.length - 1)) * 200;
      const y = 45 - ((h.value - min) / range) * 40;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });

    return `M ${points.join(' L ')}`;
  }
}
