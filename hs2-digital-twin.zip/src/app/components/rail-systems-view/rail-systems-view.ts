// ============================================================================
// RAIL SYSTEMS DIGITAL TWIN VIEW
// Subsystems domain panels: Permanent Way Track, 25kV OLE Catenary,
// 400kV/25kV Traction Power Flow, ETCS Level 2 RBC Signalling & Telecoms.
// ============================================================================

import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinStoreService } from '../../services/digital-twin-store.service';
import { PhysicsSimulationService } from '../../services/physics-simulation.service';

@Component({
  selector: 'app-rail-systems-view',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      <!-- Subsystem Selector Pills -->
      <div class="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3 font-mono text-xs">
        <button
          (click)="selectedSubsystem.set('TRACK')"
          class="px-3 py-1.5 rounded-lg border transition flex items-center gap-1.5"
          [class.bg-cyan-500/20]="selectedSubsystem() === 'TRACK'"
          [class.border-cyan-500]="selectedSubsystem() === 'TRACK'"
          [class.text-cyan-300]="selectedSubsystem() === 'TRACK'"
          [class.bg-slate-900]="selectedSubsystem() !== 'TRACK'"
          [class.border-slate-800]="selectedSubsystem() !== 'TRACK'"
          [class.text-slate-400]="selectedSubsystem() !== 'TRACK'">
          <mat-icon class="text-sm">linear_scale</mat-icon>
          <span>TRACK & PERMANENT WAY</span>
        </button>

        <button
          (click)="selectedSubsystem.set('OLE')"
          class="px-3 py-1.5 rounded-lg border transition flex items-center gap-1.5"
          [class.bg-cyan-500/20]="selectedSubsystem() === 'OLE'"
          [class.border-cyan-500]="selectedSubsystem() === 'OLE'"
          [class.text-cyan-300]="selectedSubsystem() === 'OLE'"
          [class.bg-slate-900]="selectedSubsystem() !== 'OLE'"
          [class.border-slate-800]="selectedSubsystem() !== 'OLE'"
          [class.text-slate-400]="selectedSubsystem() !== 'OLE'">
          <mat-icon class="text-sm">bolt</mat-icon>
          <span>OLE 25kV CATENARY</span>
        </button>

        <button
          (click)="selectedSubsystem.set('POWER')"
          class="px-3 py-1.5 rounded-lg border transition flex items-center gap-1.5"
          [class.bg-cyan-500/20]="selectedSubsystem() === 'POWER'"
          [class.border-cyan-500]="selectedSubsystem() === 'POWER'"
          [class.text-cyan-300]="selectedSubsystem() === 'POWER'"
          [class.bg-slate-900]="selectedSubsystem() !== 'POWER'"
          [class.border-slate-800]="selectedSubsystem() !== 'POWER'"
          [class.text-slate-400]="selectedSubsystem() !== 'POWER'">
          <mat-icon class="text-sm">power</mat-icon>
          <span>TRACTION POWER & SUBSTATIONS</span>
        </button>

        <button
          (click)="selectedSubsystem.set('SIGNALLING')"
          class="px-3 py-1.5 rounded-lg border transition flex items-center gap-1.5"
          [class.bg-cyan-500/20]="selectedSubsystem() === 'SIGNALLING'"
          [class.border-cyan-500]="selectedSubsystem() === 'SIGNALLING'"
          [class.text-cyan-300]="selectedSubsystem() === 'SIGNALLING'"
          [class.bg-slate-900]="selectedSubsystem() !== 'SIGNALLING'"
          [class.border-slate-800]="selectedSubsystem() !== 'SIGNALLING'"
          [class.text-slate-400]="selectedSubsystem() !== 'SIGNALLING'">
          <mat-icon class="text-sm">alt_route</mat-icon>
          <span>ETCS LEVEL 2 SIGNALLING</span>
        </button>
      </div>

      <!-- Subsystem 1: TRACK & PERMANENT WAY -->
      @if (selectedSubsystem() === 'TRACK') {
        <div class="space-y-4">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-3 font-mono text-xs">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">RAIL PROFILE</span>
              <span class="text-lg font-bold text-white">60E2 (EN 13674-1)</span>
              <span class="text-[10px] text-slate-400 block">R350HT Heat Treated Head</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">TRACK FORM</span>
              <span class="text-lg font-bold text-cyan-300">RHEDA 2000 Slab</span>
              <span class="text-[10px] text-slate-400 block">Non-ballasted direct slab fixation</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">LEVEL GEOMETRY SD</span>
              <span class="text-lg font-bold text-emerald-400">0.42 mm</span>
              <span class="text-[10px] text-emerald-300 block">EN 13848 Class A (High Speed)</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">RAIL THERMAL STRESS</span>
              <span class="text-lg font-bold text-slate-200">{{ railThermalData.stress_mpa }} MPa</span>
              <span class="text-[10px] block"
                [class.text-emerald-400]="railThermalData.buckling_risk === 'LOW'"
                [class.text-amber-400]="railThermalData.buckling_risk !== 'LOW'">
                CRT Margin: Safe ({{ railThermalData.buckling_risk }} Risk)
              </span>
            </div>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-white font-bold">PERMANENT WAY ENGINEERING PARAMETERS</span>
              <span class="text-slate-400">NOMINAL GAUGE: 1435.0 mm</span>
            </div>
            <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div class="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span class="text-slate-400 block text-[10px]">FASTENING SYSTEM</span>
                <span class="text-white font-bold">Vossloh System 300 W-14</span>
              </div>
              <div class="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span class="text-slate-400 block text-[10px]">DYNAMIC STIFFNESS</span>
                <span class="text-white font-bold">60 kN/mm (Intermediate Pad)</span>
              </div>
              <div class="bg-slate-950 p-2.5 rounded border border-slate-800">
                <span class="text-slate-400 block text-[10px]">STRESS-FREE TEMPERATURE (SFT)</span>
                <span class="text-cyan-300 font-bold">27.0 °C (UK Standard Neutral)</span>
              </div>
            </div>
          </div>
        </div>
      }

      <!-- Subsystem 2: OLE 25kV CATENARY -->
      @if (selectedSubsystem() === 'OLE') {
        <div class="space-y-4">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-3 font-mono text-xs">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">CONTACT WIRE TENSION</span>
              <span class="text-lg font-bold text-cyan-300">20.0 kN</span>
              <span class="text-[10px] text-slate-400 block">CuAg 120 mm2 Alloy</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">NOMINAL WIRE HEIGHT</span>
              <span class="text-lg font-bold text-white">{{ oleData.contact_wire_height_m }} m</span>
              <span class="text-[10px] text-slate-400 block">Thermal Sag: {{ oleData.sag_mm }} mm</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">PANTOGRAPH UPLIFT (360k)</span>
              <span class="text-lg font-bold text-emerald-400">{{ oleData.uplift_mm }} mm</span>
              <span class="text-[10px] text-emerald-300 block">Max Permissible: 90 mm</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">LATERAL STAGGER</span>
              <span class="text-lg font-bold text-slate-200">±180 mm</span>
              <span class="text-[10px] text-slate-400 block">Zigzag wear dispersion</span>
            </div>
          </div>
        </div>
      }

      <!-- Subsystem 3: TRACTION POWER & SUBSTATIONS -->
      @if (selectedSubsystem() === 'POWER') {
        <div class="space-y-4">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-3 font-mono text-xs">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">NATIONAL GRID INFEED</span>
              <span class="text-lg font-bold text-white">400 kV (East Claydon)</span>
              <span class="text-[10px] text-emerald-400 block">Dual Redundant Circuits</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">FEEDER VOLTAGE</span>
              <span class="text-lg font-bold text-cyan-300">27.42 kV (+25kV AT)</span>
              <span class="text-[10px] text-slate-400 block">Nominal 25-0-25kV System</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">ACTIVE SECTION LOAD</span>
              <span class="text-lg font-bold text-amber-400">38.4 MW</span>
              <span class="text-[10px] text-slate-400 block">Power Factor: 0.985 (SVC active)</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">TRANSFORMER STATUS</span>
              <span class="text-lg font-bold text-emerald-400">58.2 °C (Tx1)</span>
              <span class="text-[10px] text-emerald-300 block">Thermal Margin: 48%</span>
            </div>
          </div>
        </div>
      }

      <!-- Subsystem 4: ETCS LEVEL 2 SIGNALLING -->
      @if (selectedSubsystem() === 'SIGNALLING') {
        <div class="space-y-4">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-3 font-mono text-xs">
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">ETCS BASELINE</span>
              <span class="text-lg font-bold text-white">Baseline 3 Set 3</span>
              <span class="text-[10px] text-slate-400 block">SIL 4 Radio Block Centre</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">RADIO LINK (EURORADIO)</span>
              <span class="text-lg font-bold text-cyan-300">FRMCS / GSM-R</span>
              <span class="text-[10px] text-emerald-400 block">Latency: 142 ms</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">TRAIN DETECTION</span>
              <span class="text-lg font-bold text-emerald-400">Axle Counters</span>
              <span class="text-[10px] text-slate-400 block">Frauscher Wheel Sensors</span>
            </div>
            <div class="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block text-[10px]">MOVING BLOCK HEADWAY</span>
              <span class="text-lg font-bold text-indigo-300">120 Seconds</span>
              <span class="text-[10px] text-slate-400 block">At 360 km/h line speed</span>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class RailSystemsView {
  public store = inject(DigitalTwinStoreService);
  private physics = inject(PhysicsSimulationService);

  public selectedSubsystem = signal<'TRACK' | 'OLE' | 'POWER' | 'SIGNALLING'>('TRACK');

  public railThermalData = this.physics.calculateRailThermalStress(24.8, 27.0);
  public oleData = this.physics.calculateOLESagAndUplift(25.0, 360.0);
}
