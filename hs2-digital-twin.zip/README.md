# HS2 DIGITAL TWIN
## Integrated Railway Engineering, Construction & Operations Digital Twin

> **DEMONSTRATION DISCLAIMER**
> **SYNTHETIC HS2-LIKE DEMONSTRATION DATA — NOT OFFICIAL HS2 DATA**
> This repository is a serious engineering digital twin platform architecture for high-speed rail systems, civil infrastructure, linear referencing, structural health monitoring, and physics-driven operations.

---

### Key Architectural Pillars
1. **The Digital Twin is the Data & Physics Layer**: 3D spatial models are only one window; the true twin is the computational state linking geometry, engineering parameters, programme, assets, telemetry, and decision loops.
2. **Universal Asset Hierarchy**: Multi-discipline representation (Civils, Track, 25kV OLE, Traction Power, ETCS L2 Signalling, Telecoms, Stations, Tunnels, Drainage, Environment).
3. **Linear Referencing Engine**: Mathematical alignment transformations (Chainage $s \leftrightarrow$ British National Grid OSGB36 $\leftrightarrow$ WGS84 $\leftrightarrow$ Elevation $\leftrightarrow$ Curvature $\leftrightarrow$ Cant).
4. **4D & 5D Engineering Engine**: Time-travel construction replay (2022–2030), earned-value schedule variance, Bill of Quantities (BoQ), and embodied/operational carbon accounting (PAS 2080).
5. **Real-Time Physics & Kinematics**: Davis equation train performance model (TPM), 25-0-25kV autotransformer load flow, OLE catenary dynamic tension, and continuous welded rail thermal stress.
6. **Structural Health Monitoring (SHM)**: Vibrating wire piezometers, inclinometers, distributed fiber DTS temperature, and EWMA/CUSUM anomaly detection.
7. **ISO 19650 Common Data Environment (CDE)**: Information containers, Uniclass 2015 tables, and immutable tamper-evident audit ledger.

---

### Rust Cargo Workspace Architecture
```
hs2-digital-twin/
├── Cargo.toml
├── crates/
│   ├── twin-core/
│   ├── twin-geometry/
│   ├── twin-geospatial/
│   ├── twin-track/
│   ├── twin-ole/
│   ├── twin-power/
│   ├── twin-signalling/
│   ├── twin-rolling-stock/
│   ├── twin-sensors/
│   ├── twin-telemetry/
│   ├── twin-simulation/
│   ├── twin-risk/
│   └── twin-cli/
├── docs/
└── scenarios/
```

---

### CLI Syntax
```bash
# Query an asset
hs2-twin asset get CIV-VIAD-COLNE-01

# Inspect route chainage
hs2-twin route chainage 22+800 --radius 500

# Execute What-If simulation scenario
hs2-twin scenario run scenarios/flood_calvert.toml

# Validate ISO 19650 dataset integrity
hs2-twin validate dataset --strict
```
