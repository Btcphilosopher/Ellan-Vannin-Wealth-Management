# HS2 Digital Twin — Systems Architecture

## 1. Executive Summary
The HS2 Digital Twin is an integrated computational platform designed for extreme-scale linear infrastructure engineering. It unifies:
- **Geometry & Spatial Modeling**: IFC 4x3 BIM, British National Grid OSGB36, WGS84, and continuous route chainage.
- **Physical Domain Modeling**: 60E2 track slab dynamics, 25kV autotransformer traction power networks, ETCS Level 2 radio block centers, and rolling stock kinematics.
- **Temporal & Programme State (4D/5D)**: Time machine replay from 2022 ground-breaking to 2030 revenue service, earned-value schedule variance, Bill of Quantities, and PAS 2080 carbon accounting.
- **Edge Telemetry & Condition Feedback (SHM)**: Vibrating wire piezometers, inclinometers, distributed fiber DTS temperature, and EWMA/CUSUM anomaly detection engines.

## 2. Ingestion & Federation Pipeline
```
[ BIM (IFC4x3) ] ──┐
[ GIS (OSGB36) ] ──┼──> [ Ingestion Adapter ] ──> [ Universal Asset Store ] ──> [ Physics Engine ]
[ SCADA & IoT  ] ──┤                                                                  │
[ ISO 19650    ] ──┘                                                                  ▼
                                                                                 [ Visualizer & API ]
```

## 3. Data Integrity & Validation
The twin detects NaN, infinity, invalid coordinates, broken relationships, and stale telemetry before state commits.
All demonstration data is explicitly marked as **SYNTHETIC DEMONSTRATION DATA**.
