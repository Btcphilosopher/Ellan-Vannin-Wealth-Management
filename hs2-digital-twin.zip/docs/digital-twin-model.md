# Digital Twin Model Specification

## 1. Digital Twin Definition
Every twin object must maintain:
- `physical_entity_id`: Real-world physical asset identity.
- `digital_entity_id`: Immutable digital twin UUID.
- `asset_class`: Civil, Rail, Electrification, Power, Signalling, Telecoms, Station, or Environment.
- `location`: WGS84, British National Grid (OSGB36), route chainage, and elevation.
- `lifecycle_state`: DESIGNED, PLANNED, UNDER_CONSTRUCTION, AS_BUILT, COMMISSIONED, OPERATIONAL, OUT_OF_SERVICE, UNDER_MAINTENANCE, DECOMMISSIONED.
- `information_status`: ISO 19650 WIP, SHARED, PUBLISHED, or ARCHIVED.
- `provenance`: Author, revision, source system, approval signature, and timestamp.

## 2. The Feedback Loop
```
DESIGN ──> CONSTRUCTION ──> PHYSICAL RAILWAY ──> SENSOR DATA ──> DIGITAL TWIN ──> ANALYSIS ──> DECISION ──> UPDATED TWIN
```
Never treat a design model as an as-built record. Never treat stale telemetry as current state.
