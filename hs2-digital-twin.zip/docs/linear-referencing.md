# Railway Linear Referencing Engine

## 1. Linear Referencing Formulation
High-speed rail design relies on chainage $s \in [0, L]$.
For any chainage $s$, the geospatial engine computes:
- Coordinates $(X(s), Y(s), Z(s))$ in British National Grid (OSGB36) and WGS84.
- Tangent heading angle $\theta(s)$.
- Horizontal curvature $\kappa(s) = 1/R(s)$.
- Vertical gradient $g(s) = \frac{dZ}{ds}$ (‰).
- Applied cross-level cant $D(s)$ (mm).
- Design speed limit $V_{\max}(s)$ (km/h).
- Cant deficiency $I(s) = \frac{11.82 \cdot V^2}{R} - D$ (mm).

## 2. Inverse Chainage Search
Given $(X, Y)$, the system projects onto the alignment spline using spatial KD-tree indexing to resolve the nearest chainage $s^*$ and lateral offset $d$.
Query: `CH 43+250 --radius 500m` returns all intersecting structural, track, power, and environmental assets.
