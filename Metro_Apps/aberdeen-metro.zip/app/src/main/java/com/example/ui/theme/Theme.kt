package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
    darkColorScheme(
        primary = NorthSeaBlueLight,
        onPrimary = GraniteDark,
        primaryContainer = NorthSeaBlueDark,
        onPrimaryContainer = WarmWhite,
        secondary = CopperLight,
        onSecondary = GraniteDark,
        tertiary = NorthSeaBlue,
        background = GraniteDark,
        onBackground = WarmWhite,
        surface = GraniteSurface,
        onSurface = WarmWhite,
        surfaceVariant = GraniteCard,
        onSurfaceVariant = WarmWhiteDim,
        outline = GraniteLight,
        error = AlertRed
    )

private val LightColorScheme =
    lightColorScheme(
        primary = NorthSeaBlue,
        onPrimary = Color.White,
        primaryContainer = NorthSeaBlueLight,
        onPrimaryContainer = GraniteDark,
        secondary = CopperAccent,
        onSecondary = Color.White,
        tertiary = NorthSeaBlueDark,
        background = Color(0xFFF1F5F9),
        onBackground = GraniteDark,
        surface = Color.White,
        onSurface = GraniteDark,
        surfaceVariant = Color(0xFFE2E8F0),
        onSurfaceVariant = GraniteSurface,
        outline = GraniteGrey,
        error = AlertRed
    )

@Composable
fun AberdeenMetroTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Default to Granite City aesthetic
    content: @Composable () -> Unit,
) {
    val colorScheme =
        when {
            dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                val context = LocalContext.current
                if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            }
            darkTheme -> DarkColorScheme
            else -> LightColorScheme
        }

    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
