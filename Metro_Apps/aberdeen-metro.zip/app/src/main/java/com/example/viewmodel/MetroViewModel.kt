package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.MetroRepository
import com.example.data.PreferencesManager
import com.example.model.*
import com.example.routing.JourneyPlannerEngine
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MetroViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = MetroRepository(db.metroDao())
    private val preferencesManager = PreferencesManager(application)
    private val plannerEngine = JourneyPlannerEngine()

    val stations: StateFlow<List<Station>> = repository.stationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lines: StateFlow<List<MetroLine>> = repository.linesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<TicketItem>> = repository.ticketsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedJourneys: StateFlow<List<JourneyItem>> = repository.savedJourneysFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val serviceAlerts: StateFlow<List<ServiceAlert>> = repository.serviceAlertsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stepFreeOnly: StateFlow<Boolean> = preferencesManager.stepFreeOnly
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val darkTheme: StateFlow<Boolean> = preferencesManager.darkTheme
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val favoriteStations: StateFlow<Set<String>> = preferencesManager.favoriteStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    // Journey planning state
    private val _originStationId = MutableStateFlow<String?>(null)
    val originStationId: StateFlow<String?> = _originStationId

    private val _destinationStationId = MutableStateFlow<String?>(null)
    val destinationStationId: StateFlow<String?> = _destinationStationId

    private val _plannedJourneys = MutableStateFlow<List<JourneyOption>>(emptyList())
    val plannedJourneys: StateFlow<List<JourneyOption>> = _plannedJourneys

    private val _lastUpdateTimestamp = MutableStateFlow(SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))
    val lastUpdateTimestamp: StateFlow<String> = _lastUpdateTimestamp

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
            // Seed sample ticket if none exist
            if (repository.ticketsFlow.first().isEmpty()) {
                val sampleTicket = TicketItem(
                    id = "tkt_demo_01",
                    title = "Aberdeen Metro Day Pass",
                    type = "Day Pass",
                    passengerType = "Adult",
                    price = 6.50,
                    validFrom = "Today, 06:00",
                    validUntil = "Today, 23:59",
                    qrCodePayload = "ABDN-METRO-PASS-2026-X99",
                    isUsed = false
                )
                repository.insertTicket(sampleTicket)
            }
        }
    }

    fun setOrigin(stationId: String?) {
        _originStationId.value = stationId
    }

    fun setDestination(stationId: String?) {
        _destinationStationId.value = stationId
    }

    fun planJourney() {
        val origId = _originStationId.value ?: return
        val destId = _destinationStationId.value ?: return
        val stationsList = stations.value
        val origin = stationsList.find { it.id == origId } ?: return
        val destination = stationsList.find { it.id == destId } ?: return
        val stationsMap = stationsList.associateBy { it.id }
        val stepFree = stepFreeOnly.value

        val results = plannerEngine.planJourney(origin, destination, stationsMap, stepFree)
        _plannedJourneys.value = results
        _lastUpdateTimestamp.value = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }

    fun swapOriginDestination() {
        val temp = _originStationId.value
        _originStationId.value = _destinationStationId.value
        _destinationStationId.value = temp
        if (_originStationId.value != null && _destinationStationId.value != null) {
            planJourney()
        }
    }

    fun purchaseTicket(title: String, type: String, passengerType: String, price: Double) {
        viewModelScope.launch {
            val id = "tkt_${System.currentTimeMillis()}"
            val ticket = TicketItem(
                id = id,
                title = title,
                type = type,
                passengerType = passengerType,
                price = price,
                validFrom = "Today, 06:00",
                validUntil = "Today, 23:59",
                qrCodePayload = "ABDN-METRO-$id-${System.currentTimeMillis().toString().takeLast(4)}",
                isUsed = false
            )
            repository.insertTicket(ticket)
        }
    }

    fun useTicket(ticketId: String, isUsed: Boolean) {
        viewModelScope.launch {
            repository.updateTicketUsage(ticketId, isUsed)
        }
    }

    fun toggleFavorite(stationId: String) {
        viewModelScope.launch {
            preferencesManager.toggleFavoriteStation(stationId)
        }
    }

    fun setStepFree(enabled: Boolean) {
        viewModelScope.launch {
            preferencesManager.setStepFreeOnly(enabled)
            if (_originStationId.value != null && _destinationStationId.value != null) {
                planJourney()
            }
        }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            preferencesManager.setDarkTheme(enabled)
        }
    }

    fun saveJourney(originId: String, destId: String, originName: String, destName: String) {
        viewModelScope.launch {
            repository.saveJourney(originId, destId, originName, destName)
        }
    }

    fun deleteSavedJourney(id: String) {
        viewModelScope.launch {
            repository.deleteSavedJourney(id)
        }
    }

    fun refreshDepartures() {
        _lastUpdateTimestamp.value = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }

    // Generate simulated departures for a station
    fun getSimulatedDepartures(stationId: String): List<Departure> {
        val station = stations.value.find { it.id == stationId } ?: return emptyList()
        val lineId = station.lineIds.firstOrNull() ?: "line_blue"
        val lineName = if (lineId == "line_blue") "Blue Line" else if (lineId == "line_copper") "Copper Line" else "Teal Line"
        
        return listOf(
            Departure(
                id = "dep_1_${stationId}",
                stationId = stationId,
                lineId = lineId,
                destinationName = if (lineId == "line_blue") "Airport" else if (lineId == "line_copper") "Westhill" else "Bridge of Don",
                scheduledTime = "09:04",
                predictedMinutes = 2,
                platform = "Platform 1",
                statusText = "On Time"
            ),
            Departure(
                id = "dep_2_${stationId}",
                stationId = stationId,
                lineId = lineId,
                destinationName = "Aberdeen Station",
                scheduledTime = "09:12",
                predictedMinutes = 9,
                platform = "Platform 2",
                statusText = "On Time"
            ),
            Departure(
                id = "dep_3_${stationId}",
                stationId = stationId,
                lineId = lineId,
                destinationName = if (lineId == "line_blue") "City Centre" else "Peterculter",
                scheduledTime = "09:21",
                predictedMinutes = 18,
                platform = "Platform 1",
                statusText = "Simulated"
            )
        )
    }
}
