package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GraniteDark = Color(0xFF0F172A)
val GraniteSurface = Color(0xFF1E293B)
val GraniteCard = Color(0xFF334155)
val GraniteGrey = Color(0xFF64748B)
val GraniteLight = Color(0xFF94A3B8)
val WarmWhite = Color(0xFFF8FAFC)
val WarmWhiteDim = Color(0xFFCBD5E1)

val NorthSeaBlue = Color(0xFF0EA5E9)
val NorthSeaBlueDark = Color(0xFF0284C7)
val NorthSeaBlueLight = Color(0xFF38BDF8)

val CopperAccent = Color(0xFFD97706)
val CopperLight = Color(0xFFF59E0B)

val LineBlue = Color(0xFF0EA5E9)
val LineCopper = Color(0xFFD97706)
val LineTeal = Color(0xFF0D9488)

val SuccessGreen = Color(0xFF10B981)
val AlertRed = Color(0xFFEF4444)
