package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val lineIdsString: String, // comma separated
    val isInterchange: Boolean,
    val isStepFree: Boolean,
    val liftAvailable: Boolean,
    val latitude: Double,
    val longitude: Double,
    val zone: Int,
    val facilitiesString: String,
    val connectingTransportString: String,
    val entranceInfo: String
)

@Entity(tableName = "lines")
data class LineEntity(
    @PrimaryKey val id: String,
    val name: String,
    val colorHex: String,
    val corridor: String,
    val status: String
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val title: String,
    val type: String,
    val passengerType: String,
    val price: Double,
    val validFrom: String,
    val validUntil: String,
    val qrCodePayload: String,
    val isUsed: Boolean,
    val purchaseTimestamp: Long
)

@Entity(tableName = "saved_journeys")
data class SavedJourneyEntity(
    @PrimaryKey val id: String,
    val originId: String,
    val destinationId: String,
    val originName: String,
    val destinationName: String,
    val savedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "service_alerts")
data class ServiceAlertEntity(
    @PrimaryKey val id: String,
    val lineId: String?,
    val title: String,
    val description: String,
    val severity: String,
    val timestamp: Long
)
