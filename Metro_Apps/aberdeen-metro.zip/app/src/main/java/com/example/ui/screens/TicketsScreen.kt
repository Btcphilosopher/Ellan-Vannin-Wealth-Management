package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.TicketItem
import com.example.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketsScreen(
    viewModel: MetroViewModel,
    onOpenTicketDetail: (String) -> Unit
) {
    val tickets by viewModel.tickets.collectAsState()

    var selectedTicketType by remember { mutableStateOf("Day Pass") }
    var passengerCategory by remember { mutableStateOf("Adult") }

    val ticketPrices = mapOf(
        "Single Journey" to 2.80,
        "Day Pass" to 6.50,
        "Weekly Pass" to 24.00,
        "Airport-Inclusive" to 8.50
    )

    val currentPrice = ticketPrices[selectedTicketType] ?: 6.50
    val finalPrice = if (passengerCategory == "Concession") currentPrice * 0.5 else currentPrice

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Tickets & Wallet",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Secure offline-ready QR credentials for Aberdeen Metro",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline
            )
        }

        // Purchase New Ticket Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(text = "Purchase Ticket", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    // Ticket Type Selector
                    ScrollableTabRow(
                        selectedTabIndex = listOf("Single Journey", "Day Pass", "Weekly Pass", "Airport-Inclusive").indexOf(selectedTicketType),
                        edgePadding = 0.dp,
                        containerColor = androidx.compose.ui.graphics.Color.Transparent
                    ) {
                        listOf("Single Journey", "Day Pass", "Weekly Pass", "Airport-Inclusive").forEach { type ->
                            Tab(
                                selected = selectedTicketType == type,
                                onClick = { selectedTicketType = type },
                                text = { Text(type) }
                            )
                        }
                    }

                    // Passenger Category Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Adult", "Concession").forEach { cat ->
                            FilterChip(
                                selected = passengerCategory == cat,
                                onClick = { passengerCategory = cat },
                                label = { Text(cat) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Total Price", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                            Text(text = "£${String.format("%.2f", finalPrice)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }

                        Button(
                            onClick = {
                                viewModel.purchaseTicket(
                                    title = "Aberdeen Metro $selectedTicketType",
                                    type = selectedTicketType,
                                    passengerType = passengerCategory,
                                    price = finalPrice
                                )
                            }
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Buy Now (Test)")
                        }
                    }
                }
            }
        }

        // Wallet Tickets List
        item {
            Text(text = "Your Ticket Wallet (${tickets.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        items(tickets) { ticket ->
            Card(
                colors = CardDefaults.cardColors(containerColor = if (ticket.isUsed) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenTicketDetail(ticket.id) }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = ticket.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = if (ticket.isUsed) MaterialTheme.colorScheme.outline.copy(alpha = 0.2f) else MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (ticket.isUsed) "Used" else "Valid",
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    color = if (ticket.isUsed) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "${ticket.passengerType} • £${String.format("%.2f", ticket.price)} • Valid until ${ticket.validUntil}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }
                    Icon(Icons.Default.QrCode, contentDescription = "View QR", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                }
            }
        }
    }
}
