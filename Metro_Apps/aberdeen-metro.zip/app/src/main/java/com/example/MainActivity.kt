package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.navigation.Screen
import com.example.ui.screens.*
import com.example.ui.theme.AberdeenMetroTheme
import com.example.viewmodel.MetroViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MetroViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val darkTheme by viewModel.darkTheme.collectAsState()

            AberdeenMetroTheme(darkTheme = darkTheme) {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                val items = listOf(
                    Triple("Home", Screen.Home.route, Icons.Default.Home),
                    Triple("Plan", Screen.Plan.route, Icons.Default.DirectionsTransit),
                    Triple("Map", Screen.Map.route, Icons.Default.Map),
                    Triple("Tickets", Screen.Tickets.route, Icons.Default.ConfirmationNumber),
                    Triple("Account", Screen.Account.route, Icons.Default.Person)
                )

                val showBottomBar = currentRoute in items.map { it.second }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (showBottomBar) {
                            NavigationBar {
                                items.forEach { (label, route, icon) ->
                                    NavigationBarItem(
                                        icon = { Icon(icon, contentDescription = label) },
                                        label = { Text(label) },
                                        selected = currentRoute == route,
                                        onClick = {
                                            if (currentRoute != route) {
                                                navController.navigate(route) {
                                                    popUpTo(navController.graph.findStartDestination().id) {
                                                        saveState = true
                                                    }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Screen.Home.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(Screen.Home.route) {
                            HomeScreen(
                                viewModel = viewModel,
                                onNavigateToPlan = { navController.navigate(Screen.Plan.route) },
                                onNavigateToMap = { navController.navigate(Screen.Map.route) },
                                onNavigateToTickets = { navController.navigate(Screen.Tickets.route) },
                                onSelectStation = { stationId ->
                                    navController.navigate(Screen.StationDetail.createRoute(stationId))
                                }
                            )
                        }
                        composable(Screen.Plan.route) {
                            PlanScreen(viewModel = viewModel)
                        }
                        composable(Screen.Map.route) {
                            MapScreen(
                                viewModel = viewModel,
                                onSelectStation = { stationId ->
                                    navController.navigate(Screen.StationDetail.createRoute(stationId))
                                }
                            )
                        }
                        composable(Screen.Tickets.route) {
                            TicketsScreen(
                                viewModel = viewModel,
                                onOpenTicketDetail = { ticketId ->
                                    navController.navigate(Screen.TicketDetail.createRoute(ticketId))
                                }
                            )
                        }
                        composable(Screen.Account.route) {
                            AccountScreen(viewModel = viewModel)
                        }
                        composable(
                            route = Screen.StationDetail.route,
                            arguments = listOf(navArgument("stationId") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val stationId = backStackEntry.arguments?.getString("stationId") ?: "st_airport"
                            StationDetailScreen(
                                stationId = stationId,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(
                            route = Screen.TicketDetail.route,
                            arguments = listOf(navArgument("ticketId") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val ticketId = backStackEntry.arguments?.getString("ticketId") ?: ""
                            TicketDetailScreen(
                                ticketId = ticketId,
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
