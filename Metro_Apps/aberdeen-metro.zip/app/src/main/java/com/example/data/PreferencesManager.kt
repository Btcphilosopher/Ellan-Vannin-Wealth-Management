package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "metro_preferences")

class PreferencesManager(private val context: Context) {
    companion object {
        val STEP_FREE_ONLY = booleanPreferencesKey("step_free_only")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val FAVORITE_STATIONS = stringSetPreferencesKey("favorite_stations")
    }

    val stepFreeOnly: Flow<Boolean> = context.dataStore.data
        .map { preferences -> preferences[STEP_FREE_ONLY] ?: false }

    val darkTheme: Flow<Boolean> = context.dataStore.data
        .map { preferences -> preferences[DARK_THEME] ?: true }

    val favoriteStations: Flow<Set<String>> = context.dataStore.data
        .map { preferences -> preferences[FAVORITE_STATIONS] ?: emptySet() }

    suspend fun setStepFreeOnly(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[STEP_FREE_ONLY] = enabled
        }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[DARK_THEME] = enabled
        }
    }

    suspend fun toggleFavoriteStation(stationId: String) {
        context.dataStore.edit { preferences ->
            val current = preferences[FAVORITE_STATIONS] ?: emptySet()
            if (current.contains(stationId)) {
                preferences[FAVORITE_STATIONS] = current - stationId
            } else {
                preferences[FAVORITE_STATIONS] = current + stationId
            }
        }
    }
}
