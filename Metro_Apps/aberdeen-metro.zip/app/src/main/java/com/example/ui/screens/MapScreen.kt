package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Station
import com.example.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    viewModel: MetroViewModel,
    onSelectStation: (String) -> Unit
) {
    val stations by viewModel.stations.collectAsState()
    val lines by viewModel.lines.collectAsState()

    var isListView by remember { mutableStateOf(false) }
    var selectedStation by remember { mutableStateOf<Station?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    var zoom by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val filteredStations = stations.filter { it.name.contains(searchQuery, ignoreCase = true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Metro Map",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Aberdeen Metro Schematic Network",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(onClick = { isListView = !isListView }) {
                    Icon(
                        imageVector = if (isListView) Icons.Default.Map else Icons.Default.List,
                        contentDescription = "Toggle View",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search stations or lines...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Legend row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(Color(0xFF0EA5E9)))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Blue Line", style = MaterialTheme.typography.labelSmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(Color(0xFFD97706)))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Copper Line", style = MaterialTheme.typography.labelSmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(Color(0xFF0D9488)))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Teal Line", style = MaterialTheme.typography.labelSmall)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (isListView) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredStations) { station ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectStation(station.id) }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = station.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                Text(text = "Zone ${station.zone} • ${if (station.isStepFree) "Step-Free" else "Partial Access"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }
        } else {
            // Interactive Schematic Map Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoomChange, _ ->
                            zoom = (zoom * zoomChange).coerceIn(0.8f, 3f)
                            offset = offset + pan
                        }
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Draw abstract schematic lines connecting stations
                    val centerPt = Offset(w * 0.5f, h * 0.5f)
                    val airportPt = Offset(w * 0.2f, h * 0.2f)
                    val dycePt = Offset(w * 0.3f, h * 0.25f)
                    val bucksPt = Offset(w * 0.38f, h * 0.32f)
                    val woodPt = Offset(w * 0.44f, h * 0.4f)
                    val kittyPt = Offset(w * 0.48f, h * 0.46f)
                    val cityPt = centerPt
                    val abrdnStnPt = Offset(w * 0.55f, h * 0.6f)

                    // Blue Line
                    drawLine(Color(0xFF0EA5E9), airportPt, dycePt, strokeWidth = 8f)
                    drawLine(Color(0xFF0EA5E9), dycePt, bucksPt, strokeWidth = 8f)
                    drawLine(Color(0xFF0EA5E9), bucksPt, woodPt, strokeWidth = 8f)
                    drawLine(Color(0xFF0EA5E9), woodPt, kittyPt, strokeWidth = 8f)
                    drawLine(Color(0xFF0EA5E9), kittyPt, cityPt, strokeWidth = 8f)
                    drawLine(Color(0xFF0EA5E9), cityPt, abrdnStnPt, strokeWidth = 8f)

                    // Copper Line
                    val westhillPt = Offset(w * 0.15f, h * 0.7f)
                    val kingsPt = Offset(w * 0.3f, h * 0.65f)
                    val ariPt = Offset(w * 0.42f, h * 0.55f)
                    val rosePt = Offset(w * 0.46f, h * 0.52f)
                    val duthiePt = Offset(w * 0.62f, h * 0.68f)
                    val cultsPt = Offset(w * 0.75f, h * 0.75f)
                    val peterPt = Offset(w * 0.88f, h * 0.82f)

                    drawLine(Color(0xFFD97706), westhillPt, kingsPt, strokeWidth = 8f)
                    drawLine(Color(0xFFD97706), kingsPt, ariPt, strokeWidth = 8f)
                    drawLine(Color(0xFFD97706), ariPt, rosePt, strokeWidth = 8f)
                    drawLine(Color(0xFFD97706), rosePt, cityPt, strokeWidth = 8f)
                    drawLine(Color(0xFFD97706), cityPt, duthiePt, strokeWidth = 8f)
                    drawLine(Color(0xFFD97706), duthiePt, cultsPt, strokeWidth = 8f)
                    drawLine(Color(0xFFD97706), cultsPt, peterPt, strokeWidth = 8f)

                    // Teal Line
                    val bridgeDonPt = Offset(w * 0.65f, h * 0.22f)
                    val univPt = Offset(w * 0.6f, h * 0.35f)
                    val beachPt = Offset(w * 0.7f, h * 0.5f)
                    val harbourPt = Offset(w * 0.63f, h * 0.58f)
                    val torryPt = Offset(w * 0.55f, h * 0.72f)
                    val altensPt = Offset(w * 0.52f, h * 0.82f)
                    val covePt = Offset(w * 0.5f, h * 0.92f)

                    drawLine(Color(0xFF0D9488), bridgeDonPt, univPt, strokeWidth = 8f)
                    drawLine(Color(0xFF0D9488), univPt, beachPt, strokeWidth = 8f)
                    drawLine(Color(0xFF0D9488), beachPt, harbourPt, strokeWidth = 8f)
                    drawLine(Color(0xFF0D9488), harbourPt, abrdnStnPt, strokeWidth = 8f)
                    drawLine(Color(0xFF0D9488), abrdnStnPt, torryPt, strokeWidth = 8f)
                    drawLine(Color(0xFF0D9488), torryPt, altensPt, strokeWidth = 8f)
                    drawLine(Color(0xFF0D9488), altensPt, covePt, strokeWidth = 8f)

                    // Draw station dots
                    val allPts = listOf(
                        airportPt, dycePt, bucksPt, woodPt, kittyPt, cityPt, abrdnStnPt,
                        westhillPt, kingsPt, ariPt, rosePt, duthiePt, cultsPt, peterPt,
                        bridgeDonPt, univPt, beachPt, harbourPt, torryPt, altensPt, covePt
                    )
                    allPts.forEach { pt ->
                        drawCircle(Color.White, radius = 10f, center = pt)
                        drawCircle(Color(0xFF1E293B), radius = 6f, center = pt)
                    }
                }

                // Overlay interactive button to inspect city centre interchange
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(bottom = 16.dp)
                ) {
                    Button(
                        onClick = { onSelectStation("st_city_centre") },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Train, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("City Centre Interchange")
                    }
                }
            }
        }
    }
}
