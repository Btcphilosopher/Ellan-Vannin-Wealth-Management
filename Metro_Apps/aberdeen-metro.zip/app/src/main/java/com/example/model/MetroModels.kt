package com.example.model

data class Station(
    val id: String,
    val name: String,
    val lineIds: List<String>,
    val isInterchange: Boolean = false,
    val isStepFree: Boolean = true,
    val liftAvailable: Boolean = true,
    val latitude: Double,
    val longitude: Double,
    val zone: Int = 1,
    val facilities: List<String> = emptyList(),
    val connectingTransport: List<String> = emptyList(),
    val entranceInfo: String = "Main Street Entrance"
)

data class MetroLine(
    val id: String,
    val name: String,
    val colorHex: String,
    val corridor: String,
    val status: String = "Good Service"
)

data class Departure(
    val id: String,
    val stationId: String,
    val lineId: String,
    val destinationName: String,
    val scheduledTime: String,
    val predictedMinutes: Int,
    val platform: String,
    val isSimulated: Boolean = true,
    val isCancelled: Boolean = false,
    val statusText: String = "On Time"
)

data class JourneyOption(
    val id: String,
    val originStationId: String,
    val destinationStationId: String,
    val originName: String,
    val destinationName: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val changesCount: Int,
    val walkingMinutes: Int,
    val waitingMinutes: Int,
    val fareAmount: Double,
    val isStepFree: Boolean,
    val legs: List<JourneyLeg>,
    val instructions: List<String>
)

data class JourneyLeg(
    val lineId: String,
    val lineName: String,
    val lineHex: String,
    val fromStationName: String,
    val toStationName: String,
    val departureTime: String,
    val arrivalTime: String,
    val stopsCount: Int,
    val platform: String
)

data class JourneyItem(
    val id: String,
    val originId: String,
    val destinationId: String,
    val originName: String,
    val destinationName: String,
    val savedTimestamp: Long
)

data class TicketItem(
    val id: String,
    val title: String,
    val type: String,
    val passengerType: String,
    val price: Double,
    val validFrom: String,
    val validUntil: String,
    val qrCodePayload: String,
    val isUsed: Boolean = false,
    val purchaseTimestamp: Long = System.currentTimeMillis()
)

data class ServiceAlert(
    val id: String,
    val lineId: String?,
    val title: String,
    val description: String,
    val severity: String,
    val timestamp: Long = System.currentTimeMillis()
)
