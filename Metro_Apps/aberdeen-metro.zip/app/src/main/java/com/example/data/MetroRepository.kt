package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MetroRepository(private val dao: MetroDao) {

    val stationsFlow: Flow<List<Station>> = dao.getAllStations().map { entities ->
        entities.map { it.toDomain() }
    }

    val linesFlow: Flow<List<MetroLine>> = dao.getAllLines().map { entities ->
        entities.map { it.toDomain() }
    }

    val ticketsFlow: Flow<List<TicketItem>> = dao.getAllTickets().map { entities ->
        entities.map { it.toDomain() }
    }

    val savedJourneysFlow: Flow<List<JourneyItem>> = dao.getSavedJourneys().map { entities ->
        entities.map { JourneyItem(it.id, it.originId, it.destinationId, it.originName, it.destinationName, it.savedTimestamp) }
    }

    val serviceAlertsFlow: Flow<List<ServiceAlert>> = dao.getServiceAlerts().map { entities ->
        entities.map { it.toDomain() }
    }

    suspend fun seedInitialDataIfNeeded() {
        val initialLines = listOf(
            LineEntity("line_blue", "Blue Line", "#0EA5E9", "Airport → Dyce → City Centre → Aberdeen Station", "Good Service"),
            LineEntity("line_copper", "Copper Line", "#D97706", "Westhill → ARI → City Centre → Peterculter", "Good Service"),
            LineEntity("line_teal", "Teal Line", "#0D9488", "Bridge of Don → Beach → Harbour → Cove", "Minor Delays")
        )

        val initialStations = listOf(
            // Blue Line
            StationEntity("st_airport", "Airport", "line_blue", false, true, true, 57.2020, -2.1970, 3, listOf("Airport Terminal", "Express Bus").joinToString(","), listOf("Bus 727").joinToString(","), "Terminal Arrivals Forecourt"),
            StationEntity("st_dyce", "Dyce", "line_blue", false, true, true, 57.2150, -2.2030, 2, listOf("Parking", "Bike Racks").joinToString(","), listOf("National Rail").joinToString(","), "Station Road Entrance"),
            StationEntity("st_bucksburn", "Bucksburn", "line_blue", false, true, false, 57.1920, -2.1750, 2, listOf("Bus Interchange").joinToString(","), listOf("Local Buses").joinToString(","), "Stoneywood Road"),
            StationEntity("st_woodside", "Woodside", "line_blue", false, true, true, 57.1780, -2.1320, 1, listOf("Shelter", "Ticket Office").joinToString(","), "", "Great Northern Road"),
            StationEntity("st_kittybrewster", "Kittybrewster", "line_blue", false, true, true, 57.1650, -2.1150, 1, listOf("Retail Kiosk").joinToString(","), "", "Clifton Road"),
            
            // Shared Interchange
            StationEntity("st_city_centre", "City Centre", "line_blue,line_copper", true, true, true, 57.1498, -2.0938, 1, listOf("WiFi", "Toilets", "ATM", "Shops").joinToString(","), listOf("City Buses").joinToString(","), "St Nicholas Square"),
            StationEntity("st_aberdeen_station", "Aberdeen Station", "line_blue,line_teal", true, true, true, 57.1438, -2.0988, 1, listOf("Travel Centre", "National Rail", "Taxi Rank").joinToString(","), listOf("National Rail", "Ferry Terminal").joinToString(","), "Guild Street Concourse"),

            // Copper Line
            StationEntity("st_westhill", "Westhill", "line_copper", false, true, true, 57.1510, -2.2740, 3, listOf("Park & Ride", "EV Charging").joinToString(","), listOf("Business Park Shuttle").joinToString(","), "Westhill Drive"),
            StationEntity("st_kingswells", "Kingswells", "line_copper", false, true, true, 57.1450, -2.2350, 2, listOf("Park & Ride").joinToString(","), "", "Skene Road"),
            StationEntity("st_ari", "ARI (Royal Infirmary)", "line_copper", false, true, true, 57.1580, -2.1220, 1, listOf("Hospital Access", "Pharmacy").joinToString(","), listOf("Hospital Shuttles").joinToString(","), "Foresterhill Road"),
            StationEntity("st_rosemount", "Rosemount", "line_copper", false, true, false, 57.1520, -2.1080, 1, listOf("Local Shops").joinToString(","), "", "Rosemount Viaduct"),
            StationEntity("st_duthie_park", "Duthie Park", "line_copper", false, true, true, 57.1320, -2.1020, 1, listOf("Park Access", "Café").joinToString(","), "", "Riverside Drive"),
            StationEntity("st_cults", "Cults", "line_copper", false, true, true, 57.1290, -2.1750, 2, listOf("Bike Racks").joinToString(","), "", "North Deeside Road"),
            StationEntity("st_peterculter", "Peterculter", "line_copper", false, true, true, 57.1180, -2.2380, 3, listOf("Heritage Centre", "Parking").joinToString(","), "", "Waterfront Place"),

            // Teal Line
            StationEntity("st_bridge_of_don", "Bridge of Don", "line_teal", false, true, true, 57.1790, -2.1030, 2, listOf("Exhibition Centre", "Parking").joinToString(","), listOf("Coastal Buses").joinToString(","), "Ellon Road"),
            StationEntity("st_university", "University", "line_teal", false, true, true, 57.1640, -2.1010, 1, listOf("Library", "Student Hub").joinToString(","), listOf("Campus Shuttles").joinToString(","), "High Street, Old Aberdeen"),
            StationEntity("st_beach", "Beach", "line_teal", false, true, true, 57.1550, -2.0780, 1, listOf("Esplanade", "Leisure Centre").joinToString(","), "", "Beach Boulevard"),
            StationEntity("st_harbour", "Harbour", "line_teal", false, true, true, 57.1430, -2.0850, 1, listOf("Port Access", "Viewing Platform").joinToString(","), listOf("Ferry Terminal").joinToString(","), "Regent Quay"),
            StationEntity("st_torry", "Torry", "line_teal", false, true, true, 57.1350, -2.0880, 1, listOf("Community Hub").joinToString(","), "", "Victoria Road"),
            StationEntity("st_altens", "Altens", "line_teal", false, true, true, 57.1210, -2.0810, 2, listOf("Industrial Park").joinToString(","), "", "Altens Industrial Estate"),
            StationEntity("st_cove", "Cove", "line_teal", false, true, true, 57.1050, -2.0750, 3, listOf("Coastal Views", "Parking").joinToString(","), "", "Cove Bay Station Road")
        )

        val initialAlerts = listOf(
            ServiceAlertEntity("alert_1", "line_teal", "Teal Line Engineering Works", "Scheduled platform maintenance at Beach station this weekend. Replacement shuttle running.", "Warning", System.currentTimeMillis() - 3600000),
            ServiceAlertEntity("alert_2", null, "Airport Express Frequency Increased", "Additional Blue Line services operating between Aberdeen Station and Airport during peak hours.", "Info", System.currentTimeMillis() - 7200000)
        )

        dao.insertLines(initialLines)
        dao.insertStations(initialStations)
        dao.insertAlerts(initialAlerts)
    }

    suspend fun insertTicket(ticket: TicketItem) {
        dao.insertTicket(ticket.toEntity())
    }

    suspend fun updateTicketUsage(id: String, isUsed: Boolean) {
        dao.updateTicketUsage(id, isUsed)
    }

    suspend fun saveJourney(originId: String, destId: String, originName: String, destName: String) {
        val entity = SavedJourneyEntity(
            id = "sj_${System.currentTimeMillis()}",
            originId = originId,
            destinationId = destId,
            originName = originName,
            destinationName = destName
        )
        dao.insertSavedJourney(entity)
    }

    suspend fun deleteSavedJourney(id: String) {
        dao.deleteSavedJourney(id)
    }
}

fun StationEntity.toDomain() = Station(
    id = id,
    name = name,
    lineIds = lineIdsString.split(","),
    isInterchange = isInterchange,
    isStepFree = isStepFree,
    liftAvailable = liftAvailable,
    latitude = latitude,
    longitude = longitude,
    zone = zone,
    facilities = if (facilitiesString.isBlank()) emptyList() else facilitiesString.split(","),
    connectingTransport = if (connectingTransportString.isBlank()) emptyList() else connectingTransportString.split(","),
    entranceInfo = entranceInfo
)

fun LineEntity.toDomain() = MetroLine(
    id = id,
    name = name,
    colorHex = colorHex,
    corridor = corridor,
    status = status
)

fun TicketEntity.toDomain() = TicketItem(
    id = id,
    title = title,
    type = type,
    passengerType = passengerType,
    price = price,
    validFrom = validFrom,
    validUntil = validUntil,
    qrCodePayload = qrCodePayload,
    isUsed = isUsed,
    purchaseTimestamp = purchaseTimestamp
)

fun TicketItem.toEntity() = TicketEntity(
    id = id,
    title = title,
    type = type,
    passengerType = passengerType,
    price = price,
    validFrom = validFrom,
    validUntil = validUntil,
    qrCodePayload = qrCodePayload,
    isUsed = isUsed,
    purchaseTimestamp = purchaseTimestamp
)

fun ServiceAlertEntity.toDomain() = ServiceAlert(
    id = id,
    lineId = lineId,
    title = title,
    description = description,
    severity = severity,
    timestamp = timestamp
)
