package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Plan : Screen("plan")
    object Map : Screen("map")
    object Tickets : Screen("tickets")
    object Account : Screen("account")
    object StationDetail : Screen("station_detail/{stationId}") {
        fun createRoute(stationId: String) = "station_detail/$stationId"
    }
    object TicketDetail : Screen("ticket_detail/{ticketId}") {
        fun createRoute(ticketId: String) = "ticket_detail/$ticketId"
    }
}
