package com.example

import com.example.data.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testFareCalculation_LRT1() {
        // Roosevelt (lrt1-fpj) to Monumento (lrt1-monumento) is 2 stops
        val fare = TransitData.calculateFare(LineCode.LRT1, "lrt1-fpj", "lrt1-monumento")
        // Base 15.0 + 2 stops * 1.0 = 17.0
        assertEquals(17.0, fare, 0.01)
    }

    @Test
    fun testFareCalculation_LRT2() {
        // Recto to Antipolo is 12 stops
        val fare = TransitData.calculateFare(LineCode.LRT2, "lrt2-recto", "lrt2-antipolo")
        // Base 15.0 + 12 stops * 1.2 = 29.4 rounded to 29.0
        assertEquals(29.0, fare, 0.01)
    }

    @Test
    fun testFareCalculation_MRT3() {
        // North Avenue (mrt3-north) to Taft Avenue (mrt3-taft) is 12 stops
        val fare = TransitData.calculateFare(LineCode.MRT3, "mrt3-north", "mrt3-taft")
        // Base 13.0 + 12 stops * 1.0 = 25.0
        assertEquals(25.0, fare, 0.01)
    }

    @Test
    fun testDirectRoutePlanning_LRT2() {
        // Recto to Gilmore (direct LRT-2)
        val route = TransitData.planRoute("lrt2-recto", "lrt2-gilmore")
        assertNotNull(route)
        assertEquals(1, route!!.legs.size)
        assertTrue(route.legs.first() is JourneyLeg.RailLeg)
        
        val railLeg = route.legs.first() as JourneyLeg.RailLeg
        assertEquals(LineCode.LRT2, railLeg.lineCode)
        assertEquals("lrt2-recto", railLeg.originStationId)
        assertEquals("lrt2-gilmore", railLeg.destinationStationId)
        assertEquals(4, railLeg.intermediateStations.size) // Legarda, Pureza, V.Mapa, J.Ruiz
    }

    @Test
    fun testInterchangeRoutePlanning_LRT2_to_MRT3() {
        // Gilmore (LRT-2) to Ayala (MRT-3) requires transfer at Araneta Center-Cubao
        val route = TransitData.planRoute("lrt2-gilmore", "mrt3-ayala")
        assertNotNull(route)
        
        // Should have 3 legs: RailLeg (LRT-2), TransferLeg (Cubao), RailLeg (MRT-3)
        assertEquals(3, route!!.legs.size)
        
        val firstLeg = route.legs[0] as JourneyLeg.RailLeg
        val transferLeg = route.legs[1] as JourneyLeg.TransferLeg
        val thirdLeg = route.legs[2] as JourneyLeg.RailLeg
        
        assertEquals(LineCode.LRT2, firstLeg.lineCode)
        assertEquals("lrt2-gilmore", firstLeg.originStationId)
        assertEquals("lrt2-cubao", firstLeg.destinationStationId)
        
        assertEquals("lrt2-cubao", transferLeg.stationId)
        assertEquals(LineCode.LRT2, transferLeg.fromLine)
        assertEquals(LineCode.MRT3, transferLeg.toLine)
        
        assertEquals(LineCode.MRT3, thirdLeg.lineCode)
        assertEquals("mrt3-cubao", thirdLeg.originStationId)
        assertEquals("mrt3-ayala", thirdLeg.destinationStationId)
    }

    @Test
    fun testSameStationNoRoute() {
        val route = TransitData.planRoute("lrt2-cubao", "lrt2-cubao")
        assertNotNull(route)
        assertEquals(0, route!!.totalDurationMinutes)
        assertEquals(0.0, route.totalFare, 0.01)
        assertTrue(route.legs.first() is JourneyLeg.WalkLeg)
    }
}
