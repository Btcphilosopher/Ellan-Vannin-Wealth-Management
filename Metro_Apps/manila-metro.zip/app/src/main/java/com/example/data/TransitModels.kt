package com.example.data

import androidx.compose.ui.graphics.Color

enum class LineCode {
    LRT1, LRT2, MRT3, MMS, MRT7, NSCR
}

enum class StationFacilityType {
    ELEVATOR, ESCALATOR, STAIRS, TOILET, ATM, RETAIL, CUSTOMER_SERVICE, BIKE_PARKING
}

enum class TransitCardType {
    BEEP, CONTACTLESS_VISA, CONTACTLESS_MC, MOBILE_WALLET
}

enum class ServiceStatusType {
    NORMAL, MINOR_DELAY, MAJOR_DELAY, PARTIAL_SERVICE, SUSPENDED, PLANNED_WORK, UNKNOWN
}

enum class RoutePreference {
    FASTEST, FEWEST_TRANSFERS, STEP_FREE, CHEAPEST
}

data class TransitLine(
    val id: LineCode,
    val name: String,
    val fullName: String,
    val operator: String,
    val color: Color,
    val status: ServiceStatusType,
    val statusMessage: String,
    val isFuture: Boolean = false,
    val operatingHours: String = "05:00 AM - 10:00 PM"
)

data class StationExit(
    val name: String,
    val bestFor: String,
    val walkTimeMinutes: Int
)

data class StationFacility(
    val type: StationFacilityType,
    val description: String
)

data class Station(
    val id: String,
    val name: String,
    val tag: String, // search keyword e.g. "Cubao", "Ayala"
    val alternativeNames: List<String> = emptyList(),
    val latitude: Double,
    val longitude: Double,
    val lines: List<LineCode>,
    val exits: List<StationExit> = emptyList(),
    val facilities: List<StationFacility> = emptyList(),
    val accessibilityDescription: String = "Accessible with ramps and tactile paths"
)

data class ServiceAlert(
    val id: String,
    val lineId: LineCode,
    val title: String,
    val description: String,
    val severity: ServiceStatusType,
    val timestamp: String
)

data class Arrival(
    val stationId: String,
    val lineId: LineCode,
    val direction: String, // e.g. "Northbound", "Southbound", "Eastbound", "Westbound"
    val destination: String,
    val minutesRemaining: Int,
    val isRealTime: Boolean
)

sealed class JourneyLeg {
    data class WalkLeg(
        val fromName: String,
        val toName: String,
        val distanceMeters: Int,
        val durationMinutes: Int,
        val instructions: List<String>
    ) : JourneyLeg()

    data class RailLeg(
        val lineCode: LineCode,
        val originStationId: String,
        val destinationStationId: String,
        val intermediateStations: List<String>,
        val durationMinutes: Int,
        val fare: Double,
        val direction: String
    ) : JourneyLeg()

    data class TransferLeg(
        val fromLine: LineCode,
        val toLine: LineCode,
        val stationId: String,
        val durationMinutes: Int,
        val instructions: String
    ) : JourneyLeg()
}

data class RouteResult(
    val legs: List<JourneyLeg>,
    val totalDurationMinutes: Int,
    val totalFare: Double,
    val totalWalkDistanceMeters: Int,
    val transferCount: Int
)

data class DiscoverDestination(
    val id: String,
    val name: String,
    val description: String,
    val category: String, // e.g. "Malls", "Universities", "Culture"
    val nearestStationId: String,
    val walkTimeMinutes: Int,
    val imageUrl: String,
    val tips: String
)
