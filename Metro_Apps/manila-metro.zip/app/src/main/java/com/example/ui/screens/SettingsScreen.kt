package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ManilaMetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ManilaMetroViewModel,
    modifier: Modifier = Modifier
) {
    val isEnglish by viewModel.isEnglish.collectAsState()
    val isStepFreePreferred by viewModel.isStepFreePreferred.collectAsState()

    var showHotlineDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Settings title
        item {
            Text(
                text = if (isEnglish) "PREFERENCES & SAFETY" else "MGA SETTING AT KALIGTASAN",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isEnglish) "Customize language, transit preferences, and access help hotlines."
                       else "I-bago ang wika, mga kagustuhan sa ruta, at kumuha ng tulong.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        // Language & Localization options card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isEnglish) "Localisation" else "Wika at Pagsasalin",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = Color.Gray)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (isEnglish) "Current Language: English" else "Kasalukuyang Wika: Filipino",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }

                        Button(
                            onClick = { viewModel.toggleLanguage() },
                            modifier = Modifier.testTag("toggle_language_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (isEnglish) "Filipino" else "English",
                                color = Color(0xFF112233),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Accessibility preference options card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isEnglish) "Accessibility Settings" else "Mga Setting sa Aksesibilidad",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Accessible, contentDescription = null, tint = Color.Gray)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = viewModel.getString("step_free_preference"),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (isEnglish) "Prioritize routes with operational elevators & ramps"
                                           else "I-prioritize ang mga rutang may elevator at rampa",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }
                        }

                        Switch(
                            checked = isStepFreePreferred,
                            onCheckedChange = { viewModel.toggleStepFree() },
                            modifier = Modifier.testTag("step_free_switch")
                        )
                    }
                }
            }
        }

        // Discreet Safety & Assist Guidelines Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = viewModel.getString("safety"),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showHotlineDialog = true }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PhoneCallback, contentDescription = null, tint = Color(0xFFE05A47))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (isEnglish) "View Railway Emergency Hotlines" else "Tingnan ang mga Emergency Hotline",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    // Helpful general railway regulations list
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Passenger Code of Conduct",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "1. Please queue properly at platform screen gates.\n" +
                                       "2. Priority seating must be offered to elderly, pregnant women, and PWD passengers.\n" +
                                       "3. Pets are allowed only inside regulatory hard cages.\n" +
                                       "4. Food, drinks, and smoking are strictly prohibited inside trains.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }

        // About app details
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "MANILA METRO • Passenger Mobility Hub",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Text(
                        text = "Version 1.0.0 (Simulated Demo Mode)",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }

    // Emergency Hotlines Alert dialog
    if (showHotlineDialog) {
        AlertDialog(
            onDismissRequest = { showHotlineDialog = false },
            title = { Text(viewModel.getString("safety")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("In case of medical emergencies, fire, or safety disruptions, contact station staff immediately or dial operator command centers below:", style = MaterialTheme.typography.bodyMedium)
                    
                    HorizontalDivider()

                    Column {
                        Text("LRMC LRT-1 Hotlines:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        Text("(02) 8249-5900", fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    }

                    Column {
                        Text("LRTA LRT-2 Command Center:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        Text("(02) 8647-3479 or (02) 8647-3487", fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    }

                    Column {
                        Text("MRT-3 Station Security Control:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        Text("(02) 8929-5347 ext. 2810", fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    }

                    Column {
                        Text("Philippine National Police Pasay / QC:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        Text("Dial 911 (Direct Emergency Line)", fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showHotlineDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}
