package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.*
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainContainer()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContainer() {
    val viewModel: ManilaMetroViewModel = viewModel()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("app_scaffold"),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsTransit,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Column {
                            Text(
                                text = "MANILA METRO",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Passenger Portal",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                actions = {
                    // Quick language toggle in app bar
                    IconButton(
                        onClick = { viewModel.toggleLanguage() },
                        modifier = Modifier.testTag("appbar_lang_toggle")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "Switch Language",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Alerts shortcut
                    IconButton(
                        onClick = { viewModel.setScreen(ActiveScreen.ALERTS) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Alerts Center",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Settings shortcut
                    IconButton(
                        onClick = { viewModel.setScreen(ActiveScreen.SETTINGS) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .testTag("app_navigation_bar"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                // HOME Item
                NavigationBarItem(
                    selected = currentScreen == ActiveScreen.HOME,
                    onClick = { viewModel.setScreen(ActiveScreen.HOME) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text(if (isEnglish) "Home" else "Home", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_home")
                )

                // PLANNER Item
                NavigationBarItem(
                    selected = currentScreen == ActiveScreen.PLANNER || currentScreen == ActiveScreen.LIVE_TRIP,
                    onClick = { viewModel.setScreen(ActiveScreen.PLANNER) },
                    icon = { Icon(Icons.Default.Route, contentDescription = "Planner") },
                    label = { Text(if (isEnglish) "Planner" else "Ruta", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_planner")
                )

                // MAP Item
                NavigationBarItem(
                    selected = currentScreen == ActiveScreen.MAP,
                    onClick = { viewModel.setScreen(ActiveScreen.MAP) },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                    label = { Text(if (isEnglish) "Map" else "Mapa", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_map")
                )

                // TICKETS Item
                NavigationBarItem(
                    selected = currentScreen == ActiveScreen.FARES,
                    onClick = { viewModel.setScreen(ActiveScreen.FARES) },
                    icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Tickets") },
                    label = { Text(if (isEnglish) "Tickets" else "Tiket", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_tickets")
                )

                // DISCOVER Item
                NavigationBarItem(
                    selected = currentScreen == ActiveScreen.DISCOVER,
                    onClick = { viewModel.setScreen(ActiveScreen.DISCOVER) },
                    icon = { Icon(Icons.Default.Explore, contentDescription = "Discover") },
                    label = { Text(if (isEnglish) "Discover" else "Galugarin", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_discover")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                ActiveScreen.HOME -> HomeScreen(viewModel = viewModel)
                ActiveScreen.PLANNER -> PlannerScreen(viewModel = viewModel)
                ActiveScreen.MAP -> MapScreen(viewModel = viewModel)
                ActiveScreen.FARES -> FaresScreen(viewModel = viewModel)
                ActiveScreen.DISCOVER -> DiscoverScreen(viewModel = viewModel)
                ActiveScreen.LIVE_TRIP -> LiveTripScreen(viewModel = viewModel)
                ActiveScreen.ALERTS -> AlertsScreen(viewModel = viewModel)
                ActiveScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
