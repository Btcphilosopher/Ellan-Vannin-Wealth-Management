package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.ManilaMetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FaresScreen(
    viewModel: ManilaMetroViewModel,
    modifier: Modifier = Modifier
) {
    val isEnglish by viewModel.isEnglish.collectAsState()
    val cards by viewModel.transitCards.collectAsState()
    val transactionHistory by viewModel.transactionHistory.collectAsState()
    val gateState by viewModel.gateState.collectAsState()

    var selectedCard by remember { mutableStateOf<TransitCardEntity?>(null) }
    var showBarcode by remember { mutableStateOf(false) }

    var showTopupDialog by remember { mutableStateOf(false) }
    var showTurnstileSimulator by remember { mutableStateOf(false) }

    // Use first card as default selection if none selected
    LaunchedEffect(cards) {
        if (selectedCard == null && cards.isNotEmpty()) {
            selectedCard = cards.first()
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Stored value cards overview
        item {
            Text(
                text = if (isEnglish) "MANAGE TRANSIT TICKETS" else "MGA TIKET AT TRANSIT CARD",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isEnglish) "Tap any card to view barcode ticket or simulate swipe-gate turnstile."
                       else "I-tap ang card para makita ang tiket o subukan ang pag-tap sa gate.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        // Horizontal Card Carousel selection
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                cards.forEach { card ->
                    val isSelected = selectedCard?.id == card.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedCard = card }
                            .testTag("card_selection_${card.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 6.dp else 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (card.cardType == "BEEP") Icons.Default.Nfc else Icons.Default.CreditCard,
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = card.label,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                if (card.isDefault) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (isSelected) Color.White.copy(alpha = 0.3f) else MaterialTheme.colorScheme.primaryContainer)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "DEFAULT",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Column {
                                    Text(
                                        text = card.cardNo,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp,
                                        color = if (isSelected) Color.White.copy(alpha = 0.8f) else Color.Gray
                                    )
                                    Text(
                                        text = "LAST USED: ${TransitData.stations[card.lastUsedStationId]?.name ?: "None"}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) Color.White.copy(alpha = 0.6f) else Color.Gray,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "₱${"%.2f".format(card.balance)}",
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Black,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "SIMULATED BALANCE",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White.copy(alpha = 0.7f) else Color.Red
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Expandable Barcode Ticket box
        if (selectedCard != null) {
            val card = selectedCard!!
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showBarcode = !showBarcode },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.QrCode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (isEnglish) "Show Barcode Ticket" else "Ipakita ang Barcode Ticket",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Icon(
                                imageVector = if (showBarcode) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null
                            )
                        }

                        AnimatedVisibility(
                            visible = showBarcode,
                            enter = expandVertically(animationSpec = tween(300)),
                            exit = shrinkVertically(animationSpec = tween(300))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Simple text bar code rendering
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(0.9f)
                                        .height(70.dp)
                                        .background(Color.White)
                                        .border(2.dp, Color.Black)
                                        .padding(12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        // Draw multiple lines to represent barcode bars
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            listOf(2, 4, 1, 3, 2, 5, 1, 4, 2, 3, 1, 5, 2, 4).forEach { width ->
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxHeight()
                                                        .width(width.dp)
                                                        .background(Color.Black)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = card.cardNo,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color.Black
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = if (isEnglish) "Scan at modern automated ticket gates" else "I-scan sa mga modernong ticket gate",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }

            // Quick actions (Recharge Beep & Simulate SWIPE GATE)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Topup action button
                    Button(
                        onClick = { showTopupDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("top_up_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.AddCard, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(viewModel.getString("top_up_beep"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // Turnstile simulation trigger
                    Button(
                        onClick = { showTurnstileSimulator = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("turnstile_trigger"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Sensors, contentDescription = null, tint = Color(0xFF112233))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isEnglish) "SWIPE GATE" else "TAPE-GATE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF112233))
                    }
                }
            }
        }

        // SWIPE TURNSTILE SIMULATION interactive playground
        if (showTurnstileSimulator && selectedCard != null) {
            val card = selectedCard!!
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(2.dp, MaterialTheme.colorScheme.secondary, RoundedCornerShape(16.dp))
                        .testTag("turnstile_simulation_box"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DoorSliding, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isEnglish) "TURNSTILE SIMULATOR" else "SIMULADOR NG TURNSTILE",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            IconButton(onClick = { showTurnstileSimulator = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Close Simulator")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Visual simulated terminal screen representation
                        val terminalColor = when (gateState) {
                            ManilaMetroViewModel.GateSimulationState.TAPPED_IN, ManilaMetroViewModel.GateSimulationState.TAPPED_OUT -> Color(0xFF4CAF50)
                            ManilaMetroViewModel.GateSimulationState.INSUFFICIENT_FUNDS -> Color(0xFFF44336)
                            else -> Color(0xFF263238)
                        }

                        val terminalMsg = when (gateState) {
                            ManilaMetroViewModel.GateSimulationState.TAPPED_IN -> "TAPPED IN - WELCOME"
                            ManilaMetroViewModel.GateSimulationState.TAPPED_OUT -> "TAPPED OUT - THANK YOU"
                            ManilaMetroViewModel.GateSimulationState.INSUFFICIENT_FUNDS -> "LOW BALANCE - BLOCKED"
                            else -> "READY - PLEASE TAP CARD"
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(terminalColor)
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = terminalMsg,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Card Bal: ₱${"%.2f".format(card.balance)} (Simulated)",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Gate tap interactive action buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.simulateGateTap(card, 0.0, "lrt2-cubao") // Tap in is free
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tap_in_trigger"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(viewModel.getString("tap_in"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    viewModel.simulateGateTap(card, 22.0, "lrt2-recto") // Average fare subtraction on tap out
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tap_out_trigger"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(viewModel.getString("tap_out"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Localized Turnstile swipe logs history
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = viewModel.getString("history"),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (transactionHistory.isEmpty()) {
                        Text(
                            text = if (isEnglish) "No transactions recorded yet. Tap cards to produce logs."
                                   else "Walang nakatalang transaksyon. Mag-tap ng card para mag-log.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            transactionHistory.take(5).forEach { log ->
                                Text(
                                    text = log,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 13.sp,
                                    color = if (log.contains("DENIED") || log.contains("LOW")) Color(0xFFE05A47) else MaterialTheme.colorScheme.onSurface
                                )
                                HorizontalDivider()
                            }
                        }
                    }
                }
            }
        }
    }

    // Recharge topup selection popup Dialog
    if (showTopupDialog && selectedCard != null) {
        val card = selectedCard!!
        var topupAmt by remember { mutableStateOf(100.0) }

        AlertDialog(
            onDismissRequest = { showTopupDialog = false },
            title = { Text(viewModel.getString("top_up_beep")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        text = "Current balance: ₱${"%.2f".format(card.balance)} (Simulated)",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Text(
                        text = "Select Amount (₱)",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelMedium
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(50.0, 100.0, 200.0, 500.0).forEach { amt ->
                            val isAmtSelected = topupAmt == amt
                            Button(
                                onClick = { topupAmt = amt },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isAmtSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                                ),
                                contentPadding = PaddingValues(4.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "₱${amt.toInt()}",
                                    color = if (isAmtSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Payment, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Secure simulated checkout via GCash/Maya",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.topUpCard(card, topupAmt)
                        showTopupDialog = false
                    },
                    modifier = Modifier.testTag("confirm_topup_button")
                ) {
                    Text("Confirm Recharge")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTopupDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
