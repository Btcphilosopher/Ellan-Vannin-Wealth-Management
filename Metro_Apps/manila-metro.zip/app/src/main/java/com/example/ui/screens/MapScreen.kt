package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.ActiveScreen
import com.example.ui.ManilaMetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    viewModel: ManilaMetroViewModel,
    modifier: Modifier = Modifier
) {
    val isEnglish by viewModel.isEnglish.collectAsState()
    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val selectedLineCode by viewModel.selectedLineCode.collectAsState()
    val arrivals by viewModel.stationArrivals.collectAsState()

    var scale by remember { mutableStateOf(1.2f) }
    var offset by remember { mutableStateOf(Offset(0f, 0f)) }

    val transformState = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.5f, 3.0f)
        offset += offsetChange
    }

    val selectedStation = selectedStationId?.let { TransitData.stations[it] }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Toggle view header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "METRO MANILA RAILWAY MAP",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (isEnglish) "Pan to move, double-finger pinch to zoom" else "I-drag para gumalaw, i-pinch para mag-zoom",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }

                // Reset zoom button
                IconButton(
                    onClick = {
                        scale = 1.2f
                        offset = Offset(0f, 0f)
                    }
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset Zoom", tint = Color.White)
                }
            }
        }

        // Active Interactive Canvas Map Box
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(0.dp))
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                .background(Color(0xFFF1F3F5))
                .transformable(state = transformState)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
            ) {
                // Width and height helpers
                val w = size.width
                val h = size.height
                val cX = w / 2
                val cY = h / 2

                // Define station coordinate mappings on a simplified grid relative to center
                // 1. LRT-1 Line (Yellow, North to Southward corridor)
                val lrt1Coords = listOf(
                    Offset(cX - 150f, cY - 260f), // FPJ Roosevelt
                    Offset(cX - 160f, cY - 210f), // Balintawak
                    Offset(cX - 170f, cY - 160f), // Monumento
                    Offset(cX - 160f, cY - 110f), // 5th Ave
                    Offset(cX - 150f, cY - 60f),  // Tayuman
                    Offset(cX - 140f, cY - 10f),  // D. Jose
                    Offset(cX - 130f, cY + 40f),  // Carriedo
                    Offset(cX - 120f, cY + 90f),  // Central Terminal
                    Offset(cX - 110f, cY + 140f), // Vito Cruz
                    Offset(cX - 100f, cY + 190f), // Gil Puyat
                    Offset(cX - 90f, cY + 240f),  // EDSA
                    Offset(cX - 80f, cY + 290f),  // Baclaran
                    Offset(cX - 70f, cY + 340f)   // Dr. Santos
                )

                // 2. LRT-2 Line (Purple, West to Eastward corridor)
                val lrt2Coords = listOf(
                    Offset(cX - 140f, cY - 10f), // Recto
                    Offset(cX - 80f, cY - 10f),  // Legarda
                    Offset(cX - 20f, cY - 10f),  // Pureza
                    Offset(cX + 40f, cY - 10f),  // Gilmore
                    Offset(cX + 100f, cY - 10f), // Betty Go
                    Offset(cX + 160f, cY - 10f), // Cubao
                    Offset(cX + 220f, cY - 10f), // Anonas
                    Offset(cX + 280f, cY - 10f), // Katipunan
                    Offset(cX + 340f, cY - 10f)  // Antipolo
                )

                // 3. MRT-3 Line (Blue, Ring corridor)
                val mrt3Coords = listOf(
                    Offset(cX - 50f, cY - 140f),  // North Avenue
                    Offset(cX + 10f, cY - 100f),  // Quezon Ave
                    Offset(cX + 70f, cY - 60f),   // Kamuning
                    Offset(cX + 160f, cY - 10f),  // Cubao
                    Offset(cX + 180f, cY + 40f),  // Santolan
                    Offset(cX + 160f, cY + 90f),  // Ortigas
                    Offset(cX + 140f, cY + 140f), // Shaw Blvd
                    Offset(cX + 100f, cY + 190f), // Buendia
                    Offset(cX + 50f, cY + 220f),  // Ayala
                    Offset(cX - 10f, cY + 230f),  // Magallanes
                    Offset(cX - 90f, cY + 240f)   // Taft Avenue
                )

                // Draw Interchange Links (dotted grey rectangles)
                // D.Jose LRT-1 <-> Recto LRT-2
                drawRect(
                    color = Color.DarkGray,
                    topLeft = Offset(cX - 150f, cY - 15f),
                    size = androidx.compose.ui.geometry.Size(30f, 15f),
                    style = Stroke(width = 2f)
                )

                // Cubao LRT-2 <-> Cubao MRT-3
                drawCircle(
                    color = Color.DarkGray,
                    radius = 25f,
                    center = Offset(cX + 160f, cY - 10f),
                    style = Stroke(width = 2f)
                )

                // EDSA LRT-1 <-> Taft MRT-3
                drawCircle(
                    color = Color.DarkGray,
                    radius = 25f,
                    center = Offset(cX - 90f, cY + 240f),
                    style = Stroke(width = 2f)
                )

                // Render MRT-3 (Blue line segment paths)
                val mrt3Path = Path()
                mrt3Path.moveTo(mrt3Coords.first().x, mrt3Coords.first().y)
                for (coord in mrt3Coords.drop(1)) {
                    mrt3Path.lineTo(coord.x, coord.y)
                }
                drawPath(mrt3Path, color = Color(0xFF0070C0), style = Stroke(width = 8f))

                // Render LRT-2 (Purple line segment paths)
                val lrt2Path = Path()
                lrt2Path.moveTo(lrt2Coords.first().x, lrt2Coords.first().y)
                for (coord in lrt2Coords.drop(1)) {
                    lrt2Path.lineTo(coord.x, coord.y)
                }
                drawPath(lrt2Path, color = Color(0xFF7030A0), style = Stroke(width = 8f))

                // Render LRT-1 (Yellow line segment paths)
                val lrt1Path = Path()
                lrt1Path.moveTo(lrt1Coords.first().x, lrt1Coords.first().y)
                for (coord in lrt1Coords.drop(1)) {
                    lrt1Path.lineTo(coord.x, coord.y)
                }
                drawPath(lrt1Path, color = Color(0xFFE4C329), style = Stroke(width = 8f))

                // Render all Station Dots
                lrt1Coords.forEachIndexed { idx, offset ->
                    drawCircle(Color(0xFFE4C329), radius = 10f, center = offset)
                    drawCircle(Color.White, radius = 5f, center = offset)
                }

                lrt2Coords.forEachIndexed { idx, offset ->
                    drawCircle(Color(0xFF7030A0), radius = 10f, center = offset)
                    drawCircle(Color.White, radius = 5f, center = offset)
                }

                mrt3Coords.forEachIndexed { idx, offset ->
                    drawCircle(Color(0xFF0070C0), radius = 10f, center = offset)
                    drawCircle(Color.White, radius = 5f, center = offset)
                }
            }

            // Quick Floating Line Code badges over the map
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LineCode.values().take(3).forEach { code ->
                    val line = TransitData.lines[code] ?: return@forEach
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(line.color)
                            .clickable { viewModel.selectLine(code) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(line.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Expanded Bottom Sheet containing details for selected Station
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("station_bottom_sheet"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (selectedStation != null) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = selectedStation.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    selectedStation.lines.forEach { lineCode ->
                                        val l = TransitData.lines[lineCode] ?: return@forEach
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(l.color)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(l.name, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            // Quick routing buttons
                            Button(
                                onClick = {
                                    viewModel.setOrigin(selectedStation.id)
                                    viewModel.setScreen(ActiveScreen.PLANNER)
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Directions, contentDescription = "Route")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Go", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Dynamic Arrivals Section
                    item {
                        Text(
                            text = if (isEnglish) "EXPECTED LIVE DEPARTURES" else "MGA SUSUNOD NA TREN",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        if (arrivals.isEmpty()) {
                            Text(
                                "No scheduled arrivals right now.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                arrivals.take(3).forEach { arrival ->
                                    val lColor = TransitData.lines[arrival.lineId]?.color ?: Color.Gray
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                                RoundedCornerShape(8.dp)
                                            )
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(lColor)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "${arrival.direction} to ${arrival.destination}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "${arrival.minutesRemaining} mins",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = if (arrival.minutesRemaining <= 3) Color(0xFFE05A47) else MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(
                                                imageVector = Icons.Default.Sensors,
                                                contentDescription = "Live feed verified",
                                                tint = Color(0xFF4CAF50),
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Exits Navigation Guidelines
                    if (selectedStation.exits.isNotEmpty()) {
                        item {
                            Text(
                                text = viewModel.getString("exits"),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                selectedStation.exits.forEach { exit ->
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                                                RoundedCornerShape(8.dp)
                                            )
                                            .padding(8.dp)
                                    ) {
                                        Text(
                                            text = exit.name,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "Best for: ${exit.bestFor}",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        Text(
                                            text = "Walk time: ~${exit.walkTimeMinutes} mins",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Facilities & Accessibility Indicators
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = viewModel.getString("facilities"),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(
                                        Icons.Default.Elevator,
                                        contentDescription = "Elevator",
                                        tint = if (selectedStation.facilities.any { it.type == StationFacilityType.ELEVATOR }) Color(0xFF4CAF50) else Color.Gray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Icon(
                                        Icons.Default.Wc,
                                        contentDescription = "Toilet",
                                        tint = Color(0xFF4CAF50),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Icon(
                                        Icons.Default.Atm,
                                        contentDescription = "ATM Available",
                                        tint = Color(0xFF4CAF50),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = viewModel.getString("accessibility"),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Accessible,
                                        contentDescription = "Accessible",
                                        tint = Color(0xFF4CAF50),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = selectedStation.accessibilityDescription,
                                        fontSize = 11.sp,
                                        lineHeight = 13.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }
                } else {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(36.dp), tint = Color.Gray)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (isEnglish) "Select a station on the interactive map above" else "Pumili ng istasyon sa mapa sa itaas",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
