package com.example.ui

import android.app.Application
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.*

enum class ActiveScreen {
    HOME, DISCOVER, MAP, PLANNER, LIVE_TRIP, FARES, ALERTS, SETTINGS
}

class ManilaMetroViewModel(application: Application) : AndroidViewModel(application) {

    private val db = ManilaMetroDatabase.getDatabase(application)
    private val placeDao = db.savedPlaceDao()
    private val journeyDao = db.savedJourneyDao()
    private val historyDao = db.searchHistoryDao()
    private val cardDao = db.transitCardDao()

    // Screen navigation
    private val _currentScreen = MutableStateFlow(ActiveScreen.HOME)
    val currentScreen: StateFlow<ActiveScreen> = _currentScreen.asStateFlow()

    // Language state: true for English, false for Filipino
    private val _isEnglish = MutableStateFlow(true)
    val isEnglish: StateFlow<Boolean> = _isEnglish.asStateFlow()

    // Accessibility routing: step-free routes preferred
    private val _isStepFreePreferred = MutableStateFlow(false)
    val isStepFreePreferred: StateFlow<Boolean> = _isStepFreePreferred.asStateFlow()

    // Live vs Scheduled Toggle
    private val _isLiveMode = MutableStateFlow(true)
    val isLiveMode: StateFlow<Boolean> = _isLiveMode.asStateFlow()

    // Graph Journey Planner parameters
    private val _originStationId = MutableStateFlow<String?>(null)
    val originStationId: StateFlow<String?> = _originStationId.asStateFlow()

    private val _destStationId = MutableStateFlow<String?>(null)
    val destStationId: StateFlow<String?> = _destStationId.asStateFlow()

    private val _routePreference = MutableStateFlow(RoutePreference.FASTEST)
    val routePreference: StateFlow<RoutePreference> = _routePreference.asStateFlow()

    private val _plannedRoute = MutableStateFlow<RouteResult?>(null)
    val plannedRoute: StateFlow<RouteResult?> = _plannedRoute.asStateFlow()

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Selected station on Map or Search
    private val _selectedStationId = MutableStateFlow<String?>("lrt2-cubao")
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    // Selected line on Map or Search
    private val _selectedLineCode = MutableStateFlow<LineCode?>(LineCode.LRT2)
    val selectedLineCode: StateFlow<LineCode?> = _selectedLineCode.asStateFlow()

    // Service Alerts list (custom state matching realistic feeds)
    private val _alertsList = MutableStateFlow<List<ServiceAlert>>(emptyList())
    val alertsList: StateFlow<List<ServiceAlert>> = _alertsList.asStateFlow()

    // Live Journey Simulator state
    private val _activeTripRoute = MutableStateFlow<RouteResult?>(null)
    val activeTripRoute: StateFlow<RouteResult?> = _activeTripRoute.asStateFlow()

    private val _activeTripLegIndex = MutableStateFlow(0)
    val activeTripLegIndex: StateFlow<Int> = _activeTripLegIndex.asStateFlow()

    private val _activeTripStationIndex = MutableStateFlow(0)
    val activeTripStationIndex: StateFlow<Int> = _activeTripStationIndex.asStateFlow()

    private val _activeTripRemainingMinutes = MutableStateFlow(0)
    val activeTripRemainingMinutes: StateFlow<Int> = _activeTripRemainingMinutes.asStateFlow()

    private val _activeTripCompleted = MutableStateFlow(false)
    val activeTripCompleted: StateFlow<Boolean> = _activeTripCompleted.asStateFlow()

    private val _alertBeforeStop = MutableStateFlow(1) // 1, 2, or 3 stops before stop
    val alertBeforeStop: StateFlow<Int> = _alertBeforeStop.asStateFlow()

    private val _tripAlertTriggered = MutableStateFlow<String?>(null)
    val tripAlertTriggered: StateFlow<String?> = _tripAlertTriggered.asStateFlow()

    private var simulatorJob: Job? = null

    // Room persistent flows
    val savedPlaces: StateFlow<List<SavedPlaceEntity>> = placeDao.getAllSavedPlaces().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val savedJourneys: StateFlow<List<SavedJourneyEntity>> = journeyDao.getAllSavedJourneys().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val searchHistory: StateFlow<List<SearchHistoryEntity>> = historyDao.getRecentHistory().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val transitCards: StateFlow<List<TransitCardEntity>> = cardDao.getAllCards().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Log of turnstile transactions
    private val _transactionHistory = MutableStateFlow<List<String>>(emptyList())
    val transactionHistory: StateFlow<List<String>> = _transactionHistory.asStateFlow()

    // Interactive Gate Tap State
    private val _gateState = MutableStateFlow<GateSimulationState>(GateSimulationState.IDLE)
    val gateState: StateFlow<GateSimulationState> = _gateState.asStateFlow()

    enum class GateSimulationState {
        IDLE, TAPPED_IN, TAPPED_OUT, INSUFFICIENT_FUNDS, ERROR
    }

    // Dynamic Station Arrivals state
    private val _stationArrivals = MutableStateFlow<List<Arrival>>(emptyList())
    val stationArrivals: StateFlow<List<Arrival>> = _stationArrivals.asStateFlow()

    init {
        seedInitialDatabase()
        seedAlerts()
        startArrivalsCountdownUpdater()
    }

    fun setScreen(screen: ActiveScreen) {
        _currentScreen.value = screen
    }

    fun toggleLanguage() {
        _isEnglish.value = !_isEnglish.value
    }

    fun toggleStepFree() {
        _isStepFreePreferred.value = !_isStepFreePreferred.value
        recalculateRoute()
    }

    fun toggleLiveMode() {
        _isLiveMode.value = !_isLiveMode.value
        seedAlerts()
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        if (query.isNotEmpty()) {
            viewModelScope.launch {
                historyDao.insertHistory(SearchHistoryEntity(query = query, timestamp = System.currentTimeMillis()))
            }
        }
    }

    fun setOrigin(stationId: String?) {
        _originStationId.value = stationId
        recalculateRoute()
    }

    fun setDestination(stationId: String?) {
        _destStationId.value = stationId
        recalculateRoute()
    }

    fun setPreference(pref: RoutePreference) {
        _routePreference.value = pref
        recalculateRoute()
    }

    fun selectStation(stationId: String?) {
        _selectedStationId.value = stationId
        stationId?.let { id ->
            val station = TransitData.stations[id]
            if (station != null && station.lines.isNotEmpty()) {
                _selectedLineCode.value = station.lines.first()
            }
            updateArrivalsForStation(id)
        }
    }

    fun selectLine(lineCode: LineCode?) {
        _selectedLineCode.value = lineCode
    }

    fun addSavedPlace(label: String, customName: String, stationId: String, address: String) {
        viewModelScope.launch {
            placeDao.insertSavedPlace(
                SavedPlaceEntity(
                    label = label,
                    customName = customName,
                    stationId = stationId,
                    address = address
                )
            )
        }
    }

    fun deleteSavedPlace(entity: SavedPlaceEntity) {
        viewModelScope.launch {
            placeDao.deleteSavedPlace(entity)
        }
    }

    fun addSavedJourney(name: String, originId: String, destId: String, depTime: String, days: String) {
        viewModelScope.launch {
            journeyDao.insertSavedJourney(
                SavedJourneyEntity(
                    name = name,
                    originStationId = originId,
                    destinationStationId = destId,
                    departureTime = depTime,
                    daysOfWeek = days
                )
            )
        }
    }

    fun deleteSavedJourney(entity: SavedJourneyEntity) {
        viewModelScope.launch {
            journeyDao.deleteSavedJourney(entity)
        }
    }

    fun clearSearchHistory() {
        viewModelScope.launch {
            historyDao.clearHistory()
        }
    }

    // Dynamic Fare & Routing integration
    private fun recalculateRoute() {
        val orig = _originStationId.value
        val dest = _destStationId.value
        if (orig != null && dest != null) {
            val pref = if (_isStepFreePreferred.value) RoutePreference.STEP_FREE else _routePreference.value
            val result = TransitData.planRoute(orig, dest, pref)
            _plannedRoute.value = result
        } else {
            _plannedRoute.value = null
        }
    }

    // Arrival calculations based on clock/simulation
    fun updateArrivalsForStation(stationId: String) {
        val station = TransitData.stations[stationId] ?: return
        val list = mutableListOf<Arrival>()
        val calendar = Calendar.getInstance()
        val seedRandom = Random(stationId.hashCode().toLong() + calendar.get(Calendar.MINUTE) / 3)

        for (line in station.lines) {
            val lineStations = TransitData.getStationsForLine(line)
            val index = lineStations.indexOfFirst { it.id == stationId }
            if (index == -1) continue

            // 1. East/Northbound
            if (index < lineStations.size - 1) {
                val destName = lineStations.last().name
                val dir = when (line) {
                    LineCode.LRT2 -> "Eastbound"
                    LineCode.MRT3 -> "Southbound"
                    else -> "Southbound"
                }
                val min1 = seedRandom.nextInt(1, 4)
                val min2 = min1 + seedRandom.nextInt(4, 7)
                list.add(Arrival(stationId, line, dir, destName, min1, _isLiveMode.value))
                list.add(Arrival(stationId, line, dir, destName, min2, _isLiveMode.value))
            }

            // 2. West/Southbound
            if (index > 0) {
                val destName = lineStations.first().name
                val dir = when (line) {
                    LineCode.LRT2 -> "Westbound"
                    LineCode.MRT3 -> "Northbound"
                    else -> "Northbound"
                }
                val min1 = seedRandom.nextInt(2, 5)
                val min2 = min1 + seedRandom.nextInt(4, 8)
                list.add(Arrival(stationId, line, dir, destName, min1, _isLiveMode.value))
                list.add(Arrival(stationId, line, dir, destName, min2, _isLiveMode.value))
            }
        }
        _stationArrivals.value = list
    }

    private fun startArrivalsCountdownUpdater() {
        viewModelScope.launch {
            while (true) {
                delay(30000) // Update every 30 seconds
                _selectedStationId.value?.let {
                    updateArrivalsForStation(it)
                }
            }
        }
    }

    // Card Top-Ups and Swipe Gate Actions
    fun topUpCard(card: TransitCardEntity, amount: Double) {
        viewModelScope.launch {
            val updated = card.copy(balance = card.balance + amount)
            cardDao.insertCard(updated)
            logTransaction("Top-up: +₱${"%.2f".format(amount)} onto card ${card.label} via GCash")
        }
    }

    fun simulateGateTap(card: TransitCardEntity, requiredFare: Double, stationId: String) {
        viewModelScope.launch {
            if (card.balance < requiredFare) {
                _gateState.value = GateSimulationState.INSUFFICIENT_FUNDS
                logTransaction("TAP DENIED: Insufficient Balance (₱${"%.2f".format(card.balance)} < ₱${"%.2f".format(requiredFare)})")
                delay(2500)
                _gateState.value = GateSimulationState.IDLE
            } else {
                val newBal = card.balance - requiredFare
                val updated = card.copy(balance = newBal, lastUsedStationId = stationId)
                cardDao.insertCard(updated)
                _gateState.value = GateSimulationState.TAPPED_OUT
                val stationName = TransitData.stations[stationId]?.name ?: stationId
                logTransaction("TAP SUCCESS: Fare ₱${"%.2f".format(requiredFare)} paid. Balance: ₱${"%.2f".format(newBal)} at $stationName")
                delay(2500)
                _gateState.value = GateSimulationState.IDLE
            }
        }
    }

    private fun logTransaction(log: String) {
        val currentLogs = _transactionHistory.value.toMutableList()
        currentLogs.add(0, "[${Date().toLocaleString()}] $log")
        _transactionHistory.value = currentLogs
    }

    // Immersive Active Live Journey Navigation simulator
    fun startTripSimulation(route: RouteResult) {
        simulatorJob?.cancel()
        _activeTripRoute.value = route
        _activeTripLegIndex.value = 0
        _activeTripStationIndex.value = 0
        _activeTripRemainingMinutes.value = route.totalDurationMinutes
        _activeTripCompleted.value = false
        _tripAlertTriggered.value = null

        // Gather all transit stations in order across the rail legs
        val railLegs = route.legs.filterIsInstance<JourneyLeg.RailLeg>()
        if (railLegs.isEmpty()) {
            _activeTripCompleted.value = true
            return
        }

        val allStations = mutableListOf<String>()
        // Add start station
        allStations.add(railLegs.first().originStationId)
        for (leg in railLegs) {
            allStations.addAll(leg.intermediateStations)
            allStations.add(leg.destinationStationId)
        }
        val distinctStations = allStations.distinct()

        simulatorJob = viewModelScope.launch {
            setScreen(ActiveScreen.LIVE_TRIP)
            for (idx in distinctStations.indices) {
                _activeTripStationIndex.value = idx
                val currentStationId = distinctStations[idx]
                val currentStationName = TransitData.stations[currentStationId]?.name ?: currentStationId

                // Check alert triggers (X stops before destination)
                val stopsRemaining = distinctStations.size - 1 - idx
                if (stopsRemaining > 0 && stopsRemaining <= _alertBeforeStop.value) {
                    _tripAlertTriggered.value = "ALERT: Commuter Alert! $stopsRemaining stop(s) before your destination. Get ready to alight at ${TransitData.stations[distinctStations.last()]?.name}!"
                }

                if (idx == distinctStations.size - 1) {
                    _tripAlertTriggered.value = "ARRIVED: Welcome! You have arrived at your destination: $currentStationName. Remember to tap your ticket to exit."
                    _activeTripCompleted.value = true
                }

                _activeTripRemainingMinutes.value = Math.max(0, (stopsRemaining * 2))
                delay(5000) // Simulated station duration (5 seconds)
            }
        }
    }

    fun stopTripSimulation() {
        simulatorJob?.cancel()
        _activeTripRoute.value = null
        _activeTripCompleted.value = false
        _tripAlertTriggered.value = null
    }

    fun setAlertBeforeStop(stops: Int) {
        _alertBeforeStop.value = stops
    }

    private fun seedInitialDatabase() {
        viewModelScope.launch {
            // Seed a sample default card if table is empty
            cardDao.getAllCards().collect { list ->
                if (list.isEmpty()) {
                    cardDao.insertCard(
                        TransitCardEntity(
                            cardType = "BEEP",
                            cardNo = "1201-4498-2231-9005",
                            balance = 250.0,
                            label = "My Primary Beep Card",
                            isDefault = true
                        )
                    )
                    cardDao.insertCard(
                        TransitCardEntity(
                            cardType = "CONTACTLESS_VISA",
                            cardNo = "Visa •••• 5691",
                            balance = 1500.0,
                            label = "Maya Card (Contactless)",
                            isDefault = false
                        )
                    )
                }
            }
        }

        viewModelScope.launch {
            placeDao.getAllSavedPlaces().collect { list ->
                if (list.isEmpty()) {
                    placeDao.insertSavedPlace(SavedPlaceEntity(label = "Home", customName = "Home (Parañaque)", stationId = "lrt1-drsantos", address = "Dr. Santos, Sucat Rd"))
                    placeDao.insertSavedPlace(SavedPlaceEntity(label = "Work", customName = "Corporate Office", stationId = "mrt3-ayala", address = "Ayala Avenue, Makati"))
                    placeDao.insertSavedPlace(SavedPlaceEntity(label = "School", customName = "Katipunan Campus", stationId = "lrt2-katipunan", address = "Loyola Heights, Quezon City"))
                }
            }
        }
    }

    private fun seedAlerts() {
        val list = mutableListOf<ServiceAlert>()
        if (_isLiveMode.value) {
            // Live-disruption mode alerts
            list.add(
                ServiceAlert(
                    id = "alert-mrt3-delay",
                    lineId = LineCode.MRT3,
                    title = "Minor Disruption: Slow Operations",
                    description = "Speed restriction of 30kph implemented between Santolan-Annapolis and Ortigas due to signaling calibrations. Expect 4-6 minutes additional travel time.",
                    severity = ServiceStatusType.MINOR_DELAY,
                    timestamp = "Updated 10 mins ago"
                )
            )
            list.add(
                ServiceAlert(
                    id = "alert-lrt1-construction",
                    lineId = LineCode.LRT1,
                    title = "Planned Work: Cavite Extension",
                    description = "Temporary platform adjustments at Redemptorist and Dr. Santos station for testing of mechanical systems. Trains are active but use caution.",
                    severity = ServiceStatusType.PLANNED_WORK,
                    timestamp = "Valid today"
                )
            )
            list.add(
                ServiceAlert(
                    id = "alert-typhoon",
                    lineId = LineCode.LRT2,
                    title = "Weather Advisory: Heavy Rain",
                    description = "Heavy monsoon rainfall across Metro Manila. LRT-2 operations remain normal but street-level walking paths at Recto and Cubao have high water levels.",
                    severity = ServiceStatusType.NORMAL,
                    timestamp = "Updated 2 mins ago"
                )
            )
        } else {
            // Normal scheduled operations mode
            list.add(
                ServiceAlert(
                    id = "alert-sched-normal",
                    lineId = LineCode.LRT2,
                    title = "Full Normal Operations",
                    description = "All railway operator feeds confirm normal running status on scheduled timetables.",
                    severity = ServiceStatusType.NORMAL,
                    timestamp = "Just now"
                )
            )
        }
        _alertsList.value = list
    }

    // Localization strings dictionary helper
    fun getString(key: String): String {
        val eng = mapOf(
            "where_to" to "Where are you going?",
            "search_hint" to "Search malls, stations, universities...",
            "nearby_stations" to "NEARBY STATIONS",
            "network_status" to "NETWORK STATUS",
            "normal" to "Normal",
            "minor_delay" to "Minor Delay",
            "major_delay" to "Major Delay",
            "suspended" to "Suspended",
            "planned_work" to "Planned Work",
            "unknown" to "Unknown",
            "good_service" to "Good Service",
            "min_walk" to "min walk",
            "next_train" to "Next train",
            "operating_hours" to "Operating Hours",
            "exits" to "STATION EXITS",
            "facilities" to "FACILITIES",
            "accessibility" to "ACCESSIBILITY",
            "live" to "LIVE",
            "scheduled" to "SCHEDULED",
            "from" to "From",
            "to" to "To",
            "find_route" to "PLAN MY JOURNEY",
            "route_preference" to "Route Preference",
            "fastest" to "Fastest Duration",
            "fewest_transfers" to "Fewest Transfers",
            "cheapest" to "Cheapest Fare",
            "step_free_preference" to "Step-free (Wheelchair Friendly)",
            "start_live_journey" to "START LIVE TRIP SIMULATOR",
            "stops_remaining" to "stops remaining",
            "get_off_alert" to "GET READY TO ALIGHT",
            "tap_in" to "TAP IN TICKET",
            "tap_out" to "TAP OUT TICKET",
            "wallet_balance" to "Transit Balance",
            "simulated" to "SIMULATED",
            "alert_me_before" to "Alert me before my stop:",
            "stops" to "stops",
            "stop" to "stop",
            "top_up_beep" to "TOP UP BEEP CARD",
            "history" to "Transaction Logs",
            "english" to "English",
            "filipino" to "Filipino",
            "safety" to "Safety & Hotline Assistance",
            "save_place" to "Save New Place",
            "saved_places" to "SAVED PLACES"
        )

        val tgl = mapOf(
            "where_to" to "Saan mo gustong pumunta?",
            "search_hint" to "Maghanap ng malls, istasyon, unibersidad...",
            "nearby_stations" to "MGA KALAPIT NA ISTASYON",
            "network_status" to "STATUS NG OPERASYON",
            "normal" to "Normal",
            "minor_delay" to "Bahagyang Naantala",
            "major_delay" to "Malaking Pagkaantala",
            "suspended" to "Ipinatigil",
            "planned_work" to "Naka-iskedyul na Gawa",
            "unknown" to "Hindi Alám",
            "good_service" to "Maayos na Serbisyo",
            "min_walk" to "min lakad",
            "next_train" to "Susunod na tren",
            "operating_hours" to "Oras ng Biyahe",
            "exits" to "MGA LABASAN NG ISTASYON",
            "facilities" to "MGA PASILIDAD",
            "accessibility" to "AKSESIBILIDAD",
            "live" to "LIVE FEED",
            "scheduled" to "ORAS SA ISKEDYUL",
            "from" to "Mula sa",
            "to" to "Patungo sa",
            "find_route" to "MAGPLANO NG BIYAHE",
            "route_preference" to "Nais na Ruta",
            "fastest" to "Pinakamabilis",
            "fewest_transfers" to "Kaunting Paglipat",
            "cheapest" to "Pinakamababang Pamasahe",
            "step_free_preference" to "Walang Hagdan (Para sa Wheelchair)",
            "start_live_journey" to "SIMULAN ANG SIMULASYON NG BIYAHE",
            "stops_remaining" to "istasyon ang natitira",
            "get_off_alert" to "MAGHANDA NANG BUMABA",
            "tap_in" to "TAP IN SA TAPE-GATE",
            "tap_out" to "TAP OUT SA TAPE-GATE",
            "wallet_balance" to "Pondo ng Transit Card",
            "simulated" to "SIMULADO",
            "alert_me_before" to "Paalalahanan ako bago bumaba:",
            "stops" to "istasyon",
            "stop" to "istasyon",
            "top_up_beep" to "MAG-RECHARGE NG BEEP CARD",
            "history" to "Mga Nakaraang Transaksyon",
            "english" to "English",
            "filipino" to "Filipino",
            "safety" to "Kaligtasan at mga Emergency Hotline",
            "save_place" to "I-save ang Bagong Lugar",
            "saved_places" to "MGA INI-SAVENG LUGAR"
        )

        val dict = if (_isEnglish.value) eng else tgl
        return dict[key] ?: key
    }
}
