package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.ActiveScreen
import com.example.ui.ManilaMetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(
    viewModel: ManilaMetroViewModel,
    modifier: Modifier = Modifier
) {
    val isEnglish by viewModel.isEnglish.collectAsState()
    val isStepFreePreferred by viewModel.isStepFreePreferred.collectAsState()
    val routePreference by viewModel.routePreference.collectAsState()
    val originId by viewModel.originStationId.collectAsState()
    val destId by viewModel.destStationId.collectAsState()
    val plannedRoute by viewModel.plannedRoute.collectAsState()

    var showOriginPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }

    val allStations = TransitData.stations.values.toList().sortedBy { it.name }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Station Selectors
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("journey_fields_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (isEnglish) "PLAN YOUR JOURNEY" else "IPLANO ANG RUTA",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // Origin Input Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .clickable { showOriginPicker = true }
                            .padding(12.dp)
                            .testTag("origin_picker_trigger")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MyLocation, contentDescription = null, tint = Color(0xFF4CAF50))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = viewModel.getString("from"),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.Gray
                                )
                                Text(
                                    text = originId?.let { TransitData.stations[it]?.name } ?: (if (isEnglish) "Select Start Station" else "Pumili ng Simulang Istasyon"),
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = if (originId != null) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    // Destination Input Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .clickable { showDestPicker = true }
                            .padding(12.dp)
                            .testTag("dest_picker_trigger")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Place, contentDescription = null, tint = Color(0xFFE05A47))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = viewModel.getString("to"),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.Gray
                                )
                                Text(
                                    text = destId?.let { TransitData.stations[it]?.name } ?: (if (isEnglish) "Select Destination" else "Pumili ng Patutunguhan"),
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = if (destId != null) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    // Accessibility & Swap Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Quick Swap button
                        IconButton(
                            onClick = {
                                val temp = originId
                                viewModel.setOrigin(destId)
                                viewModel.setDestination(temp)
                            }
                        ) {
                            Icon(Icons.Default.SwapVert, contentDescription = "Swap Locations")
                        }

                        // Step Free switch option
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { viewModel.toggleStepFree() }
                        ) {
                            Checkbox(
                                checked = isStepFreePreferred,
                                onCheckedChange = { viewModel.toggleStepFree() },
                                modifier = Modifier.testTag("step_free_checkbox")
                            )
                            Text(
                                text = "Wheelchair / Step-Free",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Preference Chips Row
        item {
            Text(
                text = viewModel.getString("route_preference"),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RoutePreference.values().take(3).forEach { pref ->
                    val label = when (pref) {
                        RoutePreference.FASTEST -> viewModel.getString("fastest")
                        RoutePreference.FEWEST_TRANSFERS -> viewModel.getString("fewest_transfers")
                        else -> viewModel.getString("cheapest")
                    }
                    val isSelected = pref == routePreference

                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setPreference(pref) },
                        label = { Text(label, fontSize = 11.sp) },
                        modifier = Modifier.testTag("pref_chip_${pref.name}")
                    )
                }
            }
        }

        // Planned Journey Result Cards
        if (plannedRoute != null) {
            val route = plannedRoute!!

            // Journey Totals Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "SUMMARY OF TRIP",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${route.totalDurationMinutes} mins travel time",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "₱${"%.2f".format(route.totalFare)}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Text(
                                    text = "${route.transferCount} transfers",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Dynamic Launch button for simulation
                        Button(
                            onClick = { viewModel.startTripSimulation(route) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("start_simulation_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF112233))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = viewModel.getString("start_live_journey"),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF112233)
                            )
                        }
                    }
                }
            }

            // Steps break-down list
            item {
                Text(
                    text = "STEP-BY-STEP DIRECTIONS",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            items(route.legs) { leg ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        when (leg) {
                            is JourneyLeg.WalkLeg -> {
                                Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = Color.Gray)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("Walk from ${leg.fromName} to ${leg.toName}", fontWeight = FontWeight.SemiBold)
                                    Text("${leg.distanceMeters}m • ${leg.durationMinutes} mins", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                }
                            }
                            is JourneyLeg.RailLeg -> {
                                val line = TransitData.lines[leg.lineCode]
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(line?.color ?: Color.Gray),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(line?.name ?: "", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    val startStationName = TransitData.stations[leg.originStationId]?.name ?: ""
                                    val endStationName = TransitData.stations[leg.destinationStationId]?.name ?: ""
                                    Text("Board $startStationName", fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${leg.direction} direction",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "Ride ${leg.intermediateStations.size + 1} stop(s) to $endStationName",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        text = "Duration: ${leg.durationMinutes} mins • Fare: ₱${"%.2f".format(leg.fare)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.Gray
                                    )
                                }
                            }
                            is JourneyLeg.TransferLeg -> {
                                val fromLine = TransitData.lines[leg.fromLine]
                                val toLine = TransitData.lines[leg.toLine]
                                Icon(Icons.Default.TransferWithinAStation, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    val stationName = TransitData.stations[leg.stationId]?.name ?: ""
                                    Text("Transfer at $stationName", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                    Text(
                                        text = "Change from ${fromLine?.name} to ${toLine?.name}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = leg.instructions,
                                        style = MaterialTheme.typography.bodySmall,
                                        lineHeight = 15.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else if (originId != null && destId != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Could not plan a transit route with selected parameters.", color = Color.Gray)
                }
            }
        } else {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.AltRoute, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.Gray)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isEnglish) "Set origin and destination above to calculate route" else "Magtakda ng simula at patutunguhan para i-plano",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }

    // Origin Picker Popup dialog
    if (showOriginPicker) {
        var query by remember { mutableStateOf("") }
        val filtered = allStations.filter { it.name.contains(query, ignoreCase = true) }

        AlertDialog(
            onDismissRequest = { showOriginPicker = false },
            title = { Text(viewModel.getString("from")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Search Station") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    LazyColumn(
                        modifier = Modifier
                            .height(250.dp)
                            .fillMaxWidth()
                    ) {
                        items(filtered) { station ->
                            ListItem(
                                headlineContent = { Text(station.name, fontWeight = FontWeight.SemiBold) },
                                supportingContent = { Text(station.lines.joinToString(", ")) },
                                modifier = Modifier.clickable {
                                    viewModel.setOrigin(station.id)
                                    showOriginPicker = false
                                }
                            )
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showOriginPicker = false }) { Text("Cancel") }
            }
        )
    }

    // Destination Picker Popup dialog
    if (showDestPicker) {
        var query by remember { mutableStateOf("") }
        val filtered = allStations.filter { it.name.contains(query, ignoreCase = true) }

        AlertDialog(
            onDismissRequest = { showDestPicker = false },
            title = { Text(viewModel.getString("to")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Search Station") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    LazyColumn(
                        modifier = Modifier
                            .height(250.dp)
                            .fillMaxWidth()
                    ) {
                        items(filtered) { station ->
                            ListItem(
                                headlineContent = { Text(station.name, fontWeight = FontWeight.SemiBold) },
                                supportingContent = { Text(station.lines.joinToString(", ")) },
                                modifier = Modifier.clickable {
                                    viewModel.setDestination(station.id)
                                    showDestPicker = false
                                }
                            )
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDestPicker = false }) { Text("Cancel") }
            }
        )
    }
}
