package com.example.data

import androidx.compose.ui.graphics.Color
import java.util.PriorityQueue

object TransitData {

    val lines = mapOf(
        LineCode.LRT1 to TransitLine(
            id = LineCode.LRT1,
            name = "LRT-1",
            fullName = "LRT Line 1 (Green/Yellow)",
            operator = "Light Rail Manila Corporation (LRMC)",
            color = Color(0xFFE4C329), // Bright Yellow-Gold
            status = ServiceStatusType.NORMAL,
            statusMessage = "Good service across all stations."
        ),
        LineCode.LRT2 to TransitLine(
            id = LineCode.LRT2,
            name = "LRT-2",
            fullName = "LRT Line 2 (Purple)",
            operator = "Light Rail Transit Authority (LRTA)",
            color = Color(0xFF7030A0), // Deep Purple
            status = ServiceStatusType.NORMAL,
            statusMessage = "Good service. Normal operations."
        ),
        LineCode.MRT3 to TransitLine(
            id = LineCode.MRT3,
            name = "MRT-3",
            fullName = "MRT Line 3 (Blue)",
            operator = "Metro Rail Transit Corporation (MRTC)",
            color = Color(0xFF0070C0), // Sky Blue
            status = ServiceStatusType.NORMAL,
            statusMessage = "Normal operations. 15 trains running."
        ),
        LineCode.MMS to TransitLine(
            id = LineCode.MMS,
            name = "MMS",
            fullName = "Metro Manila Subway (Future)",
            operator = "DOTr",
            color = Color(0xFFC00000), // Crimson Red
            status = ServiceStatusType.PLANNED_WORK,
            statusMessage = "Under construction. Priority project.",
            isFuture = true
        ),
        LineCode.MRT7 to TransitLine(
            id = LineCode.MRT7,
            name = "MRT-7",
            fullName = "MRT Line 7 (Green/Red)",
            operator = "SMC Mass Rail Transit II",
            color = Color(0xFF385723), // Forest Green
            status = ServiceStatusType.PLANNED_WORK,
            statusMessage = "Under construction. Dynamic testing underway.",
            isFuture = true
        )
    )

    val stations = mapOf(
        // LRT-1 Stations
        "lrt1-fpj" to Station("lrt1-fpj", "FPJ (Roosevelt)", "Roosevelt", listOf("FPJ"), 14.6575, 121.0211, listOf(LineCode.LRT1)),
        "lrt1-balintawak" to Station("lrt1-balintawak", "Balintawak", "Balintawak", emptyList(), 14.65, 121.001, listOf(LineCode.LRT1)),
        "lrt1-monumento" to Station("lrt1-monumento", "Monumento", "Monumento", emptyList(), 14.6536, 120.9839, listOf(LineCode.LRT1)),
        "lrt1-5thave" to Station("lrt1-5thave", "5th Avenue", "5th Ave", emptyList(), 14.6444, 120.9836, listOf(LineCode.LRT1)),
        "lrt1-rpapa" to Station("lrt1-rpapa", "R. Papa", "Papa", emptyList(), 14.6361, 120.9828, listOf(LineCode.LRT1)),
        "lrt1-abadsantos" to Station("lrt1-abadsantos", "Abad Santos", "Abad", emptyList(), 14.6292, 120.9814, listOf(LineCode.LRT1)),
        "lrt1-blumentritt" to Station("lrt1-blumentritt", "Blumentritt", "Blumentritt", emptyList(), 14.6225, 120.9831, listOf(LineCode.LRT1)),
        "lrt1-tayuman" to Station("lrt1-tayuman", "Tayuman", "Tayuman", emptyList(), 14.6169, 120.9822, listOf(LineCode.LRT1)),
        "lrt1-bambang" to Station("lrt1-bambang", "Bambang", "Bambang", emptyList(), 14.6111, 120.9817, listOf(LineCode.LRT1)),
        "lrt1-djose" to Station(
            "lrt1-djose", "D. Jose", "Jose", listOf("Doroteo Jose"), 14.6053, 120.9817, listOf(LineCode.LRT1),
            exits = listOf(
                StationExit("East Exit", "Rizal Avenue, Manila Grand Opera", 2),
                StationExit("West Exit", "Doroteo Jose St, LRT-2 Recto Walkway", 3)
            ),
            facilities = listOf(
                StationFacility(StationFacilityType.ELEVATOR, "At northbound boarding platform"),
                StationFacility(StationFacilityType.CUSTOMER_SERVICE, "Concourse area level 1")
            )
        ),
        "lrt1-carriedo" to Station(
            "lrt1-carriedo", "Carriedo", "Carriedo", listOf("Quiapo"), 14.5996, 120.9804, listOf(LineCode.LRT1),
            exits = listOf(
                StationExit("Plaza Lacson", "Escolta, Santa Cruz Church", 2),
                StationExit("Quiapo Walkway", "Quiapo Church, Carriedo Shopping", 4)
            )
        ),
        "lrt1-central" to Station(
            "lrt1-central", "Central Terminal", "Central", listOf("Arroceros", "Intramuros"), 14.5919, 120.9814, listOf(LineCode.LRT1),
            exits = listOf(
                StationExit("Arroceros Park", "Forest Park, Metropolitan Theater", 1),
                StationExit("Intramuros Pathway", "SM Manila, City Hall, Intramuros Gate", 5)
            )
        ),
        "lrt1-un" to Station("lrt1-un", "United Nations", "UN Avenue", listOf("Rizal Park"), 14.5828, 120.9839, listOf(LineCode.LRT1)),
        "lrt1-padrefaura" to Station("lrt1-padrefaura", "Padre Faura", "Faura", listOf("PGH"), 14.578, 120.985, listOf(LineCode.LRT1)),
        "lrt1-quirino" to Station("lrt1-quirino", "Quirino", "Quirino", listOf("Zoo"), 14.5701, 120.9915, listOf(LineCode.LRT1)),
        "lrt1-vitocruz" to Station(
            "lrt1-vitocruz", "Vito Cruz", "Vito Cruz", listOf("DLSU"), 14.5633, 120.9949, listOf(LineCode.LRT1),
            exits = listOf(
                StationExit("DLSU Gate", "De La Salle University campus", 2),
                StationExit("Rizal Coliseum", "Sports complex, Harrison Plaza area", 4)
            )
        ),
        "lrt1-gilpuyat" to Station(
            "lrt1-gilpuyat", "Gil Puyat", "Gil Puyat", listOf("Buendia LRT"), 14.5544, 120.9972, listOf(LineCode.LRT1),
            exits = listOf(
                StationExit("Bus Terminal North", "DLTB, JAC Liner Terminals for Batangas", 1),
                StationExit("Buendia West", "Sogo Hotel, Taft Avenue commercial establishments", 2)
            )
        ),
        "lrt1-libertad" to Station("lrt1-libertad", "Libertad", "Libertad", listOf("Pasay"), 14.5476, 120.9985, listOf(LineCode.LRT1)),
        "lrt1-edsa" to Station(
            "lrt1-edsa", "EDSA", "EDSA", listOf("EDSA LRT"), 14.5375, 121.0013, listOf(LineCode.LRT1),
            exits = listOf(
                StationExit("Metropoint Mall", "Direct connection to Metropoint Shopping Center", 1),
                StationExit("MRT-3 Walkway", "Covered bridge to MRT-3 Taft Avenue Station", 3)
            ),
            facilities = listOf(
                StationFacility(StationFacilityType.ELEVATOR, "Street to concourse, concourse to platform"),
                StationFacility(StationFacilityType.TOILET, "Inside paid area concourse"),
                StationFacility(StationFacilityType.ATM, "BDO and BPI near turnstiles")
            )
        ),
        "lrt1-baclaran" to Station("lrt1-baclaran", "Baclaran", "Baclaran", listOf("Redemptorist"), 14.5283, 121.0022, listOf(LineCode.LRT1)),
        "lrt1-redemptorist" to Station("lrt1-redemptorist", "Redemptorist", "Redemptorist", emptyList(), 14.5211, 121.0031, listOf(LineCode.LRT1)),
        "lrt1-mia" to Station("lrt1-mia", "MIA Road", "MIA", listOf("Airport Road"), 14.5125, 121.0042, listOf(LineCode.LRT1)),
        "lrt1-asiaworld" to Station("lrt1-asiaworld", "Asia World", "Asiaworld", listOf("PITX"), 14.505, 121.0055, listOf(LineCode.LRT1)),
        "lrt1-ninoyaquino" to Station("lrt1-ninoyaquino", "Ninoy Aquino", "Ninoy", emptyList(), 14.4965, 121.007, listOf(LineCode.LRT1)),
        "lrt1-drsantos" to Station(
            "lrt1-drsantos", "Dr. Santos", "Santos", listOf("Sucat"), 14.4851, 121.0112, listOf(LineCode.LRT1),
            exits = listOf(
                StationExit("Sucat Road North", "SM City Sucat, Transport Terminal", 3),
                StationExit("South Exit", "Parañaque residential and commercial streets", 4)
            )
        ),

        // LRT-2 Stations
        "lrt2-recto" to Station(
            "lrt2-recto", "Recto", "Recto", listOf("Isetann"), 14.6038, 120.9831, listOf(LineCode.LRT2),
            exits = listOf(
                StationExit("Isetann Mall", "Isetann Department Store and Supermarket", 1),
                StationExit("LRT-1 Walkway", "Direct elevated walkway to LRT-1 Doroteo Jose Station", 3)
            )
        ),
        "lrt2-legarda" to Station("lrt2-legarda", "Legarda", "Legarda", listOf("Mendiola"), 14.6008, 120.9922, listOf(LineCode.LRT2)),
        "lrt2-pureza" to Station("lrt2-pureza", "Pureza", "Pureza", emptyList(), 14.6015, 121.0053, listOf(LineCode.LRT2)),
        "lrt2-vmapa" to Station("lrt2-vmapa", "V. Mapa", "Mapa", listOf("SM Sta Mesa"), 14.6042, 121.0175, listOf(LineCode.LRT2)),
        "lrt2-jruiz" to Station("lrt2-jruiz", "J. Ruiz", "Ruiz", emptyList(), 14.6106, 121.0261, listOf(LineCode.LRT2)),
        "lrt2-gilmore" to Station(
            "lrt2-gilmore", "Gilmore", "Gilmore", listOf("Computers"), 14.6136, 121.0344, listOf(LineCode.LRT2),
            exits = listOf(
                StationExit("Gilmore IT Center", "Computers, computer parts, electronics stores", 2),
                StationExit("St. Paul", "St. Paul University Quezon City", 3)
            )
        ),
        "lrt2-bettygo" to Station("lrt2-bettygo", "Betty Go-Belmonte", "Betty Go", emptyList(), 14.6186, 121.0425, listOf(LineCode.LRT2)),
        "lrt2-cubao" to Station(
            "lrt2-cubao", "Araneta Center-Cubao", "Cubao", listOf("Gateway Mall"), 14.6225, 121.0525, listOf(LineCode.LRT2),
            exits = listOf(
                StationExit("Gateway Mall Connection", "Direct entry to Gateway Mall Level 3", 1),
                StationExit("South Exit", "Aurora Boulevard, Farmers Plaza, MRT-3 Walkway", 5)
            ),
            facilities = listOf(
                StationFacility(StationFacilityType.ELEVATOR, "Fully operational elevators to platform"),
                StationFacility(StationFacilityType.ESCALATOR, "Dual-direction escalators in main lobby"),
                StationFacility(StationFacilityType.TOILET, "Premium passenger comfort room at concourse")
            )
        ),
        "lrt2-anonas" to Station("lrt2-anonas", "Anonas", "Anonas", emptyList(), 14.6281, 121.0642, listOf(LineCode.LRT2)),
        "lrt2-katipunan" to Station(
            "lrt2-katipunan", "Katipunan", "Katipunan", listOf("UP Diliman", "Ateneo"), 14.6311, 121.0725, listOf(LineCode.LRT2),
            exits = listOf(
                StationExit("North Exit", "Katipunan Jeepney Terminal, Ateneo de Manila", 3),
                StationExit("South Exit", "Miriam College, commercial strips along Katipunan", 3)
            )
        ),
        "lrt2-santolan" to Station("lrt2-santolan", "Santolan", "Santolan", emptyList(), 14.6219, 121.0858, listOf(LineCode.LRT2)),
        "lrt2-marikina" to Station("lrt2-marikina", "Marikina-Pasig", "Marikina", listOf("Robinsons Metro East"), 14.6189, 121.0994, listOf(LineCode.LRT2)),
        "lrt2-antipolo" to Station(
            "lrt2-antipolo", "Antipolo", "Antipolo", listOf("Masinag"), 14.6175, 121.1125, listOf(LineCode.LRT2),
            exits = listOf(
                StationExit("SM Masinag Gate", "Direct pedestrian bridge into SM Masinag Mall", 2),
                StationExit("Marcos Highway North", "Public utility vehicle terminal for Antipolo Proper", 3)
            )
        ),

        // MRT-3 Stations
        "mrt3-north" to Station(
            "mrt3-north", "North Avenue", "North Ave", listOf("SM North", "Trinoma"), 14.6531, 121.0308, listOf(LineCode.MRT3),
            exits = listOf(
                StationExit("Trinoma Mall Gate", "Direct bridge access to Trinoma Second Level", 2),
                StationExit("SM North Pathway", "Walkway crossing North Avenue to SM North EDSA", 5)
            )
        ),
        "mrt3-quezon" to Station("mrt3-quezon", "Quezon Avenue", "Quezon Ave", listOf("Centris"), 14.6425, 121.0378, listOf(LineCode.MRT3)),
        "mrt3-kamuning" to Station("mrt3-kamuning", "GMA-Kamuning", "Kamuning", listOf("GMA"), 14.6353, 121.0433, listOf(LineCode.MRT3)),
        "mrt3-cubao" to Station(
            "mrt3-cubao", "Araneta Center-Cubao", "Cubao", listOf("Farmers Plaza"), 14.6219, 121.0514, listOf(LineCode.MRT3),
            exits = listOf(
                StationExit("Farmers Plaza Concourse", "Farmers Plaza Mall Level 2", 1),
                StationExit("LRT-2 Interchange", "Walkway leading to LRT-2 Araneta Center-Cubao", 6)
            ),
            facilities = listOf(
                StationFacility(StationFacilityType.ATM, "Multiple bank kiosks in retail concourse"),
                StationFacility(StationFacilityType.BIKE_PARKING, "At street level under the station")
            )
        ),
        "mrt3-santolan" to Station("mrt3-santolan", "Santolan-Annapolis", "Santolan", emptyList(), 14.6081, 121.0561, listOf(LineCode.MRT3)),
        "mrt3-ortigas" to Station("mrt3-ortigas", "Ortigas", "Ortigas", listOf("Megamall"), 14.5878, 121.0567, listOf(LineCode.MRT3)),
        "mrt3-shaw" to Station("mrt3-shaw", "Shaw Boulevard", "Shaw", listOf("Shangri-La"), 14.5814, 121.0536, listOf(LineCode.MRT3)),
        "mrt3-boni" to Station("mrt3-boni", "Boni", "Boni", listOf("Light Mall"), 14.5739, 121.0481, listOf(LineCode.MRT3)),
        "mrt3-guadalupe" to Station("mrt3-guadalupe", "Guadalupe", "Guadalupe", listOf("Ferry"), 14.5672, 121.0456, listOf(LineCode.MRT3)),
        "mrt3-buendia" to Station("mrt3-buendia", "Buendia (MRT)", "Buendia", emptyList(), 14.5542, 121.0347, listOf(LineCode.MRT3)),
        "mrt3-ayala" to Station(
            "mrt3-ayala", "Ayala", "Ayala", listOf("Glorietta", "BGC Bus"), 14.5492, 121.0275, listOf(LineCode.MRT3),
            exits = listOf(
                StationExit("SM Makati Bridge", "Direct access to SM Makati department store", 1),
                StationExit("BGC Bus Terminal", "Ayala-McKinley terminal for BGC shuttle buses", 2),
                StationExit("One Ayala", "One Ayala Transit Hub, regional buses and taxis", 3)
            ),
            facilities = listOf(
                StationFacility(StationFacilityType.ELEVATOR, "Full platform accessibility"),
                StationFacility(StationFacilityType.TOILET, "Well-maintained restrooms on lobby level"),
                StationFacility(StationFacilityType.CUSTOMER_SERVICE, "Ticketing and route help counter")
            )
        ),
        "mrt3-magallanes" to Station("mrt3-magallanes", "Magallanes", "Magallanes", emptyList(), 14.5408, 121.0203, listOf(LineCode.MRT3)),
        "mrt3-taft" to Station(
            "mrt3-taft", "Taft Avenue", "Taft", listOf("EDSA"), 14.5378, 121.0022, listOf(LineCode.MRT3),
            exits = listOf(
                StationExit("Metropoint Walkway", "Direct connection to Metropoint Mall and LRT-1", 3),
                StationExit("Taft Southbound", "Jeepney stops for Pasay and Manila South", 3)
            )
        )
    )

    // Discover Manila Destinations
    val discoverDestinations = listOf(
        DiscoverDestination(
            id = "dest-intramuros",
            name = "Intramuros (Walled City)",
            description = "The historic core of Manila, home to Fort Santiago, San Agustin Church, and beautiful Spanish colonial architecture.",
            category = "Culture & Historical",
            nearestStationId = "lrt1-central",
            walkTimeMinutes = 11,
            imageUrl = "intramuros_thumbnail",
            tips = "Take the pedestrian underpass towards Manila High School and follow the signs to Victoria Gate. Excellent for walking tours."
        ),
        DiscoverDestination(
            id = "dest-moa",
            name = "SM Mall of Asia (MOA)",
            description = "One of the largest shopping malls in the world, featuring bayside amusement park, IMAX theater, and convention centers.",
            category = "Malls & Shopping",
            nearestStationId = "lrt1-edsa",
            walkTimeMinutes = 18,
            imageUrl = "moa_thumbnail",
            tips = "Take LRT-1 to EDSA Station or MRT-3 to Taft Avenue. From there, transfer to a yellow jeepney or modern mini-bus outside Metropoint Mall (approx. 5-10 min ride)."
        ),
        DiscoverDestination(
            id = "dest-bgc",
            name = "Bonifacio Global City (BGC)",
            description = "A premier financial and lifestyle district known for its walkable streets, murals, open parks, and high-end dining.",
            category = "Business & Leisure",
            nearestStationId = "mrt3-ayala",
            walkTimeMinutes = 15,
            imageUrl = "bgc_thumbnail",
            tips = "Get off at MRT-3 Ayala Station. Use Exit 2 to go directly to the BGC Bus Terminal. Take the East or West route bus straight into BGC."
        ),
        DiscoverDestination(
            id = "dest-quiapochurch",
            name = "Minor Basilica of the Black Nazarene (Quiapo)",
            description = "A famous Catholic church in Manila housing the miraculous dark statue of Jesus Christ, drawing millions of devotees.",
            category = "Culture & Historical",
            nearestStationId = "lrt1-carriedo",
            walkTimeMinutes = 4,
            imageUrl = "quiapo_thumbnail",
            tips = "Exit LRT-1 Carriedo Station towards Carriedo Street, then walk straight past street vendors for 300 meters directly into Plaza Miranda."
        ),
        DiscoverDestination(
            id = "dest-megamall",
            name = "SM Megamall",
            description = "A massive shopping mall complex in Ortigas Center, housing ice skating rink, fashion boutiques, and local food courts.",
            category = "Malls & Shopping",
            nearestStationId = "mrt3-ortigas",
            walkTimeMinutes = 5,
            imageUrl = "megamall_thumbnail",
            tips = "Use MRT-3 Ortigas Station (south exit) and walk down EDSA, or use MRT-3 Shaw Boulevard Station (north exit). Both lead directly to Megamall."
        ),
        DiscoverDestination(
            id = "dest-updiliman",
            name = "University of the Philippines (UP) Diliman",
            description = "The flagship campus of the national university system, famous for its lush academic oval, sunflowers, and street-food 'isaw'.",
            category = "Universities",
            nearestStationId = "lrt2-katipunan",
            walkTimeMinutes = 12,
            imageUrl = "updiliman_thumbnail",
            tips = "Exit LRT-2 Katipunan (North Exit). Walk to the jeepney terminal under the flyover and ride the UP-Katipunan jeepney line."
        ),
        DiscoverDestination(
            id = "dest-dlsu",
            name = "De La Salle University (DLSU) Manila",
            description = "A prestigious private university located in Taft Avenue, Manila, known for its green and white sporting legacy and academic excellence.",
            category = "Universities",
            nearestStationId = "lrt1-vitocruz",
            walkTimeMinutes = 1,
            imageUrl = "dlsu_thumbnail",
            tips = "Exit LRT-1 Vito Cruz Station. The main campus gate is directly beside the staircase of the northbound platform."
        ),
        DiscoverDestination(
            id = "dest-rizalpark",
            name = "Rizal Park (Luneta)",
            description = "The iconic national park of the Philippines, featuring the monument of Jose Rizal, Chinese/Japanese gardens, and musical fountains.",
            category = "Parks & Outdoors",
            nearestStationId = "lrt1-un",
            walkTimeMinutes = 5,
            imageUrl = "rizalpark_thumbnail",
            tips = "Exit LRT-1 United Nations Station. Head west along United Nations Avenue for one block to reach the park entrance."
        ),
        DiscoverDestination(
            id = "dest-naia",
            name = "Ninoy Aquino International Airport (NAIA)",
            description = "The main international gateway to the Philippines, currently connected via airport shuttle services and taxi handoffs.",
            category = "Airports & Transport",
            nearestStationId = "lrt1-mia",
            walkTimeMinutes = 15,
            imageUrl = "naia_thumbnail",
            tips = "Exit LRT-1 MIA Road Station. Take a taxi, airport shuttle loop, or jeepney along MIA road to reach Terminals 1, 2, or 3."
        )
    )

    // FARE ENGINE DEFINITIONS & DATA
    // LRT-1 and LRT-2 use a boarding fare + distance fare model.
    // MRT-3 uses boarding fare + station fare.
    fun calculateFare(line: LineCode, originId: String, destId: String): Double {
        if (originId == destId) return 0.0

        val lineStations = getStationsForLine(line)
        val oIdx = lineStations.indexOfFirst { it.id == originId }
        val dIdx = lineStations.indexOfFirst { it.id == destId }

        if (oIdx == -1 || dIdx == -1) {
            // Default flat rate fallback if not on same line directly
            return 20.0
        }

        val stopsCount = Math.abs(oIdx - dIdx)

        return when (line) {
            LineCode.LRT1 -> {
                // Official LRT-1: ₱15.00 base + ₱1.00 per station traveled
                15.0 + (stopsCount * 1.0)
            }
            LineCode.LRT2 -> {
                // Official LRT-2: ₱15.00 base + ₱1.20 per station traveled, rounded to nearest peso
                Math.round(15.0 + (stopsCount * 1.2)).toDouble()
            }
            LineCode.MRT3 -> {
                // Official MRT-3: ₱13.00 base + ₱1.00 per station traveled
                13.0 + (stopsCount * 1.0)
            }
            else -> 20.0 // Future subway/MRT-7 projected default
        }
    }

    fun getStationsForLine(line: LineCode): List<Station> {
        return when (line) {
            LineCode.LRT1 -> listOf(
                "lrt1-fpj", "lrt1-balintawak", "lrt1-monumento", "lrt1-5thave", "lrt1-rpapa",
                "lrt1-abadsantos", "lrt1-blumentritt", "lrt1-tayuman", "lrt1-bambang", "lrt1-djose",
                "lrt1-carriedo", "lrt1-central", "lrt1-un", "lrt1-padrefaura", "lrt1-quirino",
                "lrt1-vitocruz", "lrt1-gilpuyat", "lrt1-libertad", "lrt1-edsa", "lrt1-baclaran",
                "lrt1-redemptorist", "lrt1-mia", "lrt1-asiaworld", "lrt1-ninoyaquino", "lrt1-drsantos"
            ).mapNotNull { stations[it] }

            LineCode.LRT2 -> listOf(
                "lrt2-recto", "lrt2-legarda", "lrt2-pureza", "lrt2-vmapa", "lrt2-jruiz",
                "lrt2-gilmore", "lrt2-bettygo", "lrt2-cubao", "lrt2-anonas", "lrt2-katipunan",
                "lrt2-santolan", "lrt2-marikina", "lrt2-antipolo"
            ).mapNotNull { stations[it] }

            LineCode.MRT3 -> listOf(
                "mrt3-north", "mrt3-quezon", "mrt3-kamuning", "mrt3-cubao", "mrt3-santolan",
                "mrt3-ortigas", "mrt3-shaw", "mrt3-boni", "mrt3-guadalupe", "mrt3-buendia",
                "mrt3-ayala", "mrt3-magallanes", "mrt3-taft"
            ).mapNotNull { stations[it] }

            else -> emptyList()
        }
    }

    // MULTIMODAL INTERCHANGE MAP
    // Key: StationId to physical transfers
    // Transfer from Station A to Station B within X minutes
    val interchanges = mapOf(
        "lrt1-djose" to listOf(TransferLink("lrt2-recto", LineCode.LRT2, 5, "Follow the signs to the elevated walkway connecting LRT-1 Doroteo Jose and LRT-2 Recto.")),
        "lrt2-recto" to listOf(TransferLink("lrt1-djose", LineCode.LRT1, 5, "Follow the signs to the elevated walkway connecting LRT-2 Recto and LRT-1 Doroteo Jose.")),
        
        "lrt2-cubao" to listOf(TransferLink("mrt3-cubao", LineCode.MRT3, 6, "Exit LRT-2, walk through Gateway Mall and Farmers Plaza Mall via the covered pedestrian link.")),
        "mrt3-cubao" to listOf(TransferLink("lrt2-cubao", LineCode.LRT2, 6, "Exit MRT-3, walk through Farmers Plaza Mall and Gateway Mall via the covered pedestrian link.")),
        
        "lrt1-edsa" to listOf(TransferLink("mrt3-taft", LineCode.MRT3, 4, "Cross the covered elevated overpass straight to MRT-3 Taft Avenue Station entry.")),
        "mrt3-taft" to listOf(TransferLink("lrt1-edsa", LineCode.LRT1, 4, "Cross the covered elevated overpass straight to LRT-1 EDSA Station entry."))
    )

    data class TransferLink(
        val targetStationId: String,
        val targetLine: LineCode,
        val durationMinutes: Int,
        val instructions: String
    )

    // GRAPH ROUTING ENGINE
    // Standard Dijkstra finding shortest-path on multi-line rail model.
    // Vertices are State Node: (StationId, LineCode)
    data class PathNode(
        val stationId: String,
        val line: LineCode
    )

    data class QueueState(
        val node: PathNode,
        val cost: Double, // time in minutes
        val parent: QueueState?,
        val walkDistance: Int,
        val fare: Double,
        val transferCostAdded: Double = 0.0
    ) : Comparable<QueueState> {
        override fun compareTo(other: QueueState): Int = this.cost.compareTo(other.cost)
    }

    fun planRoute(
        originStationId: String,
        destStationId: String,
        preference: RoutePreference = RoutePreference.FASTEST
    ): RouteResult? {
        val startStation = stations[originStationId] ?: return null
        val endStation = stations[destStationId] ?: return null

        if (originStationId == destStationId) {
            return RouteResult(
                legs = listOf(JourneyLeg.WalkLeg(startStation.name, endStation.name, 0, 0, listOf("You are already at your destination."))),
                totalDurationMinutes = 0,
                totalFare = 0.0,
                totalWalkDistanceMeters = 0,
                transferCount = 0
            )
        }

        val queue = PriorityQueue<QueueState>()
        val visited = mutableSetOf<PathNode>()

        // Initialize queue with starting stations on all lines passing through origin
        for (line in startStation.lines) {
            queue.add(QueueState(PathNode(originStationId, line), 0.0, null, 0, 0.0))
        }

        var destinationState: QueueState? = null

        while (queue.isNotEmpty()) {
            val current = queue.poll()

            if (current.node.stationId == destStationId) {
                destinationState = current
                break
            }

            if (!visited.add(current.node)) continue

            val currentStationId = current.node.stationId
            val currentLine = current.node.line
            val currentStation = stations[currentStationId] ?: continue

            // 1. Traverse within the current line (adjacent stations)
            val lineStations = getStationsForLine(currentLine)
            val index = lineStations.indexOfFirst { it.id == currentStationId }

            if (index != -1) {
                // Move Backwards
                if (index > 0) {
                    val prevStation = lineStations[index - 1]
                    val edgeDuration = 2.0 // average 2 minutes per station stop
                    val fare = calculateFare(currentLine, originStationId, prevStation.id) // simplistic fare accumulation
                    queue.add(
                        QueueState(
                            node = PathNode(prevStation.id, currentLine),
                            cost = current.cost + edgeDuration,
                            parent = current,
                            walkDistance = current.walkDistance,
                            fare = fare
                        )
                    )
                }
                // Move Forwards
                if (index < lineStations.size - 1) {
                    val nextStation = lineStations[index + 1]
                    val edgeDuration = 2.0
                    val fare = calculateFare(currentLine, originStationId, nextStation.id)
                    queue.add(
                        QueueState(
                            node = PathNode(nextStation.id, currentLine),
                            cost = current.cost + edgeDuration,
                            parent = current,
                            walkDistance = current.walkDistance,
                            fare = fare
                        )
                    )
                }
            }

            // 2. Traverse physical transfer walking connections
            val transfers = interchanges[currentStationId] ?: emptyList()
            for (transfer in transfers) {
                val transferNode = PathNode(transfer.targetStationId, transfer.targetLine)
                if (transferNode !in visited) {
                    val penalty = when (preference) {
                        RoutePreference.FEWEST_TRANSFERS -> 15.0 // heavy penalty to discourage transfer
                        else -> 0.0
                    }
                    queue.add(
                        QueueState(
                            node = transferNode,
                            cost = current.cost + transfer.durationMinutes + penalty,
                            parent = current,
                            walkDistance = current.walkDistance + (transfer.durationMinutes * 60), // assume 60m/min
                            fare = current.fare, // Fare is added when entering new line leg
                            transferCostAdded = transfer.durationMinutes.toDouble()
                        )
                    )
                }
            }
        }

        if (destinationState == null) return null

        // Reconstruct the path backwards
        val statesList = mutableListOf<QueueState>()
        var curr: QueueState? = destinationState
        while (curr != null) {
            statesList.add(0, curr)
            curr = curr.parent
        }

        // Convert QueueStates into printable JourneyLegs
        val legs = mutableListOf<JourneyLeg>()
        var i = 0
        var totalFare = 0.0
        var totalWalkMeters = 0
        var transferCount = 0

        while (i < statesList.size) {
            val state = statesList[i]
            val fromNode = state.node

            // If we have a sequence on the same line, gather them into a single RailLeg
            if (i < statesList.size - 1 && statesList[i + 1].node.line == fromNode.line && statesList[i + 1].node.stationId != fromNode.stationId) {
                val lineCode = fromNode.line
                val startRailIdx = i
                val startStationId = fromNode.stationId

                // Find how far we can go on this same line
                while (i < statesList.size - 1 && statesList[i + 1].node.line == lineCode && statesList[i + 1].node.stationId != statesList[i].node.stationId) {
                    i++
                }

                val endStationId = statesList[i].node.stationId
                val railStationsPassed = mutableListOf<String>()
                for (k in (startRailIdx + 1)..i) {
                    railStationsPassed.add(statesList[k].node.stationId)
                }

                val fare = calculateFare(lineCode, startStationId, endStationId)
                totalFare += fare

                val lineStations = getStationsForLine(lineCode)
                val sIdx = lineStations.indexOfFirst { it.id == startStationId }
                val eIdx = lineStations.indexOfFirst { it.id == endStationId }
                val direction = if (eIdx > sIdx) {
                    if (lineCode == LineCode.LRT2) "Eastbound (Antipolo)" else if (lineCode == LineCode.MRT3) "Southbound (Taft)" else "Southbound (Dr. Santos)"
                } else {
                    if (lineCode == LineCode.LRT2) "Westbound (Recto)" else if (lineCode == LineCode.MRT3) "Northbound (North Ave)" else "Northbound (FPJ)"
                }

                legs.add(
                    JourneyLeg.RailLeg(
                        lineCode = lineCode,
                        originStationId = startStationId,
                        destinationStationId = endStationId,
                        intermediateStations = railStationsPassed.dropLast(1),
                        durationMinutes = ((i - startRailIdx) * 2),
                        fare = fare,
                        direction = direction
                    )
                )
            } else if (i < statesList.size - 1 && statesList[i + 1].node.stationId == fromNode.stationId && statesList[i + 1].node.line != fromNode.line) {
                // This is a direct transfer at an interchange hub
                val nextNode = statesList[i + 1].node
                val transferDetails = interchanges[fromNode.stationId]?.find { it.targetStationId == nextNode.stationId && it.targetLine == nextNode.line }
                val transferTime = transferDetails?.durationMinutes ?: 5
                val transferInstr = transferDetails?.instructions ?: "Change lines at the station."

                legs.add(
                    JourneyLeg.TransferLeg(
                        fromLine = fromNode.line,
                        toLine = nextNode.line,
                        stationId = fromNode.stationId,
                        durationMinutes = transferTime,
                        instructions = transferInstr
                    )
                )
                totalWalkMeters += (transferTime * 65)
                transferCount++
                i++ // consume the transfer transition
            } else if (i < statesList.size - 1 && statesList[i + 1].node.stationId != fromNode.stationId && statesList[i + 1].node.line != fromNode.line) {
                // Walking physical interchange walk leg (e.g. D. Jose to Recto)
                val nextNode = statesList[i + 1].node
                val transferDetails = interchanges[fromNode.stationId]?.find { it.targetStationId == nextNode.stationId && it.targetLine == nextNode.line }
                val transferTime = transferDetails?.durationMinutes ?: 6
                val transferInstr = transferDetails?.instructions ?: "Change lines."

                legs.add(
                    JourneyLeg.TransferLeg(
                        fromLine = fromNode.line,
                        toLine = nextNode.line,
                        stationId = fromNode.stationId,
                        durationMinutes = transferTime,
                        instructions = transferInstr
                    )
                )
                totalWalkMeters += (transferTime * 65)
                transferCount++
                i++
            } else {
                i++
            }
        }

        // Calculate actual total duration
        val totalDur = legs.sumOf {
            when (it) {
                is JourneyLeg.WalkLeg -> it.durationMinutes
                is JourneyLeg.RailLeg -> it.durationMinutes
                is JourneyLeg.TransferLeg -> it.durationMinutes
            }
        }

        return RouteResult(
            legs = legs,
            totalDurationMinutes = totalDur,
            totalFare = totalFare,
            totalWalkDistanceMeters = totalWalkMeters,
            transferCount = transferCount
        )
    }
}
