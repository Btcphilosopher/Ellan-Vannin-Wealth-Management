package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette (Warm Tropical Off-White & Concrete Deep Blue)
val PrimaryBlue = Color(0xFF112233)
val SecondaryGold = Color(0xFFC0A060)
val BackgroundLight = Color(0xFFF9F7F5)
val SurfaceLight = Color(0xFFFFFFFF)
val OnPrimaryLight = Color(0xFFFFFFFF)
val OnSecondaryLight = Color(0xFF112233)
val OnBackgroundLight = Color(0xFF1E2022)
val OnSurfaceLight = Color(0xFF1E2022)
val AccentOrange = Color(0xFFE05A47)

// Dark Theme Palette (Metropolitan Concrete Slate & Graphite)
val PrimaryBlueDark = Color(0xFF90A4AE)
val SecondaryGoldDark = Color(0xFFE5C158)
val BackgroundDark = Color(0xFF121416)
val SurfaceDark = Color(0xFF1E2225)
val OnPrimaryDark = Color(0xFF121416)
val OnSecondaryDark = Color(0xFF121416)
val OnBackgroundDark = Color(0xFFECEFF1)
val OnSurfaceDark = Color(0xFFECEFF1)
val BorderDark = Color(0xFF2C3238)
val BorderLight = Color(0xFFE0E5EA)
