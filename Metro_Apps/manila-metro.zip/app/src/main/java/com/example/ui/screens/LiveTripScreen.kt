package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.ActiveScreen
import com.example.ui.ManilaMetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveTripScreen(
    viewModel: ManilaMetroViewModel,
    modifier: Modifier = Modifier
) {
    val isEnglish by viewModel.isEnglish.collectAsState()
    val activeTripRoute by viewModel.activeTripRoute.collectAsState()
    val activeStationIndex by viewModel.activeTripStationIndex.collectAsState()
    val remainingMinutes by viewModel.activeTripRemainingMinutes.collectAsState()
    val tripAlertTriggered by viewModel.tripAlertTriggered.collectAsState()
    val alertBeforeStop by viewModel.alertBeforeStop.collectAsState()
    val completed by viewModel.activeTripCompleted.collectAsState()

    // Gather all station records along the rail legs
    val stationsList = remember(activeTripRoute) {
        val list = mutableListOf<Station>()
        activeTripRoute?.legs?.filterIsInstance<JourneyLeg.RailLeg>()?.forEach { leg ->
            list.add(TransitData.stations[leg.originStationId]!!)
            leg.intermediateStations.forEach { sId ->
                list.add(TransitData.stations[sId]!!)
            }
            list.add(TransitData.stations[leg.destinationStationId]!!)
        }
        list.distinct()
    }

    val currentStation = stationsList.getOrNull(activeStationIndex)
    val nextStation = stationsList.getOrNull(activeStationIndex + 1)
    val finalStation = stationsList.lastOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Red flashing simulated warning header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (completed) Color(0xFF4CAF50) else Color(0xFFE05A47))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (completed) Icons.Default.CheckCircle else Icons.Default.DirectionsTransit,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (completed) (if (isEnglish) "ARRIVED!" else "NAKATINGIN!") else (if (isEnglish) "LIVE NAVIGATION ACTIVE" else "NAKA-NAVIGATE"),
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (completed) (if (isEnglish) "Tap out to finish" else "I-tap out para tapusin")
                                   else "${stationsList.size - 1 - activeStationIndex} ${viewModel.getString("stops_remaining")}",
                            color = Color.White.copy(alpha = 0.8f),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                // Close / Cancel simulator
                IconButton(
                    onClick = {
                        viewModel.stopTripSimulation()
                        viewModel.setScreen(ActiveScreen.PLANNER)
                    }
                ) {
                    Icon(Icons.Default.Close, contentDescription = "End Trip", tint = Color.White)
                }
            }
        }

        // Expanded Alarm Trigger Box Alert
        AnimatedVisibility(
            visible = tripAlertTriggered != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            tripAlertTriggered?.let { alertMsg ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.errorContainer)
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Alert Triggered",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = alertMsg,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Immersive Countdown card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (isEnglish) "ESTIMATED REMAINING TIME" else "GAYAK NA ORAS",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (completed) "0 mins" else "$remainingMinutes mins",
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Black,
                            color = if (completed) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Current Station", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text(
                                    text = currentStation?.name ?: "N/A",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color.LightGray)
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Next Station", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text(
                                    text = if (completed) "Arrived" else (nextStation?.name ?: "Terminus"),
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }

            // User alarm settings
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = viewModel.getString("alert_me_before"),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(1, 2, 3).forEach { stops ->
                                val isSelected = alertBeforeStop == stops
                                Button(
                                    onClick = { viewModel.setAlertBeforeStop(stops) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "$stops ${if (stops == 1) viewModel.getString("stop") else viewModel.getString("stops")}",
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Timeline Sequence Tracker list
            item {
                Text(
                    text = "STATION TRACKER TIMELINE",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            items(stationsList.size) { idx ->
                val station = stationsList[idx]
                val isPassed = idx < activeStationIndex
                val isCurrent = idx == activeStationIndex
                val isUpcoming = idx > activeStationIndex

                val trackerColor = when {
                    isCurrent -> MaterialTheme.colorScheme.secondary
                    isPassed -> Color.LightGray
                    else -> MaterialTheme.colorScheme.primary
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Timeline Dot
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(trackerColor),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isPassed) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        } else if (isCurrent) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Station Name
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = station.name,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.SemiBold,
                            fontSize = if (isCurrent) 16.sp else 14.sp,
                            color = if (isPassed) Color.Gray else MaterialTheme.colorScheme.onSurface
                        )
                        if (isCurrent) {
                            Text(
                                text = "Train currently docked at platform",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.Bold
                            )
                        } else if (idx == stationsList.size - 1) {
                            Text(
                                text = "Destination Terminal",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}
