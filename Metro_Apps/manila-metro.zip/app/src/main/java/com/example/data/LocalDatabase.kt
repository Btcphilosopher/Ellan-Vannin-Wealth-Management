package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "saved_places")
data class SavedPlaceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String, // Home, Work, School, or Other
    val customName: String, // e.g. "My Office in Makati"
    val stationId: String, // Nearest Station ID
    val address: String
)

@Entity(tableName = "saved_journeys")
data class SavedJourneyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, // e.g. "Morning Commute"
    val originStationId: String,
    val destinationStationId: String,
    val departureTime: String, // e.g. "07:15 AM"
    val daysOfWeek: String // Comma separated e.g. "Mon,Tue,Wed,Thu,Fri"
)

@Entity(tableName = "search_history")
data class SearchHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val query: String,
    val timestamp: Long
)

@Entity(tableName = "transit_cards")
data class TransitCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardType: String, // BEEP, VISA, MASTERCARD, PAYMAYA, GCASH
    val cardNo: String, // Masked or full number, e.g. "1201-9876-5432-1100"
    val balance: Double,
    val label: String, // e.g. "Daily Commute Beep"
    val isDefault: Boolean = false,
    val lastUsedStationId: String = ""
)

@Dao
interface SavedPlaceDao {
    @Query("SELECT * FROM saved_places ORDER BY id DESC")
    fun getAllSavedPlaces(): Flow<List<SavedPlaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedPlace(place: SavedPlaceEntity)

    @Delete
    suspend fun deleteSavedPlace(place: SavedPlaceEntity)
}

@Dao
interface SavedJourneyDao {
    @Query("SELECT * FROM saved_journeys ORDER BY id DESC")
    fun getAllSavedJourneys(): Flow<List<SavedJourneyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedJourney(journey: SavedJourneyEntity)

    @Delete
    suspend fun deleteSavedJourney(journey: SavedJourneyEntity)
}

@Dao
interface SearchHistoryDao {
    @Query("SELECT * FROM search_history ORDER BY timestamp DESC LIMIT 10")
    fun getRecentHistory(): Flow<List<SearchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(item: SearchHistoryEntity)

    @Query("DELETE FROM search_history")
    suspend fun clearHistory()
}

@Dao
interface TransitCardDao {
    @Query("SELECT * FROM transit_cards ORDER BY id DESC")
    fun getAllCards(): Flow<List<TransitCardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCard(card: TransitCardEntity)

    @Update
    suspend fun updateCard(card: TransitCardEntity)

    @Delete
    suspend fun deleteCard(card: TransitCardEntity)

    @Query("UPDATE transit_cards SET isDefault = 0")
    suspend fun clearDefaults()

    @Transaction
    suspend fun setDefaultCard(cardId: Long) {
        clearDefaults()
        // Simple manual implementation as we might not have a direct set default query
    }
}

@Database(
    entities = [
        SavedPlaceEntity::class,
        SavedJourneyEntity::class,
        SearchHistoryEntity::class,
        TransitCardEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ManilaMetroDatabase : RoomDatabase() {
    abstract fun savedPlaceDao(): SavedPlaceDao
    abstract fun savedJourneyDao(): SavedJourneyDao
    abstract fun searchHistoryDao(): SearchHistoryDao
    abstract fun transitCardDao(): TransitCardDao

    companion object {
        @Volatile
        private var INSTANCE: ManilaMetroDatabase? = null

        fun getDatabase(context: Context): ManilaMetroDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ManilaMetroDatabase::class.java,
                    "manila_metro_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
