package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// A polished, high-contrast dark theme is perfect for a transport application
// used in various lighting conditions (underground platforms, direct sunlight).
private val MetroDarkColorScheme = darkColorScheme(
    primary = MetroYellow,
    onPrimary = MetroOnYellow,
    primaryContainer = MetroSurfaceVariant,
    onPrimaryContainer = Color.White,
    secondary = MetroSurface,
    onSecondary = Color.White,
    secondaryContainer = MetroSurfaceVariant,
    onSecondaryContainer = MetroTextSecondary,
    tertiary = ColorRail,
    onTertiary = Color.White,
    background = MetroDarkBackground,
    onBackground = MetroTextPrimary,
    surface = MetroSurface,
    onSurface = MetroTextPrimary,
    surfaceVariant = MetroSurfaceVariant,
    onSurfaceVariant = MetroTextSecondary,
    outline = MetroBorder,
    error = ColorAlert,
    onError = Color.White
)

// Standard light color scheme for compatibility, keeping yellow brand accents
private val MetroLightColorScheme = lightColorScheme(
    primary = MetroYellow,
    onPrimary = MetroOnYellow,
    primaryContainer = Color(0xFFFFF4CC),
    onPrimaryContainer = Color(0xFF4A3A00),
    secondary = Color(0xFFEFEFEF),
    onSecondary = Color(0xFF121212),
    secondaryContainer = Color(0xFFF5F5F5),
    onSecondaryContainer = Color(0xFF121212),
    tertiary = ColorRail,
    onTertiary = Color.White,
    background = Color.White,
    onBackground = Color(0xFF121212),
    surface = Color(0xFFF9F9F9),
    onSurface = Color(0xFF121212),
    surfaceVariant = Color(0xFFE0E0E0),
    onSurfaceVariant = Color(0xFF333333),
    outline = Color(0xFFCCCCCC),
    error = ColorAlert,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // We disable dynamic color by default to maintain the strong, distinctive Metro Yellow/Black brand identity
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) MetroDarkColorScheme else MetroLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
