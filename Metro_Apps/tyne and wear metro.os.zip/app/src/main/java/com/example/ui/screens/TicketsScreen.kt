package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransportData
import com.example.model.DigitalTicket
import com.example.model.TicketType
import com.example.ui.theme.*
import com.example.viewmodel.TransportViewModel

@Composable
fun TicketsScreen(viewModel: TransportViewModel) {
    val wallet by viewModel.ticketWallet.collectAsState()
    val popCard by viewModel.popCard.collectAsState()

    var showBuyDialog by remember { mutableStateOf(false) }
    var selectedTicketType by remember { mutableStateOf(TicketType.DAY_TICKET) }
    var selectedPassengerType by remember { mutableStateOf("ADULT") }

    var activeViewTicket by remember { mutableStateOf<DigitalTicket?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- TOP NAVIGATION HEADER ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MetroSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PASSENGER WALLET",
                            style = MaterialTheme.typography.labelMedium,
                            color = MetroYellow
                        )
                        Text(
                            text = "My Digital Tickets",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Button(
                        onClick = { showBuyDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MetroYellow, contentColor = MetroOnYellow),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("buy_new_ticket_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("BUY")
                    }
                }
            }
        }

        // --- TICKETS WALLET LIST ---
        if (wallet.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No tickets purchased yet. Tap BUY to purchase a transit pass.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MetroTextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(wallet) { ticket ->
                    TicketCard(ticket = ticket, onOpenTicket = { activeViewTicket = ticket })
                }
            }
        }
    }

    // --- PURCHASE SHEET DIALOG ---
    if (showBuyDialog) {
        AlertDialog(
            onDismissRequest = { showBuyDialog = false },
            confirmButton = {
                val calculatedPrice = TransportData.calculateFarePence("central", "tynemouth", selectedTicketType, selectedPassengerType)
                TextButton(
                    onClick = {
                        viewModel.buyTicket(selectedTicketType, selectedPassengerType)
                        showBuyDialog = false
                    },
                    modifier = Modifier.testTag("confirm_ticket_purchase_btn")
                ) {
                    Text("Pay ${TransportData.formatPence(calculatedPrice)}", color = MetroYellow, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBuyDialog = false }) {
                    Text("Cancel", color = MetroTextSecondary)
                }
            },
            title = {
                Text("Select Transit Product", style = MaterialTheme.typography.headlineMedium, color = Color.White)
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Ticket Category
                    Column {
                        Text("PRODUCT TYPE", style = MaterialTheme.typography.labelMedium, color = MetroYellow)
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        TicketType.values().filter { it != TicketType.POP_PAYG }.forEach { type ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (selectedTicketType == type) MetroSurfaceVariant else Color.Transparent)
                                    .clickable { selectedTicketType = type }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(type.label, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                Text(TransportData.formatPence(type.basePricePence), style = MaterialTheme.typography.bodyMedium, color = MetroTextSecondary)
                            }
                        }
                    }

                    // Passenger Class Choice
                    Column {
                        Text("PASSENGER CATEGORY", style = MaterialTheme.typography.labelMedium, color = MetroYellow)
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("ADULT", "YOUTH", "CONCESSION").forEach { cat ->
                                val selected = selectedPassengerType == cat
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (selected) MetroYellow else MetroSurfaceVariant)
                                        .clickable { selectedPassengerType = cat }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = cat,
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = if (selected) MetroOnYellow else Color.White
                                    )
                                }
                            }
                        }
                    }

                    // Balance Quick Warn
                    val price = TransportData.calculateFarePence("central", "tynemouth", selectedTicketType, selectedPassengerType)
                    if (popCard.balancePence < price) {
                        Text(
                            text = "Insufficient Pop Balance. We will process this via your registered debit/credit card.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MetroTextSecondary
                        )
                    } else {
                        Text(
                            text = "Payment will be automatically deducted from your Pop Balance (${TransportData.formatPence(popCard.balancePence)}).",
                            style = MaterialTheme.typography.bodySmall,
                            color = ColorGoodService
                        )
                    }
                }
            },
            containerColor = MetroSurface
        )
    }

    // --- VIEW HIGH QUALITY TICKET CODE DIALOG ---
    activeViewTicket?.let { ticket ->
        AlertDialog(
            onDismissRequest = { activeViewTicket = null },
            confirmButton = {
                TextButton(onClick = { activeViewTicket = null }) {
                    Text("Close", color = MetroYellow, fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Text(
                    text = ticket.type.label.uppercase(),
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = MetroYellow,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // QR CODE PLACEHOLDER
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Drawing a beautiful synthetic QR Code pattern using Compose Canvas
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            val steps = 8
                            val stepX = w / steps
                            val stepY = h / steps

                            // Draw QR corners
                            drawRect(color = Color.Black, topLeft = Offset(0f, 0f), size = androidx.compose.ui.geometry.Size(stepX * 2, stepY * 2))
                            drawRect(color = Color.White, topLeft = Offset(4f, 4f), size = androidx.compose.ui.geometry.Size(stepX * 2 - 8, stepY * 2 - 8))
                            drawRect(color = Color.Black, topLeft = Offset(8f, 8f), size = androidx.compose.ui.geometry.Size(stepX * 2 - 16, stepY * 2 - 16))

                            drawRect(color = Color.Black, topLeft = Offset(w - stepX * 2, 0f), size = androidx.compose.ui.geometry.Size(stepX * 2, stepY * 2))
                            drawRect(color = Color.White, topLeft = Offset(w - stepX * 2 + 4, 4f), size = androidx.compose.ui.geometry.Size(stepX * 2 - 8, stepY * 2 - 8))
                            drawRect(color = Color.Black, topLeft = Offset(w - stepX * 2 + 8, 8f), size = androidx.compose.ui.geometry.Size(stepX * 2 - 16, stepY * 2 - 16))

                            drawRect(color = Color.Black, topLeft = Offset(0f, h - stepY * 2), size = androidx.compose.ui.geometry.Size(stepX * 2, stepY * 2))
                            drawRect(color = Color.White, topLeft = Offset(4f, h - stepY * 2 + 4), size = androidx.compose.ui.geometry.Size(stepX * 2 - 8, stepY * 2 - 8))
                            drawRect(color = Color.Black, topLeft = Offset(8f, h - stepY * 2 + 8), size = androidx.compose.ui.geometry.Size(stepX * 2 - 16, stepY * 2 - 16))

                            // Draw central random dots to make it look highly authentic
                            for (x in 2 until steps - 2) {
                                for (y in 2 until steps - 2) {
                                    if ((x + y) % 3 == 0 || (x * y) % 5 == 1) {
                                        drawRect(
                                            color = Color.Black,
                                            topLeft = Offset(x * stepX, y * stepY),
                                            size = androidx.compose.ui.geometry.Size(stepX, stepY)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Text(
                        text = ticket.id,
                        style = MaterialTheme.typography.labelLarge,
                        color = MetroTextSecondary
                    )

                    // Ticket details summary
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MetroSurfaceVariant)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("VALIDITY", style = MaterialTheme.typography.bodySmall, color = MetroTextSecondary)
                            Text(ticket.validityState, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = ColorGoodService)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ZONES", style = MaterialTheme.typography.bodySmall, color = MetroTextSecondary)
                            Text(ticket.zones, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("PASSENGER", style = MaterialTheme.typography.bodySmall, color = MetroTextSecondary)
                            Text(ticket.passengerType, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("EXPIRES", style = MaterialTheme.typography.bodySmall, color = MetroTextSecondary)
                            Text(ticket.expiryDate, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                        }
                    }
                }
            },
            containerColor = MetroSurface
        )
    }
}

@Composable
fun TicketCard(ticket: DigitalTicket, onOpenTicket: () -> Unit) {
    val isValid = ticket.validityState == "VALID"
    val color = if (isValid) MetroYellow else MetroTextMuted

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenTicket() }
            .testTag("digital_ticket_item_${ticket.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MetroSurface),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Category & State
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        imageVector = Icons.Default.ConfirmationNumber,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = ticket.type.label.uppercase(),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Text(
                            text = ticket.id,
                            style = MaterialTheme.typography.labelSmall,
                            color = MetroTextSecondary
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isValid) ColorGoodService.copy(alpha = 0.2f) else MetroBorder)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = ticket.validityState,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isValid) ColorGoodService else MetroTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tear line representation using dashed line
            Canvas(modifier = Modifier.fillMaxWidth().height(1.dp)) {
                drawLine(
                    color = MetroBorder,
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Details body
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("PASSENGER", style = MaterialTheme.typography.labelSmall, color = MetroTextMuted)
                    Text(ticket.passengerType, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("COVERAGE", style = MaterialTheme.typography.labelSmall, color = MetroTextMuted)
                    Text(ticket.zones, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("EXPIRY", style = MaterialTheme.typography.labelSmall, color = MetroTextMuted)
                    Text(ticket.expiryDate, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tap to show Ticket Barcode / QR Code",
                    style = MaterialTheme.typography.labelSmall,
                    color = color
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(Icons.Default.QrCode, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            }
        }
    }
}
