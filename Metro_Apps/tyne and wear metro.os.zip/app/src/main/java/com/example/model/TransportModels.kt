package com.example.model

import java.util.UUID

enum class TransportMode(val label: String) {
    METRO("Metro"),
    BUS("Bus"),
    RAIL("Rail"),
    FERRY("Ferry"),
    WALK("Walk"),
    CYCLE("Cycle"),
    AIRPORT("Airport"),
    FUTURE("Planned Metro")
}

data class Station(
    val id: String,
    val name: String,
    val code: String,
    val lines: List<String>,
    val modes: List<TransportMode>,
    val isInterchange: Boolean = false,
    val hasLifts: Boolean = true,
    val hasToilets: Boolean = false,
    val hasParking: Boolean = false,
    val parkingCapacity: Int = 0,
    val hasCycleHub: Boolean = false,
    val isPlanned: Boolean = false,
    val artwork: List<MetroArtwork> = emptyList(),
    val facilities: List<String> = emptyList(),
    val latitude: Double,
    val longitude: Double
)

data class MetroArtwork(
    val title: String,
    val artist: String,
    val year: String,
    val description: String
)

data class TransportLine(
    val id: String,
    val name: String,
    val mode: TransportMode,
    val colorHex: String,
    val stations: List<String>, // List of station IDs in order
    val isPlanned: Boolean = false
)

data class Vehicle(
    val id: String,
    val serviceLineId: String,
    val currentStationId: String,
    val nextStationId: String?,
    val destinationStationId: String,
    val positionOffsetPercent: Float, // 0.0 to 1.0 between current and next
    val delayMinutes: Int = 0,
    val mode: TransportMode = TransportMode.METRO,
    val capacityPercent: Int, // e.g. 45% full
    val hasUsbCharging: Boolean = true,
    val hasClimateControl: Boolean = true,
    val isStepFreeBoarding: Boolean = true
)

data class RouteSegment(
    val mode: TransportMode,
    val lineId: String?,
    val lineName: String?,
    val fromStationId: String,
    val fromStationName: String,
    val toStationId: String,
    val toStationName: String,
    val durationMinutes: Int,
    val stopCount: Int = 0,
    val intermediateStations: List<String> = emptyList(),
    val vehicleId: String? = null,
    val instruction: String
)

data class Journey(
    val id: String = UUID.randomUUID().toString(),
    val segments: List<RouteSegment>,
    val startTime: String, // e.g. "14:42"
    val endTime: String, // e.g. "15:13"
    val totalDurationMinutes: Int,
    val totalFarePence: Int, // represented as integer pence to avoid float errors
    val carbonKgEstimate: Double,
    val isDisrupted: Boolean = false,
    val disruptionMessage: String? = null,
    val alternativeJourneyId: String? = null
)

enum class TicketType(val label: String, val basePricePence: Int) {
    SINGLE("Single Ticket", 240),
    RETURN("Return Ticket", 430),
    DAY_TICKET("Day Ticket", 530),
    WEEKLY_PASS("Weekly Pass", 2400),
    SEASON_PASS("Season Pass", 8500),
    CONCESSIONARY("Concession Day", 120),
    POP_PAYG("Pop PAYG Fare", 220)
}

data class DigitalTicket(
    val id: String = "TCK-${UUID.randomUUID().toString().take(6).uppercase()}",
    val type: TicketType,
    val passengerType: String = "ADULT", // ADULT, YOUTH, CONCESSION
    val zones: String = "All Zones (A+B+C)",
    val purchaseDate: String,
    val expiryDate: String,
    val validityState: String = "VALID", // VALID, EXPIRED, USED
    val qrCodePayload: String = "METRO.OS-${UUID.randomUUID()}"
)

data class PopCard(
    val cardNumber: String = "9826 3020 4821 9402",
    val balancePence: Int = 1840,
    val paygEnabled: Boolean = true,
    val recentTransactions: List<PopTransaction> = emptyList()
)

data class PopTransaction(
    val id: String = UUID.randomUUID().toString().take(8),
    val timestamp: String,
    val description: String,
    val amountPence: Int, // negative for fares, positive for top-ups
    val type: String // "TAP_IN", "TAP_OUT", "TOP_UP", "FARE"
)

data class Disruption(
    val id: String,
    val affectedLineId: String,
    val title: String,
    val description: String,
    val delayMinutes: Int,
    val isSuspended: Boolean = false
)

data class ParkingFacility(
    val stationId: String,
    val stationName: String,
    val totalSpaces: Int,
    val availableSpaces: Int,
    val hasEvCharging: Boolean,
    val dailyRatePence: Int
)
