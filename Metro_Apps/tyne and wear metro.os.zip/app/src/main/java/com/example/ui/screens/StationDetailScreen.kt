package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransportData
import com.example.model.TransportMode
import com.example.ui.theme.*
import com.example.viewmodel.TransportViewModel

@Composable
fun StationDetailScreen(viewModel: TransportViewModel) {
    val stationId by viewModel.selectedStationId.collectAsState()
    val detailState by viewModel.stationDetailState.collectAsState()

    val station = TransportData.stations[stationId] ?: return

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- HEADER STATION HERO ---
        item {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(MetroYellow)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = station.code,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MetroOnYellow
                        )
                    }
                    Text(
                        text = "METRO STATION HUB",
                        style = MaterialTheme.typography.labelMedium,
                        color = MetroYellow
                    )
                }

                Text(
                    text = station.name,
                    style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Black),
                    modifier = Modifier.testTag("station_hero_name")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Mode Badges
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    station.modes.forEach { mode ->
                        val color = when (mode) {
                            TransportMode.METRO -> ColorMetro
                            TransportMode.RAIL -> ColorRail
                            TransportMode.BUS -> ColorBus
                            TransportMode.FERRY -> ColorFerry
                            else -> ColorWalk
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(color.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = mode.label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
                        }
                    }
                }
            }
        }

        // --- DEPARTURE BOARD ---
        item {
            Text(
                text = "LIVE DEPARTURE BOARD",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = MetroTextSecondary
            )
        }

        if (detailState.departures.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MetroSurface)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No trains currently scheduled. Timetable normal.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MetroTextSecondary
                        )
                    }
                }
            }
        } else {
            items(detailState.departures) { vehicle ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MetroSurface)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(if (vehicle.serviceLineId == "yellow") MetroYellow else ColorRail, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.DirectionsTransit,
                                contentDescription = null,
                                tint = if (vehicle.serviceLineId == "yellow") MetroOnYellow else Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Column {
                            val destName = TransportData.stations[vehicle.destinationStationId]?.name ?: vehicle.destinationStationId
                            Text(
                                text = "To $destName",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${vehicle.serviceLineId.uppercase()} LINE • Train ${vehicle.id}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MetroTextSecondary
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (vehicle.delayMinutes > 0) "Due +${vehicle.delayMinutes}m" else "Due Now",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, color = MetroYellow)
                        )
                        Text(
                            text = "Platform 1",
                            style = MaterialTheme.typography.bodySmall,
                            color = MetroTextSecondary
                        )
                    }
                }
            }
        }

        // --- METRO ART LAYER ---
        if (station.artwork.isNotEmpty()) {
            item {
                Text(
                    text = "METRO ART HERITAGE",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                    color = MetroYellow
                )
            }

            items(station.artwork) { art ->
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("metro_art_card_${art.title.lowercase().replace(" ", "_")}"),
                    colors = CardDefaults.cardColors(containerColor = MetroSurface),
                    border = BorderStroke(1.dp, MetroYellow.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = art.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Text(
                                    text = "${art.artist} • ${art.year}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MetroYellow
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = "Artwork",
                                tint = MetroYellow,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = art.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MetroTextSecondary
                        )
                    }
                }
            }
        }

        // --- STATION FACILITIES ---
        item {
            Text(
                text = "STATION FACILITIES",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = MetroTextSecondary
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MetroSurface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    station.facilities.forEach { facility ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = ColorGoodService,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(text = facility, style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    // Standard checks
                    FacilityRow(label = "Step-Free Level Access", available = station.hasLifts)
                    FacilityRow(label = "Passenger Toilets", available = station.hasToilets)
                    FacilityRow(label = "Secure Cycle Hub", available = station.hasCycleHub)
                    FacilityRow(label = "Park & Ride Parking", available = station.hasParking)
                }
            }
        }
    }
}

@Composable
fun FacilityRow(label: String, available: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = if (available) Icons.Default.CheckCircle else Icons.Default.Cancel,
            contentDescription = null,
            tint = if (available) ColorGoodService else MetroBorder,
            modifier = Modifier.size(16.dp)
        )
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = if (available) Color.White else MetroTextMuted)
    }
}
