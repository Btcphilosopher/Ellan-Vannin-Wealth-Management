package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransportData
import com.example.model.Journey
import com.example.model.RouteSegment
import com.example.model.TransportMode
import com.example.ui.theme.*
import com.example.viewmodel.TransportViewModel

@Composable
fun PlannerScreen(viewModel: TransportViewModel) {
    val state by viewModel.plannerState.collectAsState()

    var originDropdownExpanded by remember { mutableStateOf(false) }
    var destinationDropdownExpanded by remember { mutableStateOf(false) }

    val allStationsList = TransportData.stations.values.toList()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- TOP SEARCH AREA ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MetroSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ONE REGION. ONE JOURNEY.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MetroYellow
                )
                Text(
                    text = "Multimodal Journey Planner",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // ORIGIN INPUT Selection
                Box {
                    OutlinedButton(
                        onClick = { originDropdownExpanded = true },
                        modifier = Modifier.fillMaxWidth().testTag("planner_origin_dropdown"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(1.dp, MetroBorder),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Place, contentDescription = null, tint = MetroYellow)
                                Text(
                                    text = "From: ${TransportData.stations[state.originId]?.name}",
                                    style = MaterialTheme.typography.bodyLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MetroTextSecondary)
                        }
                    }
                    DropdownMenu(
                        expanded = originDropdownExpanded,
                        onDismissRequest = { originDropdownExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.9f).background(MetroSurface)
                    ) {
                        allStationsList.forEach { station ->
                            DropdownMenuItem(
                                text = { Text(station.name, color = Color.White) },
                                onClick = {
                                    viewModel.setPlannerOrigin(station.id)
                                    originDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // SWAP BUTTON
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButton(
                        onClick = { viewModel.swapPlannerStations() },
                        modifier = Modifier
                            .size(36.dp)
                            .background(MetroSurfaceVariant, CircleShape)
                            .testTag("swap_stations_btn")
                    ) {
                        Icon(Icons.Default.SwapVert, contentDescription = "Swap Locations", tint = MetroYellow)
                    }
                }

                // DESTINATION INPUT Selection
                Box {
                    OutlinedButton(
                        onClick = { destinationDropdownExpanded = true },
                        modifier = Modifier.fillMaxWidth().testTag("planner_destination_dropdown"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(1.dp, MetroBorder),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.NearMe, contentDescription = null, tint = MetroYellow)
                                Text(
                                    text = "To: ${TransportData.stations[state.destinationId]?.name}",
                                    style = MaterialTheme.typography.bodyLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MetroTextSecondary)
                        }
                    }
                    DropdownMenu(
                        expanded = destinationDropdownExpanded,
                        onDismissRequest = { destinationDropdownExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.9f).background(MetroSurface)
                    ) {
                        allStationsList.forEach { station ->
                            DropdownMenuItem(
                                text = { Text(station.name, color = Color.White) },
                                onClick = {
                                    viewModel.setPlannerDestination(station.id)
                                    destinationDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Preference Filter Toggle Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("FASTEST", "LOWEST_COST", "ACCESSIBLE", "METRO_ONLY").forEach { pref ->
                        val selected = state.preference == pref
                        val label = pref.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() }
                        FilterChip(
                            selected = selected,
                            onClick = { viewModel.setPlannerPreference(pref) },
                            label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MetroYellow,
                                selectedLabelColor = MetroOnYellow,
                                containerColor = MetroSurfaceVariant,
                                labelColor = Color.White
                            ),
                            border = null
                        )
                    }
                }
            }
        }

        // --- PLAN JOURNEY RESULTS LIST ---
        if (state.plannedJourneys.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No direct routes found. Try changing your selection.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MetroTextSecondary
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(state.plannedJourneys) { journey ->
                    JourneyResultCard(journey = journey, onSelect = {
                        viewModel.startLiveJourneyTracking(journey)
                    })
                }
            }
        }
    }
}

@Composable
fun JourneyResultCard(journey: Journey, onSelect: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("journey_card_${journey.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MetroSurface),
        border = if (journey.isDisrupted) BorderStroke(1.dp, ColorAlert) else null
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Time, Cost, Duration
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "${journey.startTime} → ${journey.endTime}",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Text(
                        text = "${journey.totalDurationMinutes} min duration",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MetroTextSecondary
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = TransportData.formatPence(journey.totalFarePence),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = MetroYellow)
                    )
                    Text(
                        text = "${journey.carbonKgEstimate} kg CO₂e",
                        style = MaterialTheme.typography.labelMedium,
                        color = ColorCycle
                    )
                }
            }

            // Disruption Warn
            if (journey.isDisrupted && journey.disruptionMessage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(ColorAlert.copy(alpha = 0.15f))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Warning, contentDescription = "Alert", tint = ColorAlert, modifier = Modifier.size(16.dp))
                    Text(
                        text = journey.disruptionMessage,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = ColorAlert
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Progress segments display bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                journey.segments.forEachIndexed { index, segment ->
                    val color = when (segment.mode) {
                        TransportMode.METRO -> ColorMetro
                        TransportMode.RAIL -> ColorRail
                        TransportMode.BUS -> ColorBus
                        TransportMode.FERRY -> ColorFerry
                        TransportMode.WALK -> ColorWalk
                        TransportMode.CYCLE -> ColorCycle
                        else -> MetroBorder
                    }

                    Box(
                        modifier = Modifier
                            .weight(segment.durationMinutes.toFloat())
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(color)
                    )

                    if (index < journey.segments.size - 1) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = MetroTextMuted,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Written segment breakdown
            journey.segments.forEach { segment ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    val (icon, color) = when (segment.mode) {
                        TransportMode.METRO -> Pair(Icons.Default.DirectionsTransit, ColorMetro)
                        TransportMode.RAIL -> Pair(Icons.Default.DirectionsRailway, ColorRail)
                        TransportMode.BUS -> Pair(Icons.Default.DirectionsBus, ColorBus)
                        TransportMode.FERRY -> Pair(Icons.Default.DirectionsBoat, ColorFerry)
                        TransportMode.WALK -> Pair(Icons.Default.DirectionsWalk, ColorWalk)
                        TransportMode.CYCLE -> Pair(Icons.Default.DirectionsBike, ColorCycle)
                        else -> Pair(Icons.Default.TripOrigin, Color.White)
                    }

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(color.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
                    }

                    Column {
                        Text(
                            text = segment.instruction,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        if (segment.lineName != null) {
                            Text(
                                text = "${segment.lineName} • ${segment.durationMinutes} min",
                                style = MaterialTheme.typography.bodySmall,
                                color = MetroTextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tap to enter Live Tracker Mode",
                    style = MaterialTheme.typography.labelSmall,
                    color = MetroYellow
                )
                Icon(
                    imageVector = Icons.Default.Directions,
                    contentDescription = null,
                    tint = MetroYellow,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
