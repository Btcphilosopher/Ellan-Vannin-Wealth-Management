package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransportData
import com.example.model.Vehicle
import com.example.ui.theme.*
import com.example.viewmodel.TransportViewModel

@Composable
fun MapScreen(viewModel: TransportViewModel) {
    val vehicles by viewModel.vehicles.collectAsState()
    val showFuture by viewModel.showFutureWashington.collectAsState()

    var selectedVehicle by remember { mutableStateOf<Vehicle?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- CONTROL TOGGLE BAR ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MetroSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "METRO NETWORK MAP",
                            style = MaterialTheme.typography.labelMedium,
                            color = MetroYellow
                        )
                        Text(
                            text = "Real-Time Digital Twin",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    // Toggle Future Extension
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Washington Proposal",
                            style = MaterialTheme.typography.bodySmall,
                            color = MetroTextSecondary
                        )
                        Switch(
                            checked = showFuture,
                            onCheckedChange = { viewModel.toggleFutureWashington(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MetroYellow,
                                checkedTrackColor = MetroYellow.copy(alpha = 0.5f),
                                uncheckedThumbColor = MetroTextMuted,
                                uncheckedTrackColor = MetroBorder
                            ),
                            modifier = Modifier.testTag("future_washington_toggle")
                        )
                    }
                }
            }
        }

        // --- MAP GRAPHIC CANVAS ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MetroSurface)
                .border(1.dp, MetroBorder, RoundedCornerShape(12.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Base coordinates scaling
                val airportPt = Offset(w * 0.15f, h * 0.15f)
                val southGosforthPt = Offset(w * 0.45f, h * 0.35f)
                val monumentPt = Offset(w * 0.45f, h * 0.5f)
                val centralPt = Offset(w * 0.4f, h * 0.6f)
                val gatesheadPt = Offset(w * 0.4f, h * 0.72f)
                val pelawPt = Offset(w * 0.55f, h * 0.8f)
                
                val tynemouthPt = Offset(w * 0.85f, h * 0.35f)
                val wallsendPt = Offset(w * 0.65f, h * 0.45f)
                
                val southShieldsPt = Offset(w * 0.85f, h * 0.75f)
                val sunderlandPt = Offset(w * 0.75f, h * 0.88f)
                val southHyltonPt = Offset(w * 0.62f, h * 0.92f)

                // Washington points (Proposed 2033)
                val follingsbyPt = Offset(w * 0.58f, h * 0.86f)
                val washNorthPt = Offset(w * 0.61f, h * 0.89f)
                val washSouthPt = Offset(w * 0.64f, h * 0.91f)

                // DRAW NETWORK TRACK LINES
                // 1. Green Line (Airport to South Hylton)
                drawLine(color = Color(0xFF4CAF50), start = airportPt, end = southGosforthPt, strokeWidth = 8f)
                drawLine(color = Color(0xFF4CAF50), start = southGosforthPt, end = monumentPt, strokeWidth = 8f)
                drawLine(color = Color(0xFF4CAF50), start = monumentPt, end = centralPt, strokeWidth = 8f)
                drawLine(color = Color(0xFF4CAF50), start = centralPt, end = gatesheadPt, strokeWidth = 8f)
                drawLine(color = Color(0xFF4CAF50), start = gatesheadPt, end = pelawPt, strokeWidth = 8f)
                drawLine(color = Color(0xFF4CAF50), start = pelawPt, end = sunderlandPt, strokeWidth = 8f)
                drawLine(color = Color(0xFF4CAF50), start = sunderlandPt, end = southHyltonPt, strokeWidth = 8f)

                // 2. Yellow Line Loop (St James / Monument round to South Shields)
                drawLine(color = ColorMetro, start = southGosforthPt, end = tynemouthPt, strokeWidth = 6f)
                drawLine(color = ColorMetro, start = tynemouthPt, end = wallsendPt, strokeWidth = 6f)
                drawLine(color = ColorMetro, start = wallsendPt, end = monumentPt, strokeWidth = 6f)
                drawLine(color = ColorMetro, start = monumentPt, end = centralPt, strokeWidth = 6f)
                drawLine(color = ColorMetro, start = centralPt, end = gatesheadPt, strokeWidth = 6f)
                drawLine(color = ColorMetro, start = gatesheadPt, end = pelawPt, strokeWidth = 6f)
                drawLine(color = ColorMetro, start = pelawPt, end = southShieldsPt, strokeWidth = 6f)

                // 3. Shields Ferry crossing (North Shields to South Shields)
                drawLine(
                    color = ColorFerry, start = Offset(w * 0.85f, h * 0.45f), end = southShieldsPt, strokeWidth = 4f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )

                // 4. Proposed Washington extension (Leamside Line)
                if (showFuture) {
                    drawLine(
                        color = ColorFuture, start = pelawPt, end = follingsbyPt, strokeWidth = 6f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                    )
                    drawLine(
                        color = ColorFuture, start = follingsbyPt, end = washNorthPt, strokeWidth = 6f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                    )
                    drawLine(
                        color = ColorFuture, start = washNorthPt, end = washSouthPt, strokeWidth = 6f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                    )
                    drawLine(
                        color = ColorFuture, start = washSouthPt, end = southHyltonPt, strokeWidth = 6f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                    )
                }

                // DRAW STATIONS AS DOTS
                drawCircle(color = Color.White, radius = 8f, center = airportPt)
                drawCircle(color = Color.White, radius = 8f, center = southGosforthPt)
                drawCircle(color = MetroYellow, radius = 10f, center = monumentPt) // Major Interchange
                drawCircle(color = MetroYellow, radius = 10f, center = centralPt)   // Major Interchange
                drawCircle(color = Color.White, radius = 8f, center = gatesheadPt)
                drawCircle(color = Color.White, radius = 8f, center = pelawPt)
                drawCircle(color = Color.White, radius = 8f, center = tynemouthPt)
                drawCircle(color = Color.White, radius = 8f, center = southShieldsPt)
                drawCircle(color = Color.White, radius = 8f, center = sunderlandPt)
                drawCircle(color = Color.White, radius = 8f, center = southHyltonPt)

                if (showFuture) {
                    drawCircle(color = ColorFuture, radius = 6f, center = follingsbyPt)
                    drawCircle(color = ColorFuture, radius = 6f, center = washNorthPt)
                    drawCircle(color = ColorFuture, radius = 6f, center = washSouthPt)
                }
            }

            // Interactive Overlaid Train Markers
            vehicles.forEach { v ->
                val w = 340.dp // assumed local constraints
                val h = 500.dp
                val xPercent = when (v.serviceLineId) {
                    "green" -> when (v.currentStationId) {
                        "airport" -> 0.18f
                        "jesmond" -> 0.44f
                        "sunderland" -> 0.72f
                        else -> 0.48f
                    }
                    "yellow" -> when (v.currentStationId) {
                        "st_james" -> 0.38f
                        "tynemouth" -> 0.81f
                        "gateshead" -> 0.41f
                        else -> 0.62f
                    }
                    "northumberland" -> 0.31f
                    else -> 0.83f
                }
                val yPercent = when (v.serviceLineId) {
                    "green" -> when (v.currentStationId) {
                        "airport" -> 0.16f
                        "jesmond" -> 0.41f
                        "sunderland" -> 0.84f
                        else -> 0.65f
                    }
                    "yellow" -> when (v.currentStationId) {
                        "st_james" -> 0.48f
                        "tynemouth" -> 0.38f
                        "gateshead" -> 0.70f
                        else -> 0.52f
                    }
                    "northumberland" -> 0.44f
                    else -> 0.68f
                }

                Box(
                    modifier = Modifier
                        .absoluteOffset(
                            x = (xPercent * 310).dp,
                            y = (yPercent * 410).dp
                        )
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(if (v.serviceLineId == "yellow") MetroYellow else ColorRail)
                        .border(1.5.dp, Color.White, CircleShape)
                        .clickable { selectedVehicle = v }
                        .testTag("vehicle_marker_${v.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsTransit,
                        contentDescription = "Train ${v.id}",
                        tint = if (v.serviceLineId == "yellow") MetroOnYellow else Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }

        // --- SELECTED VEHICLE DRAWER ---
        selectedVehicle?.let { v ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("map_vehicle_detail_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MetroSurface),
                border = BorderStroke(1.dp, MetroYellow)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(if (v.serviceLineId == "yellow") MetroYellow else ColorRail, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.DirectionsTransit,
                                    contentDescription = null,
                                    tint = if (v.serviceLineId == "yellow") MetroOnYellow else Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "TRAIN ${v.id}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${v.serviceLineId.uppercase()} LINE • To ${TransportData.stations[v.destinationStationId]?.name ?: v.destinationStationId}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MetroTextSecondary
                                )
                            }
                        }

                        IconButton(onClick = { selectedVehicle = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = MetroTextMuted)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "CURRENT POSITION", style = MaterialTheme.typography.labelSmall, color = MetroTextMuted)
                            Text(
                                text = "At ${TransportData.stations[v.currentStationId]?.name}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "STATUS", style = MaterialTheme.typography.labelSmall, color = MetroTextMuted)
                            Text(
                                text = if (v.delayMinutes > 0) "Delayed +${v.delayMinutes}m" else "On Time",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (v.delayMinutes > 0) ColorAlert else ColorGoodService
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Stadler new train features
                    Text(text = "ONBOARD METRICS (NEW STADLER FLEET)", style = MaterialTheme.typography.labelSmall, color = MetroYellow)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        IconFeature(Icons.Default.BatteryChargingFull, "USB Power", true)
                        IconFeature(Icons.Default.AcUnit, "Climate Control", true)
                        IconFeature(Icons.Default.Accessibility, "Step-Free Level Access", true)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Capacity Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Occupancy:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MetroTextSecondary
                        )
                        LinearProgressIndicator(
                            progress = { v.capacityPercent / 100f },
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (v.capacityPercent > 80) ColorAlert else if (v.capacityPercent > 50) MetroYellow else ColorGoodService,
                            trackColor = MetroBorder
                        )
                        Text(
                            text = "${v.capacityPercent}%",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IconFeature(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(MetroSurfaceVariant)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(icon, contentDescription = null, tint = if (active) MetroYellow else MetroTextMuted, modifier = Modifier.size(14.dp))
        Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (active) Color.White else MetroTextMuted)
    }
}
