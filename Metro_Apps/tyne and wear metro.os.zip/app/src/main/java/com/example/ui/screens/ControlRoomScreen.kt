package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransportData
import com.example.model.Disruption
import com.example.ui.theme.*
import com.example.viewmodel.TransportViewModel

@Composable
fun ControlRoomScreen(viewModel: TransportViewModel) {
    val vehicles by viewModel.vehicles.collectAsState()
    val disruptions by viewModel.disruptions.collectAsState()

    var speedSelected by remember { mutableStateOf(1) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- HEADER ---
        item {
            Column {
                Text(
                    text = "INTERNAL MANAGEMENT SYSTEM",
                    style = MaterialTheme.typography.labelMedium,
                    color = ColorAlert
                )
                Text(
                    text = "Metro Control Centre",
                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.ExtraBold)
                )
                Text(
                    text = "Network-wide dispatch, telemetry, and disruption injector.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MetroTextSecondary
                )
            }
        }

        // --- DISRUPTION INJECTOR CONTROLS ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MetroSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "INCIDENT MANAGEMENT & DISRUPTION INJECTION",
                        style = MaterialTheme.typography.labelMedium,
                        color = ColorAlert
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.injectDisruption(
                                    lineId = "green",
                                    title = "Sunderland Signals",
                                    desc = "Power supply failure near Seaburn. Green line delayed.",
                                    delayMin = 18
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("inject_green_delay_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = ColorAlert),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Green Delays (+18m)", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                viewModel.injectDisruption(
                                    lineId = "yellow",
                                    title = "Jarrow Fleet Work",
                                    desc = "Emergency structural inspections at Jarrow. Yellow line minor delays.",
                                    delayMin = 12
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("inject_yellow_delay_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = ColorAlert),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Yellow Delays (+12m)", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (disruptions.isNotEmpty()) {
                        Button(
                            onClick = { viewModel.clearAllDisruptions() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("clear_disruptions_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = ColorGoodService, contentColor = Color.White),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("CLEAR INCIDENTS / RESTORE NORMAL SERVICE")
                        }
                    }
                }
            }
        }

        // --- TIME ACCELERATOR ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MetroSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SIMULATION CONTROL ENGINE",
                            style = MaterialTheme.typography.labelMedium,
                            color = MetroYellow
                        )

                        // Manual Step Action
                        IconButton(
                            onClick = { viewModel.advanceSimulationTick() },
                            modifier = Modifier
                                .size(32.dp)
                                .background(MetroSurfaceVariant, CircleShape)
                                .testTag("manual_tick_btn")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Tick Step", tint = MetroYellow)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(1, 10, 100).forEach { speed ->
                            val selected = speedSelected == speed
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selected) MetroYellow else MetroSurfaceVariant)
                                    .clickable {
                                        speedSelected = speed
                                        viewModel.updateSimulationSpeed(speed)
                                    }
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${speed}x Speed",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (selected) MetroOnYellow else Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- LIVE INCIDENTS TABLE ---
        item {
            Text(
                text = "ACTIVE DISPATCH INCIDENTS",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MetroTextSecondary
            )
        }

        if (disruptions.isEmpty()) {
            item {
                Text(
                    text = "● No active incidents reported on the telemetry system.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ColorGoodService
                )
            }
        } else {
            items(disruptions) { dis ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(ColorAlert.copy(alpha = 0.12f))
                        .border(1.dp, ColorAlert, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = dis.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = ColorAlert)
                        Text(text = dis.description, style = MaterialTheme.typography.bodySmall, color = MetroTextPrimary)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ColorAlert)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = "+${dis.delayMinutes}m", fontWeight = FontWeight.Bold, fontSize = 10.sp, color = Color.White)
                    }
                }
            }
        }

        // --- VEHICLE TELEMETRY FEED ---
        item {
            Text(
                text = "ACTIVE TELEMETRY STREAM (${vehicles.size} vehicles)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MetroTextSecondary
            )
        }

        items(vehicles) { v ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MetroSurface)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(if (v.serviceLineId == "yellow") MetroYellow else ColorRail, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.DirectionsTransit,
                            contentDescription = null,
                            tint = if (v.serviceLineId == "yellow") MetroOnYellow else Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    Column {
                        val currentName = TransportData.stations[v.currentStationId]?.name ?: v.currentStationId
                        Text(
                            text = "TRAIN ${v.id}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Line: ${v.serviceLineId.uppercase()} • Position: $currentName",
                            style = MaterialTheme.typography.bodySmall,
                            color = MetroTextSecondary
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${v.capacityPercent}% occupancy",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (v.capacityPercent > 80) ColorAlert else MetroTextSecondary
                    )
                    Text(
                        text = if (v.delayMinutes > 0) "+${v.delayMinutes} min" else "ON TIME",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (v.delayMinutes > 0) ColorAlert else ColorGoodService
                    )
                }
            }
        }
    }
}
