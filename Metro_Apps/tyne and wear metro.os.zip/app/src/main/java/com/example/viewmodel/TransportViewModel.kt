package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.TransportData
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class AppScreen {
    HOME,
    PLANNER,
    MAP,
    TICKETS,
    MY_METRO,
    STATION_DETAIL,
    CONTROL_ROOM
}

data class PlannerInputState(
    val originId: String = "central",
    val destinationId: String = "tynemouth",
    val preference: String = "FASTEST",
    val plannedJourneys: List<Journey> = emptyList()
)

data class LiveJourneyState(
    val activeJourney: Journey? = null,
    val currentSegmentIndex: Int = 0,
    val currentStationName: String = "",
    val nextStationName: String = "",
    val stopsRemaining: Int = 0,
    val stateMessage: String = "Ready to depart",
    val isTracking: Boolean = false
)

data class StationDetailState(
    val stationId: String = "monument",
    val departures: List<Vehicle> = emptyList()
)

class TransportViewModel : ViewModel() {

    // Navigation and core UI screens
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Screen stack to handle back navigation safely
    private val screenStack = Stack<AppScreen>()

    // Selected Station for details screen
    private val _selectedStationId = MutableStateFlow("monument")
    val selectedStationId: StateFlow<String> = _selectedStationId.asStateFlow()

    // Planner UI State
    private val _plannerState = MutableStateFlow(PlannerInputState())
    val plannerState: StateFlow<PlannerInputState> = _plannerState.asStateFlow()

    // Tickets State (User Wallet)
    private val _ticketWallet = MutableStateFlow<List<DigitalTicket>>(emptyList())
    val ticketWallet: StateFlow<List<DigitalTicket>> = _ticketWallet.asStateFlow()

    // Pop Card State
    private val _popCard = MutableStateFlow(PopCard())
    val popCard: StateFlow<PopCard> = _popCard.asStateFlow()

    // Active PAYG Trip State
    private val _activeTapInStationId = MutableStateFlow<String?>(null)
    val activeTapInStationId: StateFlow<String?> = _activeTapInStationId.asStateFlow()

    // Active Live Journey Tracker State
    private val _liveJourneyState = MutableStateFlow(LiveJourneyState())
    val liveJourneyState: StateFlow<LiveJourneyState> = _liveJourneyState.asStateFlow()

    // Real-time Vehicle position list
    private val _vehicles = MutableStateFlow<List<Vehicle>>(emptyList())
    val vehicles: StateFlow<List<Vehicle>> = _vehicles.asStateFlow()

    // Disruptions State
    private val _disruptions = MutableStateFlow<List<Disruption>>(emptyList())
    val disruptions: StateFlow<List<Disruption>> = _disruptions.asStateFlow()

    // Station Departures screen helper
    private val _stationDetailState = MutableStateFlow(StationDetailState())
    val stationDetailState: StateFlow<StationDetailState> = _stationDetailState.asStateFlow()

    // Future Network map toggle
    private val _showFutureWashington = MutableStateFlow(false)
    val showFutureWashington: StateFlow<Boolean> = _showFutureWashington.asStateFlow()

    // Background simulation ticker job
    private var simulationJob: Job? = null

    init {
        // Prepare some mock tickets in the wallet
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale.UK)
        val todayStr = sdf.format(Date())
        val tomorrowStr = sdf.format(Date(System.currentTimeMillis() + 86400000))
        
        _ticketWallet.value = listOf(
            DigitalTicket(type = TicketType.DAY_TICKET, purchaseDate = todayStr, expiryDate = todayStr),
            DigitalTicket(type = TicketType.SINGLE, purchaseDate = todayStr, expiryDate = todayStr, validityState = "USED")
        )

        // Populate initial Pop Card transaction history
        val popHist = listOf(
            PopTransaction(timestamp = "08:14", description = "Tap-in Monument", amountPence = 0, type = "TAP_IN"),
            PopTransaction(timestamp = "08:35", description = "Tap-out Whitley Bay", amountPence = -240, type = "FARE"),
            PopTransaction(timestamp = "12:00", description = "Top Up (Auto-Pay)", amountPence = 1000, type = "TOP_UP")
        )
        _popCard.value = PopCard(balancePence = 1840, recentTransactions = popHist)

        // Sync initial vehicles and disruptions
        _vehicles.value = TransportData.vehiclesList
        _disruptions.value = TransportData.activeDisruptions

        // Pre-calculate standard planned journeys
        calculateJourneys()

        // Start background real-time ticker
        startRealTimeSimulation()
    }

    // Navigation Methods
    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            screenStack.push(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        return if (!screenStack.isEmpty()) {
            _currentScreen.value = screenStack.pop()
            true
        } else {
            if (_currentScreen.value != AppScreen.HOME) {
                _currentScreen.value = AppScreen.HOME
                true
            } else {
                false
            }
        }
    }

    fun viewStationDetails(stationId: String) {
        _selectedStationId.value = stationId
        updateStationDetailState(stationId)
        navigateTo(AppScreen.STATION_DETAIL)
    }

    // Journey Planner Actions
    fun setPlannerOrigin(originId: String) {
        _plannerState.value = _plannerState.value.copy(originId = originId)
        calculateJourneys()
    }

    fun setPlannerDestination(destinationId: String) {
        _plannerState.value = _plannerState.value.copy(destinationId = destinationId)
        calculateJourneys()
    }

    fun setPlannerPreference(pref: String) {
        _plannerState.value = _plannerState.value.copy(preference = pref)
        calculateJourneys()
    }

    fun swapPlannerStations() {
        val oldOrigin = _plannerState.value.originId
        val oldDest = _plannerState.value.destinationId
        _plannerState.value = _plannerState.value.copy(originId = oldDest, destinationId = oldOrigin)
        calculateJourneys()
    }

    fun calculateJourneys() {
        val origin = _plannerState.value.originId
        val dest = _plannerState.value.destinationId
        val pref = _plannerState.value.preference
        
        // Use real routing engine
        val list = TransportData.planJourney(
            originId = origin,
            destinationId = dest,
            preference = pref,
            currentTime = "14:42",
            isDisruptedState = _disruptions.value.isNotEmpty(),
            disruptedLineId = _disruptions.value.firstOrNull()?.affectedLineId
        )
        _plannerState.value = _plannerState.value.copy(plannedJourneys = list)
    }

    // Station details helper
    fun updateStationDetailState(stationId: String) {
        val stationVehicles = _vehicles.value.filter { v ->
            v.currentStationId == stationId || v.nextStationId == stationId
        }
        _stationDetailState.value = StationDetailState(
            stationId = stationId,
            departures = stationVehicles.take(5)
        )
    }

    // Live Journey tracking mode
    fun startLiveJourneyTracking(journey: Journey) {
        val firstSegment = journey.segments.firstOrNull() ?: return
        _liveJourneyState.value = LiveJourneyState(
            activeJourney = journey,
            currentSegmentIndex = 0,
            currentStationName = firstSegment.fromStationName,
            nextStationName = firstSegment.toStationName,
            stopsRemaining = firstSegment.stopCount,
            stateMessage = firstSegment.instruction,
            isTracking = true
        )
        navigateTo(AppScreen.HOME)
    }

    fun advanceLiveJourney() {
        val active = _liveJourneyState.value.activeJourney ?: return
        val currentIdx = _liveJourneyState.value.currentSegmentIndex
        
        if (currentIdx + 1 < active.segments.size) {
            val nextSeg = active.segments[currentIdx + 1]
            _liveJourneyState.value = _liveJourneyState.value.copy(
                currentSegmentIndex = currentIdx + 1,
                currentStationName = nextSeg.fromStationName,
                nextStationName = nextSeg.toStationName,
                stopsRemaining = nextSeg.stopCount,
                stateMessage = nextSeg.instruction
            )
        } else {
            // Journey complete
            _liveJourneyState.value = LiveJourneyState() // Reset
        }
    }

    fun cancelLiveJourney() {
        _liveJourneyState.value = LiveJourneyState()
    }

    // Ticketing system methods
    fun buyTicket(type: TicketType, passengerType: String) {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale.UK)
        val todayStr = sdf.format(Date())
        val price = TransportData.calculateFarePence("central", "tynemouth", type, passengerType)

        // Deduct from Pop Card if available and sufficient, otherwise simulate card payment
        if (_popCard.value.balancePence >= price) {
            val newBalance = _popCard.value.balancePence - price
            val transaction = PopTransaction(
                timestamp = SimpleDateFormat("HH:mm", Locale.UK).format(Date()),
                description = "Purchase: ${type.label}",
                amountPence = -price,
                type = "FARE"
            )
            _popCard.value = _popCard.value.copy(
                balancePence = newBalance,
                recentTransactions = listOf(transaction) + _popCard.value.recentTransactions
            )
        }

        val newTicket = DigitalTicket(
            type = type,
            passengerType = passengerType,
            purchaseDate = todayStr,
            expiryDate = todayStr,
            validityState = "VALID"
        )
        _ticketWallet.value = listOf(newTicket) + _ticketWallet.value
    }

    // Pop PAYG Simulated Tapping
    fun tapPopCard(stationId: String) {
        val currentTap = _activeTapInStationId.value
        val sdf = SimpleDateFormat("HH:mm", Locale.UK)
        val timeStr = sdf.format(Date())

        if (currentTap == null) {
            // Tap In
            _activeTapInStationId.value = stationId
            val transaction = PopTransaction(
                timestamp = timeStr,
                description = "Tap-in ${TransportData.stations[stationId]?.name ?: stationId}",
                amountPence = 0,
                type = "TAP_IN"
            )
            _popCard.value = _popCard.value.copy(
                recentTransactions = listOf(transaction) + _popCard.value.recentTransactions
            )
        } else {
            // Tap Out
            _activeTapInStationId.value = null
            val fare = TransportData.calculateFarePence(currentTap, stationId, TicketType.POP_PAYG)
            val newBalance = Math.max(0, _popCard.value.balancePence - fare)

            val tapOutTrans = PopTransaction(
                timestamp = timeStr,
                description = "Tap-out ${TransportData.stations[stationId]?.name ?: stationId}",
                amountPence = 0,
                type = "TAP_OUT"
            )
            val fareTrans = PopTransaction(
                timestamp = timeStr,
                description = "Journey Fare: ${TransportData.stations[currentTap]?.name} → ${TransportData.stations[stationId]?.name}",
                amountPence = -fare,
                type = "FARE"
            )

            _popCard.value = _popCard.value.copy(
                balancePence = newBalance,
                recentTransactions = listOf(fareTrans, tapOutTrans) + _popCard.value.recentTransactions
            )
        }
    }

    fun topUpPopCard(amountPence: Int) {
        val sdf = SimpleDateFormat("HH:mm", Locale.UK)
        val timeStr = sdf.format(Date())
        val transaction = PopTransaction(
            timestamp = timeStr,
            description = "Top Up (Mobile Payment)",
            amountPence = amountPence,
            type = "TOP_UP"
        )
        _popCard.value = _popCard.value.copy(
            balancePence = _popCard.value.balancePence + amountPence,
            recentTransactions = listOf(transaction) + _popCard.value.recentTransactions
        )
    }

    // Future extension toggle
    fun toggleFutureWashington(show: Boolean) {
        _showFutureWashington.value = show
    }

    // Simulation & Control Room operator actions
    fun injectDisruption(lineId: String, title: String, desc: String, delayMin: Int) {
        val dis = Disruption(
            id = "DIS-${UUID.randomUUID().toString().take(4).uppercase()}",
            affectedLineId = lineId,
            title = title,
            description = desc,
            delayMinutes = delayMin
        )
        TransportData.activeDisruptions.add(dis)
        _disruptions.value = TransportData.activeDisruptions.toList()

        // Apply delays to vehicles operating on this line
        TransportData.vehiclesList = TransportData.vehiclesList.map { v ->
            if (v.serviceLineId == lineId) {
                v.copy(delayMinutes = delayMin)
            } else {
                v
            }
        }.toMutableList()
        _vehicles.value = TransportData.vehiclesList

        calculateJourneys() // Recalculate journeys instantly
    }

    fun clearAllDisruptions() {
        TransportData.activeDisruptions.clear()
        _disruptions.value = emptyList()

        // Clear vehicle delays
        TransportData.vehiclesList = TransportData.vehiclesList.map { v ->
            v.copy(delayMinutes = 0)
        }.toMutableList()
        _vehicles.value = TransportData.vehiclesList

        calculateJourneys()
    }

    fun updateSimulationSpeed(multiplier: Int) {
        TransportData.simulationSpeedMultiplier = multiplier
    }

    fun advanceSimulationTick() {
        TransportData.stepSimulation()
        _vehicles.value = TransportData.vehiclesList.toList()
        
        // Update station detail state if on station screen
        updateStationDetailState(_selectedStationId.value)
    }

    private fun startRealTimeSimulation() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            while (true) {
                delay(3000) // tick every 3 seconds
                advanceSimulationTick()
            }
        }
    }

    override fun onCleared() {
        simulationJob?.cancel()
        super.onCleared()
    }
}
