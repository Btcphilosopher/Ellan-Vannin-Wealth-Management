package com.example.data

import com.example.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

object TransportData {

    // --- METRO ARTWORKS (Real-world examples) ---
    val monumentArtworks = listOf(
        MetroArtwork(
            title = "Famous Faces",
            artist = "Bob Olley",
            year = "1996",
            description = "A large scale mural depicting famous North East faces looking out from a Metro train window. Features cultural, sporting, and political figures of the region."
        ),
        MetroArtwork(
            title = "Parsons Polygon",
            artist = "David Hamilton",
            year = "1985",
            description = "A red terracotta tile monument celebrating the steam turbine engineering legacy of Sir Charles Parsons, integrated into the station ventilation shaft."
        )
    )

    val centralArtworks = listOf(
        MetroArtwork(
            title = "From the Rivers to the Sea",
            artist = "Hilary Paynter",
            year = "2013",
            description = "A massive wood engraving mural composed of hundreds of panels showing the natural and industrial landscapes of Tyne and Wear."
        )
    )

    val tynemouthArtworks = listOf(
        MetroArtwork(
            title = "The Tynemouth Map",
            artist = "Anya Lewin",
            year = "2004",
            description = "A detailed historical and topographical map mural highlighting coastal heritage, marine activities, and community stories."
        )
    )

    // --- STATIONS DATASET ---
    val stations = mapOf(
        // Core Interchange Stations
        "monument" to Station(
            id = "monument", name = "Monument", code = "MON",
            lines = listOf("yellow", "green"), modes = listOf(TransportMode.METRO, TransportMode.WALK),
            isInterchange = true, hasToilets = false, hasParking = false, hasCycleHub = true,
            artwork = monumentArtworks, facilities = listOf("Lifts", "Ticket Machines", "Cycle Storage", "Intercalated Retail"),
            latitude = 54.9739, longitude = -1.6133
        ),
        "central" to Station(
            id = "central", name = "Newcastle Central", code = "CEN",
            lines = listOf("yellow", "green", "northumberland"), modes = listOf(TransportMode.METRO, TransportMode.RAIL, TransportMode.WALK, TransportMode.CYCLE),
            isInterchange = true, hasToilets = true, hasParking = true, parkingCapacity = 250, hasCycleHub = true,
            artwork = centralArtworks, facilities = listOf("National Rail Interchange", "Lifts", "Toilets", "Waiting Rooms", "Cafés", "Cycle Parking", "Taxi Rank"),
            latitude = 54.9686, longitude = -1.6171
        ),
        "haymarket" to Station(
            id = "haymarket", name = "Haymarket", code = "HAY",
            lines = listOf("yellow", "green"), modes = listOf(TransportMode.METRO, TransportMode.BUS, TransportMode.WALK),
            isInterchange = true, hasToilets = false, hasParking = false, hasCycleHub = false,
            facilities = listOf("Major Bus Station Interchange", "Lifts", "Ticket Office", "Shops"),
            latitude = 54.9781, longitude = -1.6141
        ),
        "gateshead" to Station(
            id = "gateshead", name = "Gateshead", code = "GHD",
            lines = listOf("yellow", "green"), modes = listOf(TransportMode.METRO, TransportMode.BUS, TransportMode.WALK),
            isInterchange = true, hasToilets = true, hasParking = false, hasCycleHub = true,
            facilities = listOf("Gateshead Bus Interchange", "Lifts", "Toilets", "Security Hub", "Shops"),
            latitude = 54.9618, longitude = -1.6039
        ),
        "sunderland" to Station(
            id = "sunderland", name = "Sunderland", code = "SUN",
            lines = listOf("green"), modes = listOf(TransportMode.METRO, TransportMode.RAIL, TransportMode.BUS, TransportMode.WALK),
            isInterchange = true, hasToilets = true, hasParking = true, parkingCapacity = 180, hasCycleHub = true,
            facilities = listOf("Shared Metro & Northern Rail Platforms", "Sunderland Interchange", "Toilets", "Ticket Office", "Lifts"),
            latitude = 54.9061, longitude = -1.3789
        ),
        "south_shields" to Station(
            id = "south_shields", name = "South Shields", code = "SSH",
            lines = listOf("yellow"), modes = listOf(TransportMode.METRO, TransportMode.BUS, TransportMode.FERRY, TransportMode.WALK),
            isInterchange = true, hasToilets = true, hasParking = false, hasCycleHub = true,
            facilities = listOf("South Shields Transport Interchange", "Ferry Connection", "Toilets", "Lifts", "Cycle Hub"),
            latitude = 55.0003, longitude = -1.4312
        ),
        "heworth" to Station(
            id = "heworth", name = "Heworth", code = "HEW",
            lines = listOf("yellow", "green"), modes = listOf(TransportMode.METRO, TransportMode.BUS, TransportMode.RAIL, TransportMode.CYCLE),
            isInterchange = true, hasToilets = false, hasParking = true, parkingCapacity = 450, hasCycleHub = true,
            facilities = listOf("Park & Ride", "Bus Interchange", "Northern Rail Stopping Services", "Lifts"),
            latitude = 54.9421, longitude = -1.5362
        ),
        "northumberland_park" to Station(
            id = "northumberland_park", name = "Northumberland Park", code = "NDP",
            lines = listOf("yellow", "northumberland"), modes = listOf(TransportMode.METRO, TransportMode.RAIL, TransportMode.CYCLE),
            isInterchange = true, hasToilets = false, hasParking = true, parkingCapacity = 380, hasCycleHub = true,
            facilities = listOf("Park & Ride", "Northumberland Line Interchange", "Lifts", "Cycle Lockers"),
            latitude = 55.0315, longitude = -1.5238
        ),

        // Green Line Specific Stations
        "airport" to Station(
            id = "airport", name = "Newcastle Airport", code = "APT",
            lines = listOf("green"), modes = listOf(TransportMode.METRO, TransportMode.AIRPORT),
            isInterchange = true, hasToilets = true, hasParking = true, parkingCapacity = 1200, hasCycleHub = false,
            facilities = listOf("Newcastle Airport Terminal Access", "Toilets", "Step-free boarding", "Flight Departure Boards", "Luggage Carts"),
            latitude = 55.0381, longitude = -1.7107
        ),
        "callerton_parkway" to Station(
            id = "callerton_parkway", name = "Callerton Parkway", code = "CAL",
            lines = listOf("green"), modes = listOf(TransportMode.METRO),
            isInterchange = false, hasParking = true, parkingCapacity = 150,
            latitude = 55.0298, longitude = -1.6912
        ),
        "bank_foot" to Station(
            id = "bank_foot", name = "Bank Foot", code = "BKF",
            lines = listOf("green"), modes = listOf(TransportMode.METRO),
            isInterchange = false, hasParking = true, parkingCapacity = 80,
            latitude = 55.0189, longitude = -1.6661
        ),
        "regent_centre" to Station(
            id = "regent_centre", name = "Regent Centre", code = "RGC",
            lines = listOf("green"), modes = listOf(TransportMode.METRO, TransportMode.BUS),
            isInterchange = true, hasParking = true, parkingCapacity = 200,
            latitude = 55.0069, longitude = -1.6247
        ),
        "south_gosforth" to Station(
            id = "south_gosforth", name = "South Gosforth", code = "SGO",
            lines = listOf("yellow", "green"), modes = listOf(TransportMode.METRO),
            isInterchange = true, hasParking = false,
            latitude = 55.0042, longitude = -1.6111
        ),
        "jesmond" to Station(
            id = "jesmond", name = "Jesmond", code = "JES",
            lines = listOf("yellow", "green"), modes = listOf(TransportMode.METRO),
            isInterchange = false,
            latitude = 54.9825, longitude = -1.6094
        ),
        "stadium_of_light" to Station(
            id = "stadium_of_light", name = "Stadium of Light", code = "SOL",
            lines = listOf("green"), modes = listOf(TransportMode.METRO),
            isInterchange = false,
            facilities = listOf("Access to Stadium of Light", "Crowd Control Barriers", "Elevated Platform"),
            latitude = 54.9161, longitude = -1.3931
        ),
        "south_hylton" to Station(
            id = "south_hylton", name = "South Hylton", code = "SHY",
            lines = listOf("green"), modes = listOf(TransportMode.METRO),
            isInterchange = false, hasParking = true, parkingCapacity = 50,
            latitude = 54.9015, longitude = -1.4556
        ),

        // Yellow Line Specific Stations
        "st_james" to Station(
            id = "st_james", name = "St James", code = "SJM",
            lines = listOf("yellow"), modes = listOf(TransportMode.METRO),
            isInterchange = false,
            facilities = listOf("Direct Access to St James' Park", "Crowd Management Sluices"),
            latitude = 54.9725, longitude = -1.6212
        ),
        "manors" to Station(
            id = "manors", name = "Manors", code = "MAS",
            lines = listOf("yellow", "northumberland"), modes = listOf(TransportMode.METRO, TransportMode.RAIL),
            isInterchange = true,
            latitude = 54.9729, longitude = -1.6022
        ),
        "byker" to Station(
            id = "byker", name = "Byker", code = "BYK",
            lines = listOf("yellow"), modes = listOf(TransportMode.METRO),
            isInterchange = false,
            latitude = 54.9744, longitude = -1.5831
        ),
        "wallsend" to Station(
            id = "wallsend", name = "Wallsend", code = "WSD",
            lines = listOf("yellow"), modes = listOf(TransportMode.METRO, TransportMode.BUS),
            isInterchange = true, hasToilets = false,
            facilities = listOf("Segedunum Roman Fort Access", "Roman Bilingual Station Signage", "Bus Connections"),
            latitude = 54.9902, longitude = -1.5305
        ),
        "north_shields" to Station(
            id = "north_shields", name = "North Shields", code = "NSH",
            lines = listOf("yellow"), modes = listOf(TransportMode.METRO, TransportMode.BUS, TransportMode.FERRY),
            isInterchange = true, hasToilets = false,
            facilities = listOf("Ferry Link Bus Connection", "Cycle Racks", "Ticket Machines"),
            latitude = 55.0083, longitude = -1.4429
        ),
        "tynemouth" to Station(
            id = "tynemouth", name = "Tynemouth", code = "TYN",
            lines = listOf("yellow"), modes = listOf(TransportMode.METRO),
            isInterchange = false, hasToilets = true, hasCycleHub = true,
            artwork = tynemouthArtworks,
            facilities = listOf("Victorian Station Canopy", "Weekend Heritage Markets", "Toilets", "Cycle Hub", "Step-free Boarding"),
            latitude = 55.0179, longitude = -1.4251
        ),
        "whitley_bay" to Station(
            id = "whitley_bay", name = "Whitley Bay", code = "WTB",
            lines = listOf("yellow"), modes = listOf(TransportMode.METRO),
            isInterchange = false, hasToilets = true, hasParking = true, parkingCapacity = 60,
            facilities = listOf("Coastal Beach Access", "Lifts", "Café on Platform"),
            latitude = 55.0442, longitude = -1.4452
        ),
        "monkseaton" to Station(
            id = "monkseaton", name = "Monkseaton", code = "MKS",
            lines = listOf("yellow"), modes = listOf(TransportMode.METRO),
            isInterchange = false,
            latitude = 55.0433, longitude = -1.4641
        ),
        "pelaw" to Station(
            id = "pelaw", name = "Pelaw", code = "PEL",
            lines = listOf("yellow", "green"), modes = listOf(TransportMode.METRO),
            isInterchange = true,
            latitude = 54.9525, longitude = -1.5178
        ),
        "jarrow" to Station(
            id = "jarrow", name = "Jarrow", code = "JAR",
            lines = listOf("yellow"), modes = listOf(TransportMode.METRO, TransportMode.BUS),
            isInterchange = true,
            facilities = listOf("Jarrow Bus Station", "Step-free access"),
            latitude = 54.9818, longitude = -1.4886
        ),
        "hebburn" to Station(
            id = "hebburn", name = "Hebburn", code = "HEB",
            lines = listOf("yellow"), modes = listOf(TransportMode.METRO),
            isInterchange = false,
            latitude = 54.9752, longitude = -1.5199
        ),

        // Northumberland Line Only Stations (National Rail)
        "seaton_delaval" to Station(
            id = "seaton_delaval", name = "Seaton Delaval", code = "SDL",
            lines = listOf("northumberland"), modes = listOf(TransportMode.RAIL, TransportMode.WALK),
            isInterchange = false, hasParking = true, parkingCapacity = 100,
            latitude = 55.0745, longitude = -1.5422
        ),
        "newsham" to Station(
            id = "newsham", name = "Newsham", code = "NSM",
            lines = listOf("northumberland"), modes = listOf(TransportMode.RAIL),
            isInterchange = false, hasParking = true, parkingCapacity = 120,
            latitude = 55.1061, longitude = -1.5194
        ),
        "blyth_bebside" to Station(
            id = "blyth_bebside", name = "Blyth Bebside", code = "BBS",
            lines = listOf("northumberland"), modes = listOf(TransportMode.RAIL),
            isInterchange = false, hasParking = true, parkingCapacity = 160,
            latitude = 55.1278, longitude = -1.5399
        ),
        "ashington" to Station(
            id = "ashington", name = "Ashington", code = "ASH",
            lines = listOf("northumberland"), modes = listOf(TransportMode.RAIL, TransportMode.WALK),
            isInterchange = false, hasParking = true, parkingCapacity = 200,
            latitude = 55.1812, longitude = -1.5645
        ),

        // Future Washington Extension Stations (Planned)
        "follingsby" to Station(
            id = "follingsby", name = "Follingsby (Planned)", code = "FOL",
            lines = listOf("washington"), modes = listOf(TransportMode.FUTURE),
            isInterchange = false, hasParking = true, parkingCapacity = 300, isPlanned = true,
            facilities = listOf("Proposed Park & Ride (Target 2033)", "Leamside Corridor Extension"),
            latitude = 54.9255, longitude = -1.5123
        ),
        "washington_north" to Station(
            id = "washington_north", name = "Washington North (Planned)", code = "WAN",
            lines = listOf("washington"), modes = listOf(TransportMode.FUTURE),
            isInterchange = false, isPlanned = true,
            facilities = listOf("Washington Civic Centre Access (Target 2033)"),
            latitude = 54.9042, longitude = -1.5211
        ),
        "washington_south" to Station(
            id = "washington_south", name = "Washington South (Planned)", code = "WAS",
            lines = listOf("washington"), modes = listOf(TransportMode.FUTURE),
            isInterchange = false, isPlanned = true,
            facilities = listOf("Washington South Hub Connection (Target 2033)"),
            latitude = 54.8911, longitude = -1.5167
        )
    )

    // --- LINES DATASET ---
    val lines = mapOf(
        "yellow" to TransportLine(
            id = "yellow",
            name = "Yellow Line",
            mode = TransportMode.METRO,
            colorHex = "#FFCD00",
            stations = listOf(
                "st_james", "monument", "manors", "byker", "wallsend",
                "north_shields", "tynemouth", "whitley_bay", "monkseaton",
                "northumberland_park", "south_gosforth", "jesmond",
                "haymarket", "monument", "central", "gateshead",
                "heworth", "pelaw", "hebburn", "jarrow", "south_shields"
            )
        ),
        "green" to TransportLine(
            id = "green",
            name = "Green Line",
            mode = TransportMode.METRO,
            colorHex = "#0082CA", // Green Line on maps has historically used green but here we use the specified branding
            stations = listOf(
                "airport", "callerton_parkway", "bank_foot", "regent_centre",
                "south_gosforth", "jesmond", "haymarket", "monument",
                "central", "gateshead", "heworth", "pelaw",
                "stadium_of_light", "sunderland", "south_hylton"
            )
        ),
        "northumberland" to TransportLine(
            id = "northumberland",
            name = "Northumberland Line",
            mode = TransportMode.RAIL,
            colorHex = "#1E5A9E",
            stations = listOf(
                "central", "manors", "northumberland_park", "seaton_delaval", "newsham", "blyth_bebside", "ashington"
            )
        ),
        "ferry" to TransportLine(
            id = "ferry",
            name = "Shields Ferry",
            mode = TransportMode.FERRY,
            colorHex = "#0E3D60",
            stations = listOf("north_shields", "south_shields")
        ),
        "washington" to TransportLine(
            id = "washington",
            name = "Washington Extension",
            mode = TransportMode.FUTURE,
            colorHex = "#8C8C8C",
            stations = listOf("pelaw", "follingsby", "washington_north", "washington_south", "south_hylton"),
            isPlanned = true
        )
    )

    // --- FARE CALCULATION ENGINE ---
    // Rules: Zones A, B, and C. Single/Day Ticket rates as integer pence.
    // Origin & Destination determines how many zones.
    // Standard zone configuration based on geography:
    // Zone A: city centre stations (Central, Monument, Haymarket, Jesmond, St James, Manors, Gateshead, Byker)
    // Zone B: mid-distance stations (South Gosforth, Regent Centre, Heworth, Pelaw, Hebburn, Jarrow, Wallsend)
    // Zone C: outer ring (Airport, Callerton Parkway, Bank Foot, Northumberland Park, Whitley Bay, Tynemouth, Monkseaton, North Shields, South Shields, Stadium of Light, Sunderland, South Hylton)
    fun getStationZone(stationId: String): String {
        return when (stationId) {
            "central", "monument", "haymarket", "jesmond", "st_james", "manors", "gateshead", "byker" -> "A"
            "south_gosforth", "regent_centre", "heworth", "pelaw", "hebburn", "jarrow", "wallsend" -> "B"
            else -> "C"
        }
    }

    fun calculateFarePence(
        originId: String,
        destinationId: String,
        ticketType: TicketType = TicketType.SINGLE,
        passengerType: String = "ADULT"
    ): Int {
        // Northumberland Line, Ferry, Airport have special rates
        val isFerry = (originId == "north_shields" && destinationId == "south_shields") || (originId == "south_shields" && destinationId == "north_shields")
        if (isFerry) {
            return if (ticketType == TicketType.SINGLE) 210 else 340 // Ferry specific fare
        }

        val hasAirport = originId == "airport" || destinationId == "airport"
        val zonesTravelled = mutableSetOf<String>()
        zonesTravelled.add(getStationZone(originId))
        zonesTravelled.add(getStationZone(destinationId))

        // simple Zone calculation: 1, 2 or 3 zones
        val numZones = when {
            zonesTravelled.contains("A") && zonesTravelled.contains("C") -> 3
            zonesTravelled.size == 1 -> 1
            else -> 2
        }

        var basePence = when (numZones) {
            1 -> 240
            2 -> 360
            else -> 430
        }

        // Apply product type pricing modifiers
        basePence = when (ticketType) {
            TicketType.SINGLE -> basePence
            TicketType.RETURN -> (basePence * 1.8).toInt()
            TicketType.DAY_TICKET -> (basePence * 2.2).toInt()
            TicketType.WEEKLY_PASS -> 2400
            TicketType.SEASON_PASS -> 8500
            TicketType.CONCESSIONARY -> 120
            TicketType.POP_PAYG -> (basePence * 0.85).toInt() // PAYG 15% discount
        }

        // Apply airport premium if applicable
        if (hasAirport && ticketType != TicketType.CONCESSIONARY) {
            basePence += 50 // Airport surcharge of 50p
        }

        // Apply passenger type multipliers
        return when (passengerType.uppercase()) {
            "YOUTH" -> (basePence * 0.6).toInt() // 40% youth discount
            "CONCESSION" -> 120 // Concession ceiling flat rate
            else -> basePence
        }
    }

    // --- MULTIMODAL ROUTE PLANNER ---
    // Generates 1 to 3 distinct travel options based on criteria
    fun planJourney(
        originId: String,
        destinationId: String,
        preference: String = "FASTEST", // FASTEST, LOWEST_COST, ACCESSIBLE, METRO_ONLY
        currentTime: String = "14:42",
        isDisruptedState: Boolean = false,
        disruptedLineId: String? = null
    ): List<Journey> {
        val fromStation = stations[originId] ?: return emptyList()
        val toStation = stations[destinationId] ?: return emptyList()

        val results = mutableListOf<Journey>()

        // Option 1: Direct Metro / Spine journey (Primary Option)
        val directMetroSegment = getMetroRouting(originId, destinationId)
        if (directMetroSegment != null) {
            val totalMin = directMetroSegment.sumOf { it.durationMinutes }
            val fare = calculateFarePence(originId, destinationId, TicketType.POP_PAYG)
            
            // Check if any segment is affected by disruption
            var isDisrupted = false
            var disruptionMsg: String? = null
            if (isDisruptedState && disruptedLineId != null) {
                for (seg in directMetroSegment) {
                    if (seg.lineId == disruptedLineId) {
                        isDisrupted = true
                        disruptionMsg = "${lines[disruptedLineId]?.name ?: "Line"} has severe delays of +18 mins."
                    }
                }
            }

            val finalMin = if (isDisrupted) totalMin + 18 else totalMin
            val carbon = totalMin * 0.02 // very clean, 20g per minute

            val journey1 = Journey(
                id = "J-DIR-01",
                segments = directMetroSegment,
                startTime = currentTime,
                endTime = addMinutesToTime(currentTime, finalMin),
                totalDurationMinutes = finalMin,
                totalFarePence = fare,
                carbonKgEstimate = Math.round(carbon * 10.0) / 10.0,
                isDisrupted = isDisrupted,
                disruptionMessage = disruptionMsg
            )
            results.add(journey1)
        }

        // Option 2: Multimodal option (Buses / Ferry / Rail comparison)
        val multiSegments = getMultimodalRouting(originId, destinationId)
        if (multiSegments != null && multiSegments.isNotEmpty()) {
            val totalMin = multiSegments.sumOf { it.durationMinutes }
            val fare = calculateFarePence(originId, destinationId, TicketType.SINGLE) - 30 // Bus flat-rate adjustments
            val carbon = multiSegments.sumOf { seg ->
                when (seg.mode) {
                    TransportMode.WALK, TransportMode.CYCLE -> 0.0
                    TransportMode.METRO -> seg.durationMinutes * 0.02
                    TransportMode.RAIL -> seg.durationMinutes * 0.04
                    TransportMode.FERRY -> seg.durationMinutes * 0.08
                    TransportMode.BUS -> seg.durationMinutes * 0.06
                    else -> 0.0
                }
            }

            val journey2 = Journey(
                id = "J-MUL-02",
                segments = multiSegments,
                startTime = addMinutesToTime(currentTime, 3), // Leaves slightly later
                endTime = addMinutesToTime(currentTime, totalMin + 3),
                totalDurationMinutes = totalMin,
                totalFarePence = Math.max(120, fare),
                carbonKgEstimate = Math.round(carbon * 10.0) / 10.0
            )
            results.add(journey2)
        }

        // Option 3: Low Carbon Mode or Active Mode (Walking / Cycling)
        val activeSegments = getActiveRouting(originId, destinationId)
        if (activeSegments != null) {
            val totalMin = activeSegments.sumOf { it.durationMinutes }
            val journey3 = Journey(
                id = "J-ACT-03",
                segments = activeSegments,
                startTime = currentTime,
                endTime = addMinutesToTime(currentTime, totalMin),
                totalDurationMinutes = totalMin,
                totalFarePence = 0, // completely free!
                carbonKgEstimate = 0.0
            )
            results.add(journey3)
        }

        // Adjust results based on preferences
        return when (preference) {
            "LOWEST_COST" -> results.sortedBy { it.totalFarePence }
            "ACCESSIBLE" -> results.filter { j -> j.segments.none { it.mode == TransportMode.WALK && it.durationMinutes > 15 } }
            "METRO_ONLY" -> results.filter { j -> j.segments.all { it.mode == TransportMode.METRO || it.mode == TransportMode.WALK } }
            else -> results.sortedBy { it.totalDurationMinutes }
        }
    }

    private fun getMetroRouting(fromId: String, toId: String): List<RouteSegment>? {
        if (fromId == toId) return emptyList()

        val fromSt = stations[fromId] ?: return null
        val toSt = stations[toId] ?: return null

        // Shields Ferry specific routing
        if ((fromId == "north_shields" && toId == "south_shields") || (fromId == "south_shields" && toId == "north_shields")) {
            return listOf(
                RouteSegment(
                    mode = TransportMode.FERRY,
                    lineId = "ferry",
                    lineName = "Shields Ferry Crossing",
                    fromStationId = fromId,
                    fromStationName = fromSt.name,
                    toStationId = toId,
                    toStationName = toSt.name,
                    durationMinutes = 7,
                    stopCount = 1,
                    instruction = "Board the Shields Ferry crossing at the landing terminal. Fast River Tyne crossing."
                )
            )
        }

        // Simple direct line check
        val commonLines = fromSt.lines.intersect(toSt.lines)
        if (commonLines.isNotEmpty()) {
            val lineId = commonLines.first()
            val line = lines[lineId]!!
            
            val fromIndex = line.stations.indexOf(fromId)
            val toIndex = line.stations.indexOf(toId)
            
            if (fromIndex != -1 && toIndex != -1) {
                val stops = abs(toIndex - fromIndex)
                val duration = stops * 2
                val intermediate = if (fromIndex < toIndex) {
                    line.stations.subList(fromIndex + 1, toIndex)
                } else {
                    line.stations.subList(toIndex + 1, fromIndex).reversed()
                }

                return listOf(
                    RouteSegment(
                        mode = TransportMode.METRO,
                        lineId = lineId,
                        lineName = line.name,
                        fromStationId = fromId,
                        fromStationName = fromSt.name,
                        toStationId = toId,
                        toStationName = toSt.name,
                        durationMinutes = duration,
                        stopCount = stops,
                        intermediateStations = intermediate,
                        instruction = "Board the ${line.name} towards ${stations[line.stations.last()]?.name}. Ride for $stops stops."
                    )
                )
            }
        }

        // Multi-line Metro interchange (e.g. Whitley Bay -> Airport, requires change at South Gosforth or Monument)
        // Let's return a simulated 2-segment Metro route
        val changeStationId = if (fromSt.lines.contains("yellow") && toSt.lines.contains("green")) {
            "south_gosforth"
        } else {
            "monument"
        }
        val changeStation = stations[changeStationId] ?: return null

        val seg1 = getMetroRouting(fromId, changeStationId)?.firstOrNull() ?: return null
        val seg2 = getMetroRouting(changeStationId, toId)?.firstOrNull() ?: return null

        val walkTransfer = RouteSegment(
            mode = TransportMode.WALK,
            lineId = null,
            lineName = null,
            fromStationId = changeStationId,
            fromStationName = changeStation.name,
            toStationId = changeStationId,
            toStationName = changeStation.name,
            durationMinutes = 3,
            instruction = "Change platforms at ${changeStation.name}. Walk time 3 min."
        )

        return listOf(seg1, walkTransfer, seg2)
    }

    private fun getMultimodalRouting(fromId: String, toId: String): List<RouteSegment>? {
        val fromSt = stations[fromId] ?: return null
        val toSt = stations[toId] ?: return null

        val segments = mutableListOf<RouteSegment>()

        // Case A: Journey involves Northumberland Line (Rail)
        // e.g. Ashington -> Central
        if (fromId == "ashington" || toId == "ashington" || fromId == "seaton_delaval" || toId == "seaton_delaval") {
            val railLine = lines["northumberland"]!!
            val fromIdx = railLine.stations.indexOf(fromId)
            val toIdx = railLine.stations.indexOf(toId)

            if (fromIdx != -1 && toIdx != -1) {
                // Direct Rail
                val stops = abs(toIdx - fromIdx)
                segments.add(
                    RouteSegment(
                        mode = TransportMode.RAIL,
                        lineId = "northumberland",
                        lineName = "Northumberland Line",
                        fromStationId = fromId,
                        fromStationName = fromSt.name,
                        toStationId = toId,
                        toStationName = toSt.name,
                        durationMinutes = stops * 5,
                        stopCount = stops,
                        instruction = "Board the National Rail Northumberland Line stopping service."
                    )
                )
            } else {
                // Connect Ashington to Newcastle Central or Northumberland Park, then change to Metro
                val railDestId = if (toSt.lines.contains("yellow")) "northumberland_park" else "central"
                val railDest = stations[railDestId]!!
                val railIdx = railLine.stations.indexOf(fromId)
                val railDestIdx = railLine.stations.indexOf(railDestId)
                
                if (railIdx != -1 && railDestIdx != -1) {
                    segments.add(
                        RouteSegment(
                            mode = TransportMode.RAIL,
                            lineId = "northumberland",
                            lineName = "Northumberland Line",
                            fromStationId = fromId,
                            fromStationName = fromSt.name,
                            toStationId = railDestId,
                            toStationName = railDest.name,
                            durationMinutes = abs(railDestIdx - railIdx) * 5,
                            instruction = "Board Northern Rail service at ${fromSt.name} to ${railDest.name} Interchange."
                        )
                    )
                    segments.add(
                        RouteSegment(
                            mode = TransportMode.WALK,
                            lineId = null,
                            lineName = null,
                            fromStationId = railDestId,
                            fromStationName = railDest.name,
                            toStationId = railDestId,
                            toStationName = railDest.name,
                            durationMinutes = 4,
                            instruction = "Interchange to Tyne and Wear Metro platforms (4 min walk)."
                        )
                    )
                    val metroSegs = getMetroRouting(railDestId, toId)
                    if (metroSegs != null) {
                        segments.addAll(metroSegs)
                    }
                }
            }
            return segments
        }

        // Case B: Let's construct a general bus + Metro journey
        // We simulate a local regional bus route
        segments.add(
            RouteSegment(
                mode = TransportMode.WALK,
                lineId = null,
                lineName = null,
                fromStationId = fromId,
                fromStationName = fromSt.name,
                toStationId = fromId,
                toStationName = "Local Bus Stop",
                durationMinutes = 5,
                instruction = "Walk 5 mins to nearby Bus Stand."
            )
        )
        segments.add(
            RouteSegment(
                mode = TransportMode.BUS,
                lineId = "bus_gne_307",
                lineName = "Go North East 307",
                fromStationId = fromId,
                fromStationName = "Local Bus Stop",
                toStationId = toId,
                toStationName = toSt.name,
                durationMinutes = 18,
                instruction = "Board regional bus route 307. Direct service to ${toSt.name}."
            )
        )
        return segments
    }

    private fun getActiveRouting(fromId: String, toId: String): List<RouteSegment>? {
        val fromSt = stations[fromId] ?: return null
        val toSt = stations[toId] ?: return null

        // Estimate distance based on lat/lng coordinates roughly
        val latDiff = abs(fromSt.latitude - toSt.latitude)
        val lngDiff = abs(fromSt.longitude - toSt.longitude)
        val approxDistanceMiles = (latDiff + lngDiff) * 50.0 // rough scaling factor

        if (approxDistanceMiles > 10.0) return null // Too far to walk/cycle

        val mode = if (approxDistanceMiles > 2.0) TransportMode.CYCLE else TransportMode.WALK
        val duration = if (mode == TransportMode.CYCLE) {
            (approxDistanceMiles * 5).toInt() + 2
        } else {
            (approxDistanceMiles * 18).toInt() + 3
        }

        return listOf(
            RouteSegment(
                mode = mode,
                lineId = null,
                lineName = null,
                fromStationId = fromId,
                fromStationName = fromSt.name,
                toStationId = toId,
                toStationName = toSt.name,
                durationMinutes = duration,
                instruction = if (mode == TransportMode.CYCLE) {
                    "Cycle along the local regional cycle network. Well maintained routes via Tyne Quay."
                } else {
                    "Walk along designated accessible footpaths. Low gradients and signalized pedestrian crossings."
                }
            )
        )
    }

    // Helper functions
    fun addMinutesToTime(time: String, minutes: Int): String {
        return try {
            val df = SimpleDateFormat("HH:mm", Locale.UK)
            val d = df.parse(time)
            val cal = Calendar.getInstance()
            if (d != null) {
                cal.time = d
                cal.add(Calendar.MINUTE, minutes)
                df.format(cal.time)
            } else {
                time
            }
        } catch (e: Exception) {
            time
        }
    }

    fun formatPence(pence: Int): String {
        return "£" + String.format("%.2f", pence / 100.0)
    }

    // --- REAL-TIME ENGINE STATE (Mutable simulation layer) ---
    var vehiclesList = mutableListOf<Vehicle>()
    var activeDisruptions = mutableListOf<Disruption>()
    var simulationSpeedMultiplier = 1 // 1x, 10x, 100x

    init {
        // Initialize 10 simulated moving Metro trains
        resetSimulation()
    }

    fun resetSimulation() {
        vehiclesList.clear()
        activeDisruptions.clear()

        // Setup some standard moving trains
        vehiclesList.add(Vehicle("555-001", "yellow", "st_james", "monument", "south_shields", 0.2f, 0, TransportMode.METRO, 35))
        vehiclesList.add(Vehicle("555-002", "yellow", "wallsend", "north_shields", "south_shields", 0.7f, 0, TransportMode.METRO, 72))
        vehiclesList.add(Vehicle("555-003", "yellow", "tynemouth", "whitley_bay", "st_james", 0.4f, 0, TransportMode.METRO, 58))
        vehiclesList.add(Vehicle("555-004", "yellow", "gateshead", "heworth", "south_shields", 0.9f, 2, TransportMode.METRO, 88))
        vehiclesList.add(Vehicle("555-011", "green", "airport", "callerton_parkway", "south_hylton", 0.1f, 0, TransportMode.METRO, 22))
        vehiclesList.add(Vehicle("555-012", "green", "jesmond", "haymarket", "south_hylton", 0.5f, 0, TransportMode.METRO, 64))
        vehiclesList.add(Vehicle("555-013", "green", "sunderland", "south_hylton", "airport", 0.8f, 0, TransportMode.METRO, 41))
        
        // Northumberland Line rail stopping service
        vehiclesList.add(Vehicle("NT-401", "northumberland", "central", "manors", "ashington", 0.3f, 0, TransportMode.RAIL, 18))
        // Shields Ferry crossing vessel
        vehiclesList.add(Vehicle("FY-01", "ferry", "north_shields", "south_shields", "south_shields", 0.6f, 0, TransportMode.FERRY, 12))
    }

    // Progress vehicle positions by a step
    fun stepSimulation() {
        val speedFactor = 0.05f * simulationSpeedMultiplier
        vehiclesList = vehiclesList.map { v ->
            val newOffset = v.positionOffsetPercent + speedFactor
            if (newOffset >= 1.0f) {
                // Move to next station
                val currentLine = lines[v.serviceLineId]
                if (currentLine != null) {
                    val currentIdx = currentLine.stations.indexOf(v.nextStationId ?: v.currentStationId)
                    val nextIdx = if (currentIdx != -1 && currentIdx < currentLine.stations.size - 1) {
                        currentIdx + 1
                    } else {
                        0 // Loop or terminal reverse
                    }
                    val nextStation = currentLine.stations[nextIdx]
                    val futureIdx = if (nextIdx < currentLine.stations.size - 1) nextIdx + 1 else 0
                    val futureStation = currentLine.stations[futureIdx]

                    v.copy(
                        currentStationId = nextStation,
                        nextStationId = futureStation,
                        positionOffsetPercent = 0.0f,
                        // randomize passenger capacity slightly on stops
                        capacityPercent = Math.max(10, Math.min(100, v.capacityPercent + (-15..15).random()))
                    )
                } else {
                    v.copy(positionOffsetPercent = 0.0f)
                }
            } else {
                v.copy(positionOffsetPercent = newOffset)
            }
        }.toMutableList()
    }
}
