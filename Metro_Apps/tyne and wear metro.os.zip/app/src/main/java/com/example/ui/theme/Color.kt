package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Core Colors
val MetroYellow = Color(0xFFFFCD00) // Iconic Pantone 116C Metro Yellow
val MetroDarkBackground = Color(0xFF121212) // Near-black graphite
val MetroSurface = Color(0xFF1E1E1E) // Slate-charcoal
val MetroSurfaceVariant = Color(0xFF2D2D2D) // Lighter slate
val MetroBorder = Color(0xFF3D3D3D) // Soft divider

// Typography Contrast
val MetroTextPrimary = Color(0xFFFFFFFF)
val MetroTextSecondary = Color(0xFFB3B3B3)
val MetroTextMuted = Color(0xFF767676)
val MetroOnYellow = Color(0xFF121212)

// Multi-modal Transport Colors (As defined in Product Specification)
val ColorMetro = Color(0xFFFFCD00) // Metro Yellow
val ColorRail = Color(0xFF1E5A9E)  // Restrained rail blue
val ColorBus = Color(0xFF0082CA)   // Regional blue
val ColorFerry = Color(0xFF0E3D60)  // Deep marine blue
val ColorWalk = Color(0xFF7B8C96)   // Neutral grey
val ColorCycle = Color(0xFF1D783B)  // Restrained green
val ColorAirport = Color(0xFF00A3A6) // Aviation turquoise
val ColorFuture = Color(0xFF8C8C8C)  // Muted grey for Washington extension
val ColorAlert = Color(0xFFE53935)   // Delays and disruptions alert
val ColorGoodService = Color(0xFF4CAF50) // On time / Normal operations
