package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.AppScreen
import com.example.viewmodel.TransportViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppShell()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppShell() {
    val viewModel: TransportViewModel = viewModel()
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Intercept system back clicks to pop the navigation screen stack safely
    BackHandler(enabled = currentScreen != AppScreen.HOME) {
        viewModel.navigateBack()
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        val isWideScreen = maxWidth > 600.dp

        Scaffold(
            topBar = {
                // If we are on details screens (STATION_DETAIL, CONTROL_ROOM), show a TopBar with back navigation
                if (currentScreen == AppScreen.STATION_DETAIL || currentScreen == AppScreen.CONTROL_ROOM) {
                    TopAppBar(
                        title = {
                            Text(
                                text = if (currentScreen == AppScreen.STATION_DETAIL) "STATION DETAIL" else "METRO CONTROL ROOM",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = { viewModel.navigateBack() },
                                modifier = Modifier.testTag("top_bar_back_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Navigate Back",
                                    tint = MetroYellow
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = MetroSurface)
                    )
                }
            },
            bottomBar = {
                // Show bottom bar on mobile screens ONLY, and only on core screens
                if (!isWideScreen) {
                    NavigationBar(
                        containerColor = MetroSurface,
                        tonalElevation = 8.dp,
                        modifier = Modifier.testTag("mobile_bottom_nav_bar")
                    ) {
                        val items = listOf(
                            NavigationItem(AppScreen.HOME, "Home", Icons.Default.Home, "nav_home_tab"),
                            NavigationItem(AppScreen.PLANNER, "Plan", Icons.Default.Route, "nav_plan_tab"),
                            NavigationItem(AppScreen.MAP, "Map", Icons.Default.Map, "nav_map_tab"),
                            NavigationItem(AppScreen.TICKETS, "Tickets", Icons.Default.ConfirmationNumber, "nav_tickets_tab"),
                            NavigationItem(AppScreen.MY_METRO, "My Pop", Icons.Default.Contactless, "nav_pop_tab")
                        )

                        items.forEach { item ->
                            val isSelected = currentScreen == item.screen
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { viewModel.navigateTo(item.screen) },
                                icon = { Icon(item.icon, contentDescription = item.label) },
                                label = { Text(item.label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MetroOnYellow,
                                    selectedTextColor = MetroYellow,
                                    indicatorColor = MetroYellow,
                                    unselectedIconColor = MetroTextSecondary,
                                    unselectedTextColor = MetroTextSecondary
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Show Left Navigation Rail on Tablet / Wide Screens
                if (isWideScreen) {
                    NavigationRail(
                        containerColor = MetroSurface,
                        header = {
                            Text(
                                "M",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black,
                                color = MetroYellow,
                                modifier = Modifier.padding(bottom = 24.dp)
                            )
                        },
                        modifier = Modifier.testTag("wide_nav_rail")
                    ) {
                        val items = listOf(
                            NavigationItem(AppScreen.HOME, "Home", Icons.Default.Home, "nav_home_tab_rail"),
                            NavigationItem(AppScreen.PLANNER, "Plan", Icons.Default.Route, "nav_plan_tab_rail"),
                            NavigationItem(AppScreen.MAP, "Map", Icons.Default.Map, "nav_map_tab_rail"),
                            NavigationItem(AppScreen.TICKETS, "Tickets", Icons.Default.ConfirmationNumber, "nav_tickets_tab_rail"),
                            NavigationItem(AppScreen.MY_METRO, "My Pop", Icons.Default.Contactless, "nav_pop_tab_rail")
                        )

                        items.forEach { item ->
                            val isSelected = currentScreen == item.screen
                            NavigationRailItem(
                                selected = isSelected,
                                onClick = { viewModel.navigateTo(item.screen) },
                                icon = { Icon(item.icon, contentDescription = item.label) },
                                label = { Text(item.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = MetroOnYellow,
                                    selectedTextColor = MetroYellow,
                                    indicatorColor = MetroYellow,
                                    unselectedIconColor = MetroTextSecondary,
                                    unselectedTextColor = MetroTextSecondary
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                // Main Screen Panel Content
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    when (currentScreen) {
                        AppScreen.HOME -> HomeScreen(viewModel = viewModel)
                        AppScreen.PLANNER -> PlannerScreen(viewModel = viewModel)
                        AppScreen.MAP -> MapScreen(viewModel = viewModel)
                        AppScreen.TICKETS -> TicketsScreen(viewModel = viewModel)
                        AppScreen.MY_METRO -> MyMetroScreen(viewModel = viewModel)
                        AppScreen.STATION_DETAIL -> StationDetailScreen(viewModel = viewModel)
                        AppScreen.CONTROL_ROOM -> ControlRoomScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

data class NavigationItem(
    val screen: AppScreen,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val testTag: String
)
