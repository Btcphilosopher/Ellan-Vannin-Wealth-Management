package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransportData
import com.example.model.TransportMode
import com.example.ui.theme.*
import com.example.viewmodel.AppScreen
import com.example.viewmodel.TransportViewModel

@Composable
fun HomeScreen(viewModel: TransportViewModel) {
    val liveJourney by viewModel.liveJourneyState.collectAsState()
    val disruptions by viewModel.disruptions.collectAsState()
    val popCard by viewModel.popCard.collectAsState()
    val activeTapInStationId by viewModel.activeTapInStationId.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- HEADER TITLE ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "METRO.OS",
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = MetroYellow
                        ),
                        modifier = Modifier.testTag("app_brand_title")
                    )
                    Text(
                        text = "TYNE & WEAR OPERATING SYSTEM",
                        style = MaterialTheme.typography.labelMedium,
                        color = MetroTextSecondary
                    )
                }
                
                // Control Room indicator button
                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.CONTROL_ROOM) },
                    modifier = Modifier
                        .size(44.dp)
                        .background(MetroSurfaceVariant, CircleShape)
                        .testTag("control_room_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.SettingsInputAntenna,
                        contentDescription = "Control Room",
                        tint = MetroYellow
                    )
                }
            }
        }

        // --- NETWORK STATUS BANNER ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MetroSurface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (disruptions.isEmpty()) ColorGoodService else ColorAlert)
                        )
                        Text(
                            text = if (disruptions.isEmpty()) "ALL NETWORKS RUNNING" else "NETWORK ALERT: ACTIVE DELAYS",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (disruptions.isEmpty()) ColorGoodService else ColorAlert
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatusIndicator(name = "Yellow Line", status = if (disruptions.any { it.affectedLineId == "yellow" }) "Delays" else "Normal", isGood = !disruptions.any { it.affectedLineId == "yellow" })
                        StatusIndicator(name = "Green Line", status = if (disruptions.any { it.affectedLineId == "green" }) "Delays" else "Normal", isGood = !disruptions.any { it.affectedLineId == "green" })
                        StatusIndicator(name = "Ferry", status = "Normal", isGood = true)
                    }
                }
            }
        }

        // --- QUICK POP PAYG TAP STATUS ---
        if (activeTapInStationId != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MetroYellow)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(
                                imageVector = Icons.Default.DirectionsTransit,
                                contentDescription = "Active Ride",
                                tint = MetroOnYellow,
                                modifier = Modifier.size(28.dp)
                            )
                            Column {
                                Text(
                                    text = "ACTIVE TRIP",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MetroOnYellow.copy(alpha = 0.7f)
                                )
                                Text(
                                    text = "Riding from ${TransportData.stations[activeTapInStationId]?.name}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MetroOnYellow
                                )
                            }
                        }
                        
                        Button(
                            onClick = { viewModel.tapPopCard(activeTapInStationId!!) },
                            colors = ButtonDefaults.buttonColors(containerColor = MetroDarkBackground, contentColor = Color.White),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("tap_out_shortcut_btn")
                        ) {
                            Text("TAP OUT")
                        }
                    }
                }
            }
        }

        // --- WHERE TO SEARCH / PLANNER ---
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo(AppScreen.PLANNER) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MetroSurfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = MetroYellow,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "Where do you want to go?",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Plan multi-modal journeys across the North East",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MetroTextSecondary
                        )
                    }
                }
            }
        }

        // --- ACTIVE LIVE JOURNEY MODE ---
        if (liveJourney.isTracking && liveJourney.activeJourney != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MetroSurface),
                    border = BorderStroke(1.dp, MetroYellow)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Navigation,
                                    contentDescription = "Active Navigation",
                                    tint = MetroYellow,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "LIVE JOURNEY TRACKER",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MetroYellow
                                )
                            }
                            IconButton(onClick = { viewModel.cancelLiveJourney() }) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = MetroTextMuted)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Text(
                            text = "Current Station: ${liveJourney.currentStationName}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Next Connection: ${liveJourney.nextStationName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MetroTextSecondary
                        )
                        
                        if (liveJourney.stopsRemaining > 0) {
                            Text(
                                text = "${liveJourney.stopsRemaining} stops remaining",
                                style = MaterialTheme.typography.labelMedium,
                                color = MetroYellow
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        
                        LinearProgressIndicator(
                            progress = { 0.5f },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = MetroYellow,
                            trackColor = MetroBorder
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { viewModel.advanceLiveJourney() },
                            colors = ButtonDefaults.buttonColors(containerColor = MetroYellow, contentColor = MetroOnYellow),
                            modifier = Modifier.fillMaxWidth().testTag("advance_journey_btn")
                        ) {
                            Text("ADVANCE JOURNEY STEP")
                        }
                    }
                }
            }
        }

        // --- CORE NAVIGATION GRID ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = "Plan Journey",
                    subtitle = "Schedules & Fares",
                    icon = Icons.Default.Route,
                    color = ColorMetro,
                    modifier = Modifier.weight(1f).testTag("home_nav_plan")
                ) { viewModel.navigateTo(AppScreen.PLANNER) }

                QuickActionCard(
                    title = "Network Map",
                    subtitle = "Live Vehicles",
                    icon = Icons.Default.Map,
                    color = ColorRail,
                    modifier = Modifier.weight(1f).testTag("home_nav_map")
                ) { viewModel.navigateTo(AppScreen.MAP) }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = "My Pop PAYG",
                    subtitle = "Balance: ${TransportData.formatPence(popCard.balancePence)}",
                    icon = Icons.Default.Contactless,
                    color = ColorBus,
                    modifier = Modifier.weight(1f).testTag("home_nav_pop")
                ) { viewModel.navigateTo(AppScreen.MY_METRO) }

                QuickActionCard(
                    title = "Tickets",
                    subtitle = "Digital Wallet",
                    icon = Icons.Default.ConfirmationNumber,
                    color = ColorFerry,
                    modifier = Modifier.weight(1f).testTag("home_nav_tickets")
                ) { viewModel.navigateTo(AppScreen.TICKETS) }
            }
        }

        // --- FAVOURITE STATIONS DEPARTURES ---
        item {
            Text(
                text = "FAVOURITE STATIONS & DEPARTURES",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = MetroTextSecondary
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("monument", "central", "sunderland", "airport").forEach { sId ->
                    val station = TransportData.stations[sId]!!
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MetroSurface)
                            .clickable { viewModel.viewStationDetails(sId) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(MetroSurfaceVariant, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (sId == "airport") Icons.Default.LocalAirport else Icons.Default.DirectionsSubway,
                                    contentDescription = null,
                                    tint = MetroYellow,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column {
                                Text(text = station.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text(
                                    text = station.lines.joinToString(" • ") { TransportData.lines[it]?.name ?: it },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MetroTextSecondary
                                )
                            }
                        }
                        
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = "View departures", style = MaterialTheme.typography.labelMedium, color = MetroYellow)
                            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = MetroYellow, modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusIndicator(name: String, status: String, isGood: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(if (isGood) ColorGoodService else ColorAlert)
        )
        Text(text = "$name: ", style = MaterialTheme.typography.bodySmall, color = MetroTextSecondary)
        Text(text = status, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = if (isGood) ColorGoodService else ColorAlert)
    }
}

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(100.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MetroSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Column {
                Text(text = title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Text(text = subtitle, style = MaterialTheme.typography.labelMedium, color = MetroTextSecondary)
            }
        }
    }
}
