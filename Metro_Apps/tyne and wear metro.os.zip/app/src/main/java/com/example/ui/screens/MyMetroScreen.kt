package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransportData
import com.example.ui.theme.*
import com.example.viewmodel.TransportViewModel

@Composable
fun MyMetroScreen(viewModel: TransportViewModel) {
    val popCard by viewModel.popCard.collectAsState()
    val activeTapInStationId by viewModel.activeTapInStationId.collectAsState()

    var showTapDialog by remember { mutableStateOf(false) }
    var selectedTapStationId by remember { mutableStateOf("monument") }

    val allStationsList = TransportData.stations.values.toList()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- HEADER ---
        item {
            Column {
                Text(
                    text = "REGIONAL MOBILITY",
                    style = MaterialTheme.typography.labelMedium,
                    color = MetroYellow
                )
                Text(
                    text = "My Pop Card",
                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.ExtraBold)
                )
            }
        }

        // --- VISUAL POP SMART CARD ---
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(MetroYellow, Color(0xFFE5A900), MetroDarkBackground)
                        )
                    )
                    .padding(20.dp)
                    .testTag("pop_card_visual")
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "POP",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MetroDarkBackground,
                                letterSpacing = 2.sp
                            )
                            Text(
                                text = "Pay As You Go",
                                style = MaterialTheme.typography.labelMedium,
                                color = MetroDarkBackground.copy(alpha = 0.8f)
                            )
                        }

                        // Contactless Wave Icon Representation
                        Icon(
                            imageVector = Icons.Default.Contactless,
                            contentDescription = "Contactless Smartcard",
                            tint = MetroDarkBackground,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "BALANCE",
                            style = MaterialTheme.typography.labelSmall,
                            color = MetroDarkBackground.copy(alpha = 0.7f)
                        )
                        Text(
                            text = TransportData.formatPence(popCard.balancePence),
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Black,
                            color = MetroDarkBackground
                        )
                        
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        Text(
                            text = popCard.cardNumber,
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // --- TOP UP CONTROLS ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MetroSurface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ADD FUNDS TO POP CARD",
                        style = MaterialTheme.typography.labelMedium,
                        color = MetroYellow
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(500, 1000, 2000).forEach { amount ->
                            Button(
                                onClick = { viewModel.topUpPopCard(amount) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("top_up_btn_$amount"),
                                colors = ButtonDefaults.buttonColors(containerColor = MetroSurfaceVariant, contentColor = Color.White),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("+${TransportData.formatPence(amount)}")
                            }
                        }
                    }
                }
            }
        }

        // --- TAP IN / OUT SIMULATOR LAYER ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MetroSurface),
                border = if (activeTapInStationId != null) BorderStroke(1.dp, MetroYellow) else null
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SIMULATE CONTACTLESS TAP-IN/OUT",
                        style = MaterialTheme.typography.labelMedium,
                        color = MetroYellow
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))

                    if (activeTapInStationId == null) {
                        Text(
                            text = "Currently outside the barrier system. Choose a station to simulate tap-in.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MetroTextSecondary
                        )
                    } else {
                        val originName = TransportData.stations[activeTapInStationId]?.name
                        Text(
                            text = "TAPPED-IN at $originName. Travel through the network and choose a station to tap-out.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ColorGoodService,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Dropdown selection for tapping station
                        Box(modifier = Modifier.weight(1.5f)) {
                            var exp by remember { mutableStateOf(false) }
                            OutlinedButton(
                                onClick = { exp = true },
                                modifier = Modifier.fillMaxWidth().testTag("tap_station_selector"),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                border = BorderStroke(1.dp, MetroBorder)
                            ) {
                                Text(TransportData.stations[selectedTapStationId]?.name ?: selectedTapStationId)
                            }
                            DropdownMenu(
                                expanded = exp,
                                onDismissRequest = { exp = false },
                                modifier = Modifier.fillMaxWidth(0.6f).background(MetroSurface)
                            ) {
                                allStationsList.forEach { station ->
                                    DropdownMenuItem(
                                        text = { Text(station.name, color = Color.White) },
                                        onClick = {
                                            selectedTapStationId = station.id
                                            exp = false
                                        }
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = { viewModel.tapPopCard(selectedTapStationId) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("sim_tap_action_btn"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeTapInStationId == null) MetroYellow else ColorAlert,
                                contentColor = if (activeTapInStationId == null) MetroOnYellow else Color.White
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (activeTapInStationId == null) "TAP IN" else "TAP OUT")
                        }
                    }
                }
            }
        }

        // --- TRANSACTION HISTORY ---
        item {
            Text(
                text = "RECENT TRANSIT TRANSACTIONS",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                color = MetroTextSecondary
            )
        }

        if (popCard.recentTransactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No history recorded yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MetroTextSecondary
                    )
                }
            }
        } else {
            items(popCard.recentTransactions) { trans ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MetroSurface)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val icon = when (trans.type) {
                            "TAP_IN" -> Icons.Default.Login
                            "TAP_OUT" -> Icons.Default.Logout
                            "TOP_UP" -> Icons.Default.AddCard
                            else -> Icons.Default.DirectionsTransit
                        }
                        val iconColor = when (trans.type) {
                            "TOP_UP" -> ColorGoodService
                            "TAP_IN" -> MetroYellow
                            "TAP_OUT" -> ColorFerry
                            else -> ColorRail
                        }

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(iconColor.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(16.dp))
                        }

                        Column {
                            Text(text = trans.description, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text(text = trans.timestamp, style = MaterialTheme.typography.bodySmall, color = MetroTextSecondary)
                        }
                    }

                    Text(
                        text = if (trans.amountPence > 0) "+${TransportData.formatPence(trans.amountPence)}" else TransportData.formatPence(trans.amountPence),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (trans.amountPence > 0) ColorGoodService else if (trans.amountPence < 0) Color.White else MetroTextSecondary
                    )
                }
            }
        }
    }
}
