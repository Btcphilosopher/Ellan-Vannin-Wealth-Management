package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.TransportData
import com.example.model.TicketType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34]) // Compatible Robolectric SDK setting
class ExampleRobolectricTest {

    @Test
    fun `verify app name resource`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("METRO.OS", appName)
    }

    @Test
    fun `verify fare calculator with zones`() {
        // Newcastle Central to Monument (both Zone A) -> Should be 1 Zone Single fare
        val centralToMonument = TransportData.calculateFarePence("central", "monument", TicketType.SINGLE)
        assertEquals(240, centralToMonument)

        // Newcastle Central to Sunderland (Zone A to Zone C) -> Should be 3 Zones Single fare
        val centralToSunderland = TransportData.calculateFarePence("central", "sunderland", TicketType.SINGLE)
        assertEquals(430, centralToSunderland)

        // Newcastle Central to Newcastle Airport (Zone A to Zone C with airport premium)
        val centralToAirport = TransportData.calculateFarePence("central", "airport", TicketType.SINGLE)
        assertEquals(480, centralToAirport) // 430 base + 50 airport surcharge
    }

    @Test
    fun `verify POP PAYG discount rate`() {
        // PAYG should apply a 15% discount on the standard zone rate
        val normalSingle = TransportData.calculateFarePence("central", "sunderland", TicketType.SINGLE)
        val popPaygSingle = TransportData.calculateFarePence("central", "sunderland", TicketType.POP_PAYG)
        
        assertEquals(430, normalSingle)
        assertEquals(365, popPaygSingle) // 430 * 0.85 = 365.5 -> 365 integer pence
    }

    @Test
    fun `verify multi-modal routing engine`() {
        // Newcastle Central to Tynemouth direct Metro Yellow Line
        val journeys = TransportData.planJourney("central", "tynemouth")
        
        assertTrue(journeys.isNotEmpty())
        val firstJourney = journeys.first()
        
        // Duration should be positive and segments should map correctly
        assertTrue(firstJourney.totalDurationMinutes > 0)
        assertTrue(firstJourney.segments.first().fromStationId == "central")
    }
}
