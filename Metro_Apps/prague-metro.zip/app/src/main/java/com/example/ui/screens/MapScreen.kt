package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    onBackClick: () -> Unit
) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SCHEMATIC NETWORK MAP", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PragueGraphite)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.5f, 4f)
                        offset += pan
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val centerOffset = offset + Offset(size.width / 2f, size.height / 2f)

                // Draw Line A (Green)
                drawLine(
                    color = LineAGreen,
                    start = centerOffset + Offset(-300f * scale, -100f * scale),
                    end = centerOffset + Offset(300f * scale, 100f * scale),
                    strokeWidth = 10f * scale
                )

                // Draw Line B (Yellow)
                drawLine(
                    color = LineBYellow,
                    start = centerOffset + Offset(-250f * scale, 200f * scale),
                    end = centerOffset + Offset(250f * scale, -200f * scale),
                    strokeWidth = 10f * scale
                )

                // Draw Line C (Red)
                drawLine(
                    color = LineCRed,
                    start = centerOffset + Offset(0f, -300f * scale),
                    end = centerOffset + Offset(0f, 300f * scale),
                    strokeWidth = 10f * scale
                )

                // Draw Interchange Hub (Můstek / Muzeum / Florenc)
                drawCircle(
                    color = Color.White,
                    radius = 12f * scale,
                    center = centerOffset
                )
                drawCircle(
                    color = CzechRed,
                    radius = 8f * scale,
                    center = centerOffset,
                    style = Stroke(width = 3f)
                )
            }

            // Legend / Info Overlay
            Card(
                modifier = Modifier
                    .padding(16.dp)
                    .align(androidx.compose.ui.Alignment.BottomStart),
                colors = CardDefaults.cardColors(containerColor = PragueCharcoal)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(text = "PRAGUE METRO LINES", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(text = "— Line A (Nemocnice Motol ↔ Depo Hostivař)", color = LineAGreen, fontSize = 11.sp)
                    Text(text = "— Line B (Zličín ↔ Černý Most)", color = LineBYellow, fontSize = 11.sp)
                    Text(text = "— Line C (Letňany ↔ Háje)", color = LineCRed, fontSize = 11.sp)
                }
            }
        }
    }
}
