package com.example.domain.model

data class MetroLine(
    val id: String,
    val code: String, // "A", "B", "C"
    val name: String,
    val colorHex: String,
    val origin: String,
    val destination: String,
    val status: LineStatus = LineStatus.NORMAL
)

enum class LineStatus {
    NORMAL, MINOR_DELAYS, MAJOR_DELAYS, SUSPENDED
}

data class Station(
    val id: String,
    val name: String,
    val officialName: String,
    val lineCodes: List<String>, // e.g. ["A", "C"] for Muzeum
    val latitude: Double,
    val longitude: Double,
    val isInterchange: Boolean = false,
    val interchangeLines: List<String> = emptyList(),
    val accessibility: AccessibilityStatus = AccessibilityStatus(),
    val facilities: List<String> = emptyList(),
    val entrances: List<StationEntrance> = emptyList()
)

data class StationEntrance(
    val id: String,
    val stationId: String,
    val name: String,
    val street: String,
    val latitude: Double,
    val longitude: Double,
    val hasElevator: Boolean = false,
    val hasEscalator: Boolean = false,
    val distanceMeters: Int = 0
)

data class AccessibilityStatus(
    val stepFree: Boolean = true,
    val elevatorOperational: Boolean = true,
    val wheelchairAccessible: Boolean = true,
    val notes: String = ""
)

data class Departure(
    val id: String,
    val stationId: String,
    val lineCode: String,
    val destination: String,
    val platform: String,
    val scheduledTime: String,
    val estimatedTime: String,
    val delayMinutes: Int = 0,
    val isCancelled: Boolean = false,
    val isRealtime: Boolean = true,
    val quality: DataQuality = DataQuality.LIVE,
    val timestamp: Long = System.currentTimeMillis()
)

enum class DataQuality {
    LIVE, RECENT, STALE, TIMETABLE, DEMO
}

data class ServiceAlert(
    val id: String,
    val title: String,
    val description: String,
    val severity: AlertSeverity,
    val affectedLines: List<String>,
    val affectedStations: List<String> = emptyList(),
    val startTime: Long,
    val endTime: Long? = null,
    val alternativeText: String = ""
)

enum class AlertSeverity {
    INFO, MINOR, MAJOR, CRITICAL
}

data class InterchangeInfo(
    val stationId: String,
    val stationName: String,
    val fromLine: String,
    val toLine: String,
    val walkingTimeMinutes: Int,
    val walkingDistanceMeters: Int,
    val stepsDescription: List<String>
)

data class JourneyLeg(
    val type: LegType,
    val lineCode: String? = null,
    val originStationName: String,
    val destinationStationName: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val stopsCount: Int = 0,
    val instructions: String = ""
)

enum class LegType {
    WALK, METRO, TRANSFER, TRAM, BUS
}

data class Journey(
    val id: String,
    val fromStationId: String,
    val fromStationName: String,
    val toStationId: String,
    val toStationName: String,
    val totalDurationMinutes: Int,
    val transferCount: Int,
    val totalWalkingMeters: Int,
    val isAccessible: Boolean,
    val legs: List<JourneyLeg>
)

data class FareProduct(
    val id: String,
    val name: String,
    val priceCZK: Int,
    val validityMinutes: Int,
    val description: String,
    val zones: String = "P, 0, B"
)

data class DigitalTicket(
    val id: String,
    val productId: String,
    val productName: String,
    val priceCZK: Int,
    val validFrom: Long,
    val validUntil: Long,
    val status: TicketStatus,
    val qrCodePayload: String
)

enum class TicketStatus {
    NOT_YET_VALID, VALID, EXPIRED, CANCELLED
}

data class VehiclePosition(
    val trainId: String,
    val lineCode: String,
    val currentStationName: String,
    val nextStationName: String,
    val direction: String,
    val delaySeconds: Int,
    val updatedAt: Long
)
