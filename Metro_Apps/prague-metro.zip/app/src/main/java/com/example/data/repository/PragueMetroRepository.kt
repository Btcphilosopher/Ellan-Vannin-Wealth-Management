package com.example.data.repository

import com.example.domain.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object PragueMetroRepository {

    private val _lines = listOf(
        MetroLine(
            id = "line_a",
            code = "A",
            name = "Linka A",
            colorHex = "#00875A",
            origin = "Nemocnice Motol",
            destination = "Depo Hostivař",
            status = LineStatus.NORMAL
        ),
        MetroLine(
            id = "line_b",
            code = "B",
            name = "Linka B",
            colorHex = "#E5A900",
            origin = "Zličín",
            destination = "Černý Most",
            status = LineStatus.NORMAL
        ),
        MetroLine(
            id = "line_c",
            code = "C",
            name = "Linka C",
            colorHex = "#C62828",
            origin = "Letňany",
            destination = "Háje",
            status = LineStatus.NORMAL
        )
    )

    private val _stations = listOf(
        // Line A stations
        Station("a_motol", "Nemocnice Motol", "Nemocnice Motol", listOf("A"), 50.0755, 14.3412, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Toilets", "Ticket machine")),
        Station("a_petriny", "Petřiny", "Petřiny", listOf("A"), 50.0853, 14.3524, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Ticket machine")),
        Station("a_veleslavin", "Nádraží Veleslavín", "Nádraží Veleslavín", listOf("A"), 50.0945, 14.3565, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Train connection", "Bus to Airport")),
        Station("a_borislavka", "Bořislavka", "Bořislavka", listOf("A"), 50.1002, 14.3644, false, emptyList(), AccessibilityStatus(true, true, true)),
        Station("a_dejvicka", "Dejvická", "Dejvická", listOf("A"), 50.1001, 14.3952, false, emptyList(), AccessibilityStatus(true, false, true, "Elevator B maintenance"), listOf("Tram connection")),
        Station("a_hradcanska", "Hradčanská", "Hradčanská", listOf("A"), 50.0964, 14.4048, false, emptyList(), AccessibilityStatus(false, false, false, "Historic station - stairs only"), listOf("Tram connection", "Train connection")),
        Station("a_malostranska", "Malostranská", "Malostranská", listOf("A"), 50.0903, 14.4109, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Tram connection")),
        Station("a_staromestska", "Staroměstská", "Staroměstská", listOf("A"), 50.0886, 14.4168, false, emptyList(), AccessibilityStatus(true, true, true)),
        Station("a_mustek", "Můstek", "Můstek", listOf("A", "B"), 50.0837, 14.4231, true, listOf("A", "B"), AccessibilityStatus(true, true, true), listOf("Interchange A/B", "Information", "Toilets"),
            listOf(StationEntrance("ent_vaclav", "a_mustek", "Václavské náměstí", "Wenceslas Square", 50.0834, 14.4240, true, true, 120),
                 StationEntrance("ent_mustek_b", "a_mustek", "Na Můstku", "Na Můstku", 50.0842, 14.4222, false, true, 190))),
        Station("a_muzeum", "Muzeum", "Muzeum", listOf("A", "C"), 50.0782, 14.4300, true, listOf("A", "C"), AccessibilityStatus(true, true, true), listOf("Interchange A/C", "National Museum"),
            listOf(StationEntrance("ent_muz_top", "a_muzeum", "Muzeum Horní", "Wenceslas Sq. top", 50.0790, 14.4295, true, true, 90))),
        Station("a_namesti_miru", "Náměstí Míru", "Náměstí Míru", listOf("A"), 50.0754, 14.4379, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Deepest station (53m)", "Longest escalator")),
        Station("a_jiriho_podebrad", "Jiřího z Poděbrad", "Jiřího z Poděbrad", listOf("A"), 50.0779, 14.4485, false, emptyList(), AccessibilityStatus(true, true, true)),
        Station("a_flora", "Flora", "Flora", listOf("A"), 50.0776, 14.4589, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Shopping mall access")),
        Station("a_zelivskeho", "Želivského", "Želivského", listOf("A"), 50.0783, 14.4714, false, emptyList(), AccessibilityStatus(true, true, true)),
        Station("a_strasnicka", "Strašnická", "Strašnická", listOf("A"), 50.0725, 14.4851, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Tram connection")),
        Station("a_skalka", "Skalka", "Skalka", listOf("A"), 50.0682, 14.5032, false, emptyList(), AccessibilityStatus(true, true, true)),
        Station("a_depo_hostivar", "Depo Hostivař", "Depo Hostivař", listOf("A"), 50.0691, 14.5152, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Terminal depot")),

        // Line B stations (subset of key terminals and intersections)
        Station("b_zlicin", "Zličín", "Zličín", listOf("B"), 50.0559, 14.2882, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Terminal B", "Park & Ride")),
        Station("b_andel", "Anděl", "Anděl", listOf("B"), 50.0706, 14.4042, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Tram interchange", "Commercial hub")),
        Station("b_florenc", "Florenc", "Florenc", listOf("B", "C"), 50.0913, 14.4423, true, listOf("B", "C"), AccessibilityStatus(true, true, true), listOf("Interchange B/C", "Central Bus Station"),
            listOf(StationEntrance("ent_florenc_main", "b_florenc", "Hlavní budova", "Křižíkova", 50.0918, 14.4420, true, true, 80))),
        Station("b_cerny_most", "Černý Most", "Černý Most", listOf("B"), 50.1102, 14.5828, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Terminal B east", "Bus terminal")),

        // Line C stations (subset)
        Station("c_letnany", "Letňany", "Letňany", listOf("C"), 50.1303, 14.5133, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Terminal C north", "Exhibition centre")),
        Station("c_holesovice", "Nádraží Holešovice", "Nádraží Holešovice", listOf("C"), 50.1085, 14.4428, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Rail connection", "Tram connection")),
        Station("c_hlavni_nadrazi", "Hlavní nádraží", "Hlavní nádraží", listOf("C"), 50.0831, 14.4354, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Main Railway Station", "Express trains to Airport", "EuroCity trains")),
        Station("c_haje", "Háje", "Háje", listOf("C"), 50.0275, 14.5298, false, emptyList(), AccessibilityStatus(true, true, true), listOf("Terminal C south"))
    ).distinctBy { it.id }

    private val _departures = mutableMapOf<String, List<Departure>>(
        "a_mustek" to listOf(
            Departure("dep_1", "a_mustek", "A", "Nemocnice Motol", "Platform 1", "14:10", "14:10", 0, false, true, DataQuality.LIVE),
            Departure("dep_2", "a_mustek", "A", "Depo Hostivař", "Platform 2", "14:12", "14:14", 2, false, true, DataQuality.LIVE),
            Departure("dep_3", "a_mustek", "B", "Zličín", "Platform 1", "14:11", "14:11", 0, false, true, DataQuality.LIVE),
            Departure("dep_4", "a_mustek", "B", "Černý Most", "Platform 2", "14:15", "14:18", 3, false, true, DataQuality.LIVE)
        ),
        "a_muzeum" to listOf(
            Departure("dep_5", "a_muzeum", "A", "Nemocnice Motol", "Platform 1", "14:11", "14:11", 0, false, true, DataQuality.LIVE),
            Departure("dep_6", "a_muzeum", "A", "Depo Hostivař", "Platform 2", "14:13", "14:13", 0, false, true, DataQuality.LIVE),
            Departure("dep_7", "a_muzeum", "C", "Letňany", "Platform 1", "14:09", "14:12", 3, false, true, DataQuality.LIVE),
            Departure("dep_8", "a_muzeum", "C", "Háje", "Platform 2", "14:14", "14:14", 0, false, true, DataQuality.LIVE)
        ),
        "b_florenc" to listOf(
            Departure("dep_9", "b_florenc", "B", "Zličín", "Platform 1", "14:12", "14:12", 0, false, true, DataQuality.LIVE),
            Departure("dep_10", "b_florenc", "B", "Černý Most", "Platform 2", "14:14", "14:16", 2, false, true, DataQuality.LIVE),
            Departure("dep_11", "b_florenc", "C", "Letňany", "Platform 1", "14:11", "14:11", 0, false, true, DataQuality.LIVE),
            Departure("dep_12", "b_florenc", "C", "Háje", "Platform 2", "14:13", "14:13", 0, false, true, DataQuality.LIVE)
        )
    )

    private val _serviceAlerts = listOf(
        ServiceAlert(
            id = "alert_1",
            title = "Dejvická Elevator Maintenance",
            description = "The main street elevator at Dejvická (Line A) is temporarily out of service for scheduled technical inspection. Step-free access is available via alternative entrance or Bořislavka.",
            severity = AlertSeverity.MINOR,
            affectedLines = listOf("A"),
            affectedStations = listOf("a_dejvicka"),
            startTime = System.currentTimeMillis() - 3600000,
            alternativeText = "Use Bořislavka or alternative street ramps."
        )
    )

    private val _fareProducts = listOf(
        FareProduct("fare_30m", "30-minute Ticket (P, 0, B)", 40, 30, "Standard short transfer ticket valid within Prague zones."),
        FareProduct("fare_90m", "90-minute Ticket (P, 0, B)", 50, 90, "Standard 90-minute transfer ticket for all city transport."),
        FareProduct("fare_24h", "24-hour Pass", 120, 1440, "Unlimited travel across Prague Metro, trams, buses and ferries for 24 hours."),
        FareProduct("fare_72h", "72-hour Pass", 330, 4320, "3-day tourist pass for all PID services.")
    )

    val interchanges = listOf(
        InterchangeInfo("a_mustek", "Můstek", "A", "B", 3, 180, listOf("Exit platform A", "Follow yellow corridor signs", "Take descending stairs to Line B platform")),
        InterchangeInfo("a_muzeum", "Muzeum", "A", "C", 3, 210, listOf("Exit platform A", "Follow red overhead signs to Line C", "Walk through connecting pedestrian subway")),
        InterchangeInfo("b_florenc", "Florenc", "B", "C", 3, 190, listOf("Exit Line B platform", "Follow corridor to Line C escalators"))
    )

    fun getLines(): List<MetroLine> = _lines

    fun getStations(): List<Station> = _stations

    fun getStation(id: String): Station? = _stations.find { it.id == id }

    fun getDeparturesForStation(stationId: String): List<Departure> {
        return _departures[stationId] ?: listOf(
            Departure("dep_gen_1", stationId, "A", "Terminus", "Platform 1", "14:15", "14:17", 2, false, true, DataQuality.TIMETABLE),
            Departure("dep_gen_2", stationId, "A", "Opposite Terminal", "Platform 2", "14:18", "14:18", 0, false, true, DataQuality.TIMETABLE)
        )
    }

    fun getServiceAlerts(): List<ServiceAlert> = _serviceAlerts

    fun getFareProducts(): List<FareProduct> = _fareProducts

    fun calculateRoute(fromStationId: String, toStationId: String, accessibleOnly: Boolean): Journey {
        val fromSt = getStation(fromStationId) ?: _stations.first()
        val toSt = getStation(toStationId) ?: _stations.last()

        // Simple intelligent route generator based on network graph knowledge
        val legs = mutableListOf<JourneyLeg>()
        var duration = 12
        var transfers = 0
        var walking = 150

        if (fromSt.lineCodes.intersect(toSt.lineCodes).isNotEmpty()) {
            legs.add(
                JourneyLeg(
                    type = LegType.METRO,
                    lineCode = fromSt.lineCodes.first(),
                    originStationName = fromSt.name,
                    destinationStationName = toSt.name,
                    departureTime = "14:15",
                    arrivalTime = "14:27",
                    durationMinutes = 12,
                    stopsCount = 4,
                    instructions = "Direct train on Line ${fromSt.lineCodes.first()}"
                )
            )
        } else {
            transfers = 1
            duration = 18
            walking = 280
            legs.add(
                JourneyLeg(
                    type = LegType.METRO,
                    lineCode = fromSt.lineCodes.first(),
                    originStationName = fromSt.name,
                    destinationStationName = "Můstek",
                    departureTime = "14:15",
                    arrivalTime = "14:23",
                    durationMinutes = 8,
                    stopsCount = 3,
                    instructions = "Board Line ${fromSt.lineCodes.first()}"
                )
            )
            legs.add(
                JourneyLeg(
                    type = LegType.TRANSFER,
                    lineCode = null,
                    originStationName = "Můstek",
                    destinationStationName = "Můstek",
                    departureTime = "14:23",
                    arrivalTime = "14:26",
                    durationMinutes = 3,
                    stopsCount = 0,
                    instructions = "Transfer A ↔ B (Walk 180m)"
                )
            )
            legs.add(
                JourneyLeg(
                    type = LegType.METRO,
                    lineCode = "B",
                    originStationName = "Můstek",
                    destinationStationName = toSt.name,
                    departureTime = "14:26",
                    arrivalTime = "14:33",
                    durationMinutes = 7,
                    stopsCount = 3,
                    instructions = "Board Line B towards ${toSt.name}"
                )
            )
        }

        return Journey(
            id = "journey_${System.currentTimeMillis()}",
            fromStationId = fromSt.id,
            fromStationName = fromSt.name,
            toStationId = toSt.id,
            toStationName = toSt.name,
            totalDurationMinutes = duration,
            transferCount = transfers,
            totalWalkingMeters = walking,
            isAccessible = !accessibleOnly || (fromSt.accessibility.stepFree && toSt.accessibility.stepFree),
            legs = legs
        )
    }
}
