package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.PragueMetroRepository
import com.example.domain.model.Journey
import com.example.domain.model.LegType
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutePlannerScreen(
    onBackClick: () -> Unit,
    onStartJourney: (Journey) -> Unit
) {
    val repository = PragueMetroRepository
    val stations = repository.getStations()
    var fromStationId by remember { mutableStateOf(stations.first().id) }
    var toStationId by remember { mutableStateOf(stations.last().id) }
    var accessibleOnly by remember { mutableStateOf(false) }
    var calculatedJourney by remember { mutableStateOf<Journey?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ROUTE PLANNER", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Input Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(text = "FROM STATION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CzechRed)
                        OutlinedButton(onClick = { /* Simple selector demo */ }, modifier = Modifier.fillMaxWidth()) {
                            Text(text = stations.find { it.id == fromStationId }?.name ?: "Select Origin")
                        }

                        Text(text = "TO STATION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CzechRed)
                        OutlinedButton(onClick = { /* Simple selector demo */ }, modifier = Modifier.fillMaxWidth()) {
                            Text(text = stations.find { it.id == toStationId }?.name ?: "Select Destination")
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Step-free accessible only", fontSize = 14.sp)
                            Switch(checked = accessibleOnly, onCheckedChange = { accessibleOnly = it })
                        }

                        Button(
                            onClick = {
                                calculatedJourney = repository.calculateRoute(fromStationId, toStationId, accessibleOnly)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("calculate_route_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CzechRed)
                        ) {
                            Text("FIND FASTEST ROUTE")
                        }
                    }
                }
            }

            // Results
            calculatedJourney?.let { journey ->
                item {
                    Text(text = "RECOMMENDED OPTION", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "${journey.totalDurationMinutes} MIN", fontSize = 24.sp, fontWeight = FontWeight.Black, color = CzechRed)
                                    Text(text = "${journey.transferCount} transfer • ${journey.totalWalkingMeters}m walk", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                }
                                Button(
                                    onClick = { onStartJourney(journey) },
                                    colors = ButtonDefaults.buttonColors(containerColor = LineAGreen),
                                    modifier = Modifier.testTag("start_journey_button")
                                ) {
                                    Text("START JOURNEY")
                                }
                            }

                            Divider()

                            journey.legs.forEach { leg ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = when (leg.type) {
                                            LegType.METRO -> Icons.Default.Train
                                            LegType.TRANSFER -> Icons.Default.SwapHoriz
                                            else -> Icons.Default.DirectionsWalk
                                        },
                                        contentDescription = null,
                                        tint = CzechRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = leg.instructions, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(text = "${leg.originStationName} → ${leg.destinationStationName} (${leg.durationMinutes} min)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
