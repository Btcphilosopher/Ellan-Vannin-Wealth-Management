package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.*
import com.example.ui.theme.PragueMetroTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PragueMetroTheme {
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "home") {
                    composable("home") {
                        HomeScreen(
                            onNavigateToStation = { stationId -> navController.navigate("station/$stationId") },
                            onNavigateToRoute = { navController.navigate("route") },
                            onNavigateToMap = { navController.navigate("map") },
                            onNavigateToDisruptions = { navController.navigate("disruptions") },
                            onNavigateToTickets = { navController.navigate("tickets") }
                        )
                    }
                    composable("station/{stationId}") { backStackEntry ->
                        val stationId = backStackEntry.arguments?.getString("stationId") ?: "a_mustek"
                        StationDetailScreen(
                            stationId = stationId,
                            onBackClick = { navController.popBackStack() }
                        )
                    }
                    composable("route") {
                        RoutePlannerScreen(
                            onBackClick = { navController.popBackStack() },
                            onStartJourney = { journey ->
                                // Navigate to active journey or home
                                navController.popBackStack()
                            }
                        )
                    }
                    composable("map") {
                        MapScreen(
                            onBackClick = { navController.popBackStack() }
                        )
                    }
                    composable("disruptions") {
                        DisruptionsScreen(
                            onBackClick = { navController.popBackStack() }
                        )
                    }
                    composable("tickets") {
                        TicketsScreen(
                            onBackClick = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
