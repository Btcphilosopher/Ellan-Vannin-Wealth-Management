package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PragueGraphite = Color(0xFF1E2022)
val PragueCharcoal = Color(0xFF111214)
val PragueConcrete = Color(0xFFE9EAE5)
val PragueWarmWhite = Color(0xFFF7F7F5)
val PragueCardBg = Color(0xFFFFFFFF)
val PragueCardBgDark = Color(0xFF282B30)

val LineAGreen = Color(0xFF00875A)
val LineBYellow = Color(0xFFE5A900)
val LineCRed = Color(0xFFC62828)

val CzechRed = Color(0xFFD32F2F)
val StatusAmber = Color(0xFFF57C00)
val MutedBlue = Color(0xFF1976D2)
