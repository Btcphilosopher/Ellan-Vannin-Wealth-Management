package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.PragueMetroRepository
import com.example.domain.model.Departure
import com.example.domain.model.MetroLine
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToStation: (String) -> Unit,
    onNavigateToRoute: () -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToDisruptions: () -> Unit,
    onNavigateToTickets: () -> Unit
) {
    val repository = PragueMetroRepository
    val stations = repository.getStations()
    val lines = repository.getLines()
    val alerts = repository.getServiceAlerts()
    val mustekStation = stations.find { it.id == "a_mustek" }!!
    val departures = repository.getDeparturesForStation("a_mustek")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "PRAGUE METRO",
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "THE UNDERGROUND NETWORK, ENGINEERED",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToMap, modifier = Modifier.testTag("map_button")) {
                        Icon(Icons.Default.Map, contentDescription = "Schematic Map")
                    }
                    IconButton(onClick = onNavigateToDisruptions, modifier = Modifier.testTag("alerts_button")) {
                        Icon(Icons.Default.Warning, contentDescription = "Service Status")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = true,
                    onClick = { },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Network") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onNavigateToRoute,
                    icon = { Icon(Icons.Default.Navigation, contentDescription = "Route") },
                    label = { Text("Planner") },
                    modifier = Modifier.testTag("nav_planner")
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onNavigateToMap,
                    icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                    label = { Text("Map") },
                    modifier = Modifier.testTag("nav_map")
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onNavigateToTickets,
                    icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Tickets") },
                    label = { Text("Tickets") },
                    modifier = Modifier.testTag("nav_tickets")
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Nearest Station Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToStation(mustekStation.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "NEAREST STATION",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                                Text(
                                    text = mustekStation.name.uppercase(),
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                LineBadge("A", LineAGreen)
                                LineBadge("B", LineBYellow)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = CzechRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "3 min walk • Praha 1 • Step-free access", fontSize = 13.sp)
                        }
                    }
                }
            }

            // Quick Route Planner Trigger Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToRoute() },
                    colors = CardDefaults.cardColors(containerColor = PragueGraphite)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ROUTE PLANNER",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                            Text(
                                text = "Where are you going?",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color.White)
                    }
                }
            }

            // Service Status Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToDisruptions() },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(LineAGreen, androidx.compose.foundation.shape.CircleShape)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = "NETWORK STATUS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(text = "All lines operating normally", fontSize = 14.sp)
                            }
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null)
                    }
                }
            }

            // Next Departures at Můstek
            item {
                Text(
                    text = "NEXT DEPARTURES — MŮSTEK",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }

            items(departures) { departure ->
                DepartureItemRow(departure)
            }

            // Favourites
            item {
                Text(
                    text = "FAVOURITES",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FavouriteChip("Home", "Muzeum", Modifier.weight(1f)) { onNavigateToStation("a_muzeum") }
                    FavouriteChip("Work", "Florenc", Modifier.weight(1f)) { onNavigateToStation("b_florenc") }
                    FavouriteChip("Airport", "Veleslavín", Modifier.weight(1f)) { onNavigateToStation("a_veleslavin") }
                }
            }
        }
    }
}

@Composable
fun LineBadge(code: String, color: Color) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .background(color, androidx.compose.foundation.shape.CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = code,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
    }
}

@Composable
fun DepartureItemRow(departure: Departure) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LineBadge(
                    code = departure.lineCode,
                    color = when (departure.lineCode) {
                        "A" -> LineAGreen
                        "B" -> LineBYellow
                        else -> LineCRed
                    }
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = departure.destination,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "${departure.platform} • ${departure.scheduledTime}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = departure.estimatedTime,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = CzechRed
                )
                if (departure.delayMinutes > 0) {
                    Text(
                        text = "+${departure.delayMinutes} min",
                        fontSize = 11.sp,
                        color = StatusAmber
                    )
                } else {
                    Text(
                        text = "On time",
                        fontSize = 11.sp,
                        color = LineAGreen
                    )
                }
            }
        }
    }
}

@Composable
fun FavouriteChip(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CzechRed)
            Text(text = subtitle, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}
