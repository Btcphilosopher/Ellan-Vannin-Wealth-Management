package com.example.data.repository

import android.content.Context
import com.example.core.localization.MetroLanguage
import com.example.core.model.*
import com.example.core.persistence.*
import com.example.data.seed.MetroSeedData
import com.example.domain.routing.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MetroRepository(
    private val context: Context,
    private val database: AppDatabase
) {
    private val dao = database.metroDao()
    private val repositoryScope = CoroutineScope(Dispatchers.IO)

    // Simulation Live States
    private val _simCrowded = MutableStateFlow(false)
    val simCrowded: StateFlow<Boolean> = _simCrowded.asStateFlow()

    private val _simDelayed = MutableStateFlow(false)
    val simDelayed: StateFlow<Boolean> = _simDelayed.asStateFlow()

    private val _closedStations = MutableStateFlow<Set<String>>(emptySet())
    val closedStations: StateFlow<Set<String>> = _closedStations.asStateFlow()

    private val _disruptedLines = MutableStateFlow<Set<String>>(emptySet())
    val disruptedLines: StateFlow<Set<String>> = _disruptedLines.asStateFlow()

    private val _simTime = MutableStateFlow("08:30")
    val simTime: StateFlow<String> = _simTime.asStateFlow()

    init {
        // Load default config or initialize database states
        repositoryScope.launch {
            // Seed NCMC Mobility Card if empty
            dao.insertMobilityCard(
                DbMobilityCard(
                    id = 1,
                    balance = 420.0,
                    cardNumber = "NCMC-8392-5819-2045",
                    lastOriginName = "અમદાવાદ",
                    lastDestName = "ગાંધીનગર",
                    lastTime = "ગઇકાલે"
                )
            )
            
            // Sync saved configs
            dao.getAllSimulationConfigs().collect { configs ->
                configs.forEach { config ->
                    when (config.configKey) {
                        "is_crowded" -> _simCrowded.value = config.valueString == "true"
                        "is_delayed" -> _simDelayed.value = config.valueString == "true"
                        "closed_stations" -> {
                            _closedStations.value = if (config.valueString.isEmpty()) {
                                emptySet()
                            } else {
                                config.valueString.split(",").toSet()
                            }
                        }
                        "disrupted_lines" -> {
                            _disruptedLines.value = if (config.valueString.isEmpty()) {
                                emptySet()
                            } else {
                                config.valueString.split(",").toSet()
                            }
                        }
                        "sim_time" -> _simTime.value = config.valueString
                    }
                }
            }
        }
    }

    // Stations
    fun getStations(): List<MetroStation> {
        return MetroSeedData.stations
    }

    fun getStationById(id: String): MetroStation? {
        val st = MetroSeedData.stations.find { it.id == id } ?: return null
        // Inject dynamic values
        return st.copy(
            gates = MetroSeedData.stationGates[id] ?: listOf(
                StationGate("g1", "મુખ્ય દ્વાર ૧", "Main Gate 1", "मुख्य द्वार 1", true, true, true)
            ),
            facilities = MetroSeedData.defaultFacilities,
            nextDepartures = generateDeparturesForStation(id)
        )
    }

    // Lines
    fun getLines(): List<MetroLine> {
        return MetroSeedData.lines
    }

    // Routing
    fun findRoute(
        originId: String,
        destinationId: String,
        preference: RoutingPreference
    ): RouteJourney? {
        return MetroRoutingEngine.findRoute(
            originId = originId,
            destinationId = destinationId,
            preference = preference,
            closedStationIds = _closedStations.value,
            disruptedLineIds = _disruptedLines.value
        )
    }

    // Favorites (Room reactive flow)
    val favoriteStationIds: Flow<Set<String>> = dao.getAllFavorites()
        .map { list -> list.map { it.stationId }.toSet() }

    suspend fun toggleFavorite(stationId: String) {
        val currentFavorites = dao.getAllFavorites().first().map { it.stationId }
        if (currentFavorites.contains(stationId)) {
            dao.removeFavorite(stationId)
        } else {
            dao.addFavorite(DbFavoriteStation(stationId))
        }
    }

    // NCMC Travel Card (Room reactive flow)
    val mobilityCard: Flow<DbMobilityCard?> = dao.getMobilityCard()

    suspend fun rechargeMobilityCard(amount: Double) {
        val currentCard = dao.getMobilityCard().first()
        if (currentCard != null) {
            val updated = currentCard.copy(balance = currentCard.balance + amount)
            dao.insertMobilityCard(updated)
        }
    }

    suspend fun deductMobilityCard(amount: Double, fromGu: String, toGu: String) {
        val currentCard = dao.getMobilityCard().first()
        if (currentCard != null && currentCard.balance >= amount) {
            val updated = currentCard.copy(
                balance = currentCard.balance - amount,
                lastOriginName = fromGu,
                lastDestName = toGu,
                lastTime = "હમણાં જ"
            )
            dao.insertMobilityCard(updated)
        }
    }

    // Tickets (Room reactive flow)
    val activeTickets: Flow<List<DbTicket>> = dao.getAllTickets()

    suspend fun purchaseTicket(originId: String, destinationId: String, passengersCount: Int, price: Double): DbTicket {
        val ticketId = "GM-DEMO-${(10000..99999).random()}"
        val ticket = DbTicket(
            id = ticketId,
            originId = originId,
            destinationId = destinationId,
            price = price,
            passengersCount = passengersCount,
            timestamp = System.currentTimeMillis(),
            qrData = "AHMEDABAD_METRO_TICKET|$ticketId|$originId|$destinationId|$passengersCount|${System.currentTimeMillis()}",
            isDemo = true
        )
        dao.insertTicket(ticket)
        return ticket
    }

    suspend fun clearTickets() {
        dao.clearAllTickets()
    }

    // Service Alerts
    fun getActiveAlerts(): List<ServiceAlert> {
        val list = MetroSeedData.serviceAlerts.toMutableList()
        // Inject simulation alerted lines
        _disruptedLines.value.forEach { lid ->
            val l = MetroSeedData.lines.find { it.id == lid }
            list.add(
                ServiceAlert(
                    id = "sim_alert_$lid",
                    titleGu = "${l?.nameGu ?: lid} માં વિક્ષેપ",
                    titleEn = "Disruption on ${l?.nameEn ?: lid}",
                    titleHi = "${l?.nameHi ?: lid} में व्यवधान",
                    descGu = "ડેવલપર મોડ સિમ્યુલેશન હેઠળ આ રૂટની સેવા અસ્થાયી રૂપે ખોરવાઈ ગઈ છે.",
                    descEn = "Service on this route is temporarily disrupted due to simulated conditions.",
                    descHi = "डेवलपर मोड सिमुलेशन के तहत इस मार्ग की सेवा अस्थायी रूप से बाधित है.",
                    severity = AlertSeverity.CRITICAL,
                    affectedLineId = lid
                )
            )
        }
        _closedStations.value.forEach { sid ->
            val s = MetroSeedData.stations.find { it.id == sid }
            list.add(
                ServiceAlert(
                    id = "sim_alert_$sid",
                    titleGu = "${s?.nameGu ?: sid} બંધ છે",
                    titleEn = "${s?.nameEn ?: sid} is Closed",
                    titleHi = "${s?.nameHi ?: sid} बंद है",
                    descGu = "ટેકનિકલ કારણોસર આ સ્ટેશન અસ્થાયી રૂપે બંધ કરવામાં આવ્યું છે.",
                    descEn = "This station is closed due to simulated developer settings.",
                    descHi = "तकनीकी कारणों से यह स्टेशन अस्थायी रूप से बंद कर दिया गया है.",
                    severity = AlertSeverity.CRITICAL,
                    affectedStationId = sid
                )
            )
        }
        return list
    }

    // Departure Board Generator (Based on timetable rules + simulation state)
    private fun generateDeparturesForStation(stationId: String): List<Departure> {
        val station = MetroSeedData.stations.find { it.id == stationId } ?: return emptyList()
        val list = mutableListOf<Departure>()

        var index = 1
        for (lineId in station.lineIds) {
            val line = MetroSeedData.lines.find { it.id == lineId } ?: continue
            val sIds = line.stationIds
            val pos = sIds.indexOf(stationId)
            if (pos == -1) continue

            // Forward train
            if (pos < sIds.size - 1) {
                val dest = MetroSeedData.stations.find { it.id == sIds.last() }
                if (dest != null) {
                    val baseMinutes = if (_simCrowded.value) 12 else 6
                    val delay = if (_simDelayed.value) 5 else 0
                    list.add(
                        Departure(
                            id = "dep_${stationId}_fw_${index++}",
                            destinationGu = dest.nameGu,
                            destinationEn = dest.nameEn,
                            destinationHi = dest.nameHi,
                            lineId = lineId,
                            platform = "પ્લેટફોર્મ ૧",
                            minutesLeft = baseMinutes + delay,
                            delayMinutes = delay
                        )
                    )
                }
            }

            // Backward train
            if (pos > 0) {
                val dest = MetroSeedData.stations.find { it.id == sIds.first() }
                if (dest != null) {
                    val baseMinutes = if (_simCrowded.value) 16 else 9
                    val delay = if (_simDelayed.value) 7 else 0
                    list.add(
                        Departure(
                            id = "dep_${stationId}_bw_${index++}",
                            destinationGu = dest.nameGu,
                            destinationEn = dest.nameEn,
                            destinationHi = dest.nameHi,
                            lineId = lineId,
                            platform = "પ્લેટફોર્મ ૨",
                            minutesLeft = baseMinutes + delay,
                            delayMinutes = delay
                        )
                    )
                }
            }
        }
        return list
    }

    // Developer / Simulation Commands
    suspend fun setSimulationTime(time: String) {
        _simTime.value = time
        dao.insertConfig(DbSimulationConfig("sim_time", time))
    }

    suspend fun toggleCrowding() {
        val next = !_simCrowded.value
        _simCrowded.value = next
        dao.insertConfig(DbSimulationConfig("is_crowded", next.toString()))
    }

    suspend fun toggleDelays() {
        val next = !_simDelayed.value
        _simDelayed.value = next
        dao.insertConfig(DbSimulationConfig("is_delayed", next.toString()))
    }

    suspend fun toggleStationClosure(stationId: String) {
        val current = _closedStations.value.toMutableSet()
        if (current.contains(stationId)) {
            current.remove(stationId)
        } else {
            current.add(stationId)
        }
        _closedStations.value = current
        dao.insertConfig(DbSimulationConfig("closed_stations", current.joinToString(",")))
    }

    suspend fun toggleLineDisruption(lineId: String) {
        val current = _disruptedLines.value.toMutableSet()
        if (current.contains(lineId)) {
            current.remove(lineId)
        } else {
            current.add(lineId)
        }
        _disruptedLines.value = current
        dao.insertConfig(DbSimulationConfig("disrupted_lines", current.joinToString(",")))
    }

    suspend fun resetSimulation() {
        _simCrowded.value = false
        _simDelayed.value = false
        _closedStations.value = emptySet()
        _disruptedLines.value = emptySet()
        _simTime.value = "08:30"

        dao.insertConfig(DbSimulationConfig("is_crowded", "false"))
        dao.insertConfig(DbSimulationConfig("is_delayed", "false"))
        dao.insertConfig(DbSimulationConfig("closed_stations", ""))
        dao.insertConfig(DbSimulationConfig("disrupted_lines", ""))
        dao.insertConfig(DbSimulationConfig("sim_time", "08:30"))
    }
}
