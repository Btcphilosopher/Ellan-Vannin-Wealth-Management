package com.example.core.persistence

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class DbTicket(
    @PrimaryKey val id: String,
    val originId: String,
    val destinationId: String,
    val price: Double,
    val passengersCount: Int,
    val timestamp: Long,
    val qrData: String,
    val isDemo: Boolean = true
)

@Entity(tableName = "mobility_card")
data class DbMobilityCard(
    @PrimaryKey val id: Int = 1,
    val balance: Double,
    val cardNumber: String,
    val lastOriginName: String,
    val lastDestName: String,
    val lastTime: String
)

@Entity(tableName = "favorite_stations")
data class DbFavoriteStation(
    @PrimaryKey val stationId: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "simulation_config")
data class DbSimulationConfig(
    @PrimaryKey val configKey: String,
    val valueString: String
)
