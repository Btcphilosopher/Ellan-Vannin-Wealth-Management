package com.example.domain.routing

import com.example.core.model.*
import com.example.data.seed.MetroSeedData
import java.util.PriorityQueue

enum class RoutingPreference {
    FASTEST,
    FEWEST_TRANSFERS,
    SIMPLEST,
    ACCESSIBLE
}

object MetroRoutingEngine {

    data class RouteNode(
        val stationId: String,
        val cost: Double, // in minutes
        val pathSteps: List<JourneyStep>,
        val currentLineId: String?,
        val transferCount: Int
    ) : Comparable<RouteNode> {
        override fun compareTo(other: RouteNode): Int = this.cost.compareTo(other.cost)
    }

    /**
     * Calculates the best route between origin and destination using Dijkstra's algorithm.
     * Respects closed stations and accessibility settings.
     */
    fun findRoute(
        originId: String,
        destinationId: String,
        preference: RoutingPreference = RoutingPreference.FASTEST,
        closedStationIds: Set<String> = emptySet(),
        disruptedLineIds: Set<String> = emptySet()
    ): RouteJourney? {
        if (originId == destinationId) {
            return RouteJourney(emptyList(), 0, 0.0, emptyList())
        }

        // Priority Queue for Dijkstra exploration
        val pq = PriorityQueue<RouteNode>()
        // Keeps track of the minimum cost to reach each station with a given line state
        val visited = mutableMapOf<Pair<String, String?>, Double>()

        // Find initial station info
        val originStation = MetroSeedData.stations.find { it.id == originId } ?: return null
        if (closedStationIds.contains(originId)) return null

        // Enqueue initial steps from origin lines
        for (lineId in originStation.lineIds) {
            pq.add(RouteNode(originId, 0.0, emptyList(), lineId, 0))
        }
        // Also allow starting with "no line" if walking/bus/external connection is nearby
        pq.add(RouteNode(originId, 0.0, emptyList(), null, 0))

        var bestJourney: RouteJourney? = null

        while (!pq.isEmpty()) {
            val curr = pq.poll() ?: break

            if (curr.stationId == destinationId) {
                // Return the first found route to destination as Dijkstra guarantees shortest path
                val modes = curr.pathSteps.map { it.mode }.distinct()
                val totalDuration = curr.pathSteps.sumOf { it.durationMinutes }
                val totalFare = curr.pathSteps.sumOf { it.fareAmount }
                val isAccessible = curr.pathSteps.all { step ->
                    // Check if stations in steps are accessible
                    val station = MetroSeedData.stations.find { it.id == step.fromStationNameEn.lowercase().replace(" ", "_") }
                    station?.gates?.any { it.isAccessible } ?: true
                }
                
                bestJourney = RouteJourney(
                    steps = curr.pathSteps,
                    totalDurationMinutes = totalDuration,
                    totalFare = totalFare,
                    modeSummary = modes,
                    isAccessible = isAccessible
                )
                break
            }

            val stateKey = Pair(curr.stationId, curr.currentLineId)
            val bestCost = visited[stateKey]
            if (bestCost != null && bestCost <= curr.cost) {
                continue
            }
            visited[stateKey] = curr.cost

            // Get out connections from current station
            val outConnections = MetroSeedData.connections.filter { it.fromStationId == curr.stationId }

            for (conn in outConnections) {
                val targetStationId = conn.toStationId
                
                // Bypass closed stations
                if (closedStationIds.contains(targetStationId)) continue

                // Bypass disrupted lines
                if (conn.lineId != null && disruptedLineIds.contains(conn.lineId)) continue

                val targetStation = MetroSeedData.stations.find { it.id == targetStationId }

                // Check if target station is operational/active
                if (targetStation != null && targetStation.status == NetworkStatus.UNDER_CONSTRUCTION) {
                    // Do not route through under-construction stations for active commutes
                    continue
                }

                // Calculate base travel cost in minutes
                var travelTimeMinutes = conn.durationSeconds / 60.0

                // Add transfer penalty if we switch lines
                var transferPenalty = 0.0
                var isTransfer = false
                if (conn.mode == TransportMode.METRO && curr.currentLineId != null && conn.lineId != null && curr.currentLineId != conn.lineId) {
                    isTransfer = true
                    transferPenalty = 5.0 // 5 minutes transfer penalty
                }

                // Mode-specific wait/transfer times
                if (conn.mode == TransportMode.BUS || conn.mode == TransportMode.BRTS) {
                    travelTimeMinutes += 4.0 // Add bus waiting time penalty
                } else if (conn.mode == TransportMode.AUTO_RICKSHAW) {
                    travelTimeMinutes += 3.0 // Add hail time
                }

                // Preference adaptations
                var extraWeight = 0.0
                when (preference) {
                    RoutingPreference.FEWEST_TRANSFERS -> {
                        if (isTransfer) extraWeight += 20.0 // heavily penalize transfers
                    }
                    RoutingPreference.SIMPLEST -> {
                        if (conn.mode != TransportMode.METRO) extraWeight += 10.0 // penalize non-metro options
                    }
                    RoutingPreference.ACCESSIBLE -> {
                        // Penalize non-accessible configurations
                        val st = MetroSeedData.stations.find { it.id == targetStationId }
                        if (st != null && st.gates.isNotEmpty() && st.gates.none { it.isAccessible }) {
                            extraWeight += 30.0 // major penalty for non-accessible station
                        }
                    }
                    RoutingPreference.FASTEST -> {}
                }

                val stepCost = travelTimeMinutes + transferPenalty + extraWeight
                val nextCost = curr.cost + stepCost

                // Build instructions for this step
                val fromStation = MetroSeedData.stations.find { it.id == curr.stationId }
                val toStation = MetroSeedData.stations.find { it.id == targetStationId }

                val fromGu = fromStation?.nameGu ?: curr.stationId
                val fromEn = fromStation?.nameEn ?: curr.stationId
                val fromHi = fromStation?.nameHi ?: curr.stationId

                val toGu = toStation?.nameGu ?: targetStationId
                val toEn = toStation?.nameEn ?: targetStationId
                val toHi = toStation?.nameHi ?: targetStationId

                val fare = if (conn.mode == TransportMode.METRO) {
                    MetroSeedData.calculateFare(curr.stationId, targetStationId)
                } else {
                    5.0 // Flat BRTS/Bus/Auto-rickshaw rate for demo
                }

                val lineName = conn.lineId?.let { lid ->
                    val line = MetroSeedData.lines.find { it.id == lid }
                    line?.nameEn ?: "Metro"
                } ?: ""

                val instrGu = when (conn.mode) {
                    TransportMode.METRO -> "મેટ્રો ટ્રેન લો ($lineName) $fromGu થી $toGu તરફ."
                    TransportMode.BRTS -> "બીઆરટીએસ બસ પકડો $fromGu થી $toGu."
                    TransportMode.BUS -> "સિટી બસ લો $fromGu થી $toGu."
                    TransportMode.RAIL -> "ભારતીય રેલ્વે લો $fromGu થી $toGu તરફ."
                    TransportMode.WALK -> "$fromGu થી $toGu સુધી ચાલો."
                    TransportMode.AUTO_RICKSHAW -> "ઓટો-રિક્ષા લો $fromGu થી $toGu તરફ."
                }

                val instrEn = when (conn.mode) {
                    TransportMode.METRO -> "Take Metro ($lineName) from $fromEn to $toEn."
                    TransportMode.BRTS -> "Board BRTS bus from $fromEn to $toEn."
                    TransportMode.BUS -> "Take City Bus from $fromEn to $toEn."
                    TransportMode.RAIL -> "Take Indian Railways from $fromEn to $toEn."
                    TransportMode.WALK -> "Walk from $fromEn to $toEn."
                    TransportMode.AUTO_RICKSHAW -> "Take Auto-rickshaw from $fromEn to $toEn."
                }

                val instrHi = when (conn.mode) {
                    TransportMode.METRO -> "मेट्रो ट्रेन लें ($lineName) $fromHi से $toHi की ओर।"
                    TransportMode.BRTS -> "बीआरटीएस बस लें $fromHi से $toHi तक।"
                    TransportMode.BUS -> "सिटी बस लें $fromHi से $toHi।"
                    TransportMode.RAIL -> "भारतीय रेलवे लें $fromHi से $toHi की ओर।"
                    TransportMode.WALK -> "$fromHi से $toHi तक चलें।"
                    TransportMode.AUTO_RICKSHAW -> "ऑटो-रिक्शा लें $fromHi से $toHi की ओर।"
                }

                val newStep = JourneyStep(
                    fromStationNameGu = fromGu,
                    fromStationNameEn = fromEn,
                    fromStationNameHi = fromHi,
                    toStationNameGu = toGu,
                    toStationNameEn = toEn,
                    toStationNameHi = toHi,
                    mode = conn.mode,
                    lineId = conn.lineId,
                    durationMinutes = travelTimeMinutes.toInt().coerceAtLeast(1),
                    fareAmount = fare,
                    instructionGu = instrGu,
                    instructionEn = instrEn,
                    instructionHi = instrHi
                )

                pq.add(
                    RouteNode(
                        stationId = targetStationId,
                        cost = nextCost,
                        pathSteps = curr.pathSteps + newStep,
                        currentLineId = conn.lineId ?: curr.currentLineId,
                        transferCount = curr.transferCount + (if (isTransfer) 1 else 0)
                    )
                )
            }
        }

        return bestJourney
    }
}
