package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Sandstone,
    secondary = DeepBlue,
    tertiary = Saffron,
    background = Charcoal,
    surface = CardBackground,
    onPrimary = Charcoal,
    onSecondary = Color.White,
    onBackground = WarmWhite,
    onSurface = WarmWhite
)

private val LightColorScheme = lightColorScheme(
    primary = DeepBlue,
    secondary = Sandstone,
    tertiary = Terracotta,
    background = WarmWhite,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Charcoal,
    onBackground = Charcoal,
    onSurface = Charcoal
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
