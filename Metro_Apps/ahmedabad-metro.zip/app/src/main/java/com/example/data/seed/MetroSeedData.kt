package com.example.data.seed

import com.example.core.model.*

object MetroSeedData {
    val lines = listOf(
        MetroLine(
            id = "ew_line",
            nameGu = "પૂર્વ-પશ્ચિમ કોરિડોર (બ્લુ લાઇન)",
            nameEn = "East-West Corridor (Blue Line)",
            nameHi = "पूर्व-पश्चिम कॉरिडोर (ब्लू लाइन)",
            colorHex = "#1E88E5",
            status = NetworkStatus.OPERATIONAL,
            stationIds = listOf(
                "thaltej_gam", "thaltej", "gurukul_road", "ahmedabad_university",
                "stadium", "old_high_court", "shahpur", "gheekanta",
                "kalupur_railway", "kankaria_east", "apparel_park", "amraiwadi",
                "rabari_colony", "vastral", "nirant_cross_road", "vastral_gam"
            )
        ),
        MetroLine(
            id = "ns_line",
            nameGu = "ઉત્તર-દક્ષિણ કોરિડોર (રેડ લાઇન)",
            nameEn = "North-South Corridor (Red Line)",
            nameHi = "उत्तर-दक्षिण कॉरिडोर (रेड लाइन)",
            colorHex = "#E53935",
            status = NetworkStatus.OPERATIONAL,
            stationIds = listOf(
                "apmc", "jivraj_park", "rajiv_nagar", "shreyas",
                "paldi", "gandhigram", "usmanpura", "old_high_court",
                "vadaj", "ranip", "aec", "sabarmati", "motera_stadium"
            )
        ),
        // Phase II
        MetroLine(
            id = "phase2_main",
            nameGu = "મોટેરા સ્ટેડિયમ - મહાત્મા મંદિર (વાયોલેટ લાઇન)",
            nameEn = "Motera Stadium - Mahatma Mandir (Violet Line)",
            nameHi = "मोटेरा स्टेडियम - महात्मा मंदिर (वायलेट लाइन)",
            colorHex = "#8E44AD",
            status = NetworkStatus.OPERATIONAL,
            stationIds = listOf(
                "motera_stadium", "koteshwar_road", "vishwakarma_college", "tapovan_circle",
                "narmada_canal", "koba_circle", "juna_koba", "koba_gaam",
                "gnlu", "pdpu", "raysan", "randesan",
                "dholakuva_circle", "infocity", "sector_1", "sector_10a",
                "sachivalaya", "akshardham", "juna_sachivalaya", "sector_16",
                "sector_24", "mahatma_mandir"
            )
        ),
        MetroLine(
            id = "phase2_gift",
            nameGu = "GNLU - ગિફ્ટ સિટી બ્રાન્ચ લાઇન",
            nameEn = "GNLU - GIFT City Branch Line",
            nameHi = "GNLU - गिफ्ट सिटी ब्रांच लाइन",
            colorHex = "#FF8F00",
            status = NetworkStatus.OPERATIONAL,
            stationIds = listOf(
                "gnlu", "pdpu", "gift_city"
            )
        ),
        // Surat Metro (Future Network)
        MetroLine(
            id = "surat_line1",
            nameGu = "સરથાણા - ડ્રીમ સિટી (સુરત ભાવિ લાઇન ૧)",
            nameEn = "Sarthana - Dream City (Surat Line 1 - Future)",
            nameHi = "सरथाणा - ड्रीम सिटी (सूरत लाइन 1 - भावी)",
            colorHex = "#4CAF50",
            status = NetworkStatus.UNDER_CONSTRUCTION,
            stationIds = listOf(
                "sarthana", "kapodra", "labheshwar_chowk", "surat_railway",
                "chowk_bazar", "majura_gate", "althan_tenement", "dream_city"
            )
        ),
        MetroLine(
            id = "surat_line2",
            nameGu = "ભેંસાણ - સરોલી (સુરત ભાવિ લાઇન ૨)",
            nameEn = "Bhesan - Saroli (Surat Line 2 - Future)",
            nameHi = "भैंसाण - सरोली (सूरत लाइन 2 - भावी)",
            colorHex = "#FF5722",
            status = NetworkStatus.PLANNED,
            stationIds = listOf(
                "bhesan", "jahangirpura", "adajan_patia", "majura_gate", "kamela_darwaja", "saroli"
            )
        )
    )

    val stations = listOf(
        // EW Line Operational
        MetroStation(
            id = "thaltej_gam",
            nameGu = "થલતેજ ગામ", nameEn = "Thaltej Gam", nameHi = "थलतेज गांव",
            lineIds = listOf("ew_line"), lat = 23.0532, lng = 72.4988, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "thaltej",
            nameGu = "થલતેજ", nameEn = "Thaltej", nameHi = "थलतेज",
            lineIds = listOf("ew_line"), lat = 23.0515, lng = 72.5115, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "gurukul_road",
            nameGu = "ગુરૂકુલ રોડ", nameEn = "Gurukul Road", nameHi = "गुरुकुल रोड",
            lineIds = listOf("ew_line"), lat = 23.0485, lng = 72.5250, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "ahmedabad_university",
            nameGu = "અમદાવાદ યુનિવર્સિટી", nameEn = "Ahmedabad University", nameHi = "अहमदाबाद यूनिवर्सिटी",
            lineIds = listOf("ew_line"), lat = 23.0410, lng = 72.5450, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "stadium",
            nameGu = "સ્ટેડિયમ", nameEn = "Stadium", nameHi = "स्टेडियम",
            lineIds = listOf("ew_line"), lat = 23.0385, lng = 72.5532, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "old_high_court",
            nameGu = "જૂની હાઇકોર્ટ (ઇન્ટરચેન્જ)", nameEn = "Old High Court (Interchange)", nameHi = "ओल्ड हाई कोर्ट (इंटरचेंज)",
            lineIds = listOf("ew_line", "ns_line"), lat = 23.0335, lng = 72.5645, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "shahpur",
            nameGu = "શાહપુર", nameEn = "Shahpur", nameHi = "शाहपुर",
            lineIds = listOf("ew_line"), lat = 23.0380, lng = 72.5780, hasParking = false,
            type = StationType.UNDERGROUND
        ),
        MetroStation(
            id = "gheekanta",
            nameGu = "ઘીકાંટા", nameEn = "Gheekanta", nameHi = "घीकांटा",
            lineIds = listOf("ew_line"), lat = 23.0298, lng = 72.5862, hasParking = false,
            type = StationType.UNDERGROUND
        ),
        MetroStation(
            id = "kalupur_railway",
            nameGu = "કાલુપુર રેલ્વે સ્ટેશન", nameEn = "Kalupur Railway Station", nameHi = "कालुपुर रेलवे स्टेशन",
            lineIds = listOf("ew_line"), lat = 23.0278, lng = 72.6015, hasParking = true,
            type = StationType.UNDERGROUND
        ),
        MetroStation(
            id = "kankaria_east",
            nameGu = "કાંકરિયા પૂર્વ", nameEn = "Kankaria East", nameHi = "कांकरिया पूर्व",
            lineIds = listOf("ew_line"), lat = 23.0185, lng = 72.6075, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "apparel_park",
            nameGu = "એપરલ પાર્ક", nameEn = "Apparel Park", nameHi = "एपेरल पार्क",
            lineIds = listOf("ew_line"), lat = 23.0162, lng = 72.6178, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "amraiwadi",
            nameGu = "અમરાઈવાડી", nameEn = "Amraiwadi", nameHi = "अमराईवाड़ी",
            lineIds = listOf("ew_line"), lat = 23.0135, lng = 72.6282, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "rabari_colony",
            nameGu = "રબારી કોલોની", nameEn = "Rabari Colony", nameHi = "रबारी कॉलोनी",
            lineIds = listOf("ew_line"), lat = 23.0105, lng = 72.6395, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "vastral",
            nameGu = "વસ્ત્રાલ", nameEn = "Vastral", nameHi = "वस्त्राल",
            lineIds = listOf("ew_line"), lat = 23.0078, lng = 72.6482, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "nirant_cross_road",
            nameGu = "નિરાંત ક્રોસ રોડ", nameEn = "Nirant Cross Road", nameHi = "निरांत क्रॉस रोड",
            lineIds = listOf("ew_line"), lat = 23.0052, lng = 72.6578, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "vastral_gam",
            nameGu = "વસ્ત્રાલ ગામ", nameEn = "Vastral Gam", nameHi = "वस्त्राल गांव",
            lineIds = listOf("ew_line"), lat = 23.0035, lng = 72.6685, hasParking = true,
            type = StationType.ELEVATED
        ),

        // NS Line Operational
        MetroStation(
            id = "apmc",
            nameGu = "એપીએમસી", nameEn = "APMC", nameHi = "एपीएमसी",
            lineIds = listOf("ns_line"), lat = 22.9812, lng = 72.5482, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "jivraj_park",
            nameGu = "જીવરાજ પાર્ક", nameEn = "Jivraj Park", nameHi = "जीवराज पार्क",
            lineIds = listOf("ns_line"), lat = 22.9950, lng = 72.5448, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "rajiv_nagar",
            nameGu = "રાજીવ નગર", nameEn = "Rajiv Nagar", nameHi = "राजीव नगर",
            lineIds = listOf("ns_line"), lat = 23.0042, lng = 72.5460, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "shreyas",
            nameGu = "શ્રેયસ", nameEn = "Shreyas", nameHi = "श्रेयस",
            lineIds = listOf("ns_line"), lat = 23.0112, lng = 72.5492, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "paldi",
            nameGu = "પાલડી", nameEn = "Paldi", nameHi = "पालडी",
            lineIds = listOf("ns_line"), lat = 23.0185, lng = 72.5562, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "gandhigram",
            nameGu = "ગાંધીગ્રામ", nameEn = "Gandhigram", nameHi = "गांधीग्राम",
            lineIds = listOf("ns_line"), lat = 23.0258, lng = 72.5615, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "usmanpura",
            nameGu = "ઉસ્માનપુરા", nameEn = "Usmanpura", nameHi = "उस्मानपुरा",
            lineIds = listOf("ns_line"), lat = 23.0425, lng = 72.5668, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "vadaj",
            nameGu = "વાડજ", nameEn = "Vadaj", nameHi = "वाडज",
            lineIds = listOf("ns_line"), lat = 23.0582, lng = 72.5695, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "ranip",
            nameGu = "રાણીપ", nameEn = "Ranip", nameHi = "राणीप",
            lineIds = listOf("ns_line"), lat = 23.0692, lng = 72.5718, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "aec",
            nameGu = "એઈસી", nameEn = "AEC", nameHi = "एईसी",
            lineIds = listOf("ns_line"), lat = 23.0812, lng = 72.5752, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "sabarmati",
            nameGu = "સાબરમતી (રેલ્વે કનેક્શન)", nameEn = "Sabarmati (Railway Connection)", nameHi = "साबरमती (रेलवे कनेक्शन)",
            lineIds = listOf("ns_line"), lat = 23.0915, lng = 72.5788, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "motera_stadium",
            nameGu = "મોટેરા સ્ટેડિયમ", nameEn = "Motera Stadium", nameHi = "मोटेरा स्टेडियम",
            lineIds = listOf("ns_line", "phase2_main"), lat = 23.1042, lng = 72.5902, hasParking = true,
            type = StationType.ELEVATED
        ),

        // Phase II Stations (Motera to Mahatma Mandir)
        MetroStation(
            id = "koteshwar_road",
            nameGu = "કોટેશ્વર રોડ", nameEn = "Koteshwar Road", nameHi = "कोटेश्वर रोड",
            lineIds = listOf("phase2_main"), lat = 23.1182, lng = 72.5982, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "vishwakarma_college",
            nameGu = "વિશ્વકર્મા કોલેજ", nameEn = "Vishwakarma College", nameHi = "विश्वकर्मा कॉलेज",
            lineIds = listOf("phase2_main"), lat = 23.1312, lng = 72.6052, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "tapovan_circle",
            nameGu = "તપોવન સર્કલ", nameEn = "Tapovan Circle", nameHi = "तपोवन सर्कल",
            lineIds = listOf("phase2_main"), lat = 23.1422, lng = 72.6112, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "narmada_canal",
            nameGu = "નર્મદા કેનાલ", nameEn = "Narmada Canal", nameHi = "नर्मदा नहर",
            lineIds = listOf("phase2_main"), lat = 23.1522, lng = 72.6182, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "koba_circle",
            nameGu = "કોબા સર્કલ", nameEn = "Koba Circle", nameHi = "कोबा सर्कल",
            lineIds = listOf("phase2_main"), lat = 23.1612, lng = 72.6252, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "juna_koba",
            nameGu = "જૂના કોબા", nameEn = "Juna Koba", nameHi = "जूना कोबा",
            lineIds = listOf("phase2_main"), lat = 23.1702, lng = 72.6312, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "koba_gaam",
            nameGu = "કોબા ગામ", nameEn = "Koba Gaam", nameHi = "कोबा गांव",
            lineIds = listOf("phase2_main"), lat = 23.1792, lng = 72.6372, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "gnlu",
            nameGu = "જીએનએલયુ (ઇન્ટરચેન્જ)", nameEn = "GNLU (Interchange)", nameHi = "जीएनएलयू (इंटरचेंज)",
            lineIds = listOf("phase2_main", "phase2_gift"), lat = 23.1895, lng = 72.6455, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "pdpu",
            nameGu = "પીડીપીયુ", nameEn = "PDPU", nameHi = "पीडीडीपीयू",
            lineIds = listOf("phase2_main", "phase2_gift"), lat = 23.1992, lng = 72.6562, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "raysan",
            nameGu = "રાયસણ", nameEn = "Raysan", nameHi = "रायसण",
            lineIds = listOf("phase2_main"), lat = 23.2045, lng = 72.6482, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "randesan",
            nameGu = "રાંદેસણ", nameEn = "Randesan", nameHi = "रांदेसण",
            lineIds = listOf("phase2_main"), lat = 23.2102, lng = 72.6422, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "dholakuva_circle",
            nameGu = "ધોળાકુવા સર્કલ", nameEn = "Dholakuva Circle", nameHi = "धोलाकुआं सर्कल",
            lineIds = listOf("phase2_main"), lat = 23.2172, lng = 72.6382, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "infocity",
            nameGu = "ઇન્ફોસિટી", nameEn = "Infocity", nameHi = "इन्फोसिटी",
            lineIds = listOf("phase2_main"), lat = 23.2242, lng = 72.6402, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "sector_1",
            nameGu = "સેક્ટર-૧", nameEn = "Sector-1", nameHi = "सेक्टर-1",
            lineIds = listOf("phase2_main"), lat = 23.2292, lng = 72.6442, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "sector_10a",
            nameGu = "સેક્ટર-૧૦એ", nameEn = "Sector-10A", nameHi = "सेक्टर-10ए",
            lineIds = listOf("phase2_main"), lat = 23.2352, lng = 72.6492, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "sachivalaya",
            nameGu = "સચિવાલય", nameEn = "Sachivalaya", nameHi = "सचिवालय",
            lineIds = listOf("phase2_main"), lat = 23.2422, lng = 72.6512, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "akshardham",
            nameGu = "અક્ષરધામ", nameEn = "Akshardham", nameHi = "अक्षरधाम",
            lineIds = listOf("phase2_main"), lat = 23.2492, lng = 72.6522, hasParking = true,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "juna_sachivalaya",
            nameGu = "જૂના સચિવાલય", nameEn = "Juna Sachivalaya", nameHi = "जूना सचिवालय",
            lineIds = listOf("phase2_main"), lat = 23.2542, lng = 72.6502, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "sector_16",
            nameGu = "સેક્ટર-૧૬", nameEn = "Sector-16", nameHi = "सेक्टर-16",
            lineIds = listOf("phase2_main"), lat = 23.2592, lng = 72.6452, hasParking = false,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "sector_24",
            nameGu = "સેક્ટર-૨૪", nameEn = "Sector-24", nameHi = "सेक्टर-24",
            lineIds = listOf("phase2_main"), lat = 23.2642, lng = 72.6392, hasParking = true,
            type = StationType.ELEVATED
        ),
        // Mahatma Mandir: integrated with Gandhinagar Capital Railway Station through a 335-metre footbridge with travellators.
        MetroStation(
            id = "mahatma_mandir",
            nameGu = "મહાત્મા મંદિર (ગાંધીનગર કેપિટલ રેલ્વે)", nameEn = "Mahatma Mandir (Railway Integration)", nameHi = "महात्मा मंदिर (रेलवे इंटीग्रेशन)",
            lineIds = listOf("phase2_main"), lat = 23.2692, lng = 72.6302, hasParking = true,
            type = StationType.ELEVATED
        ),

        // GIFT City branch station
        MetroStation(
            id = "gift_city",
            nameGu = "ગિફ્ટ સિટી", nameEn = "GIFT City", nameHi = "गिफ्ट सिटी",
            lineIds = listOf("phase2_gift"), lat = 23.1652, lng = 72.6852, hasParking = true,
            type = StationType.ELEVATED
        ),

        // Surat Metro Planned Stations (for visualization only, flagged as Future / Under Construction)
        MetroStation(
            id = "sarthana",
            nameGu = "સરથાણા (સુરત)", nameEn = "Sarthana (Surat)", nameHi = "सरथाणा (सूरत)",
            lineIds = listOf("surat_line1"), lat = 21.2212, lng = 72.8852, status = NetworkStatus.UNDER_CONSTRUCTION,
            type = StationType.ELEVATED
        ),
        MetroStation(
            id = "majura_gate",
            nameGu = "મજુરા ગેટ (સુરત)", nameEn = "Majura Gate (Surat)", nameHi = "मजुरा गेट (सूरत)",
            lineIds = listOf("surat_line1", "surat_line2"), lat = 21.1712, lng = 72.8212, status = NetworkStatus.UNDER_CONSTRUCTION,
            type = StationType.UNDERGROUND
        ),
        MetroStation(
            id = "dream_city",
            nameGu = "ડ્રીમ સિટી (સુરત)", nameEn = "Dream City (Surat)", nameHi = "ड्रीम सिटी (सूरत)",
            lineIds = listOf("surat_line1"), lat = 21.1112, lng = 72.7812, status = NetworkStatus.UNDER_CONSTRUCTION,
            type = StationType.ELEVATED
        )
    )

    // Connections list for routing graph calculation
    // Directly linked stations on same line have physical connections
    val connections: List<MetroConnection> by lazy {
        val list = mutableListOf<MetroConnection>()

        // Helper to add two-way connections
        fun addLink(f: String, t: String, time: Int, mode: TransportMode = TransportMode.METRO, lineId: String? = null) {
            list.add(MetroConnection(f, t, time, mode, lineId))
            list.add(MetroConnection(t, f, time, mode, lineId))
        }

        // Add links for EW line
        val ew = lines.first { it.id == "ew_line" }.stationIds
        for (i in 0 until ew.size - 1) {
            addLink(ew[i], ew[i + 1], 120, TransportMode.METRO, "ew_line") // 2 minutes average
        }

        // Add links for NS line
        val ns = lines.first { it.id == "ns_line" }.stationIds
        for (i in 0 until ns.size - 1) {
            addLink(ns[i], ns[i + 1], 150, TransportMode.METRO, "ns_line") // 2.5 minutes average
        }

        // Add links for Phase II Main line
        val p2 = lines.first { it.id == "phase2_main" }.stationIds
        for (i in 0 until p2.size - 1) {
            addLink(p2[i], p2[i + 1], 140, TransportMode.METRO, "phase2_main")
        }

        // Add links for GIFT branch: gnlu -> pdpu -> gift_city
        addLink("gnlu", "pdpu", 150, TransportMode.METRO, "phase2_gift")
        addLink("pdpu", "gift_city", 180, TransportMode.METRO, "phase2_gift")

        // Multimodal/Interchanges/External connections
        // 1. Kalupur Railway Station integration
        list.add(MetroConnection("kalupur_railway", "ext_rail_kalupur", 180, TransportMode.RAIL, null))
        list.add(MetroConnection("ext_rail_kalupur", "kalupur_railway", 180, TransportMode.WALK, null))

        // 2. Mahatma Mandir integration (integrated with Gandhinagar Capital Railway Station through a 335-metre footbridge with travellators)
        addLink("mahatma_mandir", "ext_rail_gandhinagar", 200, TransportMode.WALK, null)

        // 3. Airport Mode (pre-configured for Airport connection or bus last-mile)
        // Sabarmati / Motera to Airport links as Auto-Rickshaw / Bus options
        addLink("sabarmati", "airport_terminal", 600, TransportMode.BUS, null)
        addLink("motera_stadium", "airport_terminal", 480, TransportMode.AUTO_RICKSHAW, null)

        // BRTS integration at major hubs
        addLink("ranip", "brts_ranip", 120, TransportMode.WALK, null)
        addLink("paldi", "brts_paldi", 120, TransportMode.WALK, null)
        addLink("stadium", "brts_stadium", 120, TransportMode.WALK, null)

        list
    }

    // Static gates data for a few key stations to demonstrate Accessibility in detail
    val stationGates = mapOf(
        "old_high_court" to listOf(
            StationGate("gate_1", "ગેટ ૧ - હાઇકોર્ટ તરફ", "Gate 1 - Towards High Court", "गेट 1 - हाई कोर्ट की ओर", true, true, true),
            StationGate("gate_2", "ગેટ ૨ - સાબરમતી રિવરફ્રન્ટ તરફ", "Gate 2 - Towards Sabarmati Riverfront", "गेट 2 - साबरमती रिवरफ्रंट की ओर", true, false, true)
        ),
        "motera_stadium" to listOf(
            StationGate("gate_1", "ગેટ ૧ - સ્પોર્ટ્સ ક્લબ", "Gate 1 - Sports Club Entry", "गेट 1 - स्पोर्ट्स क्लब", true, true, true),
            StationGate("gate_2", "ગેટ ૨ - મોટેરા સ્ટેડિયમ રોડ", "Gate 2 - Motera Stadium Road", "गेट 2 - मोटेरा स्टेडियम रोड", false, false, false)
        ),
        "sabarmati" to listOf(
            StationGate("gate_1", "ગેટ ૧ - બુલેટ ટ્રેન કનેક્શન", "Gate 1 - Bullet Train Hub Link", "गेट 1 - बुलेट ट्रेन हब लिंक", true, true, true),
            StationGate("gate_2", "ગેટ ૨ - ધર્મનગર તરફ", "Gate 2 - Towards Dharmanagar", "गेट 2 - धर्मनगर की ओर", true, true, false)
        ),
        "mahatma_mandir" to listOf(
            StationGate("gate_1", "ગેટ ૧ - એક્ઝિબિશન હોલ", "Gate 1 - Exhibition Halls", "गेट 1 - प्रदर्शनी हॉल", true, true, true),
            StationGate("gate_2", "ગેટ ૨ - રેલ્વે ફૂટબ્રિજ (ટ્રાવેલેટર)", "Gate 2 - Railway Footbridge (Travellator)", "गेट 2 - रेलवे फुटब्रिज (ट्रेवलेटर)", true, true, true)
        )
    )

    // Static facilities data
    val defaultFacilities = listOf(
        StationFacility("wc", "શૌચાલય", "Toilet Facilities", "शौचालय", "ic_toilet"),
        StationFacility("lift", "લિફ્ટ અને એસ્કેલેટર", "Lifts & Escalators", "लिफ्ट और एस्केलेटर", "ic_elevator"),
        StationFacility("parking", "મેટ્રો પાર્કિંગ", "Metro Parking", "मेट्रो पार्किंग", "ic_local_parking"),
        StationFacility("brts", "બીઆરટીએસ જોડાણ", "BRTS Bus Connection", "बीआरटीएस कनेक्शन", "ic_directions_bus")
    )

    // Demo Alerts
    val serviceAlerts = listOf(
        ServiceAlert(
            id = "alert_1",
            titleGu = "ગિફ્ટ સિટી રૂટ પર વધારાની ટ્રેનો",
            titleEn = "Additional Trains on GIFT City Route",
            titleHi = "गिफ्ट सिटी रूट पर अतिरिक्त ट्रेनें",
            descGu = "વ્યાપાર કલાકો દરમિયાન મુસાફરોની સુવિધા માટે દર ૧૦ મિનિટે વધારાની મેટ્રો ટ્રેનો દોડાવવામાં આવશે.",
            descEn = "Extra metro services will run every 10 mins during business hours to accommodate commuter volume.",
            descHi = "व्यावसायिक घंटों के दौरान यात्रियों की सुविधा के लिए हर 10 मिनट में अतिरिक्त मेट्रो ट्रेनें चलाई जाएंगी.",
            severity = AlertSeverity.INFO,
            affectedLineId = "phase2_gift"
        ),
        ServiceAlert(
            id = "alert_2",
            titleGu = "ધોળાકુવા સ્ટેશન પર લિફ્ટ જાળવણી",
            titleEn = "Lift Maintenance at Dholakuva",
            titleHi = "धोलाकुआं स्टेशन पर लिफ्ट रखरखाव",
            descGu = "પ્લેટફોર્મ ૨ પર લિફ્ટ પૂર્વ-આયોજિત જાળવણી હેઠળ છે. દિવ્યાંગ મુસાફરોને મદદ માટે ગેટ ૧ સ્ટાફનો સંપર્ક કરવા વિનંતી.",
            descEn = "Lift on Platform 2 is undergoing scheduled maintenance. Please contact staff at Gate 1 for assistance.",
            descHi = "प्लेटफॉर्म 2 पर लिफ्ट पूर्व-नियोजित रखरखाव के अधीन है। दिव्यांग यात्रियों से अनुरोध है कि वे सहायता के लिए गेट 1 स्टाफ से संपर्क करें.",
            severity = AlertSeverity.WARNING,
            affectedStationId = "dholakuva_circle"
        )
    )

    // Fares Product List
    val fareProducts = listOf(
        FareProduct(
            id = "single_journey",
            nameGu = "સિંગલ જર્ની ટિકિટ (QR)",
            nameEn = "Single Journey Ticket (QR)",
            nameHi = "सिंगल जर्नी टिकट (QR)",
            price = 0.0, // calculated dynamically based on stations
            conditionsGu = "ખરીદીની તારીખે જ માન્ય. ફક્ત પ્રવાસી ગંતવ્ય માટે પ્રવેશ/નિકાસ.",
            conditionsEn = "Valid on date of purchase only. Single entry and exit at selected stations.",
            conditionsHi = "केवल खरीद की तारीख पर मान्य। चयनित स्टेशनों पर एकल प्रवेश और निकास."
        ),
        FareProduct(
            id = "return_journey",
            nameGu = "રિટર્ન જર્ની ટિકિટ (QR)",
            nameEn = "Return Journey Ticket (QR)",
            nameHi = "रिटर्न जर्नी टिकट (QR)",
            price = 0.0,
            conditionsGu = "બંને મુસાફરી ખરીદીના દિવસે જ પૂરી કરવાની રહેશે.",
            conditionsEn = "Both journeys must be completed on the same operating day.",
            conditionsHi = "दोनों यात्राएं खरीद के उसी दिन पूरी की जानी चाहिए."
        ),
        FareProduct(
            id = "ncmc_pass",
            nameGu = "નેશનલ કોમન મોબિલિટી કાર્ડ",
            nameEn = "National Common Mobility Card (NCMC)",
            nameHi = "नेशनल कॉमन मोबिलिटी कार्ड",
            price = 100.0, // base cost
            conditionsGu = "રિચાર્જ કરવા યોગ્ય ટ્રાવેલ કાર્ડ. તમામ ટ્રાન્સપોર્ટ અને રિટેલ પર માન્ય.",
            conditionsEn = "Reloadable smart card valid across all transit systems in India.",
            conditionsHi = "रिचार्ज करने योग्य स्मार्ट कार्ड जो भारत के सभी पारगमन प्रणालियों में मान्य है."
        )
    )

    // Dynamic fare rules calculation helper
    fun calculateFare(fromStationId: String, toStationId: String): Double {
        if (fromStationId == toStationId) return 0.0

        val from = stations.find { it.id == fromStationId }
        val to = stations.find { it.id == toStationId }

        if (from == null || to == null) return 10.0

        // Compute distance-based or station count-based pricing
        // Official GMRC pricing roughly: Base ₹5/₹10, increases up to ₹25 max for Phase 1.
        val dx = from.lat - to.lat
        val dy = from.lng - to.lng
        val estDistanceKm = Math.sqrt(dx * dx + dy * dy) * 111.0

        val fare = when {
            estDistanceKm <= 2.0 -> 10.0
            estDistanceKm <= 5.0 -> 15.0
            estDistanceKm <= 12.0 -> 20.0
            estDistanceKm <= 20.0 -> 25.0
            else -> 30.0
        }
        return fare
    }
}

data class MetroConnection(
    val fromStationId: String,
    val toStationId: String,
    val durationSeconds: Int,
    val mode: TransportMode,
    val lineId: String? = null
)
