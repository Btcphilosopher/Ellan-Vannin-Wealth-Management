package com.example.features.more

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.localization.MetroLanguage
import com.example.core.localization.stringResource
import com.example.data.seed.MetroSeedData
import com.example.features.home.MetroViewModel

@Composable
fun MoreScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val selectedCity by viewModel.selectedCity.collectAsState()
    val simCrowded by viewModel.simCrowded.collectAsState()
    val simDelayed by viewModel.simDelayed.collectAsState()
    val simTime by viewModel.simTime.collectAsState()
    val closedStations by viewModel.closedStations.collectAsState()
    val disruptedLines by viewModel.disruptedLines.collectAsState()
    val alerts by viewModel.serviceAlerts.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp, top = 8.dp)
    ) {
        // 1. Language switcher
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "INTERFACE LANGUAGE / ભાષા પસંદ કરો",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    letterSpacing = 0.5.sp
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LanguagePill(
                            label = "ગુજરાતી",
                            isSelected = currentLanguage == MetroLanguage.GUJARATI,
                            onClick = { viewModel.setLanguage(MetroLanguage.GUJARATI) },
                            modifier = Modifier.weight(1f).testTag("lang_gujarati")
                        )
                        LanguagePill(
                            label = "English",
                            isSelected = currentLanguage == MetroLanguage.ENGLISH,
                            onClick = { viewModel.setLanguage(MetroLanguage.ENGLISH) },
                            modifier = Modifier.weight(1f).testTag("lang_english")
                        )
                        LanguagePill(
                            label = "हिन्दी",
                            isSelected = currentLanguage == MetroLanguage.HINDI,
                            onClick = { viewModel.setLanguage(MetroLanguage.HINDI) },
                            modifier = Modifier.weight(1f).testTag("lang_hindi")
                        )
                    }
                }
            }
        }

        // 2. City Selector
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "NETWORK NETWORK / નેટવર્ક પસંદ કરો",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    letterSpacing = 0.5.sp
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CityPill(
                            label = "Ahmedabad Metro",
                            isSelected = selectedCity == "ahmedabad",
                            onClick = { viewModel.selectCity("ahmedabad") },
                            modifier = Modifier.weight(1f)
                        )
                        CityPill(
                            label = "Surat (Future)",
                            isSelected = selectedCity == "surat",
                            onClick = { viewModel.selectCity("surat") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 3. Active Service Alerts list
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "SERVICE ALERTS / સૂચનાઓ",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    letterSpacing = 0.5.sp
                )

                if (alerts.isEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.Green)
                            Text(
                                text = "બધી સેવાઓ સામાન્ય રીતે કાર્યરત છે / All services operating normally.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        alerts.forEach { alert ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (alert.severity == com.example.core.model.AlertSeverity.CRITICAL) {
                                        Color.Red.copy(alpha = 0.08f)
                                    } else {
                                        Color.Yellow.copy(alpha = 0.08f)
                                    }
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (alert.severity == com.example.core.model.AlertSeverity.CRITICAL) Color.Red else Color.Yellow
                                    )
                                    Column {
                                        Text(
                                            text = alert.getTitle(currentLanguage),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = alert.getDesc(currentLanguage),
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Interactive Simulation & Developer Controls Panel
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LIVE SIMULATOR / સિમ્યુલેટર પેનલ",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        letterSpacing = 0.5.sp
                    )
                    
                    TextButton(onClick = { viewModel.resetSimulation() }) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("RESET")
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth().testTag("simulator_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Simulation Time slider mockup
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Simulated Clock Time", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Alters frequency cycles", fontSize = 12.sp, color = Color.Gray)
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable {
                                        val options = listOf("08:30", "12:00", "18:15", "22:45")
                                        val nextIdx = (options.indexOf(simTime) + 1) % options.size
                                        viewModel.updateSimTime(options[nextIdx])
                                    }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(simTime, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                        // Crowding state trigger
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("High Passenger Crowding", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Toggles peak congestion timetables", fontSize = 12.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = simCrowded,
                                onCheckedChange = { viewModel.toggleCrowding() },
                                modifier = Modifier.testTag("simulator_crowding_switch")
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                        // Train delays trigger
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Introduce Train Delays", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("Causes dynamic path re-calculations", fontSize = 12.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = simDelayed,
                                onCheckedChange = { viewModel.toggleDelays() },
                                modifier = Modifier.testTag("simulator_delays_switch")
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                        // Station closure trigger list
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Simulate Closed Stations", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("Routing will automatically bypass selected stations", fontSize = 12.sp, color = Color.Gray)

                            LazyRow(
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(MetroSeedData.stations.take(6)) { station ->
                                    val isClosed = closedStations.contains(station.id)
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(
                                                if (isClosed) Color.Red else MaterialTheme.colorScheme.surfaceVariant
                                            )
                                            .clickable { viewModel.toggleStationClosure(station.id) }
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = station.nameEn,
                                            color = if (isClosed) Color.White else MaterialTheme.colorScheme.onSurface,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LanguagePill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
            )
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}

@Composable
fun CityPill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant
            )
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}
