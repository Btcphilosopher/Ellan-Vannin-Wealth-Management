package com.example.core.model

import com.example.core.localization.MetroLanguage

data class MetroLine(
    val id: String,
    val nameGu: String,
    val nameEn: String,
    val nameHi: String,
    val colorHex: String,
    val status: NetworkStatus = NetworkStatus.OPERATIONAL,
    val stationIds: List<String>
) {
    fun getName(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> nameGu
        MetroLanguage.ENGLISH -> nameEn
        MetroLanguage.HINDI -> nameHi
    }
}

enum class NetworkStatus {
    OPERATIONAL,
    UNDER_CONSTRUCTION,
    PLANNED,
    PROPOSED
}

data class MetroStation(
    val id: String,
    val nameGu: String,
    val nameEn: String,
    val nameHi: String,
    val lineIds: List<String>,
    val lat: Double,
    val lng: Double,
    val status: NetworkStatus = NetworkStatus.OPERATIONAL,
    val hasParking: Boolean = false,
    val type: StationType = StationType.ELEVATED,
    val gates: List<StationGate> = emptyList(),
    val facilities: List<StationFacility> = emptyList(),
    val nextDepartures: List<Departure> = emptyList()
) {
    fun getName(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> nameGu
        MetroLanguage.ENGLISH -> nameEn
        MetroLanguage.HINDI -> nameHi
    }
}

enum class StationType {
    UNDERGROUND,
    ELEVATED,
    AT_GRADE
}

data class StationGate(
    val id: String,
    val nameGu: String,
    val nameEn: String,
    val nameHi: String,
    val isAccessible: Boolean = true,
    val liftNearby: Boolean = true,
    val ramp: Boolean = true
) {
    fun getName(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> nameGu
        MetroLanguage.ENGLISH -> nameEn
        MetroLanguage.HINDI -> nameHi
    }
}

data class StationFacility(
    val id: String,
    val nameGu: String,
    val nameEn: String,
    val nameHi: String,
    val iconName: String
) {
    fun getName(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> nameGu
        MetroLanguage.ENGLISH -> nameEn
        MetroLanguage.HINDI -> nameHi
    }
}

data class Departure(
    val id: String,
    val destinationGu: String,
    val destinationEn: String,
    val destinationHi: String,
    val lineId: String,
    val platform: String,
    val minutesLeft: Int,
    val delayMinutes: Int = 0
) {
    fun getDestination(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> destinationGu
        MetroLanguage.ENGLISH -> destinationEn
        MetroLanguage.HINDI -> destinationHi
    }
}

data class ServiceAlert(
    val id: String,
    val titleGu: String,
    val titleEn: String,
    val titleHi: String,
    val descGu: String,
    val descEn: String,
    val descHi: String,
    val severity: AlertSeverity = AlertSeverity.INFO,
    val affectedLineId: String? = null,
    val affectedStationId: String? = null
) {
    fun getTitle(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> titleGu
        MetroLanguage.ENGLISH -> titleEn
        MetroLanguage.HINDI -> titleHi
    }
    fun getDesc(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> descGu
        MetroLanguage.ENGLISH -> descEn
        MetroLanguage.HINDI -> descHi
    }
}

enum class AlertSeverity {
    INFO,
    WARNING,
    CRITICAL
}

data class FareProduct(
    val id: String,
    val nameGu: String,
    val nameEn: String,
    val nameHi: String,
    val price: Double,
    val conditionsGu: String,
    val conditionsEn: String,
    val conditionsHi: String
) {
    fun getName(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> nameGu
        MetroLanguage.ENGLISH -> nameEn
        MetroLanguage.HINDI -> nameHi
    }
    fun getConditions(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> conditionsGu
        MetroLanguage.ENGLISH -> conditionsEn
        MetroLanguage.HINDI -> conditionsHi
    }
}

enum class TransportMode {
    METRO,
    BRTS,
    BUS,
    RAIL,
    WALK,
    AUTO_RICKSHAW
}

data class JourneyStep(
    val fromStationNameGu: String,
    val fromStationNameEn: String,
    val fromStationNameHi: String,
    val toStationNameGu: String,
    val toStationNameEn: String,
    val toStationNameHi: String,
    val mode: TransportMode,
    val lineId: String? = null,
    val durationMinutes: Int,
    val fareAmount: Double = 0.0,
    val instructionGu: String,
    val instructionEn: String,
    val instructionHi: String
) {
    fun getFromStationName(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> fromStationNameGu
        MetroLanguage.ENGLISH -> fromStationNameEn
        MetroLanguage.HINDI -> fromStationNameHi
    }
    fun getToStationName(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> toStationNameGu
        MetroLanguage.ENGLISH -> toStationNameEn
        MetroLanguage.HINDI -> toStationNameHi
    }
    fun getInstruction(lang: MetroLanguage): String = when (lang) {
        MetroLanguage.GUJARATI -> instructionGu
        MetroLanguage.ENGLISH -> instructionEn
        MetroLanguage.HINDI -> instructionHi
    }
}

data class RouteJourney(
    val steps: List<JourneyStep>,
    val totalDurationMinutes: Int,
    val totalFare: Double,
    val modeSummary: List<TransportMode>,
    val isAccessible: Boolean = true
)

data class SimulatedTrain(
    val trainId: String,
    val lineId: String,
    val currentStationId: String,
    val nextStationId: String,
    val progress: Float, // 0.0 to 1.0 between current and next
    val direction: Int, // 1 for forward, -1 for backward in stationIds list
    val occupancyPercent: Int, // 10% to 95%
    val delayMinutes: Int = 0
)
