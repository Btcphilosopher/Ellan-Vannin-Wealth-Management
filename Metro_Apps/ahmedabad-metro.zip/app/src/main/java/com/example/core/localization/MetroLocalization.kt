package com.example.core.localization

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class MetroLanguage(val code: String, val displayName: String) {
    GUJARATI("gu", "ગુજરાતી"),
    ENGLISH("en", "English"),
    HINDI("hi", "हिन्दी")
}

class LocalizationState(initialLanguage: MetroLanguage = MetroLanguage.GUJARATI) {
    var currentLanguage by mutableStateOf(initialLanguage)
}

val LocalLocalization = staticCompositionLocalOf { LocalizationState() }

object MetroStrings {
    private val strings = mapOf(
        "app_title" to mapOf(
            MetroLanguage.GUJARATI to "Ahmedabad METRO",
            MetroLanguage.ENGLISH to "Ahmedabad METRO",
            MetroLanguage.HINDI to "Ahmedabad METRO"
        ),
        "app_subtitle" to mapOf(
            MetroLanguage.GUJARATI to "ગુજરાતને જોડતું મેટ્રો",
            MetroLanguage.ENGLISH to "Connecting Gujarat",
            MetroLanguage.HINDI to "गुजरात को जोड़ने वाली मेट्रो"
        ),
        "home" to mapOf(
            MetroLanguage.GUJARATI to "હોમ",
            MetroLanguage.ENGLISH to "HOME",
            MetroLanguage.HINDI to "होम"
        ),
        "map" to mapOf(
            MetroLanguage.GUJARATI to "નકશો",
            MetroLanguage.ENGLISH to "MAP",
            MetroLanguage.HINDI to "मानचित्र"
        ),
        "routes" to mapOf(
            MetroLanguage.GUJARATI to "રૂટ",
            MetroLanguage.ENGLISH to "ROUTES",
            MetroLanguage.HINDI to "मार्ग"
        ),
        "tickets" to mapOf(
            MetroLanguage.GUJARATI to "ટિકિટ",
            MetroLanguage.ENGLISH to "TICKETS",
            MetroLanguage.HINDI to "टिकट"
        ),
        "more" to mapOf(
            MetroLanguage.GUJARATI to "વધુ",
            MetroLanguage.ENGLISH to "MORE",
            MetroLanguage.HINDI to "अधिक"
        ),
        "search_title" to mapOf(
            MetroLanguage.GUJARATI to "ક્યાં જવું છે?",
            MetroLanguage.ENGLISH to "Where to go?",
            MetroLanguage.HINDI to "कहाँ जाना है?"
        ),
        "from" to mapOf(
            MetroLanguage.GUJARATI to "થી:",
            MetroLanguage.ENGLISH to "From:",
            MetroLanguage.HINDI to "से:"
        ),
        "to" to mapOf(
            MetroLanguage.GUJARATI to "સુધી:",
            MetroLanguage.ENGLISH to "To:",
            MetroLanguage.HINDI to "तक:"
        ),
        "select_station" to mapOf(
            MetroLanguage.GUJARATI to "[ સ્ટેશન પસંદ કરો ]",
            MetroLanguage.ENGLISH to "[ Select Station ]",
            MetroLanguage.HINDI to "[ स्टेशन चुनें ]"
        ),
        "find_route" to mapOf(
            MetroLanguage.GUJARATI to "રૂટ શોધો",
            MetroLanguage.ENGLISH to "FIND ROUTE",
            MetroLanguage.HINDI to "मार्ग खोजें"
        ),
        "quick_actions" to mapOf(
            MetroLanguage.GUJARATI to "ક્વિક એક્શન",
            MetroLanguage.ENGLISH to "QUICK ACTIONS",
            MetroLanguage.HINDI to "त्वरित कार्रवाई"
        ),
        "nearby_station" to mapOf(
            MetroLanguage.GUJARATI to "નજીકનું સ્ટેશન",
            MetroLanguage.ENGLISH to "Nearby Station",
            MetroLanguage.HINDI to "निकटतम स्टेशन"
        ),
        "my_routes" to mapOf(
            MetroLanguage.GUJARATI to "મારા રૂટ",
            MetroLanguage.ENGLISH to "My Routes",
            MetroLanguage.HINDI to "मेरे मार्ग"
        ),
        "buy_ticket" to mapOf(
            MetroLanguage.GUJARATI to "ટિકિટ ખરીદો",
            MetroLanguage.ENGLISH to "Buy Ticket",
            MetroLanguage.HINDI to "टिकट खरीदें"
        ),
        "service_status" to mapOf(
            MetroLanguage.GUJARATI to "સેવા સ્થિતિ",
            MetroLanguage.ENGLISH to "Service Status",
            MetroLanguage.HINDI to "सेवा की स्थिति"
        ),
        "metro_status" to mapOf(
            MetroLanguage.GUJARATI to "મેટ્રો સ્થિતિ",
            MetroLanguage.ENGLISH to "METRO STATUS",
            MetroLanguage.HINDI to "मेट्रो की स्थिति"
        ),
        "normal_service" to mapOf(
            MetroLanguage.GUJARATI to "સામાન્ય સેવા",
            MetroLanguage.ENGLISH to "Normal Service",
            MetroLanguage.HINDI to "सामान्य सेवा"
        ),
        "delayed" to mapOf(
            MetroLanguage.GUJARATI to "મોડું",
            MetroLanguage.ENGLISH to "Delayed",
            MetroLanguage.HINDI to "विलंबित"
        ),
        "demo_data_notice" to mapOf(
            MetroLanguage.GUJARATI to "ડેમો ડેટા - વાસ્તવિક મુસાફરી માટે માન્ય નથી",
            MetroLanguage.ENGLISH to "DEMO DATA - Not valid for real travel",
            MetroLanguage.HINDI to "डेमो डेटा - वास्तविक यात्रा के लिए मान्य नहीं"
        ),
        "demo_badge" to mapOf(
            MetroLanguage.GUJARATI to "ડેમો ડેટા",
            MetroLanguage.ENGLISH to "DEMO DATA",
            MetroLanguage.HINDI to "डेमो डेटा"
        ),
        "ahmedabad" to mapOf(
            MetroLanguage.GUJARATI to "અમદાવાદ",
            MetroLanguage.ENGLISH to "Ahmedabad",
            MetroLanguage.HINDI to "अहमदाबाद"
        ),
        "gandhinagar" to mapOf(
            MetroLanguage.GUJARATI to "ગાંધીનગર",
            MetroLanguage.ENGLISH to "Gandhinagar",
            MetroLanguage.HINDI to "गांधीनगर"
        ),
        "surat" to mapOf(
            MetroLanguage.GUJARATI to "સુરત",
            MetroLanguage.ENGLISH to "Surat",
            MetroLanguage.HINDI to "सूरत"
        ),
        "gift_city" to mapOf(
            MetroLanguage.GUJARATI to "ગિફ્ટ સિટી",
            MetroLanguage.ENGLISH to "GIFT City",
            MetroLanguage.HINDI to "गिफ्ट सिटी"
        ),
        "language" to mapOf(
            MetroLanguage.GUJARATI to "ભાષા",
            MetroLanguage.ENGLISH to "LANGUAGE",
            MetroLanguage.HINDI to "भाषा"
        ),
        "future_network" to mapOf(
            MetroLanguage.GUJARATI to "ભવિષ્યનું નેટવર્ક",
            MetroLanguage.ENGLISH to "Future Network",
            MetroLanguage.HINDI to "भविष्य का नेटवर्क"
        ),
        "operational" to mapOf(
            MetroLanguage.GUJARATI to "કાર્યરત",
            MetroLanguage.ENGLISH to "Operational",
            MetroLanguage.HINDI to "कार्यशील"
        ),
        "under_construction" to mapOf(
            MetroLanguage.GUJARATI to "બાંધકામ હેઠળ",
            MetroLanguage.ENGLISH to "Under Construction",
            MetroLanguage.HINDI to "निर्माणाधीन"
        ),
        "planned" to mapOf(
            MetroLanguage.GUJARATI to "આયોજિત",
            MetroLanguage.ENGLISH to "Planned",
            MetroLanguage.HINDI to "नियोजित"
        ),
        "proposed" to mapOf(
            MetroLanguage.GUJARATI to "સૂચિત",
            MetroLanguage.ENGLISH to "Proposed",
            MetroLanguage.HINDI to "प्रस्तावित"
        ),
        "active_journey" to mapOf(
            MetroLanguage.GUJARATI to "મારું પ્રવાસ",
            MetroLanguage.ENGLISH to "My Journey",
            MetroLanguage.HINDI to "मेरी यात्रा"
        ),
        "active_journey_title" to mapOf(
            MetroLanguage.GUJARATI to "તમારી મુસાફરી",
            MetroLanguage.ENGLISH to "Your Active Journey",
            MetroLanguage.HINDI to "आपकी सक्रिय यात्रा"
        ),
        "current_station" to mapOf(
            MetroLanguage.GUJARATI to "હાલ:",
            MetroLanguage.ENGLISH to "Current:",
            MetroLanguage.HINDI to "वर्तमान:"
        ),
        "next_station" to mapOf(
            MetroLanguage.GUJARATI to "આગળ:",
            MetroLanguage.ENGLISH to "Next:",
            MetroLanguage.HINDI to "अगला:"
        ),
        "destination_station" to mapOf(
            MetroLanguage.GUJARATI to "ગંતવ્ય:",
            MetroLanguage.ENGLISH to "Destination:",
            MetroLanguage.HINDI to "गंतव्य:"
        ),
        "time_remaining" to mapOf(
            MetroLanguage.GUJARATI to "બાકી સમય:",
            MetroLanguage.ENGLISH to "Time Left:",
            MetroLanguage.HINDI to "शेष समय:"
        ),
        "simulated_journey" to mapOf(
            MetroLanguage.GUJARATI to "સિમ્યુલેટેડ પ્રવાસ",
            MetroLanguage.ENGLISH to "Simulated Journey",
            MetroLanguage.HINDI to "सिम्युलेटेड यात्रा"
        ),
        "minutes" to mapOf(
            MetroLanguage.GUJARATI to "મિનિટ",
            MetroLanguage.ENGLISH to "min",
            MetroLanguage.HINDI to "मिनट"
        ),
        "my_travel_card" to mapOf(
            MetroLanguage.GUJARATI to "મારી ટ્રાવેલ કાર્ડ",
            MetroLanguage.ENGLISH to "MY TRAVEL CARD",
            MetroLanguage.HINDI to "मेरा ट्रेवल कार्ड"
        ),
        "card_balance" to mapOf(
            MetroLanguage.GUJARATI to "બેલેન્સ",
            MetroLanguage.ENGLISH to "Balance",
            MetroLanguage.HINDI to "शेष राशि"
        ),
        "last_journey" to mapOf(
            MetroLanguage.GUJARATI to "છેલ્લી મુસાફરી",
            MetroLanguage.ENGLISH to "Last Journey",
            MetroLanguage.HINDI to "अंतिम यात्रा"
        ),
        "recharge" to mapOf(
            MetroLanguage.GUJARATI to "રિચાર્જ",
            MetroLanguage.ENGLISH to "Recharge",
            MetroLanguage.HINDI to "रिचार्ज"
        ),
        "transactions" to mapOf(
            MetroLanguage.GUJARATI to "ટ્રાન્ઝેક્શન",
            MetroLanguage.ENGLISH to "Transactions",
            MetroLanguage.HINDI to "लेन-देन"
        ),
        "developer_mode" to mapOf(
            MetroLanguage.GUJARATI to "ડેવલપર મોડ",
            MetroLanguage.ENGLISH to "DEVELOPER MODE",
            MetroLanguage.HINDI to "डेवलपर मोड"
        ),
        "simulation" to mapOf(
            MetroLanguage.GUJARATI to "સિમ્યુલેશન",
            MetroLanguage.ENGLISH to "SIMULATION",
            MetroLanguage.HINDI to "सिम्युलेशन"
        ),
        "reset" to mapOf(
            MetroLanguage.GUJARATI to "રીસેટ",
            MetroLanguage.ENGLISH to "RESET",
            MetroLanguage.HINDI to "रीसेट"
        ),
        "delay_train" to mapOf(
            MetroLanguage.GUJARATI to "ટ્રેન વિલંબિત કરો",
            MetroLanguage.ENGLISH to "Delay Train",
            MetroLanguage.HINDI to "ट्रेन विलंबित करें"
        ),
        "close_station" to mapOf(
            MetroLanguage.GUJARATI to "સ્ટેશન બંધ કરો",
            MetroLanguage.ENGLISH to "Close Station",
            MetroLanguage.HINDI to "स्टेशन बंद करें"
        ),
        "increase_crowd" to mapOf(
            MetroLanguage.GUJARATI to "ભીડ વધારો",
            MetroLanguage.ENGLISH to "Increase Crowding",
            MetroLanguage.HINDI to "भीड़ बढ़ाएं"
        ),
        "reduce_freq" to mapOf(
            MetroLanguage.GUJARATI to "આવર્તન ઘટાડો",
            MetroLanguage.ENGLISH to "Reduce Frequency",
            MetroLanguage.HINDI to "आवृत्ति घटाएं"
        ),
        "disable_conn" to mapOf(
            MetroLanguage.GUJARATI to "જોડાણ અક્ષમ કરો",
            MetroLanguage.ENGLISH to "Disable Connection",
            MetroLanguage.HINDI to "कनेक्शन अक्षम करें"
        ),
        "airport" to mapOf(
            MetroLanguage.GUJARATI to "એરપોર્ટ",
            MetroLanguage.ENGLISH to "AIRPORT",
            MetroLanguage.HINDI to "हवाई अड्डा"
        ),
        "airport_title" to mapOf(
            MetroLanguage.GUJARATI to "સરદાર વલ્લભભાઈ પટેલ એરપોર્ટ",
            MetroLanguage.ENGLISH to "Sardar Vallabhbhai Patel Airport",
            MetroLanguage.HINDI to "सरदार वल्लभभाई पटेल हवाई अड्डा"
        ),
        "upcoming_connection" to mapOf(
            MetroLanguage.GUJARATI to "આગામી કનેક્શન",
            MetroLanguage.ENGLISH to "Upcoming Connection",
            MetroLanguage.HINDI to "आगामी कनेक्शन"
        ),
        "mahatma_mandir" to mapOf(
            MetroLanguage.GUJARATI to "મહાત્મા મંદિર",
            MetroLanguage.ENGLISH to "Mahatma Mandir",
            MetroLanguage.HINDI to "महात्मा मंदिर"
        ),
        "surat_coming_soon" to mapOf(
            MetroLanguage.GUJARATI to "સુરત મેટ્રો ટૂંક સમયમાં આવી રહી છે",
            MetroLanguage.ENGLISH to "Surat Metro coming to Surat",
            MetroLanguage.HINDI to "सूरत मेट्रो जल्द ही आ रही है"
        ),
        "future_network_vis" to mapOf(
            MetroLanguage.GUJARATI to "ભવિષ્યના નેટવર્કનું ચિત્રણ",
            MetroLanguage.ENGLISH to "Future Network Visualization",
            MetroLanguage.HINDI to "भविष्य के नेटवर्क का विज़ुअलाइज़ेशन"
        ),
        "routing_modes" to mapOf(
            MetroLanguage.GUJARATI to "રૂટ મોડ્સ",
            MetroLanguage.ENGLISH to "Routing Modes",
            MetroLanguage.HINDI to "रूट मोड्स"
        ),
        "fastest" to mapOf(
            MetroLanguage.GUJARATI to "સૌથી ઝડપી",
            MetroLanguage.ENGLISH to "FASTEST",
            MetroLanguage.HINDI to "सबसे तेज़"
        ),
        "fewest_transfers" to mapOf(
            MetroLanguage.GUJARATI to "ઓછા ટ્રાન્સફર",
            MetroLanguage.ENGLISH to "FEWEST TRANSFERS",
            MetroLanguage.HINDI to "न्यूनतम स्थानांतरण"
        ),
        "simplest" to mapOf(
            MetroLanguage.GUJARATI to "સરળ રૂટ",
            MetroLanguage.ENGLISH to "SIMPLEST",
            MetroLanguage.HINDI to "सबसे सरल"
        ),
        "accessible" to mapOf(
            MetroLanguage.GUJARATI to "અનુકૂળ (દિવ્યાંગ)",
            MetroLanguage.ENGLISH to "ACCESSIBLE",
            MetroLanguage.HINDI to "सुलभ (दिव्यांग)"
        ),
        "city_selector" to mapOf(
            MetroLanguage.GUJARATI to "શહેર પસંદ કરો",
            MetroLanguage.ENGLISH to "Select City",
            MetroLanguage.HINDI to "शहर चुनें"
        )
    )

    fun get(key: String, lang: MetroLanguage): String {
        return strings[key]?.get(lang) ?: key
    }
}

@Composable
fun stringResource(key: String): String {
    val state = LocalLocalization.current
    return MetroStrings.get(key, state.currentLanguage)
}
