package com.example.features.map

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.localization.stringResource
import com.example.features.home.MetroViewModel

@Composable
fun MapScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val selectedCity by viewModel.selectedCity.collectAsState()
    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val simulatedTrains by viewModel.simulatedTrains.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()
    val closedStations by viewModel.closedStations.collectAsState()

    var showFutureLines by remember { mutableStateOf(true) }

    // Fetch details of selected station
    val selectedStation = remember(selectedStationId, closedStations) {
        selectedStationId?.let { viewModel.repository.getStationById(it) }
    }

    Box(modifier = modifier.fillMaxSize()) {
        // 1. Core Map Canvas View
        InteractiveMetroMap(
            selectedCity = selectedCity,
            selectedStationId = selectedStationId,
            simulatedTrains = simulatedTrains,
            showFutureLines = showFutureLines,
            onStationSelect = { viewModel.selectStation(it) }
        )

        // 2. Floating Top Header Controls (City Indicator, Future Toggle)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Future Network Toggle Button
                Button(
                    onClick = { showFutureLines = !showFutureLines },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (showFutureLines) MaterialTheme.colorScheme.primary else Color(0xFF2C2C2C),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.height(38.dp)
                ) {
                    Icon(
                        if (showFutureLines) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource("future_network"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Selected City Indicator Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF2C2C2C))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color.Green)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (selectedCity == "surat") "SURAT METRO" else "AHMEDABAD METRO",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }

        // 3. Slide-Up Station Info Drawer (If station is selected)
        AnimatedVisibility(
            visible = selectedStation != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            selectedStation?.let { station ->
                val isClosed = closedStations.contains(station.id)

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("station_info_panel"),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF1E1E1E) // High contrast dark mode theme
                    ),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Station Name and Close icon
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = station.getName(lang),
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    IconButton(
                                        onClick = { viewModel.toggleFavorite(station.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        val favs by viewModel.favorites.collectAsState()
                                        Icon(
                                            imageVector = if (favs.contains(station.id)) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                            contentDescription = "Toggle Favorite",
                                            tint = if (favs.contains(station.id)) Color.Red else Color.LightGray,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "${station.nameEn} • ${station.type.name}",
                                    fontSize = 13.sp,
                                    color = Color.LightGray
                                )
                            }
                            IconButton(
                                onClick = { viewModel.selectStation(null) },
                                modifier = Modifier.background(Color(0xFF2C2C2C), RoundedCornerShape(12.dp))
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                            }
                        }

                        if (isClosed) {
                            // Show Closed Station warning
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Red.copy(alpha = 0.15f))
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "સ્ટેશન અસ્થાયી રૂપે બંધ છે / Station Temporarily Closed",
                                    color = Color.Red,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            // Departures Board Section
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "NEXT DEPARTURES / આગામી ટ્રેનો",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.LightGray
                                )

                                if (station.nextDepartures.isEmpty()) {
                                    Text(
                                        text = "No active scheduled trains for this corridor.",
                                        fontSize = 13.sp,
                                        color = Color.Gray
                                    )
                                } else {
                                    station.nextDepartures.forEach { dep ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFF2A2A2A))
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    Icons.Default.DirectionsSubway,
                                                    contentDescription = null,
                                                    tint = Color(0xFF1E88E5),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = dep.getDestination(lang),
                                                    color = Color.White,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "${dep.minutesLeft} mins",
                                                    color = if (dep.delayMinutes > 0) Color.Yellow else Color.Green,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                if (dep.delayMinutes > 0) {
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = "(+${dep.delayMinutes} min delay)",
                                                        color = Color.Yellow,
                                                        fontSize = 11.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Gate-Level Accessibility Detail Grid
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "ACCESSIBLE ENTRANCES & GATES / સુલભ પ્રવેશદ્વારો",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.LightGray
                                )

                                if (station.gates.isEmpty()) {
                                    Text(
                                        text = "Gate data is being updated. All main gates have lift connections.",
                                        fontSize = 12.sp,
                                        color = Color.Gray
                                    )
                                } else {
                                    station.gates.forEach { gate ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFF252525))
                                                .padding(8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = gate.getName(lang),
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                if (gate.isAccessible) {
                                                    AccessibilityBadge("Accessible")
                                                }
                                                if (gate.liftNearby) {
                                                    AccessibilityBadge("Lift")
                                                }
                                                if (gate.ramp) {
                                                    AccessibilityBadge("Ramp")
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Station Facilities
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "FACILITIES / સુવિધાઓ",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.LightGray
                                )
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(station.facilities) { fac ->
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFF2C2C2C))
                                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Text(
                                                text = fac.getName(lang),
                                                fontSize = 11.sp,
                                                color = Color.White,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AccessibilityBadge(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF2E7D32).copy(alpha = 0.2f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = "✓ $text",
            fontSize = 9.sp,
            color = Color(0xFF4CAF50),
            fontWeight = FontWeight.Bold
        )
    }
}
