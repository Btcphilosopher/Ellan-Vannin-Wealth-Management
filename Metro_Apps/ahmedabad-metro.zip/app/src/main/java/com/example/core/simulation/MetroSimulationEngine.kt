package com.example.core.simulation

import com.example.core.model.SimulatedTrain
import com.example.data.seed.MetroSeedData
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object MetroSimulationEngine {
    private val _simulatedTrains = MutableStateFlow<List<SimulatedTrain>>(emptyList())
    val simulatedTrains: StateFlow<List<SimulatedTrain>> = _simulatedTrains.asStateFlow()

    private var simulationJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    init {
        initializeTrains()
    }

    fun startSimulation() {
        if (simulationJob != null) return
        simulationJob = scope.launch {
            while (isActive) {
                delay(300) // Update 3 times per second for smooth movement
                updateTrainPositions()
            }
        }
    }

    fun stopSimulation() {
        simulationJob?.cancel()
        simulationJob = null
    }

    private fun initializeTrains() {
        val initialList = listOf(
            SimulatedTrain(
                trainId = "T-EW-1",
                lineId = "ew_line",
                currentStationId = "thaltej_gam",
                nextStationId = "thaltej",
                progress = 0.0f,
                direction = 1,
                occupancyPercent = 45
            ),
            SimulatedTrain(
                trainId = "T-EW-2",
                lineId = "ew_line",
                currentStationId = "vastral_gam",
                nextStationId = "nirant_cross_road",
                progress = 0.2f,
                direction = -1,
                occupancyPercent = 78
            ),
            SimulatedTrain(
                trainId = "T-NS-1",
                lineId = "ns_line",
                currentStationId = "apmc",
                nextStationId = "jivraj_park",
                progress = 0.5f,
                direction = 1,
                occupancyPercent = 60
            ),
            SimulatedTrain(
                trainId = "T-NS-2",
                lineId = "ns_line",
                currentStationId = "motera_stadium",
                nextStationId = "sabarmati",
                progress = 0.1f,
                direction = -1,
                occupancyPercent = 85
            ),
            // Phase II Mahatma Mandir train
            SimulatedTrain(
                trainId = "T-P2-1",
                lineId = "phase2_main",
                currentStationId = "motera_stadium",
                nextStationId = "koteshwar_road",
                progress = 0.4f,
                direction = 1,
                occupancyPercent = 35
            ),
            // GIFT City branch train
            SimulatedTrain(
                trainId = "T-GIFT-1",
                lineId = "phase2_gift",
                currentStationId = "gnlu",
                nextStationId = "pdpu",
                progress = 0.6f,
                direction = 1,
                occupancyPercent = 50
            )
        )
        _simulatedTrains.value = initialList
    }

    private fun updateTrainPositions() {
        val currentTrains = _simulatedTrains.value
        val updated = currentTrains.map { train ->
            val line = MetroSeedData.lines.find { it.id == train.lineId }
            if (line == null) return@map train

            val sIds = line.stationIds
            var progress = train.progress + 0.03f // incremental step

            if (progress >= 1.0f) {
                // Train has arrived at its next station
                val currentIdx = sIds.indexOf(train.nextStationId)
                if (currentIdx == -1) {
                    // Fail-safe, reset
                    return@map train.copy(progress = 0.0f)
                }

                var nextIdx = currentIdx + train.direction
                var direction = train.direction

                if (nextIdx >= sIds.size || nextIdx < 0) {
                    // Out of bounds, reverse train direction!
                    direction = -direction
                    nextIdx = currentIdx + direction
                }

                // Bound check again
                val finalNextIdx = nextIdx.coerceIn(0, sIds.lastIndex)
                
                train.copy(
                    currentStationId = train.nextStationId,
                    nextStationId = sIds[finalNextIdx],
                    progress = 0.0f,
                    direction = direction,
                    occupancyPercent = (25..95).random() // randomize occupancy for realism
                )
            } else {
                train.copy(progress = progress)
            }
        }
        _simulatedTrains.value = updated
    }
}
