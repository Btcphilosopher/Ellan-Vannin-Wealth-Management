package com.example.features.routes

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsWalk
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.localization.stringResource
import com.example.core.model.JourneyStep
import com.example.core.model.TransportMode
import com.example.domain.routing.RoutingPreference
import com.example.features.home.MetroViewModel

@Composable
fun RoutesScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val routePreference by viewModel.routePreference.collectAsState()
    val computedRoute by viewModel.computedRoute.collectAsState()
    val isJourneyModeActive by viewModel.isJourneyModeActive.collectAsState()
    val activeJourneyStepIndex by viewModel.activeJourneyStepIndex.collectAsState()

    if (isJourneyModeActive && computedRoute != null) {
        // Active Journey Progress HUD
        ActiveJourneyHUD(
            route = computedRoute!!,
            activeStepIndex = activeJourneyStepIndex,
            lang = lang,
            onAdvance = { viewModel.advanceJourneyStep() },
            onEnd = { viewModel.endActiveJourney() }
        )
    } else {
        // Standard Route Selector and Steps list
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 32.dp, top = 8.dp)
        ) {
            // Preferences Tabs Selector
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource("routing_modes"),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        letterSpacing = 0.5.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        RoutingPreferenceTab(
                            preference = RoutingPreference.FASTEST,
                            label = stringResource("fastest"),
                            isSelected = routePreference == RoutingPreference.FASTEST,
                            onClick = { viewModel.setRoutePreference(RoutingPreference.FASTEST) },
                            modifier = Modifier.weight(1f)
                        )
                        RoutingPreferenceTab(
                            preference = RoutingPreference.FEWEST_TRANSFERS,
                            label = stringResource("fewest_transfers"),
                            isSelected = routePreference == RoutingPreference.FEWEST_TRANSFERS,
                            onClick = { viewModel.setRoutePreference(RoutingPreference.FEWEST_TRANSFERS) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        RoutingPreferenceTab(
                            preference = RoutingPreference.SIMPLEST,
                            label = stringResource("simplest"),
                            isSelected = routePreference == RoutingPreference.SIMPLEST,
                            onClick = { viewModel.setRoutePreference(RoutingPreference.SIMPLEST) },
                            modifier = Modifier.weight(1f)
                        )
                        RoutingPreferenceTab(
                            preference = RoutingPreference.ACCESSIBLE,
                            label = stringResource("accessible"),
                            isSelected = routePreference == RoutingPreference.ACCESSIBLE,
                            onClick = { viewModel.setRoutePreference(RoutingPreference.ACCESSIBLE) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Calculations Display
            if (computedRoute == null) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.DirectionsSubway,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f),
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "અમદાવાદ મેટ્રો રૂટ પ્લાનર",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                        Text(
                            text = "થી અને સુધી સ્ટેશન પસંદ કરો.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                        )
                    }
                }
            } else {
                val route = computedRoute!!

                // Summary Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${route.totalDurationMinutes} ${stringResource("minutes")}",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Estimated travel time",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "₹ ${"%.2f".format(route.totalFare)}",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                                Text(
                                    text = "Computed Fare",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                        }
                    }
                }

                // Steps list Header & Action button
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "JOURNEY PATHWAY / મુસાફરી માર્ગ",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                            letterSpacing = 0.5.sp
                        )

                        // Start Journey simulated mode
                        Button(
                            onClick = { viewModel.startActiveJourney() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("start_journey_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(stringResource("active_journey"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Steps
                itemsIndexed(route.steps) { index, step ->
                    RouteStepItem(step = step, isFirst = index == 0, isLast = index == route.steps.size - 1, lang = lang)
                }
            }
        }
    }
}

@Composable
fun RoutingPreferenceTab(
    preference: RoutingPreference,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag("tab_pref_${preference.name.lowercase()}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun RouteStepItem(
    step: JourneyStep,
    isFirst: Boolean,
    isLast: Boolean,
    lang: com.example.core.localization.MetroLanguage
) {
    val modeIcon = when (step.mode) {
        TransportMode.METRO -> Icons.Default.DirectionsSubway
        TransportMode.BRTS -> Icons.Default.DirectionsBus
        TransportMode.BUS -> Icons.Default.DirectionsBus
        TransportMode.RAIL -> Icons.Default.Train
        TransportMode.WALK -> Icons.AutoMirrored.Filled.DirectionsWalk
        TransportMode.AUTO_RICKSHAW -> Icons.Default.AirportShuttle
    }

    val modeColor = when (step.mode) {
        TransportMode.METRO -> Color(0xFF1E88E5)
        TransportMode.BRTS -> Color(0xFFE65100)
        TransportMode.BUS -> Color(0xFF4CAF50)
        TransportMode.RAIL -> Color(0xFF673AB7)
        TransportMode.WALK -> Color.Gray
        TransportMode.AUTO_RICKSHAW -> Color(0xFFFBC02D)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("route_step_item"),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Timeline Dot & Connector
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(modeColor)
            )

            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(60.dp)
                    .background(Color.Gray.copy(alpha = 0.3f))
            )
        }

        // Details Column
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${step.getFromStationName(lang)} → ${step.getToStationName(lang)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${step.durationMinutes} ${stringResource("minutes")}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = modeIcon,
                    contentDescription = null,
                    tint = modeColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = step.getInstruction(lang),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
            }

            if (step.fareAmount > 0.0) {
                Text(
                    text = "Fare: ₹ ${"%.2f".format(step.fareAmount)}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.tertiary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}

// Active Journey HUD overlay
@Composable
fun ActiveJourneyHUD(
    route: com.example.core.model.RouteJourney,
    activeStepIndex: Int,
    lang: com.example.core.localization.MetroLanguage,
    onAdvance: () -> Unit,
    onEnd: () -> Unit
) {
    val step = route.steps.getOrNull(activeStepIndex) ?: return

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212)) // Dark atmospheric theme for HUD
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Text(
                text = stringResource("active_journey_title"),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.LightGray,
                letterSpacing = 1.sp
            )

            // Animated Route Map Progress Bar ●━━━━━━○━━━━○━━━━○
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                route.steps.forEachIndexed { idx, _ ->
                    val isActive = idx == activeStepIndex
                    val isVisited = idx < activeStepIndex

                    Box(
                        modifier = Modifier
                            .size(if (isActive) 16.dp else 10.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isActive) Color(0xFFFF8F00)
                                else if (isVisited) Color(0xFF4CAF50)
                                else Color.DarkGray
                            )
                    )
                    
                    if (idx < route.steps.size - 1) {
                        Divider(
                            modifier = Modifier.weight(1f).height(2.dp),
                            color = if (isVisited) Color(0xFF4CAF50) else Color.DarkGray
                        )
                    }
                }
            }

            // Details Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .testTag("hud_details_card"),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    DetailHUDRow(stringResource("current_station"), step.getFromStationName(lang), Color.Green)
                    DetailHUDRow(stringResource("next_station"), step.getToStationName(lang), Color(0xFFFF8F00))
                    DetailHUDRow(stringResource("destination_station"), route.steps.last().getToStationName(lang), Color(0xFF1E88E5))
                    DetailHUDRow(stringResource("time_remaining"), "${route.steps.drop(activeStepIndex).sumOf { it.durationMinutes }} ${stringResource("minutes")}", Color.LightGray)
                }
            }

            // Status bar
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF2E7D32).copy(alpha = 0.2f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.FlashOn, contentDescription = null, tint = Color.Green, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource("simulated_journey"),
                    color = Color.Green,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onEnd,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC0392B)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("End Journey", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onAdvance,
                    modifier = Modifier.weight(1f).testTag("hud_advance_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Advance (GPS)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun DetailHUDRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color.Gray, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = valueColor, fontSize = 15.sp, fontWeight = FontWeight.Black)
    }
}
