package com.example.core.persistence

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {
    // Tickets
    @Query("SELECT * FROM tickets ORDER BY timestamp DESC")
    fun getAllTickets(): Flow<List<DbTicket>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: DbTicket)

    @Query("DELETE FROM tickets WHERE id = :id")
    suspend fun deleteTicketById(id: String)

    @Query("DELETE FROM tickets")
    suspend fun clearAllTickets()

    // Mobility Card (only 1 row with id=1)
    @Query("SELECT * FROM mobility_card WHERE id = 1 LIMIT 1")
    fun getMobilityCard(): Flow<DbMobilityCard?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMobilityCard(card: DbMobilityCard)

    // Favorite Stations
    @Query("SELECT * FROM favorite_stations")
    fun getAllFavorites(): Flow<List<DbFavoriteStation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(favorite: DbFavoriteStation)

    @Query("DELETE FROM favorite_stations WHERE stationId = :stationId")
    suspend fun removeFavorite(stationId: String)

    // Simulation Configs
    @Query("SELECT * FROM simulation_config")
    fun getAllSimulationConfigs(): Flow<List<DbSimulationConfig>>

    @Query("SELECT * FROM simulation_config WHERE configKey = :key LIMIT 1")
    suspend fun getConfigByKey(key: String): DbSimulationConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfig(config: DbSimulationConfig)
}
