package com.example.features.tickets

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.localization.stringResource
import com.example.core.persistence.DbTicket
import com.example.data.seed.MetroSeedData
import com.example.features.home.MetroViewModel

@Composable
fun TicketsScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val mobilityCard by viewModel.mobilityCard.collectAsState()
    val activeTickets by viewModel.activeTickets.collectAsState()

    var showBuyTicketSheet by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp, top = 8.dp)
    ) {
        // GMRC NCMC Travel Card
        item {
            Text(
                text = "GMRC SMART CARD / સ્માર્ટ કાર્ડ",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            mobilityCard?.let { card ->
                NCMCSmartCard(
                    cardNumber = card.cardNumber,
                    balance = card.balance,
                    lastTrip = "Last: ${card.lastOriginName} → ${card.lastDestName} (${card.lastTime})",
                    onRecharge = { viewModel.rechargeCard(100.0) }
                )
            }
        }

        // Active Tickets Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE DIGITAL TICKETS / સક્રિય ક્યુઆર ટિકિટ",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    letterSpacing = 0.5.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (activeTickets.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearTickets() }) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear All Tickets", tint = Color.Red)
                        }
                    }

                    Button(
                        onClick = { showBuyTicketSheet = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("buy_ticket_trigger_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(stringResource("buy_ticket"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Tickets List
        if (activeTickets.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.QrCode,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "કોઈ સક્રિય ટિકિટ નથી / No active tickets found",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        } else {
            items(activeTickets) { ticket ->
                TicketItemCard(ticket = ticket, lang = lang)
            }
        }

        // Legal Notice Compliance
        item {
            Card(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.05f)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.Gavel, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                    Column {
                        Text(
                            text = "આ એક સિમ્યુલેશન ડેમો એપ્લિકેશન છે.",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                        Text(
                            text = "This application is a proof of concept only and has no real-world affiliation with GMRC or state government authorities.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }
    }

    if (showBuyTicketSheet) {
        BuyTicketDialog(
            lang = lang,
            onDismiss = { showBuyTicketSheet = false },
            onBuy = { fromId, toId, passengers, price ->
                viewModel.buyTicket(fromId, toId, passengers, price)
                showBuyTicketSheet = false
            }
        )
    }
}

@Composable
fun NCMCSmartCard(
    cardNumber: String,
    balance: Double,
    lastTrip: String,
    onRecharge: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .testTag("ncmc_smart_card"),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF0F2027),
                            Color(0xFF203A43),
                            Color(0xFF2C5364)
                        )
                    )
                )
                .padding(20.dp)
        ) {
            // Chip and GMRC logo
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Gold Chip
                Box(
                    modifier = Modifier
                        .size(36.dp, 26.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFFD4AF37))
                )
                
                Text(
                    text = "GMRC • NCMC",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            }

            // Balance Details
            Column(
                modifier = Modifier.align(Alignment.CenterStart),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "BALANCE / બેલેન્સ",
                    color = Color.LightGray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "₹ ${"%.2f".format(balance)}",
                    color = Color.White,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black
                )
            }

            // Card details and Quick recharge button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = cardNumber,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = lastTrip,
                        color = Color.LightGray.copy(alpha = 0.8f),
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }

                Button(
                    onClick = onRecharge,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White.copy(alpha = 0.2f),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(32.dp).testTag("recharge_button")
                ) {
                    Text("+ ₹100", fontSize = 11.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun TicketItemCard(ticket: DbTicket, lang: com.example.core.localization.MetroLanguage) {
    val origin = MetroSeedData.stations.find { it.id == ticket.originId }
    val dest = MetroSeedData.stations.find { it.id == ticket.destinationId }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ticket_item_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Simulated Vector QR Code
            SimulatedQRCode(
                qrData = ticket.qrData,
                modifier = Modifier.size(80.dp)
            )

            // Details
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "${origin?.getName(lang) ?: ticket.originId} ➔ ${dest?.getName(lang) ?: ticket.destinationId}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "ID: ${ticket.id}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                Text(
                    text = "Passengers: ${ticket.passengersCount} Single Journey",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Price: ₹ ${"%.2f".format(ticket.price)}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.tertiary,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.Green.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "DEMO OK",
                            fontSize = 9.sp,
                            color = Color.Green,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// Custom Vector Simulated QR Code Generator using Canvas
@Composable
fun SimulatedQRCode(qrData: String, modifier: Modifier = Modifier) {
    // Generate static grid values based on hash to keep QR consistent
    val size = 10
    val hash = qrData.hashCode()
    val qrGrid = remember(qrData) {
        Array(size) { r ->
            BooleanArray(size) { c ->
                // Make corners look like QR position anchors
                if ((r < 3 && c < 3) || (r < 3 && c >= size - 3) || (r >= size - 3 && c < 3)) {
                    // Position locator boxes
                    r == 0 || r == 2 || c == 0 || c == 2 || (r >= size - 3 && (r == size - 1 || r == size - 3 || c == 0 || c == 2)) || (c >= size - 3 && (r == 0 || r == 2 || c == size - 1 || c == size - 3))
                } else {
                    // Random pseudo seed patterns based on char values
                    (hash + r * 37 + c * 17) % 2 == 0
                }
            }
        }
    }

    Canvas(
        modifier = modifier
            .background(Color.White)
            .padding(6.dp)
    ) {
        val cellW = this.size.width / size
        val cellH = this.size.height / size

        for (r in 0 until size) {
            for (c in 0 until size) {
                if (qrGrid[r][c]) {
                    drawRect(
                        color = Color.Black,
                        topLeft = androidx.compose.ui.geometry.Offset(c * cellW, r * cellH),
                        size = androidx.compose.ui.geometry.Size(cellW, cellH)
                    )
                }
            }
        }
    }
}

// Dialog to buy single tickets
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuyTicketDialog(
    lang: com.example.core.localization.MetroLanguage,
    onDismiss: () -> Unit,
    onBuy: (fromId: String, toId: String, passengers: Int, price: Double) -> Unit
) {
    var fromId by remember { mutableStateOf("thaltej_gam") }
    var toId by remember { mutableStateOf("vastral_gam") }
    var passengerCount by remember { mutableStateOf(1) }

    val fromStation = MetroSeedData.stations.find { it.id == fromId }
    val toStation = MetroSeedData.stations.find { it.id == toId }

    val price = remember(fromId, toId, passengerCount) {
        MetroSeedData.calculateFare(fromId, toId) * passengerCount
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Generate Digital Ticket", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // From station selection dropdown
                Column {
                    Text("From Station / ક્યાંથી", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    // Simplified Picker Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = fromStation?.getName(lang) ?: fromId,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // To station selection dropdown
                Column {
                    Text("To Station / ક્યાં સુધી", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = toStation?.getName(lang) ?: toId,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Passenger count selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Passengers / મુસાફરો", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        IconButton(onClick = { if (passengerCount > 1) passengerCount-- }) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease")
                        }
                        Text(text = passengerCount.toString(), fontSize = 16.sp, fontWeight = FontWeight.Black)
                        IconButton(onClick = { if (passengerCount < 6) passengerCount++ }) {
                            Icon(Icons.Default.Add, contentDescription = "Increase")
                        }
                    }
                }

                // Calculated Price Display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Total Price / કુલ ભાડું", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = "₹ ${"%.2f".format(price)}", fontSize = 18.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.tertiary)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onBuy(fromId, toId, passengerCount, price) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                modifier = Modifier.testTag("buy_ticket_confirm_button")
            ) {
                Text("Confirm Purchase", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
