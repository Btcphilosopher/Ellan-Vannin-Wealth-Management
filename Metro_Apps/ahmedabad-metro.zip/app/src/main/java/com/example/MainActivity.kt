package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.core.localization.LocalLocalization
import com.example.core.localization.stringResource
import com.example.features.home.HomeScreen
import com.example.features.home.MetroViewModel
import com.example.features.map.MapScreen
import com.example.features.more.MoreScreen
import com.example.features.routes.RoutesScreen
import com.example.features.tickets.TicketsScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MetroViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val currentLanguage by viewModel.currentLanguage.collectAsState()
            val localizationState = remember(currentLanguage) { com.example.core.localization.LocalizationState(currentLanguage) }

            // Connect localization CompositionLocal reactive context
            CompositionLocalProvider(LocalLocalization provides localizationState) {
                MyApplicationTheme {
                    var selectedTab by remember { mutableStateOf(0) }

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        bottomBar = {
                            NavigationBar(
                                modifier = Modifier.testTag("bottom_nav_bar")
                            ) {
                                NavigationBarItem(
                                    selected = selectedTab == 0,
                                    onClick = { selectedTab = 0 },
                                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                    label = { Text(stringResource("tab_home")) },
                                    modifier = Modifier.testTag("nav_tab_home")
                                )
                                NavigationBarItem(
                                    selected = selectedTab == 1,
                                    onClick = { selectedTab = 1 },
                                    icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                                    label = { Text(stringResource("tab_map")) },
                                    modifier = Modifier.testTag("nav_tab_map")
                                )
                                NavigationBarItem(
                                    selected = selectedTab == 2,
                                    onClick = { selectedTab = 2 },
                                    icon = { Icon(Icons.Default.Directions, contentDescription = "Routes") },
                                    label = { Text(stringResource("tab_routes")) },
                                    modifier = Modifier.testTag("nav_tab_routes")
                                )
                                NavigationBarItem(
                                    selected = selectedTab == 3,
                                    onClick = { selectedTab = 3 },
                                    icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Tickets") },
                                    label = { Text(stringResource("tab_tickets")) },
                                    modifier = Modifier.testTag("nav_tab_tickets")
                                )
                                NavigationBarItem(
                                    selected = selectedTab == 4,
                                    onClick = { selectedTab = 4 },
                                    icon = { Icon(Icons.Default.Settings, contentDescription = "More") },
                                    label = { Text(stringResource("tab_more")) },
                                    modifier = Modifier.testTag("nav_tab_more")
                                )
                            }
                        }
                    ) { innerPadding ->
                        val screenModifier = Modifier.padding(innerPadding)
                        when (selectedTab) {
                            0 -> HomeScreen(
                                viewModel = viewModel,
                                onNavigateToTab = { selectedTab = it },
                                modifier = screenModifier
                            )
                            1 -> MapScreen(
                                viewModel = viewModel,
                                modifier = screenModifier
                            )
                            2 -> RoutesScreen(
                                viewModel = viewModel,
                                modifier = screenModifier
                            )
                            3 -> TicketsScreen(
                                viewModel = viewModel,
                                modifier = screenModifier
                            )
                            4 -> MoreScreen(
                                viewModel = viewModel,
                                modifier = screenModifier
                            )
                        }
                    }
                }
            }
        }
    }
}
