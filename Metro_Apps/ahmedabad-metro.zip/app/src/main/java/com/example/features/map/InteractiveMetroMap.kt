package com.example.features.map

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.core.localization.MetroLanguage
import com.example.core.model.MetroStation
import com.example.core.model.NetworkStatus
import com.example.core.model.SimulatedTrain
import com.example.data.seed.MetroSeedData
import kotlin.math.sqrt

@Composable
fun InteractiveMetroMap(
    selectedCity: String,
    selectedStationId: String?,
    simulatedTrains: List<SimulatedTrain>,
    showFutureLines: Boolean,
    onStationSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    highlightedStationIds: List<String> = emptyList()
) {
    var zoom by remember { mutableStateOf(1.2f) }
    var offset by remember { mutableStateOf(Offset(0f, 0f)) }

    // Filter lines/stations by city selection
    val activeLines = remember(selectedCity, showFutureLines) {
        MetroSeedData.lines.filter { line ->
            if (selectedCity == "surat") {
                line.id.startsWith("surat_")
            } else {
                !line.id.startsWith("surat_") && (showFutureLines || line.status == NetworkStatus.OPERATIONAL)
            }
        }
    }

    val activeStations = remember(selectedCity, showFutureLines, activeLines) {
        val lineStationIds = activeLines.flatMap { it.stationIds }.toSet()
        MetroSeedData.stations.filter { lineStationIds.contains(it.id) }
    }

    // Map bounds calculation for normalization
    val bounds = remember(activeStations) {
        if (activeStations.isEmpty()) {
            MapBounds(22.9, 23.3, 72.4, 72.7)
        } else {
            var minLat = Double.MAX_VALUE
            var maxLat = -Double.MAX_VALUE
            var minLng = Double.MAX_VALUE
            var maxLng = -Double.MAX_VALUE
            for (st in activeStations) {
                if (st.lat < minLat) minLat = st.lat
                if (st.lat > maxLat) maxLat = st.lat
                if (st.lng < minLng) minLng = st.lng
                if (st.lng > maxLng) maxLng = st.lng
            }
            // Add margin
            val latDiff = (maxLat - minLat).coerceAtLeast(0.01)
            val lngDiff = (maxLng - minLng).coerceAtLeast(0.01)
            MapBounds(
                minLat - latDiff * 0.15,
                maxLat + latDiff * 0.15,
                minLng - lngDiff * 0.15,
                maxLng + lngDiff * 0.15
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E1E)) // Elegant deep graphite background
    ) {
        // Main Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(selectedCity, activeStations, bounds) {
                    detectTransformGestures { _, pan, zoomAmount, _ ->
                        zoom = (zoom * zoomAmount).coerceIn(0.5f, 5.0f)
                        offset += pan
                    }
                }
                .pointerInput(selectedCity, activeStations, bounds, zoom, offset) {
                    detectTapGestures { tapOffset ->
                        // Reverse project screen tap coordinates back to original scale to find closest node
                        val canvasWidth = size.width.toFloat()
                        val canvasHeight = size.height.toFloat()

                        var closestStation: MetroStation? = null
                        var minDist = Float.MAX_VALUE

                        for (st in activeStations) {
                            val px = bounds.normalizeX(st.lng, canvasWidth)
                            val py = bounds.normalizeY(st.lat, canvasHeight)

                            // Apply zoom and offset transformation
                            val transformedX = px * zoom + offset.x
                            val transformedY = py * zoom + offset.y

                            val dx = tapOffset.x - transformedX
                            val dy = tapOffset.y - transformedY
                            val dist = sqrt(dx * dx + dy * dy)

                            if (dist < 40f && dist < minDist) {
                                minDist = dist
                                closestStation = st
                            }
                        }

                        if (closestStation != null) {
                            onStationSelect(closestStation.id)
                        }
                    }
                }
        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            withTransform({
                // Apply cumulative Pan and Zoom
                translate(offset.x, offset.y)
                scale(zoom, zoom, Offset(0f, 0f))
            }) {
                // 1. Draw grid backdrop representing planned geometries
                drawGridPattern(bounds, canvasWidth, canvasHeight)

                // 2. Draw connections (lines tracks)
                activeLines.forEach { line ->
                    val path = Path()
                    var isFirst = true
                    
                    line.stationIds.forEach { sid ->
                        val st = activeStations.find { it.id == sid }
                        if (st != null) {
                            val px = bounds.normalizeX(st.lng, canvasWidth)
                            val py = bounds.normalizeY(st.lat, canvasHeight)
                            if (isFirst) {
                                path.moveTo(px, py)
                                isFirst = false
                            } else {
                                path.lineTo(px, py)
                            }
                        }
                    }

                    // Standard line draw
                    drawPath(
                        path = path,
                        color = Color(android.graphics.Color.parseColor(line.colorHex)),
                        style = Stroke(
                            width = 6f / zoom.coerceAtLeast(0.5f),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                    
                    // Draw outer styling track for visual richness
                    drawPath(
                        path = path,
                        color = Color(android.graphics.Color.parseColor(line.colorHex)).copy(alpha = 0.15f),
                        style = Stroke(
                            width = 20f / zoom.coerceAtLeast(0.5f),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                }

                // 3. Highlighted journey route overlay if applicable
                if (highlightedStationIds.isNotEmpty()) {
                    val highlightPath = Path()
                    var isFirst = true
                    highlightedStationIds.forEach { sid ->
                        val st = activeStations.find { it.id == sid }
                        if (st != null) {
                            val px = bounds.normalizeX(st.lng, canvasWidth)
                            val py = bounds.normalizeY(st.lat, canvasHeight)
                            if (isFirst) {
                                highlightPath.moveTo(px, py)
                                isFirst = false
                            } else {
                                highlightPath.lineTo(px, py)
                            }
                        }
                    }
                    drawPath(
                        path = highlightPath,
                        color = Color(0xFFE65100), // Rich warning/route accent orange
                        style = Stroke(
                            width = 12f / zoom.coerceAtLeast(0.5f),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                }

                // 4. Draw Station Nodes
                activeStations.forEach { st ->
                    val px = bounds.normalizeX(st.lng, canvasWidth)
                    val py = bounds.normalizeY(st.lat, canvasHeight)

                    val isInterchange = st.lineIds.size > 1
                    val isSelected = st.id == selectedStationId
                    val isHighlighted = highlightedStationIds.contains(st.id)

                    // Draw outer highlight pulse
                    if (isSelected || isHighlighted) {
                        drawCircle(
                            color = if (isSelected) Color(0xFFFFEB3B) else Color(0xFFE65100),
                            radius = 22f / zoom.coerceAtLeast(0.5f),
                            center = Offset(px, py),
                            alpha = 0.4f
                        )
                    }

                    // Inner circles
                    val baseRadius = if (isInterchange) 14f else 9f
                    drawCircle(
                        color = if (isInterchange) Color.White else Color(0xFF2C2C2C),
                        radius = baseRadius / zoom.coerceAtLeast(0.5f),
                        center = Offset(px, py)
                    )

                    drawCircle(
                        color = if (isInterchange) Color(0xFF1E1E1E) else Color.White,
                        radius = (baseRadius * 0.6f) / zoom.coerceAtLeast(0.5f),
                        center = Offset(px, py)
                    )

                    // Labels - only draw if zoomed in enough or is major/selected station
                    if (zoom > 1.0f || isSelected || isInterchange) {
                        // Draw label text background box
                        val paint = Paint().asFrameworkPaint().apply {
                            color = android.graphics.Color.WHITE
                            textSize = (10f * zoom).coerceIn(24f, 40f) / zoom
                            textAlign = android.graphics.Paint.Align.CENTER
                            isFakeBoldText = isSelected || isInterchange
                        }
                        
                        // Simple canvas native text draw for exact placement
                        drawContext.canvas.nativeCanvas.drawText(
                            st.nameEn,
                            px,
                            py - (baseRadius + 12f) / zoom.coerceAtLeast(0.5f),
                            paint
                        )
                    }
                }

                // 5. Draw active moving trains
                simulatedTrains.filter { t -> activeLines.any { it.id == t.lineId } }.forEach { train ->
                    val line = activeLines.find { it.id == train.lineId }
                    if (line != null) {
                        val currentStation = activeStations.find { it.id == train.currentStationId }
                        val nextStation = activeStations.find { it.id == train.nextStationId }

                        if (currentStation != null && nextStation != null) {
                            val curX = bounds.normalizeX(currentStation.lng, canvasWidth)
                            val curY = bounds.normalizeY(currentStation.lat, canvasHeight)
                            val nxtX = bounds.normalizeX(nextStation.lng, canvasWidth)
                            val nxtY = bounds.normalizeY(nextStation.lat, canvasHeight)

                            // Interpolate train coordinate based on progress
                            val trainX = curX + (nxtX - curX) * train.progress
                            val trainY = curY + (nxtY - curY) * train.progress

                            // Draw train icon shape
                            val color = Color(android.graphics.Color.parseColor(line.colorHex))
                            drawCircle(
                                color = Color.White,
                                radius = 10f / zoom.coerceAtLeast(0.5f),
                                center = Offset(trainX, trainY)
                            )
                            drawCircle(
                                color = color,
                                radius = 7f / zoom.coerceAtLeast(0.5f),
                                center = Offset(trainX, trainY)
                            )
                        }
                    }
                }
            }
        }

        // Overlay Map Controls (Floating bar)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SmallFloatingActionButton(
                onClick = { zoom = (zoom + 0.3f).coerceAtMost(5.0f) },
                containerColor = Color(0xFF2C2C2C),
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In")
            }

            SmallFloatingActionButton(
                onClick = { zoom = (zoom - 0.3f).coerceAtLeast(0.5f) },
                containerColor = Color(0xFF2C2C2C),
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out")
            }

            SmallFloatingActionButton(
                onClick = {
                    zoom = 1.2f
                    offset = Offset(0f, 0f)
                },
                containerColor = Color(0xFF2C2C2C),
                contentColor = Color.White
            ) {
                Icon(Icons.Default.MyLocation, contentDescription = "Recenter")
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGridPattern(
    bounds: MapBounds,
    width: Float,
    height: Float
) {
    val steps = 15
    for (i in 0..steps) {
        val x = (width / steps) * i
        drawLine(
            color = Color.White.copy(alpha = 0.05f),
            start = Offset(x, 0f),
            end = Offset(x, height),
            strokeWidth = 1f
        )
        val y = (height / steps) * i
        drawLine(
            color = Color.White.copy(alpha = 0.05f),
            start = Offset(0f, y),
            end = Offset(width, y),
            strokeWidth = 1f
        )
    }
}

data class MapBounds(
    val minLat: Double,
    val maxLat: Double,
    val minLng: Double,
    val maxLng: Double
) {
    fun normalizeX(lng: Double, width: Float): Float {
        val fraction = (lng - minLng) / (maxLng - minLng)
        return (fraction * width).toFloat()
    }

    fun normalizeY(lat: Double, height: Float): Float {
        // Invert Y because canvas Y starts at the top and goes down
        val fraction = (lat - minLat) / (maxLat - minLat)
        return ((1.0 - fraction) * height).toFloat()
    }
}
