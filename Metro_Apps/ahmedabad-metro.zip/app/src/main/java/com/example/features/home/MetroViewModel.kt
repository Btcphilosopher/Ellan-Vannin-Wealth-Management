package com.example.features.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.localization.MetroLanguage
import com.example.core.model.*
import com.example.core.persistence.AppDatabase
import com.example.core.persistence.DbMobilityCard
import com.example.core.persistence.DbTicket
import com.example.core.simulation.MetroSimulationEngine
import com.example.data.repository.MetroRepository
import com.example.domain.routing.RoutingPreference
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MetroViewModel(application: Application) : AndroidViewModel(application) {
    
    private val database = AppDatabase.getDatabase(application)
    val repository = MetroRepository(application, database)

    // Language setting state
    private val _currentLanguage = MutableStateFlow(MetroLanguage.GUJARATI)
    val currentLanguage: StateFlow<MetroLanguage> = _currentLanguage.asStateFlow()

    // Route search selections
    private val _originStationId = MutableStateFlow<String?>("motera_stadium")
    val originStationId: StateFlow<String?> = _originStationId.asStateFlow()

    private val _destStationId = MutableStateFlow<String?>("mahatma_mandir")
    val destStationId: StateFlow<String?> = _destStationId.asStateFlow()

    private val _routePreference = MutableStateFlow(RoutingPreference.FASTEST)
    val routePreference: StateFlow<RoutingPreference> = _routePreference.asStateFlow()

    // Computed route result
    private val _computedRoute = MutableStateFlow<RouteJourney?>(null)
    val computedRoute: StateFlow<RouteJourney?> = _computedRoute.asStateFlow()

    // Station search and select details
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedStationId = MutableStateFlow<String?>("old_high_court")
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    // City Selection Mode (Ahmedabad/Gandhinagar or Surat)
    private val _selectedCity = MutableStateFlow("ahmedabad") // "ahmedabad" or "surat"
    val selectedCity: StateFlow<String> = _selectedCity.asStateFlow()

    // Active trip progress mode
    private val _activeJourneyStepIndex = MutableStateFlow(0)
    val activeJourneyStepIndex: StateFlow<Int> = _activeJourneyStepIndex.asStateFlow()

    private val _isJourneyModeActive = MutableStateFlow(false)
    val isJourneyModeActive: StateFlow<Boolean> = _isJourneyModeActive.asStateFlow()

    // Observables from Repository
    val favorites: StateFlow<Set<String>> = repository.favoriteStationIds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val mobilityCard: StateFlow<DbMobilityCard?> = repository.mobilityCard
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeTickets: StateFlow<List<DbTicket>> = repository.activeTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val simCrowded: StateFlow<Boolean> = repository.simCrowded
    val simDelayed: StateFlow<Boolean> = repository.simDelayed
    val closedStations: StateFlow<Set<String>> = repository.closedStations
    val disruptedLines: StateFlow<Set<String>> = repository.disruptedLines
    val simTime: StateFlow<String> = repository.simTime

    // Live Simulated Train updates
    val simulatedTrains: StateFlow<List<SimulatedTrain>> = MetroSimulationEngine.simulatedTrains
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Live Alerts
    private val _serviceAlerts = MutableStateFlow<List<ServiceAlert>>(emptyList())
    val serviceAlerts: StateFlow<List<ServiceAlert>> = _serviceAlerts.asStateFlow()

    init {
        // Start simulation loop
        MetroSimulationEngine.startSimulation()
        refreshAlerts()

        // Auto calculate initial route
        calculateRoute()
    }

    override fun onCleared() {
        super.onCleared()
        MetroSimulationEngine.stopSimulation()
    }

    fun setLanguage(lang: MetroLanguage) {
        _currentLanguage.value = lang
    }

    fun selectCity(city: String) {
        _selectedCity.value = city
    }

    fun setOrigin(stationId: String?) {
        _originStationId.value = stationId
        calculateRoute()
    }

    fun setDestination(stationId: String?) {
        _destStationId.value = stationId
        calculateRoute()
    }

    fun setRoutePreference(pref: RoutingPreference) {
        _routePreference.value = pref
        calculateRoute()
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectStation(id: String?) {
        _selectedStationId.value = id
    }

    fun swapStations() {
        val temp = _originStationId.value
        _originStationId.value = _destStationId.value
        _destStationId.value = temp
        calculateRoute()
    }

    fun calculateRoute() {
        val orig = _originStationId.value
        val dest = _destStationId.value
        if (orig != null && dest != null) {
            _computedRoute.value = repository.findRoute(orig, dest, _routePreference.value)
        } else {
            _computedRoute.value = null
        }
    }

    fun toggleFavorite(stationId: String) {
        viewModelScope.launch {
            repository.toggleFavorite(stationId)
        }
    }

    fun rechargeCard(amount: Double) {
        viewModelScope.launch {
            repository.rechargeMobilityCard(amount)
        }
    }

    fun buyTicket(originId: String, destinationId: String, count: Int, price: Double) {
        viewModelScope.launch {
            repository.purchaseTicket(originId, destinationId, count, price)
        }
    }

    fun clearTickets() {
        viewModelScope.launch {
            repository.clearTickets()
        }
    }

    // Active Journey Actions
    fun startActiveJourney() {
        _isJourneyModeActive.value = true
        _activeJourneyStepIndex.value = 0
    }

    fun endActiveJourney() {
        _isJourneyModeActive.value = false
        _activeJourneyStepIndex.value = 0
    }

    fun advanceJourneyStep() {
        val route = _computedRoute.value ?: return
        val currentIdx = _activeJourneyStepIndex.value
        if (currentIdx < route.steps.size - 1) {
            _activeJourneyStepIndex.value = currentIdx + 1
        } else {
            // Reached destination! Deduct fare from travel card as standard GMRC tap-out
            viewModelScope.launch {
                val originName = route.steps.firstOrNull()?.getFromStationName(MetroLanguage.ENGLISH) ?: "Origin"
                val destName = route.steps.lastOrNull()?.getToStationName(MetroLanguage.ENGLISH) ?: "Dest"
                repository.deductMobilityCard(route.totalFare, originName, destName)
            }
            endActiveJourney()
        }
    }

    // Simulation commands
    fun updateSimTime(time: String) {
        viewModelScope.launch {
            repository.setSimulationTime(time)
        }
    }

    fun toggleCrowding() {
        viewModelScope.launch {
            repository.toggleCrowding()
        }
    }

    fun toggleDelays() {
        viewModelScope.launch {
            repository.toggleDelays()
            refreshAlerts()
            calculateRoute() // Recalculate route to factor in delays
        }
    }

    fun toggleStationClosure(stationId: String) {
        viewModelScope.launch {
            repository.toggleStationClosure(stationId)
            refreshAlerts()
            calculateRoute()
        }
    }

    fun toggleLineDisruption(lineId: String) {
        viewModelScope.launch {
            repository.toggleLineDisruption(lineId)
            refreshAlerts()
            calculateRoute()
        }
    }

    fun resetSimulation() {
        viewModelScope.launch {
            repository.resetSimulation()
            refreshAlerts()
            calculateRoute()
        }
    }

    fun refreshAlerts() {
        _serviceAlerts.value = repository.getActiveAlerts()
    }
}
