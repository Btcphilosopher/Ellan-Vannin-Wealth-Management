package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Charcoal = Color(0xFF121212)
val CardBackground = Color(0xFF1E1E1E)
val ConcreteGrey = Color(0xFF333333)
val MutedConcrete = Color(0xFF555555)
val LightGrey = Color(0xFF888888)

val WarmWhite = Color(0xFFFAFAFA)
val OffWhite = Color(0xFFEEEEEE)

val DeepBlue = Color(0xFF1E88E5)
val Terracotta = Color(0xFFD84315)
val Saffron = Color(0xFFFF8F00)
val Sandstone = Color(0xFFD7C49E)
val MutedGreen = Color(0xFF2E7D32)
val ActiveLineGlow = Color(0xFF4CAF50)
