package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.data.Repository
import com.example.data.Ticket
import com.example.ui.MetroViewModel
import com.example.ui.Strings
import com.example.ui.localizedString
import com.example.ui.theme.MetroRed
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuyTicketScreen(viewModel: MetroViewModel, navController: NavController) {
    var selectedType by remember { mutableStateOf(0) } // 0: Single, 1: Day, 2: Multi-day
    var passengers by remember { mutableStateOf(1) }

    val ticketTypesNL = listOf(Strings.SINGLE_JOURNEY_NL, Strings.DAY_TICKET_NL, Strings.MULTI_DAY_TICKET_NL)
    val ticketTypesEN = listOf(Strings.SINGLE_JOURNEY_EN, Strings.DAY_TICKET_EN, Strings.MULTI_DAY_TICKET_EN)
    val ticketPrices = listOf("€3.40", "€9.00", "€15.00")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(localizedString(Strings.BUY_TICKET_NL, Strings.BUY_TICKET_EN, viewModel)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(24.dp)
        ) {
            
            Text(
                text = localizedString(Strings.DEMO_DATA_NL, Strings.DEMO_DATA_EN, viewModel),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Ticket Types
            ticketTypesNL.indices.forEach { index ->
                val typeName = localizedString(ticketTypesNL[index], ticketTypesEN[index], viewModel)
                Card(
                    onClick = { selectedType = index },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedType == index) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = typeName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedType == index) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = ticketPrices[index],
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = if (selectedType == index) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Passengers
            Text(
                text = if (viewModel.isEnglish.collectAsState().value) "Passengers" else "Passagiers",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { if (passengers > 1) passengers-- }) {
                    Text("-", style = MaterialTheme.typography.titleLarge)
                }
                Text(
                    text = passengers.toString(),
                    style = MaterialTheme.typography.displayMedium,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
                Button(onClick = { passengers++ }) {
                    Text("+", style = MaterialTheme.typography.titleLarge)
                }
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            
            val total = ticketPrices[selectedType].replace("€", "").toFloat() * passengers
            val typeName = localizedString(ticketTypesNL[selectedType], ticketTypesEN[selectedType], viewModel)

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("JE KAARTJE", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(typeName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("$passengers passagier(s)", style = MaterialTheme.typography.bodyLarge)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(String.format("€%.2f", total), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = MetroRed)
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Button(
                onClick = { 
                    val ticket = Ticket(
                        id = UUID.randomUUID().toString(),
                        typeName = typeName,
                        passengers = passengers,
                        validFrom = "Vandaag 00:00",
                        validUntil = "Morgen 04:00",
                        price = String.format("€%.2f", total),
                        active = true
                    )
                    Repository.buyTicket(ticket)
                    navController.popBackStack()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MetroRed)
            ) {
                Text(
                    text = localizedString(Strings.BUY_TICKET_NL, Strings.BUY_TICKET_EN, viewModel),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}
