package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.data.Repository
import com.example.navigation.Screen
import com.example.ui.MetroViewModel
import com.example.ui.Strings
import com.example.ui.localizedString
import com.example.ui.theme.MetroRed

@Composable
fun TicketsScreen(viewModel: MetroViewModel, navController: NavController) {
    val myTickets by Repository.myTickets.collectAsState()
    
    val activeTickets = myTickets.filter { it.active }
    val expiredTickets = myTickets.filter { !it.active }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = localizedString(Strings.TICKETS_NL, Strings.TICKETS_EN, viewModel),
                style = MaterialTheme.typography.displayLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(32.dp))
            
            Button(
                onClick = { navController.navigate(Screen.BuyTicket.route) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MetroRed)
            ) {
                Text(
                    text = localizedString(Strings.BUY_TICKET_NL, Strings.BUY_TICKET_EN, viewModel),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
            
            Spacer(modifier = Modifier.height(48.dp))
            
            Text(
                text = localizedString(Strings.MY_TICKETS_NL, Strings.MY_TICKETS_EN, viewModel),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            if (activeTickets.isNotEmpty()) {
                Text(
                    text = localizedString(Strings.ACTIVE_NL, Strings.ACTIVE_EN, viewModel),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
        }
        
        items(activeTickets) { ticket ->
            TicketCard(ticket = ticket) {
                navController.navigate(Screen.TicketDetail.createRoute(ticket.id))
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
        
        if (expiredTickets.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = localizedString(Strings.EXPIRED_NL, Strings.EXPIRED_EN, viewModel),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
            
            items(expiredTickets) { ticket ->
                TicketCard(ticket = ticket, isExpired = true) {
                    navController.navigate(Screen.TicketDetail.createRoute(ticket.id))
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun TicketCard(ticket: com.example.data.Ticket, isExpired: Boolean = false, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isExpired) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = ticket.typeName,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = if (isExpired) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "${ticket.passengers} ${if(ticket.passengers > 1) "passagiers" else "passagier"}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = if (isExpired) "Verlopen op: ${ticket.validUntil}" else "Geldig tot: ${ticket.validUntil}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = if (isExpired) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary
            )
        }
    }
}
