package com.example.data

import com.example.ui.theme.*
import java.util.UUID

object DemoData {

    val Lines = listOf(
        Line("M50", "M50", LineM50Green),
        Line("M51", "M51", LineM51Orange),
        Line("M52", "M52", LineM52Blue),
        Line("M53", "M53", LineM53Red),
        Line("M54", "M54", LineM54Yellow)
    )

    val Stations = listOf(
        Station("CS", "Amsterdam Centraal", listOf("M51", "M52", "M53", "M54")),
        Station("ZUID", "Zuid", listOf("M50", "M51", "M52")),
        Station("NOORD", "Noord", listOf("M52")),
        Station("SLO", "Sloterdijk", listOf("M50", "M51")),
        Station("ROK", "Rokin", listOf("M52")),
        Station("VJZ", "Vijzelgracht", listOf("M52")),
        Station("DPP", "De Pijp", listOf("M52")),
        Station("EPL", "Europaplein", listOf("M52")),
        Station("AMST", "Amstelstation", listOf("M51", "M53", "M54")),
        Station("ISO", "Isolatorweg", listOf("M50", "M51")),
        Station("GAA", "Gaasperplas", listOf("M53")),
        Station("GEI", "Gein", listOf("M50", "M54"))
    )

    fun getStation(id: String): Station = Stations.find { it.id == id } ?: Stations.first()
    fun getLine(id: String): Line = Lines.find { it.id == id } ?: Lines.first()
    
    fun getLineStations(lineId: String): List<Station> {
        return Stations.filter { it.lines.contains(lineId) }
    }

    fun findJourneys(fromId: String, toId: String): List<Journey> {
        if (fromId == toId) return emptyList()
        val from = getStation(fromId)
        val to = getStation(toId)
        
        // Simple mock logic for direct and transfer journeys
        val commonLines = from.lines.intersect(to.lines.toSet())
        
        if (commonLines.isNotEmpty()) {
            val lineId = commonLines.first()
            return listOf(
                Journey(
                    id = UUID.randomUUID().toString(),
                    fromStationId = fromId,
                    toStationId = toId,
                    departureTime = "10:42",
                    arrivalTime = "10:56",
                    durationMin = 14,
                    legs = listOf(
                        JourneyLeg(LegType.METRO, lineId, fromId, toId, "10:42", "10:56", 14)
                    )
                ),
                Journey(
                    id = UUID.randomUUID().toString(),
                    fromStationId = fromId,
                    toStationId = toId,
                    departureTime = "10:49",
                    arrivalTime = "11:03",
                    durationMin = 14,
                    legs = listOf(
                        JourneyLeg(LegType.METRO, lineId, fromId, toId, "10:49", "11:03", 14)
                    )
                )
            )
        } else {
            // Transfer logic mock
            return listOf(
                Journey(
                    id = UUID.randomUUID().toString(),
                    fromStationId = fromId,
                    toStationId = toId,
                    departureTime = "10:42",
                    arrivalTime = "11:02",
                    durationMin = 20,
                    legs = listOf(
                        JourneyLeg(LegType.METRO, from.lines.first(), fromId, "ROK", "10:42", "10:49", 7),
                        JourneyLeg(LegType.TRANSFER, null, "ROK", "ROK", "10:49", "10:52", 3),
                        JourneyLeg(LegType.METRO, to.lines.first(), "ROK", toId, "10:52", "11:02", 10)
                    )
                )
            )
        }
    }

    fun getLiveDepartures(stationId: String): List<Departure> {
        val st = getStation(stationId)
        return st.lines.mapIndexed { index, lineId ->
            Departure(lineId, if (index % 2 == 0) "Zuid" else "Centraal", (index + 1) * 3, "Perron ${index % 2 + 1}")
        }
    }
}
