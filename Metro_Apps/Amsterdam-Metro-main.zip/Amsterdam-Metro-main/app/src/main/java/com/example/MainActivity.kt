package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.data.Repository
import com.example.ui.MetroViewModel
import com.example.ui.screens.MainScreen
import com.example.ui.theme.MyTheme

class MainActivity : ComponentActivity() {
    
    private val viewModel: MetroViewModel by viewModels()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        Repository.init(this)
        
        enableEdgeToEdge()
        setContent {
            MyTheme {
                MainScreen(viewModel)
            }
        }
    }
}
