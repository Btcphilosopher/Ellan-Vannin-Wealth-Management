package com.example.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.navigation.Screen
import com.example.ui.MetroViewModel
import com.example.ui.Strings
import com.example.ui.localizedString
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsTransit
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.MoreHoriz

@Composable
fun MainScreen(viewModel: MetroViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val bottomBarScreens = listOf(
        Screen.Home,
        Screen.Map,
        Screen.Tickets,
        Screen.More
    )

    val showBottomBar = bottomBarScreens.any { it.route == currentDestination?.route }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
                    contentColor = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                ) {
                    val colors = androidx.compose.material3.NavigationBarItemDefaults.colors(
                        selectedIconColor = androidx.compose.material3.MaterialTheme.colorScheme.primary,
                        selectedTextColor = androidx.compose.material3.MaterialTheme.colorScheme.primary,
                        unselectedIconColor = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                        indicatorColor = androidx.compose.material3.MaterialTheme.colorScheme.surface
                    )
                    NavigationBarItem(
                        colors = colors,
                        icon = { Icon(Icons.Filled.DirectionsTransit, contentDescription = null) },
                        label = { Text(localizedString(Strings.JOURNEY_NL, Strings.JOURNEY_EN, viewModel), style = androidx.compose.material3.MaterialTheme.typography.labelSmall) },
                        selected = currentDestination?.hierarchy?.any { it.route == Screen.Home.route } == true,
                        onClick = {
                            navController.navigate(Screen.Home.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                    NavigationBarItem(
                        colors = colors,
                        icon = { Icon(Icons.Filled.Map, contentDescription = null) },
                        label = { Text(localizedString(Strings.MAP_NL, Strings.MAP_EN, viewModel), style = androidx.compose.material3.MaterialTheme.typography.labelSmall) },
                        selected = currentDestination?.hierarchy?.any { it.route == Screen.Map.route } == true,
                        onClick = {
                            navController.navigate(Screen.Map.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                    NavigationBarItem(
                        colors = colors,
                        icon = { Icon(Icons.Filled.ConfirmationNumber, contentDescription = null) },
                        label = { Text(localizedString(Strings.TICKETS_NL, Strings.TICKETS_EN, viewModel), style = androidx.compose.material3.MaterialTheme.typography.labelSmall) },
                        selected = currentDestination?.hierarchy?.any { it.route == Screen.Tickets.route } == true,
                        onClick = {
                            navController.navigate(Screen.Tickets.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                    NavigationBarItem(
                        colors = colors,
                        icon = { Icon(Icons.Filled.MoreHoriz, contentDescription = null) },
                        label = { Text(localizedString(Strings.MORE_NL, Strings.MORE_EN, viewModel), style = androidx.compose.material3.MaterialTheme.typography.labelSmall) },
                        selected = currentDestination?.hierarchy?.any { it.route == Screen.More.route } == true,
                        onClick = {
                            navController.navigate(Screen.More.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen(viewModel, navController) }
            composable(Screen.Map.route) { MapScreen(viewModel, navController) }
            composable(Screen.Tickets.route) { TicketsScreen(viewModel, navController) }
            composable(Screen.More.route) { MoreScreen(viewModel, navController) }
            
            composable(Screen.StationSearch.route) { backStackEntry ->
                val type = backStackEntry.arguments?.getString("type") ?: "from"
                StationSearchScreen(viewModel, navController, type)
            }
            composable(Screen.JourneyResults.route) { backStackEntry ->
                val from = backStackEntry.arguments?.getString("from") ?: ""
                val to = backStackEntry.arguments?.getString("to") ?: ""
                JourneyResultsScreen(viewModel, navController, from, to)
            }
            composable(Screen.JourneyDetail.route) { backStackEntry ->
                val journeyId = backStackEntry.arguments?.getString("journeyId") ?: ""
                JourneyDetailScreen(viewModel, navController, journeyId)
            }
            composable(Screen.StationDetail.route) { backStackEntry ->
                val stationId = backStackEntry.arguments?.getString("stationId") ?: ""
                StationDetailScreen(viewModel, navController, stationId)
            }
            composable(Screen.BuyTicket.route) { BuyTicketScreen(viewModel, navController) }
            composable(Screen.TicketDetail.route) { backStackEntry ->
                val ticketId = backStackEntry.arguments?.getString("ticketId") ?: ""
                TicketDetailScreen(viewModel, navController, ticketId)
            }
        }
    }
}
