package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FavoriteJourney
import com.example.data.Repository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class MetroViewModel : ViewModel() {

    // Localization
    val isEnglish = MutableStateFlow(false)

    fun toggleLanguage() {
        isEnglish.value = !isEnglish.value
    }

    // Journey Planner State
    val fromStationId = MutableStateFlow<String?>(null)
    val toStationId = MutableStateFlow<String?>(null)

    fun setFromStation(id: String) {
        fromStationId.value = id
    }

    fun setToStation(id: String) {
        toStationId.value = id
    }
    
    fun swapStations() {
        val temp = fromStationId.value
        fromStationId.value = toStationId.value
        toStationId.value = temp
    }

    // Favorites
    val favorites: StateFlow<List<FavoriteJourney>> = Repository.getDao().getFavorites()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addFavorite(from: String, to: String, title: String, subtitle: String) {
        viewModelScope.launch {
            Repository.getDao().addFavorite(
                FavoriteJourney(
                    id = UUID.randomUUID().toString(),
                    fromStationId = from,
                    toStationId = to,
                    title = title,
                    subtitle = subtitle
                )
            )
        }
    }
}
