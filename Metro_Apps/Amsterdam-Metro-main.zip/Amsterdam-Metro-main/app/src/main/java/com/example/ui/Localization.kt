package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue

object Strings {
    const val PLAN_JOURNEY_NL = "PLAN REIS"
    const val PLAN_JOURNEY_EN = "PLAN JOURNEY"
    const val WHERE_TO_NL = "Waar wil je naartoe?"
    const val WHERE_TO_EN = "Where do you want to go?"
    const val FROM_NL = "Van"
    const val FROM_EN = "From"
    const val TO_NL = "Naar"
    const val TO_EN = "To"
    const val CHOOSE_STATION_NL = "Kies station"
    const val CHOOSE_STATION_EN = "Choose station"
    const val CHOOSE_DESTINATION_NL = "Kies bestemming"
    const val CHOOSE_DESTINATION_EN = "Choose destination"
    const val QUICK_DESTINATIONS_NL = "Snelle bestemmingen"
    const val QUICK_DESTINATIONS_EN = "Quick destinations"
    const val FAVORITES_NL = "Favorieten"
    const val FAVORITES_EN = "Favorites"
    const val JOURNEY_NL = "Reis"
    const val JOURNEY_EN = "Journey"
    const val MAP_NL = "Kaart"
    const val MAP_EN = "Map"
    const val TICKETS_NL = "Tickets"
    const val TICKETS_EN = "Tickets"
    const val MORE_NL = "Meer"
    const val MORE_EN = "More"
    const val BUY_TICKET_NL = "KOOP EEN KAARTJE"
    const val BUY_TICKET_EN = "BUY A TICKET"
    const val MY_TICKETS_NL = "MIJN TICKETS"
    const val MY_TICKETS_EN = "MY TICKETS"
    const val ACTIVE_NL = "ACTIEF"
    const val ACTIVE_EN = "ACTIVE"
    const val EXPIRED_NL = "VERLOPEN"
    const val EXPIRED_EN = "EXPIRED"
    const val SINGLE_JOURNEY_NL = "Enkele Reis"
    const val SINGLE_JOURNEY_EN = "Single Journey"
    const val DAY_TICKET_NL = "Dagkaart"
    const val DAY_TICKET_EN = "Day Ticket"
    const val MULTI_DAY_TICKET_NL = "Meerdagenkaart"
    const val MULTI_DAY_TICKET_EN = "Multi-Day Ticket"
    const val DEPARTURES_NL = "VERTREKKEN"
    const val DEPARTURES_EN = "DEPARTURES"
    const val DEPARTURE_NL = "Vertrek"
    const val DEPARTURE_EN = "Departure"
    const val ARRIVAL_NL = "Aankomst"
    const val ARRIVAL_EN = "Arrival"
    const val DEMO_DATA_NL = "DEMO DATA"
    const val DEMO_DATA_EN = "DEMO DATA"
    const val SHOW_TICKET_NL = "TOON KAARTJE"
    const val SHOW_TICKET_EN = "SHOW TICKET"
}

@Composable
fun localizedString(nl: String, en: String, viewModel: MetroViewModel): String {
    val isEnglish by viewModel.isEnglish.collectAsState()
    return if (isEnglish) en else nl
}
