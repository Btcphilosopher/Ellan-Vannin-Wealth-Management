package com.example.data

import android.content.Context
import androidx.room.Room

object Repository {
    private var database: MetroDatabase? = null
    
    fun init(context: Context) {
        if (database == null) {
            database = Room.databaseBuilder(
                context.applicationContext,
                MetroDatabase::class.java,
                "metro_db"
            ).build()
        }
    }
    
    fun getDao(): MetroDao {
        return database!!.metroDao()
    }
    
    // In-memory tickets for the prototype
    val myTickets = kotlinx.coroutines.flow.MutableStateFlow<List<Ticket>>(emptyList())
    
    fun buyTicket(ticket: Ticket) {
        val current = myTickets.value.toMutableList()
        current.add(0, ticket)
        myTickets.value = current
    }
}
