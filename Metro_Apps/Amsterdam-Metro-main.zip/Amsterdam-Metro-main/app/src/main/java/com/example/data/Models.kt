package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow

data class Station(
    val id: String,
    val name: String,
    val lines: List<String> // line IDs
)

data class Line(
    val id: String,
    val name: String,
    val color: Color
)

data class JourneyLeg(
    val type: LegType, // METRO, TRANSFER
    val lineId: String? = null,
    val fromStationId: String,
    val toStationId: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMin: Int
)

enum class LegType {
    METRO, TRANSFER
}

data class Journey(
    val id: String,
    val fromStationId: String,
    val toStationId: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMin: Int,
    val legs: List<JourneyLeg>
)

data class Departure(
    val lineId: String,
    val destination: String,
    val timeInMin: Int,
    val platform: String
)

data class Ticket(
    val id: String,
    val typeName: String,
    val passengers: Int,
    val validFrom: String,
    val validUntil: String,
    val price: String,
    val active: Boolean
)
