package com.example.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Main : Screen("main")
    object Home : Screen("home")
    object Map : Screen("map")
    object Tickets : Screen("tickets")
    object More : Screen("more")
    object JourneyResults : Screen("journey_results/{from}/{to}") {
        fun createRoute(from: String, to: String) = "journey_results/$from/$to"
    }
    object JourneyDetail : Screen("journey_detail/{journeyId}") {
        fun createRoute(journeyId: String) = "journey_detail/$journeyId"
    }
    object StationDetail : Screen("station_detail/{stationId}") {
        fun createRoute(stationId: String) = "station_detail/$stationId"
    }
    object LineDetail : Screen("line_detail/{lineId}") {
        fun createRoute(lineId: String) = "line_detail/$lineId"
    }
    object BuyTicket : Screen("buy_ticket")
    object TicketDetail : Screen("ticket_detail/{ticketId}") {
        fun createRoute(ticketId: String) = "ticket_detail/$ticketId"
    }
    object StationSearch : Screen("station_search/{type}") {
        fun createRoute(type: String) = "station_search/$type" // type = from or to
    }
    object Settings : Screen("settings")
}
