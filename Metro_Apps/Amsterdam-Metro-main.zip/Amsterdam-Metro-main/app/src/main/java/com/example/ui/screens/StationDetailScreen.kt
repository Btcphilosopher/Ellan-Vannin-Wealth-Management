package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.data.DemoData
import com.example.ui.MetroViewModel
import com.example.ui.Strings
import com.example.ui.localizedString
import com.example.ui.theme.MetroRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationDetailScreen(viewModel: MetroViewModel, navController: NavController, stationId: String) {
    val station = DemoData.getStation(stationId)
    val departures = DemoData.getLiveDepartures(stationId)
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(station.name) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp)
        ) {
            item {
                Text(
                    text = localizedString(Strings.DEMO_DATA_NL, Strings.DEMO_DATA_EN, viewModel),
                    style = MaterialTheme.typography.labelLarge,
                    color = MetroRed
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = localizedString(Strings.DEPARTURES_NL, Strings.DEPARTURES_EN, viewModel),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(24.dp))
            }
            
            items(departures) { dep ->
                val line = DemoData.getLine(dep.lineId)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = line.color,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = line.name,
                                color = MaterialTheme.colorScheme.onPrimary,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(16.dp))
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Text(dep.destination, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(dep.platform, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        
                        Text("${dep.timeInMin} min", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MetroRed)
                    }
                }
            }
        }
    }
}
