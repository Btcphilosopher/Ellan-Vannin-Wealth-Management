package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "favorite_journeys")
data class FavoriteJourney(
    @PrimaryKey val id: String,
    val fromStationId: String,
    val toStationId: String,
    val title: String,
    val subtitle: String
)

@Dao
interface MetroDao {
    @Query("SELECT * FROM favorite_journeys")
    fun getFavorites(): Flow<List<FavoriteJourney>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(journey: FavoriteJourney)

    @Query("DELETE FROM favorite_journeys WHERE id = :id")
    suspend fun removeFavorite(id: String)
}

@Database(entities = [FavoriteJourney::class], version = 1, exportSchema = false)
abstract class MetroDatabase : RoomDatabase() {
    abstract fun metroDao(): MetroDao
}
