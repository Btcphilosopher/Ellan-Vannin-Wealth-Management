package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MetroRed = Color(0xFFED1C24)
val MetroAnthracite = Color(0xFF1A1A1A)
val MetroAnthraciteLight = Color(0xFF2C2C2C)
val MetroCoolGray = Color(0xFFF2F2F2)
val MetroCoolGrayDark = Color(0xFF999999)
val MetroWhite = Color(0xFFFFFFFF)
val MetroSurfaceVariant = Color(0xFFF8F8F8)
val MetroBorder = Color(0xFFEEEEEE)

// Metro Lines
val LineM50Green = Color(0xFF1D8C43)
val LineM51Orange = Color(0xFFF16E22)
val LineM52Blue = Color(0xFF5CC5E8)
val LineM53Red = Color(0xFFE3000F)
val LineM54Yellow = Color(0xFFFFD100)

val LightBackground = MetroCoolGray
val LightSurface = MetroWhite
val LightOnSurface = MetroAnthracite

val DarkBackground = MetroAnthracite
val DarkSurface = MetroAnthraciteLight
val DarkOnSurface = MetroWhite
