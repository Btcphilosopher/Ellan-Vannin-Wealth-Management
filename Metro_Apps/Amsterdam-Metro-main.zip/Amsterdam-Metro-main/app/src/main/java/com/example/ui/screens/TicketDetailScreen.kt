package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.data.Repository
import com.example.ui.MetroViewModel
import com.example.ui.Strings
import com.example.ui.localizedString
import com.example.ui.theme.MetroRed
import com.example.ui.theme.MetroWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketDetailScreen(viewModel: MetroViewModel, navController: NavController, ticketId: String) {
    val ticket = Repository.myTickets.collectAsState().value.find { it.id == ticketId }

    if (ticket == null) {
        navController.popBackStack()
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(localizedString(Strings.SHOW_TICKET_NL, Strings.SHOW_TICKET_EN, viewModel)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MetroRed, titleContentColor = MetroWhite, navigationIconContentColor = MetroWhite)
            )
        },
        containerColor = MetroRed
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "AMSTERDAM METRO",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = ticket.typeName,
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // Faux QR Code
                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .background(Color.White)
                            .padding(8.dp)
                    ) {
                        // Drawing a fake QR pattern for demo
                        Row(modifier = Modifier.fillMaxSize()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Box(modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black))
                                Box(modifier = Modifier.weight(0.5f).fillMaxWidth().background(Color.White))
                                Box(modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Box(modifier = Modifier.weight(0.5f).fillMaxWidth().background(Color.White))
                                Box(modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black))
                                Box(modifier = Modifier.weight(0.5f).fillMaxWidth().background(Color.White))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Box(modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black))
                                Box(modifier = Modifier.weight(0.5f).fillMaxWidth().background(Color.White))
                                Box(modifier = Modifier.weight(1f).fillMaxWidth().background(Color.Black))
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = localizedString(Strings.DEMO_DATA_NL, Strings.DEMO_DATA_EN, viewModel),
                        style = MaterialTheme.typography.labelLarge,
                        color = MetroRed
                    )

                    Spacer(modifier = Modifier.height(32.dp))
                    
                    Divider(color = MaterialTheme.colorScheme.surfaceVariant)
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Geldig vanaf", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(ticket.validFrom, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Geldig tot", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(ticket.validUntil, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Passagiers", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(ticket.passengers.toString(), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Nummer", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(ticket.id.take(8).uppercase(), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
