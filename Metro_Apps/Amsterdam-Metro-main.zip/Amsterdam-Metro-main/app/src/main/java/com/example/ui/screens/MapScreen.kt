package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.R
import com.example.ui.MetroViewModel
import com.example.ui.Strings
import com.example.ui.localizedString

@Composable
fun MapScreen(viewModel: MetroViewModel, navController: NavController) {
    var scale by remember { mutableStateOf(1f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 3f)
                    val maxOffset = (scale - 1) * 1000f // Rough estimate bounds
                    offsetX = (offsetX + pan.x * scale).coerceIn(-maxOffset, maxOffset)
                    offsetY = (offsetY + pan.y * scale).coerceIn(-maxOffset, maxOffset)
                    if (scale == 1f) {
                        offsetX = 0f
                        offsetY = 0f
                    }
                }
            }
    ) {
        // We'll use the generated metro map image
        Image(
            painter = painterResource(id = R.drawable.img_metro_map),
            contentDescription = "Map",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offsetX,
                    translationY = offsetY
                )
        )
        
        Text(
            text = localizedString(Strings.MAP_NL, Strings.MAP_EN, viewModel).uppercase(),
            style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(24.dp)
        )
    }
}
