package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.data.DemoData
import com.example.data.LegType
import com.example.ui.MetroViewModel
import com.example.ui.Strings
import com.example.ui.localizedString
import com.example.ui.theme.MetroCoolGrayDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyDetailScreen(viewModel: MetroViewModel, navController: NavController, journeyId: String) {
    // In a real app we'd fetch this from the ViewModel or Repository.
    // For demo, we just grab any journey.
    val journey = DemoData.findJourneys("CS", "ZUID").firstOrNull() // Hack for prototype demo
    
    if (journey == null) {
        navController.popBackStack()
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(localizedString(Strings.JOURNEY_NL, Strings.JOURNEY_EN, viewModel)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.addFavorite(journey.fromStationId, journey.toStationId, DemoData.getStation(journey.fromStationId).name, DemoData.getStation(journey.toStationId).name) }) {
                        Icon(Icons.Filled.FavoriteBorder, contentDescription = "Favorite")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp)
        ) {
            Text(
                text = "${journey.durationMin} min",
                style = MaterialTheme.typography.displayLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(32.dp))
            
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(journey.legs) { leg ->
                    if (leg.type == LegType.METRO) {
                        val line = DemoData.getLine(leg.lineId!!)
                        val from = DemoData.getStation(leg.fromStationId)
                        val to = DemoData.getStation(leg.toStationId)
                        
                        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                            // Timeline column
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(40.dp)) {
                                Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(line.color))
                                Box(modifier = Modifier.width(4.dp).weight(1f).background(line.color))
                                Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(line.color))
                            }
                            
                            Spacer(modifier = Modifier.width(16.dp))
                            
                            // Info column
                            Column(modifier = Modifier.weight(1f).padding(bottom = 24.dp)) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(from.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text(leg.departureTime, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                                }
                                
                                Spacer(modifier = Modifier.height(16.dp))
                                
                                Surface(
                                    color = line.color,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = line.name,
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                
                                Spacer(modifier = Modifier.height(16.dp))
                                
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(to.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text(leg.arrivalTime, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    } else if (leg.type == LegType.TRANSFER) {
                        Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(40.dp)) {
                                Box(modifier = Modifier.width(4.dp).weight(1f).background(MetroCoolGrayDark))
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f).padding(bottom = 24.dp)) {
                                Text("Overstappen", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}
