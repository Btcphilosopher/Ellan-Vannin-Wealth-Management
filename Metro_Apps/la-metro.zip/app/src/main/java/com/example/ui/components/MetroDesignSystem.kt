package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.AlertSeverity
import com.example.ui.theme.*

// 1. LINE BADGE
@Composable
fun LineBadge(
    lineId: String,
    modifier: Modifier = Modifier,
    size: Int = 28
) {
    val (color, text) = when (lineId) {
        "A" -> Pair(MetroBlue, "A")
        "B" -> Pair(MetroRed, "B")
        "C" -> Pair(MetroGreen, "C")
        "D" -> Pair(MetroPurple, "D")
        "E" -> Pair(MetroExpo, "E")
        "K" -> Pair(MetroPink, "K")
        "J" -> Pair(MetroSilver, "J")
        else -> if (lineId.startsWith("BUS")) Pair(MetroGold, lineId.replace("BUS-", "")) else Pair(MutedText, lineId)
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(color)
    ) {
        Text(
            text = text,
            color = if (color == MetroGold) Color.Black else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size * 0.48).sp,
            textAlign = TextAlign.Center
        )
    }
}

// 2. METRO BUTTON
@Composable
fun MetroButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isSecondary: Boolean = false,
    icon: ImageVector? = null,
    testTag: String = ""
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSecondary) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary,
            contentColor = if (isSecondary) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onPrimary
        ),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag(testTag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                letterSpacing = 0.5.sp
            )
        }
    }
}

// 3. STATION CARD
@Composable
fun StationCard(
    name: String,
    lines: List<String>,
    distance: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    lines.forEach { lineId ->
                        LineBadge(lineId = lineId, size = 20)
                    }
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Icon(
                    Icons.Default.DirectionsWalk,
                    contentDescription = null,
                    tint = MutedText,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = distance,
                    fontSize = 13.sp,
                    color = MutedText,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

// 4. ARRIVAL ROW
@Composable
fun ArrivalRow(
    lineId: String,
    lineName: String,
    destination: String,
    minutes: Int,
    platform: String,
    status: String,
    isOffline: Boolean = false,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition()
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp, horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LineBadge(lineId = lineId, size = 32)
        Spacer(modifier = Modifier.width(12.dp))
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = destination,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "$platform • $status",
                fontSize = 12.sp,
                color = if (status.contains("SUSPENDED")) SoftOrange else MutedText,
                fontWeight = FontWeight.Medium
            )
        }

        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (minutes <= 5 && !isOffline && !status.contains("SUSPENDED")) {
                    Box(
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(SoftGreen.copy(alpha = pulseAlpha))
                    )
                }
                Text(
                    text = if (isOffline) "--" else if (minutes == 0) "Arriving" else "${minutes}m",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = if (minutes <= 2 && !isOffline && !status.contains("SUSPENDED")) SoftGreen else MaterialTheme.colorScheme.onSurface
                )
            }
            Text(
                text = if (isOffline) "Scheduled" else "Live",
                fontSize = 10.sp,
                color = if (isOffline) MutedText else SoftGreen,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// 5. ROUTE CARD
@Composable
fun RouteCard(
    duration: Int,
    transfers: Int,
    walkingMinutes: Int,
    departureTime: String,
    arrivalTime: String,
    tag: String,
    segments: List<String>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Duration and Tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${duration} min",
                        fontWeight = FontWeight.Black,
                        fontSize = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    if (tag.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (tag.contains("Alternative")) SoftOrange.copy(alpha = 0.15f) else MetroGold.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = tag.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (tag.contains("Alternative")) SoftOrange else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
                
                Text(
                    text = "$departureTime — $arrivalTime",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = MutedText
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Route Overview (Segments Row)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                segments.forEachIndexed { index, seg ->
                    if (index > 0) {
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = MutedText,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    if (seg == "WALK") {
                        Icon(
                            Icons.Default.DirectionsWalk,
                            contentDescription = "Walk",
                            tint = MutedText,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        LineBadge(lineId = seg, size = 20)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Footer Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (transfers == 0) "Direct trip" else if (transfers == 1) "1 transfer" else "$transfers transfers",
                    fontSize = 13.sp,
                    color = MutedText,
                    fontWeight = FontWeight.Medium
                )
                
                Text(
                    text = "Walk ${walkingMinutes} min",
                    fontSize = 13.sp,
                    color = MutedText,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

// 6. JOURNEY STEP (Timeline Item)
@Composable
fun JourneyStep(
    time: String,
    title: String,
    subtitle: String,
    mode: String, // "WALK", "RAIL", "BUS"
    lineId: String?,
    lineColorHex: String?,
    isLast: Boolean = false,
    modifier: Modifier = Modifier
) {
    val lineCol = if (lineColorHex != null) Color(android.graphics.Color.parseColor(lineColorHex)) else MutedText

    Row(modifier = modifier.fillMaxWidth()) {
        // Time Column
        Text(
            text = time,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.width(60.dp)
        )

        // Timeline Marker & Line
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(if (mode == "WALK") MutedText else lineCol)
            )
            
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(50.dp)
                        .background(if (mode == "WALK") BorderGrey else lineCol)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Content Column
        Column(modifier = Modifier.weight(1f).padding(bottom = 20.dp)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 13.sp,
                color = MutedText
            )
            if (lineId != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LineBadge(lineId = lineId, size = 16)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LA Metro Service",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = lineCol
                    )
                }
            }
        }
    }
}

// 7. ALERT CARD
@Composable
fun AlertCard(
    lineName: String,
    lineColorHex: String?,
    severity: AlertSeverity,
    title: String,
    description: String,
    updatedAgo: String,
    modifier: Modifier = Modifier
) {
    val tintColor = when (severity) {
        AlertSeverity.SEVERE -> MetroRed
        AlertSeverity.MAJOR -> SoftOrange
        AlertSeverity.MINOR -> MetroGold
        AlertSeverity.INFO -> MetroBlue
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
    ) {
        Row(modifier = Modifier.padding(16.dp)) {
            // Alert side stripe
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(64.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(tintColor)
            )
            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = lineName.uppercase(),
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp,
                        color = if (lineColorHex != null) Color(android.graphics.Color.parseColor(lineColorHex)) else MutedText
                    )
                    Text(
                        text = updatedAgo,
                        fontSize = 11.sp,
                        color = MutedText
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = description,
                    fontSize = 13.sp,
                    color = MutedText,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

// 8. MAP CONTROLS
@Composable
fun MapControl(
    selectedMode: String,
    onModeSelect: (String) -> Unit,
    onZoomIn: () -> Unit,
    onZoomOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Mode Selector Pills
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp))
        ) {
            Row(modifier = Modifier.padding(4.dp)) {
                listOf("RAIL", "BUS", "ALL").forEach { mode ->
                    val isSelected = selectedMode == mode
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { onModeSelect(mode) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = mode,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Zoom Buttons
        Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
        ) {
            Column {
                IconButton(onClick = onZoomIn, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "Zoom In", tint = MaterialTheme.colorScheme.onSurface)
                }
                Box(modifier = Modifier.width(40.dp).height(1.dp).background(MaterialTheme.colorScheme.outline))
                IconButton(onClick = onZoomOut, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.Remove, contentDescription = "Zoom Out", tint = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

// 9. TAP CARD
@Composable
fun TapCard(
    cardNumber: String,
    balance: Double,
    activePass: String?,
    modifier: Modifier = Modifier,
    testTag: String = "tap_card_mock"
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF000000),
                            Color(0xFF232526),
                            Color(0xFF414345)
                        )
                    )
                )
                .padding(20.dp)
        ) {
            // TAP Logo / branding
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column {
                    Text(
                        text = "TAP",
                        color = MetroGold,
                        fontWeight = FontWeight.Black,
                        fontSize = 32.sp,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Los Angeles",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Icon(
                    Icons.Default.Contactless,
                    contentDescription = "Contactless",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            // Card chip and details
            Column(
                modifier = Modifier.align(Alignment.BottomStart)
            ) {
                Text(
                    text = "BALANCE",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "$${String.format("%.2f", balance)}",
                    color = Color.White,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black
                )
                
                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = cardNumber,
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
            }

            // Active pass indicator
            if (activePass != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .clip(RoundedCornerShape(4.dp))
                        .background(MetroGold)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = activePass.uppercase(),
                        color = Color.Black,
                        fontWeight = FontWeight.Black,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

// 10. FARE CARD (For Store Purchases)
@Composable
fun FareCard(
    title: String,
    price: Double,
    description: String,
    onPurchase: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = description,
                    fontSize = 12.sp,
                    color = MutedText
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "$${String.format("%.2f", price)}",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                MetroButton(
                    text = "Buy",
                    onClick = onPurchase,
                    testTag = "buy_pass_${title.replace(" ", "_").lowercase()}"
                )
            }
        }
    }
}

// 11. PLACE CARD (Saved Locations)
@Composable
fun PlaceCard(
    name: String,
    address: String,
    iconName: String,
    onSelect: () -> Unit,
    onDelete: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val vector = when (iconName) {
        "home" -> Icons.Default.Home
        "work" -> Icons.Default.Work
        "school" -> Icons.Default.School
        "flight" -> Icons.Default.Flight
        else -> Icons.Default.Place
    }

    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
    ) {
        Row(
            modifier = Modifier
                .clickable { onSelect() }
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Icon(vector, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = address,
                        fontSize = 12.sp,
                        color = MutedText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (onDelete != null) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MutedText, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
