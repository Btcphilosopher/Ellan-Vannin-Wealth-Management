package com.example.ui.maps

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.JourneyOption
import com.example.data.models.MetroStation
import com.example.ui.components.MapControl
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetroViewModel

@Composable
fun MetroMapView(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val stations = viewModel.metroStations
    val busStops = viewModel.metroBusStops
    val selectedJourneyState by viewModel.selectedJourney.collectAsState()
    val isBLineSuspended by viewModel.isBLineInterrupted.collectAsState()

    // Map control state
    var mapMode by remember { mutableStateOf("ALL") } // RAIL, BUS, ALL
    var scale by remember { mutableFloatStateOf(1.2f) }
    var offsetX by remember { mutableFloatStateOf(-50f) }
    var offsetY by remember { mutableFloatStateOf(80f) }

    val density = LocalDensity.current

    // Pulsing animation for user location
    val infiniteTransition = rememberInfiniteTransition(label = "Pulse")
    val userHaloRadius by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "HaloRadius"
    )
    val userHaloAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "HaloAlpha"
    )

    // Bounds for Los Angeles coordinates to scale them to screen space
    val minLat = 33.90
    val maxLat = 34.18
    val minLng = -118.52
    val maxLng = -118.10

    val latSpan = maxLat - minLat
    val lngSpan = maxLng - minLng

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Core interactive canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                // Transform gestures listener (pan & zoom)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.6f, 4.0f)
                        offsetX += pan.x
                        offsetY += pan.y
                    }
                }
                // Interactive Click/Tap detector for map station nodes
                .pointerInput(Unit) {
                    detectTapGestures { tapOffset ->
                        // Helper to find projected coordinates in local scope
                        fun projectCoords(lat: Double, lng: Double, width: Float, height: Float): Offset {
                            val relativeLat = (lat - minLat) / latSpan
                            val projectedY = height - (relativeLat * height)

                            val relativeLng = (lng - minLng) / lngSpan
                            val projectedX = relativeLng * width

                            val centerX = width / 2f
                            val centerY = height / 2f
                            
                            val finalX = (projectedX - centerX) * scale + centerX + offsetX
                            val finalY = (projectedY - centerY) * scale + centerY + offsetY
                            return Offset(finalX.toFloat(), finalY.toFloat())
                        }

                        val w = size.width.toFloat()
                        val h = size.height.toFloat()

                        // Check if tap hit any station
                        if (mapMode == "RAIL" || mapMode == "ALL") {
                            stations.forEach { station ->
                                val stationPos = projectCoords(station.latitude, station.longitude, w, h)
                                val distance = (tapOffset - stationPos).getDistance()
                                val clickThreshold = with(density) { 24.dp.toPx() }

                                if (distance < clickThreshold) {
                                    viewModel.selectArrivalStation(station.id)
                                    viewModel.showStationPage(station.id)
                                }
                            }
                        }
                    }
                }
        ) {
            val width = size.width
            val height = size.height

            // Coordinate Projection helper for drawing
            fun project(lat: Double, lng: Double): Offset {
                val relativeLat = (lat - minLat) / latSpan
                val projectedY = height - (relativeLat * height)

                val relativeLng = (lng - minLng) / lngSpan
                val projectedX = relativeLng * width

                val centerX = width / 2f
                val centerY = height / 2f
                
                val finalX = (projectedX - centerX) * scale + centerX + offsetX
                val finalY = (projectedY - centerY) * scale + centerY + offsetY
                return Offset(finalX.toFloat(), finalY.toFloat())
            }

            // --- 1. DRAW TRANSIT LINES ---
            if (mapMode == "RAIL" || mapMode == "ALL") {
                // A Line (Blue) Path
                val aLineStations = listOf("LTA", "GAB", "7MC", "PIC")
                for (i in 0 until aLineStations.size - 1) {
                    val s1 = stations.firstOrNull { it.id == aLineStations[i] }
                    val s2 = stations.firstOrNull { it.id == aLineStations[i + 1] }
                    if (s1 != null && s2 != null) {
                        drawLine(
                            color = MetroBlue,
                            start = project(s1.latitude, s1.longitude),
                            end = project(s2.latitude, s2.longitude),
                            strokeWidth = 6.dp.toPx() * scale,
                            pathEffect = null
                        )
                    }
                }

                // B Line (Red) Path
                val bLineStations = listOf("NOH", "HHL", "HVI", "WVT", "7MC", "PSQ", "CCG", "UST")
                for (i in 0 until bLineStations.size - 1) {
                    val s1 = stations.firstOrNull { it.id == bLineStations[i] }
                    val s2 = stations.firstOrNull { it.id == bLineStations[i + 1] }
                    if (s1 != null && s2 != null) {
                        val isSectionSuspended = isBLineSuspended && 
                            ((s1.id == "HVI" && s2.id == "WVT") || (s1.id == "WVT" && s2.id == "7MC"))
                        
                        drawLine(
                            color = if (isSectionSuspended) MetroRed.copy(alpha = 0.2f) else MetroRed,
                            start = project(s1.latitude, s1.longitude),
                            end = project(s2.latitude, s2.longitude),
                            strokeWidth = 6.dp.toPx() * scale,
                            pathEffect = if (isSectionSuspended) PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f) else null
                        )
                    }
                }

                // D Line (Purple) Path
                val dLineStations = listOf("WVT", "7MC", "PSQ", "CCG", "UST")
                for (i in 0 until dLineStations.size - 1) {
                    val s1 = stations.firstOrNull { it.id == dLineStations[i] }
                    val s2 = stations.firstOrNull { it.id == dLineStations[i + 1] }
                    if (s1 != null && s2 != null) {
                        drawLine(
                            color = MetroPurple,
                            start = project(s1.latitude, s1.longitude),
                            end = project(s2.latitude, s2.longitude),
                            strokeWidth = 6.dp.toPx() * scale
                        )
                    }
                }

                // E Line (Expo) Path
                val eLineStations = listOf("SMO", "CUL", "7MC", "GAB", "LTA")
                for (i in 0 until eLineStations.size - 1) {
                    val s1 = stations.firstOrNull { it.id == eLineStations[i] }
                    val s2 = stations.firstOrNull { it.id == eLineStations[i + 1] }
                    if (s1 != null && s2 != null) {
                        drawLine(
                            color = MetroExpo,
                            start = project(s1.latitude, s1.longitude),
                            end = project(s2.latitude, s2.longitude),
                            strokeWidth = 6.dp.toPx() * scale
                        )
                    }
                }
            }

            // --- 2. DRAW BUS ROUTES ---
            if (mapMode == "BUS" || mapMode == "ALL") {
                // Simple Bus Route 720 (Santa Monica to Union Station via Wilshire Blvd)
                val line720StopCoords = listOf(
                    Offset(34.0135f, -118.4913f), // SM Pier
                    Offset(34.0592f, -118.4442f), // Westwood
                    Offset(34.0671f, -118.3995f), // Beverly Hills
                    Offset(34.0631f, -118.3615f), // Fairfax
                    Offset(34.0621f, -118.3441f), // La Brea
                    Offset(34.0625f, -118.2916f), // Vermont
                    Offset(34.0486f, -118.2587f), // 7th St Metro
                    Offset(34.0562f, -118.2365f)  // Union Station
                )
                for (i in 0 until line720StopCoords.size - 1) {
                    drawLine(
                        color = SoftOrange,
                        start = project(line720StopCoords[i].x.toDouble(), line720StopCoords[i].y.toDouble()),
                        end = project(line720StopCoords[i + 1].x.toDouble(), line720StopCoords[i + 1].y.toDouble()),
                        strokeWidth = 3.dp.toPx() * scale,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                }
            }

            // --- 3. DRAW CURRENT ACTIVE JOURNEY HIGHLIGHT (Dominant Route) ---
            selectedJourneyState?.let { journey ->
                journey.segments.forEach { segment ->
                    val sName = segment.fromName
                    val tName = segment.toName
                    
                    val lat1 = stations.firstOrNull { it.name == sName }?.latitude 
                        ?: busStops.firstOrNull { it.name == sName }?.latitude
                    val lng1 = stations.firstOrNull { it.name == sName }?.longitude 
                        ?: busStops.firstOrNull { it.name == sName }?.longitude

                    val lat2 = stations.firstOrNull { it.name == tName }?.latitude 
                        ?: busStops.firstOrNull { it.name == tName }?.latitude
                    val lng2 = stations.firstOrNull { it.name == tName }?.longitude 
                        ?: busStops.firstOrNull { it.name == tName }?.longitude

                    if (lat1 != null && lng1 != null && lat2 != null && lng2 != null) {
                        val segCol = if (segment.routeColorHex != null) {
                            Color(android.graphics.Color.parseColor(segment.routeColorHex))
                        } else {
                            MutedText
                        }

                        drawLine(
                            color = segCol,
                            start = project(lat1, lng1),
                            end = project(lat2, lng2),
                            strokeWidth = 10.dp.toPx() * scale,
                            pathEffect = if (segment.mode == "WALK") PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f) else null
                        )
                    }
                }
            }

            // --- 4. DRAW USER LOCATION (Pulsing Hollywood Location) ---
            val userLoc = project(34.1018, -118.3268) // Centered on Hollywood/Vine for the prototype
            drawCircle(
                color = MetroBlue.copy(alpha = userHaloAlpha),
                radius = userHaloRadius * scale,
                center = userLoc
            )
            drawCircle(
                color = Color.White,
                radius = 7.dp.toPx() * scale,
                center = userLoc
            )
            drawCircle(
                color = MetroBlue,
                radius = 5.dp.toPx() * scale,
                center = userLoc
            )

            // --- 5. DRAW STATION & STOP NODES & LABELS ---
            if (mapMode == "RAIL" || mapMode == "ALL") {
                stations.forEach { station ->
                    val point = project(station.latitude, station.longitude)
                    
                    val isSelected = viewModel.selectedArrivalStationId.value == station.id
                    val primaryColor = if (station.lines.contains("B")) MetroRed else if (station.lines.contains("A")) MetroBlue else MetroExpo

                    drawCircle(
                        color = if (isSelected) MetroGold else Color.White,
                        radius = (if (isSelected) 8.dp else 6.dp).toPx() * scale,
                        center = point,
                        style = Stroke(width = 3.dp.toPx() * scale)
                    )
                    drawCircle(
                        color = primaryColor,
                        radius = (if (isSelected) 5.dp else 4.dp).toPx() * scale,
                        center = point
                    )
                }
            }

            if ((mapMode == "BUS" || mapMode == "ALL") && scale > 1.2f) {
                busStops.forEach { stop ->
                    val point = project(stop.latitude, stop.longitude)
                    drawCircle(
                        color = Color.White,
                        radius = 4.dp.toPx() * scale,
                        center = point,
                        style = Stroke(width = 1.5f.dp.toPx() * scale)
                    )
                    drawCircle(
                        color = SoftOrange,
                        radius = 2.5f.dp.toPx() * scale,
                        center = point
                    )
                }
            }
        }

        // --- 6. OVERLAY CONTROLS ---
        MapControl(
            selectedMode = mapMode,
            onModeSelect = { mapMode = it },
            onZoomIn = { scale = (scale + 0.3f).coerceAtMost(4.0f) },
            onZoomOut = { scale = (scale - 0.3f).coerceAtLeast(0.6f) },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
                .safeDrawingPadding()
        )

        // Subtle Location Legend Banner
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(
                text = "LOS ANGELES BASIN TRANSIT MAP",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    }
}
