package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LA Metro Official Line Colors
val MetroBlue = Color(0xFF1073E6)      // A Line
val MetroRed = Color(0xFFE31B23)       // B Line
val MetroGreen = Color(0xFF00A550)     // C Line
val MetroPurple = Color(0xFF802F8F)    // D Line
val MetroExpo = Color(0xFFF2A900)      // E Line (Expo / Gold)
val MetroPink = Color(0xFFE94B8A)      // K Line
val MetroSilver = Color(0xFF8A9094)    // J Line (Bus Rapid Transit)

// Southern California Modernism Neutrals
val DeepCharcoal = Color(0xFF121212)   // Late-2020s Dark Background
val DarkCard = Color(0xFF1E1E1E)       // Dark Theme Cards
val WarmWhite = Color(0xFFFAFAF7)      // Sun-bleached warm background
val ConcreteGrey = Color(0xFFEFEFEA)   // Concrete grey surface
val BorderGrey = Color(0xFFD6D6CF)     // Subtle border line
val MetroGold = Color(0xFFFFD100)      // Main branding yellow-gold
val MutedText = Color(0xFF757570)      // Soft grey for secondary text
val SoftGreen = Color(0xFF4CAF50)      // Active / Normal service status
val SoftOrange = Color(0xFFF57C00)     // Delays / Alerts
