package com.example.data.repository

import com.example.data.models.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TransitRepository {

    // --- METRO LINES DATA ---
    val metroLines = listOf(
        MetroLine("A", "A Line (Blue)", "#1073E6", LineType.RAIL, listOf("APU", "LTA", "HBD", "GAB", "7MC", "PIC", "DLB")),
        MetroLine("B", "B Line (Red)", "#E31B23", LineType.RAIL, listOf("NOH", "UCC", "HHL", "HVI", "HWE", "WVT", "7MC", "PSQ", "CCG", "UST")),
        MetroLine("C", "C Line (Green)", "#00A550", LineType.RAIL, listOf("NOR", "AVB", "LAC", "ELH", "RDB")),
        MetroLine("D", "D Line (Purple)", "#802F8F", LineType.RAIL, listOf("WWS", "WNM", "WVT", "7MC", "PSQ", "CCG", "UST")),
        MetroLine("E", "E Line (Expo)", "#F2A900", LineType.RAIL, listOf("SMO", "WTW", "CUL", "LAT", "PIC", "7MC", "GAB", "HBD", "LTA", "ELA")),
        MetroLine("K", "K Line (Pink)", "#E94B8A", LineType.RAIL, listOf("EXC", "MUP", "HYD", "WVB")),
        MetroLine("J", "J Line (Silver)", "#8A9094", LineType.BUS, listOf("SLS", "HAR", "7MC", "UST", "ELS"))
    )

    private val lineMap = metroLines.associateBy { it.id }

    // --- METRO STATIONS DATA ---
    val metroStations = listOf(
        MetroStation(
            id = "UST", name = "Union Station", lines = listOf("B", "D", "A"),
            latitude = 34.0562, longitude = -118.2365, walkingDistance = "0.1 mi",
            entrances = listOf(
                StationEntrance("Alameda St Entrance", "0.05 mi", true, true),
                StationEntrance("Vignes St Plaza", "0.12 mi", true, true)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true),
                StationFacility("Restrooms", "wc", true),
                StationFacility("Bike Lockers", "directions_bike", true),
                StationFacility("Customer Info", "info", true)
            ),
            nearbyDestinations = listOf("Olvera Street", "Chinatown", "Little Tokyo", "Dodger Stadium Express")
        ),
        MetroStation(
            id = "CCG", name = "Civic Center / Grand Park", lines = listOf("B", "D"),
            latitude = 34.0548, longitude = -118.2435, walkingDistance = "0.3 mi",
            entrances = listOf(
                StationEntrance("Hill St Upper Entrance", "0.1 mi", true, false),
                StationEntrance("Broadway Plaza Entrance", "0.2 mi", true, true)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true),
                StationFacility("Escalator", "stairs", true)
            ),
            nearbyDestinations = listOf("Grand Park", "The Broad Museum", "Walt Disney Concert Hall", "City Hall")
        ),
        MetroStation(
            id = "PSQ", name = "Pershing Square", lines = listOf("B", "D"),
            latitude = 34.0485, longitude = -118.2492, walkingDistance = "0.4 mi",
            entrances = listOf(
                StationEntrance("5th St & Hill", "0.05 mi", true, true),
                StationEntrance("4th St Escalator", "0.15 mi", true, false)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true),
                StationFacility("Bike Racks", "directions_bike", true)
            ),
            nearbyDestinations = listOf("Pershing Square", "Grand Central Market", "Angels Flight Railway", "The Last Bookstore")
        ),
        MetroStation(
            id = "7MC", name = "7th Street / Metro Center", lines = listOf("B", "D", "A", "E"),
            latitude = 34.0486, longitude = -118.2587, walkingDistance = "0.0 mi",
            entrances = listOf(
                StationEntrance("Hope St Entrance A", "0.02 mi", true, true),
                StationEntrance("Figueroa St Entrance B", "0.06 mi", true, true),
                StationEntrance("Flower St Subway Link", "0.10 mi", true, true)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevators", "elevator", true),
                StationFacility("Lost & Found", "help", true),
                StationFacility("Security Desk", "security", true),
                StationFacility("Restrooms", "wc", false)
            ),
            nearbyDestinations = listOf("Crypto.com Arena", "LA Live", "FIGat7th Shopping", "Financial District")
        ),
        MetroStation(
            id = "HVI", name = "Hollywood / Vine", lines = listOf("B"),
            latitude = 34.1018, longitude = -118.3268, walkingDistance = "0.5 mi",
            entrances = listOf(
                StationEntrance("Hollywood Blvd Entrance A", "0.02 mi", true, true)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true),
                StationFacility("Escalators", "stairs", true)
            ),
            nearbyDestinations = listOf("Pantages Theatre", "Walk of Fame", "Capitol Records Building", "Hollywood Palladium")
        ),
        MetroStation(
            id = "HHL", name = "Hollywood / Highland", lines = listOf("B"),
            latitude = 34.1016, longitude = -118.3384, walkingDistance = "0.8 mi",
            entrances = listOf(
                StationEntrance("Ovation Hollywood Court", "0.04 mi", true, true)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true),
                StationFacility("Escalator", "stairs", true)
            ),
            nearbyDestinations = listOf("TCL Chinese Theatre", "Dolby Theatre", "Hollywood Bowl (Shuttle)", "Ovation Shopping Mall")
        ),
        MetroStation(
            id = "NOH", name = "North Hollywood", lines = listOf("B"),
            latitude = 34.1682, longitude = -118.3765, walkingDistance = "1.2 mi",
            entrances = listOf(
                StationEntrance("Lankershim Plaza", "0.05 mi", true, true)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true),
                StationFacility("Park & Ride Lot", "local_parking", true),
                StationFacility("Bike Hub", "directions_bike", true)
            ),
            nearbyDestinations = listOf("NoHo Arts District", "El Portal Theatre", "NoHo West Shopping")
        ),
        MetroStation(
            id = "SMO", name = "Downtown Santa Monica", lines = listOf("E"),
            latitude = 34.0135, longitude = -118.4913, walkingDistance = "0.6 mi",
            entrances = listOf(
                StationEntrance("4th St & Colorado A", "0.05 mi", true, true),
                StationEntrance("3rd St Promenade Link B", "0.15 mi", true, false)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true),
                StationFacility("Bike Depot", "directions_bike", true),
                StationFacility("Customer Help", "info", true)
            ),
            nearbyDestinations = listOf("Santa Monica Pier", "Santa Monica Beach", "Third Street Promenade", "Santa Monica Place")
        ),
        MetroStation(
            id = "CUL", name = "Culver City", lines = listOf("E"),
            latitude = 34.0282, longitude = -118.3891, walkingDistance = "1.5 mi",
            entrances = listOf(
                StationEntrance("Washington Blvd Ramp", "0.05 mi", true, true)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true),
                StationFacility("Park & Ride Lot", "local_parking", true)
            ),
            nearbyDestinations = listOf("Downtown Culver City", "Helms Bakery District", "Sony Pictures Studios")
        ),
        MetroStation(
            id = "WVT", name = "Wilshire / Vermont", lines = listOf("B", "D"),
            latitude = 34.0625, longitude = -118.2916, walkingDistance = "0.9 mi",
            entrances = listOf(
                StationEntrance("Wilshire Blvd Center Plaza", "0.03 mi", true, true)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true),
                StationFacility("Escalators (Super Long)", "stairs", true)
            ),
            nearbyDestinations = listOf("Koreatown Plaza", "Shatto 39 Lanes", "Korean Cultural Center")
        ),
        MetroStation(
            id = "LTA", name = "Little Tokyo / Arts District", lines = listOf("A", "E"),
            latitude = 34.0481, longitude = -118.2384, walkingDistance = "0.7 mi",
            entrances = listOf(
                StationEntrance("1st St East Portal", "0.05 mi", true, true)
            ),
            facilities = listOf(
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true)
            ),
            nearbyDestinations = listOf("Japanese American National Museum", "Geffen Contemporary at MOCA", "Arts District Breweries")
        ),
        MetroStation(
            id = "NOR", name = "Norwalk", lines = listOf("C"),
            latitude = 33.9142, longitude = -118.1250, walkingDistance = "5.0 mi",
            entrances = listOf(
                StationEntrance("I-105 Freeway Center Portal", "0.02 mi", true, true)
            ),
            facilities = listOf(
                StationFacility("Park & Ride", "local_parking", true),
                StationFacility("TAP Vending", "credit_card", true),
                StationFacility("Elevator", "elevator", true)
            ),
            nearbyDestinations = listOf("Norwalk City Hall", "Metrolink Connection")
        )
    )

    private val stationMap = metroStations.associateBy { it.id }

    // --- BUS STOPS DATA ---
    val metroBusStops = listOf(
        MetroBusStop("BST-1", "Wilshire Blvd / Westwood Blvd", listOf("720", "20"), 34.0592, -118.4442, "0.1 mi"),
        MetroBusStop("BST-2", "Wilshire Blvd / Beverly Drive", listOf("720", "20"), 34.0671, -118.3995, "0.3 mi"),
        MetroBusStop("BST-3", "Wilshire Blvd / Fairfax Ave", listOf("720", "20"), 34.0631, -118.3615, "0.5 mi"),
        MetroBusStop("BST-4", "Wilshire Blvd / La Brea Ave", listOf("720", "20"), 34.0621, -118.3441, "0.8 mi"),
        MetroBusStop("BST-5", "Santa Monica Blvd / Westwood Blvd", listOf("4"), 34.0465, -118.4312, "1.2 mi"),
        MetroBusStop("BST-6", "Santa Monica Blvd / La Cienega Blvd", listOf("4"), 34.0905, -118.3762, "1.6 mi"),
        MetroBusStop("BST-7", "Santa Monica Blvd / Vermont Ave", listOf("4"), 34.0901, -118.2915, "2.0 mi")
    )

    // --- SERVICE ALERTS STATE ---
    private val defaultAlerts = listOf(
        ServiceAlert(
            id = "AL-1", lineId = "A", lineName = "A Line (Blue)", lineColorHex = "#1073E6",
            severity = AlertSeverity.INFO, title = "Scheduled Maintenance",
            description = "Maintenance teams will perform scheduled track cleaning this weekend. No delays expected.",
            updatedAgo = "5 min ago"
        ),
        ServiceAlert(
            id = "AL-2", lineId = "E", lineName = "E Line (Expo)", lineColorHex = "#F2A900",
            severity = AlertSeverity.MINOR, title = "Slight Delay near Santa Monica",
            description = "A minor signalling issue at Santa Monica station is causing 5-minute delays on westbound services.",
            updatedAgo = "12 min ago"
        ),
        ServiceAlert(
            id = "AL-3", lineId = null, lineName = "System-Wide", lineColorHex = null,
            severity = AlertSeverity.INFO, title = "TAP Card Terminal Upgrade",
            description = "Station turnstiles are being upgraded with faster NFC readers. Tap as normal.",
            updatedAgo = "1 hour ago"
        )
    )

    private val _alertsFlow = MutableStateFlow(defaultAlerts)
    val alertsFlow: StateFlow<List<ServiceAlert>> = _alertsFlow.asStateFlow()

    // Service interruption toggle
    private val _isBLineInterrupted = MutableStateFlow(false)
    val isBLineInterrupted: StateFlow<Boolean> = _isBLineInterrupted.asStateFlow()

    fun triggerBLineInterruption(active: Boolean) {
        _isBLineInterrupted.value = active
        val currentList = _alertsFlow.value.toMutableList()
        currentList.removeAll { it.id == "AL-DISRUPT" }

        if (active) {
            currentList.add(0, ServiceAlert(
                id = "AL-DISRUPT",
                lineId = "B",
                lineName = "B Line (Red)",
                lineColorHex = "#E31B23",
                severity = AlertSeverity.SEVERE,
                title = "TRACK SUSPENSION: Hollywood to Downtown",
                description = "B Line (Red) rail services are suspended between Hollywood/Vine and 7th St/Metro Center due to an active track maintenance emergency. Alternative Bus Shuttle 901 is operating. Use alternative journey recommendations.",
                updatedAgo = "Just now",
                duration = "Expected next 4 hours"
            ))
        }
        _alertsFlow.value = currentList
    }

    // --- SAVED PLACES & JOURNEYS (In-Memory Simulation) ---
    private val _savedPlaces = MutableStateFlow(listOf(
        SavedPlace("P-1", "Home", "Santa Monica Blvd, West LA", "Home", "home"),
        SavedPlace("P-2", "Work (Downtown)", "Financial District, 7th & Flower", "Work", "work"),
        SavedPlace("P-3", "UCLA Campus", "Westwood, Los Angeles", "School", "school"),
        SavedPlace("P-4", "LAX Airport", "1 World Way, Los Angeles", "Airport", "flight")
    ))
    val savedPlaces: StateFlow<List<SavedPlace>> = _savedPlaces.asStateFlow()

    fun addSavedPlace(name: String, address: String, category: String) {
        val newPlace = SavedPlace(
            id = "P-${System.currentTimeMillis()}",
            name = name,
            address = address,
            category = category,
            iconName = when (category.lowercase()) {
                "home" -> "home"
                "work" -> "work"
                "school" -> "school"
                "airport" -> "flight"
                else -> "place"
            }
        )
        _savedPlaces.value = _savedPlaces.value + newPlace
    }

    fun removeSavedPlace(id: String) {
        _savedPlaces.value = _savedPlaces.value.filter { it.id != id }
    }

    private val _savedJourneys = MutableStateFlow(listOf(
        SavedJourney("J-1", "SMO", "7MC", "Downtown Santa Monica", "7th Street / Metro Center", "08:10 AM", "Weekdays"),
        SavedJourney("J-2", "HVI", "UST", "Hollywood / Vine", "Union Station", "05:30 PM", "Daily")
    ))
    val savedJourneys: StateFlow<List<SavedJourney>> = _savedJourneys.asStateFlow()

    fun saveJourney(fromId: String, toId: String) {
        val fromName = stationMap[fromId]?.name ?: fromId
        val toName = stationMap[toId]?.name ?: toId
        val newJourney = SavedJourney(
            id = "J-${System.currentTimeMillis()}",
            fromStationId = fromId,
            toStationId = toId,
            fromStationName = fromName,
            toStationName = toName,
            timeLabel = "08:30 AM",
            daysLabel = "Weekdays"
        )
        _savedJourneys.value = _savedJourneys.value + newJourney
    }

    fun removeSavedJourney(id: String) {
        _savedJourneys.value = _savedJourneys.value.filter { it.id != id }
    }

    // --- RECENT SEARCHES ---
    private val _recentSearches = MutableStateFlow(listOf(
        "Santa Monica Pier",
        "Hollywood Bowl",
        "Dodger Stadium",
        "Union Station"
    ))
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    fun addRecentSearch(query: String) {
        val current = _recentSearches.value.toMutableList()
        current.remove(query)
        current.add(0, query)
        _recentSearches.value = current.take(5)
    }

    // --- TAP CARD FARE MANAGEMENT STATE ---
    private val _tapCardState = MutableStateFlow(
        TapCard(
            cardNumber = "4512 8734 9012 5580",
            balance = 24.50,
            expiryDate = "12/2029",
            transactions = listOf(
                TapTransaction("TR-1", "Today 08:14 AM", "7th St/Metro Center (B Line)", -1.75),
                TapTransaction("TR-2", "Yesterday 05:45 PM", "Downtown Santa Monica (E Line)", -1.75),
                TapTransaction("TR-3", "Yesterday 08:30 AM", "Union Station Entry", -1.75),
                TapTransaction("TR-4", "Sep 30, 2026", "Add Value (Simulated Check)", 20.00),
                TapTransaction("TR-5", "Sep 29, 2026", "Hollywood/Vine Exit Ride", -1.75)
            )
        )
    )
    val tapCardState: StateFlow<TapCard> = _tapCardState.asStateFlow()

    fun addMoneyToTap(amount: Double) {
        val current = _tapCardState.value
        val newTransaction = TapTransaction(
            id = "TR-${System.currentTimeMillis()}",
            date = "Just now",
            description = "Add Value (Simulated)",
            cost = amount
        )
        _tapCardState.value = current.copy(
            balance = current.balance + amount,
            transactions = listOf(newTransaction) + current.transactions
        )
    }

    fun purchasePass(passName: String, cost: Double) {
        val current = _tapCardState.value
        if (current.balance >= cost) {
            val newTransaction = TapTransaction(
                id = "TR-${System.currentTimeMillis()}",
                date = "Just now",
                description = "Purchase $passName",
                cost = -cost
            )
            _tapCardState.value = current.copy(
                balance = current.balance - cost,
                activePass = passName,
                transactions = listOf(newTransaction) + current.transactions
            )
        }
    }

    // --- SEARCH spelling & alias mapping ---
    fun searchDestinations(query: String): List<StationOrPlaceSearchResult> {
        val clean = query.trim().lowercase(Locale.ROOT)
        if (clean.isEmpty()) return emptyList()

        val results = mutableListOf<StationOrPlaceSearchResult>()

        // 1. Hardcoded smart aliases
        if ("lax" in clean || "airport" in clean) {
            results.add(StationOrPlaceSearchResult("LAX Airport FlyAway Link", "Transit Center / FlyAway Connection", "PLACE", "flight", "7MC"))
        }
        if ("dodger" in clean || "baseball" in clean) {
            results.add(StationOrPlaceSearchResult("Dodger Stadium", "1000 Vin Scully Ave (Express from Union Station)", "PLACE", "sports_baseball", "UST"))
        }
        if ("crypto" in clean || "lakers" in clean || "staples" in clean) {
            results.add(StationOrPlaceSearchResult("Crypto.com Arena", "1111 S Figueroa St", "PLACE", "sports_basketball", "7MC"))
        }
        if ("bowl" in clean || "hollywood bowl" in clean) {
            results.add(StationOrPlaceSearchResult("Hollywood Bowl", "2301 N Highland Ave (Shuttle from Hollywood/Highland)", "PLACE", "music_note", "HHL"))
        }
        if ("sofi" in clean || "stadium" in clean) {
            results.add(StationOrPlaceSearchResult("SoFi Stadium", "1001 Stadium Dr (K Line Shuttle)", "PLACE", "sports_football", "HYD"))
        }

        // 2. Search Metro Stations with error tolerance & abbreviations
        for (station in metroStations) {
            val matchesName = station.name.lowercase(Locale.ROOT).contains(clean) || 
                              station.id.lowercase(Locale.ROOT).contains(clean)
            
            // Basic typo tolerancing (containment or minor edit distance)
            val passesTypoCheck = matchesName || 
                    (clean.length >= 4 && station.name.lowercase(Locale.ROOT).split(" ").any { word -> 
                        word.startsWith(clean) || clean.startsWith(word.take(4))
                    })

            if (passesTypoCheck) {
                val sub = station.lines.joinToString(" • ") { "$it Line" }
                results.add(StationOrPlaceSearchResult(station.name, sub, "STATION", "train", station.id))
            }
        }

        // 3. Search Bus Stops
        for (stop in metroBusStops) {
            if (stop.name.lowercase(Locale.ROOT).contains(clean)) {
                val sub = stop.routes.joinToString(" • ") { "Line $it" }
                results.add(StationOrPlaceSearchResult(stop.name, sub, "BUS_STOP", "directions_bus", stop.id))
            }
        }

        return results.distinctBy { it.id }
    }

    // --- REALTIME DEPARTURES GENERATOR ---
    fun getArrivalsForStation(stationId: String): List<Arrival> {
        val station = stationMap[stationId] ?: return emptyList()
        val arrivalsList = mutableListOf<Arrival>()

        // Generate arrivals based on actual lines of the station
        station.lines.forEach { lineId ->
            val line = lineMap[lineId] ?: return@forEach
            val direction1 = when (lineId) {
                "B" -> "North Hollywood"
                "A" -> "Downtown Long Beach"
                "D" -> "Union Station"
                "E" -> "Santa Monica"
                "C" -> "Norwalk"
                "K" -> "Westchester"
                else -> "Downtown LA"
            }
            val direction2 = when (lineId) {
                "B" -> "Union Station"
                "A" -> "APU / Citrus College"
                "D" -> "Wilshire / Western"
                "E" -> "East LA Civic Center"
                "C" -> "Redondo Beach"
                "K" -> "Expo / Crenshaw"
                else -> "Northbound Loop"
            }

            // Check if B line has active suspension
            val isBLineSuspended = _isBLineInterrupted.value && lineId == "B"
            
            if (isBLineSuspended) {
                // If B line is suspended between Hollywood and Downtown, adjust departures
                if (stationId in listOf("UST", "CCG", "PSQ", "7MC", "WVT")) {
                    arrivalsList.add(Arrival(lineId, line.name, direction1, 45, "Platform 2", "SUSPENDED (Shuttle Avail.)"))
                    arrivalsList.add(Arrival(lineId, line.name, direction2, 50, "Platform 1", "SUSPENDED (Shuttle Avail.)"))
                } else {
                    // Running North Hollywood to Hollywood/Vine only
                    arrivalsList.add(Arrival(lineId, line.name, "Hollywood / Vine Limit", 3, "Platform 1", "Active Delays"))
                    arrivalsList.add(Arrival(lineId, line.name, "North Hollywood", 7, "Platform 2", "Active Delays"))
                }
            } else {
                // Normal Arrivals
                arrivalsList.add(Arrival(lineId, line.name, direction1, 3, "Platform 1", "On Time"))
                arrivalsList.add(Arrival(lineId, line.name, direction1, 11, "Platform 1", "On Time"))
                arrivalsList.add(Arrival(lineId, line.name, direction2, 6, "Platform 2", "On Time"))
                arrivalsList.add(Arrival(lineId, line.name, direction2, 14, "Platform 2", "On Time"))
            }
        }
        return arrivalsList.sortedBy { it.minutes }
    }

    fun getArrivalsForBusStop(stopId: String): List<Arrival> {
        val stop = metroBusStops.firstOrNull { it.id == stopId } ?: return emptyList()
        val arrivalsList = mutableListOf<Arrival>()

        stop.routes.forEach { routeNumber ->
            val dest1 = when (routeNumber) {
                "720" -> "Santa Monica Pier"
                "20" -> "Downtown LA"
                "4" -> "Union Station"
                else -> "Metro Center"
            }
            arrivalsList.add(Arrival("BUS-$routeNumber", "Line $routeNumber", dest1, 5, "Street Bay A", "On Time"))
            arrivalsList.add(Arrival("BUS-$routeNumber", "Line $routeNumber", dest1, 16, "Street Bay A", "On Time"))
        }

        return arrivalsList.sortedBy { it.minutes }
    }

    // --- JOURNEY GENERATION LOGIC ---
    fun planJourney(fromId: String, toId: String): List<JourneyOption> {
        // Special case: Hollywood/Vine (HVI) to Downtown LA (7MC) - the demo journey requested!
        val isDisruptionActive = _isBLineInterrupted.value

        if (fromId == "HVI" && toId == "7MC") {
            if (isDisruptionActive) {
                // User gets alternative route warning and a clear substitute shuttle journey
                return listOf(
                    JourneyOption(
                        id = "JO-ALT-1",
                        segments = listOf(
                            RouteSegment("WALK", "Walk to Bus Bay", null, "Hollywood / Vine Station", "Hollywood/Vine Bus Stop", 2),
                            RouteSegment("BUS", "Emergency Shuttle 901", "#E31B23", "Hollywood/Vine Bus Stop", "7th Street / Metro Center", 25, 4, listOf("Hollywood/Western", "Wilshire/Vermont", "Westlake/MacArthur", "7th St/Metro Center")),
                            RouteSegment("WALK", "Walk to Destination", null, "7th St/Metro Center Plaza", "Downtown LA", 3)
                        ),
                        totalDurationMinutes = 30,
                        transfersCount = 1,
                        walkingMinutes = 5,
                        departureTime = "08:14",
                        arrivalTime = "08:44",
                        tag = "Alternative Route (Emergency Shuttle)"
                    ),
                    JourneyOption(
                        id = "JO-ALT-2",
                        segments = listOf(
                            RouteSegment("RAIL", "B Line (Red)", "#E31B23", "Hollywood / Vine", "Hollywood / Western", 4, 1, listOf("Hollywood/Western")),
                            RouteSegment("BUS", "Local Bus 20", "#8A9094", "Hollywood / Western Stop", "7th St / Metro Center", 35, 12),
                            RouteSegment("WALK", "Walk to Destination", null, "7th St/Metro Plaza", "Downtown LA", 5)
                        ),
                        totalDurationMinutes = 44,
                        transfersCount = 2,
                        walkingMinutes = 5,
                        departureTime = "08:16",
                        arrivalTime = "09:00",
                        tag = "Alternative Route (Bus 20 Transfer)"
                    )
                )
            } else {
                // Standard optimal B Line (Red) route - Direct 13 min!
                return listOf(
                    JourneyOption(
                        id = "JO-1",
                        segments = listOf(
                            RouteSegment("WALK", "Walk to Entrance A", null, "Hollywood / Vine Plaza", "Hollywood / Vine Platform", 2),
                            RouteSegment("RAIL", "B Line (Red)", "#E31B23", "Hollywood / Vine", "7th Street / Metro Center", 13, 3, listOf("Hollywood / Western", "Wilshire / Vermont", "Westlake / MacArthur Park")),
                            RouteSegment("WALK", "Walk to Exit", null, "7th St/Metro Center Platform", "Downtown LA", 4)
                        ),
                        totalDurationMinutes = 19,
                        transfersCount = 0,
                        walkingMinutes = 6,
                        departureTime = "08:14",
                        arrivalTime = "08:33",
                        tag = "Fastest (Direct)"
                    ),
                    JourneyOption(
                        id = "JO-2",
                        segments = listOf(
                            RouteSegment("WALK", "Walk to Stop", null, "Hollywood / Vine Station", "Sunset / Vine Stop", 4),
                            RouteSegment("BUS", "Line 4", "#F2A900", "Sunset / Vine Stop", "Union Station Bus Bay", 28, 14),
                            RouteSegment("RAIL", "D Line (Purple)", "#802F8F", "Union Station", "7th Street / Metro Center", 6, 2),
                            RouteSegment("WALK", "Walk to Destination", null, "7th St/Metro Center", "Downtown LA", 3)
                        ),
                        totalDurationMinutes = 41,
                        transfersCount = 1,
                        walkingMinutes = 7,
                        departureTime = "08:10",
                        arrivalTime = "08:51",
                        tag = "Scenic (Fewest Stairs)"
                    )
                )
            }
        }

        // Generic Simulated Routing for any other pairs
        val fromName = stationMap[fromId]?.name ?: fromId
        val toName = stationMap[toId]?.name ?: toId
        return listOf(
            JourneyOption(
                id = "JO-GEN-1",
                segments = listOf(
                    RouteSegment("WALK", "Walk to Station", null, "Starting Location", fromName, 5),
                    RouteSegment("RAIL", "A Line (Blue)", "#1073E6", fromName, toName, 24, 5),
                    RouteSegment("WALK", "Walk to Destination", null, toName, "End Location", 8)
                ),
                totalDurationMinutes = 37,
                transfersCount = 0,
                walkingMinutes = 13,
                departureTime = "08:14",
                arrivalTime = "08:51",
                tag = "Fastest"
            ),
            JourneyOption(
                id = "JO-GEN-2",
                segments = listOf(
                    RouteSegment("WALK", "Walk to Stop", null, "Starting Location", "Nearby Bus Stop", 3),
                    RouteSegment("BUS", "Line 720", "#E31B23", "Nearby Bus Stop", "Intersection Stop", 22, 10),
                    RouteSegment("WALK", "Transfer Walk", null, "Intersection Stop", "Connection Station", 4),
                    RouteSegment("RAIL", "E Line (Expo)", "#F2A900", "Connection Station", toName, 15, 3),
                    RouteSegment("WALK", "Walk to Destination", null, toName, "End Location", 4)
                ),
                totalDurationMinutes = 48,
                transfersCount = 1,
                walkingMinutes = 11,
                departureTime = "08:10",
                arrivalTime = "08:58",
                tag = "Fewest Transfers"
            )
        )
    }
}

data class StationOrPlaceSearchResult(
    val title: String,
    val subtitle: String,
    val type: String, // "STATION", "BUS_STOP", "PLACE"
    val iconName: String,
    val id: String // Station or stop ID, or landmark key
)
