package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetroViewModel

@Composable
fun MoreScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.language.collectAsState()
    val isDark by viewModel.isDarkMode.collectAsState()
    val isOffline by viewModel.isOfflineMode.collectAsState()
    val isBLineSuspended by viewModel.isBLineInterrupted.collectAsState()
    val savedPlaces by viewModel.savedPlaces.collectAsState()
    val alerts by viewModel.alerts.collectAsState()

    val isSpanish = language == com.example.ui.viewmodel.Language.SPANISH

    var showAddPlaceDialog by remember { mutableStateOf(false) }
    var newPlaceName by remember { mutableStateOf("") }
    var newPlaceAddress by remember { mutableStateOf("") }
    var newPlaceCategory by remember { mutableStateOf("Custom") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App bar space
        item {
            Column(modifier = Modifier.padding(vertical = 12.dp).safeDrawingPadding()) {
                Text(
                    text = if (isSpanish) "AJUSTES Y SERVICIOS" else "SETTINGS & SERVICES",
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (isSpanish) "Personaliza tu experiencia de tránsito de Los Ángeles" else "Customize your Los Angeles transit parameters",
                    fontSize = 13.sp,
                    color = MutedText
                )
            }
        }

        // Active Alerts summary
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSpanish) "ESTADO DE LÍNEAS (ALERTAS)" else "METRO LINE STATUS (ALERTS)",
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp,
                        color = MutedText
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    alerts.forEach { alert ->
                        AlertCard(
                            lineName = alert.lineName,
                            lineColorHex = alert.lineColorHex,
                            severity = alert.severity,
                            title = alert.title,
                            description = alert.description,
                            updatedAgo = alert.updatedAgo
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }

        // App Language & Appearance settings
        item {
            Text(
                text = if (isSpanish) "CONFIGURACIÓN DE LA APLICACIÓN" else "APPLICATION PREFERENCES",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = MutedText
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
            ) {
                Column {
                    // Language Toggle Selector
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (isSpanish) "Idioma del Sistema" else "Bilingual Language",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(2.dp)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (!isSpanish) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    .clickable { viewModel.setLanguage(com.example.ui.viewmodel.Language.ENGLISH) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .testTag("lang_en_button")
                            ) {
                                Text(
                                    text = "EN",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (!isSpanish) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSpanish) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    .clickable { viewModel.setLanguage(com.example.ui.viewmodel.Language.SPANISH) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .testTag("lang_es_button")
                            ) {
                                Text(
                                    text = "ES",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (isSpanish) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Divider()

                    // Dark Mode Toggle Switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (isSpanish) "Modo Oscuro" else "Dark Theme Mode",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }

                        Switch(
                            checked = isDark,
                            onCheckedChange = { viewModel.toggleDarkMode() },
                            modifier = Modifier.testTag("dark_mode_switch")
                        )
                    }
                }
            }
        }

        // Developer Simulator Triggers
        item {
            Text(
                text = if (isSpanish) "HERRAMIENTAS DE SIMULACIÓN" else "DEVELOPER SIMULATOR CONTROLS",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = MutedText
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
            ) {
                Column {
                    // Trigger B Line Emergency Suspension
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FlashOn, contentDescription = null, tint = MetroRed)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isSpanish) "Interrupción de Línea B (Roja)" else "Simulate B Line Interruption",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = if (isSpanish) "Suspende tráfico y sugiere shuttles" else "Suspends train traffic and forces shuttle rerouting.",
                                    fontSize = 11.sp,
                                    color = MutedText
                                )
                            }
                        }

                        Switch(
                            checked = isBLineSuspended,
                            onCheckedChange = { viewModel.toggleBLineInterruption() },
                            modifier = Modifier.testTag("disruption_simulator_switch")
                        )
                    }

                    Divider()

                    // Simulate Offline Cache Mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CloudOff, contentDescription = null, tint = SoftOrange)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                val simLabel = if (isSpanish) "Simular Modo Offline" else "Simulate Offline Mode"
                                Text(
                                    text = simLabel,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = if (isSpanish) "Muestra horarios fijos programados" else "Displays scheduled cached fallback schedules.",
                                    fontSize = 11.sp,
                                    color = MutedText
                                )
                            }
                        }

                        Switch(
                            checked = isOffline,
                            onCheckedChange = { viewModel.toggleOfflineMode() },
                            modifier = Modifier.testTag("offline_simulator_switch")
                        )
                    }
                }
            }
        }

        // Custom Places list manager
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isSpanish) "GESTIONAR LUGARES" else "MANAGE SAVED PLACES",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MutedText
                )
                
                Text(
                    text = if (isSpanish) "+ Añadir Lugar" else "+ Add Place",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clickable { showAddPlaceDialog = true }
                        .testTag("add_place_button")
                )
            }
        }

        items(savedPlaces) { place ->
            PlaceCard(
                name = place.name,
                address = place.address,
                iconName = place.iconName,
                onSelect = {},
                onDelete = { viewModel.removeSavedPlace(place.id) }
            )
        }

        // Help guides section
        item {
            Text(
                text = if (isSpanish) "GUÍA DE USO Y AYUDA" else "HELP & RIDER INSTRUCTIONS",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = MutedText
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
            ) {
                Column {
                    HelpRow(title = if (isSpanish) "¿Cómo viajar en Metro?" else "How to ride Metro")
                    Divider()
                    HelpRow(title = if (isSpanish) "¿Cómo funciona TAP?" else "How TAP works")
                    Divider()
                    HelpRow(title = if (isSpanish) "Accesibilidad del sistema" else "Accessibility directives")
                    Divider()
                    HelpRow(title = if (isSpanish) "Información de Seguridad" else "Safety instructions")
                }
            }
        }
    }

    // Add Saved Place Dialog
    if (showAddPlaceDialog) {
        AlertDialog(
            onDismissRequest = { showAddPlaceDialog = false },
            title = { Text(if (isSpanish) "Añadir Sitio Guardado" else "Add New Saved Place") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newPlaceName,
                        onValueChange = { newPlaceName = it },
                        label = { Text(if (isSpanish) "Nombre (ej: Escuela)" else "Label Name (e.g. School)") },
                        modifier = Modifier.fillMaxWidth().testTag("add_place_name_input")
                    )
                    OutlinedTextField(
                        value = newPlaceAddress,
                        onValueChange = { newPlaceAddress = it },
                        label = { Text(if (isSpanish) "Dirección" else "Address details") },
                        modifier = Modifier.fillMaxWidth().testTag("add_place_address_input")
                    )
                    OutlinedTextField(
                        value = newPlaceCategory,
                        onValueChange = { newPlaceCategory = it },
                        label = { Text(if (isSpanish) "Categoría" else "Category (Home, Work, School, Airport, Custom)") },
                        modifier = Modifier.fillMaxWidth().testTag("add_place_category_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPlaceName.isNotEmpty() && newPlaceAddress.isNotEmpty()) {
                            viewModel.toggleSavePlace(newPlaceName, newPlaceAddress, newPlaceCategory)
                            newPlaceName = ""
                            newPlaceAddress = ""
                            showAddPlaceDialog = false
                        }
                    },
                    modifier = Modifier.testTag("add_place_confirm_button")
                ) {
                    Text(if (isSpanish) "Guardar" else "Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddPlaceDialog = false }) {
                    Text(if (isSpanish) "Cancelar" else "Cancel")
                }
            }
        )
    }
}

@Composable
fun HelpRow(title: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { }
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MutedText, modifier = Modifier.size(18.dp))
    }
}
