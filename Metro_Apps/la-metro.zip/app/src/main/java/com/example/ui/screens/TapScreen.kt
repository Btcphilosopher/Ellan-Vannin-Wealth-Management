package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetroViewModel

@Composable
fun TapScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val tapCard by viewModel.tapCard.collectAsState()
    val language by viewModel.language.collectAsState()

    val isSpanish = language == com.example.ui.viewmodel.Language.SPANISH

    var showTopUpDialog by remember { mutableStateOf(false) }
    var selectedAmount by remember { mutableDoubleStateOf(10.0) }
    var customAmountText by remember { mutableStateOf("") }
    var isCustomSelected by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Bar Space
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .safeDrawingPadding()
        ) {
            Text(
                text = "TAP FARES",
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = if (isSpanish) "Administra tu tarjeta inteligente TAP" else "Manage your virtual TAP smart-card",
                fontSize = 13.sp,
                color = MutedText
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // High-fidelity digital TAP Card UI
            item {
                TapCard(
                    cardNumber = tapCard.cardNumber,
                    balance = tapCard.balance,
                    activePass = tapCard.activePass
                )
            }

            // Quick Add Value Presets Card
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isSpanish) "AGREGAR SALDO" else "ADD MONEY VALUE",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            color = MutedText
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf(10.0, 20.0, 40.0, 60.0).forEach { amt ->
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable {
                                            selectedAmount = amt
                                            isCustomSelected = false
                                            showTopUpDialog = true
                                        }
                                        .padding(vertical = 12.dp)
                                ) {
                                    Text(
                                        text = "$$amt",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Available Fare Products section
            item {
                Text(
                    text = if (isSpanish) "PRODUCTOS DE TARIFAS DISPONIBLES" else "AVAILABLE FARE PRODUCTS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MutedText
                )
            }

            item {
                FareCard(
                    title = if (isSpanish) "Pase de 1 Día" else "1-Day Day Pass",
                    price = 5.00,
                    description = if (isSpanish) "Viajes ilimitados durante 24 horas" else "Unlimited system-wide rides for 24 hours.",
                    onPurchase = { viewModel.purchaseTapPass("Day Pass", 5.00) }
                )
            }

            item {
                FareCard(
                    title = if (isSpanish) "Pase de 7 Días" else "7-Day Week Pass",
                    price = 18.00,
                    description = if (isSpanish) "Viajes ilimitados durante 7 días" else "Unlimited rides for 7 consecutive days.",
                    onPurchase = { viewModel.purchaseTapPass("7-Day Pass", 18.00) }
                )
            }

            item {
                FareCard(
                    title = if (isSpanish) "Pase de 30 Días" else "30-Day Month Pass",
                    price = 50.00,
                    description = if (isSpanish) "Viajes ilimitados durante 30 días" else "Unlimited system-wide rides for 30 consecutive days.",
                    onPurchase = { viewModel.purchaseTapPass("30-Day Pass", 50.00) }
                )
            }

            // Recent Transaction History
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isSpanish) "HISTORIAL DE TRANSACCIONES" else "TRANSACTION ACTIVITY HISTORY",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MutedText
                )
            }

            items(tapCard.transactions) { trx ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Icon(
                                imageVector = if (trx.cost > 0) Icons.Default.AddCard else Icons.Default.DirectionsTransit,
                                contentDescription = null,
                                tint = if (trx.cost > 0) SoftGreen else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = trx.description,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = trx.date,
                                fontSize = 11.sp,
                                color = MutedText
                            )
                        }
                    }

                    Text(
                        text = if (trx.cost > 0) "+$${String.format("%.2f", trx.cost)}" else "-$${String.format("%.2f", -trx.cost)}",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = if (trx.cost > 0) SoftGreen else MaterialTheme.colorScheme.onSurface
                    )
                }
                Divider()
            }
        }

        // Top Up Checkout dialog
        if (showTopUpDialog) {
            AlertDialog(
                onDismissRequest = { showTopUpDialog = false },
                title = { Text(if (isSpanish) "Confirmar Carga" else "Simulated Check-Out") },
                text = {
                    Column {
                        Text(
                            text = if (isSpanish) "Vas a agregar $${String.format("%.2f", selectedAmount)} a tu tarjeta TAP."
                                   else "You are topping up $${String.format("%.2f", selectedAmount)} into your TAP Card virtual balance.",
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(12.dp)
                        ) {
                            Icon(Icons.Default.CreditCard, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Google Pay •••• 9845",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (isSpanish) "Checkout de simulación segura" else "Simulated Secure Payment Token",
                                    fontSize = 11.sp,
                                    color = MutedText
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.addTapValue(selectedAmount)
                            showTopUpDialog = false
                        },
                        modifier = Modifier.testTag("confirm_topup_button")
                    ) {
                        Text(if (isSpanish) "Pagar Ahora" else "Authorize Pay")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showTopUpDialog = false }) {
                        Text(if (isSpanish) "Cancelar" else "Cancel")
                    }
                }
            )
        }
    }
}
