package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.models.*
import com.example.data.repository.StationOrPlaceSearchResult
import com.example.data.repository.TransitRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppTab {
    PLAN, MAP, ARRIVALS, TAP, MORE
}

enum class Language {
    ENGLISH, SPANISH
}

class MetroViewModel : ViewModel() {

    private val repository = TransitRepository()

    // --- NAVIGATION TABS ---
    private val _activeTab = MutableStateFlow(AppTab.PLAN)
    val activeTab: StateFlow<AppTab> = _activeTab.asStateFlow()

    fun selectTab(tab: AppTab) {
        _activeTab.value = tab
    }

    // --- APP-LEVEL OPTIONS ---
    private val _language = MutableStateFlow(Language.ENGLISH)
    val language: StateFlow<Language> = _language.asStateFlow()

    fun setLanguage(lang: Language) {
        _language.value = lang
    }

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    fun toggleOfflineMode() {
        _isOfflineMode.value = !_isOfflineMode.value
    }

    // --- DATA EXPOSURES ---
    val metroLines = repository.metroLines
    val metroStations = repository.metroStations
    val metroBusStops = repository.metroBusStops
    val alerts = repository.alertsFlow
    val isBLineInterrupted = repository.isBLineInterrupted
    val savedPlaces = repository.savedPlaces
    val savedJourneys = repository.savedJourneys
    val recentSearches = repository.recentSearches
    val tapCard = repository.tapCardState

    // --- JOURNEY PLANNER STATE ---
    private val _searchQueryFrom = MutableStateFlow("")
    val searchQueryFrom: StateFlow<String> = _searchQueryFrom.asStateFlow()

    private val _searchQueryTo = MutableStateFlow("")
    val searchQueryTo: StateFlow<String> = _searchQueryTo.asStateFlow()

    private val _selectedFromStation = MutableStateFlow<StationOrPlaceSearchResult?>(
        StationOrPlaceSearchResult("Current Location", "Your GPS Coordinates", "STATION", "my_location", "HVI") // Defaults to Hollywood/Vine
    )
    val selectedFromStation: StateFlow<StationOrPlaceSearchResult?> = _selectedFromStation.asStateFlow()

    private val _selectedToStation = MutableStateFlow<StationOrPlaceSearchResult?>(null)
    val selectedToStation: StateFlow<StationOrPlaceSearchResult?> = _selectedToStation.asStateFlow()

    private val _searchResultsFrom = MutableStateFlow<List<StationOrPlaceSearchResult>>(emptyList())
    val searchResultsFrom: StateFlow<List<StationOrPlaceSearchResult>> = _searchResultsFrom.asStateFlow()

    private val _searchResultsTo = MutableStateFlow<List<StationOrPlaceSearchResult>>(emptyList())
    val searchResultsTo: StateFlow<List<StationOrPlaceSearchResult>> = _searchResultsTo.asStateFlow()

    private val _journeyOptions = MutableStateFlow<List<JourneyOption>>(emptyList())
    val journeyOptions: StateFlow<List<JourneyOption>> = _journeyOptions.asStateFlow()

    private val _selectedJourney = MutableStateFlow<JourneyOption?>(null)
    val selectedJourney: StateFlow<JourneyOption?> = _selectedJourney.asStateFlow()

    // --- ACTIVE LIVE NAVIGATION ---
    private val _isActiveJourneyLive = MutableStateFlow(false)
    val isActiveJourneyLive: StateFlow<Boolean> = _isActiveJourneyLive.asStateFlow()

    private val _currentSegmentIndex = MutableStateFlow(0)
    val currentSegmentIndex: StateFlow<Int> = _currentSegmentIndex.asStateFlow()

    private val _currentStopIndexWithinSegment = MutableStateFlow(0)
    val currentStopIndexWithinSegment: StateFlow<Int> = _currentStopIndexWithinSegment.asStateFlow()

    private val _navStatusMessage = MutableStateFlow("Ready to Ride")
    val navStatusMessage: StateFlow<String> = _navStatusMessage.asStateFlow()

    // --- ARRIVALS SCREEN SEARCH ---
    private val _arrivalsSearchQuery = MutableStateFlow("")
    val arrivalsSearchQuery: StateFlow<String> = _arrivalsSearchQuery.asStateFlow()

    private val _arrivalsSearchResults = MutableStateFlow<List<StationOrPlaceSearchResult>>(emptyList())
    val arrivalsSearchResults: StateFlow<List<StationOrPlaceSearchResult>> = _arrivalsSearchResults.asStateFlow()

    private val _selectedArrivalStationId = MutableStateFlow("7MC") // Default Downtown
    val selectedArrivalStationId: StateFlow<String> = _selectedArrivalStationId.asStateFlow()

    // --- SELECTED STATION/LINE PAGES ---
    private val _selectedStationPageId = MutableStateFlow<String?>(null)
    val selectedStationPageId: StateFlow<String?> = _selectedStationPageId.asStateFlow()

    private val _selectedLinePageId = MutableStateFlow<String?>(null)
    val selectedLinePageId: StateFlow<String?> = _selectedLinePageId.asStateFlow()

    // --- SEARCH / SELECTION ACTIONS ---
    fun updateSearchFrom(query: String) {
        _searchQueryFrom.value = query
        _searchResultsFrom.value = repository.searchDestinations(query)
    }

    fun updateSearchTo(query: String) {
        _searchQueryTo.value = query
        _searchResultsTo.value = repository.searchDestinations(query)
    }

    fun selectFromStation(result: StationOrPlaceSearchResult) {
        _selectedFromStation.value = result
        _searchQueryFrom.value = result.title
        _searchResultsFrom.value = emptyList()
        triggerJourneyPlanningIfReady()
    }

    fun selectToStation(result: StationOrPlaceSearchResult) {
        _selectedToStation.value = result
        _searchQueryTo.value = result.title
        _searchResultsTo.value = emptyList()
        repository.addRecentSearch(result.title)
        triggerJourneyPlanningIfReady()
    }

    fun swapFromTo() {
        val temp = _selectedFromStation.value
        _selectedFromStation.value = _selectedToStation.value
        _selectedToStation.value = temp

        val tempQuery = _searchQueryFrom.value
        _searchQueryFrom.value = _searchQueryTo.value
        _searchQueryTo.value = tempQuery
        triggerJourneyPlanningIfReady()
    }

    fun selectRecentSearch(search: String) {
        _searchQueryTo.value = search
        val results = repository.searchDestinations(search)
        if (results.isNotEmpty()) {
            selectToStation(results[0])
        }
    }

    private fun triggerJourneyPlanningIfReady() {
        val from = _selectedFromStation.value
        val to = _selectedToStation.value
        if (from != null && to != null) {
            _journeyOptions.value = repository.planJourney(from.id, to.id)
            _selectedJourney.value = _journeyOptions.value.firstOrNull()
        }
    }

    fun selectJourneyOption(option: JourneyOption) {
        _selectedJourney.value = option
    }

    fun clearJourneySearch() {
        _searchQueryTo.value = ""
        _selectedToStation.value = null
        _journeyOptions.value = emptyList()
        _selectedJourney.value = null
        _isActiveJourneyLive.value = false
    }

    // --- LIVE NAVIGATION ---
    fun startLiveJourney() {
        val journey = _selectedJourney.value ?: return
        _isActiveJourneyLive.value = true
        _currentSegmentIndex.value = 0
        _currentStopIndexWithinSegment.value = 0
        updateNavStatus()
    }

    fun stopLiveJourney() {
        _isActiveJourneyLive.value = false
        _currentSegmentIndex.value = 0
        _currentStopIndexWithinSegment.value = 0
        _navStatusMessage.value = "Journey Completed"
    }

    fun advanceLiveJourneyStep() {
        val journey = _selectedJourney.value ?: return
        val currentSeg = journey.segments.getOrNull(_currentSegmentIndex.value) ?: return

        if (currentSeg.stopsCount > 0 && _currentStopIndexWithinSegment.value < currentSeg.stopsCount) {
            _currentStopIndexWithinSegment.value += 1
        } else {
            if (_currentSegmentIndex.value < journey.segments.size - 1) {
                _currentSegmentIndex.value += 1
                _currentStopIndexWithinSegment.value = 0
            } else {
                stopLiveJourney()
                return
            }
        }
        updateNavStatus()
    }

    private fun updateNavStatus() {
        val journey = _selectedJourney.value ?: return
        val segment = journey.segments.getOrNull(_currentSegmentIndex.value) ?: return
        
        when (segment.mode) {
            "WALK" -> {
                _navStatusMessage.value = "Walk to ${segment.toName} (${segment.durationMinutes} min)"
            }
            "RAIL" -> {
                val stopsLeft = segment.stopsCount - _currentStopIndexWithinSegment.value
                val nextStopName = segment.stopsList.getOrNull(_currentStopIndexWithinSegment.value) ?: segment.toName
                if (stopsLeft <= 0) {
                    _navStatusMessage.value = "Get ready to exit at ${segment.toName}!"
                } else {
                    _navStatusMessage.value = "Ride ${segment.routeName}. Next: $nextStopName ($stopsLeft stops left)"
                }
            }
            "BUS" -> {
                val stopsLeft = segment.stopsCount - _currentStopIndexWithinSegment.value
                val nextStopName = segment.stopsList.getOrNull(_currentStopIndexWithinSegment.value) ?: segment.toName
                if (stopsLeft <= 0) {
                    _navStatusMessage.value = "Get off here: ${segment.toName}!"
                } else {
                    _navStatusMessage.value = "Ride Bus ${segment.routeName}. Next: $nextStopName ($stopsLeft stops left)"
                }
            }
        }
    }

    // --- SERVICE DISRUPTION SIMULATION ---
    fun toggleBLineInterruption() {
        val active = !repository.isBLineInterrupted.value
        repository.triggerBLineInterruption(active)
        // If we were currently searching HVI to 7MC, update the journey planning options!
        triggerJourneyPlanningIfReady()
    }

    // --- ARRIVALS ACTIONS ---
    fun updateArrivalsSearch(query: String) {
        _arrivalsSearchQuery.value = query
        _arrivalsSearchResults.value = repository.searchDestinations(query)
    }

    fun selectArrivalStation(stationId: String) {
        _selectedArrivalStationId.value = stationId
        _arrivalsSearchQuery.value = ""
        _arrivalsSearchResults.value = emptyList()
    }

    fun getArrivalsForSelectedStation(): List<Arrival> {
        val id = _selectedArrivalStationId.value
        return if (id.startsWith("BST-")) {
            repository.getArrivalsForBusStop(id)
        } else {
            repository.getArrivalsForStation(id)
        }
    }

    // --- DETAILS SCREENS NAVIGATION ---
    fun showStationPage(stationId: String?) {
        _selectedStationPageId.value = stationId
        if (stationId != null) {
            _selectedArrivalStationId.value = stationId
        }
    }

    fun showLinePage(lineId: String?) {
        _selectedLinePageId.value = lineId
    }

    // --- SAVED ACTIONS ---
    fun toggleSavePlace(name: String, address: String, category: String) {
        repository.addSavedPlace(name, address, category)
    }

    fun removeSavedPlace(id: String) {
        repository.removeSavedPlace(id)
    }

    fun saveJourneyOption() {
        val from = _selectedFromStation.value ?: return
        val to = _selectedToStation.value ?: return
        repository.saveJourney(from.id, to.id)
    }

    fun loadSavedJourney(saved: SavedJourney) {
        val fromResult = StationOrPlaceSearchResult(saved.fromStationName, "Saved Station", "STATION", "train", saved.fromStationId)
        val toResult = StationOrPlaceSearchResult(saved.toStationName, "Saved Station", "STATION", "train", saved.toStationId)
        
        _selectedFromStation.value = fromResult
        _selectedToStation.value = toResult
        _searchQueryFrom.value = saved.fromStationName
        _searchQueryTo.value = saved.toStationName
        _activeTab.value = AppTab.PLAN
        triggerJourneyPlanningIfReady()
    }

    // --- TAP CARD ACTIONS ---
    fun addTapValue(amount: Double) {
        repository.addMoneyToTap(amount)
    }

    fun purchaseTapPass(passName: String, cost: Double) {
        repository.purchasePass(passName, cost)
    }
}
