package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.StationOrPlaceSearchResult
import com.example.ui.components.*
import com.example.ui.maps.MetroMapView
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetroViewModel

@Composable
fun MapScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val selectedStationId by viewModel.selectedArrivalStationId.collectAsState()
    val stations = viewModel.metroStations
    val selectedStation = stations.firstOrNull { it.id == selectedStationId }
    val language by viewModel.language.collectAsState()
    val isSpanish = language == com.example.ui.viewmodel.Language.SPANISH

    Box(modifier = modifier.fillMaxSize()) {
        // Fullscreen Custom Canvas Map
        MetroMapView(viewModel = viewModel, modifier = Modifier.fillMaxSize())

        // Bottom Sheet Overlay for Station Info Panel
        selectedStation?.let { station ->
            AnimatedVisibility(
                visible = true,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
                    .safeDrawingPadding()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp)
                        .testTag("map_bottom_sheet"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = station.name,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    station.lines.forEach { lineId ->
                                        LineBadge(lineId = lineId, size = 20)
                                    }
                                }
                            }
                            
                            IconButton(onClick = { viewModel.showStationPage(null) }) {
                                Icon(Icons.Default.Close, contentDescription = "Close Sheet")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Scrollable section for departures/facilities/entrances
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            // Facilities Indicators Row
                            item {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.padding(vertical = 4.dp)
                                ) {
                                    station.facilities.forEach { facility ->
                                        if (facility.isAvailable) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                val fVector = when (facility.iconName) {
                                                    "elevator" -> Icons.Default.Elevator
                                                    "wc" -> Icons.Default.Wc
                                                    "credit_card" -> Icons.Default.CreditCard
                                                    "directions_bike" -> Icons.Default.DirectionsBike
                                                    else -> Icons.Default.Info
                                                }
                                                Icon(
                                                    imageVector = fVector, 
                                                    contentDescription = null, 
                                                    modifier = Modifier.size(12.dp), 
                                                    tint = MaterialTheme.colorScheme.primary
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(facility.name, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                                Divider(modifier = Modifier.padding(vertical = 8.dp))
                            }

                            // Dynamic Live Arrivals header
                            item {
                                Text(
                                    text = (if (isSpanish) "Próximas salidas en vivo" else "LIVE STATION ARRIVALS").uppercase(),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp,
                                    color = MutedText
                                )
                            }

                            // Pull arrivals lists
                            val arrivals = viewModel.getArrivalsForSelectedStation().take(3)
                            if (arrivals.isEmpty()) {
                                item {
                                    Text(
                                        text = if (isSpanish) "No hay arribos programados" else "No scheduled arrivals available.",
                                        fontSize = 13.sp,
                                        color = MutedText
                                    )
                                }
                            } else {
                                items(arrivals) { arr ->
                                    ArrivalRow(
                                        lineId = arr.lineId,
                                        lineName = arr.lineName,
                                        destination = arr.destination,
                                        minutes = arr.minutes,
                                        platform = arr.platform,
                                        status = arr.status
                                    )
                                    Divider()
                                }
                            }

                            // Entrances Subsection
                            item {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = (if (isSpanish) "Accesos y escaleras" else "STATION ENTRANCES").uppercase(),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp,
                                    color = MutedText
                                )
                            }
                            items(station.entrances) { ent ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Login, contentDescription = null, tint = MutedText, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(ent.name, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (ent.hasElevator) {
                                            Icon(Icons.Default.Elevator, contentDescription = "Elevator", tint = SoftGreen, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        Text(
                                            text = ent.distance,
                                            fontSize = 12.sp,
                                            color = MutedText
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Action Button
                        MetroButton(
                            text = if (isSpanish) "Planear viaje aquí" else "Plan Journey Here",
                            onClick = {
                                val mockResult = StationOrPlaceSearchResult(station.name, "Metro Station", "STATION", "train", station.id)
                                viewModel.selectToStation(mockResult)
                                viewModel.selectTab(com.example.ui.viewmodel.AppTab.PLAN)
                            },
                            icon = Icons.Default.Directions,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
