package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetroViewModel

@Composable
fun ArrivalsScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val selectedStationId by viewModel.selectedArrivalStationId.collectAsState()
    val arrivalsQuery by viewModel.arrivalsSearchQuery.collectAsState()
    val arrivalsSearchResults by viewModel.arrivalsSearchResults.collectAsState()
    val isOffline by viewModel.isOfflineMode.collectAsState()
    val language by viewModel.language.collectAsState()

    val isSpanish = language == com.example.ui.viewmodel.Language.SPANISH

    val currentStation = viewModel.metroStations.firstOrNull { it.id == selectedStationId }
    val currentBusStop = viewModel.metroBusStops.firstOrNull { it.id == selectedStationId }

    val name = currentStation?.name ?: currentBusStop?.name ?: "7th Street / Metro Center"
    val linesList = currentStation?.lines ?: currentBusStop?.routes ?: listOf("B", "D", "A", "E")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App bar space
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .safeDrawingPadding()
        ) {
            Text(
                text = if (isSpanish) "HORARIOS EN VIVO" else "LIVE ARRIVALS",
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Station Quick Search Bar
            OutlinedTextField(
                value = arrivalsQuery,
                onValueChange = { viewModel.updateArrivalsSearch(it) },
                placeholder = { Text(if (isSpanish) "Buscar estación o parada de autobús..." else "Search station or bus stop...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("arrivals_station_search")
            )
        }

        // Search Results overlays
        if (arrivalsSearchResults.isNotEmpty()) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(arrivalsSearchResults) { result ->
                    ListItem(
                        headlineContent = { Text(result.title, fontWeight = FontWeight.Bold) },
                        supportingContent = { Text(result.subtitle, color = MutedText) },
                        leadingContent = {
                            Icon(
                                imageVector = if (result.type == "BUS_STOP") Icons.Default.DirectionsBus else Icons.Default.Train,
                                contentDescription = null
                            )
                        },
                        modifier = Modifier
                            .clickable { viewModel.selectArrivalStation(result.id) }
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                    )
                }
            }
        } else {
            // Main Arrivals View
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                // Active Station/Stop Showcase Header
                item {
                    Card(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = name,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    linesList.forEach { lineId ->
                                        LineBadge(lineId = lineId, size = 20)
                                    }
                                }
                            }
                            
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable {
                                        viewModel.selectTab(com.example.ui.viewmodel.AppTab.MAP)
                                    }
                                    .padding(8.dp)
                            ) {
                                Icon(Icons.Default.Map, contentDescription = "View on Map", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }

                // Offline Mode Banner Warning if active
                if (isOffline) {
                    item {
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 16.dp, vertical = 4.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(SoftOrange.copy(alpha = 0.15f))
                                .border(1.dp, SoftOrange, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CloudOff, contentDescription = "Offline", tint = SoftOrange)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = if (isSpanish) "Información en vivo no disponible. Mostrando horarios programados."
                                           else "Live information unavailable. Showing scheduled information.",
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                // Arrivals List Section
                item {
                    Text(
                        text = if (isSpanish) "PRÓXIMAS LLEGADAS" else "UPCOMING DEPARTURES",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MutedText,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                    )
                }

                val listArrivals = viewModel.getArrivalsForSelectedStation()
                if (listArrivals.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isSpanish) "Cargando horarios..." else "Searching schedule timetables...",
                                color = MutedText,
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    items(listArrivals) { arr ->
                        ArrivalRow(
                            lineId = arr.lineId,
                            lineName = arr.lineName,
                            destination = arr.destination,
                            minutes = arr.minutes,
                            platform = arr.platform,
                            status = arr.status,
                            isOffline = isOffline
                        )
                        Divider(modifier = Modifier.padding(horizontal = 16.dp))
                    }
                }

                // Station Page Facilities overview if it's a Rail Station
                currentStation?.let { station ->
                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = if (isSpanish) "COMODIDADES Y ACCESIBILIDAD" else "FACILITIES & ACCESSIBILITY",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MutedText,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                        )
                    }

                    // Accessibility Notes Card
                    item {
                        Card(
                            modifier = Modifier
                                .padding(horizontal = 16.dp, vertical = 4.dp)
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.Accessible, contentDescription = "Accessibility", tint = MetroBlue)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (isSpanish) "Declaración de Accesibilidad" else "Step-Free Level Access",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = station.accessibilityNote,
                                        fontSize = 12.sp,
                                        color = MutedText
                                    )
                                }
                            }
                        }
                    }

                    // Facilities list
                    items(station.facilities) { fac ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val vector = when (fac.iconName) {
                                    "elevator" -> Icons.Default.Elevator
                                    "wc" -> Icons.Default.Wc
                                    "credit_card" -> Icons.Default.CreditCard
                                    "directions_bike" -> Icons.Default.DirectionsBike
                                    else -> Icons.Default.Info
                                }
                                Icon(vector, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = fac.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(if (fac.isAvailable) SoftGreen else SoftOrange)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (fac.isAvailable) (if (isSpanish) "Operativo" else "Operational") else (if (isSpanish) "Fuera de servicio" else "Out of Service"),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (fac.isAvailable) SoftGreen else SoftOrange
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
