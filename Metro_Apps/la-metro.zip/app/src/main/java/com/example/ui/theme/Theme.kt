package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = Color.White,
  onPrimary = DeepCharcoal,
  secondary = MetroGold,
  onSecondary = DeepCharcoal,
  background = DeepCharcoal,
  onBackground = WarmWhite,
  surface = DarkCard,
  onSurface = WarmWhite,
  surfaceVariant = Color(0xFF2C2C2C),
  onSurfaceVariant = ConcreteGrey,
  outline = Color(0xFF3C3C3C)
)

private val LightColorScheme = lightColorScheme(
  primary = DeepCharcoal,
  onPrimary = Color.White,
  secondary = MetroGold,
  onSecondary = DeepCharcoal,
  background = WarmWhite,
  onBackground = DeepCharcoal,
  surface = Color.White,
  onSurface = DeepCharcoal,
  surfaceVariant = ConcreteGrey,
  onSurfaceVariant = DeepCharcoal,
  outline = BorderGrey
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disabling dynamic colors to force the custom LA Metro concrete-and-charcoal identity
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
