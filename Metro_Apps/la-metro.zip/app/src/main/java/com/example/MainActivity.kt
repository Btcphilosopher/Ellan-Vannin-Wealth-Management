package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.Language
import com.example.ui.viewmodel.MetroViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MetroViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            MyApplicationTheme(darkTheme = isDarkMode) {
                MainContainer(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainContainer(viewModel: MetroViewModel) {
    val activeTab by viewModel.activeTab.collectAsState()
    val language by viewModel.language.collectAsState()

    val isSpanish = language == Language.SPANISH

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_navigation_bar")
            ) {
                // Tab 1: PLAN
                NavigationBarItem(
                    selected = activeTab == AppTab.PLAN,
                    onClick = { viewModel.selectTab(AppTab.PLAN) },
                    icon = { Icon(Icons.Default.Directions, contentDescription = "Plan Route") },
                    label = { 
                        Text(
                            text = if (isSpanish) "Planear" else "Plan",
                            fontWeight = if (activeTab == AppTab.PLAN) FontWeight.Black else FontWeight.Normal,
                            fontSize = 11.sp
                        ) 
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("tab_plan")
                )

                // Tab 2: MAP
                NavigationBarItem(
                    selected = activeTab == AppTab.MAP,
                    onClick = { viewModel.selectTab(AppTab.MAP) },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Explore Map") },
                    label = { 
                        Text(
                            text = if (isSpanish) "Mapa" else "Map",
                            fontWeight = if (activeTab == AppTab.MAP) FontWeight.Black else FontWeight.Normal,
                            fontSize = 11.sp
                        ) 
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("tab_map")
                )

                // Tab 3: ARRIVALS
                NavigationBarItem(
                    selected = activeTab == AppTab.ARRIVALS,
                    onClick = { viewModel.selectTab(AppTab.ARRIVALS) },
                    icon = { Icon(Icons.Default.AccessTime, contentDescription = "Schedules") },
                    label = { 
                        Text(
                            text = if (isSpanish) "Llegadas" else "Arrivals",
                            fontWeight = if (activeTab == AppTab.ARRIVALS) FontWeight.Black else FontWeight.Normal,
                            fontSize = 11.sp
                        ) 
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("tab_arrivals")
                )

                // Tab 4: TAP
                NavigationBarItem(
                    selected = activeTab == AppTab.TAP,
                    onClick = { viewModel.selectTab(AppTab.TAP) },
                    icon = { Icon(Icons.Default.CreditCard, contentDescription = "TAP Fares") },
                    label = { 
                        Text(
                            text = "TAP",
                            fontWeight = if (activeTab == AppTab.TAP) FontWeight.Black else FontWeight.Normal,
                            fontSize = 11.sp
                        ) 
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("tab_tap")
                )

                // Tab 5: MORE
                NavigationBarItem(
                    selected = activeTab == AppTab.MORE,
                    onClick = { viewModel.selectTab(AppTab.MORE) },
                    icon = { Icon(Icons.Default.Menu, contentDescription = "Settings") },
                    label = { 
                        Text(
                            text = if (isSpanish) "Más" else "More",
                            fontWeight = if (activeTab == AppTab.MORE) FontWeight.Black else FontWeight.Normal,
                            fontSize = 11.sp
                        ) 
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("tab_more")
                )
            }
        }
    ) { innerPadding ->
        Crossfade(
            targetState = activeTab,
            label = "ScreenCrossfade",
            modifier = Modifier.padding(innerPadding)
        ) { tab ->
            when (tab) {
                AppTab.PLAN -> PlanScreen(viewModel = viewModel)
                AppTab.MAP -> MapScreen(viewModel = viewModel)
                AppTab.ARRIVALS -> ArrivalsScreen(viewModel = viewModel)
                AppTab.TAP -> TapScreen(viewModel = viewModel)
                AppTab.MORE -> MoreScreen(viewModel = viewModel)
            }
        }
    }
}
