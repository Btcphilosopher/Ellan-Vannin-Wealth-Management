package com.example.data.models

import androidx.compose.ui.graphics.Color

enum class LineType {
    RAIL, BUS, BOTH
}

enum class AlertSeverity {
    INFO, MINOR, MAJOR, SEVERE
}

data class MetroLine(
    val id: String,
    val name: String,
    val colorHex: String,
    val type: LineType,
    val stations: List<String> = emptyList()
) {
    val color: Color get() = Color(android.graphics.Color.parseColor(colorHex))
}

data class StationEntrance(
    val name: String,
    val distance: String,
    val isOpen: Boolean,
    val hasElevator: Boolean
)

data class StationFacility(
    val name: String,
    val iconName: String,
    val isAvailable: Boolean
)

data class MetroStation(
    val id: String,
    val name: String,
    val lines: List<String>, // IDs of MetroLines passing through
    val latitude: Double,
    val longitude: Double,
    val walkingDistance: String = "",
    val entrances: List<StationEntrance> = emptyList(),
    val facilities: List<StationFacility> = emptyList(),
    val accessibilityNote: String = "Fully accessible with step-free elevators.",
    val nearbyDestinations: List<String> = emptyList()
)

data class MetroBusStop(
    val id: String,
    val name: String,
    val routes: List<String>, // Bus route numbers passing through
    val latitude: Double,
    val longitude: Double,
    val walkingDistance: String = ""
)

data class Arrival(
    val lineId: String,
    val lineName: String,
    val destination: String,
    val minutes: Int,
    val platform: String = "Platform 1",
    val status: String = "On Time"
)

data class ServiceAlert(
    val id: String,
    val lineId: String?, // Null means system-wide or generic
    val lineName: String,
    val lineColorHex: String?,
    val severity: AlertSeverity,
    val title: String,
    val description: String,
    val updatedAgo: String,
    val duration: String = "Until further notice"
)

data class SavedPlace(
    val id: String,
    val name: String,
    val address: String,
    val category: String, // "Home", "Work", "School", "Airport", "Custom"
    val iconName: String
)

data class SavedJourney(
    val id: String,
    val fromStationId: String,
    val toStationId: String,
    val fromStationName: String,
    val toStationName: String,
    val timeLabel: String,
    val daysLabel: String
)

data class TapTransaction(
    val id: String,
    val date: String,
    val description: String,
    val cost: Double
)

data class TapCard(
    val cardNumber: String,
    val balance: Double,
    val expiryDate: String,
    val transactions: List<TapTransaction> = emptyList(),
    val activePass: String? = null // e.g. "7-Day Pass", "30-Day Pass"
)

data class RouteSegment(
    val mode: String, // "WALK", "RAIL", "BUS"
    val routeName: String, // e.g. "B Line", "720"
    val routeColorHex: String?,
    val fromName: String,
    val toName: String,
    val durationMinutes: Int,
    val stopsCount: Int = 0,
    val stopsList: List<String> = emptyList()
)

data class JourneyOption(
    val id: String,
    val segments: List<RouteSegment>,
    val totalDurationMinutes: Int,
    val transfersCount: Int,
    val walkingMinutes: Int,
    val departureTime: String,
    val arrivalTime: String,
    val tag: String = "Fastest" // "Fastest", "Fewest Transfers", "Least Walking"
)
