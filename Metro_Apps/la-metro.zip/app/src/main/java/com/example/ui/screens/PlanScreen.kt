package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.JourneyOption
import com.example.data.repository.StationOrPlaceSearchResult
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MetroViewModel

@Composable
fun PlanScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val selectedToStation by viewModel.selectedToStation.collectAsState()
    val journeyOptions by viewModel.journeyOptions.collectAsState()
    val selectedJourney by viewModel.selectedJourney.collectAsState()
    val isActiveJourneyLive by viewModel.isActiveJourneyLive.collectAsState()
    val language by viewModel.language.collectAsState()

    val isSpanish = language == com.example.ui.viewmodel.Language.SPANISH

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (isActiveJourneyLive && selectedJourney != null) {
            // Live Navigation View
            LiveJourneyNavView(viewModel = viewModel, isSpanish = isSpanish)
        } else if (selectedToStation != null) {
            // Journey Planning Results View
            JourneyResultsView(viewModel = viewModel, isSpanish = isSpanish)
        } else {
            // Initial Landing View with Search & Recent / Saved links
            PlanLandingView(viewModel = viewModel, isSpanish = isSpanish)
        }
    }
}

@Composable
fun PlanLandingView(
    viewModel: MetroViewModel,
    isSpanish: Boolean
) {
    val searchQueryTo by viewModel.searchQueryTo.collectAsState()
    val searchResultsTo by viewModel.searchResultsTo.collectAsState()
    val savedPlaces by viewModel.savedPlaces.collectAsState()
    val savedJourneys by viewModel.savedJourneys.collectAsState()
    val recentSearches by viewModel.recentSearches.collectAsState()
    val alerts by viewModel.alerts.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Hero Image Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                // Background generated image
                Image(
                    painter = painterResource(id = com.example.R.drawable.img_hero_banner_1790933423986),
                    contentDescription = "LA Metro architectural banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Dark subtle gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, DeepCharcoal.copy(alpha = 0.8f))
                            )
                        )
                )

                // App Welcome Text
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "LA METRO",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 32.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (isSpanish) "PLANEA. VIAJA. LLEGA." else "PLAN. RIDE. ARRIVE.",
                        color = MetroGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        letterSpacing = 2.sp
                    )
                }
            }
        }

        // Active Emergency Alert indicator on home
        val emergencyAlert = alerts.firstOrNull { it.id == "AL-DISRUPT" }
        if (emergencyAlert != null) {
            item {
                Box(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MetroRed.copy(alpha = 0.15f))
                        .border(1.dp, MetroRed, RoundedCornerShape(8.dp))
                        .clickable { viewModel.selectTab(com.example.ui.viewmodel.AppTab.MORE) }
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = "Alert", tint = MetroRed, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isSpanish) "INTERRUPCIÓN DE SERVICIO ACTIVA" else "ACTIVE SERVICE INTERRUPTION",
                                color = MetroRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = emergencyAlert.title,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (isSpanish) "Toca para ver desvíos y alternativas" else "Tap to view shuttle detours & alternatives",
                                color = MutedText,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Search Section Card
        item {
            Card(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isSpanish) "¿A dónde vas?" else "Where to?",
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // From Field
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(12.dp)
                    ) {
                        Icon(Icons.Default.MyLocation, contentDescription = "My Location", tint = MetroBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isSpanish) "Mi Ubicación" else "My Location",
                                fontSize = 11.sp,
                                color = MutedText,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Hollywood / Vine Station (B Line)",
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // To Search Field
                    OutlinedTextField(
                        value = searchQueryTo,
                        onValueChange = { viewModel.updateSearchTo(it) },
                        placeholder = { Text(if (isSpanish) "Buscar estación o lugar..." else "Search stations, stadium, LAX...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon") },
                        trailingIcon = {
                            if (searchQueryTo.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateSearchTo("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("destination_search_input")
                    )
                }
            }
        }

        // Search Results list
        if (searchResultsTo.isNotEmpty()) {
            item {
                Text(
                    text = if (isSpanish) "RESULTADOS DE BÚSQUEDA" else "SEARCH RESULTS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MutedText,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
            items(searchResultsTo) { result ->
                ListItem(
                    headlineContent = { Text(result.title, fontWeight = FontWeight.Bold) },
                    supportingContent = { Text(result.subtitle, color = MutedText) },
                    leadingContent = {
                        val iconVector = when (result.iconName) {
                            "flight" -> Icons.Default.Flight
                            "sports_baseball" -> Icons.Default.SportsBaseball
                            "sports_basketball" -> Icons.Default.SportsBasketball
                            "sports_football" -> Icons.Default.SportsFootball
                            "music_note" -> Icons.Default.MusicNote
                            "directions_bus" -> Icons.Default.DirectionsBus
                            else -> Icons.Default.Train
                        }
                        Icon(iconVector, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    modifier = Modifier
                        .clickable { viewModel.selectToStation(result) }
                        .padding(horizontal = 16.dp, vertical = 2.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                )
            }
        } else {
            // Normal Dashboard: Saved places, recent searches, saved journeys
            if (savedPlaces.isNotEmpty()) {
                item {
                    Text(
                        text = if (isSpanish) "SITIOS GUARDADOS" else "SAVED PLACES",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MutedText,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
                items(savedPlaces) { place ->
                    PlaceCard(
                        name = place.name,
                        address = place.address,
                        iconName = place.iconName,
                        onSelect = {
                            val mockResult = StationOrPlaceSearchResult(place.name, place.address, "PLACE", place.iconName, "7MC")
                            viewModel.selectToStation(mockResult)
                        },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
            }

            if (savedJourneys.isNotEmpty()) {
                item {
                    Text(
                        text = if (isSpanish) "VIAJES GUARDADOS" else "SAVED JOURNEYS",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MutedText,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
                items(savedJourneys) { journey ->
                    Card(
                        modifier = Modifier
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .fillMaxWidth()
                            .clickable { viewModel.loadSavedJourney(journey) },
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "${journey.fromStationName} ➔ ${journey.toStationName}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "${journey.daysLabel} • ${journey.timeLabel}",
                                    fontSize = 12.sp,
                                    color = MutedText
                                )
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MutedText)
                        }
                    }
                }
            }

            if (recentSearches.isNotEmpty()) {
                item {
                    Text(
                        text = if (isSpanish) "BÚSQUEDAS RECIENTES (REPETIR VIAJE)" else "RECENT SEARCHES (REPEAT TRIP)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = MutedText,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
                items(recentSearches) { search ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectRecentSearch(search) }
                            .padding(horizontal = 24.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.History, contentDescription = null, tint = MutedText, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = search,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun JourneyResultsView(
    viewModel: MetroViewModel,
    isSpanish: Boolean
) {
    val selectedFrom by viewModel.selectedFromStation.collectAsState()
    val selectedTo by viewModel.selectedToStation.collectAsState()
    val journeyOptions by viewModel.journeyOptions.collectAsState()
    val selectedJourney by viewModel.selectedJourney.collectAsState()
    val isBLineSuspended by viewModel.isBLineInterrupted.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Upper Navigation Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .safeDrawingPadding(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.clearJourneySearch() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = if (isSpanish) "Opciones de Ruta" else "Transit Route Options",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )
                Text(
                    text = "${selectedFrom?.title} ➔ ${selectedTo?.title}",
                    fontSize = 13.sp,
                    color = MutedText
                )
            }
        }

        // Disruption Alert banner
        if (isBLineSuspended && selectedTo?.id == "7MC") {
            Box(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MetroRed.copy(alpha = 0.15f))
                    .border(1.dp, MetroRed, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = "Warning", tint = MetroRed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpanish) "RUTA TRADICIONAL AFECTADA" else "TRADITIONAL ROUTE AFFECTED",
                            color = MetroRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        text = if (isSpanish) "La Línea B está suspendida. Autobuses de emergencia y desvíos sugeridos abajo." else "B Line (Red) is suspended. Suggested emergency shuttles loaded below.",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // Horizontal Route Options Scroller
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = if (isSpanish) "VIAJES DISPONIBLES" else "RECOMMENDED JOURNEYS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MutedText
                )
            }

            // Route Cards list
            items(journeyOptions) { option ->
                val isSelected = selectedJourney?.id == option.id
                val borderCol = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                
                RouteCard(
                    duration = option.totalDurationMinutes,
                    transfers = option.transfersCount,
                    walkingMinutes = option.walkingMinutes,
                    departureTime = option.departureTime,
                    arrivalTime = option.arrivalTime,
                    tag = option.tag,
                    segments = option.segments.map { it.mode.let { mode -> if (mode == "WALK") "WALK" else it.routeName.replace(" Line (Red)", "B").replace(" Line (Blue)", "A").replace(" Line (Expo)", "E") } },
                    onClick = { viewModel.selectJourneyOption(option) },
                    modifier = Modifier.border(if (isSelected) 2.5.dp else 1.dp, borderCol, RoundedCornerShape(12.dp))
                )
            }

            // Timeline details for the selected journey
            selectedJourney?.let { journey ->
                item {
                    Divider(modifier = Modifier.padding(vertical = 12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isSpanish) "DETALLE DEL RECORRIDO" else "TRIP TIMELINE",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MutedText
                        )
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { viewModel.saveJourneyOption() }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.BookmarkBorder, contentDescription = "Save", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isSpanish) "Guardar" else "Save journey",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Step Timeline Items
                items(journey.segments) { segment ->
                    JourneyStep(
                        time = if (segment.mode == "WALK") "" else journey.departureTime,
                        title = segment.routeName,
                        subtitle = "From ${segment.fromName} to ${segment.toName}",
                        mode = segment.mode,
                        lineId = if (segment.mode != "WALK") segment.routeName.take(1) else null,
                        lineColorHex = segment.routeColorHex,
                        isLast = journey.segments.last() == segment
                    )
                }

                item {
                    MetroButton(
                        text = if (isSpanish) "COMENZAR NAVEGACIÓN EN VIVO" else "START LIVE NAVIGATION",
                        onClick = { viewModel.startLiveJourney() },
                        icon = Icons.Default.Navigation,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp)
                            .testTag("start_journey_button")
                    )
                }
            }
        }
    }
}

@Composable
fun LiveJourneyNavView(
    viewModel: MetroViewModel,
    isSpanish: Boolean
) {
    val selectedJourney by viewModel.selectedJourney.collectAsState()
    val currentSegmentIndex by viewModel.currentSegmentIndex.collectAsState()
    val navStatusMessage by viewModel.navStatusMessage.collectAsState()

    val journey = selectedJourney ?: return
    val segment = journey.segments.getOrNull(currentSegmentIndex) ?: journey.segments.last()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepCharcoal)
            .padding(24.dp)
            .safeDrawingPadding()
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = (if (isSpanish) "NAVEGACIÓN ACTIVA" else "ACTIVE RIDE NAVIGATION").uppercase(),
                color = MetroGold,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp,
                letterSpacing = 2.sp
            )
            
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.1f))
                    .clickable { viewModel.stopLiveJourney() }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (isSpanish) "Terminar" else "End Trip",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Big glanceable instruction
        Text(
            text = if (isSpanish) "Siguiente Paso" else "CURRENT INSTRUCTION",
            color = Color.White.copy(alpha = 0.5f),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            letterSpacing = 1.sp
        )
        
        Text(
            text = navStatusMessage,
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 28.sp,
            lineHeight = 36.sp,
            modifier = Modifier
                .padding(vertical = 12.dp)
                .testTag("live_navigation_status")
        )

        // Custom Visual Progress Meter
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color.White.copy(alpha = 0.1f))
        ) {
            val progressWidth = (currentSegmentIndex + 1).toFloat() / journey.segments.size
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(progressWidth)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (segment.routeColorHex != null) Color(android.graphics.Color.parseColor(segment.routeColorHex))
                        else MetroGold
                    )
            )
        }

        Spacer(modifier = Modifier.height(48.dp))

        // Detail checklist cards
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isSpanish) "DETALLES DEL SEGMENTO" else "SEGMENT PROTOCOL",
                    color = Color.White.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (segment.mode) {
                            "WALK" -> Icons.Default.DirectionsWalk
                            "BUS" -> Icons.Default.DirectionsBus
                            else -> Icons.Default.Train
                        },
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = segment.routeName,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "From ${segment.fromName} to ${segment.toName}",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Transfer Warnings
        if (segment.mode == "WALK" && currentSegmentIndex > 0) {
            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MetroGold.copy(alpha = 0.15f))
                    .border(1.dp, MetroGold, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = MetroGold)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isSpanish) "ADVERTENCIA DE TRANSFERENCIA" else "TRANSFER INSTRUCTIONS",
                            color = MetroGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Text(
                            text = if (isSpanish) "Sigue los letreros para la plataforma de la Línea A (Azul)." else "Transfer here. Walk 3 minutes. Follow signs for A Line (Blue) platform.",
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Next Step Command Button
        Button(
            onClick = { viewModel.advanceLiveJourneyStep() },
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DeepCharcoal),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("advance_journey_button")
        ) {
            Text(
                text = if (currentSegmentIndex == journey.segments.size - 1) (if (isSpanish) "COMPLETAR VIAJE" else "COMPLETE JOURNEY") else (if (isSpanish) "SIGUIENTE PARADA" else "NEXT STOP"),
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                letterSpacing = 1.sp
            )
        }
    }
}
