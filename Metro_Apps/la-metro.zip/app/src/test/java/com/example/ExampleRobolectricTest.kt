package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.TransitRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34]) // 34 is well supported in this build environment
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LA Metro", appName)
    }

    @Test
    fun `verify station search handles typos and aliases`() {
        val repo = TransitRepository()
        
        // Check LAX smart alias
        val laxResults = repo.searchDestinations("lax")
        assertTrue(laxResults.any { it.title.contains("LAX") })

        // Check Hollywood spelling tolerance
        val hollywoodResults = repo.searchDestinations("hollywd")
        assertTrue(hollywoodResults.any { it.title.contains("Hollywood / Vine") })

        // Check Dodgers smart alias
        val dodgersResults = repo.searchDestinations("dodgers")
        assertTrue(dodgersResults.any { it.title.contains("Dodger") })
    }

    @Test
    fun `verify journey planning Hollywood to Downtown under normal operations`() {
        val repo = TransitRepository()
        
        // Ensure disruption is inactive
        repo.triggerBLineInterruption(false)
        
        val options = repo.planJourney("HVI", "7MC")
        
        // Should have direct B Line Red option
        val firstOption = options.first()
        assertEquals("Fastest (Direct)", firstOption.tag)
        assertEquals(19, firstOption.totalDurationMinutes)
        assertEquals(0, firstOption.transfersCount)
        assertTrue(firstOption.segments.any { it.routeName == "B Line (Red)" })
    }

    @Test
    fun `verify journey planning alternative route is suggested when disruption is active`() {
        val repo = TransitRepository()
        
        // Trigger B Line Emergency Suspension
        repo.triggerBLineInterruption(true)
        
        val options = repo.planJourney("HVI", "7MC")
        
        // First option should suggest Emergency Shuttle
        val firstOption = options.first()
        assertTrue(firstOption.tag.contains("Emergency Shuttle"))
        assertTrue(firstOption.segments.any { it.routeName.contains("Shuttle") })
        assertEquals(1, firstOption.transfersCount)
    }

    @Test
    fun `verify TAP Card simulated topups`() {
        val repo = TransitRepository()
        val initialBalance = repo.tapCardState.value.balance
        
        repo.addMoneyToTap(20.0)
        
        val updatedBalance = repo.tapCardState.value.balance
        assertEquals(initialBalance + 20.0, updatedBalance, 0.01)
        
        // Purchase weekly pass
        repo.purchasePass("7-Day Pass", 18.0)
        assertEquals(initialBalance + 2.0, repo.tapCardState.value.balance, 0.01)
        assertEquals("7-Day Pass", repo.tapCardState.value.activePass)
    }
}
