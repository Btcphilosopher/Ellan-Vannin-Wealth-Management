package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.transit.data.remote.TransitRemoteDataSource
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `verify app name in German`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("München Mobil", appName)
    }

    @Test
    fun `test remote datasource stations and journeys`() = runBlocking {
        val dataSource = TransitRemoteDataSource()
        val stations = dataSource.fetchStations()
        assertNotNull(stations)
        assertEquals(true, stations.isNotEmpty())

        val journeys = dataSource.searchJourneys("Marienplatz", "Münchner Freiheit", "Schnellste")
        assertNotNull(journeys)
        assertEquals(true, journeys.isNotEmpty())
        assertEquals("Marienplatz", journeys[0].originName)
    }
}
