package com.example.transit.domain.model

enum class TransportMode {
    U_BAHN, S_BAHN, TRAM, BUS, REGIONAL, WALK
}

enum class VehicleStatus {
    ON_TIME, DELAYED, CANCELLED, FREQUENT
}

data class Station(
    val id: String,
    val name: String,
    val lines: List<String>,
    val latitude: Double,
    val longitude: Double,
    val hasElevator: Boolean = true,
    val hasEscalator: Boolean = true,
    val isBarrierFree: Boolean = true,
    val hasBikeStorage: Boolean = true,
    val district: String = "München"
)

data class Route(
    val id: String,
    val name: String,
    val mode: TransportMode,
    val colorHex: String,
    val origin: String,
    val destination: String,
    val status: String = "Normalbetrieb"
)

data class Departure(
    val id: String,
    val lineName: String,
    val mode: TransportMode,
    val destination: String,
    val departureTime: String,
    val countdownMinutes: Int,
    val platform: String,
    val isRealtime: Boolean = true,
    val status: VehicleStatus = VehicleStatus.ON_TIME,
    val stationId: String
)

data class Vehicle(
    val id: String,
    val routeId: String,
    val lineName: String,
    val mode: TransportMode,
    val latitude: Double,
    val longitude: Double,
    val bearing: Double,
    val speed: Double?,
    val destination: String?,
    val status: VehicleStatus,
    val lastUpdated: Long
)

data class JourneyLeg(
    val mode: TransportMode,
    val lineName: String,
    val originStop: String,
    val destinationStop: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val platform: String?,
    val intermediateStopsCount: Int
)

data class Journey(
    val id: String,
    val originName: String,
    val destinationName: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val transfersCount: Int,
    val walkingMinutes: Int,
    val isBarrierFree: Boolean,
    val legs: List<JourneyLeg>
)

data class ServiceAlert(
    val id: String,
    val lineName: String,
    val mode: TransportMode,
    val title: String,
    val description: String,
    val affectedRoute: String,
    val updateTime: String,
    val severity: String // "INFO", "WARNING", "SEVERE"
)

data class FavoriteItem(
    val id: String,
    val type: String, // "STATION", "LINE", "JOURNEY"
    val title: String,
    val subtitle: String,
    val details: String
)
