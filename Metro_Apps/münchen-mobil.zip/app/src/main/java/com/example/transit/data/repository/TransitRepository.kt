package com.example.transit.data.repository

import com.example.transit.data.local.FavoriteEntity
import com.example.transit.data.local.RecentSearchEntity
import com.example.transit.data.local.RouteEntity
import com.example.transit.data.local.StationEntity
import com.example.transit.data.local.TransitDao
import com.example.transit.data.remote.TransitRemoteDataSource
import com.example.transit.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

class TransitRepository(
    private val transitDao: TransitDao,
    private val remoteDataSource: TransitRemoteDataSource
) {
    val stations: Flow<List<Station>> = transitDao.getAllStations().map { entities ->
        if (entities.isEmpty()) {
            // return default remote or cache them
            listOf()
        } else {
            entities.map { e ->
                Station(
                    id = e.id,
                    name = e.name,
                    lines = e.linesCsv.split(","),
                    latitude = e.latitude,
                    longitude = e.longitude,
                    hasElevator = e.hasElevator,
                    hasEscalator = e.hasEscalator,
                    isBarrierFree = e.isBarrierFree,
                    hasBikeStorage = e.hasBikeStorage,
                    district = e.district
                )
            }
        }
    }

    val routes: Flow<List<Route>> = transitDao.getAllRoutes().map { entities ->
        entities.map { e ->
            Route(
                id = e.id,
                name = e.name,
                mode = TransportMode.valueOf(e.mode),
                colorHex = e.colorHex,
                origin = e.origin,
                destination = e.destination,
                status = e.status
            )
        }
    }

    val favourites: Flow<List<FavoriteItem>> = transitDao.getAllFavourites().map { entities ->
        entities.map { e ->
            FavoriteItem(
                id = e.id,
                type = e.type,
                title = e.title,
                subtitle = e.subtitle,
                details = e.details
            )
        }
    }

    val recentSearches: Flow<List<String>> = transitDao.getRecentSearches().map { entities ->
        entities.map { it.queryText }
    }

    suspend fun refreshData() {
        try {
            val remoteStations = remoteDataSource.fetchStations()
            val stationEntities = remoteStations.map { s ->
                StationEntity(
                    id = s.id,
                    name = s.name,
                    linesCsv = s.lines.joinToString(","),
                    latitude = s.latitude,
                    longitude = s.longitude,
                    hasElevator = s.hasElevator,
                    hasEscalator = s.hasEscalator,
                    isBarrierFree = s.isBarrierFree,
                    hasBikeStorage = s.hasBikeStorage,
                    district = s.district
                )
            }
            transitDao.insertStations(stationEntities)

            val remoteRoutes = remoteDataSource.fetchRoutes()
            val routeEntities = remoteRoutes.map { r ->
                RouteEntity(
                    id = r.id,
                    name = r.name,
                    mode = r.mode.name,
                    colorHex = r.colorHex,
                    origin = r.origin,
                    destination = r.destination,
                    status = r.status
                )
            }
            transitDao.insertRoutes(routeEntities)
        } catch (_: Exception) {
            // Fallback or offline graceful handling
        }
    }

    suspend fun getDepartures(stationId: String): List<Departure> {
        return remoteDataSource.fetchDepartures(stationId)
    }

    suspend fun getVehicles(): List<Vehicle> {
        return remoteDataSource.fetchVehicles()
    }

    suspend fun getServiceAlerts(): List<ServiceAlert> {
        return remoteDataSource.fetchServiceAlerts()
    }

    suspend fun searchJourneys(origin: String, destination: String, timeFilter: String): List<Journey> {
        return remoteDataSource.searchJourneys(origin, destination, timeFilter)
    }

    suspend fun addFavorite(item: FavoriteItem) {
        transitDao.insertFavorite(
            FavoriteEntity(
                id = item.id,
                type = item.type,
                title = item.title,
                subtitle = item.subtitle,
                details = item.details
            )
        )
    }

    suspend fun removeFavorite(id: String) {
        transitDao.deleteFavorite(id)
    }

    suspend fun addRecentSearch(query: String) {
        if (query.isNotBlank()) {
            transitDao.insertRecentSearch(RecentSearchEntity(queryText = query))
        }
    }
}
