package com.example.transit.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.transit.ui.bus.BusScreen
import com.example.transit.ui.components.MunichBottomBar
import com.example.transit.ui.departures.DepartureBoardScreen
import com.example.transit.ui.disruptions.DisruptionsScreen
import com.example.transit.ui.favourites.FavouritesScreen
import com.example.transit.ui.home.HomeScreen
import com.example.transit.ui.journey.JourneyPlannerScreen
import com.example.transit.ui.map.NetworkMapScreen
import com.example.transit.ui.sbahn.SBahnScreen
import com.example.transit.ui.station.StationDetailScreen
import com.example.transit.ui.tram.TramScreen
import com.example.transit.ui.ubahn.UBahnScreen

@Composable
fun NavGraph() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Home.route

    val showBottomBar = currentRoute in listOf(
        Screen.Home.route,
        Screen.Journey.route,
        Screen.Map.route,
        Screen.Disruptions.route,
        Screen.Favourites.route
    )

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                MunichBottomBar(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        navController.navigate(route) {
                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onNavigateToJourney = { origin, destination ->
                        navController.navigate(Screen.Journey.route)
                    },
                    onNavigateToDepartures = { stationId ->
                        navController.navigate(Screen.Departures.createRoute(stationId))
                    },
                    onNavigateToMap = { navController.navigate(Screen.Map.route) },
                    onNavigateToUBahn = { navController.navigate(Screen.UBahn.route) },
                    onNavigateToSBahn = { navController.navigate(Screen.SBahn.route) },
                    onNavigateToTram = { navController.navigate(Screen.Tram.route) },
                    onNavigateToBus = { navController.navigate(Screen.Bus.route) },
                    onNavigateToDisruptions = { navController.navigate(Screen.Disruptions.route) },
                    onNavigateToStation = { stationId ->
                        navController.navigate(Screen.StationDetail.createRoute(stationId))
                    }
                )
            }
            composable(Screen.Journey.route) {
                JourneyPlannerScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Map.route) {
                NetworkMapScreen(
                    onNavigateToStation = { stationId ->
                        navController.navigate(Screen.StationDetail.createRoute(stationId))
                    }
                )
            }
            composable(Screen.Disruptions.route) {
                DisruptionsScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Favourites.route) {
                FavouritesScreen(
                    onNavigateToStation = { stationId ->
                        navController.navigate(Screen.StationDetail.createRoute(stationId))
                    }
                )
            }
            composable(Screen.UBahn.route) {
                UBahnScreen(onNavigateBack = { navController.popBackStack() })
            }
            composable(Screen.SBahn.route) {
                SBahnScreen(onNavigateBack = { navController.popBackStack() })
            }
            composable(Screen.Tram.route) {
                TramScreen(onNavigateBack = { navController.popBackStack() })
            }
            composable(Screen.Bus.route) {
                BusScreen(onNavigateBack = { navController.popBackStack() })
            }
            composable(
                route = Screen.StationDetail.route,
                arguments = listOf(navArgument("stationId") { type = NavType.StringType })
            ) { backStackEntry ->
                val stationId = backStackEntry.arguments?.getString("stationId") ?: "s_marienplatz"
                StationDetailScreen(
                    stationId = stationId,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable(
                route = Screen.Departures.route,
                arguments = listOf(navArgument("stationId") { type = NavType.StringType })
            ) { backStackEntry ->
                val stationId = backStackEntry.arguments?.getString("stationId") ?: "s_marienplatz"
                DepartureBoardScreen(
                    stationId = stationId,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}
