package com.example.transit.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Journey : Screen("journey")
    object Map : Screen("map")
    object Disruptions : Screen("disruptions")
    object Favourites : Screen("favourites")
    object UBahn : Screen("ubahn")
    object SBahn : Screen("sbahn")
    object Tram : Screen("tram")
    object Bus : Screen("bus")
    object StationDetail : Screen("station/{stationId}") {
        fun createRoute(stationId: String) = "station/$stationId"
    }
    object Departures : Screen("departures/{stationId}") {
        fun createRoute(stationId: String) = "departures/$stationId"
    }
    object Settings : Screen("settings")
}
