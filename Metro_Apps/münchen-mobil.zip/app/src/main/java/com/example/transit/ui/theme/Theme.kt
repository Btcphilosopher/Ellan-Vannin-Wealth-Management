package com.example.transit.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = MunichBlueLight,
    secondary = MunichOrange,
    background = MunichBackgroundDark,
    surface = MunichSurfaceDark,
    onPrimary = MunichOnSurfaceDark,
    onSecondary = MunichOnSurfaceDark,
    onBackground = MunichOnSurfaceDark,
    onSurface = MunichOnSurfaceDark
)

private val LightColorScheme = lightColorScheme(
    primary = MunichBlue,
    secondary = MunichOrange,
    background = MunichBackgroundLight,
    surface = MunichSurfaceLight,
    onPrimary = MunichSurfaceLight,
    onSecondary = MunichSurfaceLight,
    onBackground = MunichOnSurfaceLight,
    onSurface = MunichOnSurfaceLight
)

@Composable
fun MunichTransitTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalView.current.context
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
