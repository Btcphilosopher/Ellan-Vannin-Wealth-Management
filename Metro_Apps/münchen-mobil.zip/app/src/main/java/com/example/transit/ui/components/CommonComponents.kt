package com.example.transit.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.transit.domain.model.TransportMode
import com.example.transit.ui.theme.*

@Composable
fun ModeBadge(mode: TransportMode, name: String) {
    val bg = when (mode) {
        TransportMode.U_BAHN -> UBahnRed
        TransportMode.S_BAHN -> SBahnBlue
        TransportMode.TRAM -> TramRed
        TransportMode.BUS -> BusBlue
        else -> MaterialTheme.colorScheme.primary
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier.padding(end = 6.dp)
    ) {
        Text(
            text = name,
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun MunichBottomBar(currentRoute: String, onNavigate: (String) -> Unit) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = currentRoute == "home",
            onClick = { onNavigate("home") },
            icon = { Icon(Icons.Default.Home, contentDescription = "Start") },
            label = { Text("Start") }
        )
        NavigationBarItem(
            selected = currentRoute == "journey",
            onClick = { onNavigate("journey") },
            icon = { Icon(Icons.Default.Route, contentDescription = "Verbindung") },
            label = { Text("Verbindung") }
        )
        NavigationBarItem(
            selected = currentRoute == "map",
            onClick = { onNavigate("map") },
            icon = { Icon(Icons.Default.Map, contentDescription = "Karte") },
            label = { Text("Karte") }
        )
        NavigationBarItem(
            selected = currentRoute == "disruptions",
            onClick = { onNavigate("disruptions") },
            icon = { Icon(Icons.Default.Warning, contentDescription = "Störungen") },
            label = { Text("Störungen") }
        )
        NavigationBarItem(
            selected = currentRoute == "favourites",
            onClick = { onNavigate("favourites") },
            icon = { Icon(Icons.Default.Star, contentDescription = "Favoriten") },
            label = { Text("Favoriten") }
        )
    }
}
