package com.example.transit.data.remote

import com.example.transit.domain.model.*
import kotlinx.coroutines.delay
import java.time.Instant

class TransitRemoteDataSource {

    suspend fun fetchStations(): List<Station> {
        delay(300) // simulate network latency
        return listOf(
            Station(
                id = "s_marienplatz",
                name = "Marienplatz",
                lines = listOf("U3", "U6", "S1", "S2", "S3", "S4", "S6", "S7", "S8"),
                latitude = 48.137154,
                longitude = 11.576124,
                hasElevator = true,
                hasEscalator = true,
                isBarrierFree = true,
                hasBikeStorage = true,
                district = "Altstadt-Lehel"
            ),
            Station(
                id = "s_hauptbahnhof",
                name = "München Hauptbahnhof",
                lines = listOf("U1", "U2", "U4", "U5", "U7", "S1", "S2", "S3", "S4", "S6", "S7", "S8", "Tram 19", "Bus 100"),
                latitude = 48.140227,
                longitude = 11.558332,
                hasElevator = true,
                hasEscalator = true,
                isBarrierFree = true,
                hasBikeStorage = true,
                district = "Ludwigsvorstadt-Isarvorstadt"
            ),
            Station(
                id = "s_karlsplatz",
                name = "Karlsplatz (Stachus)",
                lines = listOf("U4", "U5", "S1", "S2", "S3", "S4", "S6", "S7", "S8", "Tram 19", "Tram 20", "Bus 100"),
                latitude = 48.139618,
                longitude = 11.565492,
                hasElevator = true,
                hasEscalator = true,
                isBarrierFree = true,
                hasBikeStorage = true,
                district = "Altstadt-Lehel"
            ),
            Station(
                id = "s_ostbahnhof",
                name = "München Ostbahnhof",
                lines = listOf("U5", "S1", "S2", "S3", "S4", "S6", "S7", "S8", "Tram 19", "Bus 54", "Bus 100"),
                latitude = 48.126583,
                longitude = 11.608306,
                hasElevator = true,
                hasEscalator = true,
                isBarrierFree = true,
                hasBikeStorage = true,
                district = "Haidhausen"
            ),
            Station(
                id = "s_muenchener_freiheit",
                name = "Münchner Freiheit",
                lines = listOf("U3", "U6", "Bus 54"),
                latitude = 48.161421,
                longitude = 11.586111,
                hasElevator = true,
                hasEscalator = true,
                isBarrierFree = true,
                hasBikeStorage = true,
                district = "Schwabing"
            ),
            Station(
                id = "s_garching",
                name = "Garching-Forschungszentrum",
                lines = listOf("U6"),
                latitude = 48.262500,
                longitude = 11.667800,
                hasElevator = true,
                hasEscalator = false,
                isBarrierFree = true,
                hasBikeStorage = true,
                district = "Garching b. München"
            ),
            Station(
                id = "s_grosshadern",
                name = "Klinikum Großhadern",
                lines = listOf("U6"),
                latitude = 48.110500,
                longitude = 11.469500,
                hasElevator = true,
                hasEscalator = true,
                isBarrierFree = true,
                hasBikeStorage = true,
                district = "Hadern"
            ),
            Station(
                id = "s_flughafen",
                name = "Flughafen München",
                lines = listOf("S1", "S8"),
                latitude = 48.353783,
                longitude = 11.786086,
                hasElevator = true,
                hasEscalator = true,
                isBarrierFree = true,
                hasBikeStorage = true,
                district = "Erding / Freising"
            ),
            Station(
                id = "s_odeonsplatz",
                name = "Odeonsplatz",
                lines = listOf("U3", "U4", "U5", "U6"),
                latitude = 48.141528,
                longitude = 11.577111,
                hasElevator = false,
                hasEscalator = true,
                isBarrierFree = false,
                hasBikeStorage = false,
                district = "Altstadt-Lehel"
            )
        )
    }

    suspend fun fetchRoutes(): List<Route> {
        delay(200)
        return listOf(
            Route("u1", "U1", TransportMode.U_BAHN, "#DA291C", "Olympia-Einkaufszentrum", "Mangfallplatz", "Normalbetrieb"),
            Route("u2", "U2", TransportMode.U_BAHN, "#939598", "Feldmoching", "Messestadt Ost", "Normalbetrieb"),
            Route("u3", "U3", TransportMode.U_BAHN, "#ED6B22", "Moosach", "Fürstenried West", "Normalbetrieb"),
            Route("u4", "U4", TransportMode.U_BAHN, "#008080", "Westendstraße", "Arabellapark", "Normalbetrieb"),
            Route("u5", "U5", TransportMode.U_BAHN, "#A95221", "Laimer Platz", "Neuperlach Süd", "Normalbetrieb"),
            Route("u6", "U6", TransportMode.U_BAHN, "#007A3D", "Klinikum Großhadern", "Garching-Forschungszentrum", "Einschränkungen"),
            Route("u7", "U7", TransportMode.U_BAHN, "#00539F", "Westfriedhof", "Neuperlach Zentrum", "Normalbetrieb"),
            Route("u8", "U8", TransportMode.U_BAHN, "#101820", "Olympiazentrum", "Neuperlach Zentrum", "Normalbetrieb"),
            Route("s1", "S1", TransportMode.S_BAHN, "#00AEEF", "Freising / Flughafen", "München Ost", "Normalbetrieb"),
            Route("s2", "S2", TransportMode.S_BAHN, "#4CA647", "Petershausen", "Erding", "Normalbetrieb"),
            Route("s3", "S3", TransportMode.S_BAHN, "#78BE20", "Mammendorf", "Holzkirchen", "Normalbetrieb"),
            Route("s4", "S4", TransportMode.S_BAHN, "#RED", "Geltendorf", "Ebersberg", "Normalbetrieb"),
            Route("s6", "S6", TransportMode.S_BAHN, "#800080", "Tutzing", "Ebersberg", "Normalbetrieb"),
            Route("s7", "S7", TransportMode.S_BAHN, "#B22222", "Wolfratshausen", "Kreuzstraße", "Normalbetrieb"),
            Route("s8", "S8", TransportMode.S_BAHN, "#FFD700", "Herrsching", "Flughafen München", "Einschränkungen"),
            Route("t19", "Tram 19", TransportMode.TRAM, "#E60000", "Pasing", "Berg am Laim", "Normalbetrieb"),
            Route("b100", "Bus 100", TransportMode.BUS, "#003366", "Hauptbahnhof Nord", "Ostbahnhof", "Normalbetrieb")
        )
    }

    suspend fun fetchDepartures(stationId: String): List<Departure> {
        delay(250)
        return when (stationId) {
            "s_marienplatz" -> listOf(
                Departure("d1", "U6", TransportMode.U_BAHN, "Garching-Forschungszentrum", "14:42", 2, "Gleis 2", true, VehicleStatus.ON_TIME, stationId),
                Departure("d2", "U3", TransportMode.U_BAHN, "Moosach", "14:46", 6, "Gleis 1", true, VehicleStatus.ON_TIME, stationId),
                Departure("d3", "S8", TransportMode.S_BAHN, "Flughafen München", "14:50", 10, "Gleis 4", true, VehicleStatus.DELAYED, stationId),
                Departure("d4", "U6", TransportMode.U_BAHN, "Klinikum Großhadern", "14:51", 11, "Gleis 2", true, VehicleStatus.ON_TIME, stationId),
                Departure("d5", "S1", TransportMode.S_BAHN, "Freising", "14:55", 15, "Gleis 3", true, VehicleStatus.ON_TIME, stationId)
            )
            "s_hauptbahnhof" -> listOf(
                Departure("h1", "S1", TransportMode.S_BAHN, "Flughafen München", "14:44", 4, "Gleis 1", true, VehicleStatus.ON_TIME, stationId),
                Departure("h2", "U4", TransportMode.U_BAHN, "Arabellapark", "14:48", 8, "Gleis 3", true, VehicleStatus.ON_TIME, stationId),
                Departure("h3", "Tram 19", TransportMode.TRAM, "Berg am Laim", "14:52", 12, "Haltestelle Station A", true, VehicleStatus.ON_TIME, stationId),
                Departure("h4", "Bus 100", TransportMode.BUS, "Ostbahnhof", "14:55", 15, "Bussteig K", true, VehicleStatus.ON_TIME, stationId)
            )
            else -> listOf(
                Departure("x1", "U3", TransportMode.U_BAHN, "Fürstenried West", "14:45", 5, "Gleis 1", true, VehicleStatus.ON_TIME, stationId),
                Departure("x2", "U6", TransportMode.U_BAHN, "Münchner Freiheit", "14:50", 10, "Gleis 2", true, VehicleStatus.ON_TIME, stationId)
            )
        }
    }

    suspend fun fetchVehicles(): List<Vehicle> {
        delay(200)
        return listOf(
            Vehicle("v1", "u6", "U6", TransportMode.U_BAHN, 48.1371, 11.5761, 90.0, 45.0, "Garching-Forschungszentrum", VehicleStatus.ON_TIME, Instant.now().epochSecond),
            Vehicle("v2", "s8", "S8", TransportMode.S_BAHN, 48.1265, 11.6083, 180.0, 60.0, "Flughafen München", VehicleStatus.DELAYED, Instant.now().epochSecond),
            Vehicle("v3", "t19", "Tram 19", TransportMode.TRAM, 48.1402, 11.5583, 45.0, 25.0, "Berg am Laim", VehicleStatus.ON_TIME, Instant.now().epochSecond),
            Vehicle("v4", "b100", "Bus 100", TransportMode.BUS, 48.1396, 11.5649, 120.0, 30.0, "Ostbahnhof", VehicleStatus.ON_TIME, Instant.now().epochSecond)
        )
    }

    suspend fun fetchServiceAlerts(): List<ServiceAlert> {
        delay(200)
        return listOf(
            ServiceAlert(
                id = "alert_1",
                lineName = "S8",
                mode = TransportMode.S_BAHN,
                title = "Technische Störung",
                description = "Aufgrund einer Signalstörung im Bereich Ostbahnhof kommt es derzeit zu Verspätungen und vereinzelten Zugausfällen auf der Linie S8.",
                affectedRoute = "Herrsching ↔ Flughafen München",
                updateTime = "Vor 12 Minuten",
                severity = "WARNING"
            ),
            ServiceAlert(
                id = "alert_2",
                lineName = "U6",
                mode = TransportMode.U_BAHN,
                title = "Gleisbauarbeiten",
                description = "Wegen Gleisbauarbeiten zwischen Münchner Freiheit und Fröttmaning gilt ein angepasster Fahrplan im 10-Minuten-Takt.",
                affectedRoute = "Klinikum Großhadern ↔ Garching-Forschungszentrum",
                updateTime = "Vor 35 Minuten",
                severity = "INFO"
            )
        )
    }

    suspend fun searchJourneys(origin: String, destination: String, timeFilter: String): List<Journey> {
        delay(400)
        return listOf(
            Journey(
                id = "j1",
                originName = origin.ifEmpty { "Marienplatz" },
                destinationName = destination.ifEmpty { "Münchner Freiheit" },
                departureTime = "14:42",
                arrivalTime = "15:06",
                durationMinutes = 24,
                transfersCount = 0,
                walkingMinutes = 3,
                isBarrierFree = true,
                legs = listOf(
                    JourneyLeg(
                        mode = TransportMode.U_BAHN,
                        lineName = "U6",
                        originStop = origin.ifEmpty { "Marienplatz" },
                        destinationStop = destination.ifEmpty { "Münchner Freiheit" },
                        departureTime = "14:45",
                        arrivalTime = "15:03",
                        durationMinutes = 18,
                        platform = "Gleis 2",
                        intermediateStopsCount = 5
                    )
                )
            ),
            Journey(
                id = "j2",
                originName = origin.ifEmpty { "Marienplatz" },
                destinationName = destination.ifEmpty { "Münchner Freiheit" },
                departureTime = "14:46",
                arrivalTime = "15:14",
                durationMinutes = 28,
                transfersCount = 1,
                walkingMinutes = 4,
                isBarrierFree = true,
                legs = listOf(
                    JourneyLeg(
                        mode = TransportMode.S_BAHN,
                        lineName = "S1",
                        originStop = origin.ifEmpty { "Marienplatz" },
                        destinationStop = "Hauptbahnhof",
                        departureTime = "14:49",
                        arrivalTime = "14:53",
                        durationMinutes = 4,
                        platform = "Gleis 1",
                        intermediateStopsCount = 1
                    ),
                    JourneyLeg(
                        mode = TransportMode.U_BAHN,
                        lineName = "U4",
                        originStop = "Hauptbahnhof",
                        destinationStop = "Odeonsplatz",
                        departureTime = "14:58",
                        arrivalTime = "15:03",
                        durationMinutes = 5,
                        platform = "Gleis 3",
                        intermediateStopsCount = 2
                    )
                )
            )
        )
    }
}
