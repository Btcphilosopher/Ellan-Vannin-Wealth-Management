package com.example.transit.ui.sbahn

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.transit.data.remote.TransitRemoteDataSource
import com.example.transit.domain.model.Route
import com.example.transit.domain.model.TransportMode
import com.example.transit.ui.components.ModeBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SBahnScreen(
    onNavigateBack: () -> Unit
) {
    val remoteSource = remember { TransitRemoteDataSource() }
    var routes by remember { mutableStateOf<List<Route>>(emptyList()) }

    LaunchedEffect(Unit) {
        routes = remoteSource.fetchRoutes().filter { it.mode == TransportMode.S_BAHN }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Münchner S-Bahn & Stammstrecke", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Zurück")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Flughafenanbindung", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("S1 & S8 verkehren direkt zum Flughafen München (Terminal). Fahrzeit ab Marienplatz ca. 40 Min.")
                    }
                }
            }
            item {
                Text("S1 — S8 Linien", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            items(routes) { route ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ModeBadge(route.mode, route.name)
                                Text("${route.origin} ↔ ${route.destination}", fontWeight = FontWeight.Bold)
                            }
                            Text(route.status, color = if (route.status.contains("Normal")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}
