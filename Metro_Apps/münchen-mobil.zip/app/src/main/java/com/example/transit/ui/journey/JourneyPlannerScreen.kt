package com.example.transit.ui.journey

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.transit.data.remote.TransitRemoteDataSource
import com.example.transit.domain.model.Journey
import com.example.transit.ui.components.ModeBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyPlannerScreen(
    initialOrigin: String = "",
    initialDestination: String = "",
    onNavigateBack: () -> Unit
) {
    var origin by remember { mutableStateOf(initialOrigin) }
    var destination by remember { mutableStateOf(initialDestination) }
    var selectedFilter by remember { mutableStateOf("Schnellste") }
    var journeys by remember { mutableStateOf<List<Journey>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }

    val remoteSource = remember { TransitRemoteDataSource() }

    LaunchedEffect(origin, destination) {
        isLoading = true
        journeys = remoteSource.searchJourneys(origin, destination, selectedFilter)
        isLoading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Verbindung planen", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Zurück")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Inputs
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = origin,
                        onValueChange = { origin = it },
                        label = { Text("Von (Start)") },
                        leadingIcon = { Icon(Icons.Default.MyLocation, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = destination,
                        onValueChange = { destination = it },
                        label = { Text("Nach (Ziel)") },
                        leadingIcon = { Icon(Icons.Default.Place, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Abfahrt: Jetzt", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Button(onClick = {
                            // Trigger search
                        }) {
                            Text("Suchen")
                        }
                    }
                }
            }

            // Filters
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(selected = selectedFilter == "Schnellste", onClick = { selectedFilter = "Schnellste" }, label = { Text("Schnellste") })
                FilterChip(selected = selectedFilter == "Wenigste Umstiege", onClick = { selectedFilter = "Wenigste Umstiege" }, label = { Text("Wenigste Umstiege") })
                FilterChip(selected = selectedFilter == "Barrierefrei", onClick = { selectedFilter = "Barrierefrei" }, label = { Text("Barrierefrei") })
            }

            Text("VERBINDUNGEN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            if (isLoading) {
                Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(journeys) { journey ->
                        JourneyCard(journey)
                    }
                }
            }
        }
    }
}

@Composable
fun JourneyCard(journey: Journey) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${journey.departureTime} — ${journey.arrivalTime}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${journey.durationMinutes} Min.", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${journey.transfersCount} Umstiege", style = MaterialTheme.typography.bodyMedium)
                Text("•", style = MaterialTheme.typography.bodyMedium)
                Text("${journey.walkingMinutes} Min. Fußweg", style = MaterialTheme.typography.bodyMedium)
                if (journey.isBarrierFree) {
                    Text("•", style = MaterialTheme.typography.bodyMedium)
                    Text("Barrierefrei", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                }
            }
            Divider()
            journey.legs.forEach { leg ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ModeBadge(leg.mode, leg.lineName)
                        Column {
                            Text("${leg.originStop} → ${leg.destinationStop}", fontWeight = FontWeight.SemiBold)
                            Text("Abfahrt ${leg.departureTime} • ${leg.platform ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
