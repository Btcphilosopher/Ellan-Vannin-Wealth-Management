package com.example.transit.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val linesCsv: String,
    val latitude: Double,
    val longitude: Double,
    val hasElevator: Boolean,
    val hasEscalator: Boolean,
    val isBarrierFree: Boolean,
    val hasBikeStorage: Boolean,
    val district: String
)

@Entity(tableName = "routes")
data class RouteEntity(
    @PrimaryKey val id: String,
    val name: String,
    val mode: String,
    val colorHex: String,
    val origin: String,
    val destination: String,
    val status: String
)

@Entity(tableName = "favourites")
data class FavoriteEntity(
    @PrimaryKey val id: String,
    val type: String,
    val title: String,
    val subtitle: String,
    val details: String
)

@Entity(tableName = "recent_searches")
data class RecentSearchEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val queryText: String,
    val timestamp: Long = System.currentTimeMillis()
)
