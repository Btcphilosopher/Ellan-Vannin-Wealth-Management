package com.example.transit.ui.theme

import androidx.compose.ui.graphics.Color

val MunichBlue = Color(0xFF003366)
val MunichBlueDark = Color(0xFF002244)
val MunichBlueLight = Color(0xFF1E5B94)
val MunichOrange = Color(0xFFED6B22)
val MunichGreenUBahn = Color(0xFF007A3D)
val MunichRedSbahn = Color(0xFF00AEEF)
val MunichBackgroundLight = Color(0xFFF8F9FA)
val MunichSurfaceLight = Color(0xFFFFFFFF)
val MunichOnSurfaceLight = Color(0xFF1A1C1E)

val MunichBackgroundDark = Color(0xFF111315)
val MunichSurfaceDark = Color(0xFF1A1C1E)
val MunichOnSurfaceDark = Color(0xFFE2E2E6)

val UBahnRed = Color(0xFFDA291C)
val SBahnBlue = Color(0xFF00AEEF)
val TramRed = Color(0xFFE60000)
val BusBlue = Color(0xFF003366)
