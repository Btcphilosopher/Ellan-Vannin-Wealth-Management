package com.example.transit.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [StationEntity::class, RouteEntity::class, FavoriteEntity::class, RecentSearchEntity::class],
    version = 1,
    exportSchema = false
)
abstract class TransitDatabase : RoomDatabase() {
    abstract fun transitDao(): TransitDao

    companion object {
        @Volatile
        private var INSTANCE: TransitDatabase? = null

        fun getDatabase(context: Context): TransitDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TransitDatabase::class.java,
                    "munich_transit_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
