package com.example.transit.ui.map

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.transit.domain.model.TransportMode
import com.example.transit.ui.components.ModeBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkMapScreen(
    onNavigateToStation: (String) -> Unit
) {
    var isSchematic by remember { mutableStateOf(true) }
    var selectedStation by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Münchner Netzplan", fontWeight = FontWeight.Bold) },
                actions = {
                    SingleChoiceSegmentedButtonRow {
                        SegmentedButton(
                            selected = isSchematic,
                            onClick = { isSchematic = true },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                        ) {
                            Text("Netzplan")
                        }
                        SegmentedButton(
                            selected = !isSchematic,
                            onClick = { isSchematic = false },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                        ) {
                            Text("Karte")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Schematic Map Canvas
            Canvas(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                val w = size.width
                val h = size.height

                // Draw U6 line (Green)
                drawLine(
                    color = Color(0xFF007A3D),
                    start = Offset(w * 0.2f, h * 0.2f),
                    end = Offset(w * 0.8f, h * 0.8f),
                    strokeWidth = 12f,
                    cap = StrokeCap.Round
                )
                // Draw S-Bahn trunk line (Blue)
                drawLine(
                    color = Color(0xFF00AEEF),
                    start = Offset(w * 0.1f, h * 0.5f),
                    end = Offset(w * 0.9f, h * 0.5f),
                    strokeWidth = 12f,
                    cap = StrokeCap.Round
                )
                // Draw U3 line (Orange)
                drawLine(
                    color = Color(0xFFED6B22),
                    start = Offset(w * 0.5f, h * 0.1f),
                    end = Offset(w * 0.5f, h * 0.9f),
                    strokeWidth = 12f,
                    cap = StrokeCap.Round
                )
            }

            // Station clickable markers overlay
            Box(modifier = Modifier.fillMaxSize()) {
                // Marienplatz Marker (Center)
                ElevatedButton(
                    onClick = { selectedStation = "s_marienplatz" },
                    modifier = Modifier.align(Alignment.Center)
                ) {
                    Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Marienplatz", fontWeight = FontWeight.Bold)
                }

                // Hauptbahnhof Marker
                OutlinedButton(
                    onClick = { selectedStation = "s_hauptbahnhof" },
                    modifier = Modifier.align(Alignment.CenterStart).offset(x = 40.dp, y = (-40).dp)
                ) {
                    Text("Hauptbahnhof")
                }

                // Münchner Freiheit Marker
                OutlinedButton(
                    onClick = { selectedStation = "s_muenchener_freiheit" },
                    modifier = Modifier.align(Alignment.TopCenter).offset(y = 120.dp)
                ) {
                    Text("Münchner Freiheit")
                }

                // Flughafen Marker
                OutlinedButton(
                    onClick = { selectedStation = "s_flughafen" },
                    modifier = Modifier.align(Alignment.TopEnd).offset(x = (-20).dp, y = 40.dp)
                ) {
                    Text("Flughafen München")
                }
            }

            // Station Bottom Sheet
            if (selectedStation != null) {
                ModalBottomSheet(
                    onDismissRequest = { selectedStation = null }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = when (selectedStation) {
                                "s_marienplatz" -> "Marienplatz"
                                "s_hauptbahnhof" -> "München Hauptbahnhof"
                                "s_muenchener_freiheit" -> "Münchner Freiheit"
                                "s_flughafen" -> "Flughafen München"
                                else -> "Station"
                            },
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ModeBadge(TransportMode.U_BAHN, "U3")
                            ModeBadge(TransportMode.U_BAHN, "U6")
                            ModeBadge(TransportMode.S_BAHN, "S1-S8")
                        }
                        Text("Barrierefrei: Aufzug und Rolltreppe vorhanden.", style = MaterialTheme.typography.bodyMedium)
                        Button(
                            onClick = {
                                val id = selectedStation ?: "s_marienplatz"
                                selectedStation = null
                                onNavigateToStation(id)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Zur Stationsansicht & Abfahrten")
                        }
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}
