package com.example.transit.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.transit.domain.model.*
import com.example.transit.ui.components.ModeBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToJourney: (String, String) -> Unit,
    onNavigateToDepartures: (String) -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToUBahn: () -> Unit,
    onNavigateToSBahn: () -> Unit,
    onNavigateToTram: () -> Unit,
    onNavigateToBus: () -> Unit,
    onNavigateToDisruptions: () -> Unit,
    onNavigateToStation: (String) -> Unit
) {
    var originText by remember { mutableStateOf("Marienplatz") }
    var destinationText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("MÜNCHEN", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Hauptbahnhof / Innenstadt", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToDisruptions) {
                        BadgedBox(badge = { Badge { Text("1") } }) {
                            Icon(Icons.Default.Warning, contentDescription = "Störungen")
                        }
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                // Journey Search Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Wohin möchten Sie?", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        
                        OutlinedTextField(
                            value = originText,
                            onValueChange = { originText = it },
                            label = { Text("Von (Start)") },
                            leadingIcon = { Icon(Icons.Default.MyLocation, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = destinationText,
                            onValueChange = { destinationText = it },
                            label = { Text("Nach (Ziel)") },
                            leadingIcon = { Icon(Icons.Default.Place, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onNavigateToJourney(originText, destinationText) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Search, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verbindung suchen")
                            }
                            OutlinedButton(onClick = { onNavigateToDepartures("s_marienplatz") }) {
                                Text("Abfahrten")
                            }
                        }
                    }
                }
            }

            // Transport Modes Quick Access
            item {
                Text("VERKEHRSMITTEL", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    AssistChip(onClick = onNavigateToUBahn, label = { Text("U-Bahn") }, leadingIcon = { Icon(Icons.Default.DirectionsSubway, contentDescription = null) })
                    AssistChip(onClick = onNavigateToSBahn, label = { Text("S-Bahn") }, leadingIcon = { Icon(Icons.Default.Train, contentDescription = null) })
                    AssistChip(onClick = onNavigateToTram, label = { Text("Tram") }, leadingIcon = { Icon(Icons.Default.Tram, contentDescription = null) })
                    AssistChip(onClick = onNavigateToBus, label = { Text("Bus") }, leadingIcon = { Icon(Icons.Default.DirectionsBus, contentDescription = null) })
                }
            }

            // In der Nähe Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("IN DER NÄHE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { onNavigateToStation("s_marienplatz") }) {
                        Text("Alle Abfahrten")
                    }
                }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToStation("s_marienplatz") },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Marienplatz", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Row {
                                ModeBadge(TransportMode.U_BAHN, "U3")
                                ModeBadge(TransportMode.U_BAHN, "U6")
                                ModeBadge(TransportMode.S_BAHN, "S1-S8")
                            }
                        }
                        Divider()
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ModeBadge(TransportMode.U_BAHN, "U6")
                                Text("→ Garching-Forschungszentrum")
                            }
                            Text("4 Min.", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ModeBadge(TransportMode.U_BAHN, "U3")
                                Text("→ Moosach")
                            }
                            Text("7 Min.", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Verkehrslage
            item {
                Text("VERKEHRSLAGE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        TrafficStatusRow("U-Bahn", "Normalbetrieb", Color(0xFF007A3D))
                        TrafficStatusRow("S-Bahn", "Einschränkungen (S8)", Color(0xFFED6B22))
                        TrafficStatusRow("Tram", "Normalbetrieb", Color(0xFFE60000))
                        TrafficStatusRow("Bus", "Normalbetrieb", Color(0xFF003366))
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun TrafficStatusRow(mode: String, status: String, indicatorColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(indicatorColor)
            )
            Text(mode, fontWeight = FontWeight.SemiBold)
        }
        Text(status, style = MaterialTheme.typography.bodyMedium, color = if (status.contains("Normal")) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error)
    }
}
