package com.example.core.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        StationEntity::class,
        TicketEntity::class,
        DisruptionEntity::class,
        FavouriteStationEntity::class,
        FavouriteJourneyEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MetroDatabase : RoomDatabase() {
    abstract fun metroDao(): MetroDao
}
