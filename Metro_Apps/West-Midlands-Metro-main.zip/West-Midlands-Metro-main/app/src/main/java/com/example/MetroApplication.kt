package com.example

import android.app.Application
import androidx.room.Room
import com.example.core.database.MetroDatabase
import com.example.core.repository.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class MetroApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob())

    lateinit var database: MetroDatabase
        private set

    lateinit var stationRepository: StationRepository
        private set

    lateinit var departureRepository: DepartureRepository
        private set

    lateinit var journeyRepository: JourneyRepository
        private set

    lateinit var ticketRepository: TicketRepository
        private set

    lateinit var disruptionRepository: DisruptionRepository
        private set

    lateinit var vehicleRepository: VehicleRepository
        private set

    lateinit var fareRepository: FareRepository
        private set

    lateinit var metroRepository: MetroRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Initialize Room Database
        database = Room.databaseBuilder(
            applicationContext,
            MetroDatabase::class.java,
            "west_midlands_metro_db"
        )
        .fallbackToDestructiveMigration()
        .build()

        val metroDao = database.metroDao()

        // Initialize Repositories
        stationRepository = StationRepositoryImpl(metroDao, applicationScope)
        departureRepository = DepartureRepositoryImpl()
        journeyRepository = JourneyRepositoryImpl()
        ticketRepository = TicketRepositoryImpl(metroDao)
        disruptionRepository = DisruptionRepositoryImpl(metroDao, applicationScope)
        vehicleRepository = VehicleRepositoryImpl()
        fareRepository = FareRepositoryImpl()
        metroRepository = MetroRepositoryImpl(metroDao)
    }

    companion object {
        lateinit var instance: MetroApplication
            private set
    }
}
