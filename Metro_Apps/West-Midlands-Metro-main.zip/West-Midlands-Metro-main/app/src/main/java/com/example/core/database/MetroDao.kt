package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {

    // Stations
    @Query("SELECT * FROM stations ORDER BY name ASC")
    fun getAllStations(): Flow<List<StationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)

    @Query("SELECT * FROM stations WHERE id = :id")
    suspend fun getStationById(id: String): StationEntity?

    // Tickets
    @Query("SELECT * FROM tickets ORDER BY purchaseTime DESC")
    fun getAllTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Query("UPDATE tickets SET status = :status WHERE id = :id")
    suspend fun updateTicketStatus(id: String, status: String)

    // Disruptions
    @Query("SELECT * FROM disruptions ORDER BY timestamp DESC")
    fun getAllDisruptions(): Flow<List<DisruptionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDisruptions(disruptions: List<DisruptionEntity>)

    @Query("DELETE FROM disruptions")
    suspend fun clearDisruptions()

    // Favourite Stations
    @Query("SELECT * FROM favourite_stations")
    fun getFavouriteStations(): Flow<List<FavouriteStationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavouriteStation(fav: FavouriteStationEntity)

    @Query("DELETE FROM favourite_stations WHERE stationId = :stationId")
    suspend fun deleteFavouriteStation(stationId: String)

    // Favourite Journeys
    @Query("SELECT * FROM favourite_journeys")
    fun getFavouriteJourneys(): Flow<List<FavouriteJourneyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavouriteJourney(fav: FavouriteJourneyEntity)

    @Query("DELETE FROM favourite_journeys WHERE id = :id")
    suspend fun deleteFavouriteJourney(id: String)
}
