package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Ticket
import com.example.core.model.TicketStatus
import com.example.core.repository.TransitData
import com.example.ui.MetroViewModel
import com.example.ui.theme.MetroGold
import com.example.ui.theme.MetroIndigo
import com.example.ui.theme.MetroPink
import com.example.ui.theme.MetroTeal
import com.example.ui.theme.SoftPink
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TicketsScreen(
    viewModel: MetroViewModel
) {
    val tickets by viewModel.tickets.collectAsState()
    val stations by viewModel.allStations.collectAsState()
    val originId by viewModel.originId.collectAsState()
    val destinationId by viewModel.destinationId.collectAsState()

    var isConcession by remember { mutableStateOf(false) }
    var selectedTicketForDetails by remember { mutableStateOf<Ticket?>(null) }
    var showPurchasedToast by remember { mutableStateOf(false) }

    var selectedTab by remember { mutableStateOf(0) } // 0 = Wallet, 1 = Store

    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.UK)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("tickets_screen")
    ) {
        // --- TICKETING TAB SELECTOR ---
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MetroPink
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("TICKET WALLET (${tickets.size})", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("BUY TICKETS", fontWeight = FontWeight.Bold) }
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedTab == 0) {
                // ==========================================
                // WALLET VIEWS
                // ==========================================
                if (tickets.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ConfirmationNumber,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier.size(64.dp)
                            )
                            Text(
                                text = "Your ticket wallet is empty",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MetroIndigo
                            )
                            Text(
                                text = "Choose a transit product under the 'Buy Tickets' tab to start traveling.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                            Button(
                                onClick = { selectedTab = 1 },
                                colors = ButtonDefaults.buttonColors(containerColor = MetroPink)
                            ) {
                                Text("GO TO TICKET STORE")
                            }
                        }
                    }
                } else {
                    item {
                        Text(
                            text = "MY DIGITAL TICKETS",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = MetroIndigo
                        )
                    }

                    items(tickets) { ticket ->
                        TicketWalletItem(
                            ticket = ticket,
                            onShowTicket = { selectedTicketForDetails = ticket }
                        )
                    }
                }
            } else {
                // ==========================================
                // TRANSIT STORE VIEWS
                // ==========================================
                item {
                    Text(
                        text = "WEST MIDLANDS METRO PRODUCTS",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = MetroIndigo
                    )
                }

                // Passenger Category Selector
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.People, contentDescription = null, tint = MetroPink)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (isConcession) "Concession Rate (Senior/Student)" else "Standard Adult Rate",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MetroIndigo
                                    )
                                    Text(
                                        text = if (isConcession) "Requires proof of concession ID on-board" else "Standard network fare limits",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = isConcession,
                                onCheckedChange = { isConcession = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = MetroPink, checkedTrackColor = SoftPink)
                            )
                        }
                    }
                }

                // List Available Stores products
                items(TransitData.TicketProducts) { product ->
                    val rawPrice = product.second
                    val finalPrice = if (isConcession) rawPrice * 0.5 else rawPrice
                    val finalTitle = if (isConcession) "${product.first} (Concession)" else product.first

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(MetroPink.copy(alpha = 0.1f), shape = RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.CreditCard, contentDescription = null, tint = MetroPink)
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = finalTitle,
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                    color = MetroIndigo
                                )
                                Text(
                                    text = "Metro Network • All Zones",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "£${String.format("%.2f", finalPrice)}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                                    color = MetroIndigo
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Button(
                                    onClick = {
                                        viewModel.purchaseTicket(
                                            type = if (product.first.contains("Single")) "Single" else "Day",
                                            title = finalTitle,
                                            price = finalPrice
                                        )
                                        showPurchasedToast = true
                                        selectedTab = 0 // return to wallet
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MetroPink),
                                    shape = RoundedCornerShape(14.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)
                                ) {
                                    Text("BUY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- PURCHASED NOTIFICATION TOAST BAR ---
    if (showPurchasedToast) {
        LaunchedEffect(Unit) {
            delay(3000)
            showPurchasedToast = false
        }
        Snackbar(
            modifier = Modifier.padding(16.dp),
            action = {
                TextButton(onClick = { showPurchasedToast = false }) {
                    Text("DISMISS", color = MetroGold)
                }
            }
        ) {
            Text("Ticket purchased successfully! Saved to Wallet.")
        }
    }

    // --- DIGITAL TICKET INSPECTION DIALOG ---
    selectedTicketForDetails?.let { ticket ->
        AlertDialog(
            onDismissRequest = { selectedTicketForDetails = null },
            title = null,
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "WEST MIDLANDS METRO",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp
                        ),
                        color = MetroPink
                    )
                    Text(
                        text = "BOARDING PASS",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                        color = MetroIndigo
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // QR Code visualizer mockup
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .border(2.dp, MetroIndigo, RoundedCornerShape(8.dp))
                            .background(Color.White)
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Drawing a stylized QR Code grid
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            repeat(10) { row ->
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    repeat(10) { col ->
                                        val isFilled = (row + col) % 3 != 0 && (row * col) % 4 != 1
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .background(if (isFilled) MetroIndigo else Color.White)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Text(
                        text = ticket.qrCodeString,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    // Ticket validity attributes
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("TICKET TYPE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(ticket.title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MetroIndigo)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("PASSENGER", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("DEMO USER", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MetroIndigo)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("VALID ON", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(sdf.format(Date(ticket.purchaseTime)), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MetroIndigo)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("STATUS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = ticket.status.name,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (ticket.status == TicketStatus.ACTIVE) MetroTeal else MetroPink
                            )
                        }
                    }

                    // Simulated Validation button
                    if (ticket.status == TicketStatus.ACTIVE) {
                        Button(
                            onClick = {
                                viewModel.useTicket(ticket.id)
                                selectedTicketForDetails = ticket.copy(status = TicketStatus.USED)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MetroTeal)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SIMULATE INPSECTOR VALIDATION")
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MetroTeal.copy(alpha = 0.12f), shape = RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "✓ TICKET MOCK VALIDATED FOR TRAVEL",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MetroTeal
                                )
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedTicketForDetails = null }) {
                    Text("CLOSE TICKET", color = MetroPink, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun TicketWalletItem(
    ticket: Ticket,
    onShowTicket: () -> Unit
) {
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.UK)
    val color = if (ticket.status == TicketStatus.ACTIVE) MetroPink else MaterialTheme.colorScheme.outlineVariant

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onShowTicket() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(color.copy(alpha = 0.1f), shape = RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ConfirmationNumber,
                    contentDescription = null,
                    tint = color
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = ticket.title,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                    color = MetroIndigo
                )
                Text(
                    text = "Valid: ${sdf.format(Date(ticket.purchaseTime))}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Box(
                modifier = Modifier
                    .background(
                        color = if (ticket.status == TicketStatus.ACTIVE) MetroTeal.copy(alpha = 0.1f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = ticket.status.name,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (ticket.status == TicketStatus.ACTIVE) MetroTeal else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
