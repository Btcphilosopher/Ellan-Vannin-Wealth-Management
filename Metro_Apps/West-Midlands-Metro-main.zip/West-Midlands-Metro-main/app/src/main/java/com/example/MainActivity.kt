package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.MetroViewModel
import com.example.ui.screens.*
import com.example.ui.theme.WestMidlandsMetroTheme
import com.example.ui.theme.MetroPink

class MainActivity : ComponentActivity() {

    private val viewModel: MetroViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WestMidlandsMetroTheme {
                var selectedTab by remember { mutableStateOf(0) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = MetroPink
                        ) {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                label = { Text("Planner", fontWeight = FontWeight.Bold) },
                                icon = { Icon(Icons.Default.Route, contentDescription = "Journey Planner") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MetroPink,
                                    selectedTextColor = MetroPink,
                                    indicatorColor = MetroPink.copy(alpha = 0.1f)
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                label = { Text("Network Map", fontWeight = FontWeight.Bold) },
                                icon = { Icon(Icons.Default.Map, contentDescription = "Metro Live Map") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MetroPink,
                                    selectedTextColor = MetroPink,
                                    indicatorColor = MetroPink.copy(alpha = 0.1f)
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                label = { Text("Tickets", fontWeight = FontWeight.Bold) },
                                icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Wallet") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MetroPink,
                                    selectedTextColor = MetroPink,
                                    indicatorColor = MetroPink.copy(alpha = 0.1f)
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 3,
                                onClick = { selectedTab = 3 },
                                label = { Text("Alerts", fontWeight = FontWeight.Bold) },
                                icon = { Icon(Icons.Default.NotificationsActive, contentDescription = "Alerts") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MetroPink,
                                    selectedTextColor = MetroPink,
                                    indicatorColor = MetroPink.copy(alpha = 0.1f)
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 4,
                                onClick = { selectedTab = 4 },
                                label = { Text("Command", fontWeight = FontWeight.Bold) },
                                icon = { Icon(Icons.Default.Memory, contentDescription = "Command Centre") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MetroPink,
                                    selectedTextColor = MetroPink,
                                    indicatorColor = MetroPink.copy(alpha = 0.1f)
                                )
                            )
                        }
                    }
                ) { innerPadding ->
                    Surface(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        when (selectedTab) {
                            0 -> HomeScreen(
                                viewModel = viewModel,
                                onNavigateToMap = { selectedTab = 1 },
                                onNavigateToTickets = { selectedTab = 2 }
                            )
                            1 -> MapScreen(
                                viewModel = viewModel,
                                onPlanFromHere = { selectedTab = 0 }
                            )
                            2 -> TicketsScreen(viewModel = viewModel)
                            3 -> DisruptionsScreen(viewModel = viewModel)
                            4 -> CommandCentreScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
