package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.JourneyOption
import com.example.core.model.TransitStop
import com.example.core.model.TransportMode
import com.example.ui.MetroViewModel
import com.example.ui.theme.MetroGold
import com.example.ui.theme.MetroIndigo
import com.example.ui.theme.MetroPink
import com.example.ui.theme.MetroTeal
import com.example.ui.theme.SoftTeal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MetroViewModel,
    onNavigateToMap: () -> Unit,
    onNavigateToTickets: () -> Unit
) {
    val stations by viewModel.allStations.collectAsState()
    val disruptions by viewModel.disruptions.collectAsState()
    val originId by viewModel.originId.collectAsState()
    val destinationId by viewModel.destinationId.collectAsState()
    val journeyOptions by viewModel.journeyOptions.collectAsState()
    val isPlanningLoading by viewModel.isPlanningLoading.collectAsState()
    val selectedStation by viewModel.selectedStation.collectAsState()
    val stationDepartures by viewModel.stationDepartures.collectAsState()
    val favStations by viewModel.favouriteStationIds.collectAsState()

    var showOriginPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }
    var showJourneyResults by remember { mutableStateOf(false) }

    val originStation = stations.find { it.id == originId }
    val destStation = stations.find { it.id == destinationId }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- HEADER ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "WEST MIDLANDS METRO",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp
                        ),
                        color = MetroPink
                    )
                    Text(
                        text = "Good morning",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(MetroPink.copy(alpha = 0.1f), shape = CircleShape)
                        .clickable { /* Personalisation settings click */ },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, contentDescription = "Profile", tint = MetroPink)
                }
            }
        }

        // --- SERVICE STATUS BANNER ---
        item {
            val isNormal = disruptions.isEmpty()
            val statusColor = if (isNormal) MetroTeal else MetroGold
            val statusBg = if (isNormal) SoftTeal else MetroGold.copy(alpha = 0.12f)
            val statusText = if (isNormal) {
                "Normal services across network"
            } else {
                "${disruptions.size} service alerts active"
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, statusColor.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = statusBg),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(statusColor, shape = CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Service Status".uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        ),
                        color = statusColor
                    )
                    Spacer(modifier = Modifier.weight(1.0f))
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = statusColor
                    )
                }
            }
        }

        // --- JOURNEY PLANNER CARD ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp) // Updated to High Density generous rounded corners
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Where are you going?",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.5).sp
                        ),
                        color = MetroIndigo
                    )

                    // FROM STATION FIELD
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { showOriginPicker = true }
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MyLocation, contentDescription = "From", tint = MetroTeal)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "FROM",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = originStation?.name ?: "Select Origin Station",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // SWAP BUTTON ROW
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(
                            onClick = { viewModel.swapOriginAndDestination() },
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surface, shape = CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(Icons.Default.SwapVert, contentDescription = "Swap stations", tint = MetroPink)
                        }
                    }

                    // TO STATION FIELD
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { showDestPicker = true }
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PinDrop, contentDescription = "To", tint = MetroPink)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "TO",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = destStation?.name ?: "Select Destination Station",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    // PLAN BUTTON
                    Button(
                        onClick = {
                            viewModel.planJourney()
                            showJourneyResults = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("plan_journey_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MetroPink),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.DirectionsRun, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PLAN JOURNEY",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    }
                }
            }
        }

        // --- EXPANDABLE JOURNEY PLANNING RESULTS ---
        if (showJourneyResults) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "JOURNEY OPTIONS",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = MetroIndigo
                            )
                            IconButton(onClick = { showJourneyResults = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear results")
                            }
                        }

                        if (isPlanningLoading) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = MetroPink)
                            }
                        } else if (journeyOptions.isEmpty()) {
                            Text(
                                text = "No journey found. Please choose distinct stations.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 12.dp)
                            )
                        } else {
                            journeyOptions.forEach { option ->
                                JourneyOptionItem(option = option, onBuyTicket = onNavigateToTickets)
                                Spacer(modifier = Modifier.height(10.dp))
                            }
                        }
                    }
                }
            }
        }

        // --- FAVORITES SECTIONS (🏠 Home / 💼 Work) ---
        item {
            Text(
                text = "MY FAVOURITES",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                ),
                color = MetroIndigo
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val destinations = listOf(
                    Triple("Home", "EDG_VIL", Icons.Default.Home),
                    Triple("Work", "JWL_QTR", Icons.Default.Work),
                    Triple("Wolverhampton", "WOL_STN", Icons.Default.Star)
                )

                destinations.forEach { dest ->
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                viewModel.setDestination(dest.second)
                                showJourneyResults = true
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(dest.third, contentDescription = null, tint = MetroPink)
                            Text(
                                text = dest.first,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = MetroIndigo
                            )
                            Text(
                                text = "Tap to plan",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // --- NEXT DEPARTURES PANEL (Bull Street default) ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp), // High Density generous curves
                colors = CardDefaults.cardColors(containerColor = MetroIndigo), // Elegant dark infrastructure palette
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "LIVE DEPARTURES",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = Color(0xFF939094)
                            )
                            Text(
                                text = selectedStation?.name ?: "Bull Street Station",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }

                        // LIVE pulsating badge
                        Box(
                            modifier = Modifier
                                .background(MetroPink.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp))
                                .border(1.dp, MetroPink, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "LIVE",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MetroPink
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (stationDepartures.isEmpty()) {
                        Text(
                            text = "No departures active at this time.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF939094),
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    } else {
                        stationDepartures.take(4).forEach { departure ->
                            val isDue = departure.status == com.example.core.model.DepartureStatus.DUE
                            val timerText = if (isDue) "Due" else "${departure.dueMinutes}"
                            val timerColor = if (isDue) MetroPink else Color.White

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(if (isDue) MetroPink else Color.White.copy(alpha = 0.3f), shape = CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = departure.destinationName,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = if (isDue) Color.White else Color(0xFFC4C6D0)
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = timerText,
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                        color = timerColor
                                    )
                                    if (!isDue) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "min",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF939094)
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onNavigateToMap,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MetroPink),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("CHANGE STATION IN MAP", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
    }

    // --- DIALOGS FOR STATION PICKERS ---
    if (showOriginPicker) {
        StationPickerDialog(
            title = "Choose Origin Station",
            stations = stations,
            onDismiss = { showOriginPicker = false },
            onSelect = {
                viewModel.setOrigin(it)
                showOriginPicker = false
            }
        )
    }

    if (showDestPicker) {
        StationPickerDialog(
            title = "Choose Destination Station",
            stations = stations,
            onDismiss = { showDestPicker = false },
            onSelect = {
                viewModel.setDestination(it)
                showDestPicker = false
            }
        )
    }
}

@Composable
fun DepartureRow(departure: com.example.core.model.Departure) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Mode Icon
            val (icon, color) = when (departure.transportMode) {
                TransportMode.METRO -> Pair(Icons.Default.Tram, MetroPink)
                TransportMode.RAIL -> Pair(Icons.Default.Train, MetroIndigo)
                TransportMode.BUS -> Pair(Icons.Default.DirectionsBus, MetroTeal)
                else -> Pair(Icons.Default.DirectionsWalk, MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = 0.1f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = departure.destinationName,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = MetroIndigo
                )
                Text(
                    text = "${departure.transportMode.name} • Platform ${departure.platform}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Due Timer
            val isDue = departure.status == com.example.core.model.DepartureStatus.DUE
            val timerText = if (isDue) "Due" else "${departure.dueMinutes} min"
            val timerColor = if (isDue) MetroPink else MetroIndigo

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = timerText,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.ExtraBold),
                    color = timerColor
                )
                if (departure.status == com.example.core.model.DepartureStatus.DELAYED) {
                    Text(
                        text = "Delayed (${departure.delayMinutes}m)",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MetroGold
                    )
                }
            }
        }
    }
}

@Composable
fun JourneyOptionItem(
    option: JourneyOption,
    onBuyTicket: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Tag Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            color = when (option.tag) {
                                "FASTEST" -> MetroPink.copy(alpha = 0.1f)
                                "LOW WALKING" -> MetroTeal.copy(alpha = 0.1f)
                                else -> MetroIndigo.copy(alpha = 0.1f)
                            },
                            shape = RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = option.tag,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = when (option.tag) {
                            "FASTEST" -> MetroPink
                            "LOW WALKING" -> MetroTeal
                            else -> MetroIndigo
                        }
                    )
                }

                Text(
                    text = "£${String.format("%.2f", option.totalFare)}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = MetroIndigo
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Legs visualization
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                option.legs.forEachIndexed { index, leg ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val icon = when (leg.mode) {
                            TransportMode.METRO -> Icons.Default.Tram
                            TransportMode.RAIL -> Icons.Default.Train
                            TransportMode.BUS -> Icons.Default.DirectionsBus
                            TransportMode.WALK -> Icons.Default.DirectionsWalk
                            else -> Icons.Default.Star
                        }
                        Icon(
                            icon,
                            contentDescription = leg.mode.name,
                            tint = if (leg.mode == TransportMode.METRO) MetroPink else MetroIndigo,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${leg.durationMinutes}m",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    if (index < option.legs.size - 1) {
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1.0f))

                Text(
                    text = "${option.totalDurationMinutes} min total",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = MetroIndigo
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Detailed first instruction
            option.legs.firstOrNull()?.let { leg ->
                Text(
                    text = "Depart at ${leg.departureTime}: ${leg.instruction}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick purchase shortcut
            OutlinedButton(
                onClick = onBuyTicket,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MetroPink)
            ) {
                Text("BUY FARE / TICKETS")
            }
        }
    }
}

@Composable
fun StationPickerDialog(
    title: String,
    stations: List<TransitStop>,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = title, fontWeight = FontWeight.Bold) },
        text = {
            Box(modifier = Modifier.height(300.dp)) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(stations) { station ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(station.id) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = station.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Zone ${station.zone}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MetroPink
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
