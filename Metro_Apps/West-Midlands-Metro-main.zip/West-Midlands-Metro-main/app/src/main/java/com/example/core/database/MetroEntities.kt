package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val zone: Int,
    val isStepFree: Boolean,
    val hasCycleFacilities: Boolean,
    val hasParking: Boolean,
    val connections: String, // Comma-separated list of TransportMode names
    val platformInfo: String
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val type: String,
    val price: Double,
    val zones: String,
    val purchaseTime: Long,
    val expiryTime: Long,
    val status: String, // ACTIVE, USED, EXPIRED
    val qrCodeString: String
)

@Entity(tableName = "disruptions")
data class DisruptionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val affectedLines: String, // Comma-separated
    val level: String, // NORMAL, MINOR, MAJOR
    val alternativeInstructions: String,
    val timestamp: Long
)

@Entity(tableName = "favourite_stations")
data class FavouriteStationEntity(
    @PrimaryKey val stationId: String,
    val addedTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "favourite_journeys")
data class FavouriteJourneyEntity(
    @PrimaryKey val id: String, // originId + "_" + destinationId
    val originId: String,
    val originName: String,
    val destinationId: String,
    val destinationName: String,
    val addedTime: Long = System.currentTimeMillis()
)
