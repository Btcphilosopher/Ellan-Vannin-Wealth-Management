package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.MetroApplication
import com.example.core.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MetroViewModel : ViewModel() {

    private val app = MetroApplication.instance

    // --- Core Repositories ---
    private val stationRepo = app.stationRepository
    private val departureRepo = app.departureRepository
    private val journeyRepo = app.journeyRepository
    private val ticketRepo = app.ticketRepository
    private val disruptionRepo = app.disruptionRepository
    private val vehicleRepo = app.vehicleRepository
    private val fareRepo = app.fareRepository
    private val metroRepo = app.metroRepository

    // --- State Streams ---
    val allStations: StateFlow<List<TransitStop>> = stationRepo.getStations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val disruptions: StateFlow<List<Disruption>> = disruptionRepo.getDisruptions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vehicles: StateFlow<List<Vehicle>> = vehicleRepo.getVehicles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<Ticket>> = ticketRepo.getTickets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favouriteStationIds: StateFlow<List<String>> = metroRepo.getFavouriteStations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favouriteJourneys: StateFlow<List<com.example.core.database.FavouriteJourneyEntity>> = metroRepo.getFavouriteJourneys()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Selected Station & Departures State ---
    private val _selectedStationId = MutableStateFlow("BULL_ST")
    val selectedStationId: StateFlow<String> = _selectedStationId.asStateFlow()

    val selectedStation: StateFlow<TransitStop?> = combine(allStations, _selectedStationId) { stations, id ->
        stations.find { it.id == id } ?: stations.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val stationDepartures: StateFlow<List<Departure>> = _selectedStationId
        .flatMapLatest { id -> departureRepo.getDepartures(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Journey Planner State ---
    private val _originId = MutableStateFlow("BULL_ST")
    val originId: StateFlow<String> = _originId.asStateFlow()

    private val _destinationId = MutableStateFlow("EDG_VIL")
    val destinationId: StateFlow<String> = _destinationId.asStateFlow()

    private val _journeyOptions = MutableStateFlow<List<JourneyOption>>(emptyList())
    val journeyOptions: StateFlow<List<JourneyOption>> = _journeyOptions.asStateFlow()

    private val _accessibilityRequired = MutableStateFlow(false)
    val accessibilityRequired: StateFlow<Boolean> = _accessibilityRequired.asStateFlow()

    private val _isPlanningLoading = MutableStateFlow(false)
    val isPlanningLoading: StateFlow<Boolean> = _isPlanningLoading.asStateFlow()

    // --- Command Centre Stats ---
    val commandCentreMetrics = combine(vehicles, disruptions) { vList, dList ->
        val activeCount = vList.size
        val hasMajorDisruption = dList.any { it.level == DisruptionLevel.MAJOR }
        val operatingPercentage = if (hasMajorDisruption) "85%" else "98%"
        val networkLoad = if (hasMajorDisruption) "84%" else "68%"
        val paxDemand = if (hasMajorDisruption) "HIGH (Delayed)" else "NORMAL"
        CommandMetrics(
            operatingPercentage = operatingPercentage,
            activeVehicles = activeCount,
            networkLoad = networkLoad,
            passengerDemand = paxDemand,
            disruptionsCount = dList.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CommandMetrics())

    init {
        // Trigger initial plan
        planJourney()
    }

    // --- UI Interactions / Intent Actions ---

    fun selectStation(id: String) {
        _selectedStationId.value = id
    }

    fun setOrigin(id: String) {
        _originId.value = id
        planJourney()
    }

    fun setDestination(id: String) {
        _destinationId.value = id
        planJourney()
    }

    fun toggleAccessibility(required: Boolean) {
        _accessibilityRequired.value = required
        planJourney()
    }

    fun swapOriginAndDestination() {
        val temp = _originId.value
        _originId.value = _destinationId.value
        _destinationId.value = temp
        planJourney()
    }

    fun planJourney() {
        viewModelScope.launch(Dispatchers.Default) {
            _isPlanningLoading.value = true
            // Simulate brief calculation latency
            kotlinx.coroutines.delay(400)
            val planned = journeyRepo.planJourney(
                originId = _originId.value,
                destinationId = _destinationId.value,
                accessibilityRequired = _accessibilityRequired.value
            )
            _journeyOptions.value = planned
            _isPlanningLoading.value = false
        }
    }

    fun toggleStationFavourite(stationId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val favourites = favouriteStationIds.value
            if (favourites.contains(stationId)) {
                metroRepo.removeFavouriteStation(stationId)
            } else {
                metroRepo.addFavouriteStation(stationId)
            }
        }
    }

    fun toggleJourneyFavourite(origin: TransitStop, destination: TransitStop) {
        viewModelScope.launch(Dispatchers.IO) {
            val favs = favouriteJourneys.value
            val id = "${origin.id}_${destination.id}"
            val existing = favs.find { it.id == id }
            if (existing != null) {
                metroRepo.removeFavouriteJourney(id)
            } else {
                metroRepo.addFavouriteJourney(origin.id, origin.name, destination.id, destination.name)
            }
        }
    }

    fun purchaseTicket(type: String, title: String, price: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val expiry = now + when (type) {
                "Single" -> 3 * 3600 * 1000 // 3 hours
                "Return" -> 24 * 3600 * 1000 // 24 hours
                "Day" -> 24 * 3600 * 1000
                "Weekly" -> 7 * 24 * 3600 * 1000
                else -> 30 * 24 * 3600 * 1000
            }
            val newTicket = Ticket(
                title = title,
                description = "Valid across $type Zones",
                type = type,
                price = price,
                purchaseTime = now,
                expiryTime = expiry,
                status = TicketStatus.ACTIVE
            )
            ticketRepo.purchaseTicket(newTicket)
        }
    }

    fun useTicket(ticketId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            ticketRepo.useTicket(ticketId)
        }
    }
}

data class CommandMetrics(
    val operatingPercentage: String = "98%",
    val activeVehicles: Int = 0,
    val networkLoad: String = "72%",
    val passengerDemand: String = "NORMAL",
    val disruptionsCount: Int = 0
)
