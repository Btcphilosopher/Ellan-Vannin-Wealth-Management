package com.example.core.model

import java.util.UUID

enum class TransportMode {
    METRO,
    BUS,
    RAIL,
    WALK,
    CYCLE
}

data class TransitStop(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val zone: Int,
    val isStepFree: Boolean = true,
    val hasCycleFacilities: Boolean = true,
    val hasParking: Boolean = false,
    val connections: List<TransportMode> = listOf(TransportMode.METRO),
    val platformInfo: String = "Platform 1 & 2"
)

data class Route(
    val id: String,
    val name: String,
    val color: String, // Hex color representing the route
    val stops: List<String>, // List of Station IDs in order
    val isActive: Boolean = true
)

enum class DepartureStatus {
    DUE,
    MINUTES,
    SCHEDULED,
    DELAYED,
    CANCELLED
}

data class Departure(
    val id: String = UUID.randomUUID().toString(),
    val stationId: String,
    val destinationName: String,
    val dueMinutes: Int,
    val status: DepartureStatus = DepartureStatus.MINUTES,
    val platform: String = "1",
    val delayMinutes: Int = 0,
    val transportMode: TransportMode = TransportMode.METRO
)

data class Vehicle(
    val id: String,
    val routeId: String,
    val latitude: Double,
    val longitude: Double,
    val nextStopName: String,
    val currentSpeedKmh: Int,
    val heading: Float,
    val loadFactor: Double, // 0.0 to 1.0 representing how full the vehicle is
    val status: String = "In Transit"
)

enum class DisruptionLevel {
    NORMAL,
    MINOR,
    MAJOR
}

data class Disruption(
    val id: String,
    val title: String,
    val description: String,
    val affectedLines: List<String>,
    val level: DisruptionLevel,
    val alternativeInstructions: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class Fare(
    val id: String,
    val originStationId: String,
    val destinationStationId: String,
    val ticketTypeName: String,
    val price: Double
)

enum class TicketStatus {
    ACTIVE,
    USED,
    EXPIRED
}

data class Ticket(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val type: String, // "Single", "Return", "Day", "Weekly"
    val price: Double,
    val zones: String = "Metro Network",
    val purchaseTime: Long,
    val expiryTime: Long,
    val status: TicketStatus = TicketStatus.ACTIVE,
    val qrCodeString: String = "WMMETRO-${UUID.randomUUID().toString().take(8).uppercase()}"
)

// Journey Planner models
data class JourneyLeg(
    val mode: TransportMode,
    val lineName: String,
    val fromStopName: String,
    val toStopName: String,
    val durationMinutes: Int,
    val departureTime: String,
    val arrivalTime: String,
    val instruction: String,
    val intermediateStopsCount: Int = 0
)

data class JourneyOption(
    val id: String = UUID.randomUUID().toString(),
    val legs: List<JourneyLeg>,
    val totalDurationMinutes: Int,
    val totalFare: Double,
    val tag: String = "" // "FASTEST", "FEWEST CHANGES", "LOW WALKING"
)
