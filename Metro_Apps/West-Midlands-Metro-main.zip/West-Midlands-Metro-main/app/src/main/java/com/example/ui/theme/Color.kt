package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// "High Density" Cohesive Design Theme Palette
val MetroPink = Color(0xFFD0006F)     // Core brand magenta-pink
val MetroIndigo = Color(0xFF1C1B1F)   // Dark neutral text / core infrastructure black
val MetroTeal = Color(0xFF2E7D32)     // Normal service forest green
val MetroGold = Color(0xFFD0006F)     // Matches main accent for consistency (or warnings can use amber gold)

// Secondary & Background Accents
val SoftPink = Color(0xFFFCE1ED)      // Soft container pink
val SoftIndigo = Color(0xFFE1E2E9)    // Border gray / line separator
val SoftTeal = Color(0xFFE8F5E9)      // Service normal background

// Light Mode Platform
val LightBackground = Color(0xFFF3F4F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F2F6)
val LightOnBackground = Color(0xFF1C1B1F)
val LightOnSurface = Color(0xFF1C1B1F)
val LightOnPrimary = Color(0xFFFFFFFF)

// Dark Mode Platform
val DarkBackground = Color(0xFF0C0C0E)
val DarkSurface = Color(0xFF1C1B1F)
val DarkSurfaceVariant = Color(0xFF2B2B30)
val DarkOnBackground = Color(0xFFF3F4F9)
val DarkOnSurface = Color(0xFFF3F4F9)
val DarkOnPrimary = Color(0xFFFFFFFF)
