package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MetroViewModel
import com.example.ui.components.InteractiveMetroMap
import com.example.ui.theme.MetroIndigo
import com.example.ui.theme.MetroPink
import com.example.ui.theme.MetroTeal

@Composable
fun MapScreen(
    viewModel: MetroViewModel,
    onPlanFromHere: () -> Unit
) {
    val stations by viewModel.allStations.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()
    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val selectedStation by viewModel.selectedStation.collectAsState()
    val departures by viewModel.stationDepartures.collectAsState()
    val favStations by viewModel.favouriteStationIds.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("map_screen")
    ) {
        // --- MAP AREA ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.0f)
        ) {
            InteractiveMetroMap(
                stations = stations,
                vehicles = vehicles,
                selectedStationId = selectedStationId,
                onStationSelected = { id -> viewModel.selectStation(id) },
                modifier = Modifier.fillMaxSize()
            )
        }

        // --- STATION DETAILS BOTTOM PANEL ---
        selectedStation?.let { station ->
            val isFav = favStations.contains(station.id)

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                ) {
                    // Title and Favourite toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = station.name.uppercase(),
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 1.sp
                                    ),
                                    color = MetroIndigo
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .background(MetroPink.copy(alpha = 0.1f), shape = RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "Zone ${station.zone}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MetroPink
                                    )
                                }
                            }
                            Text(
                                text = "Platform: ${station.platformInfo}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { viewModel.toggleStationFavourite(station.id) }) {
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "Favourite station",
                                    tint = if (isFav) MetroPink else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            
                            Button(
                                onClick = {
                                    viewModel.setOrigin(station.id)
                                    onPlanFromHere()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MetroPink),
                                shape = RoundedCornerShape(20.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.DirectionsRun, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("PLAN FROM HERE", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    // Departures & Facilities Horizontal Split
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Departures list (Left 60% weight)
                        Column(
                            modifier = Modifier.weight(1.2f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "UPCOMING DEPARTURES",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = MetroIndigo
                            )

                            if (departures.isEmpty()) {
                                Text(
                                    text = "No departures planned.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                departures.take(3).forEach { dep ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .background(MetroPink, shape = CircleShape)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = dep.destinationName,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                color = MetroIndigo,
                                                maxLines = 1
                                            )
                                        }
                                        val isDue = dep.status == com.example.core.model.DepartureStatus.DUE
                                        Text(
                                            text = if (isDue) "Due" else "${dep.dueMinutes}m",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.ExtraBold),
                                            color = if (isDue) MetroPink else MetroIndigo
                                        )
                                    }
                                }
                            }
                        }

                        // Facilities (Right 40% weight)
                        Column(
                            modifier = Modifier.weight(0.8f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "FACILITIES",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                color = MetroIndigo
                            )

                            FacilityIndicator(
                                isAvailable = station.isStepFree,
                                icon = Icons.Default.Accessible,
                                label = "Step-free access"
                            )
                            FacilityIndicator(
                                isAvailable = station.hasCycleFacilities,
                                icon = Icons.Default.DirectionsBike,
                                label = "Cycle facilities"
                            )
                            FacilityIndicator(
                                isAvailable = station.hasParking,
                                icon = Icons.Default.LocalParking,
                                label = "Car Park"
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FacilityIndicator(
    isAvailable: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isAvailable) MetroTeal else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = if (isAvailable) FontWeight.SemiBold else FontWeight.Normal,
                fontSize = 11.sp
            ),
            color = if (isAvailable) MetroIndigo else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
        )
    }
}
