package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.TransitStop
import com.example.core.model.Vehicle
import com.example.ui.theme.MetroGold
import com.example.ui.theme.MetroIndigo
import com.example.ui.theme.MetroPink
import kotlin.math.max
import kotlin.math.min

@OptIn(ExperimentalTextApi::class)
@Composable
fun InteractiveMetroMap(
    stations: List<TransitStop>,
    vehicles: List<Vehicle>,
    selectedStationId: String,
    onStationSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var isGeographic by remember { mutableStateOf(false) }
    
    // Zoom & pan states
    var scale by remember { mutableStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = max(0.5f, min(scale * zoom, 4.0f))
                        offset += pan
                    }
                }
        ) {
            val width = size.width
            val height = size.height
            if (stations.isEmpty()) return@Canvas

            // --- Georouting bounds computation ---
            val minLat = stations.minOf { it.latitude }
            val maxLat = stations.maxOf { it.latitude }
            val minLng = stations.minOf { it.longitude }
            val maxLng = stations.maxOf { it.longitude }

            val latSpan = maxLat - minLat
            val lngSpan = maxLng - minLng

            // Compute positions
            val stationPositions = stations.mapIndexed { idx, stop ->
                val x: Float
                val y: Float
                if (isGeographic) {
                    // Normalize lat/lng to canvas space
                    val normX = if (lngSpan == 0.0) 0.5f else ((stop.longitude - minLng) / lngSpan).toFloat()
                    // Lat is flipped (north is up, screen y goes down)
                    val normY = if (latSpan == 0.0) 0.5f else (1.0 - (stop.latitude - minLat) / latSpan).toFloat()
                    
                    x = width * 0.15f + normX * (width * 0.7f)
                    y = height * 0.15f + normY * (height * 0.7f)
                } else {
                    // Schematic mode: single modern diagonal line going from top-left to bottom-right
                    val fraction = idx.toFloat() / (stations.size - 1)
                    x = width * 0.2f + fraction * (width * 0.6f)
                    y = height * 0.12f + fraction * (height * 0.76f)
                }
                
                // Apply current pan/zoom transformation
                val transformedX = (x + offset.x) * scale
                val transformedY = (y + offset.y) * scale
                stop.id to Offset(transformedX, transformedY)
            }.toMap()

            // --- Draw Metro Route Lines ---
            val pathPoints = stations.mapNotNull { stationPositions[it.id] }
            if (pathPoints.size > 1) {
                // Draw casing (outline)
                for (i in 0 until pathPoints.size - 1) {
                    drawLine(
                        color = MetroIndigo.copy(alpha = 0.3f),
                        start = pathPoints[i],
                        end = pathPoints[i + 1],
                        strokeWidth = 14f * scale
                    )
                }
                // Draw inner route fill (Metro Pink)
                for (i in 0 until pathPoints.size - 1) {
                    drawLine(
                        color = MetroPink,
                        start = pathPoints[i],
                        end = pathPoints[i + 1],
                        strokeWidth = 8f * scale
                    )
                }
            }

            // --- Draw Station Markers & Text Labels ---
            stations.forEach { stop ->
                val pos = stationPositions[stop.id] ?: return@forEach
                val isSelected = stop.id == selectedStationId

                // Station node outer circle
                drawCircle(
                    color = if (isSelected) MetroPink else MetroIndigo,
                    radius = (if (isSelected) 10f else 6f) * scale,
                    center = pos
                )
                
                // Inner white dot (classic transit schematic style)
                drawCircle(
                    color = Color.White,
                    radius = (if (isSelected) 5f else 3f) * scale,
                    center = pos
                )

                // Label
                if (scale >= 0.8f) {
                    val labelText = stop.name
                    // Shorten or align beautifully based on schematic direction
                    val labelOffset = if (isGeographic) {
                        Offset(12f * scale, -6f * scale)
                    } else {
                        Offset(-140f * scale, -10f * scale)
                    }
                    
                    drawText(
                        textMeasurer = textMeasurer,
                        text = labelText,
                        topLeft = pos + labelOffset,
                        style = TextStyle(
                            color = if (isSelected) MetroPink else MetroIndigo,
                            fontSize = (10f * scale).sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    )
                }
            }

            // --- Draw Live Simulated Trams ---
            vehicles.forEach { tram ->
                // To track position, find corresponding coordinate interpolation
                val tramLat = tram.latitude
                val tramLng = tram.longitude
                
                // Geographic position mapping
                val x: Float
                val y: Float
                if (isGeographic) {
                    val normX = if (lngSpan == 0.0) 0.5f else ((tramLng - minLng) / lngSpan).toFloat()
                    val normY = if (latSpan == 0.0) 0.5f else (1.0 - (tramLat - minLat) / latSpan).toFloat()
                    x = width * 0.15f + normX * (width * 0.7f)
                    y = height * 0.15f + normY * (height * 0.7f)
                } else {
                    // Interpolate index on schematic line
                    val nextStopIndex = stations.indexOfFirst { it.name == tram.nextStopName }
                    val calculatedIndex = if (nextStopIndex != -1) max(0, nextStopIndex - 1) else 3
                    val fraction = (calculatedIndex + 0.5f) / (stations.size - 1)
                    x = width * 0.2f + fraction * (width * 0.6f)
                    y = height * 0.12f + fraction * (height * 0.76f)
                }

                val tramPos = Offset((x + offset.x) * scale, (y + offset.y) * scale)

                // Draw Pulse Ring
                drawCircle(
                    color = MetroGold.copy(alpha = 0.4f),
                    radius = 16f * scale,
                    center = tramPos,
                    style = Stroke(width = 2f * scale)
                )

                // Draw Outer Body
                drawCircle(
                    color = MetroGold,
                    radius = 9f * scale,
                    center = tramPos
                )

                // Draw Core
                drawCircle(
                    color = MetroIndigo,
                    radius = 4f * scale,
                    center = tramPos
                )
            }
        }

        // --- MAP CONTROLS ---
        Card(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Map Mode Toggle Button
                IconButton(
                    onClick = { isGeographic = !isGeographic }
                ) {
                    Icon(
                        imageVector = if (isGeographic) Icons.Default.Route else Icons.Default.Map,
                        contentDescription = "Toggle Map Type",
                        tint = MetroPink
                    )
                }
                
                HorizontalDivider(modifier = Modifier.width(32.dp), color = MaterialTheme.colorScheme.outlineVariant)

                // Zoom In
                IconButton(
                    onClick = { scale = min(scale * 1.2f, 4.0f) }
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Zoom In")
                }

                // Zoom Out
                IconButton(
                    onClick = { scale = max(scale / 1.2f, 0.5f) }
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Zoom Out")
                }

                // Reset
                IconButton(
                    onClick = {
                        scale = 1.0f
                        offset = Offset.Zero
                    }
                ) {
                    Icon(Icons.Default.GpsFixed, contentDescription = "Reset view")
                }
            }
        }

        // --- QUICK LEGEND ---
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
                .background(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(8.dp)
                )
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(MetroPink, shape = RoundedCornerShape(2.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Line 1",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(MetroGold, shape = RoundedCornerShape(5.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Live Tram",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Text(
                    text = if (isGeographic) "Geographic Projection" else "Schematic Diagram",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MetroPink
                    )
                )
            }
        }
    }
}
