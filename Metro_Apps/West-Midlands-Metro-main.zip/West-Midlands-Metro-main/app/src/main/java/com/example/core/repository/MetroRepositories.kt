package com.example.core.repository

import com.example.core.database.*
import com.example.core.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// ==========================================
// 1. STATION REPOSITORY
// ==========================================
interface StationRepository {
    fun getStations(): Flow<List<TransitStop>>
    suspend fun getStation(id: String): TransitStop?
    suspend fun seedStationsIfEmpty()
}

class StationRepositoryImpl(
    private val metroDao: MetroDao,
    private val externalScope: CoroutineScope
) : StationRepository {

    init {
        externalScope.launch(Dispatchers.IO) {
            seedStationsIfEmpty()
        }
    }

    override fun getStations(): Flow<List<TransitStop>> {
        return metroDao.getAllStations().map { entities ->
            entities.map { it.toTransitStop() }
        }
    }

    override suspend fun getStation(id: String): TransitStop? {
        return metroDao.getStationById(id)?.toTransitStop()
    }

    override suspend fun seedStationsIfEmpty() {
        // Check if database is empty
        val firstStations = TransitData.Stations
        val entities = firstStations.map { stop ->
            StationEntity(
                id = stop.id,
                name = stop.name,
                latitude = stop.latitude,
                longitude = stop.longitude,
                zone = stop.zone,
                isStepFree = stop.isStepFree,
                hasCycleFacilities = stop.hasCycleFacilities,
                hasParking = stop.hasParking,
                connections = stop.connections.joinToString(",") { it.name },
                platformInfo = stop.platformInfo
            )
        }
        metroDao.insertStations(entities)
    }
}

// Extension Mapper
fun StationEntity.toTransitStop(): TransitStop {
    return TransitStop(
        id = id,
        name = name,
        latitude = latitude,
        longitude = longitude,
        zone = zone,
        isStepFree = isStepFree,
        hasCycleFacilities = hasCycleFacilities,
        hasParking = hasParking,
        connections = if (connections.isEmpty()) listOf(TransportMode.METRO) else connections.split(",").map { TransportMode.valueOf(it) },
        platformInfo = platformInfo
    )
}

// ==========================================
// 2. DEPARTURE REPOSITORY
// ==========================================
interface DepartureRepository {
    fun getDepartures(stationId: String): Flow<List<Departure>>
    fun getNetworkDepartures(): Flow<Map<String, List<Departure>>>
}

class DepartureRepositoryImpl : DepartureRepository {

    // A state flow that ticks to simulate count downs
    private val tickerFlow = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(10000) // update departures every 10 seconds
        }
    }.stateIn(CoroutineScope(Dispatchers.Default), SharingStarted.Eagerly, System.currentTimeMillis())

    override fun getDepartures(stationId: String): Flow<List<Departure>> {
        return tickerFlow.map { tickTime ->
            generateDeterministicDepartures(stationId, tickTime)
        }
    }

    override fun getNetworkDepartures(): Flow<Map<String, List<Departure>>> {
        return tickerFlow.map { tickTime ->
            TransitData.Stations.associate { stop ->
                stop.id to generateDeterministicDepartures(stop.id, tickTime)
            }
        }
    }

    private fun generateDeterministicDepartures(stationId: String, seedTime: Long): List<Departure> {
        val station = TransitData.Stations.find { it.id == stationId } ?: return emptyList()
        val index = TransitData.Stations.indexOf(station)
        if (index == -1) return emptyList()

        val departures = mutableListOf<Departure>()
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = seedTime
        val currentMinutes = calendar.get(Calendar.MINUTE)

        // Wolverhampton bound (going towards index 0 / Wolverhampton Station)
        if (index > 0) {
            // Generate departures based on index and current time
            val baseDiff = index * 3
            val nextMinutes1 = (baseDiff + (60 - currentMinutes)) % 12
            val nextMinutes2 = nextMinutes1 + 12
            val nextMinutes3 = nextMinutes2 + 12

            departures.add(createSimulatedDeparture(stationId, "Wolverhampton", nextMinutes1, "1"))
            departures.add(createSimulatedDeparture(stationId, "Wolverhampton", nextMinutes2, "1"))
            departures.add(createSimulatedDeparture(stationId, "Wolverhampton", nextMinutes3, "1"))
        }

        // Edgbaston Village bound (going towards last index / Edgbaston Village)
        val lastIdx = TransitData.Stations.size - 1
        if (index < lastIdx) {
            val baseDiff = (lastIdx - index) * 3
            val nextMinutes1 = (baseDiff + (60 - currentMinutes)) % 10
            val nextMinutes2 = nextMinutes1 + 10
            val nextMinutes3 = nextMinutes2 + 10

            departures.add(createSimulatedDeparture(stationId, "Edgbaston Village", nextMinutes1, "2"))
            departures.add(createSimulatedDeparture(stationId, "Edgbaston Village", nextMinutes2, "2"))
            departures.add(createSimulatedDeparture(stationId, "Edgbaston Village", nextMinutes3, "2"))
        }

        // Add multimodal departures (Rail or Bus) if available at station
        if (station.connections.contains(TransportMode.RAIL)) {
            val railTime1 = (currentMinutes * 3 + 7) % 23
            departures.add(
                Departure(
                    stationId = stationId,
                    destinationName = "London Euston (via Rail)",
                    dueMinutes = if (railTime1 == 0) 1 else railTime1,
                    status = if (railTime1 < 3) DepartureStatus.DUE else DepartureStatus.MINUTES,
                    platform = "Platform 3",
                    transportMode = TransportMode.RAIL
                )
            )
        }
        if (station.connections.contains(TransportMode.BUS)) {
            val busTime1 = (currentMinutes * 2 + 5) % 15
            departures.add(
                Departure(
                    stationId = stationId,
                    destinationName = "Birmingham Airport X1",
                    dueMinutes = if (busTime1 == 0) 1 else busTime1,
                    status = if (busTime1 < 2) DepartureStatus.DUE else DepartureStatus.MINUTES,
                    platform = "Stand B",
                    transportMode = TransportMode.BUS
                )
            )
        }

        return departures.sortedWith(compareBy({ it.transportMode }, { it.dueMinutes }))
    }

    private fun createSimulatedDeparture(
        stationId: String,
        destination: String,
        dueMinutes: Int,
        platform: String
    ): Departure {
        val status = when {
            dueMinutes <= 0 -> DepartureStatus.DUE
            dueMinutes == 4 -> DepartureStatus.DELAYED // Add a deterministic delayed tram
            else -> DepartureStatus.MINUTES
        }
        val delay = if (status == DepartureStatus.DELAYED) 3 else 0
        return Departure(
            stationId = stationId,
            destinationName = destination,
            dueMinutes = if (dueMinutes <= 0) 1 else dueMinutes,
            status = status,
            platform = platform,
            delayMinutes = delay,
            transportMode = TransportMode.METRO
        )
    }
}

// ==========================================
// 3. JOURNEY REPOSITORY
// ==========================================
interface JourneyRepository {
    fun planJourney(
        originId: String,
        destinationId: String,
        accessibilityRequired: Boolean = false,
        preferredMode: TransportMode = TransportMode.METRO
    ): List<JourneyOption>
}

class JourneyRepositoryImpl : JourneyRepository {
    override fun planJourney(
        originId: String,
        destinationId: String,
        accessibilityRequired: Boolean,
        preferredMode: TransportMode
    ): List<JourneyOption> {
        val origin = TransitData.Stations.find { it.id == originId } ?: return emptyList()
        val dest = TransitData.Stations.find { it.id == destinationId } ?: return emptyList()

        if (originId == destinationId) return emptyList()

        val originIdx = TransitData.Stations.indexOf(origin)
        val destIdx = TransitData.Stations.indexOf(dest)

        // Direct Metro Option
        val stopsCount = kotlin.math.abs(originIdx - destIdx)
        val travelDuration = stopsCount * 2 // 2 minutes per stop on average
        val farePrice = TransitData.getFarePrice(originId, destinationId, "Single Ticket")

        val sdf = SimpleDateFormat("HH:mm", Locale.UK)
        val calendar = Calendar.getInstance()
        val departTimeStr = sdf.format(calendar.time)
        calendar.add(Calendar.MINUTE, travelDuration)
        val arriveTimeStr = sdf.format(calendar.time)

        val directLeg = JourneyLeg(
            mode = TransportMode.METRO,
            lineName = "Blue Line 1",
            fromStopName = origin.name,
            toStopName = dest.name,
            durationMinutes = travelDuration,
            departureTime = departTimeStr,
            arrivalTime = arriveTimeStr,
            instruction = "Board Tram at platform ${if (destIdx > originIdx) "2" else "1"}.",
            intermediateStopsCount = stopsCount - 1
        )

        val option1 = JourneyOption(
            legs = listOf(directLeg),
            totalDurationMinutes = travelDuration,
            totalFare = farePrice,
            tag = "FASTEST"
        )

        // Multimodal alternative: Walk or Bus if connected
        val options = mutableListOf(option1)

        if (stopsCount > 4) {
            // Option 2: Fewer Changes (often similar, but let's make it slightly different walking)
            val walkingTime = 4
            calendar.time = Date()
            val departWalkStr = sdf.format(calendar.time)
            calendar.add(Calendar.MINUTE, walkingTime)
            val boardTimeStr = sdf.format(calendar.time)
            calendar.add(Calendar.MINUTE, travelDuration - 2)
            val arriveWalkStr = sdf.format(calendar.time)

            val walkLeg = JourneyLeg(
                mode = TransportMode.WALK,
                lineName = "Walk",
                fromStopName = origin.name,
                toStopName = origin.name,
                durationMinutes = walkingTime,
                departureTime = departWalkStr,
                arrivalTime = boardTimeStr,
                instruction = "Walk to platforms (Step-free route)."
            )

            val metroLeg = JourneyLeg(
                mode = TransportMode.METRO,
                lineName = "Blue Line 1",
                fromStopName = origin.name,
                toStopName = dest.name,
                durationMinutes = travelDuration - 2,
                departureTime = boardTimeStr,
                arrivalTime = arriveWalkStr,
                instruction = "Take Blue Line Tram.",
                intermediateStopsCount = stopsCount - 1
            )

            options.add(
                JourneyOption(
                    legs = listOf(walkLeg, metroLeg),
                    totalDurationMinutes = travelDuration + walkingTime,
                    totalFare = farePrice,
                    tag = "LOW WALKING"
                )
            )

            // Let's create an express/train multimodal option if both have RAIL
            if (origin.connections.contains(TransportMode.RAIL) && dest.connections.contains(TransportMode.RAIL)) {
                calendar.time = Date()
                val trainDep = sdf.format(calendar.time)
                val trainDuration = travelDuration / 2
                calendar.add(Calendar.MINUTE, trainDuration)
                val trainArr = sdf.format(calendar.time)

                val railLeg = JourneyLeg(
                    mode = TransportMode.RAIL,
                    lineName = "West Midlands Railway",
                    fromStopName = origin.name + " Rail",
                    toStopName = dest.name + " Rail",
                    durationMinutes = trainDuration,
                    departureTime = trainDep,
                    arrivalTime = trainArr,
                    instruction = "Board national rail service.",
                    intermediateStopsCount = 1
                )

                options.add(
                    0, // Make it the first option as it's the fastest
                    JourneyOption(
                        legs = listOf(railLeg),
                        totalDurationMinutes = trainDuration,
                        totalFare = farePrice * 1.5,
                        tag = "FEWEST CHANGES"
                    )
                )
            }
        }

        // Filter for accessibility if requested
        return if (accessibilityRequired) {
            // Filters or adjusts routes. In our static database, all main Metro stations are step-free
            options.filter { opt -> opt.legs.all { leg -> leg.mode != TransportMode.WALK || leg.instruction.contains("Step-free") } }
        } else {
            options
        }
    }
}

// ==========================================
// 4. TICKET REPOSITORY
// ==========================================
interface TicketRepository {
    fun getTickets(): Flow<List<Ticket>>
    suspend fun purchaseTicket(ticket: Ticket)
    suspend fun activateTicket(ticketId: String)
    suspend fun useTicket(ticketId: String)
}

class TicketRepositoryImpl(private val metroDao: MetroDao) : TicketRepository {

    override fun getTickets(): Flow<List<Ticket>> {
        return metroDao.getAllTickets().map { entities ->
            entities.map { it.toTicket() }
        }
    }

    override suspend fun purchaseTicket(ticket: Ticket) {
        metroDao.insertTicket(ticket.toEntity())
    }

    override suspend fun activateTicket(ticketId: String) {
        metroDao.updateTicketStatus(ticketId, TicketStatus.ACTIVE.name)
    }

    override suspend fun useTicket(ticketId: String) {
        metroDao.updateTicketStatus(ticketId, TicketStatus.USED.name)
    }
}

// Extension Mappers
fun TicketEntity.toTicket(): Ticket {
    return Ticket(
        id = id,
        title = title,
        description = description,
        type = type,
        price = price,
        zones = zones,
        purchaseTime = purchaseTime,
        expiryTime = expiryTime,
        status = TicketStatus.valueOf(status),
        qrCodeString = qrCodeString
    )
}

fun Ticket.toEntity(): TicketEntity {
    return TicketEntity(
        id = id,
        title = title,
        description = description,
        type = type,
        price = price,
        zones = zones,
        purchaseTime = purchaseTime,
        expiryTime = expiryTime,
        status = status.name,
        qrCodeString = qrCodeString
    )
}

// ==========================================
// 5. DISRUPTION REPOSITORY
// ==========================================
interface DisruptionRepository {
    fun getDisruptions(): Flow<List<Disruption>>
    suspend fun seedDisruptionsIfEmpty()
    suspend fun clearDisruptions()
}

class DisruptionRepositoryImpl(
    private val metroDao: MetroDao,
    private val externalScope: CoroutineScope
) : DisruptionRepository {

    init {
        externalScope.launch(Dispatchers.IO) {
            seedDisruptionsIfEmpty()
        }
    }

    override fun getDisruptions(): Flow<List<Disruption>> {
        return metroDao.getAllDisruptions().map { entities ->
            entities.map { it.toDisruption() }
        }
    }

    override suspend fun seedDisruptionsIfEmpty() {
        val staticDisruptions = listOf(
            Disruption(
                id = "DISR_1",
                title = "Central Birmingham Service Update",
                description = "Slightly reduced frequency in central Birmingham due to track inspection between Bull Street and Library.",
                affectedLines = listOf("Blue Line 1"),
                level = DisruptionLevel.MINOR,
                alternativeInstructions = "Services are still operating, but allow an additional 5-10 minutes for your journey."
            ),
            Disruption(
                id = "DISR_2",
                title = "Planned Weekend Engineering Works",
                description = "Bus replacement service will run between Wednesbury Great Western Street and Bilston Central this coming Sunday.",
                affectedLines = listOf("Blue Line 1"),
                level = DisruptionLevel.MAJOR,
                alternativeInstructions = "Dedicated Metro replacement buses (W1) will operate every 10 minutes from nearby bus stands."
            )
        )
        val entities = staticDisruptions.map { it.toEntity() }
        metroDao.insertDisruptions(entities)
    }

    override suspend fun clearDisruptions() {
        metroDao.clearDisruptions()
    }
}

// Extension Mappers
fun DisruptionEntity.toDisruption(): Disruption {
    return Disruption(
        id = id,
        title = title,
        description = description,
        affectedLines = affectedLines.split(","),
        level = DisruptionLevel.valueOf(level),
        alternativeInstructions = alternativeInstructions,
        timestamp = timestamp
    )
}

fun Disruption.toEntity(): DisruptionEntity {
    return DisruptionEntity(
        id = id,
        title = title,
        description = description,
        affectedLines = affectedLines.joinToString(","),
        level = level.name,
        alternativeInstructions = alternativeInstructions,
        timestamp = timestamp
    )
}

// ==========================================
// 6. VEHICLE REPOSITORY
// ==========================================
interface VehicleRepository {
    fun getVehicles(): Flow<List<Vehicle>>
}

class VehicleRepositoryImpl : VehicleRepository {

    // Emits list of vehicles whose locations are animated/moved smoothly every 5 seconds
    private val vehicleSimulationFlow = flow {
        // Initialize 5 simulated Trams spaced out across the line
        val numTrams = 6
        val stations = TransitData.Stations
        val size = stations.size

        while (true) {
            val now = System.currentTimeMillis()
            val vehicles = mutableListOf<Vehicle>()

            for (i in 0 until numTrams) {
                // Calculate position along the route index based on time
                val baseTimeOffset = (now / 15000 + i * (size / numTrams))
                val isForward = i % 2 == 0

                val routeIndex = if (isForward) {
                    (baseTimeOffset % size).toInt()
                } else {
                    ((size - 1 - (baseTimeOffset % size)) % size).toInt()
                }

                val currentStation = stations[routeIndex]
                val nextStationIndex = if (isForward) {
                    (routeIndex + 1) % size
                } else {
                    if (routeIndex - 1 < 0) size - 1 else routeIndex - 1
                }
                val nextStation = stations[nextStationIndex]

                // Compute linear interpolation for lat/lng to simulate active transit
                val progress = (now % 15000) / 15000.0
                val lat = currentStation.latitude + (nextStation.latitude - currentStation.latitude) * progress
                val lng = currentStation.longitude + (nextStation.longitude - currentStation.longitude) * progress

                vehicles.add(
                    Vehicle(
                        id = "TRAM-${300 + i}",
                        routeId = "LINE_1",
                        latitude = lat,
                        longitude = lng,
                        nextStopName = nextStation.name,
                        currentSpeedKmh = if (progress < 0.2 || progress > 0.8) 10 else 45,
                        heading = if (isForward) 135f else 315f,
                        loadFactor = 0.2 + (i % 3) * 0.25 + (progress * 0.1),
                        status = if (progress < 0.15) "At Station" else "In Transit"
                    )
                )
            }
            emit(vehicles)
            delay(3000) // update vehicle telemetry every 3 seconds
        }
    }.stateIn(CoroutineScope(Dispatchers.Default), SharingStarted.Eagerly, emptyList())

    override fun getVehicles(): Flow<List<Vehicle>> {
        return vehicleSimulationFlow
    }
}

// ==========================================
// 7. FARE REPOSITORY
// ==========================================
interface FareRepository {
    fun calculateFares(originId: String, destinationId: String): List<Fare>
}

class FareRepositoryImpl : FareRepository {
    override fun calculateFares(originId: String, destinationId: String): List<Fare> {
        val ticketTypes = listOf("Single Ticket", "Day Saver", "Off-Peak Day Saver", "Weekly Pass", "Monthly Season")
        return ticketTypes.map { type ->
            Fare(
                id = "${originId}_${destinationId}_${type.replace(" ", "_")}",
                originStationId = originId,
                destinationStationId = destinationId,
                ticketTypeName = type,
                price = TransitData.getFarePrice(originId, destinationId, type)
            )
        }
    }
}

// ==========================================
// 8. METRO REPOSITORY
// ==========================================
interface MetroRepository {
    fun getFavouriteStations(): Flow<List<String>>
    suspend fun addFavouriteStation(stationId: String)
    suspend fun removeFavouriteStation(stationId: String)

    fun getFavouriteJourneys(): Flow<List<FavouriteJourneyEntity>>
    suspend fun addFavouriteJourney(originId: String, originName: String, destId: String, destName: String)
    suspend fun removeFavouriteJourney(id: String)
}

class MetroRepositoryImpl(private val metroDao: MetroDao) : MetroRepository {

    override fun getFavouriteStations(): Flow<List<String>> {
        return metroDao.getFavouriteStations().map { entities ->
            entities.map { it.stationId }
        }
    }

    override suspend fun addFavouriteStation(stationId: String) {
        metroDao.insertFavouriteStation(FavouriteStationEntity(stationId))
    }

    override suspend fun removeFavouriteStation(stationId: String) {
        metroDao.deleteFavouriteStation(stationId)
    }

    override fun getFavouriteJourneys(): Flow<List<FavouriteJourneyEntity>> {
        return metroDao.getFavouriteJourneys()
    }

    override suspend fun addFavouriteJourney(originId: String, originName: String, destId: String, destName: String) {
        val id = "${originId}_${destId}"
        metroDao.insertFavouriteJourney(
            FavouriteJourneyEntity(
                id = id,
                originId = originId,
                originName = originName,
                destinationId = destId,
                destinationName = destName
            )
        )
    }

    override suspend fun removeFavouriteJourney(id: String) {
        metroDao.deleteFavouriteJourney(id)
    }
}
