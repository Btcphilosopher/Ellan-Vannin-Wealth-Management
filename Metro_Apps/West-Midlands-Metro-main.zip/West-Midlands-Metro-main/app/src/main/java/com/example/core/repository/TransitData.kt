package com.example.core.repository

import com.example.core.model.Route
import com.example.core.model.TransitStop
import com.example.core.model.TransportMode

object TransitData {

    // Main Line 1 Stations from Wolverhampton to Birmingham (Edgbaston Village)
    val Stations = listOf(
        TransitStop("WOL_STN", "Wolverhampton Station", 52.5882, -2.1192, 4, true, true, false, listOf(TransportMode.METRO, TransportMode.RAIL), "Platform 1"),
        TransitStop("WOL_STG", "Wolverhampton St George's", 52.5855, -2.1245, 4, true, false, false, listOf(TransportMode.METRO), "Platform 1"),
        TransitStop("THE_ROY", "The Royal", 52.5828, -2.1171, 4, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("PRIESTF", "Priestfield", 52.5714, -2.1068, 4, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("BILSTON", "Bilston Central", 52.5645, -2.0768, 4, true, true, true, listOf(TransportMode.METRO, TransportMode.BUS), "Platform 1 & 2"),
        TransitStop("LOXDALE", "Loxdale", 52.5598, -2.0621, 4, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("BRADLEY", "Bradley Lane", 52.5543, -2.0514, 4, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("WED_PKY", "Wednesbury Parkway", 52.5481, -2.0298, 3, true, true, true, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("WED_GWS", "Wednesbury Great Western St", 52.5463, -2.0245, 3, true, false, false, listOf(TransportMode.METRO, TransportMode.BUS), "Platform 1 & 2"),
        TransitStop("BL_LAKE", "Black Lake", 52.5310, -2.0125, 3, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("MET_CTR", "Metro Centre", 52.5271, -2.0134, 3, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("WB_CENT", "West Bromwich Central", 52.5187, -2.0123, 3, true, true, false, listOf(TransportMode.METRO, TransportMode.BUS), "Platform 1 & 2"),
        TransitStop("LODGE_R", "Lodge Road", 52.5114, -2.0084, 3, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("KEN_PKY", "Kenrick Park", 52.5055, -2.0012, 3, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("TRI_WAY", "Trinity Way", 52.5005, -1.9895, 2, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("HND_BTS", "Handsworth Booth Street", 52.4965, -1.9785, 2, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("WIN_GRN", "Winson Green Outer Circle", 52.4921, -1.9482, 2, true, false, false, listOf(TransportMode.METRO, TransportMode.BUS), "Platform 1 & 2"),
        TransitStop("SOHO_BR", "Soho Benson Road", 52.4912, -1.9392, 2, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("JWL_QTR", "Jewellery Quarter", 52.4895, -1.9128, 1, true, true, false, listOf(TransportMode.METRO, TransportMode.RAIL), "Platform 1 & 2"),
        TransitStop("ST_PAUL", "St Paul's", 52.4862, -1.9034, 1, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("ST_CHAD", "St Chad's", 52.4835, -1.8974, 1, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("BULL_ST", "Bull Street", 52.4815, -1.8942, 1, true, false, false, listOf(TransportMode.METRO, TransportMode.BUS), "Platform 1"),
        TransitStop("CORP_ST", "Corporation Street", 52.4801, -1.8968, 1, true, false, false, listOf(TransportMode.METRO), "Platform 1"),
        TransitStop("GRND_CT", "Grand Central", 52.4785, -1.8992, 1, true, true, false, listOf(TransportMode.METRO, TransportMode.RAIL, TransportMode.BUS), "Platform 1 & 2"),
        TransitStop("TWN_HLL", "Town Hall", 52.4775, -1.9022, 1, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("LIBRARY", "Library", 52.4791, -1.9078, 1, true, true, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("BRND_PL", "Brindleyplace", 52.4781, -1.9145, 1, true, false, false, listOf(TransportMode.METRO), "Platform 1 & 2"),
        TransitStop("FIV_WAY", "Five Ways", 52.4715, -1.9198, 1, true, false, false, listOf(TransportMode.METRO, TransportMode.RAIL), "Platform 1 & 2"),
        TransitStop("EDG_VIL", "Edgbaston Village", 52.4705, -1.9255, 1, true, true, false, listOf(TransportMode.METRO, TransportMode.BUS), "Platform 1")
    )

    // The sequence of stations for the primary Metro Line 1
    val RouteStops = Stations.map { it.id }

    val Line1 = Route(
        id = "LINE_1",
        name = "Blue Line",
        color = "#D11252", // Iconic Metro Pink
        stops = RouteStops,
        isActive = true
    )

    // A list of static ticket products
    val TicketProducts = listOf(
        Pair("Single Ticket", 2.80),
        Pair("Day Saver", 4.50),
        Pair("Off-Peak Day Saver", 3.90),
        Pair("Weekly Pass", 19.50),
        Pair("Monthly Season", 68.00)
    )

    // Generate simulated fares
    fun getFarePrice(originId: String, destId: String, ticketType: String): Double {
        val origin = Stations.find { it.id == originId }
        val dest = Stations.find { it.id == destId }
        if (origin == null || dest == null) return 2.80

        val zoneDiff = kotlin.math.abs(origin.zone - dest.zone)
        val basePrice = when (ticketType) {
            "Single Ticket" -> 2.00 + (zoneDiff * 0.40)
            "Day Saver" -> 3.50 + (zoneDiff * 0.50)
            "Off-Peak Day Saver" -> 3.00 + (zoneDiff * 0.45)
            "Weekly Pass" -> 15.00 + (zoneDiff * 2.00)
            "Monthly Season" -> 50.00 + (zoneDiff * 6.00)
            else -> 2.50
        }
        return String.format("%.2f", basePrice).toDouble()
    }
}
