package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.RailwayViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isChatLoading by viewModel.isChatLoading.collectAsState()

    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Auto-scroll chat to latest messages
    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp)
    ) {
        // Chat Header
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SupportAgent, "Rail Assist", tint = Color.White)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(LocalizedStrings.get("rail_assist", lang), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                        Text("AI Copilot · Grounded facts", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                    }
                }
            },
            actions = {
                IconButton(onClick = { viewModel.clearChat() }) {
                    Icon(Icons.Default.DeleteSweep, "Clear Chat", tint = Color.White)
                }
            },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )

        // Messages List
        Box(modifier = Modifier.weight(1f)) {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(chatMessages) { msg ->
                    ChatBubble(msg)
                }
                if (isChatLoading) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(8.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Text("Rail Assist is formulating response...", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }

        // Suggestion Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "Where is my train 12951?",
                "What does RAC mean?",
                "Check my PNR status"
            ).forEach { sug ->
                SuggestionChip(
                    onClick = { viewModel.sendChatPrompt(sug) },
                    label = { Text(sug) }
                )
            }
        }

        // Input Box Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("Ask Rail Assist...") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp)
            )
            FloatingActionButton(
                onClick = {
                    if (textInput.isNotBlank()) {
                        viewModel.sendChatPrompt(textInput)
                        textInput = ""
                    }
                },
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.Send, "Send message")
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage) {
    val isUser = msg.isUser
    val bubbleColor = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val align = if (isUser) Alignment.End else Alignment.Start

    Column(
        horizontalAlignment = align,
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            color = bubbleColor,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(text = msg.text, fontSize = 14.sp)
                
                // Grounding Source pill for official guidelines compliance
                if (!isUser) {
                    Spacer(modifier = Modifier.height(4.dp))
                    val sourcePillColor = when (msg.source) {
                        SourceClassification.LIVE -> ForestGreen
                        SourceClassification.OFFICIAL_STATIC -> CarriageBlue
                        SourceClassification.USER_ACCOUNT -> SlateCharcoal
                        SourceClassification.SIMULATION -> AmberAlert
                        SourceClassification.UNKNOWN -> Color.Gray
                    }
                    val sourceText = when (msg.source) {
                        SourceClassification.LIVE -> "LIVE SOURCE"
                        SourceClassification.OFFICIAL_STATIC -> "OFFICIAL STANDARDS"
                        SourceClassification.USER_ACCOUNT -> "USER BOOKING DATA"
                        SourceClassification.SIMULATION -> "SIMULATED TELEMETRY"
                        SourceClassification.UNKNOWN -> "FACT BASIS"
                    }
                    Badge(
                        containerColor = sourcePillColor,
                        contentColor = Color.White
                    ) {
                        Text(sourceText, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimulatorScreen(viewModel: RailwayViewModel) {
    val trains by viewModel.trains.collectAsState()
    val activeNumber by viewModel.activeTrainNumber.collectAsState()

    val train = trains.find { it.number == activeNumber } ?: trains.first()

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        TopAppBar(
            title = { Text("SIMULATOR CONTROL CENTER", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )

        // Banner Warning
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(AmberAlert.copy(alpha = 0.15f))
                .border(1.dp, AmberAlert)
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.SettingsSuggest, "Simulator", tint = AmberAlert)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("SIMULATED NETWORK EVENT MODERATOR", fontWeight = FontWeight.Bold, color = AmberAlert, fontSize = 12.sp)
                    Text("Manually inject delays, cancellations, or advance the active route to test app reactive states.", fontSize = 11.sp, color = Color.DarkGray)
                }
            }
        }

        // Selection
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("SELECT TARGET TRAIN FOR EVENT", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                trains.forEach { t ->
                    FilterChip(
                        selected = activeNumber == t.number,
                        onClick = { viewModel.selectActiveTrain(t.number) },
                        label = { Text("${t.number} - ${t.name}") }
                    )
                }
            }

            // Current State Summary Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("TELEMETRY STATE: ${train.number}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Canceled: ${train.isCanceled}", fontSize = 13.sp)
                    Text("Delay accumulated: ${train.delayMinutes} minutes", fontSize = 13.sp)
                    Text(
                        "Journey Milestone Stop Index: ${train.currentStopIndex} (${
                            if (train.currentStopIndex == -1) "Departed Origin"
                            else if (train.currentStopIndex >= train.stops.size) "Arrived Terminal"
                            else "Halted at " + train.stops[train.currentStopIndex].stationName
                        })",
                        fontSize = 13.sp
                    )
                }
            }

            // Moderator Controls Row Grid
            Text("TELEMETRY MODERATION KEYS", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
            
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.advanceActiveJourney(train.number) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
                    ) {
                        Text("ADVANCE HALT", fontSize = 11.sp)
                    }
                    Button(
                        onClick = { viewModel.addDelay(train.number, 5) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronAccent)
                    ) {
                        Text("+5 MIN DELAY", fontSize = 11.sp)
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.addDelay(train.number, 30) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronAccent)
                    ) {
                        Text("+30 MIN DELAY", fontSize = 11.sp)
                    }
                    Button(
                        onClick = { viewModel.cancelTrain(train.number) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = CarriageRed)
                    ) {
                        Text("CANCEL TRAIN", fontSize = 11.sp)
                    }
                }

                Button(
                    onClick = { viewModel.resetTrainSimulation(train.number) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                ) {
                    Text("RESET TRAIN TELEMETRY", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val isOffline by viewModel.isOfflineMode.collectAsState()
    val savedPassengers by viewModel.savedPassengers.collectAsState()

    var showAddProfileDialog by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf("") }
    var ageInput by remember { mutableStateOf("") }
    var genderInput by remember { mutableStateOf("Male") }
    var berthInput by remember { mutableStateOf("Lower") }

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        TopAppBar(
            title = { Text(LocalizedStrings.get("profile", lang).uppercase(), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )

        // General Info Panel
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ACCOUNT COMPILATION", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("T", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("Tom", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Official account binding active", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }

        // Saved passengers Profiles
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("MY PRE-SAVED PASSENGERS", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
                IconButton(onClick = { showAddProfileDialog = true }) {
                    Icon(Icons.Default.PersonAdd, "Add Passenger", tint = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            savedPassengers.forEach { p ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color.LightGray)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(p.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Age: ${p.age} · Gender: ${p.gender} · Berth: ${p.preferredBerth}", fontSize = 12.sp, color = Color.Gray)
                        }
                        IconButton(onClick = { viewModel.removeProfilePassenger(p.id) }) {
                            Icon(Icons.Default.Delete, "Delete Profile", tint = CarriageRed)
                        }
                    }
                }
            }
        }

        // Toggles & Preferences Panel
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("APPLICATION PREFERENCES", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)

            // Offline Mode Toggle
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Offline Simulation Mode", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Loads saved tickets offline when connection is poor.", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(checked = isOffline, onCheckedChange = { viewModel.toggleOfflineMode() })
                }
            }

            // Language select
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Language Selector", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Switch between English and Devanagari Hindi.", fontSize = 11.sp, color = Color.Gray)
                    }
                    Button(onClick = { viewModel.toggleLanguage() }) {
                        Text(if (lang == AppLanguage.ENGLISH) "हिन्दी" else "ENGLISH")
                    }
                }
            }

            // Privacy Center
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("PRIVACY CENTRE", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Secure storage, continuous location collection disabled. Tokens refreshed periodically.", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }
    }

    // Add Profile Dialogue
    if (showAddProfileDialog) {
        AlertDialog(
            onDismissRequest = { showAddProfileDialog = false },
            title = { Text("ADD PASSENGER PROFILE") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text("Full Name") })
                    OutlinedTextField(value = ageInput, onValueChange = { ageInput = it }, label = { Text("Age") })
                    OutlinedTextField(value = genderInput, onValueChange = { genderInput = it }, label = { Text("Gender (Male/Female/Other)") })
                    OutlinedTextField(value = berthInput, onValueChange = { berthInput = it }, label = { Text("Preferred Berth (Lower/Upper/Side)") })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nameInput.isNotEmpty() && ageInput.isNotEmpty()) {
                            viewModel.addProfilePassenger(
                                nameInput,
                                ageInput.toIntOrNull() ?: 30,
                                genderInput,
                                berthInput
                            )
                            showAddProfileDialog = false
                            nameInput = ""
                            ageInput = ""
                        }
                    }
                ) {
                    Text("SAVE PROFILE")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddProfileDialog = false }) {
                    Text("CANCEL")
                }
            }
        )
    }
}
