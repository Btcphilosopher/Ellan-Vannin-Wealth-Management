package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RailwayViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = RailwayRepository(application)

    // --- Active Screen Routing ---
    // Screens: HOME, SEARCH_RESULTS, TRAIN_DETAIL, BOOKING_FLOW, LIVE_TRACK, PNR_STATUS, TICKETS, STATIONS, SERVICES, CHAT, SIMULATOR, PROFILE
    private val _currentScreen = MutableStateFlow("HOME")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    private val screenStack = mutableListOf<String>()

    fun navigateTo(screen: String) {
        screenStack.add(_currentScreen.value)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (screenStack.isNotEmpty()) {
            _currentScreen.value = screenStack.removeAt(screenStack.size - 1)
            return true
        }
        return false
    }

    // --- Language Selection ---
    private val _language = MutableStateFlow(AppLanguage.ENGLISH)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    fun toggleLanguage() {
        _language.value = if (_language.value == AppLanguage.ENGLISH) AppLanguage.HINDI else AppLanguage.ENGLISH
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
    }

    // --- Global Data Flows from Repos ---
    val trains = repository.trains
    val tickets = repository.tickets
    val refunds = repository.refunds
    val savedPassengers = repository.savedPassengers
    val systemAlerts = repository.systemAlerts
    val isOfflineMode = repository.isOfflineMode
    val activeTrainNumber = repository.activeTrainNumber
    val chatMessages = repository.chatMessages

    // --- Search Inputs ---
    val searchFromCode = MutableStateFlow("NDLS")
    val searchToCode = MutableStateFlow("MMCT")
    val searchDate = MutableStateFlow("Tomorrow, 27 Oct")
    val searchPassengersCount = MutableStateFlow(1)
    val searchClassCode = MutableStateFlow("2A")
    val searchQuota = MutableStateFlow("GENERAL")

    // --- Search Results State ---
    private val _searchResults = MutableStateFlow<List<Train>>(emptyList())
    val searchResults: StateFlow<List<Train>> = _searchResults.asStateFlow()

    fun executeTrainSearch() {
        _searchResults.value = repository.searchTrains(
            searchFromCode.value,
            searchToCode.value,
            searchDate.value,
            searchPassengersCount.value,
            searchClassCode.value,
            searchQuota.value
        )
        navigateTo("SEARCH_RESULTS")
    }

    // --- Selected Train / Station for details ---
    private val _selectedTrain = MutableStateFlow<Train?>(null)
    val selectedTrain: StateFlow<Train?> = _selectedTrain.asStateFlow()

    fun selectTrain(train: Train) {
        _selectedTrain.value = train
        navigateTo("TRAIN_DETAIL")
    }

    private val _selectedStation = MutableStateFlow<Station?>(null)
    val selectedStation: StateFlow<Station?> = _selectedStation.asStateFlow()

    fun selectStationByCode(code: String) {
        _selectedStation.value = repository.getStation(code)
        navigateTo("STATIONS")
    }

    // --- Booking Flow State ---
    private val _bookingPassengers = MutableStateFlow<List<Passenger>>(emptyList())
    val bookingPassengers: StateFlow<List<Passenger>> = _bookingPassengers.asStateFlow()

    private val _bookingMealPreference = MutableStateFlow("Veg Meal")
    val bookingMealPreference: StateFlow<String> = _bookingMealPreference.asStateFlow()

    private val _bookingBerthPreference = MutableStateFlow("Lower")
    val bookingBerthPreference: StateFlow<String> = _bookingBerthPreference.asStateFlow()

    private val _lastBookedTicket = MutableStateFlow<Ticket?>(null)
    val lastBookedTicket: StateFlow<Ticket?> = _lastBookedTicket.asStateFlow()

    fun startBooking(train: Train) {
        _selectedTrain.value = train
        // Pre-fill with user default from saved profiles if exists
        val defaults = savedPassengers.value.take(searchPassengersCount.value)
        _bookingPassengers.value = if (defaults.isNotEmpty()) defaults else listOf(
            Passenger("temp", "Tom", 31, "Male", "Lower", "Veg Meal")
        )
        navigateTo("BOOKING_FLOW")
    }

    fun setBookingMeal(meal: String) {
        _bookingMealPreference.value = meal
    }

    fun setBookingBerth(berth: String) {
        _bookingBerthPreference.value = berth
    }

    fun updateBookingPassengers(list: List<Passenger>) {
        _bookingPassengers.value = list
    }

    fun finalizeBooking(totalFare: Int) {
        val train = _selectedTrain.value ?: return
        val ticket = repository.bookTicket(
            train.number,
            train.fromStationCode,
            train.toStationCode,
            searchDate.value,
            searchClassCode.value,
            _bookingPassengers.value.map { p ->
                p.copy(
                    preferredBerth = _bookingBerthPreference.value,
                    preferredFood = _bookingMealPreference.value
                )
            },
            totalFare
        )
        _lastBookedTicket.value = ticket
        navigateTo("BOOKING_CONFIRMED")
    }

    // --- Cancellation & Refund ---
    fun cancelActiveTicket(pnr: String) {
        repository.cancelTicket(pnr)
    }

    fun fileTdr(pnr: String, reason: String) {
        repository.submitTdr(pnr, reason)
    }

    // --- Saved Passengers ---
    fun addProfilePassenger(name: String, age: Int, gender: String, berth: String) {
        val newP = Passenger(
            id = "p_" + System.currentTimeMillis(),
            name = name,
            age = age,
            gender = gender,
            preferredBerth = berth,
            preferredFood = "Veg Meal"
        )
        repository.addPassenger(newP)
    }

    fun removeProfilePassenger(id: String) {
        repository.deletePassenger(id)
    }

    // --- Chat Service ---
    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    fun sendChatPrompt(prompt: String) {
        if (prompt.isBlank()) return
        _isChatLoading.value = true
        viewModelScope.launch {
            repository.sendChatMessage(prompt)
            _isChatLoading.value = false
        }
    }

    fun clearChat() {
        repository.clearChat()
    }

    // --- Offline Status ---
    fun toggleOfflineMode() {
        repository.setOfflineMode(!isOfflineMode.value)
    }

    // --- Simulation Operations ---
    fun selectActiveTrain(trainNumber: String) {
        repository.selectActiveTrain(trainNumber)
    }

    fun advanceActiveJourney(trainNumber: String) {
        repository.advanceJourneyStep(trainNumber)
    }

    fun addDelay(trainNumber: String, mins: Int) {
        repository.simulateDelay(trainNumber, mins)
    }

    fun cancelTrain(trainNumber: String) {
        repository.simulateCancellation(trainNumber)
    }

    fun updatePlatform(trainNumber: String, stopIndex: Int, platform: Int) {
        repository.simulatePlatformChange(trainNumber, stopIndex, platform)
    }

    fun resetTrainSimulation(trainNumber: String) {
        repository.resetJourney(trainNumber)
    }
}
