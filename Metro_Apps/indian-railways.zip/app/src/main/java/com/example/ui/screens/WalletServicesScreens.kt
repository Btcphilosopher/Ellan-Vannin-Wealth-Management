package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.RailwayViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketsScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val tickets by viewModel.tickets.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Upcoming, 1: Completed, 2: Cancelled
    var ticketToCancel by remember { mutableStateOf<Ticket?>(null) }

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp)
    ) {
        TopAppBar(
            title = { Text(LocalizedStrings.get("tickets", lang), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )

        // Wallet Tabs
        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                Text("UPCOMING", modifier = Modifier.padding(16.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                Text("COMPLETED", modifier = Modifier.padding(16.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) {
                Text("CANCELLED", modifier = Modifier.padding(16.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        // Filter tickets based on tab status
        val filteredTickets = tickets.filter { ticket ->
            when (selectedTab) {
                0 -> ticket.status == "CONFIRMED"
                1 -> ticket.status == "COMPLETED"
                else -> ticket.status == "CANCELLED"
            }
        }

        if (filteredTickets.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ConfirmationNumber, "No Tickets", modifier = Modifier.size(64.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("No tickets found in this wallet category.", fontWeight = FontWeight.Medium, color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredTickets) { ticket ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color.LightGray),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "PNR: ${ticket.pnr}",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 14.sp
                                )
                                Badge(
                                    containerColor = if (ticket.status == "CONFIRMED") ForestGreen else CarriageRed,
                                    contentColor = Color.White
                                ) {
                                    Text(ticket.status, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp), fontSize = 9.sp)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "${ticket.trainNumber} - ${ticket.trainName}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "${ticket.fromStation} → ${ticket.toStation}",
                                fontWeight = FontWeight.Medium,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Date: ${ticket.date} · Class: ${ticket.classCode}",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            // Barcode Representation
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .background(Color.White)
                                    .border(1.dp, Color.LightGray),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(0.9f),
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    // Symmetrical black stripes representing real railway barcode
                                    listOf(3, 1, 4, 1, 2, 5, 2, 1, 3, 1, 4, 2, 1, 3).forEach { weight ->
                                        Box(
                                            modifier = Modifier
                                                .width(weight.dp)
                                                .fillMaxHeight()
                                                .background(Color.Black)
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            if (ticket.status == "CONFIRMED") {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    OutlinedButton(
                                        onClick = { ticketToCancel = ticket },
                                        border = BorderStroke(1.dp, CarriageRed),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CarriageRed),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Icon(Icons.Default.CancelPresentation, "Cancel", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("CANCEL JOURNEY", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Cancellation confirmation box
    if (ticketToCancel != null) {
        val refundEstimate = (ticketToCancel!!.totalFare * 0.85).toInt()
        val penalty = ticketToCancel!!.totalFare - refundEstimate
        AlertDialog(
            onDismissRequest = { ticketToCancel = null },
            title = { Text("CANCEL TICKET CONFIRMATION") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Are you sure you want to cancel PNR ${ticketToCancel!!.pnr}?")
                    Text("Cancellation penalty rules will apply.", fontSize = 11.sp, color = Color.Gray)
                    Divider()
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Amount Paid:")
                        Text("₹${ticketToCancel!!.totalFare}")
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Cancellation Charge (15%):", color = CarriageRed)
                        Text("-₹$penalty", color = CarriageRed)
                    }
                    Divider()
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ESTIMATED REFUND:", fontWeight = FontWeight.Bold)
                        Text("₹$refundEstimate", fontWeight = FontWeight.Bold, color = ForestGreen)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.cancelActiveTicket(ticketToCancel!!.pnr)
                        ticketToCancel = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CarriageRed)
                ) {
                    Text("CONFIRM CANCELLATION", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { ticketToCancel = null }) {
                    Text("CLOSE")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationsHubScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val station by viewModel.selectedStation.collectAsState()

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    if (station == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No station selected")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        TopAppBar(
            title = {
                Column {
                    Text(text = "${station!!.name} (${station!!.code})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                    Text(text = "${station!!.city} Terminal", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                }
            },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )

        // Schematic Demonstration Panel
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("SCHEMATIC DEMONSTRATION", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(12.dp))
                // Platform layout schematic representation
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..4).forEach { p ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Platform $p", fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.width(70.dp))
                            // Train track visual represent
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(4.dp)
                                    .background(Color.Gray)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (p % 2 == 0) "Track occupied" else "Free", fontSize = 10.sp, color = if (p % 2 == 0) CarriageRed else ForestGreen)
                        }
                    }
                }
            }
        }

        // Amenities
        Column(modifier = Modifier.padding(16.dp)) {
            Text("STATION SERVICES & CONNECTIONS", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(8.dp))

            // Amenities flow lists
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color.LightGray)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row {
                        Icon(Icons.Default.DirectionsTransit, "Metro", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Metro Connections", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(station!!.metroConnections, fontSize = 12.sp)
                        }
                    }
                    Divider()
                    Row {
                        Icon(Icons.Default.LocalTaxi, "Taxi", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Prepaid Taxis & Ride-hailing", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(station!!.taxiServices, fontSize = 12.sp)
                        }
                    }
                    Divider()
                    Row {
                        Icon(Icons.Default.AccessibilityNew, "Access", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Accessibility Facilities", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(station!!.accessibility.joinToString(", "), fontSize = 12.sp)
                        }
                    }
                    Divider()
                    Row {
                        Icon(Icons.Default.Hotel, "Hotels", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Nearby Hotels", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(station!!.nearbyHotels.joinToString(", "), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServicesHubScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val refunds by viewModel.refunds.collectAsState()

    var showFoodDialog by remember { mutableStateOf(false) }
    var showTdrDialog by remember { mutableStateOf(false) }

    var pnrInput by remember { mutableStateOf("") }
    var tdrReason by remember { mutableStateOf("") }

    var selectedMeal by remember { mutableStateOf("Vande Bharat Saffron Thali") }

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        TopAppBar(
            title = { Text(LocalizedStrings.get("services", lang).uppercase(), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )

        // Services Action Panel
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // E-Catering Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color.LightGray)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("E-CATERING ON-BOARD MEALS", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Order freshly prepared thalis directly to your seat", fontSize = 11.sp, color = Color.Gray)
                        }
                        Icon(Icons.Default.Fastfood, "Food", tint = SaffronAccent, modifier = Modifier.size(32.dp))
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { showFoodDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronAccent)
                    ) {
                        Text("ORDER FRESH MEAL", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // TDR submission
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color.LightGray)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("REFUNDS & TDR ARCHIVE", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("File Ticket Deposit Receipts for delays and disruptions", fontSize = 11.sp, color = Color.Gray)
                        }
                        Icon(Icons.Default.CurrencyRupee, "Refund", tint = CarriageBlue, modifier = Modifier.size(32.dp))
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = { showTdrDialog = true }) {
                        Text("FILE NEW TDR (REFUND)", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Show Filed TDR status
            if (refunds.isNotEmpty()) {
                Text(
                    text = "ACTIVE FILED REFUND CLAIMS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                refunds.forEach { req ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Ref: ${req.referenceNumber}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Badge(containerColor = ForestGreen, contentColor = Color.White) {
                                    Text(req.status, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp))
                                }
                            }
                            Text("PNR: ${req.ticketPnr} · Reason: ${req.reason}", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    // E Catering Food Dialogue
    if (showFoodDialog) {
        var foodOrdered by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showFoodDialog = false },
            title = { Text("E-CATERING SEAT DELIVERY") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (!foodOrdered) {
                        Text("Select an authentic local Indian thali to deliver directly to your coach on arrival.")
                        listOf(
                            "Vande Bharat Saffron Thali" to "₹180",
                            "Classic Maharaja Veg Thali" to "₹150",
                            "Premium Egg Biryani Bowl" to "₹140"
                        ).forEach { (thali, price) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedMeal = thali }
                                    .background(if (selectedMeal == thali) SaffronAccent.copy(alpha = 0.1f) else Color.Transparent)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(thali, fontWeight = FontWeight.Bold)
                                Text(price, color = SaffronAccent)
                            }
                        }
                    } else {
                        Text(
                            text = "ORDER CONFIRMED!\n\nYour meal: $selectedMeal has been scheduled for seat delivery. It will be collected and delivered to Coach A2, Berth 31.",
                            fontWeight = FontWeight.Bold,
                            color = ForestGreen,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            },
            confirmButton = {
                if (!foodOrdered) {
                    Button(
                        onClick = { foodOrdered = true },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronAccent)
                    ) {
                        Text("PLACE ORDER (SIMULATED)")
                    }
                } else {
                    Button(onClick = { showFoodDialog = false }) {
                        Text("DONE")
                    }
                }
            },
            dismissButton = {
                if (!foodOrdered) {
                    TextButton(onClick = { showFoodDialog = false }) {
                        Text("CANCEL")
                    }
                }
            }
        )
    }

    // TDR Filing Dialog
    if (showTdrDialog) {
        AlertDialog(
            onDismissRequest = { showTdrDialog = false },
            title = { Text("FILE TICKET DEPOSIT RECEIPT") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select your eligible ticket PNR and disruption reason to submit an authorized TDR claim.")
                    OutlinedTextField(
                        value = pnrInput,
                        onValueChange = { pnrInput = it },
                        label = { Text("Enter 10-Digit PNR") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = tdrReason,
                        onValueChange = { tdrReason = it },
                        label = { Text("Disruption Reason (e.g. Train delayed >3h)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pnrInput.isNotEmpty() && tdrReason.isNotEmpty()) {
                            viewModel.fileTdr(pnrInput, tdrReason)
                            showTdrDialog = false
                        }
                    }
                ) {
                    Text("SUBMIT TDR CLAIM")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTdrDialog = false }) {
                    Text("CANCEL")
                }
            }
        )
    }
}
