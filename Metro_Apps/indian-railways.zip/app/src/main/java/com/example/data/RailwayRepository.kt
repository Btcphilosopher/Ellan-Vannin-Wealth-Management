package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class RailwayRepository(private val context: Context) {

    private val sharedPrefs: SharedPreferences = 
        context.getSharedPreferences("indian_railways_prefs", Context.MODE_PRIVATE)

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    // --- State Flows ---
    private val _trains = MutableStateFlow<List<Train>>(RailwayDataStore.INITIAL_TRAINS)
    val trains: StateFlow<List<Train>> = _trains.asStateFlow()

    private val _tickets = MutableStateFlow<List<Ticket>>(emptyList())
    val tickets: StateFlow<List<Ticket>> = _tickets.asStateFlow()

    private val _refunds = MutableStateFlow<List<RefundRequest>>(emptyList())
    val refunds: StateFlow<List<RefundRequest>> = _refunds.asStateFlow()

    private val _savedPassengers = MutableStateFlow<List<Passenger>>(emptyList())
    val savedPassengers: StateFlow<List<Passenger>> = _savedPassengers.asStateFlow()

    private val _systemAlerts = MutableStateFlow<List<SystemAlert>>(emptyList())
    val systemAlerts: StateFlow<List<SystemAlert>> = _systemAlerts.asStateFlow()

    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    // --- Active Journey Tracker ---
    private val _activeTrainNumber = MutableStateFlow<String?>("12951") // Mumbai Rajdhani by default
    val activeTrainNumber: StateFlow<String?> = _activeTrainNumber.asStateFlow()

    // --- Chat Flow ---
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                "init",
                "Namaste! I am RAIL ASSIST, your Indian Railways companion. How can I help you today?",
                false,
                SourceClassification.OFFICIAL_STATIC
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    // --- Retrofit & Gemini Client ---
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://generativelanguage.googleapis.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val geminiService = retrofit.create(GeminiApiService::class.java)

    init {
        loadData()
        seedInitialData()
    }

    private fun loadData() {
        // Load tickets
        val ticketsJson = sharedPrefs.getString("tickets", null)
        if (ticketsJson != null) {
            val type = Types.newParameterizedType(List::class.java, Ticket::class.java)
            val adapter = moshi.adapter<List<Ticket>>(type)
            try {
                _tickets.value = adapter.fromJson(ticketsJson) ?: emptyList()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Load passengers
        val passengersJson = sharedPrefs.getString("passengers", null)
        if (passengersJson != null) {
            val type = Types.newParameterizedType(List::class.java, Passenger::class.java)
            val adapter = moshi.adapter<List<Passenger>>(type)
            try {
                _savedPassengers.value = adapter.fromJson(passengersJson) ?: emptyList()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Load refunds
        val refundsJson = sharedPrefs.getString("refunds", null)
        if (refundsJson != null) {
            val type = Types.newParameterizedType(List::class.java, RefundRequest::class.java)
            val adapter = moshi.adapter<List<RefundRequest>>(type)
            try {
                _refunds.value = adapter.fromJson(refundsJson) ?: emptyList()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun seedInitialData() {
        // If passenger list is empty, seed a couple of passengers
        if (_savedPassengers.value.isEmpty()) {
            val list = listOf(
                Passenger("p1", "Tom", 31, "Male", "Lower", "Veg Meal", "A2", 31, "CNF"),
                Passenger("p2", "Arjun", 28, "Male", "Side Lower", "Non-Veg Meal", "A2", 32, "CNF")
            )
            _savedPassengers.value = list
            savePassengersToPrefs(list)
        }

        // Add default system alerts
        _systemAlerts.value = listOf(
            SystemAlert("Line Block on Agra-Bhopal Corridor", "Engineering work between AGC and VGLJ platforms will cause slight diversions tonight.", AlertType.ENGINEERING),
            SystemAlert("Weather Warning: Northern Fog", "Seasonal fog is expected near New Delhi (NDLS) next week. Expect minor schedules variations.", AlertType.WEATHER),
            SystemAlert("Catering Upgrade", "New organic e-catering meals are now available on all Vande Bharat corridors.", AlertType.INFO)
        )

        // Seed a demo upcoming ticket if none exists
        if (_tickets.value.isEmpty()) {
            val demoTicket = Ticket(
                pnr = "1234567890",
                trainNumber = "12951",
                trainName = "Mumbai Rajdhani",
                date = "27 OCT 2026",
                fromStation = "New Delhi (NDLS)",
                toStation = "Mumbai Central (MMCT)",
                classCode = "2A",
                passengers = listOf(_savedPassengers.value.first()),
                totalFare = 2845,
                status = "CONFIRMED",
                transactionId = "TXN" + Random.nextInt(100000, 999999)
            )
            val list = listOf(demoTicket)
            _tickets.value = list
            saveTicketsToPrefs(list)
        }
    }

    private fun saveTicketsToPrefs(list: List<Ticket>) {
        val type = Types.newParameterizedType(List::class.java, Ticket::class.java)
        val adapter = moshi.adapter<List<Ticket>>(type)
        sharedPrefs.edit().putString("tickets", adapter.toJson(list)).apply()
    }

    private fun savePassengersToPrefs(list: List<Passenger>) {
        val type = Types.newParameterizedType(List::class.java, Passenger::class.java)
        val adapter = moshi.adapter<List<Passenger>>(type)
        sharedPrefs.edit().putString("passengers", adapter.toJson(list)).apply()
    }

    private fun saveRefundsToPrefs(list: List<RefundRequest>) {
        val type = Types.newParameterizedType(List::class.java, RefundRequest::class.java)
        val adapter = moshi.adapter<List<RefundRequest>>(type)
        sharedPrefs.edit().putString("refunds", adapter.toJson(list)).apply()
    }

    // --- Offline Mode Toggle ---
    fun setOfflineMode(enabled: Boolean) {
        _isOfflineMode.value = enabled
    }

    // --- Station Search ---
    fun searchStations(query: String): List<Station> {
        if (query.isBlank()) return RailwayDataStore.STATIONS
        val cleaned = query.trim().uppercase()
        
        // Smart Aliasing
        val resolvedQuery = when (cleaned) {
            "DELHI" -> "NDLS"
            "BOMBAY", "MUMBAI" -> "MMCT"
            "CALCUTTA", "KOLKATA" -> "HWH"
            "BANGALORE" -> "SBC"
            "MADRAS" -> "MAS"
            "BENARAS", "KASHI" -> "BSB"
            else -> cleaned
        }

        return RailwayDataStore.STATIONS.filter {
            it.code.contains(resolvedQuery) ||
            it.name.uppercase().contains(cleaned) ||
            it.city.uppercase().contains(cleaned)
        }
    }

    fun getStation(code: String): Station? {
        return RailwayDataStore.STATIONS.find { it.code.equals(code, ignoreCase = true) }
    }

    // --- Train Search ---
    fun searchTrains(
        fromCode: String,
        toCode: String,
        date: String,
        passengersCount: Int,
        classCode: String,
        quota: String
    ): List<Train> {
        // Dynamic matching of train routes based on stopping points
        return _trains.value.filter { train ->
            val stops = train.stops
            val fromIndex = stops.indexOfFirst { it.stationCode.equals(fromCode, ignoreCase = true) }
            val toIndex = stops.indexOfFirst { it.stationCode.equals(toCode, ignoreCase = true) }
            fromIndex != -1 && toIndex != -1 && fromIndex < toIndex
        }
    }

    // --- Ticket Booking ---
    fun bookTicket(
        trainNumber: String,
        fromCode: String,
        toCode: String,
        date: String,
        classCode: String,
        passengersInput: List<Passenger>,
        fare: Int
    ): Ticket {
        val train = _trains.value.find { it.number == trainNumber } ?: _trains.value.first()
        val fromStationObj = getStation(fromCode)?.name ?: fromCode
        val toStationObj = getStation(toCode)?.name ?: toCode

        // Generate coach / seat details
        val coach = when (classCode) {
            "1A" -> "H" + Random.nextInt(1, 3)
            "2A" -> "A" + Random.nextInt(1, 4)
            "3A" -> "B" + Random.nextInt(1, 6)
            "3E" -> "M" + Random.nextInt(1, 4)
            "SL" -> "S" + Random.nextInt(1, 10)
            "CC" -> "C" + Random.nextInt(1, 5)
            else -> "D" + Random.nextInt(1, 3)
        }

        val allocatedPassengers = passengersInput.mapIndexed { idx, p ->
            p.copy(
                coach = coach,
                berth = Random.nextInt(1, 64),
                status = "CNF"
            )
        }

        val newTicket = Ticket(
            pnr = Random.nextLong(1000000000L, 9999999999L).toString(),
            trainNumber = train.number,
            trainName = train.name,
            date = date,
            fromStation = "$fromStationObj ($fromCode)",
            toStation = "$toStationObj ($toCode)",
            classCode = classCode,
            passengers = allocatedPassengers,
            totalFare = fare,
            transactionId = "TXN" + Random.nextInt(100000, 999999)
        )

        val updatedList = _tickets.value + newTicket
        _tickets.value = updatedList
        saveTicketsToPrefs(updatedList)
        return newTicket
    }

    // --- Cancel Ticket ---
    fun cancelTicket(pnr: String): Ticket? {
        val list = _tickets.value.toMutableList()
        val index = list.indexOfFirst { it.pnr == pnr }
        if (index != -1) {
            val oldTicket = list[index]
            val updatedTicket = oldTicket.copy(status = "CANCELLED")
            list[index] = updatedTicket
            _tickets.value = list
            saveTicketsToPrefs(list)

            // Emit a refund automatic request
            val refundEst = (oldTicket.totalFare * 0.85).toInt() // 15% cancellation charge
            val refundReq = RefundRequest(
                id = "REF" + Random.nextInt(10000, 99999),
                ticketPnr = pnr,
                reason = "Passenger request cancellation",
                estimatedRefund = refundEst,
                status = "SUBMITTED",
                referenceNumber = "REF-IND-" + Random.nextInt(1000000, 9999999)
            )
            val refundList = _refunds.value + refundReq
            _refunds.value = refundList
            saveRefundsToPrefs(refundList)

            return updatedTicket
        }
        return null
    }

    fun submitTdr(pnr: String, reason: String): RefundRequest {
        val req = RefundRequest(
            id = "REF" + Random.nextInt(10000, 99999),
            ticketPnr = pnr,
            reason = reason,
            estimatedRefund = 0, // Rules-based delayed
            status = "APPROVED",
            referenceNumber = "TDR-IND-" + Random.nextInt(1000000, 9999999)
        )
        val refundList = _refunds.value + req
        _refunds.value = refundList
        saveRefundsToPrefs(refundList)
        return req
    }

    // --- Saved Passengers Management ---
    fun addPassenger(passenger: Passenger) {
        val updatedList = _savedPassengers.value + passenger
        _savedPassengers.value = updatedList
        savePassengersToPrefs(updatedList)
    }

    fun deletePassenger(id: String) {
        val updatedList = _savedPassengers.value.filter { it.id != id }
        _savedPassengers.value = updatedList
        savePassengersToPrefs(updatedList)
    }

    // --- Digital Journey Simulator Actions ---
    fun selectActiveTrain(trainNumber: String) {
        _activeTrainNumber.value = trainNumber
    }

    fun simulateDelay(trainNumber: String, minutes: Int) {
        val updated = _trains.value.map {
            if (it.number == trainNumber) {
                it.copy(delayMinutes = it.delayMinutes + minutes)
            } else it
        }
        _trains.value = updated
    }

    fun simulateCancellation(trainNumber: String) {
        val updated = _trains.value.map {
            if (it.number == trainNumber) {
                it.copy(isCanceled = true)
            } else it
        }
        _trains.value = updated
    }

    fun simulatePlatformChange(trainNumber: String, stopIndex: Int, newPlatform: Int) {
        val updated = _trains.value.map {
            if (it.number == trainNumber) {
                val stopsCopy = it.stops.mapIndexed { idx, stop ->
                    if (idx == stopIndex) stop.copy(expectedPlatform = newPlatform) else stop
                }
                it.copy(stops = stopsCopy)
            } else it
        }
        _trains.value = updated
    }

    fun advanceJourneyStep(trainNumber: String) {
        val updated = _trains.value.map {
            if (it.number == trainNumber) {
                val nextIdx = if (it.currentStopIndex < it.stops.size) it.currentStopIndex + 1 else -1
                it.copy(currentStopIndex = nextIdx)
            } else it
        }
        _trains.value = updated
    }

    fun resetJourney(trainNumber: String) {
        val updated = _trains.value.map {
            if (it.number == trainNumber) {
                it.copy(currentStopIndex = -1, delayMinutes = 0, isCanceled = false)
            } else it
        }
        _trains.value = updated
    }

    // --- Conversational Assistant (RAIL ASSIST) ---
    suspend fun sendChatMessage(userText: String): Unit = withContext(Dispatchers.IO) {
        // 1. Add user message
        val userMsg = ChatMessage(
            id = "msg_" + System.currentTimeMillis(),
            text = userText,
            isUser = true,
            source = SourceClassification.USER_ACCOUNT
        )
        _chatMessages.value = _chatMessages.value + userMsg

        // 2. Query Gemini or run local rule engine
        val apiKey = try {
            com.example.BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        val hasRealApiKey = apiKey.isNotEmpty() && !apiKey.startsWith("MY_GEMINI_")

        val responseMsg = if (hasRealApiKey && !_isOfflineMode.value) {
            try {
                // Build simple chat prompt
                val contextPrompt = """
                    You are RAIL ASSIST, a smart conversational assistant for the Indian Railways passenger mobile app.
                    Your knowledge is grounded in Indian Railways codes (GNWL, RLWL, PQWL, RAC, TQWL), train services, and guidelines.
                    Answer the user professionally. Keep answers short, structured, and easy for a passenger to read on a phone.
                    
                    Here is the current state of our simulation for reference:
                    - Active user tickets in app: ${_tickets.value.map { "PNR:${it.pnr} from ${it.fromStation} to ${it.toStation} status:${it.status}" }}
                    - Running simulator train 12951 Mumbai Rajdhani current delay: ${_trains.value.find { it.number == "12951" }?.delayMinutes} minutes.
                    
                    User asked: $userText
                """.trimIndent()

                val request = GenerateContentRequest(
                    contents = listOf(Content(listOf(Part(contextPrompt))))
                )

                val response = geminiService.generateContent(apiKey, request)
                val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                    ?: "I'm having trouble retrieving live information. Please check your offline wallet."
                
                ChatMessage(
                    id = "msg_reply_" + System.currentTimeMillis(),
                    text = replyText,
                    isUser = false,
                    source = SourceClassification.LIVE
                )
            } catch (e: Exception) {
                // Fallback on network failure
                generateLocalFallbackReply(userText)
            }
        } else {
            // Local high-fidelity mock assistant that parses query strings and replies beautifully
            generateLocalFallbackReply(userText)
        }

        _chatMessages.value = _chatMessages.value + responseMsg
    }

    private fun generateLocalFallbackReply(userText: String): ChatMessage {
        val textLower = userText.lowercase()
        val (reply, source) = when {
            textLower.contains("pnr") || textLower.contains("status") -> {
                val demoTicket = _tickets.value.firstOrNull()
                if (demoTicket != null) {
                    Pair(
                        "Your current booking status for Train ${demoTicket.trainNumber} (${demoTicket.trainName}) under PNR *${demoTicket.pnr}* is **${demoTicket.status}**. Coach: A2, Berth: 31 (Lower). Your journey is scheduled on ${demoTicket.date}.",
                        SourceClassification.USER_ACCOUNT
                    )
                } else {
                    Pair(
                        "You don't have any booked journeys loaded in your Ticket Wallet right now. Use the Book screen to search and reserve a seat.",
                        SourceClassification.OFFICIAL_STATIC
                    )
                }
            }
            textLower.contains("rac") -> {
                Pair(
                    "**RAC (Reservation Against Cancellation)** means you have a sitting seat and are allowed to board the train. You share a side lower berth with another passenger. If a confirmed (CNF) ticket is cancelled, your seat will be automatically upgraded to a full sleeping berth by the TTE.",
                    SourceClassification.OFFICIAL_STATIC
                )
            }
            textLower.contains("gnwl") -> {
                Pair(
                    "**GNWL (General Waitlist)** has the highest priority of all waiting list quotas. Tickets are issued when you board at the train's originating station or nearby. It clears the fastest when people cancel.",
                    SourceClassification.OFFICIAL_STATIC
                )
            }
            textLower.contains("where is") || textLower.contains("delay") || textLower.contains("platform") || textLower.contains("12951") -> {
                val train = _trains.value.find { it.number == "12951" }
                if (train != null) {
                    val delay = train.delayMinutes
                    val delayStr = if (delay == 0) "on time" else "$delay minutes late"
                    val currentStop = if (train.currentStopIndex in 0 until train.stops.size) {
                        "currently at ${train.stops[train.currentStopIndex].stationName}"
                    } else "departed from New Delhi (NDLS)"
                    Pair(
                        "Train 12951 (Mumbai Rajdhani) is **$currentStop** and running **$delayStr**. Scheduled platform is Platform ${train.stops.first().expectedPlatform} at New Delhi (NDLS). This is simulated telemetry.",
                        SourceClassification.SIMULATION
                    )
                } else {
                    Pair(
                        "Train 12951 route tracking is currently offline. Check the Simulator panel to run the train journey.",
                        SourceClassification.OFFICIAL_STATIC
                    )
                }
            }
            textLower.contains("delhi") || textLower.contains("mumbai") || textLower.contains("train") -> {
                Pair(
                    "We have high-speed daily premium services operating between New Delhi (NDLS) and Mumbai Central (MMCT):\n- 12951 Mumbai Rajdhani (Departs 16:55)\n- 12952 NDLS Rajdhani (Departs 17:00)\nSearch for trains on the home screen to book now.",
                    SourceClassification.OFFICIAL_STATIC
                )
            }
            else -> {
                Pair(
                    "I am RAIL ASSIST, your on-board digital coordinator. I can explain railway terminologies (RAC, GNWL, WL), check your PNR status, find platform and schedule delays, or assist in e-catering meal bookings.",
                    SourceClassification.OFFICIAL_STATIC
                )
            }
        }

        return ChatMessage(
            id = "msg_reply_" + System.currentTimeMillis(),
            text = reply,
            isUser = false,
            source = source
        )
    }

    fun clearChat() {
        _chatMessages.value = listOf(
            ChatMessage(
                "init",
                "Namaste! Chat cleared. How can I assist you with your train journey today?",
                false,
                SourceClassification.OFFICIAL_STATIC
            )
        )
    }
}

// --- Moshi Classes for Retrofit ---
interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

data class Part(val text: String)
data class Content(val parts: List<Part>)
data class GenerationConfig(val responseMimeType: String? = null, val temperature: Float? = null)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

data class PartResponse(val text: String? = null)
data class ContentResponse(val parts: List<PartResponse>? = null)
data class Candidate(val content: ContentResponse? = null)
data class GenerateContentResponse(val candidates: List<Candidate>? = null)
