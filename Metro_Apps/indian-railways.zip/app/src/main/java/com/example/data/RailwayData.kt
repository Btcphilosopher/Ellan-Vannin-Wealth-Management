package com.example.data

import androidx.compose.ui.graphics.Color

enum class AppLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    HINDI("hi", "हिन्दी")
}

object LocalizedStrings {
    private val en = mapOf(
        "app_title" to "INDIAN RAILWAYS",
        "subtitle" to "One railway. One journey. One app.",
        "where_to" to "WHERE TO?",
        "from" to "From",
        "to" to "To",
        "date" to "Date",
        "passengers" to "Passengers",
        "class" to "Class",
        "quota" to "Quota",
        "search_trains" to "SEARCH TRAINS",
        "your_next_journey" to "YOUR NEXT JOURNEY",
        "live_railway" to "LIVE RAILWAY",
        "rail_assist" to "RAIL ASSIST",
        "home" to "Home",
        "journeys" to "Journeys",
        "live" to "Live Track",
        "tickets" to "My Tickets",
        "profile" to "Profile",
        "services" to "Services",
        "stations" to "Stations",
        "admin" to "Simulator",
        "pnr" to "PNR Status",
        "view_journey" to "VIEW JOURNEY",
        "departure" to "Departure",
        "arrival" to "Arrival",
        "duration" to "Duration",
        "train" to "Train",
        "status" to "Status",
        "passenger_list" to "Passenger List",
        "confirm" to "Confirmed",
        "cancel" to "Cancel",
        "refund" to "Refund",
        "payment" to "Payment",
        "book_now" to "BOOK TICKET",
        "seat_avail" to "Seat Availability",
        "fare" to "Fare Breakup",
        "total_fare" to "Total Fare",
        "upi_pay" to "Pay via UPI",
        "card_pay" to "Pay via Debit/Credit Card",
        "demo_data_warn" to "DEMO DATA — NOT LIVE INDIAN RAILWAYS INFORMATION",
        "low_conn_warn" to "CACHED — OFFLINE MODE",
        "live_conn" to "LIVE UPDATES ACTIVE",
        "tatkal_opens" to "TATKAL OPENS AT 10:00 AM",
        "prepare_to_leave" to "Prepare to leave the train. Your stop is next!",
        "coach_pos" to "Coach Position",
        "platform" to "Platform",
        "on_time" to "ON TIME",
        "delayed" to "DELAYED",
        "canceled" to "CANCELED"
    )

    private val hi = mapOf(
        "app_title" to "भारतीय रेलवे",
        "subtitle" to "एक रेलवे। एक यात्रा। एक ऐप।",
        "where_to" to "कहाँ जाना है?",
        "from" to "से",
        "to" to "तक",
        "date" to "तारीख",
        "passengers" to "यात्री संख्या",
        "class" to "श्रेणी",
        "quota" to "कोटा",
        "search_trains" to "ट्रेनें खोजें",
        "your_next_journey" to "आपकी अगली यात्रा",
        "live_railway" to "लाइव रेलवे अपडेट",
        "rail_assist" to "रेल असिस्ट (AI)",
        "home" to "होम",
        "journeys" to "यात्राएं",
        "live" to "लाइव ट्रैक",
        "tickets" to "मेरे टिकट",
        "profile" to "प्रोफ़ाइल",
        "services" to "सेवाएं",
        "stations" to "स्टेशन",
        "admin" to "सिम्युलेटर",
        "pnr" to "पीएनआर स्थिति",
        "view_journey" to "यात्रा देखें",
        "departure" to "प्रस्थान",
        "arrival" to "आगमन",
        "duration" to "अवधि",
        "train" to "ट्रेन",
        "status" to "स्थिति",
        "passenger_list" to "यात्री सूची",
        "confirm" to "पुष्टि की गई",
        "cancel" to "रद्द करें",
        "refund" to "रिफंड",
        "payment" to "भुगतान",
        "book_now" to "टिकट बुक करें",
        "seat_avail" to "सीट उपलब्धता",
        "fare" to "किराया विवरण",
        "total_fare" to "कुल किराया",
        "upi_pay" to "UPI द्वारा भुगतान करें",
        "card_pay" to "डेबिट/क्रेडिट कार्ड द्वारा भुगतान",
        "demo_data_warn" to "डेमो डेटा — लाइव भारतीय रेलवे की जानकारी नहीं है",
        "low_conn_warn" to "कैश किया गया — ऑफ़लाइन मोड",
        "live_conn" to "लाइव अपडेट सक्रिय",
        "tatkal_opens" to "तत्काल बुकिंग सुबह 10:00 बजे खुलती है",
        "prepare_to_leave" to "ट्रेन से उतरने की तैयारी करें। आपका स्टेशन अगला है!",
        "coach_pos" to "कोच की स्थिति",
        "platform" to "प्लेटफॉर्म",
        "on_time" to "समय पर",
        "delayed" to "देरी से",
        "canceled" to "रद्द"
    )

    fun get(key: String, lang: AppLanguage): String {
        val dict = if (lang == AppLanguage.HINDI) hi else en
        return dict[key] ?: en[key] ?: key
    }
}

data class Station(
    val code: String,
    val name: String,
    val city: String,
    val platforms: Int,
    val facilities: List<String>,
    val accessibility: List<String>,
    val metroConnections: String,
    val taxiServices: String,
    val nearbyHotels: List<String>
)

data class TrainStop(
    val stationCode: String,
    val stationName: String,
    val arrivalTime: String,
    val departureTime: String,
    val stopMinutes: Int,
    val distanceKm: Int,
    val expectedPlatform: Int
)

data class Train(
    val number: String,
    val name: String,
    val type: String, // Rajdhani, Shatabdi, Vande Bharat, Express, etc.
    val runningDays: String, // e.g., "Daily", "M, W, F"
    val stops: List<TrainStop>,
    val classes: List<String>, // 1A, 2A, 3A, SL, etc.
    val amenities: List<String>,
    // Dynamic values that can change in simulation:
    var delayMinutes: Int = 0,
    var isCanceled: Boolean = false,
    var currentStopIndex: Int = -1, // -1 means departed/not started, stops.size means arrived
    var currentPlatform: Int = -1
) {
    val fromStationCode: String get() = stops.firstOrNull()?.stationCode ?: ""
    val toStationCode: String get() = stops.lastOrNull()?.stationCode ?: ""
    val departureTime: String get() = stops.firstOrNull()?.departureTime ?: "00:00"
    val arrivalTime: String get() = stops.lastOrNull()?.arrivalTime ?: "00:00"
    
    val totalDuration: String get() {
        val start = stops.firstOrNull() ?: return "0h"
        val end = stops.lastOrNull() ?: return "0h"
        val diffMin = end.distanceKm * 60 / 75 // Assuming avg speed 75 km/h
        val hrs = diffMin / 60
        val mins = diffMin % 60
        return "${hrs}h ${mins}m"
    }
}

data class Passenger(
    val id: String,
    val name: String,
    val age: Int,
    val gender: String,
    val preferredBerth: String,
    val preferredFood: String,
    var coach: String = "",
    var berth: Int = 0,
    var status: String = "CNF" // CNF, RAC, WL, CAN
)

data class Ticket(
    val pnr: String,
    val trainNumber: String,
    val trainName: String,
    val date: String,
    val fromStation: String,
    val toStation: String,
    val classCode: String,
    val passengers: List<Passenger>,
    val totalFare: Int,
    var status: String = "CONFIRMED", // CONFIRMED, CANCELLED, RAC, WAITLIST
    val transactionId: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val source: SourceClassification = SourceClassification.OFFICIAL_STATIC,
    val timestamp: Long = System.currentTimeMillis()
)

enum class SourceClassification {
    LIVE,
    OFFICIAL_STATIC,
    USER_ACCOUNT,
    SIMULATION,
    UNKNOWN
}

data class SystemAlert(
    val title: String,
    val message: String,
    val type: AlertType,
    val timestamp: Long = System.currentTimeMillis()
)

enum class AlertType {
    WEATHER,
    ENGINEERING,
    DELAY,
    INFO
}

data class RefundRequest(
    val id: String,
    val ticketPnr: String,
    val reason: String,
    val estimatedRefund: Int,
    val status: String, // SUBMITTED, APPROVED, REFUNDED
    val referenceNumber: String,
    val timestamp: Long = System.currentTimeMillis()
)

object RailwayAbbreviationExplanations {
    val abbreviations = mapOf(
        "GNWL" to "General Waitlist - Highest priority waitlist, has the maximum chance of confirmation. Created when a journey begins at the train's originating station.",
        "RLWL" to "Remote Location Waitlist - Issued for intermediate stations. Confirmation depends on passengers from the originating station booking to your boarding point cancelling their tickets.",
        "PQWL" to "Pooled Quota Waitlist - Shared by several small intermediate stations. Confirmations depend on cancellations of bookings originating from these specific stations.",
        "RAC" to "Reservation Against Cancellation - You are allocated a shared side-lower berth. You can board the train and get a sitting seat. If a confirmed passenger cancels, you get a full sleeper berth.",
        "TQWL" to "Tatkal Waitlist - Issued when Tatkal quota tickets sell out. Confirms directly from Tatkal cancellations, and does not progress to RAC status."
    )
}

object QuotaTypes {
    val list = listOf(
        "GENERAL" to "General Quota - Open to all passengers.",
        "TATKAL" to "Tatkal Quota - Premium booking that opens 1 day before departure for urgent journeys.",
        "PREMIUM TATKAL" to "Premium Tatkal - Dynamic pricing Tatkal tickets.",
        "LADIES" to "Ladies Quota - Reserved compartments for solo women or women with children.",
        "SENIOR CITIZEN" to "Senior Citizen Quota - Lower berths reserved for elderly passengers.",
        "DIVYANGJAN" to "Divyangjan Quota - Reserved berths and concessions for differently-abled passengers."
    )
}

object RailwayDataStore {
    val STATIONS = listOf(
        Station("NDLS", "New Delhi", "Delhi", 16, 
            facilities = listOf("Premium Lounge", "AC Waiting Halls", "Food Plaza", "WiFi", "Escalators", "Cloak Room", "Executive Lounge"),
            accessibility = listOf("Wheelchair Ramps", "Tactile Paths", "Accessible Toilets", "Battery Cars"),
            metroConnections = "Yellow Line & Airport Express Metro (Direct entry)",
            taxiServices = "Prepaid Taxi, App Cab pickups (Ola/Uber Lounge)",
            nearbyHotels = listOf("Hotel Rail Plaza (inside)", "The Connaught", "Radisson Blu Marina")
        ),
        Station("MMCT", "Mumbai Central", "Mumbai", 9, 
            facilities = listOf("Pod Hotel", "Executive Waiting Rooms", "Food Court", "WiFi", "Book Stalls"),
            accessibility = listOf("Wheelchair Assistance", "Ramps", "Elevators"),
            metroConnections = "Western Line Suburban (Direct Bridge Connection)",
            taxiServices = "Prepaid Auto & Taxi Booth, App Cab zones",
            nearbyHotels = listOf("The YMCA International", "Hotel Sahil", "ITC Grand Central")
        ),
        Station("HWH", "Howrah Junction", "Kolkata", 23, 
            facilities = listOf("Jan Aahar Restaurant", "AC Lounges", "Retiring Rooms", "WiFi", "E-Carts"),
            accessibility = listOf("Ramps", "Wheelchairs at Helpdesk", "Special Toilets"),
            metroConnections = "Kolkata Metro Green Line (Howrah Metro Station - Deepest in India)",
            taxiServices = "Prepaid Taxi Stand, App Cab bays",
            nearbyHotels = listOf("Howrah Railway Yatri Niwas", "The Lalit Great Eastern")
        ),
        Station("MAS", "Chennai Central", "Chennai", 17, 
            facilities = listOf("Executive Lounge", "Food Street", "WiFi", "Water Vending Machines"),
            accessibility = listOf("Escalators", "Battery Operated Cars", "Braille Signage"),
            metroConnections = "Chennai Metro Green & Blue Lines (Central Metro)",
            taxiServices = "Prepaid Auto and Taxi bays",
            nearbyHotels = listOf("Hotel Ramada", "Radisson Chennai City Centre")
        ),
        Station("SBC", "KSR Bengaluru", "Bengaluru", 10, 
            facilities = listOf("AC Lounges", "Sardar Patel Food Plaza", "Book stalls", "WiFi"),
            accessibility = listOf("Wheelchair ramps", "Lifts on all platforms"),
            metroConnections = "Namma Metro Purple Line (Kranthiveera Sangolli Rayanna Metro)",
            taxiServices = "Prepaid Auto stand, Uber/Ola dedicated pickup zones",
            nearbyHotels = listOf("Hotel Maurya", "Taj West End")
        ),
        Station("BSB", "Varanasi Junction", "Varanasi", 9, 
            facilities = listOf("Food plaza", "VIP Waiting Lounge", "Retiring rooms", "WiFi"),
            accessibility = listOf("Wheelchairs", "Escalators"),
            metroConnections = "Proposed Metro Line (Local auto and e-rickshaws available)",
            taxiServices = "Prepaid Taxi, local auto-rickshaw bays",
            nearbyHotels = listOf("Taj Ganges", "BrijRama Palace", "Hotel Varanasi Tourist")
        ),
        Station("ADI", "Ahmedabad Junction", "Ahmedabad", 12, 
            facilities = listOf("AC Retiring Rooms", "Food Court", "WiFi", "Amul Parlors"),
            accessibility = listOf("Escalators", "Battery Operated Golf Carts"),
            metroConnections = "Ahmedabad Metro East-West Corridor (Kalupur Metro Station)",
            taxiServices = "Prepaid Taxi & Rickshaw booth",
            nearbyHotels = listOf("Hyatt Regency Ahmedabad", "Radisson Blu Ahmedabad")
        ),
        Station("JP", "Jaipur Junction", "Jaipur", 7, 
            facilities = listOf("Heritage Waiting Lounges", "Food stalls", "WiFi", "Craft Shops"),
            accessibility = listOf("Ramps", "Wheelchairs on Call"),
            metroConnections = "Jaipur Metro Pink Line (Railway Station Metro)",
            taxiServices = "Prepaid Cab and Rickshaw stands",
            nearbyHotels = listOf("Umaid Bhawan", "Taj Rambagh Palace")
        )
    )

    val INITIAL_TRAINS = listOf(
        Train("12951", "Mumbai Rajdhani", "Rajdhani", "Daily", 
            stops = listOf(
                TrainStop("NDLS", "New Delhi", "00:00", "16:55", 0, 0, 6),
                TrainStop("KOTA", "Kota Junction", "21:35", "21:40", 5, 465, 1),
                TrainStop("RTM", "Ratlam Junction", "00:52", "00:55", 3, 731, 4),
                TrainStop("BRC", "Vadodara Junction", "03:48", "03:56", 8, 992, 2),
                TrainStop("ST", "Surat Junction", "05:37", "05:42", 5, 1122, 1),
                TrainStop("MMCT", "Mumbai Central", "08:35", "00:00", 0, 1385, 2)
            ),
            classes = listOf("1A", "2A", "3A"),
            amenities = listOf("Catering Included", "AC", "Pillows & Blankets", "Charging Ports", "Reading Lights")
        ),
        Train("12952", "Mumbai NDLS Rajdhani", "Rajdhani", "Daily", 
            stops = listOf(
                TrainStop("MMCT", "Mumbai Central", "00:00", "17:00", 0, 0, 2),
                TrainStop("ST", "Surat Junction", "19:42", "19:47", 5, 263, 1),
                TrainStop("BRC", "Vadodara Junction", "21:18", "21:26", 8, 393, 3),
                TrainStop("RTM", "Ratlam Junction", "00:40", "00:43", 3, 654, 4),
                TrainStop("KOTA", "Kota Junction", "03:55", "04:00", 5, 920, 1),
                TrainStop("NDLS", "New Delhi", "08:30", "00:00", 0, 1385, 6)
            ),
            classes = listOf("1A", "2A", "3A"),
            amenities = listOf("Catering Included", "AC", "Pillows & Blankets", "Charging Ports", "Reading Lights")
        ),
        Train("22436", "Varanasi Vande Bharat", "Vande Bharat", "M, T, W, F, S, S", 
            stops = listOf(
                TrainStop("NDLS", "New Delhi", "00:00", "06:00", 0, 0, 5),
                TrainStop("CNB", "Kanpur Central", "10:08", "10:10", 2, 440, 1),
                TrainStop("PRYJ", "Prayagraj Junction", "12:08", "12:10", 2, 634, 6),
                TrainStop("BSB", "Varanasi Junction", "14:00", "00:00", 0, 755, 1)
            ),
            classes = listOf("CC", "EC"),
            amenities = listOf("Sleek Interiors", "Onboard Catering", "CCTV Security", "Automatic Doors", "WiFi", "AC")
        ),
        Train("12002", "NDLS Bhopal Shatabdi", "Shatabdi", "Daily", 
            stops = listOf(
                TrainStop("NDLS", "New Delhi", "00:00", "06:00", 0, 0, 3),
                TrainStop("AGC", "Agra Cantt", "07:50", "07:55", 5, 188, 1),
                TrainStop("GWL", "Gwalior Junction", "09:23", "09:28", 5, 306, 4),
                TrainStop("VGLJ", "VGL Jhansi Junction", "10:45", "10:53", 8, 403, 1),
                TrainStop("BPL", "Bhopal Junction", "14:40", "00:00", 0, 701, 1)
            ),
            classes = listOf("CC", "EC"),
            amenities = listOf("Complimentary Water & Newspaper", "AC", "Meals Included", "Charging Outlets")
        ),
        Train("12301", "Howrah Rajdhani", "Rajdhani", "M, T, Th, F, S", 
            stops = listOf(
                TrainStop("NDLS", "New Delhi", "00:00", "16:50", 0, 0, 11),
                TrainStop("CNB", "Kanpur Central", "21:35", "21:40", 5, 440, 1),
                TrainStop("PRYJ", "Prayagraj Junction", "23:55", "23:57", 2, 634, 4),
                TrainStop("DDU", "Pt. Deen Dayal Upadhyaya", "01:25", "01:35", 10, 785, 2),
                TrainStop("GAYA", "Gaya Junction", "03:45", "03:48", 3, 990, 3),
                TrainStop("HWH", "Howrah Junction", "09:55", "00:00", 0, 1450, 9)
            ),
            classes = listOf("1A", "2A", "3A"),
            amenities = listOf("Premium Catering", "AC", "Retractable Bed", "USB Ports")
        )
    )
}
