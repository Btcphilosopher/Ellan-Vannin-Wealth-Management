package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = CarriageBlue,
    secondary = SaffronAccent,
    tertiary = CarriageRed,
    background = SlateCharcoal,
    surface = SlateCharcoal,
    onPrimary = WarmWhite,
    onSecondary = SlateCharcoal,
    onTertiary = WarmWhite,
    onBackground = WarmWhite,
    onSurface = WarmWhite
)

private val LightColorScheme = lightColorScheme(
    primary = RailwayBlue,
    secondary = CarriageBlue,
    tertiary = CarriageRed,
    background = WarmWhite,
    surface = WarmWhite,
    onPrimary = WarmWhite,
    onSecondary = WarmWhite,
    onTertiary = WarmWhite,
    onBackground = SlateCharcoal,
    onSurface = SlateCharcoal
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep colors branded by default
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
