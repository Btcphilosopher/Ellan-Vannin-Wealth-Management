package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.RailwayViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainDetailScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val train by viewModel.selectedTrain.collectAsState()

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    if (train == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No train selected")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp)
    ) {
        // Header
        TopAppBar(
            title = {
                Column {
                    Text(text = "${train!!.number} - ${train!!.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                    Text(text = "${train!!.type} · Runs ${train!!.runningDays}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                }
            },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )

        // Route list
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Text(
                    text = "STATION SCHEDULE & DELAYS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            itemsIndexed(train!!.stops) { index, stop ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    // Timeline bullet with line
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(36.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (index <= train!!.currentStopIndex) ForestGreen else Color.LightGray,
                            modifier = Modifier.size(16.dp)
                        ) {
                            if (index <= train!!.currentStopIndex) {
                                Icon(Icons.Default.Check, "Arrived", tint = Color.White, modifier = Modifier.padding(2.dp))
                            }
                        }
                        if (index < train!!.stops.size - 1) {
                            Box(
                                modifier = Modifier
                                    .width(2.dp)
                                    .height(50.dp)
                                    .background(if (index < train!!.currentStopIndex) ForestGreen else Color.LightGray)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Station Halt Details
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stop.stationName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (index <= train!!.currentStopIndex) SlateCharcoal else Color.Gray
                            )
                            if (train!!.delayMinutes > 0 && index >= train!!.currentStopIndex) {
                                Text(
                                    text = "+${train!!.delayMinutes}m delay",
                                    color = AmberAlert,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Arr: ${stop.arrivalTime} · Dep: ${stop.departureTime} (Halt: ${stop.stopMinutes}m)",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                            Text(
                                text = "Platform ${stop.expectedPlatform}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Text(
                            text = "Distance: ${stop.distanceKm} Km",
                            fontSize = 11.sp,
                            color = Color.LightGray
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                // Coach Composition Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "COACH LAYOUT (TYPICAL COMPOSITION)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf("ENG", "H1", "A1", "A2", "B1", "B2", "B3", "PC", "S1", "S2", "GD").forEach { coach ->
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (coach.startsWith("H") || coach.startsWith("A") || coach.startsWith("B")) {
                                                CarriageBlue
                                            } else if (coach.startsWith("S")) {
                                                CarriageRed
                                            } else Color.DarkGray,
                                            shape = RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = coach, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.startBooking(train!!) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Text(LocalizedStrings.get("book_now", lang), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LiveTrackScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val trainsList by viewModel.trains.collectAsState()
    val activeNumber by viewModel.activeTrainNumber.collectAsState()
    val isOffline by viewModel.isOfflineMode.collectAsState()

    val train = trainsList.find { it.number == activeNumber } ?: trainsList.first()

    var destinationAlertEnabled by remember { mutableStateOf(true) }

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Tracker Top Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "LIVE JOURNEY TRACKER",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${train.number} - ${train.name}",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Delay Info Box
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (train.isCanceled) CarriageRed.copy(alpha = 0.15f) else if (train.delayMinutes > 0) AmberAlert.copy(alpha = 0.15f) else ForestGreen.copy(alpha = 0.15f))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (train.isCanceled) {
                    "STATUS: CANCELED TONIGHT"
                } else if (train.delayMinutes > 0) {
                    "STATUS: DELAYED BY ${train.delayMinutes} MINS"
                } else {
                    "STATUS: RUNNING ON TIME"
                },
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (train.isCanceled) CarriageRed else if (train.delayMinutes > 0) AmberAlert else ForestGreen
            )
            Text(
                text = if (isOffline) "OFFLINE CACHED" else "LIVE GPS TELEMETRY",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray
            )
        }

        // Cartographic Route Map View (Custom Canvas drawing representing India Railway Corridor geometry)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(200.dp),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color.LightGray)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Draw Background clean grid lines for aesthetic cartographic design
                    val gridCount = 6
                    for (i in 1..gridCount) {
                        drawLine(
                            color = Color(0xFFF1F5F9),
                            start = androidx.compose.ui.geometry.Offset(0f, (h / gridCount) * i),
                            end = androidx.compose.ui.geometry.Offset(w, (h / gridCount) * i),
                            strokeWidth = 1f
                        )
                        drawLine(
                            color = Color(0xFFF1F5F9),
                            start = androidx.compose.ui.geometry.Offset((w / gridCount) * i, 0f),
                            end = androidx.compose.ui.geometry.Offset((w / gridCount) * i, h),
                            strokeWidth = 1f
                        )
                    }

                    // Railway track line geometry (S-curve representation from NDLS to MMCT)
                    val points = listOf(
                        androidx.compose.ui.geometry.Offset(0.1f * w, 0.2f * h), // NDLS
                        androidx.compose.ui.geometry.Offset(0.25f * w, 0.4f * h), // KOTA
                        androidx.compose.ui.geometry.Offset(0.45f * w, 0.55f * h), // RTM
                        androidx.compose.ui.geometry.Offset(0.6f * w, 0.45f * h), // BRC
                        androidx.compose.ui.geometry.Offset(0.75f * w, 0.65f * h), // ST
                        androidx.compose.ui.geometry.Offset(0.9f * w, 0.8f * h)  // MMCT
                    )

                    // Draw track line
                    for (i in 0 until points.size - 1) {
                        drawLine(
                            color = Color.Gray,
                            start = points[i],
                            end = points[i + 1],
                            strokeWidth = 4f
                        )
                        // Sleepers ticks
                        val steps = 8
                        for (s in 1..steps) {
                            val ratio = s.toFloat() / steps
                            val x = points[i].x + (points[i + 1].x - points[i].x) * ratio
                            val y = points[i].y + (points[i + 1].y - points[i].y) * ratio
                            // perpendicular ticks
                            drawLine(
                                color = Color.LightGray,
                                start = androidx.compose.ui.geometry.Offset(x, y - 6f),
                                end = androidx.compose.ui.geometry.Offset(x, y + 6f),
                                strokeWidth = 2f
                            )
                        }
                    }

                    // Draw Station circle nodes
                    points.forEachIndexed { idx, point ->
                        val isArrived = idx <= train.currentStopIndex
                        drawCircle(
                            color = if (isArrived) ForestGreen else Color.LightGray,
                            radius = 10f,
                            center = point
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 5f,
                            center = point
                        )
                    }

                    // Draw ACTIVE train running marker
                    val activeIndex = if (train.currentStopIndex == -1) 0 else if (train.currentStopIndex >= train.stops.size) train.stops.size - 1 else train.currentStopIndex
                    val trainPos = points[activeIndex]
                    drawCircle(
                        color = CarriageRed,
                        radius = 14f,
                        center = trainPos
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 6f,
                        center = trainPos
                    )
                }

                // Node Labels Overlay
                Text("NDLS", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 25.dp, top = 25.dp))
                Text("KOTA", fontSize = 10.sp, color = Color.Gray, modifier = Modifier.padding(start = 75.dp, top = 65.dp))
                Text("RTM", fontSize = 10.sp, color = Color.Gray, modifier = Modifier.padding(start = 145.dp, top = 105.dp))
                Text("MMCT", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 285.dp, top = 150.dp))
                
                // Demo Map Label
                Badge(containerColor = Color.DarkGray, contentColor = Color.White, modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)) {
                    Text("SIMPLIFIED CORRIDOR", fontSize = 8.sp, modifier = Modifier.padding(2.dp))
                }
            }
        }

        // Approaching Alert Box (DESTINATION ALERT)
        val stopsLeft = train.stops.size - 1 - train.currentStopIndex
        if (stopsLeft == 1 && destinationAlertEnabled) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CarriageRed.copy(alpha = 0.08f)),
                border = BorderStroke(1.5.dp, CarriageRed)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.NotificationsActive,
                        "Approaching",
                        tint = CarriageRed,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = LocalizedStrings.get("prepare_to_leave", lang),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = CarriageRed
                        )
                        Text(
                            text = "Next stop: ${train.stops.last().stationName}. Gather your luggage.",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }
                    IconButton(onClick = { destinationAlertEnabled = false }) {
                        Icon(Icons.Default.Close, "Dismiss", tint = Color.Gray)
                    }
                }
            }
        }

        // Timeline live progress Tracker (Vertical Halt-by-Halt telemetry)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "HALT TELEMETRY LOG",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                train.stops.forEachIndexed { idx, stop ->
                    val isPast = idx < train.currentStopIndex
                    val isCurrent = idx == train.currentStopIndex
                    val isFuture = idx > train.currentStopIndex

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Colored status bullet
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isCurrent) CarriageRed
                                    else if (isPast) ForestGreen
                                    else Color.LightGray
                                )
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stop.stationName,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 13.sp,
                                color = if (isCurrent) CarriageRed else if (isPast) SlateCharcoal else Color.Gray
                            )
                            Text(
                                text = if (isCurrent) "Currently here · Platform ${stop.expectedPlatform}"
                                else if (isPast) "Departed ${stop.departureTime}"
                                else "Upcoming halt (Expected: ${stop.arrivalTime})",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}
