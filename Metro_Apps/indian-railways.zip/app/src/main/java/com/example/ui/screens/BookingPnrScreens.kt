package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.RailwayViewModel
import com.example.ui.theme.*
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingFlowScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val train by viewModel.selectedTrain.collectAsState()
    val classCode by viewModel.searchClassCode.collectAsState()
    val quota by viewModel.searchQuota.collectAsState()

    val bookingPassengers by viewModel.bookingPassengers.collectAsState()
    val mealPref by viewModel.bookingMealPreference.collectAsState()
    val berthPref by viewModel.bookingBerthPreference.collectAsState()

    var showPaymentSheet by remember { mutableStateOf(false) }
    var upiIdInput by remember { mutableStateOf("") }

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    if (train == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No train selected")
        }
        return
    }

    // Calculations
    val ticketPriceMultiplier = when (classCode) {
        "1A" -> 4200
        "2A" -> 2845
        "3A" -> 2100
        "3E" -> 1800
        "SL" -> 645
        else -> 420
    }
    val count = bookingPassengers.size
    val baseFare = ticketPriceMultiplier * count
    val reservationCharge = 40 * count
    val cateringCharge = 120 * count
    val gst = (baseFare * 0.05).toInt()
    val totalFare = baseFare + reservationCharge + cateringCharge + gst

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Header
        TopAppBar(
            title = { Text("PASSENGER DETAILS", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )

        // Train Details Box
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "${train!!.number} - ${train!!.name}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "${train!!.fromStationCode} → ${train!!.toStationCode} | Class: $classCode | Quota: $quota",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )
            }
        }

        // Tatkal Open Countdown Banner
        if (quota == "TATKAL") {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SaffronAccent.copy(alpha = 0.12f))
                    .border(1.dp, SaffronAccent)
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Timer, "Timer", tint = SaffronAccent)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = LocalizedStrings.get("tatkal_opens", lang),
                            fontWeight = FontWeight.Bold,
                            color = SaffronAccent,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Secure your booking instantly with pre-saved passenger profiles below.",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }
        }

        // Passenger Entry Cards
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "PASSENGERS LIST (${bookingPassengers.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = Color.Gray
            )

            bookingPassengers.forEachIndexed { index, passenger ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color.LightGray)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Passenger ${index + 1}",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = passenger.name,
                            onValueChange = { newName ->
                                val updated = bookingPassengers.toMutableList()
                                updated[index] = passenger.copy(name = newName)
                                viewModel.updateBookingPassengers(updated)
                            },
                            label = { Text("Full Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = passenger.age.toString(),
                                onValueChange = { newAge ->
                                    val updated = bookingPassengers.toMutableList()
                                    updated[index] = passenger.copy(age = newAge.toIntOrNull() ?: 30)
                                    viewModel.updateBookingPassengers(updated)
                                },
                                label = { Text("Age") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = passenger.gender,
                                onValueChange = { newG ->
                                    val updated = bookingPassengers.toMutableList()
                                    updated[index] = passenger.copy(gender = newG)
                                    viewModel.updateBookingPassengers(updated)
                                },
                                label = { Text("Gender (M/F/O)") },
                                modifier = Modifier.weight(1.2f)
                            )
                        }
                    }
                }
            }

            // Berth & Food Choice
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color.LightGray)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("PREFERENCES", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Berth Preference", fontSize = 11.sp, color = Color.DarkGray)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Lower", "Middle", "Upper", "Side Lower").forEach { b ->
                            FilterChip(
                                selected = berthPref == b,
                                onClick = { viewModel.setBookingBerth(b) },
                                label = { Text(b) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Meal Catering Preference", fontSize = 11.sp, color = Color.DarkGray)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Veg Meal", "Non-Veg", "No Food").forEach { m ->
                            FilterChip(
                                selected = mealPref == m,
                                onClick = { viewModel.setBookingMeal(m) },
                                label = { Text(m) }
                            )
                        }
                    }
                }
            }

            // Fare Breakup Panel
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = LocalizedStrings.get("fare", lang).uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Base Ticket Fare ($count x $ticketPriceMultiplier)", fontSize = 13.sp)
                        Text("₹$baseFare", fontSize = 13.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Superfast & Reservation Fees", fontSize = 13.sp)
                        Text("₹$reservationCharge", fontSize = 13.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Catering Food Charges ($mealPref)", fontSize = 13.sp)
                        Text("₹$cateringCharge", fontSize = 13.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("GST Tax (5%)", fontSize = 13.sp)
                        Text("₹$gst", fontSize = 13.sp)
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(LocalizedStrings.get("total_fare", lang), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("₹$totalFare", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = CarriageRed)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Proceed to Payment button
            Button(
                onClick = { showPaymentSheet = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ForestGreen)
            ) {
                Icon(Icons.Default.Payment, "Pay")
                Spacer(modifier = Modifier.width(8.dp))
                Text("PROCEED TO PAY  ₹$totalFare", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }

    // Simple payment sheets / bottom modal simulation
    if (showPaymentSheet) {
        AlertDialog(
            onDismissRequest = { showPaymentSheet = false },
            title = { Text("DEMO SECURE PAYMENT") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "This is a payment simulation tokenizing your security. Do NOT store raw card details.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    OutlinedTextField(
                        value = upiIdInput,
                        onValueChange = { upiIdInput = it },
                        label = { Text("Enter UPI ID (e.g. user@okhdfc)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            showPaymentSheet = false
                            viewModel.finalizeBooking(totalFare)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("DEMO UPI PAYMENT  ₹$totalFare", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = {
                            showPaymentSheet = false
                            viewModel.finalizeBooking(totalFare)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("DEMO DEBIT/CREDIT CARD", fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPaymentSheet = false }) {
                    Text("CANCEL")
                }
            }
        )
    }
}

@Composable
fun BookingConfirmedScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val lastTicket by viewModel.lastBookedTicket.collectAsState()

    androidx.activity.compose.BackHandler {
        viewModel.navigateTo("HOME")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(40.dp))

        // Success Bullet Indicator
        Surface(
            shape = RoundedCornerShape(100.dp),
            color = ForestGreen,
            modifier = Modifier.size(72.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Check, "Success", tint = Color.White, modifier = Modifier.size(40.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "BOOKING CONFIRMED!",
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            color = ForestGreen
        )
        Text(
            text = LocalizedStrings.get("demo_data_warn", lang),
            fontSize = 11.sp,
            color = Color.Gray,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        if (lastTicket != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color.LightGray)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("PNR NUMBER", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
                        Text(lastTicket!!.pnr, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Divider()
                    Text(
                        text = "${lastTicket!!.trainNumber} - ${lastTicket!!.trainName}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "${lastTicket!!.fromStation} → ${lastTicket!!.toStation}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Date of Journey: ${lastTicket!!.date} · Class: ${lastTicket!!.classCode}",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                    Divider()
                    lastTicket!!.passengers.forEach { p ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(p.name, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text("Coach ${p.coach} / Berth ${p.berth} (${p.preferredBerth})", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { viewModel.navigateTo("TICKETS") },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("VIEW TICKET IN WALLET", fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
            onClick = { viewModel.navigateTo("HOME") },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("RETURN TO HOME", fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PnrStatusScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val tickets by viewModel.tickets.collectAsState()

    var pnrInput by remember { mutableStateOf("") }
    var displayedTicket by remember { mutableStateOf<Ticket?>(null) }
    var searched by remember { mutableStateOf(false) }

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        TopAppBar(
            title = { Text(LocalizedStrings.get("pnr", lang), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
        )

        // PNR Input Panel
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "CHECK 10-DIGIT PNR STATUS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                OutlinedTextField(
                    value = pnrInput,
                    onValueChange = { pnrInput = it },
                    label = { Text("Enter PNR Number") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                    )
                )
                Button(
                    onClick = {
                        searched = true
                        displayedTicket = tickets.find { it.pnr == pnrInput }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("FETCH CURRENT STATUS", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Search Results
        if (searched) {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                if (displayedTicket != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "PNR ${displayedTicket!!.pnr} DETAILS",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "${displayedTicket!!.trainNumber} - ${displayedTicket!!.trainName}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "${displayedTicket!!.fromStation} → ${displayedTicket!!.toStation}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Booking Status: ${displayedTicket!!.status}",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = if (displayedTicket!!.status == "CONFIRMED") ForestGreen else CarriageRed
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            displayedTicket!!.passengers.forEachIndexed { i, p ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Passenger ${i + 1}: ${p.name}", fontSize = 12.sp)
                                    Text("Status: ${p.status} (Coach ${p.coach} / Berth ${p.berth})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CarriageRed.copy(alpha = 0.08f)),
                        border = BorderStroke(1.dp, CarriageRed)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Warning, "Not Found", tint = CarriageRed)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("PNR Status record not found locally.", fontWeight = FontWeight.Bold, color = CarriageRed)
                            Text("Use standard demo PNR 1234567890 or create a new booking.", fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }

        // Glossary / Abbreviation Explanations
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "RAILWAY TERMINOLOGY DECODER",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            RailwayAbbreviationExplanations.abbreviations.forEach { (abbr, desc) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = abbr, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = desc, fontSize = 11.sp, color = Color.DarkGray)
                    }
                }
            }
        }
    }
}
