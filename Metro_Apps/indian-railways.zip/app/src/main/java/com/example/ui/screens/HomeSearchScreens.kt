package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.*
import com.example.ui.RailwayViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val isOffline by viewModel.isOfflineMode.collectAsState()
    val systemAlerts by viewModel.systemAlerts.collectAsState()
    val tickets by viewModel.tickets.collectAsState()

    val fromCode by viewModel.searchFromCode.collectAsState()
    val toCode by viewModel.searchToCode.collectAsState()
    val date by viewModel.searchDate.collectAsState()
    val passengers by viewModel.searchPassengersCount.collectAsState()
    val classCode by viewModel.searchClassCode.collectAsState()
    val quota by viewModel.searchQuota.collectAsState()

    var showFromDropdown by remember { mutableStateOf(false) }
    var showToDropdown by remember { mutableStateOf(false) }
    var showClassDropdown by remember { mutableStateOf(false) }
    var showQuotaDropdown by remember { mutableStateOf(false) }

    val stations = RailwayDataStore.STATIONS

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp)
    ) {
        // Hero Image Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.scenic_train_banner),
                contentDescription = "Scenic Train Banner",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Gradient Overlay for readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0xAA000000)),
                            startY = 100f
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
            ) {
                Text(
                    text = LocalizedStrings.get("app_title", lang),
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = LocalizedStrings.get("subtitle", lang),
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 12.sp
                )
            }
        }

        // Search Panel
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = LocalizedStrings.get("where_to", lang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                // FROM Station
                Box {
                    OutlinedTextField(
                        value = stations.find { it.code == fromCode }?.let { "${it.name} (${it.code})" } ?: fromCode,
                        onValueChange = {},
                        label = { Text(LocalizedStrings.get("from", lang)) },
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { showFromDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, "Select Origin")
                            }
                        }
                    )
                    DropdownMenu(
                        expanded = showFromDropdown,
                        onDismissRequest = { showFromDropdown = false },
                        modifier = Modifier.fillMaxWidth(0.85f)
                    ) {
                        stations.forEach { station ->
                            DropdownMenuItem(
                                text = { Text("${station.city} - ${station.name} (${station.code})") },
                                onClick = {
                                    viewModel.searchFromCode.value = station.code
                                    showFromDropdown = false
                                }
                            )
                        }
                    }
                }

                // Swap Button
                IconButton(
                    onClick = {
                        val temp = viewModel.searchFromCode.value
                        viewModel.searchFromCode.value = viewModel.searchToCode.value
                        viewModel.searchToCode.value = temp
                    },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Icon(Icons.Default.SwapVert, "Swap stations", tint = MaterialTheme.colorScheme.primary)
                }

                // TO Station
                Box {
                    OutlinedTextField(
                        value = stations.find { it.code == toCode }?.let { "${it.name} (${it.code})" } ?: toCode,
                        onValueChange = {},
                        label = { Text(LocalizedStrings.get("to", lang)) },
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { showToDropdown = true }) {
                                Icon(Icons.Default.ArrowDropDown, "Select Destination")
                            }
                        }
                    )
                    DropdownMenu(
                        expanded = showToDropdown,
                        onDismissRequest = { showToDropdown = false },
                        modifier = Modifier.fillMaxWidth(0.85f)
                    ) {
                        stations.forEach { station ->
                            DropdownMenuItem(
                                text = { Text("${station.city} - ${station.name} (${station.code})") },
                                onClick = {
                                    viewModel.searchToCode.value = station.code
                                    showToDropdown = false
                                }
                            )
                        }
                    }
                }

                // Date & Passengers Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { viewModel.searchDate.value = it },
                        label = { Text(LocalizedStrings.get("date", lang)) },
                        modifier = Modifier.weight(1.2f)
                    )
                    OutlinedTextField(
                        value = passengers.toString(),
                        onValueChange = { viewModel.searchPassengersCount.value = it.toIntOrNull() ?: 1 },
                        label = { Text(LocalizedStrings.get("passengers", lang)) },
                        modifier = Modifier.weight(0.8f),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                        )
                    )
                }

                // Class & Quota Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Class Dropdown
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = classCode,
                            onValueChange = {},
                            label = { Text(LocalizedStrings.get("class", lang)) },
                            readOnly = true,
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = { showClassDropdown = true }) {
                                    Icon(Icons.Default.ArrowDropDown, "Select Class")
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = showClassDropdown,
                            onDismissRequest = { showClassDropdown = false }
                        ) {
                            listOf("1A", "2A", "3A", "3E", "SL", "CC").forEach { c ->
                                DropdownMenuItem(
                                    text = { Text(c) },
                                    onClick = {
                                        viewModel.searchClassCode.value = c
                                        showClassDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    // Quota Dropdown
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = quota,
                            onValueChange = {},
                            label = { Text(LocalizedStrings.get("quota", lang)) },
                            readOnly = true,
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = { showQuotaDropdown = true }) {
                                    Icon(Icons.Default.ArrowDropDown, "Select Quota")
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = showQuotaDropdown,
                            onDismissRequest = { showQuotaDropdown = false }
                        ) {
                            QuotaTypes.list.forEach { (q, _) ->
                                DropdownMenuItem(
                                    text = { Text(q) },
                                    onClick = {
                                        viewModel.searchQuota.value = q
                                        showQuotaDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                Button(
                    onClick = { viewModel.executeTrainSearch() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("search_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Search, "Search", modifier = Modifier.padding(end = 8.dp))
                    Text(
                        text = LocalizedStrings.get("search_trains", lang),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // NEXT JOURNEY
        val nextTicket = tickets.find { it.status == "CONFIRMED" }
        if (nextTicket != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = LocalizedStrings.get("your_next_journey", lang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${nextTicket.trainNumber} - ${nextTicket.trainName}",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Badge(containerColor = ForestGreen, contentColor = Color.White) {
                                Text(
                                    text = "CONFIRMED",
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${nextTicket.fromStation} → ${nextTicket.toStation}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Date: ${nextTicket.date} · Class: ${nextTicket.classCode}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "Coach ${nextTicket.passengers.firstOrNull()?.coach ?: "A2"} · Berth ${nextTicket.passengers.firstOrNull()?.berth ?: 31}",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.navigateTo("LIVE_TRACK") },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.Default.MyLocation, "Track", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("TRACK", fontSize = 11.sp)
                            }
                            OutlinedButton(
                                onClick = { viewModel.navigateTo("TICKETS") },
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.Default.QrCode, "Ticket", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("VIEW TICKET", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Live Ticker System Alerts
        if (systemAlerts.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = LocalizedStrings.get("live_railway", lang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                systemAlerts.forEach { alert ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when (alert.type) {
                                    AlertType.WEATHER -> Icons.Default.Cloud
                                    AlertType.ENGINEERING -> Icons.Default.Engineering
                                    AlertType.DELAY -> Icons.Default.Timer
                                    AlertType.INFO -> Icons.Default.Info
                                },
                                contentDescription = alert.type.name,
                                tint = when (alert.type) {
                                    AlertType.WEATHER -> Color.Blue
                                    AlertType.ENGINEERING -> AmberAlert
                                    AlertType.DELAY -> CarriageRed
                                    AlertType.INFO -> CarriageBlue
                                },
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = alert.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = alert.message,
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchResultsScreen(viewModel: RailwayViewModel) {
    val lang by viewModel.language.collectAsState()
    val fromCode by viewModel.searchFromCode.collectAsState()
    val toCode by viewModel.searchToCode.collectAsState()
    val date by viewModel.searchDate.collectAsState()
    val classCode by viewModel.searchClassCode.collectAsState()
    val results by viewModel.searchResults.collectAsState()

    androidx.activity.compose.BackHandler {
        viewModel.navigateBack()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 80.dp)
    ) {
        // Criteria Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$fromCode → $toCode",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "$date · Class: $classCode",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = { viewModel.navigateTo("HOME") }) {
                        Icon(Icons.Default.Home, "Home", tint = Color.White)
                    }
                }
            }
        }

        // Demo Data Notice Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(AmberAlert.copy(alpha = 0.15f))
                .border(1.dp, AmberAlert)
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = LocalizedStrings.get("demo_data_warn", lang),
                color = AmberAlert,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }

        // Search Results List
        if (results.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Train,
                        "No trains found",
                        modifier = Modifier.size(64.dp),
                        tint = Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No direct trains found for $fromCode → $toCode.",
                        fontWeight = FontWeight.Medium,
                        color = Color.Gray
                    )
                    Text(
                        text = "Try switching search parameters to Delhi (NDLS) or Mumbai Central (MMCT).",
                        fontSize = 12.sp,
                        color = Color.LightGray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(results) { train ->
                    TrainResultCard(train = train, selectedClass = classCode, onSelect = {
                        viewModel.selectTrain(train)
                    })
                }
            }
        }
    }
}

@Composable
fun TrainResultCard(train: Train, selectedClass: String, onSelect: () -> Unit) {
    val baseFare = when (selectedClass) {
        "1A" -> 4200
        "2A" -> 2845
        "3A" -> 2100
        "3E" -> 1800
        "SL" -> 645
        else -> 420
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Train Header info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = train.number,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 13.sp
                    )
                    Text(
                        text = train.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
                Badge(
                    containerColor = when (train.type) {
                        "Vande Bharat" -> SaffronAccent
                        "Rajdhani" -> CarriageRed
                        "Shatabdi" -> CarriageBlue
                        else -> ForestGreen
                    },
                    contentColor = Color.White
                ) {
                    Text(
                        text = train.type,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Timings Timeline
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = train.departureTime, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(text = train.fromStationCode, fontSize = 11.sp, color = Color.Gray)
                }

                // Center timeline representation
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = train.totalDuration, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.6f)
                            .height(2.dp)
                            .background(Color.LightGray)
                    )
                    Text(text = "Direct", fontSize = 10.sp, color = Color.Gray)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = train.arrivalTime, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(text = train.toStationCode, fontSize = 11.sp, color = Color.Gray)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Class box availability (Simulated)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = ForestGreen.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, ForestGreen),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = selectedClass, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ForestGreen)
                        Text(text = "₹$baseFare", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = "AVAILABLE 148", fontSize = 10.sp, color = ForestGreen)
                    }
                }
                
                Spacer(modifier = Modifier.width(8.dp))

                // Alternative class (SL or 3A as preview)
                val altClass = if (selectedClass == "3A") "2A" else "3A"
                val altFare = if (selectedClass == "3A") 2845 else 2100
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.LightGray.copy(alpha = 0.15f),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = altClass, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
                        Text(text = "₹$altFare", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        Text(text = "AVAILABLE 42", fontSize = 10.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}
