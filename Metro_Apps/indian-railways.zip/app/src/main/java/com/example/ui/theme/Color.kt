package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RailwayBlue = Color(0xFF0C2340)       // Deep navy steel
val CarriageBlue = Color(0xFF1D4ED8)      // Classic passenger coach blue
val CarriageRed = Color(0xFFB91C1C)       // Traditional express train crimson
val SaffronAccent = Color(0xFFEA580C)     // Warm saffron warning/highlights
val ForestGreen = Color(0xFF15803D)       // Muted green signal
val WarmWhite = Color(0xFFF8FAFC)         // Premium white
val ConcreteGray = Color(0xFFE2E8F0)      // Sleek station concrete
val SlateCharcoal = Color(0xFF0F172A)     // Dark charcoal text
val AmberAlert = Color(0xFFD97706)        // Status warning/delay yellow
val PlatinumTonal = Color(0xFFF1F5F9)     // Subtle light surface tonal
