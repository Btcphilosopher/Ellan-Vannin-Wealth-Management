package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import com.example.ui.RailwayViewModel
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val rViewModel: RailwayViewModel = viewModel()
                MainAppLayout(viewModel = rViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppLayout(viewModel: RailwayViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val lang by viewModel.language.collectAsState()
    val isOffline by viewModel.isOfflineMode.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Train,
                            contentDescription = "IR Logo",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = LocalizedStrings.get("app_title", lang),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                text = "One railway. One journey. One app.",
                                fontSize = 10.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }
                },
                actions = {
                    // Quick Chat Assistant FAB-style action in TopBar
                    IconButton(onClick = { viewModel.navigateTo("CHAT") }) {
                        Icon(
                            imageVector = Icons.Default.SupportAgent,
                            contentDescription = "AI Support",
                            tint = Color.White
                        )
                    }

                    // Language Quick Toggle
                    TextButton(onClick = { viewModel.toggleLanguage() }) {
                        Text(
                            text = if (lang == AppLanguage.ENGLISH) "हिन्दी" else "EN",
                            color = SaffronAccent,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    // Admin Simulator Panel Key
                    IconButton(onClick = { viewModel.navigateTo("SIMULATOR") }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Simulation Admin",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = RailwayBlue)
            )
        },
        bottomBar = {
            // Respect navigation safe drawing bar zones for edge-to-edge gestural pills
            NavigationBar(
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                containerColor = RailwayBlue,
                contentColor = Color.White
            ) {
                // Bottom tab item list matching specifications exactly
                val tabs = listOf(
                    Triple("HOME", Icons.Default.Search, "home"),
                    Triple("JOURNEYS", Icons.Default.ListAlt, "journeys"),
                    Triple("LIVE_TRACK", Icons.Default.MyLocation, "live"),
                    Triple("TICKETS", Icons.Default.ConfirmationNumber, "tickets"),
                    Triple("PROFILE", Icons.Default.Person, "profile")
                )

                tabs.forEach { (route, icon, labelKey) ->
                    val isSelected = currentScreen == route || 
                        (route == "HOME" && (currentScreen == "SEARCH_RESULTS" || currentScreen == "TRAIN_DETAIL" || currentScreen == "BOOKING_FLOW" || currentScreen == "BOOKING_CONFIRMED"))
                    
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.navigateTo(route) },
                        icon = { Icon(icon, contentDescription = route, modifier = Modifier.size(24.dp)) },
                        label = { Text(LocalizedStrings.get(labelKey, lang), fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SaffronAccent,
                            selectedTextColor = SaffronAccent,
                            unselectedIconColor = Color.White.copy(alpha = 0.7f),
                            unselectedTextColor = Color.White.copy(alpha = 0.7f),
                            indicatorColor = Color.Transparent
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Screen switching logic with animation transitions
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "ScreenTransition"
            ) { target ->
                when (target) {
                    "HOME" -> HomeScreen(viewModel = viewModel)
                    "SEARCH_RESULTS" -> SearchResultsScreen(viewModel = viewModel)
                    "TRAIN_DETAIL" -> TrainDetailScreen(viewModel = viewModel)
                    "BOOKING_FLOW" -> BookingFlowScreen(viewModel = viewModel)
                    "BOOKING_CONFIRMED" -> BookingConfirmedScreen(viewModel = viewModel)
                    "LIVE_TRACK" -> LiveTrackScreen(viewModel = viewModel)
                    "TICKETS" -> TicketsScreen(viewModel = viewModel)
                    "STATIONS" -> StationsHubScreen(viewModel = viewModel)
                    "SERVICES" -> ServicesHubScreen(viewModel = viewModel)
                    "CHAT" -> ChatScreen(viewModel = viewModel)
                    "SIMULATOR" -> SimulatorScreen(viewModel = viewModel)
                    "PROFILE" -> ProfileScreen(viewModel = viewModel)
                    else -> HomeScreen(viewModel = viewModel)
                }
            }

            // Global Low-Connectivity Indicator Overlay Bar
            if (isOffline) {
                Surface(
                    color = Color.DarkGray,
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .height(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = LocalizedStrings.get("low_conn_warn", lang),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
