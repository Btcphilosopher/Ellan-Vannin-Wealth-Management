package com.example

import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testRoutingEngine_FastestRoute() {
        // Find fastest route between Powell and Embarcadero (direct Muni/BART subway)
        val journeys = RoutingEngine.planRoute(
            startId = "powell",
            endId = "embarcadero",
            accessibilityFilter = false,
            routeRanking = "FASTEST"
        )

        assertFalse(journeys.isEmpty())
        val fastest = journeys.first()
        // Should be direct transfer
        assertTrue(fastest.totalDurationMin <= 10)
        assertEquals(0, fastest.transferCount)
    }

    @Test
    fun testRoutingEngine_FewestTransfers() {
        // Multi-operator journey Daly City to SFO
        val journeys = RoutingEngine.planRoute(
            startId = "daly_city",
            endId = "sfo",
            accessibilityFilter = false,
            routeRanking = "FEWEST_TRANSFERS"
        )

        assertFalse(journeys.isEmpty())
        val directRoute = journeys.first()
        assertEquals(0, directRoute.transferCount) // direct yellow line
        assertTrue(directRoute.legs.any { it.routeId == "BART_YELLOW" })
    }

    @Test
    fun testFareEngine_CalculationRules() {
        // Muni Metro flat fare is $2.50
        val muniJourneys = RoutingEngine.planRoute("powell", "embarcadero")
        assertFalse(muniJourneys.isEmpty())
        // Standard Muni route should charge flat $2.50
        val cheapestMuni = muniJourneys.minByOrNull { it.totalFare }!!
        assertEquals(2.50, cheapestMuni.totalFare, 0.1)

        // BART SFO surcharge / distance base
        val sfoJourneys = RoutingEngine.planRoute("daly_city", "sfo")
        assertFalse(sfoJourneys.isEmpty())
        val sfoRoute = sfoJourneys.first()
        assertEquals(10.55, sfoRoute.totalFare, 0.1)
    }

    @Test
    fun testRouting_DisruptionRerouting() {
        // When N Judah is fully suspended, check routing recalculation
        val activeDisruptions = listOf(
            ServiceAlert(
                id = "disruption_n_judah",
                title = "N Judah Suspended",
                description = "N line is offline.",
                affectedRoutes = listOf("N"),
                affectedStations = emptyList(),
                severity = AlertSeverity.SEVERE,
                category = AlertCategory.CLOSURE
            )
        )

        // Powell to Ocean Beach would normally take N Judah direct
        val disruptedJourneys = RoutingEngine.planRoute(
            startId = "powell",
            endId = "ocean_beach",
            accessibilityFilter = false,
            routeRanking = "FASTEST",
            activeDisruptions = activeDisruptions
        )

        // It should still find a way if alternative segments exist, otherwise return empty
        // Since no other lines service ocean_beach, it will return empty or walk segment
        // Let's verify that the direct N line is not present in legs
        disruptedJourneys.forEach { journey ->
            val hasNJudah = journey.legs.any { it.routeId == "N" }
            assertFalse(hasNJudah)
        }
    }

    @Test
    fun testAccessibility_PathFiltering() {
        // Select route with broken elevators and step-free enabled
        val alerts = listOf(
            ServiceAlert(
                id = "powell_elevator_broken",
                title = "Powell elevator out",
                description = "Broken concourse elevator.",
                affectedRoutes = emptyList(),
                affectedStations = listOf("powell"),
                severity = AlertSeverity.MAJOR,
                category = AlertCategory.ELEVATOR_OUTAGE
            )
        )

        val journeys = RoutingEngine.planRoute(
            startId = "powell",
            endId = "embarcadero",
            accessibilityFilter = true,
            routeRanking = "FASTEST",
            activeDisruptions = alerts
        )

        // If step-free is on and Powell elevator is broken, it cannot board at Powell station.
        // It must find an alternative starting route or return empty.
        assertTrue(journeys.isEmpty() || journeys.none { it.legs.firstOrNull()?.fromStation?.id == "powell" })
    }
}
