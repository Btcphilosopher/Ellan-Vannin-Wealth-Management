package com.example

import androidx.compose.ui.graphics.Color

object TransitData {

    // --- STATIONS ---
    val STATIONS = mapOf(
        // Downtown / Market Street Core Interchanges
        "embarcadero" to Station("embarcadero", "Embarcadero", TransitType.MUNI_METRO, "Financial District & Waterfront. Major interchange.", 37.7930, -122.3970, listOf(TransitType.MUNI_METRO, TransitType.BART, TransitType.STREETCAR, TransitType.MUNI_BUS), true, listOf("A1 Market St", "B2 Ferry Building", "C3 Pine St")),
        "montgomery" to Station("montgomery", "Montgomery St", TransitType.MUNI_METRO, "Financial District & SoMa. Busy commuter hub.", 37.7894, -122.4013, listOf(TransitType.MUNI_METRO, TransitType.BART, TransitType.MUNI_BUS), true, listOf("A1 Market St", "B2 Sutter St", "C3 Mission St")),
        "powell" to Station("powell", "Powell St", TransitType.MUNI_METRO, "Union Square, cable cars, shopping. Prime hub.", 37.7844, -122.4080, listOf(TransitType.MUNI_METRO, TransitType.BART, TransitType.CABLE_CAR, TransitType.MUNI_BUS), true, listOf("A1 Cable Car Turnaround", "B2 Hallidie Plaza", "C3 Westfield Mall")),
        "civic_center" to Station("civic_center", "Civic Center / UN Plaza", TransitType.MUNI_METRO, "City Hall, Asian Art Museum, Broadway SF.", 37.7797, -122.4141, listOf(TransitType.MUNI_METRO, TransitType.BART, TransitType.MUNI_BUS), true, listOf("A1 City Hall", "B2 UN Plaza", "C3 Eighth St")),
        "van_ness" to Station("van_ness", "Van Ness", TransitType.MUNI_METRO, "West Portal connection point. Center lane boarding.", 37.7753, -122.4193, listOf(TransitType.MUNI_METRO, TransitType.MUNI_BUS), true, listOf("A1 Market St", "B2 South Van Ness")),

        // Mission District (BART & Buses)
        "16th_mission" to Station("16th_mission", "16th St Mission", TransitType.BART, "Vibrant cultural hub, restaurants, murals.", 37.7650, -122.4196, listOf(TransitType.BART, TransitType.MUNI_BUS), true, listOf("NE corner", "SW corner")),
        "24th_mission" to Station("24th_mission", "24th St Mission", TransitType.BART, "Heart of Calle 24 Latino Cultural District.", 37.7520, -122.4180, listOf(TransitType.BART, TransitType.MUNI_BUS), true, listOf("Northeast plaza", "Southwest plaza")),

        // Castro & Noe Valley
        "castro" to Station("castro", "Castro", TransitType.MUNI_METRO, "Historic LGBTQ+ cultural core. Rainbow plaza.", 37.7622, -122.4350, listOf(TransitType.MUNI_METRO, TransitType.STREETCAR, TransitType.MUNI_BUS), true, listOf("Harvey Milk Plaza", "Castro Theater")),
        "noe_valley" to Station("noe_valley", "Noe Valley (24th St)", TransitType.MUNI_METRO, "Sunny, family-friendly neighborhood.", 37.7516, -122.4289, listOf(TransitType.MUNI_METRO), false, listOf("Church & 24th St")),

        // Sunset & Ocean Beach
        "forest_hill" to Station("forest_hill", "Forest Hill", TransitType.MUNI_METRO, "Historic station in the Forest Hill tunnel.", 37.7483, -122.4591, listOf(TransitType.MUNI_METRO), true, listOf("Laguna Honda Blvd")),
        "west_portal" to Station("west_portal", "West Portal", TransitType.MUNI_METRO, "Western gateway to the Muni Metro tunnel.", 37.7402, -122.4632, listOf(TransitType.MUNI_METRO, TransitType.MUNI_BUS), true, listOf("West Portal Ave", "Ulloa St")),
        "ocean_beach" to Station("ocean_beach", "Ocean Beach (N Terminal)", TransitType.MUNI_METRO, "Western edge of San Francisco, overlooking Pacific.", 37.7610, -122.5085, listOf(TransitType.MUNI_METRO, TransitType.MUNI_BUS), true, listOf("Judah & La Playa")),

        // Dogpatch & Mission Bay (T Third)
        "mission_bay" to Station("mission_bay", "Mission Bay (UCSF)", TransitType.MUNI_METRO, "UCSF Medical Center, biotech hub.", 37.7681, -122.3892, listOf(TransitType.MUNI_METRO), true, listOf("3rd & 16th St")),
        "dogpatch" to Station("dogpatch", "Dogpatch (22nd St)", TransitType.MUNI_METRO, "Trendy industrial neighborhood, historic docks.", 37.7584, -122.3881, listOf(TransitType.MUNI_METRO, TransitType.CALTRAIN), true, listOf("3rd & 22nd St")),

        // South Interchange, Daly City, SFO
        "balboa_park" to Station("balboa_park", "Balboa Park", TransitType.BART, "Southern city transit junction. Muni Metro terminal.", 37.7215, -122.4475, listOf(TransitType.BART, TransitType.MUNI_METRO, TransitType.MUNI_BUS), true, listOf("Geneva Ave", "Ocean Ave")),
        "daly_city" to Station("daly_city", "Daly City", TransitType.BART, "BART terminus for multiple lines. Regional transfer.", 37.6882, -122.4690, listOf(TransitType.BART, TransitType.REGIONAL_BUS), true, listOf("De Long St", "John Daly Blvd")),
        "sfo" to Station("sfo", "San Francisco Int'l Airport", TransitType.BART, "SFO International Terminal connection. AirTrain link.", 37.6158, -122.3897, listOf(TransitType.BART), true, listOf("Terminal Link Garage")),

        // Caltrain SF & Peninsula
        "caltrain_sf" to Station("caltrain_sf", "San Francisco Caltrain Station", TransitType.CALTRAIN, "4th & King. Gateway to Peninsula & Silicon Valley.", 37.7766, -122.3951, listOf(TransitType.CALTRAIN, TransitType.MUNI_METRO, TransitType.MUNI_BUS), true, listOf("4th St & King", "Townsend St")),
        "palo_alto" to Station("palo_alto", "Palo Alto", TransitType.CALTRAIN, "Stanford University, University Avenue Downtown.", 37.4431, -122.1649, listOf(TransitType.CALTRAIN, TransitType.REGIONAL_BUS), true, listOf("Stanford Depot")),
        "san_jose" to Station("san_jose", "San Jose Diridon", TransitType.CALTRAIN, "South Bay regional terminal. VTA Connections.", 37.3297, -121.9038, listOf(TransitType.CALTRAIN, TransitType.REGIONAL_BUS), true, listOf("Cahill St Depot")),

        // East Bay / Regional Stations
        "oakland_12th" to Station("oakland_12th", "12th St Oakland City Center", TransitType.BART, "Downtown Oakland. Core East Bay Hub.", 37.8037, -122.2714, listOf(TransitType.BART), true, listOf("Broadway & 12th")),
        "berkeley" to Station("berkeley", "Downtown Berkeley", TransitType.BART, "UC Berkeley campus, theater district.", 37.8701, -122.2682, listOf(TransitType.BART, TransitType.REGIONAL_BUS), true, listOf("Shattuck Ave & Center St")),

        // North Beach & Tourist Points (Buses, Cable Car, Streetcar)
        "chinatown" to Station("chinatown", "Chinatown-Rose Pak", TransitType.MUNI_METRO, "Modern deep subway station serving historic Chinatown.", 37.7946, -122.4078, listOf(TransitType.MUNI_METRO, TransitType.MUNI_BUS), true, listOf("Stockton & Washington")),
        "fisherman_wharf" to Station("fisherman_wharf", "Fisherman's Wharf", TransitType.STREETCAR, "Pier 39, sea lions, historic seafood stalls.", 37.8080, -122.4177, listOf(TransitType.STREETCAR, TransitType.MUNI_BUS), true, listOf("Jefferson & Powell")),
        "union_square" to Station("union_square", "Union Square", TransitType.CABLE_CAR, "Heart of SF shopping, theater district.", 37.7876, -122.4075, listOf(TransitType.CABLE_CAR, TransitType.MUNI_METRO), true, listOf("Powell & Post St")),
        "golden_gate_bridge" to Station("golden_gate_bridge", "Golden Gate Bridge Plaza", TransitType.REGIONAL_BUS, "Iconic bridge vistas and visitor center.", 37.8105, -122.4771, listOf(TransitType.REGIONAL_BUS, TransitType.MUNI_BUS), true, listOf("Bridge Vista Point"))
    )

    // --- ROUTES ---
    val ROUTES = mapOf(
        // Muni Metro
        "J" to Route("J", "J Church", "J Church Metro Line", TransitType.MUNI_METRO, Color(0xFFE0A900), false), // Golden/Yellow
        "K" to Route("K", "K Ingleside", "K Ingleside Metro Line", TransitType.MUNI_METRO, Color(0xFF009688), true), // Teal
        "L" to Route("L", "L Taraval", "L Taraval Metro Line (Simulated Bus Replacement)", TransitType.MUNI_METRO, Color(0xFF9C27B0), true), // Purple
        "M" to Route("M", "M Ocean View", "M Ocean View Metro Line", TransitType.MUNI_METRO, Color(0xFF2196F3), true), // Blue
        "N" to Route("N", "N Judah", "N Judah Metro Line (Busiest Line)", TransitType.MUNI_METRO, Color(0xFFE91E63), true), // Coral Red / Pink
        "T" to Route("T", "T Third Street", "T Third Central Subway Line", TransitType.MUNI_METRO, Color(0xFFD32F2F), true), // Red

        // BART Lines (named by endpoints/colors)
        "BART_YELLOW" to Route("BART_YELLOW", "Yellow Line", "Antioch to SFO / Millbrae", TransitType.BART, Color(0xFFFFD54F), true),
        "BART_RED" to Route("BART_RED", "Red Line", "Richmond to SFO / Millbrae", TransitType.BART, Color(0xFFEF5350), true),
        "BART_BLUE" to Route("BART_BLUE", "Blue Line", "Dublin/Pleasanton to Daly City", TransitType.BART, Color(0xFF42A5F5), true),
        "BART_GREEN" to Route("BART_GREEN", "Green Line", "Berryessa to Daly City", TransitType.BART, Color(0xFF66BB6A), true),

        // Caltrain
        "CALTRAIN" to Route("CALTRAIN", "Caltrain", "Peninsula Commuter Service", TransitType.CALTRAIN, Color(0xFFE11932), true),

        // Cable Cars
        "CC_PH" to Route("CC_PH", "Powell-Hyde", "Powell-Hyde Cable Car Line", TransitType.CABLE_CAR, Color(0xFFC5A059), false),
        "CC_PM" to Route("CC_PM", "Powell-Mason", "Powell-Mason Cable Car Line", TransitType.CABLE_CAR, Color(0xFFC5A059), false),
        "CC_CA" to Route("CC_CA", "California", "California Cable Car Line", TransitType.CABLE_CAR, Color(0xFFC5A059), false),

        // Streetcars & Buses
        "F" to Route("F", "F Market", "F Market & Wharves Historic Streetcar", TransitType.STREETCAR, Color(0xFFFFA726), true),
        "MUNI_38" to Route("MUNI_38", "38 Geary", "38 Geary Rapid Bus", TransitType.MUNI_BUS, Color(0xFFE53935), true),
        "MUNI_14" to Route("MUNI_14", "14 Mission", "14 Mission Local Bus", TransitType.MUNI_BUS, Color(0xFFE53935), true),
        "GG_BUS" to Route("GG_BUS", "GGT 101", "Golden Gate Transit 101 Bus", TransitType.REGIONAL_BUS, Color(0xFF1E88E5), true)
    )

    // --- ROUTE PATTERNS ---
    val ROUTE_PATTERNS = listOf(
        // N Judah
        RoutePattern("N_IB", "N", "Inbound", listOf("ocean_beach", "west_portal", "forest_hill", "castro", "van_ness", "civic_center", "powell", "montgomery", "embarcadero", "caltrain_sf")),
        RoutePattern("N_OB", "N", "Outbound", listOf("caltrain_sf", "embarcadero", "montgomery", "powell", "civic_center", "van_ness", "castro", "forest_hill", "west_portal", "ocean_beach")),

        // J Church
        RoutePattern("J_IB", "J", "Inbound", listOf("balboa_park", "noe_valley", "castro", "van_ness", "civic_center", "powell", "montgomery", "embarcadero")),
        RoutePattern("J_OB", "J", "Outbound", listOf("embarcadero", "montgomery", "powell", "civic_center", "van_ness", "castro", "noe_valley", "balboa_park")),

        // T Third (Central Subway - Chinatown to Mission Bay & Dogpatch)
        RoutePattern("T_IB", "T", "Inbound", listOf("dogpatch", "mission_bay", "caltrain_sf", "union_square", "chinatown")),
        RoutePattern("T_OB", "T", "Outbound", listOf("chinatown", "union_square", "caltrain_sf", "mission_bay", "dogpatch")),

        // BART Yellow Line (Antioch -> SFO)
        RoutePattern("BART_Y_IB", "BART_YELLOW", "Inbound", listOf("berkeley", "oakland_12th", "embarcadero", "montgomery", "powell", "civic_center", "16th_mission", "24th_mission", "balboa_park", "daly_city", "sfo")),
        RoutePattern("BART_Y_OB", "BART_YELLOW", "Outbound", listOf("sfo", "daly_city", "balboa_park", "24th_mission", "16th_mission", "civic_center", "powell", "montgomery", "embarcadero", "oakland_12th", "berkeley")),

        // BART Red Line (Richmond -> SFO)
        RoutePattern("BART_R_IB", "BART_RED", "Inbound", listOf("berkeley", "oakland_12th", "embarcadero", "montgomery", "powell", "civic_center", "16th_mission", "24th_mission", "balboa_park", "daly_city", "sfo")),

        // BART Blue Line (Daly City -> East Bay)
        RoutePattern("BART_B_IB", "BART_BLUE", "Inbound", listOf("daly_city", "balboa_park", "24th_mission", "16th_mission", "civic_center", "powell", "montgomery", "embarcadero", "oakland_12th")),

        // Caltrain (SF -> San Jose)
        RoutePattern("CAL_OB", "CALTRAIN", "Outbound", listOf("caltrain_sf", "dogpatch", "daly_city", "palo_alto", "san_jose")),
        RoutePattern("CAL_IB", "CALTRAIN", "Inbound", listOf("san_jose", "palo_alto", "daly_city", "dogpatch", "caltrain_sf")),

        // Cable Car (Powell-Hyde)
        RoutePattern("CC_PH_IB", "CC_PH", "Inbound", listOf("powell", "union_square", "chinatown", "fisherman_wharf")),
        RoutePattern("CC_PH_OB", "CC_PH", "Outbound", listOf("fisherman_wharf", "chinatown", "union_square", "powell")),

        // Historic F Streetcar (Market St to Wharf)
        RoutePattern("F_IB", "F", "Inbound", listOf("castro", "van_ness", "civic_center", "powell", "montgomery", "embarcadero", "fisherman_wharf")),
        RoutePattern("F_OB", "F", "Outbound", listOf("fisherman_wharf", "embarcadero", "montgomery", "powell", "civic_center", "van_ness", "castro")),

        // GGT Bus 101 (Golden Gate Bridge connection)
        RoutePattern("GG_101_OB", "GG_BUS", "Outbound", listOf("civic_center", "powell", "golden_gate_bridge")),
        RoutePattern("GG_101_IB", "GG_BUS", "Inbound", listOf("golden_gate_bridge", "powell", "civic_center"))
    )

    // --- ROUTING GRAPH EDGES ---
    val EDGES: List<GraphEdge> = buildList {
        // We will programmatically generate edges from the Route Patterns to keep everything in sync!
        for (pattern in ROUTE_PATTERNS) {
            val route = ROUTES[pattern.routeId] ?: continue
            val stops = pattern.stops
            for (i in 0 until stops.size - 1) {
                val from = stops[i]
                val to = stops[i + 1]

                // Standard Transit Travel Durations
                val duration = when {
                    // Muni Subway section (Embarcadero <-> West Portal)
                    (from == "embarcadero" && to == "montgomery") || (from == "montgomery" && to == "embarcadero") -> 2.0
                    (from == "montgomery" && to == "powell") || (from == "powell" && to == "montgomery") -> 2.0
                    (from == "powell" && to == "civic_center") || (from == "civic_center" && to == "powell") -> 2.0
                    (from == "civic_center" && to == "van_ness") || (from == "van_ness" && to == "civic_center") -> 3.0
                    (from == "van_ness" && to == "castro") || (from == "castro" && to == "van_ness") -> 4.0
                    (from == "castro" && to == "forest_hill") || (from == "forest_hill" && to == "castro") -> 5.0
                    (from == "forest_hill" && to == "west_portal") || (from == "west_portal" && to == "forest_hill") -> 3.0

                    // Sunset (West Portal <-> Ocean Beach)
                    (from == "west_portal" && to == "ocean_beach") || (from == "ocean_beach" && to == "west_portal") -> 15.0

                    // J Church outer segment
                    (from == "noe_valley" && to == "balboa_park") || (from == "balboa_park" && to == "noe_valley") -> 12.0
                    (from == "noe_valley" && to == "castro") || (from == "castro" && to == "noe_valley") -> 6.0

                    // Central Subway (T Third)
                    (from == "chinatown" && to == "union_square") || (from == "union_square" && to == "chinatown") -> 3.0
                    (from == "union_square" && to == "caltrain_sf") || (from == "caltrain_sf" && to == "union_square") -> 6.0
                    (from == "caltrain_sf" && to == "mission_bay") || (from == "mission_bay" && to == "caltrain_sf") -> 4.0
                    (from == "mission_bay" && to == "dogpatch") || (from == "dogpatch" && to == "mission_bay") -> 5.0

                    // BART (Market Subway <-> Mission <-> Daly City <-> SFO)
                    (from == "civic_center" && to == "16th_mission") || (from == "16th_mission" && to == "civic_center") -> 3.0
                    (from == "16th_mission" && to == "24th_mission") || (from == "24th_mission" && to == "16th_mission") -> 2.0
                    (from == "24th_mission" && to == "balboa_park") || (from == "balboa_park" && to == "24th_mission") -> 5.0
                    (from == "balboa_park" && to == "daly_city") || (from == "daly_city" && to == "balboa_park") -> 4.0
                    (from == "daly_city" && to == "sfo") || (from == "sfo" && to == "daly_city") -> 16.0

                    // BART East Bay
                    (from == "embarcadero" && to == "oakland_12th") || (from == "oakland_12th" && to == "embarcadero") -> 8.0
                    (from == "oakland_12th" && to == "berkeley") || (from == "berkeley" && to == "oakland_12th") -> 12.0

                    // Caltrain
                    (from == "caltrain_sf" && to == "dogpatch") || (from == "dogpatch" && to == "caltrain_sf") -> 4.0
                    (from == "dogpatch" && to == "daly_city") || (from == "daly_city" && to == "dogpatch") -> 10.0
                    (from == "daly_city" && to == "palo_alto") || (from == "palo_alto" && to == "daly_city") -> 22.0
                    (from == "palo_alto" && to == "san_jose") || (from == "san_jose" && to == "palo_alto") -> 20.0

                    // Cable Car / Streetcar
                    (from == "powell" && to == "union_square") || (from == "union_square" && to == "powell") -> 2.0
                    (from == "union_square" && to == "chinatown") || (from == "chinatown" && to == "union_square") -> 4.0
                    (from == "chinatown" && to == "fisherman_wharf") || (from == "fisherman_wharf" && to == "chinatown") -> 8.0
                    (from == "embarcadero" && to == "fisherman_wharf") || (from == "fisherman_wharf" && to == "embarcadero") -> 10.0

                    // GGT Bus
                    (from == "powell" && to == "golden_gate_bridge") || (from == "golden_gate_bridge" && to == "powell") -> 25.0

                    else -> 5.0 // default
                }

                val fare = when (route.type) {
                    TransitType.BART -> {
                        // BART distance-based calculation
                        if (from == "sfo" || to == "sfo") 10.55
                        else if ((from == "embarcadero" && to == "berkeley") || (from == "berkeley" && to == "embarcadero")) 4.85
                        else 2.30 // city rate
                    }
                    TransitType.CALTRAIN -> {
                        if (from == "san_jose" || to == "san_jose") 10.50
                        else if (from == "palo_alto" || to == "palo_alto") 8.25
                        else 3.75 // standard zone
                    }
                    TransitType.CABLE_CAR -> 8.00 // flat high rate
                    else -> 2.50 // Muni standard flat rate
                }

                // Add edge to graph
                add(GraphEdge(from, to, route.type, route.id, duration, fare, route.isStepFree))
            }
        }

        // Add core WALKING Transfer edges between stations
        // Powell Muni <-> Powell CC <-> Union Square
        add(GraphEdge("powell", "union_square", TransitType.WALK, null, 4.0, 0.0, true))
        add(GraphEdge("union_square", "powell", TransitType.WALK, null, 4.0, 0.0, true))

        // Embarcadero <-> Cable car / Streetcar
        add(GraphEdge("embarcadero", "caltrain_sf", TransitType.WALK, null, 20.0, 0.0, true)) // walking is slow, transfer by train is better
        add(GraphEdge("caltrain_sf", "dogpatch", TransitType.WALK, null, 15.0, 0.0, true))

        // Daly City BART <-> Caltrain Daly City
        add(GraphEdge("daly_city", "daly_city", TransitType.WALK, null, 0.5, 0.0, true))
    }

    // --- TOURIST SUGGESTIONS ---
    val RECOMMENDED_TRIPS = listOf(
        RecommendedTrip(
            "Golden Gate Bridge",
            "Walk across the iconic suspension bridge",
            "golden_gate_bridge",
            "GGT Bus 101 from Civic Center/Powell",
            "sf_transit_hero",
            "Hop on the Golden Gate Transit 101 or Muni 28 to reach the Golden Gate Bridge Plaza directly from downtown. Walk the scenic 1.7-mile length and marvel at the headlands!"
        ),
        RecommendedTrip(
            "Fisherman's Wharf & Pier 39",
            "Sea lions, clam chowder, and bay views",
            "fisherman_wharf",
            "F Market Streetcar or Powell-Hyde Cable Car",
            "sf_transit_hero",
            "Ride the historic F Market streetcar along the Embarcadero, or hop on the classic Powell-Hyde Cable Car for a rollercoaster ride over Nob Hill directly to the waterfront."
        ),
        RecommendedTrip(
            "Chinatown",
            "Explore historic alleys and dim sum",
            "chinatown",
            "Muni T Third Metro (Central Subway)",
            "sf_transit_hero",
            "Take the ultra-modern T Third central subway directly to the Chinatown-Rose Pak station. Step out right onto Stockton Street in the heart of North America's oldest Chinatown."
        ),
        RecommendedTrip(
            "Mission District Murals",
            "Sun, culture, and world-class burritos",
            "24th_mission",
            "BART Yellow Line to 24th St Mission",
            "sf_transit_hero",
            "Take BART straight to 24th Street. Wander down Balmy Alley to view stunning, politically-charged community murals, and pop into La Taqueria for an award-winning mission burrito."
        )
    )
}
