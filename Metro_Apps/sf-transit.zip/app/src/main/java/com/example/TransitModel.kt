package com.example

import androidx.compose.ui.graphics.Color
import java.util.UUID

// --- CORE GRAPH & NETWORK DEFINITIONS ---

enum class TransitType(val displayName: String, val brandColor: Color, val iconName: String) {
    MUNI_METRO("Muni Metro", Color(0xFFD32F2F), "subway"),
    MUNI_BUS("Muni Bus", Color(0xFFE53935), "directions_bus"),
    BART("BART", Color(0xFF00529B), "train"),
    CALTRAIN("Caltrain", Color(0xFFE11932), "tram"),
    CABLE_CAR("Cable Car", Color(0xFFC5A059), "gavel"),
    STREETCAR("Historic Streetcar", Color(0xFFD4AF37), "filter_vintage"),
    REGIONAL_BUS("Regional Bus", Color(0xFF1E88E5), "directions_bus"),
    WALK("Walk", Color(0xFF757575), "directions_walk")
}

data class Station(
    val id: String,
    val name: String,
    val type: TransitType,
    val description: String,
    val latitude: Double,
    val longitude: Double,
    val supportedTypes: List<TransitType> = listOf(type),
    val isAccessible: Boolean = true,
    val exits: List<String> = emptyList()
)

data class Route(
    val id: String,
    val name: String,
    val longName: String,
    val type: TransitType,
    val color: Color,
    val isStepFree: Boolean = true
)

data class RoutePattern(
    val id: String,
    val routeId: String,
    val direction: String, // "Inbound" or "Outbound"
    val stops: List<String> // Station IDs
)

// --- GRAPH NETWORK ELEMENTS ---

data class GraphNode(
    val id: String, // usually "station_id"
    val station: Station
)

data class GraphEdge(
    val sourceId: String,
    val targetId: String,
    val type: TransitType,
    val routeId: String?,
    val durationMin: Double,
    val baseFare: Double,
    val isAccessible: Boolean = true
)

// --- FARE & PAYMENT SYSTEM ---

enum class FareCategory {
    ADULT, YOUTH, SENIOR, CLIPPER_DISCOUNT, FREE
}

data class ClipperCard(
    val cardId: String = "4125-8894-3201",
    val balance: Double = 12.50,
    val recentTrips: List<ClipperTrip> = emptyList(),
    val passType: String? = null, // "Muni Monthly Pass"
    val isTransferActive: Boolean = false,
    val transferExpiryTime: Long = 0L // Timestamp
)

data class ClipperTrip(
    val date: String,
    val routeName: String,
    val type: TransitType,
    val fare: Double,
    val startStation: String,
    val endStation: String
)

// --- VEHICLE SIMULATOR ---

enum class VehicleStatus {
    ON_TIME, DELAYED, SIMULATED
}

data class Vehicle(
    val id: String,
    val routeId: String,
    val routeName: String,
    val type: TransitType,
    val direction: String,
    val latitude: Double,
    val longitude: Double,
    val nextStopId: String,
    val speedMph: Double,
    val occupancyEstimate: Double, // 0.0 to 1.0 (empty to full)
    val delayMin: Int = 0,
    val status: VehicleStatus = VehicleStatus.ON_TIME,
    val lastUpdateMs: Long = System.currentTimeMillis()
)

// --- SERVICE ALERTS ---

enum class AlertSeverity {
    MINOR, MAJOR, SEVERE
}

enum class AlertCategory {
    DELAY, CLOSURE, ELEVATOR_OUTAGE, SPECIAL_EVENT, EMERGENCY
}

data class ServiceAlert(
    val id: String,
    val title: String,
    val description: String,
    val affectedRoutes: List<String>, // route IDs
    val affectedStations: List<String>, // station IDs
    val severity: AlertSeverity,
    val category: AlertCategory,
    val status: String = "Active"
)

// --- JOURNEY PLANNER ---

data class JourneyRequest(
    val fromStationId: String,
    val toStationId: String,
    val accessibilityFilter: Boolean = false,
    val routeRanking: String = "FASTEST", // "FASTEST", "FEWEST_TRANSFERS", "LEAST_WALKING"
    val departureTime: String = "NOW", // "NOW", "8:00 AM", etc.
    val walkingToleranceMin: Int = 15
)

data class JourneyLeg(
    val type: TransitType,
    val routeId: String?,
    val routeName: String,
    val routeColor: Color,
    val fromStation: Station,
    val toStation: Station,
    val durationMin: Int,
    val startStopIndex: Int = 0,
    val endStopIndex: Int = 0,
    val intermediateStops: List<String> = emptyList(),
    val instructions: String,
    val fare: Double = 0.0,
    val isStepFree: Boolean = true
)

data class Journey(
    val id: String = UUID.randomUUID().toString(),
    val legs: List<JourneyLeg>,
    val totalDurationMin: Int,
    val totalWalkingMin: Int,
    val transferCount: Int,
    val totalFare: Double,
    val isAccessible: Boolean = true,
    val serviceStatus: String = "Normal Service"
)

// --- OTHER STRUCTURES ---

data class FavoritePlace(
    val name: String,
    val stationId: String,
    val iconName: String // "home", "work", "airport", "star"
)

data class RecommendedTrip(
    val title: String,
    val subtitle: String,
    val destinationId: String,
    val recommendedRouteDesc: String,
    val imageResName: String,
    val description: String
)
