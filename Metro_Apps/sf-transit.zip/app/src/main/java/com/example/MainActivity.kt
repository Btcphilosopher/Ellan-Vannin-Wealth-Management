package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplaneTicket
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.BayAreaBlue
import com.example.ui.theme.DarkGraphite
import com.example.ui.theme.FogGrey
import com.example.ui.theme.GoldenAccent
import com.example.ui.theme.MuniRed
import com.example.ui.theme.OffBlack
import com.example.ui.theme.SFTransitTheme
import com.example.ui.theme.WarmWhite

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()
    private val clipperViewModel: ClipperWalletViewModel by viewModels()
    private val aiViewModel: TransitAssistantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SFTransitTheme {
                val configuration = LocalConfiguration.current
                val isExpanded = configuration.screenWidthDp >= 840 // M3 standard tablet/desktop threshold

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (!isExpanded) {
                            // Bottom Nav for phone layout
                            BottomNavigationMenu()
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        if (isExpanded) {
                            DesktopThreePanelLayout()
                        } else {
                            MobileSinglePaneLayout()
                        }
                    }
                }
            }
        }
    }

    // --- BOTTOM NAVIGATION CORNERSTATE (MOBILE ONLY) ---
    private var currentMobileTab = mutableStateOf("home")

    @Composable
    fun BottomNavigationMenu() {
        val selectedTab = currentMobileTab.value

        NavigationBar(
            containerColor = OffBlack,
            tonalElevation = 8.dp,
            modifier = Modifier.testTag("bottom_nav_bar")
        ) {
            val tabs = listOf(
                Triple("home", "Home", Icons.Default.Home),
                Triple("planner", "Planner", Icons.Default.Navigation),
                Triple("map", "Map", Icons.Default.Map),
                Triple("clipper", "Clipper", Icons.Default.Wallet),
                Triple("ai", "Transit AI", Icons.Default.Psychology)
            )

            tabs.forEach { (tabId, label, icon) ->
                NavigationBarItem(
                    selected = selectedTab == tabId,
                    onClick = { currentMobileTab.value = tabId },
                    icon = { Icon(imageVector = icon, contentDescription = label) },
                    label = { Text(text = label, fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = WarmWhite,
                        selectedTextColor = GoldenAccent,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        indicatorColor = MuniRed
                    ),
                    modifier = Modifier.testTag("nav_tab_$tabId")
                )
            }
        }
    }

    // ==========================================
    // MOBILE SINGLE PANEL SCREEN CONTROLLER
    // ==========================================

    @Composable
    fun MobileSinglePaneLayout() {
        when (currentMobileTab.value) {
            "home" -> HomeScreenView()
            "planner" -> PlannerScreenView()
            "map" -> MapScreenView()
            "clipper" -> ClipperScreenView()
            "ai" -> AiAssistantScreenView()
        }
    }

    // ==========================================
    // MOBILE TABS & VIEWS
    // ==========================================

    @Composable
    fun HomeScreenView() {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Hero Image Illustration Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    // Try to load the generated custom illustration first, otherwise show fallback color
                    AsyncImage(
                        model = "/app/src/main/res/drawable/sf_transit_hero_1791098368329.jpg",
                        contentDescription = "SF Transit Line",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                        error = painterResource(id = android.R.drawable.ic_dialog_map)
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.55f))
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "SAN FRANCISCO TRANSIT",
                                color = WarmWhite,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "MOVE THROUGH THE CITY.",
                                color = GoldenAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )
                        }

                        Text(
                            text = "THE CITY, CONNECTED.",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Quick Departures Summary box for Powell Interchange
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "NEXT DEPARTURES (POWELL)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MuniRed
                            )
                            Icon(imageVector = Icons.Default.NearMe, contentDescription = null, tint = MuniRed, modifier = Modifier.size(16.dp))
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Dynamic calculation
                        val deps = mainViewModel.getDeparturesForStation("powell").take(3)
                        deps.forEach { dep ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    TransitBadge(type = dep.type, text = dep.routeName, color = dep.routeColor)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = dep.destination, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(
                                    text = "${dep.minutesRemaining} MIN",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MuniRed
                                )
                            }
                        }
                    }
                }
            }

            // Quick Actions Links
            item {
                Column {
                    Text(
                        text = "QUICK ACTIONS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val actions = listOf(
                            Triple("Plan Trip", Icons.Default.Navigation, "planner"),
                            Triple("Metro Map", Icons.Default.Map, "map"),
                            Triple("Clipper Pass", Icons.Default.Wallet, "clipper"),
                            Triple("SF Transit AI", Icons.Default.Psychology, "ai")
                        )

                        actions.forEach { (label, icon, tabId) ->
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { currentMobileTab.value = tabId },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(imageVector = icon, contentDescription = label, tint = BayAreaBlue, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = label,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Tourist suggested itineraries card list
            item {
                Text(
                    text = "EXPLORE SAN FRANCISCO",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
            }

            items(TransitData.RECOMMENDED_TRIPS) { trip ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            mainViewModel.selectFromStation("powell") // start from Powell hub
                            mainViewModel.selectToStation(trip.destinationId)
                            currentMobileTab.value = "planner"
                        }
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.AirplaneTicket, contentDescription = null, tint = GoldenAccent, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = trip.title, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(text = trip.subtitle, fontSize = 11.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Transit: ${trip.recommendedRouteDesc}", fontSize = 10.sp, color = BayAreaBlue, fontWeight = FontWeight.SemiBold)
                        }
                        Icon(imageVector = Icons.Default.Navigation, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }

    @Composable
    fun PlannerScreenView() {
        val activeCompanion by mainViewModel.activeCompanionJourney.collectAsState()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
        ) {
            // Quick scenario picker
            DemoScenariosPanel(mainViewModel)

            Divider()

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }

                // Search inputs
                item { JourneySearchForm(mainViewModel) }

                // Dynamic WHAT IF simulation toggles
                item { WhatIfDisruptionSimulatorCard() }

                // Live route results list
                item {
                    Text(
                        text = "LIVE ROUTE OPTIONS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                }

                item {
                    JourneyResultsList(
                        viewModel = mainViewModel,
                        onRouteSelectedForCompanion = { mainViewModel.startCompanionTrip(it) }
                    )
                }

                item { Spacer(modifier = Modifier.height(32.dp)) }
            }

            // Interactive navigation companion layer at the bottom
            AnimatedVisibility(visible = activeCompanion != null) {
                TripCompanionOverlay(mainViewModel)
            }
        }
    }

    @Composable
    fun MapScreenView() {
        val selectedStationId by mainViewModel.selectedStationId.collectAsState()

        Box(modifier = Modifier.fillMaxSize()) {
            InteractiveMetroMap(viewModel = mainViewModel, modifier = Modifier.fillMaxSize())

            // floating station departures overlay
            if (selectedStationId != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                        .fillMaxWidth()
                ) {
                    StationDeparturesCard(mainViewModel)
                }
            }
        }
    }

    @Composable
    fun ClipperScreenView() {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { ClipperWalletView(clipperViewModel) }
        }
    }

    @Composable
    fun AiAssistantScreenView() {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(16.dp)
        ) {
            TransitAiAssistantPanel(
                assistantViewModel = aiViewModel,
                onRouteParamsParsed = { from, to, stepFree, rank ->
                    mainViewModel.selectFromStation(from)
                    mainViewModel.selectToStation(to)
                    mainViewModel.toggleAccessibility(stepFree)
                    mainViewModel.selectRouteRanking(rank)
                    // auto redirect to planner to show path
                    currentMobileTab.value = "planner"
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    // ==========================================
    // RESPONSIVE TABLET / DESKTOP DESIGNS
    // ==========================================

    @Composable
    fun DesktopThreePanelLayout() {
        val selectedStationId by mainViewModel.selectedStationId.collectAsState()
        val activeCompanion by mainViewModel.activeCompanionJourney.collectAsState()

        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(WarmWhite)
        ) {
            // PANEL 1: JOURNEY SEARCHES, AI AND WHAT-IF (Width: ~340dp)
            Column(
                modifier = Modifier
                    .width(360.dp)
                    .fillMaxHeight()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "SF TRANSIT PLANNER",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = MuniRed
                )

                DemoScenariosPanel(mainViewModel)

                JourneySearchForm(mainViewModel)

                WhatIfDisruptionSimulatorCard()

                // AI panel inside left column
                TransitAiAssistantPanel(
                    assistantViewModel = aiViewModel,
                    onRouteParamsParsed = { from, to, stepFree, rank ->
                        mainViewModel.selectFromStation(from)
                        mainViewModel.selectToStation(to)
                        mainViewModel.toggleAccessibility(stepFree)
                        mainViewModel.selectRouteRanking(rank)
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            // PANEL 2: INTERACTIVE METRO CANVAS MAP (Fills center viewport)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .border(1.dp, Color.LightGray)
            ) {
                InteractiveMetroMap(viewModel = mainViewModel, modifier = Modifier.fillMaxSize())
            }

            // PANEL 3: NEXT DEPARTURES, ROUTE OPTIONS & ALERTS (Width: ~380dp)
            Column(
                modifier = Modifier
                    .width(400.dp)
                    .fillMaxHeight()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // If navigation companion active, pin it to the top of side pane
                if (activeCompanion != null) {
                    TripCompanionOverlay(mainViewModel)
                }

                // If a station is selected on the map, show next departures, otherwise show overall alerts
                if (selectedStationId != null) {
                    StationDeparturesCard(mainViewModel)
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "STATION PAGE (MAP SHORTCUT)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Click any station circle on the interactive map to load real-time arrival departures here.",
                                fontSize = 11.sp,
                                color = Color.DarkGray
                            )
                        }
                    }
                }

                ServiceAlertsPanel()

                // Clipper wallet inside desktop layout too!
                ClipperWalletView(clipperViewModel, modifier = Modifier.weight(1f))
            }
        }
    }

    // ==========================================
    // GENERAL UTILITIES / WIDGETS
    // ==========================================

    @Composable
    fun WhatIfDisruptionSimulatorCard() {
        val nJudah by mainViewModel.disruptionNJudah.collectAsState()
        val elevator by mainViewModel.disruptionPowellElevator.collectAsState()
        val tube by mainViewModel.disruptionBartTube.collectAsState()
        val closure by mainViewModel.disruptionMarketClosure.collectAsState()

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MuniRed, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SERVICE DISRUPTION SIMULATOR ('WHAT-IF')",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SimulatorToggleRow(label = "N Judah Suspended", checked = nJudah, onCheckedChange = { mainViewModel.setDisruptionNJudah(it) })
                    SimulatorToggleRow(label = "Powell Elevator Out of Service", checked = elevator, onCheckedChange = { mainViewModel.setDisruptionPowellElevator(it) })
                    SimulatorToggleRow(label = "BART Transbay Tunnel Delay", checked = tube, onCheckedChange = { mainViewModel.setDisruptionBartTube(it) })
                    SimulatorToggleRow(label = "Market Street Track Obstruction", checked = closure, onCheckedChange = { mainViewModel.setDisruptionMarketClosure(it) })
                }
            }
        }
    }

    @Composable
    fun SimulatorToggleRow(
        label: String,
        checked: Boolean,
        onCheckedChange: (Boolean) -> Unit
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, fontSize = 11.sp, color = Color.DarkGray)
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(checkedThumbColor = MuniRed, checkedTrackColor = MuniRed.copy(alpha = 0.5f)),
                modifier = Modifier.scale(0.7f).testTag("switch_${label.lowercase().replace(" ", "_")}")
            )
        }
    }
}
