package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = MuniRed,
    secondary = BayAreaBlue,
    tertiary = GoldenAccent,
    background = OffBlack,
    surface = DarkGraphite,
    onPrimary = WarmWhite,
    onSecondary = WarmWhite,
    onTertiary = OffBlack,
    onBackground = WarmWhite,
    onSurface = WarmWhite
)

private val LightColorScheme = lightColorScheme(
    primary = MuniRed,
    secondary = BayAreaBlue,
    tertiary = GoldenAccent,
    background = WarmWhite,
    surface = FogGreyLight,
    onPrimary = WarmWhite,
    onSecondary = WarmWhite,
    onTertiary = OffBlack,
    onBackground = OffBlack,
    onSurface = OffBlack
)

@Composable
fun SFTransitTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
