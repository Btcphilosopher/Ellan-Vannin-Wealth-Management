package com.example

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AirplaneTicket
import androidx.compose.material.icons.filled.AirportShuttle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Subway
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberDelay
import com.example.ui.theme.BayAreaBlue
import com.example.ui.theme.DarkGraphite
import com.example.ui.theme.FogGrey
import com.example.ui.theme.GoldenAccent
import com.example.ui.theme.GreenOnTime
import com.example.ui.theme.MuniRed
import com.example.ui.theme.OffBlack
import com.example.ui.theme.RedDisrupted

// ==========================================
// 1. CHIP / BADGE COMPONENTS
// ==========================================

@Composable
fun TransitBadge(
    type: TransitType,
    text: String,
    modifier: Modifier = Modifier,
    color: Color? = null
) {
    val bg = color ?: type.brandColor
    val icon = when (type) {
        TransitType.MUNI_METRO -> Icons.Default.Subway
        TransitType.BART -> Icons.Default.Train
        TransitType.CALTRAIN -> Icons.Default.Train
        TransitType.CABLE_CAR -> Icons.Default.Subway
        TransitType.STREETCAR -> Icons.Default.Subway
        TransitType.WALK -> Icons.Default.DirectionsWalk
        else -> Icons.Default.DirectionsBus
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = text,
            color = Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// ==========================================
// 2. DEMO JOURNEYS PICKER
// ==========================================

@Composable
fun DemoScenariosPanel(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val scenarios = listOf(
        "Powell → Embarcadero" to ("powell" to "embarcadero"),
        "Mission → SFO" to ("24th_mission" to "sfo"),
        "Ocean Beach → Downtown" to ("ocean_beach" to "embarcadero"),
        "Daly City → Fin. Dist" to ("daly_city" to "montgomery"),
        "SF → Berkeley" to ("embarcadero" to "berkeley"),
        "SF → San Jose" to ("caltrain_sf" to "san_jose")
    )

    Column(modifier = modifier.padding(8.dp)) {
        Text(
            text = "DEMO QUICK-LAUNCH JOURNEYS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(scenarios) { (label, endpoints) ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .clickable {
                            viewModel.selectFromStation(endpoints.first)
                            viewModel.selectToStation(endpoints.second)
                        }
                        .testTag("demo_scen_${label.lowercase().replace(" ", "_")}")
                ) {
                    Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. JOURNEY PLANNER SEARCH FORM
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneySearchForm(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val fromVal by viewModel.fromStationId.collectAsState()
    val toVal by viewModel.toStationId.collectAsState()
    val isStepFree by viewModel.accessibilityFilter.collectAsState()
    val ranking by viewModel.routeRanking.collectAsState()

    var fromExpanded by remember { mutableStateOf(false) }
    var toExpanded by remember { mutableStateOf(false) }

    val stationsList = TransitData.STATIONS.values.toList()

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "WHERE ARE YOU GOING?",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MuniRed,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // DEPARTURE SELECTOR
            Box(modifier = Modifier.fillMaxWidth()) {
                ExposedDropdownMenuBox(
                    expanded = fromExpanded,
                    onExpandedChange = { fromExpanded = !fromExpanded }
                ) {
                    OutlinedTextField(
                        value = TransitData.STATIONS[fromVal]?.name ?: "Select Origin",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("FROM") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = fromExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("input_from"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MuniRed,
                            focusedLabelColor = MuniRed
                        )
                    )

                    ExposedDropdownMenu(
                        expanded = fromExpanded,
                        onDismissRequest = { fromExpanded = false }
                    ) {
                        stationsList.forEach { station ->
                            DropdownMenuItem(
                                text = { Text(station.name) },
                                onClick = {
                                    viewModel.selectFromStation(station.id)
                                    fromExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // DESTINATION SELECTOR
            Box(modifier = Modifier.fillMaxWidth()) {
                ExposedDropdownMenuBox(
                    expanded = toExpanded,
                    onExpandedChange = { toExpanded = !toExpanded }
                ) {
                    OutlinedTextField(
                        value = TransitData.STATIONS[toVal]?.name ?: "Select Destination",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("TO") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = toExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("input_to"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MuniRed,
                            focusedLabelColor = MuniRed
                        )
                    )

                    ExposedDropdownMenu(
                        expanded = toExpanded,
                        onDismissRequest = { toExpanded = false }
                    ) {
                        stationsList.forEach { station ->
                            DropdownMenuItem(
                                text = { Text(station.name) },
                                onClick = {
                                    viewModel.selectToStation(station.id)
                                    toExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // CRITERIA & FILTERS
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // ACCESSIBILITY FILTER
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Accessible,
                        contentDescription = "Step-Free Route",
                        tint = if (isStepFree) MuniRed else Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Step-free only", fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Switch(
                        checked = isStepFree,
                        onCheckedChange = { viewModel.toggleAccessibility(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MuniRed, checkedTrackColor = MuniRed.copy(alpha = 0.5f)),
                        modifier = Modifier.scale(0.8f).testTag("accessibility_switch")
                    )
                }

                // QUICK REFRESH / PLAN TRIP BUTTON
                Button(
                    onClick = { viewModel.recalculateJourneys() },
                    colors = ButtonDefaults.buttonColors(containerColor = MuniRed),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("plan_trip_button")
                ) {
                    Icon(imageVector = Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "PLAN", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // PREFERENCE TABS (FASTEST, FEWEST TRANSFERS, LEAST WALKING)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "FASTEST" to "Fastest",
                    "FEWEST_TRANSFERS" to "Direct",
                    "LEAST_WALKING" to "Low Walk"
                ).forEach { (prefKey, label) ->
                    val isSelected = ranking == prefKey
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) MuniRed else FogGrey)
                            .clickable { viewModel.selectRouteRanking(prefKey) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else Color.Black,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. JOURNEY SEARCH RESULTS LIST
// ==========================================

@Composable
fun JourneyResultsList(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier,
    onRouteSelectedForCompanion: (Journey) -> Unit
) {
    val journeys by viewModel.plannedJourneys.collectAsState()

    Column(modifier = modifier) {
        if (journeys.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = RedDisrupted, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "NO SERVICE / PATH BLOCKED",
                        fontWeight = FontWeight.Bold,
                        color = Color.DarkGray,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Current toggled disruptions make this route impossible. Recalculate or disable active service alerts to restore.",
                        textAlign = TextAlign.Center,
                        color = Color.Gray,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(journeys) { journey ->
                    JourneyResultCard(
                        journey = journey,
                        onCompanionTap = { onRouteSelectedForCompanion(journey) }
                    )
                }
            }
        }
    }
}

@Composable
fun JourneyResultCard(
    journey: Journey,
    onCompanionTap: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${journey.totalDurationMin} MIN",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = MuniRed
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Walk ${journey.totalWalkingMin} min",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                Text(
                    text = "$${String.format("%.2f", journey.totalFare)}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = BayAreaBlue
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Connection Timeline visual segments
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                journey.legs.forEachIndexed { index, leg ->
                    if (index > 0) {
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier
                                .size(14.dp)
                                .padding(horizontal = 2.dp)
                        )
                    }

                    TransitBadge(
                        type = leg.type,
                        text = leg.routeName,
                        color = leg.routeColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Step instructions overview
            Column {
                journey.legs.forEach { leg ->
                    Row(
                        modifier = Modifier.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val dotColor = if (leg.type == TransitType.WALK) Color.Gray else leg.routeColor
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(dotColor)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = leg.instructions,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = Color.DarkGray
                        )
                    }
                }
            }

            Divider(modifier = Modifier.padding(vertical = 10.dp))

            // Start Companion mode trigger
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (journey.isAccessible) Icons.Default.Accessible else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (journey.isAccessible) GreenOnTime else AmberDelay,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (journey.isAccessible) "Fully Step-free" else "Contains Stairs / Transfer Outages",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (journey.isAccessible) GreenOnTime else AmberDelay
                    )
                }

                Button(
                    onClick = onCompanionTap,
                    colors = ButtonDefaults.buttonColors(containerColor = BayAreaBlue),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = ButtonDefaults.ContentPadding,
                    modifier = Modifier.height(32.dp)
                ) {
                    Icon(imageVector = Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "RIDE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==========================================
// 5. TRIP COMPANION / LIVE GUIDANCE MODULE
// ==========================================

@Composable
fun TripCompanionOverlay(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val trip by viewModel.activeCompanionJourney.collectAsState()
    val activeLegIndex by viewModel.currentNavigationLegIndex.collectAsState()

    if (trip == null) return

    val currentLeg = trip!!.legs.getOrNull(activeLegIndex) ?: return

    Card(
        colors = CardDefaults.cardColors(containerColor = OffBlack),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("trip_companion_panel")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.Green)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LIVE TRIP EN-ROUTE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Green
                    )
                }

                IconButton(
                    onClick = { viewModel.cancelCompanionTrip() },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Segment Progress line visualization
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                trip!!.legs.forEachIndexed { index, leg ->
                    val isActive = index == activeLegIndex
                    val isPast = index < activeLegIndex

                    val pillColor = if (isActive) leg.routeColor else (if (isPast) Color.DarkGray else Color.LightGray.copy(alpha = 0.3f))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(6.dp)
                            .padding(horizontal = 2.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(pillColor)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Current Leg Instruction Card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(currentLeg.routeColor),
                        contentAlignment = Alignment.Center
                    ) {
                        val legIcon = if (currentLeg.type == TransitType.WALK) Icons.Default.DirectionsWalk else Icons.Default.Subway
                        Icon(imageVector = legIcon, contentDescription = null, tint = Color.White)
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = "NEXT STEP (${currentLeg.durationMin} MIN)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldenAccent
                        )
                        Text(
                            text = currentLeg.instructions,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        if (currentLeg.intermediateStops.isNotEmpty()) {
                            Text(
                                text = "Via: ${currentLeg.intermediateStops.joinToString(", ")}",
                                fontSize = 10.sp,
                                color = Color.LightGray,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Total journey stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DESTINATION: ${TransitData.STATIONS[trip!!.legs.last().toStation.id]?.name}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.LightGray
                )

                Text(
                    text = "ARRIVING IN ~${trip!!.totalDurationMin} MIN",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }
    }
}

// ==========================================
// 6. STATION DEPARTURES CARD
// ==========================================

@Composable
fun StationDeparturesCard(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedId by viewModel.selectedStationId.collectAsState()
    if (selectedId == null) return

    val station = TransitData.STATIONS[selectedId] ?: return
    val departures = viewModel.getDeparturesForStation(selectedId!!)

    val activeAlerts by DisruptionSimulator.activeAlerts.collectAsState()
    val stationAlerts = activeAlerts.filter { it.affectedStations.contains(selectedId) }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Station Title & Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = station.name.uppercase(),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black
                    )
                    Text(
                        text = station.description,
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                // Close selection
                IconButton(onClick = { viewModel.selectStation(null) }) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Accessibility badges
            Row(verticalAlignment = Alignment.CenterVertically) {
                val hasElevatorOutage = stationAlerts.any { it.category == AlertCategory.ELEVATOR_OUTAGE }
                Icon(
                    imageVector = Icons.Default.Accessible,
                    contentDescription = null,
                    tint = if (hasElevatorOutage) RedDisrupted else GreenOnTime,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (hasElevatorOutage) "Elevator Out of Service" else "Step-free Elevator Access Available",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (hasElevatorOutage) RedDisrupted else GreenOnTime
                )
            }

            // Station alert warning box
            if (stationAlerts.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                stationAlerts.forEach { alert ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(RedDisrupted.copy(alpha = 0.15f))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = RedDisrupted, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = alert.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RedDisrupted)
                    }
                }
            }

            Divider(modifier = Modifier.padding(vertical = 12.dp))

            Text(
                text = "NEXT DEPARTURES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MuniRed,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            if (departures.isEmpty()) {
                Text(
                    text = "No upcoming departures scheduled for this platform.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    departures.forEach { dep ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(FogGrey.copy(alpha = 0.5f))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TransitBadge(type = dep.type, text = dep.routeName, color = dep.routeColor)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(text = dep.destination, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text(text = dep.direction, fontSize = 10.sp, color = Color.Gray)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Live countdown pill
                                val countdownBg = when (dep.statusString) {
                                    "LIVE" -> GreenOnTime
                                    "DELAYED" -> AmberDelay
                                    else -> Color.DarkGray
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(countdownBg)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${dep.minutesRemaining} MIN",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = dep.statusString,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = countdownBg
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 7. SERVICE ALERTS SYSTEM
// ==========================================

@Composable
fun ServiceAlertsPanel(
    modifier: Modifier = Modifier
) {
    val alerts by DisruptionSimulator.activeAlerts.collectAsState()

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "REGIONAL SERVICE ALERTS",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MuniRed,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            if (alerts.isEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = GreenOnTime, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "All systems operating normally.", fontSize = 13.sp)
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    alerts.forEach { alert ->
                        val borderCol = when (alert.severity) {
                            AlertSeverity.SEVERE -> RedDisrupted
                            AlertSeverity.MAJOR -> AmberDelay
                            else -> Color.Gray
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, borderCol, RoundedCornerShape(6.dp))
                                .background(borderCol.copy(alpha = 0.05f))
                                .padding(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = borderCol, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(text = alert.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = borderCol)
                                Text(text = alert.description, fontSize = 11.sp, color = Color.DarkGray)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 8. CLIPPER WALLET VIEW
// ==========================================

@Composable
fun ClipperWalletView(
    walletViewModel: ClipperWalletViewModel,
    modifier: Modifier = Modifier
) {
    val card by walletViewModel.clipperCard.collectAsState()
    val isTapping by walletViewModel.isTapping.collectAsState()
    val tapSuccess by walletViewModel.tapSuccess.collectAsState()

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth().testTag("clipper_wallet_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "CLIPPER WALLET",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = BayAreaBlue,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Dynamic card render
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(BayAreaBlue)
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CLIPPER®",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Icon(imageVector = Icons.Default.Wallet, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }

                    Column {
                        Text(
                            text = "BALANCE",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$${String.format("%.2f", card.balance)}",
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = card.cardId, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                        Text(
                            text = card.passType ?: "Clipper e-Cash",
                            color = GoldenAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Wallet operations row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { walletViewModel.addCash(10.0) },
                    colors = ButtonDefaults.buttonColors(containerColor = BayAreaBlue),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "+$10 CASH", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { walletViewModel.purchaseMuniPass() },
                    colors = ButtonDefaults.buttonColors(containerColor = if (card.passType != null) Color.Gray else GoldenAccent),
                    enabled = card.passType == null && card.balance >= 80.0,
                    modifier = Modifier.weight(1.5f)
                ) {
                    Text(text = if (card.passType != null) "PASS ACTIVE" else "BUY MUNI PASS ($80)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tap & Ride Simulation Terminal
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(OffBlack)
                    .clickable { walletViewModel.triggerTapAndRide {} }
                    .padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                if (isTapping) {
                    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                    val pulseScale by infiniteTransition.animateFloat(
                        initialValue = 1.0f,
                        targetValue = 1.1f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(600),
                            repeatMode = RepeatMode.Reverse
                        ), label = "pulse"
                    )

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.scale(pulseScale)
                    ) {
                        Icon(imageVector = Icons.Default.Wallet, contentDescription = null, tint = GoldenAccent, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "HOLD NEAR READER...", color = GoldenAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                } else if (tapSuccess) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = GreenOnTime, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "✓ FARE ACCEPTED", color = GreenOnTime, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.NearMe, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "SIMULATE TAP-TO-PAY GATE ENTRY", color = Color.LightGray, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(text = "Deducts $2.50 or applies transfer", color = Color.Gray, fontSize = 10.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Recent Trips List
            Text(
                text = "RECENT CLIPPER TRIPS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            if (card.recentTrips.isEmpty()) {
                Text(text = "No recent transactions found.", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    card.recentTrips.take(3).forEach { trip ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(FogGrey.copy(alpha = 0.3f))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = trip.routeName, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(text = "${trip.startStation} → ${trip.endStation}", fontSize = 10.sp, color = Color.Gray)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = if (trip.fare == 0.0) "FREE" else "-$${String.format("%.2f", trip.fare)}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (trip.fare == 0.0) GreenOnTime else Color.Black
                                )
                                Text(text = trip.date, fontSize = 8.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 9. AI TRANSIT ASSISTANT DIALOGUE
// ==========================================

@Composable
fun TransitAiAssistantPanel(
    assistantViewModel: TransitAssistantViewModel,
    onRouteParamsParsed: (fromId: String, toId: String, isStepFree: Boolean, ranking: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val chatHistory by assistantViewModel.chatHistory.collectAsState()
    val isAiLoading by assistantViewModel.isAiLoading.collectAsState()

    var queryText by remember { mutableStateOf("") }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "SF TRANSIT AI ASSISTANT",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MuniRed,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Chat Messages Container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 200.dp)
                    .background(FogGrey.copy(alpha = 0.2f))
                    .padding(8.dp)
            ) {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(chatHistory) { msg ->
                        val isAssistant = msg.sender == "assistant"
                        val bubbleColor = if (isAssistant) FogGrey.copy(alpha = 0.8f) else MuniRed.copy(alpha = 0.1f)
                        val align = if (isAssistant) Alignment.Start else Alignment.End

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            contentAlignment = if (isAssistant) Alignment.TopStart else Alignment.TopEnd
                        ) {
                            Column(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(bubbleColor)
                                    .padding(8.dp)
                                    .widthIn(max = 240.dp)
                            ) {
                                Text(
                                    text = if (isAssistant) "SF Transit AI" else "You",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isAssistant) BayAreaBlue else MuniRed
                                )
                                Text(text = msg.text, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Prompt query textfield
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = queryText,
                    onValueChange = { queryText = it },
                    placeholder = { Text("Ask: 'How do I go from Mission to Chinatown?'", fontSize = 12.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 40.dp)
                        .testTag("ai_prompt_input"),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MuniRed,
                        unfocusedBorderColor = Color.LightGray
                    )
                )

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = {
                        assistantViewModel.sendAiQuery(queryText) { from, to, stepFree, rank ->
                            onRouteParamsParsed(from, to, stepFree, rank)
                        }
                        queryText = ""
                    },
                    enabled = !isAiLoading && queryText.isNotBlank(),
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (queryText.isNotBlank()) MuniRed else Color.LightGray)
                        .testTag("ai_send_button")
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = "Send Prompt", tint = Color.White)
                }
            }
            if (isAiLoading) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "⚡ Gemini analyzing query structured parameters...", fontSize = 10.sp, color = MuniRed, fontWeight = FontWeight.Bold)
            }
        }
    }
}
