package com.example

import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    // --- SELECTIONS & SEARCH FIELDS ---
    val fromStationId = MutableStateFlow("powell")
    val toStationId = MutableStateFlow("embarcadero")
    val accessibilityFilter = MutableStateFlow(false)
    val routeRanking = MutableStateFlow("FASTEST") // FASTEST, FEWEST_TRANSFERS, LEAST_WALKING
    val departureTimeMode = MutableStateFlow("NOW") // NOW, DEPART_AT, ARRIVE_BY

    // --- CORE JOURNEYS ---
    private val _plannedJourneys = MutableStateFlow<List<Journey>>(emptyList())
    val plannedJourneys: StateFlow<List<Journey>> = _plannedJourneys.asStateFlow()

    private val _selectedJourney = MutableStateFlow<Journey?>(null)
    val selectedJourney: StateFlow<Journey?> = _selectedJourney.asStateFlow()

    // --- COMPANION / NAVIGATION MODE ---
    private val _activeCompanionJourney = MutableStateFlow<Journey?>(null)
    val activeCompanionJourney: StateFlow<Journey?> = _activeCompanionJourney.asStateFlow()

    private val _currentNavigationLegIndex = MutableStateFlow(0)
    val currentNavigationLegIndex: StateFlow<Int> = _currentNavigationLegIndex.asStateFlow()

    // --- SELECTED STATION DETAILS ---
    private val _selectedStationId = MutableStateFlow<String?>("powell")
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    // --- FAVORITES ---
    private val _favorites = MutableStateFlow<List<FavoritePlace>>(
        listOf(
            FavoritePlace("Home", "noe_valley", "home"),
            FavoritePlace("Work", "montgomery", "work"),
            FavoritePlace("SFO", "sfo", "flight"),
            FavoritePlace("Stanford", "palo_alto", "school")
        )
    )
    val favorites: StateFlow<List<FavoritePlace>> = _favorites.asStateFlow()

    // --- TOGGLED DISRUPTIONS SCENARIOS (WHAT IF?) ---
    private val _disruptionNJudah = MutableStateFlow(false)
    val disruptionNJudah = _disruptionNJudah.asStateFlow()

    private val _disruptionPowellElevator = MutableStateFlow(false)
    val disruptionPowellElevator = _disruptionPowellElevator.asStateFlow()

    private val _disruptionBartTube = MutableStateFlow(false)
    val disruptionBartTube = _disruptionBartTube.asStateFlow()

    private val _disruptionMarketClosure = MutableStateFlow(false)
    val disruptionMarketClosure = _disruptionMarketClosure.asStateFlow()

    // --- AUTOMATIC VEHICLE TICKING ---
    private var simulationJob: Job? = null

    init {
        // Run journey planning calculation on start-up
        recalculateJourneys()

        // Start simulation loop (tick vehicle simulation every 3 seconds)
        simulationJob = viewModelScope.launch {
            while (true) {
                delay(3000)
                VehicleSimulator.tickSimulation(DisruptionSimulator.activeAlerts.value)
                // If navigation companion is active, simulate progress
                advanceCompanionProgress()
            }
        }
    }

    fun selectFromStation(id: String) {
        fromStationId.value = id
        recalculateJourneys()
    }

    fun selectToStation(id: String) {
        toStationId.value = id
        recalculateJourneys()
    }

    fun selectRouteRanking(ranking: String) {
        routeRanking.value = ranking
        recalculateJourneys()
    }

    fun toggleAccessibility(enable: Boolean) {
        accessibilityFilter.value = enable
        recalculateJourneys()
    }

    fun selectStation(id: String?) {
        _selectedStationId.value = id
    }

    fun addFavorite(name: String, stationId: String, icon: String) {
        _favorites.update {
            it + FavoritePlace(name, stationId, icon)
        }
    }

    fun removeFavorite(stationId: String) {
        _favorites.update { list ->
            list.filter { it.stationId != stationId }
        }
    }

    fun planFavoriteJourney(fav: FavoritePlace) {
        fromStationId.value = "powell" // default starting point if Home isn't explicitly set
        toStationId.value = fav.stationId
        recalculateJourneys()
    }

    // Recalculates paths dynamically incorporating current filters & active disruptions
    fun recalculateJourneys() {
        viewModelScope.launch {
            val journeys = RoutingEngine.planRoute(
                startId = fromStationId.value,
                endId = toStationId.value,
                accessibilityFilter = accessibilityFilter.value,
                routeRanking = routeRanking.value,
                activeDisruptions = DisruptionSimulator.activeAlerts.value
            )
            _plannedJourneys.value = journeys
            if (journeys.isNotEmpty()) {
                _selectedJourney.value = journeys.first()
            } else {
                _selectedJourney.value = null
            }
        }
    }

    // Disruptions scenarios triggers
    fun setDisruptionNJudah(enable: Boolean) {
        _disruptionNJudah.value = enable
        DisruptionSimulator.toggleDisruption("disruption_n_judah", enable)
        recalculateJourneys()
    }

    fun setDisruptionPowellElevator(enable: Boolean) {
        _disruptionPowellElevator.value = enable
        DisruptionSimulator.toggleDisruption("disruption_powell_elevator", enable)
        recalculateJourneys()
    }

    fun setDisruptionBartTube(enable: Boolean) {
        _disruptionBartTube.value = enable
        DisruptionSimulator.toggleDisruption("disruption_bart_tube", enable)
        recalculateJourneys()
    }

    fun setDisruptionMarketClosure(enable: Boolean) {
        _disruptionMarketClosure.value = enable
        DisruptionSimulator.toggleDisruption("disruption_market_closure", enable)
        recalculateJourneys()
    }

    // Companion Mode operations
    fun startCompanionTrip(journey: Journey) {
        _activeCompanionJourney.value = journey
        _currentNavigationLegIndex.value = 0
    }

    fun cancelCompanionTrip() {
        _activeCompanionJourney.value = null
    }

    private fun advanceCompanionProgress() {
        val trip = _activeCompanionJourney.value ?: return
        val currentIndex = _currentNavigationLegIndex.value
        if (currentIndex < trip.legs.size - 1) {
            // Chance-based simulation progress increments (simulating boardings & transfers)
            if (Math.random() > 0.6) {
                _currentNavigationLegIndex.value = currentIndex + 1
            }
        }
    }

    // DYNAMIC DEPARTURES SOLVER FOR SELECTED STATION
    // Calculates arrival countdowns dynamically based on live vehicles moving on patterns
    fun getDeparturesForStation(stationId: String): List<DynamicDeparture> {
        val station = TransitData.STATIONS[stationId] ?: return emptyList()
        val simulatedVehicles = VehicleSimulator.vehicles.value
        val departures = mutableListOf<DynamicDeparture>()

        for (pattern in TransitData.ROUTE_PATTERNS) {
            val stopIndex = pattern.stops.indexOf(stationId)
            if (stopIndex == -1 || stopIndex == pattern.stops.size - 1) {
                continue // route does not stop here or ends here (no departures)
            }

            val route = TransitData.ROUTES[pattern.routeId] ?: continue

            // Find simulated vehicles running on this exact pattern that haven't reached this station yet
            val activeVehicles = simulatedVehicles.filter { v ->
                v.routeId == pattern.routeId && v.direction == pattern.direction
            }

            if (activeVehicles.isNotEmpty()) {
                activeVehicles.forEach { v ->
                    // Calculate simple mock arrival based on coordinate proximity
                    val remainingStops = pattern.stops.subList(0, stopIndex + 1).size
                    val timeEst = (remainingStops * 3 + (Math.random() * 2)).toInt().coerceAtLeast(1)

                    departures.add(
                        DynamicDeparture(
                            routeId = route.id,
                            routeName = route.name,
                            routeColor = route.color,
                            direction = pattern.direction,
                            destination = TransitData.STATIONS[pattern.stops.last()]?.name ?: "Terminus",
                            minutesRemaining = timeEst,
                            type = route.type,
                            statusString = if (v.status == VehicleStatus.DELAYED) "DELAYED" else "LIVE"
                        )
                    )
                }
            } else {
                // Return scheduled/simulated fallback fallback if no live train is active on the route
                departures.add(
                    DynamicDeparture(
                        routeId = route.id,
                        routeName = route.name,
                        routeColor = route.color,
                        direction = pattern.direction,
                        destination = TransitData.STATIONS[pattern.stops.last()]?.name ?: "Terminus",
                        minutesRemaining = 12,
                        type = route.type,
                        statusString = "SCHEDULED"
                    )
                )
                departures.add(
                    DynamicDeparture(
                        routeId = route.id,
                        routeName = route.name,
                        routeColor = route.color,
                        direction = pattern.direction,
                        destination = TransitData.STATIONS[pattern.stops.last()]?.name ?: "Terminus",
                        minutesRemaining = 24,
                        type = route.type,
                        statusString = "SCHEDULED"
                    )
                )
            }
        }

        return departures.sortedBy { it.minutesRemaining }.take(6)
    }

    override fun onCleared() {
        super.onCleared()
        simulationJob?.cancel()
    }
}

data class DynamicDeparture(
    val routeId: String,
    val routeName: String,
    val routeColor: Color,
    val direction: String,
    val destination: String,
    val minutesRemaining: Int,
    val type: TransitType,
    val statusString: String // LIVE, SCHEDULED, SIMULATED
)
