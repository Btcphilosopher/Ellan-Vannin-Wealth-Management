package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MuniRed = Color(0xFFD32F2F)
val MuniRedDark = Color(0xFF9A0007)
val BayAreaBlue = Color(0xFF1565C0)
val BayAreaBlueDark = Color(0xFF003C8F)
val WarmWhite = Color(0xFFFAF9F6)
val OffBlack = Color(0xFF121212)
val DarkGraphite = Color(0xFF1C1C1E)
val LightGraphite = Color(0xFF2C2C2E)
val FogGrey = Color(0xFFE5E5EA)
val FogGreyLight = Color(0xFFF2F2F7)
val GoldenAccent = Color(0xFFD4AF37)
val GoldenAccentMuted = Color(0xFFAA8010)

val GreenOnTime = Color(0xFF2E7D32)
val AmberDelay = Color(0xFFEF6C00)
val RedDisrupted = Color(0xFFC62828)
val GreyNoData = Color(0xFF757575)
