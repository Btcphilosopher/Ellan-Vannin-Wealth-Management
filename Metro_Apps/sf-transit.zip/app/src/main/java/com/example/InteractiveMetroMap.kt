package com.example

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkGraphite
import com.example.ui.theme.FogGrey
import com.example.ui.theme.GoldenAccent

@Composable
fun InteractiveMetroMap(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val vehicles by VehicleSimulator.vehicles.collectAsState()
    val activeAlerts by DisruptionSimulator.activeAlerts.collectAsState()
    val selectedStationId by viewModel.selectedStationId.collectAsState()

    // Map Offset and Zoom states
    var scale by remember { mutableStateOf(1.0f) }
    var offsetX by remember { mutableStateOf(-300f) }
    var offsetY by remember { mutableStateOf(-150f) }

    val textMeasurer = rememberTextMeasurer()

    // Map boundary bounds and scale conversions
    // SF coordinates boundaries roughly: Lat 37.60 to 37.90, Lng -122.52 to -122.15
    val minLat = 37.30
    val maxLat = 37.92
    val minLng = -122.55
    val maxLng = -121.85

    fun getX(lng: Double, width: Float): Float {
        val pct = (lng - minLng) / (maxLng - minLng)
        return (pct * width).toFloat()
    }

    fun getY(lat: Double, height: Float): Float {
        // Invert Y because Latitude increases upwards, screen pixels increase downwards
        val pct = (lat - minLat) / (maxLat - minLat)
        return ((1.0 - pct) * height).toFloat()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF9F8F6)) // Warm White Fog Map background
            .testTag("interactive_metro_map")
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX += dragAmount.x
                    offsetY += dragAmount.y
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { tapOffset ->
                    // Reverse-transform tap coordinates to find nearest station
                    val rawX = (tapOffset.x - offsetX) / scale
                    val rawY = (tapOffset.y - offsetY) / scale

                    var nearestStationId: String? = null
                    var minDistance = 50.0f // click threshold in map units

                    TransitData.STATIONS.forEach { (id, station) ->
                        // Calculate positions
                        // Assuming canvas width=1200f height=1200f as virtual dimensions
                        val sx = getX(station.longitude, 1600f)
                        val sy = getY(station.latitude, 1600f)

                        val dist = Math.sqrt(((sx - rawX) * (sx - rawX) + (sy - rawY) * (sy - rawY)).toDouble()).toFloat()
                        if (dist < minDistance) {
                            minDistance = dist
                            nearestStationId = id
                        }
                    }

                    if (nearestStationId != null) {
                        viewModel.selectStation(nearestStationId)
                    }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = 1600f
            val height = 1600f

            // Apply camera transform (pan & zoom)
            withTransform({
                translate(offsetX, offsetY)
                scale(scale, scale)
            }) {

                // --- 1. DRAW WATER (SF Bay & Pacific Ocean) ---
                // Simulating water bodies via elegant grid-background layers
                drawRect(
                    color = Color(0xFFD4E6F1), // Soft blue bay
                    topLeft = Offset(getX(-122.42, width), getY(37.92, height)),
                    size = androidx.compose.ui.geometry.Size(1200f, 1000f)
                )

                // --- 2. DRAW GOLDEN GATE BRIDGE (Iconic Civic design) ---
                val bridgeStart = Offset(getX(-122.4771, width), getY(37.8105, height))
                val bridgeEnd = Offset(getX(-122.478, width), getY(37.85, height))
                drawLine(
                    color = Color(0xFFD32F2F), // International Orange
                    start = bridgeStart,
                    end = bridgeEnd,
                    strokeWidth = 6f
                )

                // --- 3. DRAW TRANSIT LINES (METRO & BART CONNECTIONS) ---
                TransitData.ROUTE_PATTERNS.forEach { pattern ->
                    val route = TransitData.ROUTES[pattern.routeId] ?: return@forEach
                    val stops = pattern.stops
                    val isSuspended = activeAlerts.any { it.category == AlertCategory.CLOSURE && it.affectedRoutes.contains(route.id) }

                    for (i in 0 until stops.size - 1) {
                        val fromStation = TransitData.STATIONS[stops[i]] ?: continue
                        val toStation = TransitData.STATIONS[stops[i + 1]] ?: continue

                        val p1 = Offset(getX(fromStation.longitude, width), getY(fromStation.latitude, height))
                        val p2 = Offset(getX(toStation.longitude, width), getY(toStation.latitude, height))

                        // Draw background track shadow
                        drawLine(
                            color = Color.LightGray.copy(alpha = 0.5f),
                            start = p1,
                            end = p2,
                            strokeWidth = 8f
                        )

                        // Draw actual transit route
                        val pathEffect = if (route.type == TransitType.CABLE_CAR) {
                            androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        } else {
                            null
                        }
                        drawLine(
                            color = if (isSuspended) Color.Gray else route.color,
                            start = p1,
                            end = p2,
                            strokeWidth = 4f,
                            pathEffect = pathEffect
                        )
                    }
                }

                // --- 4. DRAW STATION NODES ---
                TransitData.STATIONS.forEach { (id, station) ->
                    val sx = getX(station.longitude, width)
                    val sy = getY(station.latitude, height)
                    val isSelected = id == selectedStationId

                    val isClosed = activeAlerts.any { it.category == AlertCategory.CLOSURE && it.affectedStations.contains(id) }

                    // Glow or shadow ring
                    drawCircle(
                        color = if (isSelected) GoldenAccent else (if (isClosed) Color.Red else Color.White),
                        radius = if (isSelected) 14f else 8f,
                        center = Offset(sx, sy)
                    )

                    drawCircle(
                        color = if (isClosed) Color.Gray else station.type.brandColor,
                        radius = if (isSelected) 8f else 5f,
                        center = Offset(sx, sy)
                    )

                    // Draw neighborhood or station label text elegantly
                    val textStyle = TextStyle(
                        color = if (isSelected) Color.Black else Color.DarkGray,
                        fontSize = if (isSelected) 12.sp else 9.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                    )
                    val textLayout = textMeasurer.measure(
                        text = station.name,
                        style = textStyle
                    )
                    drawText(
                        textLayoutResult = textLayout,
                        topLeft = Offset(sx + 12f, sy - 15f)
                    )
                }

                // --- 5. DRAW SIMULATED REAL-TIME VEHICLES ---
                vehicles.forEach { v ->
                    val vx = getX(v.longitude, width)
                    val vy = getY(v.latitude, height)
                    val isDelayed = v.status == VehicleStatus.DELAYED

                    // Vehicle circular pill representation pulsing
                    drawCircle(
                        color = Color.Black,
                        radius = 11f,
                        center = Offset(vx, vy)
                    )
                    drawCircle(
                        color = if (isDelayed) Color(0xFFEF6C00) else v.type.brandColor,
                        radius = 8f,
                        center = Offset(vx, vy)
                    )

                    // Draw route abbreviation inside vehicle
                    val textLayout = textMeasurer.measure(
                        text = v.routeName.take(2).uppercase(),
                        style = TextStyle(
                            color = Color.White,
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    drawText(
                        textLayoutResult = textLayout,
                        topLeft = Offset(vx - 7f, vy - 6f)
                    )
                }
            }
        }
    }
}
