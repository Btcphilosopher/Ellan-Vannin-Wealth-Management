package com.example

import android.os.SystemClock
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ui.theme.GreenOnTime
import com.example.ui.theme.AmberDelay
import com.example.ui.theme.RedDisrupted
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

// ==========================================
// 1. DISRUPTION SIMULATOR
// ==========================================

object DisruptionSimulator {
    private val _activeAlerts = MutableStateFlow<List<ServiceAlert>>(
        listOf(
            ServiceAlert(
                id = "alert_default_1",
                title = "F Market Heritage Spacing",
                description = "Streetcar service is running with slight delays due to waterfront parade clearance.",
                affectedRoutes = listOf("F"),
                affectedStations = emptyList(),
                severity = AlertSeverity.MINOR,
                category = AlertCategory.DELAY
            )
        )
    )
    val activeAlerts: StateFlow<List<ServiceAlert>> = _activeAlerts.asStateFlow()

    fun toggleDisruption(scenarioId: String, enable: Boolean) {
        val current = _activeAlerts.value.toMutableList()
        current.removeAll { it.id == scenarioId }

        if (enable) {
            val alert = when (scenarioId) {
                "disruption_n_judah" -> ServiceAlert(
                    id = "disruption_n_judah",
                    title = "N Judah Suspended",
                    description = "Muni Metro N Judah train service suspended due to overhead wire damage near Cole Valley.",
                    affectedRoutes = listOf("N"),
                    affectedStations = listOf("ocean_beach"),
                    severity = AlertSeverity.SEVERE,
                    category = AlertCategory.CLOSURE
                )
                "disruption_powell_elevator" -> ServiceAlert(
                    id = "disruption_powell_elevator",
                    title = "Powell St Elevator Out of Service",
                    description = "Platform-to-concourse elevator out of service for preventative maintenance. Avoid step-free transfers here.",
                    affectedRoutes = emptyList(),
                    affectedStations = listOf("powell"),
                    severity = AlertSeverity.MAJOR,
                    category = AlertCategory.ELEVATOR_OUTAGE
                )
                "disruption_bart_tube" -> ServiceAlert(
                    id = "disruption_bart_tube",
                    title = "BART Transbay Delay",
                    description = "Yellow Line and Red Line trains delayed ~15 minutes through the Transbay Tube due to wet track conditions.",
                    affectedRoutes = listOf("BART_YELLOW", "BART_RED"),
                    affectedStations = emptyList(),
                    severity = AlertSeverity.MAJOR,
                    category = AlertCategory.DELAY
                )
                "disruption_market_closure" -> ServiceAlert(
                    id = "disruption_market_closure",
                    title = "Market Street Track Obstruction",
                    description = "Market Street streetcar corridor closed between 5th and 8th St. Streetcars routing to Embarcadero only.",
                    affectedRoutes = listOf("F"),
                    affectedStations = listOf("powell", "civic_center"),
                    severity = AlertSeverity.MAJOR,
                    category = AlertCategory.CLOSURE
                )
                else -> null
            }
            if (alert != null) {
                current.add(alert)
            }
        }
        _activeAlerts.value = current
    }
}

// ==========================================
// 2. VEHICLE REAL-TIME SIMULATOR
// ==========================================

object VehicleSimulator {
    private val _vehicles = MutableStateFlow<List<Vehicle>>(emptyList())
    val vehicles: StateFlow<List<Vehicle>> = _vehicles.asStateFlow()

    private val activeSimulators = mutableMapOf<String, SimState>()

    private data class SimState(
        var patternIndex: Int,
        var currentStopIndex: Int,
        var stopTimerMs: Long,
        var progressPercent: Double // 0.0 to 1.0 between stops
    )

    init {
        // Seed initial vehicles
        val initialList = listOf(
            Vehicle("v_n_1", "N", "N Judah", TransitType.MUNI_METRO, "Inbound", 37.7610, -122.5085, "west_portal", 25.0, 0.4, 0, VehicleStatus.ON_TIME),
            Vehicle("v_n_2", "N", "N Judah", TransitType.MUNI_METRO, "Outbound", 37.7766, -122.3951, "embarcadero", 18.0, 0.7, 0, VehicleStatus.ON_TIME),
            Vehicle("v_j_1", "J", "J Church", TransitType.MUNI_METRO, "Inbound", 37.7215, -122.4475, "noe_valley", 22.0, 0.2, 0, VehicleStatus.ON_TIME),
            Vehicle("v_t_1", "T", "T Third", TransitType.MUNI_METRO, "Outbound", 37.7946, -122.4078, "union_square", 12.0, 0.5, 0, VehicleStatus.ON_TIME),
            Vehicle("v_by_1", "BART_YELLOW", "Yellow Line", TransitType.BART, "Inbound", 37.8701, -122.2682, "oakland_12th", 45.0, 0.6, 0, VehicleStatus.ON_TIME),
            Vehicle("v_cal_1", "CALTRAIN", "Caltrain", TransitType.CALTRAIN, "Outbound", 37.7766, -122.3951, "dogpatch", 55.0, 0.3, 0, VehicleStatus.ON_TIME)
        )
        _vehicles.value = initialList

        // Setup individual simulation states mapping to the first matching route patterns
        initialList.forEach { v ->
            val pattern = TransitData.ROUTE_PATTERNS.firstOrNull { it.routeId == v.routeId && it.direction == v.direction }
            if (pattern != null) {
                activeSimulators[v.id] = SimState(
                    patternIndex = TransitData.ROUTE_PATTERNS.indexOf(pattern),
                    currentStopIndex = 0,
                    stopTimerMs = 0L,
                    progressPercent = 0.0
                )
            }
        }
    }

    /**
     * Periodically advances vehicle positions on the map.
     */
    fun tickSimulation(alerts: List<ServiceAlert>) {
        val currentVehicles = _vehicles.value.map { v ->
            val sim = activeSimulators[v.id] ?: return@map v
            val pattern = TransitData.ROUTE_PATTERNS[sim.patternIndex]
            val stops = pattern.stops

            // Determine if route is disrupted (suspended/delayed)
            val isSuspended = alerts.any { it.category == AlertCategory.CLOSURE && it.affectedRoutes.contains(v.routeId) }
            val delayMins = alerts.filter { it.affectedRoutes.contains(v.routeId) }.sumOf { if (it.severity == AlertSeverity.SEVERE) 20 else 8 }

            if (isSuspended) {
                // Suspended vehicles don't move and register delay
                return@map v.copy(
                    speedMph = 0.0,
                    delayMin = 30,
                    status = VehicleStatus.DELAYED,
                    occupancyEstimate = 0.0
                )
            }

            // Increment progress
            var stopIndex = sim.currentStopIndex
            var nextStopIndex = stopIndex + 1

            if (nextStopIndex >= stops.size) {
                // At terminal! Reverse direction
                val oppositePattern = TransitData.ROUTE_PATTERNS.firstOrNull { it.routeId == v.routeId && it.direction != v.direction }
                if (oppositePattern != null) {
                    sim.patternIndex = TransitData.ROUTE_PATTERNS.indexOf(oppositePattern)
                    sim.currentStopIndex = 0
                    sim.progressPercent = 0.0
                } else {
                    sim.currentStopIndex = 0
                    sim.progressPercent = 0.0
                }
                stopIndex = 0
                nextStopIndex = 1
            }

            // Advance progress percent
            sim.progressPercent += 0.15
            if (sim.progressPercent >= 1.0) {
                sim.progressPercent = 0.0
                sim.currentStopIndex = nextStopIndex
                stopIndex = nextStopIndex
                nextStopIndex = stopIndex + 1
                if (nextStopIndex >= stops.size) nextStopIndex = stopIndex
            }

            val fromStation = TransitData.STATIONS[stops[stopIndex]]!!
            val toStation = TransitData.STATIONS[stops[nextStopIndex]]!!

            // Linear interpolation of lat/lng
            val currentLat = fromStation.latitude + (toStation.latitude - fromStation.latitude) * sim.progressPercent
            val currentLng = fromStation.longitude + (toStation.longitude - fromStation.longitude) * sim.progressPercent

            v.copy(
                latitude = currentLat,
                longitude = currentLng,
                nextStopId = toStation.id,
                speedMph = if (sim.progressPercent == 0.0) 0.0 else (if (v.type == TransitType.BART) 50.0 else 22.0),
                delayMin = delayMins,
                status = if (delayMins > 0) VehicleStatus.DELAYED else VehicleStatus.ON_TIME,
                lastUpdateMs = System.currentTimeMillis()
            )
        }
        _vehicles.value = currentVehicles
    }
}

// ==========================================
// 3. CLIPPER WALLET VIEWMODEL
// ==========================================

class ClipperWalletViewModel : ViewModel() {
    private val _clipperCard = MutableStateFlow(ClipperCard())
    val clipperCard: StateFlow<ClipperCard> = _clipperCard.asStateFlow()

    private val _isTapping = MutableStateFlow(false)
    val isTapping: StateFlow<Boolean> = _isTapping.asStateFlow()

    private val _tapSuccess = MutableStateFlow(false)
    val tapSuccess: StateFlow<Boolean> = _tapSuccess.asStateFlow()

    fun addCash(amount: Double) {
        _clipperCard.update {
            it.copy(balance = it.balance + amount)
        }
    }

    fun purchaseMuniPass() {
        _clipperCard.update {
            if (it.balance >= 80.00) {
                it.copy(balance = it.balance - 80.00, passType = "Muni Monthly Pass")
            } else {
                it
            }
        }
    }

    fun triggerTapAndRide(onComplete: () -> Unit) {
        viewModelScope.launch {
            _isTapping.value = true
            _tapSuccess.value = false
            delay(1500) // simulated hardware tap latency
            _tapSuccess.value = true
            delay(1000) // display success checkmark

            // Deduct fare
            _clipperCard.update {
                val isPassActive = it.passType != null
                val hasTransfer = it.isTransferActive && System.currentTimeMillis() < it.transferExpiryTime
                val fareToDeduct = if (isPassActive || hasTransfer) 0.0 else 2.50

                val updatedTrips = it.recentTrips.toMutableList()
                updatedTrips.add(
                    0, ClipperTrip(
                        date = SimpleDateFormat("MMM d, h:mm a", Locale.US).format(Date()),
                        routeName = "Muni Metro / BART Tap",
                        type = TransitType.MUNI_METRO,
                        fare = fareToDeduct,
                        startStation = "Powell Street",
                        endStation = "Reader Entry"
                    )
                )

                it.copy(
                    balance = (it.balance - fareToDeduct).coerceAtLeast(0.0),
                    isTransferActive = !isPassActive, // activate new transfer
                    transferExpiryTime = System.currentTimeMillis() + 120 * 60 * 1000, // 2 hour window
                    recentTrips = updatedTrips
                )
            }

            _isTapping.value = false
            _tapSuccess.value = false
            onComplete()
        }
    }
}

// ==========================================
// 4. TRANSIT AI ASSISTANT VIEWMODEL
// ==========================================

class TransitAssistantViewModel : ViewModel() {
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage("assistant", "Hello! I am SF Transit AI. Ask me any transit question like 'How do I get from Castro to SFO with low walking?' or 'Avoid stairs Powell Street.'")
        )
    )
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    fun sendAiQuery(userText: String, onRouteParamsParsed: (fromId: String, toId: String, isStepFree: Boolean, ranking: String) -> Unit) {
        if (userText.isBlank()) return

        // Add user message to chat
        val current = _chatHistory.value.toMutableList()
        current.add(ChatMessage("user", userText))
        _chatHistory.value = current

        _isAiLoading.value = true

        viewModelScope.launch {
            // Check if Gemini API key exists
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isNullOrEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                // Fallback to local Regex Parsing
                delay(1200) // simulate thinking
                val parsed = parseQueryLocally(userText)
                val statusText = if (parsed.fromId != null && parsed.toId != null) {
                    val fromName = TransitData.STATIONS[parsed.fromId]?.name ?: parsed.fromId
                    val toName = TransitData.STATIONS[parsed.toId]?.name ?: parsed.toId
                    onRouteParamsParsed(parsed.fromId, parsed.toId, parsed.accessibility, parsed.ranking)
                    "Plan loaded: **$fromName** to **$toName** (${parsed.ranking.lowercase()}${if (parsed.accessibility) ", step-free" else ""})."
                } else {
                    "I parsed your message but couldn't resolve both a valid departure and destination. Please mention clear SF locations (e.g., 'Mission', 'Castro', 'SFO', 'Chinatown', 'Embarcadero')."
                }

                _chatHistory.update {
                    it + ChatMessage("assistant", "*(Offline AI mode)* $statusText")
                }
                _isAiLoading.value = false
            } else {
                // Direct REST API call
                try {
                    val responseText = callGeminiApi(userText, apiKey)
                    val parsed = parseGeminiResponse(responseText)

                    val assistantReply: String
                    if (parsed != null && parsed.fromId != null && parsed.toId != null) {
                        val fromName = TransitData.STATIONS[parsed.fromId]?.name ?: parsed.fromId
                        val toName = TransitData.STATIONS[parsed.toId]?.name ?: parsed.toId
                        onRouteParamsParsed(parsed.fromId, parsed.toId, parsed.accessibility, parsed.ranking)
                        assistantReply = "Certainly! I've plotted your journey from **$fromName** to **$toName** using **${parsed.ranking.lowercase()}** preferences${if (parsed.accessibility) " and step-free routing" else ""}. You can see your live route options on the planner screen!"
                    } else {
                        assistantReply = "I received your query but struggled to parse clear Bay Area locations from it. Let's try again. I can resolve areas like Castro, SFO, Berkeley, Chinatown, Palo Alto, Mission, and Embarcadero."
                    }

                    _chatHistory.update {
                        it + ChatMessage("assistant", assistantReply)
                    }
                } catch (e: Exception) {
                    _chatHistory.update {
                        it + ChatMessage("assistant", "Error contacting Gemini: ${e.message}. Active offline local fallback triggered.")
                    }
                    // Trigger local fallback
                    val parsed = parseQueryLocally(userText)
                    if (parsed.fromId != null && parsed.toId != null) {
                        onRouteParamsParsed(parsed.fromId, parsed.toId, parsed.accessibility, parsed.ranking)
                    }
                } finally {
                    _isAiLoading.value = false
                }
            }
        }
    }

    private suspend fun callGeminiApi(userQuery: String, apiKey: String): String = withContext(Dispatchers.IO) {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val stationKeys = TransitData.STATIONS.keys.joinToString(", ")
        val systemInstruction = "You are the SF Transit AI Router. Translate user's transit requests into structured JSON. " +
                "Output ONLY a raw valid JSON object with the following schema: " +
                "{\"fromId\": \"<stationId or null>\", \"toId\": \"<stationId or null>\", \"accessibility\": <boolean>, \"ranking\": \"FASTEST\" | \"FEWEST_TRANSFERS\" | \"LEAST_WALKING\"}. " +
                "Do not include markdown blocks, backticks, or other text. Here are valid stationIds: $stationKeys."

        val payload = """
            {
              "contents": [{
                "parts": [{"text": "$userQuery"}]
              }],
              "systemInstruction": {
                "parts": [{"text": "$systemInstruction"}]
              },
              "generationConfig": {
                "responseMimeType": "application/json"
              }
            }
        """.trimIndent()

        val request = Request.Builder()
            .url(url)
            .post(payload.toRequestBody("application/json".toMediaType()))
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("HTTP error code: ${response.code}")
            val bodyString = response.body?.string() ?: throw Exception("Empty response body")
            bodyString
        }
    }

    private fun parseGeminiResponse(apiJson: String): ParsedQueryParams? {
        return try {
            // Simple string extraction of JSON inside candidates to avoid massive model serialization boilerplate
            val startIndex = apiJson.indexOf("\"text\":")
            if (startIndex == -1) return null
            val sub = apiJson.substring(startIndex)
            val firstQuote = sub.indexOf("\"")
            val secondQuote = sub.indexOf("\"", firstQuote + 1)
            val thirdQuote = sub.indexOf("\"", secondQuote + 1)
            val textContent = sub.substring(thirdQuote + 1, sub.indexOf("\"", thirdQuote + 1))
                .replace("\\n", "")
                .replace("\\\"", "\"")
                .trim()

            // Deserialize using Moshi
            val adapter = moshi.adapter(ParsedQueryParams::class.java)
            adapter.fromJson(textContent)
        } catch (e: Exception) {
            null
        }
    }

    private fun parseQueryLocally(query: String): ParsedQueryParams {
        val lower = query.lowercase()

        // Match departure
        val fromId = findStationIdInText(lower, "from") ?: findStationIdInText(lower)

        // Match destination
        val toId = findStationIdInText(lower, "to") ?: run {
            // Find second distinct station
            val firstStation = fromId
            TransitData.STATIONS.keys.firstOrNull { it != firstStation && lower.contains(it) }
        }

        val accessibility = lower.contains("wheelchair") || lower.contains("accessible") || lower.contains("stair") || lower.contains("elevator") || lower.contains("avoid elevator")
        val ranking = when {
            lower.contains("transfer") || lower.contains("direct") -> "FEWEST_TRANSFERS"
            lower.contains("walk") || lower.contains("near") -> "LEAST_WALKING"
            else -> "FASTEST"
        }

        return ParsedQueryParams(fromId, toId, accessibility, ranking)
    }

    private fun findStationIdInText(text: String, prefixWord: String? = null): String? {
        if (prefixWord != null) {
            val index = text.indexOf(prefixWord)
            if (index != -1) {
                val sub = text.substring(index)
                return TransitData.STATIONS.keys.firstOrNull { sub.contains(it) }
            }
        }
        return TransitData.STATIONS.keys.firstOrNull { text.contains(it) }
    }
}

data class ChatMessage(val sender: String, val text: String)

data class ParsedQueryParams(
    val fromId: String?,
    val toId: String?,
    val accessibility: Boolean = false,
    val ranking: String = "FASTEST"
)
