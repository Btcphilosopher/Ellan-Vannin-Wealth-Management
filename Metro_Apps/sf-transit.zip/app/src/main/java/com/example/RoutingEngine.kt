package com.example

import androidx.compose.ui.graphics.Color
import java.util.PriorityQueue

object RoutingEngine {

    // Helper class for Dijkstra node states
    private data class PathNode(
        val stationId: String,
        val totalCost: Double,
        val totalTime: Double,
        val totalFare: Double,
        val totalWalking: Double,
        val transferCount: Int,
        val lastRouteId: String?,
        val parentEdge: GraphEdge?,
        val parentNode: PathNode?
    ) : Comparable<PathNode> {
        override fun compareTo(other: PathNode): Int {
            return this.totalCost.compareTo(other.totalCost)
        }
    }

    /**
     * Finds paths from start to end stations.
     * Supports multiple routing options (Fastest, Fewest Transfers, Least Walking, etc.).
     */
    fun planRoute(
        startId: String,
        endId: String,
        accessibilityFilter: Boolean = false,
        routeRanking: String = "FASTEST",
        activeDisruptions: List<ServiceAlert> = emptyList()
    ): List<Journey> {
        val startStation = TransitData.STATIONS[startId] ?: return emptyList()
        val endStation = TransitData.STATIONS[endId] ?: return emptyList()

        if (startId == endId) {
            return listOf(
                Journey(
                    legs = emptyList(),
                    totalDurationMin = 0,
                    totalWalkingMin = 0,
                    transferCount = 0,
                    totalFare = 0.0,
                    isAccessible = startStation.isAccessible
                )
            )
        }

        // We will run Dijkstra with three different sets of cost weights to yield multiple options!
        val journeys = mutableListOf<Journey>()

        val options = listOf("FASTEST", "FEWEST_TRANSFERS", "LEAST_WALKING")
        for (option in options) {
            val path = solveDijkstra(startId, endId, accessibilityFilter, option, activeDisruptions)
            if (path != null) {
                val journey = mapPathToJourney(path, activeDisruptions)
                // Avoid duplicates in output list
                if (journeys.none { it.totalDurationMin == journey.totalDurationMin && it.transferCount == journey.transferCount }) {
                    journeys.add(journey)
                }
            }
        }

        // If the configured one is not in the list, move it to the top or sort appropriately
        return journeys.sortedWith(compareBy {
            when (routeRanking) {
                "FEWEST_TRANSFERS" -> it.transferCount
                "LEAST_WALKING" -> it.totalWalkingMin
                else -> it.totalDurationMin
            }
        })
    }

    private fun solveDijkstra(
        startId: String,
        endId: String,
        accessibilityFilter: Boolean,
        rankingMode: String,
        activeDisruptions: List<ServiceAlert>
    ): PathNode? {
        val queue = PriorityQueue<PathNode>()
        // Keeps track of the minimum cost to reach each node
        val minCosts = mutableMapOf<String, Double>()

        // Analyze disruptions
        val suspendedRouteIds = activeDisruptions
            .filter { it.category == AlertCategory.CLOSURE && it.affectedRoutes.isNotEmpty() }
            .flatMap { it.affectedRoutes }
            .toSet()

        val closedStationIds = activeDisruptions
            .filter { it.category == AlertCategory.CLOSURE && it.affectedStations.isNotEmpty() }
            .flatMap { it.affectedStations }
            .toSet()

        val brokenElevatorStationIds = activeDisruptions
            .filter { it.category == AlertCategory.ELEVATOR_OUTAGE }
            .flatMap { it.affectedStations }
            .toSet()

        // Initialize start
        queue.add(
            PathNode(
                stationId = startId,
                totalCost = 0.0,
                totalTime = 0.0,
                totalFare = 0.0,
                totalWalking = 0.0,
                transferCount = 0,
                lastRouteId = null,
                parentEdge = null,
                parentNode = null
            )
        )
        minCosts[startId] = 0.0

        while (queue.isNotEmpty()) {
            val current = queue.poll()

            if (current.stationId == endId) {
                return current
            }

            if ((minCosts[current.stationId] ?: Double.MAX_VALUE) < current.totalCost) {
                continue
            }

            // Get valid outgoing edges
            val edges = TransitData.EDGES.filter { it.sourceId == current.stationId }

            for (edge in edges) {
                val targetId = edge.targetId

                // --- ACCESSIBILITY FILTER ---
                if (accessibilityFilter) {
                    val targetStation = TransitData.STATIONS[targetId]
                    if (targetStation != null && !targetStation.isAccessible) continue
                    if (brokenElevatorStationIds.contains(targetId)) continue
                    if (brokenElevatorStationIds.contains(current.stationId)) continue
                    if (!edge.isAccessible) continue
                }

                // --- DISRUPTION FILTER ---
                if (closedStationIds.contains(targetId) || closedStationIds.contains(current.stationId)) {
                    continue // closed station is impassable
                }
                if (edge.routeId != null && suspendedRouteIds.contains(edge.routeId)) {
                    continue // transit route is suspended
                }

                // --- COST CALCULATION ENGINE ---
                val isTransfer = current.lastRouteId != null && edge.routeId != null && current.lastRouteId != edge.routeId
                val transferPenalty = if (isTransfer) 15.0 else 0.0

                val edgeTime = edge.durationMin
                val walkPenaltyMultiplier = if (rankingMode == "LEAST_WALKING" && edge.type == TransitType.WALK) 5.0 else 1.0
                val transferPenaltyWeight = if (rankingMode == "FEWEST_TRANSFERS") 30.0 else 5.0

                // Total path costs
                val addedCost = (edgeTime * walkPenaltyMultiplier) +
                        (if (isTransfer) transferPenaltyWeight else 0.0) +
                        (if (edge.type == TransitType.WALK) 2.0 else 0.0) // prefer trains over long walks

                val nextCost = current.totalCost + addedCost
                val nextTime = current.totalTime + edgeTime
                val nextFare = current.totalFare + edge.baseFare
                val nextWalking = current.totalWalking + (if (edge.type == TransitType.WALK) edgeTime else 0.0)
                val nextTransfers = current.transferCount + (if (isTransfer) 1 else 0)

                val bestCostSoFar = minCosts[targetId] ?: Double.MAX_VALUE
                if (nextCost < bestCostSoFar) {
                    minCosts[targetId] = nextCost
                    queue.add(
                        PathNode(
                            stationId = targetId,
                            totalCost = nextCost,
                            totalTime = nextTime,
                            totalFare = nextFare,
                            totalWalking = nextWalking,
                            transferCount = nextTransfers,
                            lastRouteId = edge.routeId ?: current.lastRouteId,
                            parentEdge = edge,
                            parentNode = current
                        )
                    )
                }
            }
        }

        return null // no path found
    }

    private fun mapPathToJourney(endNode: PathNode, activeDisruptions: List<ServiceAlert>): Journey {
        // Trace back parents
        val edges = mutableListOf<GraphEdge>()
        var curr: PathNode? = endNode
        while (curr?.parentEdge != null) {
            edges.add(0, curr.parentEdge!!)
            curr = curr.parentNode
        }

        // Compact edges into JourneyLeg segments
        val legs = mutableListOf<JourneyLeg>()
        if (edges.isEmpty()) {
            val station = TransitData.STATIONS[endNode.stationId] ?: Station("?", "?", TransitType.WALK, "", 0.0, 0.0)
            return Journey(
                legs = listOf(JourneyLeg(TransitType.WALK, null, "Walk", Color.Gray, station, station, 0, 0, 0, emptyList(), "Arrived")),
                totalDurationMin = 0,
                totalWalkingMin = 0,
                transferCount = 0,
                totalFare = 0.0
            )
        }

        // Group continuous edges on the same transit route into one JourneyLeg
        var i = 0
        while (i < edges.size) {
            val firstEdge = edges[i]
            val fromStation = TransitData.STATIONS[firstEdge.sourceId]!!
            var toStation = TransitData.STATIONS[firstEdge.targetId]!!
            var totalLegDuration = firstEdge.durationMin
            var totalLegFare = firstEdge.baseFare
            val routeId = firstEdge.routeId
            val type = firstEdge.type
            val intermediateStops = mutableListOf<String>()

            var j = i + 1
            while (j < edges.size && edges[j].routeId == routeId && routeId != null && edges[j].type == type) {
                // Same continuous segment
                val nextEdge = edges[j]
                intermediateStops.add(TransitData.STATIONS[nextEdge.sourceId]!!.name)
                toStation = TransitData.STATIONS[nextEdge.targetId]!!
                totalLegDuration += nextEdge.durationMin
                if (type == TransitType.BART || type == TransitType.CALTRAIN) {
                    totalLegFare += nextEdge.baseFare
                }
                j++
            }

            val route = routeId?.let { TransitData.ROUTES[it] }
            val routeName = route?.name ?: if (type == TransitType.WALK) "Walk" else "Transit Connection"
            val routeColor = route?.color ?: Color.Gray

            val instructions = when (type) {
                TransitType.WALK -> "Walk ${totalLegDuration.toInt()} min to ${toStation.name}"
                TransitType.MUNI_METRO -> "Board ${routeName} at ${fromStation.name} to ${toStation.name} (${intermediateStops.size + 1} stops)"
                TransitType.BART -> "Board BART ${routeName} at ${fromStation.name} to ${toStation.name} (${intermediateStops.size + 1} stops)"
                TransitType.CALTRAIN -> "Board Caltrain at ${fromStation.name} to ${toStation.name} (${intermediateStops.size + 1} stops)"
                TransitType.CABLE_CAR -> "Ride ${routeName} Cable Car from ${fromStation.name} to ${toStation.name}"
                TransitType.STREETCAR -> "Ride F Market Historic Streetcar from ${fromStation.name} to ${toStation.name}"
                else -> "Take ${routeName} from ${fromStation.name} to ${toStation.name}"
            }

            legs.add(
                JourneyLeg(
                    type = type,
                    routeId = routeId,
                    routeName = routeName,
                    routeColor = routeColor,
                    fromStation = fromStation,
                    toStation = toStation,
                    durationMin = totalLegDuration.toInt(),
                    intermediateStops = intermediateStops,
                    instructions = instructions,
                    fare = totalLegFare,
                    isStepFree = route?.isStepFree ?: true
                )
            )

            i = j
        }

        // Assess overall service status based on disruptions affecting routes in this journey
        val usedRouteIds = legs.mapNotNull { it.routeId }.toSet()
        val pathDisruptions = activeDisruptions.filter { alert ->
            alert.affectedRoutes.any { usedRouteIds.contains(it) }
        }

        val statusText = if (pathDisruptions.any { it.severity == AlertSeverity.SEVERE }) {
            "Severe Delays / Rerouting Active"
        } else if (pathDisruptions.any { it.severity == AlertSeverity.MAJOR }) {
            "Major Disruptions Reported"
        } else if (pathDisruptions.isNotEmpty()) {
            "Minor Delays of ~${pathDisruptions.size * 5} min"
        } else {
            "On Time / Normal Service"
        }

        // Calculate dynamic fare based on regional Clipper transfer rules
        var calculatedFare = 0.0
        var boardedMuni = false
        legs.forEach { leg ->
            if (leg.type == TransitType.WALK) return@forEach

            when (leg.type) {
                TransitType.MUNI_METRO, TransitType.MUNI_BUS, TransitType.STREETCAR -> {
                    if (!boardedMuni) {
                        calculatedFare += 2.50 // flat Muni boarding fare
                        boardedMuni = true
                    }
                }
                TransitType.CABLE_CAR -> {
                    calculatedFare += 8.00 // flat Cable Car fare
                }
                TransitType.BART -> {
                    calculatedFare += leg.fare
                }
                TransitType.CALTRAIN -> {
                    calculatedFare += leg.fare
                }
                else -> {
                    calculatedFare += leg.fare
                }
            }
        }

        return Journey(
            legs = legs,
            totalDurationMin = endNode.totalTime.toInt(),
            totalWalkingMin = endNode.totalWalking.toInt(),
            transferCount = endNode.transferCount,
            totalFare = calculatedFare,
            isAccessible = legs.all { it.isStepFree } && endNode.parentNode?.stationId?.let { TransitData.STATIONS[it]?.isAccessible } ?: true,
            serviceStatus = statusText
        )
    }
}
