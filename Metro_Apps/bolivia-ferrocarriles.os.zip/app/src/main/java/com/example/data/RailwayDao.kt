package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RailwayDao {

    // User Balance and Cards
    @Query("SELECT * FROM user_balance WHERE id = 1")
    fun getUserBalanceFlow(): Flow<UserBalance?>

    @Query("SELECT * FROM user_balance WHERE id = 1")
    suspend fun getUserBalanceDirect(): UserBalance?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserBalance(balance: UserBalance)

    @Query("UPDATE user_balance SET balance = :newBalance WHERE id = 1")
    suspend fun updateBalanceAmount(newBalance: Double)

    @Query("UPDATE user_balance SET cardStatus = :status, cardType = :cardType WHERE id = 1")
    suspend fun updateCardDetails(status: String, cardType: String)

    // Contactless Wallet Transactions
    @Query("SELECT * FROM transaction_records ORDER BY timestamp DESC")
    fun getTransactionsFlow(): Flow<List<TransactionRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(record: TransactionRecord)

    // Stations
    @Query("SELECT * FROM stations")
    fun getStationsFlow(): Flow<List<Station>>

    @Query("SELECT * FROM stations WHERE code = :code")
    suspend fun getStationByCode(code: String): Station?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<Station>)

    // Tickets & Bookings
    @Query("SELECT * FROM tickets ORDER BY timestamp DESC")
    fun getTicketsFlow(): Flow<List<Ticket>>

    @Query("SELECT * FROM tickets WHERE id = :id")
    suspend fun getTicketById(id: String): Ticket?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: Ticket)

    @Query("UPDATE tickets SET status = :status WHERE id = :id")
    suspend fun updateTicketStatus(id: String, status: String)

    @Query("DELETE FROM tickets WHERE id = :id")
    suspend fun deleteTicketById(id: String)

    // Service Alerts
    @Query("SELECT * FROM service_alerts ORDER BY id DESC")
    fun getAlertsFlow(): Flow<List<ServiceAlert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<ServiceAlert>)

    @Query("DELETE FROM service_alerts")
    suspend fun clearAlerts()

    // Simulation Metrics
    @Query("SELECT * FROM simulation_metrics ORDER BY id DESC LIMIT 5")
    fun getSimulationMetricsFlow(): Flow<List<SimulationMetric>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSimulationMetric(metric: SimulationMetric)
}
