package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ServiceAlert
import com.example.data.Station
import com.example.data.Ticket
import com.example.data.TransactionRecord
import java.text.SimpleDateFormat
import java.util.*

// Regional Theme Colors
data class RegionPalette(
    val primary: Color,
    val secondary: Color,
    val backgroundGradStart: Color,
    val backgroundGradEnd: Color,
    val accent: Color,
    val surfaceColor: Color,
    val onSurfaceColor: Color
)

val AndinoPalette = RegionPalette(
    primary = Color(0xFF1E3A8A), // Azul Altiplánico Profundo
    secondary = Color(0xFFB91C1C), // Rojo Mineral Tierra
    backgroundGradStart = Color(0xFFF1F5F9), // Gris Altiplano Claro
    backgroundGradEnd = Color(0xFFE2E8F0), // Gris Piedra
    accent = Color(0xFF0369A1), // Azul Cielo
    surfaceColor = Color.White,
    onSurfaceColor = Color(0xFF1E293B)
)

val OrientalPalette = RegionPalette(
    primary = Color(0xFF065F46), // Verde Vegetal Profundo
    secondary = Color(0xFFC2410C), // Marrón Arcilla Chiquitana
    backgroundGradStart = Color(0xFFF0FDF4), // Crema Verde Pálido
    backgroundGradEnd = Color(0xFFDCFCE7), // Sombra de Selva Clara
    accent = Color(0xFFD97706), // Amarillo Sol Oriental
    surfaceColor = Color.White,
    onSurfaceColor = Color(0xFF064E3B)
)

val NacionalPalette = RegionPalette(
    primary = Color(0xFF3F3F46), // Gris Carbón Ferroviario
    secondary = Color(0xFF4B5563), // Acero
    backgroundGradStart = Color(0xFFFAFAFA), // Blanco Mineral
    backgroundGradEnd = Color(0xFFF4F4F5), // Gris Arena
    accent = Color(0xFFB45309), // Oro Cobrizo
    surfaceColor = Color.White,
    onSurfaceColor = Color(0xFF18181B)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RailwayApp(viewModel: RailwayViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val regionalFilter by viewModel.selectedRegionalFilter.collectAsStateWithLifecycle()
    val userBalanceState by viewModel.userBalance.collectAsStateWithLifecycle()

    val palette = when (regionalFilter) {
        "ANDINA" -> AndinoPalette
        "ORIENTAL" -> OrientalPalette
        else -> NacionalPalette
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.DirectionsTransit,
                                contentDescription = null,
                                tint = palette.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "FERROCARRILES.OS",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.5.sp
                                ),
                                color = palette.primary
                            )
                        }
                        Text(
                            text = "Plataforma Nacional Ferroviaria de Bolivia",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.secondary
                        )
                    }
                },
                actions = {
                    // Demo indicator
                    Box(
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(palette.secondary.copy(alpha = 0.15.dp.value))
                            .border(1.dp, palette.secondary.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "DEMO",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = palette.secondary
                        )
                    }
                    IconButton(
                        onClick = { viewModel.currentScreen.value = AppScreen.PERFIL },
                        modifier = Modifier.testTag("profile_top_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Mi Perfil",
                            tint = palette.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = palette.surfaceColor,
                    titleContentColor = palette.primary
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = palette.surfaceColor,
                tonalElevation = 8.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                val items = listOf(
                    Triple(AppScreen.INICIO, Icons.Default.Home, "Inicio"),
                    Triple(AppScreen.PLANIFICAR, Icons.Default.Search, "Planificar"),
                    Triple(AppScreen.BILLETERA, Icons.Default.Wallet, "Billetera"),
                    Triple(AppScreen.RED_FERROVIARIA, Icons.Default.Map, "Mapa"),
                    Triple(AppScreen.ESTACIONES, Icons.Default.Storefront, "Estaciones"),
                    Triple(AppScreen.SIMULADOR, Icons.Default.Terminal, "Simulador")
                )

                items.forEach { (screen, icon, label) ->
                    NavigationBarItem(
                        selected = currentScreen == screen,
                        onClick = { viewModel.currentScreen.value = screen },
                        icon = { Icon(imageVector = icon, contentDescription = label) },
                        label = { Text(text = label, style = MaterialTheme.typography.labelMedium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = palette.primary,
                            selectedTextColor = palette.primary,
                            indicatorColor = palette.primary.copy(alpha = 0.12f),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(palette.backgroundGradStart, palette.backgroundGradEnd)
                    )
                )
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    AppScreen.INICIO -> HomeScreen(viewModel, palette)
                    AppScreen.PLANIFICAR -> PlanningScreen(viewModel, palette)
                    AppScreen.COMPRAR -> BookingScreen(viewModel, palette)
                    AppScreen.BILLETERA -> WalletScreen(viewModel, palette)
                    AppScreen.RED_FERROVIARIA -> MapAndControlScreen(viewModel, palette)
                    AppScreen.ESTACIONES -> StationsScreen(viewModel, palette)
                    AppScreen.SIMULADOR -> SimulatorScreen(viewModel, palette)
                    AppScreen.PERFIL -> ProfileScreen(viewModel, palette)
                    else -> HomeScreen(viewModel, palette)
                }
            }
        }
    }
}

// 1. HOME SCREEN
@Composable
fun HomeScreen(viewModel: RailwayViewModel, palette: RegionPalette) {
    val selectedRegion by viewModel.selectedRegionalFilter.collectAsStateWithLifecycle()
    val stationsList by viewModel.stations.collectAsStateWithLifecycle()
    val ticketsList by viewModel.tickets.collectAsStateWithLifecycle()
    val alertsList by viewModel.alerts.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Warning banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(palette.secondary.copy(alpha = 0.08f))
                    .border(1.dp, palette.secondary.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Simulado",
                        tint = palette.secondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Modo demostración — Información ferroviaria simulada para Bolivia. Red Andina, Oriental y Ramales.",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                        color = palette.onSurfaceColor
                    )
                }
            }
        }

        // Region selector tabs
        item {
            Column {
                Text(
                    text = "Seleccionar Región de Operación",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val regions = listOf(
                        "NACIONAL" to "Todas las Redes",
                        "ANDINA" to "Red Andina",
                        "ORIENTAL" to "Red Oriental"
                    )
                    regions.forEach { (code, name) ->
                        val isSelected = selectedRegion == code
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) palette.primary else Color.LightGray.copy(alpha = 0.3f))
                                .clickable { viewModel.selectedRegionalFilter.value = code }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = name,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = if (isSelected) Color.White else Color.DarkGray
                            )
                        }
                    }
                }
            }
        }

        // Search Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "¿Adónde quieres viajar?",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = palette.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Origin selector dropdown simulator
                    var showOriginSelect by remember { mutableStateOf(false) }
                    var showDestSelect by remember { mutableStateOf(false) }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Origin
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Gray.copy(alpha = 0.1f))
                                .clickable { showOriginSelect = true }
                                .padding(12.dp)
                        ) {
                            Column {
                                Text("Origen", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text(
                                    text = viewModel.searchOrigin?.name ?: "Seleccionar",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Swap button
                        IconButton(
                            onClick = {
                                val temp = viewModel.searchOrigin
                                viewModel.searchOrigin = viewModel.searchDestination
                                viewModel.searchDestination = temp
                            },
                            modifier = Modifier.align(Alignment.CenterVertically)
                        ) {
                            Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = "Intercambiar", tint = palette.primary)
                        }

                        // Destination
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Gray.copy(alpha = 0.1f))
                                .clickable { showDestSelect = true }
                                .padding(12.dp)
                        ) {
                            Column {
                                Text("Destino", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text(
                                    text = viewModel.searchDestination?.name ?: "Seleccionar",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // Dropdowns list
                    if (showOriginSelect) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .padding(top = 8.dp),
                            elevation = CardDefaults.cardElevation(4.dp)
                        ) {
                            LazyColumn {
                                val filteredStations = if (selectedRegion == "NACIONAL") stationsList else stationsList.filter { it.region == selectedRegion }
                                items(filteredStations) { station ->
                                    Text(
                                        text = "${station.name} (${station.code}) - ${station.region}",
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.searchOrigin = station
                                                showOriginSelect = false
                                            }
                                            .padding(12.dp),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                                }
                            }
                        }
                    }

                    if (showDestSelect) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .padding(top = 8.dp),
                            elevation = CardDefaults.cardElevation(4.dp)
                        ) {
                            LazyColumn {
                                val filteredStations = if (selectedRegion == "NACIONAL") stationsList else stationsList.filter { it.region == selectedRegion }
                                items(filteredStations) { station ->
                                    Text(
                                        text = "${station.name} (${station.code}) - ${station.region}",
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.searchDestination = station
                                                showDestSelect = false
                                            }
                                            .padding(12.dp),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Date & Passengers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Gray.copy(alpha = 0.1f))
                                .clickable {
                                    // toggle date simple options
                                    if (viewModel.searchDate == "2026-09-23") {
                                        viewModel.searchDate = "2026-09-24"
                                        viewModel.searchDateSelectedText = "Pasado Mañana (24 Sep)"
                                    } else {
                                        viewModel.searchDate = "2026-09-23"
                                        viewModel.searchDateSelectedText = "Mañana (23 Sep)"
                                    }
                                }
                                .padding(12.dp)
                        ) {
                            Column {
                                Text("Fecha", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text(
                                    text = viewModel.searchDateSelectedText,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Gray.copy(alpha = 0.1f))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text("Pasajeros", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = viewModel.passengerCount.toString(),
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Row {
                                        IconButton(
                                            onClick = { if (viewModel.passengerCount > 1) viewModel.passengerCount-- },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Remove, contentDescription = "Menos", modifier = Modifier.size(16.dp))
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        IconButton(
                                            onClick = { if (viewModel.passengerCount < 10) viewModel.passengerCount++ },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Add, contentDescription = "Mas", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (viewModel.searchOrigin != null && viewModel.searchDestination != null) {
                                viewModel.performSearch()
                                viewModel.currentScreen.value = AppScreen.PLANIFICAR
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("search_button"),
                        enabled = viewModel.searchOrigin != null && viewModel.searchDestination != null
                    ) {
                        Text(
                            text = "BUSCAR VIAJES",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        // Quick Access Panel
        item {
            Column {
                Text(
                    text = "Accesos Rápidos",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = palette.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.height(190.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val quickAccessItems = listOf(
                        Triple(Icons.Default.ConfirmationNumber, "Comprar Billete", AppScreen.PLANIFICAR),
                        Triple(Icons.Default.QrCodeScanner, "Mi Billetera", AppScreen.BILLETERA),
                        Triple(Icons.Default.Schedule, "Salidas", AppScreen.ESTACIONES),
                        Triple(Icons.Default.Storefront, "Estaciones", AppScreen.ESTACIONES),
                        Triple(Icons.Default.Map, "Ver Red", AppScreen.RED_FERROVIARIA),
                        Triple(Icons.Default.ReportProblem, "Estado Red", AppScreen.ESTADO_SERVICIO)
                    )

                    items(quickAccessItems) { (icon, text, screen) ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable {
                                    if (screen == AppScreen.ESTADO_SERVICIO) {
                                        viewModel.currentScreen.value = AppScreen.SIMULADOR
                                    } else {
                                        viewModel.currentScreen.value = screen
                                    }
                                }
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(8.dp)
                                    .fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = text,
                                    tint = palette.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = text,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    color = palette.primary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Next Active Trip
        val activeTickets = ticketsList.filter { it.status == "CONFIRMADO" || it.status == "VALIDADO" }
        if (activeTickets.isNotEmpty()) {
            val nextTicket = activeTickets.first()
            item {
                Column {
                    Text(
                        text = "Próximo Viaje",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = palette.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = palette.primary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = nextTicket.trainNumber,
                                    color = Color.White.copy(alpha = 0.8f),
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Text(
                                    text = nextTicket.status,
                                    color = palette.accent,
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = nextTicket.originCode,
                                        color = Color.White,
                                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black)
                                    )
                                    Text(
                                        text = nextTicket.originName,
                                        color = Color.White.copy(alpha = 0.8f),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = "Ruta",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = nextTicket.destCode,
                                        color = Color.White,
                                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black)
                                    )
                                    Text(
                                        text = nextTicket.destName,
                                        color = Color.White.copy(alpha = 0.8f),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("SALIDA", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
                                    Text(nextTicket.departureTime, style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("FECHA", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
                                    Text(nextTicket.date, style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("ASIENTO", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
                                    Text(nextTicket.seatNumber, style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    viewModel.currentScreen.value = AppScreen.BILLETERA
                                    viewModel.startValidationJourney(nextTicket)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = "Validar", tint = palette.primary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("MOSTRAR TICKET / EMBARCAR", color = palette.primary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Active Alerts summary
        if (alertsList.isNotEmpty()) {
            item {
                Column {
                    Text(
                        text = "Alertas Operacionales Recientes",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = palette.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    alertsList.take(2).forEach { alert ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(palette.surfaceColor)
                                .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = alert.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = palette.primary
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(palette.secondary.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = alert.region,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = palette.secondary
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = alert.details,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.DarkGray
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Consecuencia: ${alert.consequence}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = palette.secondary
                                    )
                                    Text(
                                        text = alert.publishTime,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 2. PLANNING / SEARCH RESULTS SCREEN
@Composable
fun PlanningScreen(viewModel: RailwayViewModel, palette: RegionPalette) {
    val results = viewModel.searchResults
    val isSearching = viewModel.isSearching

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Search criteria overview card
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.primary),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "PLANIFICADOR DE RUTA",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = viewModel.searchOrigin?.name ?: "Origen",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "A", tint = Color.White, modifier = Modifier.size(16.dp))
                    Text(
                        text = viewModel.searchDestination?.name ?: "Destino",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Fecha: ${viewModel.searchDateSelectedText}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Text(
                        text = "${viewModel.passengerCount} Pasajero(s)",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Filters bar
        var selectedFilter by remember { mutableStateOf("PRÓXIMA") } // "PRÓXIMA", "MENOR_DURACION", "MENOR_PRECIO"
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf(
                "PRÓXIMA" to "Salida Próxima",
                "MENOR_DURACION" to "Menor Duración",
                "MENOR_PRECIO" to "Menor Precio"
            )
            filters.forEach { (code, text) ->
                val isSelected = selectedFilter == code
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) palette.primary else Color.LightGray.copy(alpha = 0.3f))
                        .clickable { selectedFilter = code }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = text,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (isSelected) Color.White else Color.DarkGray
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isSearching) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = palette.primary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Buscando conexiones ferroviarias óptimas...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.primary
                    )
                }
            }
        } else if (results.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Vacio",
                        tint = Color.Gray,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Ingresa origen y destino en Inicio para buscar itinerarios.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Sort list based on filter
            val sortedResults = when (selectedFilter) {
                "MENOR_DURACION" -> results.sortedBy { it.duration }
                "MENOR_PRECIO" -> results.sortedBy { it.priceEconomica }
                else -> results
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(sortedResults) { journey ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.DirectionsTransit, contentDescription = null, tint = palette.primary)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = journey.trainName,
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                        color = palette.primary
                                    )
                                }
                                Text(
                                    text = journey.trainNumber,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.Gray
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(journey.departureTime, style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold), color = palette.primary)
                                    Text(journey.originCode, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(journey.duration, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                                    Box(
                                        modifier = Modifier
                                            .height(2.dp)
                                            .width(80.dp)
                                            .background(Color.Gray)
                                    )
                                    Text(
                                        text = "Directo",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.Gray
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(journey.arrivalTime, style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold), color = palette.primary)
                                    Text(journey.destCode, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Estaciones: ${journey.stopStations.joinToString(" ➔ ")}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.DarkGray,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Tarifas desde",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = "${journey.priceEconomica.toInt()} BOB",
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                                        color = palette.secondary
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { viewModel.startBooking(journey, "Económica") },
                                        colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Económica", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                    }
                                    Button(
                                        onClick = { viewModel.startBooking(journey, "Preferente") },
                                        colors = ButtonDefaults.buttonColors(containerColor = palette.secondary),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Preferente", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 3. BOOKING WORKFLOW (COMPRAR)
@Composable
fun BookingScreen(viewModel: RailwayViewModel, palette: RegionPalette) {
    val journey = viewModel.bookingJourney
    val step = viewModel.bookingStep

    if (journey == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No se ha seleccionado ningún itinerario para reservar.")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Booking Progress indicator
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.primary.copy(alpha = 0.05f)),
            border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.2f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val steps = listOf("1. Viaje", "2. Datos", "3. Asiento", "4. Pago", "5. Fin")
                steps.forEachIndexed { index, name ->
                    val isCurrent = step == index + 1
                    val isPassed = step > index + 1
                    Text(
                        text = name,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Normal
                        ),
                        color = if (isCurrent) palette.primary else if (isPassed) Color.Gray else Color.LightGray
                    )
                }
            }
        }

        when (step) {
            2 -> PassengerDataStep(viewModel, palette)
            3 -> SeatMapStep(viewModel, palette)
            4 -> PaymentStep(viewModel, palette)
            5 -> ConfirmationStep(viewModel, palette)
            else -> PassengerDataStep(viewModel, palette)
        }
    }
}

@Composable
fun PassengerDataStep(viewModel: RailwayViewModel, palette: RegionPalette) {
    var name by remember { mutableStateOf(viewModel.bookingPassengerName) }
    var doc by remember { mutableStateOf(viewModel.bookingPassengerDoc) }

    Card(
        colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Datos de los Pasajeros (Demostración)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = palette.primary
            )
            Text(
                text = "Ingresa nombres de demostración. No solicitamos identificaciones reales para este prototipo.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nombre Completo") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("passenger_name_input")
            )

            OutlinedTextField(
                value = doc,
                onValueChange = { doc = it },
                label = { Text("Documento de Identidad (CI / Pasaporte)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("passenger_doc_input")
            )

            Button(
                onClick = { viewModel.submitPassengerDetails(name, doc) },
                enabled = name.isNotEmpty() && doc.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("passenger_submit_btn")
            ) {
                Text("CONTINUAR A SELECCIÓN DE ASIENTO", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SeatMapStep(viewModel: RailwayViewModel, palette: RegionPalette) {
    var selectedSeat by remember { mutableStateOf(viewModel.bookingSeatNumber) }

    Card(
        colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Selección de Asientos",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = palette.primary,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Train wagon visual illustration
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Gray.copy(alpha = 0.1f))
                    .padding(8.dp)
            ) {
                Text(
                    text = "VISTA ESQUEMÁTICA DEL COCHE (Clase: ${viewModel.bookingClass})",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.Gray,
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Grid of seats
            val rows = 6
            val cols = 4

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (r in 1..rows) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (c in 1..cols) {
                            if (c == 3) {
                                // Aisle
                                Spacer(modifier = Modifier.width(20.dp))
                            }
                            val seatLabel = "Fila $r - A$c"
                            val isOccupied = (r + c) % 3 == 0 // simulated occupancy
                            val isSelected = selectedSeat == seatLabel

                            Box(
                                modifier = Modifier
                                    .size(45.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        if (isOccupied) Color.LightGray
                                        else if (isSelected) palette.secondary
                                        else palette.primary.copy(alpha = 0.1f)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) palette.secondary else palette.primary,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable(enabled = !isOccupied) {
                                        selectedSeat = seatLabel
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$r${'A' + (c - 1)}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (isOccupied) Color.Gray else if (isSelected) Color.White else palette.primary
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(16.dp).background(palette.primary.copy(alpha = 0.1f)).border(1.dp, palette.primary, RoundedCornerShape(2.dp)))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Disponible", style = MaterialTheme.typography.labelSmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(16.dp).background(Color.LightGray).border(1.dp, Color.Gray, RoundedCornerShape(2.dp)))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Ocupado", style = MaterialTheme.typography.labelSmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(16.dp).background(palette.secondary).border(1.dp, palette.secondary, RoundedCornerShape(2.dp)))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tu Selección", style = MaterialTheme.typography.labelSmall)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { viewModel.selectSeatAndProceed(selectedSeat) },
                enabled = selectedSeat.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("seat_submit_btn")
            ) {
                Text("CONTINUAR AL PAGO", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PaymentStep(viewModel: RailwayViewModel, palette: RegionPalette) {
    val journey = viewModel.bookingJourney ?: return
    val balanceState by viewModel.userBalance.collectAsStateWithLifecycle()
    val currentBalance = balanceState?.balance ?: 0.0
    val price = if (viewModel.bookingClass == "Económica") journey.priceEconomica else journey.pricePreferente
    val totalCost = price * viewModel.passengerCount

    Card(
        colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Resumen de Pago",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = palette.primary
            )

            // Price Breakdown list
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Gray.copy(alpha = 0.05f))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Pasaje de Tren (${journey.trainNumber})")
                        Text("${price.toInt()} BOB")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Cantidad de Pasajeros")
                        Text("x ${viewModel.passengerCount}")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Clase")
                        Text(viewModel.bookingClass)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Asiento")
                        Text(viewModel.bookingSeatNumber)
                    }
                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Total a Pagar", fontWeight = FontWeight.Bold, color = palette.primary)
                        Text("${totalCost.toInt()} BOB", fontWeight = FontWeight.Black, color = palette.secondary, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }

            Text(
                text = "Seleccionar Medio de Pago Simulado",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = palette.primary
            )

            // Method 1: Wallet Balance
            Card(
                colors = CardDefaults.cardColors(containerColor = palette.primary.copy(alpha = 0.04f)),
                border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .clickable { viewModel.completePaymentWithWallet() }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Wallet, contentDescription = "Billetera", tint = palette.primary, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Billetera Digital Ferroviaria", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = palette.primary)
                        Text("Saldo Disponible: ${currentBalance.toInt()} BOB", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Pagar", tint = palette.primary)
                }
            }

            // Method 2: Fake cards
            Card(
                colors = CardDefaults.cardColors(containerColor = palette.secondary.copy(alpha = 0.04f)),
                border = BorderStroke(1.dp, palette.secondary.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .clickable { viewModel.completePaymentWithMockCard("Banco Unión de Demostración") }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.CreditCard, contentDescription = "Tarjeta", tint = palette.secondary, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Tarjeta de Débito Simulado (Banco Unión)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = palette.secondary)
                        Text("Simula pago con pasarela nacional de prueba", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Pagar", tint = palette.secondary)
                }
            }

            // Error display
            viewModel.paymentErrorMessage?.let { err ->
                Text(
                    text = err,
                    color = Color.Red,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun ConfirmationStep(viewModel: RailwayViewModel, palette: RegionPalette) {
    val ticket = viewModel.generatedTicket ?: return

    Card(
        colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(palette.primary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Exito", tint = palette.primary, modifier = Modifier.size(40.dp))
            }

            Text(
                text = "¡Reserva Confirmada!",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                color = palette.primary
            )
            Text(
                text = "Tu billete digital para BOLIVIA FERROCARRILES.OS se ha emitido correctamente.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = Color.DarkGray
            )

            HorizontalDivider()

            // Visual historic ticket representation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
                    .padding(16.dp)
                    .drawBehind {
                        // Retro dashed style or line details
                    }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "BILLETE DE EMBARQUE",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = palette.secondary
                        )
                        Text(
                            text = ticket.id,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = palette.primary
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("PASAJERO", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(ticket.passengerName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("CI/DOC", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(ticket.passengerDoc, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("DE", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text("${ticket.originName} (${ticket.originCode})", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("A", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text("${ticket.destName} (${ticket.destCode})", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("SALIDA", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(ticket.departureTime, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("FECHA", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(ticket.date, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ASIENTO", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(ticket.seatNumber, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    viewModel.currentScreen.value = AppScreen.BILLETERA
                    viewModel.resetValidation()
                },
                colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("VER EN MI BILLETERA DIGITAL", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// 4. WALLET / TICKET STORAGE SCREEN (MI BILLETERA)
@Composable
fun WalletScreen(viewModel: RailwayViewModel, palette: RegionPalette) {
    val balanceState by viewModel.userBalance.collectAsStateWithLifecycle()
    val transactions by viewModel.transactionHistory.collectAsStateWithLifecycle()
    val ticketsList by viewModel.tickets.collectAsStateWithLifecycle()

    val currentBalance = balanceState?.balance ?: 0.0
    val cardType = balanceState?.cardType ?: "VIRTUAL"
    val cardNumber = balanceState?.cardNumber ?: "FC-BO-8821-39"
    val cardStatus = balanceState?.cardStatus ?: "ACTIVO"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Digital Card Wallet Illustration
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.primary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TARJETA FERROVIARIA INTEGRADA",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White.copy(alpha = 0.8f)
                    )
                    Text(
                        text = "Bolivia",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = palette.accent
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = "SALDO DISPONIBLE",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                        Text(
                            text = "${currentBalance.toInt()} BOB",
                            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Black),
                            color = Color.White
                        )
                    }

                    // Card chip visual
                    Box(
                        modifier = Modifier
                            .size(36.dp, 28.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFE2E8F0).copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(cardNumber, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                    Text(
                        text = "MODO: $cardType | ESTADO: $cardStatus",
                        color = Color.White.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        // Top up and Tap interactions
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
            shape = RoundedCornerShape(12.dp),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Acciones Rápidas de Tarjeta",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = palette.primary
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.performNfcValidation() },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.Contactless, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SIMULAR NFC", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }

                    Button(
                        onClick = { viewModel.topUpTransitCard(50.0) },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.secondary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(imageVector = Icons.Default.AddCard, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("CARGAR +50 BOB", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }

        // Contactless terminal reading simulation visual output
        if (viewModel.contactlessValidationState != "IDLE") {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = when (viewModel.contactlessValidationState) {
                        "GRANTED" -> Color(0xFFD1FAE5)
                        "DENIED" -> Color(0xFFFEE2E2)
                        else -> palette.primary.copy(alpha = 0.1f)
                    }
                ),
                border = BorderStroke(
                    1.dp,
                    when (viewModel.contactlessValidationState) {
                        "GRANTED" -> Color(0xFF10B981)
                        "DENIED" -> Color(0xFFEF4444)
                        else -> palette.primary
                    }
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "LECTOR SIN CONTACTO (TARIFA CERCANÍAS)",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = palette.primary
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (viewModel.contactlessValidationState == "SCANNING" || viewModel.contactlessValidationState == "VERIFYING") {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = palette.primary)
                        } else if (viewModel.contactlessValidationState == "GRANTED") {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "OK", tint = Color(0xFF10B981))
                        } else if (viewModel.contactlessValidationState == "DENIED") {
                            Icon(imageVector = Icons.Default.Cancel, contentDescription = "ERROR", tint = Color(0xFFEF4444))
                        }
                        Text(
                            text = viewModel.contactlessValidationMessage,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            textAlign = TextAlign.Center
                        )
                    }

                    Button(
                        onClick = { viewModel.resetNfcValidation() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color.LightGray)
                    ) {
                        Text("Limpiar", color = Color.DarkGray, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // Digital Tickets List
        Column {
            Text(
                text = "Tus Billetes Digitales",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = palette.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            val availableTickets = ticketsList.filter { it.status != "CANCELADO" }

            if (availableTickets.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.ConfirmationNumber, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No tienes billetes activos. Compra uno en la pestaña Planificar.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                }
            } else {
                availableTickets.forEach { ticket ->
                    // Retro aesthetic train ticket card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "BILLETE FERROVIARIO",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = palette.secondary
                                )
                                Text(
                                    text = ticket.status,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (ticket.status == "VALIDADO") Color(0xFF10B981) else palette.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(ticket.originCode, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = palette.primary)
                                    Text(ticket.originName, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                }
                                Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = Color.Gray)
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(ticket.destCode, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = palette.primary)
                                    Text(ticket.destName, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("TREN", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    Text(ticket.trainNumber, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                }
                                Column {
                                    Text("FECHA", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    Text(ticket.date, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("ASIENTO", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    Text(ticket.seatNumber, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Action buttons inside ticket card
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.startValidationJourney(ticket) },
                                    colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                                    modifier = Modifier.weight(1.5f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("EMBARCAR (QR)", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                }

                                Button(
                                    onClick = { viewModel.cancelAndRefundTicket(ticket) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.1f)),
                                    border = BorderStroke(1.dp, Color.Red),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("DEVOLVER", color = Color.Red, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                }
                            }

                            // Active Verification process on this specific ticket
                            if (viewModel.validatingTicketId == ticket.id) {
                                Spacer(modifier = Modifier.height(16.dp))
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = when (viewModel.ticketValidationStep) {
                                            "VALID" -> Color(0xFFD1FAE5)
                                            "INVALID" -> Color(0xFFFEE2E2)
                                            else -> Color.DarkGray.copy(alpha = 0.05f)
                                        }
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        when (viewModel.ticketValidationStep) {
                                            "VALID" -> Color(0xFF10B981)
                                            "INVALID" -> Color(0xFFEF4444)
                                            else -> palette.primary
                                        }
                                    )
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "TORNIQUETE DE ACCESO QR",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = palette.primary
                                        )

                                        // QR visual placeholder inside validating block
                                        Box(
                                            modifier = Modifier
                                                .size(120.dp)
                                                .background(Color.White)
                                                .border(2.dp, palette.primary)
                                                .padding(8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.QrCode,
                                                contentDescription = "QR",
                                                tint = Color.Black,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            if (viewModel.ticketValidationStep == "SCANNING" || viewModel.ticketValidationStep == "VERIFYING") {
                                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                            }
                                            Text(
                                                text = viewModel.ticketValidationMessage,
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                                textAlign = TextAlign.Center
                                            )
                                        }

                                        Button(
                                            onClick = { viewModel.resetValidation() },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                            border = BorderStroke(1.dp, Color.LightGray)
                                        ) {
                                            Text("Cerrar Validador", color = Color.DarkGray, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 5. VECTOR SCHEMATIC MAP AND CONTROL CENTER (RED FERROVIARIA)
@Composable
fun MapAndControlScreen(viewModel: RailwayViewModel, palette: RegionPalette) {
    var activeLayer by remember { mutableStateOf("TODAS") } // "TODAS", "ANDINA", "ORIENTAL"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Map toggles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val layers = listOf(
                "TODAS" to "Red Integrada",
                "ANDINA" to "Capa Andina",
                "ORIENTAL" to "Capa Oriental"
            )
            layers.forEach { (code, text) ->
                val isSelected = activeLayer == code
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) palette.primary else Color.LightGray.copy(alpha = 0.3f))
                        .clickable { activeLayer = code }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = text,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (isSelected) Color.White else Color.DarkGray
                    )
                }
            }
        }

        // Live Vector schematic canvas representation
        Card(
            colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.2f)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Mapa Esquemático Nacional",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = palette.primary
                )
                Text(
                    text = "Representación topográfica de corredores y conexiones",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0F172A)) // dark screen like control panels
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasWidth = size.width
                        val canvasHeight = size.height

                        // Coordinates Mapping helpers
                        // Bolivia map fits roughly from La Paz (top left) to Puerto Quijarro (right)
                        val laPaz = Offset(canvasWidth * 0.15f, canvasHeight * 0.2f)
                        val elAlto = Offset(canvasWidth * 0.12f, canvasHeight * 0.22f)
                        val viacha = Offset(canvasWidth * 0.16f, canvasHeight * 0.28f)
                        val oruro = Offset(canvasWidth * 0.22f, canvasHeight * 0.45f)
                        val cochabamba = Offset(canvasWidth * 0.4f, canvasHeight * 0.35f)
                        val aiquile = Offset(canvasWidth * 0.48f, canvasHeight * 0.45f)
                        val uyuni = Offset(canvasWidth * 0.24f, canvasHeight * 0.7f)
                        val potosi = Offset(canvasWidth * 0.38f, canvasHeight * 0.6f)
                        val tupiza = Offset(canvasWidth * 0.26f, canvasHeight * 0.82f)
                        val villazon = Offset(canvasWidth * 0.28f, canvasHeight * 0.92f)

                        val santaCruz = Offset(canvasWidth * 0.58f, canvasHeight * 0.46f)
                        val cotoca = Offset(canvasWidth * 0.64f, canvasHeight * 0.45f)
                        val pailas = Offset(canvasWidth * 0.7f, canvasHeight * 0.43f)
                        val pailon = Offset(canvasWidth * 0.76f, canvasHeight * 0.42f)
                        val sanJose = Offset(canvasWidth * 0.83f, canvasHeight * 0.5f)
                        val robore = Offset(canvasWidth * 0.88f, canvasHeight * 0.62f)
                        val puertoQuijarro = Offset(canvasWidth * 0.94f, canvasHeight * 0.72f)

                        // Draw lines based on filter
                        if (activeLayer == "TODAS" || activeLayer == "ANDINA") {
                            // Andina Lines
                            val andinaPath = Path().apply {
                                moveTo(laPaz.x, laPaz.y)
                                lineTo(elAlto.x, elAlto.y)
                                lineTo(viacha.x, viacha.y)
                                lineTo(oruro.x, oruro.y)
                                lineTo(uyuni.x, uyuni.y)
                                lineTo(tupiza.x, tupiza.y)
                                lineTo(villazon.x, villazon.y)
                            }
                            drawPath(andinaPath, color = Color(0xFF38BDF8), style = Stroke(width = 4f))

                            // Viacha - Potosí branch
                            drawPath(Path().apply {
                                moveTo(viacha.x, viacha.y)
                                lineTo(potosi.x, potosi.y)
                            }, color = Color(0xFF38BDF8), style = Stroke(width = 2.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))))
                        }

                        if (activeLayer == "TODAS" || activeLayer == "ORIENTAL") {
                            // Oriental lines
                            val orientalPath = Path().apply {
                                moveTo(santaCruz.x, santaCruz.y)
                                lineTo(cotoca.x, cotoca.y)
                                lineTo(pailas.x, pailas.y)
                                lineTo(pailon.x, pailon.y)
                                lineTo(sanJose.x, sanJose.y)
                                lineTo(robore.x, robore.y)
                                lineTo(puertoQuijarro.x, puertoQuijarro.y)
                            }
                            drawPath(orientalPath, color = Color(0xFF34D399), style = Stroke(width = 4f))
                        }

                        // Draw hypothetical connection (national integration concept)
                        if (activeLayer == "TODAS") {
                            drawPath(Path().apply {
                                moveTo(oruro.x, oruro.y)
                                lineTo(cochabamba.x, cochabamba.y)
                                lineTo(santaCruz.x, santaCruz.y)
                            }, color = Color(0xFFFBBF24), style = Stroke(width = 3f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f))))
                        }

                        // Draw regional valley services
                        if (activeLayer == "TODAS") {
                            drawPath(Path().apply {
                                moveTo(cochabamba.x, cochabamba.y)
                                lineTo(aiquile.x, aiquile.y)
                            }, color = Color(0xFFFB923C), style = Stroke(width = 2.5f))
                        }

                        // Draw station circles
                        val stations = mutableListOf<Pair<Offset, String>>()
                        if (activeLayer == "TODAS" || activeLayer == "ANDINA") {
                            stations.add(laPaz to "La Paz")
                            stations.add(oruro to "Oruro")
                            stations.add(uyuni to "Uyuni")
                            stations.add(villazon to "Villazón")
                            stations.add(potosi to "Potosí")
                        }
                        if (activeLayer == "TODAS" || activeLayer == "ORIENTAL") {
                            stations.add(santaCruz to "Santa Cruz")
                            stations.add(sanJose to "S.J. Chiquitos")
                            stations.add(robore to "Roboré")
                            stations.add(puertoQuijarro to "P. Quijarro")
                        }

                        stations.forEach { (pos, label) ->
                            drawCircle(color = Color.White, radius = 6f, center = pos)
                            drawCircle(color = Color(0xFF1E293B), radius = 3f, center = pos)
                        }
                    }

                    // Floating text overlay labels
                    Text("Andina (Occidente)", color = Color(0xFF38BDF8), style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.TopStart).padding(8.dp))
                    Text("Oriental (Este)", color = Color(0xFF34D399), style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp))
                    Text("Red Virtual de Demostración", color = Color(0xFFFBBF24), style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.BottomStart).padding(8.dp))
                }
            }
        }

        // Live logs scrolling block (simulating traffic logs)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Centro de Control Ferroviario - Live Logs",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace),
                        color = Color(0xFF38BDF8)
                    )
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color.Green)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(viewModel.liveSimulationLogs) { log ->
                        Text(
                            text = log,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            ),
                            color = if (log.contains("[ALERTA]") || log.contains("[FAIL]")) Color(0xFFF87171)
                                    else if (log.contains("[VENTA]") || log.contains("[ABORDO]")) Color(0xFF34D399)
                                    else Color.White
                        )
                    }
                }
            }
        }
    }
}

// 6. STATIONS DIRECTORY SCREEN
@Composable
fun StationsScreen(viewModel: RailwayViewModel, palette: RegionPalette) {
    val stationsList by viewModel.stations.collectAsStateWithLifecycle()
    var searchQuery by remember { mutableStateOf("") }
    var regionFilter by remember { mutableStateOf("TODAS") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            label = { Text("Buscar Estación (ej: Uyuni, Santa Cruz)") },
            modifier = Modifier.fillMaxWidth()
        )

        // Filters
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf(
                "TODAS" to "Todas",
                "ANDINA" to "Andina",
                "ORIENTAL" to "Oriental"
            )
            filters.forEach { (code, text) ->
                val isSelected = regionFilter == code
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) palette.primary else Color.LightGray.copy(alpha = 0.3f))
                        .clickable { regionFilter = code }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = text,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (isSelected) Color.White else Color.DarkGray
                    )
                }
            }
        }

        val filteredStations = stationsList.filter {
            (regionFilter == "TODAS" || it.region == regionFilter) &&
            (searchQuery.isEmpty() || it.name.contains(searchQuery, ignoreCase = true) || it.code.contains(searchQuery, ignoreCase = true))
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredStations) { station ->
                var expanded by remember { mutableStateOf(false) }

                Card(
                    colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expanded = !expanded }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = station.name,
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                    color = palette.primary
                                )
                                Text(
                                    text = "Código: ${station.code} | Red: ${station.region}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.Gray
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        when (station.status) {
                                            "ACTIVA" -> Color(0xFFD1FAE5)
                                            "REHABILITACION" -> Color(0xFFFEF3C7)
                                            else -> Color(0xFFF3F4F6)
                                        }
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = station.status,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = when (station.status) {
                                        "ACTIVA" -> Color(0xFF065F46)
                                        "REHABILITACION" -> Color(0xFF92400E)
                                        else -> Color.DarkGray
                                    }
                                )
                            }
                        }

                        if (expanded) {
                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "LÍNEAS OPERATIVAS",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = palette.secondary
                            )
                            Text(station.lines, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 8.dp))

                            Text(
                                text = "SERVICIOS EN ESTACIÓN",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = palette.secondary
                            )
                            Text(station.amenities, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 8.dp))

                            Text(
                                text = "RESEÑA HISTÓRICA",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = palette.secondary
                            )
                            Text(
                                text = station.historicalInfo,
                                style = MaterialTheme.typography.bodySmall,
                                fontStyle = FontStyle.Italic
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            // Simple mock departures list
                            Text(
                                text = "PRÓXIMAS SALIDAS (SIMULADO)",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = palette.primary
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 4.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("08:30 - Expreso del Sur (A Tiempo)", style = MaterialTheme.typography.labelSmall)
                                    Text("Andén 1", style = MaterialTheme.typography.labelSmall)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("14:10 - Ferrobús Altiplano (Programado)", style = MaterialTheme.typography.labelSmall)
                                    Text("Andén 2", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 7. OPERATIONAL SIMULATOR CONTROLS AND SCENARIOS
@Composable
fun SimulatorScreen(viewModel: RailwayViewModel, palette: RegionPalette) {
    var activeScenario = viewModel.simulationActiveScenario

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Módulo de Simulación Ferroviaria",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = palette.primary
                    )
                    Text(
                        text = "Ajusta las condiciones de la red y observa las métricas de rendimiento operacional en tiempo real.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }
        }

        // Live metrics grid
        item {
            Column {
                Text(
                    text = "Métricas Operacionales en Tiempo Real",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = palette.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.height(250.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val metrics = listOf(
                        Triple(Icons.Default.Timer, "Puntualidad Red", "${viewModel.livePuntualidad}%"),
                        Triple(Icons.Default.People, "Pasajeros Totales", viewModel.livePasajerosCount.toString()),
                        Triple(Icons.Default.AirlineSeatReclineNormal, "Ocupación Media", "${viewModel.liveOcupacionMedia}%"),
                        Triple(Icons.Default.Check, "Validadas con Éxito", viewModel.liveValidacionesExito.toString()),
                        Triple(Icons.Default.ErrorOutline, "Rechazadas/Errores", viewModel.liveValidacionesFallo.toString()),
                        Triple(Icons.Default.Warning, "Incidentes Activos", viewModel.liveIncidentesActivos.toString())
                    )

                    items(metrics) { (icon, label, value) ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
                            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(imageVector = icon, contentDescription = null, tint = palette.primary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = palette.primary)
                            }
                        }
                    }
                }
            }
        }

        // Scenarios
        item {
            Column {
                Text(
                    text = "Escenarios Operacionales Disponibles",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = palette.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                val scenarios = listOf(
                    Triple("Día Normal", "Operación óptima regular en todas las líneas.", "A TIEMPO"),
                    Triple("Hora Punta", "Congestión simulada y alta demanda de abordo.", "ALTA DEMANDA"),
                    Triple("Demora Altiplano", "Retrasos de 15 min en tramos andinos por obras.", "DEMORADO"),
                    Triple("Bloqueo Oriental", "Corte técnico entre San José y Roboré.", "CORTE DE LÍNEA"),
                    Triple("Servicio Turístico", "Viaje histórico con coches patrimoniales.", "ESPECIAL")
                )

                scenarios.forEach { (name, desc, badge) ->
                    val isSelected = activeScenario == name
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) palette.primary.copy(alpha = 0.08f) else palette.surfaceColor
                        ),
                        border = BorderStroke(1.dp, if (isSelected) palette.primary else Color.LightGray.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .clickable { viewModel.triggerSimulationScenario(name) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = palette.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(palette.secondary.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = badge, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = palette.secondary)
                                    }
                                }
                                Text(text = desc, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                            RadioButton(
                                selected = isSelected,
                                onClick = { viewModel.triggerSimulationScenario(name) },
                                colors = RadioButtonDefaults.colors(selectedColor = palette.primary)
                            )
                        }
                    }
                }
            }
        }
    }
}

// 8. PROFILE / CONTACTLESS LEDGER SCREEN
@Composable
fun ProfileScreen(viewModel: RailwayViewModel, palette: RegionPalette) {
    val balanceState by viewModel.userBalance.collectAsStateWithLifecycle()
    val transactions by viewModel.transactionHistory.collectAsStateWithLifecycle()

    val currentBalance = balanceState?.balance ?: 0.0
    val cardNumber = balanceState?.cardNumber ?: "FC-BO-8821-39"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(palette.primary.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = palette.primary, modifier = Modifier.size(36.dp))
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("Tomás Benavídez", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = palette.primary)
                        Text("Pasajero de la Red Nacional", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Text("Documento CI: 9124805 LP (Demostración)", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Configuración de Tarjeta Virtual",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                        color = palette.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Modo de Tarjeta Ferroviaria", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text("Cambiar entre tarjeta física o virtual en billetera", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }

                        var checked by remember { mutableStateOf(viewModel.nfcCardTypeSelected == "FISICA") }
                        Switch(
                            checked = checked,
                            onCheckedChange = {
                                checked = it
                                viewModel.switchNfcCardType(if (it) "FISICA" else "VIRTUAL")
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = palette.primary)
                        )
                    }
                }
            }
        }

        // Transactions list from Room db
        item {
            Column {
                Text(
                    text = "Historial de Transacciones (Billetera Local)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = palette.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (transactions.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No hay movimientos registrados.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                } else {
                    transactions.forEach { tx ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = palette.surfaceColor),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = tx.description,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = palette.primary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(tx.timestamp))
                                    Text(
                                        text = "$dateStr | Tipo: ${tx.type}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.Gray
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "${if (tx.amount > 0) "+" else ""}${tx.amount.toInt()} BOB",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Black),
                                    color = if (tx.amount > 0) Color(0xFF10B981) else palette.secondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
