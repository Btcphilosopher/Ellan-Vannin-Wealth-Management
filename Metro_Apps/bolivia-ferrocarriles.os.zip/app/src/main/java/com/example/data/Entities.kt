package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_balance")
data class UserBalance(
    @PrimaryKey val id: Int = 1,
    val cardType: String = "VIRTUAL", // "FISICA", "VIRTUAL", "NINGUNO"
    val cardNumber: String = "FC-BO-8821-39",
    val balance: Double = 150.0,
    val cardStatus: String = "ACTIVO" // "ACTIVO", "BLOQUEADO"
)

@Entity(tableName = "transaction_records")
data class TransactionRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String, // "RECARGA", "PAGO_BILLETE", "REEMBOLSO"
    val amount: Double,
    val description: String
)

@Entity(tableName = "stations")
data class Station(
    @PrimaryKey val code: String,
    val name: String,
    val region: String, // "ANDINA", "ORIENTAL", "VALLES", "CHIQUITANIA", "PANTANAL"
    val lines: String, // e.g. "Línea Occidental, Ramal Villazón"
    val status: String, // "ACTIVA", "HISTORICA", "HIPOTETICA", "REHABILITACION"
    val amenities: String, // e.g. "Boletería, Baños, Conexión de Bus, Cafetería"
    val historicalInfo: String,
    val latitude: Double,
    val longitude: Double
)

@Entity(tableName = "tickets")
data class Ticket(
    @PrimaryKey val id: String, // e.g. "RES-8921-X"
    val passengerName: String,
    val passengerDoc: String,
    val originCode: String,
    val originName: String,
    val destCode: String,
    val destName: String,
    val departureTime: String,
    val arrivalTime: String,
    val date: String,
    val trainNumber: String,
    val className: String, // "Económica", "Preferente"
    val seatNumber: String,
    val price: Double,
    val status: String, // "RESERVADO", "CONFIRMADO", "LISTO_EMBARQUE", "VALIDADO", "UTILIZADO", "CANCELADO"
    val qrCode: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "service_alerts")
data class ServiceAlert(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val details: String,
    val region: String, // "ANDINA", "ORIENTAL", "NACIONAL"
    val affectedLines: String,
    val consequence: String,
    val publishTime: String,
    val duration: String,
    val isDemo: Boolean = true
)

@Entity(tableName = "simulation_metrics")
data class SimulationMetric(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val scenarioName: String,
    val puntualidad: Int, // percentage, e.g. 96
    val pasajerosTransportados: Int,
    val ocupacionPromedio: Int, // percentage
    val tiempoEmbarque: Int, // seconds/min
    val validacionesCorrectas: Int,
    val billetesRechazados: Int,
    val incidenciasReportadas: Int,
    val timestamp: Long = System.currentTimeMillis()
)
