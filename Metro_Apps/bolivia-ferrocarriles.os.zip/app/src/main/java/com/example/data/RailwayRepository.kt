package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.first

class RailwayRepository(private val dao: RailwayDao) {

    val userBalanceFlow: Flow<UserBalance?> = dao.getUserBalanceFlow()
    val transactionsFlow: Flow<List<TransactionRecord>> = dao.getTransactionsFlow()
    val stationsFlow: Flow<List<Station>> = dao.getStationsFlow()
    val ticketsFlow: Flow<List<Ticket>> = dao.getTicketsFlow()
    val alertsFlow: Flow<List<ServiceAlert>> = dao.getAlertsFlow()
    val simulationMetricsFlow: Flow<List<SimulationMetric>> = dao.getSimulationMetricsFlow()

    suspend fun getUserBalanceDirect(): UserBalance? = dao.getUserBalanceDirect()

    suspend fun topUpBalance(amount: Double, description: String) {
        val current = dao.getUserBalanceDirect() ?: UserBalance()
        val updatedAmount = current.balance + amount
        dao.updateBalanceAmount(updatedAmount)
        dao.insertTransaction(
            TransactionRecord(
                type = "RECARGA",
                amount = amount,
                description = description
            )
        )
    }

    suspend fun chargeBalance(amount: Double, description: String): Boolean {
        val current = dao.getUserBalanceDirect() ?: UserBalance()
        if (current.balance < amount) return false
        val updatedAmount = current.balance - amount
        dao.updateBalanceAmount(updatedAmount)
        dao.insertTransaction(
            TransactionRecord(
                type = "PAGO_BILLETE",
                amount = -amount,
                description = description
            )
        )
        return true
    }

    suspend fun refundBalance(amount: Double, description: String) {
        val current = dao.getUserBalanceDirect() ?: UserBalance()
        val updatedAmount = current.balance + amount
        dao.updateBalanceAmount(updatedAmount)
        dao.insertTransaction(
            TransactionRecord(
                type = "REEMBOLSO",
                amount = amount,
                description = description
            )
        )
    }

    suspend fun updateCardDetails(status: String, cardType: String) {
        dao.updateCardDetails(status, cardType)
    }

    suspend fun addTransaction(record: TransactionRecord) {
        dao.insertTransaction(record)
    }

    suspend fun insertTicket(ticket: Ticket) {
        dao.insertTicket(ticket)
    }

    suspend fun getTicketById(id: String): Ticket? {
        return dao.getTicketById(id)
    }

    suspend fun updateTicketStatus(id: String, status: String) {
        dao.updateTicketStatus(id, status)
    }

    suspend fun deleteTicketById(id: String) {
        dao.deleteTicketById(id)
    }

    suspend fun insertSimulationMetric(metric: SimulationMetric) {
        dao.insertSimulationMetric(metric)
    }

    suspend fun addServiceAlert(alert: ServiceAlert) {
        dao.insertAlerts(listOf(alert))
    }

    suspend fun clearAllAlerts() {
        dao.clearAlerts()
    }

    suspend fun seedDatabase() {
        // 1. Seed balance if missing
        val currentBalance = dao.getUserBalanceDirect()
        if (currentBalance == null) {
            dao.insertUserBalance(
                UserBalance(
                    id = 1,
                    cardType = "VIRTUAL",
                    cardNumber = "FC-BO-8821-39",
                    balance = 150.0,
                    cardStatus = "ACTIVO"
                )
            )
            dao.insertTransaction(
                TransactionRecord(
                    type = "RECARGA",
                    amount = 150.0,
                    description = "Carga inicial de bienvenida para demostración"
                )
            )
        }

        // 2. Seed Stations if empty
        val currentStations = dao.getStationsFlow().first()
        if (currentStations.isEmpty()) {
            val defaultStations = listOf(
                // RED ANDINA
                Station(
                    code = "LPB",
                    name = "La Paz - Central",
                    region = "ANDINA",
                    lines = "Red Occidental, Ramal Principal",
                    status = "ACTIVA",
                    amenities = "Boletería, Baños, Enlace Teleférico, Conexión de Bus, Cafetería",
                    historicalInfo = "Estación histórica inaugurada a principios del siglo XX, vital para el comercio con las costas del Pacífico.",
                    latitude = -16.4916,
                    longitude = -68.1402
                ),
                Station(
                    code = "EAL",
                    name = "El Alto Terminal",
                    region = "ANDINA",
                    lines = "Red Occidental, Conexión Viacha",
                    status = "ACTIVA",
                    amenities = "Boletería, Accesibilidad PMR, Baños, Sala de Espera Calefaccionada",
                    historicalInfo = "Ubicada a más de 4000 msnm, conecta los flujos urbanos con las rutas de larga distancia de la Red Andina.",
                    latitude = -16.5135,
                    longitude = -68.1882
                ),
                Station(
                    code = "VIA",
                    name = "Viacha",
                    region = "ANDINA",
                    lines = "Red Occidental, Ramal Oruro",
                    status = "ACTIVA",
                    amenities = "Boletería, Baños, Estacionamiento, Carga y Encomiendas",
                    historicalInfo = "Histórico nudo de rieles que unificaba las líneas hacia el puerto de Arica, La Paz y la meseta altiplánica.",
                    latitude = -16.6500,
                    longitude = -68.3000
                ),
                Station(
                    code = "ORU",
                    name = "Oruro",
                    region = "ANDINA",
                    lines = "Red Occidental, Troncal Andina",
                    status = "ACTIVA",
                    amenities = "Boletería, Cafetería, Baños, Custodia de Equipaje",
                    historicalInfo = "El gran núcleo ferroviario del altiplano boliviano, punto de transbordo hacia los salares y el sur.",
                    latitude = -17.9631,
                    longitude = -67.1064
                ),
                Station(
                    code = "UYU",
                    name = "Uyuni",
                    region = "ANDINA",
                    lines = "Red Occidental, Ramal Frontera Chile",
                    status = "ACTIVA",
                    amenities = "Boletería Turística, Baños, WiFi Gratis, Información de Salares",
                    historicalInfo = "Hogar del cementerio de trenes más famoso del mundo, punto estratégico del auge de la minería de plata y estaño.",
                    latitude = -20.4633,
                    longitude = -66.8225
                ),
                Station(
                    code = "ATO",
                    name = "Atocha",
                    region = "ANDINA",
                    lines = "Red Occidental, Ramal Villazón",
                    status = "ACTIVA",
                    amenities = "Baños, Boletería, Sala de Espera",
                    historicalInfo = "Estación andina clave tallada entre cañones áridos que conectó históricamente Oruro con el sur minero.",
                    latitude = -20.9333,
                    longitude = -66.2167
                ),
                Station(
                    code = "TUP",
                    name = "Tupiza",
                    region = "ANDINA",
                    lines = "Red Occidental, Troncal del Sur",
                    status = "ACTIVA",
                    amenities = "Boletería, Enlace Turístico, Baños, Custodia",
                    historicalInfo = "Ruta rodeada de imponentes formaciones coloradas, famosa por el paso del tren de pasajeros de alta montaña.",
                    latitude = -21.4429,
                    longitude = -65.7196
                ),
                Station(
                    code = "VIL",
                    name = "Villazón",
                    region = "ANDINA",
                    lines = "Red Occidental, Conexión Argentina",
                    status = "ACTIVA",
                    amenities = "Boletería, Control Aduanero, Baños, Cambio de Divisas",
                    historicalInfo = "Terminal fronteriza del sur andino boliviano, conectando pasajeros e intercambio comercial con La Quiaca, Argentina.",
                    latitude = -22.0911,
                    longitude = -65.5947
                ),
                Station(
                    code = "POT",
                    name = "Potosí - El Condor",
                    region = "ANDINA",
                    lines = "Red Occidental, Ramal Minero",
                    status = "REHABILITACION",
                    amenities = "Información Histórica, Baños, Mirador a Gran Altura",
                    historicalInfo = "Estación de pasajeros a mayor altura del país, sirviendo a la mítica Villa Imperial de Carlos V.",
                    latitude = -19.5888,
                    longitude = -65.7531
                ),

                // RED ORIENTAL
                Station(
                    code = "SCZ",
                    name = "Santa Cruz de la Sierra - Terminal Bimodal",
                    region = "ORIENTAL",
                    lines = "Red Oriental, Troncal del Este",
                    status = "ACTIVA",
                    amenities = "Boletería Multipropósito, Baños, Cafeterías, Conexión de Buses, Hotel de Pasajeros",
                    historicalInfo = "Principal terminal de transporte terrestre y ferroviario del Oriente, puerta de salida hacia el Chaco, Chiquitanía y Brasil.",
                    latitude = -17.7944,
                    longitude = -63.1558
                ),
                Station(
                    code = "COT",
                    name = "Cotoca",
                    region = "ORIENTAL",
                    lines = "Red Oriental, Ramal Chiquitano",
                    status = "ACTIVA",
                    amenities = "Boletería, Ventas de Artesanía, Baños",
                    historicalInfo = "Estación próxima al santuario de la Virgen de Cotoca, célebre parada de servicios religiosos y de cercanía.",
                    latitude = -17.7500,
                    longitude = -63.0600
                ),
                Station(
                    code = "PLS",
                    name = "Pailas (Río Grande)",
                    region = "ORIENTAL",
                    lines = "Red Oriental, Cruce de Puente",
                    status = "ACTIVA",
                    amenities = "Baños, Control Operativo de Vías",
                    historicalInfo = "Estación de control adyacente al emblemático puente ferroviario mixto que cruza el inmenso Río Grande.",
                    latitude = -17.6531,
                    longitude = -62.7911
                ),
                Station(
                    code = "PLN",
                    name = "Pailón",
                    region = "ORIENTAL",
                    lines = "Red Oriental, Entrada Chiquitanía",
                    status = "ACTIVA",
                    amenities = "Boletería, Baños, Sala de Espera",
                    historicalInfo = "Puerta de entrada geográfica al gran llano chiquitano, epicentro de la producción agrícola y maderera oriental.",
                    latitude = -17.6600,
                    longitude = -62.7200
                ),
                Station(
                    code = "SJC",
                    name = "San José de Chiquitos",
                    region = "ORIENTAL",
                    lines = "Red Oriental, Ramal Misiones",
                    status = "ACTIVA",
                    amenities = "Boletería Turística, Baños, Información Misional, Venta de Souvenirs",
                    historicalInfo = "Estación de estilo colonial que sirve a la cuna de la chiquitanía y templo misional jesuítico patrimonio de la UNESCO.",
                    latitude = -17.8447,
                    longitude = -60.7431
                ),
                Station(
                    code = "ROB",
                    name = "Roboré",
                    region = "ORIENTAL",
                    lines = "Red Oriental, Corredor Biocéanico",
                    status = "ACTIVA",
                    amenities = "Boletería, Baños, Cafetería regional, Enlace de Ecoturismo",
                    historicalInfo = "Conocida como 'La Perla del Oriente', rodeada de serranías, aguas termales, cascadas y un entorno natural asombroso.",
                    latitude = -18.3333,
                    longitude = -59.7500
                ),
                Station(
                    code = "PSU",
                    name = "Puerto Suárez",
                    region = "ORIENTAL",
                    lines = "Red Oriental, Frontera Brasil",
                    status = "ACTIVA",
                    amenities = "Boletería, Baños, Aduana de Carga",
                    historicalInfo = "Estratégica parada cercana a la Laguna Cáceres y puerto clave del sistema fluvial hacia el río Paraguay.",
                    latitude = -18.9667,
                    longitude = -57.8000
                ),
                Station(
                    code = "PTQ",
                    name = "Puerto Quijarro",
                    region = "ORIENTAL",
                    lines = "Red Oriental, Conexión Corumbá",
                    status = "ACTIVA",
                    amenities = "Boletería Internacional, Baños, Enlace Fronterizo, Carga Multimodal",
                    historicalInfo = "Terminal fronteriza de la Red Oriental boliviana, posibilitando el intercambio con el ferrocarril de Brasil.",
                    latitude = -19.0022,
                    longitude = -57.7125
                ),

                // REGIONAL & HISTORIC
                Station(
                    code = "CBB",
                    name = "Cochabamba - San Antonio",
                    region = "VALLES",
                    lines = "Ramal Central, Tren Metropolitano",
                    status = "ACTIVA",
                    amenities = "Boletería Tren Eléctrico, Accesibilidad, Baños, Enlace de Cercanías",
                    historicalInfo = "Antigua estación de locomotoras a vapor reconvertida en moderna terminal del Tren Metropolitano.",
                    latitude = -17.4000,
                    longitude = -66.1500
                ),
                Station(
                    code = "VIV",
                    name = "Vila Vila",
                    region = "VALLES",
                    lines = "Ramal Histórico Vila Vila - Aiquile",
                    status = "REHABILITACION",
                    amenities = "Información Patrimonial, Parada Histórica",
                    historicalInfo = "Pintoresca estación valluna que albergó el paso de autocarriles regionales que conectaban Cochabamba con los valles profundos.",
                    latitude = -17.8200,
                    longitude = -65.9000
                ),
                Station(
                    code = "AIQ",
                    name = "Aiquile",
                    region = "VALLES",
                    lines = "Ramal Histórico del Cono Sur",
                    status = "HISTORICA",
                    amenities = "Museo de Instrumentos Locales, Venta de Charangos",
                    historicalInfo = "Terminal del ramal cochabambino del Cono Sur, célebre por su cultura valluna, festivales de charango y ferrocarriles históricos.",
                    latitude = -18.1500,
                    longitude = -65.1800
                )
            )
            dao.insertStations(defaultStations)
        }

        // 3. Seed Alerts if empty
        val currentAlerts = dao.getAlertsFlow().first()
        if (currentAlerts.isEmpty()) {
            val defaultAlerts = listOf(
                ServiceAlert(
                    title = "Mantenimiento en Tramo Challapata (Red Andina)",
                    details = "Obras de nivelación preventiva de rieles en el tramo Challapata - Río Mulato. Los trenes de pasajeros 'Expreso del Sur' y 'Wara Wara del Sur' podrían registrar demoras estimadas de 15 a 20 minutos.",
                    region = "ANDINA",
                    affectedLines = "Troncal Andina (Oruro - Uyuni)",
                    consequence = "Demora Leve (15-20 min)",
                    publishTime = "Hace 2 horas",
                    duration = "Hasta el 25 de Septiembre",
                    isDemo = true
                ),
                ServiceAlert(
                    title = "Nuevas Frecuencias Turísticas Chiquitanía",
                    details = "Se habilitan las salidas especiales de fin de semana para el Tren de las Misiones Jesuíticas. Recorrido panorámico de Santa Cruz de la Sierra hacia San José de Chiquitos.",
                    region = "ORIENTAL",
                    affectedLines = "Ramal Chiquitano (Santa Cruz - San José)",
                    consequence = "Servicio Especial Activo",
                    publishTime = "Ayer",
                    duration = "Temporal (Fines de semana)",
                    isDemo = true
                ),
                ServiceAlert(
                    title = "Estudios Geotécnicos en Ramal Potosí",
                    details = "Estación El Cóndor en fase de análisis estructural para el futuro restablecimiento regular de pasajeros en la ruta alta de los Andes.",
                    region = "ANDINA",
                    affectedLines = "Ramal Minero (Viacha - Potosí)",
                    consequence = "Línea en Rehabilitación",
                    publishTime = "Hace 3 días",
                    duration = "Indefinida",
                    isDemo = true
                )
            )
            dao.insertAlerts(defaultAlerts)
        }
    }
}
