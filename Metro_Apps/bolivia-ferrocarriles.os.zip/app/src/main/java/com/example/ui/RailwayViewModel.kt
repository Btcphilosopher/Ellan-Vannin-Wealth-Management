package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

enum class AppScreen {
    INICIO,
    PLANIFICAR,
    COMPRAR,
    BILLETERA,
    RED_FERROVIARIA,
    ESTACIONES,
    ESTADO_SERVICIO,
    SIMULADOR,
    PERFIL
}

data class SynthesizedJourney(
    val id: String,
    val trainNumber: String,
    val trainName: String,
    val originCode: String,
    val originName: String,
    val destCode: String,
    val destName: String,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val priceEconomica: Double,
    val pricePreferente: Double,
    val availableSeats: Int,
    val totalSeats: Int,
    val region: String,
    val status: String, // "A TIEMPO", "DEMORADO", "PROGRAMADO"
    val stopStations: List<String>
)

class RailwayViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: RailwayRepository

    init {
        val database = RailwayDatabase.getDatabase(application)
        repository = RailwayRepository(database.railwayDao())
        
        // Seed database and initialize default states
        viewModelScope.launch {
            repository.seedDatabase()
            startSimulationLoop()
        }
    }

    // Navigation and screen flows
    val currentScreen = MutableStateFlow(AppScreen.INICIO)
    val selectedRegionalFilter = MutableStateFlow("NACIONAL") // "ANDINA", "ORIENTAL", "NACIONAL"

    // DB backed flows
    val userBalance: StateFlow<UserBalance?> = repository.userBalanceFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val transactionHistory: StateFlow<List<TransactionRecord>> = repository.transactionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stations: StateFlow<List<Station>> = repository.stationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<Ticket>> = repository.ticketsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alerts: StateFlow<List<ServiceAlert>> = repository.alertsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val simulationMetrics: StateFlow<List<SimulationMetric>> = repository.simulationMetricsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state for Travel Search & Planning
    var searchOrigin by mutableStateOf<Station?>(null)
    var searchDestination by mutableStateOf<Station?>(null)
    var searchDate by mutableStateOf("2026-09-23")
    var searchDateSelectedText by mutableStateOf("Mañana (23 Sep)")
    var passengerCount by mutableStateOf(1)
    var searchClassPreference by mutableStateOf("Económica")
    var searchNeedsAccessibility by mutableStateOf(false)
    var searchWithBicycle by mutableStateOf(false)

    // Results of planning search
    var searchResults by mutableStateOf<List<SynthesizedJourney>>(emptyList())
    var isSearching by mutableStateOf(false)

    // Active purchase process
    var bookingJourney by mutableStateOf<SynthesizedJourney?>(null)
    var bookingClass by mutableStateOf("Económica")
    var bookingPassengerName by mutableStateOf("Tomás Benavídez")
    var bookingPassengerDoc by mutableStateOf("9124805 LP")
    var bookingSeatNumber by mutableStateOf("")
    var bookingStep by mutableStateOf(1) // 1: Select Journey, 2: Passenger Data, 3: Seat Map, 4: Payment, 5: Confirmation
    var generatedTicket by mutableStateOf<Ticket?>(null)
    var paymentErrorMessage by mutableStateOf<String?>(null)

    // Contactless NFC / QR Reader Simulator
    var contactlessValidationState by mutableStateOf("IDLE") // "IDLE", "SCANNING", "VERIFYING", "GRANTED", "DENIED"
    var contactlessValidationMessage by mutableStateOf("")
    var nfcCardTypeSelected by mutableStateOf("VIRTUAL") // "VIRTUAL", "FISICA"

    // Digital ticket QR validator
    var validatingTicketId by mutableStateOf<String?>(null)
    var ticketValidationStep by mutableStateOf("IDLE") // "IDLE", "SCANNING", "VERIFYING", "VALID", "INVALID"
    var ticketValidationMessage by mutableStateOf("")
    var inspectorModeActive by mutableStateOf(false)

    // Simulation states
    var simulationActiveScenario by mutableStateOf("Día Normal")
    var livePuntualidad by mutableStateOf(96)
    var livePasajerosCount by mutableStateOf(1450)
    var liveOcupacionMedia by mutableStateOf(72)
    var liveValidacionesExito by mutableStateOf(892)
    var liveValidacionesFallo by mutableStateOf(12)
    var liveIncidentesActivos by mutableStateOf(0)
    val liveSimulationLogs = mutableStateListOf<String>()

    private var simulationJob: Job? = null

    // Perform journey search
    fun performSearch() {
        val origin = searchOrigin ?: return
        val dest = searchDestination ?: return
        
        isSearching = true
        searchResults = emptyList()

        viewModelScope.launch {
            delay(800) // Synthesized loading
            
            val isAndina = origin.region == "ANDINA" && dest.region == "ANDINA"
            val isOriental = origin.region == "ORIENTAL" && dest.region == "ORIENTAL"
            val isRegionalValles = origin.region == "VALLES" && dest.region == "VALLES"

            val results = mutableListOf<SynthesizedJourney>()

            if (isAndina) {
                results.add(
                    SynthesizedJourney(
                        id = "J-AND-01",
                        trainNumber = "EX-SUR-501",
                        trainName = "Expreso del Sur",
                        originCode = origin.code,
                        originName = origin.name,
                        destCode = dest.code,
                        destName = dest.name,
                        departureTime = "08:30",
                        arrivalTime = "13:45",
                        duration = "5h 15m",
                        priceEconomica = 50.0,
                        pricePreferente = 90.0,
                        availableSeats = 14,
                        totalSeats = 40,
                        region = "ANDINA",
                        status = "A TIEMPO",
                        stopStations = listOf(origin.name, "Viacha", "Oruro", dest.name)
                    )
                )
                results.add(
                    SynthesizedJourney(
                        id = "J-AND-02",
                        trainNumber = "WWS-503",
                        trainName = "Wara Wara del Sur",
                        originCode = origin.code,
                        originName = origin.name,
                        destCode = dest.code,
                        destName = dest.name,
                        departureTime = "20:15",
                        arrivalTime = "06:40",
                        duration = "10h 25m",
                        priceEconomica = 65.0,
                        pricePreferente = 120.0,
                        availableSeats = 28,
                        totalSeats = 50,
                        region = "ANDINA",
                        status = "PROGRAMADO",
                        stopStations = listOf(origin.name, "Viacha", "Oruro", "Atocha", "Tupiza", dest.name)
                    )
                )
                results.add(
                    SynthesizedJourney(
                        id = "J-AND-03",
                        trainNumber = "FBA-512",
                        trainName = "Ferrobús Altiplano",
                        originCode = origin.code,
                        originName = origin.name,
                        destCode = dest.code,
                        destName = dest.name,
                        departureTime = "14:10",
                        arrivalTime = "18:30",
                        duration = "4h 20m",
                        priceEconomica = 45.0,
                        pricePreferente = 80.0,
                        availableSeats = 6,
                        totalSeats = 25,
                        region = "ANDINA",
                        status = "A TIEMPO",
                        stopStations = listOf(origin.name, "Viacha", dest.name)
                    )
                )
            } else if (isOriental) {
                results.add(
                    SynthesizedJourney(
                        id = "J-ORI-01",
                        trainNumber = "EXO-102",
                        trainName = "Expreso Oriental",
                        originCode = origin.code,
                        originName = origin.name,
                        destCode = dest.code,
                        destName = dest.name,
                        departureTime = "12:30",
                        arrivalTime = "17:30",
                        duration = "5h 00m",
                        priceEconomica = 40.0,
                        pricePreferente = 75.0,
                        availableSeats = 22,
                        totalSeats = 45,
                        region = "ORIENTAL",
                        status = "A TIEMPO",
                        stopStations = listOf(origin.name, "Cotoca", "Pailón", "San José de Chiquitos", dest.name)
                    )
                )
                results.add(
                    SynthesizedJourney(
                        id = "J-ORI-02",
                        trainNumber = "FBO-104",
                        trainName = "Ferrobús Oriental",
                        originCode = origin.code,
                        originName = origin.name,
                        destCode = dest.code,
                        destName = dest.name,
                        departureTime = "18:00",
                        arrivalTime = "22:15",
                        duration = "4h 15m",
                        priceEconomica = 55.0,
                        pricePreferente = 100.0,
                        availableSeats = 8,
                        totalSeats = 30,
                        region = "ORIENTAL",
                        status = "DEMORADO",
                        stopStations = listOf(origin.name, "Pailón", "San José de Chiquitos", "Roboré", dest.name)
                    )
                )
                results.add(
                    SynthesizedJourney(
                        id = "J-ORI-03",
                        trainNumber = "TMS-110",
                        trainName = "Tren de las Misiones (Turístico)",
                        originCode = origin.code,
                        originName = origin.name,
                        destCode = dest.code,
                        destName = dest.name,
                        departureTime = "07:15",
                        arrivalTime = "12:45",
                        duration = "5h 30m",
                        priceEconomica = 80.0,
                        pricePreferente = 150.0,
                        availableSeats = 12,
                        totalSeats = 35,
                        region = "ORIENTAL",
                        status = "A TIEMPO",
                        stopStations = listOf(origin.name, "Cotoca", "Pailas", "Pailón", "San José de Chiquitos", dest.name)
                    )
                )
            } else if (isRegionalValles) {
                results.add(
                    SynthesizedJourney(
                        id = "J-VAL-01",
                        trainNumber = "TME-301",
                        trainName = "Tren Metropolitano (Cercanías)",
                        originCode = origin.code,
                        originName = origin.name,
                        destCode = dest.code,
                        destName = dest.name,
                        departureTime = "09:00",
                        arrivalTime = "09:45",
                        duration = "0h 45m",
                        priceEconomica = 10.0,
                        pricePreferente = 15.0,
                        availableSeats = 35,
                        totalSeats = 60,
                        region = "VALLES",
                        status = "A TIEMPO",
                        stopStations = listOf(origin.name, "Vila Vila", dest.name)
                    )
                )
                results.add(
                    SynthesizedJourney(
                        id = "J-VAL-02",
                        trainNumber = "ACH-305",
                        trainName = "Autocarril Histórico",
                        originCode = origin.code,
                        originName = origin.name,
                        destCode = dest.code,
                        destName = dest.name,
                        departureTime = "14:00",
                        arrivalTime = "17:45",
                        duration = "3h 45m",
                        priceEconomica = 25.0,
                        pricePreferente = 40.0,
                        availableSeats = 4,
                        totalSeats = 15,
                        region = "VALLES",
                        status = "PROGRAMADO",
                        stopStations = listOf(origin.name, "Vila Vila", dest.name)
                    )
                )
            } else {
                // Cross network hypothetical corridor
                results.add(
                    SynthesizedJourney(
                        id = "J-NAC-01",
                        trainNumber = "CBI-901",
                        trainName = "Corredor Bioceánico Integrado (Futuro)",
                        originCode = origin.code,
                        originName = origin.name,
                        destCode = dest.code,
                        destName = dest.name,
                        departureTime = "06:00",
                        arrivalTime = "16:30",
                        duration = "10h 30m",
                        priceEconomica = 120.0,
                        pricePreferente = 220.0,
                        availableSeats = 30,
                        totalSeats = 80,
                        region = "NACIONAL",
                        status = "PROGRAMADO",
                        stopStations = listOf(origin.name, "Viacha", "Oruro", "Cochabamba", "Santa Cruz", dest.name)
                    )
                )
            }

            searchResults = results
            isSearching = false
        }
    }

    // Direct booking activation
    fun startBooking(journey: SynthesizedJourney, selectedClass: String) {
        bookingJourney = journey
        bookingClass = selectedClass
        bookingStep = 2 // Go to passenger info
        currentScreen.value = AppScreen.COMPRAR
    }

    fun submitPassengerDetails(name: String, doc: String) {
        bookingPassengerName = name
        bookingPassengerDoc = doc
        bookingStep = 3 // Go to seat map
    }

    fun selectSeatAndProceed(seat: String) {
        bookingSeatNumber = seat
        bookingStep = 4 // Go to payment
    }

    fun completePaymentWithWallet() {
        val journey = bookingJourney ?: return
        val price = if (bookingClass == "Económica") journey.priceEconomica else journey.pricePreferente
        val totalCost = price * passengerCount

        viewModelScope.launch {
            val success = repository.chargeBalance(
                totalCost,
                "Compra de Billete ${journey.trainNumber}: ${journey.originCode} ➔ ${journey.destCode}"
            )
            
            if (success) {
                createTicketAndComplete(totalCost)
            } else {
                paymentErrorMessage = "Saldo insuficiente en tu billetera digital ferrocarrilera. Por favor recarga saldo o selecciona otra forma de pago."
            }
        }
    }

    fun completePaymentWithMockCard(cardName: String) {
        val journey = bookingJourney ?: return
        val price = if (bookingClass == "Económica") journey.priceEconomica else journey.pricePreferente
        val totalCost = price * passengerCount

        viewModelScope.launch {
            delay(1000) // Synthesizing card network
            repository.addTransaction(
                TransactionRecord(
                    type = "PAGO_BILLETE",
                    amount = -totalCost,
                    description = "Pago Tarjeta de Demostración ($cardName): Billete ${journey.trainNumber}"
                )
            )
            createTicketAndComplete(totalCost)
        }
    }

    private suspend fun createTicketAndComplete(pricePaid: Double) {
        val journey = bookingJourney ?: return
        val randomNum = Random.nextInt(1000, 9999)
        val ticketId = "FC-RES-$randomNum"
        
        // QR structure includes validatable JSON signatures
        val qrContent = "FBO-VERIFY:ID=$ticketId;PASS=${bookingPassengerName};DOC=${bookingPassengerDoc};TRAIN=${journey.trainNumber};SEAT=${bookingSeatNumber};DATE=${searchDate}"

        val newTicket = Ticket(
            id = ticketId,
            passengerName = bookingPassengerName,
            passengerDoc = bookingPassengerDoc,
            originCode = journey.originCode,
            originName = journey.originName,
            destCode = journey.destCode,
            destName = journey.destName,
            departureTime = journey.departureTime,
            arrivalTime = journey.arrivalTime,
            date = searchDate,
            trainNumber = journey.trainNumber,
            className = bookingClass,
            seatNumber = bookingSeatNumber,
            price = pricePaid,
            status = "CONFIRMADO",
            qrCode = qrContent
        )

        repository.insertTicket(newTicket)
        generatedTicket = newTicket
        bookingStep = 5 // Confirmation step
        
        liveSimulationLogs.add(0, "[VENTA] Billete $ticketId emitido con éxito para ${bookingPassengerName} rumbo a ${journey.destCode}.")
    }

    fun startValidationJourney(ticket: Ticket) {
        validatingTicketId = ticket.id
        ticketValidationStep = "SCANNING"
        ticketValidationMessage = "Coloca el código QR frente al escáner de embarque..."
        currentScreen.value = AppScreen.BILLETERA
        
        viewModelScope.launch {
            delay(1500)
            ticketValidationStep = "VERIFYING"
            ticketValidationMessage = "Verificando autenticidad del billete digital..."
            
            delay(1200)
            val updatedTicket = repository.getTicketById(ticket.id)
            if (updatedTicket == null) {
                ticketValidationStep = "INVALID"
                ticketValidationMessage = "Error: Reserva no encontrada en la base de datos local de control."
                liveValidacionesFallo++
            } else if (updatedTicket.status == "CANCELADO") {
                ticketValidationStep = "INVALID"
                ticketValidationMessage = "Acceso denegado: Este billete fue cancelado o reembolsado."
                liveValidacionesFallo++
            } else if (updatedTicket.status == "VALIDADO") {
                ticketValidationStep = "INVALID"
                ticketValidationMessage = "Alerta: Este billete ya ha sido validado para el embarque."
                liveValidacionesFallo++
            } else {
                repository.updateTicketStatus(ticket.id, "VALIDADO")
                ticketValidationStep = "VALID"
                ticketValidationMessage = "¡Billete Válido! Embarque Autorizado. Coche: ${updatedTicket.seatNumber}."
                liveValidacionesExito++
                livePasajerosCount++
                liveSimulationLogs.add(0, "[ABORDO] Pasajero ${updatedTicket.passengerName} abordó tren ${updatedTicket.trainNumber} con billete ${updatedTicket.id}.")
            }
        }
    }

    fun resetValidation() {
        validatingTicketId = null
        ticketValidationStep = "IDLE"
        ticketValidationMessage = ""
    }

    // Refunding / cancellation flow
    fun cancelAndRefundTicket(ticket: Ticket) {
        viewModelScope.launch {
            repository.updateTicketStatus(ticket.id, "CANCELADO")
            repository.refundBalance(ticket.price, "Reembolso automático billete cancelado: ${ticket.id}")
            liveSimulationLogs.add(0, "[REEMBOLSO] Billete ${ticket.id} reembolsado al usuario: +${ticket.price} BOB.")
        }
    }

    // NFC Transit card simulation
    fun performNfcValidation() {
        contactlessValidationState = "SCANNING"
        contactlessValidationMessage = "Acerque su tarjeta ferroviaria virtual al lector sin contacto..."

        viewModelScope.launch {
            delay(1500)
            contactlessValidationState = "VERIFYING"
            contactlessValidationMessage = "Validando saldo de la tarjeta y autorizando acceso..."

            delay(1000)
            val balance = userBalance.value?.balance ?: 0.0
            if (balance >= 10.0) {
                val updatedAmount = balance - 10.0
                // Direct update
                repository.chargeBalance(10.0, "Acceso a Andén: Viaje sin Contacto (Cobro Fijo de Cercanías)")
                contactlessValidationState = "GRANTED"
                contactlessValidationMessage = "¡Acceso Autorizado! Saldo debitado: 10.00 BOB."
                liveValidacionesExito++
                livePasajerosCount++
                liveSimulationLogs.add(0, "[CONTACTLESS] Tarjeta sin contacto autorizada en lector de andén (-10.00 BOB).")
            } else {
                contactlessValidationState = "DENIED"
                contactlessValidationMessage = "Saldo Insuficiente. Saldo mínimo requerido para abordar: 10.00 BOB."
                liveValidacionesFallo++
                liveSimulationLogs.add(0, "[CONTACTLESS] Tarjeta rechazada por saldo insuficiente en andén de cercanías.")
            }
        }
    }

    fun resetNfcValidation() {
        contactlessValidationState = "IDLE"
        contactlessValidationMessage = ""
    }

    fun topUpTransitCard(amount: Double) {
        viewModelScope.launch {
            repository.topUpBalance(amount, "Recarga Tarjeta Ferroviaria Digital")
            liveSimulationLogs.add(0, "[RECARGA] Tarjeta ferroviaria virtual recargada con +${amount} BOB.")
        }
    }

    fun switchNfcCardType(type: String) {
        viewModelScope.launch {
            repository.updateCardDetails("ACTIVO", type)
            nfcCardTypeSelected = type
        }
    }

    // Simulator management
    fun triggerSimulationScenario(scenario: String) {
        simulationActiveScenario = scenario
        when (scenario) {
            "Día Normal" -> {
                livePuntualidad = 96
                liveIncidentesActivos = 0
                liveOcupacionMedia = 72
                liveSimulationLogs.add(0, "[SIMULADOR] Escenario establecido en 'Día Normal'. Operación óptima de red.")
            }
            "Hora Punta" -> {
                livePuntualidad = 91
                liveIncidentesActivos = 0
                liveOcupacionMedia = 94
                liveSimulationLogs.add(0, "[SIMULADOR] Escenario de 'Hora Punta'. Alta afluencia de pasajeros en Red Oriental.")
            }
            "Demora Altiplano" -> {
                livePuntualidad = 84
                liveIncidentesActivos = 1
                liveOcupacionMedia = 76
                liveSimulationLogs.add(0, "[SIMULADOR] Escenario 'Demora de 15 minutos en Altiplano'. Obra de mantenimiento activa.")
            }
            "Bloqueo Oriental" -> {
                livePuntualidad = 71
                liveIncidentesActivos = 2
                liveOcupacionMedia = 64
                liveSimulationLogs.add(0, "[SIMULADOR] Alerta de seguridad: 'Interrupción de tramo San José - Roboré'.")
            }
            "Servicio Turístico" -> {
                livePuntualidad = 98
                liveIncidentesActivos = 0
                liveOcupacionMedia = 88
                liveSimulationLogs.add(0, "[SIMULADOR] 'Servicio Turístico Especial' activado. Alta ocupación de trenes históricos.")
            }
        }

        viewModelScope.launch {
            // Log in DB history too
            repository.insertSimulationMetric(
                SimulationMetric(
                    scenarioName = scenario,
                    puntualidad = livePuntualidad,
                    pasajerosTransportados = livePasajerosCount,
                    ocupacionPromedio = liveOcupacionMedia,
                    tiempoEmbarque = if (scenario == "Hora Punta") 180 else 90,
                    validacionesCorrectas = liveValidacionesExito,
                    billetesRechazados = liveValidacionesFallo,
                    incidenciasReportadas = liveIncidentesActivos
                )
            )
        }
    }

    // Background loop to generate operational train tracking and status messages
    private fun startSimulationLoop() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            val operations = listOf(
                "Tren Expreso del Sur EX-SUR-501 saliendo a tiempo de Oruro hacia Uyuni.",
                "Autocarril Histórico ACH-305 cruzando Vila Vila con ocupación turística del 85%.",
                "Tren de carga mineral cargado cruzando andén de Viacha rumbo a frontera.",
                "Control de andenes: Santa Cruz Bimodal reporta validación regular de billetes QR.",
                "Lector NFC registra abordaje sin contacto en estación El Alto.",
                "Tren Expreso Oriental EXO-102 ingresando a San José de Chiquitos con 12 minutos de retraso.",
                "Puntualidad de la Red Andina del Altiplano calificada en un sobresaliente 95% hoy.",
                "Tren de las Misiones TMS-110 cruzando puente de Pailas con espectacular vista del Río Grande."
            )

            // Initial logs
            liveSimulationLogs.add("[SISTEMA] Iniciando centro de control de BOLIVIA FERROCARRILES.OS...")
            liveSimulationLogs.add("[SISTEMA] Sincronizando capas Red Andina, Red Oriental y Ramales Regionales...")
            liveSimulationLogs.add("[SISTEMA] Base de datos local inicializada con procedencia sintética de demostración.")

            while (true) {
                delay(6000)
                val log = operations[Random.nextInt(operations.size)]
                val timeStamp = "[INFO]"
                liveSimulationLogs.add(0, "$timeStamp $log")
                if (liveSimulationLogs.size > 50) {
                    liveSimulationLogs.removeLast()
                }

                // Randomly vary passenger count and metrics slightly
                if (Random.nextBoolean()) {
                    livePasajerosCount += Random.nextInt(1, 5)
                    liveValidacionesExito += Random.nextInt(1, 3)
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        simulationJob?.cancel()
    }
}

// Custom structure for managing a live list state
fun <T> mutableStateListOf() = androidx.compose.runtime.mutableStateListOf<T>()
