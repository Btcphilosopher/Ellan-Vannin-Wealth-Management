package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserBalance::class,
        TransactionRecord::class,
        Station::class,
        Ticket::class,
        ServiceAlert::class,
        SimulationMetric::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RailwayDatabase : RoomDatabase() {
    abstract fun railwayDao(): RailwayDao

    companion object {
        @Volatile
        private var INSTANCE: RailwayDatabase? = null

        fun setTestDatabase(db: RailwayDatabase) {
            INSTANCE = db
        }

        fun getDatabase(context: Context): RailwayDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RailwayDatabase::class.java,
                    "railway_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
