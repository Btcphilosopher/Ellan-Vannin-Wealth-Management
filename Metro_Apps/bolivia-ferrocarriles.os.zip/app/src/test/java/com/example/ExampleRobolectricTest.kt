package com.example

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import com.example.ui.AppScreen
import com.example.ui.RailwayViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private val testDispatcher = StandardTestDispatcher()
    private lateinit var context: Context
    private lateinit var application: Application
    private lateinit var database: RailwayDatabase
    private lateinit var dao: RailwayDao
    private lateinit var repository: RailwayRepository
    private lateinit var viewModel: RailwayViewModel

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        context = ApplicationProvider.getApplicationContext()
        application = context as Application
        
        // Setup isolated in-memory database
        database = Room.inMemoryDatabaseBuilder(context, RailwayDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        
        RailwayDatabase.setTestDatabase(database)
        dao = database.railwayDao()
        repository = RailwayRepository(dao)
        
        viewModel = RailwayViewModel(application)
    }

    @After
    fun tearDown() {
        database.close()
        Dispatchers.resetMain()
    }

    @Test
    fun testAppNameString() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Ferrocarriles OS", appName)
    }

    @Test
    fun testDatabaseSeeding() = runTest(testDispatcher) {
        // Trigger seeding in test context
        repository.seedDatabase()
        
        // Let asynchronous Room flow emissions and writes complete
        testScheduler.advanceUntilIdle()

        // Wait for emissions using Flow.first with condition
        val stations = repository.stationsFlow.first { it.isNotEmpty() }
        assertTrue("Se debieron sembrar las estaciones bolivianas", stations.isNotEmpty())
        
        val lpb = stations.find { it.code == "LPB" }
        assertNotNull("Estación La Paz debe existir", lpb)
        assertEquals("ANDINA", lpb?.region)

        val scz = stations.find { it.code == "SCZ" }
        assertNotNull("Estación Santa Cruz debe existir", scz)
        assertEquals("ORIENTAL", scz?.region)

        val balance = repository.userBalanceFlow.first { it != null }
        assertNotNull("Debe existir un saldo de demostración inicial", balance)
        assertTrue("El saldo inicial debe ser mayor o igual a 100 BOB", (balance?.balance ?: 0.0) >= 100.0)
    }

    @Test
    fun testTravelSearchAndPlanning() = runTest(testDispatcher) {
        repository.seedDatabase()
        testScheduler.advanceUntilIdle()

        val stations = repository.stationsFlow.first { it.isNotEmpty() }
        val lpb = stations.find { it.code == "LPB" }!!
        val uyu = stations.find { it.code == "UYU" }!!

        viewModel.searchOrigin = lpb
        viewModel.searchDestination = uyu
        viewModel.performSearch()
        
        // Advance past delay(800) inside performSearch()
        testScheduler.advanceUntilIdle()

        val results = viewModel.searchResults
        assertTrue("Búsqueda entre La Paz y Uyuni debe dar opciones andinas", results.isNotEmpty())
        assertEquals("ANDINA", results.first().region)
        assertEquals("Expreso del Sur", results.first().trainName)
    }

    @Test
    fun testBookingAndPaymentWithWallet() = runTest(testDispatcher) {
        repository.seedDatabase()
        testScheduler.advanceUntilIdle()

        val stations = repository.stationsFlow.first { it.isNotEmpty() }
        val lpb = stations.find { it.code == "LPB" }!!
        val uyu = stations.find { it.code == "UYU" }!!

        viewModel.searchOrigin = lpb
        viewModel.searchDestination = uyu
        viewModel.performSearch()
        
        // Advance past performSearch delay(800)
        testScheduler.advanceUntilIdle()

        val selectedJourney = viewModel.searchResults.first()
        viewModel.startBooking(selectedJourney, "Económica")

        // Step 2: Passenger details
        viewModel.submitPassengerDetails("Pasajero de Prueba", "1234567 LP")
        assertEquals(3, viewModel.bookingStep)

        // Step 3: Seat selection
        viewModel.selectSeatAndProceed("Fila 3 - A2")
        assertEquals(4, viewModel.bookingStep)

        // Step 4: Complete payment
        val initialBalance = repository.userBalanceFlow.first { it != null }?.balance ?: 0.0
        viewModel.completePaymentWithWallet()

        // Wait for coroutine db operations to complete
        testScheduler.advanceUntilIdle()

        // Confirm ticket generation
        val tickets = repository.ticketsFlow.first { it.isNotEmpty() }
        assertTrue("Un billete debió emitirse", tickets.isNotEmpty())
        val generated = tickets.first()
        assertEquals("CONFIRMADO", generated.status)
        assertEquals("Pasajero de Prueba", generated.passengerName)
        assertEquals("Fila 3 - A2", generated.seatNumber)

        // Confirm wallet charge
        val finalBalance = repository.userBalanceFlow.first { it != null }?.balance ?: 0.0
        assertEquals(initialBalance - selectedJourney.priceEconomica, finalBalance, 0.01)
    }

    @Test
    fun testNfcTransitCardValidation() = runTest(testDispatcher) {
        repository.seedDatabase()
        testScheduler.advanceUntilIdle()
        
        // Cargar suficiente saldo
        repository.topUpBalance(20.0, "Carga de test")
        
        // Esperar a que se procese la recarga
        testScheduler.advanceUntilIdle()
        
        val initialBalance = repository.userBalanceFlow.first { it != null }?.balance ?: 0.0

        viewModel.performNfcValidation()
        
        // Avanzar el reloj para superar los delays de SCANNING (1500) y VERIFYING (1000)
        testScheduler.advanceTimeBy(3000)
        testScheduler.advanceUntilIdle()

        assertEquals("GRANTED", viewModel.contactlessValidationState)
        val finalBalance = repository.userBalanceFlow.first { it != null }?.balance ?: 0.0
        assertEquals(initialBalance - 10.0, finalBalance, 0.01)
    }

    @Test
    fun testNfcTransitCardValidationInsufficientBalance() = runTest(testDispatcher) {
        repository.seedDatabase()
        testScheduler.advanceUntilIdle()
        
        // Forzar balance bajo
        dao.insertUserBalance(UserBalance(id = 1, balance = 5.0))
        testScheduler.advanceUntilIdle()

        viewModel.performNfcValidation()
        
        // Avanzar reloj
        testScheduler.advanceTimeBy(3000)
        testScheduler.advanceUntilIdle()

        assertEquals("DENIED", viewModel.contactlessValidationState)
        assertTrue(viewModel.contactlessValidationMessage.contains("Saldo Insuficiente"))
    }

    @Test
    fun testSimulationScenarios() = runTest(testDispatcher) {
        viewModel.triggerSimulationScenario("Hora Punta")
        assertEquals("Hora Punta", viewModel.simulationActiveScenario)
        assertEquals(91, viewModel.livePuntualidad)
        assertEquals(94, viewModel.liveOcupacionMedia)

        viewModel.triggerSimulationScenario("Bloqueo Oriental")
        assertEquals("Bloqueo Oriental", viewModel.simulationActiveScenario)
        assertEquals(71, viewModel.livePuntualidad)
        assertEquals(2, viewModel.liveIncidentesActivos)
    }
}
