package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.model.*
import com.example.core.routing.MetroRoutingEngine
import com.example.core.simulation.MetroSimulationManager
import com.example.core.simulation.SimulatedTrain
import com.example.data.repository.MetroRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MetroViewModel(private val repository: MetroRepository) : ViewModel() {

    // --- Core Master Data ---
    val lines = repository.getLines()
    val stations = repository.getStations()
    val connections = repository.getConnections()
    val interchanges = repository.getInterchanges()
    val fareProducts = repository.getFareProducts()
    val destinations = repository.getDestinations()

    // --- Search State ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResults: StateFlow<List<MetroStation>> = _searchQuery
        .map { query ->
            if (query.isBlank()) emptyList()
            else {
                val norm = query.trim().lowercase()
                stations.filter { station ->
                    station.name.lowercase().contains(norm) ||
                    station.nameLatin.lowercase().contains(norm) ||
                    station.district.lowercase().contains(norm) ||
                    station.aliases.any { it.lowercase().contains(norm) } ||
                    station.lineIds.any { it.lowercase() == norm }
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Route Planner State ---
    private val _fromStation = MutableStateFlow<MetroStation?>(null)
    val fromStation: StateFlow<MetroStation?> = _fromStation.asStateFlow()

    private val _toStation = MutableStateFlow<MetroStation?>(null)
    val toStation: StateFlow<MetroStation?> = _toStation.asStateFlow()

    private val _routePreference = MutableStateFlow(MetroRoutingEngine.RoutePreference.SHORTEST_TIME)
    val routePreference: StateFlow<MetroRoutingEngine.RoutePreference> = _routePreference.asStateFlow()

    private val _calculatedRoute = MutableStateFlow<Journey?>(null)
    val calculatedRoute: StateFlow<Journey?> = _calculatedRoute.asStateFlow()

    // --- Live Journey Mode State (Моето Пътуване) ---
    private val _activeJourney = MutableStateFlow<Journey?>(null)
    val activeJourney: StateFlow<Journey?> = _activeJourney.asStateFlow()

    private val _currentJourneyStepIdx = MutableStateFlow(0)
    val currentJourneyStepIdx: StateFlow<Int> = _currentJourneyStepIdx.asStateFlow()

    private val _isJourneyActive = MutableStateFlow(false)
    val isJourneyActive: StateFlow<Boolean> = _isJourneyActive.asStateFlow()

    private var journeySimulationJob: Job? = null

    // --- Selected Station Screen State ---
    private val _selectedStation = MutableStateFlow<MetroStation?>(null)
    val selectedStation: StateFlow<MetroStation?> = _selectedStation.asStateFlow()

    // --- Database Flows (Reactive DB updates from Room) ---
    val savedTickets: StateFlow<List<Ticket>> = repository.savedTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteStationIds: StateFlow<List<String>> = repository.favoriteStationIds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteRoutes: StateFlow<List<com.example.core.persistence.DbFavoriteRoute>> = repository.favoriteRoutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Simulation Manager State Links ---
    val simulationState: StateFlow<SimulationState> = MetroSimulationManager.simState
    val activeTrains: StateFlow<List<SimulatedTrain>> = MetroSimulationManager.activeTrains
    val lineStatuses: StateFlow<Map<String, String>> = MetroSimulationManager.lineStatuses

    // --- Init ---
    init {
        // Automatically calculate routes when endpoints or preference changes
        viewModelScope.launch {
            combine(fromStation, toStation, routePreference, simulationState) { from, to, pref, sim ->
                if (from != null && to != null) {
                    MetroRoutingEngine.calculateRoute(
                        origin = from.id,
                        destination = to.id,
                        preference = pref,
                        closedStationId = sim.closedStationId
                    )
                } else null
            }.collect { journey ->
                _calculatedRoute.value = journey
            }
        }
    }

    // --- Search Actions ---
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // --- Route Actions ---
    fun setFromStation(station: MetroStation?) {
        _fromStation.value = station
    }

    fun setToStation(station: MetroStation?) {
        _toStation.value = station
    }

    fun setRoutePreference(pref: MetroRoutingEngine.RoutePreference) {
        _routePreference.value = pref
    }

    fun swapStations() {
        val temp = _fromStation.value
        _fromStation.value = _toStation.value
        _toStation.value = temp
    }

    fun selectStation(station: MetroStation?) {
        _selectedStation.value = station
    }

    // --- Persistent User Actions (Favourites & Tickets) ---
    fun toggleFavoriteStation(stationId: String, customLabel: String = "Любими") {
        viewModelScope.launch {
            repository.toggleFavoriteStation(stationId, customLabel)
        }
    }

    fun addFavoriteRoute(fromId: String, toId: String) {
        viewModelScope.launch {
            repository.addFavoriteRoute(fromId, toId)
        }
    }

    fun deleteFavoriteRoute(id: String) {
        viewModelScope.launch {
            repository.deleteFavoriteRoute(id)
        }
    }

    fun buyTicket(product: FareProduct) {
        viewModelScope.launch {
            repository.buyTicket(product)
        }
    }

    fun deleteTicket(ticket: Ticket) {
        viewModelScope.launch {
            repository.deleteTicket(ticket)
        }
    }

    fun clearAllTickets() {
        viewModelScope.launch {
            repository.clearTickets()
        }
    }

    // --- Live Journey Mode Simulation Actions ---
    fun startLiveJourney(journey: Journey) {
        journeySimulationJob?.cancel()
        _activeJourney.value = journey
        _currentJourneyStepIdx.value = 0
        _isJourneyActive.value = true

        journeySimulationJob = viewModelScope.launch {
            // Simulate advancing steps every 8 seconds for visual feel
            val totalSteps = journey.steps.size
            for (stepIdx in 0 until totalSteps) {
                _currentJourneyStepIdx.value = stepIdx
                delay(8000)
            }
            _isJourneyActive.value = false
            _activeJourney.value = null
        }
    }

    fun stopLiveJourney() {
        journeySimulationJob?.cancel()
        _isJourneyActive.value = false
        _activeJourney.value = null
        _currentJourneyStepIdx.value = 0
    }

    // --- Developer Mode Actions (Simulation Controller) ---
    fun triggerSimulatedDelay(minutes: Int) {
        MetroSimulationManager.triggerDelay(minutes)
    }

    fun triggerSimulatedClosure(stationId: String) {
        MetroSimulationManager.closeStation(stationId)
    }

    fun setTrainsMoreFrequent() {
        MetroSimulationManager.decreaseHeadways()
    }

    fun setTrainsLessFrequent() {
        MetroSimulationManager.increaseHeadways()
    }

    fun resetSimulationState() {
        MetroSimulationManager.resetSimulation()
    }
}

class MetroViewModelFactory(private val repository: MetroRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MetroViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MetroViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
