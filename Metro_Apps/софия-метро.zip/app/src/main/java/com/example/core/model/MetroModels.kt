package com.example.core.model

import androidx.compose.ui.graphics.Color

enum class StationStatus {
    OPERATING,
    UNDER_CONSTRUCTION,
    PLANNED,
    TEMPORARILY_CLOSED
}

enum class AlertSeverity {
    INFO,
    WARNING,
    CRITICAL
}

enum class TicketType {
    SINGLE_TRIP,
    TIME_30_PLUS,
    TIME_60_PLUS,
    DAILY_PASS,
    MONTHLY_CARD
}

data class MetroLine(
    val id: String, // M1, M2, M3, M4
    val name: String, // e.g., "Линия М1"
    val colorHex: String, // Red, Blue, Green, Yellow hex
    val status: StationStatus = StationStatus.OPERATING
) {
    val composeColor: Color
        get() = Color(android.graphics.Color.parseColor(colorHex))
}

data class MetroStation(
    val id: String,
    val name: String,
    val nameLatin: String,
    val lineIds: List<String>,
    val latitude: Double,
    val longitude: Double,
    val schematicX: Float, // Normalized Coordinate (0 to 1000)
    val schematicY: Float, // Normalized Coordinate (0 to 1000)
    val district: String,
    val entrances: List<String> = emptyList(),
    val exits: List<String> = emptyList(),
    val facilities: List<String> = emptyList(), // elevator, escalator, ticket_machine, info_desk
    val accessibility: Boolean = true,
    val nearbyPlaces: List<String> = emptyList(),
    val status: StationStatus = StationStatus.OPERATING,
    val aliases: List<String> = emptyList()
)

data class MetroConnection(
    val id: String,
    val fromStationId: String,
    val toStationId: String,
    val lineId: String,
    val travelTimeSeconds: Int
)

data class Interchange(
    val stationIds: List<String>, // e.g., ["serdika", "serdika2"]
    val walkingTimeSeconds: Int,
    val accessibility: Boolean = true,
    val directions: String
)

data class Destination(
    val id: String,
    val name: String,
    val category: String, // Център, Забележителности, Транспорт, Бизнес, Образование, Паркове, Болници
    val nearestStationId: String,
    val walkingTimeMinutes: Int,
    val description: String
)

data class ServiceAlert(
    val id: String,
    val lineId: String?,
    val stationId: String?,
    val title: String,
    val message: String,
    val severity: AlertSeverity,
    val timestamp: Long,
    val isDemo: Boolean = true
)

data class Departure(
    val destination: String,
    val minutesLeft: Int,
    val lineId: String
)

data class FareProduct(
    val id: String,
    val name: String,
    val price: Double,
    val currency: String = "лв.",
    val validity: String,
    val transferRules: String,
    val purchaseMethod: String,
    val lastUpdated: String = "2026-09-20"
)

data class Ticket(
    val id: String,
    val productName: String,
    val price: Double,
    val purchaseTimestamp: Long,
    val qrCodeData: String,
    val isValid: Boolean = true,
    val isDemo: Boolean = true
)

data class Journey(
    val originStationId: String,
    val destinationStationId: String,
    val totalTimeMinutes: Int,
    val waitingTimeMinutes: Int,
    val walkingTimeMinutes: Int,
    val transfersCount: Int,
    val steps: List<JourneyStep>
)

data class JourneyStep(
    val type: StepType, // BOARD, RIDE, INTERCHANGE, EXIT
    val stationId: String,
    val lineId: String? = null,
    val detail: String, // Bulgarian description
    val durationMinutes: Int
)

enum class StepType {
    BOARD,
    RIDE,
    INTERCHANGE,
    EXIT
}

data class SimulationState(
    val currentTime: String = "08:15",
    val status: String = "Нормално",
    val delayMinutes: Int = 0,
    val isDelayed: Boolean = false,
    val closedStationId: String? = null,
    val headwaysMinutes: Int = 5,
    val activeSimulation: Boolean = false
)
