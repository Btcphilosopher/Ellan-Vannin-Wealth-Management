package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import com.example.core.design.*
import com.example.core.model.FareProduct
import com.example.core.model.Ticket
import com.example.ui.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketsScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val savedTickets by viewModel.savedTickets.collectAsState()
    val fareProducts = viewModel.fareProducts

    var activeTabIdx by remember { mutableStateOf(0) } // 0: Активни билети, 1: Купи билет
    var selectedViewTicket by remember { mutableStateOf<Ticket?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF9F6F0)) // WarmWhite
    ) {
        // Upper Title block
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Graphite)
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            Text(
                text = "МОИТЕ БИЛЕТИ",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = WarmWhite,
                letterSpacing = 1.5.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // Sub Navigation Tabs (Active Tickets / Purchase ticket)
        TabRow(
            selectedTabIndex = activeTabIdx,
            containerColor = Color.White,
            contentColor = Graphite,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[activeTabIdx]),
                    color = AccentGold
                )
            }
        ) {
            Tab(
                selected = activeTabIdx == 0,
                onClick = { activeTabIdx = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.ConfirmationNumber, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("АКТИВНИ (${savedTickets.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    }
                }
            )
            Tab(
                selected = activeTabIdx == 1,
                onClick = { activeTabIdx = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("КУПИ БИЛЕТ", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    }
                }
            )
        }

        // List Scroll Content
        Box(modifier = Modifier.weight(1f)) {
            if (activeTabIdx == 0) {
                // Active purchased tickets
                if (savedTickets.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            tint = ConcreteGrey,
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Нямате закупени дигитални билети в момента.",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = Graphite.copy(alpha = 0.5f),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = { activeTabIdx = 1 },
                            colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("КУПИ БИЛЕТ СЕГА", color = WarmWhite)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Quick Clear All option for demo purposes
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = { viewModel.clearAllTickets() },
                                    colors = ButtonColors(containerColor = Color.Transparent, contentColor = MutedRed, disabledContainerColor = Color.Transparent, disabledContentColor = Color.Gray)
                                ) {
                                    Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Изчисти всички", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        items(savedTickets) { ticket ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedViewTicket = ticket },
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, ConcreteGrey),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .background(AccentGold.copy(alpha = 0.15f), RoundedCornerShape(20.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = AccentGold)
                                        }
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Column {
                                            Text(
                                                text = ticket.productName,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = CharcoalDark
                                            )
                                            val df = java.text.SimpleDateFormat("dd.09.2026, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ticket.purchaseTimestamp))
                                            Text(
                                                text = "Закупен на: $df",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Graphite.copy(alpha = 0.5f)
                                            )
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = String.format("%.2f лв.", ticket.price),
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Black,
                                            color = MutedRed,
                                            modifier = Modifier.padding(end = 8.dp)
                                        )
                                        Icon(Icons.Default.QrCode, contentDescription = "Покажи QR код", tint = Graphite.copy(alpha = 0.6f))
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // Buy Tickets catalog view
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CharcoalDark),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CreditCard, contentDescription = null, tint = AccentGold, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "БЕЗКОНТАКТНО ПЛАЩАНЕ",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Black,
                                        color = AccentGold,
                                        letterSpacing = 1.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Всички турникети на Софийското метро приемат директно плащане с безконтактна банкова карта (Visa, Mastercard) или мобилно устройство.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ConcreteGrey
                                )
                            }
                        }
                    }

                    items(fareProducts) { product ->
                        TicketCard(
                            product = product,
                            onBuy = {
                                viewModel.buyTicket(product)
                                activeTabIdx = 0 // Switch back to purchased tab
                            }
                        )
                    }
                }
            }
        }
    }

    // Modal Dialog to display Full QR Code Ticket details
    if (selectedViewTicket != null) {
        Dialog(onDismissRequest = { selectedViewTicket = null }) {
            selectedViewTicket?.let { ticket ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    DigitalTicket(ticket = ticket)
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { selectedViewTicket = null },
                        colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("ЗАТВОРИ", color = WarmWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
