package com.example.data.repository

import com.example.core.model.*
import com.example.core.persistence.*
import com.example.data.seed.MetroSeedData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class MetroRepository(private val metroDao: MetroDao) {

    // --- Static Factual Data ---
    fun getLines(): List<MetroLine> = MetroSeedData.lines
    fun getStations(): List<MetroStation> = MetroSeedData.stations
    fun getConnections(): List<MetroConnection> = MetroSeedData.connections
    fun getInterchanges(): List<Interchange> = MetroSeedData.interchanges
    fun getFareProducts(): List<FareProduct> = MetroSeedData.fareProducts
    fun getDestinations(): List<Destination> = MetroSeedData.destinations

    // --- Dynamic User Data: Tickets (Room Persistence) ---
    val savedTickets: Flow<List<Ticket>> = metroDao.getAllTickets().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun buyTicket(product: FareProduct) {
        val uniqueId = "TKT-" + System.currentTimeMillis().toString().takeLast(8)
        val newTicket = Ticket(
            id = uniqueId,
            productName = product.name,
            price = product.price,
            purchaseTimestamp = System.currentTimeMillis(),
            qrCodeData = "SOFIA-METRO-DEMO-$uniqueId-VALID-2026",
            isValid = true,
            isDemo = true
        )
        metroDao.insertTicket(newTicket.toDbEntity())
    }

    suspend fun deleteTicket(ticket: Ticket) {
        metroDao.deleteTicket(ticket.toDbEntity())
    }

    suspend fun clearTickets() {
        metroDao.clearTickets()
    }

    // --- Dynamic User Data: Favorite Stations (Room Persistence) ---
    val favoriteStations: Flow<List<DbFavoriteStation>> = metroDao.getFavoriteStations()

    val favoriteStationIds: Flow<List<String>> = metroDao.getFavoriteStations().map { list ->
        list.map { it.stationId }
    }

    suspend fun toggleFavoriteStation(stationId: String, customLabel: String = "Любими") {
        val currentFavs = favoriteStations.first()
        val exists = currentFavs.any { it.stationId == stationId }
        if (exists) {
            metroDao.deleteFavoriteStationById(stationId)
        } else {
            metroDao.insertFavoriteStation(
                DbFavoriteStation(stationId = stationId, label = customLabel)
            )
        }
    }

    suspend fun removeFavoriteStation(stationId: String) {
        metroDao.deleteFavoriteStationById(stationId)
    }

    // --- Dynamic User Data: Favorite Routes (Room Persistence) ---
    val favoriteRoutes: Flow<List<DbFavoriteRoute>> = metroDao.getFavoriteRoutes()

    suspend fun addFavoriteRoute(fromStationId: String, toStationId: String) {
        val fromName = MetroSeedData.stations.find { it.id == fromStationId }?.name ?: fromStationId
        val toName = MetroSeedData.stations.find { it.id == toStationId }?.name ?: toStationId
        val routeId = "${fromStationId}_to_${toStationId}"

        metroDao.insertFavoriteRoute(
            DbFavoriteRoute(
                id = routeId,
                fromStationId = fromStationId,
                toStationId = toStationId,
                fromStationName = fromName,
                toStationName = toName
            )
        )
    }

    suspend fun deleteFavoriteRoute(id: String) {
        metroDao.deleteFavoriteRouteById(id)
    }

    // --- Mappings Helpers ---
    private fun DbTicket.toDomain(): Ticket {
        return Ticket(
            id = this.id,
            productName = this.productName,
            price = this.price,
            purchaseTimestamp = this.purchaseTimestamp,
            qrCodeData = this.qrCodeData,
            isValid = this.isValid,
            isDemo = this.isDemo
        )
    }

    private fun Ticket.toDbEntity(): DbTicket {
        return DbTicket(
            id = this.id,
            productName = this.productName,
            price = this.price,
            purchaseTimestamp = this.purchaseTimestamp,
            qrCodeData = this.qrCodeData,
            isValid = this.isValid,
            isDemo = this.isDemo
        )
    }
}
