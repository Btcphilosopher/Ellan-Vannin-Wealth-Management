package com.example.core.persistence

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Delete
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {
    // Tickets
    @Query("SELECT * FROM saved_tickets ORDER BY purchaseTimestamp DESC")
    fun getAllTickets(): Flow<List<DbTicket>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: DbTicket)

    @Delete
    suspend fun deleteTicket(ticket: DbTicket)

    @Query("DELETE FROM saved_tickets")
    suspend fun clearTickets()

    // Favorite Stations
    @Query("SELECT * FROM favorite_stations ORDER BY timestamp DESC")
    fun getFavoriteStations(): Flow<List<DbFavoriteStation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavoriteStation(station: DbFavoriteStation)

    @Query("DELETE FROM favorite_stations WHERE stationId = :stationId")
    suspend fun deleteFavoriteStationById(stationId: String)

    @Query("DELETE FROM favorite_stations")
    suspend fun clearFavoriteStations()

    // Favorite Routes
    @Query("SELECT * FROM favorite_routes ORDER BY timestamp DESC")
    fun getFavoriteRoutes(): Flow<List<DbFavoriteRoute>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavoriteRoute(route: DbFavoriteRoute)

    @Query("DELETE FROM favorite_routes WHERE id = :id")
    suspend fun deleteFavoriteRouteById(id: String)
}
