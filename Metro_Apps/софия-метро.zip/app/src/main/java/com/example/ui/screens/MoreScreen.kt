package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.core.design.*
import com.example.core.model.MetroStation
import com.example.ui.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val simState by viewModel.simulationState.collectAsState()
    val stations = viewModel.stations

    var showCloseStationSelector by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF9F6F0)), // WarmWhite
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Upper Title block
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Graphite)
                    .statusBarsPadding()
                    .padding(16.dp)
            ) {
                Text(
                    text = "ИНФОРМАЦИЯ И СИМУЛАТОР",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = WarmWhite,
                    letterSpacing = 1.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        // Conceptual Disclaimer
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = WarmWhite),
                border = BorderStroke(1.5.dp, AccentGold),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.WarningAmber, contentDescription = "Внимание", tint = AccentGold, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "КОНЦЕПТУАЛЕН ДЕМОНСТРАЦИОНЕН ПРОЕКТ",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Black,
                            color = AccentGold,
                            letterSpacing = 0.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Това приложение е независима разработка с образователна и концептуална цел. То НЕ е официално приложение на „Метрополитен“ ЕАД, Център за градска мобилност (ЦГМ) или Столична община. Всички разписания, разстояния и симулации на движение са условни.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CharcoalDark,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Developer Mode & Simulation Controller
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "ДЕВЕЛОПЪР СИМУЛАТОР (РЕАКТИВЕН)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black,
                    color = Graphite.copy(alpha = 0.6f),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, ConcreteGrey),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Simulation Switch
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayCircleOutline, contentDescription = null, tint = Graphite)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Активна симулация", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("Движение на влакове в реално време", style = MaterialTheme.typography.bodySmall, color = Graphite.copy(alpha = 0.5f))
                                }
                            }
                            Switch(
                                checked = simState.activeSimulation,
                                onCheckedChange = { checked ->
                                    // Simulation manager toggle handles it
                                    // State flows reactively
                                }
                            )
                        }

                        HorizontalDivider(color = ConcreteGrey, modifier = Modifier.padding(vertical = 12.dp))

                        // Delay Trigger Overrides
                        Text(
                            text = "ВЪВЕДИ ИЗКУСТВЕНО ЗАКЪСНЕНИЕ:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = AccentGold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                Pair(0, "БЕЗ"),
                                Pair(2, "+2 мин"),
                                Pair(5, "+5 мин"),
                                Pair(10, "+10 мин")
                            ).forEach { (min, label) ->
                                val isSelected = simState.delayMinutes == min
                                Button(
                                    onClick = { viewModel.triggerSimulatedDelay(min) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) MutedRed else WarmWhite,
                                        contentColor = if (isSelected) WarmWhite else CharcoalDark
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (isSelected) MutedRed else ConcreteGrey),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                                ) {
                                    Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        HorizontalDivider(color = ConcreteGrey, modifier = Modifier.padding(vertical = 12.dp))

                        // Station Closure Override
                        Text(
                            text = "ЗАТВОРИ СТАНЦИЯ (СМУЩЕНИЕ В МАРШРУТА):",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = AccentGold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (simState.closedStationId != null) {
                                        val st = stations.find { it.id == simState.closedStationId }
                                        "Затворена: ${st?.name}"
                                    } else "Всички станции работят",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (simState.closedStationId != null) MutedRed else LineM3Color
                                )
                                Text(
                                    text = "Dijkstra рутерът ще заобиколи тази станция",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Graphite.copy(alpha = 0.5f)
                                )
                            }
                            Button(
                                onClick = { showCloseStationSelector = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("ИЗБЕРИ", color = WarmWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        HorizontalDivider(color = ConcreteGrey, modifier = Modifier.padding(vertical = 12.dp))

                        // Frequency Adjust
                        Text(
                            text = "ЧЕСТОТА НА ДВИЖЕНИЕ:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = AccentGold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { viewModel.setTrainsMoreFrequent() },
                                colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ПИК (3 мин)", fontSize = 11.sp)
                            }
                            Button(
                                onClick = { viewModel.setTrainsLessFrequent() },
                                colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.HourglassEmpty, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("РАЗРЕДЕНО (12 мин)", fontSize = 11.sp)
                            }
                        }

                        HorizontalDivider(color = ConcreteGrey, modifier = Modifier.padding(vertical = 12.dp))

                        // Reset Button
                        Button(
                            onClick = { viewModel.resetSimulationState() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = WarmWhite)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("ИЗЧИСТИ ВСИЧКИ СИМУЛАЦИИ", color = WarmWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Station selector popup dialog for Closing a station
    if (showCloseStationSelector) {
        Dialog(onDismissRequest = { showCloseStationSelector = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.7f),
                colors = CardDefaults.cardColors(containerColor = WarmWhite),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Изберете станция за затваряне",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = CharcoalDark
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(stations) { station ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.triggerSimulatedClosure(station.id)
                                        showCloseStationSelector = false
                                    },
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, ConcreteGrey),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(station.name, fontWeight = FontWeight.Bold, color = CharcoalDark)
                                        Text("кв. ${station.district}", style = MaterialTheme.typography.bodySmall, color = Graphite.copy(alpha = 0.5f))
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        station.lineIds.forEach { lineId ->
                                            MetroLineBadge(lineId = lineId)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
