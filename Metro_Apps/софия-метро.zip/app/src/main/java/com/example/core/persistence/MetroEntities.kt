package com.example.core.persistence

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_tickets")
data class DbTicket(
    @PrimaryKey val id: String,
    val productName: String,
    val price: Double,
    val purchaseTimestamp: Long,
    val qrCodeData: String,
    val isValid: Boolean = true,
    val isDemo: Boolean = true
)

@Entity(tableName = "favorite_stations")
data class DbFavoriteStation(
    @PrimaryKey val stationId: String,
    val label: String, // e.g., "Дом", "Работа", "Любими"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorite_routes")
data class DbFavoriteRoute(
    @PrimaryKey val id: String, // "fromStationId -> toStationId"
    val fromStationId: String,
    val toStationId: String,
    val fromStationName: String,
    val toStationName: String,
    val timestamp: Long = System.currentTimeMillis()
)
