package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.design.*
import com.example.core.model.*
import com.example.core.routing.MetroRoutingEngine
import com.example.ui.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutesScreen(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val fromStation by viewModel.fromStation.collectAsState()
    val toStation by viewModel.toStation.collectAsState()
    val preference by viewModel.routePreference.collectAsState()
    val calculatedRoute by viewModel.calculatedRoute.collectAsState()

    val isJourneyActive by viewModel.isJourneyActive.collectAsState()
    val activeJourney by viewModel.activeJourney.collectAsState()
    val activeJourneyStepIdx by viewModel.currentJourneyStepIdx.collectAsState()

    var showFromSelector by remember { mutableStateOf(false) }
    var showToSelector by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF9F6F0)) // WarmWhite
    ) {
        // Upper Route Selector Form
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, ConcreteGrey)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Route endpoints block
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        // From Station
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showFromSelector = true }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.RadioButtonUnchecked, contentDescription = null, tint = LineM1Color, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = fromStation?.name ?: "Изберете начало",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (fromStation != null) FontWeight.Bold else FontWeight.Normal,
                                color = if (fromStation != null) CharcoalDark else Graphite.copy(alpha = 0.5f)
                            )
                        }

                        HorizontalDivider(color = ConcreteGrey, modifier = Modifier.padding(vertical = 6.dp))

                        // To Station
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showToSelector = true }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Place, contentDescription = null, tint = LineM2Color, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = toStation?.name ?: "Изберете край",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (toStation != null) FontWeight.Bold else FontWeight.Normal,
                                color = if (toStation != null) CharcoalDark else Graphite.copy(alpha = 0.5f)
                            )
                        }
                    }

                    // Swap button on right
                    IconButton(
                        onClick = { viewModel.swapStations() },
                        modifier = Modifier
                            .padding(start = 10.dp)
                            .background(WarmWhite, RoundedCornerShape(12.dp))
                            .border(1.dp, ConcreteGrey, RoundedCornerShape(12.dp))
                            .size(44.dp)
                    ) {
                        Icon(Icons.Default.SwapVert, contentDescription = "Размени", tint = Graphite)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Preferences Tabs
                Text(
                    text = "ПРЕДПОЧИТАНИЕ:",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = AccentGold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val prefs = listOf(
                        Triple(MetroRoutingEngine.RoutePreference.SHORTEST_TIME, "НАЙ-БЪРЗ", Icons.Default.Timer),
                        Triple(MetroRoutingEngine.RoutePreference.FEWEST_TRANSFERS, "БЕЗ ПРЕКАЧВАНЕ", Icons.Default.AltRoute),
                        Triple(MetroRoutingEngine.RoutePreference.SIMPLEST, "НАЙ-ЛЕСЕН", Icons.Default.Signpost)
                    )
                    prefs.forEach { (prefType, label, icon) ->
                        val isSelected = preference == prefType
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.setRoutePreference(prefType) },
                            color = if (isSelected) Graphite else WarmWhite,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, if (isSelected) Graphite else ConcreteGrey)
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) WarmWhite else Graphite,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) WarmWhite else Graphite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live Journey Simulation Active overlay
        AnimatedVisibility(
            visible = isJourneyActive && activeJourney != null,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            activeJourney?.let { journey ->
                val step = journey.steps.getOrNull(activeJourneyStepIdx)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalDark),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.5.dp, AccentGold)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DirectionsSubway, contentDescription = null, tint = AccentGold, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "МОЕТО ПЪТУВАНЕ",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Black,
                                    color = AccentGold,
                                    letterSpacing = 1.sp
                                )
                            }
                            Surface(
                                color = LineM3Color.copy(alpha = 0.2f),
                                border = BorderStroke(1.dp, LineM3Color),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "АКТИВНО",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = LineM3Color,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Progress Indicator Bar
                        val progressPercent = (activeJourneyStepIdx.toFloat() / journey.steps.size.toFloat()).coerceIn(0f, 1f)
                        Column(modifier = Modifier.fillMaxWidth()) {
                            LinearProgressIndicator(
                                progress = { progressPercent },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp),
                                color = AccentGold,
                                trackColor = Graphite,
                                strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Стъпка ${activeJourneyStepIdx + 1} от ${journey.steps.size}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ConcreteGrey.copy(alpha = 0.6f)
                                )
                                val remainingMin = Math.max(0, journey.totalTimeMinutes - (activeJourneyStepIdx * 3))
                                Text(
                                    text = "Остават: $remainingMin мин",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AccentGold,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Active Step detail card
                        step?.let { s ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Graphite)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val icon = when (s.type) {
                                        StepType.BOARD -> Icons.Default.Login
                                        StepType.RIDE -> Icons.Default.DirectionsSubway
                                        StepType.INTERCHANGE -> Icons.Default.SwapCalls
                                        StepType.EXIT -> Icons.Default.Logout
                                    }
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = if (s.lineId != null) getLineColor(s.lineId) else WarmWhite,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = s.detail,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = WarmWhite,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (s.durationMinutes > 0) {
                                            Text(
                                                text = "Продължителност: ${s.durationMinutes} мин.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = ConcreteGrey.copy(alpha = 0.7f)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = { viewModel.stopLiveJourney() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MutedRed),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("СПРИ ПЪТУВАНЕТО", fontWeight = FontWeight.Bold, color = WarmWhite)
                        }
                    }
                }
            }
        }

        // Calculated Path steps scroll view
        Box(modifier = Modifier.weight(1f)) {
            if (fromStation == null || toStation == null) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Route,
                        contentDescription = null,
                        tint = ConcreteGrey,
                        modifier = Modifier.size(72.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Въведете начална и крайна точка, за да планирате маршрут.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = Graphite.copy(alpha = 0.5f)
                    )
                }
            } else if (calculatedRoute == null) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = MutedRed,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Няма намерен маршрут.\nВъзможно е някоя станция да е затворена поради технически дейности.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = Graphite.copy(alpha = 0.6f)
                    )
                }
            } else {
                calculatedRoute?.let { journey ->
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Overview Card
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Graphite),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "ОБЩО ВРЕМЕ",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AccentGold,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Surface(
                                            color = AccentGold.copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "Прекачвания: ${journey.transfersCount}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = AccentGold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = "${journey.totalTimeMinutes} минути",
                                        style = MaterialTheme.typography.headlineMedium,
                                        fontWeight = FontWeight.Black,
                                        color = WarmWhite
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))
                                    HorizontalDivider(color = CharcoalDark)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        Text(
                                            text = "Изчакване: ${journey.waitingTimeMinutes} мин.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = ConcreteGrey
                                        )
                                        Text(
                                            text = "•",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = AccentGold
                                        )
                                        Text(
                                            text = "Вървене: ${journey.walkingTimeMinutes} мин.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = ConcreteGrey
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    if (!isJourneyActive) {
                                        Button(
                                            onClick = { viewModel.startLiveJourney(journey) },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = AccentGold, contentColor = CharcoalDark),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("ЗАПОЧНИ ПЪТУВАНЕ", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        // Steps Heading
                        item {
                            Text(
                                text = "МАРШРУТ СТЪПКА ПО СТЪПКА",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Graphite.copy(alpha = 0.5f),
                                modifier = Modifier.padding(start = 2.dp, top = 8.dp)
                            )
                        }

                        // Individual Journey Steps
                        itemsIndexed(journey.steps) { index, step ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, ConcreteGrey),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val icon = when (step.type) {
                                        StepType.BOARD -> Icons.Default.Login
                                        StepType.RIDE -> Icons.Default.DirectionsSubway
                                        StepType.INTERCHANGE -> Icons.Default.SwapHoriz
                                        StepType.EXIT -> Icons.Default.Logout
                                    }
                                    val iconColor = if (step.lineId != null) getLineColor(step.lineId) else AccentGold

                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(iconColor.copy(alpha = 0.15f), RoundedCornerShape(20.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = icon,
                                            contentDescription = null,
                                            tint = iconColor,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(14.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = step.detail,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = CharcoalDark
                                        )
                                        if (step.durationMinutes > 0) {
                                            Text(
                                                text = "Времетраене: ${step.durationMinutes} мин.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Graphite.copy(alpha = 0.6f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Origin Selector Dialog
    if (showFromSelector) {
        StationSelectorDialog(
            stations = viewModel.stations,
            onDismiss = { showFromSelector = false },
            onSelect = {
                viewModel.setFromStation(it)
                showFromSelector = false
            }
        )
    }

    // Destination Selector Dialog
    if (showToSelector) {
        StationSelectorDialog(
            stations = viewModel.stations,
            onDismiss = { showToSelector = false },
            onSelect = {
                viewModel.setToStation(it)
                showToSelector = false
            }
        )
    }
}
