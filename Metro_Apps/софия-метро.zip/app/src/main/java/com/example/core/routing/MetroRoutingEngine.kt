package com.example.core.routing

import com.example.core.model.*
import com.example.data.seed.MetroSeedData
import java.util.PriorityQueue

object MetroRoutingEngine {

    enum class RoutePreference {
        SHORTEST_TIME,  // НАЙ-БЪРЗ
        FEWEST_TRANSFERS, // НАЙ-МАЛКО ПРЕКАЧВАНИЯ
        SIMPLEST        // НАЙ-ЛЕСЕН
    }

    private data class GraphNode(
        val stationId: String,
        val currentLineId: String?,
        val gCost: Double, // Cost to reach this node
        val transfersCount: Int,
        val parent: GraphNode? = null,
        val arrivalType: StepType = StepType.RIDE,
        val timeElapsedSeconds: Int = 0
    ) : Comparable<GraphNode> {
        override fun compareTo(other: GraphNode): Int {
            return this.gCost.compareTo(other.gCost)
        }
    }

    fun calculateRoute(
        origin: String,
        destination: String,
        preference: RoutePreference = RoutePreference.SHORTEST_TIME,
        closedStationId: String? = null
    ): Journey? {
        if (origin == destination) {
            val station = MetroSeedData.stations.find { it.id == origin } ?: return null
            return Journey(
                originStationId = origin,
                destinationStationId = destination,
                totalTimeMinutes = 0,
                waitingTimeMinutes = 0,
                walkingTimeMinutes = 0,
                transfersCount = 0,
                steps = listOf(
                    JourneyStep(StepType.BOARD, origin, null, "Вече сте на станция ${station.name}", 0)
                )
            )
        }

        // Dijkstra's Algorithm
        val openList = PriorityQueue<GraphNode>()
        // Map to keep track of visited nodes with minimum costs
        // Key: stationId + "_" + (currentLineId ?: "")
        val visited = mutableMapOf<String, Double>()

        // Put initial nodes in queue
        val startStation = MetroSeedData.stations.find { it.id == origin } ?: return null
        if (startStation.id == closedStationId) return null

        // We can board any line from start station
        for (lineId in startStation.lineIds) {
            val startNode = GraphNode(
                stationId = origin,
                currentLineId = lineId,
                gCost = 0.0,
                transfersCount = 0,
                parent = null,
                arrivalType = StepType.BOARD,
                timeElapsedSeconds = 0
            )
            openList.add(startNode)
            visited[origin + "_" + lineId] = 0.0
        }

        var destinationNode: GraphNode? = null

        while (openList.isNotEmpty()) {
            val current = openList.poll()

            // If we reached the destination station
            if (current.stationId == destination) {
                if (destinationNode == null || current.gCost < destinationNode.gCost) {
                    destinationNode = current
                }
                break
            }

            val currentKey = current.stationId + "_" + (current.currentLineId ?: "")
            if ((visited[currentKey] ?: Double.MAX_VALUE) < current.gCost) {
                continue
            }

            // Get current station details
            val station = MetroSeedData.stations.find { it.id == current.stationId } ?: continue

            // 1. Move to adjacent stations on the same line (RIDE)
            val directConnections = MetroSeedData.connections.filter {
                (it.fromStationId == current.stationId || it.toStationId == current.stationId) &&
                        it.lineId == current.currentLineId
            }

            for (conn in directConnections) {
                val nextStationId = if (conn.fromStationId == current.stationId) conn.toStationId else conn.fromStationId
                if (nextStationId == closedStationId) continue

                val rideDuration = conn.travelTimeSeconds
                var edgeCost = rideDuration.toDouble()

                // Adjust costs according to preferences
                when (preference) {
                    RoutePreference.SHORTEST_TIME -> {
                        // Standard travel time in seconds
                    }
                    RoutePreference.FEWEST_TRANSFERS -> {
                        // Keep weight of travel time but heavily penalize transfers (added below)
                    }
                    RoutePreference.SIMPLEST -> {
                        // Penalize line rides slightly to favor shorter overall steps
                        edgeCost += 5.0
                    }
                }

                val nextCost = current.gCost + edgeCost
                val nextKey = nextStationId + "_" + current.currentLineId

                if (nextCost < (visited[nextKey] ?: Double.MAX_VALUE)) {
                    visited[nextKey] = nextCost
                    openList.add(
                        GraphNode(
                            stationId = nextStationId,
                            currentLineId = current.currentLineId,
                            gCost = nextCost,
                            transfersCount = current.transfersCount,
                            parent = current,
                            arrivalType = StepType.RIDE,
                            timeElapsedSeconds = current.timeElapsedSeconds + rideDuration
                        )
                    )
                }
            }

            // 2. Perform physical line interchanges at the current station (INTERCHANGE)
            // e.g. Serdika <-> Serdika 2, SU <-> Orlov Most
            val relevantInterchanges = MetroSeedData.interchanges.filter { current.stationId in it.stationIds }
            for (inter in relevantInterchanges) {
                val otherStationId = inter.stationIds.find { it != current.stationId } ?: continue
                if (otherStationId == closedStationId) continue

                val otherStation = MetroSeedData.stations.find { it.id == otherStationId } ?: continue
                for (nextLineId in otherStation.lineIds) {
                    val walkSeconds = inter.walkingTimeSeconds
                    var edgeCost = walkSeconds.toDouble()

                    // Penalties
                    var transferPenaltyCount = 1
                    when (preference) {
                        RoutePreference.SHORTEST_TIME -> {
                            edgeCost += 120.0 // Add waiting time for next train (boarding penalty)
                        }
                        RoutePreference.FEWEST_TRANSFERS -> {
                            edgeCost += 10000.0 // Huge penalty for transferring
                        }
                        RoutePreference.SIMPLEST -> {
                            edgeCost += 600.0 // Extra penalty for walking and boarding
                        }
                    }

                    val nextCost = current.gCost + edgeCost
                    val nextKey = otherStationId + "_" + nextLineId

                    if (nextCost < (visited[nextKey] ?: Double.MAX_VALUE)) {
                        visited[nextKey] = nextCost
                        openList.add(
                            GraphNode(
                                stationId = otherStationId,
                                currentLineId = nextLineId,
                                gCost = nextCost,
                                transfersCount = current.transfersCount + transferPenaltyCount,
                                parent = current,
                                arrivalType = StepType.INTERCHANGE,
                                timeElapsedSeconds = current.timeElapsedSeconds + walkSeconds
                            )
                        )
                    }
                }
            }

            // 3. Same physical station line change (for multi-line stations, like Obelya or Serdika if we just switch line context)
            if (station.lineIds.size > 1) {
                for (otherLineId in station.lineIds) {
                    if (otherLineId == current.currentLineId) continue

                    var transferCost = 120.0 // Boards next train, waiting penalty
                    when (preference) {
                        RoutePreference.FEWEST_TRANSFERS -> transferCost += 10000.0
                        RoutePreference.SIMPLEST -> transferCost += 300.0
                        RoutePreference.SHORTEST_TIME -> { /* No extra penalty */ }
                    }

                    val nextCost = current.gCost + transferCost
                    val nextKey = current.stationId + "_" + otherLineId

                    if (nextCost < (visited[nextKey] ?: Double.MAX_VALUE)) {
                        visited[nextKey] = nextCost
                        openList.add(
                            GraphNode(
                                stationId = current.stationId,
                                currentLineId = otherLineId,
                                gCost = nextCost,
                                transfersCount = current.transfersCount + 1,
                                parent = current,
                                arrivalType = StepType.INTERCHANGE,
                                timeElapsedSeconds = current.timeElapsedSeconds + 30 // Virtual delay
                            )
                        )
                    }
                }
            }
        }

        return destinationNode?.let { buildJourney(it, origin, destination) }
    }

    private fun buildJourney(destNode: GraphNode, origin: String, destination: String): Journey {
        val pathNodes = mutableListOf<GraphNode>()
        var curr: GraphNode? = destNode
        while (curr != null) {
            pathNodes.add(0, curr)
            curr = curr.parent
        }

        val steps = mutableListOf<JourneyStep>()
        var waitingTimeSec = 120 // Initial wait to board first train

        var first = pathNodes.first()
        val startStation = MetroSeedData.stations.find { it.id == origin }
        steps.add(
            JourneyStep(
                type = StepType.BOARD,
                stationId = origin,
                lineId = first.currentLineId,
                detail = "Качете се на ${first.currentLineId ?: ""} от метростанция ${startStation?.name ?: origin}",
                durationMinutes = 2
            )
        )

        var lastBoardedLine: String? = first.currentLineId
        var currentSectionStartId: String = origin
        var sectionTime = 0

        for (i in 1 until pathNodes.size) {
            val node = pathNodes[i]
            val prevNode = pathNodes[i - 1]

            if (node.arrivalType == StepType.INTERCHANGE) {
                // We are switching lines. Flush the current ride segment
                if (node.stationId != currentSectionStartId) {
                    val sName = MetroSeedData.stations.find { it.id == node.stationId }?.name ?: node.stationId
                    steps.add(
                        JourneyStep(
                            type = StepType.RIDE,
                            stationId = node.stationId,
                            lineId = lastBoardedLine,
                            detail = "Пътувайте по линия $lastBoardedLine до станция $sName",
                            durationMinutes = Math.max(1, Math.round(sectionTime / 60.0).toInt())
                        )
                    )
                }

                // Add interchange step
                val currentStationName = MetroSeedData.stations.find { it.id == prevNode.stationId }?.name ?: prevNode.stationId
                val targetStationName = MetroSeedData.stations.find { it.id == node.stationId }?.name ?: node.stationId
                val detailText = if (prevNode.stationId == node.stationId) {
                    "Прекачете се на линия ${node.currentLineId} в станция $currentStationName"
                } else {
                    "Пешеходен трансфер от $currentStationName към $targetStationName за линия ${node.currentLineId}"
                }

                val walkSec = Math.max(30, node.timeElapsedSeconds - prevNode.timeElapsedSeconds)
                steps.add(
                    JourneyStep(
                        type = StepType.INTERCHANGE,
                        stationId = node.stationId,
                        lineId = node.currentLineId,
                        detail = detailText,
                        durationMinutes = Math.max(1, Math.round(walkSec / 60.0).toInt())
                    )
                )

                waitingTimeSec += 120 // Wait for next train
                lastBoardedLine = node.currentLineId
                currentSectionStartId = node.stationId
                sectionTime = 0
            } else {
                // RIDE connection
                sectionTime += (node.timeElapsedSeconds - prevNode.timeElapsedSeconds)
            }
        }

        // Flush final ride segment if any remains
        if (destNode.stationId != currentSectionStartId) {
            val destName = MetroSeedData.stations.find { it.id == destination }?.name ?: destination
            steps.add(
                JourneyStep(
                    type = StepType.RIDE,
                    stationId = destination,
                    lineId = lastBoardedLine,
                    detail = "Пътувайте по линия $lastBoardedLine до крайна станция $destName",
                    durationMinutes = Math.max(1, Math.round(sectionTime / 60.0).toInt())
                )
            )
        }

        // Final Exit Step
        val finalStation = MetroSeedData.stations.find { it.id == destination }
        steps.add(
            JourneyStep(
                type = StepType.EXIT,
                stationId = destination,
                lineId = null,
                detail = "Слезте на метростанция ${finalStation?.name ?: destination}. Пътуването приключи.",
                durationMinutes = 0
            )
        )

        // Calculate walking time and total minutes
        val totalTravelTimeSec = destNode.timeElapsedSeconds
        val walkingTimeSec = pathNodes.filter { it.arrivalType == StepType.INTERCHANGE }.sumOf { current ->
            val prev = current.parent
            if (prev != null && prev.stationId != current.stationId) {
                current.timeElapsedSeconds - prev.timeElapsedSeconds
            } else 0
        }

        val totalMinutes = Math.round((totalTravelTimeSec + waitingTimeSec) / 60.0).toInt()
        val waitMinutes = Math.round(waitingTimeSec / 60.0).toInt()
        val walkMinutes = Math.round(walkingTimeSec / 60.0).toInt()

        return Journey(
            originStationId = origin,
            destinationStationId = destination,
            totalTimeMinutes = Math.max(1, totalMinutes),
            waitingTimeMinutes = waitMinutes,
            walkingTimeMinutes = walkMinutes,
            transfersCount = destNode.transfersCount,
            steps = steps
        )
    }
}
