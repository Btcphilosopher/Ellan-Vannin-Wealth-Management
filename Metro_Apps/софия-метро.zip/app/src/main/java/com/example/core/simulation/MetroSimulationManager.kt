package com.example.core.simulation

import com.example.core.model.SimulationState
import com.example.data.seed.MetroSeedData
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.roundToInt

data class SimulatedTrain(
    val id: String,
    val lineId: String,
    val fromStationId: String,
    val toStationId: String,
    val progress: Float, // 0.0 to 1.0 between from and to stations
    val directionText: String,
    val delayMinutes: Int = 0
)

object MetroSimulationManager {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val _simState = MutableStateFlow(SimulationState())
    val simState: StateFlow<SimulationState> = _simState.asStateFlow()

    private val _activeTrains = MutableStateFlow<List<SimulatedTrain>>(emptyList())
    val activeTrains: StateFlow<List<SimulatedTrain>> = _activeTrains.asStateFlow()

    // Store line statuses locally
    private val _lineStatuses = MutableStateFlow(
        mapOf(
            "M1" to "НОРМАЛНО",
            "M2" to "НОРМАЛНО",
            "M3" to "НОРМАЛНО",
            "M4" to "НОРМАЛНО"
        )
    )
    val lineStatuses: StateFlow<Map<String, String>> = _lineStatuses.asStateFlow()

    private var simulationJob: Job? = null
    private var simulatedMinutes = 8 * 60 + 15 // Start at 08:15 in minutes

    init {
        initializeTrains()
        startSimulation()
    }

    private fun initializeTrains() {
        // Build initial trains for M1, M2, M3, M4
        val initialList = mutableListOf<SimulatedTrain>()

        // M1: Red Line Slivnica <-> Business Park
        initialList.add(SimulatedTrain("train_m1_1", "M1", "slivnica", "lyulin", 0.2f, "Бизнес парк"))
        initialList.add(SimulatedTrain("train_m1_2", "M1", "g_m_dimitrov", "joliot_curie", 0.7f, "Сливница"))

        // M2: Blue Line Obelya <-> Vitosha
        initialList.add(SimulatedTrain("train_m2_1", "M2", "central_railway_station", "lavov_most", 0.5f, "Витоша"))
        initialList.add(SimulatedTrain("train_m2_2", "M2", "james_bourchier", "european_union", 0.1f, "Обеля"))

        // M3: Green Line Gorna Banya <-> Hadzhi Dimitar
        initialList.add(SimulatedTrain("train_m3_1", "M3", "krasno_selo", "bulgaria", 0.4f, "Хаджи Димитър"))
        initialList.add(SimulatedTrain("train_m3_2", "M3", "teatralna", "orlov_most", 0.8f, "Горна баня"))

        // M4: Yellow Line Obelya <-> Sofia Airport
        initialList.add(SimulatedTrain("train_m4_1", "M4", "mladost1", "mladost3", 0.3f, "Летище София"))
        initialList.add(SimulatedTrain("train_m4_2", "M4", "sofia_airport", "mladost3", 0.6f, "Обеля"))

        _activeTrains.value = initialList
    }

    fun startSimulation() {
        if (simulationJob != null) return

        simulationJob = scope.launch {
            while (isActive) {
                delay(1500) // Tick every 1.5 real seconds

                // 1. Advance simulated time (1 simulated minute every 3 Real ticks / 4.5 seconds)
                advanceTime()

                // 2. Update active trains moving along their routes
                updateTrainPositions()
            }
        }
        _simState.update { it.copy(activeSimulation = true) }
    }

    fun stopSimulation() {
        simulationJob?.cancel()
        simulationJob = null
        _simState.update { it.copy(activeSimulation = false) }
    }

    private fun advanceTime() {
        simulatedMinutes = (simulatedMinutes + 1) % (24 * 60)
        val h = simulatedMinutes / 60
        val m = simulatedMinutes % 60
        val timeString = String.format("%02d:%02d", h, m)

        _simState.update { it.copy(currentTime = timeString) }
    }

    private fun updateTrainPositions() {
        _activeTrains.update { list ->
            list.map { train ->
                var nextProgress = train.progress + 0.12f // speed increment
                var fromId = train.fromStationId
                var toId = train.toStationId

                if (nextProgress >= 1.0f) {
                    nextProgress = 0.0f
                    // Swap stations or find next in route sequence
                    val stationsOnLine = MetroSeedData.stations.filter { train.lineId in it.lineIds }
                    val currentIdx = stationsOnLine.indexOfFirst { it.id == toId }
                    if (currentIdx != -1) {
                        fromId = toId
                        val isHeadingToEnd = train.directionText == "Бизнес парк" || 
                                             train.directionText == "Витоша" || 
                                             train.directionText == "Хаджи Димитър" || 
                                             train.directionText == "Летище София"

                        val nextIdx = if (isHeadingToEnd) {
                            if (currentIdx + 1 < stationsOnLine.size) currentIdx + 1 else currentIdx - 1
                        } else {
                            if (currentIdx - 1 >= 0) currentIdx - 1 else currentIdx + 1
                        }

                        // Bounds check and direction swap if terminal is reached
                        val finalNextIdx = if (nextIdx in stationsOnLine.indices) nextIdx else {
                            // Reverse heading
                            0
                        }
                        toId = stationsOnLine[finalNextIdx].id
                    }
                }

                train.copy(
                    fromStationId = fromId,
                    toStationId = toId,
                    progress = nextProgress,
                    delayMinutes = _simState.value.delayMinutes
                )
            }
        }
    }

    // DEVELOPER OVERRIDES
    fun triggerDelay(minutes: Int) {
        _simState.update {
            it.copy(
                status = "Закъснение",
                delayMinutes = minutes,
                isDelayed = true
            )
        }
        _lineStatuses.update {
            it.mapValues { entry -> if (entry.key == "M1" || entry.key == "M2") "ЗАКЪСНЕНИЕ" else entry.value }
        }
    }

    fun closeStation(stationId: String) {
        _simState.update {
            it.copy(
                status = "Затворена станция",
                closedStationId = stationId
            )
        }
        val stationName = MetroSeedData.stations.find { it.id == stationId }?.name ?: stationId
        _lineStatuses.update {
            it.mapValues { entry -> "ОГРАНИЧЕНО ДВИЖЕНИЕ" }
        }
    }

    fun increaseHeadways() {
        _simState.update {
            it.copy(headwaysMinutes = 12)
        }
    }

    fun decreaseHeadways() {
        _simState.update {
            it.copy(headwaysMinutes = 3)
        }
    }

    fun resetSimulation() {
        simulatedMinutes = 8 * 60 + 15
        _simState.update {
            SimulationState(
                currentTime = "08:15",
                status = "Нормално",
                delayMinutes = 0,
                isDelayed = false,
                closedStationId = null,
                headwaysMinutes = 5,
                activeSimulation = true
            )
        }
        _lineStatuses.value = mapOf(
            "M1" to "НОРМАЛНО",
            "M2" to "НОРМАЛНО",
            "M3" to "НОРМАЛНО",
            "M4" to "НОРМАЛНО"
        )
        initializeTrains()
    }
}
