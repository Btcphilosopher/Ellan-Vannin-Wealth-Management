package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import com.example.core.persistence.MetroDatabase
import com.example.data.repository.MetroRepository
import com.example.ui.MetroApp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.MetroViewModel
import com.example.ui.viewmodel.MetroViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Room Local Database
        val database = MetroDatabase.getDatabase(this)
        
        // Setup Repository Pattern
        val repository = MetroRepository(database.metroDao())
        
        // Instantiate the Shared MVVM ViewModel
        val viewModelFactory = MetroViewModelFactory(repository)
        val viewModel = ViewModelProvider(this, viewModelFactory)[MetroViewModel::class.java]

        setContent {
            MyApplicationTheme {
                MetroApp(
                    viewModel = viewModel,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
