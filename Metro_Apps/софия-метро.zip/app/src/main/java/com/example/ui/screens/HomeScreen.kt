package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.core.design.*
import com.example.core.model.MetroStation
import com.example.ui.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MetroViewModel,
    onNavigateToTab: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val fromStation by viewModel.fromStation.collectAsState()
    val toStation by viewModel.toStation.collectAsState()
    val lineStatuses by viewModel.lineStatuses.collectAsState()
    val favoriteStationIds by viewModel.favoriteStationIds.collectAsState()
    val calculatedRoute by viewModel.calculatedRoute.collectAsState()

    var showStationSelectorForFrom by remember { mutableStateOf(false) }
    var showStationSelectorForTo by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF9F6F0)), // WarmWhite
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Hero Visual Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_sofia_metro_hero),
                    contentDescription = "София Метро Витоша",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(Color.Transparent, CharcoalDark.copy(alpha = 0.8f))
                            )
                        )
                )
                Text(
                    text = "СОФИЯ МЕТРО\nВашият град. Вашият маршрут.",
                    style = MaterialTheme.typography.titleLarge,
                    color = WarmWhite,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp),
                    lineHeight = 26.sp
                )
            }
        }

        // Search Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                border = BorderStroke(1.dp, ConcreteGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "НАКЪДЕ ПЪТУВАТЕ?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = CharcoalDark,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Origin Station Selection Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WarmWhite, RoundedCornerShape(8.dp))
                            .border(1.dp, ConcreteGrey, RoundedCornerShape(8.dp))
                            .clickable { showStationSelectorForFrom = true }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.RadioButtonUnchecked,
                            contentDescription = "Начало",
                            tint = LineM1Color,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "ОТ",
                                style = MaterialTheme.typography.labelSmall,
                                color = Graphite.copy(alpha = 0.5f)
                            )
                            Text(
                                text = fromStation?.name ?: "Изберете начална станция",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (fromStation != null) FontWeight.Bold else FontWeight.Normal,
                                color = if (fromStation != null) CharcoalDark else Graphite.copy(alpha = 0.6f)
                            )
                        }
                    }

                    // Swap Button middle divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(32.dp)
                    ) {
                        HorizontalDivider(
                            color = ConcreteGrey,
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(horizontal = 24.dp)
                        )
                        IconButton(
                            onClick = { viewModel.swapStations() },
                            modifier = Modifier
                                .align(Alignment.Center)
                                .background(Color.White, RoundedCornerShape(16.dp))
                                .border(1.dp, ConcreteGrey, RoundedCornerShape(16.dp))
                                .size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "Размени",
                                tint = Graphite,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Destination Station Selection Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WarmWhite, RoundedCornerShape(8.dp))
                            .border(1.dp, ConcreteGrey, RoundedCornerShape(8.dp))
                            .clickable { showStationSelectorForTo = true }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = "Крайна точка",
                            tint = LineM2Color,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "ДО",
                                style = MaterialTheme.typography.labelSmall,
                                color = Graphite.copy(alpha = 0.5f)
                            )
                            Text(
                                text = toStation?.name ?: "Изберете крайна станция",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (toStation != null) FontWeight.Bold else FontWeight.Normal,
                                color = if (toStation != null) CharcoalDark else Graphite.copy(alpha = 0.6f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (fromStation != null && toStation != null) {
                                onNavigateToTab("маршрути")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = (fromStation != null && toStation != null),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Graphite,
                            contentColor = WarmWhite
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ТЪРСИ МАРШРУТ",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Quick Access / Бърз достъп
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "БЪРЗ ДОСТЪП",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black,
                    color = Graphite.copy(alpha = 0.6f),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToTab("карта") },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, ConcreteGrey),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Icon(Icons.Outlined.Map, contentDescription = null, tint = AccentGold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Виж Картата", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToTab("билети") },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, ConcreteGrey),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Icon(Icons.Outlined.ConfirmationNumber, contentDescription = null, tint = MutedRed)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Моите Билети", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        // Vitosha mountain connector banner
        item {
            VitoshaCard(
                modifier = Modifier.padding(16.dp)
            )
        }

        // Network status card panel
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "СЪСТОЯНИЕ НА МРЕЖАТА",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black,
                    color = Graphite.copy(alpha = 0.6f),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    lineStatuses.forEach { (lineId, status) ->
                        ServiceStatusCard(
                            lineId = lineId,
                            status = status,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    // Origin Station Selector Dialog
    if (showStationSelectorForFrom) {
        StationSelectorDialog(
            stations = viewModel.stations,
            onDismiss = { showStationSelectorForFrom = false },
            onSelect = {
                viewModel.setFromStation(it)
                showStationSelectorForFrom = false
            }
        )
    }

    // Destination Station Selector Dialog
    if (showStationSelectorForTo) {
        StationSelectorDialog(
            stations = viewModel.stations,
            onDismiss = { showStationSelectorForTo = false },
            onSelect = {
                viewModel.setToStation(it)
                showStationSelectorForTo = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationSelectorDialog(
    stations: List<MetroStation>,
    onDismiss: () -> Unit,
    onSelect: (MetroStation) -> Unit
) {
    var filterText by remember { mutableStateOf("") }
    val filteredStations = remember(filterText) {
        if (filterText.isBlank()) stations
        else {
            val norm = filterText.lowercase().trim()
            stations.filter {
                it.name.lowercase().contains(norm) ||
                it.nameLatin.lowercase().contains(norm) ||
                it.district.lowercase().contains(norm)
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.75f),
            colors = CardDefaults.cardColors(containerColor = WarmWhite),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, ConcreteGrey)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Изберете Метростанция",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalDark
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Затвори")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = filterText,
                    onValueChange = { filterText = it },
                    placeholder = { Text("Търсете по име или квартал...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Graphite,
                        unfocusedBorderColor = ConcreteGrey
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (filteredStations.isEmpty()) {
                        item {
                            Text(
                                text = "Няма намерени станции",
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                textAlign = TextAlign.Center,
                                color = Graphite.copy(alpha = 0.5f)
                            )
                        }
                    } else {
                        items(filteredStations) { station ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelect(station) },
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, ConcreteGrey),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(station.name, fontWeight = FontWeight.Bold, color = CharcoalDark)
                                        Text("кв. ${station.district}", style = MaterialTheme.typography.bodySmall, color = Graphite.copy(alpha = 0.6f))
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        station.lineIds.forEach { lineId ->
                                            MetroLineBadge(lineId = lineId)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
