package com.example.core.design

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.core.simulation.SimulatedTrain
import com.example.data.seed.MetroSeedData
import kotlin.math.abs
import kotlin.math.sqrt

// --- Premium Theme Colors (Modern Sofia Visual Identity) ---
val WarmWhite = Color(0xFFF9F6F0) // Ceramic/warm-stone ground
val ConcreteGrey = Color(0xFFE2E2DF) // Structural modernist cement
val Graphite = Color(0xFF333333) // Railway steel / slate
val CharcoalDark = Color(0xFF1A1A1A) // Deep underground shadow
val MutedRed = Color(0xFFD63434) // Sofia Red
val AccentGold = Color(0xFFC5A059) // Ochre gold reminiscent of ancient Serdica ruins

val LineM1Color = Color(0xFFE31E24)
val LineM2Color = Color(0xFF005CA9)
val LineM3Color = Color(0xFF00A651)
val LineM4Color = Color(0xFFE5B000)

fun getLineColor(lineId: String): Color {
    return when (lineId) {
        "M1" -> LineM1Color
        "M2" -> LineM2Color
        "M3" -> LineM3Color
        "M4" -> LineM4Color
        else -> Graphite
    }
}

// --- Reusable Components ---

@Composable
fun SofiaMetroHeader(
    modifier: Modifier = Modifier,
    locationText: String = "Сердика, Център"
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Graphite),
        shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "СОФИЯ МЕТРО",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = WarmWhite,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "Вашият град. Вашият маршрут.",
                        style = MaterialTheme.typography.bodySmall,
                        color = AccentGold,
                        fontWeight = FontWeight.Medium
                    )
                }
                Surface(
                    color = MutedRed.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, MutedRed)
                ) {
                    Text(
                        text = "ДЕМО",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmWhite,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Place,
                    contentDescription = "Локация",
                    tint = AccentGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = locationText,
                    style = MaterialTheme.typography.bodySmall,
                    color = ConcreteGrey,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun MetroLineBadge(
    lineId: String,
    modifier: Modifier = Modifier
) {
    val bgColor = getLineColor(lineId)
    val textColor = if (lineId == "M4") CharcoalDark else Color.White
    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = lineId,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

@Composable
fun StationCard(
    station: MetroStation,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    trailingContent: @Composable (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = WarmWhite),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, ConcreteGrey)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = station.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CharcoalDark
                )
                Text(
                    text = station.nameLatin,
                    style = MaterialTheme.typography.bodySmall,
                    color = Graphite.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    station.lineIds.forEach { lineId ->
                        MetroLineBadge(lineId = lineId)
                    }
                    if (station.district.isNotBlank()) {
                        Text(
                            text = "• кв. ${station.district}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Graphite.copy(alpha = 0.6f),
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
            }
            if (trailingContent != null) {
                trailingContent()
            } else {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Виж детайли",
                    tint = Graphite.copy(alpha = 0.5f)
                )
            }
        }
    }
}

@Composable
fun ServiceStatusCard(
    lineId: String,
    status: String,
    modifier: Modifier = Modifier
) {
    val isNormal = status == "НОРМАЛНО"
    val color = if (isNormal) LineM3Color else MutedRed

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = WarmWhite),
        border = BorderStroke(1.dp, ConcreteGrey),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            MetroLineBadge(lineId = lineId)
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(color, RoundedCornerShape(4.dp))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = status,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            }
        }
    }
}

@Composable
fun DepartureBoard(
    stationName: String,
    departures: List<Departure>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CharcoalDark),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.5.dp, AccentGold)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = "Разписание",
                        tint = AccentGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "СЛЕДВАЩИ ВЛАКОВЕ",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Black,
                        color = WarmWhite,
                        letterSpacing = 1.sp
                    )
                }
                Text(
                    text = stationName.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = AccentGold,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = AccentGold.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(12.dp))

            if (departures.isEmpty()) {
                Text(
                    text = "Няма планирани влакове в момента",
                    style = MaterialTheme.typography.bodySmall,
                    color = ConcreteGrey.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            } else {
                departures.forEachIndexed { index, departure ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            MetroLineBadge(lineId = departure.lineId)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "към ${departure.destination}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = WarmWhite,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Text(
                            text = "${departure.minutesLeft} мин",
                            style = MaterialTheme.typography.titleMedium,
                            color = AccentGold,
                            fontWeight = FontWeight.Black
                        )
                    }
                    if (index < departures.size - 1) {
                        HorizontalDivider(color = Graphite, modifier = Modifier.padding(vertical = 4.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun TicketCard(
    product: FareProduct,
    onBuy: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = WarmWhite),
        border = BorderStroke(1.dp, ConcreteGrey),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalDark
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = product.validity,
                        style = MaterialTheme.typography.bodySmall,
                        color = Graphite.copy(alpha = 0.7f)
                    )
                }
                Text(
                    text = String.format("%.2f %s", product.price, product.currency),
                    style = MaterialTheme.typography.titleLarge,
                    color = MutedRed,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = ConcreteGrey)
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = product.transferRules,
                style = MaterialTheme.typography.bodySmall,
                color = Graphite.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onBuy,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(text = "КУПИ БИЛЕТ", color = WarmWhite, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun DigitalTicket(
    ticket: Ticket,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = WarmWhite),
        border = BorderStroke(2.dp, AccentGold),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "БИЛЕТ ЗА МЕТРО",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Black,
                color = AccentGold,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "СОФИЙСКО МЕТРО",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = Graphite.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Simulated Ticket Punch line
            Canvas(modifier = Modifier.fillMaxWidth().height(1.dp)) {
                val sizeWidth = size.width
                var currentX = 0f
                val dashWidth = 8.dp.toPx()
                val gapWidth = 6.dp.toPx()
                while (currentX < sizeWidth) {
                    drawLine(
                        color = AccentGold,
                        start = Offset(currentX, 0f),
                        end = Offset(currentX + dashWidth, 0f),
                        strokeWidth = 2f
                    )
                    currentX += dashWidth + gapWidth
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = ticket.productName,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = CharcoalDark
            )
            Text(
                text = String.format("Цена: %.2f лв.", ticket.price),
                style = MaterialTheme.typography.bodyMedium,
                color = MutedRed,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Simulated Elegant QR code
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .background(Color.White, RoundedCornerShape(8.dp))
                    .border(1.dp, ConcreteGrey, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val side = 15
                    val blockWidth = size.width / side
                    val blockHeight = size.height / side

                    // Draw a deterministic QR lookalike from hash code of ticket ID
                    val idHash = abs(ticket.id.hashCode())
                    for (i in 0 until side) {
                        for (j in 0 until side) {
                            val isCorner = (i < 4 && j < 4) || (i >= side - 4 && j < 4) || (i < 4 && j >= side - 4)
                            val isBlock = if (isCorner) {
                                (i == 0 || i == 3 || j == 0 || j == 3) || (i == 1 && j == 1) || (i == 2 && j == 2)
                            } else {
                                ((idHash + i * 31 + j * 17) % 3 == 0)
                            }

                            if (isBlock) {
                                drawRect(
                                    color = CharcoalDark,
                                    topLeft = Offset(i * blockWidth, j * blockHeight),
                                    size = androidx.compose.ui.geometry.Size(blockWidth + 0.5f, blockHeight + 0.5f)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.Start) {
                    Text(text = "Код", style = MaterialTheme.typography.labelSmall, color = Graphite.copy(alpha = 0.5f))
                    Text(text = ticket.id, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CharcoalDark)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "Дата/Час на покупка", style = MaterialTheme.typography.labelSmall, color = Graphite.copy(alpha = 0.5f))
                    val dateFormatted = java.text.SimpleDateFormat("dd.09.2026, HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ticket.purchaseTimestamp))
                    Text(text = dateFormatted, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CharcoalDark)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                color = Color.Black,
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "ДЕМО • НЕ Е ВАЛИДЕН ЗА ПЪТУВАНЕ",
                    style = MaterialTheme.typography.labelSmall,
                    color = WarmWhite,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun VitoshaCard(
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Graphite),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, AccentGold.copy(alpha = 0.4f))
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(110.dp)) {
            // Mountain canvas drawing background
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Draw background mountain silhouette (Vitosha lookalike)
                val mPath = Path().apply {
                    moveTo(0f, h)
                    lineTo(w * 0.1f, h * 0.8f)
                    lineTo(w * 0.35f, h * 0.35f) // Kamen Del peak
                    lineTo(w * 0.48f, h * 0.5f)
                    lineTo(w * 0.65f, h * 0.25f) // Black Peak (Cherni Vrah)
                    lineTo(w * 0.82f, h * 0.6f)
                    lineTo(w, h * 0.9f)
                    lineTo(w, h)
                    close()
                }

                drawPath(
                    path = mPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            AccentGold.copy(alpha = 0.25f),
                            Color.Transparent
                        )
                    )
                )

                // Draws secondary closer ridges
                val rPath = Path().apply {
                    moveTo(0f, h)
                    lineTo(w * 0.2f, h * 0.75f)
                    lineTo(w * 0.5f, h * 0.55f)
                    lineTo(w * 0.75f, h * 0.8f)
                    lineTo(w, h * 0.7f)
                    lineTo(w, h)
                    close()
                }
                drawPath(
                    path = rPath,
                    color = CharcoalDark.copy(alpha = 0.4f)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FilterHdr,
                        contentDescription = "Планина",
                        tint = AccentGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ВИТОША",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Black,
                        color = AccentGold,
                        letterSpacing = 1.sp
                    )
                }

                Column {
                    Text(
                        text = "Метрото свързва града с планината.",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = WarmWhite
                    )
                    Text(
                        text = "Слезте на МС Витоша за автобуси 66 и 98 директно до Алеко и лифта.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ConcreteGrey.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

// --- FULLY INTERACTIVE VECTOR METRO MAP ---
@Composable
fun MetroMap(
    stations: List<MetroStation>,
    connections: List<MetroConnection>,
    interchanges: List<Interchange>,
    activeTrains: List<SimulatedTrain>,
    selectedStation: MetroStation?,
    highlightedJourney: Journey?,
    onStationSelected: (MetroStation) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset(0f, 0f)) }

    val transformState = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.5f, 3.5f)
        offset += offsetChange * scale
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalDark)
            .pointerInput(Unit) {
                // Support dragging
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offset += dragAmount
                }
            }
            .transformable(state = transformState)
            .clipToBounds()
    ) {
        val maxMapWidth = maxWidth
        val maxMapHeight = maxHeight

        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            // Apply scale and offset transformations
            val canvasWidth = size.width
            val canvasHeight = size.height

            // Center mapping
            val centerX = canvasWidth / 2f + offset.x
            val centerY = canvasHeight / 2f + offset.y

            // Coordinate normalizer (Map from seed 0..1000 coordinate space to canvas)
            fun mapCoord(x: Float, y: Float): Offset {
                val normX = (x - 500f) * 0.9f * scale + centerX
                val normY = (y - 450f) * 0.9f * scale + centerY
                return Offset(normX, normY)
            }

            // 1. Draw Background Grid or Accents
            drawCircle(
                color = AccentGold.copy(alpha = 0.05f),
                radius = 200f * scale,
                center = mapCoord(540f, 340f) // Center near Serdika
            )

            // 2. Draw Connections (Lines)
            val lineStrokeWidth = 6f * scale
            val highlightedStrokeWidth = 12f * scale

            // Group connections by lineId to draw contiguous strokes
            val connectionsByLine = connections.groupBy { it.lineId }
            connectionsByLine.forEach { (lineId, lineConns) ->
                val color = getLineColor(lineId)
                lineConns.forEach { conn ->
                    val fromStation = stations.find { it.id == conn.fromStationId }
                    val toStation = stations.find { it.id == conn.toStationId }
                    if (fromStation != null && toStation != null) {
                        drawLine(
                            color = color.copy(alpha = 0.4f),
                            start = mapCoord(fromStation.schematicX, fromStation.schematicY),
                            end = mapCoord(toStation.schematicX, toStation.schematicY),
                            strokeWidth = lineStrokeWidth,
                            pathEffect = PathEffect.cornerPathEffect(20f)
                        )
                    }
                }
            }

            // 3. Highlight calculated journey path if exists
            if (highlightedJourney != null) {
                val steps = highlightedJourney.steps.filter { it.type == StepType.RIDE }
                steps.forEach { step ->
                    // Find the line connection to draw highlight
                    val targetStation = stations.find { it.id == step.stationId }
                    // Highlight preceding connections leading to this station on step.lineId
                    val parentStepIdx = highlightedJourney.steps.indexOf(step) - 1
                    if (parentStepIdx >= 0) {
                        val prevStationId = highlightedJourney.steps[parentStepIdx].stationId
                        val prevStation = stations.find { it.id == prevStationId }
                        if (prevStation != null && targetStation != null) {
                            drawLine(
                                color = getLineColor(step.lineId ?: "M1"),
                                start = mapCoord(prevStation.schematicX, prevStation.schematicY),
                                end = mapCoord(targetStation.schematicX, targetStation.schematicY),
                                strokeWidth = highlightedStrokeWidth,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }
            }

            // 4. Draw Interchanges (dashed grey links)
            interchanges.forEach { inter ->
                val s1 = stations.find { it.id == inter.stationIds[0] }
                val s2 = stations.find { it.id == inter.stationIds[1] }
                if (s1 != null && s2 != null) {
                    val p1 = mapCoord(s1.schematicX, s1.schematicY)
                    val p2 = mapCoord(s2.schematicX, s2.schematicY)
                    drawLine(
                        color = ConcreteGrey,
                        start = p1,
                        end = p2,
                        strokeWidth = 4f * scale,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                    )
                }
            }

            // 5. Draw Station Nodes
            stations.forEach { station ->
                val p = mapCoord(station.schematicX, station.schematicY)
                val radius = if (station.id == selectedStation?.id) 11f * scale else 7f * scale
                val color = if (station.lineIds.size > 1) AccentGold else getLineColor(station.lineIds.first())

                // Draw outer ring
                drawCircle(
                    color = color,
                    radius = radius,
                    center = p
                )
                // Draw inner white center
                drawCircle(
                    color = Color.White,
                    radius = radius * 0.6f,
                    center = p
                )

                // Draw Labels if zoomed in
                if (scale >= 0.8f) {
                    val labelOffset = when {
                        station.schematicY < 200f -> Offset(0f, -20f * scale)
                        station.schematicX > 800f -> Offset(22f * scale, 0f)
                        else -> Offset(0f, 22f * scale)
                    }

                    // We can draw text labels directly via native Canvas to maintain beautiful performance
                    val paint = android.graphics.Paint().apply {
                        setColor(android.graphics.Color.WHITE)
                        textSize = (11f * scale).coerceAtLeast(10f).coerceAtMost(16f)
                        textAlign = if (station.schematicX > 800f) android.graphics.Paint.Align.LEFT else android.graphics.Paint.Align.CENTER
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                    }
                    drawContext.canvas.nativeCanvas.drawText(
                        station.name,
                        p.x + labelOffset.x,
                        p.y + labelOffset.y,
                        paint
                    )
                }
            }

            // 6. Draw Simulated Live Trains gliding along tracks
            activeTrains.forEach { train ->
                val fromSt = stations.find { it.id == train.fromStationId }
                val toSt = stations.find { it.id == train.toStationId }
                if (fromSt != null && toSt != null) {
                    val p1 = mapCoord(fromSt.schematicX, fromSt.schematicY)
                    val p2 = mapCoord(toSt.schematicX, toSt.schematicY)

                    // Interpolate position
                    val trainX = p1.x + (p2.x - p1.x) * train.progress
                    val trainY = p1.y + (p2.y - p1.y) * train.progress

                    // Draw glowing train marker
                    drawCircle(
                        color = getLineColor(train.lineId),
                        radius = 10f * scale,
                        center = Offset(trainX, trainY)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 4f * scale,
                        center = Offset(trainX, trainY)
                    )
                }
            }
        }

        // 7. Click Detection overlay for Station Tapping
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            val density = LocalDensity.current
            val widthPx = with(density) { maxMapWidth.toPx() }
            val heightPx = with(density) { maxMapHeight.toPx() }
            val centerX = widthPx / 2f + offset.x
            val centerY = heightPx / 2f + offset.y

            stations.forEach { station ->
                // Approximate coordinate of each station on actual screen space
                val rawX = (station.schematicX - 500f) * 0.9f * scale + centerX
                val rawY = (station.schematicY - 450f) * 0.9f * scale + centerY
                val xInDp = with(density) { rawX.toDp() }
                val yInDp = with(density) { rawY.toDp() }

                Box(
                    modifier = Modifier
                        .offset(xInDp - 24.dp, yInDp - 24.dp)
                        .size(48.dp) // Generous 48.dp accessibility touch target
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            onStationSelected(station)
                        }
                )
            }
        }

        // Map control overlays
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FloatingActionButton(
                onClick = { scale = (scale + 0.3f).coerceAtMost(3.5f) },
                containerColor = Graphite,
                contentColor = WarmWhite,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Увеличи")
            }
            FloatingActionButton(
                onClick = { scale = (scale - 0.3f).coerceAtLeast(0.5f) },
                containerColor = Graphite,
                contentColor = WarmWhite,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(imageVector = Icons.Default.Remove, contentDescription = "Намали")
            }
            FloatingActionButton(
                onClick = {
                    scale = 1f
                    offset = Offset(0f, 0f)
                },
                containerColor = Graphite,
                contentColor = WarmWhite,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(imageVector = Icons.Default.MyLocation, contentDescription = "Центрирай")
            }
        }
    }
}
