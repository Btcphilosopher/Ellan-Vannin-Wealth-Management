package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.design.*
import com.example.core.model.Departure
import com.example.core.model.MetroStation
import com.example.ui.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    viewModel: MetroViewModel,
    onNavigateToTab: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedStation by viewModel.selectedStation.collectAsState()
    val activeTrains by viewModel.activeTrains.collectAsState()
    val simulationState by viewModel.simulationState.collectAsState()
    val favoriteStationIds by viewModel.favoriteStationIds.collectAsState()
    val calculatedRoute by viewModel.calculatedRoute.collectAsState()

    var showStationSheet by remember { mutableStateOf(false) }

    // Synchronize sheet state with viewModel selectedStation
    LaunchedEffect(selectedStation) {
        showStationSheet = (selectedStation != null)
    }

    Box(modifier = modifier.fillMaxSize()) {
        // Main Interactive Vector Map Canvas
        MetroMap(
            stations = viewModel.stations,
            connections = viewModel.connections,
            interchanges = viewModel.interchanges,
            activeTrains = activeTrains,
            selectedStation = selectedStation,
            highlightedJourney = calculatedRoute,
            onStationSelected = { station ->
                viewModel.selectStation(station)
                showStationSheet = true
            },
            modifier = Modifier.fillMaxSize()
        )

        // Top Status Overlay (Time and general status)
        Card(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(14.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalDark.copy(alpha = 0.9f)),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, AccentGold.copy(alpha = 0.4f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = "Време",
                        tint = AccentGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Време: ${simulationState.currentTime}",
                        style = MaterialTheme.typography.bodySmall,
                        color = WarmWhite,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(modifier = Modifier.size(1.dp, 12.dp).background(ConcreteGrey.copy(alpha = 0.3f)))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(if (simulationState.isDelayed) MutedRed else LineM3Color, RoundedCornerShape(3.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (simulationState.isDelayed) "ЗАКЪСНЕНИЕ (+${simulationState.delayMinutes}м)" else "НОРМАЛНО",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (simulationState.isDelayed) MutedRed else LineM3Color,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Bottom Sheet Style Panel for Selected Station
        AnimatedVisibility(
            visible = showStationSheet && selectedStation != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 68.dp) // Leave room for Navigation bar
        ) {
            selectedStation?.let { station ->
                val isFav = favoriteStationIds.contains(station.id)

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmWhite),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    border = BorderStroke(1.5.dp, AccentGold)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Header section with close and favorite
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                station.lineIds.forEach { lineId ->
                                    MetroLineBadge(lineId = lineId)
                                    Spacer(modifier = Modifier.width(6.dp))
                                }
                                Text(
                                    text = station.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = CharcoalDark
                                )
                            }
                            Row {
                                IconButton(
                                    onClick = { viewModel.toggleFavoriteStation(station.id) }
                                ) {
                                    Icon(
                                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Любима",
                                        tint = if (isFav) MutedRed else Graphite
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        viewModel.selectStation(null)
                                        showStationSheet = false
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Затвори",
                                        tint = Graphite
                                    )
                                }
                            }
                        }

                        Text(
                            text = station.nameLatin,
                            style = MaterialTheme.typography.bodySmall,
                            color = Graphite.copy(alpha = 0.6f),
                            modifier = Modifier.padding(start = 2.dp, bottom = 8.dp)
                        )

                        Text(
                            text = "кв. ${station.district}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Graphite
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Next Trains Departure Board (Simulated based on line and delays)
                        val headways = simulationState.headwaysMinutes
                        val currentDelay = simulationState.delayMinutes
                        val simulatedDepartures = station.lineIds.flatMap { lineId ->
                            listOf(
                                Departure(destination = if (lineId == "M2") "Витоша" else "Бизнес парк", minutesLeft = headways + currentDelay, lineId = lineId),
                                Departure(destination = if (lineId == "M2") "Обеля" else "Сливница", minutesLeft = (headways * 2) + currentDelay, lineId = lineId)
                            )
                        }
                        DepartureBoard(
                            stationName = station.name,
                            departures = simulatedDepartures,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Nearby Landmarks
                        if (station.nearbyPlaces.isNotEmpty()) {
                            Text(
                                text = "В БЛИЗОСТ:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = AccentGold,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            station.nearbyPlaces.forEach { place ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = AccentGold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = place,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Graphite
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Accessible Facilities Header
                        Text(
                            text = "УДОБСТВА И ДОСТЪПНОСТ:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = AccentGold,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (station.accessibility) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .background(LineM3Color.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Accessible,
                                        contentDescription = "Достъпен",
                                        tint = LineM3Color,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Достъпна", style = MaterialTheme.typography.labelSmall, color = LineM3Color, fontWeight = FontWeight.Bold)
                                }
                            }
                            station.facilities.forEach { fac ->
                                val (facName, facIcon) = when (fac) {
                                    "elevator" -> Pair("Асансьор", Icons.Default.Elevator)
                                    "escalator" -> Pair("Ескалатор", Icons.Default.DirectionsWalk)
                                    "ticket_machine" -> Pair("Каса/Автомат", Icons.Default.ConfirmationNumber)
                                    else -> Pair("Други", Icons.Default.Info)
                                }
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .background(ConcreteGrey, RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = facIcon,
                                        contentDescription = facName,
                                        tint = Graphite,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(facName, style = MaterialTheme.typography.labelSmall, color = CharcoalDark)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Origin / Destination setup controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.setFromStation(station)
                                    onNavigateToTab("маршрути")
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.RadioButtonUnchecked, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ОТ ТУК", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = {
                                    viewModel.setToStation(station)
                                    onNavigateToTab("маршрути")
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ДО ТУК", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
