package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.design.*
import com.example.ui.screens.*
import com.example.ui.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetroApp(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf("начало") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color(0xFFF9F6F0), // WarmWhite
        bottomBar = {
            NavigationBar(
                containerColor = Graphite,
                contentColor = WarmWhite,
                tonalElevation = 8.dp
            ) {
                val tabs = listOf(
                    Triple("начало", "НАЧАЛО", Icons.Default.Home),
                    Triple("карта", "КАРТА", Icons.Default.Map),
                    Triple("маршрути", "МАРШРУТИ", Icons.Default.AltRoute),
                    Triple("билети", "БИЛЕТИ", Icons.Default.ConfirmationNumber),
                    Triple("още", "ОЩЕ", Icons.Default.MoreHoriz)
                )

                tabs.forEach { (route, label, icon) ->
                    val isSelected = activeTab == route
                    val itemColor = if (isSelected) AccentGold else ConcreteGrey.copy(alpha = 0.7f)

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { activeTab = route },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = itemColor,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = label,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                color = itemColor,
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = CharcoalDark
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Animated Slide and Fade Transitions for premium native applet feel
            AnimatedContent(
                targetState = activeTab,
                transitionSpec = {
                    (fadeIn(animationSpec = tween(220, delayMillis = 90)) +
                            scaleIn(initialScale = 0.98f, animationSpec = tween(220, delayMillis = 90)))
                        .togetherWith(fadeOut(animationSpec = tween(90)))
                },
                label = "ScreenTransition"
            ) { tab ->
                when (tab) {
                    "начало" -> HomeScreen(
                        viewModel = viewModel,
                        onNavigateToTab = { activeTab = it }
                    )
                    "карта" -> MapScreen(
                        viewModel = viewModel,
                        onNavigateToTab = { activeTab = it }
                    )
                    "маршрути" -> RoutesScreen(
                        viewModel = viewModel
                    )
                    "билети" -> TicketsScreen(
                        viewModel = viewModel
                    )
                    "още" -> MoreScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}
