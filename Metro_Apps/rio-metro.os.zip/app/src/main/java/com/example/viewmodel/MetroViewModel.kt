package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class MainTab {
    HOME, PLAN, BUY, WALLET, MORE
}

enum class QrValidationState {
    IDLE, READY, PRESENT, VERIFYING, VALID_AUTHORIZED, ERROR_EXPIRED, ERROR_USED, ERROR_INVALID
}

enum class ContactlessState {
    IDLE, READY, PRESENT, VERIFYING, AUTHORIZED
}

class MetroViewModel(application: Application) : AndroidViewModel(application) {

    private val database = MetroDatabase.getDatabase(application)
    private val repository = MetroRepository(database.metroDao())

    // Tabs & Navigation State
    val currentTab = mutableStateOf(MainTab.HOME)

    // Room Persistent Flows
    val stations: StateFlow<List<StationEntity>> = repository.allStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<TicketEntity>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alerts: StateFlow<List<AlertEntity>> = repository.allAlerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transportCards: StateFlow<List<TransportCardEntity>> = repository.allTransportCards
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Journey Planner Inputs
    val originStationId = mutableStateOf<String?>("botafogo")
    val destStationId = mutableStateOf<String?>("central")
    val planAccessibleOnly = mutableStateOf(false)
    val plannedJourney = mutableStateOf<JourneyPlan?>(null)

    // Ticketing State
    val buyOriginId = mutableStateOf<String?>("botafogo")
    val buyDestId = mutableStateOf<String?>("central")
    val selectedFareType = mutableStateOf("SINGLE") // SINGLE, GIRO, DAY
    val passengerNameInput = mutableStateOf("Tom")
    val buyCardNumber = mutableStateOf("4532 9821 5493 0210")
    val purchaseState = mutableStateOf<String>("IDLE") // IDLE, PROCESSING, SUCCESS, ERROR

    // QR Validation Screen State
    val activeValidationTicketId = mutableStateOf<String?>(null)
    val qrValidationState = mutableStateOf(QrValidationState.IDLE)
    val qrValidationMessage = mutableStateOf("")

    // NFC Contactless Simulator State
    val contactlessState = mutableStateOf(ContactlessState.IDLE)
    val activeJourneyNodeIndex = mutableStateOf(0)

    // Active Journey Tracking State
    val activeJourneyPlan = mutableStateOf<JourneyPlan?>(null)
    val activeJourneyTicket = mutableStateOf<TicketEntity?>(null)
    val isJourneyRunning = mutableStateOf(false)

    // Stations Directory Search
    val stationSearchQuery = mutableStateOf("")

    init {
        // Seed database with MetrôRio stations, Giro cards, and initial Alerts
        viewModelScope.launch {
            repository.seedIfNeeded()
            // Run path planning to have an initial pre-calculated trip on start
            triggerPathPlanning()
        }
    }

    // Dynamic Journey Planning
    fun setOrigin(id: String?) {
        originStationId.value = id
        triggerPathPlanning()
    }

    fun setDestination(id: String?) {
        destStationId.value = id
        triggerPathPlanning()
    }

    fun toggleAccessibleOnly(enabled: Boolean) {
        planAccessibleOnly.value = enabled
        triggerPathPlanning()
    }

    fun triggerPathPlanning() {
        val orig = originStationId.value
        val dest = destStationId.value
        if (orig != null && dest != null) {
            val stats = stations.value
            if (stats.isNotEmpty()) {
                plannedJourney.value = repository.findJourneyPlan(
                    originId = orig,
                    destId = dest,
                    accessibleOnly = planAccessibleOnly.value,
                    stationsList = stats
                )
            }
        } else {
            plannedJourney.value = null
        }
    }

    // Purchase end-to-end journey
    fun purchaseTicket(onComplete: () -> Unit) {
        val origId = buyOriginId.value ?: return
        val destId = buyDestId.value ?: return
        val stats = stations.value
        val originStation = stats.find { it.id == origId } ?: return
        val destStation = stats.find { it.id == destId } ?: return

        viewModelScope.launch {
            purchaseState.value = "PROCESSING"
            delay(1500) // Simulate card processing latency

            val price = when (selectedFareType.value) {
                "SINGLE" -> 7.50
                "GIRO" -> 6.90
                "DAY" -> 22.00
                else -> 7.50
            }

            val typePt = when (selectedFareType.value) {
                "SINGLE" -> "Bilhete Unitário"
                "GIRO" -> "Recarga Giro"
                "DAY" -> "Passe Diário"
                else -> "Bilhete Unitário"
            }
            val typeEs = when (selectedFareType.value) {
                "SINGLE" -> "Billete Unitario"
                "GIRO" -> "Recarga Giro"
                "DAY" -> "Pase Diario"
                else -> "Billete Unitario"
            }
            val typeEn = when (selectedFareType.value) {
                "SINGLE" -> "Single Journey"
                "GIRO" -> "Giro Recharge"
                "DAY" -> "Day Pass"
                else -> "Single Journey"
            }

            // If paying by Giro card, deduct balance
            if (selectedFareType.value == "GIRO") {
                repository.deductTransportCard("giro_main", price)
            }

            val ticket = repository.addTicket(
                origin = originStation,
                dest = destStation,
                price = price,
                passengerName = passengerNameInput.value,
                typePt = typePt,
                typeEs = typeEs,
                typeEn = typeEn
            )

            purchaseState.value = "SUCCESS"
            delay(500)
            purchaseState.value = "IDLE"
            onComplete()
        }
    }

    // Activate Ticket in Wallet
    fun activateTicket(ticketId: String) {
        viewModelScope.launch {
            repository.activateTicket(ticketId)
        }
    }

    // Refund ticket
    fun refundTicket(ticketId: String) {
        viewModelScope.launch {
            repository.refundTicket(ticketId)
        }
    }

    // Top up Giro Card
    fun topUpGiroCard(amount: Double) {
        viewModelScope.launch {
            repository.topUpTransportCard("giro_main", amount)
        }
    }

    // Start QR Validator Simulation Flow
    fun startQrValidation(ticketId: String) {
        activeValidationTicketId.value = ticketId
        qrValidationState.value = QrValidationState.READY
    }

    fun triggerQrScan() {
        val ticketId = activeValidationTicketId.value ?: return
        viewModelScope.launch {
            qrValidationState.value = QrValidationState.PRESENT
            delay(1000)
            qrValidationState.value = QrValidationState.VERIFYING
            delay(1200)

            val (success, errorCode) = repository.validateTicket(ticketId)
            if (success) {
                qrValidationState.value = QrValidationState.VALID_AUTHORIZED
                
                // If it was successful, start active journey tracking automatically for demonstration!
                val tkt = repository.getTicketById(ticketId)
                if (tkt != null) {
                    val stats = stations.value
                    val plan = repository.findJourneyPlan(tkt.originCode.lowercase(), tkt.destCode.lowercase(), false, stats)
                    if (plan != null) {
                        activeJourneyPlan.value = plan
                        activeJourneyTicket.value = tkt
                        activeJourneyNodeIndex.value = 0
                        isJourneyRunning.value = true
                    }
                }
            } else {
                when (errorCode) {
                    "EXPIRED" -> qrValidationState.value = QrValidationState.ERROR_EXPIRED
                    "ALREADY_USED" -> qrValidationState.value = QrValidationState.ERROR_USED
                    else -> qrValidationState.value = QrValidationState.ERROR_INVALID
                }
            }
        }
    }

    fun closeQrValidation() {
        activeValidationTicketId.value = null
        qrValidationState.value = QrValidationState.IDLE
    }

    // Contactless gate access simulation (NFC)
    fun triggerNfcContactless() {
        viewModelScope.launch {
            contactlessState.value = ContactlessState.READY
            delay(1000)
            contactlessState.value = ContactlessState.PRESENT
            delay(1000)
            contactlessState.value = ContactlessState.VERIFYING
            delay(1200)
            
            // Deduct from GIRO Card
            repository.deductTransportCard("giro_main", 7.50)
            
            contactlessState.value = ContactlessState.AUTHORIZED
            delay(2000)
            contactlessState.value = ContactlessState.IDLE
        }
    }

    // Journey Simulation controls
    fun progressJourney() {
        val plan = activeJourneyPlan.value ?: return
        // Collect list of intermediate nodes
        val totalStops = plan.totalStops
        if (activeJourneyNodeIndex.value < totalStops) {
            activeJourneyNodeIndex.value += 1
        } else {
            // Arrived at destination! Stop journey
            isJourneyRunning.value = false
            activeJourneyPlan.value = null
            activeJourneyTicket.value = null
        }
    }

    fun cancelJourney() {
        isJourneyRunning.value = false
        activeJourneyPlan.value = null
        activeJourneyTicket.value = null
    }
}
