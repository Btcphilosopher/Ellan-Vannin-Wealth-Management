package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.theme.*
import com.example.viewmodel.ContactlessState
import com.example.viewmodel.MetroViewModel

@Composable
fun MoreTab(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val stations by viewModel.stations.collectAsState()
    val alerts by viewModel.alerts.collectAsState()
    val contactlessState = viewModel.contactlessState.value

    val currentLang = I18n.currentLanguage.value

    // Filtering stations by search query
    val searchQuery = viewModel.stationSearchQuery.value
    val filteredStations = stations.filter { station ->
        station.namePt.contains(searchQuery, ignoreCase = true) ||
        station.nameEs.contains(searchQuery, ignoreCase = true) ||
        station.nameEn.contains(searchQuery, ignoreCase = true) ||
        station.code.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. RIO INTERACTIVE NETWORK MAP ---
        Text(
            text = I18n.get("explore_stations"),
            style = MaterialTheme.typography.titleLarge,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        MapWidget(
            selectedOriginId = viewModel.originStationId.value,
            selectedDestId = viewModel.destStationId.value,
            onStationSelect = { id ->
                // Swap or update selection
                if (viewModel.originStationId.value == null) {
                    viewModel.setOrigin(id)
                } else if (viewModel.destStationId.value == null) {
                    viewModel.setDestination(id)
                } else {
                    viewModel.setOrigin(id)
                    viewModel.setDestination(null)
                }
            },
            modifier = Modifier.fillMaxWidth().testTag("interactive_map_canvas")
        )

        // --- 2. STATIONS DIRECTORY SEARCH ---
        Card(
            modifier = Modifier.fillMaxWidth().testTag("stations_search_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Diretório de Estações",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    fontSize = 16.sp
                )

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.stationSearchQuery.value = it },
                    placeholder = { Text(I18n.get("search_station")) },
                    modifier = Modifier.fillMaxWidth().testTag("station_search_field"),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = TropicalGreen) }
                )

                // List of searched stations
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    filteredStations.take(3).forEach { station ->
                        var isExpanded by remember { mutableStateOf(false) }
                        val name = if (currentLang == AppLanguage.PT_BR) station.namePt else if (currentLang == AppLanguage.ES) station.nameEs else station.nameEn
                        val opHours = if (currentLang == AppLanguage.PT_BR) station.openingHoursPt else if (currentLang == AppLanguage.ES) station.openingHoursEs else station.openingHoursEn

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                .clickable { isExpanded = !isExpanded }
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(text = "Cód: ${station.code} • Linhas: ${station.lines}", fontSize = 11.sp, color = Color.Gray)
                                }
                                Icon(
                                    imageVector = if (isExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                    contentDescription = null,
                                    tint = TropicalGreen
                                )
                            }

                            AnimatedVisibility(visible = isExpanded) {
                                Column(
                                    modifier = Modifier.padding(top = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Schedule, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(text = "${I18n.get("operating_hours")}: $opHours", fontSize = 11.sp, color = Color.DarkGray)
                                    }

                                    // Elevators / Escalators
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (station.accessible) Icons.Filled.Accessible else Icons.Filled.NotAccessible,
                                            contentDescription = null,
                                            tint = if (station.accessible) SuccessGreen else ErrorRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = if (station.accessible) I18n.get("step_free") else "Não acessível",
                                            fontSize = 11.sp,
                                            color = if (station.accessible) SuccessGreen else ErrorRed
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (station.elevatorsOk) Icons.Filled.Elevator else Icons.Filled.Elevator,
                                            contentDescription = null,
                                            tint = if (station.elevatorsOk) SuccessGreen else ErrorRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = if (station.elevatorsOk) I18n.get("elevators") else "Elevador inativo",
                                            fontSize = 11.sp,
                                            color = if (station.elevatorsOk) SuccessGreen else ErrorRed
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Filled.SwapVert,
                                            contentDescription = null,
                                            tint = if (station.escalatorsOk) SuccessGreen else ErrorRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = if (station.escalatorsOk) I18n.get("escalators") else "Escada rolante inativa",
                                            fontSize = 11.sp,
                                            color = if (station.escalatorsOk) SuccessGreen else ErrorRed
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- 3. D_EMO CONTACTLESS NFC GATEWAY ARCHITECTURE ---
        Card(
            modifier = Modifier.fillMaxWidth().testTag("nfc_simulator_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Contactless, contentDescription = null, tint = TropicalGreen)
                    Spacer(Modifier.width(8.dp))
                    Text(text = I18n.get("nfc_title"), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                // Gate Screen
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val stateStr = when(contactlessState) {
                            ContactlessState.IDLE, ContactlessState.READY -> I18n.get("nfc_ready")
                            ContactlessState.PRESENT -> I18n.get("nfc_present")
                            ContactlessState.VERIFYING -> I18n.get("nfc_verifying")
                            ContactlessState.AUTHORIZED -> I18n.get("nfc_authorized")
                        }

                        val screenCol = if (contactlessState == ContactlessState.AUTHORIZED) SuccessGreen else HighContrastGold

                        Text(
                            text = stateStr,
                            color = screenCol,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )

                        if (contactlessState == ContactlessState.AUTHORIZED) {
                            Text(
                                text = "L1 / L2 / L4 GATE OPENED",
                                color = SuccessGreen,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                if (contactlessState == ContactlessState.IDLE) {
                    Button(
                        onClick = { viewModel.triggerNfcContactless() },
                        colors = ButtonDefaults.buttonColors(containerColor = TropicalGreen),
                        modifier = Modifier.fillMaxWidth().testTag("trigger_nfc_button")
                    ) {
                        Text("Simular Cartão Crédito (NFC)", color = Color.White)
                    }
                }
            }
        }

        // --- 4. LINE SERVICE ALERTS ---
        Card(
            modifier = Modifier.fillMaxWidth().testTag("service_alerts_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = I18n.get("service_status"),
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    fontSize = 16.sp
                )

                alerts.forEach { alert ->
                    val lineCol = when (alert.lineCode) {
                        "L1" -> Color(0xFFF15A24)
                        "L2" -> Color(0xFF00A859)
                        "L4" -> Color(0xFF005CA9)
                        else -> Color.DarkGray
                    }

                    val title = if (currentLang == AppLanguage.PT_BR) alert.titlePt else if (currentLang == AppLanguage.ES) alert.titleEs else alert.titleEn
                    val desc = if (currentLang == AppLanguage.PT_BR) alert.descPt else if (currentLang == AppLanguage.ES) alert.descEs else alert.descEn

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        // Line identifier bullet
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(lineCol),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = alert.lineCode, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = desc, fontSize = 11.sp, color = Color.DarkGray)
                        }
                    }
                }
            }
        }

        // --- 5. SYSTEM SETTINGS & DYNAMIC LANGUAGE SELECTORS ---
        Card(
            modifier = Modifier.fillMaxWidth().testTag("language_settings_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Configuração do Sistema / Idioma",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    fontSize = 15.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LanguageButton(
                        lang = AppLanguage.PT_BR,
                        selected = currentLang == AppLanguage.PT_BR,
                        onClick = { I18n.currentLanguage.value = AppLanguage.PT_BR },
                        modifier = Modifier.weight(1f).testTag("lang_pt_button")
                    )
                    LanguageButton(
                        lang = AppLanguage.ES,
                        selected = currentLang == AppLanguage.ES,
                        onClick = { I18n.currentLanguage.value = AppLanguage.ES },
                        modifier = Modifier.weight(1f).testTag("lang_es_button")
                    )
                    LanguageButton(
                        lang = AppLanguage.EN,
                        selected = currentLang == AppLanguage.EN,
                        onClick = { I18n.currentLanguage.value = AppLanguage.EN },
                        modifier = Modifier.weight(1f).testTag("lang_en_button")
                    )
                }
            }
        }

        // Persistent independent prototype footer disclaimer
        Spacer(Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = I18n.get("unofficial_banner"),
                color = Color.Gray,
                fontSize = 11.sp,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.testTag("unoficial_footer")
            )
        }
    }
}

@Composable
fun LanguageButton(
    lang: AppLanguage,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) TropicalGreen else MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(4.dp),
        modifier = modifier.height(38.dp)
    ) {
        Text(
            text = lang.label,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
