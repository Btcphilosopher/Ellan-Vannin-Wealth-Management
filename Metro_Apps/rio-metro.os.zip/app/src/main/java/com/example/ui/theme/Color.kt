package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Branding Colors
val TropicalGreen = Color(0xFF00A859) // Line 2 & general brand green
val AtlanticBlue = Color(0xFF005CA9)  // Line 4 & brand blue
val MetroOrange = Color(0xFFF15A24)   // Line 1 & brand orange/terracotta

// Neutral System
val WarmWhite = Color(0xFFF8F9FA)
val ConcreteGrey = Color(0xFFECEFF1)
val SlateCharcoal = Color(0xFF1E252B)
val DeepBlack = Color(0xFF121417)

// Text & Accents
val HighContrastGold = Color(0xFFFFCC00)
val SoftCoral = Color(0xFFFF6F61)
val MutedSlate = Color(0xFF607D8B)
val SuccessGreen = Color(0xFF2E7D32)
val ErrorRed = Color(0xFFC62828)
val AlertYellow = Color(0xFFFBC02D)

