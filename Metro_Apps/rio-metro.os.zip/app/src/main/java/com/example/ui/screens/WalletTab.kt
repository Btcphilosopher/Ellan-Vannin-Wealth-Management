package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TicketEntity
import com.example.ui.*
import com.example.ui.theme.*
import com.example.viewmodel.MetroViewModel
import com.example.viewmodel.QrValidationState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WalletTab(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val tickets by viewModel.tickets.collectAsState()
    val activeValidationTicketId = viewModel.activeValidationTicketId.value
    val qrState = viewModel.qrValidationState.value

    val currentLang = I18n.currentLanguage.value

    // Partition tickets into Active (PURCHASED, ACTIVATED) and History (USED, EXPIRED, CANCELLED, REFUNDED)
    val activeList = tickets.filter { it.status == "PURCHASED" || it.status == "ACTIVATED" }
    val historyList = tickets.filter { it.status != "PURCHASED" && it.status != "ACTIVATED" }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = I18n.get("wallet"),
            style = MaterialTheme.typography.titleLarge,
            fontSize = 20.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        // QR Validation Gate Simulation dialog overlay (rendered inline elegantly!)
        AnimatedVisibility(
            visible = activeValidationTicketId != null,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            val validationTicket = tickets.find { it.id == activeValidationTicketId }
            if (validationTicket != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("qr_validator_simulator_card"),
                    colors = CardDefaults.cardColors(containerColor = SlateCharcoal),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.QrCodeScanner, contentDescription = null, tint = HighContrastGold)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "Simulador de Catraca",
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontSize = 15.sp
                                )
                            }
                            IconButton(onClick = { viewModel.closeQrValidation() }) {
                                Icon(Icons.Filled.Close, contentDescription = null, tint = Color.LightGray)
                            }
                        }

                        // Ticket details
                        Text(
                            text = "${validationTicket.originCode} → ${validationTicket.destCode}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )

                        // Custom Vector QR Code Graphics representing transit ticket
                        Box(
                            modifier = Modifier
                                .size(140.dp)
                                .background(Color.White, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                repeat(5) { r ->
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        repeat(5) { c ->
                                            val isFilled = (r + c) % 2 == 0 || (r == 0 && c == 0) || (r == 4 && c == 4) || (r == 0 && c == 4) || (r == 4 && c == 0)
                                            Box(
                                                modifier = Modifier
                                                    .size(20.dp)
                                                    .background(if (isFilled) Color.Black else Color.White)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Text(
                            text = "ID: ${validationTicket.id}",
                            color = Color.LightGray,
                            fontSize = 12.sp
                        )

                        // GATE VALIDATOR DISPLAY SCREEN
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.Black),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                val stateTitle = when (qrState) {
                                    QrValidationState.IDLE, QrValidationState.READY -> I18n.get("qr_ready")
                                    QrValidationState.PRESENT -> I18n.get("qr_present")
                                    QrValidationState.VERIFYING -> I18n.get("qr_verifying")
                                    QrValidationState.VALID_AUTHORIZED -> I18n.get("qr_valid")
                                    QrValidationState.ERROR_EXPIRED -> I18n.get("qr_err_expired")
                                    QrValidationState.ERROR_USED -> I18n.get("qr_err_used")
                                    QrValidationState.ERROR_INVALID -> I18n.get("qr_err_invalid")
                                }

                                val stateColor = when (qrState) {
                                    QrValidationState.VALID_AUTHORIZED -> SuccessGreen
                                    QrValidationState.ERROR_EXPIRED, QrValidationState.ERROR_USED, QrValidationState.ERROR_INVALID -> ErrorRed
                                    else -> HighContrastGold
                                }

                                Text(
                                    text = stateTitle,
                                    color = stateColor,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                if (qrState == QrValidationState.VALID_AUTHORIZED) {
                                    Text(
                                        text = I18n.get("qr_authorized"),
                                        color = SuccessGreen,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Scanner trigger
                        if (qrState == QrValidationState.IDLE || qrState == QrValidationState.READY) {
                            Button(
                                onClick = { viewModel.triggerQrScan() },
                                colors = ButtonDefaults.buttonColors(containerColor = HighContrastGold),
                                modifier = Modifier.fillMaxWidth().testTag("scan_qr_button")
                            ) {
                                Text("Aproximar Código", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        } else if (qrState == QrValidationState.VALID_AUTHORIZED) {
                            Button(
                                onClick = { viewModel.closeQrValidation() },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Acessar Plataforma", color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Active tickets list
        Text(
            text = I18n.get("active_tickets"),
            style = MaterialTheme.typography.titleMedium,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        if (activeList.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.CardGiftcard, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                    Text(
                        text = I18n.get("empty_wallet"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                activeList.forEach { ticket ->
                    TicketItemView(
                        ticket = ticket,
                        onActivate = { viewModel.activateTicket(ticket.id) },
                        onShowQr = { viewModel.startQrValidation(ticket.id) },
                        onRefund = { viewModel.refundTicket(ticket.id) }
                    )
                }
            }
        }

        // Historic tickets list
        if (historyList.isNotEmpty()) {
            Text(
                text = I18n.get("expired_tickets"),
                style = MaterialTheme.typography.titleMedium,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                historyList.forEach { ticket ->
                    TicketItemView(
                        ticket = ticket,
                        onActivate = {},
                        onShowQr = {},
                        onRefund = {}
                    )
                }
            }
        }
    }
}

@Composable
fun TicketItemView(
    ticket: TicketEntity,
    onActivate: () -> Unit,
    onShowQr: () -> Unit,
    onRefund: () -> Unit
) {
    val currentLang = I18n.currentLanguage.value
    val ticketType = if (currentLang == AppLanguage.PT_BR) ticket.ticketTypePt else if (currentLang == AppLanguage.ES) ticket.ticketTypeEs else ticket.ticketTypeEn
    val originName = if (currentLang == AppLanguage.PT_BR) ticket.originNamePt else if (currentLang == AppLanguage.ES) ticket.originNameEs else ticket.originNameEn
    val destName = if (currentLang == AppLanguage.PT_BR) ticket.destNamePt else if (currentLang == AppLanguage.ES) ticket.destNameEs else ticket.destNameEn

    val statusColor = when (ticket.status) {
        "PURCHASED" -> AtlanticBlue
        "ACTIVATED" -> TropicalGreen
        "USED" -> Color.Gray
        "EXPIRED" -> ErrorRed
        "REFUNDED" -> Color.DarkGray
        else -> Color.DarkGray
    }

    val statusLabel = when (ticket.status) {
        "PURCHASED" -> "Disponível"
        "ACTIVATED" -> I18n.get("valid_ticket")
        "USED" -> I18n.get("used_ticket")
        "EXPIRED" -> I18n.get("expired_ticket")
        "REFUNDED" -> I18n.get("refunded_ticket")
        else -> ticket.status
    }

    Card(
        modifier = Modifier.fillMaxWidth().testTag("ticket_item_${ticket.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = ticketType, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(text = "Passageiro: ${ticket.passengerName}", fontSize = 11.sp, color = Color.Gray)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(statusColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text = statusLabel, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Route Details Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "$originName (${ticket.originCode})", fontSize = 13.sp)
                    Text(text = "↓", fontSize = 12.sp, color = Color.Gray)
                    Text(text = "$destName (${ticket.destCode})", fontSize = 13.sp)
                }
                Text(
                    text = "R$ ${String.format("%.2f", ticket.price)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Validity Countdown timers if activated
            if (ticket.status == "ACTIVATED" && ticket.expiryTimestamp != null) {
                val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
                val expString = formatter.format(Date(ticket.expiryTimestamp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Timer, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "Válido até $expString",
                        color = SuccessGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Action Buttons
            if (ticket.status == "PURCHASED" || ticket.status == "ACTIVATED") {
                Divider(color = MaterialTheme.colorScheme.outlineVariant)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (ticket.status == "PURCHASED") {
                        TextButton(onClick = onRefund, modifier = Modifier.testTag("refund_ticket_button_${ticket.id}")) {
                            Text(I18n.get("refund_ticket"), color = ErrorRed, fontSize = 12.sp)
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = onActivate,
                            colors = ButtonDefaults.buttonColors(containerColor = AtlanticBlue),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(32.dp).testTag("activate_ticket_button_${ticket.id}")
                        ) {
                            Text(I18n.get("activate_ticket"), fontSize = 12.sp, color = Color.White)
                        }
                    } else if (ticket.status == "ACTIVATED") {
                        Button(
                            onClick = onShowQr,
                            colors = ButtonDefaults.buttonColors(containerColor = TropicalGreen),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.height(32.dp).testTag("show_qr_button_${ticket.id}")
                        ) {
                            Icon(Icons.Filled.QrCode, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(Modifier.width(4.dp))
                            Text("QR Code", fontSize = 12.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
