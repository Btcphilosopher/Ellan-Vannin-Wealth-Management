package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.theme.*
import com.example.viewmodel.MainTab
import com.example.viewmodel.MetroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTab(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val stations by viewModel.stations.collectAsState()
    val transportCards by viewModel.transportCards.collectAsState()
    val isJourneyRunning = viewModel.isJourneyRunning.value
    val activeJourneyPlan = viewModel.activeJourneyPlan.value
    val activeNodeIndex = viewModel.activeJourneyNodeIndex.value

    val primaryCard = transportCards.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Branding Tagline
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "RIO METRO.OS",
                fontSize = 24.sp,
                style = MaterialTheme.typography.titleLarge,
                color = TropicalGreen,
                modifier = Modifier.testTag("app_brand_title")
            )
            Text(
                text = I18n.get("tagline"),
                fontSize = 14.sp,
                color = Color.Gray,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        // Active Journey Simulator Widget
        AnimatedVisibility(
            visible = isJourneyRunning && activeJourneyPlan != null,
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut()
        ) {
            activeJourneyPlan?.let { plan ->
                val totalLegs = plan.legs
                // Flatten all station names across legs
                val allStationsPt = plan.legs.flatMap { it.stationNamesPt }.distinct()
                val allStationsEs = plan.legs.flatMap { it.stationNamesEs }.distinct()
                val allStationsEn = plan.legs.flatMap { it.stationNamesEn }.distinct()
                
                val currentStationName = when (I18n.currentLanguage.value) {
                    AppLanguage.PT_BR -> allStationsPt.getOrNull(activeNodeIndex) ?: "Final"
                    AppLanguage.ES -> allStationsEs.getOrNull(activeNodeIndex) ?: "Final"
                    AppLanguage.EN -> allStationsEn.getOrNull(activeNodeIndex) ?: "Final"
                }

                val nextStationName = when (I18n.currentLanguage.value) {
                    AppLanguage.PT_BR -> allStationsPt.getOrNull(activeNodeIndex + 1) ?: "Chegada"
                    AppLanguage.ES -> allStationsEs.getOrNull(activeNodeIndex + 1) ?: "Llegada"
                    AppLanguage.EN -> allStationsEn.getOrNull(activeNodeIndex + 1) ?: "Arrival"
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = SlateCharcoal),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("active_journey_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.DirectionsTransit, contentDescription = null, tint = HighContrastGold)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = I18n.get("active_journey"),
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontSize = 16.sp
                            )
                        }

                        // Origin -> Dest Header
                        val currentLang = I18n.currentLanguage.value
                        val originName = stations.find { it.id == plan.originId }?.let {
                            if (currentLang == AppLanguage.PT_BR) it.namePt else if (currentLang == AppLanguage.ES) it.nameEs else it.nameEn
                        } ?: plan.originId

                        val destName = stations.find { it.id == plan.destId }?.let {
                            if (currentLang == AppLanguage.PT_BR) it.namePt else if (currentLang == AppLanguage.ES) it.nameEs else it.nameEn
                        } ?: plan.destId

                        Text(
                            text = "$originName → $destName",
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge,
                            fontSize = 18.sp
                        )

                        // Real Stop-by-Stop Progress Gauges
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "Atual: $currentStationName",
                                    color = HighContrastGold,
                                    fontSize = 13.sp,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "Próxima: $nextStationName",
                                    color = Color.LightGray,
                                    fontSize = 13.sp,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }

                            // Horizontal progression bar
                            val progress = if (plan.totalStops > 0) activeNodeIndex.toFloat() / plan.totalStops else 1f
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                color = TropicalGreen,
                                trackColor = Color.DarkGray
                            )

                            Text(
                                text = "${plan.totalStops - activeNodeIndex} ${I18n.get("stops_remaining")}",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }

                        // Simulation control actions
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.progressJourney() },
                                colors = ButtonDefaults.buttonColors(containerColor = TropicalGreen),
                                modifier = Modifier.weight(1f).testTag("progress_journey_button")
                            ) {
                                Text(
                                    text = if (activeNodeIndex < plan.totalStops) "Próxima Estação" else "Finalizar",
                                    fontSize = 12.sp
                                )
                            }
                            Button(
                                onClick = { viewModel.cancelJourney() },
                                colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                modifier = Modifier.weight(0.8f).testTag("cancel_journey_button")
                            ) {
                                Text("Sair", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Main Quick Journey Search Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("quick_journey_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = I18n.get("where_to"),
                    fontSize = 18.sp,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )

                // Origin drop-down
                var originExpanded by remember { mutableStateOf(false) }
                Box {
                    val currentLang = I18n.currentLanguage.value
                    val currentOriginName = stations.find { it.id == viewModel.originStationId.value }?.let {
                        if (currentLang == AppLanguage.PT_BR) it.namePt else if (currentLang == AppLanguage.ES) it.nameEs else it.nameEn
                    } ?: I18n.get("origin")

                    OutlinedTextField(
                        value = currentOriginName,
                        onValueChange = {},
                        label = { Text(I18n.get("origin")) },
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().clickable { originExpanded = true },
                        enabled = false,
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledTextColor = MaterialTheme.colorScheme.onSurface,
                            disabledLabelColor = MaterialTheme.colorScheme.primary,
                            disabledBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                    DropdownMenu(
                        expanded = originExpanded,
                        onDismissRequest = { originExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        stations.forEach { station ->
                            val name = if (currentLang == AppLanguage.PT_BR) station.namePt else if (currentLang == AppLanguage.ES) station.nameEs else station.nameEn
                            DropdownMenuItem(
                                text = { Text("$name (${station.code})") },
                                onClick = {
                                    viewModel.setOrigin(station.id)
                                    originExpanded = false
                                }
                            )
                        }
                    }
                }

                // Destination drop-down
                var destExpanded by remember { mutableStateOf(false) }
                Box {
                    val currentLang = I18n.currentLanguage.value
                    val currentDestName = stations.find { it.id == viewModel.destStationId.value }?.let {
                        if (currentLang == AppLanguage.PT_BR) it.namePt else if (currentLang == AppLanguage.ES) it.nameEs else it.nameEn
                    } ?: I18n.get("destination")

                    OutlinedTextField(
                        value = currentDestName,
                        onValueChange = {},
                        label = { Text(I18n.get("destination")) },
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().clickable { destExpanded = true },
                        enabled = false,
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledTextColor = MaterialTheme.colorScheme.onSurface,
                            disabledLabelColor = MaterialTheme.colorScheme.primary,
                            disabledBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                    DropdownMenu(
                        expanded = destExpanded,
                        onDismissRequest = { destExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        stations.forEach { station ->
                            val name = if (currentLang == AppLanguage.PT_BR) station.namePt else if (currentLang == AppLanguage.ES) station.nameEs else station.nameEn
                            DropdownMenuItem(
                                text = { Text("$name (${station.code})") },
                                onClick = {
                                    viewModel.setDestination(station.id)
                                    destExpanded = false
                                }
                            )
                        }
                    }
                }

                // Accessible Route Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Accessible, contentDescription = null, tint = TropicalGreen)
                        Spacer(Modifier.width(8.dp))
                        Text(I18n.get("accessibility"), style = MaterialTheme.typography.bodyMedium)
                    }
                    Switch(
                        checked = viewModel.planAccessibleOnly.value,
                        onCheckedChange = { viewModel.toggleAccessibleOnly(it) }
                    )
                }

                Button(
                    onClick = {
                        viewModel.triggerPathPlanning()
                        viewModel.currentTab.value = MainTab.PLAN
                    },
                    modifier = Modifier.fillMaxWidth().testTag("plan_journey_submit"),
                    colors = ButtonDefaults.buttonColors(containerColor = TropicalGreen)
                ) {
                    Text(I18n.get("plan_button"), color = Color.White)
                }
            }
        }

        // Quick Actions Grid
        Text(
            text = I18n.get("quick_actions"),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            QuickActionItem(
                title = I18n.get("buy_ticket"),
                icon = Icons.Filled.LocalMall,
                modifier = Modifier.weight(1f),
                onClick = {
                    viewModel.buyOriginId.value = viewModel.originStationId.value
                    viewModel.buyDestId.value = viewModel.destStationId.value
                    viewModel.currentTab.value = MainTab.BUY
                }
            )
            QuickActionItem(
                title = I18n.get("show_ticket"),
                icon = Icons.Filled.QrCode,
                modifier = Modifier.weight(1f),
                onClick = { viewModel.currentTab.value = MainTab.WALLET }
            )
            QuickActionItem(
                title = I18n.get("explore_stations"),
                icon = Icons.Filled.NearMe,
                modifier = Modifier.weight(1f),
                onClick = { viewModel.currentTab.value = MainTab.MORE }
            )
        }

        // Simulated GIRO Transport Card Wallet Card
        primaryCard?.let { card ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AtlanticBlue)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = card.type, color = Color.White, style = MaterialTheme.typography.titleMedium)
                        Icon(Icons.Filled.Contactless, contentDescription = null, tint = Color.White)
                    }

                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "R$ ${String.format("%.2f", card.balance)}",
                        color = Color.White,
                        fontSize = 28.sp,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(text = "Nº ${card.number}", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)

                    Divider(color = Color.White.copy(alpha = 0.2f), modifier = Modifier.padding(vertical = 4.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = { viewModel.topUpGiroCard(10.0) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+ R$10", color = Color.White, fontSize = 11.sp)
                        }
                        Button(
                            onClick = { viewModel.topUpGiroCard(20.0) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+ R$20", color = Color.White, fontSize = 11.sp)
                        }
                        Button(
                            onClick = { viewModel.topUpGiroCard(50.0) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+ R$50", color = Color.White, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(80.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = TropicalGreen, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(4.dp))
            Text(title, fontSize = 11.sp, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}
