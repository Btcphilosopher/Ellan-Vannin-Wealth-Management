package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val namePt: String,
    val nameEs: String,
    val nameEn: String,
    val code: String,
    val lines: String, // Comma separated list like "L1, L2"
    val accessible: Boolean,
    val elevatorsOk: Boolean,
    val escalatorsOk: Boolean,
    val openingHoursPt: String,
    val openingHoursEs: String,
    val openingHoursEn: String,
    val latitude: Double,
    val longitude: Double,
    val provenance: String = "REAL" // REAL, SYNTHETIC, etc.
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val originCode: String,
    val originNamePt: String,
    val originNameEs: String,
    val originNameEn: String,
    val destCode: String,
    val destNamePt: String,
    val destNameEs: String,
    val destNameEn: String,
    val purchaseTimestamp: Long,
    val activationTimestamp: Long? = null,
    val expiryTimestamp: Long? = null,
    val price: Double,
    val status: String, // CREATED, PURCHASED, ACTIVATED, VALID, USED, EXPIRED, CANCELLED, REFUNDED
    val qrCode: String,
    val ticketTypePt: String,
    val ticketTypeEs: String,
    val ticketTypeEn: String,
    val passengerName: String,
    val provenance: String = "DEMONSTRATION"
)

@Entity(tableName = "alerts")
data class AlertEntity(
    @PrimaryKey val id: String,
    val lineCode: String, // L1, L2, L4
    val severity: String, // NORMAL, MINOR, MAJOR, CRITICAL
    val titlePt: String,
    val titleEs: String,
    val titleEn: String,
    val descPt: String,
    val descEs: String,
    val descEn: String,
    val timestamp: Long,
    val provenance: String = "DEMONSTRATION"
)

@Entity(tableName = "transport_cards")
data class TransportCardEntity(
    @PrimaryKey val id: String,
    val number: String,
    val balance: Double,
    val type: String, // Giro, Bilhete Unico
    val lastTopUpTimestamp: Long? = null
)
