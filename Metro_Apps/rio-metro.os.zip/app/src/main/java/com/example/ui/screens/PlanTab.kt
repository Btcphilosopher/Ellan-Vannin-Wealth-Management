package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.theme.*
import com.example.viewmodel.MainTab
import com.example.viewmodel.MetroViewModel

@Composable
fun PlanTab(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val stations by viewModel.stations.collectAsState()
    val tickets by viewModel.tickets.collectAsState()
    val plan = viewModel.plannedJourney.value

    val currentLang = I18n.currentLanguage.value

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = I18n.get("plan_button"),
            style = MaterialTheme.typography.titleLarge,
            fontSize = 20.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        // Trip Details Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.MyLocation, contentDescription = null, tint = TropicalGreen)
                    Spacer(Modifier.width(8.dp))
                    val origName = stations.find { it.id == viewModel.originStationId.value }?.let {
                        if (currentLang == AppLanguage.PT_BR) it.namePt else if (currentLang == AppLanguage.ES) it.nameEs else it.nameEn
                    } ?: "Botafogo"
                    Text("Origem: $origName", fontSize = 14.sp)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Place, contentDescription = null, tint = ErrorRed)
                    Spacer(Modifier.width(8.dp))
                    val destName = stations.find { it.id == viewModel.destStationId.value }?.let {
                        if (currentLang == AppLanguage.PT_BR) it.namePt else if (currentLang == AppLanguage.ES) it.nameEs else it.nameEn
                    } ?: "Central"
                    Text("Destino: $destName", fontSize = 14.sp)
                }
            }
        }

        if (plan == null) {
            // No route found / same origin & dest
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.AltRoute, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                    Text(
                        text = "Selecione estações de origem e destino diferentes para ver rotas.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                }
            }
        } else {
            // Display Route details
            Card(
                modifier = Modifier.fillMaxWidth().testTag("route_plan_result_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Summary row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${plan.durationMinutes} min",
                                style = MaterialTheme.typography.titleLarge,
                                color = TropicalGreen,
                                fontSize = 24.sp
                            )
                            Text(
                                text = "${plan.totalStops} ${I18n.get("stops")} • ${plan.transfers} ${I18n.get("transfers")}",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        Text(
                            text = "R$ ${String.format("%.2f", plan.fare)}",
                            fontSize = 18.sp,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Accessibility badge
                    if (plan.isAccessible) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(SuccessGreen.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Filled.Accessible, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(I18n.get("accessible_route"), color = SuccessGreen, fontSize = 12.sp)
                        }
                    }

                    // Line Connection Diagram Tree!
                    Column(
                        modifier = Modifier.padding(start = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        plan.legs.forEachIndexed { index, leg ->
                            val lineCol = when (leg.lineCode) {
                                "L1" -> Color(0xFFF15A24)
                                "L2" -> Color(0xFF00A859)
                                "L4" -> Color(0xFF005CA9)
                                else -> Color.DarkGray
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Left colored dot & track line
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(24.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(lineCol)
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .width(4.dp)
                                            .height(30.dp)
                                            .background(lineCol.copy(alpha = 0.6f))
                                    )
                                }

                                Spacer(Modifier.width(12.dp))

                                // Right node text details
                                val startStName = stations.find { it.id == leg.startStationId }?.let {
                                    if (currentLang == AppLanguage.PT_BR) it.namePt else if (currentLang == AppLanguage.ES) it.nameEs else it.nameEn
                                } ?: leg.startStationId

                                val endStName = stations.find { it.id == leg.endStationId }?.let {
                                    if (currentLang == AppLanguage.PT_BR) it.namePt else if (currentLang == AppLanguage.ES) it.nameEs else it.nameEn
                                } ?: leg.endStationId

                                Column {
                                    Text(text = startStName, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 14.sp)
                                    Text(
                                        text = "${leg.lineName} (${leg.lineCode}) • ${leg.stopsCount} ${I18n.get("stops")}",
                                        fontSize = 12.sp,
                                        color = lineCol
                                    )
                                    Text(text = "↓", fontSize = 12.sp, color = Color.Gray)
                                    Text(text = endStName, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        }
                    }

                    // CHECK FOR ACTIVE TICKET COVERAGE AND INDICATE IF AN ADDITIONAL TICKET IS REQUIRED
                    // Find any active, valid ticket (PURCHASED or ACTIVATED) covering this route
                    val coverageTicket = tickets.find {
                        (it.status == "PURCHASED" || it.status == "ACTIVATED") &&
                        it.originCode.equals(plan.originId, ignoreCase = true) ||
                        it.originCode.equals(stations.find { s -> s.id == plan.originId }?.code, ignoreCase = true)
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    if (coverageTicket != null) {
                        // User has coverage! Show green success pill
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SuccessGreen.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SuccessGreen)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = I18n.get("has_ticket"),
                                    color = SuccessGreen,
                                    fontSize = 13.sp,
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                )
                                Text(
                                    text = "Bilhete ativo: ${coverageTicket.id} (${coverageTicket.ticketTypePt})",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }

                        // Activate / Travel simulator button
                        if (coverageTicket.status == "PURCHASED") {
                            Button(
                                onClick = {
                                    viewModel.activateTicket(coverageTicket.id)
                                    viewModel.currentTab.value = MainTab.WALLET
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = TropicalGreen),
                                modifier = Modifier.fillMaxWidth().testTag("activate_coverage_ticket_button")
                            ) {
                                Text(I18n.get("activate_ticket"))
                            }
                        } else {
                            Button(
                                onClick = {
                                    // Start validator simulation right away!
                                    viewModel.startQrValidation(coverageTicket.id)
                                    viewModel.currentTab.value = MainTab.WALLET
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = TropicalGreen),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(I18n.get("simulate_scan"))
                            }
                        }
                    } else {
                        // User has no valid coverage ticket for this route. Warn and redirect to purchase
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ErrorRed.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = ErrorRed)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = I18n.get("no_ticket_warning"),
                                color = ErrorRed,
                                fontSize = 13.sp,
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.buyOriginId.value = plan.originId
                                viewModel.buyDestId.value = plan.destId
                                viewModel.currentTab.value = MainTab.BUY
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TropicalGreen),
                            modifier = Modifier.fillMaxWidth().testTag("buy_route_ticket_button")
                        ) {
                            Text(I18n.get("buy_ticket"))
                        }
                    }
                }
            }
        }
    }
}
