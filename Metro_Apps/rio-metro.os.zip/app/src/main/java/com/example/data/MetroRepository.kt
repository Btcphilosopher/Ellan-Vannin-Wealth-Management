package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import java.util.UUID

data class JourneyLeg(
    val lineCode: String, // L1, L2, L4
    val lineName: String,
    val startStationId: String,
    val endStationId: String,
    val stopsCount: Int,
    val stationNamesPt: List<String>,
    val stationNamesEs: List<String>,
    val stationNamesEn: List<String>
)

data class JourneyPlan(
    val originId: String,
    val destId: String,
    val legs: List<JourneyLeg>,
    val durationMinutes: Int,
    val transfers: Int,
    val totalStops: Int,
    val fare: Double,
    val isAccessible: Boolean
)

class MetroRepository(private val dao: MetroDao) {

    val allStations: Flow<List<StationEntity>> = dao.getAllStationsFlow()
    val allTickets: Flow<List<TicketEntity>> = dao.getAllTicketsFlow()
    val allAlerts: Flow<List<AlertEntity>> = dao.getAllAlertsFlow()
    val allTransportCards: Flow<List<TransportCardEntity>> = dao.getAllTransportCardsFlow()

    suspend fun seedIfNeeded() {
        val currentStations = dao.getAllStations()
        if (currentStations.isEmpty()) {
            val seedStations = listOf(
                // Line 4 Stations
                StationEntity("jardim_oceanico", "Jardim Oceânico", "Jardim Oceânico", "Jardim Oceanico", "JOC", "L4", true, true, true, "05:00 às 00:10", "05:00 a 00:10", "05:00 AM to 12:10 AM", -23.0076, -43.3059),
                StationEntity("sau_conrado", "São Conrado", "São Conrado", "Sao Conrado", "SCD", "L4", true, true, true, "05:00 às 00:05", "05:00 a 00:05", "05:00 AM to 12:05 AM", -22.9922, -43.2523),
                StationEntity("antero_de_quental", "Antero de Quental", "Antero de Quental", "Antero de Quental", "ADQ", "L4", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9850, -43.2229),
                StationEntity("jardim_de_alah", "Jardim de Alah", "Jardim de Alah", "Jardim de Alah", "JDA", "L4", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9825, -43.2147),
                StationEntity("nossa_senhora_da_paz", "Nossa Senhora da Paz", "Nossa Senhora da Paz", "Nossa Senhora da Paz", "NSP", "L4", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9837, -43.2065),
                
                // Line 1 / L4 Interchange
                StationEntity("general_osorio", "General Osório", "General Osório", "General Osorio", "GOS", "L1, L4", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9847, -43.1971),
                
                // Line 1 Stations
                StationEntity("cantagalo", "Cantagalo", "Cantagalo", "Cantagalo", "CTG", "L1", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9763, -43.1927),
                StationEntity("siqueira_campos", "Siqueira Campos", "Siqueira Campos", "Siqueira Campos", "SCP", "L1", true, true, false, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9672, -43.1895),
                StationEntity("cardeal_arcoverde", "Cardeal Arcoverde", "Cardeal Arcoverde", "Cardeal Arcoverde", "CAV", "L1", false, false, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9646, -43.1793),
                StationEntity("botafogo", "Botafogo", "Botafogo", "Botafogo", "BTF", "L1, L2", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9512, -43.1911),
                StationEntity("flamengo", "Flamengo", "Flamengo", "Flamengo", "FLM", "L1, L2", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9376, -43.1788),
                StationEntity("carioca", "Carioca", "Carioca", "Carioca", "CRC", "L1, L2", true, true, true, "05:00 às 05:00", "24hs", "24 Hours", -22.9071, -43.1789),
                StationEntity("central", "Central do Brasil", "Central de Brasil", "Central", "CEN", "L1, L2", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9031, -43.1915),
                StationEntity("uruguai", "Uruguai", "Uruguai", "Uruguai", "URG", "L1", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9315, -43.2393),
                
                // Line 2 Stations
                StationEntity("maracana", "Maracanã", "Maracaná", "Maracana", "MCN", "L2", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.9099, -43.2301),
                StationEntity("pavuna", "Pavuna", "Pavuna", "Pavuna", "PVN", "L2", true, true, true, "05:00 às 00:00", "05:00 a 00:00", "05:00 AM to 12:00 AM", -22.8068, -43.3643)
            )
            dao.insertStations(seedStations)

            // Initial simulated GIRO Card
            val seedCard = TransportCardEntity(
                id = "giro_main",
                number = "8021 5493 0210",
                balance = 25.00,
                type = "Giro MetrôRio",
                lastTopUpTimestamp = System.currentTimeMillis()
            )
            dao.insertTransportCard(seedCard)

            // Initial service alerts (some synthetic alerts)
            val seedAlerts = listOf(
                AlertEntity(
                    id = "alert_1",
                    lineCode = "L2",
                    severity = "MINOR",
                    titlePt = "Trabalhos de manutenção programada",
                    titleEs = "Trabajos de mantenimiento programado",
                    titleEn = "Scheduled maintenance works",
                    descPt = "Intervalos ligeiramente maiores entre as estações Pavuna e Central.",
                    descEs = "Intervalos ligeramente mayores entre las estaciones Pavuna y Central.",
                    descEn = "Slightly longer headways between Pavuna and Central stations.",
                    timestamp = System.currentTimeMillis() - 3600 * 1000
                ),
                AlertEntity(
                    id = "alert_2",
                    lineCode = "L1",
                    severity = "NORMAL",
                    titlePt = "Operação normal",
                    titleEs = "Operación normal",
                    titleEn = "Normal operations",
                    descPt = "A Linha 1 opera com fluxo de trens regular e sem atrasos.",
                    descEs = "La Línea 1 opera con flujo de trenes regular sin retrasos.",
                    descEn = "Line 1 is operating with regular train flows and no delays.",
                    timestamp = System.currentTimeMillis()
                ),
                AlertEntity(
                    id = "alert_3",
                    lineCode = "L4",
                    severity = "NORMAL",
                    titlePt = "Operação normal",
                    titleEs = "Operación normal",
                    titleEn = "Normal operations",
                    descPt = "A Linha 4 opera com fluxo regular em todas as estações.",
                    descEs = "La Línea 4 opera con flujo regular en todas las estaciones.",
                    descEn = "Line 4 is operating normally at all stations.",
                    timestamp = System.currentTimeMillis()
                )
            )
            dao.insertAlerts(seedAlerts)
        }
    }

    suspend fun addTicket(
        origin: StationEntity,
        dest: StationEntity,
        price: Double,
        passengerName: String,
        typePt: String,
        typeEs: String,
        typeEn: String
    ): TicketEntity {
        val ticketId = "TKT-" + UUID.randomUUID().toString().take(8).uppercase()
        val qrCodeValue = "RIOMETROOS|${ticketId}|${origin.code}|${dest.code}|${System.currentTimeMillis()}"
        val newTicket = TicketEntity(
            id = ticketId,
            originCode = origin.code,
            originNamePt = origin.namePt,
            originNameEs = origin.nameEs,
            originNameEn = origin.nameEn,
            destCode = dest.code,
            destNamePt = dest.namePt,
            destNameEs = dest.nameEs,
            destNameEn = dest.nameEn,
            purchaseTimestamp = System.currentTimeMillis(),
            price = price,
            status = "PURCHASED",
            qrCode = qrCodeValue,
            ticketTypePt = typePt,
            ticketTypeEs = typeEs,
            ticketTypeEn = typeEn,
            passengerName = passengerName
        )
        dao.insertTicket(newTicket)
        return newTicket
    }

    suspend fun getTicketById(id: String): TicketEntity? {
        return dao.getTicketById(id)
    }

    suspend fun activateTicket(id: String): Boolean {
        val ticket = dao.getTicketById(id) ?: return false
        if (ticket.status == "PURCHASED") {
            val now = System.currentTimeMillis()
            val expiry = now + (2 * 3600 * 1000) // Valid for 2 hours
            val updated = ticket.copy(
                status = "ACTIVATED",
                activationTimestamp = now,
                expiryTimestamp = expiry
            )
            dao.updateTicket(updated)
            return true
        }
        return false
    }

    suspend fun validateTicket(id: String): Pair<Boolean, String> {
        val ticket = dao.getTicketById(id) ?: return Pair(false, "INVALID_QR")
        val now = System.currentTimeMillis()
        
        if (ticket.status == "USED") {
            return Pair(false, "ALREADY_USED")
        }
        if (ticket.status == "EXPIRED" || (ticket.expiryTimestamp != null && now > ticket.expiryTimestamp)) {
            if (ticket.status != "EXPIRED") {
                dao.updateTicket(ticket.copy(status = "EXPIRED"))
            }
            return Pair(false, "EXPIRED")
        }
        if (ticket.status == "CANCELLED" || ticket.status == "REFUNDED") {
            return Pair(false, "CANCELLED")
        }

        // Complete the validation
        val updated = ticket.copy(status = "USED")
        dao.updateTicket(updated)
        return Pair(true, "SUCCESS")
    }

    suspend fun refundTicket(id: String): Boolean {
        val ticket = dao.getTicketById(id) ?: return false
        if (ticket.status == "PURCHASED") {
            val updated = ticket.copy(status = "REFUNDED")
            dao.updateTicket(updated)
            return true
        }
        return false
    }

    suspend fun topUpTransportCard(id: String, amount: Double): Boolean {
        val card = dao.getTransportCardById(id) ?: return false
        val updated = card.copy(
            balance = card.balance + amount,
            lastTopUpTimestamp = System.currentTimeMillis()
        )
        dao.updateTransportCard(updated)
        return true
    }

    suspend fun deductTransportCard(id: String, amount: Double): Boolean {
        val card = dao.getTransportCardById(id) ?: return false
        if (card.balance >= amount) {
            val updated = card.copy(
                balance = card.balance - amount
            )
            dao.updateTransportCard(updated)
            return true
        }
        return false
    }

    // Dynamic Route Planning BFS algorithm!
    // We map station IDs to adjacent stations along their lines
    fun findJourneyPlan(
        originId: String,
        destId: String,
        accessibleOnly: Boolean,
        stationsList: List<StationEntity>
    ): JourneyPlan? {
        val stationMap = stationsList.associateBy { it.id }
        val origin = stationMap[originId] ?: return null
        val dest = stationMap[destId] ?: return null

        if (originId == destId) return null

        // Adjacency connections representing MetrôRio lines layout
        // Line 4 Layout: JOC - SCD - ADQ - JDA - NSP - GOS
        // Line 1 Layout: URG - CEN - CRC - FLM - BTF - CAV - SCP - CTG - GOS
        // Line 2 Layout: PVN - MCN - SCR - CEN - CRC - BTF
        val connections = mapOf(
            "jardim_oceanico" to listOf("sau_conrado"),
            "sau_conrado" to listOf("jardim_oceanico", "antero_de_quental"),
            "antero_de_quental" to listOf("sau_conrado", "jardim_de_alah"),
            "jardim_de_alah" to listOf("antero_de_quental", "nossa_senhora_da_paz"),
            "nossa_senhora_da_paz" to listOf("jardim_de_alah", "general_osorio"),
            "general_osorio" to listOf("nossa_senhora_da_paz", "cantagalo"),
            
            "cantagalo" to listOf("general_osorio", "siqueira_campos"),
            "siqueira_campos" to listOf("cantagalo", "cardeal_arcoverde"),
            "cardeal_arcoverde" to listOf("siqueira_campos", "botafogo"),
            
            "botafogo" to listOf("cardeal_arcoverde", "flamengo"),
            "flamengo" to listOf("botafogo", "carioca"),
            "carioca" to listOf("flamengo", "central"),
            "central" to listOf("carioca", "uruguai", "maracana"),
            "uruguai" to listOf("central"),
            
            "maracana" to listOf("central", "pavuna"),
            "pavuna" to listOf("maracana")
        )

        // Queue for BFS path search. Queue holds full path list of Station IDs.
        val queue = ArrayDeque<List<String>>()
        queue.add(listOf(originId))
        
        val visited = mutableSetOf<String>()
        visited.add(originId)

        var shortestPath: List<String>? = null

        while (queue.isNotEmpty()) {
            val path = queue.removeFirst()
            val last = path.last()

            if (last == destId) {
                shortestPath = path
                break
            }

            val neighbors = connections[last] ?: emptyList()
            for (neighbor in neighbors) {
                // If filtering by accessibility
                if (accessibleOnly) {
                    val stationNode = stationMap[neighbor]
                    if (stationNode != null && !stationNode.accessible) {
                        continue // Skip inaccessible station
                    }
                }

                if (neighbor !in visited) {
                    visited.add(neighbor)
                    val newPath = path + neighbor
                    queue.add(newPath)
                }
            }
        }

        val path = shortestPath ?: return null

        // Group path into Line Segments (legs)
        // Helper to determine line of a link
        fun getLineForLink(fromId: String, toId: String): String {
            val fromSt = stationMap[fromId]!!
            val toSt = stationMap[toId]!!
            val linesFrom = fromSt.lines.split(",").map { it.trim() }
            val linesTo = toSt.lines.split(",").map { it.trim() }
            val commonLines = linesFrom.intersect(linesTo.toSet())
            return when {
                commonLines.contains("L4") -> "L4"
                commonLines.contains("L2") -> "L2"
                commonLines.contains("L1") -> "L1"
                else -> linesFrom.firstOrNull() ?: "L1"
            }
        }

        val legs = mutableListOf<JourneyLeg>()
        var currentLegStationIds = mutableListOf<String>()
        var currentLineCode = ""

        for (i in 0 until path.size - 1) {
            val linkLine = getLineForLink(path[i], path[i + 1])
            if (currentLegStationIds.isEmpty()) {
                currentLegStationIds.add(path[i])
                currentLegStationIds.add(path[i + 1])
                currentLineCode = linkLine
            } else if (linkLine == currentLineCode) {
                currentLegStationIds.add(path[i + 1])
            } else {
                // Finalize old leg
                val legOrigin = currentLegStationIds.first()
                val legDest = currentLegStationIds.last()
                val namesPt = currentLegStationIds.map { stationMap[it]!!.namePt }
                val namesEs = currentLegStationIds.map { stationMap[it]!!.nameEs }
                val namesEn = currentLegStationIds.map { stationMap[it]!!.nameEn }
                legs.add(
                    JourneyLeg(
                        lineCode = currentLineCode,
                        lineName = when(currentLineCode) {
                            "L1" -> "Linha 1"
                            "L2" -> "Linha 2"
                            "L4" -> "Linha 4"
                            else -> "Linha 1"
                        },
                        startStationId = legOrigin,
                        endStationId = legDest,
                        stopsCount = currentLegStationIds.size - 1,
                        stationNamesPt = namesPt,
                        stationNamesEs = namesEs,
                        stationNamesEn = namesEn
                    )
                )

                // Start new leg
                currentLegStationIds = mutableListOf(path[i], path[i + 1])
                currentLineCode = linkLine
            }
        }

        // Finalize last leg
        if (currentLegStationIds.isNotEmpty()) {
            val legOrigin = currentLegStationIds.first()
            val legDest = currentLegStationIds.last()
            val namesPt = currentLegStationIds.map { stationMap[it]!!.namePt }
            val namesEs = currentLegStationIds.map { stationMap[it]!!.nameEs }
            val namesEn = currentLegStationIds.map { stationMap[it]!!.nameEn }
            legs.add(
                JourneyLeg(
                    lineCode = currentLineCode,
                    lineName = when(currentLineCode) {
                        "L1" -> "Linha 1"
                        "L2" -> "Linha 2"
                        "L4" -> "Linha 4"
                        else -> "Linha 1"
                    },
                    startStationId = legOrigin,
                    endStationId = legDest,
                    stopsCount = currentLegStationIds.size - 1,
                    stationNamesPt = namesPt,
                    stationNamesEs = namesEs,
                    stationNamesEn = namesEn
                )
            )
        }

        val totalStops = path.size - 1
        val transfers = legs.size - 1
        val totalDurationMinutes = totalStops * 2 + transfers * 4 // 2 mins per stop, 4 mins transfer
        val syntheticFare = 7.50 + (transfers * 1.50) // Base R$ 7.50, +R$ 1.50 per transfer

        val pathAccessible = path.all { stationMap[it]!!.accessible }

        return JourneyPlan(
            originId = originId,
            destId = destId,
            legs = legs,
            durationMinutes = totalDurationMinutes,
            transfers = transfers,
            totalStops = totalStops,
            fare = syntheticFare,
            isAccessible = pathAccessible
        )
    }
}
