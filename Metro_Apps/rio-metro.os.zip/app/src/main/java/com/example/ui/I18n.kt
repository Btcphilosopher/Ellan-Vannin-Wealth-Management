package com.example.ui

import androidx.compose.runtime.mutableStateOf

enum class AppLanguage(val code: String, val label: String) {
    PT_BR("pt-BR", "Português"),
    ES("es", "Español"),
    EN("en", "English")
}

object I18n {
    val currentLanguage = mutableStateOf(AppLanguage.PT_BR)

    private val translations = mapOf(
        "tagline" to mapOf(
            AppLanguage.PT_BR to "A cidade em movimento.",
            AppLanguage.ES to "La ciudad en movimiento.",
            AppLanguage.EN to "The city in motion."
        ),
        "home" to mapOf(
            AppLanguage.PT_BR to "Início",
            AppLanguage.ES to "Inicio",
            AppLanguage.EN to "Home"
        ),
        "plan" to mapOf(
            AppLanguage.PT_BR to "Planejar",
            AppLanguage.ES to "Planificar",
            AppLanguage.EN to "Plan"
        ),
        "buy" to mapOf(
            AppLanguage.PT_BR to "Comprar",
            AppLanguage.ES to "Comprar",
            AppLanguage.EN to "Buy"
        ),
        "wallet" to mapOf(
            AppLanguage.PT_BR to "Carteira",
            AppLanguage.ES to "Billetera",
            AppLanguage.EN to "Wallet"
        ),
        "more" to mapOf(
            AppLanguage.PT_BR to "Mais",
            AppLanguage.ES to "Más",
            AppLanguage.EN to "More"
        ),
        "demo_mode" to mapOf(
            AppLanguage.PT_BR to "Modo demonstração — Dados simulados",
            AppLanguage.ES to "Modo de demonstração — Datos simulados",
            AppLanguage.EN to "Demo mode — Simulated data"
        ),
        "unofficial_banner" to mapOf(
            AppLanguage.PT_BR to "Protótipo independente — não oficial",
            AppLanguage.ES to "Prototipo independiente — no oficial",
            AppLanguage.EN to "Independent prototype — not official"
        ),
        "where_to" to mapOf(
            AppLanguage.PT_BR to "Para onde você vai?",
            AppLanguage.ES to "¿Adónde vas?",
            AppLanguage.EN to "Where are you going?"
        ),
        "origin" to mapOf(
            AppLanguage.PT_BR to "Estação de Origem",
            AppLanguage.ES to "Estación de Origen",
            AppLanguage.EN to "Origin Station"
        ),
        "destination" to mapOf(
            AppLanguage.PT_BR to "Estação de Destino",
            AppLanguage.ES to "Estación de Destino",
            AppLanguage.EN to "Destination Station"
        ),
        "date" to mapOf(
            AppLanguage.PT_BR to "Data de viagem",
            AppLanguage.ES to "Fecha de viaje",
            AppLanguage.EN to "Travel Date"
        ),
        "time" to mapOf(
            AppLanguage.PT_BR to "Horário",
            AppLanguage.ES to "Horario",
            AppLanguage.EN to "Time"
        ),
        "passengers" to mapOf(
            AppLanguage.PT_BR to "Número de passageiros",
            AppLanguage.ES to "Número de pasajeros",
            AppLanguage.EN to "Number of passengers"
        ),
        "plan_button" to mapOf(
            AppLanguage.PT_BR to "Planejar Viagem",
            AppLanguage.ES to "Planificar Viaje",
            AppLanguage.EN to "Plan Journey"
        ),
        "quick_actions" to mapOf(
            AppLanguage.PT_BR to "Ações rápidas",
            AppLanguage.ES to "Acciones rápidas",
            AppLanguage.EN to "Quick actions"
        ),
        "buy_ticket" to mapOf(
            AppLanguage.PT_BR to "Comprar Bilhete",
            AppLanguage.ES to "Comprar Billete",
            AppLanguage.EN to "Buy Ticket"
        ),
        "show_ticket" to mapOf(
            AppLanguage.PT_BR to "Mostrar Bilhete",
            AppLanguage.ES to "Mostrar Billete",
            AppLanguage.EN to "Show Ticket"
        ),
        "explore_stations" to mapOf(
            AppLanguage.PT_BR to "Consultar Estações",
            AppLanguage.ES to "Consultar Estaciones",
            AppLanguage.EN to "Explore Stations"
        ),
        "view_fares" to mapOf(
            AppLanguage.PT_BR to "Ver Tarifas",
            AppLanguage.ES to "Ver Tarifas",
            AppLanguage.EN to "View Fares"
        ),
        "service_status" to mapOf(
            AppLanguage.PT_BR to "Status do Serviço",
            AppLanguage.ES to "Estado del Servicio",
            AppLanguage.EN to "Service Status"
        ),
        "help" to mapOf(
            AppLanguage.PT_BR to "Ajuda & FAQ",
            AppLanguage.ES to "Ayuda & FAQ",
            AppLanguage.EN to "Help & FAQ"
        ),
        "nearby_stations" to mapOf(
            AppLanguage.PT_BR to "Estações Próximas",
            AppLanguage.ES to "Estaciones Cercanas",
            AppLanguage.EN to "Nearby Stations"
        ),
        "accessibility" to mapOf(
            AppLanguage.PT_BR to "Acessibilidade",
            AppLanguage.ES to "Accesibilidad",
            AppLanguage.EN to "Accessibility"
        ),
        "step_free" to mapOf(
            AppLanguage.PT_BR to "Livre de degraus",
            AppLanguage.ES to "Acceso sin escalones",
            AppLanguage.EN to "Step-free route"
        ),
        "elevators" to mapOf(
            AppLanguage.PT_BR to "Elevador operacional",
            AppLanguage.ES to "Elevador operativo",
            AppLanguage.EN to "Elevator operational"
        ),
        "escalators" to mapOf(
            AppLanguage.PT_BR to "Escada rolante operacional",
            AppLanguage.ES to "Escalera mecánica operativa",
            AppLanguage.EN to "Escalator operational"
        ),
        "next_departures" to mapOf(
            AppLanguage.PT_BR to "Próximas partidas",
            AppLanguage.ES to "Próximas salidas",
            AppLanguage.EN to "Next departures"
        ),
        "active_journey" to mapOf(
            AppLanguage.PT_BR to "Sua Viagem Ativa",
            AppLanguage.ES to "Tu Viaje Activo",
            AppLanguage.EN to "Your Active Journey"
        ),
        "stops_remaining" to mapOf(
            AppLanguage.PT_BR to "estações restantes",
            AppLanguage.ES to "estaciones restantes",
            AppLanguage.EN to "stations remaining"
        ),
        "interchange" to mapOf(
            AppLanguage.PT_BR to "Baldeação",
            AppLanguage.ES to "Combinación",
            AppLanguage.EN to "Interchange"
        ),
        "no_active_journey" to mapOf(
            AppLanguage.PT_BR to "Nenhuma viagem ativa no momento",
            AppLanguage.ES to "Ningún viaje activo en este momento",
            AppLanguage.EN to "No active journey at the moment"
        ),
        // Fares and tickets
        "single_journey" to mapOf(
            AppLanguage.PT_BR to "Bilhete Unitário",
            AppLanguage.ES to "Billete Unitario",
            AppLanguage.EN to "Single Journey"
        ),
        "single_journey_desc" to mapOf(
            AppLanguage.PT_BR to "Válido para uma viagem no MetrôRio.",
            AppLanguage.ES to "Válido para un viaje en el MetrôRio.",
            AppLanguage.EN to "Valid for a single journey on MetrôRio."
        ),
        "giro_card" to mapOf(
            AppLanguage.PT_BR to "Cartão Giro MetrôRio",
            AppLanguage.ES to "Tarjeta Giro MetrôRio",
            AppLanguage.EN to "MetrôRio Giro Card"
        ),
        "giro_card_desc" to mapOf(
            AppLanguage.PT_BR to "Recarregável com benefícios e tarifas integradas.",
            AppLanguage.ES to "Recargable con beneficios y tarifas integradas.",
            AppLanguage.EN to "Rechargeable card with benefits and integrated fares."
        ),
        "day_pass" to mapOf(
            AppLanguage.PT_BR to "Passe Diário",
            AppLanguage.ES to "Pase Diario",
            AppLanguage.EN to "Day Pass"
        ),
        "day_pass_desc" to mapOf(
            AppLanguage.PT_BR to "Viagens ilimitadas no metrô por 24 horas.",
            AppLanguage.ES to "Viajes ilimitados en metro por 24 horas.",
            AppLanguage.EN to "Unlimited subway rides for 24 hours."
        ),
        "fictional_fare_notice" to mapOf(
            AppLanguage.PT_BR to "Tarifas simuladas para fins de demonstração.",
            AppLanguage.ES to "Tarifas simuladas con fines demostrativos.",
            AppLanguage.EN to "Simulated fares for demonstration purposes."
        ),
        "select_ticket" to mapOf(
            AppLanguage.PT_BR to "Selecione o tipo de bilhete",
            AppLanguage.ES to "Selecciona el tipo de billete",
            AppLanguage.EN to "Select ticket type"
        ),
        "passenger_details" to mapOf(
            AppLanguage.PT_BR to "Detalhes do passageiro",
            AppLanguage.ES to "Detalles del pasajero",
            AppLanguage.EN to "Passenger details"
        ),
        "full_name" to mapOf(
            AppLanguage.PT_BR to "Nome completo",
            AppLanguage.ES to "Nombre completo",
            AppLanguage.EN to "Full name"
        ),
        "payment_method" to mapOf(
            AppLanguage.PT_BR to "Meio de pagamento",
            AppLanguage.ES to "Medio de pago",
            AppLanguage.EN to "Payment method"
        ),
        "card_number" to mapOf(
            AppLanguage.PT_BR to "Número do cartão simulado",
            AppLanguage.ES to "Número de tarjeta simulado",
            AppLanguage.EN to "Simulated card number"
        ),
        "pay_and_generate" to mapOf(
            AppLanguage.PT_BR to "Pagar e Gerar Bilhete",
            AppLanguage.ES to "Pagar y Generar Billete",
            AppLanguage.EN to "Pay and Generate Ticket"
        ),
        "processing_payment" to mapOf(
            AppLanguage.PT_BR to "Processando pagamento...",
            AppLanguage.ES to "Procesando pago...",
            AppLanguage.EN to "Processing payment..."
        ),
        "payment_success" to mapOf(
            AppLanguage.PT_BR to "Sucesso! Bilhete gerado.",
            AppLanguage.ES to "¡Éxito! Billete generado.",
            AppLanguage.EN to "Success! Ticket generated."
        ),
        // Wallet Screen
        "active_tickets" to mapOf(
            AppLanguage.PT_BR to "Bilhetes Ativos",
            AppLanguage.ES to "Billetes Activos",
            AppLanguage.EN to "Active Tickets"
        ),
        "expired_tickets" to mapOf(
            AppLanguage.PT_BR to "Histórico / Expirados",
            AppLanguage.ES to "Historial / Expirados",
            AppLanguage.EN to "History / Expired"
        ),
        "empty_wallet" to mapOf(
            AppLanguage.PT_BR to "Sua carteira está vazia. Compre um bilhete para começar!",
            AppLanguage.ES to "Tu billetera está vacía. ¡Compra un billete para comenzar!",
            AppLanguage.EN to "Your wallet is empty. Buy a ticket to get started!"
        ),
        "ticket_code" to mapOf(
            AppLanguage.PT_BR to "Código do bilhete",
            AppLanguage.ES to "Código del billete",
            AppLanguage.EN to "Ticket code"
        ),
        "status" to mapOf(
            AppLanguage.PT_BR to "Status",
            AppLanguage.ES to "Estado",
            AppLanguage.EN to "Status"
        ),
        "valid_ticket" to mapOf(
            AppLanguage.PT_BR to "Bilhete válido",
            AppLanguage.ES to "Billete válido",
            AppLanguage.EN to "Valid ticket"
        ),
        "used_ticket" to mapOf(
            AppLanguage.PT_BR to "Bilhete utilizado",
            AppLanguage.ES to "Billete utilizado",
            AppLanguage.EN to "Used ticket"
        ),
        "expired_ticket" to mapOf(
            AppLanguage.PT_BR to "Bilhete expirado",
            AppLanguage.ES to "Billete expirado",
            AppLanguage.EN to "Expired ticket"
        ),
        "refunded_ticket" to mapOf(
            AppLanguage.PT_BR to "Reembolsado",
            AppLanguage.ES to "Reembolsado",
            AppLanguage.EN to "Refunded"
        ),
        "activate_ticket" to mapOf(
            AppLanguage.PT_BR to "Ativar Bilhete",
            AppLanguage.ES to "Activar Billete",
            AppLanguage.EN to "Activate Ticket"
        ),
        "refund_ticket" to mapOf(
            AppLanguage.PT_BR to "Reembolsar",
            AppLanguage.ES to "Reembolsar",
            AppLanguage.EN to "Refund"
        ),
        "simulate_scan" to mapOf(
            AppLanguage.PT_BR to "Simular Validação (QR)",
            AppLanguage.ES to "Simular Validación (QR)",
            AppLanguage.EN to "Simulate QR Validation"
        ),
        // QR Validation states
        "qr_ready" to mapOf(
            AppLanguage.PT_BR to "Bilhete pronto.",
            AppLanguage.ES to "Billete listo.",
            AppLanguage.EN to "Ticket ready."
        ),
        "qr_present" to mapOf(
            AppLanguage.PT_BR to "Aproxime o código do leitor.",
            AppLanguage.ES to "Acerca el código al lector.",
            AppLanguage.EN to "Present the code to the reader."
        ),
        "qr_verifying" to mapOf(
            AppLanguage.PT_BR to "Verificando bilhete.",
            AppLanguage.ES to "Verificando billete.",
            AppLanguage.EN to "Verifying ticket."
        ),
        "qr_valid" to mapOf(
            AppLanguage.PT_BR to "Bilhete válido.",
            AppLanguage.ES to "Billete válido.",
            AppLanguage.EN to "Valid ticket."
        ),
        "qr_authorized" to mapOf(
            AppLanguage.PT_BR to "Acesso autorizado.",
            AppLanguage.ES to "Acceso autorizado.",
            AppLanguage.EN to "Access authorised."
        ),
        // QR Error states
        "qr_err_expired" to mapOf(
            AppLanguage.PT_BR to "Bilhete expirado.",
            AppLanguage.ES to "Billete expirado.",
            AppLanguage.EN to "Expired ticket."
        ),
        "qr_err_used" to mapOf(
            AppLanguage.PT_BR to "Bilhete já utilizado.",
            AppLanguage.ES to "Billete ya utilizado.",
            AppLanguage.EN to "Ticket already used."
        ),
        "qr_err_invalid" to mapOf(
            AppLanguage.PT_BR to "QR Code inválido.",
            AppLanguage.ES to "Código QR inválido.",
            AppLanguage.EN to "Invalid QR code."
        ),
        // Contactless Card
        "nfc_title" to mapOf(
            AppLanguage.PT_BR to "Pagamento por Aproximação (NFC)",
            AppLanguage.ES to "Pago por Aproximación (NFC)",
            AppLanguage.EN to "Contactless Payment (NFC)"
        ),
        "nfc_ready" to mapOf(
            AppLanguage.PT_BR to "Meio de pagamento pronto",
            AppLanguage.ES to "Medio de pago listo",
            AppLanguage.EN to "Payment method ready"
        ),
        "nfc_present" to mapOf(
            AppLanguage.PT_BR to "Aproxime seu cartão do leitor.",
            AppLanguage.ES to "Acerca tu tarjeta al lector.",
            AppLanguage.EN to "Present your card to the reader."
        ),
        "nfc_verifying" to mapOf(
            AppLanguage.PT_BR to "Verificando autorização...",
            AppLanguage.ES to "Verificando autorización...",
            AppLanguage.EN to "Verifying authorisation..."
        ),
        "nfc_authorized" to mapOf(
            AppLanguage.PT_BR to "Acesso autorizado",
            AppLanguage.ES to "Acceso autorizado",
            AppLanguage.EN to "Access authorised"
        ),
        // Journey Planner Results
        "duration" to mapOf(
            AppLanguage.PT_BR to "Duração",
            AppLanguage.ES to "Duración",
            AppLanguage.EN to "Duration"
        ),
        "transfers" to mapOf(
            AppLanguage.PT_BR to "Transferências",
            AppLanguage.ES to "Transbordos",
            AppLanguage.EN to "Transfers"
        ),
        "stops" to mapOf(
            AppLanguage.PT_BR to "paradas",
            AppLanguage.ES to "paradas",
            AppLanguage.EN to "stops"
        ),
        "select_journey_btn" to mapOf(
            AppLanguage.PT_BR to "Selecionar esta rota",
            AppLanguage.ES to "Seleccionar esta ruta",
            AppLanguage.EN to "Select this route"
        ),
        "accessible_route" to mapOf(
            AppLanguage.PT_BR to "Rota 100% Acessível",
            AppLanguage.ES to "Ruta 100% Accesible",
            AppLanguage.EN to "100% Accessible Route"
        ),
        "route_alert" to mapOf(
            AppLanguage.PT_BR to "Aviso de serviço nesta rota",
            AppLanguage.ES to "Aviso de servicio en esta ruta",
            AppLanguage.EN to "Service warning on this route"
        ),
        "has_ticket" to mapOf(
            AppLanguage.PT_BR to "Você já tem um bilhete válido para esta rota!",
            AppLanguage.ES to "¡Ya tienes un billete válido para esta ruta!",
            AppLanguage.EN to "You already have a valid ticket for this route!"
        ),
        "no_ticket_warning" to mapOf(
            AppLanguage.PT_BR to "É necessário adquirir um bilhete para viajar nesta rota.",
            AppLanguage.ES to "Es necesario adquirir un billete para viajar en esta ruta.",
            AppLanguage.EN to "A ticket is required to travel on this route."
        ),
        // Stations Directory
        "search_station" to mapOf(
            AppLanguage.PT_BR to "Buscar estação...",
            AppLanguage.ES to "Buscar estación...",
            AppLanguage.EN to "Search station..."
        ),
        "operating_hours" to mapOf(
            AppLanguage.PT_BR to "Horário de funcionamento",
            AppLanguage.ES to "Horario de funcionamiento",
            AppLanguage.EN to "Operating hours"
        ),
        "station_facilities" to mapOf(
            AppLanguage.PT_BR to "Instalações da estação",
            AppLanguage.ES to "Instalaciones de la estación",
            AppLanguage.EN to "Station facilities"
        ),
        "station_map" to mapOf(
            AppLanguage.PT_BR to "Esquema da estação",
            AppLanguage.ES to "Esquema de la estación",
            AppLanguage.EN to "Station layout"
        ),
        // Alert severity
        "normal" to mapOf(
            AppLanguage.PT_BR to "Operando normalmente",
            AppLanguage.ES to "Operando normalmente",
            AppLanguage.EN to "Operating normally"
        ),
        "minor" to mapOf(
            AppLanguage.PT_BR to "Atraso menor",
            AppLanguage.ES to "Retraso menor",
            AppLanguage.EN to "Minor delay"
        ),
        "major" to mapOf(
            AppLanguage.PT_BR to "Atraso significativo",
            AppLanguage.ES to "Retraso significativo",
            AppLanguage.EN to "Major delay"
        ),
        "critical" to mapOf(
            AppLanguage.PT_BR to "Linha interrompida",
            AppLanguage.ES to "Línea interrumpida",
            AppLanguage.EN to "Line suspended"
        )
    )

    fun get(key: String, lang: AppLanguage = currentLanguage.value): String {
        return translations[key]?.get(lang) ?: key
    }
}
