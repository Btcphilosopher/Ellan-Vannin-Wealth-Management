package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {
    // Stations
    @Query("SELECT * FROM stations ORDER BY namePt ASC")
    fun getAllStationsFlow(): Flow<List<StationEntity>>

    @Query("SELECT * FROM stations")
    suspend fun getAllStations(): List<StationEntity>

    @Query("SELECT * FROM stations WHERE id = :id")
    suspend fun getStationById(id: String): StationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)

    // Tickets
    @Query("SELECT * FROM tickets ORDER BY purchaseTimestamp DESC")
    fun getAllTicketsFlow(): Flow<List<TicketEntity>>

    @Query("SELECT * FROM tickets WHERE id = :id")
    suspend fun getTicketById(id: String): TicketEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity)

    @Update
    suspend fun updateTicket(ticket: TicketEntity)

    @Query("DELETE FROM tickets")
    suspend fun clearTickets()

    // Service Alerts
    @Query("SELECT * FROM alerts ORDER BY timestamp DESC")
    fun getAllAlertsFlow(): Flow<List<AlertEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<AlertEntity>)

    @Query("DELETE FROM alerts")
    suspend fun clearAlerts()

    // Transport Cards
    @Query("SELECT * FROM transport_cards")
    fun getAllTransportCardsFlow(): Flow<List<TransportCardEntity>>

    @Query("SELECT * FROM transport_cards WHERE id = :id")
    suspend fun getTransportCardById(id: String): TransportCardEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransportCard(card: TransportCardEntity)

    @Update
    suspend fun updateTransportCard(card: TransportCardEntity)
}
