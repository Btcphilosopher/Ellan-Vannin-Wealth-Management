package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.theme.*

data class MapNode(
    val id: String,
    val name: String,
    val x: Float, // Relative x 0..100
    val y: Float, // Relative y 0..100
    val lineCode: String // Primary line code for coloring
)

@Composable
fun MapWidget(
    selectedOriginId: String?,
    selectedDestId: String?,
    onStationSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    // Elegant Rio schematic network nodes relative coordinates
    val nodes = listOf(
        MapNode("pavuna", "Pavuna", 15f, 15f, "L2"),
        MapNode("maracana", "Maracanã", 35f, 30f, "L2"),
        MapNode("uruguai", "Uruguai", 20f, 40f, "L1"),
        MapNode("central", "Central", 50f, 40f, "L1"),
        MapNode("carioca", "Carioca", 65f, 55f, "L1"),
        MapNode("flamengo", "Flamengo", 65f, 70f, "L1"),
        MapNode("botafogo", "Botafogo", 60f, 82f, "L1"),
        MapNode("cardeal_arcoverde", "Cardeal Arcoverde", 50f, 85f, "L1"),
        MapNode("siqueira_campos", "Siqueira Campos", 40f, 88f, "L1"),
        MapNode("cantagalo", "Cantagalo", 30f, 88f, "L1"),
        MapNode("general_osorio", "Gen. Osório", 22f, 84f, "L1"),
        MapNode("nossa_senhora_da_paz", "N.S. Paz", 16f, 75f, "L4"),
        MapNode("jardim_de_alah", "Jardim de Alah", 14f, 65f, "L4"),
        MapNode("antero_de_quental", "Ant. Quental", 12f, 55f, "L4"),
        MapNode("sau_conrado", "S. Conrado", 10f, 45f, "L4"),
        MapNode("jardim_oceanico", "Jardim Oceânico", 8f, 35f, "L4")
    )

    // Colors for route representations
    val colorL1 = Color(0xFFF15A24) // Orange
    val colorL2 = Color(0xFF00A859) // Green
    val colorL4 = Color(0xFF005CA9) // Blue

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(300.dp),
        colors = CardDefaults.cardColors(containerColor = SlateCharcoal)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = I18n.get("station_map"),
                    color = Color.White,
                    fontSize = 14.sp,
                    style = MaterialTheme.typography.titleMedium
                )
                // Legend
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).background(colorL1))
                        Spacer(Modifier.width(4.dp))
                        Text("L1", color = Color.White, fontSize = 10.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).background(colorL2))
                        Spacer(Modifier.width(4.dp))
                        Text("L2", color = Color.White, fontSize = 10.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).background(colorL4))
                        Spacer(Modifier.width(4.dp))
                        Text("L4", color = Color.White, fontSize = 10.sp)
                    }
                }
            }

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121417))
            ) {
                val canvasWidth = constraints.maxWidth.toFloat()
                val canvasHeight = constraints.maxHeight.toFloat()

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures { offset ->
                                // Find closest station node in 24.dp radius
                                var closestNode: MapNode? = null
                                var minDistance = Float.MAX_VALUE
                                nodes.forEach { node ->
                                    val nx = (node.x / 100f) * canvasWidth
                                    val ny = (node.y / 100f) * canvasHeight
                                    val dist = Math.hypot((offset.x - nx).toDouble(), (offset.y - ny).toDouble()).toFloat()
                                    if (dist < minDistance && dist < 50f) { // ~20dp tap target
                                        minDistance = dist
                                        closestNode = node
                                    }
                                }
                                closestNode?.let { onStationSelect(it.id) }
                            }
                        }
                ) {
                    // Draw Line 4: JOC -> SCD -> ADQ -> JDA -> NSP -> GOS
                    val l4Stations = listOf(
                        "jardim_oceanico", "sau_conrado", "antero_de_quental", 
                        "jardim_de_alah", "nossa_senhora_da_paz", "general_osorio"
                    ).mapNotNull { id -> nodes.find { it.id == id } }

                    for (i in 0 until l4Stations.size - 1) {
                        val p1 = Offset((l4Stations[i].x / 100f) * size.width, (l4Stations[i].y / 100f) * size.height)
                        val p2 = Offset((l4Stations[i+1].x / 100f) * size.width, (l4Stations[i+1].y / 100f) * size.height)
                        drawLine(color = colorL4, start = p1, end = p2, strokeWidth = 8f)
                    }

                    // Draw Line 1: GOS -> CTG -> SCP -> CAV -> BTF -> FLM -> CRC -> CEN -> URG
                    val l1Stations = listOf(
                        "general_osorio", "cantagalo", "siqueira_campos", "cardeal_arcoverde",
                        "botafogo", "flamengo", "carioca", "central", "uruguai"
                    ).mapNotNull { id -> nodes.find { it.id == id } }

                    for (i in 0 until l1Stations.size - 1) {
                        val p1 = Offset((l1Stations[i].x / 100f) * size.width, (l1Stations[i].y / 100f) * size.height)
                        val p2 = Offset((l1Stations[i+1].x / 100f) * size.width, (l1Stations[i+1].y / 100f) * size.height)
                        drawLine(color = colorL1, start = p1, end = p2, strokeWidth = 8f)
                    }

                    // Draw Line 2: PVN -> MCN -> CEN -> CRC -> BTF
                    val l2Stations = listOf(
                        "pavuna", "maracana", "central", "carioca", "botafogo"
                    ).mapNotNull { id -> nodes.find { it.id == id } }

                    for (i in 0 until l2Stations.size - 1) {
                        val p1 = Offset((l2Stations[i].x / 100f) * size.width, (l2Stations[i].y / 100f) * size.height)
                        val p2 = Offset((l2Stations[i+1].x / 100f) * size.width, (l2Stations[i+1].y / 100f) * size.height)
                        drawLine(color = colorL2, start = p1, end = p2, strokeWidth = 5f)
                    }

                    // Draw Interchange and Station Nodes
                    nodes.forEach { node ->
                        val cx = (node.x / 100f) * size.width
                        val cy = (node.y / 100f) * size.height
                        val isOrigin = node.id == selectedOriginId
                        val isDest = node.id == selectedDestId
                        val isInterchange = node.id == "general_osorio" || node.id == "central" || node.id == "carioca" || node.id == "botafogo"

                        // Draw node halo if selected
                        if (isOrigin) {
                            drawCircle(color = SuccessGreen.copy(alpha = 0.4f), radius = 22f, center = Offset(cx, cy))
                            drawCircle(color = SuccessGreen, radius = 10f, center = Offset(cx, cy))
                        } else if (isDest) {
                            drawCircle(color = ErrorRed.copy(alpha = 0.4f), radius = 22f, center = Offset(cx, cy))
                            drawCircle(color = ErrorRed, radius = 10f, center = Offset(cx, cy))
                        } else {
                            // Draw node base
                            val nodeColor = if (isInterchange) Color.White else Color.LightGray
                            drawCircle(color = nodeColor, radius = if (isInterchange) 8f else 6f, center = Offset(cx, cy))
                            drawCircle(
                                color = Color.Black,
                                radius = if (isInterchange) 8f else 6f,
                                center = Offset(cx, cy),
                                style = Stroke(width = 2f)
                            )
                        }
                    }
                }

                // Station Labels overlay
                nodes.forEach { node ->
                    val isOrigin = node.id == selectedOriginId
                    val isDest = node.id == selectedDestId
                    val textColor = when {
                        isOrigin -> SuccessGreen
                        isDest -> ErrorRed
                        else -> Color.White.copy(alpha = 0.85f)
                    }

                    Box(
                        modifier = Modifier
                            .offset(
                                x = ((node.x / 100f) * this@BoxWithConstraints.maxWidth.value.dp.value).dp + 8.dp,
                                y = ((node.y / 100f) * this@BoxWithConstraints.maxHeight.value.dp.value).dp - 8.dp
                            )
                    ) {
                        Text(
                            text = node.name,
                            color = textColor,
                            fontSize = 8.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
