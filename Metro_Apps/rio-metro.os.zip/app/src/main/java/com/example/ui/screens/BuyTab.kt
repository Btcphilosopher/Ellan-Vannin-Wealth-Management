package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.theme.*
import com.example.viewmodel.MainTab
import com.example.viewmodel.MetroViewModel

@Composable
fun BuyTab(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    val stations by viewModel.stations.collectAsState()
    val purchaseState = viewModel.purchaseState.value

    val currentLang = I18n.currentLanguage.value

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = I18n.get("buy_ticket"),
            style = MaterialTheme.typography.titleLarge,
            fontSize = 20.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        // Ticket Selection Layout
        Card(
            modifier = Modifier.fillMaxWidth().testTag("buy_ticket_form_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Origin Selection drop-down
                var originExpanded by remember { mutableStateOf(false) }
                Box {
                    val currentOriginName = stations.find { it.id == viewModel.buyOriginId.value }?.let {
                        if (currentLang == AppLanguage.PT_BR) it.namePt else if (currentLang == AppLanguage.ES) it.nameEs else it.nameEn
                    } ?: "Botafogo"

                    OutlinedTextField(
                        value = currentOriginName,
                        onValueChange = {},
                        label = { Text(I18n.get("origin")) },
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().clickable { originExpanded = true },
                        enabled = false,
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledTextColor = MaterialTheme.colorScheme.onSurface,
                            disabledLabelColor = MaterialTheme.colorScheme.primary,
                            disabledBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                    DropdownMenu(
                        expanded = originExpanded,
                        onDismissRequest = { originExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        stations.forEach { station ->
                            val name = if (currentLang == AppLanguage.PT_BR) station.namePt else if (currentLang == AppLanguage.ES) station.nameEs else station.nameEn
                            DropdownMenuItem(
                                text = { Text("$name (${station.code})") },
                                onClick = {
                                    viewModel.buyOriginId.value = station.id
                                    originExpanded = false
                                }
                            )
                        }
                    }
                }

                // Destination Selection drop-down
                var destExpanded by remember { mutableStateOf(false) }
                Box {
                    val currentDestName = stations.find { it.id == viewModel.buyDestId.value }?.let {
                        if (currentLang == AppLanguage.PT_BR) it.namePt else if (currentLang == AppLanguage.ES) it.nameEs else it.nameEn
                    } ?: "Central"

                    OutlinedTextField(
                        value = currentDestName,
                        onValueChange = {},
                        label = { Text(I18n.get("destination")) },
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth().clickable { destExpanded = true },
                        enabled = false,
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledTextColor = MaterialTheme.colorScheme.onSurface,
                            disabledLabelColor = MaterialTheme.colorScheme.primary,
                            disabledBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                    DropdownMenu(
                        expanded = destExpanded,
                        onDismissRequest = { destExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        stations.forEach { station ->
                            val name = if (currentLang == AppLanguage.PT_BR) station.namePt else if (currentLang == AppLanguage.ES) station.nameEs else station.nameEn
                            DropdownMenuItem(
                                text = { Text("$name (${station.code})") },
                                onClick = {
                                    viewModel.buyDestId.value = station.id
                                    destExpanded = false
                                }
                            )
                        }
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                // Ticket Fares Class Selector
                Text(
                    text = I18n.get("select_ticket"),
                    style = MaterialTheme.typography.titleMedium,
                    fontSize = 14.sp
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FareSelectorOption(
                        title = I18n.get("single_journey"),
                        desc = I18n.get("single_journey_desc"),
                        price = "R$ 7,50",
                        selected = viewModel.selectedFareType.value == "SINGLE",
                        onClick = { viewModel.selectedFareType.value = "SINGLE" }
                    )
                    FareSelectorOption(
                        title = I18n.get("giro_card"),
                        desc = I18n.get("giro_card_desc"),
                        price = "R$ 6,90",
                        selected = viewModel.selectedFareType.value == "GIRO",
                        onClick = { viewModel.selectedFareType.value = "GIRO" }
                    )
                    FareSelectorOption(
                        title = I18n.get("day_pass"),
                        desc = I18n.get("day_pass_desc"),
                        price = "R$ 22,00",
                        selected = viewModel.selectedFareType.value == "DAY",
                        onClick = { viewModel.selectedFareType.value = "DAY" }
                    )
                }

                // Passenger Credentials details
                OutlinedTextField(
                    value = viewModel.passengerNameInput.value,
                    onValueChange = { viewModel.passengerNameInput.value = it },
                    label = { Text(I18n.get("passenger_details")) },
                    modifier = Modifier.fillMaxWidth().testTag("passenger_name_input"),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null, tint = TropicalGreen) }
                )

                // Payment input details
                OutlinedTextField(
                    value = viewModel.buyCardNumber.value,
                    onValueChange = { viewModel.buyCardNumber.value = it },
                    label = { Text(I18n.get("card_number")) },
                    modifier = Modifier.fillMaxWidth().testTag("card_number_input"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    leadingIcon = { Icon(Icons.Filled.Payment, contentDescription = null, tint = TropicalGreen) }
                )

                // Synthetic Fare notices
                Text(
                    text = I18n.get("fictional_fare_notice"),
                    color = Color.Gray,
                    fontSize = 11.sp
                )

                // Checkout button / Process states
                if (purchaseState == "PROCESSING") {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(color = TropicalGreen)
                        Text(I18n.get("processing_payment"), fontSize = 13.sp, color = Color.Gray)
                    }
                } else if (purchaseState == "SUCCESS") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SuccessGreen.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SuccessGreen)
                        Spacer(Modifier.width(8.dp))
                        Text(I18n.get("payment_success"), color = SuccessGreen, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = {
                            viewModel.purchaseTicket {
                                // Redirect to Wallet Tab
                                viewModel.currentTab.value = MainTab.WALLET
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("submit_buy_ticket"),
                        colors = ButtonDefaults.buttonColors(containerColor = TropicalGreen)
                    ) {
                        val priceString = when(viewModel.selectedFareType.value) {
                            "SINGLE" -> "R$ 7,50"
                            "GIRO" -> "R$ 6,90"
                            "DAY" -> "R$ 22,00"
                            else -> "R$ 7,50"
                        }
                        Text("${I18n.get("pay_and_generate")} ($priceString)", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun FareSelectorOption(
    title: String,
    desc: String,
    price: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .background(
                if (selected) TropicalGreen.copy(alpha = 0.08f) else Color.Transparent,
                RoundedCornerShape(8.dp)
            )
            .background(
                if (selected) Color.Transparent else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                RoundedCornerShape(8.dp)
            )
            .border(
                width = 1.dp,
                color = if (selected) TropicalGreen else MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(8.dp)
            )
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(text = desc, fontSize = 11.sp, color = Color.Gray)
        }
        Text(text = price, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TropicalGreen)
    }
}
