package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.*
import com.example.ui.theme.*
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MainTab
import com.example.viewmodel.MetroViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MetroViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val currentTab = viewModel.currentTab.value
                val alerts by viewModel.alerts.collectAsState()

                // Check overall system status from alerts list
                val hasAlerts = alerts.any { it.severity != "NORMAL" }
                val systemStatusColor = if (hasAlerts) AlertYellow else SuccessGreen
                val systemStatusLabel = if (hasAlerts) "Aviso" else "Normal"

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column {
                                        Text(
                                            text = "RIO METRO.OS",
                                            fontSize = 17.sp,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = TropicalGreen,
                                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                        )
                                        // Dynamic service alert pill!
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .clip(CircleShape)
                                                    .background(systemStatusColor)
                                            )
                                            Text(
                                                text = "Metrô: $systemStatusLabel",
                                                fontSize = 10.sp,
                                                color = Color.Gray
                                            )
                                        }
                                    }
                                    
                                    Spacer(Modifier.weight(1f))

                                    // MANDATORY DEMO MODE PILL
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(HighContrastGold.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "DEMO",
                                            color = HighContrastGold,
                                            fontSize = 9.sp,
                                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                            modifier = Modifier.testTag("demo_badge")
                                        )
                                    }
                                }
                            },
                            actions = {
                                // Dynamic Language fast-switch icon button
                                var langMenuExpanded by remember { mutableStateOf(false) }
                                Box {
                                    IconButton(
                                        onClick = { langMenuExpanded = true },
                                        modifier = Modifier.testTag("language_switch_icon")
                                    ) {
                                        Icon(
                                            Icons.Filled.Translate,
                                            contentDescription = "Switch language",
                                            tint = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = langMenuExpanded,
                                        onDismissRequest = { langMenuExpanded = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("Português (Brasil)") },
                                            onClick = {
                                                I18n.currentLanguage.value = AppLanguage.PT_BR
                                                langMenuExpanded = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Español") },
                                            onClick = {
                                                I18n.currentLanguage.value = AppLanguage.ES
                                                langMenuExpanded = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("English") },
                                            onClick = {
                                                I18n.currentLanguage.value = AppLanguage.EN
                                                langMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface,
                                titleContentColor = MaterialTheme.colorScheme.onSurface
                            ),
                            modifier = Modifier.testTag("main_top_bar")
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.testTag("bottom_nav_bar"),
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = currentTab == MainTab.HOME,
                                onClick = { viewModel.currentTab.value = MainTab.HOME },
                                icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                                label = { Text(I18n.get("home"), fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_home")
                            )
                            NavigationBarItem(
                                selected = currentTab == MainTab.PLAN,
                                onClick = { viewModel.currentTab.value = MainTab.PLAN },
                                icon = { Icon(Icons.Filled.Route, contentDescription = null) },
                                label = { Text(I18n.get("plan"), fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_plan")
                            )
                            NavigationBarItem(
                                selected = currentTab == MainTab.BUY,
                                onClick = { viewModel.currentTab.value = MainTab.BUY },
                                icon = { Icon(Icons.Filled.LocalMall, contentDescription = null) },
                                label = { Text(I18n.get("buy"), fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_buy")
                            )
                            NavigationBarItem(
                                selected = currentTab == MainTab.WALLET,
                                onClick = { viewModel.currentTab.value = MainTab.WALLET },
                                icon = { Icon(Icons.Filled.QrCode, contentDescription = null) },
                                label = { Text(I18n.get("wallet"), fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_wallet")
                            )
                            NavigationBarItem(
                                selected = currentTab == MainTab.MORE,
                                onClick = { viewModel.currentTab.value = MainTab.MORE },
                                icon = { Icon(Icons.Filled.Menu, contentDescription = null) },
                                label = { Text(I18n.get("more"), fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_more")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        AnimatedContent(
                            targetState = currentTab,
                            transitionSpec = {
                                fadeIn() togetherWith fadeOut()
                            },
                            label = "tab_transition"
                        ) { tab ->
                            when (tab) {
                                MainTab.HOME -> HomeTab(viewModel = viewModel)
                                MainTab.PLAN -> PlanTab(viewModel = viewModel)
                                MainTab.BUY -> BuyTab(viewModel = viewModel)
                                MainTab.WALLET -> WalletTab(viewModel = viewModel)
                                MainTab.MORE -> MoreTab(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
