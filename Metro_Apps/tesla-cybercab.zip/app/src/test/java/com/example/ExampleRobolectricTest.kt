package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.CybercabVehicle
import com.example.data.model.LocationPoint
import com.example.data.model.ServiceOption
import com.example.data.model.VehicleStatus
import com.example.data.simulator.DispatchEngine
import com.example.data.simulator.PricingEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Tesla Cybercab", appName)
  }

  @Test
  fun `pricing engine calculates correct fare`() {
    val pricingEngine = PricingEngine()
    val service = ServiceOption(
      id = "srv_test",
      name = "Cybercab",
      tag = "Standard",
      description = "Test",
      priceMultiplier = 1.0,
      capacity = 4,
      etaMinutes = 3
    )

    val fare = pricingEngine.calculateFare(
      distanceMiles = 6.4,
      estimatedDurationMinutes = 18,
      serviceOption = service,
      hasCybercabPass = false
    )

    assertEquals(13.4, fare.total, 0.5)
  }

  @Test
  fun `dispatch engine finds eligible vehicle`() {
    val dispatchEngine = DispatchEngine()
    val userLoc = LocationPoint(name = "Pick", address = "Address", latitude = 51.5074, longitude = -0.1278)

    val fleet = listOf(
      CybercabVehicle(
        id = "veh_1",
        code = "CC-0001",
        latitude = 51.51,
        longitude = -0.12,
        batteryLevel = 90,
        status = VehicleStatus.AVAILABLE
      )
    )

    val vehicle = dispatchEngine.dispatchOptimalVehicle(fleet, userLoc)
    assertNotNull(vehicle)
    assertEquals("CC-0001", vehicle?.code)
  }
}
