package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CybercabVehicle
import com.example.data.model.VehicleStatus
import com.example.data.simulator.SyntheticLondonData
import com.example.ui.MainViewModel
import com.example.ui.components.CybercabMapCanvas
import com.example.ui.theme.TeslaGreen
import com.example.ui.theme.TeslaRed
import com.example.ui.theme.TeslaYellow

@Composable
fun FleetMapScreen(
    modifier: Modifier = Modifier,
    viewModel: MainViewModel
) {
    val fleetVehicles by viewModel.fleetVehicles.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()

    var selectedFilter by remember { mutableStateOf<VehicleStatus?>(null) }
    var inspectedVehicle by remember { mutableStateOf<CybercabVehicle?>(null) }

    val filteredFleet = remember(fleetVehicles, selectedFilter) {
        if (selectedFilter == null) fleetVehicles
        else fleetVehicles.filter { it.status == selectedFilter }
    }

    Box(modifier = modifier.fillMaxSize()) {
        // 1. Full Screen Fleet Map Canvas
        CybercabMapCanvas(
            modifier = Modifier.fillMaxSize(),
            isDarkMode = isDarkMode,
            userLocation = SyntheticLondonData.CENTRAL_LONDON,
            vehicles = filteredFleet,
            showAllFleet = true
        )

        // 2. Top Filter Controls
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "LONDON FLEET MONITOR (${filteredFleet.size} Vehicles)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            val isSelected = selectedFilter == null
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) TeslaRed else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { selectedFilter = null }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("All (${fleetVehicles.size})", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        items(
                            listOf(
                                VehicleStatus.AVAILABLE,
                                VehicleStatus.IN_RIDE,
                                VehicleStatus.CHARGING,
                                VehicleStatus.MAINTENANCE
                            )
                        ) { status ->
                            val count = fleetVehicles.count { it.status == status }
                            val isSelected = selectedFilter == status
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) TeslaRed else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { selectedFilter = status }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("$status ($count)", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        // 3. Bottom Vehicle List Sheet
        Card(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Active Vehicles Telemetry",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filteredFleet.take(30)) { veh ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                .clickable { inspectedVehicle = veh }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.ElectricCar, contentDescription = null, tint = TeslaRed)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(veh.code, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                    Text("${veh.name} • ${veh.status}", style = MaterialTheme.typography.bodySmall)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${veh.batteryLevel}% Bat", style = MaterialTheme.typography.labelMedium)
                                Spacer(modifier = Modifier.width(6.dp))
                                if (veh.isAccessible) {
                                    Icon(imageVector = Icons.Default.Accessible, contentDescription = "Accessible", modifier = Modifier.height(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Vehicle Inspector Dialog
        inspectedVehicle?.let { veh ->
            Dialog(onDismissRequest = { inspectedVehicle = null }) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp)),
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(veh.code, style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold))
                            IconButton(onClick = { inspectedVehicle = null }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Status: ${veh.status}", style = MaterialTheme.typography.titleMedium.copy(color = TeslaGreen))
                        Text("Battery Level: ${veh.batteryLevel}%", style = MaterialTheme.typography.bodyMedium)
                        Text("Capacity: ${veh.capacity} Seats", style = MaterialTheme.typography.bodyMedium)
                        Text("Color: ${veh.color}", style = MaterialTheme.typography.bodyMedium)
                        Text("Wheelchair Accessible: ${if (veh.isAccessible) "Yes" else "No"}", style = MaterialTheme.typography.bodyMedium)
                        Text("GPS: ${veh.latitude}, ${veh.longitude}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
