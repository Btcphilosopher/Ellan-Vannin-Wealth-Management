package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.ui.MainViewModel
import com.example.ui.NavigationTab
import com.example.ui.components.TeslaBottomNavBar
import com.example.ui.screens.FleetMapScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RidesHistoryScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.TeslaCybercabTheme

class MainActivity : ComponentActivity() {
    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkMode by mainViewModel.isDarkMode.collectAsState()
            val currentTab by mainViewModel.currentTab.collectAsState()

            TeslaCybercabTheme(darkTheme = isDarkMode) {
                // BackHandler for secondary tabs to return to HOME
                if (currentTab != NavigationTab.HOME) {
                    BackHandler {
                        mainViewModel.selectTab(NavigationTab.HOME)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color.Transparent,
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    bottomBar = {
                        TeslaBottomNavBar(
                            currentTab = currentTab,
                            onTabSelected = { tab -> mainViewModel.selectTab(tab) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            NavigationTab.HOME -> HomeScreen(viewModel = mainViewModel)
                            NavigationTab.RIDES -> RidesHistoryScreen(viewModel = mainViewModel)
                            NavigationTab.MAP -> FleetMapScreen(viewModel = mainViewModel)
                            NavigationTab.WALLET -> WalletScreen(viewModel = mainViewModel)
                            NavigationTab.PROFILE -> ProfileScreen(viewModel = mainViewModel)
                        }
                    }
                }
            }
        }
    }
}
