package com.example.data.repository

import com.example.data.model.ActiveRide
import com.example.data.model.CabinSettings
import com.example.data.model.CybercabVehicle
import com.example.data.model.FeedbackRating
import com.example.data.model.LocationPoint
import com.example.data.model.RideEvent
import com.example.data.model.RideState
import com.example.data.model.ServiceOption
import com.example.data.model.VehicleStatus
import com.example.data.simulator.DispatchEngine
import com.example.data.simulator.FleetSimulator
import com.example.data.simulator.PricingEngine
import com.example.data.simulator.SyntheticLondonData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class RideRepository(
    private val fleetSimulator: FleetSimulator,
    private val dispatchEngine: DispatchEngine,
    private val pricingEngine: PricingEngine
) {
    private val scope = CoroutineScope(Dispatchers.Default)

    private val _activeRide = MutableStateFlow<ActiveRide?>(null)
    val activeRide: StateFlow<ActiveRide?> = _activeRide.asStateFlow()

    private val _rideEvents = MutableStateFlow<List<RideEvent>>(emptyList())
    val rideEvents: StateFlow<List<RideEvent>> = _rideEvents.asStateFlow()

    private var simulationJob: Job? = null

    val availableServices = listOf(
        ServiceOption(
            id = "srv_cybercab",
            name = "Cybercab",
            tag = "Autonomous Standard",
            description = "Standard 2-4 passenger autonomous vehicle.",
            priceMultiplier = 1.0,
            capacity = 4,
            etaMinutes = 3,
            isAccessible = false
        ),
        ServiceOption(
            id = "srv_cybercab_xl",
            name = "Cybercab XL",
            tag = "Extra Space",
            description = "Larger autonomous cabin for up to 6 passengers or luggage.",
            priceMultiplier = 1.4,
            capacity = 6,
            etaMinutes = 5,
            isAccessible = false
        ),
        ServiceOption(
            id = "srv_cybercab_accessible",
            name = "Cybercab Accessible",
            tag = "Accessibility First",
            description = "Ramp access, lowered threshold, extra boarding assistance time.",
            priceMultiplier = 1.0,
            capacity = 4,
            etaMinutes = 4,
            isAccessible = true
        ),
        ServiceOption(
            id = "srv_cybercab_biz",
            name = "Cybercab Business",
            tag = "Corporate Travel",
            description = "Premium interior, work table, high-speed WiFi, silent cabin.",
            priceMultiplier = 1.6,
            capacity = 4,
            etaMinutes = 3,
            isAccessible = false
        )
    )

    fun selectDestination(
        origin: LocationPoint = SyntheticLondonData.CENTRAL_LONDON,
        destination: LocationPoint,
        passengerCount: Int = 1,
        selectedService: ServiceOption = availableServices.first(),
        hasPass: Boolean = false
    ) {
        val dist = dispatchEngine.calculateHaversineMiles(
            origin.latitude, origin.longitude,
            destination.latitude, destination.longitude
        ).coerceAtLeast(1.2)

        val duration = (dist * 3.2 + 5).toInt().coerceAtLeast(8)
        val fare = pricingEngine.calculateFare(dist, duration, selectedService, hasPass)

        val waypoints = SyntheticLondonData.generateRouteWaypoints(
            origin.latitude, origin.longitude,
            destination.latitude, destination.longitude
        )

        val newRide = ActiveRide(
            state = RideState.DESTINATION_SELECTED,
            passengerCount = passengerCount,
            origin = origin,
            destination = destination,
            serviceOption = selectedService,
            routePoints = waypoints,
            totalDistanceMiles = fare.distanceMiles,
            estimatedDurationMinutes = fare.estimatedDurationMinutes,
            fareBase = fare.baseFare,
            fareDistance = fare.distanceFare,
            fareTime = fare.timeFare,
            fees = fare.serviceFee,
            discount = fare.discount,
            fareTotal = fare.total
        )

        _activeRide.value = newRide
        logEvent("DESTINATION_SELECTED", "Destination set to ${destination.name}")
    }

    fun requestCybercab(passengerCount: Int, serviceOption: ServiceOption, isAccessible: Boolean) {
        val ride = _activeRide.value ?: return

        // Dispatch best vehicle
        val vehicle = dispatchEngine.dispatchOptimalVehicle(
            fleet = fleetSimulator.fleet.value,
            passengerLocation = ride.origin,
            requiredCapacity = passengerCount,
            requireAccessibility = isAccessible,
            preferXL = serviceOption.capacity >= 6
        ) ?: CybercabVehicle(
            id = "veh_CC-0421",
            code = "CC-0421",
            name = serviceOption.name,
            capacity = serviceOption.capacity,
            batteryLevel = 92,
            isAccessible = isAccessible,
            latitude = ride.origin.latitude + 0.015,
            longitude = ride.origin.longitude + 0.012,
            status = VehicleStatus.DISPATCHED
        )

        _activeRide.value = ride.copy(
            state = RideState.VEHICLE_DISPATCHED,
            assignedVehicle = vehicle,
            passengerCount = passengerCount,
            serviceOption = serviceOption
        )

        logEvent("RIDE_REQUESTED", "Cybercab request transmitted to Tesla Fleet Platform")
        logEvent("VEHICLE_ASSIGNED", "Vehicle ${vehicle.code} assigned to Ride ${ride.id}")

        startApproachSimulation(vehicle, ride.origin)
    }

    private fun startApproachSimulation(vehicle: CybercabVehicle, pickupLocation: LocationPoint) {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            // Generate approach route waypoints
            val approachWaypoints = SyntheticLondonData.generateRouteWaypoints(
                vehicle.latitude, vehicle.longitude,
                pickupLocation.latitude, pickupLocation.longitude,
                steps = 10
            )

            for (i in approachWaypoints.indices) {
                delay(1200)
                val currentRide = _activeRide.value ?: break
                if (currentRide.state != RideState.VEHICLE_DISPATCHED && currentRide.state != RideState.EN_ROUTE) break

                val point = approachWaypoints[i]
                val bearing = fleetSimulator.calculateBearing(
                    if (i > 0) approachWaypoints[i - 1].first else vehicle.latitude,
                    if (i > 0) approachWaypoints[i - 1].second else vehicle.longitude,
                    point.first, point.second
                )

                val updatedVeh = vehicle.copy(
                    latitude = point.first,
                    longitude = point.second,
                    heading = bearing,
                    speed = 22f,
                    status = VehicleStatus.EN_ROUTE
                )

                val state = if (i > 6) RideState.EN_ROUTE else RideState.VEHICLE_DISPATCHED
                val remMin = ((approachWaypoints.size - i) * 0.3).toInt().coerceAtLeast(1)

                _activeRide.value = currentRide.copy(
                    state = state,
                    assignedVehicle = updatedVeh,
                    estimatedDurationMinutes = remMin
                )

                fleetSimulator.updateVehiclePosition(
                    updatedVeh.id, point.first, point.second, bearing, 22f, VehicleStatus.EN_ROUTE
                )
            }

            // Vehicle Arrived!
            delay(1000)
            _activeRide.value?.let { currentRide ->
                val arrivedVeh = currentRide.assignedVehicle?.copy(
                    latitude = pickupLocation.latitude,
                    longitude = pickupLocation.longitude,
                    speed = 0f,
                    status = VehicleStatus.ARRIVED
                )
                _activeRide.value = currentRide.copy(
                    state = RideState.ARRIVED,
                    assignedVehicle = arrivedVeh
                )
                logEvent("VEHICLE_ARRIVED", "Cybercab ${arrivedVeh?.code} arrived at ${pickupLocation.name}")
            }
        }
    }

    fun unlockVehicle() {
        val ride = _activeRide.value ?: return
        if (ride.state != RideState.ARRIVED) return

        logEvent("PASSENGER_VERIFIED", "Secure ride token ${ride.rideToken} validated")
        logEvent("VEHICLE_UNLOCKED", "Tesla Cybercab doors unlocked")

        _activeRide.value = ride.copy(
            state = RideState.BOARDING,
            isUnlocked = true
        )

        // Auto start autonomous ride after boarding delay
        scope.launch {
            delay(2500)
            startAutonomousRide()
        }
    }

    fun startAutonomousRide() {
        val ride = _activeRide.value ?: return

        _activeRide.value = ride.copy(
            state = RideState.IN_RIDE,
            assignedVehicle = ride.assignedVehicle?.copy(status = VehicleStatus.IN_RIDE)
        )
        logEvent("PASSENGER_BOARDED", "Passenger boarded vehicle")
        logEvent("RIDE_STARTED", "Autonomous trip initiated to ${ride.destination.name}")

        startInRideSimulation()
    }

    private fun startInRideSimulation() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            val ride = _activeRide.value ?: return@launch
            val route = ride.routePoints

            for (i in 0 until route.size) {
                delay(1800)
                val currentRide = _activeRide.value ?: break
                if (currentRide.state != RideState.IN_RIDE && currentRide.state != RideState.ARRIVING) break

                val point = route[i]
                val prevPoint = if (i > 0) route[i - 1] else Pair(currentRide.origin.latitude, currentRide.origin.longitude)
                val bearing = fleetSimulator.calculateBearing(prevPoint.first, prevPoint.second, point.first, point.second)

                val updatedVeh = currentRide.assignedVehicle?.copy(
                    latitude = point.first,
                    longitude = point.second,
                    heading = bearing,
                    speed = 28f,
                    status = VehicleStatus.IN_RIDE
                )

                val remainingSteps = route.size - i
                val remainingMin = (remainingSteps * 0.8).toInt().coerceAtLeast(1)
                val remainingMiles = (currentRide.totalDistanceMiles * (remainingSteps.toDouble() / route.size)).coerceAtLeast(0.1)

                val state = if (i >= route.size - 3) RideState.ARRIVING else RideState.IN_RIDE

                _activeRide.value = currentRide.copy(
                    state = state,
                    assignedVehicle = updatedVeh,
                    currentRouteIndex = i,
                    estimatedDurationMinutes = remainingMin,
                    totalDistanceMiles = Math.round(remainingMiles * 10.0) / 10.0
                )
            }

            // Arrived at destination!
            delay(1000)
            completeTrip()
        }
    }

    fun updateCabinSettings(settings: CabinSettings) {
        _activeRide.value = _activeRide.value?.copy(cabinSettings = settings)
    }

    fun changeDestination(newDestination: LocationPoint) {
        val ride = _activeRide.value ?: return
        val currentLoc = ride.assignedVehicle?.let {
            LocationPoint(name = "Current Location", address = "In Transit", latitude = it.latitude, longitude = it.longitude)
        } ?: ride.origin

        val dist = dispatchEngine.calculateHaversineMiles(
            currentLoc.latitude, currentLoc.longitude,
            newDestination.latitude, newDestination.longitude
        ).coerceAtLeast(1.0)

        val waypoints = SyntheticLondonData.generateRouteWaypoints(
            currentLoc.latitude, currentLoc.longitude,
            newDestination.latitude, newDestination.longitude
        )

        val fare = pricingEngine.calculateFare(dist, (dist * 3).toInt() + 5, ride.serviceOption)

        _activeRide.value = ride.copy(
            destination = newDestination,
            routePoints = waypoints,
            currentRouteIndex = 0,
            totalDistanceMiles = fare.distanceMiles,
            estimatedDurationMinutes = fare.estimatedDurationMinutes,
            fareTotal = fare.total
        )

        logEvent("ROUTE_UPDATED", "Destination changed to ${newDestination.name}. Route recalculated.")
        if (ride.state == RideState.IN_RIDE || ride.state == RideState.ARRIVING) {
            startInRideSimulation()
        }
    }

    fun addStop(stop: LocationPoint) {
        val ride = _activeRide.value ?: return
        val updatedStops = ride.stops + stop
        _activeRide.value = ride.copy(
            stops = updatedStops,
            fareTotal = ride.fareTotal + 2.50
        )
        logEvent("ROUTE_UPDATED", "Intermediate stop added: ${stop.name}")
    }

    fun completeTrip() {
        val ride = _activeRide.value ?: return
        _activeRide.value = ride.copy(
            state = RideState.COMPLETED,
            assignedVehicle = ride.assignedVehicle?.copy(status = VehicleStatus.AVAILABLE, speed = 0f)
        )
        logEvent("RIDE_COMPLETED", "Trip to ${ride.destination.name} safely completed")
        logEvent("PAYMENT_COMPLETED", "Automatic fare £${ride.fareTotal} processed via Visa •••• 4821")
    }

    fun resetRide() {
        simulationJob?.cancel()
        _activeRide.value = null
        _rideEvents.value = emptyList()
    }

    fun cancelRide() {
        simulationJob?.cancel()
        logEvent("RIDE_CANCELLED", "Ride cancelled by passenger")
        _activeRide.value = _activeRide.value?.copy(state = RideState.CANCELLED)
    }

    private fun logEvent(eventName: String, description: String) {
        val list = _rideEvents.value.toMutableList()
        list.add(RideEvent(eventName = eventName, description = description))
        _rideEvents.value = list
    }
}
