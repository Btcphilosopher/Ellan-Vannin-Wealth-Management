package com.example.data.simulator

import com.example.data.model.ServiceOption

data class FareBreakdown(
    val baseFare: Double,
    val distanceFare: Double,
    val timeFare: Double,
    val serviceFee: Double,
    val discount: Double,
    val total: Double,
    val currencySymbol: String = "£",
    val distanceMiles: Double,
    val estimatedDurationMinutes: Int
)

class PricingEngine {

    fun calculateFare(
        distanceMiles: Double,
        estimatedDurationMinutes: Int,
        serviceOption: ServiceOption,
        hasCybercabPass: Boolean = false,
        isCorporateAccount: Boolean = false
    ): FareBreakdown {
        val base = 3.50 * serviceOption.priceMultiplier
        val distFare = distanceMiles * 1.00 * serviceOption.priceMultiplier
        val timeFare = estimatedDurationMinutes * 0.10 * serviceOption.priceMultiplier
        val fee = if (hasCybercabPass) 0.0 else 1.60

        val rawTotal = base + distFare + timeFare + fee
        val discount = if (hasCybercabPass) (rawTotal * 0.15) else if (isCorporateAccount) (rawTotal * 0.10) else 0.0
        val finalTotal = (rawTotal - discount).coerceAtLeast(2.50)

        return FareBreakdown(
            baseFare = Math.round(base * 100.0) / 100.0,
            distanceFare = Math.round(distFare * 100.0) / 100.0,
            timeFare = Math.round(timeFare * 100.0) / 100.0,
            serviceFee = Math.round(fee * 100.0) / 100.0,
            discount = Math.round(discount * 100.0) / 100.0,
            total = Math.round(finalTotal * 100.0) / 100.0,
            currencySymbol = "£",
            distanceMiles = Math.round(distanceMiles * 10.0) / 10.0,
            estimatedDurationMinutes = estimatedDurationMinutes
        )
    }
}
