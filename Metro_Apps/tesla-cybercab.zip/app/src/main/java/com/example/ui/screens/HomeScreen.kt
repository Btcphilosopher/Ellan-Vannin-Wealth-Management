package com.example.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import com.example.data.model.RideState
import com.example.data.simulator.SyntheticLondonData
import com.example.ui.MainViewModel
import com.example.ui.components.AutonomousRideCard
import com.example.ui.components.CabinControlsModal
import com.example.ui.components.CybercabMapCanvas
import com.example.ui.components.DestinationSearchSheet
import com.example.ui.components.RideEstimateCard
import com.example.ui.components.SafetyAndEmergencyModal
import com.example.ui.components.TeslaHeader
import com.example.ui.components.TeslaSupportModal
import com.example.ui.components.TripCompletedSheet
import com.example.ui.components.VehicleApproachingCard
import com.example.ui.components.VehicleArrivedCard

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    viewModel: MainViewModel
) {
    val activeRide by viewModel.activeRide.collectAsState()
    val fleetVehicles by viewModel.fleetVehicles.collectAsState()
    val savedPlaces by viewModel.savedPlaces.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()

    var showCabinModal by remember { mutableStateOf(false) }
    var showSafetyModal by remember { mutableStateOf(false) }
    var showSupportModal by remember { mutableStateOf(false) }
    var showDestinationSearchModal by remember { mutableStateOf(false) }

    val userLocation = activeRide?.origin ?: SyntheticLondonData.CENTRAL_LONDON
    val destinationLocation = activeRide?.destination
    val activeVehicle = activeRide?.assignedVehicle
    val routePoints = activeRide?.routePoints ?: emptyList()
    val currentRouteIndex = activeRide?.currentRouteIndex ?: 0

    Box(modifier = modifier.fillMaxSize()) {
        // 1. Interactive Map Canvas Surface
        CybercabMapCanvas(
            modifier = Modifier.fillMaxSize(),
            isDarkMode = isDarkMode,
            userLocation = userLocation,
            destinationLocation = destinationLocation,
            vehicles = fleetVehicles,
            activeVehicle = activeVehicle,
            routePoints = routePoints,
            currentRouteIndex = currentRouteIndex,
            showAllFleet = activeRide == null || activeRide?.state == RideState.IDLE
        )

        // 2. Top Header Overlay
        TeslaHeader(
            modifier = Modifier.align(Alignment.TopCenter),
            isDarkMode = isDarkMode,
            onToggleDarkMode = { viewModel.toggleDarkMode() },
            simulationModeActive = true
        )

        // 3. Dynamic Bottom Ride State Sheet
        Box(modifier = Modifier.align(Alignment.BottomCenter)) {
            when (activeRide?.state) {
                null, RideState.IDLE -> {
                    DestinationSearchSheet(
                        savedPlaces = savedPlaces,
                        onSelectLocation = { location ->
                            viewModel.selectDestination(location)
                        }
                    )
                }

                RideState.DESTINATION_SELECTED -> {
                    activeRide?.let { ride ->
                        RideEstimateCard(
                            ride = ride,
                            availableServices = viewModel.rideRepository.availableServices,
                            onRequestCybercab = { count, service ->
                                viewModel.requestCybercab(count, service)
                            }
                        )
                    }
                }

                RideState.VEHICLE_DISPATCHED, RideState.EN_ROUTE -> {
                    activeRide?.let { ride ->
                        VehicleApproachingCard(
                            ride = ride,
                            onCancelRide = { viewModel.cancelRide() },
                            onOpenSafetyModal = { showSafetyModal = true }
                        )
                    }
                }

                RideState.ARRIVED -> {
                    activeRide?.let { ride ->
                        VehicleArrivedCard(
                            ride = ride,
                            onUnlockVehicle = { viewModel.unlockVehicle() },
                            onFindCybercab = { showSafetyModal = true }
                        )
                    }
                }

                RideState.BOARDING, RideState.IN_RIDE, RideState.ARRIVING -> {
                    activeRide?.let { ride ->
                        AutonomousRideCard(
                            ride = ride,
                            onOpenCabinControls = { showCabinModal = true },
                            onChangeDestination = { showDestinationSearchModal = true },
                            onAddStop = { showDestinationSearchModal = true },
                            onShareTrip = { showSafetyModal = true },
                            onOpenSafetyModal = { showSafetyModal = true }
                        )
                    }
                }

                RideState.COMPLETED -> {
                    activeRide?.let { ride ->
                        TripCompletedSheet(
                            ride = ride,
                            onSubmitFeedback = { feedback ->
                                viewModel.submitRideFeedback(feedback)
                            }
                        )
                    }
                }

                RideState.CANCELLED -> {
                    DestinationSearchSheet(
                        savedPlaces = savedPlaces,
                        onSelectLocation = { location ->
                            viewModel.selectDestination(location)
                        }
                    )
                }
            }
        }

        // Modals
        if (showCabinModal && activeRide != null) {
            CabinControlsModal(
                currentSettings = activeRide!!.cabinSettings,
                onDismiss = { showCabinModal = false },
                onSaveSettings = { updated -> viewModel.updateCabinSettings(updated) }
            )
        }

        if (showSafetyModal) {
            SafetyAndEmergencyModal(
                ride = activeRide,
                onDismiss = { showSafetyModal = false },
                onOpenTeslaSupport = { showSupportModal = true }
            )
        }

        if (showSupportModal) {
            TeslaSupportModal(
                ride = activeRide,
                onDismiss = { showSupportModal = false }
            )
        }

        if (showDestinationSearchModal) {
            DestinationSearchSheet(
                savedPlaces = savedPlaces,
                onSelectLocation = { loc ->
                    showDestinationSearchModal = false
                    viewModel.changeDestination(loc)
                }
            )
        }
    }
}
