package com.example.data.simulator

import com.example.data.model.CybercabVehicle
import com.example.data.model.LocationPoint
import com.example.data.model.VehicleStatus
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

class DispatchEngine {

    fun dispatchOptimalVehicle(
        fleet: List<CybercabVehicle>,
        passengerLocation: LocationPoint,
        requiredCapacity: Int = 1,
        requireAccessibility: Boolean = false,
        preferXL: Boolean = false
    ): CybercabVehicle? {
        val eligible = fleet.filter { vehicle ->
            vehicle.status == VehicleStatus.AVAILABLE &&
            vehicle.batteryLevel > 20 &&
            vehicle.capacity >= requiredCapacity &&
            (!requireAccessibility || vehicle.isAccessible) &&
            (!preferXL || vehicle.capacity >= 6)
        }

        if (eligible.isEmpty()) {
            // Fallback to any available vehicle with sufficient capacity
            return fleet.firstOrNull {
                it.status == VehicleStatus.AVAILABLE && it.capacity >= requiredCapacity
            } ?: fleet.firstOrNull()
        }

        // Return closest eligible vehicle by Haversine distance
        return eligible.minByOrNull { vehicle ->
            calculateHaversineMiles(
                passengerLocation.latitude, passengerLocation.longitude,
                vehicle.latitude, vehicle.longitude
            )
        }
    }

    fun calculateHaversineMiles(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 3958.8 // Radius of earth in miles
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2.0) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2.0)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}
