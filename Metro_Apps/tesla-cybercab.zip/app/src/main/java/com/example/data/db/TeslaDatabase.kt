package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [SavedPlaceEntity::class, RideHistoryEntity::class, PaymentMethodEntity::class],
    version = 1,
    exportSchema = false
)
abstract class TeslaDatabase : RoomDatabase() {
    abstract fun savedPlaceDao(): SavedPlaceDao
    abstract fun rideHistoryDao(): RideHistoryDao
    abstract fun paymentMethodDao(): PaymentMethodDao

    companion object {
        @Volatile
        private var INSTANCE: TeslaDatabase? = null

        fun getDatabase(context: Context): TeslaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TeslaDatabase::class.java,
                    "tesla_cybercab_db"
                )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = getDatabase(context)
                            populateInitialData(database)
                        }
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun populateInitialData(db: TeslaDatabase) {
            // Default Saved Places
            db.savedPlaceDao().insertAll(
                listOf(
                    SavedPlaceEntity(
                        id = "sp_home",
                        name = "Home",
                        address = "10 Downing Street, Westminster, London",
                        latitude = 51.5034,
                        longitude = -0.1276,
                        category = "Home",
                        iconName = "home"
                    ),
                    SavedPlaceEntity(
                        id = "sp_work",
                        name = "Work (Canary Wharf)",
                        address = "1 Canada Square, Canary Wharf, London",
                        latitude = 51.5050,
                        longitude = -0.0209,
                        category = "Work",
                        iconName = "work"
                    ),
                    SavedPlaceEntity(
                        id = "sp_airport",
                        name = "Heathrow Airport T5",
                        address = "Terminal 5, Heathrow Airport, Hounslow",
                        latitude = 51.4700,
                        longitude = -0.4543,
                        category = "Airport",
                        iconName = "flight"
                    ),
                    SavedPlaceEntity(
                        id = "sp_station",
                        name = "King's Cross Station",
                        address = "Euston Road, King's Cross, London",
                        latitude = 51.5320,
                        longitude = -0.1240,
                        category = "Station",
                        iconName = "train"
                    ),
                    SavedPlaceEntity(
                        id = "sp_oxford",
                        name = "Oxford Street",
                        address = "Selfridges, Oxford Street, London",
                        latitude = 51.5144,
                        longitude = -0.1528,
                        category = "Landmark",
                        iconName = "shopping_bag"
                    )
                )
            )

            // Default Payment Methods
            db.paymentMethodDao().insertAll(
                listOf(
                    PaymentMethodEntity(
                        id = "pay_visa_4821",
                        title = "Visa ending in 4821",
                        subtitle = "Expires 11/28",
                        iconName = "credit_card",
                        isDefault = true,
                        cardBrand = "Visa",
                        last4 = "4821"
                    ),
                    PaymentMethodEntity(
                        id = "pay_apple_pay",
                        title = "Apple Pay / Google Pay",
                        subtitle = "Instant One-Tap Checkout",
                        iconName = "account_balance_wallet",
                        isDefault = false,
                        cardBrand = "Digital Wallet",
                        last4 = "GPay"
                    ),
                    PaymentMethodEntity(
                        id = "pay_tesla_account",
                        title = "Tesla Wallet",
                        subtitle = "Balance: £250.00",
                        iconName = "electric_car",
                        isDefault = false,
                        cardBrand = "Tesla Pay",
                        last4 = "TSLA"
                    )
                )
            )

            // Default Ride History
            val now = System.currentTimeMillis()
            val day = 86400000L
            db.rideHistoryDao().insertRide(
                RideHistoryEntity(
                    id = "RIDE-991A04",
                    pickupCode = "4827",
                    originName = "King's Cross Station",
                    destinationName = "Canary Wharf",
                    vehicleCode = "CC-0421",
                    vehicleName = "Tesla Cybercab",
                    fareTotal = 11.80,
                    currencySymbol = "£",
                    timestampMillis = now - (day * 1),
                    durationMinutes = 21,
                    distanceMiles = 6.4,
                    serviceName = "Cybercab"
                )
            )
            db.rideHistoryDao().insertRide(
                RideHistoryEntity(
                    id = "RIDE-882B12",
                    pickupCode = "1092",
                    originName = "Home",
                    destinationName = "Oxford Street",
                    vehicleCode = "CC-0089",
                    vehicleName = "Tesla Cybercab",
                    fareTotal = 9.40,
                    currencySymbol = "£",
                    timestampMillis = now - (day * 2),
                    durationMinutes = 15,
                    distanceMiles = 4.2,
                    serviceName = "Cybercab"
                )
            )
            db.rideHistoryDao().insertRide(
                RideHistoryEntity(
                    id = "RIDE-773C99",
                    pickupCode = "6614",
                    originName = "Heathrow Airport T5",
                    destinationName = "Home",
                    vehicleCode = "CC-0012",
                    vehicleName = "Tesla Cybercab XL",
                    fareTotal = 31.20,
                    currencySymbol = "£",
                    timestampMillis = now - (day * 6),
                    durationMinutes = 42,
                    distanceMiles = 18.5,
                    serviceName = "Cybercab XL"
                )
            )
        }
    }
}
