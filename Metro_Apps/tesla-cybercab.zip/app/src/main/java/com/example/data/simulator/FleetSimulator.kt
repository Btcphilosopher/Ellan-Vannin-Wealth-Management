package com.example.data.simulator

import com.example.data.model.CybercabVehicle
import com.example.data.model.VehicleStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class FleetSimulator {
    private val _fleet = MutableStateFlow<List<CybercabVehicle>>(emptyList())
    val fleet: StateFlow<List<CybercabVehicle>> = _fleet.asStateFlow()

    init {
        generateInitialFleet()
    }

    private fun generateInitialFleet() {
        val initialVehicles = mutableListOf<CybercabVehicle>()
        val baseLat = 51.5074
        val baseLng = -0.1278

        for (i in 1..100) {
            val code = "CC-" + String.format("%04d", i)
            // Spread across London
            val latOffset = (Random.nextDouble() - 0.5) * 0.12
            val lngOffset = (Random.nextDouble() - 0.5) * 0.25
            val battery = Random.nextInt(25, 100)
            val isAccessible = i % 5 == 0 // Every 5th vehicle is wheelchair accessible
            val capacity = if (i % 8 == 0) 6 else 4

            val status = when {
                battery < 30 -> VehicleStatus.CHARGING
                i % 12 == 0 -> VehicleStatus.MAINTENANCE
                else -> VehicleStatus.AVAILABLE
            }

            initialVehicles.add(
                CybercabVehicle(
                    id = "veh_$code",
                    code = code,
                    name = if (capacity == 6) "Tesla Cybercab XL" else "Tesla Cybercab",
                    color = if (i % 3 == 0) "Satin Black" else "Metallic Silver",
                    capacity = capacity,
                    batteryLevel = battery,
                    isAccessible = isAccessible,
                    latitude = baseLat + latOffset,
                    longitude = baseLng + lngOffset,
                    heading = Random.nextFloat() * 360f,
                    speed = if (status == VehicleStatus.AVAILABLE) Random.nextFloat() * 20f + 10f else 0f,
                    status = status,
                    chargingStation = if (status == VehicleStatus.CHARGING) "Supercharger Canary Wharf V4" else null
                )
            )
        }
        _fleet.value = initialVehicles
    }

    fun updateVehiclePosition(vehicleId: String, newLat: Double, newLng: Double, heading: Float, speed: Float, status: VehicleStatus) {
        val currentList = _fleet.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == vehicleId }
        if (index != -1) {
            val oldVeh = currentList[index]
            currentList[index] = oldVeh.copy(
                latitude = newLat,
                longitude = newLng,
                heading = heading,
                speed = speed,
                status = status,
                batteryLevel = (oldVeh.batteryLevel - 0.01).coerceAtLeast(15.0).toInt()
            )
            _fleet.value = currentList
        }
    }

    fun calculateBearing(startLat: Double, startLng: Double, endLat: Double, endLng: Double): Float {
        val dLng = Math.toRadians(endLng - startLng)
        val lat1 = Math.toRadians(startLat)
        val lat2 = Math.toRadians(endLat)

        val y = sin(dLng) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLng)

        var bearing = Math.toDegrees(atan2(y, x)).toFloat()
        if (bearing < 0) {
            bearing += 360f
        }
        return bearing
    }
}
