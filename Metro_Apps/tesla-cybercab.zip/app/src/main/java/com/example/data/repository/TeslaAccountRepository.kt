package com.example.data.repository

import com.example.data.db.PaymentMethodDao
import com.example.data.db.PaymentMethodEntity
import com.example.data.db.RideHistoryDao
import com.example.data.db.RideHistoryEntity
import com.example.data.db.SavedPlaceDao
import com.example.data.db.SavedPlaceEntity
import com.example.data.model.PassengerProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TeslaAccountRepository(
    private val savedPlaceDao: SavedPlaceDao,
    private val rideHistoryDao: RideHistoryDao,
    private val paymentMethodDao: PaymentMethodDao
) {
    private val _profile = MutableStateFlow(PassengerProfile())
    val profile: StateFlow<PassengerProfile> = _profile.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    val savedPlaces: Flow<List<SavedPlaceEntity>> = savedPlaceDao.getAllSavedPlaces()
    val rideHistory: Flow<List<RideHistoryEntity>> = rideHistoryDao.getAllRides()
    val paymentMethods: Flow<List<PaymentMethodEntity>> = paymentMethodDao.getAllPaymentMethods()

    suspend fun savePlace(place: SavedPlaceEntity) {
        savedPlaceDao.insertPlace(place)
    }

    suspend fun deletePlace(id: String) {
        savedPlaceDao.deletePlace(id)
    }

    suspend fun addRideHistory(ride: RideHistoryEntity) {
        rideHistoryDao.insertRide(ride)
    }

    fun updateProfile(newProfile: PassengerProfile) {
        _profile.value = newProfile
    }

    fun toggleCybercabPass(enabled: Boolean) {
        _profile.value = _profile.value.copy(
            isCybercabPassHolder = enabled,
            passTier = if (enabled) "Cybercab Pass Unlimited" else "None"
        )
    }

    fun toggleBusinessMode(enabled: Boolean) {
        _profile.value = _profile.value.copy(isBusinessModeEnabled = enabled)
    }

    fun toggleFamilyMode(enabled: Boolean) {
        _profile.value = _profile.value.copy(isFamilyModeEnabled = enabled)
    }

    fun updateAccessibilitySettings(
        wheelchair: Boolean,
        extraTime: Boolean,
        animal: Boolean,
        mobility: Boolean
    ) {
        _profile.value = _profile.value.copy(
            wheelchairAccessibleRequired = wheelchair,
            extraBoardingTimeRequired = extraTime,
            assistanceAnimalPresent = animal,
            reducedMobilityAssistance = mobility
        )
    }
}
