package com.example.data.simulator

import com.example.data.model.LocationPoint

object SyntheticLondonData {
    // Center point (Piccadilly / Trafalgar / Soho area)
    val CENTRAL_LONDON = LocationPoint(
        id = "loc_central",
        name = "Piccadilly Circus",
        address = "Piccadilly Circus, City of Westminster, London",
        latitude = 51.5101,
        longitude = -0.1342,
        category = "Landmark",
        iconName = "place"
    )

    val CANARY_WHARF = LocationPoint(
        id = "loc_canary",
        name = "Canary Wharf",
        address = "1 Canada Square, Canary Wharf, London E14 5AA",
        latitude = 51.5050,
        longitude = -0.0209,
        category = "Work",
        iconName = "business"
    )

    val KINGS_CROSS = LocationPoint(
        id = "loc_kingscross",
        name = "King's Cross Station",
        address = "Euston Road, King's Cross, London N1 9AL",
        latitude = 51.5320,
        longitude = -0.1240,
        category = "Station",
        iconName = "train"
    )

    val HEATHROW_T5 = LocationPoint(
        id = "loc_heathrow",
        name = "Heathrow Airport Terminal 5",
        address = "Terminal 5, Heathrow Airport, TW6 2GA",
        latitude = 51.4700,
        longitude = -0.4543,
        category = "Airport",
        iconName = "flight"
    )

    val OXFORD_STREET = LocationPoint(
        id = "loc_oxford",
        name = "Oxford Street",
        address = "400 Oxford Street, Marylebone, London W1A 1AB",
        latitude = 51.5144,
        longitude = -0.1528,
        category = "Landmark",
        iconName = "shopping_bag"
    )

    val TOWER_BRIDGE = LocationPoint(
        id = "loc_towerbridge",
        name = "Tower Bridge",
        address = "Tower Bridge Road, London SE1 2UP",
        latitude = 51.5055,
        longitude = -0.0754,
        category = "Landmark",
        iconName = "attractions"
    )

    val WESTMINSTER = LocationPoint(
        id = "loc_westminster",
        name = "Westminster Abbey",
        address = "20 Dean's Yard, London SW1P 3PA",
        latitude = 51.4993,
        longitude = -0.1273,
        category = "Landmark",
        iconName = "church"
    )

    val ALL_LOCATIONS = listOf(
        CENTRAL_LONDON,
        CANARY_WHARF,
        KINGS_CROSS,
        HEATHROW_T5,
        OXFORD_STREET,
        TOWER_BRIDGE,
        WESTMINSTER
    )

    // Generates smooth route waypoints between 2 coordinates
    fun generateRouteWaypoints(
        originLat: Double, originLng: Double,
        destLat: Double, destLng: Double,
        steps: Int = 20
    ): List<Pair<Double, Double>> {
        val points = mutableListOf<Pair<Double, Double>>()
        val midLat = (originLat + destLat) / 2.0
        val midLng = (originLng + destLng) / 2.0

        // Add a slight curve to simulate road navigation
        val curveOffsetLat = (destLng - originLng) * 0.12
        val curveOffsetLng = -(destLat - originLat) * 0.12

        for (i in 0..steps) {
            val t = i.toDouble() / steps
            // Quadratic Bezier interpolation
            val lat = (1 - t) * (1 - t) * originLat + 2 * (1 - t) * t * (midLat + curveOffsetLat) + t * t * destLat
            val lng = (1 - t) * (1 - t) * originLng + 2 * (1 - t) * t * (midLng + curveOffsetLng) + t * t * destLng
            points.add(Pair(lat, lng))
        }
        return points
    }
}
