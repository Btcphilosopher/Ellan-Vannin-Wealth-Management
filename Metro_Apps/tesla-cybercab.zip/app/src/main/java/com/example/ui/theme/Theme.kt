package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = TeslaWhite,
    onPrimary = TeslaBlack,
    primaryContainer = TeslaDarkCard,
    onPrimaryContainer = TeslaWhite,
    secondary = TeslaSilver,
    onSecondary = TeslaBlack,
    secondaryContainer = TeslaDarkGraphite,
    onSecondaryContainer = TeslaSilver,
    background = TeslaDarkBackground,
    onBackground = TeslaWhite,
    surface = TeslaDarkSurface,
    onSurface = TeslaWhite,
    surfaceVariant = TeslaDarkCard,
    onSurfaceVariant = TeslaTextMuted,
    outline = TeslaDarkBorder,
    error = TeslaRed,
    onError = TeslaWhite
)

private val LightColorScheme = lightColorScheme(
    primary = TeslaBlack,
    onPrimary = TeslaWhite,
    primaryContainer = TeslaLightCard,
    onPrimaryContainer = TeslaBlack,
    secondary = TeslaDarkGraphite,
    onSecondary = TeslaWhite,
    secondaryContainer = TeslaLightGraphite,
    onSecondaryContainer = TeslaBlack,
    background = TeslaLightBackground,
    onBackground = TeslaBlack,
    surface = TeslaLightSurface,
    onSurface = TeslaBlack,
    surfaceVariant = TeslaLightCard,
    onSurfaceVariant = TeslaLightText,
    outline = TeslaLightBorder,
    error = TeslaRed,
    onError = TeslaWhite
)

@Composable
fun TeslaCybercabTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
