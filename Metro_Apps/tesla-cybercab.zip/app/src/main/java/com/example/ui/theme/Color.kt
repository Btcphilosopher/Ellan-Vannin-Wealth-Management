package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tesla Dark Palette (Default)
val TeslaDarkBackground = Color(0xFF09090B)
val TeslaDarkSurface = Color(0xFF121215)
val TeslaDarkCard = Color(0xFF1C1C1F)
val TeslaDarkGraphite = Color(0xFF2C2C2E)
val TeslaDarkBorder = Color(0xFF2C2C30)

// Tesla Light Palette
val TeslaLightBackground = Color(0xFFF4F4F6)
val TeslaLightSurface = Color(0xFFFFFFFF)
val TeslaLightCard = Color(0xFFE9E9EE)
val TeslaLightGraphite = Color(0xFFE5E5EA)
val TeslaLightBorder = Color(0xFFD1D1D6)
val TeslaLightText = Color(0xFF1C1C1E)

// Accent & Functional Colors
val TeslaRed = Color(0xFFE31937)
val TeslaSilver = Color(0xFFC0C0C6)
val TeslaWhite = Color(0xFFFFFFFF)
val TeslaBlack = Color(0xFF000000)
val TeslaGreen = Color(0xFF34C759)
val TeslaBlue = Color(0xFF0A84FF)
val TeslaYellow = Color(0xFFFFCC00)
val TeslaTextMuted = Color(0xFF8E8E93)
