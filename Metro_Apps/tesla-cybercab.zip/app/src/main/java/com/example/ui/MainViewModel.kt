package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.RideHistoryEntity
import com.example.data.db.SavedPlaceEntity
import com.example.data.db.TeslaDatabase
import com.example.data.model.ActiveRide
import com.example.data.model.CabinSettings
import com.example.data.model.CybercabVehicle
import com.example.data.model.FeedbackRating
import com.example.data.model.LocationPoint
import com.example.data.model.PassengerProfile
import com.example.data.model.RideState
import com.example.data.model.ServiceOption
import com.example.data.repository.RideRepository
import com.example.data.repository.TeslaAccountRepository
import com.example.data.simulator.DispatchEngine
import com.example.data.simulator.FleetSimulator
import com.example.data.simulator.PricingEngine
import com.example.data.simulator.SyntheticLondonData
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class NavigationTab {
    HOME,
    RIDES,
    MAP,
    WALLET,
    PROFILE
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TeslaDatabase.getDatabase(application)
    private val fleetSimulator = FleetSimulator()
    private val dispatchEngine = DispatchEngine()
    private val pricingEngine = PricingEngine()

    val rideRepository = RideRepository(fleetSimulator, dispatchEngine, pricingEngine)
    val accountRepository = TeslaAccountRepository(db.savedPlaceDao(), db.rideHistoryDao(), db.paymentMethodDao())

    val activeRide: StateFlow<ActiveRide?> = rideRepository.activeRide
    val fleetVehicles: StateFlow<List<CybercabVehicle>> = fleetSimulator.fleet
    val profile: StateFlow<PassengerProfile> = accountRepository.profile
    val isDarkMode: StateFlow<Boolean> = accountRepository.isDarkMode

    val savedPlaces: StateFlow<List<SavedPlaceEntity>> = accountRepository.savedPlaces.stateIn(
        viewModelScope, SharingStarted.Lazily, emptyList()
    )

    val rideHistory: StateFlow<List<RideHistoryEntity>> = accountRepository.rideHistory.stateIn(
        viewModelScope, SharingStarted.Lazily, emptyList()
    )

    val paymentMethods = accountRepository.paymentMethods.stateIn(
        viewModelScope, SharingStarted.Lazily, emptyList()
    )

    private val _currentTab = kotlinx.coroutines.flow.MutableStateFlow(NavigationTab.HOME)
    val currentTab: StateFlow<NavigationTab> = _currentTab

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun toggleDarkMode() {
        accountRepository.toggleDarkMode()
    }

    fun selectDestination(locationPoint: LocationPoint) {
        val prof = profile.value
        val pass = prof.isCybercabPassHolder
        rideRepository.selectDestination(
            origin = SyntheticLondonData.CENTRAL_LONDON,
            destination = locationPoint,
            hasPass = pass
        )
    }

    fun requestCybercab(passengerCount: Int, serviceOption: ServiceOption) {
        val prof = profile.value
        rideRepository.requestCybercab(
            passengerCount = passengerCount,
            serviceOption = serviceOption,
            isAccessible = prof.wheelchairAccessibleRequired
        )
    }

    fun unlockVehicle() {
        rideRepository.unlockVehicle()
    }

    fun updateCabinSettings(settings: CabinSettings) {
        rideRepository.updateCabinSettings(settings)
    }

    fun changeDestination(newDest: LocationPoint) {
        rideRepository.changeDestination(newDest)
    }

    fun addStop(stopLoc: LocationPoint) {
        rideRepository.addStop(stopLoc)
    }

    fun submitRideFeedback(feedback: FeedbackRating) {
        val ride = activeRide.value ?: return
        viewModelScope.launch {
            accountRepository.addRideHistory(
                RideHistoryEntity(
                    id = ride.id,
                    pickupCode = ride.pickupCode,
                    originName = ride.origin.name,
                    destinationName = ride.destination.name,
                    vehicleCode = ride.assignedVehicle?.code ?: "CC-0421",
                    vehicleName = ride.serviceOption.name,
                    fareTotal = ride.fareTotal,
                    currencySymbol = ride.currencySymbol,
                    timestampMillis = System.currentTimeMillis(),
                    durationMinutes = ride.estimatedDurationMinutes,
                    distanceMiles = ride.totalDistanceMiles,
                    serviceName = ride.serviceOption.name
                )
            )
            rideRepository.resetRide()
        }
    }

    fun cancelRide() {
        rideRepository.cancelRide()
    }

    fun resetRide() {
        rideRepository.resetRide()
    }
}
