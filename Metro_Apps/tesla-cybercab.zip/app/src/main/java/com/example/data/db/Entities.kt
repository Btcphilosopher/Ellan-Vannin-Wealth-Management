package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_places")
data class SavedPlaceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val category: String, // "Home", "Work", "Airport", "Gym", "Station", "Custom"
    val iconName: String
)

@Entity(tableName = "ride_history")
data class RideHistoryEntity(
    @PrimaryKey val id: String,
    val pickupCode: String,
    val originName: String,
    val destinationName: String,
    val vehicleCode: String,
    val vehicleName: String,
    val fareTotal: Double,
    val currencySymbol: String,
    val timestampMillis: Long,
    val durationMinutes: Int,
    val distanceMiles: Double,
    val serviceName: String
)

@Entity(tableName = "payment_methods")
data class PaymentMethodEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subtitle: String,
    val iconName: String,
    val isDefault: Boolean,
    val cardBrand: String,
    val last4: String
)
