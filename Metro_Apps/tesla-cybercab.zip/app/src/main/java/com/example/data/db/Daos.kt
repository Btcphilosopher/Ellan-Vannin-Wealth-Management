package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedPlaceDao {
    @Query("SELECT * FROM saved_places")
    fun getAllSavedPlaces(): Flow<List<SavedPlaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlace(place: SavedPlaceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(places: List<SavedPlaceEntity>)

    @Query("DELETE FROM saved_places WHERE id = :id")
    suspend fun deletePlace(id: String)
}

@Dao
interface RideHistoryDao {
    @Query("SELECT * FROM ride_history ORDER BY timestampMillis DESC")
    fun getAllRides(): Flow<List<RideHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRide(ride: RideHistoryEntity)

    @Query("SELECT * FROM ride_history WHERE id = :id")
    suspend fun getRideById(id: String): RideHistoryEntity?
}

@Dao
interface PaymentMethodDao {
    @Query("SELECT * FROM payment_methods")
    fun getAllPaymentMethods(): Flow<List<PaymentMethodEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(methods: List<PaymentMethodEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMethod(method: PaymentMethodEntity)
}
