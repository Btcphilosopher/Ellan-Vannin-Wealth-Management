package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import com.example.data.model.CybercabVehicle
import com.example.data.model.LocationPoint
import com.example.ui.theme.TeslaDarkBackground
import com.example.ui.theme.TeslaDarkBorder
import com.example.ui.theme.TeslaDarkCard
import com.example.ui.theme.TeslaDarkGraphite
import com.example.ui.theme.TeslaGreen
import com.example.ui.theme.TeslaBlue
import com.example.ui.theme.TeslaRed
import com.example.ui.theme.TeslaSilver
import com.example.ui.theme.TeslaTextMuted
import com.example.ui.theme.TeslaWhite

@Composable
fun CybercabMapCanvas(
    modifier: Modifier = Modifier,
    isDarkMode: Boolean = true,
    userLocation: LocationPoint,
    destinationLocation: LocationPoint? = null,
    vehicles: List<CybercabVehicle> = emptyList(),
    activeVehicle: CybercabVehicle? = null,
    routePoints: List<Pair<Double, Double>> = emptyList(),
    currentRouteIndex: Int = 0,
    showAllFleet: Boolean = true
) {
    // Zoom and pan gesture state
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    // Pulse animation for user pin & active vehicle
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 12f,
        targetValue = 32f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseAlpha"
    )

    // Center map around user or active vehicle
    val centerLat = activeVehicle?.latitude ?: userLocation.latitude
    val centerLng = activeVehicle?.longitude ?: userLocation.longitude

    // Coordinates conversion function to canvas pixels
    fun latLngToOffset(lat: Double, lng: Double, width: Float, height: Float): Offset {
        val latSpan = 0.15 / scale
        val lngSpan = 0.25 / scale

        val x = ((lng - centerLng) / lngSpan + 0.5) * width + offsetX
        val y = ((centerLat - lat) / latSpan + 0.5) * height + offsetY
        return Offset(x.toFloat(), y.toFloat())
    }

    val mapBgColor = if (isDarkMode) Color(0xFF0C0C0E) else Color(0xFFEFEFF4)
    val roadColor = if (isDarkMode) Color(0xFF1B1B20) else Color(0xFFFFFFFF)
    val roadGridColor = if (isDarkMode) Color(0xFF141418) else Color(0xFFE5E5EA)
    val riverColor = if (isDarkMode) Color(0xFF101928) else Color(0xFFD0E1F9)
    val textColor = if (isDarkMode) TeslaWhite else Color(0xFF000000)

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("cybercab_map_canvas")
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.5f, 4.0f)
                    offsetX += pan.x
                    offsetY += pan.y
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // 1. Background
            drawRect(color = mapBgColor)

            // 2. Simulated River Thames curve
            val riverPath = Path().apply {
                moveTo(0f, canvasHeight * 0.65f)
                cubicTo(
                    canvasWidth * 0.3f, canvasHeight * 0.55f,
                    canvasWidth * 0.6f, canvasHeight * 0.75f,
                    canvasWidth, canvasHeight * 0.60f
                )
            }
            drawPath(
                path = riverPath,
                color = riverColor,
                style = Stroke(width = 48f * scale, cap = StrokeCap.Round)
            )

            // 3. Grid / Road Network
            val gridStep = 80f * scale
            var x = (offsetX % gridStep)
            while (x < canvasWidth) {
                drawLine(
                    color = roadGridColor,
                    start = Offset(x, 0f),
                    end = Offset(x, canvasHeight),
                    strokeWidth = 2f
                )
                x += gridStep
            }
            var y = (offsetY % gridStep)
            while (y < canvasHeight) {
                drawLine(
                    color = roadGridColor,
                    start = Offset(0f, y),
                    end = Offset(canvasWidth, y),
                    strokeWidth = 2f
                )
                y += gridStep
            }

            // 4. Major Roads
            val mainRoadPath = Path().apply {
                moveTo(0f, canvasHeight * 0.35f)
                lineTo(canvasWidth, canvasHeight * 0.45f)
                moveTo(canvasWidth * 0.25f, 0f)
                lineTo(canvasWidth * 0.35f, canvasHeight)
                moveTo(canvasWidth * 0.70f, 0f)
                lineTo(canvasWidth * 0.60f, canvasHeight)
            }
            drawPath(
                path = mainRoadPath,
                color = roadColor,
                style = Stroke(width = 16f * scale, cap = StrokeCap.Round)
            )

            // 5. Draw Active Route Polyline if present
            if (routePoints.size > 1) {
                val routePath = Path()
                val completedPath = Path()

                for (i in routePoints.indices) {
                    val pt = routePoints[i]
                    val offset = latLngToOffset(pt.first, pt.second, canvasWidth, canvasHeight)
                    if (i == 0) {
                        routePath.moveTo(offset.x, offset.y)
                        completedPath.moveTo(offset.x, offset.y)
                    } else {
                        routePath.lineTo(offset.x, offset.y)
                        if (i <= currentRouteIndex) {
                            completedPath.lineTo(offset.x, offset.y)
                        }
                    }
                }

                // Remaining Route (Dashed / Silver Glow)
                drawPath(
                    path = routePath,
                    color = TeslaSilver,
                    style = Stroke(
                        width = 8f * scale,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 10f), 0f)
                    )
                )

                // Completed Progress Route (Solid White)
                drawPath(
                    path = completedPath,
                    color = TeslaWhite,
                    style = Stroke(
                        width = 10f * scale,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }

            // 6. Draw Nearby Fleet Cybercabs
            val visibleFleet = if (showAllFleet) vehicles else listOfNotNull(activeVehicle)
            visibleFleet.forEach { vehicle ->
                val pos = latLngToOffset(vehicle.latitude, vehicle.longitude, canvasWidth, canvasHeight)
                if (pos.x in -100f..(canvasWidth + 100f) && pos.y in -100f..(canvasHeight + 100f)) {
                    val isActive = vehicle.id == activeVehicle?.id

                    if (isActive) {
                        // Pulse aura for active assigned Cybercab
                        drawCircle(
                            color = TeslaRed.copy(alpha = pulseAlpha),
                            radius = pulseRadius * 1.5f,
                            center = pos
                        )
                    }

                    // Cybercab Vehicle Marker (Sleek Automotive Silhouette)
                    rotate(degrees = vehicle.heading, pivot = pos) {
                        val vWidth = if (isActive) 24f * scale else 16f * scale
                        val vHeight = if (isActive) 40f * scale else 28f * scale
                        val vColor = if (isActive) TeslaRed else if (isDarkMode) TeslaSilver else Color(0xFF3A3A3C)

                        drawRoundRect(
                            color = vColor,
                            topLeft = Offset(pos.x - vWidth / 2, pos.y - vHeight / 2),
                            size = Size(vWidth, vHeight),
                            cornerRadius = CornerRadius(6f, 6f)
                        )

                        // Windshield accent line
                        drawRect(
                            color = if (isDarkMode) Color.Black else Color.White,
                            topLeft = Offset(pos.x - vWidth * 0.35f, pos.y - vHeight * 0.2f),
                            size = Size(vWidth * 0.7f, vHeight * 0.25f)
                        )
                    }
                }
            }

            // 7. Destination Pin
            destinationLocation?.let { dest ->
                val destPos = latLngToOffset(dest.latitude, dest.longitude, canvasWidth, canvasHeight)
                drawCircle(color = TeslaRed, radius = 10f * scale, center = destPos)
                drawCircle(color = TeslaWhite, radius = 4f * scale, center = destPos)
            }

            // 8. User / Passenger Location Pin
            val userPos = latLngToOffset(userLocation.latitude, userLocation.longitude, canvasWidth, canvasHeight)
            // Pulse ring
            drawCircle(color = TeslaBlue.copy(alpha = pulseAlpha), radius = pulseRadius, center = userPos)
            // Outer ring
            drawCircle(color = TeslaWhite, radius = 8f * scale, center = userPos)
            // Center blue dot
            drawCircle(color = TeslaBlue, radius = 5f * scale, center = userPos)
        }
    }
}
