package com.example.data.model

import java.util.UUID

data class LocationPoint(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val category: String = "General", // "Saved", "Airport", "Station", "Recent", "Landmark"
    val iconName: String = "place"
)

enum class VehicleStatus {
    AVAILABLE,
    DISPATCHED,
    EN_ROUTE,
    ARRIVING,
    ARRIVED,
    BOARDING,
    IN_RIDE,
    DROPPING_OFF,
    CHARGING,
    MAINTENANCE,
    OFFLINE
}

data class CybercabVehicle(
    val id: String,
    val code: String, // e.g. "CC-0421"
    val name: String = "Tesla Cybercab",
    val color: String = "Metallic Silver",
    val capacity: Int = 4,
    val batteryLevel: Int = 88, // 0 - 100
    val isAccessible: Boolean = false,
    val latitude: Double,
    val longitude: Double,
    val heading: Float = 0f, // 0 - 360 degrees
    val speed: Float = 0f, // mph
    val status: VehicleStatus = VehicleStatus.AVAILABLE,
    val chargingStation: String? = null
)

data class ServiceOption(
    val id: String,
    val name: String,
    val tag: String,
    val description: String,
    val priceMultiplier: Double,
    val capacity: Int,
    val etaMinutes: Int,
    val isAccessible: Boolean = false
)

enum class RideState {
    IDLE,
    DESTINATION_SELECTED,
    VEHICLE_DISPATCHED,
    EN_ROUTE,
    ARRIVED,
    BOARDING,
    IN_RIDE,
    ARRIVING,
    COMPLETED,
    CANCELLED
}

data class CabinSettings(
    val temperatureCelsius: Float = 21.0f,
    val seatHeatingLevel: Int = 0, // 0 = off, 1, 2, 3
    val airflowMode: String = "Auto", // "Auto", "Direct", "Diffuse", "Feet"
    val ambientLightingColorHex: String = "#FFFFFF",
    val musicVolume: Int = 50
)

data class ActiveRide(
    val id: String = "RIDE-" + UUID.randomUUID().toString().take(6).uppercase(),
    val pickupCode: String = (1000..9999).random().toString(),
    val state: RideState = RideState.IDLE,
    val passengerCount: Int = 1,
    val origin: LocationPoint,
    val destination: LocationPoint,
    val stops: List<LocationPoint> = emptyList(),
    val serviceOption: ServiceOption,
    val assignedVehicle: CybercabVehicle? = null,
    val routePoints: List<Pair<Double, Double>> = emptyList(),
    val currentRouteIndex: Int = 0,
    val pickupZoneName: String = "Pickup Zone A",
    val walkDistanceMeters: Int = 45,
    val startTimeMillis: Long = System.currentTimeMillis(),
    val estimatedDurationMinutes: Int = 18,
    val totalDistanceMiles: Double = 6.4,
    val fareBase: Double = 3.50,
    val fareDistance: Double = 6.40,
    val fareTime: Double = 1.90,
    val fees: Double = 1.60,
    val discount: Double = 0.0,
    val fareTotal: Double = 11.80,
    val currencySymbol: String = "£",
    val cabinSettings: CabinSettings = CabinSettings(),
    val isUnlocked: Boolean = false,
    val rideToken: String = "SEC-" + UUID.randomUUID().toString().take(8).uppercase(),
    val shareToken: String = "https://cybercab.tesla.com/trip/" + UUID.randomUUID().toString().take(6)
)

data class PassengerProfile(
    val name: String = "Alex Vance",
    val email: String = "alex.vance@tesla.com",
    val phone: String = "+44 7700 900123",
    val teslaAccountId: String = "TSLA-8829-402",
    val isCybercabPassHolder: Boolean = true,
    val passTier: String = "Cybercab Pass Unlimited",
    val defaultPaymentMethodId: String = "pay_visa_4821",
    val isFamilyModeEnabled: Boolean = false,
    val isBusinessModeEnabled: Boolean = false,
    val companyName: String? = "Tesla Technologies",
    val wheelchairAccessibleRequired: Boolean = false,
    val extraBoardingTimeRequired: Boolean = false,
    val assistanceAnimalPresent: Boolean = false,
    val reducedMobilityAssistance: Boolean = false
)

data class PaymentMethod(
    val id: String,
    val title: String,
    val subtitle: String,
    val iconName: String,
    val isDefault: Boolean = false,
    val cardBrand: String = "Visa",
    val last4: String = "4821"
)

data class RideEvent(
    val timestampMillis: Long = System.currentTimeMillis(),
    val eventName: String,
    val description: String
)

data class FeedbackRating(
    val ratingStars: Int = 5,
    val comfort: Boolean = true,
    val pickup: Boolean = true,
    val route: Boolean = true,
    val cleanliness: Boolean = true,
    val autonomousRide: Boolean = true,
    val safety: Boolean = true,
    val accessibility: Boolean = true,
    val comments: String = ""
)
