package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.TravelViewModel
import com.example.data.*
import com.example.data.db.PurchasedTicketEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketsScreen(
    viewModel: TravelViewModel,
    onNavigate: (String) -> Unit
) {
    val purchasedTickets by viewModel.purchasedTickets.collectAsState()
    val activeSwiftCard by viewModel.activeSwiftCard.collectAsState()

    var showPurchaseDialog by remember { mutableStateOf(false) }
    var selectedInspectTicket by remember { mutableStateOf<PurchasedTicketEntity?>(null) }

    val products = viewModel.ticketProvider.getAvailableProducts()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("TICKETING TERMINAL", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            // Swift Card status banner (Section 17)
            item {
                if (activeSwiftCard != null) {
                    val card = activeSwiftCard!!
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "swift card".uppercase(),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.5.sp
                                )
                                Icon(
                                    imageVector = Icons.Default.Contactless,
                                    contentDescription = "Contactless",
                                    tint = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "£${String.format("%.2f", card.balance)}",
                                style = MaterialTheme.typography.headlineLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "AVAILABLE BALANCE",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.6f)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = card.cardNumber,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = card.holderName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Ticket Purchase shortcut button
            item {
                Button(
                    onClick = { showPurchaseDialog = true },
                    modifier = Modifier.fillMaxWidth().testTag("purchase_ticket_shortcut"),
                    colors = ButtonDefaults.buttonColors(containerColor = BhamRed)
                ) {
                    Icon(Icons.Default.AddShoppingCart, contentDescription = "Buy")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("BUY TICKETS & PASSES", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            // Disclaimer Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BhamGold.copy(alpha = 0.15f))
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = "Simulated", tint = BhamGold)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "SIMULATED TRANSACTIONS • All tickets purchased are demo objects. No real funds are moved.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Active Passes header
            item {
                Text(
                    text = "ACTIVE PASSES & TICKETS",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
            }

            // Purchased tickets items
            if (purchasedTickets.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No active tickets found.", color = MaterialTheme.colorScheme.secondary)
                    }
                }
            } else {
                items(purchasedTickets) { ticket ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedInspectTicket = ticket }
                            .testTag("purchased_ticket_${ticket.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.ConfirmationNumber,
                                contentDescription = null,
                                tint = BhamGold,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ticket.productName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    text = "Mode: ${ticket.mode} • Zone 1-5",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "TAP TO SCAN",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BhamRed,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "VALID",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = BhamMutedGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // INSPECTOR BARCODE DIALOG Reveal
    if (selectedInspectTicket != null) {
        val ticket = selectedInspectTicket!!
        AlertDialog(
            onDismissRequest = { selectedInspectTicket = null },
            title = { Text(ticket.productName, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text("ACTIVE PASS VALID", color = BhamMutedGreen, fontWeight = FontWeight.Bold)
                    
                    // Simple programmatic simulated barcode drawn with Canvas
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .background(Color.White)
                    ) {
                        // Drawing vertical barcode lines
                        val steps = 40
                        val barW = size.width / steps
                        for (i in 0 until steps) {
                            val active = (i % 2 == 0) || (i % 5 == 0) || (i % 7 == 0)
                            if (active) {
                                drawRect(
                                    color = Color.Black,
                                    size = androidx.compose.ui.geometry.Size(barW * 0.7f, size.height),
                                    topLeft = androidx.compose.ui.geometry.Offset(i * barW, 0f)
                                )
                            }
                        }
                    }

                    Text(
                        text = "ID: ${ticket.id.uppercase().take(12)}...",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { selectedInspectTicket = null },
                    colors = ButtonDefaults.buttonColors(containerColor = BhamRed)
                ) {
                    Text("DONE", color = Color.White)
                }
            }
        )
    }

    // BUY TICKET DIALOG Interface
    if (showPurchaseDialog) {
        AlertDialog(
            onDismissRequest = { showPurchaseDialog = false },
            title = { Text("CHOOSE PRODUCT", fontWeight = FontWeight.Black) },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(products) { prod ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.simulateTicketPurchase(prod)
                                    showPurchaseDialog = false
                                }
                                .testTag("purchase_product_${prod.id}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prod.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("Mode: ${prod.mode} • Zone: ${prod.zone}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                }
                                Text(
                                    text = "£${String.format("%.2f", prod.price)}",
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPurchaseDialog = false }) {
                    Text("CANCEL")
                }
            }
        )
    }
}
