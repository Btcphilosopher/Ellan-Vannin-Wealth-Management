package com.example.data

enum class TransportMode {
    TRAIN, TRAM, BUS, WALKING, CYCLING
}

enum class PlaceCategory {
    ATTRACTION, RESTAURANT, SHOPPING, STATION, NEIGHBOURHOOD
}

data class Place(
    val id: String,
    val name: String,
    val description: String,
    val category: PlaceCategory,
    val subCategory: String, // e.g. "Curries", "Museums", "Canals", "Pubs", "Vintages"
    val neighborhood: String,
    val lat: Double,
    val lng: Double,
    val openingHours: String = "09:00 - 18:00",
    val isAccessible: Boolean = true,
    val accessibilityNotes: String = "Step-free access, wheelchair accessible throughout.",
    val imageResName: String = "ic_birmingham_placeholder"
)

data class Neighborhood(
    val id: String,
    val name: String,
    val description: String = "",
    val highlights: List<String>,
    val vibe: String
)

data class Event(
    val id: String,
    val title: String,
    val venue: String,
    val date: String,
    val startTime: String,
    val endTime: String,
    val category: String, // CONCERT, FOOTBALL, THEATRE, EXHIBITION, FESTIVAL, CONFERENCE
    val ticketUrl: String = "https://www.tfwm.org.uk/events",
    val transportImpact: String = "High passenger volume expected around New Street and Moor Street."
)

data class Disruption(
    val id: String,
    val title: String,
    val affectedMode: TransportMode,
    val description: String,
    val severity: String // MINOR, MAJOR, CRITICAL
)

data class Departure(
    val id: String,
    val stationId: String,
    val mode: TransportMode,
    val destination: String,
    val line: String,
    val dueInMinutes: Int,
    val status: String, // LIVE, SCHEDULED, DELAYED, CANCELLED, SIMULATED
    val platform: String? = null
)

object CityData {
    val Neighborhoods = listOf(
        Neighborhood(
            id = "city_centre",
            name = "City Centre",
            description = "The vibrant civic and shopping heart of Birmingham.",
            highlights = listOf("Victoria Square", "Bullring", "Birmingham Museum & Art Gallery"),
            vibe = "Brutalist landmarks meets contemporary steel and glass retail hubs."
        ),
        Neighborhood(
            id = "jewellery_quarter",
            name = "Jewellery Quarter",
            highlights = listOf("St Paul's Square", "Museum of the Jewellery Quarter", "Independent workshops"),
            vibe = "Historic Georgian streets with 250+ years of industrial metalworking craft."
        ),
        Neighborhood(
            id = "digbeth",
            name = "Digbeth",
            highlights = listOf("The Custard Factory", "Street Art tours", "Late-night venues"),
            vibe = "Industrial brick warehouses converted into raw creative and nightlife spaces."
        ),
        Neighborhood(
            id = "brindleyplace",
            name = "Brindleyplace",
            highlights = listOf("Canal Walks", "Ikon Gallery", "Waterfront dining"),
            vibe = "Sleek red-brick and glass office squares set against historic 18th-century canals."
        ),
        Neighborhood(
            id = "edgbaston",
            name = "Edgbaston",
            highlights = listOf("Botanical Gardens", "Cricket Ground", "Michelin-star restaurants"),
            vibe = "Elegant Victorian villas, leafy avenues, and world-class sporting heritage."
        ),
        Neighborhood(
            id = "moseley",
            name = "Moseley",
            highlights = listOf("Moseley Bog", "Independent coffee shops", "Sarehole Mill"),
            vibe = "Bohemian village community rich with J.R.R. Tolkien folklore."
        )
    )

    val Places = listOf(
        // Stations
        Place(
            id = "station_new_street",
            name = "Birmingham New Street",
            description = "The central rail gateway to Birmingham and the core of the UK railway network.",
            category = PlaceCategory.STATION,
            subCategory = "Rail Hub",
            neighborhood = "City Centre",
            lat = 52.4778,
            lng = -1.8990,
            openingHours = "24 Hours",
            isAccessible = true,
            accessibilityNotes = "Step-free access to all platforms via lifts. Assistance desk located on main concourse."
        ),
        Place(
            id = "station_moor_street",
            name = "Birmingham Moor Street",
            description = "A beautifully restored Grade II listed railway station with retro GWR styling.",
            category = PlaceCategory.STATION,
            subCategory = "Rail Station",
            neighborhood = "City Centre",
            lat = 52.4788,
            lng = -1.8925,
            openingHours = "05:00 - 23:45",
            isAccessible = true,
            accessibilityNotes = "Step-free ramped access to all platforms. Accessible toilets available."
        ),
        Place(
            id = "station_snow_hill",
            name = "Birmingham Snow Hill",
            description = "Serves local West Midlands rail services and the West Midlands Metro.",
            category = PlaceCategory.STATION,
            subCategory = "Rail & Metro Hub",
            neighborhood = "City Centre",
            lat = 52.4830,
            lng = -1.8995,
            openingHours = "05:30 - 23:30",
            isAccessible = true,
            accessibilityNotes = "Lift access to all platforms. Shared tram stop has level boarding."
        ),
        Place(
            id = "stop_town_hall",
            name = "Town Hall Tram Stop",
            description = "West Midlands Metro stop serving Victoria Square, Town Hall, and Birmingham Museum.",
            category = PlaceCategory.STATION,
            subCategory = "Metro Stop",
            neighborhood = "City Centre",
            lat = 52.4795,
            lng = -1.9030,
            openingHours = "05:00 - 00:30",
            isAccessible = true,
            accessibilityNotes = "Level boarding platforms with tactile paving. Audible and visual tram arrival indicators."
        ),
        Place(
            id = "stop_jewellery_quarter",
            name = "Jewellery Quarter Tram Stop",
            description = "Integrated station serving the historic metalworking district via West Midlands Metro and Rail.",
            category = PlaceCategory.STATION,
            subCategory = "Metro Stop",
            neighborhood = "Jewellery Quarter",
            lat = 52.4895,
            lng = -1.9135,
            openingHours = "05:00 - 00:30",
            isAccessible = true,
            accessibilityNotes = "Step-free ramped access to tram platforms. Lift to railway platforms."
        ),
        Place(
            id = "stop_library",
            name = "Library Tram Stop",
            description = "Metro stop located directly outside the spectacular Library of Birmingham on Centenary Square.",
            category = PlaceCategory.STATION,
            subCategory = "Metro Stop",
            neighborhood = "City Centre",
            lat = 52.4792,
            lng = -1.9080,
            openingHours = "05:00 - 00:30",
            isAccessible = true,
            accessibilityNotes = "Level platforms, step-free access throughout the square."
        ),

        // Attractions
        Place(
            id = "attraction_museum_art_gallery",
            name = "Birmingham Museum & Art Gallery",
            description = "Home to the world's finest collection of Pre-Raphaelite art and the Staffordshire Hoard. Historic Victorian architecture with signature clock tower 'Big Brum'.",
            category = PlaceCategory.ATTRACTION,
            subCategory = "Art & Culture",
            neighborhood = "City Centre",
            lat = 52.4800,
            lng = -1.9035,
            openingHours = "10:00 - 17:00",
            isAccessible = false, // Temporarily restricted due to partial works, standard accessible routing handles this.
            accessibilityNotes = "Stairs to main entrance. Accessible lift access available via Great Charles Street entrance."
        ),
        Place(
            id = "attraction_victoria_square",
            name = "Victoria Square",
            description = "The civic heart of Birmingham, featuring the magnificent Council House, Town Hall, and 'The Floozie in the Jacuzzi' fountain.",
            category = PlaceCategory.ATTRACTION,
            subCategory = "Architecture",
            neighborhood = "City Centre",
            lat = 52.4796,
            lng = -1.9025,
            openingHours = "24 Hours",
            isAccessible = true,
            accessibilityNotes = "Main plaza is open and step-free, though some surrounding routes have steps or steep gradients."
        ),
        Place(
            id = "attraction_library_bham",
            name = "Library of Birmingham",
            description = "A striking, hyper-modern landmark with a gold filigree facade, containing beautiful secret rooftop terrace gardens and Shakespeare Memorial Room.",
            category = PlaceCategory.ATTRACTION,
            subCategory = "Architecture",
            neighborhood = "City Centre",
            lat = 52.4797,
            lng = -1.9085,
            openingHours = "09:00 - 17:00 (Closed Sun)",
            isAccessible = true,
            accessibilityNotes = "Fully accessible with multi-level lifts, wide aisles, and sensory quiet rooms."
        ),
        Place(
            id = "attraction_jewellery_museum",
            name = "Museum of the Jewellery Quarter",
            description = "A perfectly preserved 'time capsule' workshop showing the industrial heritage of Birmingham's world-famous gold and silver trade.",
            category = PlaceCategory.ATTRACTION,
            subCategory = "Museums",
            neighborhood = "Jewellery Quarter",
            lat = 52.4905,
            lng = -1.9125,
            openingHours = "10:00 - 16:00 (Closed Mon/Tue)",
            isAccessible = true,
            accessibilityNotes = "Ramped entrance, ground-floor workshop is fully accessible. Upper floors via stairs only."
        ),
        Place(
            id = "attraction_custard_factory",
            name = "The Custard Factory",
            description = "The heart of creative Birmingham. Former Victorian factory of Bird's Custard, now a colorful hub of independent shops, food stalls, and street murals.",
            category = PlaceCategory.ATTRACTION,
            subCategory = "Digbeth",
            neighborhood = "Digbeth",
            lat = 52.4755,
            lng = -1.8845,
            openingHours = "09:00 - 23:00",
            isAccessible = true,
            accessibilityNotes = "Courtyards are cobbled but level. Ground level shops and cafes are fully accessible."
        ),
        Place(
            id = "attraction_canals_gas_street",
            name = "Gas Street Basin & Canals",
            description = "The beautiful intersection of the Worcester & Birmingham Canal. Birmingham has more miles of canal than Venice—this is where the industrial heritage is most scenic.",
            category = PlaceCategory.ATTRACTION,
            subCategory = "Canals",
            neighborhood = "Brindleyplace",
            lat = 52.4775,
            lng = -1.9075,
            openingHours = "24 Hours",
            isAccessible = true,
            accessibilityNotes = "Canal towpaths are flat but some entry ramps are steep. Brick paving can be slippery in wet weather."
        ),
        Place(
            id = "attraction_botanical_gardens",
            name = "Birmingham Botanical Gardens",
            description = "15 acres of stunning Victorian glasshouses, exotic plant collections, and peaceful lawns, unchanged since opening in 1832.",
            category = PlaceCategory.ATTRACTION,
            subCategory = "Parks",
            neighborhood = "Edgbaston",
            lat = 52.4695,
            lng = -1.9285,
            openingHours = "10:00 - 18:00",
            isAccessible = true,
            accessibilityNotes = "Majority of garden pathways are step-free. Accessible toilets and mobility scooter hire available."
        ),
        Place(
            id = "attraction_aston_hall",
            name = "Aston Hall",
            description = "A magnificent 17th-century Jacobean red-brick mansion, famous for Royalist sieges during the English Civil War.",
            category = PlaceCategory.ATTRACTION,
            subCategory = "History",
            neighborhood = "Aston",
            lat = 52.5050,
            lng = -1.8840,
            openingHours = "11:00 - 16:00 (Wed-Sun)",
            isAccessible = false, // Steep historical staircases
            accessibilityNotes = "Ground floor has ramped access. Upper floors (including the long gallery) require stairs."
        ),
        Place(
            id = "attraction_thinktank",
            name = "Thinktank Science Museum",
            description = "Award-winning science museum featuring local steam engines from the Industrial Revolution, a planetarium, and an outdoor science garden.",
            category = PlaceCategory.ATTRACTION,
            subCategory = "Museums",
            neighborhood = "City Centre",
            lat = 52.4826,
            lng = -1.8855,
            openingHours = "10:00 - 17:00 (Wed-Sun)",
            isAccessible = true,
            accessibilityNotes = "Fully step-free layout with accessible lifts, quiet areas, and sensory maps."
        ),

        // Food & Drink
        Place(
            id = "food_lasan",
            name = "Lasan Restaurant & Bar",
            description = "Multi-award-winning fine dining Indian restaurant located in the Jewellery Quarter, famous for sublime modern curries.",
            category = PlaceCategory.RESTAURANT,
            subCategory = "Curries",
            neighborhood = "Jewellery Quarter",
            lat = 52.4848,
            lng = -1.9070,
            openingHours = "17:00 - 23:00",
            isAccessible = true,
            accessibilityNotes = "Level entry, spacious dining area, wheelchair-friendly toilets."
        ),
        Place(
            id = "food_st_pauls_house",
            name = "Saint Pauls House Pub",
            description = "A refined, vibrant pub and boutique hotel overlooking Birmingham's last remaining Georgian square.",
            category = PlaceCategory.RESTAURANT,
            subCategory = "Pubs",
            neighborhood = "Jewellery Quarter",
            lat = 52.4870,
            lng = -1.9055,
            openingHours = "12:00 - 23:30",
            isAccessible = true,
            accessibilityNotes = "Entrance and main bar are step-free. Courtyard is level."
        ),
        Place(
            id = "food_dishoom",
            name = "Dishoom Birmingham",
            description = "Vibrant, nostalgic Bombay cafe on Chamberlain Square. Incredible street food, legendary bacon naan rolls, and house black daal.",
            category = PlaceCategory.RESTAURANT,
            subCategory = "Street Food",
            neighborhood = "City Centre",
            lat = 52.4798,
            lng = -1.9040,
            openingHours = "08:00 - 23:00",
            isAccessible = true,
            accessibilityNotes = "Fully accessible with spacious ground level seating and lift to restrooms."
        ),
        Place(
            id = "food_medicine_bakery",
            name = "Medicine Bakery + Gallery",
            description = "An spectacular artisan bakery and secret art space located inside the grandiose former Royal Society of Artists building on New Street.",
            category = PlaceCategory.RESTAURANT,
            subCategory = "Coffee",
            neighborhood = "City Centre",
            lat = 52.4793,
            lng = -1.8985,
            openingHours = "08:30 - 17:30",
            isAccessible = false, // Historic steep stair climb
            accessibilityNotes = "Accessible only via a steep 30-step historical flight of stairs. No lift available."
        ),
        Place(
            id = "food_b_ham_balti_triangle",
            name = "The Balti Bowl Provider",
            description = "Historic spot for authentic Birmingham Balti curries cooked and served in custom pressed-steel bowls invented right here.",
            category = PlaceCategory.RESTAURANT,
            subCategory = "Curries",
            neighborhood = "South Side",
            lat = 52.4550,
            lng = -1.8790,
            openingHours = "12:00 - 23:00",
            isAccessible = true,
            accessibilityNotes = "Step-free street access, wide seating booths."
        ),

        // Shopping
        Place(
            id = "shopping_bullring",
            name = "Bullring & Grand Central",
            description = "An iconic futuristic shopping complex wrapped in 15,000 aluminum discs, housing hundreds of major brands and the world-famous bronze Bull statue.",
            category = PlaceCategory.SHOPPING,
            subCategory = "Bullring",
            neighborhood = "City Centre",
            lat = 52.4775,
            lng = -1.8940,
            openingHours = "10:00 - 20:00",
            isAccessible = true,
            accessibilityNotes = "Fully step-free layout. Multiple lifts connecting Grand Central concourse directly to mall levels."
        ),
        Place(
            id = "shopping_rag_market",
            name = "The historic Rag Market",
            description = "Birmingham's legendary, bustling indoor and outdoor markets, trading fabric, vintage clothing, and fresh local produce since the 12th century.",
            category = PlaceCategory.SHOPPING,
            subCategory = "Markets",
            neighborhood = "City Centre",
            lat = 52.4760,
            lng = -1.8915,
            openingHours = "09:00 - 17:00 (Tue, Thu, Fri, Sat)",
            isAccessible = true,
            accessibilityNotes = "Level indoor stalls, though crowd density can be high. Exterior pathways are brick paved."
        ),
        Place(
            id = "shopping_red_brick",
            name = "Red Brick Market Digbeth",
            description = "An indoor alternative flea market packed with independent curators, vintage clothing, records, and quirky industrial artifacts.",
            category = PlaceCategory.SHOPPING,
            subCategory = "Vintage",
            neighborhood = "Digbeth",
            lat = 52.4740,
            lng = -1.8820,
            openingHours = "10:00 - 18:00",
            isAccessible = true,
            accessibilityNotes = "Warehouse floor is flat and concrete. Easy wheelchair maneuvering."
        )
    )

    val Events = listOf(
        Event(
            id = "event_1",
            title = "Birmingham Symphony Orchestra Concert",
            venue = "Symphony Hall, Centenary Square",
            date = "Today",
            startTime = "19:30",
            endTime = "21:30",
            category = "CONCERT",
            transportImpact = "Moderate crowds expected around Town Hall Metro and Library stops between 18:30 and 22:00."
        ),
        Event(
            id = "event_2",
            title = "Digbeth Dining Club Street Food Fest",
            venue = "Custard Factory Courtyard",
            date = "This Weekend",
            startTime = "12:00",
            endTime = "22:00",
            category = "FESTIVAL",
            transportImpact = "High footfall in Digbeth area. Walking route from Moor Street Station recommended."
        ),
        Event(
            id = "event_3",
            title = "Birmingham City FC vs Aston Villa (Derby)",
            venue = "St Andrew's Stadium",
            date = "Saturday",
            startTime = "15:00",
            endTime = "17:00",
            category = "FOOTBALL",
            transportImpact = "Severe delays. Local buses 97/17 highly congested. Use designated shuttle buses from New Street."
        ),
        Event(
            id = "event_4",
            title = "Pre-Raphaelite Treasures Exhibition",
            venue = "Birmingham Museum & Art Gallery",
            date = "Daily",
            startTime = "10:00",
            endTime = "17:00",
            category = "EXHIBITION",
            transportImpact = "No major impact. Use Town Hall Metro stop."
        )
    )

    val Disruptions = listOf(
        Disruption(
            id = "dis_1",
            title = "Birmingham Eastside Metro Extension Works",
            affectedMode = TransportMode.TRAM,
            description = "Construction on the new Eastside line is underway. Trams are running normally but road diversions apply in Digbeth.",
            severity = "MAJOR"
        ),
        Disruption(
            id = "dis_2",
            title = "Bull Street Roadworks Diversions",
            affectedMode = TransportMode.BUS,
            description = "Due to physical utility upgrades, bus routes 50, 97, 4A are diverted via Moor Street Queensway.",
            severity = "MINOR"
        ),
        Disruption(
            id = "dis_3",
            title = "West Midlands Railway Signal Upgrades",
            affectedMode = TransportMode.TRAIN,
            description = "Weekend maintenance between New Street and Bournville (Cadbury World). Replacement bus service active.",
            severity = "MAJOR"
        )
    )

    val Departures = listOf(
        Departure("dep_1", "station_new_street", TransportMode.TRAIN, "London Euston (Avanti West Coast)", "Avanti Express", 4, "LIVE", "1"),
        Departure("dep_2", "station_new_street", TransportMode.TRAIN, "Lichfield Trent Valley (WMR)", "Cross City Line", 7, "LIVE", "11"),
        Departure("dep_3", "station_new_street", TransportMode.TRAIN, "Manchester Piccadilly (CrossCountry)", "CrossCountry Express", 12, "LIVE", "3"),
        Departure("dep_4", "station_new_street", TransportMode.TRAIN, "Redditch (West Midlands Railway)", "Cross City Line", 15, "SCHEDULED", "12"),
        Departure("dep_5", "station_new_street", TransportMode.TRAIN, "Edinburgh Waverley (CrossCountry)", "North Country Express", 22, "DELAYED", "8"),
        Departure("dep_6", "station_new_street", TransportMode.TRAIN, "Aberystwyth (Transport for Wales)", "Cambrian Line", 25, "LIVE", "4"),

        Departure("dep_7", "station_moor_street", TransportMode.TRAIN, "London Marylebone (Chiltern Railway)", "Chiltern Line", 3, "LIVE", "2"),
        Departure("dep_8", "station_moor_street", TransportMode.TRAIN, "Stratford-upon-Avon (WMR)", "Shakespeare Line", 9, "LIVE", "3"),
        Departure("dep_9", "station_moor_street", TransportMode.TRAIN, "Kidderminster (WMR)", "Snow Hill Line", 16, "SCHEDULED", "1"),

        Departure("dep_10", "stop_town_hall", TransportMode.TRAM, "Wolverhampton St George's", "Line 1 Metro", 2, "LIVE"),
        Departure("dep_11", "stop_town_hall", TransportMode.TRAM, "Edgbaston Village", "Line 1 Metro", 5, "LIVE"),
        Departure("dep_12", "stop_town_hall", TransportMode.TRAM, "Wolverhampton St George's", "Line 1 Metro", 11, "SCHEDULED"),

        Departure("dep_13", "stop_library", TransportMode.TRAM, "Edgbaston Village", "Line 1 Metro", 2, "LIVE"),
        Departure("dep_14", "stop_library", TransportMode.TRAM, "Wolverhampton St George's", "Line 1 Metro", 6, "LIVE"),
        Departure("dep_15", "stop_library", TransportMode.TRAM, "Edgbaston Village", "Line 1 Metro", 14, "SCHEDULED")
    )
}
