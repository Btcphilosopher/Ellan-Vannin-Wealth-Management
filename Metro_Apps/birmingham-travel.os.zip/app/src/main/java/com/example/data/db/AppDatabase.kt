package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedPlaceDao {
    @Query("SELECT * FROM saved_places ORDER BY savedAt DESC")
    fun getAllSavedPlaces(): Flow<List<SavedPlaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePlace(place: SavedPlaceEntity)

    @Query("DELETE FROM saved_places WHERE placeId = :placeId")
    suspend fun deleteSavedPlace(placeId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM saved_places WHERE placeId = :placeId LIMIT 1)")
    suspend fun isPlaceSaved(placeId: String): Boolean
}

@Dao
interface TripDao {
    @Query("SELECT * FROM user_trips")
    fun getAllTrips(): Flow<List<TripEntity>>

    @Query("SELECT * FROM user_trips WHERE id = :id LIMIT 1")
    suspend fun getTripById(id: String): TripEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: TripEntity)

    @Query("DELETE FROM user_trips WHERE id = :id")
    suspend fun deleteTrip(id: String)
}

@Dao
interface PurchasedTicketDao {
    @Query("SELECT * FROM purchased_tickets ORDER BY purchaseTime DESC")
    fun getAllTickets(): Flow<List<PurchasedTicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: PurchasedTicketEntity)

    @Query("DELETE FROM purchased_tickets WHERE id = :id")
    suspend fun deleteTicket(id: String)
}

@Dao
interface UserPreferencesDao {
    @Query("SELECT * FROM user_preferences WHERE id = 1 LIMIT 1")
    fun getPreferencesFlow(): Flow<UserPreferencesEntity?>

    @Query("SELECT * FROM user_preferences WHERE id = 1 LIMIT 1")
    suspend fun getPreferencesDirect(): UserPreferencesEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun updatePreferences(prefs: UserPreferencesEntity)
}

@Database(
    entities = [
        SavedPlaceEntity::class,
        TripEntity::class,
        PurchasedTicketEntity::class,
        UserPreferencesEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun savedPlaceDao(): SavedPlaceDao
    abstract fun tripDao(): TripDao
    abstract fun purchasedTicketDao(): PurchasedTicketDao
    abstract fun userPreferencesDao(): UserPreferencesDao
}
