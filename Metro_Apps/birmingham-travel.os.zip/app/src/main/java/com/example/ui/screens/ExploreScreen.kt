package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.TravelViewModel
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(
    viewModel: TravelViewModel,
    initialCategory: String? = null,
    initialPlaceId: String? = null,
    onNavigate: (String) -> Unit
) {
    var selectedCategory by remember { mutableStateOf(initialCategory) }
    var selectedPlaceId by remember { mutableStateOf(initialPlaceId) }

    val places = CityData.Places

    LaunchedEffect(initialCategory, initialPlaceId) {
        if (initialCategory != null) selectedCategory = initialCategory
        if (initialPlaceId != null) selectedPlaceId = initialPlaceId
    }

    if (selectedPlaceId != null) {
        val place = places.find { it.id == selectedPlaceId }
        if (place != null) {
            // Detailed Place Page (Section 11)
            PlacePage(
                place = place,
                onBack = { selectedPlaceId = null },
                onGetThere = {
                    viewModel.setOrigin("station_new_street")
                    viewModel.setDestination(place.id)
                    onNavigate("plan")
                },
                onAddToTrip = {
                    viewModel.saveCustomTrip(
                        name = "Trip: Visit ${place.name}",
                        placeIds = listOf("station_new_street", place.id),
                        startTimes = listOf("10:00", "11:30")
                    )
                    onNavigate("trips")
                }
            )
            return
        }
    }

    // Main exploration categories view
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(selectedCategory?.uppercase() ?: "EXPLORE BIRMINGHAM", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    if (selectedCategory != null) {
                        IconButton(onClick = { selectedCategory = null }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        if (selectedCategory == null) {
            // General categories lists (Section 10)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = "SELECT CATEGORY",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    val cats = listOf(
                        "ATTRACTION" to "THINGS TO DO",
                        "RESTAURANT" to "FOOD & DRINK",
                        "SHOPPING" to "RETAIL HUBS",
                        "CANALS" to "CANALS & WATERWAYS",
                        "JEWELLERY" to "JEWELLERY QUARTER",
                        "DIGBETH" to "DIGBETH CREATIVE"
                    )
                    items(cats) { (id, label) ->
                        CategoryCard(label = label) {
                            selectedCategory = id
                        }
                    }
                }
            }
        } else {
            // List places inside chosen category
            val filteredPlaces = when (selectedCategory) {
                "ATTRACTION" -> places.filter { it.category == PlaceCategory.ATTRACTION }
                "RESTAURANT" -> places.filter { it.category == PlaceCategory.RESTAURANT }
                "SHOPPING" -> places.filter { it.category == PlaceCategory.SHOPPING }
                "CANALS" -> places.filter { it.subCategory == "Canals" }
                "JEWELLERY" -> places.filter { it.neighborhood == "Jewellery Quarter" }
                "DIGBETH" -> places.filter { it.neighborhood == "Digbeth" }
                else -> places
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filteredPlaces) { place ->
                    PlaceRowCard(place = place) {
                        selectedPlaceId = place.id
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryCard(
    label: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.BottomStart
        ) {
            Column {
                Icon(
                    imageVector = Icons.Default.Explore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

@Composable
fun PlaceRowCard(
    place: Place,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("place_row_${place.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center
            ) {
                val icon = when (place.category) {
                    PlaceCategory.RESTAURANT -> Icons.Default.Restaurant
                    PlaceCategory.SHOPPING -> Icons.Default.ShoppingBag
                    else -> Icons.Default.Attractions
                }
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = place.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = place.neighborhood + " • " + place.subCategory,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = place.openingHours,
                    style = MaterialTheme.typography.labelSmall,
                    color = BhamMutedGreen,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Icon(
                imageVector = Icons.Default.ArrowForwardIos,
                contentDescription = "Details",
                tint = MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

// Full Place Page details View (Section 11)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlacePage(
    place: Place,
    onBack: () -> Unit,
    onGetThere: () -> Unit,
    onAddToTrip: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(place.name.uppercase(), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            // Photo Placeholder
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BhamDeepBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Business,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "BIRMINGHAM TRAVEL.OS VISUAL",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.5f),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Overview Section
            item {
                Column {
                    Text(
                        text = "ABOUT",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = place.description,
                        style = MaterialTheme.typography.bodyLarge,
                        lineHeight = 22.sp
                    )
                }
            }

            // Opening details
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("HOURS TODAY", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(place.openingHours, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("NEIGHBOURHOOD", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(place.neighborhood, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Accessibility Notes
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = if (place.isAccessible) Icons.Default.Accessible else Icons.Default.NotAccessible,
                            contentDescription = "Accessibility",
                            tint = if (place.isAccessible) BhamMutedGreen else BhamRed,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("ACCESSIBILITY", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(place.accessibilityNotes, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            // Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onAddToTrip,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ADD TO TRIP", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onGetThere,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = BhamRed)
                    ) {
                        Icon(Icons.Default.Navigation, contentDescription = "Get There", tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("GET THERE", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }

            // Nearby Recommendations list (Section 11)
            item {
                Column {
                    Text(
                        text = "NEARBY RECOMMENDATIONS",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Dynamic recommendations matching same neighborhood or category
                    val recs = CityData.Places.filter { it.id != place.id && it.neighborhood == place.neighborhood }.take(2)
                    for (rec in recs) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = BhamGold, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(rec.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text(rec.subCategory, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
