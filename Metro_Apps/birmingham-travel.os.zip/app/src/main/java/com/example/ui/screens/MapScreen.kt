package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.TravelViewModel
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    viewModel: TravelViewModel,
    onNavigate: (String) -> Unit
) {
    var selectedFilter by remember { mutableStateOf("CITY") } // "CITY", "TRANSPORT", "FOOD", "CULTURE", "SHOPPING"
    var selectedPlace by remember { mutableStateOf<Place?>(null) }

    val places = CityData.Places

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BIRMINGHAM VECTOR MODEL", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BhamWarmWhite)
                .padding(padding)
        ) {
            // High Contrast Map Filter Layer Buttons (Section 9)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val filters = listOf("CITY", "TRANSPORT", "FOOD", "CULTURE", "SHOPPING")
                filters.forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = {
                            selectedFilter = filter
                            selectedPlace = null
                        },
                        label = { Text(filter, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("map_filter_$filter")
                    )
                }
            }

            // Interactive Map Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFFEFECE6)) // Sandstone Map Background style
            ) {
                CanvasMapLayout(
                    places = places,
                    selectedFilter = selectedFilter,
                    selectedPlace = selectedPlace,
                    onSelectPlace = { selectedPlace = it }
                )

                // Overlapping Interactive Card (Section 9 & 11)
                if (selectedPlace != null) {
                    val place = selectedPlace!!
                    Card(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                            .fillMaxWidth()
                            .testTag("map_overlay_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(place.name, fontWeight = FontWeight.Black, style = MaterialTheme.typography.bodyLarge)
                                    Text(place.neighborhood + " • " + place.subCategory, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                                }
                                IconButton(onClick = { selectedPlace = null }) {
                                    Icon(Icons.Default.Close, contentDescription = "Close")
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(place.description, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { onNavigate("explore?placeId=${place.id}") },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("MORE INFO")
                                }
                                Button(
                                    onClick = {
                                        viewModel.setOrigin("station_new_street")
                                        viewModel.setDestination(place.id)
                                        onNavigate("plan")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BhamRed),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("GET THERE", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CanvasMapLayout(
    places: List<Place>,
    selectedFilter: String,
    selectedPlace: Place?,
    onSelectPlace: (Place) -> Unit
) {
    // Map bounds in lat/lng for plotting coordinates inside Canvas size dynamically
    // Bounding Box: minLat = 52.45, maxLat = 52.51, minLng = -1.93, maxLng = -1.87
    val minLat = 52.45
    val maxLat = 52.51
    val minLng = -1.94
    val maxLng = -1.87

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(places, selectedFilter) {
                detectTapGestures { offset ->
                    // Calculate closest tapped marker
                    var bestPlace: Place? = null
                    var bestDist = Float.MAX_VALUE

                    for (place in places) {
                        // Coordinates map to canvas width/height
                        val x = ((place.lng - minLng) / (maxLng - minLng)) * size.width
                        // Canvas coordinates start top-left, latitude starts bottom-up
                        val y = (1.0 - (place.lat - minLat) / (maxLat - minLat)) * size.height

                        val dx = offset.x - x
                        val dy = offset.y - y
                        val dist = (dx * dx + dy * dy).toFloat()

                        // Touch target threshold (approx 48dp)
                        if (dist < 40 * 40 && dist < bestDist) {
                            bestPlace = place
                            bestDist = dist
                        }
                    }

                    if (bestPlace != null) {
                        // Check filter matches
                        val isFiltered = when (selectedFilter) {
                            "TRANSPORT" -> bestPlace.category == PlaceCategory.STATION
                            "FOOD" -> bestPlace.category == PlaceCategory.RESTAURANT
                            "CULTURE" -> bestPlace.category == PlaceCategory.ATTRACTION
                            "SHOPPING" -> bestPlace.category == PlaceCategory.SHOPPING
                            else -> true
                        }
                        if (isFiltered) onSelectPlace(bestPlace)
                    }
                }
            }
    ) {
        val w = size.width
        val h = size.height

        // Transform lat/lng to Offset
        fun toOffset(lat: Double, lng: Double): Offset {
            val x = ((lng - minLng) / (maxLng - minLng)) * w
            val y = (1.0 - (lat - minLat) / (maxLat - minLat)) * h
            return Offset(x.toFloat(), y.toFloat())
        }

        // Layer 1: Draw Canals (Worcester & Birmingham / Gas Street intersection)
        // Draw blue winding paths
        val canalPath = Path().apply {
            val start = toOffset(52.472, -1.918)
            moveTo(start.x, start.y)
            val middle = toOffset(52.4775, -1.9075) // Gas Street
            quadraticTo(middle.x - 50, middle.y + 100, middle.x, middle.y)
            val end = toOffset(52.482, -1.890)
            lineTo(end.x, end.y)
        }
        drawPath(
            path = canalPath,
            color = BhamDeepBlue.copy(alpha = 0.5f),
            style = Stroke(width = 12f)
        )

        // Layer 2: Draw Railways (Passing New Street, Moor Street, Snow Hill)
        val railPath = Path().apply {
            val start = toOffset(52.465, -1.920)
            moveTo(start.x, start.y)
            val ns = toOffset(52.4778, -1.899)
            lineTo(ns.x, ns.y)
            val ms = toOffset(52.4788, -1.8925)
            lineTo(ms.x, ms.y)
            val ext = toOffset(52.485, -1.875)
            lineTo(ext.x, ext.y)
        }
        drawPath(
            path = railPath,
            color = BhamSteelGrey.copy(alpha = 0.6f),
            style = Stroke(
                width = 8f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
            )
        )

        // Layer 3: Draw West Midlands Metro Tram Line (Town Hall, Library, Snow Hill, JQ)
        if (selectedFilter == "CITY" || selectedFilter == "TRANSPORT") {
            val metroPath = Path().apply {
                val start = toOffset(52.475, -1.915) // Edgbaston
                moveTo(start.x, start.y)
                val library = toOffset(52.4792, -1.9080)
                lineTo(library.x, library.y)
                val townHall = toOffset(52.4795, -1.9030)
                lineTo(townHall.x, townHall.y)
                val snowHill = toOffset(52.4830, -1.8995)
                lineTo(snowHill.x, snowHill.y)
                val jq = toOffset(52.4895, -1.9135)
                lineTo(jq.x, jq.y)
            }
            drawPath(
                path = metroPath,
                color = BhamGold,
                style = Stroke(width = 6f)
            )
        }

        // Layer 4: Draw Location Markers (Filtered)
        for (place in places) {
            val isMatchingFilter = when (selectedFilter) {
                "TRANSPORT" -> place.category == PlaceCategory.STATION
                "FOOD" -> place.category == PlaceCategory.RESTAURANT
                "CULTURE" -> place.category == PlaceCategory.ATTRACTION
                "SHOPPING" -> place.category == PlaceCategory.SHOPPING
                else -> true
            }

            if (isMatchingFilter) {
                val markerOffset = toOffset(place.lat, place.lng)
                val markerColor = when (place.category) {
                    PlaceCategory.STATION -> BhamSteelGrey
                    PlaceCategory.RESTAURANT -> BhamDeepBlue
                    PlaceCategory.SHOPPING -> BhamGold
                    else -> BhamRed
                }

                // Draw pulsing ring if selected
                if (selectedPlace?.id == place.id) {
                    drawCircle(
                        color = markerColor.copy(alpha = 0.3f),
                        radius = 24f,
                        center = markerOffset
                    )
                }

                // Inner core
                drawCircle(
                    color = markerColor,
                    radius = 12f,
                    center = markerOffset
                )
                drawCircle(
                    color = Color.White,
                    radius = 5f,
                    center = markerOffset
                )
            }
        }
    }
}
