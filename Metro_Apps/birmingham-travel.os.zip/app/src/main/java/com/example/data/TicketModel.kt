package com.example.data

import java.util.UUID

enum class Zone {
    ZONE_1, ZONE_2, ZONE_3, ZONE_4, ZONE_5, MULTI_ZONE
}

enum class TicketMode {
    BUS, TRAM, TRAIN, MULTIMODAL
}

data class ValidityPeriod(
    val id: String,
    val name: String, // e.g. "Single", "Day Saver", "1-Week Pass"
    val durationHours: Int
)

data class TravelProduct(
    val id: String,
    val name: String,
    val mode: TicketMode,
    val zone: Zone,
    val validity: ValidityPeriod,
    val price: Double
)

data class Ticket(
    val id: String = UUID.randomUUID().toString(),
    val product: TravelProduct,
    val purchaseTimestamp: Long = System.currentTimeMillis(),
    val isValid: Boolean = true,
    val swiftCardNumber: String? = null
)

data class SwiftCard(
    val cardNumber: String,
    val holderName: String,
    val balance: Double,
    val activeTickets: List<Ticket>,
    val autoRenew: Boolean = false
)

data class Transaction(
    val id: String = UUID.randomUUID().toString(),
    val ticketId: String,
    val amount: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String // "SUCCESSFUL", "PENDING", "SIMULATED"
)

interface TicketProvider {
    fun getAvailableProducts(): List<TravelProduct>
    fun purchaseTicket(product: TravelProduct, swiftCardNumber: String? = null): Ticket
    fun getSwiftCardDetails(cardNumber: String): SwiftCard?
}

class SimulatedTicketProvider : TicketProvider {
    private val products = listOf(
        TravelProduct("p_1", "Swift Single Bus & Tram", TicketMode.MULTIMODAL, Zone.ZONE_1, ValidityPeriod("v_1", "Single Journey", 2), 2.50),
        TravelProduct("p_2", "West Midlands Day Saver", TicketMode.MULTIMODAL, Zone.MULTI_ZONE, ValidityPeriod("v_2", "1 Day", 24), 4.70),
        TravelProduct("p_3", "Network Daytripper (Off-Peak)", TicketMode.MULTIMODAL, Zone.MULTI_ZONE, ValidityPeriod("v_3", "1 Day (Off-Peak)", 24), 7.50),
        TravelProduct("p_4", "National Express Bus Only Day", TicketMode.BUS, Zone.MULTI_ZONE, ValidityPeriod("v_2", "1 Day", 24), 4.00),
        TravelProduct("p_5", "West Midlands Metro Day Ticket", TicketMode.TRAM, Zone.MULTI_ZONE, ValidityPeriod("v_2", "1 Day", 24), 4.50),
        TravelProduct("p_6", "WMR Train Only Zone 1-2 Single", TicketMode.TRAIN, Zone.ZONE_1, ValidityPeriod("v_1", "Single Journey", 3), 3.20),
        TravelProduct("p_7", "WMR Train Only Day Saver Zone 1-5", TicketMode.TRAIN, Zone.MULTI_ZONE, ValidityPeriod("v_2", "1 Day", 24), 9.20),
        TravelProduct("p_8", "Swift Go Multimodal 1-Week Pass", TicketMode.MULTIMODAL, Zone.MULTI_ZONE, ValidityPeriod("v_4", "7 Days", 168), 29.50)
    )

    private val mockedSwiftCards = mutableMapOf(
        "SWIFT-4829-1928" to SwiftCard("SWIFT-4829-1928", "Alex Mercer", 15.50, emptyList(), true),
        "SWIFT-9921-0012" to SwiftCard("SWIFT-9921-0012", "Visitor Card", 5.00, emptyList(), false)
    )

    override fun getAvailableProducts(): List<TravelProduct> = products

    override fun purchaseTicket(product: TravelProduct, swiftCardNumber: String?): Ticket {
        val ticket = Ticket(product = product, swiftCardNumber = swiftCardNumber)
        if (swiftCardNumber != null) {
            val card = mockedSwiftCards[swiftCardNumber]
            if (card != null) {
                val newBalance = Math.max(0.0, card.balance - product.price)
                mockedSwiftCards[swiftCardNumber] = card.copy(
                    balance = newBalance,
                    activeTickets = card.activeTickets + ticket
                )
            }
        }
        return ticket
    }

    override fun getSwiftCardDetails(cardNumber: String): SwiftCard? {
        return mockedSwiftCards[cardNumber]
    }
}

class FutureTfWMProvider : TicketProvider {
    override fun getAvailableProducts(): List<TravelProduct> = emptyList()
    override fun purchaseTicket(product: TravelProduct, swiftCardNumber: String?): Ticket {
        throw NotImplementedError("Future TfWM production endpoint - currently in specification phase.")
    }
    override fun getSwiftCardDetails(cardNumber: String): SwiftCard? = null
}
