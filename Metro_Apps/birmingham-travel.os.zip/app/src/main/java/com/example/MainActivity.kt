package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val travelViewModel: TravelViewModel = viewModel()
                
                // Simple, robust, compile-safe state navigation
                var currentRoute by remember { mutableStateOf("home") }
                var exploreCategoryArg by remember { mutableStateOf<String?>(null) }
                var explorePlaceIdArg by remember { mutableStateOf<String?>(null) }

                fun navigateTo(fullRoute: String) {
                    if (fullRoute.startsWith("explore")) {
                        currentRoute = "explore"
                        when {
                            fullRoute.contains("category=") -> {
                                exploreCategoryArg = fullRoute.substringAfter("category=")
                                explorePlaceIdArg = null
                            }
                            fullRoute.contains("placeId=") -> {
                                explorePlaceIdArg = fullRoute.substringAfter("placeId=")
                                exploreCategoryArg = null
                            }
                            else -> {
                                exploreCategoryArg = null
                                explorePlaceIdArg = null
                            }
                        }
                    } else {
                        currentRoute = fullRoute
                        exploreCategoryArg = null
                        explorePlaceIdArg = null
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.testTag("main_bottom_nav"),
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = currentRoute == "home",
                                onClick = { navigateTo("home") },
                                icon = { Icon(if (currentRoute == "home") Icons.Default.Home else Icons.Outlined.Home, contentDescription = "Home") },
                                label = { Text("HOME", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_home")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "plan",
                                onClick = { navigateTo("plan") },
                                icon = { Icon(if (currentRoute == "plan") Icons.Default.Navigation else Icons.Outlined.Navigation, contentDescription = "Plan") },
                                label = { Text("PLAN", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_plan")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "explore",
                                onClick = { navigateTo("explore") },
                                icon = { Icon(if (currentRoute == "explore") Icons.Default.Explore else Icons.Outlined.Explore, contentDescription = "Explore") },
                                label = { Text("EXPLORE", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_explore")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "map",
                                onClick = { navigateTo("map") },
                                icon = { Icon(if (currentRoute == "map") Icons.Default.Map else Icons.Outlined.Map, contentDescription = "Map") },
                                label = { Text("MAP", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_map")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "trips",
                                onClick = { navigateTo("trips") },
                                icon = { Icon(if (currentRoute == "trips") Icons.Default.CalendarToday else Icons.Outlined.CalendarToday, contentDescription = "Trips") },
                                label = { Text("TRIPS", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_trips")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "tickets",
                                onClick = { navigateTo("tickets") },
                                icon = { Icon(if (currentRoute == "tickets") Icons.Default.ConfirmationNumber else Icons.Outlined.ConfirmationNumber, contentDescription = "Tickets") },
                                label = { Text("PASSES", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_tickets")
                            )
                            NavigationBarItem(
                                selected = currentRoute == "account",
                                onClick = { navigateTo("account") },
                                icon = { Icon(if (currentRoute == "account") Icons.Default.AccountCircle else Icons.Outlined.AccountCircle, contentDescription = "Account") },
                                label = { Text("PROFILE", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_account")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentRoute) {
                            "home" -> HomeScreen(viewModel = travelViewModel, onNavigate = { navigateTo(it) })
                            "plan" -> PlanScreen(viewModel = travelViewModel, onNavigate = { navigateTo(it) })
                            "explore" -> ExploreScreen(
                                viewModel = travelViewModel,
                                initialCategory = exploreCategoryArg,
                                initialPlaceId = explorePlaceIdArg,
                                onNavigate = { navigateTo(it) }
                            )
                            "map" -> MapScreen(viewModel = travelViewModel, onNavigate = { navigateTo(it) })
                            "trips" -> TripsScreen(viewModel = travelViewModel, onNavigate = { navigateTo(it) })
                            "tickets" -> TicketsScreen(viewModel = travelViewModel, onNavigate = { navigateTo(it) })
                            "account" -> AccountScreen(viewModel = travelViewModel, onNavigate = { navigateTo(it) })
                        }
                    }
                }
            }
        }
    }
}
