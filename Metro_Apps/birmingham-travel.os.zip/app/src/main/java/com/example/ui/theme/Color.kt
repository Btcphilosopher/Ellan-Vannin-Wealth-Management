package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light/Primary Color System
val BhamWarmWhite = Color(0xFFFBF9F4)
val BhamCharcoal = Color(0xFF141416)
val BhamGraphite = Color(0xFF1F2022)
val BhamRed = Color(0xFFB3241F) // Birmingham red brick
val BhamSteelGrey = Color(0xFF5F7080) // Steel engineering
val BhamDeepBlue = Color(0xFF162D42) // Canal waters / Evening sky
val BhamMutedGreen = Color(0xFF3B5C43) // Parks & Green spaces
val BhamGold = Color(0xFFC59B27) // Jewellery Quarter gold and brass accent

// Light theme color palette overrides
val LightPrimary = BhamRed
val LightSecondary = BhamSteelGrey
val LightTertiary = BhamDeepBlue
val LightBackground = BhamWarmWhite
val LightSurface = Color(0xFFF3EFE7)
val LightOnPrimary = Color.White
val LightOnSecondary = Color.White
val LightOnTertiary = Color.White
val LightOnBackground = BhamCharcoal
val LightOnSurface = BhamCharcoal

// Dark theme color palette overrides
val DarkPrimary = Color(0xFFE55D50)
val DarkSecondary = Color(0xFF8BA2B5)
val DarkTertiary = Color(0xFF7599BA)
val DarkBackground = BhamCharcoal
val DarkSurface = BhamGraphite
val DarkOnPrimary = BhamCharcoal
val DarkOnSecondary = BhamCharcoal
val DarkOnTertiary = BhamCharcoal
val DarkOnBackground = BhamWarmWhite
val DarkOnSurface = BhamWarmWhite
