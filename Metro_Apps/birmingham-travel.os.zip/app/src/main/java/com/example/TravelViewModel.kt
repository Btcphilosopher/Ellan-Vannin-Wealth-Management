package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.data.db.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class TravelViewModel(application: Application) : AndroidViewModel(application) {
    val repository = AppRepository(application)
    val travelGraph = BirminghamTravelGraph()
    val ticketProvider = SimulatedTicketProvider()

    // 1. Database Flows
    val savedPlaces = repository.savedPlacesFlow.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val userTrips = repository.tripsFlow.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val purchasedTickets = repository.ticketsFlow.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val preferences = repository.preferencesFlow.stateIn(viewModelScope, SharingStarted.Lazily, null)

    // 2. Journey Planner Inputs & Outputs
    val fromPlaceId = MutableStateFlow<String?>("station_new_street")
    val toPlaceId = MutableStateFlow<String?>("attraction_victoria_square")
    
    private val _journeyPreferences = MutableStateFlow(JourneyPreferences())
    val journeyPreferences = _journeyPreferences.asStateFlow()

    val calculatedJourney = combine(fromPlaceId, toPlaceId, journeyPreferences) { from, to, prefs ->
        if (from != null && to != null) {
            travelGraph.planJourney(from, to, "10:00", prefs)
        } else {
            null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // 3. Active Journey Mode State
    val activeJourney = MutableStateFlow<JourneyPlan?>(null)
    val currentStepIndex = MutableStateFlow(0)
    val isJourneyActive = MutableStateFlow(false)

    // 4. Smart Time Mode Inputs & Outputs
    val smartDuration = MutableStateFlow("HALF DAY") // "1 HOUR", "2 HOURS", "HALF DAY", "FULL DAY", "WEEKEND"
    val smartInterests = MutableStateFlow<Set<String>>(setOf("History", "Canals"))
    val smartItinerary = MutableStateFlow<TripEntity?>(null)

    // 5. Active Metro Station index & Live Tram Position
    // Tram stations: town_hall, library, snow_hill, jewellery_quarter
    val metroStops = listOf("stop_town_hall", "stop_library", "station_snow_hill", "stop_jewellery_quarter")
    val currentTramStopIndex = MutableStateFlow(0)
    val isTramMoving = MutableStateFlow(true)

    // 6. SwiftCard state
    val activeSwiftCard = MutableStateFlow<SwiftCard?>(null)

    init {
        viewModelScope.launch {
            repository.seedDemoDataIfEmpty()
            // Observe preferences to sync journey planning constraints
            preferences.collect { prefs ->
                if (prefs != null) {
                    _journeyPreferences.value = JourneyPreferences(
                        stepFree = prefs.accessibilityStepFree || prefs.accessibilityWheelchair,
                        publicTransportOnly = prefs.defaultMode == "PUBLIC_TRANSPORT"
                    )
                }
            }
        }

        // Initialize SwiftCard
        activeSwiftCard.value = ticketProvider.getSwiftCardDetails("SWIFT-4829-1928")

        // Tram simulation task
        viewModelScope.launch {
            while (true) {
                delay(6000) // Simulates tram transit time between stops
                if (isTramMoving.value) {
                    currentTramStopIndex.value = (currentTramStopIndex.value + 1) % metroStops.size
                }
            }
        }
    }

    // Toggle saved place (bookmarked)
    fun toggleSavedPlace(placeId: String) {
        viewModelScope.launch {
            repository.toggleSavedPlace(placeId)
        }
    }

    // Set origin/destination for plan
    fun setOrigin(placeId: String?) {
        fromPlaceId.value = placeId
    }

    fun setDestination(placeId: String?) {
        toPlaceId.value = placeId
    }

    fun setJourneyPreference(stepFree: Boolean, publicTransportOnly: Boolean) {
        _journeyPreferences.value = JourneyPreferences(
            stepFree = stepFree,
            publicTransportOnly = publicTransportOnly
        )
    }

    // Save customized itinerary
    fun saveCustomTrip(name: String, placeIds: List<String>, startTimes: List<String>) {
        viewModelScope.launch {
            val trip = TripEntity(
                id = UUID.randomUUID().toString(),
                name = name,
                date = "Tomorrow",
                placeIds = placeIds.joinToString(","),
                startTimes = startTimes.joinToString(",")
            )
            repository.insertTrip(trip)
        }
    }

    // Delete trip
    fun deleteTrip(id: String) {
        viewModelScope.launch {
            repository.deleteTrip(id)
        }
    }

    // Purchase ticket simulation (storing it in db & deducting from swift balance)
    fun simulateTicketPurchase(product: TravelProduct) {
        viewModelScope.launch {
            val card = activeSwiftCard.value
            val ticket = ticketProvider.purchaseTicket(product, card?.cardNumber)
            
            // Deduct balance from active card locally if swift card attached
            if (card != null) {
                val newBal = Math.max(0.0, card.balance - product.price)
                activeSwiftCard.value = card.copy(
                    balance = newBal,
                    activeTickets = card.activeTickets + ticket
                )
            }

            // Save in DB
            val entity = PurchasedTicketEntity(
                id = ticket.id,
                productId = product.id,
                productName = product.name,
                mode = product.mode.name,
                price = product.price,
                purchaseTime = ticket.purchaseTimestamp,
                isValid = ticket.isValid
            )
            repository.insertTicket(entity)
        }
    }

    // Start Journey Mode
    fun startJourney(plan: JourneyPlan) {
        activeJourney.value = plan
        currentStepIndex.value = 0
        isJourneyActive.value = true
    }

    fun nextJourneyStep() {
        val plan = activeJourney.value ?: return
        if (currentStepIndex.value < plan.timeline.size - 1) {
            currentStepIndex.value += 1
        } else {
            // Reached destination, close active journey
            isJourneyActive.value = false
            activeJourney.value = null
        }
    }

    fun cancelActiveJourney() {
        isJourneyActive.value = false
        activeJourney.value = null
    }

    // Toggle accessibility toggles in database
    fun updateAccessibilitySettings(stepFree: Boolean, wheelchair: Boolean, lowSensory: Boolean) {
        viewModelScope.launch {
            val current = repository.getPreferences()
            val updated = current.copy(
                accessibilityStepFree = stepFree,
                accessibilityWheelchair = wheelchair,
                accessibilityLowSensory = lowSensory
            )
            repository.updatePreferences(updated)
        }
    }

    // Save custom home/hotel shortcuts
    fun saveShortcuts(homeId: String?, hotelId: String?) {
        viewModelScope.launch {
            val current = repository.getPreferences()
            val updated = current.copy(
                homePlaceId = homeId,
                hotelPlaceId = hotelId
            )
            repository.updatePreferences(updated)
        }
    }

    // signature "Smart Time Mode" - Deterministic Itinerary Builder
    fun generateSmartItinerary() {
        val duration = smartDuration.value
        val interests = smartInterests.value

        // Filter places based on interests
        // Interests match place subcategory or categories
        val filtered = CityData.Places.filter { place ->
            val matchInterest = interests.any { interest ->
                place.subCategory.equals(interest, ignoreCase = true) ||
                place.category.name.equals(interest, ignoreCase = true) ||
                (interest == "History" && place.subCategory == "History") ||
                (interest == "Food" && place.category == PlaceCategory.RESTAURANT) ||
                (interest == "Shopping" && place.category == PlaceCategory.SHOPPING) ||
                (interest == "Canals" && place.subCategory == "Canals") ||
                (interest == "Art" && place.subCategory == "Art & Culture") ||
                (interest == "Parks" && place.subCategory == "Parks")
            }
            // Exclude transport stations
            matchInterest && place.category != PlaceCategory.STATION
        }.shuffled()

        // Determine size based on duration
        val maxItems = when (duration) {
            "1 HOUR" -> 1
            "2 HOURS" -> 2
            "HALF DAY" -> 3
            "FULL DAY" -> 5
            "WEEKEND" -> 7
            else -> 3
        }

        val selectedPlaces = mutableListOf<Place>()
        // Always start at New Street
        val newStreet = CityData.Places.find { it.id == "station_new_street" }
        if (newStreet != null) {
            selectedPlaces.add(newStreet)
        }

        selectedPlaces.addAll(filtered.take(maxItems))

        // Create trip
        val placeIds = selectedPlaces.map { it.id }
        
        // Generate nice sequential times
        val startTimes = mutableListOf<String>()
        var currMin = 9 * 60 + 30 // Start 09:30
        for (i in selectedPlaces.indices) {
            val h = currMin / 60
            val m = currMin % 60
            startTimes.add(String.format("%02d:%02d", h, m))
            currMin += 90 // 1.5 hours duration per stop
        }

        val smartTrip = TripEntity(
            id = "smart_trip_temp",
            name = "Smart Itinerary: $duration in Birmingham",
            date = "Today",
            placeIds = placeIds.joinToString(","),
            startTimes = startTimes.joinToString(",")
        )

        smartItinerary.value = smartTrip
    }

    fun saveSmartItineraryToTrips() {
        val trip = smartItinerary.value ?: return
        viewModelScope.launch {
            val savedTrip = trip.copy(
                id = UUID.randomUUID().toString(),
                name = "Saved: " + trip.name
            )
            repository.insertTrip(savedTrip)
            smartItinerary.value = null
        }
    }
}
