package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.TravelViewModel
import com.example.data.*
import com.example.data.db.TripEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TripsScreen(
    viewModel: TravelViewModel,
    onNavigate: (String) -> Unit
) {
    val userTrips by viewModel.userTrips.collectAsState()
    
    val smartDuration by viewModel.smartDuration.collectAsState()
    val smartInterests by viewModel.smartInterests.collectAsState()
    val smartItinerary by viewModel.smartItinerary.collectAsState()

    var showSmartBuilder by remember { mutableStateOf(false) }
    var selectedTripDetail by remember { mutableStateOf<TripEntity?>(null) }

    if (selectedTripDetail != null) {
        TripDetailView(
            trip = selectedTripDetail!!,
            onBack = { selectedTripDetail = null },
            onStartRoute = { plan ->
                viewModel.startJourney(plan)
                onNavigate("plan")
            },
            onDelete = {
                viewModel.deleteTrip(selectedTripDetail!!.id)
                selectedTripDetail = null
            },
            viewModel = viewModel
        )
        return
    }

    if (showSmartBuilder) {
        SmartTimeModeView(
            duration = smartDuration,
            interests = smartInterests,
            calculatedItinerary = smartItinerary,
            onGenerate = { viewModel.generateSmartItinerary() },
            onSave = {
                viewModel.saveSmartItineraryToTrips()
                showSmartBuilder = false
            },
            onDismiss = { showSmartBuilder = false },
            onUpdateDuration = { viewModel.smartDuration.value = it },
            onToggleInterest = { tag ->
                val curr = smartInterests.toMutableSet()
                if (curr.contains(tag)) curr.remove(tag) else curr.add(tag)
                viewModel.smartInterests.value = curr
            }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MY BIRMINGHAM", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            // Smart Time mode Hero banner (Section 13)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showSmartBuilder = true }
                        .testTag("smart_time_mode_trigger"),
                    colors = CardDefaults.cardColors(containerColor = BhamDeepBlue),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "SMART TIME MODE",
                            style = MaterialTheme.typography.labelMedium,
                            color = BhamGold,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "How long have you got?",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Input your exact available hours (1h, Half Day, etc.) and interests to generate a synchronized multi-modal itinerary.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = { showSmartBuilder = true },
                            colors = ButtonDefaults.buttonColors(containerColor = BhamGold),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text("BUILD CUSTOM TRIP", color = BhamCharcoal, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // User's Trip lists header
            item {
                Text(
                    text = "SAVED ITINERARIES • DEMO JOURNEYS",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
            }

            // Lists saved itineraries
            if (userTrips.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No trips planned yet.", color = MaterialTheme.colorScheme.secondary)
                    }
                }
            } else {
                items(userTrips) { trip ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedTripDetail = trip }
                            .testTag("trip_card_${trip.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(trip.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    text = "Stops: ${trip.placeIds.split(",").size} places • ${trip.date}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowForwardIos,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// Full Trip Timeline Detail and Recalculator View
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TripDetailView(
    trip: TripEntity,
    onBack: () -> Unit,
    onStartRoute: (JourneyPlan) -> Unit,
    onDelete: () -> Unit,
    viewModel: TravelViewModel
) {
    val placeIds = trip.placeIds.split(",")
    val places = placeIds.mapNotNull { pid -> CityData.Places.find { it.id == pid } }
    val times = trip.startTimes.split(",")

    // Sequence calculated journey through all stops (Dijkstra)
    val sequentialSegments = remember(trip) {
        val list = mutableListOf<RouteEdge>()
        for (i in 0 until places.size - 1) {
            val plan = viewModel.travelGraph.planJourney(places[i].id, places[i + 1].id)
            if (plan != null) {
                list.addAll(plan.segments)
            }
        }
        list
    }

    val totalDist = sequentialSegments.sumOf { it.distanceMeters }
    val totalMins = sequentialSegments.sumOf { it.durationMinutes }

    // Final consolidated plan
    val consolidatedPlan = remember(sequentialSegments) {
        val firstStopId = places.firstOrNull()?.id ?: "station_new_street"
        viewModel.travelGraph.planJourney(firstStopId, places.lastOrNull()?.id ?: "station_new_street")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(trip.name.uppercase(), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = BhamRed)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Stats Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Consolidated Route: ${totalMins} mins • ${(totalDist / 100.0).toInt() / 10.0} km",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    style = MaterialTheme.typography.bodyMedium
                )

                if (consolidatedPlan != null) {
                    Button(
                        onClick = { onStartRoute(consolidatedPlan) },
                        colors = ButtonDefaults.buttonColors(containerColor = BhamRed),
                        contentPadding = PaddingValues(horizontal = 12.dp)
                    ) {
                        Text("START ROUTE", color = Color.White)
                    }
                }
            }

            // Timeline progression lists
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                items(places.indices.toList()) { idx ->
                    val place = places[idx]
                    val time = times.getOrNull(idx) ?: "09:30"
                    
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = time,
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.width(64.dp)
                            )
                            
                            VerticalDivider(modifier = Modifier.height(32.dp).padding(horizontal = 8.dp))

                            Column {
                                Text(place.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Text(place.subCategory + " • " + place.neighborhood, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Smart Time Mode Interface (Section 13)
@Composable
fun SmartTimeModeView(
    duration: String,
    interests: Set<String>,
    calculatedItinerary: TripEntity?,
    onGenerate: () -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit,
    onUpdateDuration: (String) -> Unit,
    onToggleInterest: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("SMART TIME BUILDER", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        }

        // Q1: Duration selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("HOW LONG HAVE YOU GOT?", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    val durs = listOf("1 HOUR", "2 HOURS", "HALF DAY", "FULL DAY", "WEEKEND")
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        durs.take(3).forEach { dur ->
                            FilterChip(
                                selected = duration == dur,
                                onClick = { onUpdateDuration(dur) },
                                label = { Text(dur, fontSize = 10.sp) },
                                modifier = Modifier.testTag("smart_dur_$dur")
                            )
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        durs.drop(3).forEach { dur ->
                            FilterChip(
                                selected = duration == dur,
                                onClick = { onUpdateDuration(dur) },
                                label = { Text(dur, fontSize = 10.sp) },
                                modifier = Modifier.testTag("smart_dur_$dur")
                            )
                        }
                    }
                }
            }
        }

        // Q2: Interests checkboxes
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("WHAT ARE YOU INTERESTED IN?", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(10.dp))

                    val tags = listOf("History", "Food", "Architecture", "Shopping", "Art", "Canals", "Parks")
                    tags.forEach { tag ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleInterest(tag) }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = interests.contains(tag),
                                onCheckedChange = { onToggleInterest(tag) },
                                modifier = Modifier.testTag("interest_cb_$tag")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(tag, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        // Generate triggers
        item {
            Button(
                onClick = onGenerate,
                modifier = Modifier.fillMaxWidth().testTag("generate_smart_itinerary_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = BhamRed)
            ) {
                Text("CALCULATE SEQUENCED TRIP", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        // Results Timeline
        if (calculatedItinerary != null) {
            item {
                Text("GENERATED SEQUENCE", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.secondary)
            }

            val pids = calculatedItinerary.placeIds.split(",")
            val pObjects = pids.mapNotNull { id -> CityData.Places.find { it.id == id } }
            val pTimes = calculatedItinerary.startTimes.split(",")

            items(pObjects.indices.toList()) { idx ->
                val place = pObjects[idx]
                val ptime = pTimes.getOrNull(idx) ?: "09:30"
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(ptime, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(place.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Text(place.neighborhood + " • " + place.subCategory, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = onSave,
                    modifier = Modifier.fillMaxWidth().testTag("save_smart_itinerary_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = BhamGold)
                ) {
                    Text("SAVE TO MY TRIPS", color = BhamCharcoal, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
