package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_places")
data class SavedPlaceEntity(
    @PrimaryKey val placeId: String,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_trips")
data class TripEntity(
    @PrimaryKey val id: String,
    val name: String,
    val date: String,
    val placeIds: String, // Comma-separated list of place IDs, e.g. "station_new_street,attraction_victoria_square"
    val startTimes: String // Comma-separated scheduled times e.g. "09:30,10:30"
)

@Entity(tableName = "purchased_tickets")
data class PurchasedTicketEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val productName: String,
    val mode: String,
    val price: Double,
    val purchaseTime: Long,
    val isValid: Boolean = true
)

@Entity(tableName = "user_preferences")
data class UserPreferencesEntity(
    @PrimaryKey val id: Int = 1,
    val homePlaceId: String? = null,
    val hotelPlaceId: String? = null,
    val accessibilityStepFree: Boolean = false,
    val accessibilityWheelchair: Boolean = false,
    val accessibilityLowSensory: Boolean = false,
    val defaultMode: String = "FASTEST"
)
