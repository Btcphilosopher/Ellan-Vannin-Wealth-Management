package com.example.data

import java.util.PriorityQueue

data class RouteEdge(
    val fromId: String,
    val toId: String,
    val mode: TransportMode,
    val durationMinutes: Int,
    val distanceMeters: Int,
    val description: String,
    val isStepFree: Boolean = true
)

data class JourneyPlan(
    val segments: List<RouteEdge>,
    val totalDurationMinutes: Int,
    val totalWalkingMinutes: Int,
    val totalTransportMinutes: Int,
    val totalDistanceMeters: Int,
    val isAccessible: Boolean,
    val timeline: List<TimelineItem>
)

data class TimelineItem(
    val time: String, // e.g. "14:32"
    val mode: TransportMode?, // null for node events
    val description: String,
    val detail: String,
    val locationId: String,
    val duration: Int
)

class BirminghamTravelGraph {
    private val edges = mutableListOf<RouteEdge>()

    init {
        // Build actual West Midlands multimodal travel graph
        
        // 1. Station to Station Core Connections
        addEdge("station_new_street", "station_moor_street", TransportMode.WALKING, 5, 450, "Walk via Queensway Link", true)
        addEdge("station_new_street", "station_snow_hill", TransportMode.WALKING, 10, 800, "Walk via Corporation Street", true)
        addEdge("station_moor_street", "station_snow_hill", TransportMode.WALKING, 9, 700, "Walk via Moor St & Colmore Row", true)

        // Metro Line 1 stops (Tram)
        addEdge("stop_town_hall", "stop_library", TransportMode.TRAM, 3, 400, "West Midlands Metro (Line 1 towards Edgbaston)", true)
        addEdge("stop_town_hall", "station_snow_hill", TransportMode.TRAM, 4, 600, "West Midlands Metro (Line 1 towards Wolverhampton)", true)
        addEdge("station_snow_hill", "stop_jewellery_quarter", TransportMode.TRAM, 5, 1200, "West Midlands Metro (Line 1 towards Wolverhampton)", true)
        addEdge("stop_jewellery_quarter", "station_new_street", TransportMode.TRAIN, 4, 1800, "West Midlands Railway (towards New Street)", true)

        // 2. City Centre Connections
        addEdge("station_new_street", "attraction_victoria_square", TransportMode.WALKING, 4, 300, "Walk via Pinfold Street", true)
        addEdge("attraction_victoria_square", "stop_town_hall", TransportMode.WALKING, 1, 100, "Walk across Victoria Square", true)
        addEdge("attraction_victoria_square", "attraction_museum_art_gallery", TransportMode.WALKING, 2, 150, "Walk via Chamberlain Square", false) // Museum has steps at front entrance
        addEdge("stop_town_hall", "attraction_museum_art_gallery", TransportMode.WALKING, 2, 150, "Walk via Chamberlain Square", false)
        addEdge("attraction_museum_art_gallery", "food_dishoom", TransportMode.WALKING, 2, 120, "Walk across Chamberlain Square", true)
        addEdge("attraction_victoria_square", "food_medicine_bakery", TransportMode.WALKING, 4, 350, "Walk down New Street", false) // Cafe has historical stairs

        // 3. Westside & Canal Connections (Brindleyplace)
        addEdge("stop_library", "attraction_library_bham", TransportMode.WALKING, 1, 80, "Walk across Centenary Square", true)
        addEdge("stop_town_hall", "stop_library", TransportMode.WALKING, 6, 500, "Walk via Centenary Square", true)
        addEdge("stop_library", "attraction_canals_gas_street", TransportMode.WALKING, 4, 350, "Walk via Broad Street & Canalside ramp", true)
        addEdge("station_new_street", "attraction_canals_gas_street", TransportMode.WALKING, 9, 750, "Walk via Navigation Street & Mailbox", true)

        // 4. Shopping Connections
        addEdge("station_new_street", "shopping_bullring", TransportMode.WALKING, 3, 250, "Walk through Grand Central", true)
        addEdge("shopping_bullring", "station_moor_street", TransportMode.WALKING, 3, 220, "Walk down Moor Street Queensway", true)
        addEdge("shopping_bullring", "shopping_rag_market", TransportMode.WALKING, 2, 150, "Walk down Edgbaston Street", true)

        // 5. Digbeth Connections
        addEdge("station_moor_street", "attraction_custard_factory", TransportMode.WALKING, 8, 650, "Walk under Digbeth Viaduct", true)
        addEdge("attraction_custard_factory", "shopping_red_brick", TransportMode.WALKING, 3, 200, "Walk via Floodgate Street", true)

        // 6. Jewellery Quarter Connections
        addEdge("stop_jewellery_quarter", "attraction_jewellery_museum", TransportMode.WALKING, 3, 250, "Walk via Vyse Street", true)
        addEdge("stop_jewellery_quarter", "food_lasan", TransportMode.WALKING, 5, 400, "Walk via Spencer Street", true)
        addEdge("food_lasan", "food_st_pauls_house", TransportMode.WALKING, 4, 300, "Walk via St Paul's Square", true)
        addEdge("station_snow_hill", "food_st_pauls_house", TransportMode.WALKING, 6, 500, "Walk down Livery Street", true)

        // 7. Edgbaston Connections
        addEdge("station_new_street", "attraction_botanical_gardens", TransportMode.BUS, 12, 2800, "National Express Bus 23 (towards Harborne)", true)
        addEdge("station_new_street", "attraction_botanical_gardens", TransportMode.CYCLING, 10, 2800, "Cycle via A4540 Cycle Superhighway", true)

        // 8. Outer Outposts (Aston & South Side)
        addEdge("station_new_street", "attraction_aston_hall", TransportMode.TRAIN, 8, 3800, "West Midlands Railway (towards Lichfield to Aston Station)", true)
        addEdge("attraction_aston_hall", "station_new_street", TransportMode.BUS, 15, 3800, "National Express Bus 7 (towards City Centre)", true)
        addEdge("station_new_street", "food_b_ham_balti_triangle", TransportMode.BUS, 14, 3200, "National Express Bus 50 (towards Maypole)", true)

        // 9. Back edges to ensure bidirectionality for walking/cycling
        duplicateOpposites()
    }

    private fun addEdge(from: String, to: String, mode: TransportMode, duration: Int, distance: Int, desc: String, stepFree: Boolean) {
        edges.add(RouteEdge(from, to, mode, duration, distance, desc, stepFree))
    }

    private fun duplicateOpposites() {
        val reversed = mutableListOf<RouteEdge>()
        for (edge in edges) {
            if (edge.mode == TransportMode.WALKING || edge.mode == TransportMode.CYCLING) {
                // Reverse description lightly
                val revDesc = edge.description.replace("towards", "from").replace("via", "back via")
                reversed.add(RouteEdge(edge.toId, edge.fromId, edge.mode, edge.durationMinutes, edge.distanceMeters, "Return: $revDesc", edge.isStepFree))
            } else if (edge.mode == TransportMode.TRAM) {
                // Opposite tram direction
                val revDesc = if (edge.description.contains("Edgbaston")) {
                    "West Midlands Metro (Line 1 towards Wolverhampton)"
                } else {
                    "West Midlands Metro (Line 1 towards Edgbaston Village)"
                }
                reversed.add(RouteEdge(edge.toId, edge.fromId, edge.mode, edge.durationMinutes, edge.distanceMeters, revDesc, edge.isStepFree))
            } else if (edge.mode == TransportMode.TRAIN || edge.mode == TransportMode.BUS) {
                // Opposite train/bus direction
                reversed.add(RouteEdge(edge.toId, edge.fromId, edge.mode, edge.durationMinutes, edge.distanceMeters, "Return: ${edge.description}", edge.isStepFree))
            }
        }
        edges.addAll(reversed)
    }

    // Graph search (Dijkstra algorithm)
    fun planJourney(
        originId: String,
        destId: String,
        startTimeStr: String = "10:00",
        preferences: JourneyPreferences = JourneyPreferences()
    ): JourneyPlan? {
        if (originId == destId) {
            val place = CityData.Places.find { it.id == originId } ?: return null
            return JourneyPlan(
                segments = emptyList(),
                totalDurationMinutes = 0,
                totalWalkingMinutes = 0,
                totalTransportMinutes = 0,
                totalDistanceMeters = 0,
                isAccessible = place.isAccessible,
                timeline = listOf(TimelineItem(startTimeStr, null, "You are at your destination", place.name, originId, 0))
            )
        }

        // Custom Dijkstra implementation
        val dist = mutableMapOf<String, Int>()
        val parent = mutableMapOf<String, RouteEdge>()
        val pq = PriorityQueue<Pair<String, Int>>(compareBy { it.second })

        dist[originId] = 0
        pq.add(Pair(originId, 0))

        while (pq.isNotEmpty()) {
            val (currentId, currentDist) = pq.poll()

            if (currentDist > (dist[currentId] ?: Int.MAX_VALUE)) continue
            if (currentId == destId) break

            val currentPlace = CityData.Places.find { it.id == currentId }

            // Get outgoing edges
            val outgoing = edges.filter { it.fromId == currentId }
            for (edge in outgoing) {
                val targetPlace = CityData.Places.find { it.id == edge.toId }

                // Check Preferences:
                // 1. Accessibility Filter
                if (preferences.stepFree) {
                    if (!edge.isStepFree) continue
                    if (targetPlace != null && !targetPlace.isAccessible) continue
                    if (currentPlace != null && !currentPlace.isAccessible) continue
                }
                // 2. Mode Constraints
                if (preferences.walkOnly && edge.mode != TransportMode.WALKING) continue
                if (preferences.cycleOnly && edge.mode != TransportMode.CYCLING) continue
                if (preferences.publicTransportOnly && edge.mode == TransportMode.CYCLING) continue

                // Calculate edge cost with weights
                var cost = edge.durationMinutes
                // Add transfer penalty if we switch modes
                val prevEdge = parent[currentId]
                if (prevEdge != null && prevEdge.mode != edge.mode) {
                    cost += 3 // 3 mins transfer/waiting penalty
                }

                val newDist = currentDist + cost
                if (newDist < (dist[edge.toId] ?: Int.MAX_VALUE)) {
                    dist[edge.toId] = newDist
                    parent[edge.toId] = edge
                    pq.add(Pair(edge.toId, newDist))
                }
            }
        }

        // Reconstruct path
        if (!dist.containsKey(destId)) {
            // Direct walking fallback if graph search fails to connect
            return makeDirectFallback(originId, destId, startTimeStr)
        }

        val segments = mutableListOf<RouteEdge>()
        var curr = destId
        while (curr != originId) {
            val edge = parent[curr] ?: break
            segments.add(0, edge)
            curr = edge.fromId
        }

        var totalWalk = 0
        var totalTrans = 0
        var totalDist = 0
        var isAccessible = true

        for (seg in segments) {
            if (seg.mode == TransportMode.WALKING) {
                totalWalk += seg.durationMinutes
            } else {
                totalTrans += seg.durationMinutes
            }
            totalDist += seg.distanceMeters
            if (!seg.isStepFree) isAccessible = false
        }

        // Compile timeline
        val timeline = mutableListOf<TimelineItem>()
        var currentTime = parseTime(startTimeStr)

        val firstPlace = CityData.Places.find { it.id == originId }
        if (firstPlace != null) {
            timeline.add(
                TimelineItem(
                    time = formatTime(currentTime),
                    mode = null,
                    description = "Arrive / Start at ${firstPlace.name}",
                    detail = firstPlace.neighborhood,
                    locationId = originId,
                    duration = 0
                )
            )
        }

        for (i in segments.indices) {
            val seg = segments[i]
            val fromP = CityData.Places.find { it.id == seg.fromId }
            val toP = CityData.Places.find { it.id == seg.toId }

            // Travel segment
            timeline.add(
                TimelineItem(
                    time = formatTime(currentTime),
                    mode = seg.mode,
                    description = seg.description,
                    detail = "${seg.durationMinutes} min • ${(seg.distanceMeters / 100.0).toInt() / 10.0} km",
                    locationId = seg.toId,
                    duration = seg.durationMinutes
                )
            )

            currentTime += seg.durationMinutes

            if (i == segments.size - 1 && toP != null) {
                timeline.add(
                    TimelineItem(
                        time = formatTime(currentTime),
                        mode = null,
                        description = "Arrive at ${toP.name}",
                        detail = "Destination reached in ${toP.neighborhood}",
                        locationId = seg.toId,
                        duration = 0
                    )
                )
            }
        }

        return JourneyPlan(
            segments = segments,
            totalDurationMinutes = totalWalk + totalTrans,
            totalWalkingMinutes = totalWalk,
            totalTransportMinutes = totalTrans,
            totalDistanceMeters = totalDist,
            isAccessible = isAccessible,
            timeline = timeline
        )
    }

    private fun makeDirectFallback(originId: String, destId: String, startTimeStr: String): JourneyPlan? {
        val o = CityData.Places.find { it.id == originId } ?: return null
        val d = CityData.Places.find { it.id == destId } ?: return null

        // Approximate physical distance
        val dx = (o.lat - d.lat) * 111000
        val dy = (o.lng - d.lng) * 68000
        val distMeters = Math.sqrt(dx * dx + dy * dy).toInt()

        // Walking speed 5 km/h = 83 m/min
        val walkMin = Math.max(2, distMeters / 83)

        val edge = RouteEdge(
            fromId = originId,
            toId = destId,
            mode = TransportMode.WALKING,
            durationMinutes = walkMin,
            distanceMeters = distMeters,
            description = "Walk via direct pedestrian routes",
            isStepFree = o.isAccessible && d.isAccessible
        )

        val timeline = listOf(
            TimelineItem(startTimeStr, null, "Start at ${o.name}", o.neighborhood, originId, 0),
            TimelineItem(startTimeStr, TransportMode.WALKING, "Walk via direct pedestrian routes", "$walkMin min • ${(distMeters/100.0).toInt()/10.0} km", destId, walkMin),
            TimelineItem(formatTime(parseTime(startTimeStr) + walkMin), null, "Arrive at ${d.name}", d.neighborhood, destId, 0)
        )

        return JourneyPlan(
            segments = listOf(edge),
            totalDurationMinutes = walkMin,
            totalWalkingMinutes = walkMin,
            totalTransportMinutes = 0,
            totalDistanceMeters = distMeters,
            isAccessible = edge.isStepFree,
            timeline = timeline
        )
    }

    private fun parseTime(timeStr: String): Int {
        return try {
            val parts = timeStr.split(":")
            parts[0].toInt() * 60 + parts[1].toInt()
        } catch (e: Exception) {
            10 * 60 // Default 10:00 AM
        }
    }

    private fun formatTime(minutes: Int): String {
        val mins = minutes % 1440
        val h = mins / 60
        val m = mins % 60
        return String.format("%02d:%02d", h, m)
    }
}

data class JourneyPreferences(
    val stepFree: Boolean = false,
    val walkOnly: Boolean = false,
    val cycleOnly: Boolean = false,
    val publicTransportOnly: Boolean = false
)
