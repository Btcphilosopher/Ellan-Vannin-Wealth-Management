package com.example.data.db

import android.content.Context
import androidx.room.Room
import com.example.data.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flow

class AppRepository(context: Context) {
    private val db = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "birmingham_travel_os.db"
    ).build()

    private val savedPlaceDao = db.savedPlaceDao()
    private val tripDao = db.tripDao()
    private val ticketDao = db.purchasedTicketDao()
    private val preferencesDao = db.userPreferencesDao()

    val savedPlacesFlow: Flow<List<SavedPlaceEntity>> = savedPlaceDao.getAllSavedPlaces()
    val tripsFlow: Flow<List<TripEntity>> = tripDao.getAllTrips()
    val ticketsFlow: Flow<List<PurchasedTicketEntity>> = ticketDao.getAllTickets()
    val preferencesFlow: Flow<UserPreferencesEntity?> = preferencesDao.getPreferencesFlow()

    suspend fun isPlaceSaved(placeId: String): Boolean = savedPlaceDao.isPlaceSaved(placeId)

    suspend fun toggleSavedPlace(placeId: String) {
        if (savedPlaceDao.isPlaceSaved(placeId)) {
            savedPlaceDao.deleteSavedPlace(placeId)
        } else {
            savedPlaceDao.savePlace(SavedPlaceEntity(placeId))
        }
    }

    suspend fun insertTrip(trip: TripEntity) {
        tripDao.insertTrip(trip)
    }

    suspend fun deleteTrip(id: String) {
        tripDao.deleteTrip(id)
    }

    suspend fun insertTicket(ticket: PurchasedTicketEntity) {
        ticketDao.insertTicket(ticket)
    }

    suspend fun deleteTicket(id: String) {
        ticketDao.deleteTicket(id)
    }

    suspend fun getPreferences(): UserPreferencesEntity {
        return preferencesDao.getPreferencesDirect() ?: UserPreferencesEntity().also {
            preferencesDao.updatePreferences(it)
        }
    }

    suspend fun updatePreferences(prefs: UserPreferencesEntity) {
        preferencesDao.updatePreferences(prefs)
    }

    suspend fun seedDemoDataIfEmpty() {
        val currentTrips = tripsFlow.firstOrNull() ?: emptyList()
        if (currentTrips.isEmpty()) {
            // Seed Demo Journeys (Section 30)
            val demo1 = TripEntity(
                id = "demo_1",
                name = "Demo 1: The Core Loop",
                date = "Today",
                placeIds = "station_new_street,shopping_bullring,attraction_victoria_square,attraction_canals_gas_street,station_new_street",
                startTimes = "09:30,10:15,11:30,12:45,14:00"
            )
            val demo2 = TripEntity(
                id = "demo_2",
                name = "Demo 2: JQ to Digbeth Creative",
                date = "Saturday",
                placeIds = "station_new_street,stop_jewellery_quarter,attraction_custard_factory",
                startTimes = "10:00,11:30,14:00"
            )
            val demo3 = TripEntity(
                id = "demo_3",
                name = "Demo 3: One Hour Express",
                date = "Anyday",
                placeIds = "station_new_street,attraction_victoria_square,attraction_library_bham",
                startTimes = "09:00,09:20,09:50"
            )
            val demo4 = TripEntity(
                id = "demo_4",
                name = "Demo 4: Industrial Heritage",
                date = "Half Day",
                placeIds = "station_new_street,attraction_canals_gas_street,attraction_jewellery_museum,attraction_thinktank",
                startTimes = "09:00,09:40,11:30,14:00"
            )
            val demo5 = TripEntity(
                id = "demo_5",
                name = "Demo 5: Dedicated Shopping",
                date = "Full Day",
                placeIds = "station_new_street,shopping_bullring,shopping_rag_market,shopping_red_brick",
                startTimes = "10:00,10:30,13:00,15:30"
            )
            val demo6 = TripEntity(
                id = "demo_6",
                name = "Demo 6: Food & Architecture",
                date = "Evening",
                placeIds = "station_new_street,attraction_victoria_square,food_dishoom,food_lasan",
                startTimes = "11:00,11:30,12:30,18:00"
            )

            tripDao.insertTrip(demo1)
            tripDao.insertTrip(demo2)
            tripDao.insertTrip(demo3)
            tripDao.insertTrip(demo4)
            tripDao.insertTrip(demo5)
            tripDao.insertTrip(demo6)
        }

        // Initialize default user preferences
        val prefs = preferencesDao.getPreferencesDirect()
        if (prefs == null) {
            preferencesDao.updatePreferences(
                UserPreferencesEntity(
                    id = 1,
                    homePlaceId = "station_new_street",
                    hotelPlaceId = "food_st_pauls_house",
                    accessibilityStepFree = false,
                    accessibilityWheelchair = false,
                    accessibilityLowSensory = false
                )
            )
        }
    }
}
