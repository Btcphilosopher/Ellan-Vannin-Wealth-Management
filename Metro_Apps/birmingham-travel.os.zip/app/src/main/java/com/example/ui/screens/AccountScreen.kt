package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.TravelViewModel
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    viewModel: TravelViewModel,
    onNavigate: (String) -> Unit
) {
    val preferences by viewModel.preferences.collectAsState()
    val savedPlaces by viewModel.savedPlaces.collectAsState()

    var showHomePicker by remember { mutableStateOf(false) }
    var showHotelPicker by remember { mutableStateOf(false) }

    val places = CityData.Places

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ACCOUNT & ACCESSIBILITY", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            // User Card Profile
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Person, contentDescription = "User", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("BIRMINGHAM VISITOR", fontWeight = FontWeight.Black, style = MaterialTheme.typography.bodyLarge)
                            Text("Swift Account Enabled", style = MaterialTheme.typography.labelSmall, color = BhamGold, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Shortcuts Config Section (Section 33)
            item {
                Text(
                    text = "MY LOCATIONS & SHORTCUTS",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
            }

            item {
                if (preferences != null) {
                    val prefs = preferences!!
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Home Shortcut
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showHomePicker = true }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Home, contentDescription = "Home", tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text("HOME HUB", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                        val homeName = places.find { it.id == prefs.homePlaceId }?.name ?: "Set Home Address"
                                        Text(homeName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                            // Hotel Shortcut
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showHotelPicker = true }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Hotel, contentDescription = "Hotel", tint = BhamGold)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text("ACCOMMODATION / HOTEL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                        val hotelName = places.find { it.id == prefs.hotelPlaceId }?.name ?: "Set Hotel Accommodation"
                                        Text(hotelName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            // Accessibility Settings (Section 22)
            item {
                Text(
                    text = "ACCESSIBILITY & ASSISTANCE PROFILE",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
            }

            item {
                if (preferences != null) {
                    val prefs = preferences!!
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Step-free Routing
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Step-free Access", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("Avoid stairs, steep gradients, and physical escalators.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                }
                                Switch(
                                    checked = prefs.accessibilityStepFree,
                                    onCheckedChange = { viewModel.updateAccessibilitySettings(it, prefs.accessibilityWheelchair, prefs.accessibilityLowSensory) },
                                    modifier = Modifier.testTag("toggle_step_free")
                                )
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                            // Wheelchair Assistance
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Wheelchair Profile", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("Optimize routing exclusively for level boarding & ramps.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                }
                                Switch(
                                    checked = prefs.accessibilityWheelchair,
                                    onCheckedChange = { viewModel.updateAccessibilitySettings(prefs.accessibilityStepFree, it, prefs.accessibilityLowSensory) },
                                    modifier = Modifier.testTag("toggle_wheelchair")
                                )
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                            // Low Sensory Profile
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Low Sensory / Quiet Routes", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text("Avoid high-crowd times and loud, packed transport hubs.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                }
                                Switch(
                                    checked = prefs.accessibilityLowSensory,
                                    onCheckedChange = { viewModel.updateAccessibilitySettings(prefs.accessibilityStepFree, prefs.accessibilityWheelchair, it) },
                                    modifier = Modifier.testTag("toggle_low_sensory")
                                )
                            }
                        }
                    }
                }
            }

            // Bookmarked Favourites lists (Section 33)
            item {
                Text(
                    text = "FAVOURITE SAVED PLACES",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
            }

            if (savedPlaces.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No favorite places saved yet.", color = MaterialTheme.colorScheme.secondary)
                    }
                }
            } else {
                items(savedPlaces) { savedEntity ->
                    val place = places.find { it.id == savedEntity.placeId }
                    if (place != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigate("explore?placeId=${place.id}") }
                                .testTag("fav_place_${place.id}"),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Favorite, contentDescription = "Saved", tint = BhamRed)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(place.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text(place.neighborhood, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Home shortcuts Picker Dialog
    if (showHomePicker && preferences != null) {
        LocationPickerDialog(
            title = "Choose Home Location",
            places = places,
            onDismiss = { showHomePicker = false },
            onSelect = {
                viewModel.saveShortcuts(it, preferences!!.hotelPlaceId)
                showHomePicker = false
            }
        )
    }

    // Hotel shortcuts Picker Dialog
    if (showHotelPicker && preferences != null) {
        LocationPickerDialog(
            title = "Choose Accommodation",
            places = places,
            onDismiss = { showHotelPicker = false },
            onSelect = {
                viewModel.saveShortcuts(preferences!!.homePlaceId, it)
                showHotelPicker = false
            }
        )
    }
}
