package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.TravelViewModel
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanScreen(
    viewModel: TravelViewModel,
    onNavigate: (String) -> Unit
) {
    val fromId by viewModel.fromPlaceId.collectAsState()
    val toId by viewModel.toPlaceId.collectAsState()
    val preferences by viewModel.preferences.collectAsState()
    val journeyPrefs by viewModel.journeyPreferences.collectAsState()
    val calculatedJourney by viewModel.calculatedJourney.collectAsState()

    val isJourneyActive by viewModel.isJourneyActive.collectAsState()
    val activeJourney by viewModel.activeJourney.collectAsState()
    val currentStepIndex by viewModel.currentStepIndex.collectAsState()

    var showFromPicker by remember { mutableStateOf(false) }
    var showToPicker by remember { mutableStateOf(false) }

    val places = CityData.Places

    if (isJourneyActive && activeJourney != null) {
        // Switch to Your Journey Mode (Section 7 & 24)
        ActiveJourneyModeView(
            journey = activeJourney!!,
            currentIndex = currentStepIndex,
            onNext = { viewModel.nextJourneyStep() },
            onCancel = { viewModel.cancelActiveJourney() }
        )
    } else {
        // Standard Journey Planner Interface
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("PLAN YOUR JOURNEY", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                // Inputs Panel
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        // FROM Selector
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showFromPicker = true }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.TripOrigin, contentDescription = "From", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("FROM", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                val originName = places.find { it.id == fromId }?.name ?: "Select Starting Point"
                                Text(originName, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                        // TO Selector
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showToPicker = true }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Place, contentDescription = "To", tint = BhamGold)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("TO", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                val destName = places.find { it.id == toId }?.name ?: "Select Destination"
                                Text(destName, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Preferences Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ACCESSIBILITY & PREFERENCES", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = journeyPrefs.stepFree,
                        onClick = { viewModel.setJourneyPreference(!journeyPrefs.stepFree, journeyPrefs.publicTransportOnly) },
                        label = { Text("Step-Free Routing", fontSize = 11.sp) },
                        leadingIcon = { if (journeyPrefs.stepFree) Icon(Icons.Default.Check, "Checked", modifier = Modifier.size(12.dp)) }
                    )
                    FilterChip(
                        selected = journeyPrefs.publicTransportOnly,
                        onClick = { viewModel.setJourneyPreference(journeyPrefs.stepFree, !journeyPrefs.publicTransportOnly) },
                        label = { Text("Transit Only", fontSize = 11.sp) },
                        leadingIcon = { if (journeyPrefs.publicTransportOnly) Icon(Icons.Default.Check, "Checked", modifier = Modifier.size(12.dp)) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Journey results or state
                if (calculatedJourney != null) {
                    val plan = calculatedJourney!!
                    
                    // Route duration summary banner
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Timer, contentDescription = "Duration", size = 16.dp, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${plan.totalDurationMinutes} min journey",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Black,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                Text(
                                    text = "Walking: ${plan.totalWalkingMinutes} min • Transit: ${plan.totalTransportMinutes} min",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                )
                            }

                            Button(
                                onClick = { viewModel.startJourney(plan) },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onPrimaryContainer),
                                contentPadding = PaddingValues(horizontal = 12.dp),
                                modifier = Modifier.testTag("start_journey_button")
                            ) {
                                Text("GO", fontWeight = FontWeight.Black)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (plan.isAccessible) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        ) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Accessible, contentDescription = "Accessible", tint = BhamMutedGreen, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("STEP FREE • Suitable for wheelchair access & strollers", style = MaterialTheme.typography.labelMedium, color = BhamMutedGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // Journey timeline steps
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        itemsIndexed(plan.timeline) { idx, item ->
                            TimelineStepRow(item = item)
                        }
                    }
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Unable to construct journey. Check routing configurations.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }
    }

    // FROM Location Picker Dialog
    if (showFromPicker) {
        LocationPickerDialog(
            title = "Choose Starting Point",
            places = places,
            onDismiss = { showFromPicker = false },
            onSelect = {
                viewModel.setOrigin(it)
                showFromPicker = false
            }
        )
    }

    // TO Location Picker Dialog
    if (showToPicker) {
        LocationPickerDialog(
            title = "Choose Destination",
            places = places,
            onDismiss = { showToPicker = false },
            onSelect = {
                viewModel.setDestination(it)
                showToPicker = false
            }
        )
    }
}

@Composable
private fun Icon(imageVector: androidx.compose.ui.graphics.vector.ImageVector, contentDescription: String, size: androidx.compose.ui.unit.Dp, tint: Color) {
    Icon(
        imageVector = imageVector,
        contentDescription = contentDescription,
        tint = tint,
        modifier = Modifier.size(size)
    )
}

@Composable
fun TimelineStepRow(item: TimelineItem) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        // Time column
        Text(
            text = item.time,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.width(48.dp)
        )

        // Line and Node column
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (item.mode == null) BhamGold else MaterialTheme.colorScheme.primary)
            )
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(38.dp)
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
            )
        }

        // Details column
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.description,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = item.detail,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        // Mode icon
        if (item.mode != null) {
            val modeIcon = when (item.mode) {
                TransportMode.WALKING -> Icons.Default.DirectionsWalk
                TransportMode.CYCLING -> Icons.Default.DirectionsBike
                TransportMode.TRAM -> Icons.Default.Tram
                TransportMode.TRAIN -> Icons.Default.Train
                TransportMode.BUS -> Icons.Default.DirectionsBus
            }
            Icon(
                imageVector = modeIcon,
                contentDescription = item.mode.name,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun ActiveJourneyModeView(
    journey: JourneyPlan,
    currentIndex: Int,
    onNext: () -> Unit,
    onCancel: () -> Unit
) {
    val currentStep = journey.timeline.getOrNull(currentIndex)
    val nextStep = journey.timeline.getOrNull(currentIndex + 1)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BhamCharcoal)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 72.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "YOUR ACTIVE JOURNEY",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "ARRIVAL: ${journey.timeline.lastOrNull()?.time ?: "--:--"}",
                    style = MaterialTheme.typography.labelMedium,
                    color = BhamGold,
                    fontWeight = FontWeight.Bold
                )
            }

            // Central Massive Instructions (Section 7)
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "CURRENT STEP",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White.copy(alpha = 0.5f)
                )

                if (currentStep != null) {
                    Text(
                        text = currentStep.description.uppercase(),
                        style = MaterialTheme.typography.headlineLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        lineHeight = 38.sp
                    )
                    Text(
                        text = currentStep.detail,
                        style = MaterialTheme.typography.titleLarge,
                        color = BhamGold,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "THEN NEXT",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White.copy(alpha = 0.5f)
                )

                if (nextStep != null) {
                    Text(
                        text = nextStep.description,
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        text = "Arrive at your Destination",
                        style = MaterialTheme.typography.titleLarge,
                        color = BhamMutedGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Step Progress Dots
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                journey.timeline.forEachIndexed { idx, _ ->
                    Box(
                        modifier = Modifier
                            .size(if (idx == currentIndex) 12.dp else 8.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (idx == currentIndex) BhamGold else Color.White.copy(alpha = 0.3f))
                    )
                }
            }
        }

        // Action controls bottom panel
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { onCancel() },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                border = ButtonDefaults.outlinedButtonBorder.copy()
            ) {
                Text("CANCEL ROUTE")
            }

            Button(
                onClick = { onNext() },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = BhamRed)
            ) {
                Text(
                    text = if (currentIndex < journey.timeline.size - 1) "PROCEED" else "COMPLETE",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun LocationPickerDialog(
    title: String,
    places: List<Place>,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(places) { _, place ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(place.id) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            val icon = when (place.category) {
                                PlaceCategory.STATION -> Icons.Default.Train
                                PlaceCategory.ATTRACTION -> Icons.Default.Attractions
                                PlaceCategory.RESTAURANT -> Icons.Default.Restaurant
                                PlaceCategory.SHOPPING -> Icons.Default.ShoppingBag
                                else -> Icons.Default.LocationOn
                            }
                            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(place.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Text(place.neighborhood, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("CANCEL") }
        }
    )
}
