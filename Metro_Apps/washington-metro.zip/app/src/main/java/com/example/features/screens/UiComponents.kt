package com.example.features.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BankCardReference
import com.example.domain.model.TransitCard
import com.example.ui.theme.*

@Composable
fun MetroCardDisplay(
    card: TransitCard,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {}
) {
    // Elegant Civic-Brutalist inspired card drawing
    val cardColors = if (card.status == "Suspended" || card.status == "Blocked") {
        listOf(Color(0xFF555555), Color(0xFF333333))
    } else {
        listOf(MetroRed, DeepBlack)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .drawBehind {
                drawRect(
                    brush = Brush.linearGradient(
                        colors = cardColors,
                        start = Offset(0f, 0f),
                        end = Offset(size.width, size.height)
                    )
                )
                // Civic geometric line art overlay representing station ceiling geometry
                for (i in 1..4) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.05f * i),
                        start = Offset(0f, size.height * (0.2f * i)),
                        end = Offset(size.width, size.height * (0.15f * i)),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }
            .padding(24.dp)
            .testTag("transit_card_${card.id}")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "WASHINGTON METRO",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = card.nickname,
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = card.cardType.uppercase(),
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Column {
                Text(
                    text = "Available Balance",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 12.sp
                )
                Text(
                    text = "$${String.format("%.2f", card.balance)}",
                    color = Color.White,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-0.5).sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = card.cardNumber,
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.sp
                )

                // Smart Card status chip
                val (statusBg, statusFg, statusLabel) = when (card.status) {
                    "Ready" -> Triple(MetroGreen, Color.White, "READY")
                    "LowBalance" -> Triple(MetroYellow, Color.Black, "LOW BALANCE")
                    "Suspended" -> Triple(Color.Gray, Color.White, "FROZEN")
                    "Blocked" -> Triple(Color.Red, Color.White, "BLOCKED")
                    else -> Triple(Color.White.copy(alpha = 0.2f), Color.White, card.status.uppercase())
                }

                Box(
                    modifier = Modifier
                        .background(statusBg, RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = statusLabel,
                        color = statusFg,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun BankCardDisplay(
    card: BankCardReference,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {}
) {
    val cardColors = when (card.brand.lowercase()) {
        "visa" -> listOf(Color(0xFF1A1F71), Color(0xFF005B94))
        "mastercard" -> listOf(Color(0xFF333333), Color(0xFF1A1A1A))
        "amex" -> listOf(Color(0xFF007BC1), Color(0xFF00A2E0))
        else -> listOf(Color(0xFF555555), Color(0xFF2B2B2B))
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .drawBehind {
                drawRect(
                    brush = Brush.linearGradient(
                        colors = cardColors,
                        start = Offset(0f, 0f),
                        end = Offset(size.width, size.height)
                    )
                )
            }
            .padding(16.dp)
            .testTag("bank_card_${card.id}")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = card.brand.uppercase(),
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Icon(
                    imageVector = Icons.Default.CreditCard,
                    contentDescription = "Bank Card",
                    tint = Color.White.copy(alpha = 0.7f)
                )
            }

            Column {
                Text(
                    text = "•••• •••• •••• ${card.lastFour}",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = card.cardholderName.uppercase(),
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp
                    )
                    Text(
                        text = "${card.expiryMonth}/${card.expiryYear}",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = title.uppercase(),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        letterSpacing = 1.5.sp,
        modifier = modifier.padding(vertical = 8.dp)
    )
}
