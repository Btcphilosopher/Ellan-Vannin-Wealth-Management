package com.example.data.repositories

import com.example.data.local.*
import com.example.domain.model.*
import com.example.domain.repository.MetroRepository
import kotlinx.coroutines.flow.Flow

class MetroRepositoryImpl(private val db: MetroDatabase) : MetroRepository {
    private val cardDao = db.transitCardDao()
    private val bankDao = db.bankCardDao()
    private val tapDao = db.tapEventDao()
    private val journeyDao = db.transitJourneyDao()
    private val txDao = db.paymentTransactionDao()
    private val disputeDao = db.disputeDao()
    private val notificationDao = db.notificationDao()

    override fun getTransitCardsFlow(): Flow<List<TransitCard>> = cardDao.getAllCardsFlow()
    override suspend fun getAllTransitCards(): List<TransitCard> = cardDao.getAllCards()
    override suspend fun getTransitCardById(id: String): TransitCard? = cardDao.getCardById(id)
    override suspend fun saveTransitCard(card: TransitCard) = cardDao.insertCard(card)
    override suspend fun deleteTransitCard(card: TransitCard) = cardDao.deleteCard(card)
    override suspend fun updateCardBalance(id: String, balance: Double) = cardDao.updateBalance(id, balance)
    override suspend fun updateCardStatus(id: String, status: String) = cardDao.updateStatus(id, status)

    override fun getBankCardsFlow(): Flow<List<BankCardReference>> = bankDao.getAllBankCardsFlow()
    override suspend fun getAllBankCards(): List<BankCardReference> = bankDao.getAllBankCards()
    override suspend fun getBankCardById(id: String): BankCardReference? = bankDao.getBankCardById(id)
    override suspend fun saveBankCard(bankCard: BankCardReference) = bankDao.insertBankCard(bankCard)
    override suspend fun deleteBankCard(bankCard: BankCardReference) = bankDao.deleteBankCard(bankCard)

    override fun getTapEventsFlow(): Flow<List<TapEvent>> = tapDao.getAllTapEventsFlow()
    override suspend fun getTapEventById(id: String): TapEvent? = tapDao.getTapEventById(id)
    override suspend fun getTapEventsForCredential(credentialId: String): List<TapEvent> = tapDao.getTapEventsForCredential(credentialId)
    override suspend fun saveTapEvent(event: TapEvent) = tapDao.insertTapEvent(event)

    override fun getJourneysFlow(): Flow<List<TransitJourney>> = journeyDao.getAllJourneysFlow()
    override suspend fun getJourneyById(id: String): TransitJourney? = journeyDao.getJourneyById(id)
    override suspend fun getActiveJourney(): TransitJourney? = journeyDao.getActiveJourney()
    override suspend fun getJourneysForCredential(credentialId: String): List<TransitJourney> = journeyDao.getJourneysForCredential(credentialId)
    override suspend fun saveJourney(journey: TransitJourney) = journeyDao.insertJourney(journey)

    override fun getTransactionsFlow(): Flow<List<PaymentTransaction>> = txDao.getAllTransactionsFlow()
    override suspend fun getTransactionById(id: String): PaymentTransaction? = txDao.getTransactionById(id)
    override suspend fun saveTransaction(transaction: PaymentTransaction) = txDao.insertTransaction(transaction)

    override fun getDisputesFlow(): Flow<List<Dispute>> = disputeDao.getAllDisputesFlow()
    override suspend fun getDisputeById(id: String): Dispute? = disputeDao.getDisputeById(id)
    override suspend fun saveDispute(dispute: Dispute) = disputeDao.insertDispute(dispute)

    override fun getNotificationsFlow(): Flow<List<Notification>> = notificationDao.getAllNotificationsFlow()
    override suspend fun saveNotification(notification: Notification) = notificationDao.insertNotification(notification)
    override suspend fun markAllNotificationsAsRead() = notificationDao.markAllAsRead()
}
