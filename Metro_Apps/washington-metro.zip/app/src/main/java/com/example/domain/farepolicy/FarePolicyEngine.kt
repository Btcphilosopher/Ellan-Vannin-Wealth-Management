package com.example.domain.farepolicy

data class FarePolicyConfig(
    val policyName: String = "Demo Fare Policy",
    val currency: String = "USD",
    val calculationMode: String = "CONFIGURABLE",
    val minimumFare: Double = 2.00,
    val maximumFare: Double = 8.00,
    val baseRate: Double = 1.25,
    val peakMultiplier: Double = 1.35,
    val offPeakMultiplier: Double = 1.00,
    val incompleteJourneyHandling: String = "REVIEW_REQUIRED",
    val policyVersion: String = "v1"
)

data class FareResult(
    val baseFare: Double,
    val adjustment: Double,
    val finalFare: Double,
    val explanation: String,
    val policyName: String,
    val policyVersion: String
)

class FarePolicyEngine(private var config: FarePolicyConfig = FarePolicyConfig()) {

    fun updateConfig(newConfig: FarePolicyConfig) {
        config = newConfig
    }

    fun getConfig(): FarePolicyConfig = config

    fun calculateFare(
        entryCode: String,
        exitCode: String,
        isPeak: Boolean = false,
        specialCategory: String? = null
    ): FareResult {
        if (entryCode == exitCode) {
            // Same station entry/exit usually charged minimum fare as a stay penalty
            val fare = config.minimumFare
            return FareResult(
                baseFare = fare,
                adjustment = 0.0,
                finalFare = fare,
                explanation = "Same-station entry and exit stay fee.",
                policyName = config.policyName,
                policyVersion = config.policyVersion
            )
        }

        val distance = StationData.getDistance(entryCode, exitCode)
        val rawFare = config.minimumFare + (distance * config.baseRate)
        val multiplier = if (isPeak) config.peakMultiplier else config.offPeakMultiplier
        var finalFare = rawFare * multiplier

        // Apply policy caps
        if (finalFare > config.maximumFare) {
            finalFare = config.maximumFare
        } else if (finalFare < config.minimumFare) {
            finalFare = config.minimumFare
        }

        // Round to 2 decimal places
        finalFare = Math.round(finalFare * 100.0) / 100.0

        var explanation = "Base distance fare ($${String.format("%.2f", distance)} units)."
        var adjustment = 0.0

        if (isPeak) {
            explanation += " Peak hours multiplier (${config.peakMultiplier}x) applied."
        }

        if (specialCategory == "Senior") {
            val discount = finalFare * 0.5
            finalFare -= discount
            adjustment = -discount
            explanation += " Senior discount (50%) applied."
        }

        // Re-apply minimum check after adjustment
        if (finalFare < config.minimumFare) {
            finalFare = config.minimumFare
        }
        finalFare = Math.round(finalFare * 100.0) / 100.0

        return FareResult(
            baseFare = Math.round(rawFare * multiplier * 100.0) / 100.0,
            adjustment = adjustment,
            finalFare = finalFare,
            explanation = explanation,
            policyName = config.policyName,
            policyVersion = config.policyVersion
        )
    }

    fun calculateProvisionalFare(): Double {
        return config.minimumFare
    }

    fun getIncompleteJourneyPenalty(): Double {
        return config.maximumFare
    }
}
