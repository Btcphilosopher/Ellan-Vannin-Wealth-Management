package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.domain.model.*

@Database(
    entities = [
        TransitCard::class,
        BankCardReference::class,
        TapEvent::class,
        TransitJourney::class,
        PaymentTransaction::class,
        Dispute::class,
        Notification::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MetroDatabase : RoomDatabase() {
    abstract fun transitCardDao(): TransitCardDao
    abstract fun bankCardDao(): BankCardDao
    abstract fun tapEventDao(): TapEventDao
    abstract fun transitJourneyDao(): TransitJourneyDao
    abstract fun paymentTransactionDao(): PaymentTransactionDao
    abstract fun disputeDao(): DisputeDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: MetroDatabase? = null

        fun getDatabase(context: Context): MetroDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MetroDatabase::class.java,
                    "metro_fare_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
