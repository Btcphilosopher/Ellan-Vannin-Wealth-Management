package com.example.domain.repository

import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow

interface MetroRepository {
    // Transit Card
    fun getTransitCardsFlow(): Flow<List<TransitCard>>
    suspend fun getAllTransitCards(): List<TransitCard>
    suspend fun getTransitCardById(id: String): TransitCard?
    suspend fun saveTransitCard(card: TransitCard)
    suspend fun deleteTransitCard(card: TransitCard)
    suspend fun updateCardBalance(id: String, balance: Double)
    suspend fun updateCardStatus(id: String, status: String)

    // Bank Card
    fun getBankCardsFlow(): Flow<List<BankCardReference>>
    suspend fun getAllBankCards(): List<BankCardReference>
    suspend fun getBankCardById(id: String): BankCardReference?
    suspend fun saveBankCard(bankCard: BankCardReference)
    suspend fun deleteBankCard(bankCard: BankCardReference)

    // Tap Event
    fun getTapEventsFlow(): Flow<List<TapEvent>>
    suspend fun getTapEventById(id: String): TapEvent?
    suspend fun getTapEventsForCredential(credentialId: String): List<TapEvent>
    suspend fun saveTapEvent(event: TapEvent)

    // Transit Journey
    fun getJourneysFlow(): Flow<List<TransitJourney>>
    suspend fun getJourneyById(id: String): TransitJourney?
    suspend fun getActiveJourney(): TransitJourney?
    suspend fun getJourneysForCredential(credentialId: String): List<TransitJourney>
    suspend fun saveJourney(journey: TransitJourney)

    // Payment Transaction
    fun getTransactionsFlow(): Flow<List<PaymentTransaction>>
    suspend fun getTransactionById(id: String): PaymentTransaction?
    suspend fun saveTransaction(transaction: PaymentTransaction)

    // Dispute
    fun getDisputesFlow(): Flow<List<Dispute>>
    suspend fun getDisputeById(id: String): Dispute?
    suspend fun saveDispute(dispute: Dispute)

    // Notification
    fun getNotificationsFlow(): Flow<List<Notification>>
    suspend fun saveNotification(notification: Notification)
    suspend fun markAllNotificationsAsRead()
}
