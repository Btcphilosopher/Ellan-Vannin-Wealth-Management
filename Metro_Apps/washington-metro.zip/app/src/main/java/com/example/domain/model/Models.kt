package com.example.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transit_cards")
data class TransitCard(
    @PrimaryKey val id: String,
    val nickname: String,
    val cardNumber: String, // Masked like •••• 4821
    val balance: Double,
    val status: String, // Ready, LowBalance, Suspended, Blocked, Expired, Removed
    val autoReload: Boolean,
    val autoReloadAmount: Double,
    val autoReloadThreshold: Double,
    val cardType: String, // Physical, Virtual, Demo
    val isDefault: Boolean
)

@Entity(tableName = "bank_cards")
data class BankCardReference(
    @PrimaryKey val id: String,
    val brand: String, // Visa, Mastercard, Amex, Discover
    val lastFour: String,
    val cardholderName: String,
    val expiryMonth: String,
    val expiryYear: String,
    val isDefault: Boolean,
    val isAutoReloadDefault: Boolean
)

@Entity(tableName = "tap_events")
data class TapEvent(
    @PrimaryKey val id: String,
    val stationId: String,
    val gateId: String,
    val timestamp: Long,
    val credentialType: String, // SmartCard, BankCard
    val credentialId: String,
    val tapType: String, // ENTRY, EXIT
    val result: String, // SUCCESS, DECLINED, DUPLICATE, INVALID
    val provisionalFare: Double,
    val syncState: String, // LOCAL_ONLY, QUEUED, SYNCHRONISING, SYNCED, CONFLICT, FAILED, REQUIRES_REVIEW
    val idempotencyKey: String
)

@Entity(tableName = "transit_journeys")
data class TransitJourney(
    @PrimaryKey val id: String,
    val entryStationId: String,
    val entryTime: Long,
    val exitStationId: String?,
    val exitTime: Long?,
    val credentialType: String, // SmartCard, BankCard
    val credentialId: String,
    val baseFare: Double,
    val adjustment: Double,
    val finalFare: Double,
    val status: String, // Active, Completed, Incomplete, Resolved
    val transactionRef: String
)

@Entity(tableName = "payment_transactions")
data class PaymentTransaction(
    @PrimaryKey val id: String,
    val journeyId: String?,
    val amount: Double,
    val currency: String, // USD
    val paymentMethodId: String,
    val paymentMethodType: String, // BankCard, SmartCardBalance
    val status: String, // Created, Pending, Authorised, Captured, Declined, Reversed, Refunded
    val timestamp: Long,
    val providerReference: String,
    val authCode: String,
    val reconciliationState: String // Unreconciled, Reconciled
)

@Entity(tableName = "disputes")
data class Dispute(
    @PrimaryKey val id: String,
    val journeyId: String,
    val issueType: String, // MissingTapOut, DuplicateTap, IncorrectFare, WrongStation, DeclinedPayment
    val explanation: String,
    val note: String,
    val status: String, // Open, Submitted, UnderReview, AdditionalInfoRequired, Approved, Rejected, Resolved
    val submittedAt: Long
)

@Entity(tableName = "notifications")
data class Notification(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val timestamp: Long,
    val relatedId: String?,
    val type: String, // TAP_IN, TAP_OUT, FARE_CALCULATED, PAYMENT, LOW_BALANCE, AUTO_RELOAD, DISPUTE, OTHER
    val isRead: Boolean
)

data class Station(
    val code: String,
    val name: String,
    val lines: List<String>,
    val status: String // Active, UnderMaintenance
)

data class Gate(
    val id: String,
    val stationCode: String,
    val direction: String, // ENTRY, EXIT, BI_DIRECTIONAL
    val status: String // Open, OutOfService
)
