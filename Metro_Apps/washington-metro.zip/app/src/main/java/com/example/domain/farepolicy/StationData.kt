package com.example.domain.farepolicy

import com.example.domain.model.Station
import com.example.domain.model.Gate

object StationData {
    val STATIONS = listOf(
        Station("MET", "Metro Center", listOf("Red", "Orange", "Blue", "Silver"), "Active"),
        Station("GAL", "Gallery Place", listOf("Red", "Green", "Yellow"), "Active"),
        Station("LEN", "L’Enfant Plaza", listOf("Orange", "Blue", "Silver", "Green", "Yellow"), "Active"),
        Station("UNI", "Union Station", listOf("Red"), "Active"),
        Station("ROS", "Rosslyn", listOf("Orange", "Blue", "Silver"), "Active"),
        Station("PEN", "Pentagon", listOf("Blue", "Yellow"), "Active"),
        Station("DUP", "Dupont Circle", listOf("Red"), "Active"),
        Station("BET", "Bethesda", listOf("Red"), "Active"),
        Station("SIL", "Silver Spring", listOf("Red"), "Active"),
        Station("DCA", "Reagan National Airport", listOf("Blue", "Yellow"), "Active")
    )

    // Simplified distances (in generic units or zones) from Metro Center
    // to allow a realistic fare calculation based on station distance
    private val stationCoordinates = mapOf(
        "MET" to Pair(0.0, 0.0),    // Metro Center - Central
        "GAL" to Pair(0.5, 0.2),    // Gallery Place - very close
        "LEN" to Pair(0.8, -1.0),   // L'Enfant Plaza - close south
        "UNI" to Pair(1.5, 1.0),    // Union Station - east/north
        "ROS" to Pair(-2.5, -0.5),  // Rosslyn - west across river
        "PEN" to Pair(-2.8, -2.5),  // Pentagon - south-west
        "DUP" to Pair(-1.2, 1.5),   // Dupont Circle - north-west
        "BET" to Pair(-4.5, 5.0),   // Bethesda - far north-west
        "SIL" to Pair(1.0, 6.5),    // Silver Spring - far north
        "DCA" to Pair(-2.5, -4.5)   // National Airport - far south
    )

    fun getDistance(fromCode: String, toCode: String): Double {
        val p1 = stationCoordinates[fromCode] ?: Pair(0.0, 0.0)
        val p2 = stationCoordinates[toCode] ?: Pair(0.0, 0.0)
        return java.lang.Math.sqrt(
            java.lang.Math.pow(p1.first - p2.first, 2.0) +
            java.lang.Math.pow(p1.second - p2.second, 2.0)
        )
    }

    fun getGatesForStation(stationCode: String): List<Gate> {
        return listOf(
            Gate("${stationCode}-G01", stationCode, "BI_DIRECTIONAL", "Open"),
            Gate("${stationCode}-G02", stationCode, "BI_DIRECTIONAL", "Open"),
            Gate("${stationCode}-G03", stationCode, "BI_DIRECTIONAL", "Open")
        )
    }
}
