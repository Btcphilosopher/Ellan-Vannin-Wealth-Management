package com.example.features

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.MetroDatabase
import com.example.data.repositories.MetroRepositoryImpl
import com.example.domain.farepolicy.*
import com.example.domain.model.*
import com.example.domain.repository.MetroRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

sealed class TapResultState {
    object Idle : TapResultState()
    object Processing : TapResultState()
    data class Success(
        val stationName: String,
        val timeLabel: String,
        val cardLabel: String,
        val currentBalanceOrStatus: String,
        val textDetail: String
    ) : TapResultState()
    data class Failure(
        val errorTitle: String,
        val errorMessage: String
    ) : TapResultState()
}

class MetroViewModel(
    application: Application,
    private val repository: MetroRepository
) : AndroidViewModel(application) {

    // Global States from DB
    val transitCards = repository.getTransitCardsFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val bankCards = repository.getBankCardsFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val tapEvents = repository.getTapEventsFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val journeys = repository.getJourneysFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val transactions = repository.getTransactionsFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val disputes = repository.getDisputesFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val notifications = repository.getNotificationsFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Active Journey derived from database journeys
    val activeJourney = journeys.map { list ->
        list.firstOrNull { it.status == "Active" }
    }.stateIn(viewModelScope, SharingStarted.Lazily, null)

    // Simulation UI / Control States
    private val _isOnline = MutableStateFlow(true)
    val isOnline = _isOnline.asStateFlow()

    private val _simulationTime = MutableStateFlow(System.currentTimeMillis())
    val simulationTime = _simulationTime.asStateFlow()

    private val _selectedCardId = MutableStateFlow<String?>(null)
    val selectedCardId = _selectedCardId.asStateFlow()

    private val _selectedStationCode = MutableStateFlow("MET")
    val selectedStationCode = _selectedStationCode.asStateFlow()

    private val _selectedGateId = MutableStateFlow("MET-G01")
    val selectedGateId = _selectedGateId.asStateFlow()

    private val _selectedDirection = MutableStateFlow("ENTRY") // ENTRY or EXIT
    val selectedDirection = _selectedDirection.asStateFlow()

    private val _tapResult = MutableStateFlow<TapResultState>(TapResultState.Idle)
    val tapResult = _tapResult.asStateFlow()

    private val _isSimulating = MutableStateFlow(false)
    val isSimulating = _isSimulating.asStateFlow()

    // Configurable Fare Policy Engine
    private val farePolicyEngine = FarePolicyEngine()
    private val _fareConfig = MutableStateFlow(farePolicyEngine.getConfig())
    val fareConfig = _fareConfig.asStateFlow()

    // Preferences / Accessibility UI preferences
    private val _highContrastMode = MutableStateFlow(false)
    val highContrastMode = _highContrastMode.asStateFlow()

    private val _largeTextMode = MutableStateFlow(false)
    val largeTextMode = _largeTextMode.asStateFlow()

    private val _reducedMotionMode = MutableStateFlow(false)
    val reducedMotionMode = _reducedMotionMode.asStateFlow()

    // Onboarding completed (requires at least one smart card or bank card)
    val isOnboardingCompleted = combine(transitCards, bankCards) { cards, banks ->
        cards.isNotEmpty() || banks.isNotEmpty()
    }.stateIn(viewModelScope, SharingStarted.Lazily, false)

    init {
        // Seed default demo data if DB is empty
        seedDefaultData()
    }

    private fun seedDefaultData() {
        viewModelScope.launch {
            val existingCards = repository.getAllTransitCards()
            if (existingCards.isEmpty()) {
                // Seed a premium demo transit card
                val demoCard = TransitCard(
                    id = "CARD_WMATA_4821",
                    nickname = "Primary Smart Card",
                    cardNumber = "•••• 4821",
                    balance = 42.75,
                    status = "Ready",
                    autoReload = true,
                    autoReloadAmount = 20.00,
                    autoReloadThreshold = 10.00,
                    cardType = "Virtual",
                    isDefault = true
                )
                repository.saveTransitCard(demoCard)
                _selectedCardId.value = demoCard.id

                // Seed a demo bank card used for auto-reloads
                val demoBankCard = BankCardReference(
                    id = "BANK_VISA_1842",
                    brand = "Visa",
                    lastFour = "1842",
                    cardholderName = "Jane Doe",
                    expiryMonth = "12",
                    expiryYear = "2029",
                    isDefault = true,
                    isAutoReloadDefault = true
                )
                repository.saveBankCard(demoBankCard)

                // Add an initial notification
                repository.saveNotification(
                    Notification(
                        id = UUID.randomUUID().toString(),
                        title = "Welcome to Washington Metro Smart Fare",
                        message = "Your virtual Smart Card (•••• 4821) has been active and pre-funded with $42.75.",
                        timestamp = System.currentTimeMillis(),
                        relatedId = null,
                        type = "OTHER",
                        isRead = false
                    )
                )
            } else {
                _selectedCardId.value = existingCards.firstOrNull()?.id
            }
        }
    }

    fun setSelectedCard(cardId: String) {
        _selectedCardId.value = cardId
    }

    fun setSelectedStation(code: String) {
        _selectedStationCode.value = code
        _selectedGateId.value = "${code}-G01"
    }

    fun setSelectedGate(gateId: String) {
        _selectedGateId.value = gateId
    }

    fun setSelectedDirection(direction: String) {
        _selectedDirection.value = direction
    }

    fun toggleOnlineMode() {
        _isOnline.value = !_isOnline.value
        if (_isOnline.value) {
            // Trigger auto synchronization of offline queued events
            syncOfflineEvents()
        }
    }

    fun advanceTime(minutes: Long) {
        _simulationTime.value += minutes * 60 * 1000
    }

    fun updateFareConfig(
        policyName: String,
        minFare: Double,
        maxFare: Double,
        baseRate: Double
    ) {
        val newConfig = FarePolicyConfig(
            policyName = policyName,
            minimumFare = minFare,
            maximumFare = maxFare,
            baseRate = baseRate
        )
        farePolicyEngine.updateConfig(newConfig)
        _fareConfig.value = newConfig
    }

    fun toggleHighContrast() { _highContrastMode.value = !_highContrastMode.value }
    fun toggleLargeText() { _largeTextMode.value = !_largeTextMode.value }
    fun toggleReducedMotion() { _reducedMotionMode.value = !_reducedMotionMode.value }

    // --- CARDS ---

    fun addDemoTransitCard(nickname: String, initialBalance: Double, isPhysical: Boolean) {
        viewModelScope.launch {
            val randomFour = (1000..9999).random().toString()
            val newCard = TransitCard(
                id = "CARD_WMATA_$randomFour",
                nickname = nickname.ifEmpty { if (isPhysical) "Physical Smart Card" else "Virtual Transit Card" },
                cardNumber = "•••• $randomFour",
                balance = initialBalance,
                status = "Ready",
                autoReload = false,
                autoReloadAmount = 20.00,
                autoReloadThreshold = 5.00,
                cardType = if (isPhysical) "Physical" else "Virtual",
                isDefault = false
            )
            repository.saveTransitCard(newCard)
            if (_selectedCardId.value == null) {
                _selectedCardId.value = newCard.id
            }
            sendNotification(
                title = "Card Added Successfully",
                message = "${newCard.nickname} (${newCard.cardNumber}) has been added.",
                type = "OTHER",
                relatedId = newCard.id
            )
        }
    }

    fun toggleCardFreeze(cardId: String) {
        viewModelScope.launch {
            val card = repository.getTransitCardById(cardId) ?: return@launch
            val newStatus = if (card.status == "Suspended" || card.status == "Blocked") "Ready" else "Suspended"
            repository.updateCardStatus(cardId, newStatus)
            sendNotification(
                title = if (newStatus == "Suspended") "Card Suspended" else "Card Activated",
                message = "${card.nickname} is now ${if (newStatus == "Suspended") "frozen" else "active"}.",
                type = "OTHER",
                relatedId = card.id
            )
        }
    }

    fun removeTransitCard(cardId: String) {
        viewModelScope.launch {
            val card = repository.getTransitCardById(cardId) ?: return@launch
            // Check if there is an active journey depending on it
            val active = activeJourney.value
            if (active != null && active.credentialId == cardId) {
                sendNotification(
                    title = "Cannot Remove Card",
                    message = "Please complete or resolve your active journey before removing this card.",
                    type = "OTHER",
                    relatedId = cardId
                )
                return@launch
            }
            repository.deleteTransitCard(card)
            if (_selectedCardId.value == cardId) {
                val remaining = repository.getAllTransitCards()
                _selectedCardId.value = remaining.firstOrNull()?.id
            }
            sendNotification(
                title = "Card Removed",
                message = "${card.nickname} (${card.cardNumber}) has been unlinked.",
                type = "OTHER",
                relatedId = null
            )
        }
    }

    fun replaceCardRecord(cardId: String) {
        viewModelScope.launch {
            val card = repository.getTransitCardById(cardId) ?: return@launch
            // Simulate replacing lost physical card with a new virtual one
            val randomFour = (1000..9999).random().toString()
            val replacedCard = card.copy(
                id = "CARD_WMATA_$randomFour",
                nickname = "Replacement for ${card.nickname}",
                cardNumber = "•••• $randomFour",
                cardType = "Virtual",
                status = "Ready"
            )
            repository.deleteTransitCard(card)
            repository.saveTransitCard(replacedCard)
            _selectedCardId.value = replacedCard.id

            sendNotification(
                title = "Card Replaced",
                message = "Your lost card has been replaced with virtual Card ${replacedCard.cardNumber}. Balance of $${String.format("%.2f", card.balance)} transferred.",
                type = "OTHER",
                relatedId = replacedCard.id
            )
        }
    }

    // --- BANK CARDS ---

    fun attachDemoBankCard(
        brand: String,
        cardNumberInput: String,
        cardholderName: String,
        expiryMonth: String,
        expiryYear: String
    ): Boolean {
        // Simple Luhn validation for simulation
        val digits = cardNumberInput.replace(" ", "")
        if (digits.length < 13 || digits.length > 19 || !digits.all { it.isDigit() }) {
            return false
        }

        val lastFour = digits.takeLast(4)
        val id = "BANK_${brand.uppercase()}_$lastFour"

        viewModelScope.launch {
            val newBankCard = BankCardReference(
                id = id,
                brand = brand,
                lastFour = lastFour,
                cardholderName = cardholderName.ifEmpty { "Card Holder" },
                expiryMonth = expiryMonth,
                expiryYear = expiryYear,
                isDefault = repository.getAllBankCards().isEmpty(),
                isAutoReloadDefault = repository.getAllBankCards().isEmpty()
            )
            repository.saveBankCard(newBankCard)
            sendNotification(
                title = "Bank Card Attached",
                message = "Demo $brand card ending in $lastFour added as payment credential.",
                type = "OTHER",
                relatedId = id
            )
        }
        return true
    }

    fun removeBankCard(bankCardId: String) {
        viewModelScope.launch {
            val card = repository.getBankCardById(bankCardId) ?: return@launch
            repository.deleteBankCard(card)
            sendNotification(
                title = "Payment Method Removed",
                message = "Card ending in ${card.lastFour} has been deleted.",
                type = "OTHER",
                relatedId = null
            )
        }
    }

    fun setBankCardAsDefault(bankCardId: String) {
        viewModelScope.launch {
            val cards = repository.getAllBankCards()
            cards.forEach {
                repository.saveBankCard(it.copy(
                    isDefault = it.id == bankCardId,
                    isAutoReloadDefault = if (it.id == bankCardId) true else it.isAutoReloadDefault
                ))
            }
        }
    }

    // --- RECHARGES ---

    fun addDemoFunds(cardId: String, amount: Double, paymentMethodId: String) {
        viewModelScope.launch {
            val card = repository.getTransitCardById(cardId) ?: return@launch
            val newBalance = card.balance + amount
            repository.updateCardBalance(cardId, newBalance)

            // Log Transaction
            val txId = "TX_DEP_" + UUID.randomUUID().toString().take(8).uppercase()
            val transaction = PaymentTransaction(
                id = txId,
                journeyId = null,
                amount = amount,
                currency = "USD",
                paymentMethodId = paymentMethodId,
                paymentMethodType = "BankCard",
                status = "Captured",
                timestamp = _simulationTime.value,
                providerReference = "WMATA_RELOAD_MOCK_AUTH_" + (100000..999999).random(),
                authCode = (1000..9999).random().toString(),
                reconciliationState = "Reconciled"
            )
            repository.saveTransaction(transaction)

            // Log Notification
            sendNotification(
                title = "Funds Added Successfully",
                message = "Added $${String.format("%.2f", amount)} to ${card.nickname}. New balance: $${String.format("%.2f", newBalance)}.",
                type = "PAYMENT",
                relatedId = cardId
            )
        }
    }

    fun configureAutoReload(cardId: String, amount: Double, threshold: Double, enabled: Boolean) {
        viewModelScope.launch {
            val card = repository.getTransitCardById(cardId) ?: return@launch
            val updated = card.copy(
                autoReload = enabled,
                autoReloadAmount = amount,
                autoReloadThreshold = threshold
            )
            repository.saveTransitCard(updated)
            sendNotification(
                title = "Auto-Reload " + if (enabled) "Configured" else "Disabled",
                message = "${card.nickname} will now automatically reload $${String.format("%.2f", amount)} when below $${String.format("%.2f", threshold)}.",
                type = "AUTO_RELOAD",
                relatedId = cardId
            )
        }
    }

    // --- TAP STATE MACHINE & SIMULATION ---

    fun performSimulatedTap() {
        _tapResult.value = TapResultState.Processing
        val isEntry = _selectedDirection.value == "ENTRY"

        viewModelScope.launch {
            val online = _isOnline.value
            val time = _simulationTime.value
            val cardId = _selectedCardId.value
            val stationCode = _selectedStationCode.value
            val gateId = _selectedGateId.value

            val station = StationData.STATIONS.firstOrNull { it.code == stationCode }
                ?: StationData.STATIONS.first()

            if (cardId == null) {
                _tapResult.value = TapResultState.Failure("Unrecognised Card", "Please select a valid payment or smart card credential to tap.")
                return@launch
            }

            // Verify physical/virtual smart card details
            val card = repository.getTransitCardById(cardId)
            if (card == null) {
                _tapResult.value = TapResultState.Failure("Unrecognised Card", "The tapped smart card credential was not found.")
                return@launch
            }

            // Tap state rules
            if (card.status == "Suspended" || card.status == "Blocked") {
                _tapResult.value = TapResultState.Failure("Card Blocked", "This card has been frozen or blocked. Tap denied.")
                saveAuditAndNotification(
                    title = "Tap Denied: Card Suspended",
                    message = "Suspended Card ${card.cardNumber} attempted entry at ${station.name}.",
                    type = "TAP_IN",
                    cardId = cardId
                )
                return@launch
            }

            // Check Duplicate Tap (Same station, same card, within 30 seconds)
            val recentTaps = repository.getTapEventsForCredential(cardId)
            val duplicate = recentTaps.firstOrNull {
                it.stationId == stationCode && Math.abs(time - it.timestamp) < 30 * 1000
            }
            if (duplicate != null) {
                _tapResult.value = TapResultState.Failure("Duplicate Tap Detected", "A tap event for Card ${card.cardNumber} was already registered at this gate.")
                return@launch
            }

            if (isEntry) {
                // TAP IN
                val minFare = farePolicyEngine.calculateProvisionalFare()
                if (card.balance < minFare) {
                    _tapResult.value = TapResultState.Failure("Insufficient Balance", "Your Smart Card balance ($${String.format("%.2f", card.balance)}) is too low for entry. Minimum required is $${String.format("%.2f", minFare)}.")
                    saveAuditAndNotification(
                        title = "Tap Denied: Low Balance",
                        message = "Insufficient balance on Card ${card.cardNumber} at ${station.name}.",
                        type = "TAP_IN",
                        cardId = cardId
                    )
                    return@launch
                }

                // Check active journey mismatch
                val active = repository.getActiveJourney()
                if (active != null && active.credentialId == cardId) {
                    // Force complete previous journey as Incomplete before starting new one
                    val penalty = farePolicyEngine.getIncompleteJourneyPenalty()
                    val closedJourney = active.copy(
                        exitStationId = "UNK", // Unknown exit
                        exitTime = time,
                        finalFare = penalty,
                        status = "Incomplete",
                        adjustment = 0.0
                    )
                    repository.saveJourney(closedJourney)

                    val newBalance = Math.max(0.0, card.balance - penalty)
                    repository.updateCardBalance(cardId, newBalance)

                    sendNotification(
                        title = "Incomplete Journey Penalised",
                        message = "Previous journey was not closed. Maximum fare penalty of $${String.format("%.2f", penalty)} deducted from Card ${card.cardNumber}.",
                        type = "LOW_BALANCE",
                        relatedId = closedJourney.id
                    )

                    // Trigger Auto reload if balance went below threshold
                    triggerAutoReloadIfNeeded(cardId, newBalance)
                }

                // Create Tap Event
                val event = TapEvent(
                    id = UUID.randomUUID().toString(),
                    stationId = stationCode,
                    gateId = gateId,
                    timestamp = time,
                    credentialType = "SmartCard",
                    credentialId = cardId,
                    tapType = "ENTRY",
                    result = "SUCCESS",
                    provisionalFare = minFare,
                    syncState = if (online) "SYNCED" else "LOCAL_ONLY",
                    idempotencyKey = UUID.randomUUID().toString()
                )
                repository.saveTapEvent(event)

                // Create Journey
                val journeyId = "JRN_" + UUID.randomUUID().toString().take(8).uppercase()
                val journey = TransitJourney(
                    id = journeyId,
                    entryStationId = stationCode,
                    entryTime = time,
                    exitStationId = null,
                    exitTime = null,
                    credentialType = "SmartCard",
                    credentialId = cardId,
                    baseFare = minFare,
                    adjustment = 0.0,
                    finalFare = 0.0,
                    status = "Active",
                    transactionRef = "TX_PENDING"
                )
                repository.saveJourney(journey)

                _tapResult.value = TapResultState.Success(
                    stationName = station.name,
                    timeLabel = "Today, " + formatTime(time),
                    cardLabel = "${card.nickname} (${card.cardNumber})",
                    currentBalanceOrStatus = "Balance: $" + String.format("%.2f", card.balance),
                    textDetail = if (online) "Tap successful. Entry recorded." else "Tap recorded locally. Synchronisation pending."
                )

                saveAuditAndNotification(
                    title = "Tap-In Recorded",
                    message = "Successfully entered at ${station.name} with Card ${card.cardNumber}.",
                    type = "TAP_IN",
                    cardId = cardId
                )

            } else {
                // TAP OUT
                val active = repository.getActiveJourney()
                if (active == null || active.credentialId != cardId) {
                    _tapResult.value = TapResultState.Failure(
                        "Tap-Out Mismatch",
                        "No corresponding tap-in was found for this credential. Tap-out denied."
                    )
                    return@launch
                }

                // Calculate fare
                val fareRes = farePolicyEngine.calculateFare(active.entryStationId, stationCode)
                val finalCharge = fareRes.finalFare

                // Check balance logic (even on tap out, if fare exceeds balance we transition to declinement/unpaid)
                if (card.balance < finalCharge) {
                    _tapResult.value = TapResultState.Failure(
                        "Insufficient Balance to Exit",
                        "Calculated fare is $${String.format("%.2f", finalCharge)}, but balance is only $${String.format("%.2f", card.balance)}. Please reload."
                    )
                    saveAuditAndNotification(
                        title = "Tap-Out Declined",
                        message = "Insufficient funds for exit fare of $${String.format("%.2f", finalCharge)} at ${station.name}.",
                        type = "TAP_OUT",
                        cardId = cardId
                    )
                    return@launch
                }

                // Create Tap Event
                val event = TapEvent(
                    id = UUID.randomUUID().toString(),
                    stationId = stationCode,
                    gateId = gateId,
                    timestamp = time,
                    credentialType = "SmartCard",
                    credentialId = cardId,
                    tapType = "EXIT",
                    result = "SUCCESS",
                    provisionalFare = 0.0,
                    syncState = if (online) "SYNCED" else "LOCAL_ONLY",
                    idempotencyKey = UUID.randomUUID().toString()
                )
                repository.saveTapEvent(event)

                // Update Journey
                val updatedJourney = active.copy(
                    exitStationId = stationCode,
                    exitTime = time,
                    baseFare = fareRes.baseFare,
                    adjustment = fareRes.adjustment,
                    finalFare = finalCharge,
                    status = "Completed",
                    transactionRef = "TX_" + UUID.randomUUID().toString().take(8).uppercase()
                )
                repository.saveJourney(updatedJourney)

                // Deduct Balance
                val newBalance = card.balance - finalCharge
                repository.updateCardBalance(cardId, newBalance)

                // Log Payment Transaction
                val transaction = PaymentTransaction(
                    id = updatedJourney.transactionRef,
                    journeyId = updatedJourney.id,
                    amount = finalCharge,
                    currency = "USD",
                    paymentMethodId = cardId,
                    paymentMethodType = "SmartCardBalance",
                    status = "Captured",
                    timestamp = time,
                    providerReference = "WMATA_FARE_MOCK_AUTH_" + (100000..999999).random(),
                    authCode = (1000..9999).random().toString(),
                    reconciliationState = "Reconciled"
                )
                repository.saveTransaction(transaction)

                _tapResult.value = TapResultState.Success(
                    stationName = station.name,
                    timeLabel = "Today, " + formatTime(time),
                    cardLabel = "${card.nickname} (${card.cardNumber})",
                    currentBalanceOrStatus = "Balance: $" + String.format("%.2f", newBalance),
                    textDetail = "Exit recorded. Fare: $" + String.format("%.2f", finalCharge) + " (${fareRes.explanation})"
                )

                saveAuditAndNotification(
                    title = "Tap-Out Recorded",
                    message = "Exited at ${station.name}. Charged $${String.format("%.2f", finalCharge)}.",
                    type = "TAP_OUT",
                    cardId = cardId
                )

                // Trigger Auto reload check
                triggerAutoReloadIfNeeded(cardId, newBalance)
            }
        }
    }

    private fun triggerAutoReloadIfNeeded(cardId: String, currentBalance: Double) {
        viewModelScope.launch {
            val card = repository.getTransitCardById(cardId) ?: return@launch
            if (card.autoReload && currentBalance < card.autoReloadThreshold) {
                val newBalance = currentBalance + card.autoReloadAmount
                repository.updateCardBalance(cardId, newBalance)

                // Find default auto-reload bank card
                val bankCards = repository.getAllBankCards()
                val bankCard = bankCards.firstOrNull { it.isAutoReloadDefault } ?: bankCards.firstOrNull()

                val authCode = (1000..9999).random().toString()
                val providerRef = "WMATA_AUTO_MOCK_AUTH_" + (100000..999999).random()

                // Create Auto-Reload Transaction record
                val transaction = PaymentTransaction(
                    id = "TX_AUTO_" + UUID.randomUUID().toString().take(8).uppercase(),
                    journeyId = null,
                    amount = card.autoReloadAmount,
                    currency = "USD",
                    paymentMethodId = bankCard?.id ?: "CASH_REF",
                    paymentMethodType = "BankCard",
                    status = "Captured",
                    timestamp = _simulationTime.value,
                    providerReference = providerRef,
                    authCode = authCode,
                    reconciliationState = "Reconciled"
                )
                repository.saveTransaction(transaction)

                sendNotification(
                    title = "Auto-Reload Triggered",
                    message = "Low balance detected on ${card.nickname}. Automatically loaded $${String.format("%.2f", card.autoReloadAmount)} using attached card ending in ${bankCard?.lastFour ?: "Cash"}.",
                    type = "AUTO_RELOAD",
                    relatedId = cardId
                )
            }
        }
    }

    // Force synchronize offline queued tap events
    fun syncOfflineEvents() {
        viewModelScope.launch {
            val events = repository.getTapEventsFlow().first()
            val offlineEvents = events.filter { it.syncState == "LOCAL_ONLY" }
            if (offlineEvents.isEmpty()) return@launch

            // Simulate delayed synchronization
            offlineEvents.forEach { event ->
                val syncedEvent = event.copy(syncState = "SYNCED")
                repository.saveTapEvent(syncedEvent)
            }

            sendNotification(
                title = "Offline Events Synchronised",
                message = "Successfully synchronized ${offlineEvents.size} pending offline tap events with the metropolitan fare backend.",
                type = "OTHER",
                relatedId = null
            )
        }
    }

    // --- ISSUE RESOLUTION & DISPUTES ---

    fun submitDispute(journeyId: String, issueType: String, explanation: String) {
        viewModelScope.launch {
            val dispute = Dispute(
                id = "DSP_" + UUID.randomUUID().toString().take(8).uppercase(),
                journeyId = journeyId,
                issueType = issueType,
                explanation = explanation,
                note = "Submitted for automatic review.",
                status = "Submitted",
                submittedAt = System.currentTimeMillis()
            )
            repository.saveDispute(dispute)
            sendNotification(
                title = "Dispute Submitted",
                message = "Your issue regarding transaction $journeyId has been received. Review pending.",
                type = "DISPUTE",
                relatedId = dispute.id
            )

            // Simulate quick review trigger after 1.5 seconds in view
            // (Mocking review flow approval for demo satisfaction!)
            launch {
                kotlinx.coroutines.delay(3000)
                approveDispute(dispute.id)
            }
        }
    }

    private fun approveDispute(disputeId: String) {
        viewModelScope.launch {
            val dispute = repository.getDisputeById(disputeId) ?: return@launch
            if (dispute.status != "Submitted") return@launch

            val updated = dispute.copy(
                status = "Approved",
                note = "System review complete. Adjustment of $4.00 approved and refunded to Smart Card balance."
            )
            repository.saveDispute(updated)

            // Refund balance if active smart card exists
            val journey = repository.getJourneyById(dispute.journeyId)
            if (journey != null) {
                val card = repository.getTransitCardById(journey.credentialId)
                if (card != null) {
                    val refundAmt = 4.00
                    repository.updateCardBalance(card.id, card.balance + refundAmt)

                    // Log Refund transaction
                    val txId = "TX_REF_" + UUID.randomUUID().toString().take(8).uppercase()
                    repository.saveTransaction(
                        PaymentTransaction(
                            id = txId,
                            journeyId = journey.id,
                            amount = -refundAmt,
                            currency = "USD",
                            paymentMethodId = card.id,
                            paymentMethodType = "SmartCardBalance",
                            status = "Refunded",
                            timestamp = System.currentTimeMillis(),
                            providerReference = "WMATA_MOCK_REFUND_" + (100000..999999).random(),
                            authCode = "0000",
                            reconciliationState = "Reconciled"
                        )
                    )

                    sendNotification(
                        title = "Refund Approved",
                        message = "Your dispute for journey in ${dispute.journeyId} was approved. $${String.format("%.2f", refundAmt)} refunded to ${card.nickname}.",
                        type = "DISPUTE",
                        relatedId = disputeId
                    )
                }
            }
        }
    }

    // --- SUPPORT METHODS ---

    private fun formatTime(timeMillis: Long): String {
        val sdf = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        return sdf.format(java.util.Date(timeMillis))
    }

    private suspend fun sendNotification(title: String, message: String, type: String, relatedId: String?) {
        repository.saveNotification(
            Notification(
                id = UUID.randomUUID().toString(),
                title = title,
                message = message,
                timestamp = _simulationTime.value,
                relatedId = relatedId,
                type = type,
                isRead = false
            )
        )
    }

    private suspend fun saveAuditAndNotification(title: String, message: String, type: String, cardId: String) {
        sendNotification(title, message, type, cardId)
    }

    fun clearNotifications() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
        }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            // Delete all and reseed
            val allCards = repository.getAllTransitCards()
            allCards.forEach { repository.deleteTransitCard(it) }

            val allBankCards = repository.getAllBankCards()
            allBankCards.forEach { repository.deleteBankCard(it) }

            // Reseed
            seedDefaultData()
            _tapResult.value = TapResultState.Idle
            _isOnline.value = true
            _simulationTime.value = System.currentTimeMillis()
        }
    }
}

class MetroViewModelFactory(
    private val application: Application,
    private val repository: MetroRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MetroViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MetroViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
