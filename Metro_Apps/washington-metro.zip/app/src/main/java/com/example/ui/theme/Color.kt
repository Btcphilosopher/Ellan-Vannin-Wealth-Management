package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Washington Metro Palette
val MetroRed = Color(0xFFBF0A30) // Deep Metro red
val MetroBlue = Color(0xFF004C97) // Muted blue
val MetroYellow = Color(0xFFF1C40F) // Safety yellow/amber
val MetroGreen = Color(0xFF2ECC71) // Semantic Green
val MetroOrange = Color(0xFFE67E22) // Line orange

val GraphiteGrey = Color(0xFF2C2C2E)
val ConcreteGrey = Color(0xFF8E8E93)
val WarmWhite = Color(0xFFF4F4F6)
val StainlessSteel = Color(0xFFD1D1D6)
val DeepBlack = Color(0xFF1C1C1E)

// Theme Colors
val PrimaryLight = MetroRed
val SecondaryLight = GraphiteGrey
val BackgroundLight = Color(0xFFF4F4F6) // Concrete-esque light background
val SurfaceLight = Color(0xFFFFFFFF)

val PrimaryDark = MetroRed
val SecondaryDark = StainlessSteel
val BackgroundDark = Color(0xFF121212) // Civic night deep canvas
val SurfaceDark = Color(0xFF1E1E1E)
