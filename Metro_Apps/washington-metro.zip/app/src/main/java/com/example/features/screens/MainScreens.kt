package com.example.features.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import kotlinx.coroutines.flow.map
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.farepolicy.StationData
import com.example.domain.model.*
import com.example.features.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// --- MAIN ENTRANCE CONTROLLER ---

@Composable
fun MainLayout(
    viewModel: MetroViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf("home") }

    val transitCards by viewModel.transitCards.collectAsState()
    val bankCards by viewModel.bankCards.collectAsState()
    val isOnboardingCompleted by viewModel.isOnboardingCompleted.collectAsState()

    // Preferences
    val highContrast by viewModel.highContrastMode.collectAsState()
    val largeText by viewModel.largeTextMode.collectAsState()

    MetroTheme(highContrastMode = highContrast) {
        Surface(
            modifier = modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (!isOnboardingCompleted) {
                    OnboardingScreen(viewModel = viewModel)
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Header
                        HeaderBanner(viewModel = viewModel)

                        // Main Content
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            when (currentTab) {
                                "home" -> HomeScreen(viewModel = viewModel, onNavigateToTap = { currentTab = "tap" })
                                "cards" -> CardsScreen(viewModel = viewModel)
                                "history" -> HistoryScreen(viewModel = viewModel)
                                "tap" -> TapCentreScreen(viewModel = viewModel)
                                "more" -> MoreScreen(viewModel = viewModel)
                            }
                        }

                        // Bottom Navigation
                        BottomNavigationBar(
                            currentTab = currentTab,
                            onTabSelected = { currentTab = it },
                            viewModel = viewModel
                        )
                    }
                }
            }
        }
    }
}

// --- HEADER BANNER ---

@Composable
fun HeaderBanner(viewModel: MetroViewModel) {
    val online by viewModel.isOnline.collectAsState()

    Card(
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .statusBarsPadding()
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(MetroRed, CircleShape)
                        .align(Alignment.CenterVertically),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "M",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 20.sp,
                        fontFamily = FontFamily.SansSerif
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "WASHINGTON METRO",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Smart Fare Wallet",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Connection Status Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (online) MetroGreen.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f)
                    )
                    .border(
                        1.dp,
                        if (online) MetroGreen else Color.Red,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { viewModel.toggleOnlineMode() }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(if (online) MetroGreen else Color.Red, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (online) "ONLINE" else "OFFLINE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (online) MetroGreen else Color.Red
                    )
                }
            }
        }
    }
}

// --- BOTTOM NAVIGATION BAR ---

@Composable
fun BottomNavigationBar(
    currentTab: String,
    onTabSelected: (String) -> Unit,
    viewModel: MetroViewModel
) {
    val unreadNotifications by viewModel.notifications.map { list ->
        list.count { !it.isRead }
    }.collectAsState(initial = 0)

    NavigationBar(
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = currentTab == "home",
            onClick = { onTabSelected("home") },
            label = { Text("Home", fontSize = 11.sp) },
            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
            modifier = Modifier.testTag("nav_home")
        )
        NavigationBarItem(
            selected = currentTab == "cards",
            onClick = { onTabSelected("cards") },
            label = { Text("Cards", fontSize = 11.sp) },
            icon = { Icon(Icons.Default.CreditCard, contentDescription = "Cards") },
            modifier = Modifier.testTag("nav_cards")
        )
        NavigationBarItem(
            selected = currentTab == "tap",
            onClick = { onTabSelected("tap") },
            label = { Text("Tap Centre", fontSize = 11.sp) },
            icon = { Icon(Icons.Default.Contactless, contentDescription = "Tap Centre") },
            modifier = Modifier.testTag("nav_tap")
        )
        NavigationBarItem(
            selected = currentTab == "history",
            onClick = { onTabSelected("history") },
            label = { Text("History", fontSize = 11.sp) },
            icon = { Icon(Icons.Default.History, contentDescription = "History") },
            modifier = Modifier.testTag("nav_history")
        )
        NavigationBarItem(
            selected = currentTab == "more",
            onClick = { onTabSelected("more") },
            label = { Text("More", fontSize = 11.sp) },
            icon = {
                BadgedBox(
                    badge = {
                        if (unreadNotifications > 0) {
                            Badge { Text(unreadNotifications.toString()) }
                        }
                    }
                ) {
                    Icon(Icons.Default.Menu, contentDescription = "More")
                }
            },
            modifier = Modifier.testTag("nav_more")
        )
    }
}

// --- ONBOARDING SCREEN ---

@Composable
fun OnboardingScreen(viewModel: MetroViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .statusBarsPadding(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(MetroRed, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("M", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 36.sp)
        }
        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "WASHINGTON METRO",
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 2.sp,
            textAlign = TextAlign.Center
        )
        Text(
            text = "Smart Fare Wallet",
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Your digital pass for high-speed transit throughout the Washington, D.C. Metropolitan Area.",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(48.dp))

        // Create virtual card action card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.addDemoTransitCard("My First Smart Card", 20.00, false) },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.AddCard,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Provision Virtual Smart Card", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Instantly issue a free virtual metro card funded with $20.00.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                viewModel.attachDemoBankCard("Visa", "4111 2222 3333 1842", "Jane Doe", "12", "2029")
                viewModel.addDemoTransitCard("Primary Smart Card", 42.75, false)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Launch Demo Environment (Highly Recommended)")
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Tap in. Tap out. Move freely.",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            letterSpacing = 1.sp
        )
    }
}

// --- HOME SCREEN ---

@Composable
fun HomeScreen(viewModel: MetroViewModel, onNavigateToTap: () -> Unit) {
    val cards by viewModel.transitCards.collectAsState()
    val activeJourney by viewModel.activeJourney.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    val primaryCard = cards.firstOrNull { it.isDefault } ?: cards.firstOrNull()

    var showQuickAddFunds by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 24.dp)
    ) {
        if (primaryCard != null) {
            item {
                SectionHeader("Primary Smart Card")
                MetroCardDisplay(card = primaryCard)
                Spacer(modifier = Modifier.height(20.dp))
            }

            // Active Journey Banner
            if (activeJourney != null) {
                item {
                    val entryStationName = StationData.STATIONS.firstOrNull { it.code == activeJourney?.entryStationId }?.name ?: "Unknown"
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MetroOrange.copy(alpha = 0.15f)),
                        border = BorderStroke(1.dp, MetroOrange),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.DirectionsTransit,
                                        contentDescription = null,
                                        tint = MetroOrange
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("JOURNEY IN PROGRESS", fontWeight = FontWeight.Bold, color = MetroOrange, fontSize = 12.sp)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(MetroOrange, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("ACTIVE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Entered at $entryStationName", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Entry time: ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(activeJourney!!.entryTime))}", fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = onNavigateToTap,
                                colors = ButtonDefaults.buttonColors(containerColor = MetroOrange),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Ready to Tap Out")
                            }
                        }
                    }
                }
            }

            // Quick Actions
            item {
                SectionHeader("Quick Actions")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { showQuickAddFunds = true },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Funds", fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = onNavigateToTap,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Contactless, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Simulate Tap", fontSize = 12.sp)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        } else {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .background(Color.LightGray.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No active smart cards. Go to 'Cards' to add one.", color = Color.Gray)
                }
            }
        }

        // Recent Activity List
        item {
            SectionHeader("Recent Activities")
        }

        if (transactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No transactions found.", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else {
            items(transactions.take(5)) { tx ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(
                                        if (tx.amount < 0) MetroGreen.copy(alpha = 0.1f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (tx.amount < 0) Icons.Default.Reply else Icons.Default.TransitEnterexit,
                                    contentDescription = null,
                                    tint = if (tx.amount < 0) MetroGreen else MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (tx.amount < 0) "Refund Issued" else if (tx.journeyId != null) "Transit Fare Deduction" else "Card Top-up",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(tx.timestamp)),
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                        Text(
                            text = (if (tx.amount < 0) "+" else "-") + "$${String.format("%.2f", Math.abs(tx.amount))}",
                            fontWeight = FontWeight.Bold,
                            color = if (tx.amount < 0) MetroGreen else MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }

    // Quick Add Funds Sheet/Dialog
    if (showQuickAddFunds && primaryCard != null) {
        AlertDialog(
            onDismissRequest = { showQuickAddFunds = false },
            title = { Text("Add Funds to Smart Card") },
            text = {
                Column {
                    Text("Fund physical or virtual wallet securely. Choose top-up amount:", fontSize = 13.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf(10.0, 20.0, 50.0).forEach { amt ->
                            Button(
                                onClick = {
                                    viewModel.addDemoFunds(primaryCard.id, amt, "DEMO_ATTACHED_CARD")
                                    showQuickAddFunds = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                                modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                            ) {
                                Text("+$amt", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQuickAddFunds = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// --- CARDS SCREEN ---

@Composable
fun CardsScreen(viewModel: MetroViewModel) {
    val transitCards by viewModel.transitCards.collectAsState()
    val bankCards by viewModel.bankCards.collectAsState()

    var showAddSmartCard by remember { mutableStateOf(false) }
    var showAddBankCard by remember { mutableStateOf(false) }

    var selectedCardForDetail by remember { mutableStateOf<TransitCard?>(null) }

    var newCardNickname by remember { mutableStateOf("") }
    var newCardIsPhysical by remember { mutableStateOf(false) }

    var bankBrand by remember { mutableStateOf("Visa") }
    var bankNumber by remember { mutableStateOf("") }
    var bankHolder by remember { mutableStateOf("") }
    var bankExpiryMonth by remember { mutableStateOf("") }
    var bankExpiryYear by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        // Smart Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader("Smart Transit Cards")
                IconButton(onClick = { showAddSmartCard = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add Card", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }

        if (transitCards.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .background(Color.LightGray.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No smart transit cards linked.", color = Color.Gray, fontSize = 13.sp)
                }
            }
        } else {
            items(transitCards) { card ->
                MetroCardDisplay(
                    card = card,
                    modifier = Modifier.padding(vertical = 8.dp),
                    onClick = { selectedCardForDetail = card }
                )
            }
        }

        // Bank Cards
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader("Attached Bank Cards")
                IconButton(onClick = { showAddBankCard = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add Bank Card", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }

        if (bankCards.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .background(Color.LightGray.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No bank cards attached for auto-reload.", color = Color.Gray, fontSize = 13.sp)
                }
            }
        } else {
            items(bankCards) { card ->
                BankCardDisplay(
                    card = card,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }
    }

    // SMART CARD DETAIL DIALOG
    if (selectedCardForDetail != null) {
        val card = selectedCardForDetail!!
        AlertDialog(
            onDismissRequest = { selectedCardForDetail = null },
            title = { Text(card.nickname, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Masked Identifier: ${card.cardNumber}", fontSize = 12.sp, color = Color.Gray)
                    Text("Card Lifecycle Status: ${card.status.uppercase()}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    Text("Type: ${card.cardType}", fontSize = 12.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.toggleCardFreeze(card.id)
                                selectedCardForDetail = null
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (card.status == "Suspended") "Unfreeze" else "Freeze")
                        }
                        Button(
                            onClick = {
                                viewModel.replaceCardRecord(card.id)
                                selectedCardForDetail = null
                            },
                            modifier = Modifier.weight(1.5f),
                            colors = ButtonDefaults.buttonColors(containerColor = MetroOrange)
                        ) {
                            Text("Replace Card")
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = {
                            viewModel.removeTransitCard(card.id)
                            selectedCardForDetail = null
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red)
                    ) {
                        Text("Remove Card")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedCardForDetail = null }) {
                    Text("Close")
                }
            }
        )
    }

    // ADD SMART CARD DIALOG
    if (showAddSmartCard) {
        AlertDialog(
            onDismissRequest = { showAddSmartCard = false },
            title = { Text("Add Smart Card") },
            text = {
                Column {
                    TextField(
                        value = newCardNickname,
                        onValueChange = { newCardNickname = it },
                        label = { Text("Card Nickname") },
                        modifier = Modifier.fillMaxWidth().testTag("add_card_nickname_input")
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = newCardIsPhysical,
                            onCheckedChange = { newCardIsPhysical = it }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Physical plastic card (instead of Virtual)")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addDemoTransitCard(newCardNickname, 10.0, newCardIsPhysical)
                        newCardNickname = ""
                        showAddSmartCard = false
                    }
                ) {
                    Text("Link Card")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddSmartCard = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ADD DEBIT/CREDIT CARD DIALOG
    if (showAddBankCard) {
        AlertDialog(
            onDismissRequest = { showAddBankCard = false },
            title = { Text("Attach Bank Card") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("Secure Mock Tokenization Engine. Expiry dates strictly validated.", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Visa", "Mastercard", "Amex").forEach { brand ->
                            Button(
                                onClick = { bankBrand = brand },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (bankBrand == brand) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(brand, color = if (bankBrand == brand) Color.White else Color.Black, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    TextField(
                        value = bankNumber,
                        onValueChange = { bankNumber = it },
                        label = { Text("Card Number (Luhn verified)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("bank_number_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = bankHolder,
                        onValueChange = { bankHolder = it },
                        label = { Text("Cardholder Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextField(
                            value = bankExpiryMonth,
                            onValueChange = { bankExpiryMonth = it },
                            label = { Text("MM") },
                            modifier = Modifier.weight(1f)
                        )
                        TextField(
                            value = bankExpiryYear,
                            onValueChange = { bankExpiryYear = it },
                            label = { Text("YYYY") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = viewModel.attachDemoBankCard(
                            bankBrand, bankNumber, bankHolder, bankExpiryMonth, bankExpiryYear
                        )
                        if (success) {
                            bankNumber = ""
                            bankHolder = ""
                            bankExpiryMonth = ""
                            bankExpiryYear = ""
                            showAddBankCard = false
                        }
                    }
                ) {
                    Text("Attach")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddBankCard = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// --- TAP CENTRE SCREEN ---

@Composable
fun TapCentreScreen(viewModel: MetroViewModel) {
    val cards by viewModel.transitCards.collectAsState()
    val bankCards by viewModel.bankCards.collectAsState()
    val selectedCardId by viewModel.selectedCardId.collectAsState()
    val selectedStationCode by viewModel.selectedStationCode.collectAsState()
    val selectedGateId by viewModel.selectedGateId.collectAsState()
    val selectedDirection by viewModel.selectedDirection.collectAsState()
    val tapResult by viewModel.tapResult.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()

    var showStationSelector by remember { mutableStateOf(false) }
    var searchStationText by remember { mutableStateOf("") }

    val activeCard = cards.firstOrNull { it.id == selectedCardId } ?: cards.firstOrNull()
    val station = StationData.STATIONS.firstOrNull { it.code == selectedStationCode }
        ?: StationData.STATIONS.first()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        item {
            SectionHeader("Tap Terminal Console")
        }

        // Active Card Selector Row
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Select Payment Credential", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(10.dp))
                    if (cards.isEmpty()) {
                        Text("Provision a card under 'Cards' first.", color = Color.Red, fontSize = 12.sp)
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            cards.forEach { card ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (selectedCardId == card.id) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                            else Color.LightGray.copy(alpha = 0.2f)
                                        )
                                        .border(
                                            1.dp,
                                            if (selectedCardId == card.id) MaterialTheme.colorScheme.primary else Color.Transparent,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.setSelectedCard(card.id) }
                                        .padding(10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(card.nickname, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                                        Text(card.cardNumber, fontSize = 9.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Station Selector Box
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clickable { showStationSelector = true }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(MetroBlue.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Place, contentDescription = null, tint = MetroBlue)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Station & Gate Location", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${station.name} (${station.code}) - Gate ${selectedGateId.substringAfterLast("-")}", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Select Location")
                }
            }
        }

        // Direction Selector Row (ENTRY / EXIT)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.setSelectedDirection("ENTRY") },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedDirection == "ENTRY") MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("ENTRY GATE (TAP-IN)", color = if (selectedDirection == "ENTRY") Color.White else Color.Black, fontSize = 11.sp)
                }
                Button(
                    onClick = { viewModel.setSelectedDirection("EXIT") },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedDirection == "EXIT") MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("EXIT GATE (TAP-OUT)", color = if (selectedDirection == "EXIT") Color.White else Color.Black, fontSize = 11.sp)
                }
            }
        }

        // Massive CTA Trigger Button
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { viewModel.performSimulatedTap() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .testTag("simulate_tap_cta"),
                colors = ButtonDefaults.buttonColors(containerColor = MetroRed)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Contactless, contentDescription = null, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (selectedDirection == "ENTRY") "SIMULATE TAP-IN" else "SIMULATE TAP-OUT",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // TAP CONFIRMATION AND RESULT BOX
        item {
            AnimatedVisibility(
                visible = tapResult != TapResultState.Idle,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when (tapResult) {
                            is TapResultState.Success -> MetroGreen.copy(alpha = 0.12f)
                            is TapResultState.Failure -> Color.Red.copy(alpha = 0.12f)
                            else -> Color.LightGray.copy(alpha = 0.1f)
                        }
                    ),
                    border = BorderStroke(
                        1.dp,
                        when (tapResult) {
                            is TapResultState.Success -> MetroGreen
                            is TapResultState.Failure -> Color.Red
                            else -> Color.Transparent
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        when (val res = tapResult) {
                            is TapResultState.Success -> {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(MetroGreen, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("TAP SUCCESSFUL", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MetroGreen)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(res.stationName, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                                Text(res.timeLabel, fontSize = 12.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(res.cardLabel, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(res.currentBalanceOrStatus, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(res.textDetail, fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
                            }
                            is TapResultState.Failure -> {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(Color.Red, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, tint = Color.White)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("TAP DECLINED", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.Red)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(res.errorTitle, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(res.errorMessage, fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
                            }
                            else -> {
                                CircularProgressIndicator()
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Contacting payment gateway...", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Expanded Developer Console Section
        item {
            Spacer(modifier = Modifier.height(24.dp))
            SectionHeader("Developer Console Shortcuts")
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Manual Event Triggers", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.toggleOnlineMode() },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                        ) {
                            Text(if (isOnline) "Force Offline" else "Restore Connection", fontSize = 10.sp)
                        }
                        Button(
                            onClick = { viewModel.advanceTime(15) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                        ) {
                            Text("Advance Clock +15m", fontSize = 10.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { viewModel.resetDemoData() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                    ) {
                        Text("Reset & Seed Demo Data")
                    }
                }
            }
        }
    }

    // STATION SELECTOR DIALOG
    if (showStationSelector) {
        AlertDialog(
            onDismissRequest = { showStationSelector = false },
            title = { Text("Select Station Location") },
            text = {
                Column {
                    TextField(
                        value = searchStationText,
                        onValueChange = { searchStationText = it },
                        placeholder = { Text("Search Metro Stations...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(modifier = Modifier.height(250.dp)) {
                        LazyColumn {
                            val filtered = StationData.STATIONS.filter {
                                it.name.contains(searchStationText, ignoreCase = true)
                            }
                            items(filtered) { stat ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.setSelectedStation(stat.code)
                                            showStationSelector = false
                                        }
                                        .padding(vertical = 12.dp, horizontal = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(stat.name, fontWeight = FontWeight.Bold)
                                        Text("Lines: " + stat.lines.joinToString(", "), fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Text(stat.code, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}

// --- HISTORY SCREEN ---

@Composable
fun HistoryScreen(viewModel: MetroViewModel) {
    val journeys by viewModel.journeys.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    var showJourneyDetails by remember { mutableStateOf<TransitJourney?>(null) }
    var showDisputeForm by remember { mutableStateOf<TransitJourney?>(null) }
    var disputeType by remember { mutableStateOf("MissingTapOut") }
    var disputeExplanation by remember { mutableStateOf("") }

    var selectedHistoryTab by remember { mutableStateOf("journeys") }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { selectedHistoryTab = "journeys" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedHistoryTab == "journeys") MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f)
                ),
                modifier = Modifier.weight(1f)
            ) {
                Text("Journeys Ledger", color = if (selectedHistoryTab == "journeys") Color.White else Color.Black, fontSize = 12.sp)
            }
            Button(
                onClick = { selectedHistoryTab = "payments" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedHistoryTab == "payments") MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f)
                ),
                modifier = Modifier.weight(1f)
            ) {
                Text("Payment Ledger", color = if (selectedHistoryTab == "payments") Color.White else Color.Black, fontSize = 12.sp)
            }
        }

        Box(modifier = Modifier.weight(1f).padding(horizontal = 20.dp)) {
            if (selectedHistoryTab == "journeys") {
                if (journeys.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No journeys recorded yet.", color = Color.Gray)
                    }
                } else {
                    LazyColumn {
                        items(journeys) { jrn ->
                            val startStation = StationData.STATIONS.firstOrNull { it.code == jrn.entryStationId }?.name ?: "Unknown"
                            val endStation = StationData.STATIONS.firstOrNull { it.code == jrn.exitStationId }?.name ?: "Incomplete (No Exit)"

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable { showJourneyDetails = jrn },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date(jrn.entryTime)),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = Color.Gray
                                        )

                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    if (jrn.status == "Completed") MetroGreen.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f),
                                                    RoundedCornerShape(4.dp)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = jrn.status.uppercase(),
                                                color = if (jrn.status == "Completed") MetroGreen else Color.Red,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "$startStation → $endStation",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (jrn.status == "Completed") "Fare Deducted: $${String.format("%.2f", jrn.finalFare)}" else "Pending Exit Action / Maximum Penalty Applied",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                if (transactions.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No balance ledger reloads found.", color = Color.Gray)
                    }
                } else {
                    LazyColumn {
                        items(transactions) { tx ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = if (tx.amount < 0) "Refund Credited" else if (tx.journeyId != null) "Fare Captured" else "Auto-Reload / manual deposit",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text("Ref: ${tx.providerReference}", fontSize = 11.sp, color = Color.Gray)
                                        Text(SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(tx.timestamp)), fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Text(
                                        text = (if (tx.amount < 0) "+" else "-") + "$${String.format("%.2f", Math.abs(tx.amount))}",
                                        fontWeight = FontWeight.Bold,
                                        color = if (tx.amount < 0) MetroGreen else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // JOURNEY DETAIL WORKFLOW
    if (showJourneyDetails != null) {
        val jrn = showJourneyDetails!!
        val startStationName = StationData.STATIONS.firstOrNull { it.code == jrn.entryStationId }?.name ?: "Unknown"
        val endStationName = StationData.STATIONS.firstOrNull { it.code == jrn.exitStationId }?.name ?: "Incomplete"

        AlertDialog(
            onDismissRequest = { showJourneyDetails = null },
            title = { Text("Fare Calculation Detail", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Policy Model: Demo Fare Policy v1", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("• Entry Station: $startStationName", fontSize = 13.sp)
                    Text("• Exit Station: $endStationName", fontSize = 13.sp)
                    Text("• Base Fare: $${String.format("%.2f", jrn.baseFare)}", fontSize = 13.sp)
                    Text("• Discretionary Adjustments: $${String.format("%.2f", jrn.adjustment)}", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Final Paid Fare: $${String.format("%.2f", jrn.finalFare)}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("• Reference Key: ${jrn.transactionRef}", fontSize = 11.sp, color = Color.Gray)

                    if (jrn.status == "Incomplete") {
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                showDisputeForm = jrn
                                showJourneyDetails = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MetroOrange),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Resolve Incomplete Journey")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showJourneyDetails = null }) {
                    Text("Close")
                }
            }
        )
    }

    // RESOLVE INCOMPLETE JOURNEY FORM
    if (showDisputeForm != null) {
        val jrn = showDisputeForm!!
        AlertDialog(
            onDismissRequest = { showDisputeForm = null },
            title = { Text("Submit Issue Resolution") },
            text = {
                Column {
                    Text("We detected a missing Tap-Out or wrong gate tap on card ${jrn.credentialId}.", fontSize = 12.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Issue Type:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("MissingTapOut", "IncorrectFare").forEach { type ->
                            Button(
                                onClick = { disputeType = type },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (disputeType == type) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(type, color = if (disputeType == type) Color.White else Color.Black, fontSize = 10.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    TextField(
                        value = disputeExplanation,
                        onValueChange = { disputeExplanation = it },
                        placeholder = { Text("Provide details (e.g. gate was open)...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.submitDispute(jrn.id, disputeType, disputeExplanation)
                        disputeExplanation = ""
                        showDisputeForm = null
                    }
                ) {
                    Text("Submit Dispute")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDisputeForm = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// --- MORE SCREEN ---

@Composable
fun MoreScreen(viewModel: MetroViewModel) {
    val disputes by viewModel.disputes.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    // Config preferences
    val highContrast by viewModel.highContrastMode.collectAsState()
    val largeText by viewModel.largeTextMode.collectAsState()
    val reducedMotion by viewModel.reducedMotionMode.collectAsState()

    var showSupportDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        // App Preferences
        item {
            SectionHeader("UI Preferences & Accessibility")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("High Contrast Mode", fontWeight = FontWeight.Medium)
                        Switch(checked = highContrast, onCheckedChange = { viewModel.toggleHighContrast() })
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Large Accessibility Text", fontWeight = FontWeight.Medium)
                        Switch(checked = largeText, onCheckedChange = { viewModel.toggleLargeText() })
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Reduced Motion Dynamics", fontWeight = FontWeight.Medium)
                        Switch(checked = reducedMotion, onCheckedChange = { viewModel.toggleReducedMotion() })
                    }
                }
            }
        }

        // Dispute Cases list
        item {
            Spacer(modifier = Modifier.height(24.dp))
            SectionHeader("Submitted Dispute Reviews")
        }

        if (disputes.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .background(Color.LightGray.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No disputes submitted.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        } else {
            items(disputes) { disp ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("ID: ${disp.id}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (disp.status == "Approved") MetroGreen.copy(alpha = 0.15f) else MetroOrange.copy(alpha = 0.15f),
                                        RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(disp.status.uppercase(), color = if (disp.status == "Approved") MetroGreen else MetroOrange, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Issue: ${disp.issueType}", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        Text("Details: ${disp.explanation}", fontSize = 12.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Result Notes: ${disp.note}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        // Notification List
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader("Notification Alerts Center")
                TextButton(onClick = { viewModel.clearNotifications() }) {
                    Text("Mark all read", fontSize = 12.sp)
                }
            }
        }

        if (notifications.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No notifications.", color = Color.Gray)
                }
            }
        } else {
            items(notifications) { notif ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (notif.isRead) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(notif.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(notif.message, fontSize = 12.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(notif.timestamp)),
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        // Civic Support info
        item {
            Spacer(modifier = Modifier.height(24.dp))
            SectionHeader("Civic Support Helpline")
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.clickable { showSupportDialog = true }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.SupportAgent, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Transit Customer Care & Help", fontWeight = FontWeight.Bold)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                }
            }
        }
    }

    // SUPPORT DIALOG
    if (showSupportDialog) {
        AlertDialog(
            onDismissRequest = { showSupportDialog = false },
            title = { Text("Washington Metro Support") },
            text = {
                Column {
                    Text("For real physical card issues, please consult WMATA customer service at wmata.com.", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("• Phone support: (202) 637-7000", fontSize = 13.sp)
                    Text("• SmarTrip helpline: 1-888-762-7874", fontSize = 13.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showSupportDialog = false }) {
                    Text("OK")
                }
            }
        )
    }
}
