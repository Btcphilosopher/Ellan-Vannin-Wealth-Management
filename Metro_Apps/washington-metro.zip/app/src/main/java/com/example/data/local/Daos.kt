package com.example.data.local

import androidx.room.*
import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TransitCardDao {
    @Query("SELECT * FROM transit_cards")
    fun getAllCardsFlow(): Flow<List<TransitCard>>

    @Query("SELECT * FROM transit_cards")
    suspend fun getAllCards(): List<TransitCard>

    @Query("SELECT * FROM transit_cards WHERE id = :id")
    suspend fun getCardById(id: String): TransitCard?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCard(card: TransitCard)

    @Delete
    suspend fun deleteCard(card: TransitCard)

    @Query("UPDATE transit_cards SET balance = :balance WHERE id = :id")
    suspend fun updateBalance(id: String, balance: Double)

    @Query("UPDATE transit_cards SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)
}

@Dao
interface BankCardDao {
    @Query("SELECT * FROM bank_cards")
    fun getAllBankCardsFlow(): Flow<List<BankCardReference>>

    @Query("SELECT * FROM bank_cards")
    suspend fun getAllBankCards(): List<BankCardReference>

    @Query("SELECT * FROM bank_cards WHERE id = :id")
    suspend fun getBankCardById(id: String): BankCardReference?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBankCard(bankCard: BankCardReference)

    @Delete
    suspend fun deleteBankCard(bankCard: BankCardReference)
}

@Dao
interface TapEventDao {
    @Query("SELECT * FROM tap_events ORDER BY timestamp DESC")
    fun getAllTapEventsFlow(): Flow<List<TapEvent>>

    @Query("SELECT * FROM tap_events WHERE id = :id")
    suspend fun getTapEventById(id: String): TapEvent?

    @Query("SELECT * FROM tap_events WHERE credentialId = :credentialId ORDER BY timestamp DESC")
    suspend fun getTapEventsForCredential(credentialId: String): List<TapEvent>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTapEvent(tapEvent: TapEvent)
}

@Dao
interface TransitJourneyDao {
    @Query("SELECT * FROM transit_journeys ORDER BY entryTime DESC")
    fun getAllJourneysFlow(): Flow<List<TransitJourney>>

    @Query("SELECT * FROM transit_journeys WHERE id = :id")
    suspend fun getJourneyById(id: String): TransitJourney?

    @Query("SELECT * FROM transit_journeys WHERE status = 'Active' LIMIT 1")
    suspend fun getActiveJourney(): TransitJourney?

    @Query("SELECT * FROM transit_journeys WHERE credentialId = :credentialId ORDER BY entryTime DESC")
    suspend fun getJourneysForCredential(credentialId: String): List<TransitJourney>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourney(journey: TransitJourney)
}

@Dao
interface PaymentTransactionDao {
    @Query("SELECT * FROM payment_transactions ORDER BY timestamp DESC")
    fun getAllTransactionsFlow(): Flow<List<PaymentTransaction>>

    @Query("SELECT * FROM payment_transactions WHERE id = :id")
    suspend fun getTransactionById(id: String): PaymentTransaction?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: PaymentTransaction)
}

@Dao
interface DisputeDao {
    @Query("SELECT * FROM disputes ORDER BY submittedAt DESC")
    fun getAllDisputesFlow(): Flow<List<Dispute>>

    @Query("SELECT * FROM disputes WHERE id = :id")
    suspend fun getDisputeById(id: String): Dispute?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDispute(dispute: Dispute)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotificationsFlow(): Flow<List<Notification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: Notification)

    @Query("UPDATE notifications SET isRead = 1 WHERE isRead = 0")
    suspend fun markAllAsRead()
}
