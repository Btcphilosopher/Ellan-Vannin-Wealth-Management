package com.example.core.simulation

import com.example.core.model.*
import com.example.data.providers.DemoDataProvider
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class SimulationState(
    val isPlaying: Boolean = true,
    val speedMultiplier: Int = 1,
    val currentSimTime: Long = System.currentTimeMillis()
)

object TransportSimulator {

    private val _simState = MutableStateFlow(SimulationState())
    val simState: StateFlow<SimulationState> = _simState.asStateFlow()

    private val _vehicles = MutableStateFlow<List<Vehicle>>(emptyList())
    val vehicles: StateFlow<List<Vehicle>> = _vehicles.asStateFlow()

    private val _incidents = MutableStateFlow<List<ServiceIncident>>(DemoDataProvider.initialIncidents)
    val incidents: StateFlow<List<ServiceIncident>> = _incidents.asStateFlow()

    private val _eventLog = MutableStateFlow<List<String>>(emptyList())
    val eventLog: StateFlow<List<String>> = _eventLog.asStateFlow()

    private val simulatorScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var simJob: Job? = null

    // Internal simulation state for each vehicle
    private data class SimulatedVehicleState(
        val vehicleId: String,
        val type: VehicleType,
        val lineId: String,
        var currentStopIndex: Int,
        var isMovingForward: Boolean,
        var secondsToNextStop: Double,
        var currentDelaySeconds: Int = 0,
        var currentStatus: VehicleStatus = VehicleStatus.EN_RUTA
    )

    private val simVehicles = mutableListOf<SimulatedVehicleState>()

    init {
        initializeVehicles()
        startSimulation()
    }

    private fun initializeVehicles() {
        simVehicles.clear()

        // 1. Spawn Metro Trains (2 trains for each Metro line: one going forward, one going backward)
        DemoDataProvider.metroLines.forEach { line ->
            if (line.stations.size >= 2) {
                // Train A (forward)
                simVehicles.add(
                    SimulatedVehicleState(
                        vehicleId = "METRO_${line.id}_A",
                        type = VehicleType.METRO,
                        lineId = line.id,
                        currentStopIndex = 0,
                        isMovingForward = true,
                        secondsToNextStop = 60.0 + Random.nextInt(30)
                    )
                )
                // Train B (backward)
                simVehicles.add(
                    SimulatedVehicleState(
                        vehicleId = "METRO_${line.id}_B",
                        type = VehicleType.METRO,
                        lineId = line.id,
                        currentStopIndex = line.stations.size - 1,
                        isMovingForward = false,
                        secondsToNextStop = 45.0 + Random.nextInt(30)
                    )
                )
            }
        }

        // 2. Spawn Buses (2 buses for each route)
        DemoDataProvider.busRoutes.forEach { route ->
            if (route.stops.size >= 2) {
                // Bus A (forward)
                simVehicles.add(
                    SimulatedVehicleState(
                        vehicleId = "BUS_${route.id}_A",
                        type = route.type,
                        lineId = route.id,
                        currentStopIndex = 0,
                        isMovingForward = true,
                        secondsToNextStop = 80.0 + Random.nextInt(40)
                    )
                )
                // Bus B (starts halfway)
                simVehicles.add(
                    SimulatedVehicleState(
                        vehicleId = "BUS_${route.id}_B",
                        type = route.type,
                        lineId = route.id,
                        currentStopIndex = route.stops.size / 2,
                        isMovingForward = true,
                        secondsToNextStop = 90.0 + Random.nextInt(40)
                    )
                )
            }
        }

        updateVehiclePositions()
    }

    fun startSimulation() {
        simJob?.cancel()
        _simState.value = _simState.value.copy(isPlaying = true)
        logEvent("SIMULATION_STARTED", "Simulador de red activado.")

        simJob = simulatorScope.launch {
            while (isActive) {
                delay(1000) // tick every 1 real-time second
                if (_simState.value.isPlaying) {
                    tickSimulation()
                }
            }
        }
    }

    fun pauseSimulation() {
        _simState.value = _simState.value.copy(isPlaying = false)
        simJob?.cancel()
        logEvent("SIMULATION_PAUSED", "Simulador de red pausado.")
    }

    fun setSpeedMultiplier(multiplier: Int) {
        _simState.value = _simState.value.copy(speedMultiplier = multiplier)
        logEvent("SIMULATION_SPEED_CHANGED", "Velocidad del simulador ajustada a ${multiplier}x")
    }

    private fun tickSimulation() {
        val state = _simState.value
        val elapsedSeconds = 1.0 * state.speedMultiplier

        // Advance simulation clock
        val nextSimTime = state.currentSimTime + (elapsedSeconds * 1000L).toLong()
        _simState.value = state.copy(currentSimTime = nextSimTime)

        // Update each vehicle's position
        simVehicles.forEach { sv ->
            sv.secondsToNextStop -= elapsedSeconds

            if (sv.secondsToNextStop <= 0) {
                // Vehicle has arrived at the next stop
                val stopsCount = getStopsCountForLine(sv.type, sv.lineId)

                // Log departure from old stop
                val oldStopName = getStopName(sv.type, sv.lineId, sv.currentStopIndex)

                // Advance index
                if (sv.isMovingForward) {
                    if (sv.currentStopIndex < stopsCount - 1) {
                        sv.currentStopIndex++
                    } else {
                        // Reverse direction at terminal
                        sv.isMovingForward = false
                        sv.currentStopIndex--
                    }
                } else {
                    if (sv.currentStopIndex > 0) {
                        sv.currentStopIndex--
                    } else {
                        // Reverse direction at terminal
                        sv.isMovingForward = true
                        sv.currentStopIndex++
                    }
                }

                val newStopName = getStopName(sv.type, sv.lineId, sv.currentStopIndex)
                val serviceLabel = getServiceLabel(sv.type, sv.lineId)

                logEvent(
                    "VEHICLE_ARRIVED",
                    "Servicio $serviceLabel llegó a $newStopName (desde $oldStopName)"
                )

                // Reset time to next stop (randomized based on transport type)
                val baseTime = when (sv.type) {
                    VehicleType.METRO -> 90.0 // 1.5 mins
                    VehicleType.METROTREN -> 120.0 // 2 mins
                    else -> 150.0 // 2.5 mins for bus
                }
                sv.secondsToNextStop = baseTime + Random.nextInt(30) + sv.currentDelaySeconds
                sv.currentStatus = if (sv.currentDelaySeconds > 30) VehicleStatus.CON_RETRASO else VehicleStatus.EN_RUTA
            }
        }

        updateVehiclePositions()
    }

    private fun updateVehiclePositions() {
        val updatedVehicles = simVehicles.map { sv ->
            val stopsCount = getStopsCountForLine(sv.type, sv.lineId)
            val index = sv.currentStopIndex

            val currCoords = getStopCoords(sv.type, sv.lineId, index)

            // Interpolate position based on remaining time to next stop
            var lat = currCoords.first
            var lon = currCoords.second
            var nextStopIndex = index

            if (stopsCount > 1) {
                nextStopIndex = if (sv.isMovingForward) {
                    (index + 1).coerceAtMost(stopsCount - 1)
                } else {
                    (index - 1).coerceAtLeast(0)
                }

                if (index != nextStopIndex) {
                    val nextCoords = getStopCoords(sv.type, sv.lineId, nextStopIndex)
                    val baseInterval = when (sv.type) {
                        VehicleType.METRO -> 100.0
                        VehicleType.METROTREN -> 130.0
                        else -> 160.0
                    }
                    // Interpolate linear progress
                    val totalTime = sv.secondsToNextStop.coerceAtLeast(1.0)
                    val progress = (1.0 - (totalTime / baseInterval)).coerceIn(0.0, 1.0)

                    lat = currCoords.first + (nextCoords.first - currCoords.first) * progress
                    lon = currCoords.second + (nextCoords.second - currCoords.second) * progress
                }
            }

            val destName = getStopName(sv.type, sv.lineId, if (sv.isMovingForward) stopsCount - 1 else 0)

            Vehicle(
                id = sv.vehicleId,
                type = sv.type,
                lineId = sv.lineId,
                currentPositionIndex = index,
                status = sv.currentStatus,
                currentSpeedKmh = when (sv.type) {
                    VehicleType.METRO -> 65.0
                    VehicleType.METROTREN -> 80.0
                    else -> 25.0
                } + (if (sv.currentStatus == VehicleStatus.CON_RETRASO) -10.0 else 0.0),
                currentDelaySeconds = sv.currentDelaySeconds,
                destination = destName,
                isAccessible = true,
                latitude = lat,
                longitude = lon,
                nextStopSeconds = sv.secondsToNextStop.toInt()
            )
        }

        _vehicles.value = updatedVehicles
    }

    private fun getStopsCountForLine(type: VehicleType, lineId: String): Int {
        return when (type) {
            VehicleType.METRO, VehicleType.METROTREN -> {
                DemoDataProvider.metroLines.find { it.id == lineId }?.stations?.size ?: 0
            }
            else -> {
                DemoDataProvider.busRoutes.find { it.id == lineId }?.stops?.size ?: 0
            }
        }
    }

    private fun getStopName(type: VehicleType, lineId: String, index: Int): String {
        return when (type) {
            VehicleType.METRO, VehicleType.METROTREN -> {
                val stations = DemoDataProvider.metroLines.find { it.id == lineId }?.stations ?: return "Desconocido"
                if (index in stations.indices) stations[index].name else "Terminal"
            }
            else -> {
                val stops = DemoDataProvider.busRoutes.find { it.id == lineId }?.stops ?: return "Desconocido"
                if (index in stops.indices) {
                    val paraderoId = stops[index]
                    DemoDataProvider.paraderos.find { it.id == paraderoId }?.name ?: paraderoId
                } else "Paradero"
            }
        }
    }

    private fun getStopCoords(type: VehicleType, lineId: String, index: Int): Pair<Double, Double> {
        return when (type) {
            VehicleType.METRO, VehicleType.METROTREN -> {
                val stations = DemoDataProvider.metroLines.find { it.id == lineId }?.stations ?: return 0.0 to 0.0
                val safeIndex = index.coerceIn(stations.indices)
                val s = stations[safeIndex]
                s.latitude to s.longitude
            }
            else -> {
                val stops = DemoDataProvider.busRoutes.find { it.id == lineId }?.stops ?: return 0.0 to 0.0
                val safeIndex = index.coerceIn(stops.indices)
                val paraderoId = stops[safeIndex]
                val p = DemoDataProvider.paraderos.find { it.id == paraderoId } ?: return 0.0 to 0.0
                p.latitude to p.longitude
            }
        }
    }

    private fun getServiceLabel(type: VehicleType, lineId: String): String {
        return when (type) {
            VehicleType.METRO -> "Metro $lineId"
            VehicleType.METROTREN -> "Nos Tren"
            else -> "Bus $lineId"
        }
    }

    fun injectDelay(vehicleId: String, delaySeconds: Int) {
        val sv = simVehicles.find { it.vehicleId == vehicleId }
        if (sv != null) {
            sv.currentDelaySeconds = delaySeconds
            sv.secondsToNextStop += delaySeconds
            sv.currentStatus = if (delaySeconds > 0) VehicleStatus.CON_RETRASO else VehicleStatus.EN_RUTA
            updateVehiclePositions()
            logEvent("DELAY_INJECTED", "Retraso de $delaySeconds segundos inyectado en vehículo $vehicleId.")
        }
    }

    fun injectIncident(lineId: String, stationName: String, desc: String) {
        val newIncident = ServiceIncident(
            id = "inc_user_${System.currentTimeMillis()}",
            severity = IncidentSeverity.ALTA,
            affectedLine = lineId,
            affectedStation = stationName,
            startTime = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(_simState.value.currentSimTime)),
            expectedEnd = "23:00",
            description = desc,
            alternativeRoute = "Prefiera transporte alternativo o recorridos paralelos de Red Movilidad."
        )

        _incidents.value = _incidents.value + newIncident
        logEvent("INCIDENT_CREATED", "Incidencia creada en $lineId ($stationName): $desc")
    }

    fun resolveIncident(incidentId: String) {
        val inc = _incidents.value.find { it.id == incidentId }
        _incidents.value = _incidents.value.filter { it.id != incidentId }
        if (inc != null) {
            logEvent("INCIDENT_RESOLVED", "Incidencia resuelta en ${inc.affectedLine}: ${inc.description}")
        }
    }

    fun logEvent(event: String, description: String) {
        val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val simTimeStr = formatter.format(Date(_simState.value.currentSimTime))
        val logLine = "[$simTimeStr] $event - $description"
        val logs = _eventLog.value.toMutableList()
        logs.add(0, logLine)
        if (logs.size > 100) {
            logs.removeAt(logs.size - 1)
        }
        _eventLog.value = logs
    }
}
