package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp

@Composable
fun MetroTrainVector(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Background color / wheels shadow
        drawCircle(Color(0xFF333333), radius = h * 0.12f, center = Offset(w * 0.25f, h * 0.85f))
        drawCircle(Color(0xFF333333), radius = h * 0.12f, center = Offset(w * 0.75f, h * 0.85f))

        // Main steel body (Silver grey)
        drawRoundRect(
            color = Color(0xFFB0BEC5),
            topLeft = Offset(w * 0.05f, h * 0.20f),
            size = Size(w * 0.90f, h * 0.55f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
        )

        // Santiago Metro Red stripe (Bottom)
        drawRect(
            color = Color(0xFFE2231A),
            topLeft = Offset(w * 0.05f, h * 0.60f),
            size = Size(w * 0.90f, h * 0.10f)
        )

        // Metro Blue stripe (Middle)
        drawRect(
            color = Color(0xFF0F4C81),
            topLeft = Offset(w * 0.05f, h * 0.50f),
            size = Size(w * 0.90f, h * 0.04f)
        )

        // Dark glass windows
        drawRect(
            color = Color(0xFF263238),
            topLeft = Offset(w * 0.12f, h * 0.28f),
            size = Size(w * 0.18f, h * 0.18f)
        )
        drawRect(
            color = Color(0xFF263238),
            topLeft = Offset(w * 0.41f, h * 0.28f),
            size = Size(w * 0.18f, h * 0.18f)
        )
        drawRect(
            color = Color(0xFF263238),
            topLeft = Offset(w * 0.70f, h * 0.28f),
            size = Size(w * 0.18f, h * 0.18f)
        )

        // Connecting door / headlight lines
        drawRect(
            color = Color(0xFF455A64),
            topLeft = Offset(w * 0.02f, h * 0.35f),
            size = Size(w * 0.03f, h * 0.30f)
        )
        drawRect(
            color = Color(0xFF455A64),
            topLeft = Offset(w * 0.95f, h * 0.35f),
            size = Size(w * 0.03f, h * 0.30f)
        )
    }
}

@Composable
fun RedBusVector(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Wheels
        drawCircle(Color(0xFF212121), radius = h * 0.14f, center = Offset(w * 0.22f, h * 0.82f))
        drawCircle(Color(0xFF212121), radius = h * 0.14f, center = Offset(w * 0.78f, h * 0.82f))
        drawCircle(Color(0xFFCFD8DC), radius = h * 0.05f, center = Offset(w * 0.22f, h * 0.82f))
        drawCircle(Color(0xFFCFD8DC), radius = h * 0.05f, center = Offset(w * 0.78f, h * 0.82f))

        // White upper half
        drawRoundRect(
            color = Color(0xFFFAFAFA),
            topLeft = Offset(w * 0.05f, h * 0.18f),
            size = Size(w * 0.90f, h * 0.32f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
        )

        // Red lower half
        drawRoundRect(
            color = Color(0xFFD32F2F),
            topLeft = Offset(w * 0.05f, h * 0.50f),
            size = Size(w * 0.90f, h * 0.23f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
        )

        // Windows (divided panels)
        drawRect(Color(0xFF263238), topLeft = Offset(w * 0.10f, h * 0.24f), size = Size(w * 0.16f, h * 0.20f))
        drawRect(Color(0xFF263238), topLeft = Offset(w * 0.29f, h * 0.24f), size = Size(w * 0.16f, h * 0.20f))
        drawRect(Color(0xFF263238), topLeft = Offset(w * 0.48f, h * 0.24f), size = Size(w * 0.16f, h * 0.20f))
        // Driver windshield
        val windshield = Path().apply {
            moveTo(w * 0.67f, h * 0.24f)
            lineTo(w * 0.88f, h * 0.24f)
            lineTo(w * 0.91f, h * 0.44f)
            lineTo(w * 0.67f, h * 0.44f)
            close()
        }
        drawPath(windshield, Color(0xFF1A237E))

        // Red bus line identification stripe
        drawRect(
            color = Color(0xFF1A237E),
            topLeft = Offset(w * 0.05f, h * 0.50f),
            size = Size(w * 0.90f, h * 0.03f)
        )
    }
}

@Composable
fun ElectricBusVector(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Wheels
        drawCircle(Color(0xFF111111), radius = h * 0.13f, center = Offset(w * 0.24f, h * 0.82f))
        drawCircle(Color(0xFF111111), radius = h * 0.13f, center = Offset(w * 0.76f, h * 0.82f))
        drawCircle(Color(0xFF90A4AE), radius = h * 0.05f, center = Offset(w * 0.24f, h * 0.82f))
        drawCircle(Color(0xFF90A4AE), radius = h * 0.05f, center = Offset(w * 0.76f, h * 0.82f))

        // Modern Electric Bus Body (Teal/Turquoise upper, Graphite lower)
        drawRoundRect(
            color = Color(0xFF00838F), // Teal Electric
            topLeft = Offset(w * 0.05f, h * 0.18f),
            size = Size(w * 0.90f, h * 0.35f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f)
        )
        drawRoundRect(
            color = Color(0xFF263238), // Graphite
            topLeft = Offset(w * 0.05f, h * 0.53f),
            size = Size(w * 0.90f, h * 0.20f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
        )

        // Panoramic Dark Glass Windows
        drawRect(Color(0xFF111111), topLeft = Offset(w * 0.10f, h * 0.23f), size = Size(w * 0.23f, h * 0.24f))
        drawRect(Color(0xFF111111), topLeft = Offset(w * 0.36f, h * 0.23f), size = Size(w * 0.23f, h * 0.24f))

        // Windshield (Curved front)
        val path = Path().apply {
            moveTo(w * 0.62f, h * 0.23f)
            lineTo(w * 0.86f, h * 0.23f)
            lineTo(w * 0.90f, h * 0.47f)
            lineTo(w * 0.62f, h * 0.47f)
            close()
        }
        drawPath(path, Color(0xFF111111))

        // Electric Badge (Green Lightning)
        val bolt = Path().apply {
            moveTo(w * 0.48f, h * 0.58f)
            lineTo(w * 0.52f, h * 0.58f)
            lineTo(w * 0.50f, h * 0.64f)
            lineTo(w * 0.54f, h * 0.64f)
            lineTo(w * 0.47f, h * 0.71f)
            lineTo(w * 0.49f, h * 0.65f)
            lineTo(w * 0.46f, h * 0.65f)
            close()
        }
        drawPath(bolt, Color(0xFF00E676))

        // Headlights
        drawCircle(Color(0xFFFFEB3B), radius = h * 0.03f, center = Offset(w * 0.91f, h * 0.60f))
    }
}

@Composable
fun MetroTrenNosVector(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Wheels
        drawCircle(Color(0xFF1E1E1E), radius = h * 0.12f, center = Offset(w * 0.18f, h * 0.84f))
        drawCircle(Color(0xFF1E1E1E), radius = h * 0.12f, center = Offset(w * 0.38f, h * 0.84f))
        drawCircle(Color(0xFF1E1E1E), radius = h * 0.12f, center = Offset(w * 0.62f, h * 0.84f))
        drawCircle(Color(0xFF1E1E1E), radius = h * 0.12f, center = Offset(w * 0.82f, h * 0.84f))

        // Train body (Graphite with Orange accent)
        drawRoundRect(
            color = Color(0xFF37474F), // dark graphite
            topLeft = Offset(w * 0.04f, h * 0.20f),
            size = Size(w * 0.92f, h * 0.56f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f)
        )

        // Copper-Brown/Nos Orange Accent
        drawRect(
            color = Color(0xFF8B5E3C), // Nos Earth tone
            topLeft = Offset(w * 0.04f, h * 0.54f),
            size = Size(w * 0.92f, h * 0.12f)
        )

        // Windows
        for (i in 0..4) {
            drawRect(
                color = Color(0xFF1A1A1A),
                topLeft = Offset(w * (0.08f + i * 0.17f), h * 0.28f),
                size = Size(w * 0.12f, h * 0.20f)
            )
        }

        // Connectors
        drawRect(Color(0xFF78909C), topLeft = Offset(0f, h * 0.40f), size = Size(w * 0.04f, h * 0.20f))
        drawRect(Color(0xFF78909C), topLeft = Offset(w * 0.96f, h * 0.40f), size = Size(w * 0.04f, h * 0.20f))
    }
}

@Composable
fun AndesCordilleraGraphic(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Background Sky (Soft blue/grey transition or flat clear sky)
        drawRect(Color(0xFFECEFF1), topLeft = Offset.Zero, size = size)

        // Grid lines (inspired by metro map vectors)
        for (i in 1..4) {
            drawLine(
                color = Color(0xFFCFD8DC),
                start = Offset(w * (i * 0.2f), 0f),
                end = Offset(w * (i * 0.2f), h),
                strokeWidth = 2f
            )
            drawLine(
                color = Color(0xFFCFD8DC),
                start = Offset(0f, h * (i * 0.2f)),
                end = Offset(w, h * (i * 0.2f)),
                strokeWidth = 2f
            )
        }

        // Metro lines going across
        drawLine(
            color = Color(0xFFE2231A), // Red stripe
            start = Offset(0f, h * 0.75f),
            end = Offset(w, h * 0.55f),
            strokeWidth = 8f
        )
        drawLine(
            color = Color(0xFF008E3A), // Green L5 stripe
            start = Offset(0f, h * 0.85f),
            end = Offset(w * 0.7f, h * 0.85f),
            strokeWidth = 8f
        )
        drawLine(
            color = Color(0xFF0072C6), // Blue L4 stripe
            start = Offset(w * 0.7f, h * 0.85f),
            end = Offset(w, h * 0.2f),
            strokeWidth = 8f
        )

        // Connection node dots
        drawCircle(Color.White, radius = 10f, center = Offset(w * 0.7f, h * 0.85f))
        drawCircle(Color(0xFF37474F), radius = 6f, center = Offset(w * 0.7f, h * 0.85f))

        // Mountains (Andes geometric silhouettes - layered grey shades for brutalist feel)
        val rearMountain = Path().apply {
            moveTo(0f, h * 0.90f)
            lineTo(w * 0.30f, h * 0.25f)
            lineTo(w * 0.45f, h * 0.45f)
            lineTo(w * 0.75f, h * 0.15f)
            lineTo(w * 0.90f, h * 0.35f)
            lineTo(w, h * 0.20f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(rearMountain, Color(0xFF90A4AE)) // Grey slate mountain

        val snowTopsRear = Path().apply {
            // Mountain peak 1
            moveTo(w * 0.26f, h * 0.33f)
            lineTo(w * 0.30f, h * 0.25f)
            lineTo(w * 0.34f, h * 0.33f)
            close()
            // Mountain peak 2
            moveTo(w * 0.72f, h * 0.21f)
            lineTo(w * 0.75f, h * 0.15f)
            lineTo(w * 0.78f, h * 0.21f)
            close()
        }
        drawPath(snowTopsRear, Color.White) // Snow peaks

        val frontMountain = Path().apply {
            moveTo(0f, h)
            lineTo(w * 0.15f, h * 0.65f)
            lineTo(w * 0.35f, h * 0.42f)
            lineTo(w * 0.60f, h * 0.68f)
            lineTo(w * 0.85f, h * 0.38f)
            lineTo(w, h * 0.55f)
            lineTo(w, h)
            close()
        }
        drawPath(frontMountain, Color(0xFF455A64)) // Concrete graphite grey mountain

        val snowTopsFront = Path().apply {
            // Front peak 1
            moveTo(w * 0.32f, h * 0.48f)
            lineTo(w * 0.35f, h * 0.42f)
            lineTo(w * 0.38f, h * 0.48f)
            close()
            // Front peak 2
            moveTo(w * 0.82f, h * 0.44f)
            lineTo(w * 0.85f, h * 0.38f)
            lineTo(w * 0.88f, h * 0.44f)
            close()
        }
        drawPath(snowTopsFront, Color(0xFFECEFF1)) // Soft white snow
    }
}
