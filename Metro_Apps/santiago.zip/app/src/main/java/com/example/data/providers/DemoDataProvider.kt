package com.example.data.providers

import com.example.core.model.*

object DemoDataProvider {

    val importantPlaces = listOf(
        ImportantPlace("aeropuerto", "Aeropuerto Arturo Merino Benítez", "AEROPUERTO", -33.3930, -70.7944, listOf("L1_Pajaritos", "CENTROPUERTO")),
        ImportantPlace("estacion_central", "Estación Central", "ESTACION", -33.4513, -70.6789, listOf("L1_Estacion_Central", "Nos_Estacion_Central")),
        ImportantPlace("u_de_chile", "Universidad de Chile", "CENTRO", -33.4442, -70.6508, listOf("L1_U_de_Chile", "L3_U_de_Chile")),
        ImportantPlace("baquedano", "Baquedano", "INTERMODAL", -33.4372, -70.6341, listOf("L1_Baquedano", "L5_Baquedano")),
        ImportantPlace("los_heroes", "Los Héroes", "INTERMODAL", -33.4485, -70.6601, listOf("L1_Los_Heroes", "L2_Los_Heroes")),
        ImportantPlace("tobalaba", "Tobalaba", "CENTRO", -33.4169, -70.6005, listOf("L1_Tobalaba", "L4_Tobalaba")),
        ImportantPlace("escuela_militar", "Escuela Militar", "CENTRO", -33.4111, -70.5815, listOf("L1_Escuela_Militar")),
        ImportantPlace("plaza_de_maipu", "Plaza de Maipú", "INTERMODAL", -33.5103, -70.7573, listOf("L5_Plaza_de_Maipu")),
        ImportantPlace("vicente_valdes", "Vicente Valdés", "INTERMODAL", -33.5239, -70.5976, listOf("L4_Vicente_Valdes", "L5_Vicente_Valdes")),
        ImportantPlace("plaza_puente_alto", "Plaza de Puente Alto", "INTERMODAL", -33.6111, -70.5759, listOf("L4_Plaza_de_Puente_Alto"))
    )

    val metroStations = listOf(
        // L1 Stations
        MetroStation("L1_San_Pablo", "San Pablo", "L1", 1, true, listOf("L5"), -33.4468, -70.7291),
        MetroStation("L1_Pajaritos", "Pajaritos", "L1", 2, true, emptyList(), -33.4533, -70.7241, "aeropuerto"),
        MetroStation("L1_San_Alberto", "San Alberto Hurtado", "L1", 3, true, emptyList(), -33.4528, -70.6917),
        MetroStation("L1_Estacion_Central", "Estación Central", "L1", 4, true, listOf("Nos"), -33.4513, -70.6789, "estacion_central"),
        MetroStation("L1_Los_Heroes", "Los Héroes", "L1", 5, true, listOf("L2"), -33.4485, -70.6601, "los_heroes"),
        MetroStation("L1_U_de_Chile", "Universidad de Chile", "L1", 6, true, listOf("L3"), -33.4442, -70.6508, "u_de_chile"),
        MetroStation("L1_Baquedano", "Baquedano", "L1", 7, true, listOf("L5"), -33.4372, -70.6341, "baquedano"),
        MetroStation("L1_Pedro_de_Valdivia", "Pedro de Valdivia", "L1", 8, true, emptyList(), -33.4241, -70.6112),
        MetroStation("L1_Tobalaba", "Tobalaba", "L1", 9, true, listOf("L4"), -33.4169, -70.6005, "tobalaba"),
        MetroStation("L1_Escuela_Militar", "Escuela Militar", "L1", 10, true, emptyList(), -33.4111, -70.5815, "escuela_militar"),

        // L2 Stations
        MetroStation("L2_La_Cisterna", "La Cisterna", "L2", 1, true, listOf("L4A"), -33.5372, -70.6639),
        MetroStation("L2_Franklin", "Franklin", "L2", 2, true, listOf("L6"), -33.4756, -70.6489),
        MetroStation("L2_Los_Heroes", "Los Héroes", "L2", 3, true, listOf("L1"), -33.4485, -70.6601, "los_heroes"),
        MetroStation("L2_Santa_Ana", "Santa Ana", "L2", 4, true, listOf("L5"), -33.4395, -70.6599),
        MetroStation("L2_Vespucio_Norte", "Vespucio Norte", "L2", 5, true, emptyList(), -33.3768, -70.6272),

        // L3 Stations
        MetroStation("L3_Los_Libertadores", "Los Libertadores", "L3", 1, true, emptyList(), -33.3611, -70.6789),
        MetroStation("L3_Plaza_Chacabuco", "Plaza Chacabuco", "L3", 2, true, emptyList(), -33.4111, -70.6577),
        MetroStation("L3_Cal_y_Canto", "Puente Cal y Canto", "L3", 3, true, listOf("L2"), -33.4332, -70.6511),
        MetroStation("L3_U_de_Chile", "Universidad de Chile", "L3", 4, true, listOf("L1"), -33.4442, -70.6508, "u_de_chile"),
        MetroStation("L3_Irarrazaval", "Irarrázaval", "L3", 5, true, listOf("L5"), -33.4542, -70.6272),
        MetroStation("L3_Plaza_Egana", "Plaza Egaña", "L3", 6, true, listOf("L4"), -33.4533, -70.5703),

        // L4 Stations
        MetroStation("L4_Tobalaba", "Tobalaba", "L4", 1, true, listOf("L1"), -33.4169, -70.6005, "tobalaba"),
        MetroStation("L4_Plaza_Egana", "Plaza Egaña", "L4", 2, true, listOf("L3"), -33.4533, -70.5703),
        MetroStation("L4_Macul", "Macul", "L4", 3, true, listOf("L4A"), -33.5133, -70.5991),
        MetroStation("L4_Vicente_Valdes", "Vicente Valdés", "L4", 4, true, listOf("L5"), -33.5239, -70.5976, "vicente_valdes"),
        MetroStation("L4_Plaza_de_Puente_Alto", "Plaza de Puente Alto", "L4", 5, true, emptyList(), -33.6111, -70.5759, "plaza_puente_alto"),

        // L4A Stations
        MetroStation("L4A_La_Cisterna", "La Cisterna", "L4A", 1, true, listOf("L2"), -33.5372, -70.6639),
        MetroStation("L4A_Santa_Rosa", "Santa Rosa", "L4A", 2, true, emptyList(), -33.5300, -70.6291),
        MetroStation("L4A_Vicuna_Mackenna", "Vicuña Mackenna", "L4A", 3, true, listOf("L4"), -33.5200, -70.5989),

        // L5 Stations
        MetroStation("L5_Plaza_de_Maipu", "Plaza de Maipú", "L5", 1, true, emptyList(), -33.5103, -70.7573, "plaza_de_maipu"),
        MetroStation("L5_Pudahuel", "Pudahuel", "L5", 2, true, emptyList(), -33.4472, -70.7501),
        MetroStation("L5_San_Pablo", "San Pablo", "L5", 3, true, listOf("L1"), -33.4468, -70.7291),
        MetroStation("L5_Santa_Ana", "Santa Ana", "L5", 4, true, listOf("L2"), -33.4395, -70.6599),
        MetroStation("L5_Baquedano", "Baquedano", "L5", 5, true, listOf("L1"), -33.4372, -70.6341, "baquedano"),
        MetroStation("L5_Irarrazaval", "Irarrázaval", "L5", 6, true, listOf("L3"), -33.4542, -70.6272),
        MetroStation("L5_Vicente_Valdes", "Vicente Valdés", "L5", 7, true, listOf("L4"), -33.5239, -70.5976, "vicente_valdes"),

        // L6 Stations
        MetroStation("L6_Cerrillos", "Cerrillos", "L6", 1, true, emptyList(), -33.4988, -70.7188),
        MetroStation("L6_Lo_Valledor", "Lo Valledor", "L6", 2, true, listOf("Nos"), -33.4764, -70.6828),
        MetroStation("L6_Franklin", "Franklin", "L6", 3, true, listOf("L2"), -33.4756, -70.6489),
        MetroStation("L6_Ines_de_Suarez", "Inés de Suárez", "L6", 4, true, emptyList(), -33.4411, -70.6011),
        MetroStation("L6_Los_Leones", "Los Leones", "L6", 5, true, listOf("L1"), -33.4222, -70.6091),

        // MetroTren Nos Stations
        MetroStation("Nos_Estacion_Central", "Estación Central", "Nos", 1, true, listOf("L1"), -33.4513, -70.6789, "estacion_central"),
        MetroStation("Nos_Lo_Valledor", "Lo Valledor", "Nos", 2, true, listOf("L6"), -33.4764, -70.6828),
        MetroStation("Nos_Pedro_Aguirre_Cerda", "Pedro Aguirre Cerda", "Nos", 3, true, emptyList(), -33.4912, -70.6855),
        MetroStation("Nos_San_Bernardo", "San Bernardo", "Nos", 4, true, emptyList(), -33.5919, -70.7061),
        MetroStation("Nos_Nos", "Nos", "Nos", 5, true, emptyList(), -33.6264, -70.7161)
    )

    val metroLines = listOf(
        MetroLine("L1", "Línea 1", "#E2231A", metroStations.filter { it.lineId == "L1" }),
        MetroLine("L2", "Línea 2", "#F47A20", metroStations.filter { it.lineId == "L2" }),
        MetroLine("L3", "Línea 3", "#7A2F8A", metroStations.filter { it.lineId == "L3" }),
        MetroLine("L4", "Línea 4", "#0072C6", metroStations.filter { it.lineId == "L4" }),
        MetroLine("L4A", "Línea 4A", "#00A3E0", metroStations.filter { it.lineId == "L4A" }),
        MetroLine("L5", "Línea 5", "#008E3A", metroStations.filter { it.lineId == "L5" }),
        MetroLine("L6", "Línea 6", "#612E8B", metroStations.filter { it.lineId == "L6" }),
        MetroLine("Nos", "MetroTren Nos", "#8B5E3C", metroStations.filter { it.lineId == "Nos" })
    )

    val paraderos = listOf(
        Paradero("PC183", "Providencia / Pedro de Valdivia", "Al Oriente", listOf("405", "412", "418", "426"), -33.4243, -70.6111),
        Paradero("PC184", "Tobalaba / Providencia", "Al Sur", listOf("405", "426"), -33.4172, -70.6001),
        Paradero("PA342", "Alameda / Universidad de Chile", "Al Poniente", listOf("506", "210"), -33.4444, -70.6506),
        Paradero("PA370", "Plaza Italia / Baquedano", "Al Oriente", listOf("405", "210"), -33.4373, -70.6340),
        Paradero("PI340", "Alameda / Estación Central", "Al Poniente", listOf("210", "405", "506"), -33.4515, -70.6787),
        Paradero("PI181", "Plaza de Maipú", "Al Sur", listOf("506"), -33.5105, -70.7571),
        Paradero("PC190", "Apoquindo / Escuela Militar", "Al Oriente", listOf("405", "426"), -33.4113, -70.5813),
        Paradero("PE123", "Vicuña Mackenna / Vicente Valdés", "Al Sur", listOf("210"), -33.5241, -70.5974)
    )

    val busRoutes = listOf(
        BusRoute(
            id = "405",
            name = "Cantagallo - Plaza de Maipú",
            shortName = "405",
            colorHex = "#D32F2F",
            type = VehicleType.BUS_ELECTRICO,
            stops = listOf("PC190", "PC183", "PC184", "PA370", "PI340")
        ),
        BusRoute(
            id = "210",
            name = "Estación Central - Puente Alto",
            shortName = "210",
            colorHex = "#1976D2",
            type = VehicleType.BUS_URBANO,
            stops = listOf("PI340", "PA342", "PA370", "PE123")
        ),
        BusRoute(
            id = "506",
            name = "Peñalolén - Maipú",
            shortName = "506",
            colorHex = "#388E3C",
            type = VehicleType.BUS_URBANO,
            stops = listOf("PI181", "PI340", "PA342")
        )
    )

    // Demo Service Incidents
    val initialIncidents = listOf(
        ServiceIncident(
            id = "inc_01",
            severity = IncidentSeverity.MEDIA,
            affectedLine = "L5",
            affectedStation = "L5_Baquedano",
            startTime = "07:30",
            expectedEnd = "11:00",
            description = "Contención de andenes en estación Baquedano debido a alta afluencia de pasajeros en combinación.",
            alternativeRoute = "Prefiere combinar en estación Santa Ana (L2/L5) o Franklin (L2/L6) para evitar transbordos retrasados en Baquedano."
        ),
        ServiceIncident(
            id = "inc_02",
            severity = IncidentSeverity.BAJA,
            affectedLine = "L1",
            affectedStation = "L1_San_Alberto",
            startTime = "08:15",
            expectedEnd = "09:30",
            description = "Falla de escalera mecánica en acceso norte. Personal técnico trabajando.",
            alternativeRoute = "Utilice ascensores preferenciales si viaja con coche o movilidad reducida."
        )
    )
}
