package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.TransportViewModel
import com.example.ui.components.borderStroke
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BipTab(viewModel: TransportViewModel) {
    var sectionIndex by remember { mutableStateOf(0) } // 0 = MI BIP, 1 = BIP QR, 2 = TARIFAS

    val cards by viewModel.bipCards.collectAsState()
    val selectedCardNum by viewModel.selectedBipCardNumber.collectAsState()
    val transactions by viewModel.selectedBipCardTransactions.collectAsState()
    val activeQr by viewModel.activeQr.collectAsState()

    val rechargeAmount by viewModel.rechargeAmountOption.collectAsState()
    val rechargeState by viewModel.isRechargingState.collectAsState()

    val activeCard = cards.find { it.cardNumber == selectedCardNum }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Tab Row selector
        TabRow(
            selectedTabIndex = sectionIndex,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(selected = sectionIndex == 0, onClick = { sectionIndex = 0 }) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CreditCard, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("MI BIP!", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
            Tab(selected = sectionIndex == 1, onClick = { sectionIndex = 1 }) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.QrCode, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("BIP! QR", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
            Tab(selected = sectionIndex == 2, onClick = { sectionIndex = 2 }) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Sell, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("TARIFAS", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (sectionIndex) {
            0 -> {
                // MI BIP SECTION
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (cards.isEmpty()) {
                        item {
                            EmptyBipCardPlaceholder(viewModel)
                        }
                    } else {
                        // Card selector / spinner
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("SELECCIONAR TARJETA:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(modifier = Modifier.weight(1f)) {
                                        var expanded by remember { mutableStateOf(false) }
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(44.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                                .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                                .clickable { expanded = true }
                                                .padding(horizontal = 12.dp),
                                            contentAlignment = Alignment.CenterStart
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = activeCard?.let { "${it.cardName} (${it.cardNumber})" } ?: "Selecciona tarjeta",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                            }
                                        }

                                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                            cards.forEach { c ->
                                                DropdownMenuItem(
                                                    text = { Text("${c.cardName} [${c.cardNumber}]") },
                                                    onClick = {
                                                        viewModel.selectedBipCardNumber.value = c.cardNumber
                                                        expanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    IconButton(
                                        onClick = { viewModel.deleteSelectedBipCard() },
                                        modifier = Modifier.size(44.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }

                        // Render beautiful physical-looking BIP card
                        if (activeCard != null) {
                            item {
                                BipCardGraphics(card = activeCard)
                            }

                            // Interactive recharge panel
                            item {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                                        .border(1.dp, Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("RECARGA DE DEMOSTRACIÓN", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                                    if (rechargeState == null) {
                                        // Selector options
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            listOf(2000, 5000, 10000).forEach { amt ->
                                                val isSelected = rechargeAmount == amt
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(40.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                                        .border(1.dp, if (isSelected) Color.Transparent else Color.LightGray, RoundedCornerShape(8.dp))
                                                        .clickable { viewModel.rechargeAmountOption.value = amt },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        "$$amt",
                                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Button(
                                                onClick = { viewModel.initiateRechargeFlow() },
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Recarga remota (banco)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = { viewModel.directWebRecharge() },
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Recarga directa web", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    } else {
                                        // Recharge state flow visualization
                                        Column(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = when (rechargeState) {
                                                        "CONFIRMAR" -> "Confirmando monto..."
                                                        "PROCESANDO" -> "Procesando pago de seguridad..."
                                                        "PENDIENTE" -> "Carga procesada. Pendiente de VALIDACIÓN EN TÓTEM."
                                                        "VALIDADA" -> "¡CARGA VALIDADA CON ÉXITO! Saldo actualizado."
                                                        else -> "Registrando..."
                                                    },
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }

                                            if (rechargeState == "CONFIRMAR") {
                                                Text("Por favor confirme la transacción simulada de $$rechargeAmount pesos.", fontSize = 11.sp)
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Button(onClick = { viewModel.confirmRecharge() }, modifier = Modifier.weight(1f)) {
                                                        Text("Confirmar")
                                                    }
                                                    TextButton(onClick = { viewModel.resetRechargeState() }, modifier = Modifier.weight(1f)) {
                                                        Text("Cancelar")
                                                    }
                                                }
                                            }

                                            if (rechargeState == "PENDIENTE") {
                                                Text(
                                                    "En Santiago, algunas recargas remotas requieren que apoyes físicamente la tarjeta en un Tótem del Metro para que impacte el saldo.",
                                                    fontSize = 11.sp,
                                                    color = Color.DarkGray
                                                )
                                                Button(
                                                    onClick = { viewModel.simulateTotemValidation() },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF008E3A)),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(Icons.Default.TouchApp, contentDescription = null)
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                        Text("SIMULAR APOYAR TARJETA EN TÓTEM (VALIDAR)", fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }

                                            if (rechargeState == "VALIDADA") {
                                                Button(onClick = { viewModel.resetRechargeState() }, modifier = Modifier.fillMaxWidth()) {
                                                    Text("Finalizar")
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Transactions History
                            item {
                                Text(
                                    text = "HISTORIAL RECIENTE:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }

                            if (transactions.isEmpty()) {
                                item {
                                    Text("No hay movimientos registrados para esta tarjeta.", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
                                }
                            } else {
                                items(transactions) { tx ->
                                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(tx.timestamp))
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(tx.description, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                Text(dateStr, fontSize = 10.sp, color = Color.Gray)
                                            }

                                            Text(
                                                text = if (tx.type == "RECARGA") "+ $${tx.amount}" else "- $${tx.amount}",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 14.sp,
                                                color = if (tx.type == "RECARGA") Color(0xFF008E3A) else Color.Black
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Card addition expander
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            var expandedAdd by remember { mutableStateOf(false) }
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { expandedAdd = !expandedAdd },
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("AÑADIR OTRA TARJETA BIP!", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Icon(if (expandedAdd) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
                                }

                                if (expandedAdd) {
                                    val newNum by viewModel.newCardNumber.collectAsState()
                                    val newName by viewModel.newCardName.collectAsState()

                                    Spacer(modifier = Modifier.height(12.dp))

                                    TextField(
                                        value = newNum,
                                        onValueChange = { viewModel.newCardNumber.value = it },
                                        placeholder = { Text("Número de tarjeta (Ej: 1122 3344)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    TextField(
                                        value = newName,
                                        onValueChange = { viewModel.newCardName.value = it },
                                        placeholder = { Text("Nombre personalizado (Ej: Bip Trabajo)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Button(
                                        onClick = {
                                            viewModel.addBipCard()
                                            expandedAdd = false
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("Registrar Tarjeta", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
            1 -> {
                // BIP QR SECTION
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    "CÓDIGO DE DEMOSTRACIÓN",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    "La generación de códigos bip! QR simula de manera visual y lógica el pago electrónico en el transporte de Santiago. El saldo se deducirá de tu tarjeta seleccionada.",
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    if (activeQr == null) {
                        item {
                            Button(
                                onClick = { viewModel.generateBipQr() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.QrCode, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("GENERAR CÓDIGO QR BIP!", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else {
                        val qr = activeQr!!
                        item {
                            Card(
                                modifier = Modifier
                                    .width(260.dp)
                                    .border(1.dp, Color.LightGray, RoundedCornerShape(16.dp)),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        text = qr.state.name,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp,
                                        color = when (qr.state) {
                                            QrState.ACTIVO -> Color(0xFF008E3A)
                                            QrState.UTILIZADO -> Color.Gray
                                            QrState.EXPIRADO -> Color.Red
                                            else -> Color.Black
                                        }
                                    )

                                    // Simulated QR graphic box with lines
                                    Box(
                                        modifier = Modifier
                                            .size(160.dp)
                                            .background(Color.White)
                                            .border(4.dp, Color.Black)
                                            .padding(12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        // Simple procedural aesthetic QR drawing inside
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color.Black.copy(alpha = 0.05f))
                                        ) {
                                            // 4 corner blocks
                                            Box(modifier = Modifier.size(36.dp).background(Color.Black).align(Alignment.TopStart))
                                            Box(modifier = Modifier.size(36.dp).background(Color.Black).align(Alignment.TopEnd))
                                            Box(modifier = Modifier.size(36.dp).background(Color.Black).align(Alignment.BottomStart))
                                            // inner white blocks
                                            Box(modifier = Modifier.size(20.dp).background(Color.White).align(Alignment.TopStart).padding(8.dp))
                                            Box(modifier = Modifier.size(20.dp).background(Color.White).align(Alignment.TopEnd).padding(8.dp))
                                            Box(modifier = Modifier.size(20.dp).background(Color.White).align(Alignment.BottomStart).padding(8.dp))
                                        }
                                    }

                                    if (qr.state == QrState.ACTIVO) {
                                        val remainingSecs = ((qr.expiresAt - System.currentTimeMillis()) / 1000).coerceAtLeast(0)
                                        Text(
                                            "Expira en: $remainingSecs seg",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        LinearProgressIndicator(
                                            progress = (remainingSecs / 120f).coerceIn(0f, 1f),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }

                        if (qr.state == QrState.ACTIVO) {
                            item {
                                Button(
                                    onClick = { viewModel.useActiveQrCode() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F4C81)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.SensorWindow, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("SIMULAR ESCANEAR EN TORNUQUETE DE METRO/BUS", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        item {
                            Button(
                                onClick = { viewModel.generateBipQr() },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text("Generar otro código QR", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
            2 -> {
                // TARIFAS SECTION
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("TARIFA DE DEMOSTRACIÓN", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text("Las tarifas en el transporte de Santiago se regulan por tramos horarios (bajo, valle, punta). Los buses mantienen tarifa plana todo el día, mientras que Metro y MetroTren fluctúan.", fontSize = 12.sp)
                                Divider(modifier = Modifier.padding(vertical = 4.dp))

                                FareBandRow("Horario Bajo (06:00 - 06:29 / 20:45 - 23:00)", "$640", "$730")
                                FareBandRow("Horario Valle (06:30 - 06:59 / 09:00 - 17:59)", "$750", "$730")
                                FareBandRow("Horario Punta (07:00 - 08:59 / 18:00 - 19:59)", "$830", "$730")
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("REGLAS DE INTEGRACIÓN TARIFARIA", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text("• Ventana de tiempo: Cuentas con 120 minutos (2 horas) desde la primera validación para realizar hasta 2 transbordos libres.", fontSize = 12.sp)
                                Text("• Transbordo Bus-Bus o Bus-Metro: El costo del transbordo es $0 costo adicional, siempre que no entres en combinación horaria de mayor costo (ej. pasar de horario bajo a punta en Metro, donde pagarías la diferencia de $100).", fontSize = 12.sp)
                                Text("• Transbordo Metro-Metro: No hay cobro adicional en transbordo entre andenes internos de Metro.", fontSize = 12.sp)
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Sujeto a tarifas de demostración vigentes al 2026. La aplicación no gestiona transacciones bancarias reales.", fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }
}

@Composable
fun EmptyBipCardPlaceholder(viewModel: TransportViewModel) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
            Spacer(modifier = Modifier.height(10.dp))
            Text("No tienes tarjetas registradas", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Añade una tarjeta bip! simulada a continuación para poder recargar, pagar con QR y revisar tus movimientos.", fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun BipCardGraphics(card: BipCard) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0F4C81)) // Blue corporate Bip! card look
            .padding(20.dp)
    ) {
        // Aesthetic patterns on bip card
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "bip!",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFFE2231A))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("DEMO", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Column {
                Text("SALDO DE DEMOSTRACIÓN:", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
                Text(
                    text = "$${card.balance}",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    card.cardName,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    card.cardNumber,
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun FareBandRow(band: String, metro: String, bus: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(band, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text("Metro: $metro", fontSize = 11.sp, color = Color.Gray)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Bus: $bus", fontSize = 11.sp, color = Color.Gray)
    }
}


