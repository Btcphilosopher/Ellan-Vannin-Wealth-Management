package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = RedMetro,
    onPrimary = Color.White,
    secondary = BlueSantiago,
    onSecondary = Color.White,
    tertiary = CopperNos,
    background = GraphiteDark,
    onBackground = Color(0xFFECEFF1),
    surface = Color(0xFF37474F),
    onSurface = Color(0xFFECEFF1),
    error = RedMetro
)

private val LightColorScheme = lightColorScheme(
    primary = RedMetro,
    onPrimary = Color.White,
    secondary = BlueSantiago,
    onSecondary = Color.White,
    tertiary = CopperNos,
    background = WarmWhite,
    onBackground = SoftBlack,
    surface = Color.White,
    onSurface = SoftBlack,
    error = RedMetroDark,
    surfaceVariant = ConcreteGray,
    onSurfaceVariant = GraphiteDark
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
