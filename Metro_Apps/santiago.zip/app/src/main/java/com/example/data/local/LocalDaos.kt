package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TransportDao {

    // --- Favorites ---
    @Query("SELECT * FROM favorites ORDER BY timestamp DESC")
    fun getAllFavorites(): Flow<List<FavoriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE id = :id")
    suspend fun deleteFavoriteById(id: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE id = :id)")
    suspend fun isFavoriteExists(id: String): Boolean

    // --- Bip Cards ---
    @Query("SELECT * FROM bip_cards")
    fun getAllBipCards(): Flow<List<BipCardEntity>>

    @Query("SELECT * FROM bip_cards WHERE cardNumber = :cardNumber")
    suspend fun getBipCard(cardNumber: String): BipCardEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBipCard(card: BipCardEntity)

    @Query("UPDATE bip_cards SET balance = :balance, lastUpdated = :lastUpdated WHERE cardNumber = :cardNumber")
    suspend fun updateBipCardBalance(cardNumber: String, balance: Int, lastUpdated: Long)

    @Query("DELETE FROM bip_cards WHERE cardNumber = :cardNumber")
    suspend fun deleteBipCard(cardNumber: String)

    // --- Bip Transactions ---
    @Query("SELECT * FROM bip_transactions WHERE cardNumber = :cardNumber ORDER BY timestamp DESC")
    fun getTransactionsForCard(cardNumber: String): Flow<List<BipTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: BipTransactionEntity)

    // --- Simulation Config ---
    @Query("SELECT * FROM simulation_config WHERE id = 0")
    suspend fun getSimulationConfig(): SimulationConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSimulationConfig(config: SimulationConfigEntity)

    // --- Recent Routes ---
    @Query("SELECT * FROM recent_routes ORDER BY timestamp DESC LIMIT 10")
    fun getRecentRoutes(): Flow<List<RecentRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentRoute(route: RecentRouteEntity)

    @Query("DELETE FROM recent_routes WHERE id = :id")
    suspend fun deleteRecentRoute(id: String)
}
