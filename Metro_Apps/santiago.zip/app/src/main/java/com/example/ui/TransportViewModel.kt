package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.*
import com.example.core.routing.RoutePreference
import com.example.core.routing.RouteResult
import com.example.core.simulation.SimulationState
import com.example.core.simulation.TransportSimulator
import com.example.data.local.FavoriteEntity
import com.example.data.local.RecentRouteEntity
import com.example.data.providers.DemoDataProvider
import com.example.data.repository.TransportRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

class TransportViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TransportRepository.getInstance(application)

    // --- Tab Navigation ---
    private val _activeTab = MutableStateFlow(0) // 0 = INICIO, 1 = MAPA, 2 = RUTAS, 3 = BIP!, 4 = MÁS
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    // --- Search & Routes ---
    val searchFromId = MutableStateFlow("")
    val searchToId = MutableStateFlow("")
    private val _calculatedRoutes = MutableStateFlow<List<RouteResult>>(emptyList())
    val calculatedRoutes: StateFlow<List<RouteResult>> = _calculatedRoutes.asStateFlow()

    private val _selectedRouteResult = MutableStateFlow<RouteResult?>(null)
    val selectedRouteResult: StateFlow<RouteResult?> = _selectedRouteResult.asStateFlow()

    // --- Bip! Cards ---
    val bipCards: StateFlow<List<BipCard>> = repository.getBipCards()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedBipCardNumber = MutableStateFlow("")
    val selectedBipCardTransactions = selectedBipCardNumber
        .flatMapLatest { cardNumber ->
            if (cardNumber.isNotEmpty()) repository.getTransactions(cardNumber)
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val newCardNumber = MutableStateFlow("")
    val newCardName = MutableStateFlow("")

    val rechargeAmountOption = MutableStateFlow(5000)
    val customRechargeAmount = MutableStateFlow("")
    val isRechargingState = MutableStateFlow<String?>(null) // "SELECCIONAR", "CONFIRMAR", "PROCESANDO", "REGISTRADA", "PENDIENTE", "VALIDADA"
    val pendingRechargeTxId = MutableStateFlow<String?>(null)

    val activeQr: StateFlow<BipQrCode?> = repository.activeQr

    // --- Favorites & Recent Routes ---
    val favorites: StateFlow<List<FavoriteEntity>> = repository.getFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentRoutes: StateFlow<List<RecentRouteEntity>> = repository.getRecentRoutes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Simulator Sync ---
    val vehicles: StateFlow<List<Vehicle>> = TransportSimulator.vehicles
    val incidents: StateFlow<List<ServiceIncident>> = TransportSimulator.incidents
    val simulationState: StateFlow<SimulationState> = TransportSimulator.simState
    val eventLog: StateFlow<List<String>> = TransportSimulator.eventLog

    // --- Active Journey Navigation ---
    val activeJourney: StateFlow<RouteResult?> = repository.activeJourney
    val currentJourneySegmentIndex: StateFlow<Int> = repository.currentJourneySegmentIndex

    // --- Details Views (Selected item inspectors) ---
    val selectedMetroLineId = MutableStateFlow<String?>("L1")
    val selectedMetroStationId = MutableStateFlow<String?>("L1_Baquedano")
    val selectedParaderoId = MutableStateFlow<String?>("PC183")

    // --- Airport Mode Settings ---
    val isAirportFromMode = MutableStateFlow(true) // true = Ir al Aeropuerto, false = Salir del Aeropuerto

    // --- Map Configuration ---
    val mapZoom = MutableStateFlow(12.0f)
    val mapOffsetX = MutableStateFlow(0.0f)
    val mapOffsetY = MutableStateFlow(0.0f)
    val mapSearchQuery = MutableStateFlow("")

    // Map Layer Toggles
    val showLayerMetro = MutableStateFlow(true)
    val showLayerBuses = MutableStateFlow(true)
    val showLayerNos = MutableStateFlow(true)
    val showLayerParaderos = MutableStateFlow(true)
    val showLayerEstaciones = MutableStateFlow(true)
    val showLayerIncidencias = MutableStateFlow(true)

    // Simulating GPS location permission and center
    val hasLocationPermission = MutableStateFlow(true)
    val userLat = MutableStateFlow(-33.4442) // Centered on U de Chile
    val userLng = MutableStateFlow(-70.6508)

    // --- Developer Tools Controls ---
    val devVehicleDelayId = MutableStateFlow("")
    val devVehicleDelaySecs = MutableStateFlow("30")

    val devIncidentLineId = MutableStateFlow("L1")
    val devIncidentStationId = MutableStateFlow("L1_Baquedano")
    val devIncidentDesc = MutableStateFlow("Falla mecánica en andén")

    val reportsCategory = MutableStateFlow("Bus lleno")
    val reportsComment = MutableStateFlow("")
    val isReportSubmitted = MutableStateFlow(false)

    init {
        // Auto-select first bip card when list is loaded
        viewModelScope.launch {
            bipCards.collect { list ->
                if (list.isNotEmpty() && selectedBipCardNumber.value.isEmpty()) {
                    selectedBipCardNumber.value = list.first().cardNumber
                }
            }
        }
    }

    // --- Screen Actions ---
    fun setTab(index: Int) {
        _activeTab.value = index
    }

    fun doCalculateRoutes() {
        val from = searchFromId.value
        val to = searchToId.value
        if (from.isNotEmpty() && to.isNotEmpty()) {
            val results = repository.calculateRoutes(from, to)
            _calculatedRoutes.value = results
            _selectedRouteResult.value = results.find { it.preference == RoutePreference.MAS_RAPIDA }
            viewModelScope.launch {
                val fromName = DemoDataProvider.metroStations.find { it.id == from }?.name
                    ?: DemoDataProvider.paraderos.find { it.id == from }?.name
                    ?: DemoDataProvider.importantPlaces.find { it.id == from }?.name ?: from
                val toName = DemoDataProvider.metroStations.find { it.id == to }?.name
                    ?: DemoDataProvider.paraderos.find { it.id == to }?.name
                    ?: DemoDataProvider.importantPlaces.find { it.id == to }?.name ?: to
                repository.addRecentRoute(from, fromName, to, toName)
            }
        }
    }

    fun selectRoute(route: RouteResult) {
        _selectedRouteResult.value = route
    }

    fun startJourney() {
        val selected = _selectedRouteResult.value
        if (selected != null) {
            repository.startActiveJourney(selected)
            setTab(4) // Redirect to "MÁS" or custom screen to view travel
        }
    }

    fun advanceJourney() {
        repository.advanceJourneySegment()
    }

    fun cancelJourney() {
        repository.endActiveJourney()
    }

    // --- Favorites ---
    fun toggleFavorite(id: String, name: String, type: String) {
        viewModelScope.launch {
            if (repository.isFavorite(id)) {
                repository.removeFavorite(id)
            } else {
                repository.addFavorite(id, name, type)
            }
        }
    }

    fun isItemFavorite(id: String): Flow<Boolean> = flow {
        emit(repository.isFavorite(id))
    }

    // --- Bip Operations ---
    fun addBipCard() {
        val num = newCardNumber.value.trim()
        val name = newCardName.value.trim().ifEmpty { "Tarjeta bip!" }
        if (num.isNotEmpty()) {
            viewModelScope.launch {
                repository.addNewBipCard(num, name)
                selectedBipCardNumber.value = num
                newCardNumber.value = ""
                newCardName.value = ""
            }
        }
    }

    fun deleteSelectedBipCard() {
        val cardNum = selectedBipCardNumber.value
        if (cardNum.isNotEmpty()) {
            viewModelScope.launch {
                repository.deleteBipCard(cardNum)
                selectedBipCardNumber.value = ""
            }
        }
    }

    fun initiateRechargeFlow() {
        isRechargingState.value = "CONFIRMAR"
    }

    fun confirmRecharge() {
        val num = selectedBipCardNumber.value
        val amt = rechargeAmountOption.value
        if (num.isNotEmpty()) {
            isRechargingState.value = "PROCESANDO"
            viewModelScope.launch {
                val txId = repository.requestBipTopUp(num, amt)
                pendingRechargeTxId.value = txId
                delay(1500) // Simulating payment gateway
                isRechargingState.value = "PENDIENTE"
            }
        }
    }

    fun simulateTotemValidation() {
        val num = selectedBipCardNumber.value
        val txId = pendingRechargeTxId.value
        if (num.isNotEmpty() && txId != null) {
            isRechargingState.value = "PROCESANDO"
            viewModelScope.launch {
                delay(1000)
                repository.validateBipTopUp(num, txId)
                isRechargingState.value = "VALIDADA"
                pendingRechargeTxId.value = null
            }
        }
    }

    fun directWebRecharge() {
        val num = selectedBipCardNumber.value
        val amt = rechargeAmountOption.value
        if (num.isNotEmpty()) {
            isRechargingState.value = "PROCESANDO"
            viewModelScope.launch {
                delay(1500)
                repository.directTopUp(num, amt)
                isRechargingState.value = "VALIDADA"
            }
        }
    }

    fun resetRechargeState() {
        isRechargingState.value = null
    }

    // --- QR Operations ---
    fun generateBipQr() {
        val num = selectedBipCardNumber.value
        if (num.isNotEmpty()) {
            repository.generateBipQr(num)
        }
    }

    fun useActiveQrCode() {
        val num = selectedBipCardNumber.value
        if (num.isNotEmpty()) {
            viewModelScope.launch {
                repository.useBipQr(num)
            }
        }
    }

    // --- Simulator Operations ---
    fun togglePlayPauseSim() {
        val playing = simulationState.value.isPlaying
        if (playing) {
            TransportSimulator.pauseSimulation()
        } else {
            TransportSimulator.startSimulation()
        }
    }

    fun changeSimMultiplier(mult: Int) {
        TransportSimulator.setSpeedMultiplier(mult)
    }

    fun injectDelayToVehicle() {
        val vId = devVehicleDelayId.value
        val delaySecs = devVehicleDelaySecs.value.toIntOrNull() ?: 30
        if (vId.isNotEmpty()) {
            TransportSimulator.injectDelay(vId, delaySecs)
        }
    }

    fun injectIncidentOnNetwork() {
        val line = devIncidentLineId.value
        val stat = devIncidentStationId.value
        val desc = devIncidentDesc.value
        if (desc.isNotEmpty()) {
            TransportSimulator.injectIncident(line, stat, desc)
        }
    }

    fun resolveLiveIncident(id: String) {
        TransportSimulator.resolveIncident(id)
    }

    // --- Report Problem (Demo) ---
    fun submitReport() {
        val cat = reportsCategory.value
        val comment = reportsComment.value
        isReportSubmitted.value = true
        TransportSimulator.logEvent("USER_REPORT", "Reporte usuario: $cat - $comment")
        viewModelScope.launch {
            delay(2000)
            isReportSubmitted.value = false
            reportsComment.value = ""
        }
    }

    // --- Navigation Helpers ---
    fun setMapTarget(fromId: String, toId: String) {
        searchFromId.value = fromId
        searchToId.value = toId
        doCalculateRoutes()
        setTab(2) // Switch to Routes tab
    }
}
