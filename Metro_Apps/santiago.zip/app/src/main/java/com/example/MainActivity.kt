package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.ui.TransportViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val viewModel = remember { TransportViewModel(application) }
        val activeTab by viewModel.activeTab.collectAsState()

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          bottomBar = {
            NavigationBar {
              NavigationBarItem(
                selected = activeTab == 0,
                onClick = { viewModel.setTab(0) },
                icon = { Icon(Icons.Default.Home, contentDescription = "Inicio") },
                label = { Text("Inicio") },
                modifier = Modifier.testTag("nav_inicio")
              )
              NavigationBarItem(
                selected = activeTab == 1,
                onClick = { viewModel.setTab(1) },
                icon = { Icon(Icons.Default.Map, contentDescription = "Mapa") },
                label = { Text("Mapa") },
                modifier = Modifier.testTag("nav_mapa")
              )
              NavigationBarItem(
                selected = activeTab == 2,
                onClick = { viewModel.setTab(2) },
                icon = { Icon(Icons.Default.Navigation, contentDescription = "Rutas") },
                label = { Text("Rutas") },
                modifier = Modifier.testTag("nav_rutas")
              )
              NavigationBarItem(
                selected = activeTab == 3,
                onClick = { viewModel.setTab(3) },
                icon = { Icon(Icons.Default.Payment, contentDescription = "Bip!") },
                label = { Text("Bip!") },
                modifier = Modifier.testTag("nav_bip")
              )
              NavigationBarItem(
                selected = activeTab == 4,
                onClick = { viewModel.setTab(4) },
                icon = { Icon(Icons.Default.Settings, contentDescription = "Más") },
                label = { Text("Más") },
                modifier = Modifier.testTag("nav_mas")
              )
            }
          }
        ) { innerPadding ->
          Box(modifier = Modifier.padding(innerPadding)) {
            when (activeTab) {
              0 -> InicioTab(viewModel)
              1 -> MapaTab(viewModel)
              2 -> RutasTab(viewModel)
              3 -> BipTab(viewModel)
              4 -> MasTab(viewModel)
            }
          }
        }
      }
    }
  }
}
