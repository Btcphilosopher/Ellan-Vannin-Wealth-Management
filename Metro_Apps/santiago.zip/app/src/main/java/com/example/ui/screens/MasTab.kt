package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.core.simulation.TransportSimulator
import com.example.data.providers.DemoDataProvider
import com.example.ui.TransportViewModel
import com.example.ui.components.borderStroke

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MasTab(viewModel: TransportViewModel) {
    var configSection by remember { mutableStateOf(0) } // 0 = ESTADO RED, 1 = REPORTAR, 2 = MI VIAJE, 3 = DESARROLLADOR

    val incidents by viewModel.incidents.collectAsState()
    val eventLog by viewModel.eventLog.collectAsState()
    val activeJourney by viewModel.activeJourney.collectAsState()
    val currentSegmentIndex by viewModel.currentJourneySegmentIndex.collectAsState()

    // Simulation controls sync
    val simState by viewModel.simulationState.collectAsState()
    val simPaused = !simState.isPlaying
    val simMultiplier = simState.speedMultiplier

    // Reporting state
    var selectedReportLine by remember { mutableStateOf("L1") }
    var reportComment by remember { mutableStateOf("") }
    var reportSuccessMsg by remember { mutableStateOf<String?>(null) }

    val lineOptions = DemoDataProvider.metroLines.map { it.id } + DemoDataProvider.busRoutes.map { it.id }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Horizontal Secondary Menu Scroll
        ScrollableTabRow(
            selectedTabIndex = configSection,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
            edgePadding = 16.dp
        ) {
            Tab(selected = configSection == 0, onClick = { configSection = 0 }) {
                Text("ESTADO RED", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Tab(selected = configSection == 1, onClick = { configSection = 1 }) {
                Text("REPORTAR ⚠", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Tab(selected = configSection == 2, onClick = { configSection = 2 }) {
                Text("MI VIAJE", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Tab(selected = configSection == 3, onClick = { configSection = 3 }) {
                Text("DESARROLLADOR 🛠", modifier = Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        when (configSection) {
            0 -> {
                // ESTADO RED SECTION
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = "ESTADO OPERACIONAL EN TIEMPO REAL",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                        )
                    }

                    // Render list of lines state
                    items(DemoDataProvider.metroLines) { line ->
                        val lineCol = Color(android.graphics.Color.parseColor(line.hexColor))
                        val lineIncidents = incidents.filter { it.affectedLine == line.id }
                        val isNormal = lineIncidents.isEmpty()

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(lineCol),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(line.id, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column {
                                            Text(line.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text(
                                                text = if (isNormal) "Operación habitual" else "${lineIncidents.size} anomalía(s) reportada(s)",
                                                fontSize = 11.sp,
                                                color = if (isNormal) Color(0xFF008E3A) else Color(0xFFF57C00)
                                            )
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (isNormal) Color(0xFFE8F5E9) else Color(0xFFFFF3E0))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = if (isNormal) "NORMAL" else "ALERTAS",
                                            color = if (isNormal) Color(0xFF008E3A) else Color(0xFFF57C00),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                if (!isNormal) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    lineIncidents.forEach { incident ->
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF9C4)),
                                            modifier = Modifier.padding(vertical = 4.dp)
                                        ) {
                                            Column(modifier = Modifier.padding(8.dp)) {
                                                Text(
                                                    "⚠ ${incident.description}",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.Black
                                                )
                                                if (incident.affectedStation != null) {
                                                    Text(
                                                        "Afecta a: ${incident.affectedStation}",
                                                        fontSize = 10.sp,
                                                        color = Color.DarkGray
                                                    )
                                                }
                                                Text(
                                                    "Alternativa: ${incident.alternativeRoute}",
                                                    fontSize = 10.sp,
                                                    color = Color.DarkGray
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "HISTORIAL DE EVENTOS RECIENTES:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    if (eventLog.isEmpty()) {
                        item {
                            Text("No se han registrado eventos en la red aún.", fontSize = 12.sp, color = Color.Gray)
                        }
                    } else {
                        items(eventLog.take(15)) { logLine ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Row(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        logLine,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
            1 -> {
                // REPORTAR SITUACIÓN SECTION
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Text(
                            text = "REPORTAR ALERTA PASAJERO",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                        )
                        Text(
                            text = "Tu reporte ciudadano ayuda a inyectar novedades al sistema en tiempo real. Se reflejará automáticamente en la simulación y en el mapa.",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }

                    // Form: Line Selection
                    item {
                        var lineExpanded by remember { mutableStateOf(false) }
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("LÍNEA O RECORRIDO AFECTADO:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .clickable { lineExpanded = true }
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedReportLine, fontWeight = FontWeight.Bold)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            }

                            DropdownMenu(expanded = lineExpanded, onDismissRequest = { lineExpanded = false }) {
                                lineOptions.forEach { opt ->
                                    DropdownMenuItem(
                                        text = { Text(opt) },
                                        onClick = {
                                            selectedReportLine = opt
                                            lineExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Comment / Description Field
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("DESCRIPCIÓN DEL SUCESO:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            TextField(
                                value = reportComment,
                                onValueChange = { reportComment = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                placeholder = { Text("Escribe detalles (Ej: Falla en puerta, andén lleno, retraso de 10 min, etc.)", fontSize = 13.sp) },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                )
                            )
                        }
                    }

                    item {
                        Button(
                            onClick = {
                                if (reportComment.isNotEmpty()) {
                                    viewModel.devIncidentLineId.value = selectedReportLine
                                    viewModel.devIncidentStationId.value = "Estación de Reporte"
                                    viewModel.devIncidentDesc.value = reportComment
                                    viewModel.injectIncidentOnNetwork()
                                    reportComment = ""
                                    reportSuccessMsg = "¡Reporte inyectado con éxito! Se ha alertado a la red de simulación."
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("ENVIAR REPORTE DE PASAJERO", fontWeight = FontWeight.Bold)
                        }
                    }

                    item {
                        AnimatedVisibility(visible = reportSuccessMsg != null) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF008E3A))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(reportSuccessMsg ?: "", color = Color(0xFF008E3A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
            2 -> {
                // MI VIAJE ACTIVE NAVIGATION SECTION
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Text(
                            text = "MI NAVEGADOR ACTIVO DE VIAJE",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                        )
                    }

                    val journey = activeJourney
                    if (journey == null) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = borderStroke()
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("No tienes un viaje activo", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(
                                        "Ve a la pestaña RUTAS, selecciona origen/destino y presiona 'INICIAR VIAJE'. Al elegir un itinerario, podrás navegarlo paso a paso en esta pantalla.",
                                        fontSize = 12.sp,
                                        color = Color.Gray,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(onClick = { viewModel.setTab(2) }) {
                                        Text("Ir a planificar ahora")
                                    }
                                }
                            }
                        }
                    } else {
                        // Render active journey step navigation
                        val segments = journey.segments
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                shape = RoundedCornerShape(12.dp),
                                border = borderStroke()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("VIAJE EN CURSO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                            val totalTime = journey.totalDurationSeconds / 60
                                            Text("A destino • ~$totalTime minutos", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                        }

                                        Button(
                                            onClick = { viewModel.cancelJourney() },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                        ) {
                                            Text("Terminar", fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Interactive Steps controls
                                    if (currentSegmentIndex < segments.size) {
                                        val activeSeg = segments[currentSegmentIndex]
                                        Text(
                                            "PASO ACTUAL (${currentSegmentIndex + 1}/${segments.size}):",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            activeSeg.instruction,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 14.sp
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Button(
                                            onClick = { viewModel.advanceJourney() },
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.ArrowForward, contentDescription = null)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("SIGUIENTE PASO COMPLETADO", fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFFE8F5E9))
                                                .padding(12.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                "🎉 ¡Has llegado a tu destino! Presiona 'Terminar' para cerrar el navegador.",
                                                color = Color(0xFF008E3A),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        itemsIndexed(segments) { index, segment ->
                            val isActive = index == currentSegmentIndex
                            val isCompleted = index < currentSegmentIndex

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isActive) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                                ),
                                border = borderStroke(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Visual state circle
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isCompleted) Color(0xFF008E3A)
                                                else if (isActive) MaterialTheme.colorScheme.primary
                                                else Color.LightGray
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isCompleted) Icons.Default.Check
                                            else when (segment.type) {
                                                "METRO" -> Icons.Default.Train
                                                "BUS" -> Icons.Default.DirectionsBus
                                                "TRANSFER" -> Icons.Default.TransferWithinAStation
                                                else -> Icons.Default.DirectionsWalk
                                            },
                                            contentDescription = null,
                                            modifier = Modifier.size(12.dp),
                                            tint = Color.White
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(14.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = segment.instruction,
                                            fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (isActive) MaterialTheme.colorScheme.primary else if (isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Duración: ${segment.durationSeconds / 60} min",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
            3 -> {
                // PANEL DE DESARROLLADOR SIMULADOR
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Text(
                            text = "CONTROL DE SIMULACIÓN EN VIVO",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                        )
                        Text(
                            text = "Esta consola te permite manipular la velocidad del tiempo en el motor de simulación para observar los tránsitos y arribos aceleradamente.",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }

                    // Pause / Play toggle
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("ESTADO MOTOR SIMULACIÓN:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (simPaused) "🛑 SIMULADOR DETENIDO (PAUSADO)" else "🟢 SIMULADOR EJECUTÁNDOSE (ACTIVO)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (simPaused) Color.Red else Color(0xFF008E3A)
                                    )

                                    Button(
                                        onClick = { viewModel.togglePlayPauseSim() },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (simPaused) Color(0xFF008E3A) else Color.Red
                                        )
                                    ) {
                                        Icon(if (simPaused) Icons.Default.PlayArrow else Icons.Default.Pause, contentDescription = null)
                                    }
                                }
                            }
                        }
                    }

                    // Simulation Multiplier Selector
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("MULTIPLICADOR DE VELOCIDAD DE TIEMPO:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(1, 10, 60, 300).forEach { speed ->
                                        val isSel = simMultiplier == speed
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(44.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                                .border(1.dp, if (isSel) Color.Transparent else Color.LightGray, RoundedCornerShape(8.dp))
                                                .clickable { viewModel.changeSimMultiplier(speed) },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                "${speed}x",
                                                color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 13.sp
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = "300x simula 5 minutos de tránsito real cada 1 segundo. Ideal para ver movimientos vehiculares en el mapa.",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }

                    // Emergency Injection triggers
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("INYECCIÓN DE NOVEDADES Y EMERGENCIAS:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                                Button(
                                    onClick = {
                                        viewModel.devVehicleDelayId.value = "METRO_L1_1"
                                        viewModel.devVehicleDelaySecs.value = "120"
                                        viewModel.injectDelayToVehicle()
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF57C00))
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Bolt, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("GENERAR DEMORA EN METRO L1 (TREN 1)", fontWeight = FontWeight.Bold)
                                    }
                                }

                                Button(
                                    onClick = {
                                        incidents.forEach {
                                            TransportSimulator.resolveIncident(it.id)
                                        }
                                        TransportSimulator.logEvent("CLEAR_ALL", "Se han solucionado todas las incidencias de forma forzosa.")
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF008E3A))
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.HealthAndSafety, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("RESTABLECER RED (RESOLVER TODO)", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }
}
