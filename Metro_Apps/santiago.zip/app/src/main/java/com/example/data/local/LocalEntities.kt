package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String, // "METRO" or "BUS" or "PLACE"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "bip_cards")
data class BipCardEntity(
    @PrimaryKey val cardNumber: String,
    val cardName: String,
    val balance: Int,
    val status: String,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "bip_transactions")
data class BipTransactionEntity(
    @PrimaryKey val id: String,
    val cardNumber: String,
    val amount: Int,
    val type: String, // "RECARGA", "VIAJE", "INTEGRACION"
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "simulation_config")
data class SimulationConfigEntity(
    @PrimaryKey val id: Int = 0,
    val isPlaying: Boolean = true,
    val speedMultiplier: Int = 1,
    val useOfflineMode: Boolean = false
)

@Entity(tableName = "recent_routes")
data class RecentRouteEntity(
    @PrimaryKey val id: String, // "fromId_toId"
    val fromId: String,
    val fromName: String,
    val toId: String,
    val toName: String,
    val timestamp: Long = System.currentTimeMillis()
)
