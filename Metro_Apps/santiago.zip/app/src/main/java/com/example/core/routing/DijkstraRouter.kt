package com.example.core.routing

import com.example.core.model.*
import com.example.data.providers.DemoDataProvider
import java.util.PriorityQueue

enum class RoutePreference {
    MAS_RAPIDA,
    MENOS_TRANSBORDOS,
    MENOS_CAMINATA,
    MAS_ACCESIBLE
}

data class GraphEdge(
    val fromId: String,
    val toId: String,
    val weightSeconds: Double,
    val type: String, // "METRO", "BUS", "WALK", "TRANSFER"
    val lineId: String?, // e.g. "L1", "405", "Nos"
    val isAccessible: Boolean = true
)

data class RouteSegment(
    val fromId: String,
    val fromName: String,
    val toId: String,
    val toName: String,
    val durationSeconds: Int,
    val type: String, // "METRO", "BUS", "WALK", "TRANSFER"
    val lineId: String?,
    val lineHexColor: String?,
    val instruction: String
)

data class RouteResult(
    val preference: RoutePreference,
    val segments: List<RouteSegment>,
    val totalDurationSeconds: Int,
    val estimatedArrivalTime: String, // e.g. "08:42"
    val numTransfers: Int,
    val walkingTimeSeconds: Int,
    val estimatedCost: Int,
    val accessibilityScore: Double, // 0.0 to 1.0
    val warnings: List<String>
)

object DijkstraRouter {

    private val edges = mutableListOf<GraphEdge>()
    private val nodeNames = mutableMapOf<String, String>()
    private val nodeAccessibility = mutableMapOf<String, Boolean>()

    init {
        buildGraph()
    }

    private fun buildGraph() {
        edges.clear()
        nodeNames.clear()
        nodeAccessibility.clear()

        // 1. Populate node information
        // Metro & Nos stations
        DemoDataProvider.metroStations.forEach { station ->
            nodeNames[station.id] = "${station.name} (${station.lineId})"
            nodeAccessibility[station.id] = station.hasElevator
        }
        // Paraderos
        DemoDataProvider.paraderos.forEach { paradero ->
            nodeNames[paradero.id] = paradero.name
            nodeAccessibility[paradero.id] = paradero.isAccessible
        }
        // Important places
        DemoDataProvider.importantPlaces.forEach { place ->
            nodeNames[place.id] = place.name
            nodeAccessibility[place.id] = true
        }

        // 2. Add Metro Line edges (bidirectional travel between consecutive stations)
        DemoDataProvider.metroLines.forEach { line ->
            val stations = line.stations.sortedBy { it.order }
            for (i in 0 until stations.size - 1) {
                val s1 = stations[i]
                val s2 = stations[i + 1]
                // 120 seconds (2 minutes) travel time between consecutive stations
                edges.add(GraphEdge(s1.id, s2.id, 120.0, "METRO", line.id, s1.hasElevator && s2.hasElevator))
                edges.add(GraphEdge(s2.id, s1.id, 120.0, "METRO", line.id, s1.hasElevator && s2.hasElevator))
            }
        }

        // 3. Add Metro Station Combination / Transfer edges
        // Combine stations that have the same prefix (e.g. "Franklin" or are combined)
        val stationsGroupedByName = DemoDataProvider.metroStations.groupBy { it.name }
        stationsGroupedByName.forEach { (name, stations) ->
            if (stations.size > 1) {
                for (i in stations.indices) {
                    for (j in stations.indices) {
                        if (i != j) {
                            val s1 = stations[i]
                            val s2 = stations[j]
                            // 180 seconds (3 mins) transfer delay
                            edges.add(GraphEdge(s1.id, s2.id, 180.0, "TRANSFER", null, s1.hasElevator && s2.hasElevator))
                        }
                    }
                }
            }
        }

        // 4. Add Bus Route edges (travel along paraderos)
        DemoDataProvider.busRoutes.forEach { route ->
            for (i in 0 until route.stops.size - 1) {
                val p1 = route.stops[i]
                val p2 = route.stops[i + 1]
                // Buses take roughly 180 seconds (3 mins) between stops including traffic
                edges.add(GraphEdge(p1, p2, 180.0, "BUS", route.id, true))
            }
        }

        // 5. Add pedestrian walking connections between Metro Stations and Paraderos
        // Map station coordinate matching or close points
        addWalkEdge("L1_Pedro_de_Valdivia", "PC183", 60.0)
        addWalkEdge("L1_Tobalaba", "PC184", 60.0)
        addWalkEdge("L4_Tobalaba", "PC184", 120.0)
        addWalkEdge("L1_U_de_Chile", "PA342", 60.0)
        addWalkEdge("L3_U_de_Chile", "PA342", 120.0)
        addWalkEdge("L1_Baquedano", "PA370", 60.0)
        addWalkEdge("L5_Baquedano", "PA370", 120.0)
        addWalkEdge("L1_Estacion_Central", "PI340", 60.0)
        addWalkEdge("L5_Plaza_de_Maipu", "PI181", 60.0)
        addWalkEdge("L1_Escuela_Militar", "PC190", 60.0)
        addWalkEdge("L4_Vicente_Valdes", "PE123", 60.0)
        addWalkEdge("L5_Vicente_Valdes", "PE123", 120.0)

        // 6. Connect Important Places to their designated stations/paraderos
        DemoDataProvider.importantPlaces.forEach { place ->
            place.connectedStops.forEach { stopId ->
                if (stopId == "CENTROPUERTO") {
                    // Centropuerto airport shuttle from Pajaritos to Aeropuerto (special express edge)
                    // takes 25 minutes = 1500 seconds
                    edges.add(GraphEdge("L1_Pajaritos", place.id, 1500.0, "BUS", "Centropuerto", true))
                    edges.add(GraphEdge(place.id, "L1_Pajaritos", 1500.0, "BUS", "Centropuerto", true))
                } else {
                    // Standard walking connection of 3 minutes (180s)
                    edges.add(GraphEdge(place.id, stopId, 180.0, "WALK", null, true))
                    edges.add(GraphEdge(stopId, place.id, 180.0, "WALK", null, true))
                }
            }
        }
    }

    private fun addWalkEdge(id1: String, id2: String, seconds: Double) {
        edges.add(GraphEdge(id1, id2, seconds, "WALK", null, true))
        edges.add(GraphEdge(id2, id1, seconds, "WALK", null, true))
    }

    fun findRoutes(fromId: String, toId: String, currentTime: Long = System.currentTimeMillis()): List<RouteResult> {
        if (!nodeNames.containsKey(fromId) || !nodeNames.containsKey(toId)) {
            return emptyList()
        }

        return RoutePreference.values().map { preference ->
            solveDijkstra(fromId, toId, preference, currentTime)
        }.filterNotNull()
    }

    private fun solveDijkstra(fromId: String, toId: String, preference: RoutePreference, currentTime: Long): RouteResult? {
        val dist = mutableMapOf<String, Double>()
        val parent = mutableMapOf<String, GraphEdge>()
        val pq = PriorityQueue<Pair<String, Double>>(compareBy { it.second })

        dist[fromId] = 0.0
        pq.add(fromId to 0.0)

        while (pq.isNotEmpty()) {
            val (u, d) = pq.poll() ?: break
            if (u == toId) break

            if (d > (dist[u] ?: Double.MAX_VALUE)) continue

            val outgoing = edges.filter { it.fromId == u }
            for (edge in outgoing) {
                val v = edge.toId

                // Calculate edge weight penalty based on preferences
                var edgeCost = edge.weightSeconds

                // Accessibility modifier
                if (preference == RoutePreference.MAS_ACCESIBLE) {
                    val isUAccessible = nodeAccessibility[u] ?: true
                    val isVAccessible = nodeAccessibility[v] ?: true
                    val isEdgeAccessible = edge.isAccessible
                    if (!isUAccessible || !isVAccessible || !isEdgeAccessible) {
                        edgeCost += 5000.0 // Heavy penalty for non-accessible nodes or edges
                    }
                }

                // Walk modifier
                if (preference == RoutePreference.MENOS_CAMINATA) {
                    if (edge.type == "WALK") {
                        edgeCost *= 4.0 // walk weighs 4x
                    }
                }

                // Transfer modifier
                if (preference == RoutePreference.MENOS_TRANSBORDOS) {
                    val prevEdge = parent[u]
                    if (prevEdge != null && prevEdge.lineId != null && edge.lineId != null && prevEdge.lineId != edge.lineId) {
                        edgeCost += 1200.0 // Penalty of 20 mins for line change
                    }
                    if (edge.type == "TRANSFER") {
                        edgeCost += 1200.0
                    }
                }

                val currentDist = d + edgeCost
                if (currentDist < (dist[v] ?: Double.MAX_VALUE)) {
                    dist[v] = currentDist
                    parent[v] = edge
                    pq.add(v to currentDist)
                }
            }
        }

        // Reconstruct path
        if (!dist.containsKey(toId)) return null

        val pathEdges = mutableListOf<GraphEdge>()
        var curr = toId
        while (curr != fromId) {
            val edge = parent[curr] ?: break
            pathEdges.add(0, edge)
            curr = edge.fromId
        }

        if (pathEdges.isEmpty()) return null

        // Group into user readable segments
        val segments = mutableListOf<RouteSegment>()
        var currentSegmentEdges = mutableListOf<GraphEdge>()

        for (edge in pathEdges) {
            if (currentSegmentEdges.isEmpty()) {
                currentSegmentEdges.add(edge)
            } else {
                val last = currentSegmentEdges.last()
                if (last.type == edge.type && last.lineId == edge.lineId) {
                    currentSegmentEdges.add(edge)
                } else {
                    segments.add(createSegment(currentSegmentEdges))
                    currentSegmentEdges = mutableListOf(edge)
                }
            }
        }
        if (currentSegmentEdges.isNotEmpty()) {
            segments.add(createSegment(currentSegmentEdges))
        }

        val totalDurationSeconds = segments.sumOf { it.durationSeconds }
        val numTransfers = segments.count { it.type == "TRANSFER" || (it.type == "BUS" && it.lineId != "Centropuerto") } // Count bus transfers or metro combinations
        val walkingTimeSeconds = segments.filter { it.type == "WALK" || it.type == "TRANSFER" }.sumOf { it.durationSeconds }

        // Bip! Fare computation
        // Integration window of 120 mins (7200s). First tap 730 / 830, transfer is free or difference
        var totalCost = 730 // default bus fare
        val hasMetro = segments.any { it.type == "METRO" }
        if (hasMetro) {
            totalCost = 830 // Horario punta metro fare
        }
        if (segments.any { it.lineId == "Centropuerto" }) {
            totalCost += 2200 // Centropuerto specific ticket (demonstrative)
        }

        // Accessibility score
        val nodesInPath = pathEdges.map { it.fromId } + toId
        val accessibleNodesCount = nodesInPath.count { nodeAccessibility[it] ?: true }
        val accessibilityScore = accessibleNodesCount.toDouble() / nodesInPath.size

        // Warnings
        val warnings = mutableListOf<String>()
        if (preference == RoutePreference.MAS_ACCESIBLE && accessibilityScore < 0.95) {
            warnings.add("Esta ruta contiene estaciones o paraderos sin accesibilidad completa.")
        }
        if (numTransfers >= 2) {
            warnings.add("Ruta con múltiples combinaciones. Puede experimentar demoras.")
        }
        // Active incidents checking
        segments.forEach { seg ->
            val matchingIncident = DemoDataProvider.initialIncidents.find {
                it.affectedLine == seg.lineId || it.affectedStation == seg.fromId || it.affectedStation == seg.toId
            }
            if (matchingIncident != null) {
                warnings.add("Alerta en ${seg.lineId ?: "Ruta"}: ${matchingIncident.description}")
            }
        }

        // Expected arrival time
        val formatTime = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        val arrTime = java.util.Date(currentTime + (totalDurationSeconds * 1000L))

        return RouteResult(
            preference = preference,
            segments = segments,
            totalDurationSeconds = totalDurationSeconds,
            estimatedArrivalTime = formatTime.format(arrTime),
            numTransfers = numTransfers,
            walkingTimeSeconds = walkingTimeSeconds,
            estimatedCost = totalCost,
            accessibilityScore = accessibilityScore,
            warnings = warnings
        )
    }

    private fun createSegment(segmentEdges: List<GraphEdge>): RouteSegment {
        val first = segmentEdges.first()
        val last = segmentEdges.last()
        val fromId = first.fromId
        val toId = last.toId
        val fromName = nodeNames[fromId] ?: fromId
        val toName = nodeNames[toId] ?: toId
        val durationSeconds = segmentEdges.sumOf { it.weightSeconds }.toInt()
        val type = first.type
        val lineId = first.lineId

        // Get line color
        val lineHexColor = when (type) {
            "METRO" -> DemoDataProvider.metroLines.find { it.id == lineId }?.hexColor ?: "#757575"
            "BUS" -> {
                if (lineId == "Centropuerto") "#1E88E5"
                else DemoDataProvider.busRoutes.find { it.id == lineId }?.colorHex ?: "#00838F"
            }
            "TRANSFER" -> "#E0E0E0"
            else -> "#BDBDBD" // WALK
        }

        val instruction = when (type) {
            "METRO" -> "Toma el Metro en $fromName, dirección terminal de ${lineId?.let { getTerminalStationName(it) } ?: "la línea"}, viaja hasta $toName."
            "BUS" -> {
                if (lineId == "Centropuerto") "Sube al servicio Centropuerto en $fromName y viaja de forma directa hasta $toName."
                else "Espera el bus $lineId en paradero $fromName y desciende en $toName."
            }
            "TRANSFER" -> "Combina en $fromName hacia la línea ${last.toId.substringBefore('_')}."
            else -> "Camina desde $fromName hasta $toName."
        }

        return RouteSegment(
            fromId = fromId,
            fromName = fromName,
            toId = toId,
            toName = toName,
            durationSeconds = durationSeconds,
            type = type,
            lineId = lineId,
            lineHexColor = lineHexColor,
            instruction = instruction
        )
    }

    private fun getTerminalStationName(lineId: String): String {
        val line = DemoDataProvider.metroLines.find { it.id == lineId } ?: return "Terminal"
        return line.stations.lastOrNull()?.name ?: "Terminal"
    }

    fun getAllNodesList(): List<Pair<String, String>> {
        return nodeNames.entries.map { it.key to it.value }.sortedBy { it.second }
    }
}
