package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.core.routing.RoutePreference
import com.example.core.routing.RouteResult
import com.example.core.routing.RouteSegment
import com.example.data.providers.DemoDataProvider
import com.example.ui.TransportViewModel
import com.example.ui.components.borderStroke

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RutasTab(viewModel: TransportViewModel) {
    var subTab by remember { mutableStateOf(0) } // 0 = PLANIFICADOR, 1 = METRO, 2 = BUSES, 3 = AEROPUERTO

    val searchFrom by viewModel.searchFromId.collectAsState()
    val searchTo by viewModel.searchToId.collectAsState()
    val calculatedRoutes by viewModel.calculatedRoutes.collectAsState()
    val selectedRouteResult by viewModel.selectedRouteResult.collectAsState()

    val selectedLineId by viewModel.selectedMetroLineId.collectAsState()
    val selectedStationId by viewModel.selectedMetroStationId.collectAsState()
    val selectedParaderoId by viewModel.selectedParaderoId.collectAsState()
    val isAirportFrom by viewModel.isAirportFromMode.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()
    val favorites by viewModel.favorites.collectAsState()

    var showFromDropdown by remember { mutableStateOf(false) }
    var showToDropdown by remember { mutableStateOf(false) }

    val allLocations = (DemoDataProvider.metroStations.map { it.id to "${it.name} (${it.lineId})" } +
            DemoDataProvider.paraderos.map { it.id to "Paradero: ${it.name} [${it.id}]" } +
            DemoDataProvider.importantPlaces.map { it.id to it.name })

    val selectedFromName = allLocations.find { it.first == searchFrom }?.second ?: "Selecciona origen"
    val selectedToName = allLocations.find { it.first == searchTo }?.second ?: "Selecciona destino"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Rutas top banner
        ScrollableTabRow(
            selectedTabIndex = subTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary,
            edgePadding = 16.dp
        ) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("PLANIFICADOR", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
            Tab(selected = subTab == 1, onClick = { subTab = 1 }) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Train, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("METRO", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
            Tab(selected = subTab == 2, onClick = { subTab = 2 }) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsBus, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("RED BUSES", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
            Tab(selected = subTab == 3, onClick = { subTab = 3 }) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FlightTakeoff, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("AEROPUERTO", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (subTab) {
            0 -> {
                // PLANIFICADOR (¿COMO LLEGO?) TAB
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    "PLANIFICAR ITINERARIO",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                // From field
                                Column {
                                    Text("DESDE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(44.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .clickable { showFromDropdown = !showFromDropdown }
                                            .padding(horizontal = 12.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(selectedFromName, fontSize = 12.sp)
                                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                        }
                                    }

                                    AnimatedVisibility(visible = showFromDropdown) {
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .heightIn(max = 160.dp)
                                                .padding(top = 4.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                        ) {
                                            LazyColumn {
                                                items(allLocations) { (id, label) ->
                                                    DropdownMenuItem(
                                                        text = { Text(label, fontSize = 12.sp) },
                                                        onClick = {
                                                            viewModel.searchFromId.value = id
                                                            showFromDropdown = false
                                                            viewModel.doCalculateRoutes()
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // To field
                                Column {
                                    Text("HASTA", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(44.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .clickable { showToDropdown = !showToDropdown }
                                            .padding(horizontal = 12.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(selectedToName, fontSize = 12.sp)
                                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                        }
                                    }

                                    AnimatedVisibility(visible = showToDropdown) {
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .heightIn(max = 160.dp)
                                                .padding(top = 4.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                        ) {
                                            LazyColumn {
                                                items(allLocations) { (id, label) ->
                                                    DropdownMenuItem(
                                                        text = { Text(label, fontSize = 12.sp) },
                                                        onClick = {
                                                            viewModel.searchToId.value = id
                                                            showToDropdown = false
                                                            viewModel.doCalculateRoutes()
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Preferences Selector: Multi-Strategy Filtros
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                "CRITERIO DE BÚSQUEDA:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(
                                    RoutePreference.MAS_RAPIDA to "Rápido",
                                    RoutePreference.MENOS_TRANSBORDOS to "Transbordos",
                                    RoutePreference.MENOS_CAMINATA to "Caminata",
                                    RoutePreference.MAS_ACCESIBLE to "Accesible"
                                ).forEach { (pref, label) ->
                                    val isSelected = selectedRouteResult?.preference == pref
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(34.dp)
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                            .clickable {
                                                val matched = calculatedRoutes.find { it.preference == pref }
                                                if (matched != null) {
                                                    viewModel.selectRoute(matched)
                                                }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            label,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Route planning results details
                    if (searchFrom.isEmpty() || searchTo.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Text(
                                    "Por favor selecciona origen y destino para simular y calcular la mejor combinación.",
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(16.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else if (selectedRouteResult == null) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Text(
                                    "Calculando la ruta óptima...",
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(16.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        val route = selectedRouteResult!!
                        val totalMin = route.totalDurationSeconds / 60
                        val walkMin = route.walkingTimeSeconds / 60
                        val transfers = route.numTransfers
                        val price = route.estimatedCost

                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                shape = RoundedCornerShape(12.dp),
                                border = borderStroke()
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "ESTIMACIÓN DE VIAJE",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color(0xFF008E3A))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                "RECOMENDADA",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text("⏱ Tiempo total:", fontSize = 11.sp, color = Color.Gray)
                                            Text("~$totalMin min", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                        }
                                        Column {
                                            Text("🚇 Transbordos:", fontSize = 11.sp, color = Color.Gray)
                                            Text(if (transfers <= 0) "Directo" else "$transfers", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                                        }
                                        Column {
                                            Text("💸 Tarifa bip!:", fontSize = 11.sp, color = Color.Gray)
                                            Text("$$price", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF008E3A))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Button(
                                        onClick = {
                                            viewModel.startJourney()
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Navigation, contentDescription = null)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("INICIAR VIAJE (NAVEGACIÓN GUIADA)", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Text(
                                "ITINERARIO DE NAVEGACIÓN:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        itemsIndexed(route.segments) { index, segment ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = borderStroke(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when (segment.type) {
                                                    "METRO" -> Color(0xFFE2231A)
                                                    "BUS" -> Color(0xFF0F4C81)
                                                    "TRANSFER" -> Color(0xFF8B5E3C)
                                                    else -> Color.LightGray
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = when (segment.type) {
                                                "METRO" -> Icons.Default.Train
                                                "BUS" -> Icons.Default.DirectionsBus
                                                "TRANSFER" -> Icons.Default.TransferWithinAStation
                                                else -> Icons.Default.DirectionsWalk
                                            },
                                            contentDescription = null,
                                            modifier = Modifier.size(12.dp),
                                            tint = Color.White
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(segment.instruction, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text("Duración: ${segment.durationSeconds / 60} min", fontSize = 10.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
            1 -> {
                // METRO TAB
                Row(modifier = Modifier.fillMaxSize()) {
                    // Left Column: Metro line selection icons
                    Column(
                        modifier = Modifier
                            .width(68.dp)
                            .fillMaxHeight()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            .padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        DemoDataProvider.metroLines.forEach { line ->
                            val isSelected = selectedLineId == line.id
                            val lineCol = Color(android.graphics.Color.parseColor(line.hexColor))
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) lineCol else lineCol.copy(alpha = 0.15f))
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.onBackground else lineCol,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        viewModel.selectedMetroLineId.value = line.id
                                        viewModel.selectedMetroStationId.value = line.stations.firstOrNull()?.id
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = line.id,
                                    color = if (isSelected) Color.White else lineCol,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    // Right Column: Line station details
                    val currentLine = DemoDataProvider.metroLines.find { it.id == selectedLineId }
                    if (currentLine != null) {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .padding(horizontal = 14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                    Text(
                                        text = currentLine.name.uppercase(),
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF008E3A))
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Servicio Operacional Normal • ${currentLine.intervalMinutes} min intervalo",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            }

                            itemsIndexed(currentLine.stations) { index, station ->
                                val isSelected = selectedStationId == station.id
                                val isFav = favorites.any { it.id == station.id }

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.selectedMetroStationId.value = station.id },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    border = borderStroke()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(14.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isSelected) Color(android.graphics.Color.parseColor(currentLine.hexColor)) else Color.White)
                                                    .border(
                                                        width = 3.dp,
                                                        color = Color(android.graphics.Color.parseColor(currentLine.hexColor)),
                                                        shape = CircleShape
                                                    )
                                            )

                                            Spacer(modifier = Modifier.width(12.dp))

                                            Column {
                                                Text(
                                                    text = station.name,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                )
                                                if (station.connections.isNotEmpty()) {
                                                    Row(
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                        modifier = Modifier.padding(top = 2.dp)
                                                    ) {
                                                        Text("Combina con:", fontSize = 9.sp, color = Color.Gray)
                                                        station.connections.forEach { connLineId ->
                                                            val connCol = Color(android.graphics.Color.parseColor(DemoDataProvider.metroLines.find { it.id == connLineId }?.hexColor ?: "#333"))
                                                            Box(
                                                                modifier = Modifier
                                                                    .clip(RoundedCornerShape(3.dp))
                                                                    .background(connCol)
                                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                                            ) {
                                                                Text(
                                                                    connLineId,
                                                                    color = Color.White,
                                                                    fontSize = 8.sp,
                                                                    fontWeight = FontWeight.Bold
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (station.hasElevator) {
                                                Icon(
                                                    Icons.Default.Elevator,
                                                    contentDescription = "Accesible",
                                                    modifier = Modifier.size(16.dp),
                                                    tint = Color(0xFF008E3A)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            IconButton(
                                                onClick = { viewModel.toggleFavorite(station.id, station.name, "METRO") },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                                    contentDescription = null,
                                                    tint = if (isFav) Color.Red else Color.LightGray,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                if (isSelected) {
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 2.dp, bottom = 6.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text("INFORMACIÓN PRÁCTICA DE ESTACIÓN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                            Text("• Dirección andén: Vía 1 (Pudahuel/La Cisterna) y Vía 2 (Tobalaba/Vespucio).", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                            Text("• Equipamientos: Escaleras mecánicas operativas, zona de carga bip! presencial y tótems de validación automáticos.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                            Text("• Salida recomendada: Acceso principal norte conecta directo con Av. Libertador Bernardo O'Higgins.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)

                                            Spacer(modifier = Modifier.height(4.dp))

                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Button(
                                                    onClick = {
                                                        viewModel.searchFromId.value = station.id
                                                        viewModel.setTab(0)
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                                    shape = RoundedCornerShape(6.dp),
                                                    modifier = Modifier.height(30.dp).weight(1f)
                                                ) {
                                                    Text("Partir de aquí", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }
                                                Button(
                                                    onClick = {
                                                        viewModel.searchToId.value = station.id
                                                        viewModel.setTab(0)
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                                    shape = RoundedCornerShape(6.dp),
                                                    modifier = Modifier.height(30.dp).weight(1f)
                                                ) {
                                                    Text("Ir hasta aquí", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            item { Spacer(modifier = Modifier.height(72.dp)) }
                        }
                    }
                }
            }
            2 -> {
                // RED BUSES TAB
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = "SERVICIOS RED MOVILIDAD",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    items(DemoDataProvider.busRoutes) { route ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(android.graphics.Color.parseColor(route.colorHex)))
                                                .padding(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                route.shortName,
                                                color = Color.White,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.ExtraBold
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column {
                                            Text(
                                                route.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "Vehículo: " + if (route.type == VehicleType.BUS_ELECTRICO) "Estándar RED Eléctrico BYD" else "Diesel Euro VI",
                                                fontSize = 11.sp,
                                                color = Color.Gray
                                            )
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF008E3A).copy(alpha = 0.15f))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            "NORMAL",
                                            color = Color(0xFF008E3A),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    "RECORRIDO PRINCIPAL Y HORARIOS SIMULADOS:",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    letterSpacing = 0.5.sp
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                route.stops.forEach { stopId ->
                                    val paradero = DemoDataProvider.paraderos.find { it.id == stopId }
                                    if (paradero != null) {
                                        val isFav = favorites.any { it.id == stopId }
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { viewModel.selectedParaderoId.value = stopId }
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .clip(CircleShape)
                                                        .background(Color.LightGray)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "${paradero.name} [${paradero.id}]",
                                                    fontSize = 12.sp,
                                                    color = if (selectedParaderoId == stopId) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                )
                                            }

                                            Icon(
                                                if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                                contentDescription = null,
                                                tint = if (isFav) Color.Red else Color.LightGray,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Selected paradero inspector card
                    val paraderoDetail = DemoDataProvider.paraderos.find { it.id == selectedParaderoId }
                    if (paraderoDetail != null) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                shape = RoundedCornerShape(16.dp),
                                border = borderStroke()
                            ) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                                    // Custom Pole graphic drawing
                                    Box(
                                        modifier = Modifier
                                            .width(48.dp)
                                            .height(130.dp)
                                            .background(Color(0xFF263238), RoundedCornerShape(6.dp))
                                            .padding(2.dp),
                                        contentAlignment = Alignment.TopCenter
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(0xFF0F4C81)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("RED", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                paraderoDetail.id,
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                textAlign = TextAlign.Center
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            paraderoDetail.routes.take(2).forEach { r ->
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .background(Color.White)
                                                        .padding(vertical = 1.dp)
                                                ) {
                                                    Text(
                                                        r,
                                                        color = Color.Black,
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        textAlign = TextAlign.Center,
                                                        modifier = Modifier.fillMaxWidth()
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(2.dp))
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(16.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "PARADERO ${paraderoDetail.id}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = paraderoDetail.name,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Sentido: ${paraderoDetail.direction}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Text(
                                            "SERVICIOS DISPONIBLES EN ESTA PARADA:",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )

                                        paraderoDetail.routes.forEach { routeId ->
                                            val matching = vehicles.filter { it.lineId == routeId }
                                            val nextArr = matching.minByOrNull { it.nextStopSeconds }
                                            val minutes = if (nextArr != null) (nextArr.nextStopSeconds / 60).coerceAtLeast(1) else 6

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    "• Recorrido $routeId hacia Cantagallo/Maipú",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    "$minutes min",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = if (minutes < 3) Color(0xFF008E3A) else Color.Black
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(
                                                onClick = {
                                                    viewModel.searchFromId.value = paraderoDetail.id
                                                    viewModel.setTab(0)
                                                },
                                                modifier = Modifier.height(30.dp),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text("Fijar Origen", fontSize = 10.sp)
                                            }
                                            Button(
                                                onClick = {
                                                    viewModel.searchToId.value = paraderoDetail.id
                                                    viewModel.setTab(0)
                                                },
                                                modifier = Modifier.height(30.dp),
                                                shape = RoundedCornerShape(6.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                            ) {
                                                Text("Fijar Destino", fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
            3 -> {
                // AEROPUERTO TAB
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(16.dp),
                            border = borderStroke()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "¿VIENES DE VIAJE?",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    "Santiago de Chile cuenta con un servicio integrado de transporte de bajo costo que conecta el Aeropuerto Arturo Merino Benítez (SCL) con toda la red de Metro mediante el servicio Centropuerto.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.isAirportFromMode.value = true },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isAirportFrom) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                                ),
                                shape = RoundedCornerShape(12.dp),
                                border = borderStroke()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.ArrowOutward, contentDescription = null, tint = Color(0xFF0F4C81))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Ir al Aeropuerto", fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center)
                                    Text("Desde el centro", fontSize = 10.sp, color = Color.Gray)
                                }
                            }

                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.isAirportFromMode.value = false },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (!isAirportFrom) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                                ),
                                shape = RoundedCornerShape(12.dp),
                                border = borderStroke()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.SouthEast, contentDescription = null, tint = Color(0xFF0F4C81))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Salir del Aeropuerto", fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center)
                                    Text("Hacia Santiago", fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = if (isAirportFrom) "RUTA RECOMENDADA: IR AL AEROPUERTO" else "RUTA RECOMENDADA: LLEGAR A SANTIAGO",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                if (isAirportFrom) {
                                    Text("1. Toma el Metro Línea 1 hasta estación terminal Pajaritos.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("2. En la terminal intermodal de Pajaritos, sube al servicio Express Centropuerto (Andén 4).", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("3. El tiempo de viaje estimado es de 25 minutos de forma directa por autopista.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("4. Tarifa aproximada del bus: $2.200 (Pago directo en efectivo o transferencia, no bip!).", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                } else {
                                    Text("1. Al salir de la terminal internacional, dirígete al andén de buses oficiales del primer nivel.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("2. Sube al bus Centropuerto con destino final Estación Pajaritos / Los Héroes.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("3. Desciende en Estación Pajaritos para realizar combinación directa a Metro Línea 1 hacia cualquier sector de Santiago.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("4. Puedes pagar el bus directo con el chofer ($2.200). En Pajaritos deberás usar tu tarjeta bip! para ingresar al Metro.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Button(
                                    onClick = {
                                        if (isAirportFrom) {
                                            viewModel.setMapTarget("L1_Pajaritos", "aeropuerto")
                                        } else {
                                            viewModel.setMapTarget("aeropuerto", "L1_Pajaritos")
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Directions, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("VER RECORRIDO EN PLANIFICADOR", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = borderStroke(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFF57C00), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("ADVERTENCIAS PARA VIAJEROS", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFF57C00))
                                }
                                Text("• El Metro de Santiago NO llega de forma directa con vías de tren al Aeropuerto. La única conexión pública barata es el bus Centropuerto.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                Text("• Desconfíe de taxis informales o personas que le ofrezcan transporte dentro de los pasillos de llegada. Diríjase únicamente a los módulos oficiales de transporte autorizados.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                Text("• Mantenga sus pertenencias vigiladas en estaciones de alta congestión como Pajaritos, Los Héroes y Estación Central.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }
}
