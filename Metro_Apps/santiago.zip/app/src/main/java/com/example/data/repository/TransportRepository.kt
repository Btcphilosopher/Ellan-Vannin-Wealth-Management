package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.core.model.*
import com.example.core.routing.DijkstraRouter
import com.example.core.routing.RouteResult
import com.example.core.simulation.SimulationState
import com.example.core.simulation.TransportSimulator
import com.example.data.local.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.UUID

class TransportRepository private constructor(context: Context) {

    private val db: AppDatabase = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "santiago_transport.db"
    ).build()

    private val dao = db.transportDao()
    private val repoScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // Simulated active travel
    private val _activeJourney = MutableStateFlow<RouteResult?>(null)
    val activeJourney: StateFlow<RouteResult?> = _activeJourney.asStateFlow()

    private val _currentJourneySegmentIndex = MutableStateFlow(0)
    val currentJourneySegmentIndex: StateFlow<Int> = _currentJourneySegmentIndex.asStateFlow()

    // Bip! QR state (simulated)
    private val _activeQr = MutableStateFlow<BipQrCode?>(null)
    val activeQr: StateFlow<BipQrCode?> = _activeQr.asStateFlow()

    init {
        // Automatically provision a default Bip card for demo purposes on first startup
        repoScope.launch {
            val existingCards = dao.getAllBipCards().first()
            if (existingCards.isEmpty()) {
                val defaultCard = BipCardEntity(
                    cardNumber = "2104 5598 0032",
                    cardName = "Mi Bip! Diaria",
                    balance = 5600,
                    status = "ACTIVA",
                    lastUpdated = System.currentTimeMillis()
                )
                dao.insertBipCard(defaultCard)

                // Add some initial transaction logs
                dao.insertTransaction(
                    BipTransactionEntity(
                        id = "tx_init_0",
                        cardNumber = defaultCard.cardNumber,
                        amount = 3500,
                        type = "RECARGA",
                        description = "Carga Inicial WEB",
                        timestamp = System.currentTimeMillis() - 86400000 * 2 // 2 days ago
                    )
                )
                dao.insertTransaction(
                    BipTransactionEntity(
                        id = "tx_init_1",
                        cardNumber = defaultCard.cardNumber,
                        amount = 730,
                        type = "VIAJE",
                        description = "Viaje en Bus 405",
                        timestamp = System.currentTimeMillis() - 86400000 * 1 // 1 day ago
                    )
                )
                dao.insertTransaction(
                    BipTransactionEntity(
                        id = "tx_init_2",
                        cardNumber = defaultCard.cardNumber,
                        amount = 0,
                        type = "INTEGRACION",
                        description = "Combinación Metro L1",
                        timestamp = System.currentTimeMillis() - 86400000 * 1 + 1800000 // 1 day ago + 30 mins
                    )
                )
            }
        }
    }

    // --- Favorites ---
    fun getFavorites(): Flow<List<FavoriteEntity>> = dao.getAllFavorites()

    suspend fun addFavorite(id: String, name: String, type: String) {
        dao.insertFavorite(FavoriteEntity(id, name, type))
        TransportSimulator.logEvent("FAVORITE_ADDED", "Marcado como favorito: $name ($type)")
    }

    suspend fun removeFavorite(id: String) {
        dao.deleteFavoriteById(id)
        TransportSimulator.logEvent("FAVORITE_REMOVED", "Eliminado de favoritos: $id")
    }

    suspend fun isFavorite(id: String): Boolean = dao.isFavoriteExists(id)

    // --- Recent Routes ---
    fun getRecentRoutes(): Flow<List<RecentRouteEntity>> = dao.getRecentRoutes()

    suspend fun addRecentRoute(fromId: String, fromName: String, toId: String, toName: String) {
        val key = "${fromId}_${toId}"
        dao.insertRecentRoute(RecentRouteEntity(key, fromId, fromName, toId, toName))
    }

    // --- Bip! Card operations ---
    fun getBipCards(): Flow<List<BipCard>> = dao.getAllBipCards().map { list ->
        list.map { BipCard(it.cardNumber, it.cardName, it.balance, it.status, it.lastUpdated) }
    }

    suspend fun addNewBipCard(cardNumber: String, cardName: String) {
        val newCard = BipCardEntity(
            cardNumber = cardNumber,
            cardName = cardName,
            balance = 0,
            status = "ACTIVA"
        )
        dao.insertBipCard(newCard)
        dao.insertTransaction(
            BipTransactionEntity(
                id = UUID.randomUUID().toString(),
                cardNumber = cardNumber,
                amount = 0,
                type = "RECARGA",
                description = "Tarjeta registrada",
                timestamp = System.currentTimeMillis()
            )
        )
        TransportSimulator.logEvent("BIP_ADDED", "Tarjeta Bip! añadida: $cardNumber")
    }

    suspend fun deleteBipCard(cardNumber: String) {
        dao.deleteBipCard(cardNumber)
        TransportSimulator.logEvent("BIP_REMOVED", "Tarjeta Bip! eliminada: $cardNumber")
    }

    fun getTransactions(cardNumber: String): Flow<List<BipTransaction>> = dao.getTransactionsForCard(cardNumber).map { list ->
        list.map { BipTransaction(it.id, it.cardNumber, it.amount, it.type, it.description, it.timestamp) }
    }

    suspend fun requestBipTopUp(cardNumber: String, amount: Int): String {
        val txId = "topup_${UUID.randomUUID().toString().take(6)}"
        TransportSimulator.logEvent("BIP_TOPUP_REQUESTED", "Carga remota de $$amount solicitada para tarjeta $cardNumber.")

        // Insert pending transaction log
        dao.insertTransaction(
            BipTransactionEntity(
                id = txId,
                cardNumber = cardNumber,
                amount = amount,
                type = "RECARGA_PENDIENTE",
                description = "Carga remota (Pendiente Validación)",
                timestamp = System.currentTimeMillis()
            )
        )
        return txId
    }

    suspend fun validateBipTopUp(cardNumber: String, pendingTxId: String) {
        val card = dao.getBipCard(cardNumber) ?: return
        dao.insertTransaction(
            BipTransactionEntity(
                id = pendingTxId,
                cardNumber = cardNumber,
                amount = card.balance, // old balance reference
                type = "RECARGA",
                description = "Carga remota validada totém",
                timestamp = System.currentTimeMillis()
            )
        )

        // Find the amount loaded from transactions or default
        // Let's increment card balance by $5000 or custom amount for demo
        val defaultLoad = 5000
        val newBalance = card.balance + defaultLoad
        dao.updateBipCardBalance(cardNumber, newBalance, System.currentTimeMillis())

        TransportSimulator.logEvent("BIP_TOPUP_VALIDATED", "Carga de $$defaultLoad validada en tótem para tarjeta $cardNumber.")
    }

    suspend fun directTopUp(cardNumber: String, amount: Int) {
        val card = dao.getBipCard(cardNumber) ?: return
        val newBalance = card.balance + amount
        dao.updateBipCardBalance(cardNumber, newBalance, System.currentTimeMillis())

        dao.insertTransaction(
            BipTransactionEntity(
                id = "direct_${UUID.randomUUID().toString().take(6)}",
                cardNumber = cardNumber,
                amount = amount,
                type = "RECARGA",
                description = "Carga Directa Web",
                timestamp = System.currentTimeMillis()
            )
        )
        TransportSimulator.logEvent("BIP_TOPUP_VALIDATED", "Carga directa de $$amount exitosa para tarjeta $cardNumber.")
    }

    // --- BIP! QR Code ---
    fun generateBipQr(cardNumber: String, amount: Int = 730) {
        val active = _activeQr.value
        if (active != null && active.state == QrState.ACTIVO) {
            _activeQr.value = active.copy(state = QrState.CANCELADO)
        }

        val qrId = "qr_${UUID.randomUUID().toString().take(6)}"
        val expires = System.currentTimeMillis() + 120000 // 2 minutes expiry
        val newQr = BipQrCode(
            id = qrId,
            qrContent = "BIP_DEMO_QR_SANTIAGO_$qrId",
            state = QrState.CREANDO,
            createdAt = System.currentTimeMillis(),
            expiresAt = expires,
            amount = amount
        )
        _activeQr.value = newQr
        TransportSimulator.logEvent("QR_CREATED", "Generando código QR bip! de demostración.")

        repoScope.launch {
            delay(1000) // simulating generation
            _activeQr.value = newQr.copy(state = QrState.ACTIVO)
            TransportSimulator.logEvent("QR_ACTIVED", "Código QR bip! activo para validación.")

            // Auto-expiration flow
            delay(120000)
            val currentQr = _activeQr.value
            if (currentQr != null && currentQr.id == qrId && currentQr.state == QrState.ACTIVO) {
                _activeQr.value = currentQr.copy(state = QrState.EXPIRADO)
                TransportSimulator.logEvent("QR_EXPIRED", "Código QR bip! expiró tras 2 minutos.")
            }
        }
    }

    suspend fun useBipQr(cardNumber: String) {
        val qr = _activeQr.value
        if (qr != null && qr.state == QrState.ACTIVO) {
            val card = dao.getBipCard(cardNumber) ?: return
            if (card.balance >= qr.amount) {
                val newBal = card.balance - qr.amount
                dao.updateBipCardBalance(cardNumber, newBal, System.currentTimeMillis())
                dao.insertTransaction(
                    BipTransactionEntity(
                        id = UUID.randomUUID().toString(),
                        cardNumber = cardNumber,
                        amount = qr.amount,
                        type = "VIAJE",
                        description = "Pago bip! QR (Demo)",
                        timestamp = System.currentTimeMillis()
                    )
                )
                _activeQr.value = qr.copy(state = QrState.UTILIZADO)
                TransportSimulator.logEvent("QR_UTILIZED", "Código QR escaneado con éxito. Descontado $$qr.amount")
            } else {
                _activeQr.value = qr.copy(state = QrState.CANCELADO)
                TransportSimulator.logEvent("QR_FAILED", "Fallo de pago QR: Saldo insuficiente.")
            }
        }
    }

    // --- Active Journey Navigation ---
    fun startActiveJourney(journey: RouteResult) {
        _activeJourney.value = journey
        _currentJourneySegmentIndex.value = 0
        TransportSimulator.logEvent("ROUTE_STARTED", "Inicio de navegación para ruta hacia ${journey.segments.lastOrNull()?.toName}.")
    }

    fun advanceJourneySegment() {
        val curr = _currentJourneySegmentIndex.value
        val journey = _activeJourney.value
        if (journey != null && curr < journey.segments.size - 1) {
            _currentJourneySegmentIndex.value = curr + 1
            val seg = journey.segments[curr + 1]
            TransportSimulator.logEvent("TRANSFER_COMPLETED", "Avanzado en el trayecto. Siguiente paso: ${seg.instruction}")
        }
    }

    fun endActiveJourney() {
        val journey = _activeJourney.value
        _activeJourney.value = null
        _currentJourneySegmentIndex.value = 0
        if (journey != null) {
            TransportSimulator.logEvent("TRANSFER_COMPLETED", "Viaje finalizado con éxito.")
        }
    }

    // --- Routing Planner ---
    fun calculateRoutes(fromId: String, toId: String): List<RouteResult> {
        val simState = TransportSimulator.simState.value
        return DijkstraRouter.findRoutes(fromId, toId, simState.currentSimTime)
    }

    // --- Singleton Pattern ---
    companion object {
        @Volatile
        private var INSTANCE: TransportRepository? = null

        fun getInstance(context: Context): TransportRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = TransportRepository(context)
                INSTANCE = instance
                instance
            }
        }
    }
}
