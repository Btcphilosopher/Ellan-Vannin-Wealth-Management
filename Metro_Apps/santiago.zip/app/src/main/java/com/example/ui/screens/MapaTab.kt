package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.core.simulation.TransportSimulator
import com.example.data.providers.DemoDataProvider
import com.example.ui.TransportViewModel
import com.example.ui.components.borderStroke
import kotlin.math.sqrt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapaTab(viewModel: TransportViewModel) {
    val vehicles by viewModel.vehicles.collectAsState()
    val incidents by viewModel.incidents.collectAsState()

    val mapZoom by viewModel.mapZoom.collectAsState()
    val mapOffsetX by viewModel.mapOffsetX.collectAsState()
    val mapOffsetY by viewModel.mapOffsetY.collectAsState()
    val searchQuery by viewModel.mapSearchQuery.collectAsState()

    // Layer values
    val showMetro by viewModel.showLayerMetro.collectAsState()
    val showBuses by viewModel.showLayerBuses.collectAsState()
    val showNos by viewModel.showLayerNos.collectAsState()
    val showParaderos by viewModel.showLayerParaderos.collectAsState()
    val showEstaciones by viewModel.showLayerEstaciones.collectAsState()
    val showIncidencias by viewModel.showLayerIncidencias.collectAsState()

    val userLat by viewModel.userLat.collectAsState()
    val userLng by viewModel.userLng.collectAsState()

    var selectedNodeId by remember { mutableStateOf<String?>(null) }
    var selectedNodeName by remember { mutableStateOf<String?>(null) }
    var selectedNodeType by remember { mutableStateOf<String?>(null) }

    // Convert coordinates to canvas space
    fun getCanvasPosition(lat: Double, lng: Double, width: Float, height: Float): Offset {
        // Range bounding Santiago metropolitan area
        val minLat = -33.65
        val maxLat = -33.35
        val minLng = -70.80
        val maxLng = -70.52

        val normX = (lng - minLng) / (maxLng - minLng)
        val normY = (maxLat - lat) / (maxLat - minLat) // invert for screen coords

        val cx = width / 2f
        val cy = height / 2f

        val x = cx + (normX.toFloat() - 0.5f) * width * mapZoom + mapOffsetX
        val y = cy + (normY.toFloat() - 0.5f) * height * mapZoom + mapOffsetY

        return Offset(x, y)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        // Map Canvas Drawing
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoomChange, _ ->
                        viewModel.mapZoom.value = (viewModel.mapZoom.value * zoomChange).coerceIn(4f, 40f)
                        viewModel.mapOffsetX.value += pan.x
                        viewModel.mapOffsetY.value += pan.y
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        // Detect click on stations/paraderos
                        var foundNode: String? = null
                        var foundName: String? = null
                        var foundType: String? = null

                        val w = size.width.toFloat()
                        val h = size.height.toFloat()

                        // Check Stations
                        DemoDataProvider.metroStations.forEach { s ->
                            if ((s.lineId == "Nos" && showNos) || (s.lineId != "Nos" && showMetro)) {
                                val pos = getCanvasPosition(s.latitude, s.longitude, w, h)
                                val dist = sqrt(((offset.x - pos.x) * (offset.x - pos.x) + (offset.y - pos.y) * (offset.y - pos.y)).toDouble())
                                if (dist < 24.0) {
                                    foundNode = s.id
                                    foundName = "${s.name} (${s.lineId})"
                                    foundType = if (s.lineId == "Nos") "MetroTren" else "Metro"
                                }
                            }
                        }

                        // Check Paraderos
                        if (foundNode == null && showParaderos) {
                            DemoDataProvider.paraderos.forEach { p ->
                                val pos = getCanvasPosition(p.latitude, p.longitude, w, h)
                                val dist = sqrt(((offset.x - pos.x) * (offset.x - pos.x) + (offset.y - pos.y) * (offset.y - pos.y)).toDouble())
                                if (dist < 20.0) {
                                    foundNode = p.id
                                    foundName = p.name
                                    foundType = "Paradero"
                                }
                            }
                        }

                        selectedNodeId = foundNode
                        selectedNodeName = foundName
                        selectedNodeType = foundType
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // 1. Draw Metro lines segments
            if (showMetro) {
                DemoDataProvider.metroLines.filter { it.id != "Nos" }.forEach { line ->
                    val strokeColor = Color(android.graphics.Color.parseColor(line.hexColor))
                    val stations = line.stations.sortedBy { it.order }
                    for (i in 0 until stations.size - 1) {
                        val p1 = getCanvasPosition(stations[i].latitude, stations[i].longitude, w, h)
                        val p2 = getCanvasPosition(stations[i + 1].latitude, stations[i + 1].longitude, w, h)
                        drawLine(strokeColor, p1, p2, strokeWidth = 8f)
                    }
                }
            }

            // 2. Draw MetroTren Nos lines segments
            if (showNos) {
                val nosLine = DemoDataProvider.metroLines.find { it.id == "Nos" }
                if (nosLine != null) {
                    val strokeColor = Color(android.graphics.Color.parseColor(nosLine.hexColor))
                    val stations = nosLine.stations.sortedBy { it.order }
                    for (i in 0 until stations.size - 1) {
                        val p1 = getCanvasPosition(stations[i].latitude, stations[i].longitude, w, h)
                        val p2 = getCanvasPosition(stations[i + 1].latitude, stations[i + 1].longitude, w, h)
                        // Dashed look or double-line look for trains
                        drawLine(strokeColor, p1, p2, strokeWidth = 10f)
                        drawLine(Color.White, p1, p2, strokeWidth = 2f)
                    }
                }
            }

            // 3. Draw Bus Route lines segments (if selected/searched)
            if (showBuses) {
                DemoDataProvider.busRoutes.forEach { route ->
                    val strokeColor = Color(android.graphics.Color.parseColor(route.colorHex))
                    val stops = route.stops
                    for (i in 0 until stops.size - 1) {
                        val p1Id = stops[i]
                        val p2Id = stops[i + 1]
                        val stop1 = DemoDataProvider.paraderos.find { it.id == p1Id }
                        val stop2 = DemoDataProvider.paraderos.find { it.id == p2Id }
                        if (stop1 != null && stop2 != null) {
                            val pt1 = getCanvasPosition(stop1.latitude, stop1.longitude, w, h)
                            val pt2 = getCanvasPosition(stop2.latitude, stop2.longitude, w, h)
                            drawLine(strokeColor, pt1, pt2, strokeWidth = 4f)
                        }
                    }
                }
            }

            // 4. Draw Station Combinations (Transfer links)
            if (showMetro) {
                val stationsGrouped = DemoDataProvider.metroStations.groupBy { it.name }
                stationsGrouped.forEach { (_, stations) ->
                    if (stations.size > 1) {
                        // Draw black outline circle linking combinating platforms
                        val centerLat = stations.map { it.latitude }.average()
                        val centerLng = stations.map { it.longitude }.average()
                        val centerPos = getCanvasPosition(centerLat, centerLng, w, h)
                        drawCircle(Color.Black, radius = 18f, center = centerPos, style = Stroke(width = 4f))
                        drawCircle(Color.White, radius = 14f, center = centerPos)
                    }
                }
            }

            // 5. Draw Paraderos
            if (showParaderos) {
                DemoDataProvider.paraderos.forEach { p ->
                    val pos = getCanvasPosition(p.latitude, p.longitude, w, h)
                    drawCircle(Color(0xFF0F4C81), radius = 6f, center = pos)
                    drawCircle(Color.White, radius = 3f, center = pos)
                }
            }

            // 6. Draw Stations
            if (showEstaciones) {
                DemoDataProvider.metroStations.forEach { s ->
                    if ((s.lineId == "Nos" && showNos) || (s.lineId != "Nos" && showMetro)) {
                        val pos = getCanvasPosition(s.latitude, s.longitude, w, h)
                        val lineHex = DemoDataProvider.metroLines.find { it.id == s.lineId }?.hexColor ?: "#333"
                        val lineCol = Color(android.graphics.Color.parseColor(lineHex))

                        // Draw outer color ring
                        drawCircle(lineCol, radius = 10f, center = pos)
                        // Inner white center
                        drawCircle(Color.White, radius = 6f, center = pos)

                        // If highlighted or searched, draw double glowing ring
                        if (searchQuery.isNotEmpty() && s.name.contains(searchQuery, ignoreCase = true)) {
                            drawCircle(Color(0xFFE2231A), radius = 22f, center = pos, style = Stroke(width = 3f))
                        }
                    }
                }
            }

            // 7. Draw Active Incidents
            if (showIncidencias) {
                incidents.forEach { inc ->
                    if (inc.affectedStation != null) {
                        val stat = DemoDataProvider.metroStations.find { it.id == inc.affectedStation }
                        if (stat != null) {
                            val pos = getCanvasPosition(stat.latitude, stat.longitude, w, h)
                            // Draw flashing red alert triangle
                            drawCircle(Color(0xFFF57C00), radius = 16f, center = pos, style = Stroke(width = 2f))
                        }
                    }
                }
            }

            // 8. Draw Moving Simulated Vehicles
            vehicles.forEach { v ->
                if ((v.type == VehicleType.METRO && showMetro) ||
                    (v.type == VehicleType.METROTREN && showNos) ||
                    ((v.type == VehicleType.BUS_URBANO || v.type == VehicleType.BUS_ELECTRICO) && showBuses)
                ) {
                    val pos = getCanvasPosition(v.latitude, v.longitude, w, h)
                    val colorHex = when (v.type) {
                        VehicleType.METRO -> DemoDataProvider.metroLines.find { it.id == v.lineId }?.hexColor ?: "#333"
                        VehicleType.METROTREN -> "#8B5E3C"
                        else -> DemoDataProvider.busRoutes.find { it.id == v.lineId }?.colorHex ?: "#111"
                    }
                    val col = Color(android.graphics.Color.parseColor(colorHex))

                    // Draw solid vehicle triangle pointer
                    drawCircle(col, radius = 12f, center = pos)
                    drawCircle(Color.White, radius = 4f, center = pos)
                }
            }

            // 9. Draw Simulated User Location
            val userPos = getCanvasPosition(userLat, userLng, w, h)
            drawCircle(Color(0x332196F3), radius = 32f, center = userPos)
            drawCircle(Color.White, radius = 8f, center = userPos)
            drawCircle(Color(0xFF2196F3), radius = 5f, center = userPos)
        }

        // Search overlay bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter)
        ) {
            TextField(
                value = searchQuery,
                onValueChange = { viewModel.mapSearchQuery.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                placeholder = { Text("Buscar estaciones (Ej: Baquedano, Tobalaba)", fontSize = 14.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.mapSearchQuery.value = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = null)
                        }
                    }
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    disabledContainerColor = MaterialTheme.colorScheme.surface,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Filters / Layers bar
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    LayerChip("🚇 METRO", showMetro) { viewModel.showLayerMetro.value = !showMetro }
                }
                item {
                    LayerChip("🚍 BUSES", showBuses) { viewModel.showLayerBuses.value = !showBuses }
                }
                item {
                    LayerChip("🚊 NOS", showNos) { viewModel.showLayerNos.value = !showNos }
                }
                item {
                    LayerChip("🚏 PARADEROS", showParaderos) { viewModel.showLayerParaderos.value = !showParaderos }
                }
                item {
                    LayerChip("🏁 ESTACIONES", showEstaciones) { viewModel.showLayerEstaciones.value = !showEstaciones }
                }
                item {
                    LayerChip("⚠ INCIDENCIAS", showIncidencias) { viewModel.showLayerIncidencias.value = !showIncidencias }
                }
            }
        }

        // On-screen floating controls (Zoom, Recenter, Pan)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FloatingActionButton(
                onClick = { viewModel.mapZoom.value = (mapZoom + 2f).coerceAtMost(40f) },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In")
            }

            FloatingActionButton(
                onClick = { viewModel.mapZoom.value = (mapZoom - 2f).coerceAtLeast(4f) },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out")
            }

            FloatingActionButton(
                onClick = {
                    viewModel.mapZoom.value = 12.0f
                    viewModel.mapOffsetX.value = 0.0f
                    viewModel.mapOffsetY.value = 0.0f
                    viewModel.userLat.value = -33.4442
                    viewModel.userLng.value = -70.6508
                    TransportSimulator.logEvent("MAP_CENTERED", "Mapa centrado en ubicación del usuario (U. de Chile).")
                },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.MyLocation, contentDescription = "Centrar")
            }
        }

        // bottom Sheet Selection Inspection
        AnimatedVisibility(
            visible = selectedNodeId != null,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
                .padding(bottom = 60.dp),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = borderStroke()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = selectedNodeType?.uppercase() ?: "PUNTO DE CONEXIÓN",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = selectedNodeName ?: "Estación",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Código de red: ${selectedNodeId ?: ""}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Button(
                            onClick = {
                                val id = selectedNodeId
                                if (id != null) {
                                    viewModel.searchFromId.value = id
                                    viewModel.setTab(0) // Back to Inicio
                                    selectedNodeId = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("Fijar Origen", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        TextButton(
                            onClick = {
                                val id = selectedNodeId
                                if (id != null) {
                                    viewModel.searchToId.value = id
                                    viewModel.setTab(0) // Back to Inicio
                                    selectedNodeId = null
                                }
                            }
                        ) {
                            Text("Fijar Destino", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LayerChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
        shape = RoundedCornerShape(20.dp),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primary,
            selectedLabelColor = Color.White
        )
    )
}
