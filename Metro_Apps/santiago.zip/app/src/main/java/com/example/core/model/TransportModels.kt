package com.example.core.model

enum class ServiceStatus {
    NORMAL,
    DEMORADO,
    CON_ALTERACIONES,
    SUSPENDIDO,
    INFORMACION
}

enum class IncidentSeverity {
    BAJA,
    MEDIA,
    ALTA,
    CRITICA
}

enum class VehicleStatus {
    EN_RUTA,
    DETENIDO,
    FUERA_DE_SERVICIO,
    CON_RETRASO
}

enum class VehicleType {
    METRO,
    BUS_URBANO,
    BUS_ELECTRICO,
    METROTREN
}

data class MetroStation(
    val id: String,
    val name: String,
    val lineId: String,
    val order: Int,
    val hasElevator: Boolean = true,
    val connections: List<String> = emptyList(), // connected line IDs
    val latitude: Double,
    val longitude: Double,
    val importantPlaceId: String? = null
)

data class MetroLine(
    val id: String, // e.g., "L1", "L5"
    val name: String, // e.g., "Línea 1", "Línea 5"
    val hexColor: String, // e.g., "#E2231A" (red)
    val stations: List<MetroStation>,
    val status: ServiceStatus = ServiceStatus.NORMAL,
    val intervalMinutes: Int = 4,
    val statusDetails: String = "Operación normal"
)

data class Paradero(
    val id: String, // e.g., "PA183"
    val name: String, // e.g., "Providencia / Pedro de Valdivia"
    val direction: String, // e.g., "Al Oriente"
    val routes: List<String>, // e.g., ["405", "412", "418", "426"]
    val latitude: Double,
    val longitude: Double,
    val hasShelter: Boolean = true,
    val isAccessible: Boolean = true
)

data class BusRoute(
    val id: String, // e.g., "405"
    val name: String, // e.g., "Cantagallo - Maipú"
    val shortName: String, // "405"
    val colorHex: String = "#00838F",
    val type: VehicleType = VehicleType.BUS_ELECTRICO,
    val stops: List<String> // list of Paradero IDs
)

data class StationConnection(
    val stationId: String,
    val connectedLineId: String,
    val transferTimeSeconds: Int = 180
)

data class ServiceIncident(
    val id: String,
    val severity: IncidentSeverity,
    val affectedLine: String, // Line ID or "RED" for buses
    val affectedStation: String? = null, // Station ID or Paradero ID
    val startTime: String,
    val expectedEnd: String,
    val description: String,
    val alternativeRoute: String
)

data class Vehicle(
    val id: String,
    val type: VehicleType,
    val lineId: String, // Line ID or BusRoute ID
    val currentPositionIndex: Int, // index in the station/stop list
    val status: VehicleStatus,
    val currentSpeedKmh: Double,
    val currentDelaySeconds: Int,
    val destination: String,
    val isAccessible: Boolean = true,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val nextStopSeconds: Int = 60
)

data class BipCard(
    val cardNumber: String,
    val cardName: String,
    val balance: Int,
    val status: String, // "ACTIVA", "BLOQUEADA"
    val lastUpdated: Long,
    val isDemo: Boolean = true
)

data class BipTransaction(
    val id: String,
    val cardNumber: String,
    val amount: Int,
    val type: String, // "RECARGA", "VIAJE", "INTEGRACION"
    val description: String,
    val timestamp: Long
)

enum class QrState {
    CREANDO,
    ACTIVO,
    UTILIZADO,
    EXPIRADO,
    CANCELADO
}

data class BipQrCode(
    val id: String,
    val qrContent: String,
    val state: QrState,
    val createdAt: Long,
    val expiresAt: Long,
    val amount: Int = 730
)

data class ImportantPlace(
    val id: String,
    val name: String,
    val category: String, // "AEROPUERTO", "ESTACION", "INTERMODAL", "CENTRO"
    val latitude: Double,
    val longitude: Double,
    val connectedStops: List<String> // connected stations/paraderos IDs
)
