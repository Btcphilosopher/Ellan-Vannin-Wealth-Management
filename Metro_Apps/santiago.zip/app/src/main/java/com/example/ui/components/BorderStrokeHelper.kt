package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

@Composable
fun borderStroke() = BorderStroke(
    width = 1.dp,
    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f)
)
