package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Santiago Metro Red (Intense transport red)
val RedMetro = Color(0xFFE2231A)
val RedMetroDark = Color(0xFFB71C1C)

// Deep Blue (Santiago's corporate/intermodal navy)
val BlueSantiago = Color(0xFF0F4C81)

// Graphite & Cement (Brutalist architecture / concrete look)
val ConcreteGray = Color(0xFFECEFF1)
val CementStripe = Color(0xFFCFD8DC)
val GraphiteDark = Color(0xFF263238)
val SoftBlack = Color(0xFF121212)
val WarmWhite = Color(0xFFFBFBF8)

// Secondary/Accent Colors
val GreenStatus = Color(0xFF008E3A)
val AmberWarning = Color(0xFFF57C00)
val CopperNos = Color(0xFF8B5E3C)
