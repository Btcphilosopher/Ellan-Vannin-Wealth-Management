package com.example

import com.example.core.routing.DijkstraRouter
import com.example.core.routing.RoutePreference
import com.example.core.simulation.TransportSimulator
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testDijkstraRouter_findsRoute() {
    // Calculate a path between two L1 metro stations (Baquedano to Pajaritos)
    val results = DijkstraRouter.findRoutes("L1_Baquedano", "L1_Pajaritos")
    
    // There should be route results computed
    assertNotNull(results)
    assertTrue(results.isNotEmpty())

    // The fastest route should exist
    val fastest = results.find { it.preference == RoutePreference.MAS_RAPIDA }
    assertNotNull(fastest)
    assertTrue(fastest!!.totalDurationSeconds > 0)
    assertTrue(fastest.segments.isNotEmpty())

    // All segments should contain non-empty instruction metadata
    fastest.segments.forEach { segment ->
      assertTrue(segment.fromName.isNotEmpty())
      assertTrue(segment.toName.isNotEmpty())
      assertTrue(segment.instruction.isNotEmpty())
    }
  }

  @Test
  fun testDijkstraRouter_differentPreferences() {
    // Compute paths with different optimization criteria between Tobalaba and Plaza de Maipú
    val results = DijkstraRouter.findRoutes("L1_Tobalaba", "L5_Plaza_de_Maipu")
    assertNotNull(results)

    val fastest = results.find { it.preference == RoutePreference.MAS_RAPIDA }
    val accessible = results.find { it.preference == RoutePreference.MAS_ACCESIBLE }
    val transfers = results.find { it.preference == RoutePreference.MENOS_TRANSBORDOS }
    val walking = results.find { it.preference == RoutePreference.MENOS_CAMINATA }

    assertNotNull(fastest)
    assertNotNull(accessible)
    assertNotNull(transfers)
    assertNotNull(walking)
  }

  @Test
  fun testSimulator_stateModifications() {
    // Verify play states
    TransportSimulator.startSimulation()
    var state = TransportSimulator.simState.value
    assertTrue(state.isPlaying)

    // Verify pause states
    TransportSimulator.pauseSimulation()
    state = TransportSimulator.simState.value
    assertFalse(state.isPlaying)

    // Verify speed factors
    TransportSimulator.setSpeedMultiplier(300)
    state = TransportSimulator.simState.value
    assertEquals(300, state.speedMultiplier)

    // Restore simulator to original state
    TransportSimulator.setSpeedMultiplier(1)
    TransportSimulator.startSimulation()
  }
}
