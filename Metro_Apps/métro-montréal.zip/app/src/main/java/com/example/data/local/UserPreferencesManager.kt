package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "metro_user_preferences")

class UserPreferencesManager(private val context: Context) {

    companion object {
        val KEY_LANGUAGE = stringPreferencesKey("language")
        val KEY_THEME = stringPreferencesKey("theme")
        val KEY_STEP_FREE = booleanPreferencesKey("step_free")
        val KEY_REDUCED_STAIRS = booleanPreferencesKey("reduced_stairs")
        val KEY_HIGH_CONTRAST = booleanPreferencesKey("high_contrast")
        val KEY_LARGE_TEXT = booleanPreferencesKey("large_text")
        val KEY_HAPTIC = booleanPreferencesKey("haptic")
        val KEY_REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val KEY_IS_ONBOARDED = booleanPreferencesKey("is_onboarded")
    }

    // --- GETTERS ---

    val languageFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_LANGUAGE] ?: "fr" // Default is French as requested
    }

    val themeFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_THEME] ?: "system"
    }

    val stepFreeFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_STEP_FREE] ?: false
    }

    val reducedStairsFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_REDUCED_STAIRS] ?: false
    }

    val highContrastFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_HIGH_CONTRAST] ?: false
    }

    val largeTextFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_LARGE_TEXT] ?: false
    }

    val hapticFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_HAPTIC] ?: true
    }

    val reducedMotionFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_REDUCED_MOTION] ?: false
    }

    val isOnboardedFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_IS_ONBOARDED] ?: false
    }

    // --- SETTERS ---

    suspend fun setLanguage(language: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LANGUAGE] = language
        }
    }

    suspend fun setTheme(theme: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_THEME] = theme
        }
    }

    suspend fun setStepFree(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_STEP_FREE] = enabled
        }
    }

    suspend fun setReducedStairs(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_REDUCED_STAIRS] = enabled
        }
    }

    suspend fun setHighContrast(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_HIGH_CONTRAST] = enabled
        }
    }

    suspend fun setLargeText(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LARGE_TEXT] = enabled
        }
    }

    suspend fun setHaptic(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_HAPTIC] = enabled
        }
    }

    suspend fun setReducedMotion(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_REDUCED_MOTION] = enabled
        }
    }

    suspend fun setIsOnboarded(onboarded: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_IS_ONBOARDED] = onboarded
        }
    }

    suspend fun clearPreferences() {
        context.dataStore.edit { prefs ->
            prefs.clear()
        }
    }
}
