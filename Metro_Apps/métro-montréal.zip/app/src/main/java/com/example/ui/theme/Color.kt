package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// STM transit line colors
val StmGreen = Color(0xFF008E4F)
val StmOrange = Color(0xFFEE7F2D)
val StmYellow = Color(0xFFFAD135)
val StmBlue = Color(0xFF007EC5)

// Brutalist concrete and steel (warm/cool architectural greys)
val ConcreteLight = Color(0xFFF2F4F7)
val ConcreteDark = Color(0xFF1E2125)
val SteelGrey = Color(0xFF8A95A5)
val CharcoalSteel = Color(0xFF121417)

// Dark/Light Theme Primary tokens (Pure architectural modernism: bold blacks & crisp off-whites)
val MtlBlack = Color(0xFF0D0F12)
val MtlOffWhite = Color(0xFFF9FAFC)
val StmBlueAccent = Color(0xFF0083D1)

// High Contrast Accessibility Mode Colors
val HighContrastYellow = Color(0xFFFFF000)
val HighContrastBlue = Color(0xFF0000FF)
val PureBlack = Color(0xFF000000)
val PureWhite = Color(0xFFFFFFFF)
