package com.example.feature.tickets

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.model.DemoTicket
import com.example.domain.model.OpusCard
import com.example.domain.model.TicketProduct
import com.example.domain.model.TicketStatus
import com.example.feature.MetroViewModel
import com.example.ui.theme.StmBlue
import com.example.ui.theme.SteelGrey

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketsTabScreen(viewModel: MetroViewModel) {
    val languageState = viewModel.language.collectAsState().value
    val ticketsList = viewModel.demoTickets.collectAsState().value
    val opusCards = viewModel.opusCards.collectAsState().value

    val selectedProduct by viewModel.selectedProduct.collectAsState()
    val paymentState by viewModel.paymentState.collectAsState()
    val selectedTicketId by viewModel.selectedTicketId.collectAsState()

    var activeSubScreen by remember { mutableStateOf("dashboard") } // "dashboard", "buy", "review", "add_opus", "ticket_view"

    // Target digital ticket for detailed view
    val activeTicket = ticketsList.find { it.id == selectedTicketId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = if (activeSubScreen == "buy") {
                        stringResource(R.string.buy_tickets).uppercase()
                    } else if (activeSubScreen == "add_opus") {
                        "AJOUTER OPUS"
                    } else if (activeSubScreen == "ticket_view") {
                        "BILLET DIGITAL / DIGITAL TICKET"
                    } else {
                        stringResource(R.string.tab_tickets).uppercase()
                    },
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            },
            navigationIcon = {
                if (activeSubScreen != "dashboard") {
                    IconButton(onClick = {
                        if (activeSubScreen == "review") {
                            activeSubScreen = "buy"
                        } else {
                            activeSubScreen = "dashboard"
                            viewModel.resetPayment()
                        }
                    }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        // Routing inside Tickets Tab
        when (activeSubScreen) {
            "dashboard" -> TicketsDashboardScreen(
                viewModel = viewModel,
                languageState = languageState,
                opusCards = opusCards,
                ticketsList = ticketsList,
                onNavigateToBuy = { activeSubScreen = "buy" },
                onNavigateToAddOpus = { activeSubScreen = "add_opus" },
                onSelectTicket = { id ->
                    viewModel.selectTicket(id)
                    activeSubScreen = "ticket_view"
                }
            )
            "buy" -> TicketCatalogueScreen(
                viewModel = viewModel,
                languageState = languageState,
                onSelectProduct = { prod ->
                    viewModel.selectProductForPurchase(prod)
                    activeSubScreen = "review"
                }
            )
            "add_opus" -> AddOpusCardScreen(
                viewModel = viewModel,
                onSuccess = { activeSubScreen = "dashboard" }
            )
            "review" -> selectedProduct?.let { product ->
                PurchaseReviewScreen(
                    product = product,
                    viewModel = viewModel,
                    languageState = languageState,
                    paymentState = paymentState,
                    opusCards = opusCards,
                    onSuccess = { activeSubScreen = "dashboard" },
                    onCancel = {
                        viewModel.resetPayment()
                        activeSubScreen = "buy"
                    }
                )
            }
            "ticket_view" -> activeTicket?.let { ticket ->
                DigitalTicketDetailScreen(
                    ticket = ticket,
                    viewModel = viewModel,
                    language = languageState
                )
            }
        }
    }
}

// --- SUB SCREEN: TICKETS DASHBOARD ---
@Composable
fun TicketsDashboardScreen(
    viewModel: MetroViewModel,
    languageState: String,
    opusCards: List<OpusCard>,
    ticketsList: List<DemoTicket>,
    onNavigateToBuy: () -> Unit,
    onNavigateToAddOpus: () -> Unit,
    onSelectTicket: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- OPUS CARD MODULE ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CARTES OPUS / OPUS DASHBOARD",
                style = MaterialTheme.typography.labelSmall,
                color = SteelGrey,
                letterSpacing = 1.sp
            )

            TextButton(onClick = onNavigateToAddOpus, modifier = Modifier.testTag("add_opus_nav")) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Ajouter / Add", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (opusCards.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.CreditCardOff, contentDescription = null, tint = SteelGrey, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Aucune carte OPUS / No OPUS cards", fontWeight = FontWeight.Bold)
                }
            }
        } else {
            opusCards.forEach { card ->
                // Beautiful Tactile STM Blue Card Representation
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = StmBlue),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = card.nickname.uppercase(),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = card.id,
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }

                            // STM logo placeholder
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.White.copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "OPUS",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(
                                    text = "SOLDE / BALANCE",
                                    fontSize = 10.sp,
                                    color = Color.White.copy(alpha = 0.7f),
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = String.format(java.util.Locale.US, "$%.2f", card.balance),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            }

                            Text(
                                text = if (languageState == "fr") card.lastActivityFr else card.lastActivityEn,
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }

        // --- TICKETS CONTAINER MODULE ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MES TITRES / ACTIVE TICKETS",
                style = MaterialTheme.typography.labelSmall,
                color = SteelGrey,
                letterSpacing = 1.sp
            )

            Button(
                onClick = onNavigateToBuy,
                shape = MaterialTheme.shapes.small,
                colors = ButtonDefaults.buttonColors(containerColor = StmBlue),
                modifier = Modifier.testTag("buy_tickets_nav")
            ) {
                Text(text = "Acheter / Buy", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        val activeTickets = ticketsList.filter { it.status == TicketStatus.ACTIVE }

        if (activeTickets.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ConfirmationNumber,
                        contentDescription = null,
                        tint = SteelGrey,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Aucun titre de transport actif / No active tickets",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            activeTickets.forEach { ticket ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectTicket(ticket.id) }
                        .testTag("active_ticket_${ticket.id}"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ConfirmationNumber,
                                contentDescription = null,
                                tint = StmBlue,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = if (languageState == "fr") ticket.productNameFr else ticket.productNameEn,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    text = "Réf : ${ticket.id}",
                                    fontSize = 11.sp,
                                    color = SteelGrey
                                )
                            }
                        }

                        // Status Badge
                        Badge(containerColor = Color(0xFFE8F5E9), contentColor = Color(0xFF2E7D32)) {
                            Text(text = "ACTIF", fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                        }
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: TICKET PRODUCT CATALOGUE ---
@Composable
fun TicketCatalogueScreen(
    viewModel: MetroViewModel,
    languageState: String,
    onSelectProduct: (TicketProduct) -> Unit
) {
    val products = viewModel.repository.products

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "⚠️ " + stringResource(R.string.demo_only_warning),
                modifier = Modifier.padding(16.dp),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }

        products.forEach { product ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectProduct(product) }
                    .testTag("catalogue_product_${product.id}"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (languageState == "fr") product.nameFr else product.nameEn,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Zone : " + (if (languageState == "fr") product.zoneFr else product.zoneEn),
                                fontSize = 11.sp,
                                color = SteelGrey,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        Text(
                            text = String.format(java.util.Locale.US, "$%.2f", product.price),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = StmBlue
                        )
                    }

                    Text(
                        text = if (languageState == "fr") product.descriptionFr else product.descriptionEn,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 12.dp)
                    )

                    Divider(modifier = Modifier.padding(vertical = 12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Validité : " + (if (languageState == "fr") product.validityFr else product.validityEn),
                            fontSize = 11.sp,
                            color = SteelGrey
                        )

                        Text(
                            text = "DÉMO SEULEMENT",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = StmBlue
                        )
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: ADD DEMO OPUS CARD ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddOpusCardScreen(
    viewModel: MetroViewModel,
    onSuccess: () -> Unit
) {
    var nickname by remember { mutableStateOf("") }
    var cardNumber by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Ajoutez une carte OPUS de simulation pour gérer votre solde et acheter des titres directement bilingues.",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = nickname,
            onValueChange = { nickname = it },
            label = { Text("Surnom de la carte / Nickname") },
            placeholder = { Text("Ex: Ma Carte") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("opus_nickname_input")
        )

        OutlinedTextField(
            value = cardNumber,
            onValueChange = { cardNumber = it },
            label = { Text("Numéro de carte OPUS") },
            placeholder = { Text("Ex: 0123 4567 89") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("opus_number_input")
        )

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = {
                viewModel.addDemoOpusCard(nickname, cardNumber)
                onSuccess()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("opus_save_button"),
            colors = ButtonDefaults.buttonColors(containerColor = StmBlue),
            shape = MaterialTheme.shapes.small
        ) {
            Text(text = "CONFIRMER / SAVE", fontWeight = FontWeight.Bold)
        }
    }
}

// --- SUB SCREEN: PURCHASE REVIEW & PAYMENT ---
@Composable
fun PurchaseReviewScreen(
    product: TicketProduct,
    viewModel: MetroViewModel,
    languageState: String,
    paymentState: MetroViewModel.PaymentState,
    opusCards: List<OpusCard>,
    onSuccess: () -> Unit,
    onCancel: () -> Unit
) {
    var selectedPayMethod by remember { mutableStateOf("demo_cc") } // "demo_cc", or dynamic OPUS card id

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                text = stringResource(R.string.purchase_review).uppercase(),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black
            )

            // Invoice Summary Box
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (languageState == "fr") product.nameFr else product.nameEn,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = String.format(java.util.Locale.US, "$%.2f", product.price),
                            fontWeight = FontWeight.Black
                        )
                    }
                    Divider(modifier = Modifier.padding(vertical = 12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "TOTAL (Démo)", fontWeight = FontWeight.Bold, color = StmBlue)
                        Text(
                            text = String.format(java.util.Locale.US, "$%.2f", product.price),
                            fontWeight = FontWeight.Black,
                            color = StmBlue,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                }
            }

            // Payment Methods Selection
            Text(
                text = stringResource(R.string.payment_method).uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = SteelGrey,
                letterSpacing = 1.sp
            )

            // Fake credit card option
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedPayMethod = "demo_cc" },
                border = BorderStroke(
                    2.dp,
                    if (selectedPayMethod == "demo_cc") StmBlue else Color.Transparent
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedPayMethod == "demo_cc",
                        onClick = { selectedPayMethod = "demo_cc" }
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(text = "Carte de crédit Démo / Demo Credit Card", fontWeight = FontWeight.Bold)
                        Text(text = "Finit par **** 4321", fontSize = 11.sp, color = SteelGrey)
                    }
                }
            }

            // OPUS debit option if card exists
            opusCards.forEach { card ->
                val hasFunds = card.balance >= product.price
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = hasFunds) { selectedPayMethod = card.id },
                    border = BorderStroke(
                        2.dp,
                        if (selectedPayMethod == card.id) StmBlue else Color.Transparent
                    ),
                    colors = CardDefaults.cardColors(
                        containerColor = if (hasFunds) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedPayMethod == card.id,
                            onClick = { selectedPayMethod = card.id },
                            enabled = hasFunds
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = "Débiter la carte OPUS : ${card.nickname}",
                                fontWeight = FontWeight.Bold,
                                color = if (hasFunds) MaterialTheme.colorScheme.onSurface else SteelGrey
                            )
                            Text(
                                text = "Solde : " + String.format(java.util.Locale.US, "$%.2f", card.balance) + (if (!hasFunds) " (Fonds insuffisants)" else ""),
                                fontSize = 11.sp,
                                color = if (hasFunds) StmBlue else Color.Red
                            )
                        }
                    }
                }
            }
        }

        // --- SUBMIT CONTROLS AND STATE ANIMATIONS ---
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDE7))
            ) {
                Text(
                    text = "⚠️ " + stringResource(R.string.demo_only_warning),
                    modifier = Modifier.padding(12.dp),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    textAlign = TextAlign.Center
                )
            }

            when (paymentState) {
                is MetroViewModel.PaymentState.Idle -> {
                    Button(
                        onClick = {
                            val cardId = if (selectedPayMethod != "demo_cc") selectedPayMethod else null
                            viewModel.confirmPurchase(cardId)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("confirm_purchase_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = StmBlue),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Text(text = stringResource(R.string.confirm_purchase).uppercase(), fontWeight = FontWeight.Bold)
                    }
                }
                is MetroViewModel.PaymentState.Pending -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = StmBlue)
                    }
                }
                is MetroViewModel.PaymentState.Success -> {
                    Text(
                        text = "Achat réussi ! Redirection...",
                        color = Color.Green,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    LaunchedEffect(Unit) {
                        kotlinx.coroutines.delay(1000)
                        onSuccess()
                    }
                }
                is MetroViewModel.PaymentState.Error -> {
                    val errMsg = if (languageState == "fr") paymentState.messageFr else paymentState.messageEn
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = errMsg,
                            color = Color.Red,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { viewModel.resetPayment() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                            shape = MaterialTheme.shapes.small
                        ) {
                            Text(text = "RÉESSAYER / RETRY")
                        }
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: DIGITAL TICKET VISUAL ---
@Composable
fun DigitalTicketDetailScreen(
    ticket: DemoTicket,
    viewModel: MetroViewModel,
    language: String
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tactile paper-ticket rendering card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Digital watermark header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SOCIÉTÉ DE TRANSPORT DE MONTRÉAL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = SteelGrey,
                        letterSpacing = 0.5.sp
                    )

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(StmBlue)
                            .size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Product Title
                Text(
                    text = (if (language == "fr") ticket.productNameFr else ticket.productNameEn).uppercase(),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    color = Color.Black,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "TARIF ORDINAIRE / REGULAR FARE",
                    fontSize = 11.sp,
                    color = SteelGrey,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(32.dp))

                // FAKE DUMMY ACCESSIBLE QR CODE BOX
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .background(Color.White)
                        .border(1.dp, Color.Black)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Drawing some lines to look like a barcode/QR
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Simulated QR Code",
                            modifier = Modifier.size(120.dp),
                            tint = Color.Black
                        )
                        Text(
                            text = "DEMO ONLY",
                            fontWeight = FontWeight.Black,
                            color = StmBlue,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "RÉF : ${ticket.id}",
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Divider(modifier = Modifier.padding(vertical = 16.dp), color = Color.LightGray)

                // Ticket Validity Footer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "ÉMIS LE / ISSUED", fontSize = 10.sp, color = SteelGrey)
                        Text(
                            text = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ticket.purchaseDate)),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "STATUT / STATUS", fontSize = 10.sp, color = SteelGrey)
                        Badge(containerColor = Color(0xFFE8F5E9), contentColor = Color(0xFF2E7D32)) {
                            Text(text = "VALIDE / ACTIVE", fontWeight = FontWeight.Bold, modifier = Modifier.padding(2.dp))
                        }
                    }
                }
            }
        }

        // Large explicit data honesty warning
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Dangerous, contentDescription = null, tint = Color.Red)
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = stringResource(R.string.ticket_not_valid_for_travel),
                    color = Color.Red,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
