package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.local.MetroDatabase
import com.example.data.local.UserPreferencesManager
import com.example.domain.model.*
import com.example.domain.routing.MetroRoutingEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MetroRepository private constructor(context: Context) {

    companion object {
        @Volatile
        private var INSTANCE: MetroRepository? = null

        fun getInstance(context: Context): MetroRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = MetroRepository(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    private val db = Room.databaseBuilder(
        context,
        MetroDatabase::class.java,
        "metro_montreal_db"
    ).fallbackToDestructiveMigration().build()

    private val dao = db.metroDao()
    val preferencesManager = UserPreferencesManager(context)

    // --- STATIC CONTENT (EXPOSED BILINGUALLY) ---
    val allStations: List<MetroStation> = MetroRoutingEngine.stations
    val allLines: List<MetroLine> = MetroRoutingEngine.lines

    // --- STATE FLOWS ---
    val serviceAlerts: Flow<List<ServiceAlert>> = dao.getAllAlerts()
    val opusCards: Flow<List<OpusCard>> = dao.getAllOpusCards()
    val demoTickets: Flow<List<DemoTicket>> = dao.getAllTickets()
    val favourites: Flow<List<FavouriteStation>> = dao.getAllFavourites()

    // --- LOCAL SIMULATION ENGINE STATE ---
    private val _isOffline = MutableStateFlow(false)
    val isOffline: StateFlow<Boolean> = _isOffline.asStateFlow()

    private val _currentScenario = MutableStateFlow(SimulationScenario.NORMAL)
    val currentScenario: StateFlow<SimulationScenario> = _currentScenario.asStateFlow()

    private val _isSimulationPaused = MutableStateFlow(false)
    val isSimulationPaused: StateFlow<Boolean> = _isSimulationPaused.asStateFlow()

    private val _simulatedTime = MutableStateFlow(System.currentTimeMillis())
    val simulatedTime: StateFlow<Long> = _simulatedTime.asStateFlow()

    private val _eventLogs = MutableStateFlow<List<SimulationEvent>>(emptyList())
    val eventLogs: StateFlow<List<SimulationEvent>> = _eventLogs.asStateFlow()

    private val repositoryScope = CoroutineScope(Dispatchers.IO)

    // --- CONSOLE CONTROL SCENARIO ACTIONS ---
    init {
        // Create initial demo OPUS card
        repositoryScope.launch {
            dao.getAllOpusCards().first().let { cards ->
                if (cards.isEmpty()) {
                    dao.insertOpusCard(
                        OpusCard(
                            id = "0123 4567 89",
                            nickname = "Ma carte principale",
                            statusFr = "Active",
                            statusEn = "Active",
                            balance = 12.50,
                            lastActivityFr = "Dernier passage il y a 10 min",
                            lastActivityEn = "Last scanned 10 mins ago",
                            isFavourite = true
                        )
                    )
                }
            }
            // Start default normal service scenario
            setScenario(SimulationScenario.NORMAL)
        }
    }

    fun isStationClosed(stationId: String): Boolean {
        val scenario = _currentScenario.value
        return (scenario == SimulationScenario.STATION_CLOSED && stationId == "cote_vertu") ||
                (scenario == SimulationScenario.MULTI_ALERTS && stationId == "cote_vertu")
    }

    fun getDisruptedLines(): Set<String> {
        val scenario = _currentScenario.value
        return when (scenario) {
            SimulationScenario.DELAY_ORANGE -> setOf("L2")
            SimulationScenario.MULTI_ALERTS -> setOf("L2")
            else -> emptySet()
        }
    }

    fun logEvent(messageFr: String, messageEn: String, type: String = "INFO") {
        val newEvent = SimulationEvent(
            timestamp = _simulatedTime.value,
            messageFr = messageFr,
            messageEn = messageEn,
            type = type
        )
        _eventLogs.update { listOf(newEvent) + it }
    }

    fun advanceTime() {
        _simulatedTime.update { it + 5 * 60 * 1000 } // Add 5 minutes
        logEvent(
            "Le temps de simulation a avancé de 5 minutes.",
            "Simulation time advanced by 5 minutes.",
            "TIME"
        )
    }

    fun toggleSimulationPause() {
        _isSimulationPaused.update { !it }
        val state = if (_isSimulationPaused.value) "PAUSE" else "PLAY"
        logEvent(
            "Moteur de simulation mis en mode: $state",
            "Simulation engine state: $state",
            "SYSTEM"
        )
    }

    suspend fun clearAllLocalData() {
        dao.clearAllAlerts()
        dao.clearAllOpusCards()
        dao.clearAllTickets()
        dao.clearAllFavourites()
        preferencesManager.clearPreferences()
        _eventLogs.value = emptyList()
        _currentScenario.value = SimulationScenario.NORMAL
        _isOffline.value = false

        // Re-insert initial OPUS
        dao.insertOpusCard(
            OpusCard(
                id = "0123 4567 89",
                nickname = "Ma carte principale",
                statusFr = "Active",
                statusEn = "Active",
                balance = 15.00,
                lastActivityFr = "Réinitialisé",
                lastActivityEn = "Reset",
                isFavourite = true
            )
        )
        setScenario(SimulationScenario.NORMAL)
        logEvent("Données locales réinitialisées.", "Local data reset.", "SYSTEM")
    }

    suspend fun setScenario(scenario: SimulationScenario) {
        _currentScenario.value = scenario
        dao.clearAllAlerts()
        _isOffline.value = false

        val alertsList = mutableListOf<ServiceAlert>()
        val timeNow = _simulatedTime.value

        when (scenario) {
            SimulationScenario.NORMAL -> {
                logEvent("Scénario: Service normal activé.", "Scenario: Normal service activated.", "SCENARIO")
            }
            SimulationScenario.DELAY_ORANGE -> {
                alertsList.add(
                    ServiceAlert(
                        id = "alert-orange-delay",
                        type = AlertCategory.DELAY,
                        titleFr = "Retard important — Ligne Orange",
                        titleEn = "Major Delay — Orange Line",
                        descriptionFr = "En raison d'un problème de signalisation à la station Snowdon, prévoyez des retards de 10 à 15 minutes sur l'ensemble de la ligne.",
                        descriptionEn = "Due to a signaling issue at Snowdon station, expect delays of 10 to 15 minutes across the entire line.",
                        affectedLineId = "L2",
                        affectedStationId = null,
                        severity = AlertSeverity.MAJOR,
                        startTime = timeNow,
                        endTime = null,
                        sourceStatus = "Simulated",
                        lastUpdated = timeNow
                    )
                )
                logEvent("Scénario: Retard de la ligne Orange injecté.", "Scenario: Orange Line delay injected.", "SCENARIO")
            }
            SimulationScenario.ELEVATOR_DOWN -> {
                alertsList.add(
                    ServiceAlert(
                        id = "alert-elevator-down",
                        type = AlertCategory.ELEVATOR_OUTAGE,
                        titleFr = "Ascenseur en panne — Berri-UQAM",
                        titleEn = "Elevator Outage — Berri-UQAM",
                        descriptionFr = "L'ascenseur reliant le quai de la ligne verte à l'édicule est temporairement hors service. Éviter cet itinéraire si vous avez besoin d'un accès sans marche.",
                        descriptionEn = "The elevator connecting the green line platform to the main hall is temporarily out of service. Avoid this route if you require step-free access.",
                        affectedLineId = "L1",
                        affectedStationId = "berri_uqam",
                        severity = AlertSeverity.MINOR,
                        startTime = timeNow,
                        endTime = null,
                        sourceStatus = "Simulated",
                        lastUpdated = timeNow
                    )
                )
                logEvent("Scénario: Ascenseur hors service à Berri-UQAM.", "Scenario: Elevator out of service at Berri-UQAM.", "SCENARIO")
            }
            SimulationScenario.STATION_CLOSED -> {
                alertsList.add(
                    ServiceAlert(
                        id = "alert-station-closed",
                        type = AlertCategory.STATION_CLOSURE,
                        titleFr = "Station Côte-Vertu FERMÉE",
                        titleEn = "Côte-Vertu Station CLOSED",
                        descriptionFr = "En raison de travaux urgents de structure, la station Côte-Vertu est fermée à toute clientèle. Des navettes circulent vers Snowdon.",
                        descriptionEn = "Due to urgent structural work, Côte-Vertu station is closed to all passengers. Shuttle buses are running to Snowdon.",
                        affectedLineId = "L2",
                        affectedStationId = "cote_vertu",
                        severity = AlertSeverity.MAJOR,
                        startTime = timeNow,
                        endTime = null,
                        sourceStatus = "Simulated",
                        lastUpdated = timeNow
                    )
                )
                logEvent("Scénario: Fermeture de la station Côte-Vertu.", "Scenario: Côte-Vertu station closure.", "SCENARIO")
            }
            SimulationScenario.OFFLINE -> {
                _isOffline.value = true
                logEvent("Scénario: Mode hors ligne activé.", "Scenario: Offline mode activated.", "SCENARIO")
            }
            SimulationScenario.PAY_FAIL -> {
                logEvent("Scénario: Échec systématique des paiements configuré.", "Scenario: Systematic payment failures configured.", "SCENARIO")
            }
            SimulationScenario.WINTER -> {
                alertsList.add(
                    ServiceAlert(
                        id = "alert-winter",
                        type = AlertCategory.WEATHER_NOTICE,
                        titleFr = "Avis Hivernal — Conditions de Glace",
                        titleEn = "Winter Notice — Ice Conditions",
                        descriptionFr = "Précipitations de neige importantes. Les escaliers d'accès extérieurs de toutes les stations peuvent être glissants. Veuillez tenir la rampe.",
                        descriptionEn = "Heavy snowfall in progress. Outdoor access stairs at all stations may be slippery. Please hold the handrail.",
                        affectedLineId = null,
                        affectedStationId = null,
                        severity = AlertSeverity.MINOR,
                        startTime = timeNow,
                        endTime = null,
                        sourceStatus = "Simulated",
                        lastUpdated = timeNow
                    )
                )
                logEvent("Scénario: Avis de tempête hivernale injecté.", "Scenario: Winter storm notice injected.", "SCENARIO")
            }
            SimulationScenario.MULTI_ALERTS -> {
                alertsList.add(
                    ServiceAlert(
                        id = "alert-orange-delay",
                        type = AlertCategory.DELAY,
                        titleFr = "Retard majeur — Ligne Orange",
                        titleEn = "Major Delay — Orange Line",
                        descriptionFr = "Ralentissements importants dus à une panne mécanique.",
                        descriptionEn = "Major delays due to a mechanical breakdown.",
                        affectedLineId = "L2",
                        affectedStationId = null,
                        severity = AlertSeverity.MAJOR,
                        startTime = timeNow,
                        endTime = null,
                        sourceStatus = "Simulated",
                        lastUpdated = timeNow
                    )
                )
                alertsList.add(
                    ServiceAlert(
                        id = "alert-elevator-down",
                        type = AlertCategory.ELEVATOR_OUTAGE,
                        titleFr = "Ascenseur en panne — Berri-UQAM",
                        titleEn = "Elevator Outage — Berri-UQAM",
                        descriptionFr = "Ascenseur vert hors service.",
                        descriptionEn = "Green elevator out of service.",
                        affectedLineId = "L1",
                        affectedStationId = "berri_uqam",
                        severity = AlertSeverity.MINOR,
                        startTime = timeNow,
                        endTime = null,
                        sourceStatus = "Simulated",
                        lastUpdated = timeNow
                    )
                )
                alertsList.add(
                    ServiceAlert(
                        id = "alert-station-closed",
                        type = AlertCategory.STATION_CLOSURE,
                        titleFr = "Station Côte-Vertu FERMÉE",
                        titleEn = "Côte-Vertu Station CLOSED",
                        descriptionFr = "Fermeture temporaire.",
                        descriptionEn = "Temporary closure.",
                        affectedLineId = "L2",
                        affectedStationId = "cote_vertu",
                        severity = AlertSeverity.MAJOR,
                        startTime = timeNow,
                        endTime = null,
                        sourceStatus = "Simulated",
                        lastUpdated = timeNow
                    )
                )
                logEvent("Scénario: Multiples alertes simultanées actives.", "Scenario: Multiple simultaneous alerts active.", "SCENARIO")
            }
        }

        if (alertsList.isNotEmpty()) {
            dao.insertAlerts(alertsList)
        }
    }

    // --- NEXT DEPARTURES SIMULATOR ---
    fun getSimulatedDepartures(stationId: String): List<Departure> {
        val station = getStation(stationId) ?: return emptyList()
        val departures = mutableListOf<Departure>()
        val scenario = _currentScenario.value

        station.lines.forEach { lineId ->
            val line = getLine(lineId) ?: return@forEach
            // Exclude closed stations or disrupted lines in specific ways
            val delayPenalty = if (lineId == "L2" && (scenario == SimulationScenario.DELAY_ORANGE || scenario == SimulationScenario.MULTI_ALERTS)) 12 else 0

            line.termini.forEach { terminusId ->
                if (terminusId != stationId) { // Can't depart to the same station we are starting at
                    val baseTime1 = (Math.abs(stationId.hashCode() + terminusId.hashCode() + 3) % 6) + 1 + delayPenalty
                    val baseTime2 = baseTime1 + 6 + (Math.abs(stationId.hashCode() + 7) % 4)

                    departures.add(
                        Departure(
                            stationId = stationId,
                            lineId = lineId,
                            directionStationId = terminusId,
                            minutesAway = baseTime1,
                            isRealTime = true
                        )
                    )
                    departures.add(
                        Departure(
                            stationId = stationId,
                            lineId = lineId,
                            directionStationId = terminusId,
                            minutesAway = baseTime2,
                            isRealTime = true
                        )
                    )
                }
            }
        }
        return departures.sortedBy { it.minutesAway }
    }

    // --- ROUTE ROUTING ADAPTER ---
    fun findRoutes(request: RouteRequest): List<JourneyOption> {
        val results = mutableListOf<JourneyOption>()
        val closed = if (_currentScenario.value == SimulationScenario.STATION_CLOSED || _currentScenario.value == SimulationScenario.MULTI_ALERTS) setOf("cote_vertu") else emptySet()
        val disrupted = getDisruptedLines()

        // 1. Plan using chosen preference
        val primary = MetroRoutingEngine.planRoute(
            originId = request.originStationId,
            destinationId = request.destinationStationId,
            preference = request.preference,
            accessibleOnly = request.accessibleOnly,
            closedStations = closed,
            disruptedLines = disrupted
        )
        if (primary != null) {
            results.add(primary)
        }

        // 2. Offer alternative if not already included
        if (request.preference != RoutePreference.FASTEST) {
            val altFastest = MetroRoutingEngine.planRoute(
                originId = request.originStationId,
                destinationId = request.destinationStationId,
                preference = RoutePreference.FASTEST,
                accessibleOnly = request.accessibleOnly,
                closedStations = closed,
                disruptedLines = disrupted
            )
            if (altFastest != null && results.none { it.durationMinutes == altFastest.durationMinutes }) {
                results.add(altFastest)
            }
        }

        if (request.preference != RoutePreference.FEWER_TRANSFERS) {
            val altFewer = MetroRoutingEngine.planRoute(
                originId = request.originStationId,
                destinationId = request.destinationStationId,
                preference = RoutePreference.FEWER_TRANSFERS,
                accessibleOnly = request.accessibleOnly,
                closedStations = closed,
                disruptedLines = disrupted
            )
            if (altFewer != null && results.none { it.durationMinutes == altFewer.durationMinutes }) {
                results.add(altFewer)
            }
        }

        return results.distinctBy { it.segments.map { seg -> seg.id } }
    }

    fun getStation(id: String): MetroStation? = MetroRoutingEngine.getStation(id)
    fun getLine(id: String): MetroLine? = MetroRoutingEngine.getLine(id)

    // --- FAVOURITES ADAPTER ---
    fun isFavourite(stationId: String): Flow<Boolean> = dao.isFavourite(stationId)

    suspend fun toggleFavourite(stationId: String) {
        val isFav = dao.isFavourite(stationId).first()
        if (isFav) {
            dao.removeFavourite(stationId)
            logEvent("Station retirée des favoris: $stationId", "Station removed from favorites: $stationId", "USER")
        } else {
            dao.addFavourite(FavouriteStation(stationId))
            logEvent("Station ajoutée aux favoris: $stationId", "Station added to favorites: $stationId", "USER")
        }
    }

    // --- OPUS CARD ADAPTERS ---
    suspend fun addDemoOpusCard(nickname: String, cardNumber: String) {
        val masked = if (cardNumber.length >= 4) {
            "**** **** " + cardNumber.takeLast(4)
        } else {
            "**** **** $cardNumber"
        }
        val card = OpusCard(
            id = cardNumber.ifEmpty { "0987 6543 21" },
            nickname = nickname.ifEmpty { "Carte de Démo" },
            statusFr = "Active",
            statusEn = "Active",
            balance = 20.00,
            lastActivityFr = "Ajoutée aujourd'hui",
            lastActivityEn = "Added today",
            isFavourite = false
        )
        dao.insertOpusCard(card)
        logEvent("Nouvelle carte OPUS ajoutée: $nickname", "New OPUS card added: $nickname", "USER")
    }

    // --- TICKETING OPERATIONS ---
    val products = listOf(
        TicketProduct(
            id = "prod-single",
            nameFr = "1 passage",
            nameEn = "1 trip",
            descriptionFr = "Valide pour un trajet avec correspondances dans les 120 minutes.",
            descriptionEn = "Valid for one journey with transfers within 120 minutes.",
            validityFr = "120 minutes",
            validityEn = "120 minutes",
            zoneFr = "Zone A (Montréal)",
            zoneEn = "Zone A (Montréal)",
            price = 3.75
        ),
        TicketProduct(
            id = "prod-return",
            nameFr = "2 passages",
            nameEn = "2 trips",
            descriptionFr = "Deux trajets individuels valides pour la zone A.",
            descriptionEn = "Two individual journeys valid in Zone A.",
            validityFr = "Illimitée",
            validityEn = "Unlimited",
            zoneFr = "Zone A (Montréal)",
            zoneEn = "Zone A (Montréal)",
            price = 7.00
        ),
        TicketProduct(
            id = "prod-day",
            nameFr = "Pass 24h",
            nameEn = "24h pass",
            descriptionFr = "Trajets illimités sur l'ensemble du réseau pendant 24 heures.",
            descriptionEn = "Unlimited trips across the entire network for 24 hours.",
            validityFr = "24 heures",
            validityEn = "24 hours",
            zoneFr = "Zones A, B, C",
            zoneEn = "Zones A, B, C",
            price = 11.50
        ),
        TicketProduct(
            id = "prod-weekend",
            nameFr = "Week-end illimité",
            nameEn = "Unlimited weekend",
            descriptionFr = "Déplacements illimités du vendredi 16h au lundi 5h.",
            descriptionEn = "Unlimited travel from Friday 4 PM to Monday 5 AM.",
            validityFr = "Fin de semaine",
            validityEn = "Weekend-long",
            zoneFr = "Zones A, B, C",
            zoneEn = "Zones A, B, C",
            price = 15.00
        )
    )

    suspend fun purchaseTicket(productId: String, cardId: String? = null): DemoTicket? {
        val product = products.find { it.id == productId } ?: return null
        val scenario = _currentScenario.value
        val ticketRef = "TX-" + (100000 + (Math.random() * 900000).toInt())

        val isFailure = scenario == SimulationScenario.PAY_FAIL

        if (isFailure) {
            logEvent("Échec de paiement simulé pour le produit: ${product.nameFr}", "Simulated payment failure for product: ${product.nameEn}", "ERROR")
            return null
        }

        // Deduct from OPUS if paid with OPUS card
        if (cardId != null) {
            dao.getAllOpusCards().first().find { it.id == cardId }?.let { card ->
                if (card.balance >= product.price) {
                    val updated = card.copy(
                        balance = card.balance - product.price,
                        lastActivityFr = "Achat de titre effectué",
                        lastActivityEn = "Ticket purchased"
                    )
                    dao.updateOpusCard(updated)
                } else {
                    logEvent("Solde OPUS insuffisant.", "Insufficient OPUS balance.", "ERROR")
                    return null
                }
            }
        }

        val startTime = _simulatedTime.value
        val endTime = startTime + when (productId) {
            "prod-single" -> 2 * 60 * 60 * 1000
            "prod-day" -> 24 * 60 * 60 * 1000
            "prod-weekend" -> 72 * 60 * 60 * 1000
            else -> 100 * 365 * 24 * 60 * 60 * 1000L // unlimited / virtual
        }

        val ticket = DemoTicket(
            id = ticketRef,
            productId = productId,
            productNameFr = product.nameFr,
            productNameEn = product.nameEn,
            price = product.price,
            status = TicketStatus.ACTIVE,
            purchaseDate = startTime,
            validityStart = startTime,
            validityEnd = endTime,
            qrCodePayload = "STM-METRO-DEMO-$ticketRef-VALID"
        )

        dao.insertTicket(ticket)
        logEvent("Titre émis: ${product.nameFr} ($ticketRef)", "Ticket issued: ${product.nameEn} ($ticketRef)", "USER")
        return ticket
    }

    suspend fun activateTicket(ticketId: String) {
        dao.getTicketById(ticketId)?.let { ticket ->
            dao.insertTicket(ticket.copy(status = TicketStatus.ACTIVE))
            logEvent("Titre activé: ${ticket.id}", "Ticket activated: ${ticket.id}", "USER")
        }
    }

    suspend fun expireTicket(ticketId: String) {
        dao.getTicketById(ticketId)?.let { ticket ->
            dao.insertTicket(ticket.copy(status = TicketStatus.EXPIRED))
            logEvent("Titre expiré: ${ticket.id}", "Ticket expired: ${ticket.id}", "USER")
        }
    }

    // --- TIME UTILS ---
    fun formatSimulatedTime(): String {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        return sdf.format(Date(_simulatedTime.value))
    }
}
