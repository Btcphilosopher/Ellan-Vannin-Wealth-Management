package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = StmBlue,
    onPrimary = Color.White,
    primaryContainer = ConcreteLight,
    onPrimaryContainer = MtlBlack,
    secondary = CharcoalSteel,
    onSecondary = Color.White,
    background = MtlOffWhite,
    onBackground = MtlBlack,
    surface = Color.White,
    onSurface = MtlBlack,
    surfaceVariant = ConcreteLight,
    onSurfaceVariant = CharcoalSteel,
    outline = SteelGrey
)

private val DarkColorScheme = darkColorScheme(
    primary = StmBlue,
    onPrimary = Color.White,
    primaryContainer = CharcoalSteel,
    onPrimaryContainer = Color.White,
    secondary = SteelGrey,
    onSecondary = MtlBlack,
    background = MtlBlack,
    onBackground = Color.White,
    surface = CharcoalSteel,
    onSurface = Color.White,
    surfaceVariant = ConcreteDark,
    onSurfaceVariant = Color.White,
    outline = SteelGrey
)

private val HighContrastColorScheme = lightColorScheme(
    primary = PureBlack,
    onPrimary = PureWhite,
    primaryContainer = PureWhite,
    onPrimaryContainer = PureBlack,
    secondary = PureBlack,
    onSecondary = PureWhite,
    background = PureWhite,
    onBackground = PureBlack,
    surface = PureWhite,
    onSurface = PureBlack,
    surfaceVariant = PureWhite,
    onSurfaceVariant = PureBlack,
    outline = PureBlack
)

@Composable
fun MyApplicationTheme(
    themeVal: String = "system",
    highContrast: Boolean = false,
    content: @Composable () -> Unit
) {
    val isDark = when (themeVal) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }

    val colorScheme = when {
        highContrast -> HighContrastColorScheme
        isDark -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
