package com.example.feature.routeplanner

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.model.*
import com.example.feature.MetroViewModel
import com.example.ui.theme.StmBlue
import com.example.ui.theme.StmGreen
import com.example.ui.theme.StmOrange
import com.example.ui.theme.SteelGrey

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutesTabScreen(viewModel: MetroViewModel) {
    val languageState = viewModel.language.collectAsState().value
    val allStations = viewModel.allStations

    val selectedOriginId by viewModel.originStationId.collectAsState()
    val selectedDestId by viewModel.destinationStationId.collectAsState()
    val preference by viewModel.routePreference.collectAsState()
    val stepFreeOnly by viewModel.stepFree.collectAsState()

    val plannedRoutes by viewModel.plannedRoutes.collectAsState()
    val selectedJourney by viewModel.selectedJourney.collectAsState()

    var showOriginDropdown by remember { mutableStateOf(false) }
    var showDestDropdown by remember { mutableStateOf(false) }

    val originStation = allStations.find { it.id == selectedOriginId }
    val destStation = allStations.find { it.id == selectedDestId }

    // Auto-calculate on initial load if route lists are empty
    LaunchedEffect(selectedOriginId, selectedDestId, preference, stepFreeOnly) {
        viewModel.calculateRoutes()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = stringResource(R.string.tab_routes).uppercase(),
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- STATION SELECTORS CARD ---
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Origin dropdown
                    Box {
                        OutlinedTextField(
                            value = originStation?.let { if (languageState == "fr") it.frenchName else it.englishName } ?: "",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(stringResource(R.string.from_station)) },
                            leadingIcon = { Icon(Icons.Default.TripOrigin, contentDescription = null, tint = StmGreen) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showOriginDropdown = true },
                            enabled = false,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = MaterialTheme.colorScheme.outline,
                                disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                disabledLeadingIconColor = StmGreen,
                                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        DropdownMenu(
                            expanded = showOriginDropdown,
                            onDismissRequest = { showOriginDropdown = false },
                            modifier = Modifier.fillMaxWidth(0.8f)
                        ) {
                            allStations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(if (languageState == "fr") station.frenchName else station.englishName) },
                                    onClick = {
                                        viewModel.setOrigin(station.id)
                                        showOriginDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(onClick = { viewModel.swapStations() }) {
                            Icon(Icons.Default.SwapVert, contentDescription = "Swap", tint = StmBlue)
                        }
                    }

                    // Destination dropdown
                    Box {
                        OutlinedTextField(
                            value = destStation?.let { if (languageState == "fr") it.frenchName else it.englishName } ?: "",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(stringResource(R.string.to_station)) },
                            leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = StmOrange) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showDestDropdown = true },
                            enabled = false,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = MaterialTheme.colorScheme.outline,
                                disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                disabledLeadingIconColor = StmOrange,
                                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        DropdownMenu(
                            expanded = showDestDropdown,
                            onDismissRequest = { showDestDropdown = false },
                            modifier = Modifier.fillMaxWidth(0.8f)
                        ) {
                            allStations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(if (languageState == "fr") station.frenchName else station.englishName) },
                                    onClick = {
                                        viewModel.setDestination(station.id)
                                        showDestDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // --- ROUTING PREFERENCES SCROLLABLE ROW ---
            Text(
                text = stringResource(R.string.route_options).uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = SteelGrey,
                letterSpacing = 1.sp
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PreferenceChip(
                    title = stringResource(R.string.route_shorter),
                    isSelected = preference == RoutePreference.FASTEST,
                    onClick = { viewModel.setPreference(RoutePreference.FASTEST) }
                )
                PreferenceChip(
                    title = stringResource(R.string.route_fewer_transfers),
                    isSelected = preference == RoutePreference.FEWER_TRANSFERS,
                    onClick = { viewModel.setPreference(RoutePreference.FEWER_TRANSFERS) }
                )
                PreferenceChip(
                    title = stringResource(R.string.route_accessible),
                    isSelected = stepFreeOnly,
                    onClick = { viewModel.setStepFree(!stepFreeOnly) }
                )
            }

            // --- ROUTE RESULTS ALTERNATIVES ---
            if (plannedRoutes.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DirectionsOff,
                            contentDescription = "No route found",
                            tint = SteelGrey,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Aucun itinéraire disponible / No routes available",
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Vérifiez que la station n'est pas fermée ou modifiez vos critères d'accessibilité.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            } else {
                plannedRoutes.forEach { journey ->
                    val isSelected = selectedJourney?.id == journey.id
                    val borderStroke = if (isSelected) BorderStroke(2.dp, StmBlue) else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    val bg = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectJourney(journey) }
                            .testTag("journey_option_${journey.id}"),
                        border = borderStroke,
                        colors = CardDefaults.cardColors(containerColor = bg)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Schedule,
                                        contentDescription = null,
                                        tint = StmBlue,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${journey.durationMinutes} min",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Black
                                    )
                                }

                                Badge(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                                    Text(
                                        text = "${journey.transfers} " + (if (journey.transfers == 1) "correspondance" else "correspondances"),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            // Horizontal list of line indicators in this journey
                            Row(
                                modifier = Modifier.padding(top = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                journey.segments.filter { it.type == SegmentType.RIDE }.forEachIndexed { idx, segment ->
                                    if (idx > 0) {
                                        Icon(
                                            imageVector = Icons.Default.ChevronRight,
                                            contentDescription = null,
                                            tint = SteelGrey,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                    val line = viewModel.allLines.find { it.id == segment.lineId }
                                    val lineColour = Color(android.graphics.Color.parseColor(line?.colourHex ?: "#8A95A5"))

                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(lineColour),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = line?.id?.substring(1) ?: "",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // --- DETAILED JOURNEY TIMELINE ---
                selectedJourney?.let { journey ->
                    Text(
                        text = "DÉTAILS DU TRAJET / JOURNEY TIMELINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = SteelGrey,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(top = 12.dp)
                    )

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Warnings
                            journey.warnings.forEach { warning ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFFFFDE7))
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = "Warning", tint = StmOrange)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(text = warning, fontSize = 12.sp, color = Color.Black)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                            }

                            // Segments timeline list
                            journey.segments.forEachIndexed { index, segment ->
                                val isFirst = index == 0
                                val isLast = index == journey.segments.size - 1

                                TimelineRow(
                                    segment = segment,
                                    isFirst = isFirst,
                                    isLast = isLast,
                                    language = languageState,
                                    viewModel = viewModel
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PreferenceChip(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = isSelected,
        onClick = onClick,
        label = { Text(title, fontWeight = FontWeight.Bold) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = StmBlue,
            selectedLabelColor = Color.White
        )
    )
}

@Composable
fun TimelineRow(
    segment: JourneySegment,
    isFirst: Boolean,
    isLast: Boolean,
    language: String,
    viewModel: MetroViewModel
) {
    val line = viewModel.allLines.find { it.id == segment.lineId }
    val lineColour = line?.let { Color(android.graphics.Color.parseColor(it.colourHex)) } ?: StmBlue

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        // Dot & line visual
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(end = 16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(if (segment.type == SegmentType.WALK) SteelGrey else lineColour)
            )

            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(48.dp)
                        .background(if (segment.type == SegmentType.WALK) SteelGrey else lineColour)
                )
            }
        }

        // Segment description
        Column {
            Text(
                text = if (language == "fr") segment.instructionsFr else segment.instructionsEn,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (segment.type == SegmentType.RIDE) FontWeight.Bold else FontWeight.Normal
            )
            Text(
                text = "⏱️ ${segment.durationMinutes} min",
                style = MaterialTheme.typography.labelSmall,
                color = SteelGrey,
                modifier = Modifier.padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
