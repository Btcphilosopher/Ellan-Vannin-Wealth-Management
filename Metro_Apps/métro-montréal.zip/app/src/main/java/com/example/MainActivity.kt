package com.example

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.feature.MetroViewModel
import com.example.feature.home.HomeTabScreen
import com.example.feature.more.MoreTabScreen
import com.example.feature.onboarding.OnboardingScreen
import com.example.feature.routeplanner.RoutesTabScreen
import com.example.feature.stations.StationsTabScreen
import com.example.feature.tickets.TicketsTabScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.StmBlue
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MetroViewModel = viewModel()
            val languageState = viewModel.language.collectAsState().value
            val themeState = viewModel.theme.collectAsState().value
            val highContrastState = viewModel.highContrast.collectAsState().value
            val isOnboardedState = viewModel.isOnboarded.collectAsState().value

            // DYNAMIC LOCALE CONFIGURATION INJECTOR (Complete runtime bilinguality)
            val context = LocalContext.current
            val locale = Locale(languageState)
            Locale.setDefault(locale)
            val config = Configuration(context.resources.configuration)
            config.setLocale(locale)
            val localizedContext = context.createConfigurationContext(config)

            CompositionLocalProvider(LocalContext provides localizedContext) {
                MyApplicationTheme(themeVal = themeState, highContrast = highContrastState) {
                    if (!isOnboardedState) {
                        OnboardingScreen(
                            viewModel = viewModel,
                            onFinished = { viewModel.selectTab("home") }
                        )
                    } else {
                        MainAppScaffold(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun MainAppScaffold(viewModel: MetroViewModel) {
    val currentTab = viewModel.currentTab.collectAsState().value

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("app_scaffold"),
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == "home",
                    onClick = { viewModel.selectTab("home") },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Accueil") },
                    label = { Text("Accueil") },
                    modifier = Modifier.testTag("tab_home")
                )
                NavigationBarItem(
                    selected = currentTab == "routes",
                    onClick = { viewModel.selectTab("routes") },
                    icon = { Icon(Icons.Default.Directions, contentDescription = "Itinéraires") },
                    label = { Text("Itinéraires") },
                    modifier = Modifier.testTag("tab_routes")
                )
                NavigationBarItem(
                    selected = currentTab == "stations",
                    onClick = { viewModel.selectTab("stations") },
                    icon = { Icon(Icons.Default.Train, contentDescription = "Stations") },
                    label = { Text("Stations") },
                    modifier = Modifier.testTag("tab_stations")
                )
                NavigationBarItem(
                    selected = currentTab == "tickets",
                    onClick = { viewModel.selectTab("tickets") },
                    icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Titres") },
                    label = { Text("Titres") },
                    modifier = Modifier.testTag("tab_tickets")
                )
                NavigationBarItem(
                    selected = currentTab == "more",
                    onClick = { viewModel.selectTab("more") },
                    icon = { Icon(Icons.Default.Menu, contentDescription = "Plus") },
                    label = { Text("Plus") },
                    modifier = Modifier.testTag("tab_more")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                "home" -> HomeTabScreen(
                    viewModel = viewModel,
                    onNavigateToSettings = { viewModel.selectTab("more") },
                    onNavigateToAlerts = { viewModel.selectTab("more") },
                    onNavigateToAccessibility = { viewModel.selectTab("more") }
                )
                "routes" -> RoutesTabScreen(viewModel = viewModel)
                "stations" -> StationsTabScreen(viewModel = viewModel)
                "tickets" -> TicketsTabScreen(viewModel = viewModel)
                "more" -> MoreTabScreen(
                    viewModel = viewModel,
                    onNavigateToStationDetail = { stationId ->
                        viewModel.selectStation(stationId)
                        viewModel.selectTab("stations")
                    }
                )
            }
        }
    }
}
