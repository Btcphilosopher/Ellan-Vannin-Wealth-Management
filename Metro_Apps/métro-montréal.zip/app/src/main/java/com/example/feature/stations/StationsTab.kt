package com.example.feature.stations

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.model.FacilityType
import com.example.domain.model.MetroLine
import com.example.domain.model.MetroStation
import com.example.feature.MetroViewModel
import com.example.ui.theme.StmBlue
import com.example.ui.theme.SteelGrey

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationsTabScreen(viewModel: MetroViewModel) {
    val languageState = viewModel.language.collectAsState().value
    val allStations = viewModel.allStations
    val allLines = viewModel.allLines

    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val selectedLineId by viewModel.selectedLineId.collectAsState()

    var activeSubScreen by remember { mutableStateOf("map") } // "map", "list", "detail", "line_detail"

    // Station Detail target
    val selectedStation = allStations.find { it.id == selectedStationId }
    val selectedLine = allLines.find { it.id == selectedLineId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- TOP NAV CONTROLS ---
        TopAppBar(
            title = {
                Text(
                    text = if (activeSubScreen == "detail") {
                        selectedStation?.let { if (languageState == "fr") it.frenchName else it.englishName } ?: "Station"
                    } else if (activeSubScreen == "line_detail") {
                        selectedLine?.let { if (languageState == "fr") it.frenchName else it.englishName } ?: "Ligne"
                    } else {
                        stringResource(R.string.tab_stations).uppercase()
                    },
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            },
            navigationIcon = {
                if (activeSubScreen == "detail" || activeSubScreen == "line_detail") {
                    IconButton(onClick = { activeSubScreen = "list" }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            },
            actions = {
                if (activeSubScreen == "map" || activeSubScreen == "list") {
                    // Toggle list/map alternative
                    IconButton(
                        onClick = {
                            activeSubScreen = if (activeSubScreen == "map") "list" else "map"
                        },
                        modifier = Modifier.testTag("stations_toggle_view")
                    ) {
                        Icon(
                            imageVector = if (activeSubScreen == "map") Icons.Default.List else Icons.Default.Map,
                            contentDescription = "Toggle Map / List View"
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        // --- SUB SCREENS ROUTING ---
        when (activeSubScreen) {
            "map" -> MapViewScreen(
                viewModel = viewModel,
                languageState = languageState,
                onOpenDetails = { activeSubScreen = "detail" }
            )
            "list" -> ListViewScreen(
                viewModel = viewModel,
                languageState = languageState,
                onSelectStation = { id ->
                    viewModel.selectStation(id)
                    activeSubScreen = "detail"
                },
                onSelectLine = { id ->
                    viewModel.selectLine(id)
                    activeSubScreen = "line_detail"
                }
            )
            "detail" -> selectedStation?.let { station ->
                StationDetailsScreen(
                    station = station,
                    viewModel = viewModel,
                    languageState = languageState,
                    onBack = { activeSubScreen = "list" }
                )
            }
            "line_detail" -> selectedLine?.let { line ->
                LineDetailsScreen(
                    line = line,
                    viewModel = viewModel,
                    languageState = languageState,
                    onBack = { activeSubScreen = "list" },
                    onSelectStation = { id ->
                        viewModel.selectStation(id)
                        activeSubScreen = "detail"
                    }
                )
            }
        }
    }
}

// --- SUB SCREEN: MAP VIEW (JETPACK COMPOSE CANVAS) ---
@Composable
fun MapViewScreen(
    viewModel: MetroViewModel,
    languageState: String,
    onOpenDetails: () -> Unit
) {
    val allStations = viewModel.allStations
    val allLines = viewModel.allLines
    val selectedStationId by viewModel.selectedStationId.collectAsState()

    // 2D Normalized Coordinates lookup
    val coordinates = mapOf(
        "cote_vertu" to Offset(0.15f, 0.22f),
        "snowdon" to Offset(0.15f, 0.42f),
        "lionel_groulx" to Offset(0.35f, 0.58f),
        "bonaventure" to Offset(0.5f, 0.58f),
        "berri_uqam" to Offset(0.72f, 0.48f),
        "jean_talon" to Offset(0.72f, 0.25f),
        "montmorency" to Offset(0.55f, 0.12f),
        "angrignon" to Offset(0.2f, 0.72f),
        "guy_concordia" to Offset(0.44f, 0.48f),
        "mcgill" to Offset(0.53f, 0.48f),
        "place_des_arts" to Offset(0.62f, 0.48f),
        "honore_beaugrand" to Offset(0.9f, 0.4f),
        "longueuil" to Offset(0.85f, 0.58f),
        "saint_michel" to Offset(0.82f, 0.25f)
    )

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color.White)
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        // Detect closest station node tapped
                        var closestStationId: String? = null
                        var minDistance = 60f // pixel threshold

                        coordinates.forEach { (id, p) ->
                            val pixelX = p.x * size.width
                            val pixelY = p.y * size.height
                            val dist = Math.hypot((offset.x - pixelX).toDouble(), (offset.y - pixelY).toDouble())
                            if (dist < minDistance) {
                                minDistance = dist.toFloat()
                                closestStationId = id
                            }
                        }

                        closestStationId?.let {
                            viewModel.selectStation(it)
                        }
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasW = size.width
                val canvasH = size.height

                // 1. Draw Lines (Verte, Orange, Yellow, Blue)
                allLines.forEach { line ->
                    val lineColour = Color(android.graphics.Color.parseColor(line.colourHex))
                    for (i in 0 until line.stations.size - 1) {
                        val s1 = line.stations[i]
                        val s2 = line.stations[i + 1]
                        val p1 = coordinates[s1]
                        val p2 = coordinates[s2]
                        if (p1 != null && p2 != null) {
                            drawLine(
                                color = lineColour,
                                start = Offset(p1.x * canvasW, p1.y * canvasH),
                                end = Offset(p2.x * canvasW, p2.y * canvasH),
                                strokeWidth = 8.dp.toPx()
                            )
                        }
                    }
                }

                // 2. Draw Stations Nodes
                allStations.forEach { station ->
                    val p = coordinates[station.id] ?: return@forEach
                    val pixelX = p.x * canvasW
                    val pixelY = p.y * canvasH
                    val isSelected = station.id == selectedStationId

                    val isInterchange = station.lines.size > 1

                    // outer ring for selected station
                    if (isSelected) {
                        drawCircle(
                            color = StmBlue,
                            radius = 16.dp.toPx(),
                            center = Offset(pixelX, pixelY),
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }

                    // outer white border
                    drawCircle(
                        color = Color.Black,
                        radius = if (isInterchange) 9.dp.toPx() else 7.dp.toPx(),
                        center = Offset(pixelX, pixelY)
                    )

                    drawCircle(
                        color = Color.White,
                        radius = if (isInterchange) 7.dp.toPx() else 5.dp.toPx(),
                        center = Offset(pixelX, pixelY)
                    )

                    // Inner black core for interchanges
                    if (isInterchange) {
                        drawCircle(
                            color = Color.Black,
                            radius = 3.dp.toPx(),
                            center = Offset(pixelX, pixelY)
                        )
                    }
                }
            }

            // Overlay label hints (so user knows they can tap!)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(12.dp)
            ) {
                Text(
                    text = "👇 Touchez une station sur la carte / Tap a station node",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }

        // --- SELECTED STATION QUICK BOTTOM CARD ---
        val selectedStation = allStations.find { it.id == selectedStationId }
        selectedStation?.let { station ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = MaterialTheme.shapes.medium
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (languageState == "fr") station.frenchName else station.englishName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            station.lines.forEach { lineId ->
                                val line = allLines.find { it.id == lineId }
                                val c = Color(android.graphics.Color.parseColor(line?.colourHex ?: "#8A95A5"))
                                Badge(containerColor = c, contentColor = Color.White) {
                                    Text(text = line?.id?.substring(1) ?: "", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Button(
                        onClick = onOpenDetails,
                        colors = ButtonDefaults.buttonColors(containerColor = StmBlue)
                    ) {
                        Text(text = "Détails", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: STATION AND LINE LISTS VIEW ---
@Composable
fun ListViewScreen(
    viewModel: MetroViewModel,
    languageState: String,
    onSelectStation: (String) -> Unit,
    onSelectLine: (String) -> Unit
) {
    val allStations = viewModel.allStations
    val allLines = viewModel.allLines

    var searchQuery by remember { mutableStateOf("") }
    val filteredStations = allStations.filter {
        val name = if (languageState == "fr") it.frenchName else it.englishName
        name.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(stringResource(R.string.search_station_placeholder)) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.small
        )

        // Lines header
        Text(
            text = "LIGNES DE MÉTRO / LINES",
            style = MaterialTheme.typography.labelSmall,
            color = SteelGrey,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            allLines.forEach { line ->
                val lineColour = Color(android.graphics.Color.parseColor(line.colourHex))
                Button(
                    onClick = { onSelectLine(line.id) },
                    colors = ButtonDefaults.buttonColors(containerColor = lineColour),
                    modifier = Modifier.weight(1f),
                    shape = MaterialTheme.shapes.small,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = line.id.substring(1),
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Stations list header
        Text(
            text = "STATIONS",
            style = MaterialTheme.typography.labelSmall,
            color = SteelGrey,
            letterSpacing = 1.sp
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredStations.size) { index ->
                val station = filteredStations[index]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectStation(station.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (languageState == "fr") station.frenchName else station.englishName,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Row(
                                modifier = Modifier.padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                station.lines.forEach { lineId ->
                                    val line = allLines.find { it.id == lineId }
                                    val c = Color(android.graphics.Color.parseColor(line?.colourHex ?: "#8A95A5"))
                                    Badge(containerColor = c, contentColor = Color.White) {
                                        Text(text = line?.id?.substring(1) ?: "", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = SteelGrey
                        )
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: LINE DETAILS PAGE ---
@Composable
fun LineDetailsScreen(
    line: MetroLine,
    viewModel: MetroViewModel,
    languageState: String,
    onBack: () -> Unit,
    onSelectStation: (String) -> Unit
) {
    val lineColour = Color(android.graphics.Color.parseColor(line.colourHex))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Line Title banner
        Card(
            colors = CardDefaults.cardColors(containerColor = lineColour),
            shape = MaterialTheme.shapes.small,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (languageState == "fr") line.frenchName else line.englishName,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
                Text(
                    text = "Terminus : " + line.termini.map { viewModel.allStations.find { s -> s.id == it }?.frenchName }.joinToString(" ↔ "),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        Text(
            text = "STATIONS DESSERvIES / STATIONS LIST",
            style = MaterialTheme.typography.labelSmall,
            color = SteelGrey,
            letterSpacing = 1.sp
        )

        line.stations.forEachIndexed { index, stationId ->
            val station = viewModel.allStations.find { it.id == stationId }
            station?.let {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectStation(station.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // index indicator
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(lineColour.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (index + 1).toString(),
                                    fontWeight = FontWeight.Bold,
                                    color = lineColour,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = if (languageState == "fr") station.frenchName else station.englishName,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SteelGrey)
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: STATION DETAILS PAGE ---
@Composable
fun StationDetailsScreen(
    station: MetroStation,
    viewModel: MetroViewModel,
    languageState: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val isFav = viewModel.favourites.collectAsState().value.any { it.stationId == station.id }
    val departures = remember(station.id) { viewModel.repository.getSimulatedDepartures(station.id) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- STATION HEADER DETAILS ---
        Card(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (languageState == "fr") station.frenchName else station.englishName,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(top = 6.dp)
                        ) {
                            station.lines.forEach { lineId ->
                                val line = viewModel.allLines.find { it.id == lineId }
                                val c = Color(android.graphics.Color.parseColor(line?.colourHex ?: "#8A95A5"))
                                Badge(containerColor = c, contentColor = Color.White) {
                                    Text(text = line?.id?.substring(1) ?: "", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Fav toggle
                    IconButton(onClick = { viewModel.toggleFavourite(station.id) }) {
                        Icon(
                            imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (isFav) Color.Red else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // --- NEXT DEPARTURES COUNTDOWN ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.next_departures).uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelGrey,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                departures.forEach { departure ->
                    val direction = viewModel.allStations.find { it.id == departure.directionStationId }
                    val line = viewModel.allLines.find { it.id == departure.lineId }
                    val lineColour = Color(android.graphics.Color.parseColor(line?.colourHex ?: "#8A95A5"))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(lineColour),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = line?.id?.substring(1) ?: "",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Direction " + (if (languageState == "fr") direction?.frenchName else direction?.englishName),
                                fontSize = 13.sp
                            )
                        }

                        Text(
                            text = "${departure.minutesAway} min",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // --- ACCESSIBILITY FACILITIES STATUS ---
        Text(
            text = stringResource(R.string.accessibility_facilities).uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = SteelGrey,
            letterSpacing = 1.sp
        )

        station.facilities.forEach { facility ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = when (facility.type) {
                                FacilityType.ELEVATOR -> Icons.Default.Elevator
                                FacilityType.ESCALATOR -> Icons.Default.Escalator
                                FacilityType.BIKE_RACK -> Icons.Default.DirectionsBike
                            },
                            contentDescription = null,
                            tint = StmBlue
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(text = facility.name, fontWeight = FontWeight.Bold)
                    }

                    Badge(
                        containerColor = if (facility.isOperational) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                        contentColor = if (facility.isOperational) Color(0xFF2E7D32) else Color(0xFFC62828)
                    ) {
                        Text(
                            text = if (facility.isOperational) "Fonctionnel" else "En panne",
                            modifier = Modifier.padding(4.dp),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // --- STATION ENTRANCES LIST ---
        Text(
            text = stringResource(R.string.entrances).uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = SteelGrey,
            letterSpacing = 1.sp
        )

        station.entrances.forEach { entrance ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = entrance.name, fontWeight = FontWeight.Bold)
                        if (entrance.isAccessible) {
                            Icon(
                                imageVector = Icons.Default.Accessible,
                                contentDescription = "Accessible",
                                tint = StmBlue,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(text = entrance.street, fontSize = 12.sp, color = SteelGrey)
                }
            }
        }

        // --- SHARE STATION ACTIONS ---
        Button(
            onClick = {
                Toast.makeText(
                    context,
                    "Lien de la station partagé ! / Station details link copied !",
                    Toast.LENGTH_SHORT
                ).show()
                viewModel.repository.logEvent(
                    "Détails de la station partagés : ${station.frenchName}",
                    "Station details shared: ${station.englishName}",
                    "USER"
                )
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = StmBlue),
            shape = MaterialTheme.shapes.small
        ) {
            Icon(imageVector = Icons.Default.Share, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = stringResource(R.string.share_station).uppercase())
        }
    }
}
