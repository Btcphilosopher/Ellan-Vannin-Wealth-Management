package com.example.data.local

import androidx.room.*
import com.example.domain.model.DemoTicket
import com.example.domain.model.FavouriteStation
import com.example.domain.model.OpusCard
import com.example.domain.model.ServiceAlert
import kotlinx.coroutines.flow.Flow

@Dao
interface MetroDao {

    // --- SERVICE ALERTS ---
    @Query("SELECT * FROM service_alerts ORDER BY lastUpdated DESC")
    fun getAllAlerts(): Flow<List<ServiceAlert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<ServiceAlert>)

    @Query("DELETE FROM service_alerts")
    suspend fun clearAllAlerts()

    // --- OPUS CARDS ---
    @Query("SELECT * FROM opus_cards")
    fun getAllOpusCards(): Flow<List<OpusCard>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOpusCard(card: OpusCard)

    @Update
    suspend fun updateOpusCard(card: OpusCard)

    @Query("DELETE FROM opus_cards WHERE id = :id")
    suspend fun deleteOpusCard(id: String)

    @Query("DELETE FROM opus_cards")
    suspend fun clearAllOpusCards()

    // --- DEMO TICKETS ---
    @Query("SELECT * FROM demo_tickets ORDER BY purchaseDate DESC")
    fun getAllTickets(): Flow<List<DemoTicket>>

    @Query("SELECT * FROM demo_tickets WHERE id = :id")
    suspend fun getTicketById(id: String): DemoTicket?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: DemoTicket)

    @Update
    suspend fun updateTicket(ticket: DemoTicket)

    @Query("DELETE FROM demo_tickets")
    suspend fun clearAllTickets()

    // --- FAVORITE STATIONS ---
    @Query("SELECT * FROM favourites")
    fun getAllFavourites(): Flow<List<FavouriteStation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavourite(station: FavouriteStation)

    @Query("DELETE FROM favourites WHERE stationId = :stationId")
    suspend fun removeFavourite(stationId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favourites WHERE stationId = :stationId)")
    fun isFavourite(stationId: String): Flow<Boolean>

    @Query("DELETE FROM favourites")
    suspend fun clearAllFavourites()
}

@Database(
    entities = [
        ServiceAlert::class,
        OpusCard::class,
        DemoTicket::class,
        FavouriteStation::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MetroDatabase : RoomDatabase() {
    abstract fun metroDao(): MetroDao
}
