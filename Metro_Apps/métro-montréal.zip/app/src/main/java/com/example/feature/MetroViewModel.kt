package com.example.feature

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.MetroRepository
import com.example.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MetroViewModel(application: Application) : AndroidViewModel(application) {

    val repository = MetroRepository.getInstance(application)
    private val prefs = repository.preferencesManager

    // --- READ PREFERENCES & SYSTEM STATES ---
    val language = prefs.languageFlow.stateIn(viewModelScope, SharingStarted.Eagerly, "fr")
    val theme = prefs.themeFlow.stateIn(viewModelScope, SharingStarted.Eagerly, "system")
    val stepFree = prefs.stepFreeFlow.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val reducedStairs = prefs.reducedStairsFlow.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val highContrast = prefs.highContrastFlow.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val largeText = prefs.largeTextFlow.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val haptic = prefs.hapticFlow.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val reducedMotion = prefs.reducedMotionFlow.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val isOnboarded = prefs.isOnboardedFlow.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val isOffline = repository.isOffline.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val currentScenario = repository.currentScenario.stateIn(viewModelScope, SharingStarted.Eagerly, SimulationScenario.NORMAL)
    val isSimulationPaused = repository.isSimulationPaused.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val simulatedTime = repository.simulatedTime.stateIn(viewModelScope, SharingStarted.Eagerly, System.currentTimeMillis())
    val eventLogs = repository.eventLogs.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // --- REPOSITORY SOURCE FLOWS ---
    val serviceAlerts = repository.serviceAlerts.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val opusCards = repository.opusCards.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val demoTickets = repository.demoTickets.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val favourites = repository.favourites.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // --- TRANSLATED DATA ACCESSIBLE IN COHERENT PLACES ---
    val allStations = repository.allStations
    val allLines = repository.allLines

    // --- DYNAMIC UI STATES ---
    private val _currentTab = MutableStateFlow("home")
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    private val _selectedStationId = MutableStateFlow<String?>("berri_uqam")
    val selectedStationId: StateFlow<String?> = _selectedStationId.asStateFlow()

    private val _selectedTicketId = MutableStateFlow<String?>(null)
    val selectedTicketId: StateFlow<String?> = _selectedTicketId.asStateFlow()

    private val _selectedLineId = MutableStateFlow<String?>("L1")
    val selectedLineId: StateFlow<String?> = _selectedLineId.asStateFlow()

    // Route Planner States
    private val _originStationId = MutableStateFlow("cote_vertu")
    val originStationId: StateFlow<String> = _originStationId.asStateFlow()

    private val _destinationStationId = MutableStateFlow("berri_uqam")
    val destinationStationId: StateFlow<String> = _destinationStationId.asStateFlow()

    private val _routePreference = MutableStateFlow(RoutePreference.FASTEST)
    val routePreference: StateFlow<RoutePreference> = _routePreference.asStateFlow()

    private val _plannedRoutes = MutableStateFlow<List<JourneyOption>>(emptyList())
    val plannedRoutes: StateFlow<List<JourneyOption>> = _plannedRoutes.asStateFlow()

    private val _selectedJourney = MutableStateFlow<JourneyOption?>(null)
    val selectedJourney: StateFlow<JourneyOption?> = _selectedJourney.asStateFlow()

    // Ticketing flow states
    private val _selectedProduct = MutableStateFlow<TicketProduct?>(null)
    val selectedProduct: StateFlow<TicketProduct?> = _selectedProduct.asStateFlow()

    private val _paymentState = MutableStateFlow<PaymentState>(PaymentState.Idle)
    val paymentState: StateFlow<PaymentState> = _paymentState.asStateFlow()

    sealed interface PaymentState {
        object Idle : PaymentState
        object Pending : PaymentState
        data class Success(val ticket: DemoTicket) : PaymentState
        data class Error(val messageFr: String, val messageEn: String) : PaymentState
    }

    // --- NAVIGATION FUNCTIONS ---
    fun selectTab(tab: String) {
        _currentTab.value = tab
    }

    fun selectStation(stationId: String) {
        _selectedStationId.value = stationId
    }

    fun selectTicket(ticketId: String) {
        _selectedTicketId.value = ticketId
    }

    fun selectLine(lineId: String) {
        _selectedLineId.value = lineId
    }

    // --- ROUTE ACTIONS ---
    fun setOrigin(stationId: String) {
        _originStationId.value = stationId
        calculateRoutes()
    }

    fun setDestination(stationId: String) {
        _destinationStationId.value = stationId
        calculateRoutes()
    }

    fun setPreference(pref: RoutePreference) {
        _routePreference.value = pref
        calculateRoutes()
    }

    fun swapStations() {
        val oldOrigin = _originStationId.value
        _originStationId.value = _destinationStationId.value
        _destinationStationId.value = oldOrigin
        calculateRoutes()
    }

    fun calculateRoutes() {
        viewModelScope.launch {
            val req = RouteRequest(
                originStationId = _originStationId.value,
                destinationStationId = _destinationStationId.value,
                preference = _routePreference.value,
                accessibleOnly = stepFree.value
            )
            val routes = repository.findRoutes(req)
            _plannedRoutes.value = routes
            _selectedJourney.value = routes.firstOrNull()
        }
    }

    fun selectJourney(journey: JourneyOption) {
        _selectedJourney.value = journey
    }

    // --- TICKETING FLOW ACTIONS ---
    fun selectProductForPurchase(product: TicketProduct) {
        _selectedProduct.value = product
        _paymentState.value = PaymentState.Idle
    }

    fun confirmPurchase(cardId: String? = null) {
        val product = _selectedProduct.value ?: return
        _paymentState.value = PaymentState.Pending

        viewModelScope.launch {
            kotlinx.coroutines.delay(1500) // Simulating bank processing
            val result = repository.purchaseTicket(product.id, cardId)
            if (result != null) {
                _paymentState.value = PaymentState.Success(result)
                _selectedTicketId.value = result.id
            } else {
                _paymentState.value = PaymentState.Error(
                    "Échec de l'autorisation de paiement.",
                    "Payment authorization failed."
                )
            }
        }
    }

    fun resetPayment() {
        _paymentState.value = PaymentState.Idle
        _selectedProduct.value = null
    }

    // --- USER CONFIGURATIONS & PREFERENCES ACTIONS ---
    fun toggleLanguage() {
        viewModelScope.launch {
            val nextLang = if (language.value == "fr") "en" else "fr"
            prefs.setLanguage(nextLang)
            repository.logEvent(
                "Langue modifiée: Français",
                "Language changed: English",
                "USER"
            )
        }
    }

    fun setTheme(themeVal: String) {
        viewModelScope.launch {
            prefs.setTheme(themeVal)
            repository.logEvent(
                "Thème d'affichage mis à jour : $themeVal",
                "Display theme updated: $themeVal",
                "USER"
            )
        }
    }

    fun setStepFree(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setStepFree(enabled)
            calculateRoutes()
        }
    }

    fun setReducedStairs(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setReducedStairs(enabled)
        }
    }

    fun setHighContrast(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setHighContrast(enabled)
        }
    }

    fun setLargeText(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setLargeText(enabled)
        }
    }

    fun setHaptic(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setHaptic(enabled)
        }
    }

    fun setReducedMotion(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setReducedMotion(enabled)
        }
    }

    fun setOnboarded(onboarded: Boolean) {
        viewModelScope.launch {
            prefs.setIsOnboarded(onboarded)
        }
    }

    // --- SIMULATION CONSOLE ACTIONS ---
    fun setScenario(scenario: SimulationScenario) {
        viewModelScope.launch {
            repository.setScenario(scenario)
            calculateRoutes() // recalculate any active route
        }
    }

    fun toggleFavourite(stationId: String) {
        viewModelScope.launch {
            repository.toggleFavourite(stationId)
        }
    }

    fun addDemoOpusCard(nickname: String, cardNumber: String) {
        viewModelScope.launch {
            repository.addDemoOpusCard(nickname, cardNumber)
        }
    }

    fun advanceTime() {
        repository.advanceTime()
    }

    fun toggleSimulationPause() {
        repository.toggleSimulationPause()
    }

    fun clearLocalData() {
        viewModelScope.launch {
            repository.clearAllLocalData()
        }
    }
}
