package com.example.feature.more

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.model.AlertSeverity
import com.example.domain.model.SimulationScenario
import com.example.feature.MetroViewModel
import com.example.ui.theme.StmBlue
import com.example.ui.theme.StmOrange
import com.example.ui.theme.SteelGrey

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreTabScreen(
    viewModel: MetroViewModel,
    onNavigateToStationDetail: (String) -> Unit
) {
    val languageState = viewModel.language.collectAsState().value
    var activeSubScreen by remember { mutableStateOf("menu") } // "menu", "alerts", "accessibility", "favourites", "notifications", "about", "console"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = when (activeSubScreen) {
                        "alerts" -> stringResource(R.string.qa_alerts).uppercase()
                        "accessibility" -> stringResource(R.string.qa_accessibility).uppercase()
                        "favourites" -> "STATIONS FAVORITES"
                        "notifications" -> "NOTIFICATIONS"
                        "about" -> "À PROPOS / ABOUT"
                        "console" -> "CONSOLE DE SIMULATION"
                        else -> "PLUS / MORE"
                    },
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            },
            navigationIcon = {
                if (activeSubScreen != "menu") {
                    IconButton(onClick = { activeSubScreen = "menu" }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
        )

        // Sub Screen Router
        when (activeSubScreen) {
            "menu" -> PlusMenuScreen(
                onNavigate = { screen -> activeSubScreen = screen }
            )
            "alerts" -> ServiceAlertsScreen(
                viewModel = viewModel,
                language = languageState
            )
            "accessibility" -> AccessibilityScreen(
                viewModel = viewModel
            )
            "favourites" -> FavouritesScreen(
                viewModel = viewModel,
                language = languageState,
                onSelectStation = { id ->
                    onNavigateToStationDetail(id)
                }
            )
            "notifications" -> NotificationsScreen()
            "about" -> AboutScreen(viewModel = viewModel)
            "console" -> SimulationConsoleScreen(
                viewModel = viewModel,
                language = languageState
            )
        }
    }
}

// --- SUB SCREEN: MAIN PLUS/MORE MENU ---
@Composable
fun PlusMenuScreen(
    onNavigate: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Developer Simulation Console Shortcut (Prominent Brutalist Highlight)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigate("console") }
                .testTag("console_nav_button"),
            colors = CardDefaults.cardColors(containerColor = StmOrange),
            shape = MaterialTheme.shapes.small
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "CONSOLE DE SIMULATION",
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "Gérer les scénarios et le temps simulé",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // standard list of options
        MenuListItem(
            title = "État du service / Service Alerts",
            icon = Icons.Default.Warning,
            onClick = { onNavigate("alerts") }
        )

        MenuListItem(
            title = "Accessibilité / Accessibility",
            icon = Icons.Default.Accessible,
            onClick = { onNavigate("accessibility") }
        )

        MenuListItem(
            title = "Favoris / Favourites",
            icon = Icons.Default.Favorite,
            onClick = { onNavigate("favourites") }
        )

        MenuListItem(
            title = "Notifications",
            icon = Icons.Default.Notifications,
            onClick = { onNavigate("notifications") }
        )

        MenuListItem(
            title = "À propos & Transparence / About",
            icon = Icons.Default.Info,
            onClick = { onNavigate("about") }
        )
    }
}

@Composable
fun MenuListItem(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = StmBlue)
                Spacer(modifier = Modifier.width(16.dp))
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = SteelGrey)
        }
    }
}

// --- SUB SCREEN: SERVICE ALERTS ---
@Composable
fun ServiceAlertsScreen(
    viewModel: MetroViewModel,
    language: String
) {
    val alertsList = viewModel.serviceAlerts.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (alertsList.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = "Normal", tint = Color(0xFF2E7D32))
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "Aucun retard ou perturbation signalé. Service normal sur tout le réseau.",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32),
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            alertsList.forEach { alert ->
                val line = viewModel.allLines.find { it.id == alert.affectedLineId }
                val lineColour = line?.let { Color(android.graphics.Color.parseColor(it.colourHex)) } ?: StmOrange

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, lineColour)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (language == "fr") alert.titleFr else alert.titleEn,
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.titleMedium,
                                color = lineColour
                            )

                            Badge(
                                containerColor = if (alert.severity == AlertSeverity.MAJOR) Color.Red else StmOrange,
                                contentColor = Color.White
                            ) {
                                Text(
                                    text = alert.severity.name,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(4.dp)
                                )
                            }
                        }

                        Text(
                            text = if (language == "fr") alert.descriptionFr else alert.descriptionEn,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 8.dp)
                        )

                        Divider(modifier = Modifier.padding(vertical = 12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Source : STM (Simulé)",
                                fontSize = 11.sp,
                                color = SteelGrey
                            )

                            Text(
                                text = "Statut : Actif",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = StmOrange
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: ACCESSIBILITY PREFERENCES ---
@Composable
fun AccessibilityScreen(
    viewModel: MetroViewModel
) {
    val stepFree = viewModel.stepFree.collectAsState().value
    val reducedStairs = viewModel.reducedStairs.collectAsState().value
    val highContrast = viewModel.highContrast.collectAsState().value
    val largeText = viewModel.largeText.collectAsState().value
    val haptic = viewModel.haptic.collectAsState().value
    val reducedMotion = viewModel.reducedMotion.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "CRITÈRES D'ITINÉRAIRE / ROUTING CRITERIA",
            style = MaterialTheme.typography.labelSmall,
            color = SteelGrey,
            letterSpacing = 1.sp
        )

        AccessibilitySwitchRow(
            title = "Trajet sans obstacles (Ascenseurs)",
            desc = "Recommande exclusivement des stations équipées d'ascenseurs fonctionnels.",
            checked = stepFree,
            onCheckedChange = { viewModel.setStepFree(it) }
        )

        AccessibilitySwitchRow(
            title = "Moins d'escaliers",
            desc = "Évite les longs transferts par escaliers physiques si possible.",
            checked = reducedStairs,
            onCheckedChange = { viewModel.setReducedStairs(it) }
        )

        Divider()

        Text(
            text = "AFFICHAGE & SENS / DISPLAY & SENSORY",
            style = MaterialTheme.typography.labelSmall,
            color = SteelGrey,
            letterSpacing = 1.sp
        )

        AccessibilitySwitchRow(
            title = "Contraste élevé",
            desc = "Bascule vers un jeu de couleurs noir et blanc à fort rapport de contraste.",
            checked = highContrast,
            onCheckedChange = { viewModel.setHighContrast(it) }
        )

        AccessibilitySwitchRow(
            title = "Texte agrandi",
            desc = "Augmente la taille relative de police de caractères dans toute l'interface.",
            checked = largeText,
            onCheckedChange = { viewModel.setLargeText(it) }
        )

        AccessibilitySwitchRow(
            title = "Retour haptique",
            desc = "Vibrations subtiles lors des confirmations d'achat de titre ou de trajet.",
            checked = haptic,
            onCheckedChange = { viewModel.setHaptic(it) }
        )

        AccessibilitySwitchRow(
            title = "Mouvements réduits",
            desc = "Désactive les transitions d'écrans pour réduire la fatigue oculaire.",
            checked = reducedMotion,
            onCheckedChange = { viewModel.setReducedMotion(it) }
        )
    }
}

@Composable
fun AccessibilitySwitchRow(
    title: String,
    desc: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(text = desc, fontSize = 11.sp, color = SteelGrey, modifier = Modifier.padding(top = 2.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}

// --- SUB SCREEN: FAVOURITES ---
@Composable
fun FavouritesScreen(
    viewModel: MetroViewModel,
    language: String,
    onSelectStation: (String) -> Unit
) {
    val favs = viewModel.favourites.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (favs.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.FavoriteBorder, contentDescription = null, tint = SteelGrey, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Aucune station favorite / No favourites", fontWeight = FontWeight.Bold)
                }
            }
        } else {
            favs.forEach { fav ->
                val station = viewModel.allStations.find { it.id == fav.stationId }
                station?.let {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectStation(station.id) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (language == "fr") station.frenchName else station.englishName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "${station.lines.size} lignes connectées",
                                    fontSize = 11.sp,
                                    color = SteelGrey
                                )
                            }

                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SteelGrey)
                        }
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: NOTIFICATIONS ---
@Composable
fun NotificationsScreen() {
    var alertsChecked by remember { mutableStateOf(true) }
    var weatherChecked by remember { mutableStateOf(true) }
    var newsChecked by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "CONFIGURER LES ALERTES PASSAGERS / NOTIFICATIONS",
            style = MaterialTheme.typography.labelSmall,
            color = SteelGrey,
            letterSpacing = 1.sp
        )

        AccessibilitySwitchRow(
            title = "Avis de retards majeurs",
            desc = "Alerter lors d'interruptions majeures sur vos lignes favorites.",
            checked = alertsChecked,
            onCheckedChange = { alertsChecked = it }
        )

        AccessibilitySwitchRow(
            title = "Alertes météorologiques",
            desc = "Notification en temps de tempêtes hivernales affectant l'état des escaliers.",
            checked = weatherChecked,
            onCheckedChange = { weatherChecked = it }
        )

        AccessibilitySwitchRow(
            title = "Actualités STM",
            desc = "Informations générales de travaux ou de refontes de zones.",
            checked = newsChecked,
            onCheckedChange = { newsChecked = it }
        )
    }
}

// --- SUB SCREEN: ABOUT SCREEN ---
@Composable
fun AboutScreen(viewModel: MetroViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = StmBlue,
            modifier = Modifier.size(64.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(text = "M", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black)
            }
        }

        Text(
            text = "MÉTRO MONTRÉAL",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black
        )

        Text(
            text = "Cette application est un prototype technologique de démonstration destiné à illustrer l'expérience utilisateur et les architectures mobiles modernes (Kotlin, Jetpack Compose, Room, DataStore).\n\n" +
                    "Elle n'est pas affiliée à, financée par, ou associée à la Société de transport de Montréal (STM) ni à l'Autorité régionale de transport métropolitain (ARTM).\n\n" +
                    "Toutes les données temporelles, passages et notifications sont générées localement par un moteur de simulation déterministe hors ligne.",
            fontSize = 13.sp,
            lineHeight = 20.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Divider(modifier = Modifier.padding(vertical = 12.dp))

        Text(
            text = "Moteur de simulation v3.5 • Démo local sécurisé",
            fontSize = 11.sp,
            color = SteelGrey,
            fontWeight = FontWeight.Bold
        )
    }
}

// --- SUB SCREEN: DEVELOPER SIMULATION CONSOLE (CRITICAL) ---
@Composable
fun SimulationConsoleScreen(
    viewModel: MetroViewModel,
    language: String
) {
    val activeScenario by viewModel.currentScenario.collectAsState()
    val isPaused by viewModel.isSimulationPaused.collectAsState()
    val eventLogs by viewModel.eventLogs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "SÉLECTION DU SCÉNARIO / CHOOSE SCENARIO",
            style = MaterialTheme.typography.labelSmall,
            color = SteelGrey,
            letterSpacing = 1.sp
        )

        // 8 deterministic scenarios
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ScenarioItem(
                title = "Service Normal",
                desc = "Aucune perturbation injectée.",
                isActive = activeScenario == SimulationScenario.NORMAL,
                onClick = { viewModel.setScenario(SimulationScenario.NORMAL) }
            )
            ScenarioItem(
                title = "Retard Ligne Orange",
                desc = "Retard important sur la ligne L2 dû au signal.",
                isActive = activeScenario == SimulationScenario.DELAY_ORANGE,
                onClick = { viewModel.setScenario(SimulationScenario.DELAY_ORANGE) }
            )
            ScenarioItem(
                title = "Panne d'ascenseur",
                desc = "Ascenseur en panne à Berri-UQAM.",
                isActive = activeScenario == SimulationScenario.ELEVATOR_DOWN,
                onClick = { viewModel.setScenario(SimulationScenario.ELEVATOR_DOWN) }
            )
            ScenarioItem(
                title = "Fermeture de station",
                desc = "Côte-Vertu est temporairement fermée.",
                isActive = activeScenario == SimulationScenario.STATION_CLOSED,
                onClick = { viewModel.setScenario(SimulationScenario.STATION_CLOSED) }
            )
            ScenarioItem(
                title = "Mode Hors-ligne",
                desc = "Simule l'absence totale de réseau internet.",
                isActive = activeScenario == SimulationScenario.OFFLINE,
                onClick = { viewModel.setScenario(SimulationScenario.OFFLINE) }
            )
            ScenarioItem(
                title = "Échec d'achat",
                desc = "Tous les paiements échouent systématiquement.",
                isActive = activeScenario == SimulationScenario.PAY_FAIL,
                onClick = { viewModel.setScenario(SimulationScenario.PAY_FAIL) }
            )
            ScenarioItem(
                title = "Tempête hivernale",
                desc = "Avis de marches glissantes sur le réseau.",
                isActive = activeScenario == SimulationScenario.WINTER,
                onClick = { viewModel.setScenario(SimulationScenario.WINTER) }
            )
            ScenarioItem(
                title = "Multi-alertes",
                desc = "Combine retards, ascenseur en panne et station fermée.",
                isActive = activeScenario == SimulationScenario.MULTI_ALERTS,
                onClick = { viewModel.setScenario(SimulationScenario.MULTI_ALERTS) }
            )
        }

        Divider()

        // Clock Fast-Forward Controls
        Text(
            text = "MOTEUR TEMPOREL / TIME ENGINE",
            style = MaterialTheme.typography.labelSmall,
            color = SteelGrey,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { viewModel.advanceTime() },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = StmBlue),
                shape = MaterialTheme.shapes.small
            ) {
                Icon(Icons.Default.FastForward, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Avancer +5m", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            Button(
                onClick = { viewModel.toggleSimulationPause() },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                shape = MaterialTheme.shapes.small
            ) {
                Icon(
                    imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isPaused) "Reprendre" else "Pause",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        Divider()

        // SYSTEM LOG MONITOR
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "JOURNAL DE L'APPLICATION / EVENT LOGS",
                style = MaterialTheme.typography.labelSmall,
                color = SteelGrey,
                letterSpacing = 0.5.sp
            )

            TextButton(onClick = { viewModel.clearLocalData() }, modifier = Modifier.testTag("reset_all_data")) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Réinitialiser / Reset", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Red)
            }
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                if (eventLogs.isEmpty()) {
                    item {
                        Text(
                            text = "> Moteur de simulation initialisé.\n> En attente d'événements...",
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            color = Color.Green,
                            fontSize = 11.sp
                        )
                    }
                } else {
                    items(eventLogs.size) { index ->
                        val log = eventLogs[index]
                        val logMsg = if (language == "fr") log.messageFr else log.messageEn
                        Text(
                            text = "> [${log.type}] $logMsg",
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            color = when (log.type) {
                                "ERROR" -> Color.Red
                                "SCENARIO" -> StmOrange
                                "TIME" -> Color.Cyan
                                else -> Color.Green
                            },
                            fontSize = 11.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ScenarioItem(
    title: String,
    desc: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("scenario_$title"),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) StmBlue.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            1.dp,
            if (isActive) StmBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text(text = desc, fontSize = 11.sp, color = SteelGrey)
            }

            RadioButton(selected = isActive, onClick = onClick)
        }
    }
}
