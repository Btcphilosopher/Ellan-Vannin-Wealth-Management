package com.example.feature.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domain.model.*
import com.example.feature.MetroViewModel
import com.example.ui.theme.StmBlue
import com.example.ui.theme.StmGreen
import com.example.ui.theme.StmOrange
import com.example.ui.theme.SteelGrey

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTabScreen(
    viewModel: MetroViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToAlerts: () -> Unit,
    onNavigateToAccessibility: () -> Unit
) {
    val languageState = viewModel.language.collectAsState().value
    val timeState = viewModel.simulatedTime.collectAsState().value
    val offlineState = viewModel.isOffline.collectAsState().value
    val alertsList = viewModel.serviceAlerts.collectAsState().value
    val currentScenario = viewModel.currentScenario.collectAsState().value

    // Format simulated time
    val timeFormatter = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
    val formattedTime = timeFormatter.format(java.util.Date(timeState))

    // List of stations for quick dropdowns
    val allStations = viewModel.allStations
    var showOriginDropdown by remember { mutableStateOf(false) }
    var showDestDropdown by remember { mutableStateOf(false) }

    val selectedOriginId by viewModel.originStationId.collectAsState()
    val selectedDestId by viewModel.destinationStationId.collectAsState()

    val originStation = allStations.find { it.id == selectedOriginId }
    val destStation = allStations.find { it.id == selectedDestId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = stringResource(R.string.greeting),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Location",
                            tint = StmBlue,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.location_indicator),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            actions = {
                // Time Badge
                Badge(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Text(
                        text = "🕒 $formattedTime",
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                // Lang shortcut
                IconButton(
                    onClick = { viewModel.toggleLanguage() },
                    modifier = Modifier.testTag("home_lang_switch")
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Switch language"
                    )
                }

                // Settings icon
                IconButton(onClick = onNavigateToSettings) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings"
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        )

        // Offline Banner
        if (offlineState) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Red)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.offline_banner).uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                )
            }
        }

        // --- BODY SCROLLABLE ---
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // --- SEASONAL WEATHER CONTEXT ---
            if (currentScenario == SimulationScenario.WINTER || currentScenario == SimulationScenario.MULTI_ALERTS) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)),
                    border = BorderStroke(1.dp, StmBlue),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AcUnit,
                            contentDescription = "Snow",
                            tint = StmBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.seasonal_winter_alert),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "❄️ ${stringResource(R.string.data_simulated)}",
                                fontSize = 10.sp,
                                color = StmBlue
                            )
                        }
                    }
                }
            }

            // --- TRIP PLANNER MAIN CARD ---
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_trip_card"),
                shape = MaterialTheme.shapes.medium,
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.plan_trip).uppercase(),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Black,
                        color = StmBlue,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // FROM field
                    Box {
                        OutlinedTextField(
                            value = originStation?.let { if (languageState == "fr") it.frenchName else it.englishName } ?: "",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(stringResource(R.string.from_station)) },
                            leadingIcon = { Icon(Icons.Default.TripOrigin, contentDescription = null, tint = StmGreen) },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showOriginDropdown = true },
                            enabled = false,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = MaterialTheme.colorScheme.outline,
                                disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                disabledLeadingIconColor = StmGreen,
                                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        DropdownMenu(
                            expanded = showOriginDropdown,
                            onDismissRequest = { showOriginDropdown = false },
                            modifier = Modifier.fillMaxWidth(0.85f)
                        ) {
                            allStations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(if (languageState == "fr") station.frenchName else station.englishName) },
                                    onClick = {
                                        viewModel.setOrigin(station.id)
                                        showOriginDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // SWAP BUTTON
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(onClick = { viewModel.swapStations() }) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "Swap Origin/Destination",
                                tint = StmBlue
                            )
                        }
                    }

                    // TO field
                    Box {
                        OutlinedTextField(
                            value = destStation?.let { if (languageState == "fr") it.frenchName else it.englishName } ?: "",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(stringResource(R.string.to_station)) },
                            leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = StmOrange) },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showDestDropdown = true },
                            enabled = false,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = MaterialTheme.colorScheme.outline,
                                disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                disabledLeadingIconColor = StmOrange,
                                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        DropdownMenu(
                            expanded = showDestDropdown,
                            onDismissRequest = { showDestDropdown = false },
                            modifier = Modifier.fillMaxWidth(0.85f)
                        ) {
                            allStations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(if (languageState == "fr") station.frenchName else station.englishName) },
                                    onClick = {
                                        viewModel.setDestination(station.id)
                                        showDestDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.calculateRoutes()
                            viewModel.selectTab("routes")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("plan_trip_button"),
                        shape = MaterialTheme.shapes.small,
                        colors = ButtonDefaults.buttonColors(containerColor = StmBlue)
                    ) {
                        Text(
                            text = stringResource(R.string.plan_trip).uppercase(),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // --- NEARBY STATION CARD (Berri-UQAM) ---
            val nearbyId = "berri_uqam"
            val nearbyStation = allStations.find { it.id == nearbyId }
            if (nearbyStation != null) {
                val isFav = viewModel.favourites.collectAsState().value.any { it.stationId == nearbyId }
                val departures = remember(timeState, currentScenario) {
                    viewModel.repository.getSimulatedDepartures(nearbyId)
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = stringResource(R.string.nearby_station).uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SteelGrey,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = if (languageState == "fr") nearbyStation.frenchName else nearbyStation.englishName,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "🚶 350m — 5 min (${stringResource(R.string.walking_distance)})",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row {
                                // Accessible symbol
                                if (nearbyStation.isAccessible) {
                                    Icon(
                                        imageVector = Icons.Default.Accessible,
                                        contentDescription = "Accessible",
                                        tint = StmBlue,
                                        modifier = Modifier.padding(end = 8.dp)
                                    )
                                }
                                // Favourite toggle
                                IconButton(onClick = { viewModel.toggleFavourite(nearbyId) }) {
                                    Icon(
                                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Favorite",
                                        tint = if (isFav) Color.Red else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 12.dp))

                        Text(
                            text = stringResource(R.string.next_departures).uppercase(),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = StmBlue,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        // Listed simulated departures
                        if (departures.isEmpty()) {
                            Text(text = "Aucun départ disponible / No departures", fontSize = 12.sp)
                        } else {
                            departures.take(3).forEach { departure ->
                                val directionStation = allStations.find { it.id == departure.directionStationId }
                                val line = viewModel.allLines.find { it.id == departure.lineId }
                                val lineColour = Color(android.graphics.Color.parseColor(line?.colourHex ?: "#8A95A5"))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        // Line badge
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .background(lineColour),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = line?.id?.substring(1) ?: "",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = "Direction " + (if (languageState == "fr") directionStation?.frenchName else directionStation?.englishName),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    // Countdown
                                    Text(
                                        text = "${departure.minutesAway} min",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Black,
                                        color = if (departure.minutesAway <= 2) StmGreen else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // --- NETWORK STATUS CARD ---
            val isDisrupted = alertsList.any { it.severity == AlertSeverity.MAJOR }
            val statusColor = if (isDisrupted) StmOrange else StmGreen
            val statusText = if (isDisrupted) stringResource(R.string.status_disrupted) else stringResource(R.string.status_operational)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.network_status).uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = SteelGrey,
                            letterSpacing = 1.sp
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(statusColor)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black
                            )
                        }

                        // Alerts summary
                        val alertsCount = alertsList.size
                        Text(
                            text = "$alertsCount ${stringResource(R.string.active_alerts)}",
                            fontSize = 12.sp,
                            color = if (alertsCount > 0) StmOrange else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = onNavigateToAlerts,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Text(text = "Voir / View", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // --- QUICK ACTIONS GRID ---
            Text(
                text = "Raccourcis / Quick Actions".uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = SteelGrey,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionItem(
                    title = stringResource(R.string.qa_plan_trip),
                    icon = Icons.Default.Directions,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.selectTab("routes")
                }
                QuickActionItem(
                    title = stringResource(R.string.qa_find_station),
                    icon = Icons.Default.Train,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.selectTab("stations")
                }
                QuickActionItem(
                    title = stringResource(R.string.qa_alerts),
                    icon = Icons.Default.Warning,
                    modifier = Modifier.weight(1f)
                ) {
                    onNavigateToAlerts()
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionItem(
                    title = stringResource(R.string.qa_tickets),
                    icon = Icons.Default.ConfirmationNumber,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.selectTab("tickets")
                }
                QuickActionItem(
                    title = stringResource(R.string.qa_accessibility),
                    icon = Icons.Default.Accessible,
                    modifier = Modifier.weight(1f)
                ) {
                    onNavigateToAccessibility()
                }
                QuickActionItem(
                    title = stringResource(R.string.qa_network_map),
                    icon = Icons.Default.Map,
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.selectTab("stations")
                }
            }

            // Bottom disclaimer details
            Text(
                text = "MÉTRO MONTRÉAL PASSENGER PORTAL • ${stringResource(R.string.data_simulated)}",
                fontSize = 10.sp,
                color = SteelGrey,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(80.dp)
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.small,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = StmBlue,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
