package com.example.domain.routing

import com.example.domain.model.*
import java.util.PriorityQueue

object MetroRoutingEngine {

    // Define lines
    val lines = listOf(
        MetroLine(
            id = "L1",
            frenchName = "Ligne 1 — Verte",
            englishName = "Green Line (1)",
            colourHex = "#008E4F", // STM Green
            stations = listOf("angrignon", "lionel_groulx", "guy_concordia", "mcgill", "place_des_arts", "berri_uqam", "honore_beaugrand"),
            termini = listOf("angrignon", "honore_beaugrand")
        ),
        MetroLine(
            id = "L2",
            frenchName = "Ligne 2 — Orange",
            englishName = "Orange Line (2)",
            colourHex = "#EE7F2D", // STM Orange
            stations = listOf("cote_vertu", "snowdon", "lionel_groulx", "bonaventure", "berri_uqam", "jean_talon", "montmorency"),
            termini = listOf("cote_vertu", "montmorency")
        ),
        MetroLine(
            id = "L4",
            frenchName = "Ligne 4 — Jaune",
            englishName = "Yellow Line (4)",
            colourHex = "#FAD135", // STM Yellow
            stations = listOf("berri_uqam", "longueuil"),
            termini = listOf("berri_uqam", "longueuil")
        ),
        MetroLine(
            id = "L5",
            frenchName = "Ligne 5 — Bleue",
            englishName = "Blue Line (5)",
            colourHex = "#007EC5", // STM Blue
            stations = listOf("snowdon", "jean_talon", "saint_michel"),
            termini = listOf("snowdon", "saint_michel")
        )
    )

    // Define stations
    val stations = listOf(
        MetroStation(
            id = "angrignon",
            frenchName = "Angrignon",
            englishName = "Angrignon",
            lines = listOf("L1"),
            entrances = listOf(StationEntrance("en-1", "Entrée Principale", "Avenue des Trinitaires", true)),
            facilities = listOf(StationFacility("Support Vélos", FacilityType.BIKE_RACK, true)),
            nearbyStreets = listOf("Avenue des Trinitaires", "Boulevard Newman"),
            pointsOfInterest = listOf("Parc Angrignon", "Carrefour Angrignon"),
            isAccessible = true,
            latitude = 45.4462,
            longitude = -73.6038
        ),
        MetroStation(
            id = "lionel_groulx",
            frenchName = "Lionel-Groulx",
            englishName = "Lionel-Groulx",
            lines = listOf("L1", "L2"),
            entrances = listOf(
                StationEntrance("en-1", "Entrée Saint-Jacques", "Rue Saint-Jacques", true),
                StationEntrance("en-2", "Entrée Atwater", "Avenue Atwater", true)
            ),
            facilities = listOf(
                StationFacility("Ascenseur L1/L2", FacilityType.ELEVATOR, true),
                StationFacility("Escalier mécanique", FacilityType.ESCALATOR, true)
            ),
            nearbyStreets = listOf("Rue Saint-Jacques", "Avenue Atwater"),
            pointsOfInterest = listOf("Marché Atwater", "Canal de Lachine"),
            isAccessible = true,
            latitude = 45.4830,
            longitude = -73.5799
        ),
        MetroStation(
            id = "guy_concordia",
            frenchName = "Guy-Concordia",
            englishName = "Guy-Concordia",
            lines = listOf("L1"),
            entrances = listOf(StationEntrance("en-1", "Entrée Guy", "Rue Guy", false)),
            facilities = listOf(StationFacility("Escalier mécanique", FacilityType.ESCALATOR, true)),
            nearbyStreets = listOf("Rue Guy", "Rue Sainte-Catherine Ouest"),
            pointsOfInterest = listOf("Université Concordia", "Musée des beaux-arts de Montréal"),
            isAccessible = false,
            latitude = 45.4951,
            longitude = -73.5795
        ),
        MetroStation(
            id = "mcgill",
            frenchName = "McGill",
            englishName = "McGill",
            lines = listOf("L1"),
            entrances = listOf(StationEntrance("en-1", "Entrée Robert-Bourassa", "Avenue Robert-Bourassa", true)),
            facilities = listOf(StationFacility("Ascenseur", FacilityType.ELEVATOR, true)),
            nearbyStreets = listOf("Avenue Robert-Bourassa", "Rue Sainte-Catherine Ouest"),
            pointsOfInterest = listOf("Université McGill", "Centre Eaton de Montréal"),
            isAccessible = true,
            latitude = 45.5041,
            longitude = -73.5716
        ),
        MetroStation(
            id = "place_des_arts",
            frenchName = "Place-des-Arts",
            englishName = "Place-des-Arts",
            lines = listOf("L1"),
            entrances = listOf(StationEntrance("en-1", "Entrée Jeanne-Mance", "Rue Jeanne-Mance", true)),
            facilities = listOf(StationFacility("Ascenseur", FacilityType.ELEVATOR, true)),
            nearbyStreets = listOf("Rue Jeanne-Mance", "Rue Sainte-Catherine Ouest"),
            pointsOfInterest = listOf("Place des Arts", "Musée d'art contemporain"),
            isAccessible = true,
            latitude = 45.5081,
            longitude = -73.5686
        ),
        MetroStation(
            id = "berri_uqam",
            frenchName = "Berri-UQAM",
            englishName = "Berri-UQAM",
            lines = listOf("L1", "L2", "L4"),
            entrances = listOf(
                StationEntrance("en-1", "Entrée Saint-Denis", "Rue Saint-Denis", true),
                StationEntrance("en-2", "Entrée Berri", "Rue Berri", true)
            ),
            facilities = listOf(
                StationFacility("Ascenseur L1/L2", FacilityType.ELEVATOR, true),
                StationFacility("Escalier mécanique", FacilityType.ESCALATOR, true)
            ),
            nearbyStreets = listOf("Rue Berri", "Rue Sainte-Catherine Est", "Rue Saint-Denis"),
            pointsOfInterest = listOf("UQAM (Université du Québec à Montréal)", "Grande Bibliothèque", "Quartier des Spectacles"),
            isAccessible = true,
            latitude = 45.5155,
            longitude = -73.5617
        ),
        MetroStation(
            id = "honore_beaugrand",
            frenchName = "Honoré-Beaugrand",
            englishName = "Honoré-Beaugrand",
            lines = listOf("L1"),
            entrances = listOf(StationEntrance("en-1", "Entrée Sherbrooke", "Rue Sherbrooke Est", true)),
            facilities = listOf(StationFacility("Ascenseur", FacilityType.ELEVATOR, true)),
            nearbyStreets = listOf("Rue Sherbrooke Est", "Rue Honoré-Beaugrand"),
            pointsOfInterest = listOf("Centre commercial Place Versailles"),
            isAccessible = true,
            latitude = 45.5962,
            longitude = -73.5350
        ),
        MetroStation(
            id = "cote_vertu",
            frenchName = "Côte-Vertu",
            englishName = "Côte-Vertu",
            lines = listOf("L2"),
            entrances = listOf(StationEntrance("en-1", "Entrée Côte-Vertu", "Boulevard de la Côte-Vertu", true)),
            facilities = listOf(StationFacility("Ascenseur", FacilityType.ELEVATOR, true)),
            nearbyStreets = listOf("Boulevard de la Côte-Vertu", "Rue Décarie"),
            pointsOfInterest = listOf("Cégep Vanier", "Cégep de Saint-Laurent"),
            isAccessible = true,
            latitude = 45.5142,
            longitude = -73.6828
        ),
        MetroStation(
            id = "snowdon",
            frenchName = "Snowdon",
            englishName = "Snowdon",
            lines = listOf("L2", "L5"),
            entrances = listOf(StationEntrance("en-1", "Entrée Chemin Queen-Mary", "Chemin Queen-Mary", true)),
            facilities = listOf(
                StationFacility("Ascenseur L2/L5", FacilityType.ELEVATOR, true),
                StationFacility("Escalier mécanique", FacilityType.ESCALATOR, true)
            ),
            nearbyStreets = listOf("Chemin Queen-Mary", "Avenue Decelles"),
            pointsOfInterest = listOf("Oratoire Saint-Joseph (proche)", "Parc Macdonald"),
            isAccessible = true,
            latitude = 45.4855,
            longitude = -73.6276
        ),
        MetroStation(
            id = "bonaventure",
            frenchName = "Bonaventure",
            englishName = "Bonaventure",
            lines = listOf("L2"),
            entrances = listOf(StationEntrance("en-1", "Entrée de la Cathédrale", "Rue de la Cathédrale", true)),
            facilities = listOf(StationFacility("Ascenseur", FacilityType.ELEVATOR, true)),
            nearbyStreets = listOf("Rue de la Gauchetière Ouest", "Rue University"),
            pointsOfInterest = listOf("Gare Centrale", "Place Ville-Marie", "Centre Bell"),
            isAccessible = true,
            latitude = 45.4982,
            longitude = -73.5672
        ),
        MetroStation(
            id = "jean_talon",
            frenchName = "Jean-Talon",
            englishName = "Jean-Talon",
            lines = listOf("L2", "L5"),
            entrances = listOf(StationEntrance("en-1", "Entrée Jean-Talon", "Rue Jean-Talon Est", true)),
            facilities = listOf(
                StationFacility("Ascenseur L2/L5", FacilityType.ELEVATOR, true),
                StationFacility("Escalier mécanique", FacilityType.ESCALATOR, true)
            ),
            nearbyStreets = listOf("Rue Jean-Talon", "Rue Saint-Denis"),
            pointsOfInterest = listOf("Marché Jean-Talon", "Petite Italie"),
            isAccessible = true,
            latitude = 45.5397,
            longitude = -73.6134
        ),
        MetroStation(
            id = "montmorency",
            frenchName = "Montmorency",
            englishName = "Montmorency",
            lines = listOf("L2"),
            entrances = listOf(StationEntrance("en-1", "Entrée Jacques-Tétreault", "Boulevard Jacques-Tétreault", true)),
            facilities = listOf(StationFacility("Ascenseur", FacilityType.ELEVATOR, true)),
            nearbyStreets = listOf("Boulevard de l'Avenir", "Boulevard Jacques-Tétreault"),
            pointsOfInterest = listOf("Université de Montréal (Campus de Laval)", "Espace Bell"),
            isAccessible = true,
            latitude = 45.5579,
            longitude = -73.7212
        ),
        MetroStation(
            id = "longueuil",
            frenchName = "Longueuil–Université-de-Sherbrooke",
            englishName = "Longueuil–Université-de-Sherbrooke",
            lines = listOf("L4"),
            entrances = listOf(StationEntrance("en-1", "Entrée Terminus Longueuil", "Place Charles-Le Moyne", true)),
            facilities = listOf(StationFacility("Escalier mécanique", FacilityType.ESCALATOR, true)),
            nearbyStreets = listOf("Place Charles-Le Moyne", "Rue de Sérigny"),
            pointsOfInterest = listOf("Campus Longueuil de l'Université de Sherbrooke", "Terminus d'autobus Longueuil"),
            isAccessible = true,
            latitude = 45.5245,
            longitude = -73.5218
        ),
        MetroStation(
            id = "saint_michel",
            frenchName = "Saint-Michel",
            englishName = "Saint-Michel",
            lines = listOf("L5"),
            entrances = listOf(StationEntrance("en-1", "Entrée Boulevard Shaughnessy", "Boulevard Shaughnessy", false)),
            facilities = listOf(StationFacility("Support vélos", FacilityType.BIKE_RACK, true)),
            nearbyStreets = listOf("Boulevard Saint-Michel", "Rue Shaughnessy"),
            pointsOfInterest = listOf("Parc François-Perrault"),
            isAccessible = false,
            latitude = 45.5597,
            longitude = -73.5997
        )
    )

    private val stationsMap = stations.associateBy { it.id }
    private val linesMap = lines.associateBy { it.id }

    fun getStation(id: String): MetroStation? = stationsMap[id]
    fun getLine(id: String): MetroLine? = linesMap[id]

    // Graph definition
    data class Edge(
        val targetId: String,
        val lineId: String,
        val travelTimeMinutes: Int
    )

    // Build the structural graph representation
    private val graph: Map<String, List<Edge>> = buildMap<String, MutableList<Edge>> {
        lines.forEach { line ->
            for (i in 0 until line.stations.size - 1) {
                val s1 = line.stations[i]
                val s2 = line.stations[i + 1]
                val weight = when {
                    // Specific mock durations
                    s1 == "angrignon" && s2 == "lionel_groulx" -> 4
                    s1 == "lionel_groulx" && s2 == "guy_concordia" -> 3
                    s1 == "guy_concordia" && s2 == "mcgill" -> 2
                    s1 == "mcgill" && s2 == "place_des_arts" -> 2
                    s1 == "place_des_arts" && s2 == "berri_uqam" -> 2
                    s1 == "berri_uqam" && s2 == "honore_beaugrand" -> 6
                    
                    s1 == "cote_vertu" && s2 == "snowdon" -> 5
                    s1 == "snowdon" && s2 == "lionel_groulx" -> 4
                    s1 == "lionel_groulx" && s2 == "bonaventure" -> 3
                    s1 == "bonaventure" && s2 == "berri_uqam" -> 4
                    s1 == "berri_uqam" && s2 == "jean_talon" -> 6
                    s1 == "jean_talon" && s2 == "montmorency" -> 8
                    
                    s1 == "berri_uqam" && s2 == "longueuil" -> 4
                    
                    s1 == "snowdon" && s2 == "jean_talon" -> 6
                    s1 == "jean_talon" && s2 == "saint_michel" -> 4
                    else -> 3
                }
                
                this.getOrPut(s1) { mutableListOf() }.add(Edge(s2, line.id, weight))
                this.getOrPut(s2) { mutableListOf() }.add(Edge(s1, line.id, weight))
            }
        }
    }

    // Dijkstra implementation
    data class RouterState(
        val stationId: String,
        val cost: Int,
        val currentLineId: String?,
        val transfers: Int,
        val path: List<PathStep>
    ) : Comparable<RouterState> {
        override fun compareTo(other: RouterState): Int {
            // First by cost (duration), then by transfers
            val costCompare = this.cost.compareTo(other.cost)
            if (costCompare != 0) return costCompare
            return this.transfers.compareTo(other.transfers)
        }
    }

    data class PathStep(
        val stationId: String,
        val reachedViaLine: String?
    )

    fun planRoute(
        originId: String,
        destinationId: String,
        preference: RoutePreference,
        accessibleOnly: Boolean,
        closedStations: Set<String> = emptySet(),
        disruptedLines: Set<String> = emptySet()
    ): JourneyOption? {
        if (originId == destinationId) return null
        if (closedStations.contains(originId) || closedStations.contains(destinationId)) return null

        val origin = stationsMap[originId] ?: return null
        val destination = stationsMap[destinationId] ?: return null

        val pq = PriorityQueue<RouterState>()
        // Initialize origin
        pq.add(RouterState(originId, 0, null, 0, listOf(PathStep(originId, null))))

        // Keep track of visited states: Pair(stationId, lineId)
        val visited = mutableSetOf<Pair<String, String?>>()

        while (pq.isNotEmpty()) {
            val curr = pq.poll()

            if (curr.stationId == destinationId) {
                // We reached the destination! Let's build the JourneyOption.
                return buildJourneyOption(curr, preference)
            }

            val stateKey = Pair(curr.stationId, curr.currentLineId)
            if (visited.contains(stateKey)) continue
            visited.add(stateKey)

            val edges = graph[curr.stationId] ?: emptyList()
            for (edge in edges) {
                if (closedStations.contains(edge.targetId)) continue
                if (disruptedLines.contains(edge.lineId) && preference != RoutePreference.FASTEST) {
                    // Block routing through disrupted lines unless absolutely requested as Fastest
                    continue
                }

                val targetStation = stationsMap[edge.targetId] ?: continue
                if (accessibleOnly && !targetStation.isAccessible) continue

                // Calculate edge cost with preference weightings
                var edgeWeight = edge.travelTimeMinutes
                
                // Disrupted line penalty (if not completely blocked)
                if (disruptedLines.contains(edge.lineId)) {
                    edgeWeight += 15 // massive delay penalty
                }

                // Transfer penalty
                val isTransfer = curr.currentLineId != null && curr.currentLineId != edge.lineId
                var transferPenalty = 0
                if (isTransfer) {
                    transferPenalty = when (preference) {
                        RoutePreference.FEWER_TRANSFERS -> 25 // heavy penalty to avoid changing lines
                        RoutePreference.STEP_FREE -> 8 // extra time to find elevators
                        RoutePreference.FEWER_STAIRS -> 15 // transferring usually involves stairs
                        else -> 5 // standard transfer penalty (5 minutes)
                    }
                }

                val nextCost = curr.cost + edgeWeight + transferPenalty
                val nextTransfers = curr.transfers + (if (isTransfer) 1 else 0)
                val nextPath = curr.path + PathStep(edge.targetId, edge.lineId)

                pq.add(
                    RouterState(
                        stationId = edge.targetId,
                        cost = nextCost,
                        currentLineId = edge.lineId,
                        transfers = nextTransfers,
                        path = nextPath
                    )
                )
            }
        }

        return null
    }

    private fun buildJourneyOption(state: RouterState, preference: RoutePreference): JourneyOption {
        val segments = mutableListOf<JourneySegment>()
        val path = state.path
        val warnings = mutableListOf<String>()

        if (path.size < 2) {
            return JourneyOption("opt-1", 0, 0, emptyList(), emptyList())
        }

        // 1. Walk to Entrance segment
        val startStationId = path[0].stationId
        val startStation = stationsMap[startStationId]
        segments.add(
            JourneySegment(
                id = "seg-walk-start",
                type = SegmentType.WALK,
                fromStationId = startStationId,
                toStationId = startStationId,
                lineId = null,
                directionStationId = null,
                durationMinutes = 2,
                instructionsFr = "Marcher vers l'entrée de la station ${startStation?.frenchName}.",
                instructionsEn = "Walk to the entrance of ${startStation?.englishName} station."
            )
        )

        // Group path elements by continuous line ride
        var i = 1
        var segIdCounter = 1
        while (i < path.size) {
            val lineId = path[i].reachedViaLine!!
            val rideStartIdx = i - 1
            val rideFromId = path[rideStartIdx].stationId

            // Collect stations along the same line
            while (i < path.size && path[i].reachedViaLine == lineId) {
                i++
            }
            val rideToId = path[i - 1].stationId

            // Determine direction of travel on the line
            val directionStationId = determineDirection(lineId, rideFromId, rideToId)
            val directionStation = stationsMap[directionStationId]
            val fromStation = stationsMap[rideFromId]
            val toStation = stationsMap[rideToId]
            val line = linesMap[lineId]

            // Calculate exact travel time on line
            var travelTime = 0
            for (k in rideStartIdx until (i - 1)) {
                val sA = path[k].stationId
                val sB = path[k + 1].stationId
                travelTime += getDirectEdgeWeight(sA, sB, lineId)
            }

            segments.add(
                JourneySegment(
                    id = "seg-ride-$segIdCounter",
                    type = SegmentType.RIDE,
                    fromStationId = rideFromId,
                    toStationId = rideToId,
                    lineId = lineId,
                    directionStationId = directionStationId,
                    durationMinutes = travelTime,
                    instructionsFr = "Prendre la ligne ${line?.frenchName?.substringAfter("— ")} en direction de ${directionStation?.frenchName}.",
                    instructionsEn = "Take the ${line?.englishName} towards ${directionStation?.englishName}."
                )
            )
            segIdCounter++

            // If we are not at the final station, it means we are transferring
            if (i < path.size) {
                val transferStationId = path[i - 1].stationId
                val transferStation = stationsMap[transferStationId]
                val nextLineId = path[i].reachedViaLine!!
                val nextLine = linesMap[nextLineId]

                segments.add(
                    JourneySegment(
                        id = "seg-transfer-$segIdCounter",
                        type = SegmentType.TRANSFER,
                        fromStationId = transferStationId,
                        toStationId = transferStationId,
                        lineId = nextLineId,
                        directionStationId = null,
                        durationMinutes = 4, // 4 mins transfer time
                        instructionsFr = "Correspondance à ${transferStation?.frenchName} vers la ligne ${nextLine?.frenchName?.substringAfter("— ")}.",
                        instructionsEn = "Transfer at ${transferStation?.englishName} to the ${nextLine?.englishName}."
                    )
                )
                segIdCounter++
            }
        }

        // Final exit walk segment
        val lastStationId = path.last().stationId
        val lastStation = stationsMap[lastStationId]
        segments.add(
            JourneySegment(
                id = "seg-walk-end",
                type = SegmentType.WALK,
                fromStationId = lastStationId,
                toStationId = lastStationId,
                lineId = null,
                directionStationId = null,
                durationMinutes = 2,
                instructionsFr = "Descendre à ${lastStation?.frenchName} et prendre la sortie.",
                instructionsEn = "Arrive at ${lastStation?.englishName} and head to the exit."
            )
        )

        // Compute total duration of all segments
        val totalDuration = segments.sumOf { it.durationMinutes }

        if (preference == RoutePreference.STEP_FREE) {
            warnings.add("Itinéraire adapté aux fauteuils roulants (ascenseurs confirmés) / Wheelchair accessible route.")
        }

        return JourneyOption(
            id = "route-${state.stationId}-${System.currentTimeMillis()}",
            durationMinutes = totalDuration,
            transfers = state.transfers,
            segments = segments,
            warnings = warnings
        )
    }

    private fun determineDirection(lineId: String, fromId: String, toId: String): String {
        val line = linesMap[lineId] ?: return toId
        val stations = line.stations
        val fromIdx = stations.indexOf(fromId)
        val toIdx = stations.indexOf(toId)
        return if (toIdx > fromIdx) {
            line.termini.last()
        } else {
            line.termini.first()
        }
    }

    private fun getDirectEdgeWeight(s1: String, s2: String, lineId: String): Int {
        val edges = graph[s1] ?: return 3
        return edges.find { it.targetId == s2 && it.lineId == lineId }?.travelTimeMinutes ?: 3
    }
}
