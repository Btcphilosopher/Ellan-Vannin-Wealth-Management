package com.example.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- METRO NETWORK ---

data class MetroLine(
    val id: String, // L1 (Verte), L2 (Orange), L4 (Jaune), L5 (Bleue)
    val frenchName: String,
    val englishName: String,
    val colourHex: String,
    val stations: List<String>, // list of station IDs
    val termini: List<String>
)

data class MetroStation(
    val id: String,
    val frenchName: String,
    val englishName: String,
    val lines: List<String>, // list of line IDs (e.g. L1, L2)
    val entrances: List<StationEntrance>,
    val facilities: List<StationFacility>,
    val nearbyStreets: List<String>,
    val pointsOfInterest: List<String>,
    val isAccessible: Boolean,
    val latitude: Double,
    val longitude: Double
)

data class StationEntrance(
    val id: String,
    val name: String,
    val street: String,
    val isAccessible: Boolean
)

data class StationFacility(
    val name: String,
    val type: FacilityType,
    val isOperational: Boolean
)

enum class FacilityType {
    ELEVATOR, ESCALATOR, BIKE_RACK
}

// --- ROUTE PLANNING ---

enum class RoutePreference {
    FASTEST, FEWER_TRANSFERS, STEP_FREE, FEWER_STAIRS
}

data class RouteRequest(
    val originStationId: String,
    val destinationStationId: String,
    val preference: RoutePreference,
    val accessibleOnly: Boolean
)

data class JourneyOption(
    val id: String,
    val durationMinutes: Int,
    val transfers: Int,
    val segments: List<JourneySegment>,
    val warnings: List<String>
)

data class JourneySegment(
    val id: String,
    val type: SegmentType,
    val fromStationId: String,
    val toStationId: String,
    val lineId: String?, // null if walking
    val directionStationId: String?, // null if walking
    val durationMinutes: Int,
    val instructionsFr: String,
    val instructionsEn: String
)

enum class SegmentType {
    WALK, BOARD, RIDE, TRANSFER, EXIT
}

// --- ALERTS ---

@Entity(tableName = "service_alerts")
data class ServiceAlert(
    @PrimaryKey val id: String,
    val type: AlertCategory,
    val titleFr: String,
    val titleEn: String,
    val descriptionFr: String,
    val descriptionEn: String,
    val affectedLineId: String?,
    val affectedStationId: String?,
    val severity: AlertSeverity,
    val startTime: Long,
    val endTime: Long?,
    val sourceStatus: String, // "Verified", "Simulated", "Cached"
    val lastUpdated: Long
)

enum class AlertCategory {
    SERVICE_INTERRUPTION, DELAY, STATION_CLOSURE, ELEVATOR_OUTAGE, ESCALATOR_OUTAGE, PLANNED_WORK, WEATHER_NOTICE, ACCESSIBILITY_NOTICE, GENERAL_INFO
}

enum class AlertSeverity {
    MAJOR, MINOR, INFO
}

// --- DEPARTURES ---

data class Departure(
    val stationId: String,
    val lineId: String,
    val directionStationId: String,
    val minutesAway: Int,
    val isRealTime: Boolean
)

// --- TICKETS AND OPUS CARD ---

@Entity(tableName = "opus_cards")
data class OpusCard(
    @PrimaryKey val id: String, // card number (e.g., 0123-4567-89)
    val nickname: String,
    val statusFr: String,
    val statusEn: String,
    val balance: Double,
    val lastActivityFr: String,
    val lastActivityEn: String,
    val isFavourite: Boolean
)

data class TicketProduct(
    val id: String,
    val nameFr: String,
    val nameEn: String,
    val descriptionFr: String,
    val descriptionEn: String,
    val validityFr: String,
    val validityEn: String,
    val zoneFr: String,
    val zoneEn: String,
    val price: Double
)

@Entity(tableName = "demo_tickets")
data class DemoTicket(
    @PrimaryKey val id: String, // ticket reference
    val productId: String,
    val productNameFr: String,
    val productNameEn: String,
    val price: Double,
    val status: TicketStatus,
    val purchaseDate: Long,
    val validityStart: Long,
    val validityEnd: Long,
    val qrCodePayload: String
)

enum class TicketStatus {
    DRAFT, PAYMENT_PENDING, PAYMENT_AUTHORISED, PAYMENT_DECLINED, ISSUED, ACTIVE, EXPIRED, CANCELLED, REFUND_REQUESTED, REFUNDED
}

// --- SIMULATION & SYSTEM ---

enum class SimulationScenario {
    NORMAL, DELAY_ORANGE, ELEVATOR_DOWN, STATION_CLOSED, OFFLINE, PAY_FAIL, WINTER, MULTI_ALERTS
}

data class SimulationEvent(
    val timestamp: Long,
    val messageFr: String,
    val messageEn: String,
    val type: String
)

@Entity(tableName = "favourites")
data class FavouriteStation(
    @PrimaryKey val stationId: String,
    val timestamp: Long = System.currentTimeMillis()
)
