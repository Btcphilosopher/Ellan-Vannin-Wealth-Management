package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.AustrianRepository
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AustrianViewModel : ViewModel() {

    // Bottom Navigation tab: 0=Start, 1=Buchen, 2=Meine Reisen, 3=Status, 4=Profil
    private val _currentTab = MutableStateFlow(0)
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    fun setTab(tab: Int) {
        _currentTab.value = tab
    }

    // Search state
    private val _searchOrigin = MutableStateFlow("VIE")
    val searchOrigin: StateFlow<String> = _searchOrigin.asStateFlow()

    private val _searchDestination = MutableStateFlow("FRA")
    val searchDestination: StateFlow<String> = _searchDestination.asStateFlow()

    private val _searchDate = MutableStateFlow("2026-10-25")
    val searchDate: StateFlow<String> = _searchDate.asStateFlow()

    private val _searchResults = MutableStateFlow(AustrianRepository.searchFlights("VIE", "FRA", "2026-10-25"))
    val searchResults: StateFlow<List<Flight>> = _searchResults.asStateFlow()

    fun updateSearch(origin: String, destination: String, date: String) {
        _searchOrigin.value = origin
        _searchDestination.value = destination
        _searchDate.value = date
        _searchResults.value = AustrianRepository.searchFlights(origin, destination, date)
    }

    // Booking wizard flow state
    private val _isBookingActive = MutableStateFlow(false)
    val isBookingActive: StateFlow<Boolean> = _isBookingActive.asStateFlow()

    private val _bookingStep = MutableStateFlow(1) // 1: Fare, 2: Passenger, 3: Extras, 4: Review, 5: Payment, 6: Success
    val bookingStep: StateFlow<Int> = _bookingStep.asStateFlow()

    private val _selectedFlightForBooking = MutableStateFlow<Flight?>(null)
    val selectedFlightForBooking: StateFlow<Flight?> = _selectedFlightForBooking.asStateFlow()

    private val _selectedFare = MutableStateFlow<FareFamily?>(null)
    val selectedFare: StateFlow<FareFamily?> = _selectedFare.asStateFlow()

    private val _passengerFirstName = MutableStateFlow("Maximilian")
    val passengerFirstName: StateFlow<String> = _passengerFirstName.asStateFlow()

    private val _passengerLastName = MutableStateFlow("Weber")
    val passengerLastName: StateFlow<String> = _passengerLastName.asStateFlow()

    private val _passengerEmail = MutableStateFlow("maximilian.weber@example.com")
    val passengerEmail: StateFlow<String> = _passengerEmail.asStateFlow()

    private val _selectedSeat = MutableStateFlow("14A")
    val selectedSeat: StateFlow<String> = _selectedSeat.asStateFlow()

    private val _baggageCount = MutableStateFlow(1)
    val baggageCount: StateFlow<Int> = _baggageCount.asStateFlow()

    private val _confirmedBookingRef = MutableStateFlow("")
    val confirmedBookingRef: StateFlow<String> = _confirmedBookingRef.asStateFlow()

    fun startBooking(flight: Flight) {
        _selectedFlightForBooking.value = flight
        _selectedFare.value = flight.fareFamilies.firstOrNull()
        _bookingStep.value = 1
        _isBookingActive.value = true
    }

    fun setBookingStep(step: Int) {
        _bookingStep.value = step
    }

    fun selectFare(fare: FareFamily) {
        _selectedFare.value = fare
    }

    fun updatePassengerDetails(first: String, last: String, email: String) {
        _passengerFirstName.value = first
        _passengerLastName.value = last
        _passengerEmail.value = email
    }

    fun updateSeat(seat: String) {
        _selectedSeat.value = seat
    }

    fun updateBaggage(count: Int) {
        _baggageCount.value = count
    }

    fun confirmBooking() {
        val flight = _selectedFlightForBooking.value ?: return
        val fare = _selectedFare.value ?: flight.fareFamilies.first()
        val passenger = Passenger(
            firstName = _passengerFirstName.value,
            lastName = _passengerLastName.value,
            title = "Mr",
            dateOfBirth = "1990-01-01",
            passportNumber = "P12345678",
            frequentFlyerNumber = "OS-9928173"
        )
        val booking = AustrianRepository.addBooking(
            flight = flight,
            passengers = listOf(passenger),
            fare = fare,
            seat = _selectedSeat.value,
            baggage = _baggageCount.value
        )
        _confirmedBookingRef.value = booking.bookingRef
        _bookingStep.value = 6 // Success
    }

    fun cancelBookingWizard() {
        _isBookingActive.value = false
        _bookingStep.value = 1
    }

    // Trips and check-in
    val trips: StateFlow<List<Trip>> = AustrianRepository.trips
    val bookings: StateFlow<List<Booking>> = AustrianRepository.bookings
    val loyaltyAccount: StateFlow<LoyaltyAccount> = AustrianRepository.loyaltyAccount

    fun checkInTrip(tripId: String) {
        AustrianRepository.checkInTrip(tripId)
    }

    fun changeTripSeat(tripId: String, seat: String) {
        AustrianRepository.updateSeat(tripId, seat)
    }

    fun cancelTrip(tripId: String) {
        AustrianRepository.cancelTrip(tripId)
    }

    // Flight Status query
    private val _statusFlightNumber = MutableStateFlow("OS 571")
    val statusFlightNumber: StateFlow<String> = _statusFlightNumber.asStateFlow()

    private val _currentFlightStatus = MutableStateFlow(AustrianRepository.getFlightStatus("OS 571"))
    val currentFlightStatus: StateFlow<FlightStatus> = _currentFlightStatus.asStateFlow()

    fun queryFlightStatus(flightNum: String) {
        _statusFlightNumber.value = flightNum
        _currentFlightStatus.value = AustrianRepository.getFlightStatus(flightNum)
    }

    fun getDestinations(): List<Destination> = AustrianRepository.getDestinations()
}
