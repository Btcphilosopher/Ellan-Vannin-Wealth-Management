package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Trip
import com.example.ui.theme.*

@Composable
fun BoardingPassScreen(
    trip: Trip,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { onBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(text = "Digital Boarding Pass", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(modifier = Modifier.width(48.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AUSTRIAN AIRLINES",
                        color = AustrianRed,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Surface(
                        color = StatusGreen.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "BOARDING PASS",
                            color = StatusGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "PASSENGER", fontSize = 10.sp, color = TextSecondary)
                        Text(text = trip.passengerNames.firstOrNull() ?: "Maximilian Weber", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "BOOKING REF", fontSize = 10.sp, color = TextSecondary)
                        Text(text = trip.bookingRef, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = AustrianRed)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                Divider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "FROM", fontSize = 10.sp, color = TextSecondary)
                        Text(text = trip.flight.origin, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text(text = trip.flight.originCity, fontSize = 12.sp, color = TextSecondary)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = trip.flight.flightNumber, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AustrianRed)
                        Icon(imageVector = Icons.Default.Flight, contentDescription = "Flight", tint = AustrianRed, modifier = Modifier.size(24.dp))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "TO", fontSize = 10.sp, color = TextSecondary)
                        Text(text = trip.flight.destination, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text(text = trip.flight.destinationCity, fontSize = 12.sp, color = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "BOARDING TIME", fontSize = 10.sp, color = TextSecondary)
                        Text(text = trip.boardingTime, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "GATE", fontSize = 10.sp, color = TextSecondary)
                        Text(text = trip.gate, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "SEAT", fontSize = 10.sp, color = TextSecondary)
                        Text(text = trip.seatNumber, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = AustrianRed)
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Barcode representation
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .background(Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.QrCode2, contentDescription = "QR Code", modifier = Modifier.size(56.dp), tint = TextPrimary)
                        Text(text = trip.qrCodeData, fontSize = 9.sp, color = TextSecondary)
                    }
                }
            }
        }
    }
}
