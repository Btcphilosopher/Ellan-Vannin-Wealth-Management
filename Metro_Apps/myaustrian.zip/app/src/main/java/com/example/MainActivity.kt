package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.screens.MainScreen
import com.example.ui.theme.MyAustrianTheme
import com.example.viewmodel.AustrianViewModel

class MainActivity : ComponentActivity() {
  private val viewModel: AustrianViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyAustrianTheme {
        MainScreen(viewModel = viewModel)
      }
    }
  }
}
