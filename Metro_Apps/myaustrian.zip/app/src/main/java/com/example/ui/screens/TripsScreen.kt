package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Trip
import com.example.ui.theme.*

@Composable
fun TripsScreen(
    trips: List<Trip>,
    onCheckInClick: (String) -> Unit,
    onBoardingPassClick: (Trip) -> Unit,
    onCancelTrip: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .padding(bottom = 80.dp)
    ) {
        Text(
            text = "Meine Reisen",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "Your upcoming journeys and boarding passes",
            fontSize = 13.sp,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (trips.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.FlightLand,
                        contentDescription = "No trips",
                        tint = TextSecondary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "No upcoming trips booked", color = TextSecondary, fontSize = 16.sp)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(trips) { trip ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = AustrianRed.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Flight,
                                            contentDescription = "Flight",
                                            tint = AustrianRed,
                                            modifier = Modifier.padding(8.dp).size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "${trip.flight.flightNumber} • ${trip.flight.date}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Text(
                                            text = "Booking Ref: ${trip.bookingRef}",
                                            fontSize = 12.sp,
                                            color = TextSecondary
                                        )
                                    }
                                }

                                Surface(
                                    color = if (trip.isCheckedIn) StatusGreen.copy(alpha = 0.1f) else StatusOrange.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Text(
                                        text = if (trip.isCheckedIn) "Checked-In" else "Check-in Available",
                                        color = if (trip.isCheckedIn) StatusGreen else StatusOrange,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = trip.flight.origin, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text(text = trip.flight.departureTime, fontSize = 13.sp, color = TextSecondary)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = trip.flight.duration, fontSize = 11.sp, color = TextSecondary)
                                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "To", tint = AustrianRed, modifier = Modifier.size(16.dp))
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = trip.flight.destination, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text(text = trip.flight.arrivalTime, fontSize = 13.sp, color = TextSecondary)
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "Seat: ${trip.seatNumber}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    Text(text = "Gate: ${trip.gate}", fontSize = 12.sp, color = TextSecondary)
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (!trip.isCheckedIn) {
                                        Button(
                                            onClick = { onCheckInClick(trip.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = AustrianRed),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Check-In", fontSize = 12.sp)
                                        }
                                    } else {
                                        Button(
                                            onClick = { onBoardingPassClick(trip) },
                                            colors = ButtonDefaults.buttonColors(containerColor = AustrianBurgundy),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.QrCode, contentDescription = "Pass", modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Boarding Pass", fontSize = 12.sp)
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = { onCancelTrip(trip.id) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Cancel", tint = StatusRed, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
