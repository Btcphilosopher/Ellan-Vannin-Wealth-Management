package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FareFamily
import com.example.model.Flight
import com.example.ui.theme.*

@Composable
fun BookingWizardScreen(
    flight: Flight,
    step: Int,
    selectedFare: FareFamily?,
    firstName: String,
    lastName: String,
    email: String,
    selectedSeat: String,
    baggageCount: Int,
    confirmedBookingRef: String,
    onSelectFare: (FareFamily) -> Unit,
    onUpdatePassenger: (String, String, String) -> Unit,
    onUpdateSeat: (String) -> Unit,
    onUpdateBaggage: (Int) -> Unit,
    onNextStep: () -> Unit,
    onPrevStep: () -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(scrollState)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { if (step > 1 && step < 6) onPrevStep() else onDismiss() }) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
            }
            Text(
                text = when(step) {
                    1 -> "Step 1: Select Fare"
                    2 -> "Step 2: Passenger"
                    3 -> "Step 3: Extras"
                    4 -> "Step 4: Review"
                    5 -> "Step 5: Secure Payment"
                    else -> "Booking Confirmed"
                },
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Text(
                text = "$step/5",
                color = TextSecondary,
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Flight Summary Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.Flight, contentDescription = "Flight", tint = AustrianRed)
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "${flight.flightNumber} • ${flight.origin} -> ${flight.destination}", fontWeight = FontWeight.Bold)
                    Text(text = "${flight.date} at ${flight.departureTime}", fontSize = 12.sp, color = TextSecondary)
                }
                Text(text = "€${flight.basePrice.toInt()}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = AustrianRed)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (step) {
            1 -> {
                // Fare Families
                Text(text = "Choose your travel experience", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(modifier = Modifier.height(8.dp))

                flight.fareFamilies.forEach { fare ->
                    val isSelected = selectedFare?.name == fare.name
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clickable { onSelectFare(fare) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) AustrianRed.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (isSelected) BorderStroke(2.dp, AustrianRed) else null
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = fare.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(
                                    text = "+ €${fare.priceExtra.toInt()}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = AustrianRed
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "• Carry-on: ${fare.carryOn}", fontSize = 12.sp, color = TextSecondary)
                            Text(text = "• Checked Baggage: ${fare.checkedBaggage}", fontSize = 12.sp, color = TextSecondary)
                            Text(text = "• Seat Selection: ${fare.seatSelection}", fontSize = 12.sp, color = TextSecondary)
                            Text(text = "• Changeable: ${if (fare.changeable) "Yes" else "No"}", fontSize = 12.sp, color = TextSecondary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = { onNextStep() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AustrianRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Continue to Passenger Details")
                }
            }
            2 -> {
                // Passenger Details
                var first by remember { mutableStateOf(firstName) }
                var last by remember { mutableStateOf(lastName) }
                var mail by remember { mutableStateOf(email) }

                Text(text = "Passenger Information", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = first,
                    onValueChange = { first = it; onUpdatePassenger(first, last, mail) },
                    label = { Text("First Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = last,
                    onValueChange = { last = it; onUpdatePassenger(first, last, mail) },
                    label = { Text("Last Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = mail,
                    onValueChange = { mail = it; onUpdatePassenger(first, last, mail) },
                    label = { Text("Email Address") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { onNextStep() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AustrianRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Continue to Extras & Seats")
                }
            }
            3 -> {
                // Extras & Seats
                Text(text = "Seat & Baggage Selection", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = selectedSeat,
                    onValueChange = { onUpdateSeat(it) },
                    label = { Text("Preferred Seat (e.g. 12A)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))
                Text(text = "Checked Bags (23kg each)", fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(0, 1, 2).forEach { count ->
                        OutlinedButton(
                            onClick = { onUpdateBaggage(count) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (baggageCount == count) AustrianRed.copy(alpha = 0.1f) else Color.Transparent
                            )
                        ) {
                            Text("$count Bags")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { onNextStep() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AustrianRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Review Booking")
                }
            }
            4 -> {
                // Review
                val total = flight.basePrice + (selectedFare?.priceExtra ?: 0.0)
                Text(text = "Review Your Booking", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(modifier = Modifier.height(12.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Flight: ${flight.flightNumber} (${flight.origin} -> ${flight.destination})", fontWeight = FontWeight.Bold)
                        Text("Fare: ${selectedFare?.name ?: "Economy"}")
                        Text("Passenger: $firstName $lastName")
                        Text("Seat: $selectedSeat | Baggage: $baggageCount piece(s)")
                        Spacer(modifier = Modifier.height(12.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Amount", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("€${total.toInt()}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = AustrianRed)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { onNextStep() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AustrianRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Proceed to Secure Payment")
                }
            }
            5 -> {
                // Payment
                Text(text = "Secure Payment", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(text = "Encrypted 256-bit SSL transaction", fontSize = 12.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = "4000 1234 5678 9010",
                    onValueChange = {},
                    label = { Text("Card Number") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = "10/28", onValueChange = {}, label = { Text("MM/YY") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = "888", onValueChange = {}, label = { Text("CVV") }, modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { onConfirm() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AustrianRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = "Secure")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Complete Secure Payment")
                }
            }
            6 -> {
                // Success
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Surface(
                        shape = RoundedCornerShape(50.dp),
                        color = StatusGreen.copy(alpha = 0.1f),
                        modifier = Modifier.size(80.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Success", tint = StatusGreen, modifier = Modifier.size(48.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "Booking Confirmed!", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Booking Reference: $confirmedBookingRef", fontSize = 16.sp, color = AustrianRed, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Your itinerary and boarding pass have been saved to 'Meine Reisen'.", fontSize = 13.sp, color = TextSecondary)

                    Spacer(modifier = Modifier.height(32.dp))
                    Button(
                        onClick = { onDismiss() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = AustrianRed),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("View My Trips")
                    }
                }
            }
        }
    }
}
