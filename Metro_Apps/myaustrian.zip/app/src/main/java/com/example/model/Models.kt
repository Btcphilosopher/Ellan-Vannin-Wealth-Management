package com.example.model

import java.io.Serializable

data class Flight(
    val id: String,
    val flightNumber: String, // e.g. OS 571
    val origin: String, // e.g. VIE
    val destination: String, // e.g. FRA
    val originCity: String, // Vienna
    val destinationCity: String, // Frankfurt
    val departureTime: String, // 07:15
    val arrivalTime: String, // 08:45
    val date: String, // 2026-10-25
    val duration: String, // 1h 30m
    val basePrice: Double, // 149.00
    val currency: String = "EUR",
    val stops: Int = 0,
    val aircraft: String = "Airbus A320",
    val fareFamilies: List<FareFamily>
) : Serializable

data class FareFamily(
    val name: String, // Light, Classic, Flex, Business
    val priceExtra: Double, // 0.0, 45.0, 110.0, 280.0
    val carryOn: String, // 1 piece (8kg)
    val checkedBaggage: String, // 0 pieces, 1x23kg, 2x23kg, 2x32kg
    val seatSelection: String, // Fee applies, Free standard, Free preferred, Free front
    val changeable: Boolean, // false, with fee, free, free
    val refundable: Boolean // false, false, with fee, fully refundable
) : Serializable

data class Passenger(
    val firstName: String,
    val lastName: String,
    val title: String, // Mr, Ms, Dr
    val dateOfBirth: String,
    val passportNumber: String,
    val frequentFlyerNumber: String? = null
) : Serializable

data class Booking(
    val bookingRef: String, // e.g. OS8492
    val flight: Flight,
    val passengers: List<Passenger>,
    val selectedFare: FareFamily,
    val seatNumber: String, // e.g. 14A
    val baggageCount: Int,
    val status: String, // Confirmed, Checked-In, Boarded, Cancelled
    val paymentStatus: String, // Paid
    val bookingDate: String,
    val totalAmount: Double
) : Serializable

data class Trip(
    val id: String,
    val bookingRef: String,
    val flight: Flight,
    val passengerNames: List<String>,
    val seatNumber: String,
    val gate: String,
    val terminal: String,
    val boardingTime: String,
    val isCheckedIn: Boolean,
    val isBoardingPassReady: Boolean,
    val qrCodeData: String
) : Serializable

data class FlightStatus(
    val flightNumber: String,
    val route: String,
    val status: String, // Scheduled, Boarding, Departed, Delayed, Cancelled, Arrived
    val scheduledDeparture: String,
    val estimatedDeparture: String,
    val scheduledArrival: String,
    val estimatedArrival: String,
    val gate: String,
    val terminal: String,
    val freshness: String // Just now, 5 mins ago
) : Serializable

data class LoyaltyActivity(
    val description: String,
    val date: String,
    val miles: Int,
    val type: String // earned, redeemed
) : Serializable

data class LoyaltyAccount(
    val memberName: String,
    val tier: String, // Senator, Frequent Traveller, HON Circle
    val tierNumber: String,
    val milesBalance: Int,
    val qualifyingPoints: Int,
    val recentActivity: List<LoyaltyActivity>
) : Serializable

data class Destination(
    val id: String,
    val city: String,
    val country: String,
    val description: String,
    val priceFrom: Double,
    val imageUrl: String
) : Serializable
