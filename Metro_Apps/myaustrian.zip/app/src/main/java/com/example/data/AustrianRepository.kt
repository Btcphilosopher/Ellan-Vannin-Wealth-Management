package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

object AustrianRepository {

    private val sampleFareFamilies = listOf(
        FareFamily(
            name = "Economy Light",
            priceExtra = 0.0,
            carryOn = "1 piece (max. 8kg)",
            checkedBaggage = "0 pieces",
            seatSelection = "Fee applies at check-in",
            changeable = false,
            refundable = false
        ),
        FareFamily(
            name = "Economy Classic",
            priceExtra = 45.0,
            carryOn = "1 piece (max. 8kg)",
            checkedBaggage = "1 piece (max. 23kg)",
            seatSelection = "Free standard seat selection",
            changeable = true,
            refundable = false
        ),
        FareFamily(
            name = "Economy Flex",
            priceExtra = 110.0,
            carryOn = "1 piece (max. 8kg)",
            checkedBaggage = "1 piece (max. 23kg)",
            seatSelection = "Free preferred seat selection",
            changeable = true,
            refundable = true
        ),
        FareFamily(
            name = "Business",
            priceExtra = 260.0,
            carryOn = "2 pieces (max. 8kg each)",
            checkedBaggage = "2 pieces (max. 32kg each)",
            seatSelection = "Free front seat selection",
            changeable = true,
            refundable = true
        )
    )

    private val initialFlights = listOf(
        Flight(
            id = "f1",
            flightNumber = "OS 571",
            origin = "VIE",
            destination = "FRA",
            originCity = "Vienna",
            destinationCity = "Frankfurt",
            departureTime = "07:15",
            arrivalTime = "08:45",
            date = "2026-10-25",
            duration = "1h 30m",
            basePrice = 149.0,
            stops = 0,
            aircraft = "Airbus A320neo",
            fareFamilies = sampleFareFamilies
        ),
        Flight(
            id = "f2",
            flightNumber = "OS 311",
            origin = "VIE",
            destination = "LHR",
            originCity = "Vienna",
            destinationCity = "London Heathrow",
            departureTime = "10:20",
            arrivalTime = "11:50",
            date = "2026-10-25",
            duration = "2h 30m",
            basePrice = 189.0,
            stops = 0,
            aircraft = "Airbus A321",
            fareFamilies = sampleFareFamilies
        ),
        Flight(
            id = "f3",
            flightNumber = "OS 451",
            origin = "VIE",
            destination = "CDG",
            originCity = "Vienna",
            destinationCity = "Paris Charles de Gaulle",
            departureTime = "14:10",
            arrivalTime = "16:20",
            date = "2026-10-25",
            duration = "2h 10m",
            basePrice = 165.0,
            stops = 0,
            aircraft = "Airbus A320",
            fareFamilies = sampleFareFamilies
        ),
        Flight(
            id = "f4",
            flightNumber = "OS 087",
            origin = "VIE",
            destination = "JFK",
            originCity = "Vienna",
            destinationCity = "New York JFK",
            departureTime = "10:45",
            arrivalTime = "14:15",
            date = "2026-10-26",
            duration = "9h 30m",
            basePrice = 649.0,
            stops = 0,
            aircraft = "Boeing 777-200ER",
            fareFamilies = sampleFareFamilies
        ),
        Flight(
            id = "f5",
            flightNumber = "OS 561",
            origin = "VIE",
            destination = "ZRH",
            originCity = "Vienna",
            destinationCity = "Zurich",
            departureTime = "08:00",
            arrivalTime = "09:20",
            date = "2026-10-25",
            duration = "1h 20m",
            basePrice = 135.0,
            stops = 0,
            aircraft = "Embraer E195",
            fareFamilies = sampleFareFamilies
        )
    )

    private val initialBookings = mutableListOf(
        Booking(
            bookingRef = "OS8492",
            flight = initialFlights[0],
            passengers = listOf(Passenger("Maximilian", "Weber", "Mr", "1988-04-12", "P98765432", "OS-9928173")),
            selectedFare = sampleFareFamilies[1], // Classic
            seatNumber = "12A",
            baggageCount = 1,
            status = "Confirmed",
            paymentStatus = "Paid",
            bookingDate = "2026-10-10",
            totalAmount = 194.0
        )
    )

    private val initialTrips = mutableListOf(
        Trip(
            id = "t1",
            bookingRef = "OS8492",
            flight = initialFlights[0],
            passengerNames = listOf("Maximilian Weber"),
            seatNumber = "12A",
            gate = "B32",
            terminal = "3",
            boardingTime = "06:35",
            isCheckedIn = true,
            isBoardingPassReady = true,
            qrCodeData = "M1WEBER/MAXIMILIANOS8492 VIEFRAOS 20261025 0571 12A"
        )
    )

    private val destinationsList = listOf(
        Destination(
            id = "d1",
            city = "Vienna",
            country = "Austria",
            description = "Immerse yourself in imperial palaces, cozy coffee houses and world-class classical music.",
            priceFrom = 89.0,
            imageUrl = "vienna"
        ),
        Destination(
            id = "d2",
            city = "Mallorca",
            country = "Spain",
            description = "Sun-drenched beaches, turquoise coves and charming Mediterranean architecture.",
            priceFrom = 119.0,
            imageUrl = "mallorca"
        ),
        Destination(
            id = "d3",
            city = "New York",
            country = "United States",
            description = "Experience the boundless energy of the Big Apple, iconic skyline and Broadway.",
            priceFrom = 599.0,
            imageUrl = "newyork"
        ),
        Destination(
            id = "d4",
            city = "Tokyo",
            country = "Japan",
            description = "A fascinating blend of ultramodern neon skyscrapers and historic ancient temples.",
            priceFrom = 780.0,
            imageUrl = "tokyo"
        )
    )

    private val _flights = MutableStateFlow(initialFlights)
    val flights: StateFlow<List<Flight>> = _flights.asStateFlow()

    private val _bookings = MutableStateFlow<List<Booking>>(initialBookings)
    val bookings: StateFlow<List<Booking>> = _bookings.asStateFlow()

    private val _trips = MutableStateFlow<List<Trip>>(initialTrips)
    val trips: StateFlow<List<Trip>> = _trips.asStateFlow()

    private val _loyaltyAccount = MutableStateFlow(
        LoyaltyAccount(
            memberName = "Maximilian Weber",
            tier = "Senator",
            tierNumber = "OS-9928173",
            milesBalance = 64850,
            qualifyingPoints = 480,
            recentActivity = listOf(
                LoyaltyActivity("Flight Vienna - Frankfurt (OS 571)", "2026-09-14", 1250, "earned"),
                LoyaltyActivity("Austrian Miles & More Credit Card Bonus", "2026-09-01", 5000, "earned"),
                LoyaltyActivity("Lounge Voucher Redemption", "2026-08-20", -3000, "redeemed")
            )
        )
    )
    val loyaltyAccount: StateFlow<LoyaltyAccount> = _loyaltyAccount.asStateFlow()

    fun searchFlights(origin: String, destination: String, date: String): List<Flight> {
        return initialFlights.filter {
            (origin.isBlank() || it.origin.equals(origin, ignoreCase = true) || it.originCity.equals(origin, ignoreCase = true)) &&
            (destination.isBlank() || it.destination.equals(destination, ignoreCase = true) || it.destinationCity.equals(destination, ignoreCase = true))
        }.ifEmpty { initialFlights }
    }

    fun addBooking(flight: Flight, passengers: List<Passenger>, fare: FareFamily, seat: String, baggage: Int): Booking {
        val ref = "OS" + (1000..9999).random()
        val total = flight.basePrice + fare.priceExtra
        val newBooking = Booking(
            bookingRef = ref,
            flight = flight,
            passengers = passengers,
            selectedFare = fare,
            seatNumber = seat,
            baggageCount = baggage,
            status = "Confirmed",
            paymentStatus = "Paid",
            bookingDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            totalAmount = total
        )
        _bookings.value = _bookings.value + newBooking

        val newTrip = Trip(
            id = "t_" + System.currentTimeMillis(),
            bookingRef = ref,
            flight = flight,
            passengerNames = passengers.map { "${it.firstName} ${it.lastName}" },
            seatNumber = seat,
            gate = "C12",
            terminal = "3",
            boardingTime = "06:30",
            isCheckedIn = false,
            isBoardingPassReady = false,
            qrCodeData = "M1${passengers.firstOrNull()?.lastName?.uppercase()}/${passengers.firstOrNull()?.firstName?.uppercase()}$ref ${flight.origin}${flight.destination}OS ${flight.flightNumber.replace(" ", "")}"
        )
        _trips.value = _trips.value + newTrip
        return newBooking
    }

    fun checkInTrip(tripId: String): Boolean {
        val currentTrips = _trips.value.toMutableList()
        val index = currentTrips.indexOfFirst { it.id == tripId }
        if (index != -1) {
            val t = currentTrips[index]
            currentTrips[index] = t.copy(isCheckedIn = true, isBoardingPassReady = true)
            _trips.value = currentTrips
            return true
        }
        return false
    }

    fun updateSeat(tripId: String, newSeat: String): Boolean {
        val currentTrips = _trips.value.toMutableList()
        val index = currentTrips.indexOfFirst { it.id == tripId }
        if (index != -1) {
            val t = currentTrips[index]
            currentTrips[index] = t.copy(seatNumber = newSeat)
            _trips.value = currentTrips
            return true
        }
        return false
    }

    fun cancelTrip(tripId: String) {
        _trips.value = _trips.value.filter { it.id != tripId }
    }

    fun getDestinations(): List<Destination> = destinationsList

    fun getFlightStatus(flightNumber: String): FlightStatus {
        val flight = initialFlights.find { it.flightNumber.equals(flightNumber, ignoreCase = true) }
            ?: initialFlights.first()
        return FlightStatus(
            flightNumber = flight.flightNumber,
            route = "${flight.originCity} (${flight.origin}) -> ${flight.destinationCity} (${flight.destination})",
            status = "On Time",
            scheduledDeparture = flight.departureTime,
            estimatedDeparture = flight.departureTime,
            scheduledArrival = flight.arrivalTime,
            estimatedArrival = flight.arrivalTime,
            gate = "B32",
            terminal = "Terminal 3",
            freshness = "Updated just now"
        )
    }
}
