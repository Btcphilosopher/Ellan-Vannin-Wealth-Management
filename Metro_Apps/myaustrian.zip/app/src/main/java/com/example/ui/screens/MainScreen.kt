package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.Trip
import com.example.ui.theme.*
import com.example.viewmodel.AustrianViewModel

sealed class NavigationItem(val title: String, val icon: ImageVector) {
    object Start : NavigationItem("Start", Icons.Default.Home)
    object Buchen : NavigationItem("Buchen", Icons.Default.FlightTakeoff)
    object Trips : NavigationItem("Meine Reisen", Icons.Default.Luggage)
    object Status : NavigationItem("Status", Icons.Default.Radar)
    object Profile : NavigationItem("Profil", Icons.Default.Person)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: AustrianViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val searchOrigin by viewModel.searchOrigin.collectAsStateWithLifecycle()
    val searchDestination by viewModel.searchDestination.collectAsStateWithLifecycle()
    val searchDate by viewModel.searchDate.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()

    val isBookingActive by viewModel.isBookingActive.collectAsStateWithLifecycle()
    val bookingStep by viewModel.bookingStep.collectAsStateWithLifecycle()
    val selectedFlightForBooking by viewModel.selectedFlightForBooking.collectAsStateWithLifecycle()
    val selectedFare by viewModel.selectedFare.collectAsStateWithLifecycle()
    val firstName by viewModel.passengerFirstName.collectAsStateWithLifecycle()
    val lastName by viewModel.passengerLastName.collectAsStateWithLifecycle()
    val email by viewModel.passengerEmail.collectAsStateWithLifecycle()
    val selectedSeat by viewModel.selectedSeat.collectAsStateWithLifecycle()
    val baggageCount by viewModel.baggageCount.collectAsStateWithLifecycle()
    val confirmedBookingRef by viewModel.confirmedBookingRef.collectAsStateWithLifecycle()

    val trips by viewModel.trips.collectAsStateWithLifecycle()
    val loyaltyAccount by viewModel.loyaltyAccount.collectAsStateWithLifecycle()
    val flightStatus by viewModel.currentFlightStatus.collectAsStateWithLifecycle()
    val statusFlightNumber by viewModel.statusFlightNumber.collectAsStateWithLifecycle()

    var activeBoardingPassTrip by remember { mutableStateOf<Trip?>(null) }

    val items = listOf(
        NavigationItem.Start,
        NavigationItem.Buchen,
        NavigationItem.Trips,
        NavigationItem.Status,
        NavigationItem.Profile
    )

    Scaffold(
        bottomBar = {
            if (!isBookingActive && activeBoardingPassTrip == null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = AustrianRed
                ) {
                    items.forEachIndexed { index, item ->
                        NavigationBarItem(
                            icon = { Icon(item.icon, contentDescription = item.title) },
                            label = { Text(item.title) },
                            selected = currentTab == index,
                            onClick = { viewModel.setTab(index) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AustrianRed,
                                selectedTextColor = AustrianRed,
                                indicatorColor = AustrianRed.copy(alpha = 0.12f)
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            if (activeBoardingPassTrip != null) {
                BoardingPassScreen(
                    trip = activeBoardingPassTrip!!,
                    onBack = { activeBoardingPassTrip = null }
                )
            } else if (isBookingActive && selectedFlightForBooking != null) {
                BookingWizardScreen(
                    flight = selectedFlightForBooking!!,
                    step = bookingStep,
                    selectedFare = selectedFare,
                    firstName = firstName,
                    lastName = lastName,
                    email = email,
                    selectedSeat = selectedSeat,
                    baggageCount = baggageCount,
                    confirmedBookingRef = confirmedBookingRef,
                    onSelectFare = { viewModel.selectFare(it) },
                    onUpdatePassenger = { f, l, e -> viewModel.updatePassengerDetails(f, l, e) },
                    onUpdateSeat = { viewModel.updateSeat(it) },
                    onUpdateBaggage = { viewModel.updateBaggage(it) },
                    onNextStep = { viewModel.setBookingStep(bookingStep + 1) },
                    onPrevStep = { viewModel.setBookingStep(bookingStep - 1) },
                    onConfirm = { viewModel.confirmBooking() },
                    onDismiss = { viewModel.cancelBookingWizard() }
                )
            } else {
                when (currentTab) {
                    0 -> StartScreen(
                        trips = trips,
                        destinations = viewModel.getDestinations(),
                        onSearchClick = { viewModel.setTab(1) },
                        onTripClick = { activeBoardingPassTrip = it },
                        onBoardingPassClick = { activeBoardingPassTrip = it },
                        onDestinationClick = { dest ->
                            viewModel.updateSearch("VIE", dest.city.take(3).uppercase(), "2026-10-25")
                            viewModel.setTab(1)
                        }
                    )
                    1 -> SearchScreen(
                        origin = searchOrigin,
                        destination = searchDestination,
                        date = searchDate,
                        flights = searchResults,
                        onSearchChange = { o, d, dt -> viewModel.updateSearch(o, d, dt) },
                        onSelectFlight = { flight -> viewModel.startBooking(flight) }
                    )
                    2 -> TripsScreen(
                        trips = trips,
                        onCheckInClick = { tripId -> viewModel.checkInTrip(tripId) },
                        onBoardingPassClick = { trip -> activeBoardingPassTrip = trip },
                        onCancelTrip = { tripId -> viewModel.cancelTrip(tripId) }
                    )
                    3 -> StatusScreen(
                        flightNumber = statusFlightNumber,
                        flightStatus = flightStatus,
                        onQueryFlight = { viewModel.queryFlightStatus(it) }
                    )
                    4 -> ProfileScreen(
                        loyaltyAccount = loyaltyAccount
                    )
                }
            }
        }
    }
}
