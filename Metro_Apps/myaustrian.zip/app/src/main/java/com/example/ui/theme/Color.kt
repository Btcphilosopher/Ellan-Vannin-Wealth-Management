package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AustrianRed = Color(0xFFE30613)
val AustrianRedDark = Color(0xFFB3040E)
val AustrianBurgundy = Color(0xFF5C061C)
val AustrianGold = Color(0xFFC5A059)

val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF7F7F9)
val SurfaceDark = Color(0xFF141416)
val BackgroundDark = Color(0xFF0B0B0D)

val TextPrimary = Color(0xFF1C1B1F)
val TextSecondary = Color(0xFF59595E)
val TextPrimaryDark = Color(0xFFE6E6EA)
val TextSecondaryDark = Color(0xFF9E9EA4)

val StatusGreen = Color(0xFF2E7D32)
val StatusOrange = Color(0xFFD97706)
val StatusRed = Color(0xFFDC2626)
