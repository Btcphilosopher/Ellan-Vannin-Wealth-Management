package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DirectionsTransit
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.state.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TripsView(
    viewModel: MetroViewModel
) {
    val activeTrip by viewModel.activeTrip.collectAsState()
    val activeStepIdx by viewModel.activeTripStepIndex.collectAsState()
    val alertText by viewModel.activeTripAlert.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AucklandGreyLight)
    ) {
        // --- TOP HEADER ---
        TopAppBar(
            title = {
                Column {
                    Text(
                        "TRIP ASSISTANT",
                        style = MaterialTheme.typography.labelLarge,
                        color = AucklandBlue,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        if (activeTrip != null) "Active Commute Conductor" else "Your Trips",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = AucklandNavy)
        )

        if (activeTrip == null) {
            // --- EMPTY TRIP STATE WITH QUICK DEMO LAUNCHER ---
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.DirectionsTransit,
                            contentDescription = null,
                            tint = AucklandGreyMuted,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No active journey in progress",
                            style = MaterialTheme.typography.titleMedium,
                            color = AucklandNavy,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "When you plan a journey and tap 'Start Journey', this screen transforms into a real-time smart conductor guiding you step-by-step.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AucklandGreyMuted,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                viewModel.updateFromQuery("Britomart")
                                viewModel.updateToQuery("Auckland Airport")
                                viewModel.planJourney()
                                viewModel.startJourney()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("demo_airport_trip_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = AucklandBlue),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                "DEMO AIRPORT TRIP",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // --- COMPLETED RECENT TRIP LIST ---
                Text(
                    text = "RECENT COMPLETED JOURNEYS",
                    style = MaterialTheme.typography.labelLarge,
                    color = AucklandNavy.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val completedPresets = listOf(
                        Triple("Britomart to Newmarket", "3 stops • 12 mins • Train", "$2.50"),
                        Triple("Takapuna to Downtown", "Busway • 18 mins • Bus", "$3.60"),
                        Triple("Devonport to Britomart", "Sailing • 12 mins • Ferry", "$3.60")
                    )
                    items(completedPresets) { (route, details, price) ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.CheckCircle,
                                    contentDescription = null,
                                    tint = AucklandGreen,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = route,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = AucklandNavy,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = details,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = AucklandGreyMuted
                                    )
                                }
                                Text(
                                    text = price,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = AucklandNavy,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        } else {
            val trip = activeTrip!!
            val steps = trip.steps

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // --- ON-TIME HEADER STATUS ---
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = AucklandGreen),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "YOU'RE ON TIME",
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Arriving at ${trip.arrivalTime} • ${trip.totalDuration} mins remaining",
                                    color = Color.White.copy(alpha = 0.9f),
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }

                // --- CALM CONDUCTOR ALERTS PANEL (Section 12) ---
                if (alertText != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = AucklandNavyLight),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.NotificationsActive,
                                    contentDescription = "Alert",
                                    tint = AucklandBlue,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "CONDUCATOR ASSISTANCE",
                                        color = AucklandBlue,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                    Text(
                                        text = alertText!!,
                                        color = Color.White,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // --- VERTICAL PROGRESS STEAMER / TIMELINE ---
                item {
                    Text(
                        text = "COMMUTE ROADMAP",
                        style = MaterialTheme.typography.labelLarge,
                        color = AucklandNavy.copy(alpha = 0.5f),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }

                items(steps.size) { idx ->
                    val step = steps[idx]
                    val isCurrent = idx == activeStepIdx
                    val isCompleted = idx < activeStepIdx
                    val isFuture = idx > activeStepIdx

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (isCurrent) Color.White else Color.Transparent,
                                RoundedCornerShape(4.dp)
                            )
                            .border(
                                width = if (isCurrent) 1.5.dp else 0.dp,
                                color = if (isCurrent) AucklandBlue else Color.Transparent,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Timeline Indicator Bubble
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isCompleted -> AucklandGreen
                                        isCurrent -> AucklandBlue
                                        else -> AucklandGreyMuted.copy(alpha = 0.3f)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCompleted) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Done",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else {
                                Text(
                                    text = "${idx + 1}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isCurrent) Color.White else AucklandNavy.copy(alpha = 0.5f),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Step description
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = step.lineName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isFuture) AucklandNavy.copy(alpha = 0.4f) else AucklandNavy
                                )
                                if (step.platformOrTerminal.isNotBlank()) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (isFuture) AucklandGreyMuted.copy(alpha = 0.3f) else AucklandNavyLight,
                                                RoundedCornerShape(3.dp)
                                            )
                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = step.platformOrTerminal,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (isFuture) AucklandNavy.copy(alpha = 0.4f) else Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "${step.fromStation} → ${step.toStation}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isFuture) AucklandNavy.copy(alpha = 0.4f) else AucklandNavy,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${step.departureTime} - ${step.arrivalTime} • ${step.durationMinutes} mins",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isFuture) AucklandGreyMuted.copy(alpha = 0.4f) else AucklandGreyMuted
                            )
                        }

                        // Mode icon
                        Icon(
                            imageVector = getStepIcon(step.type),
                            contentDescription = null,
                            tint = if (isFuture) AucklandGreyMuted.copy(alpha = 0.3f) else getStepColor(step.type),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // --- STEP PROGRESS BACK/NEXT AND TRIP CANCEL CTAS ---
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (activeStepIdx > 0) {
                            OutlinedButton(
                                onClick = { viewModel.prevTripStep() },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp),
                                shape = RoundedCornerShape(4.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = AucklandNavy),
                                border = BorderStroke(1.dp, AucklandGreyMuted.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    "PREV STEP",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Button(
                            onClick = { viewModel.nextTripStep() },
                            modifier = Modifier
                                .weight(if (activeStepIdx > 0) 1.5f else 1f)
                                .height(52.dp)
                                .testTag("next_step_button"),
                            shape = RoundedCornerShape(4.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeStepIdx == steps.size - 1) AucklandGreen else AucklandNavy
                            )
                        ) {
                            Text(
                                if (activeStepIdx == steps.size - 1) "COMPLETE JOURNEY" else "NEXT STEP / ARRIVED",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    TextButton(
                        onClick = { viewModel.cancelActiveTrip() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text(
                            "CANCEL COMMUTE TRACKING",
                            style = MaterialTheme.typography.labelLarge,
                            color = AucklandOrange,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }
}
