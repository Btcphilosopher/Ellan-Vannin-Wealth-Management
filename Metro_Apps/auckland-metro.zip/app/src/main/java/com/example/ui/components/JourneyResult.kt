package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.DirectionsBus
import androidx.compose.material.icons.outlined.DirectionsBoat
import androidx.compose.material.icons.outlined.DirectionsRun
import androidx.compose.material.icons.outlined.DirectionsTransit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.state.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyResultView(
    viewModel: MetroViewModel,
    onBack: () -> Unit
) {
    val options by viewModel.journeyOptions.collectAsState()
    val selectedOption by viewModel.selectedJourneyOption.collectAsState()
    val fromVal by viewModel.fromQuery.collectAsState()
    val toVal by viewModel.toQuery.collectAsState()

    val option = selectedOption ?: options.firstOrNull()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AucklandGreyLight)
    ) {
        // --- HEADER BAR ---
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = "JOURNEY PLANNER",
                        style = MaterialTheme.typography.labelLarge,
                        color = AucklandBlue,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "$fromVal → $toVal",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Outlined.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = AucklandNavy)
        )

        if (option == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No routes found. Please try another search.", color = AucklandNavy)
            }
            return
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp)
        ) {
            // --- 1. THE MAIN JOURNEY CARD ---
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(4.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // Header: Time & Price
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${option.totalDuration} min",
                                style = MaterialTheme.typography.displayMedium,
                                color = AucklandNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Leave ${option.departureTime} • Arrive ${option.arrivalTime}",
                                style = MaterialTheme.typography.bodyLarge,
                                color = AucklandNavy,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFFEF3C7), RoundedCornerShape(4.dp))
                                .border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(4.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "$${String.format("%.2f", option.cost)}",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color(0xFFD97706),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = AucklandGreyLight)
                    Spacer(modifier = Modifier.height(16.dp))

                    // Connection Steps
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        option.steps.forEachIndexed { index, step ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                // Transport Icon Circle
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(getStepColor(step.type))
                                        .border(2.dp, Color.White, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = getStepIcon(step.type),
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                // Step details
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = step.lineName,
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = AucklandNavy
                                        )
                                        if (step.platformOrTerminal.isNotBlank()) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(
                                                        AucklandNavyLight,
                                                        RoundedCornerShape(3.dp)
                                                    )
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = step.platformOrTerminal,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = "${step.fromStation} → ${step.toStation}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = AucklandNavy.copy(alpha = 0.8f),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${step.details} (${step.durationMinutes} min)",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = AucklandGreyMuted
                                    )
                                }
                            }

                            // Down arrow connection between steps
                            if (index < option.steps.size - 1) {
                                Row(
                                    modifier = Modifier
                                        .padding(start = 14.dp)
                                        .height(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(8.dp)
                                            .fillMaxHeight()
                                            .background(AucklandGreyMuted.copy(alpha = 0.4f))
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Start journey Button
                    Button(
                        onClick = { viewModel.startJourney() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("start_journey_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = AucklandBlue),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "START JOURNEY",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // --- 2. ALTERNATIVES SECTION ---
            Text(
                text = "TRANSIT ALTERNATIVES",
                style = MaterialTheme.typography.labelLarge,
                color = AucklandNavy.copy(alpha = 0.6f),
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                options.forEach { opt ->
                    val isSelected = opt.id == option.id
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.selectJourneyOption(opt) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) AucklandNavy else Color.White
                        ),
                        shape = RoundedCornerShape(4.dp),
                        border = if (!isSelected) BorderStroke(
                            1.dp,
                            AucklandGreyMuted.copy(alpha = 0.4f)
                        ) else null
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(10.dp)
                                .fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = opt.label.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) AucklandBlue else AucklandBlue,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${opt.totalDuration} min",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isSelected) Color.White else AucklandNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$${String.format("%.2f", opt.cost)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isSelected) Color.White.copy(alpha = 0.7f) else AucklandGreyMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

fun getStepColor(type: TransitType): Color = when (type) {
    TransitType.TRAIN -> AucklandBlue
    TransitType.BUS -> LineBus
    TransitType.FERRY -> HarbourBlue
    TransitType.WALK -> AucklandGreyMuted
}

fun getStepIcon(type: TransitType) = when (type) {
    TransitType.TRAIN -> Icons.Outlined.DirectionsTransit
    TransitType.BUS -> Icons.Outlined.DirectionsBus
    TransitType.FERRY -> Icons.Outlined.DirectionsBoat
    TransitType.WALK -> Icons.Outlined.DirectionsRun
}
