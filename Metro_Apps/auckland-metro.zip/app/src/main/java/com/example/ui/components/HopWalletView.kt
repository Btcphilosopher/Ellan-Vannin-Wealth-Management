package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.state.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HopWalletView(
    viewModel: MetroViewModel
) {
    val balance by viewModel.hopBalance.collectAsState()
    val showTopUp by viewModel.showTopUpDialog.collectAsState()

    var activeWalletTab by remember { mutableStateOf("hop") } // "hop" or "contactless"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AucklandGreyLight),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // --- TOP HEADER ---
        item {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "MY TRAVEL & PAYMENTS",
                            style = MaterialTheme.typography.labelLarge,
                            color = AucklandBlue,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            "AT HOP Wallet & Contactless",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AucklandNavy)
            )
        }

        // --- SUB MENU (HOP vs Contactless) ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(vertical = 12.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { activeWalletTab = "hop" },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (activeWalletTab == "hop") AucklandNavy else AucklandGreyLight
                    ),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Style,
                        contentDescription = null,
                        tint = if (activeWalletTab == "hop") Color.White else AucklandNavy,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "AT HOP CARD",
                        color = if (activeWalletTab == "hop") Color.White else AucklandNavy,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = { activeWalletTab = "contactless" },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (activeWalletTab == "contactless") AucklandNavy else AucklandGreyLight
                    ),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.CreditCard,
                        contentDescription = null,
                        tint = if (activeWalletTab == "contactless") Color.White else AucklandNavy,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "CONTACTLESS",
                        color = if (activeWalletTab == "contactless") Color.White else AucklandNavy,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }

        // --- AT HOP CARD RENDER ---
        if (activeWalletTab == "hop") {
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    // Digital AT HOP card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .border(1.dp, Color(0xFF1E3A8A).copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(AucklandNavy, AucklandNavyLight, AucklandBlue)
                                    )
                                )
                                .padding(20.dp)
                        ) {
                            // Top Row: Brand & Logo
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "AT HOP",
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.SansSerif
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Box(
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(3.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "AUCKLAND",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Middle: Live Balance
                            Column(
                                modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .padding(top = 10.dp)
                            ) {
                                Text(
                                    text = "CARD BALANCE",
                                    color = Color.White.copy(alpha = 0.6f),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "$${String.format("%.2f", balance)}",
                                    style = MaterialTheme.typography.displayMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.testTag("hop_balance_display")
                                )
                            }

                            // Bottom Row: Card Metadata
                            Row(
                                modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter),
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Column {
                                    Text(
                                        text = "CARD HOLDER",
                                        color = Color.White.copy(alpha = 0.6f),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                    Text(
                                        text = "Auckland Commuter",
                                        color = Color.White,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = "•••• 4812",
                                    color = Color.White.copy(alpha = 0.8f),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // TODAY TRAVEL SUMMARY
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Analytics,
                                contentDescription = null,
                                tint = AucklandBlue,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    "TODAY'S ACCUMULATED FARES",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AucklandGreyMuted,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "$8.60",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = AucklandNavy,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            Box(
                                modifier = Modifier
                                    .background(AucklandGreen.copy(alpha = 0.1f), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    "DAILY CAP: $20.00",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AucklandGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // --- CARD CONTROL PANEL / TOP UP ACTIONS (Section 10) ---
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(4.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "WALLET CONTROLS",
                                style = MaterialTheme.typography.labelLarge,
                                color = AucklandNavy.copy(alpha = 0.5f),
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = { viewModel.setShowTopUpDialog(true) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("top_up_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = AucklandNavy),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Icon(Icons.Default.Add, "Top Up")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "TOP UP BALANCE",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            // Dynamic Quick Top Up drawer inside the card!
                            AnimatedVisibility(visible = showTopUp) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 14.dp)
                                        .background(AucklandGreyLight, RoundedCornerShape(4.dp))
                                        .padding(12.dp)
                                ) {
                                    Text(
                                        "Select amount to instantly add to card:",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = AucklandNavy,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf(10.0, 20.0, 50.0).forEach { amount ->
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(Color.White)
                                                    .border(
                                                        1.dp,
                                                        AucklandNavy.copy(alpha = 0.2f),
                                                        RoundedCornerShape(4.dp)
                                                    )
                                                    .clickable {
                                                        viewModel.topUpBalance(amount)
                                                        viewModel.setShowTopUpDialog(false)
                                                    }
                                                    .padding(vertical = 12.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    "+$${amount.toInt()}",
                                                    color = AucklandNavy,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    TextButton(
                                        onClick = { viewModel.setShowTopUpDialog(false) },
                                        modifier = Modifier.align(Alignment.CenterHorizontally)
                                    ) {
                                        Text("Cancel", color = AucklandOrange, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedButton(
                                onClick = { },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = AucklandNavy),
                                border = BorderStroke(1.dp, AucklandGreyMuted.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Icon(Icons.Default.CreditCard, null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "ADD NEW HOP CARD",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // --- CONTACTLESS CARD VIEW ---
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    // Conceptual Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .border(1.dp, Color(0x33000000), RoundedCornerShape(8.dp)),
                        shape = RoundedCornerShape(8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(Color(0xFF374151), Color(0xFF1F2937), Color(0xFF111827))
                                    )
                                )
                                .padding(20.dp)
                        ) {
                            // Top Row: Brand & Wave logo
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Visa Platinum",
                                    color = Color.White.copy(alpha = 0.8f),
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = null,
                                    tint = AucklandBlue,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            // Middle: Ready to travel pulse
                            Row(
                                modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .background(AucklandGreen.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                    .border(1.dp, AucklandGreen, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(AucklandGreen)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "READY TO TRAVEL",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }

                            // Bottom Row: Card details
                            Row(
                                modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter),
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Column {
                                    Text(
                                        text = "CONTACTLESS COMMUTE",
                                        color = Color.White.copy(alpha = 0.6f),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                    Text(
                                        text = "Visa Debit Card",
                                        color = Color.White,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = "•••• 4281",
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Info box clarifying contactless is simulated
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Info,
                                contentDescription = null,
                                tint = AucklandBlue,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Contactless payment is fully supported across Auckland's trains, buses, and most ferry terminals. Simply tap on and off using your visual Visa/Mastercard on your phone or card.",
                                style = MaterialTheme.typography.labelLarge,
                                color = AucklandNavy.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }

        // --- RECENT TRAVEL HISTORY LIST ---
        item {
            Text(
                text = "RECENT TRAVEL LOGS",
                style = MaterialTheme.typography.labelLarge,
                color = AucklandNavy.copy(alpha = 0.5f),
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 8.dp)
            )
        }

        items(MetroData.RECENT_JOURNEYS) { tx ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(getStepColor(tx.type)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = getStepIcon(tx.type),
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${tx.fromStation} ↔ ${tx.toStation}",
                            color = AucklandNavy,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${tx.date} at ${tx.time} • Approved",
                            color = AucklandGreyMuted,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                    Text(
                        text = "-$${String.format("%.2f", tx.fare)}",
                        color = AucklandOrange,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
