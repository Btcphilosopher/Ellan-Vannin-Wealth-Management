package com.example.state

import androidx.lifecycle.ViewModel
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class MetroViewModel : ViewModel() {

    // --- NAVIGATION ---
    private val _currentTab = MutableStateFlow("home") // "home", "map", "departures", "trips", "account"
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    // Custom backstack/navigation modes
    private val _activeScreenState = MutableStateFlow("dashboard") // "dashboard", "results", "active_trip", "station_detail"
    val activeScreenState: StateFlow<String> = _activeScreenState.asStateFlow()

    fun setTab(tab: String) {
        _currentTab.value = tab
        // Reset specific states when changing tabs
        if (tab == "home" && _activeScreenState.value == "station_detail") {
            _activeScreenState.value = "dashboard"
        }
    }

    fun navigateToHome() {
        _currentTab.value = "home"
        _activeScreenState.value = "dashboard"
    }

    // --- JOURNEY PLANNER SEARCH ---
    private val _fromQuery = MutableStateFlow("Current location")
    val fromQuery: StateFlow<String> = _fromQuery.asStateFlow()

    private val _toQuery = MutableStateFlow("")
    val toQuery: StateFlow<String> = _toQuery.asStateFlow()

    // Smart Suggestion List
    private val _suggestions = MutableStateFlow<List<Pair<String, String>>>(emptyList()) // Pair(Name, SecondaryLabel)
    val suggestions: StateFlow<List<Pair<String, String>>> = _suggestions.asStateFlow()

    // Loaded Journey options for the searched query
    private val _journeyOptions = MutableStateFlow<List<JourneyOption>>(emptyList())
    val journeyOptions: StateFlow<List<JourneyOption>> = _journeyOptions.asStateFlow()

    private val _selectedJourneyOption = MutableStateFlow<JourneyOption?>(null)
    val selectedJourneyOption: StateFlow<JourneyOption?> = _selectedJourneyOption.asStateFlow()

    // --- LIVE DEPARTURES HUB ---
    private val _selectedDepartureStation = MutableStateFlow("britomart")
    val selectedDepartureStation: StateFlow<String> = _selectedDepartureStation.asStateFlow()

    // --- TRAVEL WALLET (AT HOP) ---
    private val _hopBalance = MutableStateFlow(42.80)
    val hopBalance: StateFlow<Double> = _hopBalance.asStateFlow()

    // Active Running Trip Progress
    private val _activeTrip = MutableStateFlow<JourneyOption?>(null)
    val activeTrip: StateFlow<JourneyOption?> = _activeTrip.asStateFlow()

    private val _activeTripStepIndex = MutableStateFlow(0)
    val activeTripStepIndex: StateFlow<Int> = _activeTripStepIndex.asStateFlow()

    // Active alert/alert text displayed on trip progress
    private val _activeTripAlert = MutableStateFlow<String?>("Welcome aboard. Tap 'Next' as you complete steps.")
    val activeTripAlert: StateFlow<String?> = _activeTripAlert.asStateFlow()

    fun updateFromQuery(query: String) {
        _fromQuery.value = query
        updateSuggestions(query, isFromField = true)
    }

    fun updateToQuery(query: String) {
        _toQuery.value = query
        updateSuggestions(query, isFromField = false)
    }

    private fun updateSuggestions(query: String, isFromField: Boolean) {
        if (query.isBlank() || query == "Current location") {
            _suggestions.value = emptyList()
            return
        }

        val lowercase = query.lowercase(Locale.ROOT)
        // Match our list of stations + landmarks
        val matches = mutableListOf<Pair<String, String>>()
        
        if (lowercase.contains("sky") || lowercase.contains("tow")) {
            matches.add("Sky Tower" to "Auckland CBD Landmark")
        }
        
        MetroData.STATIONS.forEach { station ->
            if (station.name.lowercase(Locale.ROOT).contains(lowercase) ||
                station.maoriName.lowercase(Locale.ROOT).contains(lowercase)
            ) {
                val typeDesc = when {
                    station.isFerry -> "Ferry Terminal"
                    station.isTrain && station.isBus -> "Transport Interchange"
                    station.isTrain -> "Train Station"
                    station.isBus -> "Bus Hub"
                    else -> "Transit Stop"
                }
                matches.add("${station.name} (${station.maoriName})" to typeDesc)
            }
        }
        
        _suggestions.value = matches.take(5)
    }

    fun selectSuggestion(selectedText: String, isFromField: Boolean) {
        // Strip Māori translation brackets if present for query fields to look clean
        val cleanName = if (selectedText.contains(" (")) {
            selectedText.substringBefore(" (")
        } else {
            selectedText
        }

        if (isFromField) {
            _fromQuery.value = cleanName
        } else {
            _toQuery.value = cleanName
        }
        _suggestions.value = emptyList()
    }

    fun selectSavedPreset(preset: SavedPreset) {
        val fromStation = MetroData.STATIONS.firstOrNull { it.id == preset.fromId }
        val toStation = MetroData.STATIONS.firstOrNull { it.id == preset.toId }
        
        _fromQuery.value = fromStation?.name ?: "Current location"
        _toQuery.value = toStation?.name ?: ""
        planJourney()
    }

    // Smart Dynamic Fare & Route Planner
    fun planJourney() {
        val fromNormalized = _fromQuery.value.lowercase(Locale.ROOT).trim()
        val toNormalized = _toQuery.value.lowercase(Locale.ROOT).trim()

        // Match preset journeys
        var foundPresets: List<JourneyOption>? = null

        if (fromNormalized.contains("britomart") || fromNormalized.contains("current")) {
            if (toNormalized.contains("airport") || toNormalized.contains("tomokanga")) {
                foundPresets = MetroData.PRESETS_JOURNEYS["britomart"]?.get("airport")
            } else if (toNormalized.contains("devonport")) {
                foundPresets = MetroData.PRESETS_JOURNEYS["britomart"]?.get("devonport")
            }
        } else if (fromNormalized.contains("devonport") && toNormalized.contains("britomart")) {
            foundPresets = MetroData.PRESETS_JOURNEYS["devonport"]?.get("britomart")
        }

        if (foundPresets != null) {
            _journeyOptions.value = foundPresets
            _selectedJourneyOption.value = foundPresets.firstOrNull()
        } else {
            // Generate a synthetic but extremely realistic Auckland Metro journey option
            val destTitle = if (_toQuery.value.isNotBlank()) _toQuery.value else "Auckland CBD"
            val startTitle = if (_fromQuery.value.isNotBlank() && _fromQuery.value != "Current location") _fromQuery.value else "Britomart"
            
            val option1 = JourneyOption(
                id = "dynamic_opt_1",
                totalDuration = 32,
                cost = 4.20,
                departureTime = "12:45",
                arrivalTime = "13:17",
                label = "Fastest",
                steps = listOf(
                    JourneyStep(
                        type = TransitType.TRAIN,
                        lineName = "Eastern Line",
                        fromStation = startTitle,
                        toStation = destTitle,
                        durationMinutes = 32,
                        departureTime = "12:45",
                        arrivalTime = "13:17",
                        details = "Eastern Line service toward central hubs",
                        platformOrTerminal = "Platform 3"
                    )
                )
            )

            val option2 = JourneyOption(
                id = "dynamic_opt_2",
                totalDuration = 40,
                cost = 2.50,
                departureTime = "12:40",
                arrivalTime = "13:20",
                label = "Lowest cost",
                steps = listOf(
                    JourneyStep(
                        type = TransitType.BUS,
                        lineName = "Route 18 Bus",
                        fromStation = startTitle,
                        toStation = destTitle,
                        durationMinutes = 40,
                        departureTime = "12:40",
                        arrivalTime = "13:20",
                        details = "Local bus service along transport corridor",
                        platformOrTerminal = "Stop 7015"
                    )
                )
            )

            _journeyOptions.value = listOf(option1, option2)
            _selectedJourneyOption.value = option1
        }

        _activeScreenState.value = "results"
    }

    fun selectJourneyOption(option: JourneyOption) {
        _selectedJourneyOption.value = option
    }

    // --- ACTIVE TRIP MANAGEMENT ---
    fun startJourney() {
        val selected = _selectedJourneyOption.value
        if (selected != null) {
            _activeTrip.value = selected
            _activeTripStepIndex.value = 0
            _currentTab.value = "trips"
            _activeScreenState.value = "active_trip"
            updateTripAlertForStep(0)
        }
    }

    fun cancelActiveTrip() {
        _activeTrip.value = null
        _activeScreenState.value = "dashboard"
    }

    fun nextTripStep() {
        val trip = _activeTrip.value ?: return
        val currentIdx = _activeTripStepIndex.value
        if (currentIdx < trip.steps.size - 1) {
            val nextIdx = currentIdx + 1
            _activeTripStepIndex.value = nextIdx
            updateTripAlertForStep(nextIdx)
        } else {
            // Completed!
            _activeTrip.value = null
            _activeScreenState.value = "dashboard"
            _currentTab.value = "home"
        }
    }

    fun prevTripStep() {
        val currentIdx = _activeTripStepIndex.value
        if (currentIdx > 0) {
            val prevIdx = currentIdx - 1
            _activeTripStepIndex.value = prevIdx
            updateTripAlertForStep(prevIdx)
        }
    }

    private fun updateTripAlertForStep(stepIndex: Int) {
        val trip = _activeTrip.value ?: return
        val step = trip.steps.getOrNull(stepIndex) ?: return
        
        _activeTripAlert.value = when (step.type) {
            TransitType.WALK -> "Follow walkway signs to your connection. 🚶"
            TransitType.TRAIN -> "Train arriving in 2 minutes. Platform ${step.platformOrTerminal.ifBlank { "1" }}. 🚆"
            TransitType.BUS -> "Get ready to board ${step.lineName}. Have your AT HOP card or contactless device ready. 🚌"
            TransitType.FERRY -> "Ferry boarding commenced at ${step.platformOrTerminal}. Have a nice sailing! ⚓"
        }
    }

    // --- LIVE DEPARTURES HUB ---
    private val _departureTab = MutableStateFlow("train") // "train", "bus", "ferry"
    val departureTab: StateFlow<String> = _departureTab.asStateFlow()

    fun setDepartureTab(tab: String) {
        _departureTab.value = tab
    }

    fun selectDepartureHub(hubId: String) {
        _selectedDepartureStation.value = hubId
    }

    // --- TRAVEL WALLET (AT HOP) ---
    private val _showTopUpDialog = MutableStateFlow(false)
    val showTopUpDialog: StateFlow<Boolean> = _showTopUpDialog.asStateFlow()

    fun setShowTopUpDialog(show: Boolean) {
        _showTopUpDialog.value = show
    }

    fun topUpBalance(amount: Double) {
        _hopBalance.value += amount
    }

    // --- SYSTEM ALERTS AND DISRUPTIONS ---
    private val _selectedAlertId = MutableStateFlow<String?>(null)
    val selectedAlertId: StateFlow<String?> = _selectedAlertId.asStateFlow()

    fun toggleAlertDetail(alertId: String) {
        if (_selectedAlertId.value == alertId) {
            _selectedAlertId.value = null
        } else {
            _selectedAlertId.value = alertId
        }
    }

    // Handle back button behavior for custom screen states inside Compose back handler
    fun handleBackPress(): Boolean {
        if (_activeScreenState.value == "active_trip") {
            _activeScreenState.value = "dashboard"
            _activeTrip.value = null
            return true
        }
        if (_activeScreenState.value == "results") {
            _activeScreenState.value = "dashboard"
            return true
        }
        if (_activeScreenState.value == "station_detail") {
            _activeScreenState.value = "dashboard"
            return true
        }
        return false
    }
}
