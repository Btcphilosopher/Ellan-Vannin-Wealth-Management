package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

// --- DATA MODELS ---

enum class TransitType {
    TRAIN, BUS, FERRY, WALK
}

enum class AlertSeverity {
    NORMAL, MINOR, MAJOR
}

data class Station(
    val id: String,
    val name: String,
    val maoriName: String,
    val latitude: Double,  // Used for custom rendering positions
    val longitude: Double, // Used for custom rendering positions
    val isTrain: Boolean = false,
    val isBus: Boolean = false,
    val isFerry: Boolean = false,
    val isInterchange: Boolean = false
)

data class TransitLine(
    val id: String,
    val name: String,
    val maoriName: String,
    val description: String,
    val color: Color,
    val type: TransitType,
    val activeServices: List<String> = emptyList()
)

data class LiveDeparture(
    val id: String,
    val routeNo: String,
    val lineId: String,
    val lineName: String,
    val destination: String,
    val minutesAway: Int,
    val platform: String,
    val type: TransitType,
    val color: Color
)

data class JourneyStep(
    val type: TransitType,
    val lineName: String,
    val fromStation: String,
    val toStation: String,
    val durationMinutes: Int,
    val departureTime: String,
    val arrivalTime: String,
    val details: String,
    val platformOrTerminal: String = ""
)

data class JourneyOption(
    val id: String,
    val totalDuration: Int,
    val cost: Double,
    val departureTime: String,
    val arrivalTime: String,
    val steps: List<JourneyStep>,
    val label: String // "Fastest", "Fewest changes", "Lowest cost", or "Standard"
)

data class ServiceAlert(
    val id: String,
    val title: String,
    val description: String,
    val affectedLineName: String,
    val severity: AlertSeverity,
    val isPlannedWorks: Boolean,
    val affectedArea: String,
    val timeRange: String,
    val alternativeRoute: String
)

data class HopTransaction(
    val id: String,
    val fromStation: String,
    val toStation: String,
    val fare: Double,
    val date: String,
    val time: String,
    val type: TransitType
)

// --- SYNTHETIC DATA STORE ---

object MetroData {

    // Unique list of major stations with relative geographic coordinates
    // Top-Left (West/North) to Bottom-Right (East/South) representing Auckland coastline & harbours
    val STATIONS = listOf(
        Station("britomart", "Britomart", "Waitematā", -36.8442, 174.7684, isTrain = true, isBus = true, isFerry = true, isInterchange = true),
        Station("newmarket", "Newmarket", "Te Tihi o Mangaika", -36.8686, 174.7794, isTrain = true, isBus = true, isInterchange = true),
        Station("mt_eden", "Mt Eden", "Maungawhau", -36.8710, 174.7570, isTrain = true),
        Station("new_lynn", "New Lynn", "Mokoia", -36.9080, 174.6850, isTrain = true, isBus = true, isInterchange = true),
        Station("henderson", "Henderson", "Kuranui", -36.8810, 174.6300, isTrain = true),
        Station("panmure", "Panmure", "Mokoia Peak", -36.9020, 174.8510, isTrain = true, isBus = true, isInterchange = true),
        Station("sylvia_park", "Sylvia Park", "Puke-ki-te-toka", -36.9150, 174.8420, isTrain = true),
        Station("otahuhu", "Ōtāhuhu", "Portage Station", -36.9400, 174.8400, isTrain = true, isBus = true, isInterchange = true),
        Station("manukau", "Manukau", "Manukau Central", -36.9920, 174.8720, isTrain = true, isBus = true),
        Station("puhinui", "Puhinui", "Puhinui Interchange", -36.9880, 174.8560, isTrain = true, isBus = true, isInterchange = true),
        Station("airport", "Auckland Airport", "Tomokanga o Tāmaki", -37.0080, 174.7920, isBus = true),
        
        // North Shore (Above Waitematā Harbour)
        Station("albany", "Albany", "Okahukura", -36.7320, 174.7080, isBus = true),
        Station("takapuna", "Takapuna", "Takapuna Beach", -36.7880, 174.7780, isBus = true),
        Station("devonport", "Devonport", "Te Hau Kapua", -36.8250, 174.7980, isFerry = true, isBus = true),
        
        // Upper Harbour ferries
        Station("bayswater", "Bayswater", "Bayswater Marina", -36.8180, 174.7700, isFerry = true),
        Station("hobsonville", "Hobsonville Point", "Onekiritea", -36.7900, 174.6750, isFerry = true, isBus = true),
        Station("half_moon_bay", "Half Moon Bay", "Ara-moutere", -36.8780, 174.9020, isFerry = true)
    )

    val LINES = listOf(
        TransitLine("western", "Western Line", "Raina ki te uru", "Swanson ↔ Britomart (City Centre)", LineWestern, TransitType.TRAIN),
        TransitLine("southern", "Southern Line", "Raina ki te tonga", "Papakura ↔ Britomart (City Centre)", LineSouthern, TransitType.TRAIN),
        TransitLine("eastern", "Eastern Line", "Raina ki te rāwhiti", "Manukau ↔ Britomart (City Centre)", LineEastern, TransitType.TRAIN),
        TransitLine("onehunga", "Onehunga Line", "Raina ki Onehunga", "Onehunga ↔ Britomart (City Centre)", LineOnehunga, TransitType.TRAIN),
        TransitLine("crl", "City Rail Link", "Karere ā-Metro", "Waitematā ↔ Maungawhau (Central Loop)", LineCityRailLink, TransitType.TRAIN),
        
        TransitLine("nx1", "Northern Express NX1", "Pahi o te raki", "Albany ↔ Downtown Britomart via Busway", LineBus, TransitType.BUS, listOf("NX1", "NX2")),
        TransitLine("route_18", "Route 18", "Raupapa 18", "New Lynn ↔ Downtown CBD via Great North Rd", LineBus, TransitType.BUS, listOf("18", "18H")),
        TransitLine("route_20", "Route 20", "Raupapa 20", "Onehunga ↔ Wynyard Quarter", LineBus, TransitType.BUS),
        
        TransitLine("ferry_devonport", "Devonport Ferry", "Waka kōpiko Devonport", "Britomart Terminal ↔ Devonport Terminal", LineFerry, TransitType.FERRY),
        TransitLine("ferry_hobsonville", "Hobsonville Ferry", "Waka kōpiko Hobsonville", "Downtown ↔ Hobsonville Point", LineFerry, TransitType.FERRY)
    )

    // Live departures list for major hubs
    val DEPARTURES = mapOf(
        "britomart" to listOf(
            LiveDeparture("dep_w_1", "WESTERN", "western", "Western Line", "Swanson", 4, "Platform 1", TransitType.TRAIN, LineWestern),
            LiveDeparture("dep_e_1", "EASTERN", "eastern", "Eastern Line", "Manukau", 8, "Platform 3", TransitType.TRAIN, LineEastern),
            LiveDeparture("dep_s_1", "SOUTHERN", "southern", "Southern Line", "Papakura", 12, "Platform 2", TransitType.TRAIN, LineSouthern),
            LiveDeparture("dep_b_18", "18", "route_18", "Route 18", "New Lynn", 5, "Bus Stop 7015", TransitType.BUS, LineBus),
            LiveDeparture("dep_b_nx1", "NX1", "nx1", "Northern Express", "Albany Station", 7, "Bus Stop 7020", TransitType.BUS, LineBus),
            LiveDeparture("dep_f_dev", "FERRY", "ferry_devonport", "Devonport Ferry", "Devonport Wharf", 14, "Pier 1C", TransitType.FERRY, LineFerry)
        ),
        "newmarket" to listOf(
            LiveDeparture("dep_nm_s_south", "SOUTHERN", "southern", "Southern Line", "Papakura", 2, "Platform 2", TransitType.TRAIN, LineSouthern),
            LiveDeparture("dep_nm_s_north", "SOUTHERN", "southern", "Southern Line", "Britomart", 6, "Platform 1", TransitType.TRAIN, LineSouthern),
            LiveDeparture("dep_nm_w_west", "WESTERN", "western", "Western Line", "Swanson", 9, "Platform 3", TransitType.TRAIN, LineWestern),
            LiveDeparture("dep_nm_b_20", "20", "route_20", "Route 20", "Onehunga", 4, "Stop 2291", TransitType.BUS, LineBus)
        ),
        "puhinui" to listOf(
            LiveDeparture("dep_ph_s_south", "SOUTHERN", "southern", "Southern Line", "Papakura", 5, "Platform 2", TransitType.TRAIN, LineSouthern),
            LiveDeparture("dep_ph_s_north", "SOUTHERN", "southern", "Southern Line", "Britomart", 11, "Platform 1", TransitType.TRAIN, LineSouthern),
            LiveDeparture("dep_ph_b_air", "380", "airport_link", "Airport Link Bus", "Auckland Airport", 3, "Stop A", TransitType.BUS, AucklandBlue)
        ),
        "devonport" to listOf(
            LiveDeparture("dep_dv_f_bri", "FERRY", "ferry_devonport", "Devonport Ferry", "Downtown Britomart", 10, "Pier 1", TransitType.FERRY, LineFerry),
            LiveDeparture("dep_dv_b_801", "801", "local_bus", "Local Feeder", "Bayswater", 18, "Stop A", TransitType.BUS, LineBus)
        ),
        "albany" to listOf(
            LiveDeparture("dep_al_b_nx1", "NX1", "nx1", "Northern Express", "Downtown Britomart", 3, "Platform 1", TransitType.BUS, LineBus),
            LiveDeparture("dep_al_b_nx2", "NX2", "nx1", "Northern Express", "Newmarket", 17, "Platform 1", TransitType.BUS, LineBus),
            LiveDeparture("dep_al_b_866", "866", "local_bus", "Cross City", "Westgate", 11, "Platform 3", TransitType.BUS, LineBus)
        )
    )

    // Pre-calculated beautiful journeys for common searches
    val PRESETS_JOURNEYS = mapOf(
        "britomart" to mapOf(
            "airport" to listOf(
                JourneyOption(
                    id = "bri_air_fastest",
                    totalDuration = 45,
                    cost = 5.80,
                    departureTime = "18:20",
                    arrivalTime = "19:05",
                    label = "Fastest",
                    steps = listOf(
                        JourneyStep(
                            type = TransitType.TRAIN,
                            lineName = "Southern Line",
                            fromStation = "Britomart",
                            toStation = "Puhinui",
                            durationMinutes = 28,
                            departureTime = "18:20",
                            arrivalTime = "18:48",
                            details = "Southern Line train toward Papakura",
                            platformOrTerminal = "Platform 2"
                        ),
                        JourneyStep(
                            type = TransitType.WALK,
                            lineName = "Transfer",
                            fromStation = "Puhinui Platform",
                            toStation = "Puhinui Bus Stop",
                            durationMinutes = 2,
                            departureTime = "18:48",
                            arrivalTime = "18:50",
                            details = "Walk to the dedicated Airport Link bus bay"
                        ),
                        JourneyStep(
                            type = TransitType.BUS,
                            lineName = "Airport Link (Bus 38)",
                            fromStation = "Puhinui Station",
                            toStation = "Auckland Airport",
                            durationMinutes = 15,
                            departureTime = "18:55",
                            arrivalTime = "19:05",
                            details = "Frequent Airport Orange bus via Puhinui corridor",
                            platformOrTerminal = "Stop A"
                        )
                    )
                ),
                JourneyOption(
                    id = "bri_air_onehunga",
                    totalDuration = 55,
                    cost = 5.80,
                    departureTime = "18:15",
                    arrivalTime = "19:10",
                    label = "Fewest changes",
                    steps = listOf(
                        JourneyStep(
                            type = TransitType.TRAIN,
                            lineName = "Onehunga Line",
                            fromStation = "Britomart",
                            toStation = "Onehunga",
                            durationMinutes = 25,
                            departureTime = "18:15",
                            arrivalTime = "18:40",
                            details = "Onehunga Line train",
                            platformOrTerminal = "Platform 4"
                        ),
                        JourneyStep(
                            type = TransitType.BUS,
                            lineName = "Route 380",
                            fromStation = "Onehunga",
                            toStation = "Auckland Airport",
                            durationMinutes = 30,
                            departureTime = "18:45",
                            arrivalTime = "19:15",
                            details = "Airport Connector Bus",
                            platformOrTerminal = "Stop 2"
                        )
                    )
                ),
                JourneyOption(
                    id = "bri_air_direct_shuttle",
                    totalDuration = 50,
                    cost = 4.20,
                    departureTime = "18:10",
                    arrivalTime = "19:00",
                    label = "Lowest cost",
                    steps = listOf(
                        JourneyStep(
                            type = TransitType.BUS,
                            lineName = "Route 38",
                            fromStation = "Britomart Downtown",
                            toStation = "Auckland Airport",
                            durationMinutes = 50,
                            departureTime = "18:10",
                            arrivalTime = "19:00",
                            details = "Direct Express Bus Connection",
                            platformOrTerminal = "Stop 7012"
                        )
                    )
                )
            ),
            "devonport" to listOf(
                JourneyOption(
                    id = "bri_dev_ferry",
                    totalDuration = 12,
                    cost = 3.60,
                    departureTime = "18:30",
                    arrivalTime = "18:42",
                    label = "Fastest / Ferry",
                    steps = listOf(
                        JourneyStep(
                            type = TransitType.FERRY,
                            lineName = "Devonport Ferry",
                            fromStation = "Britomart Ferry Terminal",
                            toStation = "Devonport Wharf",
                            durationMinutes = 12,
                            departureTime = "18:30",
                            arrivalTime = "18:42",
                            details = "Direct sailing across Waitematā Harbour",
                            platformOrTerminal = "Pier 1C"
                        )
                    )
                )
            )
        ),
        "devonport" to mapOf(
            "britomart" to listOf(
                JourneyOption(
                    id = "dev_bri_preset",
                    totalDuration = 12,
                    cost = 3.60,
                    departureTime = "08:15",
                    arrivalTime = "08:27",
                    label = "Fastest",
                    steps = listOf(
                        JourneyStep(
                            type = TransitType.FERRY,
                            lineName = "Devonport Ferry",
                            fromStation = "Devonport Wharf",
                            toStation = "Britomart Ferry Terminal",
                            durationMinutes = 12,
                            departureTime = "08:15",
                            arrivalTime = "08:27",
                            details = "Direct morning commuter sailing",
                            platformOrTerminal = "Pier 1"
                        )
                    )
                )
            )
        )
    )

    // Favourites Shortcuts
    val FAVOURITES = listOf(
        SavedPreset("Home → Work", "Devonport ↔ Britomart (Ferry)", "devonport", "britomart", 12, "Ferry leaves in 4 min"),
        SavedPreset("Airport Link", "Britomart ↔ Auckland Airport", "britomart", "airport", 45, "Train + Bus combo"),
        SavedPreset("Shopping Route", "Newmarket ↔ Sylvia Park (Train)", "newmarket", "sylvia_park", 14, "Every 10 mins")
    )

    // Service Alerts
    val ALERTS = listOf(
        ServiceAlert(
            id = "alert_ok",
            title = "Network operating normally",
            description = "All train, bus, and ferry networks are operating on standard timetables with minor delay-free services.",
            affectedLineName = "All Lines",
            severity = AlertSeverity.NORMAL,
            isPlannedWorks = false,
            affectedArea = "Entire Auckland Region",
            timeRange = "Today",
            alternativeRoute = ""
        ),
        ServiceAlert(
            id = "alert_1",
            title = "Western Line: Minor timetable changes Saturday",
            description = "Track protection and standard maintenance between Swanson and Mt Eden. Commencing Saturday at 06:00 until 18:00.",
            affectedLineName = "Western Line",
            severity = AlertSeverity.MINOR,
            isPlannedWorks = true,
            affectedArea = "Swanson to Mt Eden",
            timeRange = "Saturday 06:00 - 18:00",
            alternativeRoute = "Use Southern Line services for central-city travel, or local Bus 18 along Great North Road."
        ),
        ServiceAlert(
            id = "alert_2",
            title = "Route 18: Temporary stop change downtown",
            description = "Due to roadworks on Custom Street, Route 18 services will bypass Stop 7015. Please proceed to the temporary shelter outside Commercial Bay.",
            affectedLineName = "Route 18",
            severity = AlertSeverity.MINOR,
            isPlannedWorks = false,
            affectedArea = "Custom Street East, Auckland CBD",
            timeRange = "Active now until Friday next week",
            alternativeRoute = "Please walk 2 minutes north to the temporary bus stop at Stop 7022 outside H&M."
        )
    )

    // Travel Wallet History
    val RECENT_JOURNEYS = listOf(
        HopTransaction("tx1", "Britomart", "Newmarket", 2.50, "Today", "14:15", TransitType.TRAIN),
        HopTransaction("tx2", "Newmarket", "Britomart", 2.50, "Today", "09:30", TransitType.TRAIN),
        HopTransaction("tx3", "Britomart", "Devonport", 3.60, "Yesterday", "17:10", TransitType.FERRY),
        HopTransaction("tx4", "Devonport", "Britomart", 3.60, "Yesterday", "08:45", TransitType.FERRY),
        HopTransaction("tx5", "New Lynn", "Britomart", 4.20, "29 Sep", "12:12", TransitType.TRAIN)
    )
}

data class SavedPreset(
    val title: String,
    val description: String,
    val fromId: String,
    val toId: String,
    val durationMin: Int,
    val statusText: String
)
