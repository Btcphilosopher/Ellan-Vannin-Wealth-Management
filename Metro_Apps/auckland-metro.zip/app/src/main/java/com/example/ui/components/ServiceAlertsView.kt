package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Announcement
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.state.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceAlertsView(
    viewModel: MetroViewModel,
    onBack: () -> Unit
) {
    val expandedAlertId by viewModel.selectedAlertId.collectAsState()

    // Separate normal status from real service disruptions
    val activeAlerts = MetroData.ALERTS.filter { it.severity != AlertSeverity.NORMAL }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AucklandGreyLight)
    ) {
        // --- HEADER BAR ---
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = "NETWORK OPERATIONS",
                        style = MaterialTheme.typography.labelLarge,
                        color = AucklandBlue,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Live Alerts & Planned Works",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Outlined.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = AucklandNavy)
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // --- GENERAL SYSTEM HEALTH CARD ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(AucklandGreen.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = null,
                                tint = AucklandGreen,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = "SYSTEM INTEGRITY: STABLE",
                                color = AucklandGreen,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "All lines running normally",
                                style = MaterialTheme.typography.titleMedium,
                                color = AucklandNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Normal timetables are active across Tāmaki Makaurau.",
                                style = MaterialTheme.typography.labelLarge,
                                color = AucklandGreyMuted
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "ACTIVE SERVICE NOTICES",
                    style = MaterialTheme.typography.labelLarge,
                    color = AucklandNavy.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            // --- EXPANDABLE ALERTS ---
            items(activeAlerts) { alert ->
                val isExpanded = expandedAlertId == alert.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.toggleAlertDetail(alert.id) }
                        .testTag("alert_card_${alert.id}"),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(4.dp),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (alert.isPlannedWorks) LineEastern.copy(alpha = 0.5f) else AucklandOrange.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (alert.isPlannedWorks) LineEastern.copy(alpha = 0.15f) else AucklandOrange.copy(alpha = 0.15f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (alert.isPlannedWorks) Icons.Outlined.Info else Icons.Outlined.Warning,
                                    contentDescription = null,
                                    tint = if (alert.isPlannedWorks) Color(0xFFD97706) else AucklandOrange,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (alert.isPlannedWorks) "PLANNED WORKS" else "SERVICE DISRUPTION",
                                    color = if (alert.isPlannedWorks) Color(0xFFD97706) else AucklandOrange,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = alert.title,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = AucklandNavy,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = if (isExpanded) "Show Less" else "Show More",
                                tint = AucklandGreyMuted,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Expanded Area
                        AnimatedVisibility(
                            visible = isExpanded,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 12.dp)
                            ) {
                                Divider(color = AucklandGreyLight)
                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "Details",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = AucklandNavy,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = alert.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = AucklandNavy.copy(alpha = 0.8f)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                DetailRow("Affected Area:", alert.affectedArea)
                                DetailRow("Time Frame:", alert.timeRange)
                                DetailRow("Alternative Route:", alert.alternativeRoute)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, valText: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = AucklandNavy,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = valText,
            style = MaterialTheme.typography.bodyMedium,
            color = AucklandGreyMuted
        )
    }
}
