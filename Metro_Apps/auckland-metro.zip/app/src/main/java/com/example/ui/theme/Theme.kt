package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AucklandBlue,
    secondary = AucklandNavyLight,
    background = AucklandNavyDark,
    surface = AucklandNavyLight,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White,
    error = AucklandOrange
)

private val LightColorScheme = lightColorScheme(
    primary = AucklandNavy,
    secondary = AucklandBlue,
    background = AucklandGreyLight,
    surface = AucklandCardBg,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = AucklandNavy,
    onSurface = AucklandNavy,
    error = AucklandOrange
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
