package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.outlined.DirectionsBoat
import androidx.compose.material.icons.outlined.DirectionsBus
import androidx.compose.material.icons.outlined.DirectionsTransit
import androidx.compose.material.icons.outlined.FiberManualRecord
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.state.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeparturesView(
    viewModel: MetroViewModel
) {
    val selectedHubId by viewModel.selectedDepartureStation.collectAsState()
    val selectedTab by viewModel.departureTab.collectAsState() // "train", "bus", "ferry", "all"

    val currentHub = MetroData.STATIONS.first { it.id == selectedHubId }
    val departures = MetroData.DEPARTURES[selectedHubId] ?: emptyList()

    // Filter departures by mode tab
    val filteredDeps = departures.filter { dep ->
        when (selectedTab) {
            "train" -> dep.type == TransitType.TRAIN
            "bus" -> dep.type == TransitType.BUS
            "ferry" -> dep.type == TransitType.FERRY
            else -> true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AucklandGreyLight)
    ) {
        // --- TOP HEADER ---
        TopAppBar(
            title = {
                Column {
                    Text(
                        "LIVE DEPARTURES",
                        style = MaterialTheme.typography.labelLarge,
                        color = AucklandBlue,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        "Real-time countdown boards",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = AucklandNavy)
        )

        // --- HUB SELECTOR SLIDER ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(0.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text(
                    text = "SELECT STATION OR HUB",
                    color = AucklandNavy.copy(alpha = 0.5f),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 6.dp),
                    letterSpacing = 1.sp
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val hubs = listOf(
                        "britomart" to "Britomart",
                        "newmarket" to "Newmarket",
                        "puhinui" to "Puhinui",
                        "devonport" to "Devonport",
                        "albany" to "Albany"
                    )
                    items(hubs) { (id, name) ->
                        val isSelected = id == selectedHubId
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) AucklandNavy else AucklandGreyLight)
                                .clickable { viewModel.selectDepartureHub(id) }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = name,
                                color = if (isSelected) Color.White else AucklandNavy,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // --- DEPARTURE FILTER TABS (Train, Bus, Ferry, All) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val tabs = listOf(
                "train" to "TRAINS",
                "bus" to "BUSES",
                "ferry" to "FERRIES",
                "all" to "ALL SERVICES"
            )
            tabs.forEach { (tabId, label) ->
                val isSelected = tabId == selectedTab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) AucklandBlue else Color.White)
                        .border(
                            1.dp,
                            if (isSelected) Color.Transparent else AucklandGreyMuted.copy(alpha = 0.3f),
                            RoundedCornerShape(4.dp)
                        )
                        .clickable { viewModel.setDepartureTab(tabId) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) Color.White else AucklandNavy,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- DEPARTURES BOARD ---
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            if (filteredDeps.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = null,
                            tint = AucklandGreyMuted,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No upcoming departures scheduled for this mode.",
                            color = AucklandNavy,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Try switching filters to 'ALL' or selecting a different terminal hub.",
                            color = AucklandGreyMuted,
                            style = MaterialTheme.typography.labelLarge,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${currentHub.name} Wharf & Station".uppercase(),
                                style = MaterialTheme.typography.labelLarge,
                                color = AucklandNavy.copy(alpha = 0.6f),
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "LIVE STATUS",
                                style = MaterialTheme.typography.labelLarge,
                                color = AucklandGreen,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    items(filteredDeps) { dep ->
                        DepartureCard(dep)
                    }
                }
            }
        }
    }
}

@Composable
fun DepartureCard(dep: LiveDeparture) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Line ID Colored badge
            Box(
                modifier = Modifier
                    .size(width = 72.dp, height = 36.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(dep.color),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = dep.routeNo,
                    color = if (dep.color == LineEastern) AucklandNavy else Color.White,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Destination and line info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = dep.destination,
                    color = AucklandNavy,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = dep.lineName,
                        color = AucklandGreyMuted,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Outlined.FiberManualRecord,
                        contentDescription = null,
                        tint = AucklandGreyMuted.copy(alpha = 0.5f),
                        modifier = Modifier.size(6.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = dep.platform,
                        color = AucklandGreyMuted,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            // Realtime countdown
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${dep.minutesAway}",
                    style = MaterialTheme.typography.displayLarge,
                    color = if (dep.minutesAway <= 5) AucklandOrange else AucklandNavy,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (dep.minutesAway == 1) "MIN AWAY" else "MINS AWAY",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (dep.minutesAway <= 5) AucklandOrange else AucklandGreyMuted,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
