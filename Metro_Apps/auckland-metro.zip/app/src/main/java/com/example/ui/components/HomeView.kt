package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.AirplanemodeActive
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.state.MetroViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeView(
    viewModel: MetroViewModel,
    onNavigateToAlerts: () -> Unit
) {
    val fromVal by viewModel.fromQuery.collectAsState()
    val toVal by viewModel.toQuery.collectAsState()
    val suggestions by viewModel.suggestions.collectAsState()
    val focusManager = LocalFocusManager.current

    // Keep track of which input field has active focus
    var activeFieldIsFrom by remember { mutableStateOf(false) }

    // Pulsing animation for normal operating status
    val infiniteTransition = rememberInfiniteTransition(label = "status_pulse")
    val alphaPulse by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(AucklandGreyLight)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- BRAND HEADER ---
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text(
                    text = "TĀMAKI MAKAURAU",
                    style = MaterialTheme.typography.labelLarge,
                    color = AucklandBlue,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "AUCKLAND METRO",
                    style = MaterialTheme.typography.displayMedium,
                    color = AucklandNavy,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // --- NETWORK OPERATING NORMAL STATUS ---
        item {
            Card(
                onClick = onNavigateToAlerts,
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AucklandNavy),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(AucklandGreen.copy(alpha = alphaPulse))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Network operating normally",
                        color = Color.White,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "View details",
                        tint = Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // --- WHERE TO CENTRAL PLANNER PANEL ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Where to?",
                        style = MaterialTheme.typography.titleLarge,
                        color = AucklandNavy,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // From input
                    OutlinedTextField(
                        value = fromVal,
                        onValueChange = {
                            activeFieldIsFrom = true
                            viewModel.updateFromQuery(it)
                        },
                        label = { Text("From", style = MaterialTheme.typography.labelLarge) },
                        placeholder = { Text("Current location") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.MyLocation,
                                contentDescription = "Current location",
                                tint = AucklandBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        trailingIcon = {
                            if (fromVal.isNotBlank() && fromVal != "Current location") {
                                IconButton(onClick = { viewModel.updateFromQuery("") }) {
                                    Icon(Icons.Default.Clear, "Clear")
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("from_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(4.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AucklandNavy,
                            unfocusedBorderColor = AucklandGreyMuted.copy(alpha = 0.5f)
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // To input
                    OutlinedTextField(
                        value = toVal,
                        onValueChange = {
                            activeFieldIsFrom = false
                            viewModel.updateToQuery(it)
                        },
                        label = { Text("To", style = MaterialTheme.typography.labelLarge) },
                        placeholder = { Text("Search destination") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Outlined.Search,
                                contentDescription = "Search destination",
                                tint = AucklandNavy,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        trailingIcon = {
                            if (toVal.isNotBlank()) {
                                IconButton(onClick = { viewModel.updateToQuery("") }) {
                                    Icon(Icons.Default.Clear, "Clear")
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("to_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(4.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AucklandNavy,
                            unfocusedBorderColor = AucklandGreyMuted.copy(alpha = 0.5f)
                        )
                    )

                    // --- INTELLIGENT SEARCH DROP-DOWN AUTO-SUGGESTIONS ---
                    AnimatedVisibility(
                        visible = suggestions.isNotEmpty(),
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .background(Color(0xFFF9FAFB), RoundedCornerShape(4.dp))
                        ) {
                            suggestions.forEach { (stationName, details) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.selectSuggestion(
                                                stationName,
                                                activeFieldIsFrom
                                            )
                                            focusManager.clearFocus()
                                        }
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Place,
                                        contentDescription = null,
                                        tint = AucklandGreyMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = stationName,
                                            color = AucklandNavy,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = details,
                                            color = AucklandGreyMuted,
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                }
                                Divider(color = AucklandGreyLight)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Leave now dropdown metadata
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Leave now",
                            tint = AucklandGreyMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Leave now",
                            color = AucklandNavy,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // PLAN JOURNEY BUTTON
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            viewModel.planJourney()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("plan_journey_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = AucklandNavy),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "PLAN JOURNEY",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        // --- AUCKLAND AIRPORT DEDICATED SHORTCUT ---
        item {
            Card(
                onClick = {
                    viewModel.updateFromQuery("Current location")
                    viewModel.updateToQuery("Auckland Airport")
                    viewModel.planJourney()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("airport_shortcut"),
                colors = CardDefaults.cardColors(containerColor = AucklandBlue),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AirplanemodeActive,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "AUCKLAND AIRPORT CONNECTION",
                            color = Color.White.copy(alpha = 0.8f),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Get to Auckland Airport",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Multi-modal departures via Puhinui Train Interchange & Airport Bus Link",
                            color = Color.White.copy(alpha = 0.9f),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }

        // --- SAVED FAVORITES (Useful every morning) ---
        item {
            Text(
                text = "SAVED JOURNEYS",
                style = MaterialTheme.typography.labelLarge,
                color = AucklandNavy.copy(alpha = 0.6f),
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(MetroData.FAVOURITES) { preset ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.StarBorder,
                        contentDescription = "Starred Favorite",
                        tint = AucklandBlue,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = preset.title,
                            color = AucklandNavy,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = preset.description,
                            color = AucklandGreyMuted,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${preset.durationMin} min • ${preset.statusText}",
                            color = AucklandGreen,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Button(
                        onClick = { viewModel.selectSavedPreset(preset) },
                        colors = ButtonDefaults.buttonColors(containerColor = AucklandNavyLight),
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "GO",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
