package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.state.MetroViewModel
import com.example.ui.components.*
import com.example.ui.theme.AucklandNavy
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Enable true Edge-to-Edge full bleed layout support
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: MetroViewModel = viewModel()
                
                // Track if we are displaying the Alerts screen
                var isShowingAlerts by remember { mutableStateOf(false) }

                val currentTab by viewModel.currentTab.collectAsState()
                val activeScreenState by viewModel.activeScreenState.collectAsState()

                // Integrated Android System Back Press Handler
                BackHandler(enabled = isShowingAlerts || activeScreenState != "dashboard" || currentTab != "home") {
                    when {
                        isShowingAlerts -> {
                            isShowingAlerts = false
                        }
                        !viewModel.handleBackPress() -> {
                            // If we are at the top level of another tab, back button returns us to the Home tab
                            viewModel.setTab("home")
                        }
                    }
                }

                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding() // Safe notch and system navigation pill padding
                ) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        bottomBar = {
                            // Don't show bottom navigation bar when viewing sub-detail screens like Alerts or Journey Result
                            if (!isShowingAlerts && activeScreenState == "dashboard") {
                                NavigationBar(
                                    modifier = Modifier.fillMaxWidth().testTag("bottom_nav_bar"),
                                    containerColor = Color.White,
                                    tonalElevation = 8.dp
                                ) {
                                    NavigationBarItem(
                                        selected = currentTab == "home",
                                        onClick = { viewModel.setTab("home") },
                                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                        label = { Text("Home", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = AucklandNavy,
                                            selectedTextColor = AucklandNavy,
                                            indicatorColor = Color(0x1F009FBD)
                                        ),
                                        modifier = Modifier.testTag("nav_item_home")
                                    )
                                    NavigationBarItem(
                                        selected = currentTab == "map",
                                        onClick = { viewModel.setTab("map") },
                                        icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                                        label = { Text("Live Map", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = AucklandNavy,
                                            selectedTextColor = AucklandNavy,
                                            indicatorColor = Color(0x1F009FBD)
                                        ),
                                        modifier = Modifier.testTag("nav_item_map")
                                    )
                                    NavigationBarItem(
                                        selected = currentTab == "departures",
                                        onClick = { viewModel.setTab("departures") },
                                        icon = { Icon(Icons.Default.Schedule, contentDescription = "Departures") },
                                        label = { Text("Departures", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = AucklandNavy,
                                            selectedTextColor = AucklandNavy,
                                            indicatorColor = Color(0x1F009FBD)
                                        ),
                                        modifier = Modifier.testTag("nav_item_departures")
                                    )
                                    NavigationBarItem(
                                        selected = currentTab == "trips",
                                        onClick = { viewModel.setTab("trips") },
                                        icon = { Icon(Icons.Default.DirectionsTransit, contentDescription = "Trips") },
                                        label = { Text("Trips", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = AucklandNavy,
                                            selectedTextColor = AucklandNavy,
                                            indicatorColor = Color(0x1F009FBD)
                                        ),
                                        modifier = Modifier.testTag("nav_item_trips")
                                    )
                                    NavigationBarItem(
                                        selected = currentTab == "account",
                                        onClick = { viewModel.setTab("account") },
                                        icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Account") },
                                        label = { Text("Account", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = AucklandNavy,
                                            selectedTextColor = AucklandNavy,
                                            indicatorColor = Color(0x1F009FBD)
                                        ),
                                        modifier = Modifier.testTag("nav_item_account")
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            // Main Screen Router with animated transitions
                            AnimatedContent(
                                targetState = RouterState(
                                    tab = currentTab,
                                    screenState = activeScreenState,
                                    showingAlerts = isShowingAlerts
                                ),
                                transitionSpec = {
                                    fadeIn() togetherWith fadeOut()
                                },
                                label = "screen_navigation"
                            ) { state ->
                                when {
                                    state.showingAlerts -> {
                                        ServiceAlertsView(
                                            viewModel = viewModel,
                                            onBack = { isShowingAlerts = false }
                                        )
                                    }
                                    state.tab == "home" -> {
                                        when (state.screenState) {
                                            "dashboard" -> {
                                                HomeView(
                                                    viewModel = viewModel,
                                                    onNavigateToAlerts = { isShowingAlerts = true }
                                                )
                                            }
                                            "results" -> {
                                                // Display the beautiful searched journey alternatives
                                                JourneyResultView(
                                                    viewModel = viewModel,
                                                    onBack = { viewModel.handleBackPress() }
                                                )
                                            }
                                            "active_trip" -> {
                                                // Transform directly to conductor mode if activated
                                                TripsView(viewModel = viewModel)
                                            }
                                            else -> {
                                                HomeView(
                                                    viewModel = viewModel,
                                                    onNavigateToAlerts = { isShowingAlerts = true }
                                                )
                                            }
                                        }
                                    }
                                    state.tab == "map" -> {
                                        MetroMap()
                                    }
                                    state.tab == "departures" -> {
                                        DeparturesView(viewModel = viewModel)
                                    }
                                    state.tab == "trips" -> {
                                        TripsView(viewModel = viewModel)
                                    }
                                    state.tab == "account" -> {
                                        HopWalletView(viewModel = viewModel)
                                    }
                                    else -> {
                                        HomeView(
                                            viewModel = viewModel,
                                            onNavigateToAlerts = { isShowingAlerts = true }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Data holder class for router state tracking inside Compose animations
data class RouterState(
    val tab: String,
    val screenState: String,
    val showingAlerts: Boolean
)
