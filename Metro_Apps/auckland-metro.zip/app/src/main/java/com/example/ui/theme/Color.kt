package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Auckland Metro Color Palette
val AucklandNavy = Color(0xFF0C1B33)     // Deep Navy (primary backgrounds / headers)
val AucklandNavyLight = Color(0xFF162A4A) // Secondary navy containers
val AucklandNavyDark = Color(0xFF050B14)  // Absolute dark backgrounds
val AucklandBlue = Color(0xFF009FBD)      // Vibrant Transit Blue (primary actions, train indicators)
val HarbourBlue = Color(0xFF005C7A)       // Deep Ocean Blue (Ferry indicators)
val AucklandOrange = Color(0xFFEF5B24)    // Operational Accent (alerts, alert warning states)
val AucklandGreen = Color(0xFF10B981)     // Network OK green / on-time status
val AucklandGreyLight = Color(0xFFF3F4F6) // Soft background for screens
val AucklandGreyMuted = Color(0xFF9CA3AF) // Muted text/borders
val AucklandCardBg = Color(0xFFFFFFFF)    // Plain white surface for maximum readability

// Transit Lines Specific Colors
val LineWestern = Color(0xFFEF4444)       // Western Line Red (traditional AT Red/Western)
val LineSouthern = Color(0xFF3B82F6)      // Southern Line Blue
val LineEastern = Color(0xFFF59E0B)       // Eastern Line Yellow/Orange
val LineOnehunga = Color(0xFF10B981)      // Onehunga Line Green
val LineCityRailLink = Color(0xFF8B5CF6)  // CRL Purple (modern New Connection)
val LineFerry = Color(0xFF06B6D4)         // Ferry Cyan
val LineBus = Color(0xFF6B7280)           // Bus Corridor Grey/Slate
