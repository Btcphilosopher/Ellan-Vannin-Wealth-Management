package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalTextApi::class)
@Composable
fun MetroMap(
    modifier: Modifier = Modifier,
    stations: List<Station> = MetroData.STATIONS,
    lines: List<TransitLine> = MetroData.LINES
) {
    // Zoom & pan states
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset(0f, 0f)) }

    // Dynamic animation for live vehicles moving along transit lines
    val infiniteTransition = rememberInfiniteTransition(label = "vehicle_movement")
    val progress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "progress"
    )

    // Pulse animation for user location
    val pulse by infiniteTransition.animateFloat(
        initialValue = 4f,
        targetValue = 16f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFE5E7EB)) // Soft sand/light grey landmass
    ) {
        // Main Map Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.5f, 4f)
                        offset += pan
                    }
                }
        ) {
            withTransform({
                translate(offset.x, offset.y)
                scale(scale, scale, pivot = Offset(size.width / 2, size.height / 2))
            }) {
                // --- 1. WATER BODIES (Waitematā and Manukau Harbours) ---
                drawHarbourWaterways()

                // --- 2. GRID BLUEPRINT LINES (Restrained technical background) ---
                drawMapGrid()

                // --- 3. TRANSIT LINES ---
                // We define geographic path links based on actual stations
                drawTransitPaths(lines, stations)

                // --- 4. STATIONS ---
                drawStations(stations, textMeasurer, scale)

                // --- 5. LIVE ANIMATED VEHICLES ---
                drawLiveVehicles(progress)

                // --- 6. USER LOCATION ---
                drawUserLocation(pulse)
            }
        }

        // Map Legend and Floating Actions
        MapControlsOverlay(
            scale = scale,
            onZoomIn = { scale = (scale + 0.3f).coerceAtMost(4f) },
            onZoomOut = { scale = (scale - 0.3f).coerceAtLeast(0.5f) },
            onReset = {
                scale = 1f
                offset = Offset(0f, 0f)
            }
        )
    }
}

// Draw Waitematā Harbour and Manukau Harbour geographically
private fun DrawScope.drawHarbourWaterways() {
    val waterColor = Color(0xFFBACEDB) // Clean Auckland Harbour Blue

    // 1. Waitematā Harbour (Top portion representing the bridge and the gulf)
    val waitemataPath = Path().apply {
        moveTo(0f, 0f)
        lineTo(size.width, 0f)
        lineTo(size.width, size.height * 0.35f)
        // Draw coastline towards Devonport / North Shore
        cubicTo(
            size.width * 0.85f, size.height * 0.3f,
            size.width * 0.7f, size.height * 0.4f,
            size.width * 0.6f, size.height * 0.32f
        )
        // Under the Harbour Bridge down into Shoal Bay / Bayswater
        cubicTo(
            size.width * 0.55f, size.height * 0.28f,
            size.width * 0.45f, size.height * 0.38f,
            size.width * 0.4f, size.height * 0.33f
        )
        // Hobsonville waterfront
        cubicTo(
            size.width * 0.25f, size.height * 0.35f,
            size.width * 0.1f, size.height * 0.2f,
            0f, size.height * 0.25f
        )
        close()
    }
    drawPath(path = waitemataPath, color = waterColor)

    // 2. Manukau Harbour (Bottom-left portion representing South-West Auckland)
    val manukauPath = Path().apply {
        moveTo(0f, size.height)
        lineTo(size.width * 0.45f, size.height)
        cubicTo(
            size.width * 0.38f, size.height * 0.88f,
            size.width * 0.25f, size.height * 0.8f,
            size.width * 0.2f, size.height * 0.88f
        )
        cubicTo(
            size.width * 0.15f, size.height * 0.95f,
            size.width * 0.08f, size.height * 0.85f,
            0f, size.height * 0.82f
        )
        close()
    }
    drawPath(path = manukauPath, color = waterColor)
}

private fun DrawScope.drawMapGrid() {
    val gridColor = Color(0x1F9CA3AF)
    val spacing = 80f
    
    var x = 0f
    while (x < size.width) {
        drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
        x += spacing
    }
    
    var y = 0f
    while (y < size.height) {
        drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
        y += spacing
    }
}

// Translate Latitude & Longitude to Canvas relative Offset
private fun DrawScope.getStationPos(station: Station): Offset {
    // Custom bounds calibrated to include Albany (North), Henderson (West), Airport (South) and Half Moon Bay (East)
    val latMin = -37.02
    val latMax = -36.72
    val lonMin = 174.60
    val lonMax = 174.92

    val xNorm = (station.longitude - lonMin) / (lonMax - lonMin)
    val yNorm = (station.latitude - latMin) / (latMax - latMin)

    // Flip Y because negative latitude is South but Y increases downwards in Canvas
    val x = xNorm * size.width
    val y = (1.0 - yNorm) * size.height

    return Offset(x.toFloat(), y.toFloat())
}

private fun DrawScope.drawTransitPaths(lines: List<TransitLine>, stations: List<Station>) {
    // Map of Station ID to its Offset
    val positions = stations.associate { it.id to getStationPos(it) }

    lines.forEach { line ->
        val pathStations = when (line.id) {
            "western" -> listOf("henderson", "new_lynn", "mt_eden", "newmarket", "britomart")
            "southern" -> listOf("puhinui", "otahuhu", "sylvia_park", "newmarket", "britomart")
            "eastern" -> listOf("manukau", "puhinui", "otahuhu", "panmure", "britomart")
            "onehunga" -> listOf("newmarket", "britomart") // Simplified route representation
            "crl" -> listOf("britomart", "mt_eden", "newmarket")
            "nx1" -> listOf("albany", "takapuna", "britomart")
            "route_18" -> listOf("new_lynn", "britomart")
            "ferry_devonport" -> listOf("britomart", "devonport")
            "ferry_hobsonville" -> listOf("britomart", "bayswater", "hobsonville")
            else -> emptyList()
        }

        if (pathStations.size >= 2) {
            val path = Path().apply {
                val startPos = positions[pathStations.first()]
                if (startPos != null) {
                    moveTo(startPos.x, startPos.y)
                    for (i in 1 until pathStations.size) {
                        val toPos = positions[pathStations[i]]
                        if (toPos != null) {
                            // Render slightly curved schematic connections rather than raw diagonals
                            val fromPos = positions[pathStations[i - 1]]!!
                            val midX = (fromPos.x + toPos.x) / 2
                            val midY = (fromPos.y + toPos.y) / 2
                            // Slight curve bias for schematic feel
                            val controlX = midX + (toPos.y - fromPos.y) * 0.05f
                            val controlY = midY - (toPos.x - fromPos.x) * 0.05f
                            
                            quadraticTo(controlX, controlY, toPos.x, toPos.y)
                        }
                    }
                }
            }
            
            // Draw transit lines with thick clear markers
            drawPath(
                path = path,
                color = line.color,
                style = Stroke(
                    width = if (line.type == TransitType.FERRY) 4f else 8f,
                    pathEffect = if (line.type == TransitType.FERRY) PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f) else null,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }
    }
}

private fun DrawScope.drawStations(
    stations: List<Station>,
    textMeasurer: TextMeasurer,
    scale: Float
) {
    stations.forEach { station ->
        val pos = getStationPos(station)

        // Interchange nodes are represented with larger double rings, others with solid nodes
        if (station.isInterchange) {
            drawCircle(
                color = Color.White,
                radius = 12f,
                center = pos
            )
            drawCircle(
                color = AucklandNavy,
                radius = 12f,
                center = pos,
                style = Stroke(width = 3f)
            )
            drawCircle(
                color = AucklandNavy,
                radius = 4f,
                center = pos
            )
        } else {
            drawCircle(
                color = Color.White,
                radius = 7f,
                center = pos
            )
            val strokeColor = when {
                station.isFerry -> HarbourBlue
                station.isTrain -> AucklandBlue
                else -> LineBus
            }
            drawCircle(
                color = strokeColor,
                radius = 7f,
                center = pos,
                style = Stroke(width = 2.5f)
            )
        }

        // Draw station text labels (only at readable zoom scales)
        if (scale >= 0.8f) {
            val labelText = station.name
            val layoutResult = textMeasurer.measure(
                text = AnnotatedString(labelText),
                style = TextStyle(
                    color = AucklandNavy,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    background = Color(0xB3FFFFFF) // Tiny white background backdrop for legibility
                )
            )

            // Dynamic anchor positioning to prevent overlapping
            val textOffset = when (station.id) {
                "britomart" -> Offset(pos.x - layoutResult.size.width / 2, pos.y - 36f)
                "devonport" -> Offset(pos.x + 16f, pos.y - 10f)
                "airport" -> Offset(pos.x - layoutResult.size.width / 2, pos.y + 16f)
                "albany" -> Offset(pos.x - layoutResult.size.width - 16f, pos.y - 10f)
                else -> Offset(pos.x + 16f, pos.y - 12f)
            }

            drawText(textLayoutResult = layoutResult, topLeft = textOffset)
        }
    }
}

private fun DrawScope.drawLiveVehicles(progress: Float) {
    // Generate simulated vehicle offsets moving beautifully along routes
    val vehicles = listOf(
        // Western Line train: Henderson to Britomart
        getSimulatedPosition("western", progress, isReverse = false),
        // Southern Line train: Britomart to Puhinui
        getSimulatedPosition("southern", (progress + 0.3f) % 1f, isReverse = true),
        // Northern Express bus: Albany to Britomart
        getSimulatedPosition("nx1", (progress + 0.5f) % 1f, isReverse = false),
        // Devonport ferry sailing across harbour
        getSimulatedPosition("ferry_devonport", (progress + 0.7f) % 1f, isReverse = false)
    )

    vehicles.forEach { (pos, color, symbol) ->
        // Draw crisp circle border
        drawCircle(
            color = Color.White,
            radius = 11f,
            center = pos
        )
        drawCircle(
            color = color,
            radius = 9f,
            center = pos
        )
        // Tiny directional marker or white core
        drawCircle(
            color = Color.White,
            radius = 3.5f,
            center = pos
        )
    }
}

private fun DrawScope.getSimulatedPosition(
    lineId: String,
    prog: Float,
    isReverse: Boolean
): Triple<Offset, Color, String> {
    val pathPoints = when (lineId) {
        "western" -> listOf("henderson", "new_lynn", "mt_eden", "newmarket", "britomart")
        "southern" -> listOf("britomart", "newmarket", "sylvia_park", "otahuhu", "puhinui")
        "nx1" -> listOf("albany", "takapuna", "britomart")
        "ferry_devonport" -> listOf("britomart", "devonport")
        else -> listOf("britomart", "newmarket")
    }

    val actualProg = if (isReverse) 1f - prog else prog
    val numSegments = pathPoints.size - 1
    val segmentFloat = actualProg * numSegments
    val segmentIdx = segmentFloat.toInt().coerceIn(0, numSegments - 1)
    val segmentProg = segmentFloat - segmentIdx

    val startStation = MetroData.STATIONS.first { it.id == pathPoints[segmentIdx] }
    val endStation = MetroData.STATIONS.first { it.id == pathPoints[segmentIdx + 1] }

    val startPos = getStationPos(startStation)
    val endPos = getStationPos(endStation)

    // Linear interpolate along segment
    val x = startPos.x + (endPos.x - startPos.x) * segmentProg
    val y = startPos.y + (endPos.y - startPos.y) * segmentProg

    val color = when (lineId) {
        "western" -> LineWestern
        "southern" -> LineSouthern
        "nx1" -> AucklandBlue
        "ferry_devonport" -> LineFerry
        else -> AucklandNavy
    }

    val symbol = when (lineId) {
        "ferry_devonport" -> "⚓"
        "nx1" -> "🚌"
        else -> "🚆"
    }

    return Triple(Offset(x, y), color, symbol)
}

private fun DrawScope.drawUserLocation(pulseRadius: Float) {
    // Anchor user location near Mt Eden station
    val mtEden = MetroData.STATIONS.first { it.id == "mt_eden" }
    val basePos = getStationPos(mtEden)
    // Offset slightly so it looks like user is walking nearby
    val userPos = Offset(basePos.x + 35f, basePos.y - 25f)

    // Pulse Backdrop
    drawCircle(
        color = AucklandBlue.copy(alpha = 0.3f),
        radius = pulseRadius * 2,
        center = userPos
    )

    // Core Solid Dot
    drawCircle(
        color = Color.White,
        radius = 8f,
        center = userPos
    )
    drawCircle(
        color = AucklandBlue,
        radius = 5.5f,
        center = userPos
    )
}

@Composable
private fun BoxScope.MapControlsOverlay(
    scale: Float,
    onZoomIn: () -> Unit,
    onZoomOut: () -> Unit,
    onReset: () -> Unit
) {
    // 1. Legend at top left
    Card(
        modifier = Modifier
            .padding(16.dp)
            .align(Alignment.TopStart)
            .width(220.dp),
        colors = CardDefaults.cardColors(containerColor = AucklandNavy.copy(alpha = 0.9f)),
        shape = RoundedCornerShape(4.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                "TĀMAKI MAKAURAU",
                color = AucklandBlue,
                style = MaterialTheme.typography.labelLarge
            )
            Text(
                "NETWORK SCHEMATIC",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            
            LegendRow(LineWestern, "Western Line (Raina Uru)")
            LegendRow(LineSouthern, "Southern Line (Raina Tonga)")
            LegendRow(LineEastern, "Eastern Line (Raina Rāwhiti)")
            LegendRow(LineCityRailLink, "City Rail Link (CRL Loop)")
            LegendRow(AucklandBlue, "Northern Busway Corridors")
            LegendRow(LineFerry, "Waitematā Ferry Routes")
            
            Spacer(modifier = Modifier.height(4.dp))
            Divider(color = Color.White.copy(alpha = 0.2f), thickness = 1.dp)
            Spacer(modifier = Modifier.height(4.dp))
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(AucklandBlue)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "Your location (Simulated)",
                    color = Color.White.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }

    // 2. Map actions bottom right
    Column(
        modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        IconButton(
            onClick = onZoomIn,
            modifier = Modifier
                .background(Color.White, RoundedCornerShape(4.dp))
                .size(48.dp)
        ) {
            Icon(Icons.Default.Add, "Zoom In", tint = AucklandNavy)
        }
        IconButton(
            onClick = onZoomOut,
            modifier = Modifier
                .background(Color.White, RoundedCornerShape(4.dp))
                .size(48.dp)
        ) {
            Icon(Icons.Default.Remove, "Zoom Out", tint = AucklandNavy)
        }
        IconButton(
            onClick = onReset,
            modifier = Modifier
                .background(Color.White, RoundedCornerShape(4.dp))
                .size(48.dp)
        ) {
            Icon(Icons.Default.Refresh, "Reset Map View", tint = AucklandNavy)
        }
    }
}

@Composable
private fun LegendRow(color: Color, name: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(16.dp)
                .height(4.dp)
                .background(color, RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            name,
            color = Color.White.copy(alpha = 0.9f),
            style = MaterialTheme.typography.labelSmall
        )
    }
}
