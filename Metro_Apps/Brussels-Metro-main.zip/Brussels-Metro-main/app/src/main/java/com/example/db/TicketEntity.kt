package com.example.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val typeName: String,
    val titleKey: String,
    val validFrom: String,
    val validUntil: String,
    val qrCodeToken: String,
    val isActive: Boolean,
    val priceEur: Double
)
