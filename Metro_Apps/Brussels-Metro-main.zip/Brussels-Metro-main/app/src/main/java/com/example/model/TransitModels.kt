package com.example.model

enum class TransitMode {
    METRO,
    TRAM,
    BUS,
    TRAIN,
    SNCB,
    WALK
}

enum class StatusSeverity {
    NORMAL,
    MINOR_DELAY,
    MAJOR_DELAY,
    PARTIAL_SERVICE,
    SUSPENDED,
    STATION_CLOSED,
    PLATFORM_CHANGE
}

enum class Facility {
    ELEVATOR,
    ESCALATOR,
    TICKET_MACHINE,
    TOILETS,
    TACTILE_GUIDANCE,
    STEP_FREE
}

data class StationEntrance(
    val id: String,
    val name: String,
    val lat: Double,
    val lng: Double,
    val isAccessible: Boolean = true
)

data class StationConnection(
    val mode: TransitMode,
    val routeName: String,
    val destination: String
)

data class Station(
    val id: String,
    val nameNl: String,
    val nameFr: String,
    val nameDe: String,
    val nameWa: String,
    val nameEn: String,
    val lat: Double,
    val lng: Double,
    val lines: List<String>,
    val platforms: List<String>,
    val entrances: List<StationEntrance>,
    val facilities: List<Facility>,
    val connections: List<StationConnection>,
    val isInterchange: Boolean = false,
    val isStepFree: Boolean = true
) {
    fun getName(lang: com.example.i18n.Language): String {
        return when (lang) {
            com.example.i18n.Language.NL_BE -> nameNl
            com.example.i18n.Language.FR_BE -> nameFr
            com.example.i18n.Language.DE_BE -> nameDe
            com.example.i18n.Language.WA_BE -> nameWa
            com.example.i18n.Language.EN_GB -> nameEn
        }
    }

    val officialNameString: String
        get() = if (nameNl == nameFr) nameNl else "$nameFr / $nameNl"
}

data class Line(
    val id: String,
    val number: String,
    val name: String,
    val type: TransitMode,
    val colorHex: String,
    val stationIds: List<String>,
    val statusSeverity: StatusSeverity = StatusSeverity.NORMAL,
    val statusMessage: String = "Normal service"
)

data class DisruptionAlert(
    val alertId: String,
    val affectedLineIds: List<String>,
    val affectedStationIds: List<String>,
    val severity: StatusSeverity,
    val title: String,
    val description: String,
    val timestamp: String,
    val expectedDuration: String,
    val alternativeRouteSuggestion: String? = null
)

data class DepartureInfo(
    val lineId: String,
    val destination: String,
    val minutesAway: Int,
    val isRealtime: Boolean = true
)

data class JourneySegment(
    val fromStationId: String,
    val toStationId: String,
    val lineId: String?,
    val mode: TransitMode,
    val durationMinutes: Int,
    val stopCount: Int,
    val intermediateStationIds: List<String> = emptyList(),
    val isAccessible: Boolean = true
)

data class JourneyPlan(
    val journeyId: String,
    val originStationId: String,
    val destinationStationId: String,
    val totalDurationMinutes: Int,
    val transfersCount: Int,
    val walkingMinutes: Int,
    val isAccessible: Boolean,
    val segments: List<JourneySegment>,
    val isDisrupted: Boolean = false,
    val disruptionMessage: String? = null,
    val alternativeAvailable: Boolean = false
)

enum class TicketType {
    SINGLE_JOURNEY,
    DAY_PASS_24H,
    MULTI_10_JOURNEY,
    AIRPORT_LINE,
    CITY_PASS
}

data class TicketPass(
    val id: String,
    val type: TicketType,
    val titleKey: String,
    val validFrom: String,
    val validUntil: String,
    val qrCodeToken: String,
    val isActive: Boolean,
    val priceEur: Double
)

data class UserFavourite(
    val id: String,
    val label: String,
    val stationId: String,
    val iconName: String = "place"
)

data class VehiclePosition(
    val vehicleId: String,
    val lineId: String,
    val currentStationId: String,
    val nextStationId: String,
    val progress: Float, // 0.0 to 1.0
    val lat: Double,
    val lng: Double,
    val delayMinutes: Int = 0
)
