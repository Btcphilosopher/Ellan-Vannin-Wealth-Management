package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Localizer
import com.example.model.TicketPass
import com.example.model.TicketType
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalTicketWalletView(
    currentLanguage: Language,
    tickets: List<TicketPass>,
    onBuyTicket: (TicketType) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedQrTicket by remember { mutableStateOf<TicketPass?>(null) }
    var showBuyModal by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = Localizer.get(currentLanguage, "tickets.title"),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Button(
                    onClick = { showBuyModal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("buy_ticket_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(Localizer.get(currentLanguage, "tickets.buy_new"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        items(tickets.size) { idx ->
            val ticket = tickets[idx]

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ticket_card_$idx")
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = if (ticket.isActive) MinimalSuccess.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (ticket.isActive) Localizer.get(currentLanguage, "tickets.active") else "INACTIVE",
                                color = if (ticket.isActive) MinimalSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = "€%.2f".format(ticket.priceEur),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Text(
                        text = Localizer.get(currentLanguage, ticket.titleKey),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = Localizer.get(currentLanguage, "tickets.valid_until", ticket.validUntil),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = { selectedQrTicket = ticket },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("show_qr_btn_$idx")
                    ) {
                        Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(Localizer.get(currentLanguage, "tickets.show"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // QR Barcode Modal
    selectedQrTicket?.let { ticket ->
        AlertDialog(
            onDismissRequest = { selectedQrTicket = null },
            confirmButton = {
                TextButton(onClick = { selectedQrTicket = null }) {
                    Text("CLOSE", fontWeight = FontWeight.Bold)
                }
            },
            title = { Text(Localizer.get(currentLanguage, ticket.titleKey), fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.size(180.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.QrCode2, contentDescription = "QR Code", tint = Color.Black, modifier = Modifier.size(130.dp))
                            Text("VALID PASS", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 10.sp)
                        }
                    }

                    Text(
                        text = ticket.qrCodeToken,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = BrusselsGold,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )
    }

    // Buy Ticket Modal
    if (showBuyModal) {
        AlertDialog(
            onDismissRequest = { showBuyModal = false },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showBuyModal = false }) {
                    Text("CANCEL", color = Color.Gray)
                }
            },
            title = { Text(Localizer.get(currentLanguage, "tickets.buy_new"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TicketPurchaseOption(
                        title = "Brupass Single Journey",
                        price = "€2.60",
                        onClick = {
                            onBuyTicket(TicketType.SINGLE_JOURNEY)
                            showBuyModal = false
                        }
                    )
                    TicketPurchaseOption(
                        title = "Brupass 24h Pass",
                        price = "€8.40",
                        onClick = {
                            onBuyTicket(TicketType.DAY_PASS_24H)
                            showBuyModal = false
                        }
                    )
                    TicketPurchaseOption(
                        title = "Brupass 10 Rides Pass",
                        price = "€16.80",
                        onClick = {
                            onBuyTicket(TicketType.MULTI_10_JOURNEY)
                            showBuyModal = false
                        }
                    )
                    TicketPurchaseOption(
                        title = "Brussels Airport Express Line",
                        price = "€7.00",
                        onClick = {
                            onBuyTicket(TicketType.AIRPORT_LINE)
                            showBuyModal = false
                        }
                    )
                    TicketPurchaseOption(
                        title = "Brussels City Pass (48h)",
                        price = "€24.00",
                        onClick = {
                            onBuyTicket(TicketType.CITY_PASS)
                            showBuyModal = false
                        }
                    )
                }
            }
        )
    }
}

@Composable
fun TicketPurchaseOption(title: String, price: String, onClick: () -> Unit) {
    Surface(
        color = SurfaceDark,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
            Text(text = price, fontWeight = FontWeight.ExtraBold, color = BrusselsGold, fontSize = 14.sp)
        }
    }
}
