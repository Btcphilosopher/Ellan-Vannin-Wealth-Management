package com.example.i18n

enum class Language(
    val code: String,
    val localeTag: String,
    val displayName: String,
    val flagEmoji: String,
    val sampleNextStation: String,
    val sampleGreeting: String
) {
    NL_BE("nl", "nl-BE", "Nederlands", "🇳🇱", "Volgend station", "Goedemorgen"),
    FR_BE("fr", "fr-BE", "Français", "🇫🇷", "Prochaine station", "Bonjour"),
    DE_BE("de", "de-BE", "Deutsch", "🇩🇪", "Nächste Station", "Guten Morgen"),
    WA_BE("wa", "wa-BE", "Wallon", "🇧🇪", "Prochin station", "Bonjoûr"),
    EN_GB("en", "en-GB", "English", "🇬🇧", "Next station", "Good morning");

    companion object {
        fun fromCode(code: String): Language {
            return entries.find { it.code.equals(code, ignoreCase = true) || it.localeTag.equals(code, ignoreCase = true) }
                ?: EN_GB
        }
    }
}
