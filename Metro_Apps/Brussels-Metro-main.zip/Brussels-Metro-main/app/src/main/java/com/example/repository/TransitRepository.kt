package com.example.repository

import com.example.db.*
import com.example.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class TransitRepository(private val db: AppDatabase) {

    val favourites: Flow<List<UserFavourite>> = db.favouriteDao().getAllFavourites().map { list ->
        list.map { entity ->
            UserFavourite(
                id = entity.id,
                label = entity.label,
                stationId = entity.stationId,
                iconName = entity.iconName
            )
        }
    }

    val tickets: Flow<List<TicketPass>> = db.ticketDao().getAllTickets().map { list ->
        list.map { entity ->
            TicketPass(
                id = entity.id,
                type = try { TicketType.valueOf(entity.typeName) } catch (e: Exception) { TicketType.SINGLE_JOURNEY },
                titleKey = entity.titleKey,
                validFrom = entity.validFrom,
                validUntil = entity.validUntil,
                qrCodeToken = entity.qrCodeToken,
                isActive = entity.isActive,
                priceEur = entity.priceEur
            )
        }
    }

    suspend fun saveFavourite(favourite: UserFavourite) {
        db.favouriteDao().insertFavourite(
            FavouriteEntity(favourite.id, favourite.label, favourite.stationId, favourite.iconName)
        )
    }

    suspend fun removeFavourite(id: String) {
        db.favouriteDao().deleteFavourite(id)
    }

    suspend fun saveTicket(ticket: TicketPass) {
        db.ticketDao().insertTicket(
            TicketEntity(
                id = ticket.id,
                typeName = ticket.type.name,
                titleKey = ticket.titleKey,
                validFrom = ticket.validFrom,
                validUntil = ticket.validUntil,
                qrCodeToken = ticket.qrCodeToken,
                isActive = ticket.isActive,
                priceEur = ticket.priceEur
            )
        )
    }

    suspend fun getSavedLanguageCode(): String? {
        return db.preferenceDao().getPreference("selected_language")
    }

    suspend fun saveLanguageCode(code: String) {
        db.preferenceDao().setPreference(AppPreferenceEntity("selected_language", code))
    }
}
