package com.example.routing

import com.example.data.BrusselsNetworkData
import com.example.model.*
import java.util.PriorityQueue

object GraphRoutingEngine {

    private data class Edge(
        val targetStationId: String,
        val lineId: String?,
        val mode: TransitMode,
        val durationMinutes: Int,
        val isStepFree: Boolean = true
    )

    private data class NodePath(
        val stationId: String,
        val totalCost: Int,
        val transfers: Int,
        val walkingMinutes: Int,
        val path: List<JourneySegment>
    ) : Comparable<NodePath> {
        override fun compareTo(other: NodePath): Int {
            return totalCost.compareTo(other.totalCost)
        }
    }

    fun calculateRoutes(
        originId: String,
        destinationId: String,
        stepFreeOnly: Boolean = false,
        disruptions: List<DisruptionAlert> = emptyList()
    ): List<JourneyPlan> {
        if (originId == destinationId) return emptyList()

        val originStation = BrusselsNetworkData.getStationById(originId) ?: return emptyList()
        val destStation = BrusselsNetworkData.getStationById(destinationId) ?: return emptyList()

        if (stepFreeOnly && (!originStation.isStepFree || !destStation.isStepFree)) {
            // Cannot route if start or end is not accessible
            return emptyList()
        }

        val graph = buildAdjacencyGraph(stepFreeOnly, disruptions)

        val plans = mutableListOf<JourneyPlan>()

        // 1. Calculate Fastest Path
        val fastestPath = findPath(graph, originId, destinationId, OptimizationGoal.FASTEST, stepFreeOnly)
        if (fastestPath != null) {
            plans.add(buildJourneyPlan("PLAN-FASTEST", originId, destinationId, fastestPath, disruptions))
        }

        // 2. Calculate Fewest Transfers Path
        val fewestTransfersPath = findPath(graph, originId, destinationId, OptimizationGoal.FEWEST_TRANSFERS, stepFreeOnly)
        if (fewestTransfersPath != null && (fastestPath == null || fewestTransfersPath != fastestPath)) {
            plans.add(buildJourneyPlan("PLAN-TRANSFERS", originId, destinationId, fewestTransfersPath, disruptions))
        }

        // If no plan, return empty
        return plans
    }

    private enum class OptimizationGoal {
        FASTEST,
        FEWEST_TRANSFERS
    }

    private fun buildAdjacencyGraph(
        stepFreeOnly: Boolean,
        disruptions: List<DisruptionAlert>
    ): Map<String, List<Edge>> {
        val adj = mutableMapOf<String, MutableList<Edge>>()

        fun addEdge(from: String, to: String, edge: Edge) {
            adj.getOrPut(from) { mutableListOf() }.add(edge)
        }

        val disruptedLineIds = disruptions.filter { it.severity == StatusSeverity.SUSPENDED }.flatMap { it.affectedLineIds }.toSet()
        val lineDelays = disruptions.filter { it.severity == StatusSeverity.MINOR_DELAY || it.severity == StatusSeverity.MAJOR_DELAY }
            .associate { alert ->
                val delay = if (alert.severity == StatusSeverity.MAJOR_DELAY) 10 else 5
                alert.affectedLineIds to delay
            }

        // Add line edges
        for (line in BrusselsNetworkData.lines) {
            if (disruptedLineIds.contains(line.id)) continue // Skip suspended lines

            var delayAddon = 0
            for ((lines, delay) in lineDelays) {
                if (lines.contains(line.id)) {
                    delayAddon += delay
                }
            }

            val stationIds = line.stationIds
            for (i in 0 until stationIds.size - 1) {
                val s1 = stationIds[i]
                val s2 = stationIds[i + 1]

                val st1 = BrusselsNetworkData.getStationById(s1)
                val st2 = BrusselsNetworkData.getStationById(s2)

                if (st1 == null || st2 == null) continue
                if (stepFreeOnly && (!st1.isStepFree || !st2.isStepFree)) continue

                val baseDuration = 2 + delayAddon
                addEdge(s1, s2, Edge(s2, line.id, line.type, baseDuration, st2.isStepFree))
                addEdge(s2, s1, Edge(s1, line.id, line.type, baseDuration, st1.isStepFree))
            }
        }

        // Add walking transfers between nearby stations or within interchange hubs
        val stations = BrusselsNetworkData.stations
        for (i in stations.indices) {
            for (j in i + 1 until stations.size) {
                val s1 = stations[i]
                val s2 = stations[j]
                val distance = calculateDistanceMeters(s1.lat, s1.lng, s2.lat, s2.lng)

                if (distance <= 400.0) { // Walkable interchange distance
                    val walkMinutes = (distance / 70.0).toInt().coerceAtLeast(2)
                    val isStepFreeWalk = s1.isStepFree && s2.isStepFree
                    if (!stepFreeOnly || isStepFreeWalk) {
                        addEdge(s1.id, s2.id, Edge(s2.id, null, TransitMode.WALK, walkMinutes, isStepFreeWalk))
                        addEdge(s2.id, s1.id, Edge(s1.id, null, TransitMode.WALK, walkMinutes, isStepFreeWalk))
                    }
                }
            }
        }

        return adj
    }

    private fun findPath(
        graph: Map<String, List<Edge>>,
        startId: String,
        targetId: String,
        goal: OptimizationGoal,
        stepFreeOnly: Boolean
    ): List<JourneySegment>? {
        val queue = PriorityQueue<NodePath>()
        val minCosts = mutableMapOf<Pair<String, String?>, Int>() // (stationId, currentLine) -> cost

        queue.add(NodePath(startId, 0, 0, 0, emptyList()))

        while (queue.isNotEmpty()) {
            val current = queue.poll() ?: break

            val lastLine = current.path.lastOrNull()?.lineId

            if (current.stationId == targetId) {
                return current.path
            }

            val stateKey = current.stationId to lastLine
            if (minCosts.containsKey(stateKey) && minCosts[stateKey]!! <= current.totalCost) {
                continue
            }
            minCosts[stateKey] = current.totalCost

            val edges = graph[current.stationId] ?: emptyList()
            for (edge in edges) {
                if (stepFreeOnly && !edge.isStepFree) continue

                val isTransfer = lastLine != null && edge.lineId != null && lastLine != edge.lineId
                val transferPenalty = if (isTransfer) 3 else 0
                val transferCountInc = if (isTransfer) 1 else 0

                val edgeWeight = when (goal) {
                    OptimizationGoal.FASTEST -> edge.durationMinutes + transferPenalty
                    OptimizationGoal.FEWEST_TRANSFERS -> edge.durationMinutes + (transferCountInc * 20)
                }

                val newWalkingMinutes = current.walkingMinutes + if (edge.mode == TransitMode.WALK) edge.durationMinutes else 0

                val newSegment = JourneySegment(
                    fromStationId = current.stationId,
                    toStationId = edge.targetStationId,
                    lineId = edge.lineId,
                    mode = edge.mode,
                    durationMinutes = edge.durationMinutes,
                    stopCount = 1,
                    isAccessible = edge.isStepFree
                )

                queue.add(
                    NodePath(
                        stationId = edge.targetStationId,
                        totalCost = current.totalCost + edgeWeight,
                        transfers = current.transfers + transferCountInc,
                        walkingMinutes = newWalkingMinutes,
                        path = current.path + newSegment
                    )
                )
            }
        }

        return null
    }

    private fun buildJourneyPlan(
        planId: String,
        originId: String,
        destinationId: String,
        rawSegments: List<JourneySegment>,
        disruptions: List<DisruptionAlert>
    ): JourneyPlan {
        // Consolidate consecutive segments on the same line
        val consolidated = mutableListOf<JourneySegment>()
        var current: JourneySegment? = null

        for (seg in rawSegments) {
            if (current == null) {
                current = seg
            } else if (current.lineId != null && current.lineId == seg.lineId && current.mode == seg.mode) {
                val intermediates = current.intermediateStationIds + current.toStationId
                current = current.copy(
                    toStationId = seg.toStationId,
                    durationMinutes = current.durationMinutes + seg.durationMinutes,
                    stopCount = current.stopCount + 1,
                    intermediateStationIds = intermediates
                )
            } else {
                consolidated.add(current)
                current = seg
            }
        }
        if (current != null) consolidated.add(current)

        val totalDuration = consolidated.sumOf { it.durationMinutes } + ((consolidated.size - 1).coerceAtLeast(0) * 2)
        val transfers = consolidated.count { it.lineId != null } - 1
        val walkingMinutes = consolidated.filter { it.mode == TransitMode.WALK }.sumOf { it.durationMinutes }
        val isAccessible = consolidated.all { it.isAccessible }

        val affectedStationIds = consolidated.flatMap { listOf(it.fromStationId, it.toStationId) + it.intermediateStationIds }
        val affectedLineIds = consolidated.mapNotNull { it.lineId }

        val matchingAlert = disruptions.find { alert ->
            alert.affectedLineIds.any { affectedLineIds.contains(it) } ||
            alert.affectedStationIds.any { affectedStationIds.contains(it) }
        }

        return JourneyPlan(
            journeyId = planId,
            originStationId = originId,
            destinationStationId = destinationId,
            totalDurationMinutes = totalDuration.coerceAtLeast(3),
            transfersCount = transfers.coerceAtLeast(0),
            walkingMinutes = walkingMinutes,
            isAccessible = isAccessible,
            segments = consolidated,
            isDisrupted = matchingAlert != null,
            disruptionMessage = matchingAlert?.description,
            alternativeAvailable = matchingAlert != null
        )
    }

    fun calculateDistanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0 // Earth radius in meters
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return r * c
    }
}
