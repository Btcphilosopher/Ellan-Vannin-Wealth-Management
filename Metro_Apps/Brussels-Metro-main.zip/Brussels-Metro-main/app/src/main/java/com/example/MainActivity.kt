package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.i18n.Localizer
import com.example.ui.components.*
import com.example.ui.theme.BrusselsCobalt
import com.example.ui.theme.BrusselsMetroTheme
import com.example.ui.theme.BrusselsNavy
import com.example.viewmodel.AppTab
import com.example.viewmodel.TransitViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: TransitViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            BrusselsMetroTheme {
                val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
                val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
                val selectedStation by viewModel.selectedStation.collectAsStateWithLifecycle()
                val originStation by viewModel.originStation.collectAsStateWithLifecycle()
                val destStation by viewModel.destStation.collectAsStateWithLifecycle()
                val stepFreeOnly by viewModel.stepFreeOnly.collectAsStateWithLifecycle()
                val alerts by viewModel.alerts.collectAsStateWithLifecycle()
                val calculatedRoutes by viewModel.calculatedRoutes.collectAsStateWithLifecycle()
                val activeJourney by viewModel.activeJourney.collectAsStateWithLifecycle()
                val isNavigating by viewModel.isNavigating.collectAsStateWithLifecycle()
                val currentNavStep by viewModel.currentNavStep.collectAsStateWithLifecycle()
                val vehicles by viewModel.vehiclePositions.collectAsStateWithLifecycle()
                val tickets by viewModel.tickets.collectAsStateWithLifecycle()
                val favourites by viewModel.favourites.collectAsStateWithLifecycle()
                val twinState by viewModel.digitalTwinState.collectAsStateWithLifecycle()

                Scaffold(
                    topBar = {
                        if (!isNavigating) {
                            BrusselsHeaderBar(
                                currentLanguage = currentLanguage,
                                onLanguageSelected = { viewModel.setLanguage(it) },
                                stepFreeOnly = stepFreeOnly,
                                onStepFreeToggled = { viewModel.setStepFreeOnly(it) },
                                disruptionCount = alerts.size,
                                onDisruptionClicked = { viewModel.setActiveTab(AppTab.STATUS) }
                            )
                        }
                    },
                    bottomBar = {
                        if (!isNavigating) {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface,
                                contentColor = MaterialTheme.colorScheme.onSurface,
                                tonalElevation = 0.dp,
                                modifier = Modifier
                                    .navigationBarsPadding()
                                    .testTag("bottom_navigation_bar")
                            ) {
                                NavigationBarItem(
                                    selected = activeTab == AppTab.HOME,
                                    onClick = { viewModel.setActiveTab(AppTab.HOME) },
                                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                                    label = { Text(Localizer.get(currentLanguage, "nav.home"), fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )

                                NavigationBarItem(
                                    selected = activeTab == AppTab.MAP,
                                    onClick = { viewModel.setActiveTab(AppTab.MAP) },
                                    icon = { Icon(Icons.Default.Map, contentDescription = null) },
                                    label = { Text(Localizer.get(currentLanguage, "nav.map"), fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )

                                NavigationBarItem(
                                    selected = activeTab == AppTab.PLANNER,
                                    onClick = { viewModel.setActiveTab(AppTab.PLANNER) },
                                    icon = { Icon(Icons.Default.AltRoute, contentDescription = null) },
                                    label = { Text(Localizer.get(currentLanguage, "nav.planner"), fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )

                                NavigationBarItem(
                                    selected = activeTab == AppTab.STATUS,
                                    onClick = { viewModel.setActiveTab(AppTab.STATUS) },
                                    icon = { Icon(Icons.Default.Warning, contentDescription = null) },
                                    label = { Text(Localizer.get(currentLanguage, "nav.status"), fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )

                                NavigationBarItem(
                                    selected = activeTab == AppTab.TICKETS,
                                    onClick = { viewModel.setActiveTab(AppTab.TICKETS) },
                                    icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = null) },
                                    label = { Text(Localizer.get(currentLanguage, "nav.tickets"), fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )

                                NavigationBarItem(
                                    selected = activeTab == AppTab.FAVOURITES,
                                    onClick = { viewModel.setActiveTab(AppTab.FAVOURITES) },
                                    icon = { Icon(Icons.Default.Favorite, contentDescription = null) },
                                    label = { Text(Localizer.get(currentLanguage, "nav.favourites"), fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )

                                NavigationBarItem(
                                    selected = activeTab == AppTab.DIGITAL_TWIN,
                                    onClick = { viewModel.setActiveTab(AppTab.DIGITAL_TWIN) },
                                    icon = { Icon(Icons.Default.Analytics, contentDescription = null) },
                                    label = { Text(Localizer.get(currentLanguage, "nav.digital_twin"), fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (isNavigating && activeJourney != null) {
                            LiveJourneyNavView(
                                plan = activeJourney!!,
                                currentStepIndex = currentNavStep,
                                currentLanguage = currentLanguage,
                                onNextStep = { viewModel.nextNavStep() },
                                onStopNavigation = { viewModel.stopJourneyNavigation() }
                            )
                        } else {
                            when (activeTab) {
                                AppTab.HOME -> HomeScreenView(
                                    currentLanguage = currentLanguage,
                                    originStation = originStation,
                                    destStation = destStation,
                                    onOriginSelected = { viewModel.setOriginStation(it) },
                                    onDestSelected = { viewModel.setDestinationStation(it) },
                                    onSwapClick = { viewModel.swapOriginAndDestination() },
                                    onPlanJourneyClick = { viewModel.setActiveTab(AppTab.PLANNER) },
                                    onOpenMapClick = { viewModel.setActiveTab(AppTab.MAP) },
                                    onStationClick = { viewModel.selectStation(it) },
                                    onOpenTicketsClick = { viewModel.setActiveTab(AppTab.TICKETS) },
                                    onOpenStatusClick = { viewModel.setActiveTab(AppTab.STATUS) }
                                )

                                AppTab.MAP -> InteractiveMetroMap(
                                    currentLanguage = currentLanguage,
                                    selectedStation = selectedStation,
                                    onStationSelected = { viewModel.selectStation(it) },
                                    vehicles = vehicles
                                )

                                AppTab.PLANNER -> JourneyPlannerView(
                                    currentLanguage = currentLanguage,
                                    originStation = originStation,
                                    destStation = destStation,
                                    routes = calculatedRoutes,
                                    stepFreeOnly = stepFreeOnly,
                                    onStepFreeToggled = { viewModel.setStepFreeOnly(it) },
                                    onStartNavigation = { viewModel.startJourneyNavigation(it) }
                                )

                                AppTab.STATUS -> DisruptionCenterView(
                                    currentLanguage = currentLanguage,
                                    alerts = alerts
                                )

                                AppTab.TICKETS -> DigitalTicketWalletView(
                                    currentLanguage = currentLanguage,
                                    tickets = tickets,
                                    onBuyTicket = { viewModel.buyTicket(it) }
                                )

                                AppTab.FAVOURITES -> FavouritesView(
                                    currentLanguage = currentLanguage,
                                    favourites = favourites,
                                    onSelectStation = {
                                        viewModel.selectStation(it)
                                        viewModel.setActiveTab(AppTab.MAP)
                                    },
                                    onRemoveFavourite = { viewModel.removeFavourite(it) }
                                )

                                AppTab.DIGITAL_TWIN -> OperationsDashboardView(
                                    currentLanguage = currentLanguage,
                                    digitalTwinState = twinState,
                                    vehicles = vehicles
                                )
                            }
                        }

                        // Station Detail Bottom Sheet
                        selectedStation?.let { st ->
                            StationDetailSheet(
                                station = st,
                                currentLanguage = currentLanguage,
                                departures = viewModel.getNextDeparturesForStation(st.id),
                                onSetAsOrigin = {
                                    viewModel.setOriginStation(it)
                                    viewModel.setActiveTab(AppTab.PLANNER)
                                },
                                onSetAsDestination = {
                                    viewModel.setDestinationStation(it)
                                    viewModel.setActiveTab(AppTab.PLANNER)
                                },
                                onAddFavourite = { viewModel.addFavourite(it, it.getName(currentLanguage)) },
                                onDismiss = { viewModel.selectStation(null) }
                            )
                        }
                    }
                }
            }
        }
    }
}
