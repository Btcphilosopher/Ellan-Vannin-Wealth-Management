package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Palette
val MinimalPrimary = Color(0xFF18181B)         // Deep Zinc
val MinimalOnPrimary = Color(0xFFFFFFFF)
val MinimalSecondary = Color(0xFF2563EB)       // Crisp Cobalt
val MinimalAccent = Color(0xFF0D9488)          // Modern Teal
val MinimalBackgroundLight = Color(0xFFFAFAFA) // Off-white canvas
val MinimalSurfaceLight = Color(0xFFFFFFFF)    // Pure white cards
val MinimalSurfaceVariantLight = Color(0xFFF4F4F5) // Light gray fills
val MinimalBorderLight = Color(0xFFE4E4E7)      // Crisp subtle border
val MinimalTextPrimaryLight = Color(0xFF09090B)   // Dark zinc text
val MinimalTextSecondaryLight = Color(0xFF71717A) // Slate text

val MinimalBackgroundDark = Color(0xFF09090B)    // Dark zinc canvas
val MinimalSurfaceDark = Color(0xFF18181B)       // Dark card background
val MinimalSurfaceVariantDark = Color(0xFF27272A) // Dark gray fills
val MinimalBorderDark = Color(0xFF3F3F46)       // Dark subtle border
val MinimalTextPrimaryDark = Color(0xFFFAFAFA)
val MinimalTextSecondaryDark = Color(0xFFA1A1AA)

// STIB/MIVB Transit Line Colors
val MetroLine1Color = Color(0xFFC61280) // Line 1 Magenta
val MetroLine2Color = Color(0xFFED6B00) // Line 2 Orange
val MetroLine5Color = Color(0xFFE59F00) // Line 5 Gold
val MetroLine6Color = Color(0xFF008ACA) // Line 6 Blue
val TramLine3Color = Color(0xFF62B22E)  // Line 3 Green
val TramLine4Color = Color(0xFFEA4C89)  // Line 4 Pink

// Status Colors
val MinimalSuccess = Color(0xFF10B981)
val MinimalWarning = Color(0xFFF59E0B)
val MinimalError = Color(0xFFEF4444)
val MinimalInfo = Color(0xFF3B82F6)

// Compatibility bindings for existing components
val BrusselsNavy = MinimalPrimary
val BrusselsNavyLight = MinimalSurfaceVariantDark
val BrusselsCobalt = MinimalSecondary
val BrusselsGold = MinimalWarning
val BrusselsEmerald = MinimalSuccess
val BrusselsCrimson = MinimalError
val SurfaceDark = MinimalBackgroundDark
val SurfaceCardDark = MinimalSurfaceDark
val TextPrimaryDark = MinimalTextPrimaryDark
val TextSecondaryDark = MinimalTextSecondaryDark


