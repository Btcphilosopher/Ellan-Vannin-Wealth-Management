package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BrusselsNetworkData
import com.example.i18n.Language
import com.example.i18n.Localizer
import com.example.model.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyPlannerView(
    currentLanguage: Language,
    originStation: Station,
    destStation: Station,
    routes: List<JourneyPlan>,
    stepFreeOnly: Boolean,
    onStepFreeToggled: (Boolean) -> Unit,
    onStartNavigation: (JourneyPlan) -> Unit,
    modifier: Modifier = Modifier
) {
    var expandedRouteId by remember { mutableStateOf<String?>(routes.firstOrNull()?.journeyId) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
    ) {
        // Title & Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = Localizer.get(currentLanguage, "planner.title"),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${originStation.getName(currentLanguage)}  ➔  ${destStation.getName(currentLanguage)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrusselsCobalt
                )
            }
        }

        // Accessibility Filter Chip
        item {
            FilterChip(
                selected = stepFreeOnly,
                onClick = { onStepFreeToggled(!stepFreeOnly) },
                label = { Text(Localizer.get(currentLanguage, "planner.accessible_only")) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Accessible,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                },
                modifier = Modifier.testTag("step_free_chip")
            )
        }

        // Route Options List
        if (routes.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = BrusselsGold, modifier = Modifier.size(40.dp))
                        Text(
                            text = Localizer.get(currentLanguage, "planner.no_route"),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        } else {
            items(routes.size) { index ->
                val plan = routes[index]
                val isExpanded = expandedRouteId == plan.journeyId

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        0.5.dp,
                        if (isExpanded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { expandedRouteId = if (isExpanded) null else plan.journeyId }
                        .testTag("route_option_card_$index")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Badge: FASTEST or FEWEST TRANSFERS
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = if (index == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (index == 0) Localizer.get(currentLanguage, "planner.fastest") else Localizer.get(currentLanguage, "planner.fewest_transfers"),
                                    color = if (index == 0) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            if (plan.isAccessible) {
                                Text("♿ Step-free", fontSize = 11.sp, color = MinimalSuccess, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Duration, Transfers, Walking
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Localizer.get(currentLanguage, "planner.duration", plan.totalDurationMinutes),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = Localizer.get(currentLanguage, "planner.transfers", plan.transfersCount),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = Localizer.get(currentLanguage, "planner.walk", plan.walkingMinutes),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Disruption Alert banner if route affected
                        if (plan.isDisrupted) {
                            Surface(
                                color = Color(0xFFEF4444).copy(alpha = 0.12f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEF4444))
                                    Text(
                                        text = plan.disruptionMessage ?: "Route affected by service alert",
                                        fontSize = 11.sp,
                                        color = Color(0xFFEF4444),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        // Expanded Step-by-Step Segments Timeline
                        AnimatedVisibility(visible = isExpanded) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Divider(color = MaterialTheme.colorScheme.outline)

                                plan.segments.forEachIndexed { segIdx, seg ->
                                    val fromStation = BrusselsNetworkData.getStationById(seg.fromStationId)
                                    val toStation = BrusselsNetworkData.getStationById(seg.toStationId)

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (seg.mode == TransitMode.WALK) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (seg.mode == TransitMode.WALK) Icons.Default.DirectionsWalk else Icons.Default.DirectionsSubway,
                                                contentDescription = null,
                                                tint = if (seg.mode == TransitMode.WALK) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onPrimary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${fromStation?.getName(currentLanguage)}  ➔  ${toStation?.getName(currentLanguage)}",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = if (seg.mode == TransitMode.WALK) "Walk ${seg.durationMinutes} min" else "${seg.lineId} (${seg.stopCount} stops • ${seg.durationMinutes} min)",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                // Button: START NAVIGATION
                                Button(
                                    onClick = { onStartNavigation(plan) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("start_navigation_btn")
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Text(
                                            text = Localizer.get(currentLanguage, "planner.start_navigation"),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
