package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BrusselsNetworkData
import com.example.db.AppDatabase
import com.example.i18n.Language
import com.example.model.*
import com.example.repository.TransitRepository
import com.example.routing.GraphRoutingEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppTab {
    HOME,
    MAP,
    PLANNER,
    STATUS,
    TICKETS,
    FAVOURITES,
    DIGITAL_TWIN
}

data class DigitalTwinState(
    val activeVehiclesCount: Int = 184,
    val networkHealthPct: Double = 96.7,
    val activeDisruptionsCount: Int = 2,
    val avgDelayMinutes: Double = 1.8,
    val dailyPassengers: Int = 412820
)

class TransitViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TransitRepository(AppDatabase.getInstance(application))

    private val _currentLanguage = MutableStateFlow(Language.EN_GB)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    private val _activeTab = MutableStateFlow(AppTab.HOME)
    val activeTab: StateFlow<AppTab> = _activeTab.asStateFlow()

    private val _selectedStation = MutableStateFlow<Station?>(null)
    val selectedStation: StateFlow<Station?> = _selectedStation.asStateFlow()

    private val _originStation = MutableStateFlow<Station>(BrusselsNetworkData.getStationById("G-CENTRAL")!!)
    val originStation: StateFlow<Station> = _originStation.asStateFlow()

    private val _destStation = MutableStateFlow<Station>(BrusselsNetworkData.getStationById("SCHUMAN")!!)
    val destStation: StateFlow<Station> = _destStation.asStateFlow()

    private val _stepFreeOnly = MutableStateFlow(false)
    val stepFreeOnly: StateFlow<Boolean> = _stepFreeOnly.asStateFlow()

    private val _alerts = MutableStateFlow<List<DisruptionAlert>>(BrusselsNetworkData.initialAlerts)
    val alerts: StateFlow<List<DisruptionAlert>> = _alerts.asStateFlow()

    private val _calculatedRoutes = MutableStateFlow<List<JourneyPlan>>(emptyList())
    val calculatedRoutes: StateFlow<List<JourneyPlan>> = _calculatedRoutes.asStateFlow()

    private val _activeJourney = MutableStateFlow<JourneyPlan?>(null)
    val activeJourney: StateFlow<JourneyPlan?> = _activeJourney.asStateFlow()

    private val _isNavigating = MutableStateFlow(false)
    val isNavigating: StateFlow<Boolean> = _isNavigating.asStateFlow()

    private val _currentNavStep = MutableStateFlow(0)
    val currentNavStep: StateFlow<Int> = _currentNavStep.asStateFlow()

    private val _vehiclePositions = MutableStateFlow<List<VehiclePosition>>(emptyList())
    val vehiclePositions: StateFlow<List<VehiclePosition>> = _vehiclePositions.asStateFlow()

    val favourites: StateFlow<List<UserFavourite>> = repository.favourites.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = BrusselsNetworkData.initialFavourites
    )

    val tickets: StateFlow<List<TicketPass>> = repository.tickets.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = BrusselsNetworkData.initialTickets
    )

    private val _digitalTwinState = MutableStateFlow(DigitalTwinState())
    val digitalTwinState: StateFlow<DigitalTwinState> = _digitalTwinState.asStateFlow()

    init {
        // Seed initial DB data if empty
        viewModelScope.launch {
            val savedLangCode = repository.getSavedLanguageCode()
            if (savedLangCode != null) {
                _currentLanguage.value = Language.fromCode(savedLangCode)
            }
            BrusselsNetworkData.initialFavourites.forEach { repository.saveFavourite(it) }
            BrusselsNetworkData.initialTickets.forEach { repository.saveTicket(it) }
            recalculateJourneyPlans()
        }

        // Start real-time digital twin train simulation loop
        startVehicleSimulation()
    }

    fun setLanguage(language: Language) {
        _currentLanguage.value = language
        viewModelScope.launch {
            repository.saveLanguageCode(language.code)
        }
    }

    fun setActiveTab(tab: AppTab) {
        _activeTab.value = tab
    }

    fun selectStation(station: Station?) {
        _selectedStation.value = station
    }

    fun setOriginStation(station: Station) {
        _originStation.value = station
        recalculateJourneyPlans()
    }

    fun setDestinationStation(station: Station) {
        _destStation.value = station
        recalculateJourneyPlans()
    }

    fun swapOriginAndDestination() {
        val temp = _originStation.value
        _originStation.value = _destStation.value
        _destStation.value = temp
        recalculateJourneyPlans()
    }

    fun setStepFreeOnly(enabled: Boolean) {
        _stepFreeOnly.value = enabled
        recalculateJourneyPlans()
    }

    fun recalculateJourneyPlans() {
        val routes = GraphRoutingEngine.calculateRoutes(
            originId = _originStation.value.id,
            destinationId = _destStation.value.id,
            stepFreeOnly = _stepFreeOnly.value,
            disruptions = _alerts.value
        )
        _calculatedRoutes.value = routes
    }

    fun startJourneyNavigation(plan: JourneyPlan) {
        _activeJourney.value = plan
        _isNavigating.value = true
        _currentNavStep.value = 0
        _activeTab.value = AppTab.PLANNER
    }

    fun stopJourneyNavigation() {
        _isNavigating.value = false
        _activeJourney.value = null
        _currentNavStep.value = 0
    }

    fun nextNavStep() {
        val journey = _activeJourney.value ?: return
        if (_currentNavStep.value < journey.segments.size - 1) {
            _currentNavStep.value += 1
        }
    }

    fun buyTicket(type: TicketType) {
        val newTicket = when (type) {
            TicketType.SINGLE_JOURNEY -> TicketPass(
                id = "TKT-${System.currentTimeMillis() % 10000}",
                type = TicketType.SINGLE_JOURNEY,
                titleKey = "tickets.single",
                validFrom = "Just now",
                validUntil = "In 60 min",
                qrCodeToken = "STIB-BRU-${System.currentTimeMillis()}-S1",
                isActive = true,
                priceEur = 2.60
            )
            TicketType.DAY_PASS_24H -> TicketPass(
                id = "TKT-${System.currentTimeMillis() % 10000}",
                type = TicketType.DAY_PASS_24H,
                titleKey = "tickets.day_pass",
                validFrom = "Just now",
                validUntil = "24 Hours from activation",
                qrCodeToken = "STIB-BRU-${System.currentTimeMillis()}-24H",
                isActive = true,
                priceEur = 8.40
            )
            TicketType.MULTI_10_JOURNEY -> TicketPass(
                id = "TKT-${System.currentTimeMillis() % 10000}",
                type = TicketType.MULTI_10_JOURNEY,
                titleKey = "tickets.multi_10",
                validFrom = "10 Rides Pass",
                validUntil = "10 Rides Remaining",
                qrCodeToken = "STIB-BRU-${System.currentTimeMillis()}-M10",
                isActive = true,
                priceEur = 16.80
            )
            TicketType.AIRPORT_LINE -> TicketPass(
                id = "TKT-${System.currentTimeMillis() % 10000}",
                type = TicketType.AIRPORT_LINE,
                titleKey = "tickets.airport",
                validFrom = "Express Airport Line",
                validUntil = "Valid for 1 Journey",
                qrCodeToken = "STIB-BRU-${System.currentTimeMillis()}-AIR",
                isActive = true,
                priceEur = 7.00
            )
            TicketType.CITY_PASS -> TicketPass(
                id = "TKT-${System.currentTimeMillis() % 10000}",
                type = TicketType.CITY_PASS,
                titleKey = "tickets.tourist",
                validFrom = "Brussels City Pass",
                validUntil = "48 Hours Unlimited",
                qrCodeToken = "STIB-BRU-${System.currentTimeMillis()}-CP",
                isActive = true,
                priceEur = 24.00
            )
        }
        viewModelScope.launch {
            repository.saveTicket(newTicket)
        }
    }

    fun addFavourite(station: Station, label: String) {
        val fav = UserFavourite(
            id = "FAV-${System.currentTimeMillis()}",
            label = label,
            stationId = station.id,
            iconName = "place"
        )
        viewModelScope.launch {
            repository.saveFavourite(fav)
        }
    }

    fun removeFavourite(id: String) {
        viewModelScope.launch {
            repository.removeFavourite(id)
        }
    }

    private fun startVehicleSimulation() {
        viewModelScope.launch {
            var simStep = 0
            while (true) {
                delay(1500)
                simStep = (simStep + 1) % 100

                // Move simulated trains along line segments
                val updatedVehicles = mutableListOf<VehiclePosition>()

                for ((idx, line) in BrusselsNetworkData.lines.withIndex()) {
                    if (line.stationIds.size >= 2) {
                        val st1 = BrusselsNetworkData.getStationById(line.stationIds[simStep % (line.stationIds.size - 1)])
                        val st2 = BrusselsNetworkData.getStationById(line.stationIds[(simStep % (line.stationIds.size - 1)) + 1])

                        if (st1 != null && st2 != null) {
                            val progress = ((simStep * 10) % 100) / 100f
                            val currentLat = st1.lat + (st2.lat - st1.lat) * progress
                            val currentLng = st1.lng + (st2.lng - st1.lng) * progress

                            updatedVehicles.add(
                                VehiclePosition(
                                    vehicleId = "MTR-${line.number}-${101 + idx}",
                                    lineId = line.id,
                                    currentStationId = st1.id,
                                    nextStationId = st2.id,
                                    progress = progress,
                                    lat = currentLat,
                                    lng = currentLng,
                                    delayMinutes = if (line.id == "Line 5") 5 else 0
                                )
                            )
                        }
                    }
                }

                _vehiclePositions.value = updatedVehicles

                // Dynamic update of Digital Twin telemetry metrics
                val activeCount = 180 + (simStep % 12)
                val health = 96.0 + ((simStep % 15) / 10.0)
                _digitalTwinState.value = DigitalTwinState(
                    activeVehiclesCount = activeCount,
                    networkHealthPct = health,
                    activeDisruptionsCount = _alerts.value.size,
                    avgDelayMinutes = 1.4 + ((simStep % 10) / 10.0),
                    dailyPassengers = 412820 + (simStep * 150)
                )
            }
        }
    }

    fun getNextDeparturesForStation(stationId: String): List<DepartureInfo> {
        val station = BrusselsNetworkData.getStationById(stationId) ?: return emptyList()
        val departures = mutableListOf<DepartureInfo>()

        for (lineId in station.lines) {
            val line = BrusselsNetworkData.getLineById(lineId) ?: continue
            val firstStation = BrusselsNetworkData.getStationById(line.stationIds.first())?.getName(_currentLanguage.value) ?: ""
            val lastStation = BrusselsNetworkData.getStationById(line.stationIds.last())?.getName(_currentLanguage.value) ?: ""

            departures.add(
                DepartureInfo(
                    lineId = line.id,
                    destination = lastStation,
                    minutesAway = (2..8).random(),
                    isRealtime = true
                )
            )
            departures.add(
                DepartureInfo(
                    lineId = line.id,
                    destination = firstStation,
                    minutesAway = (5..14).random(),
                    isRealtime = true
                )
            )
        }
        return departures.sortedBy { it.minutesAway }
    }
}
