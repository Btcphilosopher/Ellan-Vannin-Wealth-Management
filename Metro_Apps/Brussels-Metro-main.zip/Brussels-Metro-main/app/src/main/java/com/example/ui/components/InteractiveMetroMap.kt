package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BrusselsNetworkData
import com.example.i18n.Language
import com.example.model.Station
import com.example.model.VehiclePosition
import com.example.ui.theme.*

@Composable
fun InteractiveMetroMap(
    currentLanguage: Language,
    selectedStation: Station?,
    onStationSelected: (Station) -> Unit,
    vehicles: List<VehiclePosition>,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.6f, 3.0f)
        offset += offsetChange
    }

    val minLat = 50.8100
    val maxLat = 50.9000
    val minLng = 4.2500
    val maxLng = 4.4700

    fun mapToScreen(lat: Double, lng: Double, canvasWidth: Float, canvasHeight: Float): Offset {
        val xNorm = ((lng - minLng) / (maxLng - minLng)).toFloat()
        val yNorm = (1.0f - ((lat - minLat) / (maxLat - minLat))).toFloat() // invert lat for screen y

        val baseX = xNorm * canvasWidth
        val baseY = yNorm * canvasHeight

        return Offset(
            x = (baseX - canvasWidth / 2) * scale + canvasWidth / 2 + offset.x,
            y = (baseY - canvasHeight / 2) * scale + canvasHeight / 2 + offset.y
        )
    }

    val mapBgColor = MaterialTheme.colorScheme.background
    val stationInnerColor = MaterialTheme.colorScheme.surface

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(mapBgColor)
            .testTag("interactive_metro_map")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .transformable(state = state)
                .pointerInput(scale, offset) {
                    detectTapGestures { tapOffset ->
                        val canvasWidth = size.width.toFloat()
                        val canvasHeight = size.height.toFloat()

                        // Find closest station
                        var closest: Station? = null
                        var minDist = Float.MAX_VALUE

                        for (st in BrusselsNetworkData.stations) {
                            val pos = mapToScreen(st.lat, st.lng, canvasWidth, canvasHeight)
                            val dist = (pos - tapOffset).getDistance()
                            if (dist < 40f * scale && dist < minDist) {
                                minDist = dist
                                closest = st
                            }
                        }

                        if (closest != null) {
                            onStationSelected(closest)
                        }
                    }
                }
        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // 1. Draw Line Paths
            for (line in BrusselsNetworkData.lines) {
                val lineColor = when (line.id) {
                    "Line 1" -> MetroLine1Color
                    "Line 2" -> MetroLine2Color
                    "Line 5" -> MetroLine5Color
                    "Line 6" -> MetroLine6Color
                    "Line 3" -> TramLine3Color
                    "Line 4" -> TramLine4Color
                    else -> Color.Gray
                }

                val path = Path()
                var first = true

                for (stationId in line.stationIds) {
                    val st = BrusselsNetworkData.getStationById(stationId) ?: continue
                    val pos = mapToScreen(st.lat, st.lng, canvasWidth, canvasHeight)

                    if (first) {
                        path.moveTo(pos.x, pos.y)
                        first = false
                    } else {
                        path.lineTo(pos.x, pos.y)
                    }
                }

                drawPath(
                    path = path,
                    color = lineColor,
                    style = Stroke(
                        width = 8.dp.toPx() * scale,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }

            // 2. Draw Stations
            for (st in BrusselsNetworkData.stations) {
                val pos = mapToScreen(st.lat, st.lng, canvasWidth, canvasHeight)
                val isSelected = selectedStation?.id == st.id

                val baseRadius = if (st.isInterchange) 9.dp.toPx() * scale else 6.dp.toPx() * scale

                // Halo glow for selected station
                if (isSelected) {
                    drawCircle(
                        color = BrusselsGold,
                        radius = baseRadius * 2.2f,
                        center = pos
                    )
                }

                // Station Ring
                drawCircle(
                    color = Color.White,
                    radius = baseRadius,
                    center = pos
                )

                drawCircle(
                    color = stationInnerColor,
                    radius = baseRadius * 0.6f,
                    center = pos
                )

                if (st.isInterchange) {
                    drawCircle(
                        color = Color.White,
                        radius = baseRadius * 0.3f,
                        center = pos
                    )
                }
            }

            // 3. Draw Live Animated Trains
            for (v in vehicles) {
                val pos = mapToScreen(v.lat, v.lng, canvasWidth, canvasHeight)

                // Train Dot
                drawCircle(
                    color = BrusselsGold,
                    radius = 8.dp.toPx() * scale,
                    center = pos
                )
                drawCircle(
                    color = Color.Black,
                    radius = 5.dp.toPx() * scale,
                    center = pos
                )
            }
        }

        // Map Overlay Controls (Zoom +, Zoom -, Reset)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FloatingActionButton(
                onClick = { scale = (scale * 1.25f).coerceAtMost(3.0f) },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(40.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In")
            }

            FloatingActionButton(
                onClick = { scale = (scale * 0.8f).coerceAtLeast(0.6f) },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(40.dp)
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out")
            }

            FloatingActionButton(
                onClick = {
                    scale = 1.0f
                    offset = Offset.Zero
                },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.size(40.dp)
            ) {
                Icon(Icons.Default.MyLocation, contentDescription = "Reset Center")
            }
        }

        // Map Legend
        Surface(
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
            shape = RoundedCornerShape(8.dp),
            tonalElevation = 2.dp,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    "BRUSSELS METRO",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).background(MetroLine1Color, RoundedCornerShape(2.dp)))
                    Text("L1", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                    Box(modifier = Modifier.size(10.dp).background(MetroLine2Color, RoundedCornerShape(2.dp)))
                    Text("L2", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                    Box(modifier = Modifier.size(10.dp).background(MetroLine5Color, RoundedCornerShape(2.dp)))
                    Text("L5", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                    Box(modifier = Modifier.size(10.dp).background(MetroLine6Color, RoundedCornerShape(2.dp)))
                    Text("L6", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}
