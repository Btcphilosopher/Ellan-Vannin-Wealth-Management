package com.example.data

import com.example.model.*

object BrusselsNetworkData {

    val stations: List<Station> = listOf(
        // Core Interchange Stations
        Station(
            id = "G-WEST",
            nameNl = "Weststation",
            nameFr = "Gare de l'Ouest",
            nameDe = "Westbahnhof",
            nameWa = "Gåre di l' Ouest",
            nameEn = "West Station",
            lat = 50.8489, lng = 4.3214,
            lines = listOf("Line 1", "Line 2", "Line 5", "Line 6"),
            platforms = listOf("Voie 1", "Voie 2", "Voie 3", "Voie 4"),
            entrances = listOf(
                StationEntrance("E1", "Chaussée de Ninove", 50.8490, 4.3215),
                StationEntrance("E2", "Rue Alfonso 13", 50.8488, 4.3212)
            ),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TOILETS, Facility.TACTILE_GUIDANCE, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.SNCB, "SNCB Train", "S-Train S10 / S2"),
                StationConnection(TransitMode.BUS, "Bus 86", "Machelen"),
                StationConnection(TransitMode.TRAM, "Tram 82", "Berchem")
            ),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "BEEKKANT",
            nameNl = "Beekkant",
            nameFr = "Beekkant",
            nameDe = "Beekkant",
            nameWa = "Beekkant",
            nameEn = "Beekkant",
            lat = 50.8532, lng = 4.3228,
            lines = listOf("Line 1", "Line 2", "Line 5", "Line 6"),
            platforms = listOf("Quai A", "Quai B", "Quai C"),
            entrances = listOf(StationEntrance("E1", "Rue de la Démocratie", 50.8533, 4.3229)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TACTILE_GUIDANCE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.BUS, "Bus 87", "Simonis")),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "DEBROUCKERE",
            nameNl = "De Brouckère",
            nameFr = "De Brouckère",
            nameDe = "De Brouckère",
            nameWa = "De Brouckère",
            nameEn = "De Brouckere",
            lat = 50.8511, lng = 4.3533,
            lines = listOf("Line 1", "Line 5", "Line 3", "Line 4"),
            platforms = listOf("Quai Metro 1-5", "Quai Tram 3-4"),
            entrances = listOf(
                StationEntrance("E1", "Place de Brouckère", 50.8512, 4.3534),
                StationEntrance("E2", "Rue Anspach", 50.8510, 4.3531)
            ),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TOILETS, Facility.TACTILE_GUIDANCE, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.BUS, "Bus 88", "Heysel"),
                StationConnection(TransitMode.BUS, "Bus 29", "Hunderenveld")
            ),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "G-CENTRAL",
            nameNl = "Centraal Station",
            nameFr = "Gare Centrale",
            nameDe = "Hauptbahnhof",
            nameWa = "Gåre Centrâle",
            nameEn = "Brussels Central Station",
            lat = 50.8456, lng = 4.3572,
            lines = listOf("Line 1", "Line 5"),
            platforms = listOf("Voie A", "Voie B"),
            entrances = listOf(
                StationEntrance("E1", "Galerie Ravenstein", 50.8458, 4.3575),
                StationEntrance("E2", "Carrefour de l'Europe", 50.8454, 4.3570)
            ),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TOILETS, Facility.TACTILE_GUIDANCE, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.SNCB, "SNCB National / International", "Antwerpen, Gent, Namur, Charleroi"),
                StationConnection(TransitMode.BUS, "Bus 38", "Héroïsme"),
                StationConnection(TransitMode.BUS, "Bus 71", "Delta")
            ),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "ARTS-LOI",
            nameNl = "Kunst-Wet",
            nameFr = "Arts-Loi",
            nameDe = "Kunst-Gesetz",
            nameWa = "Årts-Lwè",
            nameEn = "Arts-Loi",
            lat = 50.8468, lng = 4.3688,
            lines = listOf("Line 1", "Line 2", "Line 5", "Line 6"),
            platforms = listOf("Niveau -1 (1-5)", "Niveau -2 (2-6)"),
            entrances = listOf(
                StationEntrance("E1", "Avenue des Arts", 50.8470, 4.3690),
                StationEntrance("E2", "Rue de la Loi", 50.8466, 4.3686)
            ),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TACTILE_GUIDANCE, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.BUS, "Bus 22", "Montgomery")
            ),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "SCHUMAN",
            nameNl = "Schuman",
            nameFr = "Schuman",
            nameDe = "Schuman (EU Quarter)",
            nameWa = "Schuman",
            nameEn = "Schuman (European Quarter)",
            lat = 50.8428, lng = 4.3811,
            lines = listOf("Line 1", "Line 5"),
            platforms = listOf("Quai 1", "Quai 2"),
            entrances = listOf(
                StationEntrance("E1", "Rond-Point Schuman", 50.8430, 4.3814),
                StationEntrance("E2", "Berlaymont / EU Commission", 50.8426, 4.3808)
            ),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TOILETS, Facility.TACTILE_GUIDANCE, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.SNCB, "SNCB European Rail", "Brussels Airport, Namur, Luxembourg"),
                StationConnection(TransitMode.BUS, "Bus 12 Express", "Brussels Airport Direct")
            ),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "MERODE",
            nameNl = "Mérode",
            nameFr = "Mérode",
            nameDe = "Mérode",
            nameWa = "Mérode",
            nameEn = "Merode",
            lat = 50.8396, lng = 4.3985,
            lines = listOf("Line 1", "Line 5"),
            platforms = listOf("Quai A", "Quai B"),
            entrances = listOf(StationEntrance("E1", "Avenue de Tervueren", 50.8398, 4.3988)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TACTILE_GUIDANCE, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.TRAM, "Tram 81", "Montgomery"),
                StationConnection(TransitMode.SNCB, "SNCB Local", "S4 / S7")
            ),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "G-MIDI",
            nameNl = "Zuidstation",
            nameFr = "Gare du Midi",
            nameDe = "Südbahnhof",
            nameWa = "Gåre do Miedi",
            nameEn = "Brussels South (Midi) Station",
            lat = 50.8358, lng = 4.3361,
            lines = listOf("Line 2", "Line 6", "Line 3", "Line 4"),
            platforms = listOf("Voie 1", "Voie 2", "Voie 3", "Voie 4"),
            entrances = listOf(
                StationEntrance("E1", "Eurostar / Thalys Terminal", 50.8360, 4.3365),
                StationEntrance("E2", "Avenue Fonsny", 50.8355, 4.3358)
            ),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TOILETS, Facility.TACTILE_GUIDANCE, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.TRAIN, "Eurostar / TGV / ICE", "London, Paris, Amsterdam, Köln"),
                StationConnection(TransitMode.SNCB, "SNCB National Hub", "All Belgian destinations"),
                StationConnection(TransitMode.TRAM, "Tram 51", "Stalle")
            ),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "ROGIER",
            nameNl = "Rogier",
            nameFr = "Rogier",
            nameDe = "Rogier",
            nameWa = "Rogier",
            nameEn = "Rogier",
            lat = 50.8558, lng = 4.3582,
            lines = listOf("Line 2", "Line 6", "Line 3", "Line 4"),
            platforms = listOf("Quai 1", "Quai 2", "Quai 3"),
            entrances = listOf(StationEntrance("E1", "Place Rogier", 50.8560, 4.3585)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TACTILE_GUIDANCE, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.BUS, "Bus 58", "Vilvoorde"),
                StationConnection(TransitMode.TRAM, "Tram 25", "Boitsfort")
            ),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "SIMONIS",
            nameNl = "Simonis",
            nameFr = "Simonis",
            nameDe = "Simonis",
            nameWa = "Simonis",
            nameEn = "Simonis",
            lat = 50.8631, lng = 4.3312,
            lines = listOf("Line 2", "Line 6"),
            platforms = listOf("Quai Elizabeth", "Quai Leopold"),
            entrances = listOf(StationEntrance("E1", "Place Simonis", 50.8633, 4.3315)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.TRAM, "Tram 19", "Groot-Bijgaarden"),
                StationConnection(TransitMode.SNCB, "SNCB Simonis", "S10")
            ),
            isInterchange = true, isStepFree = true
        ),

        // Line 1 / 5 West branch
        Station(
            id = "ERASME",
            nameNl = "Erasmus",
            nameFr = "Érasme",
            nameDe = "Erasmus",
            nameWa = "Érasme",
            nameEn = "Erasmus",
            lat = 50.8152, lng = 4.2625,
            lines = listOf("Line 5"),
            platforms = listOf("Quai 1"),
            entrances = listOf(StationEntrance("E1", "Hôpital Érasme", 50.8154, 4.2627)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.BUS, "Bus 74", "Uccle")),
            isStepFree = true
        ),
        Station(
            id = "ST-GUIDON",
            nameNl = "Sint-Guido",
            nameFr = "Saint-Guidon",
            nameDe = "Sankt Guido",
            nameWa = "Sint-Guido",
            nameEn = "Saint-Guidon",
            lat = 50.8340, lng = 4.3015,
            lines = listOf("Line 5"),
            platforms = listOf("Quai 1", "Quai 2"),
            entrances = listOf(StationEntrance("E1", "Place Vaillance", 50.8342, 4.3018)),
            facilities = listOf(Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.TRAM, "Tram 81", "Marius Renard")),
            isStepFree = true
        ),
        Station(
            id = "STE-CATHERINE",
            nameNl = "Sint-Katelijne",
            nameFr = "Sainte-Catherine",
            nameDe = "Sankt Katharina",
            nameWa = "Sinte-Catrene",
            nameEn = "Sainte-Catherine",
            lat = 50.8502, lng = 4.3482,
            lines = listOf("Line 1", "Line 5"),
            platforms = listOf("Quai 1", "Quai 2"),
            entrances = listOf(StationEntrance("E1", "Place Sainte-Catherine", 50.8504, 4.3485)),
            facilities = listOf(Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TACTILE_GUIDANCE, Facility.STEP_FREE),
            connections = emptyList(),
            isStepFree = true
        ),
        Station(
            id = "PARC",
            nameNl = "Park",
            nameFr = "Parc",
            nameDe = "Park",
            nameWa = "Pårk",
            nameEn = "Park",
            lat = 50.8451, lng = 4.3629,
            lines = listOf("Line 1", "Line 5"),
            platforms = listOf("Quai A", "Quai B"),
            entrances = listOf(StationEntrance("E1", "Rue de la Loi", 50.8453, 4.3631)),
            facilities = listOf(Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.TRAM, "Tram 92", "Fort-Jaco")),
            isStepFree = true
        ),
        Station(
            id = "MONTGOMERY",
            nameNl = "Montgomery",
            nameFr = "Montgomery",
            nameDe = "Montgomery",
            nameWa = "Montgomery",
            nameEn = "Montgomery",
            lat = 50.8378, lng = 4.4062,
            lines = listOf("Line 1"),
            platforms = listOf("Quai Metro 1", "Quai Tram 39/44"),
            entrances = listOf(StationEntrance("E1", "Square Montgomery", 50.8380, 4.4065)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.TRAM, "Tram 7", "Vanderkindere"),
                StationConnection(TransitMode.TRAM, "Tram 39", "Ban-Eik")
            ),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "STOCKEL",
            nameNl = "Stokkel",
            nameFr = "Stockel",
            nameDe = "Stockel",
            nameWa = "Stokkel",
            nameEn = "Stockel",
            lat = 50.8415, lng = 4.4648,
            lines = listOf("Line 1"),
            platforms = listOf("Quai Terminus"),
            entrances = listOf(StationEntrance("E1", "Place Dumon", 50.8417, 4.4650)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.TRAM, "Tram 39", "Montgomery")),
            isStepFree = true
        ),

        // Line 5 East branch
        Station(
            id = "HERRMANN-DEBROUX",
            nameNl = "Herrmann-Debroux",
            nameFr = "Herrmann-Debroux",
            nameDe = "Herrmann-Debroux",
            nameWa = "Herrmann-Debroux",
            nameEn = "Herrmann-Debroux",
            lat = 50.8122, lng = 4.4285,
            lines = listOf("Line 5"),
            platforms = listOf("Quai Terminus"),
            entrances = listOf(StationEntrance("E1", "Boulevard du Souverain", 50.8124, 4.4288)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.TRAM, "Tram 8", "Roodebeek")),
            isStepFree = true
        ),
        Station(
            id = "DELTA",
            nameNl = "Delta",
            nameFr = "Delta",
            nameDe = "Delta",
            nameWa = "Delta",
            nameEn = "Delta",
            lat = 50.8188, lng = 4.3988,
            lines = listOf("Line 5"),
            platforms = listOf("Quai A", "Quai B"),
            entrances = listOf(StationEntrance("E1", "ULB Campus Plaine", 50.8190, 4.3990)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.BUS, "Bus 71", "Gare Centrale")),
            isStepFree = true
        ),

        // Line 2/6 Stations
        Station(
            id = "LOUISE",
            nameNl = "Louiza",
            nameFr = "Louise",
            nameDe = "Louise",
            nameWa = "Louijhe",
            nameEn = "Louise",
            lat = 50.8352, lng = 4.3562,
            lines = listOf("Line 2", "Line 6"),
            platforms = listOf("Quai 1", "Quai 2"),
            entrances = listOf(StationEntrance("E1", "Place Louise", 50.8354, 4.3565)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.TRAM, "Tram 92 / 93", "Place Royale")),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "BOTANIQUE",
            nameNl = "Kruidtuin",
            nameFr = "Botanique",
            nameDe = "Botanischer Garten",
            nameWa = "Botanike",
            nameEn = "Botanique",
            lat = 50.8542, lng = 4.3658,
            lines = listOf("Line 2", "Line 6"),
            platforms = listOf("Quai 1", "Quai 2"),
            entrances = listOf(StationEntrance("E1", "Rue Royale", 50.8544, 4.3660)),
            facilities = listOf(Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.TRAM, "Tram 92", "Schaerbeek")),
            isStepFree = true
        ),
        Station(
            id = "PORTE-DE-HAL",
            nameNl = "Hallepoort",
            nameFr = "Porte de Hal",
            nameDe = "Haller Tor",
            nameWa = "Pôrtis di Hal",
            nameEn = "Porte de Hal",
            lat = 50.8335, lng = 4.3428,
            lines = listOf("Line 2", "Line 6", "Line 3", "Line 4"),
            platforms = listOf("Quai Metro 2-6", "Quai Pre-metro 3-4"),
            entrances = listOf(StationEntrance("E1", "Boulevard de Jaer", 50.8337, 4.3430)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.TRAM, "Tram 51", "Van Haelen")),
            isInterchange = true, isStepFree = true
        ),

        // Line 6 North
        Station(
            id = "ROI-BAUDOUIN",
            nameNl = "Koning Boudewijn",
            nameFr = "Roi Baudouin",
            nameDe = "König Baudouin",
            nameWa = "Mwa Bodoen",
            nameEn = "King Baudouin",
            lat = 50.8962, lng = 4.3312,
            lines = listOf("Line 6"),
            platforms = listOf("Quai Terminus"),
            entrances = listOf(StationEntrance("E1", "Stade Roi Baudouin", 50.8964, 4.3315)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.BUS, "Bus 83", "Berchem")),
            isStepFree = true
        ),
        Station(
            id = "HEYSEL",
            nameNl = "Heizel",
            nameFr = "Heysel",
            nameDe = "Heysel (Atomium)",
            nameWa = "Heysel",
            nameEn = "Heysel (Atomium)",
            lat = 50.8968, lng = 4.3388,
            lines = listOf("Line 6"),
            platforms = listOf("Quai 1", "Quai 2"),
            entrances = listOf(StationEntrance("E1", "Atomium Square", 50.8970, 4.3390)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.TRAM, "Tram 7", "Vanderkindere")),
            isStepFree = true
        ),

        // Pre-metro North-South
        Station(
            id = "G-NORD",
            nameNl = "Noordstation",
            nameFr = "Gare du Nord",
            nameDe = "Nordbahnhof",
            nameWa = "Gåre do Nord",
            nameEn = "Brussels North Station",
            lat = 50.8601, lng = 4.3608,
            lines = listOf("Line 3", "Line 4"),
            platforms = listOf("Quai Pre-metro A", "Quai Pre-metro B"),
            entrances = listOf(StationEntrance("E1", "CCN Terminal", 50.8603, 4.3610)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.TOILETS, Facility.STEP_FREE),
            connections = listOf(
                StationConnection(TransitMode.SNCB, "SNCB Mainlines", "Antwerpen, Leuven, Liège"),
                StationConnection(TransitMode.BUS, "De Lijn Express Bus", "Flemish Brabant")
            ),
            isInterchange = true, isStepFree = true
        ),
        Station(
            id = "ALBERT",
            nameNl = "Albert",
            nameFr = "Albert",
            nameDe = "Albert",
            nameWa = "Albert",
            nameEn = "Albert",
            lat = 50.8222, lng = 4.3415,
            lines = listOf("Line 3", "Line 4"),
            platforms = listOf("Quai 1", "Quai 2"),
            entrances = listOf(StationEntrance("E1", "Place Albert", 50.8224, 4.3418)),
            facilities = listOf(Facility.ELEVATOR, Facility.ESCALATOR, Facility.TICKET_MACHINE, Facility.STEP_FREE),
            connections = listOf(StationConnection(TransitMode.TRAM, "Tram 51", "Alsemberg")),
            isStepFree = true
        )
    )

    val lines: List<Line> = listOf(
        Line(
            id = "Line 1",
            number = "1",
            name = "Gare de l'Ouest ↔ Stockel",
            type = TransitMode.METRO,
            colorHex = "#C61280",
            stationIds = listOf("G-WEST", "BEEKKANT", "STE-CATHERINE", "DEBROUCKERE", "G-CENTRAL", "PARC", "ARTS-LOI", "SCHUMAN", "MERODE", "MONTGOMERY", "STOCKEL"),
            statusSeverity = StatusSeverity.NORMAL,
            statusMessage = "Normal service / Normale bediening"
        ),
        Line(
            id = "Line 2",
            number = "2",
            name = "Simonis ↔ Elisabeth (Loop)",
            type = TransitMode.METRO,
            colorHex = "#ED6B00",
            stationIds = listOf("SIMONIS", "G-WEST", "G-MIDI", "PORTE-DE-HAL", "LOUISE", "ARTS-LOI", "BOTANIQUE", "ROGIER", "SIMONIS"),
            statusSeverity = StatusSeverity.NORMAL,
            statusMessage = "Normal service / Normale bediening"
        ),
        Line(
            id = "Line 5",
            number = "5",
            name = "Érasme ↔ Herrmann-Debroux",
            type = TransitMode.METRO,
            colorHex = "#E59F00",
            stationIds = listOf("ERASME", "ST-GUIDON", "G-WEST", "BEEKKANT", "STE-CATHERINE", "DEBROUCKERE", "G-CENTRAL", "PARC", "ARTS-LOI", "SCHUMAN", "MERODE", "DELTA", "HERRMANN-DEBROUX"),
            statusSeverity = StatusSeverity.MINOR_DELAY,
            statusMessage = "Minor delays (Signal maintenance near Schuman)"
        ),
        Line(
            id = "Line 6",
            number = "6",
            name = "Roi Baudouin ↔ Elisabeth",
            type = TransitMode.METRO,
            colorHex = "#008ACA",
            stationIds = listOf("ROI-BAUDOUIN", "HEYSEL", "SIMONIS", "G-WEST", "G-MIDI", "PORTE-DE-HAL", "LOUISE", "ARTS-LOI", "ROGIER"),
            statusSeverity = StatusSeverity.NORMAL,
            statusMessage = "Normal service / Normale bediening"
        ),
        Line(
            id = "Line 3",
            number = "3",
            name = "Gare du Nord ↔ Albert (Pre-metro)",
            type = TransitMode.TRAM,
            colorHex = "#62B22E",
            stationIds = listOf("G-NORD", "ROGIER", "DEBROUCKERE", "G-MIDI", "PORTE-DE-HAL", "ALBERT"),
            statusSeverity = StatusSeverity.NORMAL,
            statusMessage = "Normal service / Normale bediening"
        ),
        Line(
            id = "Line 4",
            number = "4",
            name = "Gare du Nord ↔ Stalle (Pre-metro)",
            type = TransitMode.TRAM,
            colorHex = "#EA4C89",
            stationIds = listOf("G-NORD", "ROGIER", "DEBROUCKERE", "G-MIDI", "PORTE-DE-HAL", "ALBERT"),
            statusSeverity = StatusSeverity.NORMAL,
            statusMessage = "Normal service / Normale bediening"
        )
    )

    val initialAlerts: List<DisruptionAlert> = listOf(
        DisruptionAlert(
            alertId = "ALT-2026-001",
            affectedLineIds = listOf("Line 5"),
            affectedStationIds = listOf("SCHUMAN", "ARTS-LOI"),
            severity = StatusSeverity.MINOR_DELAY,
            title = "Line 5 Signal Maintenance",
            description = "Expect +5 to +7 minute delays on Line 5 between Arts-Loi and Schuman due to track signal calibration.",
            timestamp = "10:15",
            expectedDuration = "Expected resolution: 12:00",
            alternativeRouteSuggestion = "Take Line 1 from Gare Centrale directly to Schuman or Mérode."
        ),
        DisruptionAlert(
            alertId = "ALT-2026-002",
            affectedLineIds = listOf("Line 2", "Line 6"),
            affectedStationIds = listOf("BOTANIQUE"),
            severity = StatusSeverity.PLATFORM_CHANGE,
            title = "Botanique Escalator Maintenance",
            description = "Elevator and escalator maintenance at Botanique entrance 2. Step-free passengers please use Entrance 1.",
            timestamp = "09:30",
            expectedDuration = "All day",
            alternativeRouteSuggestion = "Access via Entrance 1 (Rue Royale)."
        )
    )

    val initialTickets: List<TicketPass> = listOf(
        TicketPass(
            id = "TKT-1001",
            type = TicketType.SINGLE_JOURNEY,
            titleKey = "tickets.single",
            validFrom = "09:42",
            validUntil = "10:42",
            qrCodeToken = "STIB-BRU-2026-981247-L1",
            isActive = true,
            priceEur = 2.60
        ),
        TicketPass(
            id = "TKT-1002",
            type = TicketType.DAY_PASS_24H,
            titleKey = "tickets.day_pass",
            validFrom = "08:00",
            validUntil = "Tomorrow 08:00",
            qrCodeToken = "STIB-BRU-2026-339182-24H",
            isActive = false,
            priceEur = 8.40
        ),
        TicketPass(
            id = "TKT-1003",
            type = TicketType.MULTI_10_JOURNEY,
            titleKey = "tickets.multi_10",
            validFrom = "Unactivated",
            validUntil = "10 Rides Remaining",
            qrCodeToken = "STIB-BRU-2026-772109-M10",
            isActive = false,
            priceEur = 16.80
        )
    )

    val initialFavourites: List<UserFavourite> = listOf(
        UserFavourite("FAV-1", "Home", "G-CENTRAL", "home"),
        UserFavourite("FAV-2", "Work", "SCHUMAN", "work"),
        UserFavourite("FAV-3", "Airport Bus", "G-NORD", "flight")
    )

    fun getStationById(id: String): Station? {
        return stations.find { it.id == id }
    }

    fun getLineById(id: String): Line? {
        return lines.find { it.id == id }
    }
}
