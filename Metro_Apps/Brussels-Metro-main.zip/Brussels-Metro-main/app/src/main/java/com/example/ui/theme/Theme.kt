package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MinimalSecondary,
    onPrimary = MinimalOnPrimary,
    secondary = MinimalAccent,
    onSecondary = Color.White,
    tertiary = MinimalSuccess,
    background = MinimalBackgroundDark,
    surface = MinimalSurfaceDark,
    surfaceVariant = MinimalSurfaceVariantDark,
    outline = MinimalBorderDark,
    onBackground = MinimalTextPrimaryDark,
    onSurface = MinimalTextPrimaryDark,
    onSurfaceVariant = MinimalTextSecondaryDark
)

private val LightColorScheme = lightColorScheme(
    primary = MinimalPrimary,
    onPrimary = MinimalOnPrimary,
    secondary = MinimalSecondary,
    onSecondary = Color.White,
    tertiary = MinimalAccent,
    background = MinimalBackgroundLight,
    surface = MinimalSurfaceLight,
    surfaceVariant = MinimalSurfaceVariantLight,
    outline = MinimalBorderLight,
    onBackground = MinimalTextPrimaryLight,
    onSurface = MinimalTextPrimaryLight,
    onSurfaceVariant = MinimalTextSecondaryLight
)

@Composable
fun BrusselsMetroTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

