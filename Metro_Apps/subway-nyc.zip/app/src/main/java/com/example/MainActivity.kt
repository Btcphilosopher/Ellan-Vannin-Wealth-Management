package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.viewmodel.TransitViewModel
import com.example.ui.MainLayout
import com.example.ui.theme.SubwayColors
import com.example.ui.theme.SubwayNYCTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SubwayNYCTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = SubwayColors.BackgroundDark
                ) {
                    val viewModel: TransitViewModel = viewModel()
                    MainLayout(viewModel = viewModel)
                }
            }
        }
    }
}
