package com.example.data.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AccessibilityEquipment
import com.example.data.model.EquipmentStatus
import com.example.data.model.OmnyAccount
import com.example.data.model.RouteMode
import com.example.data.model.Station
import com.example.data.model.SubwayLineInfo
import com.example.data.model.Train
import com.example.data.model.TripRoute
import com.example.data.repository.TransitRepository
import com.example.data.simulation.SimulationState
import com.example.ui.theme.SubwayLine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppTab {
    HOME, MAP, TRIPS, SERVICE, ACCOUNT
}

enum class MapLayerMode {
    NETWORK, LIVE, SERVICE
}

enum class ActiveTripStatus {
    IDLE, BOARDING, IN_TRANSIT, ARRIVED
}

data class ActiveTripState(
    val status: ActiveTripStatus = ActiveTripStatus.IDLE,
    val route: TripRoute? = null,
    val currentSegmentIndex: Int = 0,
    val currentStationName: String = "",
    val nextStationName: String = "",
    val etaMins: Int = 0,
    val progressPercent: Float = 0f
)

class TransitViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = TransitRepository(db.subwayDao(), viewModelScope)

    // Primary UI Tab Navigation
    private val _selectedTab = MutableStateFlow(AppTab.HOME)
    val selectedTab: StateFlow<AppTab> = _selectedTab.asStateFlow()

    // Search Query & Stations
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filteredStations = MutableStateFlow<List<Station>>(repository.graph.getAllStations())
    val filteredStations: StateFlow<List<Station>> = _filteredStations.asStateFlow()

    // Selected Station Detail Sheet
    private val _selectedStation = MutableStateFlow<Station?>(null)
    val selectedStation: StateFlow<Station?> = _selectedStation.asStateFlow()

    // Trip Planner State
    private val _originStation = MutableStateFlow<Station?>(repository.graph.getStation("14_st_union_sq"))
    val originStation: StateFlow<Station?> = _originStation.asStateFlow()

    private val _destStation = MutableStateFlow<Station?>(repository.graph.getStation("34_st_herald_sq"))
    val destStation: StateFlow<Station?> = _destStation.asStateFlow()

    private val _routeMode = MutableStateFlow(RouteMode.FASTEST)
    val routeMode: StateFlow<RouteMode> = _routeMode.asStateFlow()

    private val _calculatedRoutes = MutableStateFlow<List<TripRoute>>(emptyList())
    val calculatedRoutes: StateFlow<List<TripRoute>> = _calculatedRoutes.asStateFlow()

    private val _selectedRoute = MutableStateFlow<TripRoute?>(null)
    val selectedRoute: StateFlow<TripRoute?> = _selectedRoute.asStateFlow()

    // Active Journey Simulation (Vertical Slice)
    private val _activeTripState = MutableStateFlow(ActiveTripState())
    val activeTripState: StateFlow<ActiveTripState> = _activeTripState.asStateFlow()

    // Interactive Map State
    private val _mapLayerMode = MutableStateFlow(MapLayerMode.NETWORK)
    val mapLayerMode: StateFlow<MapLayerMode> = _mapLayerMode.asStateFlow()

    private val _selectedLineFilter = MutableStateFlow<SubwayLine?>(null)
    val selectedLineFilter: StateFlow<SubwayLine?> = _selectedLineFilter.asStateFlow()

    // Digital Twin / Operations Control View
    private val _isDigitalTwinOpen = MutableStateFlow(false)
    val isDigitalTwinOpen: StateFlow<Boolean> = _isDigitalTwinOpen.asStateFlow()

    // Live Engine Feeds
    val simState: StateFlow<SimulationState> = repository.simEngine.simState
    val activeTrains: StateFlow<List<Train>> = repository.simEngine.activeTrains
    val lineStatuses: StateFlow<List<SubwayLineInfo>> = repository.simEngine.lineStatuses
    val activeDisruption: StateFlow<String?> = repository.simEngine.activeDisruption
    val isOffline: StateFlow<Boolean> = repository.isOffline
    val omnyAccount: StateFlow<OmnyAccount> = repository.omnyAccount
    val accessibilityEquipments: StateFlow<List<AccessibilityEquipment>> = repository.accessibilityEquipments

    // Database flows
    val fareTransactions = repository.fareTransactionsFromDb.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tripHistory = repository.tripHistoryFromDb.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val savedPlaces = repository.savedPlacesFromDb.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        planTrips()
    }

    fun selectTab(tab: AppTab) {
        _selectedTab.value = tab
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        _filteredStations.value = repository.searchStations(query)
    }

    fun selectStation(station: Station?) {
        _selectedStation.value = station
    }

    fun setOrigin(station: Station) {
        _originStation.value = station
        planTrips()
    }

    fun setDestination(station: Station) {
        _destStation.value = station
        planTrips()
    }

    fun swapOriginAndDestination() {
        val temp = _originStation.value
        _originStation.value = _destStation.value
        _destStation.value = temp
        planTrips()
    }

    fun setRouteMode(mode: RouteMode) {
        _routeMode.value = mode
        planTrips()
    }

    fun setMapLayerMode(mode: MapLayerMode) {
        _mapLayerMode.value = mode
    }

    fun setSelectedLineFilter(line: SubwayLine?) {
        _selectedLineFilter.value = line
    }

    fun toggleDigitalTwin(open: Boolean) {
        _isDigitalTwinOpen.value = open
    }

    fun toggleOfflineMode() {
        repository.setOfflineMode(!repository.isOffline.value)
    }

    fun planTrips() {
        val orig = _originStation.value ?: return
        val dest = _destStation.value ?: return

        val disabledElevators = if (_routeMode.value == RouteMode.ACCESSIBLE) {
            repository.accessibilityEquipments.value
                .filter { it.status == EquipmentStatus.OUT_OF_SERVICE }
                .map { it.stationId }
                .toSet()
        } else emptySet()

        val mainRoute = repository.routingEngine.calculateRoute(
            originId = orig.id,
            destId = dest.id,
            mode = _routeMode.value,
            disabledElevatorStations = disabledElevators
        )

        // Calculate alternative modes for comparison
        val altMode = if (_routeMode.value == RouteMode.FASTEST) RouteMode.FEWEST_TRANSFERS else RouteMode.FASTEST
        val altRoute = repository.routingEngine.calculateRoute(
            originId = orig.id,
            destId = dest.id,
            mode = altMode,
            disabledElevatorStations = disabledElevators
        )

        val routesList = listOfNotNull(mainRoute, altRoute).distinctBy { it.totalDurationMins }
        _calculatedRoutes.value = routesList
        _selectedRoute.value = routesList.firstOrNull()
    }

    fun startTripSimulation(route: TripRoute) {
        _selectedRoute.value = route
        _selectedTab.value = AppTab.TRIPS
        viewModelScope.launch {
            val firstSeg = route.segments.firstOrNull() ?: return@launch
            _activeTripState.value = ActiveTripState(
                status = ActiveTripStatus.BOARDING,
                route = route,
                currentSegmentIndex = 0,
                currentStationName = firstSeg.fromStationName,
                nextStationName = firstSeg.toStationName,
                etaMins = route.totalDurationMins,
                progressPercent = 0.1f
            )

            // Tap into OMNY automatically
            repository.recordNewTapIn(firstSeg.fromStationName, firstSeg.line.code)

            // Advance trip through states
            kotlinx.coroutines.delay(1800L)
            _activeTripState.value = _activeTripState.value.copy(
                status = ActiveTripStatus.IN_TRANSIT,
                progressPercent = 0.5f,
                etaMins = (route.totalDurationMins / 2).coerceAtLeast(1)
            )

            kotlinx.coroutines.delay(2200L)
            _activeTripState.value = _activeTripState.value.copy(
                status = ActiveTripStatus.ARRIVED,
                currentStationName = route.destStationName,
                progressPercent = 1.0f,
                etaMins = 0
            )

            // Record completed trip into history
            val linesUsed = route.segments.joinToString(", ") { it.line.code }
            repository.recordCompletedTrip(route.originStationName, route.destStationName, route.totalDurationMins, linesUsed)
        }
    }

    fun resetTripState() {
        _activeTripState.value = ActiveTripState(status = ActiveTripStatus.IDLE)
    }

    fun executeDemoScenario(scenarioNumber: Int) {
        when (scenarioNumber) {
            1 -> { // Normal Journey: Union Sq -> Herald Sq
                setOrigin(repository.graph.getStation("14_st_union_sq")!!)
                setDestination(repository.graph.getStation("34_st_herald_sq")!!)
                setRouteMode(RouteMode.FASTEST)
                selectTab(AppTab.TRIPS)
                repository.simEngine.clearDisruption()
            }
            2 -> { // Train Delayed
                setOrigin(repository.graph.getStation("14_st_union_sq")!!)
                setDestination(repository.graph.getStation("grand_central_42")!!)
                repository.simEngine.triggerDisruptionScenario("TRAIN_DELAYED")
                selectTab(AppTab.HOME)
            }
            3 -> { // Station Closed
                repository.simEngine.triggerDisruptionScenario("STATION_CLOSED")
                selectTab(AppTab.SERVICE)
            }
            4 -> { // Elevator Unavailable
                repository.simEngine.triggerDisruptionScenario("ELEVATOR_OUTAGE")
                selectTab(AppTab.SERVICE)
            }
            5 -> { // Accessible Routing
                setOrigin(repository.graph.getStation("14_st_union_sq")!!)
                setDestination(repository.graph.getStation("74_st_broadway")!!)
                setRouteMode(RouteMode.ACCESSIBLE)
                selectTab(AppTab.TRIPS)
            }
            6 -> { // Major Service Disruption
                repository.simEngine.triggerDisruptionScenario("MAJOR_DISRUPTION")
                selectTab(AppTab.HOME)
            }
            7 -> { // Offline Subway Mode
                toggleOfflineMode()
                selectTab(AppTab.HOME)
            }
            8 -> { // Live Train Simulation Speed
                repository.simEngine.setSpeedMultiplier(10)
                setMapLayerMode(MapLayerMode.LIVE)
                selectTab(AppTab.MAP)
            }
            9 -> { // OMNY Fare History
                selectTab(AppTab.ACCOUNT)
            }
        }
    }
}
