package com.example.data.model

import com.example.ui.theme.SubwayLine

enum class TrainStatus {
    DWELLING,
    DEPARTING,
    RUNNING,
    APPROACHING,
    ARRIVING,
    HELD,
    SKIPPING,
    OUT_OF_SERVICE
}

data class Train(
    val trainId: String,
    val line: SubwayLine,
    val direction: String, // Uptown/Bronx, Downtown/Brooklyn, Queens-bound, Manhattan-bound
    val currentStationId: String,
    val nextStationId: String,
    val progressPercent: Float, // 0.0 to 1.0 along the segment
    val speedMph: Int = 32,
    val status: TrainStatus,
    val scheduledMinsAway: Int,
    val estimatedMinsAway: Int,
    val headwaySecs: Int = 240
)
