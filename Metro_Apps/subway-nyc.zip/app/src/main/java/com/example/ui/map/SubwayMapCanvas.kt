package com.example.ui.map

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MapLayerMode
import com.example.data.model.Station
import com.example.data.model.Train
import com.example.data.viewmodel.MapLayerMode as ViewModelMapLayerMode
import com.example.ui.theme.SubwayColors
import com.example.ui.theme.SubwayLine

@Composable
fun SubwayMapCanvas(
    stations: List<Station>,
    activeTrains: List<Train>,
    layerMode: ViewModelMapLayerMode,
    selectedLineFilter: SubwayLine?,
    selectedStation: Station?,
    onStationSelected: (Station) -> Unit,
    onLayerModeChanged: (ViewModelMapLayerMode) -> Unit,
    onLineFilterChanged: (SubwayLine?) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1.2f) }
    var offsetX by remember { mutableFloatStateOf(-150f) }
    var offsetY by remember { mutableFloatStateOf(-180f) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(SubwayColors.BackgroundDark)
            .testTag("subway_map_container")
    ) {
        // Interactive Canvas Layer
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.6f, 3.5f)
                        offsetX += pan.x
                        offsetY += pan.y
                    }
                }
                .pointerInput(stations, scale, offsetX, offsetY) {
                    detectTransformGestures { _, _, _, _ -> }
                    // Simple tap handler detection
                }
        ) {
            val drawContext = drawContext
            val canvas = drawContext.canvas

            // Grid background design (MTA Architecture Grid)
            val gridStep = 40f * scale
            for (x in 0..size.width.toInt() step gridStep.toInt()) {
                drawLine(
                    color = Color(0xFF1B1D22),
                    start = Offset(x.toFloat(), 0f),
                    end = Offset(x.toFloat(), size.height),
                    strokeWidth = 1f
                )
            }
            for (y in 0..size.height.toInt() step gridStep.toInt()) {
                drawLine(
                    color = Color(0xFF1B1D22),
                    start = Offset(0f, y.toFloat()),
                    end = Offset(size.width, y.toFloat()),
                    strokeWidth = 1f
                )
            }

            // Draw Track Segments
            val connections = listOf(
                Pair("59_st_columbus", "times_sq_42") to SubwayLine.LINE_1,
                Pair("times_sq_42", "34_st_herald_sq") to SubwayLine.LINE_1,
                Pair("34_st_herald_sq", "14_st_union_sq") to SubwayLine.LINE_1,
                Pair("yankee_stadium_161", "59_st_columbus") to SubwayLine.LINE_4,
                Pair("59_st_columbus", "grand_central_42") to SubwayLine.LINE_4,
                Pair("grand_central_42", "14_st_union_sq") to SubwayLine.LINE_4,
                Pair("14_st_union_sq", "fulton_st") to SubwayLine.LINE_4,
                Pair("fulton_st", "atlantic_av_barclays") to SubwayLine.LINE_4,
                Pair("times_sq_42", "grand_central_42") to SubwayLine.LINE_7,
                Pair("grand_central_42", "74_st_broadway") to SubwayLine.LINE_7,
                Pair("times_sq_42", "fulton_st") to SubwayLine.LINE_A,
                Pair("fulton_st", "jfk_terminal_4") to SubwayLine.LINE_A,
                Pair("14_st_union_sq", "atlantic_av_barclays") to SubwayLine.LINE_N,
                Pair("atlantic_av_barclays", "coney_island_stillwell") to SubwayLine.LINE_N
            )

            for ((pair, line) in connections) {
                val st1 = stations.find { it.id == pair.first }
                val st2 = stations.find { it.id == pair.second }

                if (st1 != null && st2 != null) {
                    val isDimmed = selectedLineFilter != null && selectedLineFilter != line

                    val p1 = Offset(st1.schematicX * scale + offsetX, st1.schematicY * scale + offsetY)
                    val p2 = Offset(st2.schematicX * scale + offsetX, st2.schematicY * scale + offsetY)

                    val strokeColor = if (isDimmed) Color(0xFF33363F) else line.color

                    drawLine(
                        color = strokeColor,
                        start = p1,
                        end = p2,
                        strokeWidth = (8f * scale).coerceIn(4f, 18f),
                        cap = StrokeCap.Round
                    )
                }
            }

            // Draw Station Nodes & Interchange Rings
            for (st in stations) {
                val pos = Offset(st.schematicX * scale + offsetX, st.schematicY * scale + offsetY)
                val isSelected = selectedStation?.id == st.id

                // Transfer Ring
                if (st.lines.size > 2) {
                    drawCircle(
                        color = Color.White,
                        radius = (12f * scale).coerceIn(8f, 22f),
                        center = pos
                    )
                    drawCircle(
                        color = Color(0xFF0F1012),
                        radius = (8f * scale).coerceIn(5f, 16f),
                        center = pos
                    )
                } else {
                    drawCircle(
                        color = Color.White,
                        radius = (8f * scale).coerceIn(5f, 16f),
                        center = pos
                    )
                }

                if (isSelected) {
                    drawCircle(
                        color = SubwayColors.CautionAmber,
                        radius = (16f * scale).coerceIn(10f, 28f),
                        center = pos,
                        style = Stroke(width = 4f)
                    )
                }
            }

            // Draw Animated Live Trains (if LIVE layer or default)
            if (layerMode == ViewModelMapLayerMode.LIVE || layerMode == ViewModelMapLayerMode.NETWORK) {
                for (train in activeTrains) {
                    val stFrom = stations.find { it.id == train.currentStationId }
                    val stTo = stations.find { it.id == train.nextStationId }

                    if (stFrom != null && stTo != null) {
                        val p1 = Offset(stFrom.schematicX * scale + offsetX, stFrom.schematicY * scale + offsetY)
                        val p2 = Offset(stTo.schematicX * scale + offsetX, stTo.schematicY * scale + offsetY)

                        val trainPos = Offset(
                            p1.x + (p2.x - p1.x) * train.progressPercent,
                            p1.y + (p2.y - p1.y) * train.progressPercent
                        )

                        // Train Bullet Marker
                        drawCircle(
                            color = Color.Black,
                            radius = (10f * scale).coerceIn(6f, 18f),
                            center = trainPos
                        )
                        drawCircle(
                            color = train.line.color,
                            radius = (8f * scale).coerceIn(4f, 14f),
                            center = trainPos
                        )
                    }
                }
            }
        }

        // Overlay Controls Bar (Top & Bottom)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            // Layer Switcher Row
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF141518),
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .padding(4.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ViewModelMapLayerMode.entries.forEach { mode ->
                        val isSelected = layerMode == mode
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSelected) SubwayColors.CautionAmber else Color.Transparent,
                            onClick = { onLayerModeChanged(mode) },
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = mode.name,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.Black else Color.White
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Line Quick Filters
            Row(
                modifier = Modifier.fillMaxWidth()
            ) {
                FilterChip(
                    selected = selectedLineFilter == null,
                    onClick = { onLineFilterChanged(null) },
                    label = { Text("ALL LINES", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color.White,
                        selectedLabelColor = Color.Black,
                        containerColor = Color(0xFF1F2128),
                        labelColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.width(6.dp))

                val filterLines = listOf(SubwayLine.LINE_1, SubwayLine.LINE_4, SubwayLine.LINE_7, SubwayLine.LINE_A, SubwayLine.LINE_N)
                filterLines.forEach { line ->
                    FilterChip(
                        selected = selectedLineFilter == line,
                        onClick = { onLineFilterChanged(if (selectedLineFilter == line) null else line) },
                        label = { Text(line.code, fontSize = 11.sp, fontWeight = FontWeight.Black) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = line.color,
                            selectedLabelColor = line.textColor,
                            containerColor = Color(0xFF1F2128),
                            labelColor = Color.White
                        ),
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Zoom Floating Buttons
            Column(
                modifier = Modifier.align(Alignment.End),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column {
                        IconButton(onClick = { scale = (scale + 0.3f).coerceAtMost(3.5f) }) {
                            Icon(Icons.Default.Add, contentDescription = "Zoom In", tint = Color.White)
                        }
                        IconButton(onClick = { scale = (scale - 0.3f).coerceAtLeast(0.6f) }) {
                            Icon(Icons.Default.Remove, contentDescription = "Zoom Out", tint = Color.White)
                        }
                        IconButton(onClick = { scale = 1.2f; offsetX = -150f; offsetY = -180f }) {
                            Icon(Icons.Default.MyLocation, contentDescription = "Reset Map View", tint = SubwayColors.CautionAmber)
                        }
                    }
                }
            }
        }
    }
}
