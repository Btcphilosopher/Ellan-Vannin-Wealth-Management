package com.example.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * NY Transit OS - Subway Line Design Tokens
 * Strictly models NYC Subway official line trunk colors and visual design rules.
 */
enum class SubwayLine(
    val code: String,
    val colorHex: String,
    val textColorHex: String,
    val trunkName: String
) {
    LINE_1("1", "#EE352E", "#FFFFFF", "Broadway - 7th Av Local"),
    LINE_2("2", "#EE352E", "#FFFFFF", "7th Av Express"),
    LINE_3("3", "#EE352E", "#FFFFFF", "7th Av Express"),
    LINE_4("4", "#00933C", "#FFFFFF", "Lexington Av Express"),
    LINE_5("5", "#00933C", "#FFFFFF", "Lexington Av Express"),
    LINE_6("6", "#00933C", "#FFFFFF", "Lexington Av Local"),
    LINE_7("7", "#B933AD", "#FFFFFF", "Flushing Local/Express"),
    LINE_A("A", "#0039A6", "#FFFFFF", "8th Av Express"),
    LINE_C("C", "#0039A6", "#FFFFFF", "8th Av Local"),
    LINE_E("E", "#0039A6", "#FFFFFF", "8th Av Local"),
    LINE_B("B", "#FF6319", "#FFFFFF", "6th Av Express"),
    LINE_D("D", "#FF6319", "#FFFFFF", "6th Av Express"),
    LINE_F("F", "#FF6319", "#FFFFFF", "6th Av Local"),
    LINE_M("M", "#FF6319", "#FFFFFF", "6th Av Local"),
    LINE_G("G", "#6CBE45", "#FFFFFF", "Crosstown"),
    LINE_J("J", "#996633", "#FFFFFF", "Nassau St Express"),
    LINE_Z("Z", "#996633", "#FFFFFF", "Nassau St Express"),
    LINE_L("L", "#A7A9AC", "#000000", "14th St-Canarsie Local"),
    LINE_N("N", "#FCCC0A", "#000000", "Broadway Express"),
    LINE_Q("Q", "#FCCC0A", "#000000", "Broadway Express"),
    LINE_R("R", "#FCCC0A", "#000000", "Broadway Local"),
    LINE_W("W", "#FCCC0A", "#000000", "Broadway Local"),
    LINE_S("S", "#808183", "#FFFFFF", "42nd St Shuttle"),
    AIRTRAIN("AIR", "#00A1DE", "#FFFFFF", "JFK AirTrain Connector");

    val color: Color
        get() = Color(android.graphics.Color.parseColor(colorHex))

    val textColor: Color
        get() = Color(android.graphics.Color.parseColor(textColorHex))
}

object SubwayColors {
    // New York Architectural Palette
    val BackgroundDark = Color(0xFF0A0A0C)
    val SurfaceDark = Color(0xFF141518)
    val SurfaceBorderDark = Color(0xFF26282E)
    val PrimaryTextDark = Color(0xFFFAFAFC)
    val SecondaryTextDark = Color(0xFFA0A4AD)

    val BackgroundLight = Color(0xFFF4F5F7)
    val SurfaceLight = Color(0xFFFFFFFF)
    val SurfaceBorderLight = Color(0xFFE2E4E8)
    val PrimaryTextLight = Color(0xFF0F1012)
    val SecondaryTextLight = Color(0xFF5A5E68)

    // Functional Status Colors
    val GoodService = Color(0xFF00933C)
    val DelayWarning = Color(0xFFD97706)
    val ServiceChange = Color(0xFFDC2626)
    val WorkPlanned = Color(0xFF2563EB)

    val StainlessGrey = Color(0xFF333740)
    val CautionAmber = Color(0xFFFCCC0A)
    val EmergencyRed = Color(0xFFEE352E)
}
