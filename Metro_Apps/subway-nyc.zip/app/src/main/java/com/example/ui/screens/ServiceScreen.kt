package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.Elevator
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccessibilityEquipment
import com.example.data.model.EquipmentStatus
import com.example.data.model.ServiceStatusType
import com.example.data.model.SubwayLineInfo
import com.example.ui.theme.SubwayColors

@Composable
fun ServiceScreen(
    lineStatuses: List<SubwayLineInfo>,
    accessibilityEquipments: List<AccessibilityEquipment>,
    modifier: Modifier = Modifier
) {
    var selectedLineForDialog by remember { mutableStateOf<SubwayLineInfo?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SubwayColors.BackgroundDark)
            .padding(horizontal = 16.dp)
            .testTag("service_screen")
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))

            // Overall Status Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SYSTEM SERVICE STATUS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = SubwayColors.CautionAmber,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = SubwayColors.GoodService,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "NORMAL OPERATION",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Updated: 08:42 AM",
                            fontSize = 11.sp,
                            color = SubwayColors.SecondaryTextDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "SUBWAY LINES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = SubwayColors.SecondaryTextDark,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Line Status List
        items(lineStatuses) { info ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clickable { selectedLineForDialog = info }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = info.line.color,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = info.line.code,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = info.line.textColor
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = info.line.trunkName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = info.summary,
                            fontSize = 11.sp,
                            color = SubwayColors.SecondaryTextDark
                        )
                    }

                    val (bgColor, txtColor) = when (info.status) {
                        ServiceStatusType.GOOD_SERVICE -> SubwayColors.GoodService to Color.White
                        ServiceStatusType.DELAYS -> SubwayColors.DelayWarning to Color.White
                        ServiceStatusType.SERVICE_CHANGE -> SubwayColors.ServiceChange to Color.White
                        ServiceStatusType.PLANNED_WORK -> SubwayColors.WorkPlanned to Color.White
                    }

                    Surface(
                        color = bgColor,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = info.status.label,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = txtColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))

            // Elevator & Escalator Status Section
            Text(
                text = "ELEVATOR & ESCALATOR STATUS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = SubwayColors.SecondaryTextDark,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            accessibilityEquipments.forEach { equip ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Elevator,
                            contentDescription = null,
                            tint = if (equip.status == EquipmentStatus.AVAILABLE) SubwayColors.GoodService else SubwayColors.EmergencyRed
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(equip.stationName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(equip.locationDescription, fontSize = 10.sp, color = SubwayColors.SecondaryTextDark)
                        }
                        Surface(
                            color = if (equip.status == EquipmentStatus.AVAILABLE) SubwayColors.GoodService else SubwayColors.EmergencyRed,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = equip.status.name,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Line Service Detail Dialog (NOW / PLANNED / NOTICES)
    selectedLineForDialog?.let { lineInfo ->
        var selectedTabIndex by remember { mutableIntStateOf(0) }

        AlertDialog(
            onDismissRequest = { selectedLineForDialog = null },
            containerColor = Color(0xFF181A20),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = lineInfo.line.color,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(lineInfo.line.code, fontSize = 14.sp, fontWeight = FontWeight.Black, color = lineInfo.line.textColor)
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("${lineInfo.line.code} TRAIN SERVICE", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                }
            },
            text = {
                Column {
                    TabRow(
                        selectedTabIndex = selectedTabIndex,
                        containerColor = Color(0xFF22252E),
                        contentColor = SubwayColors.CautionAmber
                    ) {
                        Tab(
                            selected = selectedTabIndex == 0,
                            onClick = { selectedTabIndex = 0 },
                            text = { Text("NOW", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTabIndex == 1,
                            onClick = { selectedTabIndex = 1 },
                            text = { Text("PLANNED WORK", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTabIndex == 2,
                            onClick = { selectedTabIndex = 2 },
                            text = { Text("NOTICES", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    when (selectedTabIndex) {
                        0 -> {
                            Text(
                                text = lineInfo.nowNotice ?: "Service running normally on schedule across all tracks.",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                        }
                        1 -> {
                            Text(
                                text = lineInfo.plannedNotice ?: "No planned weekend track work scheduled for this line.",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                        }
                        2 -> {
                            Text(
                                text = "Station modernisation and accessibility elevator additions in progress.",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedLineForDialog = null }) {
                    Text("CLOSE", color = SubwayColors.CautionAmber, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
