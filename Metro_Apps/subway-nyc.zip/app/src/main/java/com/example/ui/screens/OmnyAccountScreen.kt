package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FareTransactionEntity
import com.example.data.model.OmnyAccount
import com.example.ui.theme.SubwayColors

@Composable
fun OmnyAccountScreen(
    omnyAccount: OmnyAccount,
    transactions: List<FareTransactionEntity>,
    onSimulateTapIn: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SubwayColors.BackgroundDark)
            .padding(horizontal = 16.dp)
            .testTag("omny_account_screen")
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))

            // MY FARE — OMNY Account Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "MY FARE — OMNY ACCOUNT",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = SubwayColors.CautionAmber,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = omnyAccount.accountId,
                                fontSize = 11.sp,
                                color = SubwayColors.SecondaryTextDark
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Nfc,
                            contentDescription = "Contactless",
                            tint = SubwayColors.CautionAmber,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Spend & Trips Stats
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("THIS WEEK SPEND", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SubwayColors.SecondaryTextDark)
                            Text(
                                text = "\$${String.format("%.2f", omnyAccount.weeklyTotalSpend)}",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("TRIPS TAKEN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SubwayColors.SecondaryTextDark)
                            Text(
                                text = "${omnyAccount.weeklyTripCount}",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 7-Day Fare Cap Progress Indicator ($34.00 max)
                    val capProgress = (omnyAccount.weeklyTotalSpend / omnyAccount.fareCapThreshold).coerceIn(0.0, 1.0).toFloat()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "7-DAY FARE CAP (\$34.00)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SubwayColors.SecondaryTextDark
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = if (omnyAccount.fareCapReached) "CAP REACHED (FREE TRIPS!)" else "\$${String.format("%.2f", omnyAccount.remainingCapSpend)} TO CAP",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (omnyAccount.fareCapReached) SubwayColors.GoodService else SubwayColors.CautionAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = capProgress,
                        color = if (omnyAccount.fareCapReached) SubwayColors.GoodService else SubwayColors.CautionAmber,
                        trackColor = Color(0xFF23262E),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Tap In Simulation Trigger
                    Button(
                        onClick = onSimulateTapIn,
                        colors = ButtonDefaults.buttonColors(containerColor = SubwayColors.CautionAmber),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Nfc, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SIMULATE OMNY TURNSTILE TAP", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.Black)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Payment Methods
            Text(
                text = "LINKED FARE MEDIA",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = SubwayColors.SecondaryTextDark,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            val cards = listOf(
                Pair("VISA •••• 4821", "PRIMARY CONTACTLESS CARD"),
                Pair("APPLE PAY / PHONE WALLET", "MOBILE DEVICE PASS"),
                Pair("OMNY PHYSICAL CARD", "MTA ISSUED CONTACTLESS")
            )
            cards.forEach { (cardName, subtitle) ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CreditCard, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(cardName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(subtitle, fontSize = 10.sp, color = SubwayColors.SecondaryTextDark)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "RECENT TRIP FARE TRANSACTIONS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = SubwayColors.SecondaryTextDark,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Transactions List
        items(transactions) { tx ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(tx.stationName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("${tx.timestampStr} • Line ${tx.lineCode}", fontSize = 11.sp, color = SubwayColors.SecondaryTextDark)
                    }
                    Text(
                        text = "-\$${String.format("%.2f", tx.amount)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }
        }
    }
}
