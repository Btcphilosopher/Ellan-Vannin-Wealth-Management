package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFAFAFC),
    onPrimary = Color(0xFF0A0A0C),
    primaryContainer = Color(0xFF202228),
    onPrimaryContainer = Color(0xFFFAFAFC),
    secondary = Color(0xFFFCCC0A),
    onSecondary = Color(0xFF0A0A0C),
    background = SubwayColors.BackgroundDark,
    onBackground = SubwayColors.PrimaryTextDark,
    surface = SubwayColors.SurfaceDark,
    onSurface = SubwayColors.PrimaryTextDark,
    surfaceVariant = Color(0xFF1C1D22),
    onSurfaceVariant = SubwayColors.SecondaryTextDark,
    outline = SubwayColors.SurfaceBorderDark,
    error = SubwayColors.EmergencyRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF0F1012),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE5E7EB),
    onPrimaryContainer = Color(0xFF0F1012),
    secondary = Color(0xFFD97706),
    onSecondary = Color(0xFFFFFFFF),
    background = SubwayColors.BackgroundLight,
    onBackground = SubwayColors.PrimaryTextLight,
    surface = SubwayColors.SurfaceLight,
    onSurface = SubwayColors.PrimaryTextLight,
    surfaceVariant = Color(0xFFEBF0F5),
    onSurfaceVariant = SubwayColors.SecondaryTextLight,
    outline = SubwayColors.SurfaceBorderLight,
    error = SubwayColors.EmergencyRed,
    onError = Color.White
)

@Composable
fun SubwayNYCTheme(
    darkTheme: Boolean = true, // Default to sleek New York Dark Mode
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
