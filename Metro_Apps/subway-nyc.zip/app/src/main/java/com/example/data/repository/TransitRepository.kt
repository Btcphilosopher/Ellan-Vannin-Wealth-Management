package com.example.data.repository

import com.example.data.local.FareTransactionEntity
import com.example.data.local.SavedPlaceEntity
import com.example.data.local.SubwayDao
import com.example.data.local.TripHistoryEntity
import com.example.data.model.AccessibilityEquipment
import com.example.data.model.EquipmentStatus
import com.example.data.model.OmnyAccount
import com.example.data.model.SavedPlace
import com.example.data.model.SavedPlaceCategory
import com.example.data.model.Station
import com.example.data.model.StationEntrance
import com.example.data.model.SubwayLineInfo
import com.example.data.model.Train
import com.example.data.routing.GraphEdge
import com.example.data.routing.RoutingEngine
import com.example.data.routing.SubwayGraph
import com.example.data.simulation.SubwaySimulationEngine
import com.example.ui.theme.SubwayLine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TransitRepository(
    private val subwayDao: SubwayDao,
    private val scope: CoroutineScope
) {
    val graph = SubwayGraph()
    val routingEngine = RoutingEngine(graph)
    val simEngine = SubwaySimulationEngine(scope)

    private val _isOffline = MutableStateFlow(false)
    val isOffline: StateFlow<Boolean> = _isOffline.asStateFlow()

    private val _omnyAccount = MutableStateFlow(OmnyAccount())
    val omnyAccount: StateFlow<OmnyAccount> = _omnyAccount.asStateFlow()

    val savedPlacesFromDb: Flow<List<SavedPlaceEntity>> = subwayDao.getAllSavedPlaces()
    val fareTransactionsFromDb: Flow<List<FareTransactionEntity>> = subwayDao.getAllFareTransactions()
    val tripHistoryFromDb: Flow<List<TripHistoryEntity>> = subwayDao.getAllTripHistory()

    private val _accessibilityEquipments = MutableStateFlow<List<AccessibilityEquipment>>(emptyList())
    val accessibilityEquipments: StateFlow<List<AccessibilityEquipment>> = _accessibilityEquipments.asStateFlow()

    init {
        populateSubwayGraphAndStations()
        populateAccessibilityData()
        seedInitialHistoryIfEmpty()
    }

    private fun populateSubwayGraphAndStations() {
        val stationsList = listOf(
            Station(
                id = "times_sq_42",
                name = "Times Sq-42 St",
                borough = "Manhattan",
                latitude = 40.7559,
                longitude = -73.9871,
                schematicX = 350f,
                schematicY = 320f,
                lines = listOf(SubwayLine.LINE_1, SubwayLine.LINE_2, SubwayLine.LINE_3, SubwayLine.LINE_7, SubwayLine.LINE_N, SubwayLine.LINE_Q, SubwayLine.LINE_R, SubwayLine.LINE_W, SubwayLine.LINE_S),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "Broadway & 42nd St (SW)", isAccessible = true, hasElevator = true),
                    StationEntrance("e2", "7th Ave & 42nd St (SE)", isAccessible = true, hasElevator = true),
                    StationEntrance("e3", "8th Ave & 42nd St (Port Authority Walkway)", isAccessible = true)
                ),
                connections = listOf("Port Authority Bus Terminal", "NJ Transit", "M7, M20, M42 Bus"),
                services = listOf("Customer Service Center", "Elevators", "Wi-Fi", "OMNY Contactless")
            ),
            Station(
                id = "14_st_union_sq",
                name = "14 St-Union Sq",
                borough = "Manhattan",
                latitude = 40.7359,
                longitude = -73.9905,
                schematicX = 350f,
                schematicY = 480f,
                lines = listOf(SubwayLine.LINE_4, SubwayLine.LINE_5, SubwayLine.LINE_6, SubwayLine.LINE_L, SubwayLine.LINE_N, SubwayLine.LINE_Q, SubwayLine.LINE_R, SubwayLine.LINE_W),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "14th St & Broadway (Union Sq South)", isAccessible = true, hasElevator = true),
                    StationEntrance("e2", "14th St & 4th Ave (SE Corner)", isAccessible = false),
                    StationEntrance("e3", "16th St & Union Sq East", isAccessible = true)
                ),
                connections = listOf("M1, M2, M3, M14 SBS Bus"),
                services = listOf("Elevators", "Escalators", "OMNY Equipment", "Wi-Fi")
            ),
            Station(
                id = "34_st_herald_sq",
                name = "34 St-Herald Sq",
                borough = "Manhattan",
                latitude = 40.7497,
                longitude = -73.9877,
                schematicX = 350f,
                schematicY = 380f,
                lines = listOf(SubwayLine.LINE_B, SubwayLine.LINE_D, SubwayLine.LINE_F, SubwayLine.LINE_M, SubwayLine.LINE_N, SubwayLine.LINE_Q, SubwayLine.LINE_R, SubwayLine.LINE_W),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "Broadway & 34th St (Herald Sq Plaza)", isAccessible = true, hasElevator = true),
                    StationEntrance("e2", "6th Ave & 32nd St (PATH Connection)", isAccessible = true)
                ),
                connections = listOf("PATH Train to NJ", "M34 SBS Bus", "M55 Bus"),
                services = listOf("Elevators", "Escalators", "PATH Transfer Passageway", "OMNY")
            ),
            Station(
                id = "grand_central_42",
                name = "Grand Central-42 St",
                borough = "Manhattan",
                latitude = 40.7527,
                longitude = -73.9772,
                schematicX = 460f,
                schematicY = 320f,
                lines = listOf(SubwayLine.LINE_4, SubwayLine.LINE_5, SubwayLine.LINE_6, SubwayLine.LINE_7, SubwayLine.LINE_S),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "Grand Central Terminal Main Concourse", isAccessible = true, hasElevator = true),
                    StationEntrance("e2", "Lexington Ave & 42nd St", isAccessible = true)
                ),
                connections = listOf("Metro-North Railroad", "LIRR Grand Central Madison", "M42 SBS"),
                services = listOf("Customer Service", "Elevators", "Restrooms", "OMNY", "Wi-Fi")
            ),
            Station(
                id = "59_st_columbus",
                name = "59 St-Columbus Circle",
                borough = "Manhattan",
                latitude = 40.7683,
                longitude = -73.9819,
                schematicX = 350f,
                schematicY = 220f,
                lines = listOf(SubwayLine.LINE_1, SubwayLine.LINE_A, SubwayLine.LINE_B, SubwayLine.LINE_C, SubwayLine.LINE_D),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "Columbus Circle & Central Park South", isAccessible = true, hasElevator = true),
                    StationEntrance("e2", "8th Ave & 57th St", isAccessible = false)
                ),
                connections = listOf("M5, M7, M10, M20, M104 Bus"),
                services = listOf("Elevators", "Underground Retail Shops", "OMNY", "Wi-Fi")
            ),
            Station(
                id = "fulton_st",
                name = "Fulton St",
                borough = "Manhattan",
                latitude = 40.7104,
                longitude = -74.0089,
                schematicX = 350f,
                schematicY = 620f,
                lines = listOf(SubwayLine.LINE_2, SubwayLine.LINE_3, SubwayLine.LINE_4, SubwayLine.LINE_5, SubwayLine.LINE_A, SubwayLine.LINE_C, SubwayLine.LINE_J, SubwayLine.LINE_Z),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "Fulton Center Concourse (Broadway & Fulton)", isAccessible = true, hasElevator = true),
                    StationEntrance("e2", "Dey St Underground Passageway to WTC", isAccessible = true)
                ),
                connections = listOf("PATH at World Trade Center", "WTC Transit Hub", "M55"),
                services = listOf("Fulton Center Retail", "Customer Service Center", "Elevators", "OMNY")
            ),
            Station(
                id = "74_st_broadway",
                name = "74 St-Broadway / Jackson Hts",
                borough = "Queens",
                latitude = 40.7468,
                longitude = -73.8913,
                schematicX = 640f,
                schematicY = 280f,
                lines = listOf(SubwayLine.LINE_7, SubwayLine.LINE_E, SubwayLine.LINE_F, SubwayLine.LINE_M, SubwayLine.LINE_R),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "Victor A. Moore Terminal (74th St & Roosevelt)", isAccessible = true, hasElevator = true)
                ),
                connections = listOf("Q70 SBS LaGuardia Link Bus", "Q32, Q33, Q47 Bus"),
                services = listOf("LaGuardia Airport Bus Hub", "Elevators", "OMNY")
            ),
            Station(
                id = "jfk_terminal_4",
                name = "JFK Airport — Terminal 4 (AirTrain)",
                borough = "Queens",
                latitude = 40.6439,
                longitude = -73.7820,
                schematicX = 820f,
                schematicY = 560f,
                lines = listOf(SubwayLine.AIRTRAIN, SubwayLine.LINE_A),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "JFK Terminal 4 Arrivals Bridge", isAccessible = true, hasElevator = true)
                ),
                connections = listOf("JFK AirTrain", "Long Island Rail Road at Jamaica", "Subway A Line"),
                services = listOf("Airport Baggage Carts", "AirTrain Ticket Machines", "Elevators", "24/7 Security")
            ),
            Station(
                id = "atlantic_av_barclays",
                name = "Atlantic Av-Barclays Ctr",
                borough = "Brooklyn",
                latitude = 40.6839,
                longitude = -73.9788,
                schematicX = 420f,
                schematicY = 720f,
                lines = listOf(SubwayLine.LINE_2, SubwayLine.LINE_3, SubwayLine.LINE_4, SubwayLine.LINE_5, SubwayLine.LINE_B, SubwayLine.LINE_D, SubwayLine.LINE_N, SubwayLine.LINE_Q, SubwayLine.LINE_R),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "Barclays Center Plaza (Flatbush & Atlantic)", isAccessible = true, hasElevator = true)
                ),
                connections = listOf("LIRR Atlantic Terminal", "B41, B45, B67 Bus"),
                services = listOf("LIRR Ticket Office", "Elevators", "OMNY", "Wi-Fi")
            ),
            Station(
                id = "coney_island_stillwell",
                name = "Coney Island-Stillwell Av",
                borough = "Brooklyn",
                latitude = 40.5772,
                longitude = -73.9812,
                schematicX = 380f,
                schematicY = 880f,
                lines = listOf(SubwayLine.LINE_D, SubwayLine.LINE_F, SubwayLine.LINE_N, SubwayLine.LINE_Q),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "Stillwell Ave & Surf Ave", isAccessible = true, hasElevator = true)
                ),
                connections = listOf("B36, B68, B74, B82 Bus"),
                services = listOf("Solar Canopy Terminal", "Elevators", "OMNY")
            ),
            Station(
                id = "yankee_stadium_161",
                name = "161 St-Yankee Stadium",
                borough = "Bronx",
                latitude = 40.8279,
                longitude = -73.9256,
                schematicX = 350f,
                schematicY = 100f,
                lines = listOf(SubwayLine.LINE_4, SubwayLine.LINE_B, SubwayLine.LINE_D),
                isAccessible = true,
                entrances = listOf(
                    StationEntrance("e1", "River Ave & 161st St (Yankee Stadium)", isAccessible = true, hasElevator = true)
                ),
                connections = listOf("Metro-North Yankees-E 153 St", "Bx6, Bx13 Bus"),
                services = listOf("Stadium Crowd Control Gates", "Elevators", "OMNY")
            )
        )

        stationsList.forEach { graph.addStation(it) }

        // Track edges between connected stations
        val edges = listOf(
            // 1 Line
            GraphEdge("59_st_columbus", "times_sq_42", SubwayLine.LINE_1, 2, directionName = "Downtown / Brooklyn"),
            GraphEdge("times_sq_42", "59_st_columbus", SubwayLine.LINE_1, 2, directionName = "Uptown / Bronx"),
            GraphEdge("times_sq_42", "34_st_herald_sq", SubwayLine.LINE_1, 2, directionName = "Downtown"),
            GraphEdge("34_st_herald_sq", "14_st_union_sq", SubwayLine.LINE_1, 3, directionName = "Downtown"),

            // 4/5 Express Line
            GraphEdge("yankee_stadium_161", "59_st_columbus", SubwayLine.LINE_4, 5, directionName = "Downtown / Manhattan"),
            GraphEdge("59_st_columbus", "grand_central_42", SubwayLine.LINE_4, 3, directionName = "Downtown"),
            GraphEdge("grand_central_42", "14_st_union_sq", SubwayLine.LINE_4, 3, directionName = "Downtown / Brooklyn"),
            GraphEdge("14_st_union_sq", "grand_central_42", SubwayLine.LINE_4, 3, directionName = "Uptown / Bronx"),
            GraphEdge("14_st_union_sq", "fulton_st", SubwayLine.LINE_4, 4, directionName = "Downtown / Brooklyn"),
            GraphEdge("fulton_st", "14_st_union_sq", SubwayLine.LINE_4, 4, directionName = "Uptown / Manhattan"),
            GraphEdge("fulton_st", "atlantic_av_barclays", SubwayLine.LINE_4, 5, directionName = "Brooklyn"),

            // 7 Line
            GraphEdge("times_sq_42", "grand_central_42", SubwayLine.LINE_7, 2, directionName = "Queens-bound"),
            GraphEdge("grand_central_42", "times_sq_42", SubwayLine.LINE_7, 2, directionName = "Manhattan-bound"),
            GraphEdge("grand_central_42", "74_st_broadway", SubwayLine.LINE_7, 8, directionName = "Flushing-bound"),
            GraphEdge("74_st_broadway", "grand_central_42", SubwayLine.LINE_7, 8, directionName = "Manhattan-bound"),

            // A/C/E Lines
            GraphEdge("59_st_columbus", "times_sq_42", SubwayLine.LINE_A, 2, directionName = "Downtown / Brooklyn"),
            GraphEdge("times_sq_42", "fulton_st", SubwayLine.LINE_A, 5, directionName = "Downtown / Brooklyn"),
            GraphEdge("fulton_st", "jfk_terminal_4", SubwayLine.LINE_A, 25, directionName = "Far Rockaway / JFK Airport"),

            // N/Q/R/W Broadway Lines
            GraphEdge("times_sq_42", "34_st_herald_sq", SubwayLine.LINE_N, 2, directionName = "Downtown / Brooklyn"),
            GraphEdge("34_st_herald_sq", "14_st_union_sq", SubwayLine.LINE_N, 3, directionName = "Downtown / Brooklyn"),
            GraphEdge("14_st_union_sq", "atlantic_av_barclays", SubwayLine.LINE_N, 6, directionName = "Brooklyn"),
            GraphEdge("atlantic_av_barclays", "coney_island_stillwell", SubwayLine.LINE_N, 22, directionName = "Coney Island"),

            // L Line
            GraphEdge("times_sq_42", "14_st_union_sq", SubwayLine.LINE_L, 4, isTransfer = false, directionName = "Brooklyn-bound"),

            // In-Station Transfer Corridors
            GraphEdge("times_sq_42", "times_sq_42", SubwayLine.LINE_S, 0, isTransfer = true, transferWalkMins = 2),
            GraphEdge("14_st_union_sq", "14_st_union_sq", SubwayLine.LINE_L, 0, isTransfer = true, transferWalkMins = 3),
            GraphEdge("grand_central_42", "grand_central_42", SubwayLine.LINE_S, 0, isTransfer = true, transferWalkMins = 2)
        )

        edges.forEach { graph.addEdge(it) }
    }

    private fun populateAccessibilityData() {
        _accessibilityEquipments.value = listOf(
            AccessibilityEquipment("E201", "grand_central_42", "Grand Central-42 St", "ELEVATOR", "Main Concourse to 7 Train Platform", EquipmentStatus.AVAILABLE),
            AccessibilityEquipment("E202", "14_st_union_sq", "14 St-Union Sq", "ELEVATOR", "14 St & Broadway Entrance to L Line", EquipmentStatus.AVAILABLE),
            AccessibilityEquipment("E203", "times_sq_42", "Times Sq-42 St", "ELEVATOR", "42nd St Plaza to N/Q/R/W Mezzanine", EquipmentStatus.AVAILABLE),
            AccessibilityEquipment("E204", "34_st_herald_sq", "34 St-Herald Sq", "ELEVATOR", "Herald Sq Plaza to B/D/F/M Level", EquipmentStatus.AVAILABLE),
            AccessibilityEquipment("E205", "fulton_st", "Fulton St", "ELEVATOR", "Fulton Center Concourse to A/C Platform", EquipmentStatus.AVAILABLE),
            AccessibilityEquipment("E206", "74_st_broadway", "74 St-Broadway", "ELEVATOR", "Bus Terminal to 7 Line Elevated Platform", EquipmentStatus.AVAILABLE)
        )
    }

    private fun seedInitialHistoryIfEmpty() {
        scope.launch {
            subwayDao.insertSavedPlace(SavedPlaceEntity("home", "HOME", "HOME", "14_st_union_sq", "Union Square Park, Manhattan"))
            subwayDao.insertSavedPlace(SavedPlaceEntity("work", "WORK", "WORK", "grand_central_42", "Park Ave & 42nd St, Manhattan"))
            subwayDao.insertSavedPlace(SavedPlaceEntity("jfk", "JFK AIRPORT", "AIRPORT", "jfk_terminal_4", "JFK Airport Terminal 4"))

            subwayDao.insertFareTransaction(FareTransactionEntity("tx_101", "08:42 AM", "14 St-Union Sq", "Times Sq-42 St", 2.90, "4", "VISA •••• 4821", "TAP APPROVED"))
            subwayDao.insertFareTransaction(FareTransactionEntity("tx_100", "YESTERDAY 05:15 PM", "Grand Central-42 St", "14 St-Union Sq", 2.90, "7", "VISA •••• 4821", "TAP APPROVED"))

            subwayDao.insertTripHistory(TripHistoryEntity("th_01", System.currentTimeMillis() - 3600000, "14 St-Union Sq", "34 St-Herald Sq", 6, 2.90, "N, Q", true))
        }
    }

    fun searchStations(query: String): List<Station> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return graph.getAllStations()
        return graph.getAllStations().filter { st ->
            st.name.lowercase().contains(q) ||
            st.borough.lowercase().contains(q) ||
            st.lines.any { it.code.lowercase() == q } ||
            st.connections.any { it.lowercase().contains(q) }
        }
    }

    fun setOfflineMode(offline: Boolean) {
        _isOffline.value = offline
    }

    fun recordNewTapIn(stationName: String, lineCode: String) {
        scope.launch {
            val acc = _omnyAccount.value
            val newTrips = acc.weeklyTripCount + 1
            val newSpend = acc.weeklyTotalSpend + 2.90
            _omnyAccount.value = acc.copy(
                weeklyTripCount = newTrips,
                weeklyTotalSpend = newSpend,
                fareCapReached = newSpend >= acc.fareCapThreshold
            )

            val txId = "tx_${System.currentTimeMillis()}"
            subwayDao.insertFareTransaction(
                FareTransactionEntity(
                    id = txId,
                    timestampStr = "JUST NOW",
                    stationName = stationName,
                    exitStationName = null,
                    amount = 2.90,
                    lineCode = lineCode,
                    fareMedia = acc.primaryCardMask,
                    status = "TAP APPROVED"
                )
            )
        }
    }

    fun recordCompletedTrip(origin: String, dest: String, mins: Int, lines: String) {
        scope.launch {
            subwayDao.insertTripHistory(
                TripHistoryEntity(
                    id = "trip_${System.currentTimeMillis()}",
                    timestamp = System.currentTimeMillis(),
                    originName = origin,
                    destinationName = dest,
                    durationMins = mins,
                    fareAmount = 2.90,
                    linesUsed = lines,
                    isAccessible = true
                )
            )
        }
    }
}
