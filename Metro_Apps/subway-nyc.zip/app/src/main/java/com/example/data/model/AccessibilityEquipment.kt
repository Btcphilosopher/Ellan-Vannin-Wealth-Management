package com.example.data.model

enum class EquipmentStatus {
    AVAILABLE,
    OUT_OF_SERVICE,
    UNDER_MAINTENANCE,
    UNKNOWN
}

data class AccessibilityEquipment(
    val id: String,
    val stationId: String,
    val stationName: String,
    val type: String, // ELEVATOR, ESCALATOR
    val locationDescription: String,
    val status: EquipmentStatus,
    val outageDetails: String? = null
)

enum class SavedPlaceCategory {
    HOME, WORK, HOTEL, AIRPORT, CUSTOM
}

data class SavedPlace(
    val id: String,
    val name: String,
    val category: SavedPlaceCategory,
    val stationId: String,
    val address: String
)
