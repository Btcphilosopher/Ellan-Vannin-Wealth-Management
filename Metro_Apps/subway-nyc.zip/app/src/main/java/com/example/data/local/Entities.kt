package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_places")
data class SavedPlaceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val stationId: String,
    val address: String
)

@Entity(tableName = "fare_transactions")
data class FareTransactionEntity(
    @PrimaryKey val id: String,
    val timestampStr: String,
    val stationName: String,
    val exitStationName: String?,
    val amount: Double,
    val lineCode: String,
    val fareMedia: String,
    val status: String
)

@Entity(tableName = "trip_history")
data class TripHistoryEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val originName: String,
    val destinationName: String,
    val durationMins: Int,
    val fareAmount: Double,
    val linesUsed: String,
    val isAccessible: Boolean
)
