package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.SignalCellularOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RouteMode
import com.example.data.viewmodel.AppTab
import com.example.data.viewmodel.TransitViewModel
import com.example.ui.map.SubwayMapCanvas
import com.example.ui.screens.DigitalTwinOpsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OmnyAccountScreen
import com.example.ui.screens.ServiceScreen
import com.example.ui.screens.StationDetailSheet
import com.example.ui.screens.TripPlannerScreen
import com.example.ui.theme.SubwayColors

@Composable
fun MainLayout(
    viewModel: TransitViewModel,
    modifier: Modifier = Modifier
) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filteredStations by viewModel.filteredStations.collectAsState()
    val selectedStation by viewModel.selectedStation.collectAsState()

    val originStation by viewModel.originStation.collectAsState()
    val destStation by viewModel.destStation.collectAsState()
    val routeMode by viewModel.routeMode.collectAsState()
    val calculatedRoutes by viewModel.calculatedRoutes.collectAsState()
    val selectedRoute by viewModel.selectedRoute.collectAsState()

    val activeTripState by viewModel.activeTripState.collectAsState()
    val mapLayerMode by viewModel.mapLayerMode.collectAsState()
    val selectedLineFilter by viewModel.selectedLineFilter.collectAsState()

    val simState by viewModel.simState.collectAsState()
    val activeTrains by viewModel.activeTrains.collectAsState()
    val lineStatuses by viewModel.lineStatuses.collectAsState()
    val activeDisruption by viewModel.activeDisruption.collectAsState()
    val isOffline by viewModel.isOffline.collectAsState()
    val omnyAccount by viewModel.omnyAccount.collectAsState()
    val fareTransactions by viewModel.fareTransactions.collectAsState()
    val accessibilityEquipments by viewModel.accessibilityEquipments.collectAsState()
    val isDigitalTwinOpen by viewModel.isDigitalTwinOpen.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F1012),
                contentColor = Color.White,
                modifier = Modifier.testTag("bottom_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == AppTab.HOME,
                    onClick = { viewModel.selectTab(AppTab.HOME) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("HOME", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = SubwayColors.CautionAmber,
                        indicatorColor = SubwayColors.CautionAmber,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == AppTab.MAP,
                    onClick = { viewModel.selectTab(AppTab.MAP) },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                    label = { Text("MAP", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = SubwayColors.CautionAmber,
                        indicatorColor = SubwayColors.CautionAmber,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == AppTab.TRIPS,
                    onClick = { viewModel.selectTab(AppTab.TRIPS) },
                    icon = { Icon(Icons.Default.AltRoute, contentDescription = "Trips") },
                    label = { Text("TRIPS", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = SubwayColors.CautionAmber,
                        indicatorColor = SubwayColors.CautionAmber,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == AppTab.SERVICE,
                    onClick = { viewModel.selectTab(AppTab.SERVICE) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (activeDisruption != null) {
                                    Badge(containerColor = SubwayColors.EmergencyRed)
                                }
                            }
                        ) {
                            Icon(Icons.Default.WarningAmber, contentDescription = "Service")
                        }
                    },
                    label = { Text("SERVICE", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = SubwayColors.CautionAmber,
                        indicatorColor = SubwayColors.CautionAmber,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == AppTab.ACCOUNT,
                    onClick = { viewModel.selectTab(AppTab.ACCOUNT) },
                    icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Account") },
                    label = { Text("ACCOUNT", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = SubwayColors.CautionAmber,
                        indicatorColor = SubwayColors.CautionAmber,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )
            }
        },
        containerColor = SubwayColors.BackgroundDark
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Persistent Product Header Band
            Surface(
                color = Color(0xFF141518),
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "SUBWAY NYC",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "NYTransitOS v2.8 • MTA DATA MODEL",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = SubwayColors.SecondaryTextDark
                        )
                    }

                    // Offline Badge Button
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isOffline) SubwayColors.EmergencyRed else Color(0xFF22252C),
                        onClick = { viewModel.toggleOfflineMode() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isOffline) {
                                Icon(Icons.Default.SignalCellularOff, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("OFFLINE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            } else {
                                Text("ONLINE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SubwayColors.GoodService)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Ops Control Room Toggle Button
                    IconButton(
                        onClick = { viewModel.toggleDigitalTwin(!isDigitalTwinOpen) }
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeveloperBoard,
                            contentDescription = "Digital Twin Ops",
                            tint = if (isDigitalTwinOpen) SubwayColors.CautionAmber else Color.White
                        )
                    }
                }
            }

            // Disruption Banner (if active)
            activeDisruption?.let { disruptionMsg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SubwayColors.EmergencyRed),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = disruptionMsg,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = { viewModel.executeDemoScenario(1) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("RE-ROUTE", fontSize = 10.sp, fontWeight = FontWeight.Black, color = Color.Black)
                        }
                    }
                }
            }

            // Main Content Area or Digital Twin Ops Control Overlay
            if (isDigitalTwinOpen) {
                DigitalTwinOpsScreen(
                    simState = simState,
                    activeTrains = activeTrains,
                    onSetSpeedMultiplier = { viewModel.repository.simEngine.setSpeedMultiplier(it) },
                    onClose = { viewModel.toggleDigitalTwin(false) }
                )
            } else {
                Box(modifier = Modifier.weight(1f)) {
                    when (selectedTab) {
                        AppTab.HOME -> HomeScreen(
                            searchQuery = searchQuery,
                            onSearchQueryChanged = viewModel::updateSearchQuery,
                            originStation = originStation,
                            destStation = destStation,
                            onSwapStations = viewModel::swapOriginAndDestination,
                            onPlanTrip = { viewModel.selectTab(AppTab.TRIPS) },
                            filteredStations = filteredStations,
                            lineStatuses = lineStatuses,
                            activeTrains = activeTrains,
                            onStationClick = viewModel::selectStation,
                            onDemoScenarioClick = viewModel::executeDemoScenario
                        )
                        AppTab.MAP -> SubwayMapCanvas(
                            stations = repository.graph.getAllStations(),
                            activeTrains = activeTrains,
                            layerMode = mapLayerMode,
                            selectedLineFilter = selectedLineFilter,
                            selectedStation = selectedStation,
                            onStationSelected = viewModel::selectStation,
                            onLayerModeChanged = viewModel::setMapLayerMode,
                            onLineFilterChanged = viewModel::setSelectedLineFilter
                        )
                        AppTab.TRIPS -> TripPlannerScreen(
                            originStation = originStation,
                            destStation = destStation,
                            onSwapStations = viewModel::swapOriginAndDestination,
                            routeMode = routeMode,
                            onRouteModeChanged = viewModel::setRouteMode,
                            calculatedRoutes = calculatedRoutes,
                            selectedRoute = selectedRoute,
                            onSelectRoute = { route -> viewModel.startTripSimulation(route) },
                            activeTripState = activeTripState,
                            onStartTripSimulation = viewModel::startTripSimulation,
                            onResetTrip = viewModel::resetTripState
                        )
                        AppTab.SERVICE -> ServiceScreen(
                            lineStatuses = lineStatuses,
                            accessibilityEquipments = accessibilityEquipments
                        )
                        AppTab.ACCOUNT -> OmnyAccountScreen(
                            omnyAccount = omnyAccount,
                            transactions = fareTransactions,
                            onSimulateTapIn = {
                                viewModel.repository.recordNewTapIn("14 St-Union Sq", "4")
                            }
                        )
                    }
                }
            }
        }
    }

    // Modal Station Detail Sheet (when station tapped)
    selectedStation?.let { st ->
        StationDetailSheet(
            station = st,
            activeTrains = activeTrains,
            onDismiss = { viewModel.selectStation(null) },
            onPlanFromHere = {
                viewModel.setOrigin(it)
                viewModel.selectTab(AppTab.TRIPS)
            },
            onPlanToHere = {
                viewModel.setDestination(it)
                viewModel.selectTab(AppTab.TRIPS)
            }
        )
    }
}
