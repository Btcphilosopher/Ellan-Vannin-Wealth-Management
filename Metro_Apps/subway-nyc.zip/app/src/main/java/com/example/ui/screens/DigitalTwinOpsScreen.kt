package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Train
import com.example.data.simulation.SimulationState
import com.example.ui.theme.SubwayColors

@Composable
fun DigitalTwinOpsScreen(
    simState: SimulationState,
    activeTrains: List<Train>,
    onSetSpeedMultiplier: (Int) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0D0E11))
            .padding(16.dp)
            .testTag("digital_twin_ops_screen")
    ) {
        // Ops Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.DeveloperBoard, contentDescription = null, tint = SubwayColors.CautionAmber, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("NETWORK CONTROL — DIGITAL TWIN OPS", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text("SIMULATION TIME: ${simState.simClockTime}", fontSize = 11.sp, color = SubwayColors.CautionAmber)
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close Ops", tint = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Simulation Speed Controls
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF16181F)),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("SIMULATION CLOCK SPEED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SubwayColors.SecondaryTextDark)
                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val speeds = listOf(
                        1 to "REALTIME (1X)",
                        10 to "FAST (10X)",
                        60 to "EXPRESS (60X)",
                        0 to "PAUSE"
                    )
                    speeds.forEach { (speedVal, label) ->
                        val isSelected = simState.speedMultiplier == speedVal
                        Button(
                            onClick = { onSetSpeedMultiplier(speedVal) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) SubwayColors.CautionAmber else Color(0xFF242732)
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = label,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = if (isSelected) Color.Black else Color.White
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // System Telemetry Metrics
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF16181F)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("ACTIVE TRAINS", fontSize = 10.sp, color = SubwayColors.SecondaryTextDark)
                    Text("${simState.activeTrainCount}", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
                }
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF16181F)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("NETWORK LOAD", fontSize = 10.sp, color = SubwayColors.SecondaryTextDark)
                    Text("${simState.networkLoadPercent}%", fontSize = 20.sp, fontWeight = FontWeight.Black, color = SubwayColors.CautionAmber)
                }
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF16181F)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("ELEVATOR OK", fontSize = 10.sp, color = SubwayColors.SecondaryTextDark)
                    Text("${simState.elevatorOperationalPercent}%", fontSize = 20.sp, fontWeight = FontWeight.Black, color = SubwayColors.GoodService)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("ACTIVE TRAIN FLEET TELEMETRY", fontSize = 11.sp, fontWeight = FontWeight.Black, color = SubwayColors.SecondaryTextDark)
        Spacer(modifier = Modifier.height(8.dp))

        // Train Fleet Table
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(activeTrains) { train ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF16181F)),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = train.line.color,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(train.line.code, fontSize = 11.sp, fontWeight = FontWeight.Black, color = train.textColor)
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${train.trainId} • ${train.direction}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Status: ${train.status.name} • Speed: ${train.speedMph} mph", fontSize = 9.sp, color = SubwayColors.SecondaryTextDark)
                        }
                        Text("${train.estimatedMinsAway}m ETA", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SubwayColors.CautionAmber)
                    }
                }
            }
        }
    }
}
