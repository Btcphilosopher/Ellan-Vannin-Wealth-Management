package com.example.data.model

import com.example.ui.theme.SubwayLine

enum class ServiceStatusType(val label: String) {
    GOOD_SERVICE("GOOD SERVICE"),
    DELAYS("DELAYS"),
    SERVICE_CHANGE("SERVICE CHANGE"),
    PLANNED_WORK("PLANNED WORK")
}

data class SubwayLineInfo(
    val line: SubwayLine,
    val status: ServiceStatusType,
    val summary: String,
    val affectedStations: List<String> = emptyList(),
    val nowNotice: String? = null,
    val plannedNotice: String? = null,
    val stationNotices: List<String> = emptyList(),
    val updatedAt: String = "JUST NOW"
)
