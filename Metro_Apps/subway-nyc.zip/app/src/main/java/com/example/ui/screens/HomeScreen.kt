package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServiceStatusType
import com.example.data.model.Station
import com.example.data.model.SubwayLineInfo
import com.example.data.model.Train
import com.example.ui.theme.SubwayColors
import com.example.ui.theme.SubwayLine

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    searchQuery: String,
    onSearchQueryChanged: (String) -> Unit,
    originStation: Station?,
    destStation: Station?,
    onSwapStations: () -> Unit,
    onPlanTrip: () -> Unit,
    filteredStations: List<Station>,
    lineStatuses: List<SubwayLineInfo>,
    activeTrains: List<Train>,
    onStationClick: (Station) -> Unit,
    onDemoScenarioClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SubwayColors.BackgroundDark)
            .padding(horizontal = 16.dp)
            .testTag("home_screen_list")
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))

            // Interactive Demo Scenarios Carousel Header
            Text(
                text = "DEMO SCENARIOS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = SubwayColors.CautionAmber,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val demos = listOf(
                    1 to "Normal Journey",
                    2 to "Train Delayed",
                    3 to "Station Closed",
                    4 to "Elevator Outage",
                    5 to "Accessible Trip",
                    6 to "Major Disruption",
                    7 to "Offline Mode",
                    8 to "10x Simulation",
                    9 to "OMNY History"
                )
                items(demos) { (id, title) ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFF22252C),
                        onClick = { onDemoScenarioClick(id) }
                    ) {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Destination Search Box
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "WHERE ARE YOU GOING?",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChanged,
                        placeholder = { Text("Station, address, landmark...", color = SubwayColors.SecondaryTextDark) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SubwayColors.CautionAmber) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SubwayColors.CautionAmber,
                            unfocusedBorderColor = Color(0xFF2E313A),
                            focusedContainerColor = Color(0xFF1C1D22),
                            unfocusedContainerColor = Color(0xFF1C1D22),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("destination_search_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Journey Selector (FROM -> TO)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("FROM", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SubwayColors.SecondaryTextDark)
                            Text(
                                text = originStation?.name ?: "Current Location",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        IconButton(onClick = onSwapStations) {
                            Icon(Icons.Default.SwapVert, contentDescription = "Swap", tint = SubwayColors.CautionAmber)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("TO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SubwayColors.SecondaryTextDark)
                            Text(
                                text = destStation?.name ?: "Search Destination",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onPlanTrip,
                        colors = ButtonDefaults.buttonColors(containerColor = SubwayColors.CautionAmber),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("plan_trip_button")
                    ) {
                        Text("PLAN TRIP", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.Black)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // System Operational Condition Summary Header
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SERVICE RIGHT NOW",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = SubwayColors.SecondaryTextDark,
                            letterSpacing = 1.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            color = SubwayColors.GoodService,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "GOOD SERVICE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Line Badges Grid with Operational Status
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        lineStatuses.take(12).forEach { info ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .background(Color(0xFF1C1D22), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = info.line.color,
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(info.line.code, fontSize = 11.sp, fontWeight = FontWeight.Black, color = info.line.textColor)
                                    }
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                val statusText = when (info.status) {
                                    ServiceStatusType.GOOD_SERVICE -> "GOOD"
                                    ServiceStatusType.DELAYS -> "DELAY"
                                    ServiceStatusType.SERVICE_CHANGE -> "CHANGE"
                                    ServiceStatusType.PLANNED_WORK -> "WORK"
                                }
                                val statusColor = when (info.status) {
                                    ServiceStatusType.GOOD_SERVICE -> SubwayColors.GoodService
                                    ServiceStatusType.DELAYS -> SubwayColors.DelayWarning
                                    ServiceStatusType.SERVICE_CHANGE -> SubwayColors.ServiceChange
                                    ServiceStatusType.PLANNED_WORK -> SubwayColors.WorkPlanned
                                }
                                Text(statusText, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = statusColor)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Nearby Stations Header
            Text(
                text = "NEARBY STATIONS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = SubwayColors.SecondaryTextDark,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // List of Stations
        items(filteredStations) { station ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .clickable { onStationClick(station) }
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = station.name.uppercase(),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Text(
                                text = "2 min walk • ${station.borough}",
                                fontSize = 11.sp,
                                color = SubwayColors.SecondaryTextDark
                            )
                        }

                        if (station.isAccessible) {
                            Icon(
                                imageVector = Icons.Default.Accessible,
                                contentDescription = "Accessible",
                                tint = SubwayColors.GoodService,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Station Line Bullets Bar
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        station.lines.forEach { line ->
                            Surface(
                                shape = CircleShape,
                                color = line.color,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(line.code, fontSize = 12.sp, fontWeight = FontWeight.Black, color = line.textColor)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(12.dp))

            // Special JFK Airport Connector Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0039A6)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Flight, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("AIRPORT MODE — JFK CONNECTOR", fontSize = 12.sp, fontWeight = FontWeight.Black, color = SubwayColors.CautionAmber)
                        Text("A Train to Howard Beach -> AirTrain Terminal 4", fontSize = 11.sp, color = Color.White)
                    }
                }
            }
        }
    }
}
