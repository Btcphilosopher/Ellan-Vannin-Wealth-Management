package com.example.data.routing

import com.example.data.model.Station
import com.example.ui.theme.SubwayLine

data class GraphEdge(
    val fromStationId: String,
    val toStationId: String,
    val line: SubwayLine,
    val durationMins: Int = 2,
    val isTransfer: Boolean = false,
    val transferWalkMins: Int = 0,
    val directionName: String = "Inbound"
)

class SubwayGraph {
    private val stations = mutableMapOf<String, Station>()
    private val adjacencyList = mutableMapOf<String, MutableList<GraphEdge>>()

    fun addStation(station: Station) {
        stations[station.id] = station
        if (!adjacencyList.containsKey(station.id)) {
            adjacencyList[station.id] = mutableListOf()
        }
    }

    fun addEdge(edge: GraphEdge) {
        adjacencyList[edge.fromStationId]?.add(edge)
    }

    fun getStation(id: String): Station? = stations[id]

    fun getAllStations(): List<Station> = stations.values.toList()

    fun getNeighbors(stationId: String): List<GraphEdge> = adjacencyList[stationId] ?: emptyList()
}
