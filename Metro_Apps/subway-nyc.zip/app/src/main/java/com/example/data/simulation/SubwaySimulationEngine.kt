package com.example.data.simulation

import com.example.data.model.ServiceStatusType
import com.example.data.model.SubwayLineInfo
import com.example.data.model.Train
import com.example.data.model.TrainStatus
import com.example.ui.theme.SubwayLine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

data class SimulationState(
    val simClockTime: String = "08:42:15",
    val speedMultiplier: Int = 1, // 1x, 10x, 60x, 0 = paused
    val activeTrainCount: Int = 28,
    val networkLoadPercent: Int = 82,
    val averageHeadwaySecs: Int = 210,
    val elevatorOperationalPercent: Float = 94.2f
)

class SubwaySimulationEngine(private val scope: CoroutineScope) {

    private val _simState = MutableStateFlow(SimulationState())
    val simState: StateFlow<SimulationState> = _simState.asStateFlow()

    private val _activeTrains = MutableStateFlow<List<Train>>(emptyList())
    val activeTrains: StateFlow<List<Train>> = _activeTrains.asStateFlow()

    private val _lineStatuses = MutableStateFlow<List<SubwayLineInfo>>(emptyList())
    val lineStatuses: StateFlow<List<SubwayLineInfo>> = _lineStatuses.asStateFlow()

    private val _activeDisruption = MutableStateFlow<String?>(null)
    val activeDisruption: StateFlow<String?> = _activeDisruption.asStateFlow()

    private var simJob: Job? = null
    private var secondsCounter = 0

    init {
        initializeInitialState()
        startSimulation()
    }

    private fun initializeInitialState() {
        val initialTrains = listOf(
            Train("T101", SubwayLine.LINE_1, "Uptown / Bronx", "times_sq_42", "59_st_columbus", 0.35f, 32, TrainStatus.RUNNING, 3, 2),
            Train("T102", SubwayLine.LINE_1, "Downtown / Brooklyn", "59_st_columbus", "times_sq_42", "times_sq_42", 0.85f, 28, TrainStatus.APPROACHING, 1, 1),
            Train("T401", SubwayLine.LINE_4, "Downtown / Brooklyn", "grand_central_42", "14_st_union_sq", 0.60f, 35, TrainStatus.RUNNING, 4, 3),
            Train("T402", SubwayLine.LINE_4, "Uptown / Bronx", "14_st_union_sq", "grand_central_42", 0.10f, 0, TrainStatus.DWELLING, 2, 2),
            Train("T701", SubwayLine.LINE_7, "Queens-bound", "times_sq_42", "grand_central_42", 0.45f, 30, TrainStatus.RUNNING, 5, 4),
            Train("T702", SubwayLine.LINE_7, "Manhattan-bound", "74_st_broadway", "queensboro_plz", 0.70f, 34, TrainStatus.RUNNING, 3, 2),
            Train("TA01", SubwayLine.LINE_A, "Downtown / Brooklyn", "59_st_columbus", "42_st_port_auth", 0.90f, 20, TrainStatus.ARRIVING, 1, 1),
            Train("TC01", SubwayLine.LINE_C, "Uptown", "14_st_ace", "34_st_penn", 0.20f, 28, TrainStatus.RUNNING, 6, 5),
            Train("TL01", SubwayLine.LINE_L, "Brooklyn / Canarsie", "14_st_eighth_av", "14_st_union_sq", 0.50f, 25, TrainStatus.RUNNING, 2, 2),
            Train("TN01", SubwayLine.LINE_N, "Astoria-bound", "34_st_herald_sq", "times_sq_42", 0.80f, 30, TrainStatus.APPROACHING, 2, 2)
        )
        _activeTrains.value = initialTrains

        val linesList = SubwayLine.entries.map { line ->
            when (line) {
                SubwayLine.LINE_A -> SubwayLineInfo(
                    line = line,
                    status = ServiceStatusType.SERVICE_CHANGE,
                    summary = "Manhattan-bound trains run express from 125 St to 59 St.",
                    affectedStations = listOf("116 St", "103 St", "86 St"),
                    nowNotice = "Signal modernization work in progress near 59 St-Columbus Circle."
                )
                SubwayLine.LINE_3 -> SubwayLineInfo(
                    line = line,
                    status = ServiceStatusType.DELAYS,
                    summary = "Delays in both directions following mechanical check at Fulton St.",
                    nowNotice = "FDNY response at Fulton St cleared. Resuming regular service."
                )
                SubwayLine.LINE_7 -> SubwayLineInfo(
                    line = line,
                    status = ServiceStatusType.GOOD_SERVICE,
                    summary = "Good Service",
                    nowNotice = "CBTC automatic train control operational across Flushing line."
                )
                else -> SubwayLineInfo(
                    line = line,
                    status = ServiceStatusType.GOOD_SERVICE,
                    summary = "Good Service"
                )
            }
        }
        _lineStatuses.value = linesList
    }

    fun startSimulation() {
        simJob?.cancel()
        simJob = scope.launch(Dispatchers.Default) {
            while (true) {
                val speed = _simState.value.speedMultiplier
                if (speed > 0) {
                    delay(1000L / speed)
                    tickSimulation()
                } else {
                    delay(500L)
                }
            }
        }
    }

    private fun tickSimulation() {
        secondsCounter++
        val hours = (8 + (secondsCounter / 3600)) % 24
        val mins = (42 + (secondsCounter / 60)) % 60
        val secs = secondsCounter % 60
        val clockStr = String.format("%02d:%02d:%02d", hours, mins, secs)

        _simState.value = _simState.value.copy(simClockTime = clockStr)

        // Advance train positions
        val updatedTrains = _activeTrains.value.map { train ->
            var newProgress = train.progressPercent + 0.05f
            var newStatus = train.status
            var newMins = train.estimatedMinsAway

            if (newProgress >= 1.0f) {
                newProgress = 0.0f
                newStatus = TrainStatus.DWELLING
                newMins = if (newMins > 0) newMins - 1 else 3
            } else if (newProgress > 0.8f) {
                newStatus = TrainStatus.ARRIVING
            } else if (newProgress > 0.6f) {
                newStatus = TrainStatus.APPROACHING
            } else {
                newStatus = TrainStatus.RUNNING
            }

            train.copy(
                progressPercent = newProgress,
                status = newStatus,
                estimatedMinsAway = newMins
            )
        }
        _activeTrains.value = updatedTrains
    }

    fun setSpeedMultiplier(mult: Int) {
        _simState.value = _simState.value.copy(speedMultiplier = mult)
        startSimulation()
    }

    fun triggerDisruptionScenario(scenarioName: String) {
        when (scenarioName) {
            "TRAIN_DELAYED" -> {
                _activeDisruption.value = "ALERT: 4 Train experiencing signal delays near Union Sq. ETA +6 mins."
                val updatedLines = _lineStatuses.value.map {
                    if (it.line == SubwayLine.LINE_4) it.copy(status = ServiceStatusType.DELAYS, summary = "Signal delays at 14 St-Union Sq") else it
                }
                _lineStatuses.value = updatedLines
            }
            "STATION_CLOSED" -> {
                _activeDisruption.value = "ALERT: 34 St-Herald Sq B/D/F/M level temporarily closed for police investigation."
            }
            "ELEVATOR_OUTAGE" -> {
                _activeDisruption.value = "ALERT: Elevator E204 at Grand Central-42 St OUT OF SERVICE for emergency repair."
            }
            "MAJOR_DISRUPTION" -> {
                _activeDisruption.value = "CRITICAL: Power surge on 8th Av line. A/C/E trains suspended between 59 St and Canal St."
            }
            else -> {
                _activeDisruption.value = null
            }
        }
    }

    fun clearDisruption() {
        _activeDisruption.value = null
    }

    private fun Train(
        trainId: String,
        line: SubwayLine,
        direction: String,
        currentStationId: String,
        nextStationId: String,
        progressPercent: Float,
        speedMph: Int,
        status: TrainStatus,
        scheduledMinsAway: Int,
        estimatedMinsAway: Int
    ): Train {
        return Train(
            trainId = trainId,
            line = line,
            direction = direction,
            currentStationId = currentStationId,
            nextStationId = nextStationId,
            progressPercent = progressPercent,
            speedMph = speedMph,
            status = status,
            scheduledMinsAway = scheduledMinsAway,
            estimatedMinsAway = estimatedMinsAway,
            headwaySecs = 240
        )
    }
}
