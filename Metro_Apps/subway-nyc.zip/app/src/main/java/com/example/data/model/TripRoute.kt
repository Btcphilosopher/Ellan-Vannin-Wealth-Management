package com.example.data.model

import com.example.ui.theme.SubwayLine

enum class RouteMode {
    FASTEST,
    FEWEST_TRANSFERS,
    LEAST_WALKING,
    ACCESSIBLE
}

data class RouteSegment(
    val line: SubwayLine,
    val fromStationId: String,
    val fromStationName: String,
    val toStationId: String,
    val toStationName: String,
    val stopsCount: Int,
    val directionName: String,
    val departureTimeStr: String,
    val arrivalTimeStr: String,
    val isTransfer: Boolean = false,
    val transferWalkMins: Int = 0,
    val transferInstructions: String? = null
)

data class TripRoute(
    val id: String,
    val originStationId: String,
    val originStationName: String,
    val destStationId: String,
    val destStationName: String,
    val totalDurationMins: Int,
    val walkingTimeMins: Int,
    val transfersCount: Int,
    val isAccessible: Boolean,
    val segments: List<RouteSegment>,
    val warningNotice: String? = null,
    val mode: RouteMode = RouteMode.FASTEST
)
