package com.example.data.model

data class OmnyAccount(
    val accountId: String = "OMNY-NY-8842-1092",
    val primaryCardMask: String = "VISA •••• 4821",
    val paymentType: String = "CONTACTLESS MOBILE / VISA",
    val weeklyTripCount: Int = 11,
    val weeklyTotalSpend: Double = 31.90, // 11 * $2.90
    val fareCapThreshold: Double = 34.00, // NYC 7-Day Fare Cap is $34.00
    val fareCapReached: Boolean = false,
    val remainingCapSpend: Double = 2.10
)

data class FareTransaction(
    val id: String,
    val timestampStr: String,
    val stationName: String,
    val exitStationName: String? = null,
    val amount: Double = 2.90,
    val lineCode: String,
    val fareMedia: String = "VISA •••• 4821",
    val status: String = "TAP APPROVED"
)
