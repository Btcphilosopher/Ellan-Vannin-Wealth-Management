package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Elevator
import androidx.compose.material.icons.filled.Escalator
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Station
import com.example.data.model.Train
import com.example.ui.theme.SubwayColors
import com.example.ui.theme.SubwayLine

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun StationDetailSheet(
    station: Station,
    activeTrains: List<Train>,
    onDismiss: () -> Unit,
    onPlanFromHere: (Station) -> Unit,
    onPlanToHere: (Station) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF141518),
        scrimColor = Color.Black.copy(alpha = 0.7f),
        modifier = Modifier.testTag("station_detail_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            // Station Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = station.name.uppercase(),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = Color(0xFF242730),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = station.borough.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SubwayColors.SecondaryTextDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        if (station.isAccessible) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = Color(0xFF00933C),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Accessible,
                                        contentDescription = "Accessible",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ACCESSIBLE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Line Bullets Bar
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                station.lines.forEach { line ->
                    Surface(
                        shape = CircleShape,
                        color = line.color,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = line.code,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = line.textColor
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons
            Row(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { onPlanFromHere(station); onDismiss() },
                    colors = ButtonDefaults.buttonColors(containerColor = SubwayColors.CautionAmber),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 6.dp)
                ) {
                    Text("PLAN FROM HERE", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color.Black)
                }
                OutlinedButton(
                    onClick = { onPlanToHere(station); onDismiss() },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("PLAN TO HERE", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Live Train Departures
            Text(
                text = "NEXT TRAINS — LIVE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SubwayColors.CautionAmber,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            val stationTrains = activeTrains.filter { it.currentStationId == station.id || it.nextStationId == station.id }
            if (stationTrains.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1D22)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DirectionsSubway, contentDescription = null, tint = SubwayColors.GoodService)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("4 TRAIN — Downtown — 2 MIN", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    stationTrains.take(4).forEach { train ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1D22)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = train.line.color,
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(train.line.code, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = train.textColor)
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(train.direction, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text("Status: ${train.status.name}", fontSize = 10.sp, color = SubwayColors.SecondaryTextDark)
                                }
                                Text(
                                    text = "${train.estimatedMinsAway} MIN",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = SubwayColors.CautionAmber
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Entrances & Accessibility Equipment
            Text(
                text = "ENTRANCES & EQUIPMENT",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SubwayColors.SecondaryTextDark,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            station.entrances.forEach { entrance ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(entrance.locationName, fontSize = 12.sp, color = Color.White, modifier = Modifier.weight(1f))
                    if (entrance.hasElevator) {
                        Icon(Icons.Default.Elevator, contentDescription = "Elevator", tint = SubwayColors.GoodService, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    if (entrance.hasEscalator) {
                        Icon(Icons.Default.Escalator, contentDescription = "Escalator", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                    }
                }
            }

            if (station.connections.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "TRANSIT CONNECTIONS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = SubwayColors.SecondaryTextDark,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = station.connections.joinToString(" • "),
                    fontSize = 12.sp,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
