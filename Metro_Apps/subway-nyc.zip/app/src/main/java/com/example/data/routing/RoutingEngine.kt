package com.example.data.routing

import com.example.data.model.RouteMode
import com.example.data.model.RouteSegment
import com.example.data.model.Station
import com.example.data.model.TripRoute
import com.example.ui.theme.SubwayLine
import java.util.PriorityQueue

class RoutingEngine(private val graph: SubwayGraph) {

    data class PathNode(
        val stationId: String,
        val cost: Double,
        val lastLine: SubwayLine?,
        val parentNode: PathNode?,
        val edgeFromParent: GraphEdge?
    ) : Comparable<PathNode> {
        override fun compareTo(other: PathNode): Int = cost.compareTo(other.cost)
    }

    fun calculateRoute(
        originId: String,
        destId: String,
        mode: RouteMode = RouteMode.FASTEST,
        disabledElevatorStations: Set<String> = emptySet(),
        suspendedLines: Set<SubwayLine> = emptySet()
    ): TripRoute? {
        val origin = graph.getStation(originId) ?: return null
        val dest = graph.getStation(destId) ?: return null

        if (originId == destId) return null

        val pq = PriorityQueue<PathNode>()
        val minCostMap = mutableMapOf<Pair<String, SubwayLine?>, Double>()

        pq.add(PathNode(originId, 0.0, null, null, null))
        minCostMap[Pair(originId, null)] = 0.0

        var bestDestinationNode: PathNode? = null

        while (pq.isNotEmpty()) {
            val current = pq.poll() ?: break

            if (current.stationId == destId) {
                bestDestinationNode = current
                break
            }

            val currentStation = graph.getStation(current.stationId) ?: continue

            // If accessible required and elevator out of service at this station, skip if transfer
            if (mode == RouteMode.ACCESSIBLE && disabledElevatorStations.contains(current.stationId)) {
                if (!currentStation.isAccessible) continue
            }

            for (edge in graph.getNeighbors(current.stationId)) {
                if (suspendedLines.contains(edge.line)) continue

                val targetStation = graph.getStation(edge.toStationId) ?: continue
                if (mode == RouteMode.ACCESSIBLE && (!targetStation.isAccessible || disabledElevatorStations.contains(targetStation.id))) {
                    continue
                }

                // Calculate edge weight based on route mode
                val transferPenalty = if (current.lastLine != null && current.lastLine != edge.line) {
                    when (mode) {
                        RouteMode.FEWEST_TRANSFERS -> 18.0
                        RouteMode.LEAST_WALKING -> 12.0
                        RouteMode.ACCESSIBLE -> 10.0
                        RouteMode.FASTEST -> 5.0
                    }
                } else 0.0

                val walkWeight = if (edge.isTransfer) {
                    when (mode) {
                        RouteMode.LEAST_WALKING -> edge.transferWalkMins * 3.0
                        else -> edge.transferWalkMins * 1.5
                    }
                } else edge.durationMins.toDouble()

                val newCost = current.cost + walkWeight + transferPenalty

                val key = Pair(edge.toStationId, edge.line)
                val existingCost = minCostMap[key] ?: Double.MAX_VALUE

                if (newCost < existingCost) {
                    minCostMap[key] = newCost
                    pq.add(PathNode(edge.toStationId, newCost, edge.line, current, edge))
                }
            }
        }

        if (bestDestinationNode == null) return null

        // Reconstruct path
        val pathEdges = mutableListOf<GraphEdge>()
        var curr: PathNode? = bestDestinationNode
        while (curr?.edgeFromParent != null) {
            pathEdges.add(0, curr.edgeFromParent!!)
            curr = curr.parentNode
        }

        if (pathEdges.isEmpty()) return null

        // Group path edges into clean RouteSegments
        val segments = mutableListOf<RouteSegment>()
        var currentLine: SubwayLine? = null
        var segStartStationId: String? = null
        var segStartStationName: String? = null
        var segStopsCount = 0
        var segDirection = ""
        var totalWalkMins = 0
        var totalTransfers = 0

        for ((index, edge) in pathEdges.withIndex()) {
            if (edge.isTransfer) {
                totalWalkMins += edge.transferWalkMins
                totalTransfers++
                val fromSt = graph.getStation(edge.fromStationId)?.name ?: edge.fromStationId
                val toSt = graph.getStation(edge.toStationId)?.name ?: edge.toStationId
                segments.add(
                    RouteSegment(
                        line = edge.line,
                        fromStationId = edge.fromStationId,
                        fromStationName = fromSt,
                        toStationId = edge.toStationId,
                        toStationName = toSt,
                        stopsCount = 0,
                        directionName = "Transfer Walk",
                        departureTimeStr = "+${index * 2}m",
                        arrivalTimeStr = "+${index * 2 + edge.transferWalkMins}m",
                        isTransfer = true,
                        transferWalkMins = edge.transferWalkMins,
                        transferInstructions = "Follow signs for ${edge.line.code} Train transfer passageway"
                    )
                )
            } else {
                if (currentLine != edge.line) {
                    if (currentLine != null && segStartStationId != null && segStartStationName != null) {
                        val prevEdge = pathEdges[index - 1]
                        val endStName = graph.getStation(prevEdge.toStationId)?.name ?: prevEdge.toStationId
                        segments.add(
                            RouteSegment(
                                line = currentLine!!,
                                fromStationId = segStartStationId!!,
                                fromStationName = segStartStationName!!,
                                toStationId = prevEdge.toStationId,
                                toStationName = endStName,
                                stopsCount = segStopsCount,
                                directionName = segDirection,
                                departureTimeStr = "08:${10 + index * 2}",
                                arrivalTimeStr = "08:${10 + index * 2 + segStopsCount * 2}"
                            )
                        )
                    }
                    currentLine = edge.line
                    segStartStationId = edge.fromStationId
                    segStartStationName = graph.getStation(edge.fromStationId)?.name ?: edge.fromStationId
                    segStopsCount = 1
                    segDirection = edge.directionName
                } else {
                    segStopsCount++
                }
            }
        }

        if (currentLine != null && segStartStationId != null && segStartStationName != null) {
            val lastEdge = pathEdges.last()
            val endStName = graph.getStation(lastEdge.toStationId)?.name ?: lastEdge.toStationId
            segments.add(
                RouteSegment(
                    line = currentLine!!,
                    fromStationId = segStartStationId!!,
                    fromStationName = segStartStationName!!,
                    toStationId = lastEdge.toStationId,
                    toStationName = endStName,
                    stopsCount = segStopsCount,
                    directionName = segDirection,
                    departureTimeStr = "08:15",
                    arrivalTimeStr = "08:${15 + segStopsCount * 2}"
                )
            )
        }

        val totalMins = pathEdges.sumOf { if (it.isTransfer) it.transferWalkMins else it.durationMins }

        val warning = if (suspendedLines.isNotEmpty()) "Service modifications on affected lines." else null

        return TripRoute(
            id = "route_${System.currentTimeMillis()}",
            originStationId = originId,
            originStationName = origin.name,
            destStationId = destId,
            destStationName = dest.name,
            totalDurationMins = totalMins,
            walkingTimeMins = totalWalkMins,
            transfersCount = totalTransfers,
            isAccessible = mode == RouteMode.ACCESSIBLE || (origin.isAccessible && dest.isAccessible),
            segments = segments,
            warningNotice = warning,
            mode = mode
        )
    }
}
