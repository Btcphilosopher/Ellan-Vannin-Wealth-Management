package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RouteMode
import com.example.data.model.Station
import com.example.data.model.TripRoute
import com.example.data.viewmodel.ActiveTripState
import com.example.data.viewmodel.ActiveTripStatus
import com.example.ui.theme.SubwayColors

@Composable
fun TripPlannerScreen(
    originStation: Station?,
    destStation: Station?,
    onSwapStations: () -> Unit,
    routeMode: RouteMode,
    onRouteModeChanged: (RouteMode) -> Unit,
    calculatedRoutes: List<TripRoute>,
    selectedRoute: TripRoute?,
    onSelectRoute: (TripRoute) -> Unit,
    activeTripState: ActiveTripState,
    onStartTripSimulation: (TripRoute) -> Unit,
    onResetTrip: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SubwayColors.BackgroundDark)
            .padding(horizontal = 16.dp)
            .testTag("trip_planner_screen")
    ) {
        item {
            Spacer(modifier = Modifier.height(12.dp))

            // Origin / Destination Box
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141518)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "TRIP PLANNER",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = SubwayColors.CautionAmber,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ORIGIN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SubwayColors.SecondaryTextDark)
                            Text(
                                text = originStation?.name?.uppercase() ?: "SELECT ORIGIN",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }

                        IconButton(onClick = onSwapStations) {
                            Icon(Icons.Default.SwapVert, contentDescription = "Swap Origin/Dest", tint = SubwayColors.CautionAmber)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("DESTINATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SubwayColors.SecondaryTextDark)
                            Text(
                                text = destStation?.name?.uppercase() ?: "SELECT DESTINATION",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Route Preferences Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                RouteMode.entries.forEach { mode ->
                    val isSelected = routeMode == mode
                    FilterChip(
                        selected = isSelected,
                        onClick = { onRouteModeChanged(mode) },
                        label = {
                            Text(
                                text = when (mode) {
                                    RouteMode.FASTEST -> "FASTEST"
                                    RouteMode.FEWEST_TRANSFERS -> "FEWEST TRANSFERS"
                                    RouteMode.LEAST_WALKING -> "LEAST WALKING"
                                    RouteMode.ACCESSIBLE -> "ACCESSIBLE"
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SubwayColors.CautionAmber,
                            selectedLabelColor = Color.Black,
                            containerColor = Color(0xFF1E2026),
                            labelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Active Journey Simulation Status Banner (Vertical Slice)
            if (activeTripState.status != ActiveTripStatus.IDLE) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF00933C)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DirectionsSubway, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "TRIP IN PROGRESS — ${activeTripState.status.name}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Next: ${activeTripState.nextStationName} • ETA: ${activeTripState.etaMins} mins",
                            fontSize = 12.sp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = activeTripState.progressPercent,
                            color = SubwayColors.CautionAmber,
                            trackColor = Color(0xFF006020),
                            modifier = Modifier.fillMaxWidth().height(6.dp)
                        )
                        if (activeTripState.status == ActiveTripStatus.ARRIVED) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = onResetTrip,
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text("COMPLETE TRIP & DISMISS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            }
                        }
                    }
                }
            }

            Text(
                text = "CALCULATED ROUTES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = SubwayColors.SecondaryTextDark,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // List of Calculated Routes
        items(calculatedRoutes) { route ->
            val isSelected = selectedRoute?.id == route.id

            Card(
                colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF22252D) else Color(0xFF141518)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(
                        width = if (isSelected) 2.dp else 0.dp,
                        color = if (isSelected) SubwayColors.CautionAmber else Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable { onSelectRoute(route) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${route.totalDurationMins} MIN",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = SubwayColors.CautionAmber
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "${route.transfersCount} transfers • ${route.walkingTimeMins}m walk",
                            fontSize = 12.sp,
                            color = SubwayColors.SecondaryTextDark,
                            modifier = Modifier.weight(1f)
                        )
                        if (route.isAccessible) {
                            Icon(Icons.Default.Accessible, contentDescription = "Accessible", tint = SubwayColors.GoodService)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Timeline Route Segments
                    Column {
                        route.segments.forEachIndexed { idx, seg ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (seg.isTransfer) Color.DarkGray else seg.line.color,
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = if (seg.isTransfer) "WALK" else seg.line.code,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Black,
                                            color = if (seg.isTransfer) Color.White else seg.line.textColor
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${seg.fromStationName} → ${seg.toStationName}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = if (seg.isTransfer) "Transfer corridor (${seg.transferWalkMins} min)" else "${seg.directionName} • ${seg.stopsCount} stops",
                                        fontSize = 10.sp,
                                        color = SubwayColors.SecondaryTextDark
                                    )
                                }
                            }
                            if (idx < route.segments.size - 1) {
                                Box(
                                    modifier = Modifier
                                        .padding(start = 12.dp, top = 2.dp, bottom = 2.dp)
                                        .width(2.dp)
                                        .height(14.dp)
                                        .background(Color.Gray)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { onStartTripSimulation(route) },
                        colors = ButtonDefaults.buttonColors(containerColor = SubwayColors.CautionAmber),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("start_trip_simulation_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("START JOURNEY SIMULATION", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.Black)
                    }
                }
            }
        }
    }
}
