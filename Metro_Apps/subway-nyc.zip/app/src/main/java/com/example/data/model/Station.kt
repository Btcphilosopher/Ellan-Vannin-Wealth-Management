package com.example.data.model

import com.example.ui.theme.SubwayLine

data class Station(
    val id: String,
    val name: String,
    val borough: String, // Manhattan, Brooklyn, Queens, Bronx, Staten Island
    val latitude: Double,
    val longitude: Double,
    val schematicX: Float,
    val schematicY: Float,
    val lines: List<SubwayLine>,
    val isAccessible: Boolean,
    val entrances: List<StationEntrance> = emptyList(),
    val connections: List<String> = emptyList(), // LIRR, PATH, Bus, AirTrain
    val services: List<String> = emptyList() // Wi-Fi, Restrooms, OMNY, Customer Service
)

data class StationEntrance(
    val id: String,
    val locationName: String,
    val isAccessible: Boolean,
    val hasElevator: Boolean = false,
    val hasEscalator: Boolean = false
)
