package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SubwayDao {

    @Query("SELECT * FROM saved_places")
    fun getAllSavedPlaces(): Flow<List<SavedPlaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedPlace(place: SavedPlaceEntity)

    @Query("DELETE FROM saved_places WHERE id = :id")
    suspend fun deleteSavedPlace(id: String)

    @Query("SELECT * FROM fare_transactions ORDER BY id DESC")
    fun getAllFareTransactions(): Flow<List<FareTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFareTransaction(transaction: FareTransactionEntity)

    @Query("SELECT * FROM trip_history ORDER BY timestamp DESC")
    fun getAllTripHistory(): Flow<List<TripHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTripHistory(trip: TripHistoryEntity)
}
