package com.example

import com.example.data.model.RouteMode
import com.example.data.model.Station
import com.example.data.routing.GraphEdge
import com.example.data.routing.RoutingEngine
import com.example.data.routing.SubwayGraph
import com.example.ui.theme.SubwayLine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testSubwayGraphRouting() {
        val graph = SubwayGraph()

        val unionSq = Station(
            id = "14_st_union_sq",
            name = "14 St-Union Sq",
            borough = "Manhattan",
            latitude = 40.7359,
            longitude = -73.9905,
            schematicX = 350f,
            schematicY = 480f,
            lines = listOf(SubwayLine.LINE_4, SubwayLine.LINE_N),
            isAccessible = true
        )

        val heraldSq = Station(
            id = "34_st_herald_sq",
            name = "34 St-Herald Sq",
            borough = "Manhattan",
            latitude = 40.7497,
            longitude = -73.9877,
            schematicX = 350f,
            schematicY = 380f,
            lines = listOf(SubwayLine.LINE_N),
            isAccessible = true
        )

        graph.addStation(unionSq)
        graph.addStation(heraldSq)

        graph.addEdge(
            GraphEdge(
                fromStationId = "14_st_union_sq",
                toStationId = "34_st_herald_sq",
                line = SubwayLine.LINE_N,
                durationMins = 3,
                directionName = "Uptown"
            )
        )

        val engine = RoutingEngine(graph)
        val route = engine.calculateRoute("14_st_union_sq", "34_st_herald_sq", RouteMode.FASTEST)

        assertNotNull(route)
        assertEquals("14 St-Union Sq", route?.originStationName)
        assertEquals("34 St-Herald Sq", route?.destStationName)
        assertEquals(3, route?.totalDurationMins)
    }
}
