package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// --- UI AND SIMULATION DATA STRUCTURES ---

enum class AppTab {
    INICIO, PLANIFICAR, COMPRAR, BILLETERA, ESTACIONES, SIMULADOR, MAS
}

enum class PurchaseStep {
    SELECT_JOURNEY, PASSENGER_DETAILS, SELECT_SEAT, FAKE_PAYMENT, CONFIRMATION
}

data class PassengerForm(
    val firstName: String = "",
    val lastName: String = "",
    val document: String = "",
    val type: String = "Regular", // "Regular", "Estudiante", "Adulto Mayor"
    val needsAccessibility: Boolean = false,
    val hasBicycle: Boolean = false
)

data class SimTrain(
    val id: String,
    val name: String,
    val line: String,
    val origin: String,
    val destination: String,
    val currentStation: String,
    val status: String, // "En ruta", "Detenido", "Demorado"
    val occupancyPercent: Int,
    val progress: Float, // 0.0 to 1.0 between stations
    val directionForward: Boolean
)

data class SimMetrics(
    val punctualityPercent: Int = 98,
    val passengersTransported: Int = 1420,
    val averageBoardingTimeSec: Int = 45,
    val validTickets: Int = 1380,
    val rejectedTickets: Int = 12,
    val averageOccupancyPercent: Int = 62,
    val currentActiveTrains: Int = 4,
    val avgTransferTimeMin: Int = 8
)

sealed interface ValidationUiState {
    object Idle : ValidationUiState
    object Scanning : ValidationUiState
    object Verifying : ValidationUiState
    data class Success(val ticket: TicketEntity) : ValidationUiState
    data class Error(val reason: String) : ValidationUiState
}

class RailViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = RailRepository(db)

    // --- MAIN APP STATE ---
    private val _currentTab = MutableStateFlow(AppTab.INICIO)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    // --- REPOSITORY DATA ---
    val stations: StateFlow<List<StationEntity>> = repository.stations.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val tickets: StateFlow<List<TicketEntity>> = repository.tickets.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val transitCard: StateFlow<CardEntity?> = repository.card.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    // --- PLANNER / SEARCH STATE ---
    val searchOrigin = MutableStateFlow("asu")
    val searchDestination = MutableStateFlow("ypa")
    val searchDate = MutableStateFlow("2026-09-22")
    val searchPassengerCount = MutableStateFlow(1)
    val searchFilter = MutableStateFlow("Rapido") // "Rapido", "Economico", "Directo"
    
    private val _searchResults = MutableStateFlow<List<TrainJourney>>(emptyList())
    val searchResults: StateFlow<List<TrainJourney>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    // --- TICKET PURCHASE FLOW STATE ---
    private val _purchaseStep = MutableStateFlow(PurchaseStep.SELECT_JOURNEY)
    val purchaseStep: StateFlow<PurchaseStep> = _purchaseStep.asStateFlow()

    private val _selectedJourney = MutableStateFlow<TrainJourney?>(null)
    val selectedJourney: StateFlow<TrainJourney?> = _selectedJourney.asStateFlow()

    val passengerForm = MutableStateFlow(PassengerForm())
    
    private val _selectedSeat = MutableStateFlow("")
    val selectedSeat: StateFlow<String> = _selectedSeat.asStateFlow()

    private val _selectedPaymentMethod = MutableStateFlow("Tarjeta de Crédito") // "Tarjeta de Crédito", "Tarjeta de Débito", "Tarjeta Ferroviaria", "Billetera Digital"
    val selectedPaymentMethod: StateFlow<String> = _selectedPaymentMethod.asStateFlow()

    private val _isProcessingPayment = MutableStateFlow(false)
    val isProcessingPayment: StateFlow<Boolean> = _isProcessingPayment.asStateFlow()

    private val _lastPurchasedTicketId = MutableStateFlow<Long?>(null)
    val lastPurchasedTicketId: StateFlow<Long?> = _lastPurchasedTicketId.asStateFlow()

    // --- LIVE SIMULATION OPERATIONAL STATE ---
    private val _simActive = MutableStateFlow(true)
    val simActive: StateFlow<Boolean> = _simActive.asStateFlow()

    private val _simScenario = MutableStateFlow("Día normal") // "Día normal", "Hora punta", "Demora de 10 minutos", "Estación cerrada", "Aumento de pasajeros"
    val simScenario: StateFlow<String> = _simScenario.asStateFlow()

    private val _simTrains = MutableStateFlow<List<SimTrain>>(emptyList())
    val simTrains: StateFlow<List<SimTrain>> = _simTrains.asStateFlow()

    private val _simMetrics = MutableStateFlow(SimMetrics())
    val simMetrics: StateFlow<SimMetrics> = _simMetrics.asStateFlow()

    private val _simLogs = MutableStateFlow<List<String>>(emptyList())
    val simLogs: StateFlow<List<String>> = _simLogs.asStateFlow()

    // --- QR VALIDATION & BOARDING FLOW ---
    private val _validationState = MutableStateFlow<ValidationUiState>(ValidationUiState.Idle)
    val validationState: StateFlow<ValidationUiState> = _validationState.asStateFlow()

    // Active ticket for the details dialog / view
    private val _activeTicketForDetails = MutableStateFlow<TicketEntity?>(null)
    val activeTicketForDetails: StateFlow<TicketEntity?> = _activeTicketForDetails.asStateFlow()

    // Live Simulator periodic job
    private var simJob: Job? = null

    init {
        viewModelScope.launch {
            repository.seedDatabaseIfNeeded()
            setupInitialSimulation()
            startSimulationEngine()
        }
    }

    fun selectTab(tab: AppTab) {
        _currentTab.value = tab
    }

    // --- SEARCH & PLANNER ACTIONS ---

    fun performSearch() {
        viewModelScope.launch {
            _isSearching.value = true
            delay(800) // Beautiful simulated loading animation
            val results = repository.searchJourneys(
                searchOrigin.value,
                searchDestination.value,
                searchPassengerCount.value
            )
            
            // Apply simple filters
            _searchResults.value = when (searchFilter.value) {
                "Economico" -> results.sortedBy { it.basePrice }
                "Rapido" -> results.sortedBy { it.durationMinutes }
                else -> results
            }
            _isSearching.value = false
        }
    }

    // --- BOOKING ENGINE ACTIONS ---

    fun startBooking(journey: TrainJourney) {
        _selectedJourney.value = journey
        _purchaseStep.value = PurchaseStep.PASSENGER_DETAILS
        // Reset form and seat
        passengerForm.value = PassengerForm()
        _selectedSeat.value = ""
        _currentTab.value = AppTab.COMPRAR
    }

    fun submitPassengerDetails(form: PassengerForm) {
        passengerForm.value = form
        _purchaseStep.value = PurchaseStep.SELECT_SEAT
    }

    fun selectSeat(seat: String) {
        _selectedSeat.value = seat
    }

    fun proceedToPayment() {
        _purchaseStep.value = PurchaseStep.FAKE_PAYMENT
    }

    fun selectPaymentMethod(method: String) {
        _selectedPaymentMethod.value = method
    }

    fun completePayment() {
        val journey = _selectedJourney.value ?: return
        val form = passengerForm.value
        val seat = if (_selectedSeat.value.isEmpty()) "Coche 2, A-14" else _selectedSeat.value
        val method = _selectedPaymentMethod.value

        viewModelScope.launch {
            _isProcessingPayment.value = true
            delay(1200) // Simulated transaction authorization

            var paymentApproved = true
            if (method == "Tarjeta Ferroviaria") {
                // Deduct balance
                paymentApproved = repository.deductCardBalance(journey.basePrice)
            }

            if (paymentApproved) {
                // Insert into DB
                val ticketId = repository.purchaseTicket(
                    origin = getStationName(journey.origin),
                    destination = getStationName(journey.destination),
                    date = searchDate.value,
                    time = journey.departureTime,
                    trainId = "${journey.trainName} ${journey.trainNumber}",
                    passengerName = "${form.firstName} ${form.lastName}",
                    passengerDoc = form.document.ifEmpty { "CI 4.821.391" },
                    passengerType = form.type,
                    seat = seat,
                    price = journey.basePrice
                )

                _lastPurchasedTicketId.value = ticketId
                _purchaseStep.value = PurchaseStep.CONFIRMATION
                addSimLog("Boleto comprado con éxito: ${journey.trainName} ${journey.trainNumber} - Asiento $seat")
                
                // Update metrics
                val currentM = _simMetrics.value
                _simMetrics.value = currentM.copy(
                    passengersTransported = currentM.passengersTransported + 1,
                    validTickets = currentM.validTickets + 1
                )
            } else {
                // Payment failure (not enough balance on railway card)
                _validationState.value = ValidationUiState.Error("Saldo insuficiente en Tarjeta Ferroviaria")
                delay(3000)
                _validationState.value = ValidationUiState.Idle
            }
            _isProcessingPayment.value = false
        }
    }

    fun resetBookingFlow() {
        _purchaseStep.value = PurchaseStep.SELECT_JOURNEY
        _selectedJourney.value = null
        _selectedSeat.value = ""
        _lastPurchasedTicketId.value = null
    }

    fun showTicketDetails(ticket: TicketEntity) {
        _activeTicketForDetails.value = ticket
    }

    fun hideTicketDetails() {
        _activeTicketForDetails.value = null
    }

    // --- TRAVEL CARD ACTIONS ---

    fun rechargeCard(amount: Int) {
        viewModelScope.launch {
            repository.topUpCard(amount)
            addSimLog("Carga de saldo autorizada: +₲ ${amount}")
        }
    }

    // --- BOARDING VALIDATION SYSTEM ---

    fun simulateQREntryAndBoard(qrContent: String) {
        viewModelScope.launch {
            _validationState.value = ValidationUiState.Scanning
            delay(800)
            _validationState.value = ValidationUiState.Verifying
            delay(1200)

            // Parse ticket data from QR
            // Expected format: FEPASA|RESERVA-XXXXXX|TrainId|Seat|Price|Name
            val parts = qrContent.split("|")
            if (parts.size >= 6 && parts[0] == "FEPASA") {
                // Find matching ticket in local DB
                val allT = tickets.value
                val matchedTicket = allT.find { it.qrCode == qrContent }
                
                if (matchedTicket != null) {
                    when (matchedTicket.status) {
                        "RESERVADO" -> {
                            // Update to Validated / listo
                            val updated = matchedTicket.copy(status = "VALIDADO")
                            db.ticketDao().updateTicket(updated)
                            _validationState.value = ValidationUiState.Success(updated)
                            addSimLog("Boleto validado: ${matchedTicket.passengerName} - Tren: ${matchedTicket.trainId}")
                        }
                        "VALIDADO" -> {
                            // Already validated, set to utilized on second validation
                            val updated = matchedTicket.copy(status = "UTILIZADO")
                            db.ticketDao().updateTicket(updated)
                            _validationState.value = ValidationUiState.Success(updated)
                            addSimLog("Embarque registrado: ${matchedTicket.passengerName} abordó el tren.")
                        }
                        "UTILIZADO" -> {
                            _validationState.value = ValidationUiState.Error("Boleto ya utilizado. Regla de uso único infringida.")
                            addSimLog("Intento de re-ingreso fallido: Boleto ya utilizado.")
                        }
                        "CANCELADO" -> {
                            _validationState.value = ValidationUiState.Error("El boleto correspondiente a esta reserva está cancelado.")
                        }
                        else -> {
                            _validationState.value = ValidationUiState.Success(matchedTicket)
                        }
                    }
                } else {
                    _validationState.value = ValidationUiState.Error("Boleto no registrado en el sistema central de Fepasa.")
                }
            } else {
                _validationState.value = ValidationUiState.Error("Código QR no válido. Formato digital incompatible.")
            }
        }
    }

    fun dismissValidationResult() {
        _validationState.value = ValidationUiState.Idle
    }

    // --- RAILWAY SIMULATOR AND OPERATION MODULE ---

    fun changeScenario(scenario: String) {
        _simScenario.value = scenario
        
        // Adjust simulation parameters dynamically based on scenario
        val baseMetrics = _simMetrics.value
        when (scenario) {
            "Día normal" -> {
                _simMetrics.value = baseMetrics.copy(punctualityPercent = 98, averageBoardingTimeSec = 45)
                addSimLog("Escenario Operativo: Día Normal. Despachos a tiempo del 98%.")
            }
            "Hora punta" -> {
                _simMetrics.value = baseMetrics.copy(punctualityPercent = 92, averageBoardingTimeSec = 65, averageOccupancyPercent = 88)
                addSimLog("Escenario Operativo: Hora Punta. Alto flujo de pasajeros en Asunción y Luque.")
            }
            "Demora de 10 minutos" -> {
                _simMetrics.value = baseMetrics.copy(punctualityPercent = 78, averageBoardingTimeSec = 50)
                addSimLog("Escenario Operativo: Demora de 10 minutos por control de vías en Capiatá.")
            }
            "Estación cerrada" -> {
                _simMetrics.value = baseMetrics.copy(punctualityPercent = 85, averageBoardingTimeSec = 40)
                addSimLog("Escenario Operativo: Estación Itauguá cerrada temporalmente por obras.")
            }
            "Aumento de pasajeros" -> {
                _simMetrics.value = baseMetrics.copy(averageOccupancyPercent = 94, passengersTransported = baseMetrics.passengersTransported + 250)
                addSimLog("Escenario Operativo: Evento Especial en Asunción. Alta demanda de retorno.")
            }
        }
    }

    private fun setupInitialSimulation() {
        _simTrains.value = listOf(
            SimTrain("T101", "Tren Central", "Línea Central", "Asunción", "Ypacaraí", "Luque", "En ruta", 65, 0.4f, true),
            SimTrain("T202", "Tren del Lago", "Tren del Lago", "Asunción", "Ypacaraí", "Asunción", "Detenido", 20, 0.0f, true),
            SimTrain("T102", "Tren Central", "Línea Central", "Ypacaraí", "Asunción", "Itauguá", "En ruta", 45, 0.7f, false),
            SimTrain("T301", "Tren Cercanías", "Línea Metropolitana", "Asunción", "Ypacaraí", "San Lorenzo", "Demorado", 82, 0.2f, true)
        )
        
        _simLogs.value = listOf(
            "06:30 - Inicio de operaciones de la red ferroviaria.",
            "07:00 - Tren T101 despachado desde Asunción Central a tiempo.",
            "07:15 - Tren T102 partió de Ypacaraí - Estación del Lago."
        )
    }

    private fun startSimulationEngine() {
        simJob?.cancel()
        simJob = viewModelScope.launch {
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            while (_simActive.value) {
                delay(4000) // Loop every 4 seconds for lively UI updates!
                
                val currentTrains = _simTrains.value.map { train ->
                    var nextProgress = train.progress + 0.15f
                    var nextStation = train.currentStation
                    var nextStatus = train.status
                    var nextOccupancy = train.occupancyPercent

                    if (nextProgress >= 1.0f) {
                        nextProgress = 0.0f
                        // Move to next station
                        val order = listOf("Asunción", "Luque", "San Lorenzo", "Capiatá", "Itauguá", "Ypacaraí")
                        val currentIdx = order.indexOf(train.currentStation)
                        if (train.directionForward) {
                            if (currentIdx < order.size - 1) {
                                nextStation = order[currentIdx + 1]
                                nextStatus = "Detenido"
                            } else {
                                // Reverse direction!
                                nextStation = order[order.size - 2]
                                nextStatus = "En ruta"
                                return@map train.copy(
                                    currentStation = nextStation,
                                    progress = 0.0f,
                                    directionForward = false,
                                    status = nextStatus
                                )
                            }
                        } else {
                            if (currentIdx > 0) {
                                nextStation = order[currentIdx - 1]
                                nextStatus = "Detenido"
                            } else {
                                // Reverse direction!
                                nextStation = order[1]
                                nextStatus = "En ruta"
                                return@map train.copy(
                                    currentStation = nextStation,
                                    progress = 0.0f,
                                    directionForward = true,
                                    status = nextStatus
                                )
                            }
                        }
                    } else if (train.status == "Detenido") {
                        // Stay stopped for one turn, then resume route
                        nextStatus = "En ruta"
                        nextProgress = 0.05f
                        // Simulating random boarding passengers
                        nextOccupancy = (nextOccupancy + (-10..15).random()).coerceIn(15, 95)
                        
                        val timeStr = sdf.format(Date())
                        addSimLog("$timeStr - ${train.name} (${train.id}) partió de $nextStation destino ${train.destination}")
                    } else {
                        nextStatus = "En ruta"
                    }

                    // Occasional delay simulation
                    if (_simScenario.value == "Demora de 10 minutos" && (1..10).random() > 8) {
                        nextStatus = "Demorado"
                    }

                    train.copy(
                        progress = nextProgress,
                        currentStation = nextStation,
                        status = nextStatus,
                        occupancyPercent = nextOccupancy
                    )
                }
                
                _simTrains.value = currentTrains

                // Tick simulation metrics
                val metrics = _simMetrics.value
                val passDelta = (2..8).random()
                val isPunctual = if (_simScenario.value == "Demora de 10 minutos") (75..85).random() else (94..99).random()

                _simMetrics.value = metrics.copy(
                    passengersTransported = metrics.passengersTransported + passDelta,
                    punctualityPercent = isPunctual,
                    averageOccupancyPercent = currentTrains.map { it.occupancyPercent }.average().toInt()
                )
            }
        }
    }

    private fun addSimLog(log: String) {
        val currentLogs = _simLogs.value.toMutableList()
        currentLogs.add(0, log) // Add at top
        _simLogs.value = currentLogs.take(30) // Keep last 30
    }

    fun getStationName(id: String): String {
        return when (id.lowercase()) {
            "asu" -> "Asunción"
            "luq" -> "Luque"
            "slo" -> "San Lorenzo"
            "cap" -> "Capiatá"
            "ita" -> "Itauguá"
            "ypa" -> "Ypacaraí"
            else -> id.uppercase()
        }
    }

    fun clearAllTickets() {
        viewModelScope.launch {
            db.ticketDao().clearAllTickets()
        }
    }

    fun toggleSimActive() {
        _simActive.value = !_simActive.value
        if (_simActive.value) {
            startSimulationEngine()
        } else {
            simJob?.cancel()
        }
    }

    override fun onCleared() {
        super.onCleared()
        simJob?.cancel()
    }
}
