package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.StationEntity
import com.example.data.TicketEntity
import com.example.viewmodel.RailViewModel

@Composable
fun BilleteraTab(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val tickets by viewModel.tickets.collectAsStateWithLifecycle()
    val activeTicketForDetails by viewModel.activeTicketForDetails.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Mi Billetera Digital", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("Tus billetes de embarque ferroviario y pases activos", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { viewModel.clearAllTickets() }) {
                Icon(Icons.Default.DeleteSweep, contentDescription = "Limpiar historial", tint = MaterialTheme.colorScheme.error)
            }
        }

        if (tickets.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CardTravel,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Aún no tienes billetes",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Los billetes que adquieras para viajar aparecerán en esta billetera de manera segura y offline.",
                        textAlign = TextAlign.Center,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(tickets) { ticket ->
                    TicketListItem(ticket = ticket, onClick = { viewModel.showTicketDetails(ticket) })
                }
            }
        }
    }

    // Modal details dialog
    activeTicketForDetails?.let { ticket ->
        TicketDetailsDialog(
            ticket = ticket,
            onDismiss = { viewModel.hideTicketDetails() },
            onBoardSimulate = {
                viewModel.simulateQREntryAndBoard(ticket.qrCode)
            }
        )
    }
}

@Composable
fun TicketListItem(
    ticket: TicketEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("ticket_list_item_${ticket.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = ticket.trainId,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                // Status Badge
                Badge(
                    containerColor = when (ticket.status) {
                        "RESERVADO" -> MaterialTheme.colorScheme.primaryContainer
                        "LISTO_PARA_EMBARCAR" -> MaterialTheme.colorScheme.secondaryContainer
                        "VALIDADO" -> Color(0xFFE8F5E9)
                        "UTILIZADO" -> Color(0xFFECEFF1)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    },
                    contentColor = when (ticket.status) {
                        "RESERVADO" -> MaterialTheme.colorScheme.primary
                        "LISTO_PARA_EMBARCAR" -> MaterialTheme.colorScheme.secondary
                        "VALIDADO" -> Color(0xFF2E7D32)
                        "UTILIZADO" -> Color(0xFF546E7A)
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                ) {
                    Text(
                        text = ticket.status.replace("_", " "),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(ticket.origin, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(ticket.time, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(
                    imageVector = Icons.Default.TrendingFlat,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text(ticket.destination, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.End)
                    Text("Asiento: ${ticket.seat}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.End)
                }
            }

            Divider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = ticket.passengerName,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "ID: #${ticket.id}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun TicketDetailsDialog(
    ticket: TicketEntity,
    onDismiss: () -> Unit,
    onBoardSimulate: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onBoardSimulate,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                modifier = Modifier.testTag("simulate_boarding_button")
            ) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Validar Embarque QR", fontSize = 13.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cerrar")
            }
        },
        title = {
            Text(
                text = "Billete de Abordaje FEPASA",
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // High contrast QR Representation Box
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .border(1.dp, Color.Black, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Draw simulated QR matrix squares
                        val size = 5
                        val cellSizeW = this.size.width / size
                        val cellSizeH = this.size.height / size
                        for (i in 0 until size) {
                            for (j in 0 until size) {
                                // Pseudo-random grid pattern anchored by corner markers
                                val shouldDraw = (i == 0 && j == 0) || (i == 0 && j == size - 1) || 
                                                 (i == size - 1 && j == 0) || (i == 2 && j == 2) ||
                                                 ((i + j) % 3 == 0)
                                if (shouldDraw) {
                                    drawRect(
                                        color = Color.Black,
                                        topLeft = Offset(i * cellSizeW + 2, j * cellSizeH + 2),
                                        size = androidx.compose.ui.geometry.Size(cellSizeW - 4, cellSizeH - 4)
                                    )
                                }
                            }
                        }
                    }
                }

                Text(
                    text = "ESTADO: " + ticket.status.replace("_", " "),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = when (ticket.status) {
                        "VALIDADO" -> Color(0xFF2E7D32)
                        "UTILIZADO" -> Color.Gray
                        else -> MaterialTheme.colorScheme.primary
                    }
                )

                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    DetailRow("Pasajero:", ticket.passengerName)
                    DetailRow("Documento:", ticket.passengerDoc)
                    DetailRow("Tipo de Billete:", ticket.passengerType)
                    DetailRow("Trayecto:", "${ticket.origin} → ${ticket.destination}")
                    DetailRow("Fecha / Hora:", "${ticket.date} • ${ticket.time}")
                    DetailRow("Coche / Asiento:", "C-02 • ${ticket.seat}")
                    DetailRow("Tarifa:", "₲ ${String.format("%,d", ticket.price)}")
                }

                Text(
                    text = "Ley de Ferrocarriles Nacionales (1861). Este billete es personal e intransferible. Su posesión offline autoriza el tránsito en la ruta indicada previa validación en andenes oficiales.",
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    lineHeight = 13.sp
                )
            }
        }
    )
}

@Composable
fun DetailRow(label: String, valStr: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(valStr, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

// --- ESTACIONES & MAP LAYOUT ---

@Composable
fun EstacionesTab(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val stations by viewModel.stations.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0 = Directorio, 1 = Mapa Esquemático

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Infraestructura de Estaciones", fontWeight = FontWeight.Bold, fontSize = 20.sp)

        TabRow(
            selectedTabIndex = activeTab,
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }) {
                Text("Directorio", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }) {
                Text("Mapa de la Red", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }

        if (activeTab == 0) {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(stations) { station ->
                    StationCard(station = station)
                }
            }
        } else {
            // Schematic Map representation using custom canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "MAPA ESQUEMÁTICO — LÍNEA CENTRAL DE PARAGUAY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Draw Schematic Route
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        val trackColor = MaterialTheme.colorScheme.primary
                        val dotColor = MaterialTheme.colorScheme.secondary

                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = this.size.width
                            val h = this.size.height

                            // Draw central vertical railroad track line
                            drawLine(
                                color = trackColor,
                                start = Offset(w / 2, h * 0.08f),
                                end = Offset(w / 2, h * 0.92f),
                                strokeWidth = 6.dp.toPx(),
                                cap = StrokeCap.Round
                            )

                            // Draw train ties (wooden sleepers) along the track
                            val sleeperCount = 10
                            for (i in 0..sleeperCount) {
                                val y = h * 0.08f + (h * 0.84f * (i.toFloat() / sleeperCount))
                                drawLine(
                                    color = Color.Gray.copy(alpha = 0.8f),
                                    start = Offset(w / 2 - 24.dp.toPx(), y),
                                    end = Offset(w / 2 + 24.dp.toPx(), y),
                                    strokeWidth = 3.dp.toPx(),
                                    cap = StrokeCap.Round
                                )
                            }

                            // Draw station coordinate nodes
                            val stationCoordinates = listOf(
                                "Asunción" to 0.08f,
                                "Luque" to 0.25f,
                                "San Lorenzo" to 0.42f,
                                "Capiatá" to 0.59f,
                                "Itauguá (Obras)" to 0.76f,
                                "Ypacaraí" to 0.92f
                            )

                            stationCoordinates.forEach { (name, pos) ->
                                val cy = h * pos
                                drawCircle(
                                    color = dotColor,
                                    radius = 8.dp.toPx(),
                                    center = Offset(w / 2, cy)
                                )
                                drawCircle(
                                    color = Color.White,
                                    radius = 4.dp.toPx(),
                                    center = Offset(w / 2, cy)
                                )
                            }
                        }

                        // Absolute Text positionings to avoid overlapping
                        val labels = listOf(
                            "Asunción (ASU)" to Alignment.TopStart,
                            "Luque (LUQ)" to Alignment.CenterStart,
                            "San Lorenzo (SLO)" to Alignment.CenterStart,
                            "Capiatá (CAP)" to Alignment.CenterStart,
                            "Itauguá (ITA)" to Alignment.CenterStart,
                            "Ypacaraí (YPA)" to Alignment.BottomStart
                        )
                        val offsetPaddings = listOf(
                            25.dp, 82.dp, 140.dp, 198.dp, 255.dp, 310.dp
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxHeight()
                                .padding(horizontal = 8.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            labels.forEachIndexed { index, (label, align) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = if (index == 0) 10.dp else 0.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        if (label.contains("Itauguá")) {
                                            Text("En desarrollo / Obras", fontSize = 9.sp, color = MaterialTheme.colorScheme.primary)
                                        } else {
                                            Text("Estación Activa", fontSize = 9.sp, color = Color(0xFF2E7D32))
                                        }
                                    }
                                    Spacer(modifier = Modifier.weight(1.2f))
                                }
                            }
                        }
                    }

                    Text(
                        text = "Conexiones de trenes en tiempo real y andenes activos representados bajo control satelital de Fepasa.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
fun StationCard(station: StationEntity) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("station_card_${station.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Store, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = station.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Badge(
                    containerColor = if (station.status == "Activa") Color(0xFFE8F5E9) else Color(0xFFFFF3E0),
                    contentColor = if (station.status == "Activa") Color(0xFF2E7D32) else Color(0xFFE65100)
                ) {
                    Text(
                        text = station.status.uppercase(),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = "Ubicación: " + station.location,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text(
                text = "Líneas de conexión: " + station.lines,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Facilities rendering
                val featuresList = station.features.split(",")
                featuresList.forEach { feature ->
                    val (icon, label) = when (feature.trim()) {
                        "baños" -> Icons.Default.Wc to "Baños"
                        "taquilla" -> Icons.Default.LocalActivity to "Boletería"
                        "atencion" -> Icons.Default.SupportAgent to "Atención"
                        "bicicleteros" -> Icons.Default.DirectionsBike to "Bicicleta"
                        "accesible" -> Icons.Default.Accessible to "Rampas"
                        else -> Icons.Default.Done to feature.trim()
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Divider(color = MaterialTheme.colorScheme.outlineVariant)

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Default.Commute, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                Text(
                    text = "Transferencias: " + station.connections,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
