package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// --- DOMAIN MODELS FOR RUNTIME USE ---

data class TrainJourney(
    val id: String,
    val trainNumber: String,
    val trainName: String,
    val origin: String,
    val destination: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val serviceType: String, // "Regional", "Rápido", "Cercanías"
    val basePrice: Int,
    val availableSeats: Int,
    val intermediateStops: List<String>
)

class RailRepository(private val db: AppDatabase) {

    val stations: Flow<List<StationEntity>> = db.stationDao().getAllStations()
    val tickets: Flow<List<TicketEntity>> = db.ticketDao().getAllTickets()
    val card: Flow<CardEntity?> = db.cardDao().getCard()

    suspend fun seedDatabaseIfNeeded() {
        val existingStations = db.stationDao().getAllStations().first()
        if (existingStations.isEmpty()) {
            val defaultStations = listOf(
                StationEntity(
                    id = "asu",
                    name = "Asunción - Estación Central",
                    code = "ASU",
                    location = "Eligio Ayala y México, Asunción",
                    lines = "Línea Central, Tren del Lago",
                    features = "baños,taquilla,atencion,accesible,cafetería",
                    status = "Activa",
                    connections = "Líneas de Autobús 15, 30, 23, 56"
                ),
                StationEntity(
                    id = "luq",
                    name = "Luque - Estación Histórica",
                    code = "LUQ",
                    location = "Gral. Aquino, Luque",
                    lines = "Línea Central",
                    features = "baños,taquilla,atencion,bicicleteros,accesible",
                    status = "Activa",
                    connections = "Línea 30 (Luque), Internos"
                ),
                StationEntity(
                    id = "slo",
                    name = "San Lorenzo - Campus",
                    code = "SLO",
                    location = "Ruta PY02 Mariscal Estigarribia, San Lorenzo",
                    lines = "Línea Central",
                    features = "baños,taquilla,atencion,bicicleteros,accesible",
                    status = "Activa",
                    connections = "Línea 26, 27, 96, Metrobús"
                ),
                StationEntity(
                    id = "cap",
                    name = "Capiatá - Ruta 2",
                    code = "CAP",
                    location = "Km 20 Ruta PY02, Capiatá",
                    lines = "Línea Central",
                    features = "baños,taquilla,atencion,accesible",
                    status = "Activa",
                    connections = "Línea 53, 58, 96"
                ),
                StationEntity(
                    id = "ita",
                    name = "Itauguá - Estación del Ñandutí",
                    code = "ITA",
                    location = "Teniente Esteban Martínez, Itauguá",
                    lines = "Línea Central, Tren del Lago",
                    features = "baños,taquilla,bicicleteros,atencion,accesible",
                    status = "Obras", // In development for realistic status
                    connections = "Línea 165, Internos"
                ),
                StationEntity(
                    id = "ypa",
                    name = "Ypacaraí - Estación del Lago",
                    code = "YPA",
                    location = "Calle de la Estación, Ypacaraí",
                    lines = "Línea Central, Tren del Lago",
                    features = "baños,taquilla,atencion,bicicleteros,accesible,mirador",
                    status = "Activa",
                    connections = "Línea 242, Internos de Ypacaraí"
                )
            )
            db.stationDao().insertStations(defaultStations)
        }

        val existingCard = db.cardDao().getCard().first()
        if (existingCard == null) {
            val defaultCard = CardEntity(
                cardNumber = "FEPASA-1861-4821",
                balance = 50000, // ₲ 50.000 preloaded for easy testing!
                status = "Activa"
            )
            db.cardDao().insertCard(defaultCard)
        }
    }

    // Generate static list of train paths in paraguay
    private val standardRoutes = listOf(
        // Origin, Destination, Departure, Arrival, TrainNumber, TrainName, ServiceType, BasePrice, Stops
        RouteTemplate("asu", "ypa", "07:40", "08:32", "101", "Tren Central", "Rápido", 18000, listOf("LUQ", "SLO", "CAP", "ITA")),
        RouteTemplate("asu", "ypa", "09:15", "10:20", "202", "Tren del Lago", "Regional", 15000, listOf("LUQ", "SLO", "CAP", "ITA")),
        RouteTemplate("asu", "ypa", "13:30", "14:22", "103", "Tren Central", "Rápido", 18000, listOf("LUQ", "SLO", "CAP", "ITA")),
        RouteTemplate("asu", "ypa", "17:00", "18:15", "301", "Tren Metropolitano", "Cercanías", 12000, listOf("LUQ", "SLO", "CAP", "ITA")),
        
        // Return journeys
        RouteTemplate("ypa", "asu", "10:30", "11:22", "102", "Tren Central", "Rápido", 18000, listOf("ITA", "CAP", "SLO", "LUQ")),
        RouteTemplate("ypa", "asu", "15:00", "16:05", "203", "Tren del Lago", "Regional", 15000, listOf("ITA", "CAP", "SLO", "LUQ")),
        RouteTemplate("ypa", "asu", "19:00", "20:15", "302", "Tren Metropolitano", "Cercanías", 12000, listOf("ITA", "CAP", "SLO", "LUQ"))
    )

    fun searchJourneys(
        originId: String,
        destinationId: String,
        passengerCount: Int = 1
    ): List<TrainJourney> {
        val oId = originId.lowercase()
        val dId = destinationId.lowercase()
        
        // Match exact or generate intermediate stops routing
        val matchedTemplates = standardRoutes.filter {
            (it.origin == oId && it.destination == dId) || 
            // Also generate partial routes (e.g. Asuncion -> Luque or San Lorenzo -> Ypacarai)
            (it.origin == "asu" && it.destination == "ypa" && isIntermediatePath(oId, dId, it.stops)) ||
            (it.origin == "ypa" && it.destination == "asu" && isIntermediatePath(oId, dId, it.stops))
        }

        return matchedTemplates.map { template ->
            val actualPrice = calculatePrice(oId, dId, template.basePrice) * passengerCount
            val duration = calculateDuration(oId, dId, template.durationMinutes)
            val intermediateStops = getStopsBetween(oId, dId, template.stops)
            
            TrainJourney(
                id = "${template.trainNumber}-$oId-$dId-${template.departureTime.replace(":", "")}",
                trainNumber = template.trainNumber,
                trainName = template.trainName,
                origin = oId.uppercase(),
                destination = dId.uppercase(),
                departureTime = template.departureTime,
                arrivalTime = calculateArrivalTime(template.departureTime, duration),
                durationMinutes = duration,
                serviceType = template.serviceType,
                basePrice = actualPrice,
                availableSeats = 84 - (passengerCount * 3), // Realistic seat count
                intermediateStops = intermediateStops
            )
        }
    }

    private fun isIntermediatePath(from: String, to: String, stops: List<String>): Boolean {
        // Simple logic: if 'from' and 'to' are in our station list, check ordering
        val stationOrder = listOf("asu", "luq", "slo", "cap", "ita", "ypa")
        val revStationOrder = stationOrder.reversed()
        
        val fromIdx = stationOrder.indexOf(from)
        val toIdx = stationOrder.indexOf(to)
        
        if (fromIdx != -1 && toIdx != -1) {
            return fromIdx < toIdx // Forward direction
        }
        
        val revFromIdx = revStationOrder.indexOf(from)
        val revToIdx = revStationOrder.indexOf(to)
        if (revFromIdx != -1 && revToIdx != -1) {
            return revFromIdx < revToIdx // Reverse direction
        }
        return false
    }

    private fun getStopsBetween(from: String, to: String, templateStops: List<String>): List<String> {
        val stationNames = mapOf(
            "ASU" to "Asunción",
            "LUQ" to "Luque",
            "SLO" to "San Lorenzo",
            "CAP" to "Capiatá",
            "ITA" to "Itauguá",
            "YPA" to "Ypacaraí"
        )
        val routeOrder = listOf("asu", "luq", "slo", "cap", "ita", "ypa")
        val isForward = routeOrder.indexOf(from) < routeOrder.indexOf(to)
        val currentOrder = if (isForward) routeOrder else routeOrder.reversed()
        
        val fromIdx = currentOrder.indexOf(from)
        val toIdx = currentOrder.indexOf(to)
        
        if (fromIdx == -1 || toIdx == -1 || fromIdx >= toIdx) return emptyList()
        
        return currentOrder.subList(fromIdx + 1, toIdx).map { stationId ->
            stationNames[stationId.uppercase()] ?: stationId.uppercase()
        }
    }

    private fun calculatePrice(from: String, to: String, fullRouteBasePrice: Int): Int {
        val order = listOf("asu", "luq", "slo", "cap", "ita", "ypa")
        val fromIdx = order.indexOf(from)
        val toIdx = order.indexOf(to)
        
        if (fromIdx == -1 || toIdx == -1) return 10000
        val totalStops = Math.abs(toIdx - fromIdx)
        
        // ₲ 3.000 per station stop, minimum ₲ 6.000, capped at fullRouteBasePrice
        val price = totalStops * 3500
        return Math.max(6000, Math.min(price, fullRouteBasePrice))
    }

    private fun calculateDuration(from: String, to: String, fullRouteDuration: Int): Int {
        val order = listOf("asu", "luq", "slo", "cap", "ita", "ypa")
        val fromIdx = order.indexOf(from)
        val toIdx = order.indexOf(to)
        
        if (fromIdx == -1 || toIdx == -1) return 30
        val totalStops = Math.abs(toIdx - fromIdx)
        
        // Standard fraction of full duration
        val fraction = totalStops.toFloat() / (order.size - 1)
        return (fullRouteDuration * fraction).toInt().coerceAtLeast(12)
    }

    private fun calculateArrivalTime(departureTime: String, durationMinutes: Int): String {
        try {
            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
            val date = sdf.parse(departureTime) ?: return departureTime
            val arrivalMillis = date.time + (durationMinutes * 60 * 1000)
            return sdf.format(Date(arrivalMillis))
        } catch (e: Exception) {
            return departureTime
        }
    }

    // --- WRITE OPERATIONS ---

    suspend fun purchaseTicket(
        origin: String,
        destination: String,
        date: String,
        time: String,
        trainId: String,
        passengerName: String,
        passengerDoc: String,
        passengerType: String,
        seat: String,
        price: Int
    ): Long {
        val qrPayload = "FEPASA|RESERVA-${(100000..999999).random()}|$trainId|$seat|$price|$passengerName"
        val newTicket = TicketEntity(
            origin = origin,
            destination = destination,
            date = date,
            time = time,
            trainId = trainId,
            passengerName = passengerName,
            passengerDoc = passengerDoc,
            passengerType = passengerType,
            seat = seat,
            price = price,
            status = "RESERVADO",
            qrCode = qrPayload
        )
        return db.ticketDao().insertTicket(newTicket)
    }

    suspend fun updateTicketStatus(ticketId: Long, newStatus: String) {
        val ticket = db.ticketDao().getTicketById(ticketId)
        if (ticket != null) {
            db.ticketDao().updateTicket(ticket.copy(status = newStatus))
        }
    }

    suspend fun topUpCard(amount: Int) {
        val currentCard = db.cardDao().getCard().first()
        if (currentCard != null) {
            val newBalance = currentCard.balance + amount
            db.cardDao().updateBalance(currentCard.cardNumber, newBalance)
        }
    }

    suspend fun deductCardBalance(amount: Int): Boolean {
        val currentCard = db.cardDao().getCard().first() ?: return false
        if (currentCard.balance >= amount) {
            val newBalance = currentCard.balance - amount
            db.cardDao().updateBalance(currentCard.cardNumber, newBalance)
            return true
        }
        return false
    }

    suspend fun clearAllTickets() {
        db.ticketDao().clearAllTickets()
    }
}

data class RouteTemplate(
    val origin: String,
    val destination: String,
    val departureTime: String,
    val arrivalTime: String,
    val trainNumber: String,
    val trainName: String,
    val serviceType: String,
    val basePrice: Int,
    val stops: List<String>,
    val durationMinutes: Int = 52
)
