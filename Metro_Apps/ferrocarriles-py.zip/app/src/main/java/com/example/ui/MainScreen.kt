package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.viewmodel.AppTab
import com.example.viewmodel.RailViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Train,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "FERROCARRILES DEL PARAGUAY.OS",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onBackground,
                                letterSpacing = 0.5.sp
                            )
                        }
                        Text(
                            text = "Tu red ferroviaria. Tu viaje. Paraguay en movimiento.",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                },
                actions = {
                    // Demo indicator tag
                    Badge(
                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        contentColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Text(
                            text = "MODO DEMOSTRACIÓN",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("bottom_nav_bar"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == AppTab.INICIO,
                    onClick = { viewModel.selectTab(AppTab.INICIO) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Inicio") },
                    label = { Text("Inicio", fontSize = 9.sp) },
                    modifier = Modifier.testTag("nav_tab_inicio")
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.PLANIFICAR,
                    onClick = { viewModel.selectTab(AppTab.PLANIFICAR) },
                    icon = { Icon(Icons.Default.CalendarMonth, contentDescription = "Planificar") },
                    label = { Text("Planificar", fontSize = 9.sp) },
                    modifier = Modifier.testTag("nav_tab_planificar")
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.COMPRAR,
                    onClick = { viewModel.selectTab(AppTab.COMPRAR) },
                    icon = { Icon(Icons.Default.ShoppingCart, contentDescription = "Comprar") },
                    label = { Text("Comprar", fontSize = 9.sp) },
                    modifier = Modifier.testTag("nav_tab_comprar")
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.BILLETERA,
                    onClick = { viewModel.selectTab(AppTab.BILLETERA) },
                    icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Billetera") },
                    label = { Text("Billetera", fontSize = 9.sp) },
                    modifier = Modifier.testTag("nav_tab_billetera")
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.ESTACIONES,
                    onClick = { viewModel.selectTab(AppTab.ESTACIONES) },
                    icon = { Icon(Icons.Default.Store, contentDescription = "Estaciones") },
                    label = { Text("Estaciones", fontSize = 9.sp) },
                    modifier = Modifier.testTag("nav_tab_estaciones")
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.SIMULADOR,
                    onClick = { viewModel.selectTab(AppTab.SIMULADOR) },
                    icon = { Icon(Icons.Default.PrecisionManufacturing, contentDescription = "Simulador") },
                    label = { Text("Simulador", fontSize = 9.sp) },
                    modifier = Modifier.testTag("nav_tab_simulador")
                )
                NavigationBarItem(
                    selected = currentTab == AppTab.MAS,
                    onClick = { viewModel.selectTab(AppTab.MAS) },
                    icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "Más") },
                    label = { Text("Más", fontSize = 9.sp) },
                    modifier = Modifier.testTag("nav_tab_mas")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Demonstration Mode visible disclaimer as requested in Section 2:
            // "Incluye una etiqueta visible: Modo demostración — Datos ferroviarios simulados"
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFE5A93B).copy(alpha = 0.15f))
                    .padding(vertical = 4.dp, horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Modo demostración — Datos ferroviarios simulados",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF9E6D0F),
                    textAlign = TextAlign.Center
                )
            }

            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "tab_transition",
                modifier = Modifier.weight(1f)
            ) { tab ->
                when (tab) {
                    AppTab.INICIO -> InicioTab(viewModel)
                    AppTab.PLANIFICAR -> PlanificarTab(viewModel)
                    AppTab.COMPRAR -> ComprarTab(viewModel)
                    AppTab.BILLETERA -> BilleteraTab(viewModel)
                    AppTab.ESTACIONES -> EstacionesTab(viewModel)
                    AppTab.SIMULADOR -> SimuladorTab(viewModel)
                    AppTab.MAS -> MasTab(viewModel)
                }
            }
        }
    }
}
