package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Authentic Paraguayan Railway Palette
val RedTierra = Color(0xFFBA3F25)        // Red soil of Paraguay, brick station walls, classic trains
val CremaEstacion = Color(0xFFFAF7F2)    // Off-white stone wall textures
val VerdeSubtropical = Color(0xFF1B4E3B) // Lush greenery of Eastern Paraguay
val GrisHormigon = Color(0xFF8E9296)     // Concrete infrastructure, modern sleek structures
val Carbon = Color(0xFF1B1C1E)           // Deep coal, modern carbon steel, high contrast dark theme base
val AmarilloSenal = Color(0xFFE5A93B)    // Railway warning and signal accent yellow

// Material 3 semantic mappings
val LightPrimary = RedTierra
val LightOnPrimary = Color.White
val LightSecondary = VerdeSubtropical
val LightBackground = CremaEstacion
val LightSurface = Color(0xFFFFFDFC)
val LightOnBackground = Carbon
val LightOnSurface = Carbon

val DarkPrimary = Color(0xFFFFB4A2)
val DarkOnPrimary = Color(0xFF690005)
val DarkSecondary = Color(0xFF81D8B0)
val DarkBackground = Carbon
val DarkSurface = Color(0xFF252629)
val DarkOnBackground = Color(0xFFE2E2E6)
val DarkOnSurface = Color(0xFFE2E2E6)
