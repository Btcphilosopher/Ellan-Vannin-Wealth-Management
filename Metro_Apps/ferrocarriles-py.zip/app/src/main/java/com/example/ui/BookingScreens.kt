package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.TicketEntity
import com.example.viewmodel.AppTab
import com.example.viewmodel.PassengerForm
import com.example.viewmodel.PurchaseStep
import com.example.viewmodel.RailViewModel

@Composable
fun ComprarTab(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val step by viewModel.purchaseStep.collectAsStateWithLifecycle()
    val selectedJourney by viewModel.selectedJourney.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Multi-Step Progress Header
        StepProgressHeader(currentStep = step)

        Divider(color = MaterialTheme.colorScheme.outlineVariant)

        // Render step content
        Box(modifier = Modifier.weight(1f)) {
            when (step) {
                PurchaseStep.SELECT_JOURNEY -> {
                    SelectJourneyStep(viewModel)
                }
                PurchaseStep.PASSENGER_DETAILS -> {
                    PassengerDetailsStep(viewModel)
                }
                PurchaseStep.SELECT_SEAT -> {
                    SelectSeatStep(viewModel)
                }
                PurchaseStep.FAKE_PAYMENT -> {
                    FakePaymentStep(viewModel)
                }
                PurchaseStep.CONFIRMATION -> {
                    ConfirmationStep(viewModel)
                }
            }
        }
    }
}

@Composable
fun StepProgressHeader(currentStep: PurchaseStep) {
    val steps = listOf(
        PurchaseStep.PASSENGER_DETAILS to "Pasajero",
        PurchaseStep.SELECT_SEAT to "Asiento",
        PurchaseStep.FAKE_PAYMENT to "Pago",
        PurchaseStep.CONFIRMATION to "Listo"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, (step, name) ->
            val isCurrent = currentStep == step
            val isPassed = currentStep.ordinal > step.ordinal || currentStep == PurchaseStep.CONFIRMATION

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            when {
                                isCurrent -> MaterialTheme.colorScheme.primary
                                isPassed -> MaterialTheme.colorScheme.secondary
                                else -> MaterialTheme.colorScheme.outlineVariant
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isPassed && !isCurrent) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    } else {
                        Text(
                            text = (index + 1).toString(),
                            color = if (isCurrent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text(
                    text = name,
                    fontSize = 12.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                    color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (index < steps.size - 1) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp)
                        .height(1.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant)
                )
            }
        }
    }
}

@Composable
fun SelectJourneyStep(viewModel: RailViewModel) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Train,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
            modifier = Modifier.size(72.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Planifica tu viaje primero",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Selecciona tu origen y destino en el buscador de la pestaña Inicio o Planificar.",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = { viewModel.selectTab(AppTab.PLANIFICAR) }
        ) {
            Text("Ir al Planificador")
        }
    }
}

@Composable
fun PassengerDetailsStep(viewModel: RailViewModel) {
    val journey = viewModel.selectedJourney.collectAsStateWithLifecycle().value ?: return

    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var docNum by remember { mutableStateOf("") }
    var passType by remember { mutableStateOf("Regular") }
    var accessibility by remember { mutableStateOf(false) }
    var bicycle by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Selected journey review card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("RESUMEN DE VIAJE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("${journey.origin} → ${journey.destination}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("${journey.trainName} ${journey.trainNumber} • ${journey.departureTime}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        text = "₲ ${String.format("%,d", journey.basePrice)}",
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    )
                }
            }

            Text("Información del Pasajero", fontWeight = FontWeight.Bold, fontSize = 16.sp)

            OutlinedTextField(
                value = firstName,
                onValueChange = { firstName = it },
                label = { Text("Nombre") },
                modifier = Modifier.fillMaxWidth().testTag("input_firstname"),
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
            )

            OutlinedTextField(
                value = lastName,
                onValueChange = { lastName = it },
                label = { Text("Apellido") },
                modifier = Modifier.fillMaxWidth().testTag("input_lastname"),
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
            )

            OutlinedTextField(
                value = docNum,
                onValueChange = { docNum = it },
                label = { Text("Documento de Identidad (C.I. / Pasaporte)") },
                modifier = Modifier.fillMaxWidth().testTag("input_document"),
                leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                placeholder = { Text("ej. 4.821.391") }
            )

            // Pasager Type Row
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Categoría de Tarifa", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Regular", "Estudiante", "Adulto Mayor").forEach { type ->
                        val selected = passType == type
                        ElevatedFilterChip(
                            selected = selected,
                            onClick = { passType = type },
                            label = { Text(type) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Divider(color = MaterialTheme.colorScheme.outlineVariant)

            // Checkboxes
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(checked = accessibility, onCheckedChange = { accessibility = it })
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text("Asistencia de Accesibilidad", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("Requiero embarque adaptado para silla de ruedas", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(checked = bicycle, onCheckedChange = { bicycle = it })
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text("Equipaje Especial: Bicicleta", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("Añadir plaza de bicicleta en el coche de carga", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { viewModel.resetBookingFlow() },
                modifier = Modifier.weight(1f)
            ) {
                Text("Cancelar")
            }
            Button(
                onClick = {
                    viewModel.submitPassengerDetails(
                        PassengerForm(firstName, lastName, docNum, passType, accessibility, bicycle)
                    )
                },
                modifier = Modifier
                    .weight(1.5f)
                    .testTag("submit_passenger_button"),
                enabled = firstName.isNotBlank() && lastName.isNotBlank()
            ) {
                Text("Continuar a Asientos")
            }
        }
    }
}

@Composable
fun SelectSeatStep(viewModel: RailViewModel) {
    val selectedSeat by viewModel.selectedSeat.collectAsStateWithLifecycle()
    
    // Grid of seats 1 to 24
    val seatList = remember { (1..24).map { "Asiento ${if (it < 10) "0" else ""}$it" } }
    // Fake reserved seats
    val reservedSeats = remember { listOf("Asiento 04", "Asiento 05", "Asiento 12", "Asiento 18", "Asiento 19") }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Selección de Asiento", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Coche 02 — Clase Única (Estándar Regional)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

            // Legend indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendItem("Libre", Color(0xFF2E7D32))
                LegendItem("Reservado", Color(0xFF8E9296))
                LegendItem("Seleccionado", MaterialTheme.colorScheme.primary)
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Visual car layout representation
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("← CABINA DE CONDUCCIÓN / EQUIPAJES", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.outline)

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(seatList) { seat ->
                            val isReserved = reservedSeats.contains(seat)
                            val isSelected = selectedSeat == seat

                            Box(
                                modifier = Modifier
                                    .height(36.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        when {
                                            isReserved -> Color(0xFFE2E2E6)
                                            isSelected -> MaterialTheme.colorScheme.primary
                                            else -> Color(0xFFE8F5E9)
                                        }
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = when {
                                            isReserved -> Color.Transparent
                                            isSelected -> MaterialTheme.colorScheme.primary
                                            else -> Color(0xFF81C784)
                                        },
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable(enabled = !isReserved) {
                                        viewModel.selectSeat(seat)
                                    }
                                    .testTag("seat_item_$seat"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = seat.replace("Asiento ", ""),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        isReserved -> Color(0xFF8E9296)
                                        isSelected -> Color.White
                                        else -> Color(0xFF2E7D32)
                                    }
                                )
                            }
                        }
                    }

                    Text("CONEXIÓN A COCHE SIGUIENTE / BAÑOS →", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.outline)
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { viewModel.submitPassengerDetails(viewModel.passengerForm.value) },
                modifier = Modifier.weight(1f)
            ) {
                Text("Volver")
            }
            Button(
                onClick = { viewModel.proceedToPayment() },
                modifier = Modifier
                    .weight(1.5f)
                    .testTag("confirm_seat_button"),
                enabled = selectedSeat.isNotEmpty()
            ) {
                Text("Confirmar Asiento")
            }
        }
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(modifier = Modifier.size(12.dp).clip(RoundedCornerShape(3.dp)).background(color))
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun FakePaymentStep(viewModel: RailViewModel) {
    val journey = viewModel.selectedJourney.collectAsStateWithLifecycle().value ?: return
    val form by viewModel.passengerForm.collectAsStateWithLifecycle()
    val seat by viewModel.selectedSeat.collectAsStateWithLifecycle()
    val paymentMethod by viewModel.selectedPaymentMethod.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessingPayment.collectAsStateWithLifecycle()
    val transitCard by viewModel.transitCard.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Simulación de Pago Seguro", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Este es un canal de demostración nacional. Ninguna transacción monetaria real será realizada.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

            // Resumen General
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("DETALLES DE RESERVA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pasajero:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${form.firstName} ${form.lastName}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Identificación:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(form.document, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Viaje:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${journey.origin} → ${journey.destination}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Asiento Asignado:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(seat, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TOTAL DE DEMOSTRACIÓN:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("₲ ${String.format("%,d", journey.basePrice)}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            Text("Método de Pago", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            // Options
            listOf(
                "Tarjeta de Crédito / Débito (Demo)" to Icons.Outlined.CreditCard,
                "Tarjeta Ferroviaria (Demo Balance)" to Icons.Outlined.Contactless,
                "Billetera Digital PagoMóvil" to Icons.Outlined.QrCodeScanner
            ).forEach { (method, icon) ->
                val selected = paymentMethod == method
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectPaymentMethod(method) }
                        .testTag("payment_method_$method"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(
                        width = if (selected) 2.dp else 1.dp,
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(method, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            if (method == "Tarjeta Ferroviaria (Demo Balance)") {
                                val bal = transitCard?.balance ?: 50000
                                Text("Saldo: ₲ ${String.format("%,d", bal)}", fontSize = 11.sp, color = if (bal >= journey.basePrice) Color(0xFF2E7D32) else Color.Red)
                            } else {
                                Text("Referencia sintética: **** **** **** 4821", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        RadioButton(selected = selected, onClick = { viewModel.selectPaymentMethod(method) })
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { viewModel.submitPassengerDetails(viewModel.passengerForm.value) },
                modifier = Modifier.weight(1f),
                enabled = !isProcessing
            ) {
                Text("Atrás")
            }
            Button(
                onClick = { viewModel.completePayment() },
                modifier = Modifier
                    .weight(1.5f)
                    .testTag("pay_simulate_button"),
                enabled = !isProcessing,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Lock, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Autorizar Pago ₲ ${String.format("%,d", journey.basePrice)}")
                }
            }
        }
    }
}

@Composable
fun ConfirmationStep(viewModel: RailViewModel) {
    val tickets by viewModel.tickets.collectAsStateWithLifecycle()
    val lastId by viewModel.lastPurchasedTicketId.collectAsStateWithLifecycle()

    val boughtTicket = remember(tickets, lastId) {
        tickets.find { it.id == lastId } ?: tickets.firstOrNull()
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (boughtTicket == null) {
            Text("Procesando boleto...")
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF2E7D32),
                    modifier = Modifier.size(64.dp)
                )

                Text(
                    text = "¡Compra Autorizada!",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF2E7D32)
                )

                Text(
                    text = "Tu reserva ferroviaria nacional ha sido registrada en el sistema de boletería de Fepasa.",
                    textAlign = TextAlign.Center,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Beautiful classical ticket representation
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "FERROCARRILES DEL PARAGUAY",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "ID: #${boughtTicket.id}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.outlineVariant)

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("ORIGEN", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(boughtTicket.origin, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text("DESTINO", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(boughtTicket.destination, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("FECHA / HORA", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${boughtTicket.date} • ${boughtTicket.time}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text("ASIENTO / COCHE", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${boughtTicket.seat} / C-02", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("PASAJERO", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(boughtTicket.passengerName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text("TARIFA", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("₲ ${String.format("%,d", boughtTicket.price)}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Default.QrCode2, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                            Column {
                                Text("CÓDIGO QR SEGURO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.outline)
                                Text("Listo para escaneo en andén de salida.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            Button(
                onClick = {
                    viewModel.resetBookingFlow()
                    viewModel.selectTab(AppTab.BILLETERA)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("goto_wallet_button")
            ) {
                Icon(Icons.Default.ConfirmationNumber, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Ir a Mi Billetera")
            }
        }
    }
}
