package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- ENTITIES ---

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val code: String,
    val location: String,
    val lines: String, // e.g. "Línea Central, Tren del Lago"
    val features: String, // e.g. "baños,taquilla,atencion,bicicleteros,accesible"
    val status: String, // "Activa", "Obras", "Cerrada"
    val connections: String // e.g. "Autobús 30, Terminal de Luque"
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val origin: String,
    val destination: String,
    val date: String,
    val time: String,
    val trainId: String,
    val passengerName: String,
    val passengerDoc: String,
    val passengerType: String, // "Regular", "Estudiante", "Adulto Mayor"
    val seat: String,
    val price: Int, // Price in Guaraníes (₲)
    val status: String, // "RESERVADO", "LISTO_PARA_EMBARCAR", "VALIDADO", "UTILIZADO", "CANCELADO"
    val qrCode: String,
    val purchaseTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "transit_cards")
data class CardEntity(
    @PrimaryKey val cardNumber: String,
    val balance: Int, // in ₲
    val status: String, // "Activa", "Bloqueada"
    val lastUsedTime: Long = System.currentTimeMillis()
)

// --- DAOS ---

@Dao
interface StationDao {
    @Query("SELECT * FROM stations")
    fun getAllStations(): Flow<List<StationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)

    @Query("SELECT * FROM stations WHERE id = :id")
    suspend fun getStationById(id: String): StationEntity?
}

@Dao
interface TicketDao {
    @Query("SELECT * FROM tickets ORDER BY id DESC")
    fun getAllTickets(): Flow<List<TicketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: TicketEntity): Long

    @Update
    suspend fun updateTicket(ticket: TicketEntity)

    @Query("SELECT * FROM tickets WHERE id = :id")
    suspend fun getTicketById(id: Long): TicketEntity?

    @Query("DELETE FROM tickets")
    suspend fun clearAllTickets()
}

@Dao
interface CardDao {
    @Query("SELECT * FROM transit_cards LIMIT 1")
    fun getCard(): Flow<CardEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCard(card: CardEntity)

    @Query("UPDATE transit_cards SET balance = :newBalance WHERE cardNumber = :cardNumber")
    suspend fun updateBalance(cardNumber: String, newBalance: Int)
}

// --- DATABASE CLASS ---

@Database(
    entities = [StationEntity::class, TicketEntity::class, CardEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun stationDao(): StationDao
    abstract fun ticketDao(): TicketDao
    abstract fun cardDao(): CardDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ferrocarriles_paraguay_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
