package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.viewmodel.AppTab
import com.example.viewmodel.RailViewModel
import com.example.viewmodel.ValidationUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SimuladorTab(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val simActive by viewModel.simActive.collectAsStateWithLifecycle()
    val simScenario by viewModel.simScenario.collectAsStateWithLifecycle()
    val simTrains by viewModel.simTrains.collectAsStateWithLifecycle()
    val simMetrics by viewModel.simMetrics.collectAsStateWithLifecycle()
    val simLogs by viewModel.simLogs.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // --- CONTROL Y ESCENARIOS ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Simulador de Operaciones", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Demostración operacional de la red en tiempo real", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        // Play / Pause switch
                        IconToggleButton(
                            checked = simActive,
                            onCheckedChange = { viewModel.toggleSimActive() }
                        ) {
                            Icon(
                                imageVector = if (simActive) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                                contentDescription = "Alternar simulación",
                                tint = if (simActive) MaterialTheme.colorScheme.primary else Color(0xFF2E7D32),
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    // Scenario selector
                    var scenarioExpanded by remember { mutableStateOf(false) }
                    Text("Escenario Operativo Activo", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Box {
                        OutlinedButton(
                            onClick = { scenarioExpanded = true },
                            modifier = Modifier.fillMaxWidth().testTag("scenario_selector_btn"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.SettingsInputAntenna, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(simScenario, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(
                            expanded = scenarioExpanded,
                            onDismissRequest = { scenarioExpanded = false }
                        ) {
                            listOf("Día normal", "Hora punta", "Demora de 10 minutos", "Estación cerrada", "Aumento de pasajeros").forEach { scenario ->
                                DropdownMenuItem(
                                    text = { Text(scenario) },
                                    onClick = {
                                        viewModel.changeScenario(scenario)
                                        scenarioExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- MÉTRICAS DE CONTROL OPERATIVO ---
        item {
            Text("Estadísticas Operativas de la Red", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard("PUNTUALIDAD", "${simMetrics.punctualityPercent}%", Icons.Default.AvTimer, Color(0xFF2E7D32), Modifier.weight(1f))
                MetricCard("PASAJEROS DÍA", simMetrics.passengersTransported.toString(), Icons.Default.Group, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                MetricCard("TIEMPO ABORDAJE", "${simMetrics.averageBoardingTimeSec} s", Icons.Default.AccessTime, Color(0xFFE5A93B), Modifier.weight(1f))
                MetricCard("OCUPACIÓN MEDIA", "${simMetrics.averageOccupancyPercent}%", Icons.Default.AirlineSeatReclineNormal, MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
            }
        }

        // --- MAPA VISUAL DE TRENES EN RUTA ---
        item {
            Text("Ubicación en Tiempo Real de Trenes", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Linear track diagram displaying train positions
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp)
                            .background(Color(0xFFFAF6EE), RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFFE2E2E6), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw train line track
                            drawLine(
                                color = Color(0xFFBA3F25),
                                start = Offset(32.dp.toPx(), h / 2),
                                end = Offset(w - 32.dp.toPx(), h / 2),
                                strokeWidth = 4.dp.toPx()
                            )

                            // Sleeper tracks
                            for (x in 32.. (w.toInt() - 32) step 30) {
                                drawLine(
                                    color = Color.LightGray,
                                    start = Offset(x.toFloat(), h / 2 - 8.dp.toPx()),
                                    end = Offset(x.toFloat(), h / 2 + 8.dp.toPx()),
                                    strokeWidth = 2.dp.toPx()
                                )
                            }
                        }

                        // Station Node Indicators overlaid
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            listOf("ASU", "LUQ", "SLO", "CAP", "ITA", "YPA").forEach { station ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0xFF1B4E3B))
                                    )
                                    Text(station, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                }
                            }
                        }

                        // Moving train indicators
                        simTrains.forEach { train ->
                            val order = listOf("Asunción", "Luque", "San Lorenzo", "Capiatá", "Itauguá", "Ypacaraí")
                            val idx = order.indexOf(train.currentStation)
                            if (idx != -1) {
                                // Calculate position fraction
                                val totalSegments = order.size - 1
                                val baseFraction = idx.toFloat() / totalSegments
                                val directionMod = if (train.directionForward) 1 else -1
                                val segmentProgress = (train.progress / totalSegments) * directionMod
                                val finalFraction = (baseFraction + segmentProgress).coerceIn(0.0f, 1.0f)

                                Box(
                                    modifier = Modifier
                                        .align(Alignment.CenterStart)
                                        .offset(
                                            x = (16.dp + (300.dp * finalFraction)) // Simple approximate width scaling
                                        )
                                        .size(16.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (train.status == "Demorado") Color(0xFFE5A93B) else Color(0xFFBA3F25)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = train.id.replace("T", ""),
                                        color = Color.White,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Active Trains list
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        simTrains.forEach { train ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(
                                        Icons.Default.Train,
                                        contentDescription = null,
                                        tint = if (train.status == "Demorado") Color(0xFFE5A93B) else Color(0xFF1B4E3B),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Column {
                                        Text("${train.name} (${train.id})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text("Siguiente parada: ${train.currentStation}", fontSize = 10.sp, color = Color.Gray)
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Ocupación: ${train.occupancyPercent}%", fontSize = 11.sp, color = Color.Gray)
                                    Badge(
                                        containerColor = if (train.status == "En ruta") Color(0xFFE8F5E9) else Color(0xFFFFF3E0),
                                        contentColor = if (train.status == "En ruta") Color(0xFF2E7D32) else Color(0xFFE65100)
                                    ) {
                                        Text(train.status.uppercase(), fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- TERMINAL DE REGISTRO EN TIEMPO REAL ---
        item {
            Text("Terminal de Auditoría Operativa", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1F22))
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(simLogs) { log ->
                        Text(
                            text = log,
                            color = Color(0xFF81C784),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(68.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
                Text(label, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray, letterSpacing = 0.5.sp)
            }
            Text(value, fontSize = 16.sp, fontWeight = FontWeight.Black, color = color)
        }
    }
}

// --- TAB MÁS: RECARGAS, HISTORIA E INSPECTOR DE BOLETOS ---

@Composable
fun MasTab(
    viewModel: RailViewModel,
    modifier: Modifier = Modifier
) {
    val transitCard by viewModel.transitCard.collectAsStateWithLifecycle()
    val validationState by viewModel.validationState.collectAsStateWithLifecycle()
    val tickets by viewModel.tickets.collectAsStateWithLifecycle()

    var activeSubSection by remember { mutableStateOf("principal") } // "principal", "historia", "recharge", "inspector"

    AnimatedContent(
        targetState = activeSubSection,
        label = "mas_transition"
    ) { section ->
        when (section) {
            "principal" -> {
                Column(
                    modifier = modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text("Más servicios y configuración", fontWeight = FontWeight.Bold, fontSize = 20.sp)

                    // Sub sections grid cards
                    SettingsButtonCard(
                        title = "Tarjeta Ferroviaria Contactless",
                        subtitle = "Recarga saldo virtual y revisa movimientos",
                        icon = Icons.Default.Contactless,
                        color = MaterialTheme.colorScheme.primary,
                        onClick = { activeSubSection = "recharge" }
                    )

                    SettingsButtonCard(
                        title = "Modo Inspector de Boletos",
                        subtitle = "Simulador de validación QR para guardas de tren",
                        icon = Icons.Default.QrCodeScanner,
                        color = MaterialTheme.colorScheme.secondary,
                        onClick = { activeSubSection = "inspector" }
                    )

                    SettingsButtonCard(
                        title = "Historia del Ferrocarril Paraguayo (1861)",
                        subtitle = "Conoce las raíces de la red de Carlos Antonio López",
                        icon = Icons.Default.HistoryEdu,
                        color = Color(0xFFE5A93B),
                        onClick = { activeSubSection = "historia" }
                    )

                    // Support info card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Atención al Pasajero — FEPASA", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Para consultas o reclamos institucionales, puedes comunicarte al Call Center oficial o visitar las oficinas en la Estación Central de Asunción.", fontSize = 11.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Contacto: +595 (21) 441-502", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            Text("Horarios: Lunes a Viernes, 07:00 a 17:00 hs", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }

            "recharge" -> {
                Column(
                    modifier = modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { activeSubSection = "principal" }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Atrás")
                            }
                            Text("Tarjeta Ferroviaria Virtual", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }

                        // Transit Card representation
                        val balance = transitCard?.balance ?: 50000
                        val cardNum = transitCard?.cardNumber ?: "FEPASA-1861-4821"

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text("FEPASA TARJETA DE TRÁNSITO", fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp, color = Color.White.copy(alpha = 0.7f))
                                Column {
                                    Text("SALDO VIRTUAL DISPONIBLE", fontSize = 9.sp, color = Color.White.copy(alpha = 0.5f))
                                    Text("₲ ${String.format("%,d", balance)}", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(cardNum, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                                    Text("SISTEMA ACTIVO", fontWeight = FontWeight.Bold, color = Color(0xFF81C784), fontSize = 11.sp)
                                }
                            }
                        }

                        Text("Recargar Saldo de Demostración", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Elige un monto sintético para cargar saldo y probar compras de billetes adicionales.", fontSize = 12.sp, color = Color.Gray)

                        // Recharge buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(10000, 20000, 50000).forEach { amount ->
                                Button(
                                    onClick = { viewModel.rechargeCard(amount) },
                                    modifier = Modifier.weight(1f).testTag("topup_$amount"),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Text("+₲ ${String.format("%,d", amount).replace("000", "k")}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { activeSubSection = "principal" },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Volver")
                    }
                }
            }

            "inspector" -> {
                var selectedTicketIdToScan by remember { mutableStateOf<Long?>(null) }
                var ticketDropdownExpanded by remember { mutableStateOf(false) }

                Column(
                    modifier = modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { activeSubSection = "principal" }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Atrás")
                            }
                            Text("Modo Inspector FEPASA", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Instrucciones de Verificación", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                Text("Selecciona un billete emitido en la simulación abajo para emular la lectura del código QR por la cámara del terminal del guarda.", fontSize = 11.sp, color = Color.Gray)
                            }
                        }

                        if (tickets.isEmpty()) {
                            Text("No existen billetes emitidos en la base de datos para simular escaneo. Compra un billete primero.", color = Color.Red, fontSize = 13.sp)
                        } else {
                            Text("Selecciona Billete a Escanear", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            
                            val selectedTObj = tickets.find { it.id == selectedTicketIdToScan } ?: tickets.first()
                            
                            Box {
                                OutlinedButton(
                                    onClick = { ticketDropdownExpanded = true },
                                    modifier = Modifier.fillMaxWidth().testTag("ticket_dropdown_btn")
                                ) {
                                    Text("Boleto #${selectedTObj.id} - ${selectedTObj.passengerName} (${selectedTObj.status})")
                                    Spacer(modifier = Modifier.weight(1f))
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                                DropdownMenu(
                                    expanded = ticketDropdownExpanded,
                                    onDismissRequest = { ticketDropdownExpanded = false }
                                ) {
                                    tickets.forEach { ticket ->
                                        DropdownMenuItem(
                                            text = { Text("#${ticket.id} - ${ticket.passengerName} (${ticket.status})") },
                                            onClick = {
                                                selectedTicketIdToScan = ticket.id
                                                ticketDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    val finalTicketObj = tickets.find { it.id == selectedTicketIdToScan } ?: tickets.first()
                                    viewModel.simulateQREntryAndBoard(finalTicketObj.qrCode)
                                },
                                modifier = Modifier.fillMaxWidth().testTag("inspector_validate_qr_btn")
                            ) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Escanear y Validar QR Código")
                            }
                        }

                        // VALIDATION ANIMATION RESULTS PANELS
                        AnimatedContent(targetState = validationState, label = "validation_display") { state ->
                            when (state) {
                                ValidationUiState.Idle -> {
                                    Box(
                                        modifier = Modifier.fillMaxWidth().height(100.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("Terminal listo para escaneo de pasajero...", fontSize = 12.sp, color = Color.Gray)
                                    }
                                }
                                ValidationUiState.Scanning -> {
                                    Box(
                                        modifier = Modifier.fillMaxWidth().height(100.dp).background(Color.DarkGray.copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                            Text("Leyendo patrón QR...", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                    }
                                }
                                ValidationUiState.Verifying -> {
                                    Box(
                                        modifier = Modifier.fillMaxWidth().height(100.dp).background(Color.DarkGray.copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.primary, strokeWidth = 2.dp)
                                            Text("Verificando firma digital con FEPASA Central...", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                    }
                                }
                                is ValidationUiState.Success -> {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                                        border = BorderStroke(2.dp, Color(0xFF2E7D32))
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(36.dp))
                                            Text("EMBARQUE AUTORIZADO", fontWeight = FontWeight.Black, fontSize = 14.sp, color = Color(0xFF2E7D32))
                                            Text("Pasajero: ${state.ticket.passengerName} • Asiento: ${state.ticket.seat}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                            Text("Boleto marcado como VALIDADO en el servidor local.", fontSize = 11.sp, color = Color.DarkGray)
                                            
                                            Button(
                                                onClick = { viewModel.dismissValidationResult() },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                                            ) {
                                                Text("Listo")
                                            }
                                        }
                                    }
                                }
                                is ValidationUiState.Error -> {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                                        border = BorderStroke(2.dp, Color(0xFFC62828))
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFC62828), modifier = Modifier.size(36.dp))
                                            Text("EMBARQUE RECHAZADO", fontWeight = FontWeight.Black, fontSize = 14.sp, color = Color(0xFFC62828))
                                            Text(state.reason, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black, textAlign = TextAlign.Center)
                                            
                                            Button(
                                                onClick = { viewModel.dismissValidationResult() },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                                            ) {
                                                Text("Entendido")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { activeSubSection = "principal" },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Volver")
                    }
                }
            }

            "historia" -> {
                Column(
                    modifier = modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { activeSubSection = "principal" }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Atrás")
                            }
                            Text("Historia Ferroviaria Paraguaya", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }

                        // Historical text
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "El primer ferrocarril de Sudamérica",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "El ferrocarril paraguayo fue iniciado en 1856 bajo el gobierno de Don Carlos Antonio López. La histórica línea unió originalmente la Estación Central de Asunción con la Estación de Luque, siendo inaugurada solemnemente en junio de 1861.",
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                                Text(
                                    text = "Posteriormente se extendió hasta Ypacaraí y Encarnación, convirtiéndose en el Ferrocarril Central del Paraguay (FCPCA), impulsando el comercio agrícola e industrial nacional mediante legendarias locomotoras a vapor como la 'Sapucai'.",
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                                Text(
                                    text = "Hacia la modernidad electrificada",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Text(
                                    text = "Hoy, FEPASA lidera la visión de reactivación mediante el moderno proyecto del Tren de Cercanías del Área Metropolitana de Asunción, una red ferroviaria moderna y electrificada que devolverá el movimiento sostenible a Paraguay.",
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }

                    Button(
                        onClick = { activeSubSection = "principal" },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Volver")
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsButtonCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("settings_btn_${title.replace(" ", "_")}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(subtitle, fontSize = 11.sp, color = Color.Gray)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.LightGray)
        }
    }
}
