package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransitData
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RouteSearchScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    val searchFrom by viewModel.searchFrom.collectAsState()
    val searchTo by viewModel.searchTo.collectAsState()
    val isStepFreePref by viewModel.isStepFreePref.collectAsState()

    var viaInput by remember { mutableStateOf("") }
    var travelTimeMode by remember { mutableStateOf(0) } // 0: Now, 1: Departure, 2: Arrival

    val transportModes = listOf(
        Triple(Icons.Filled.DirectionsTransit, "Öffis", true),
        Triple(Icons.Filled.DirectionsSubway, "U-Bahn", true),
        Triple(Icons.Filled.Tram, "Tram", true),
        Triple(Icons.Filled.DirectionsBus, "Bus", true),
        Triple(Icons.Filled.DirectionsWalk, "Zu Fuß", true),
        Triple(Icons.Filled.DirectionsBike, "Fahrrad", true)
    )

    var activeModes by remember { mutableStateOf(setOf("Öffis", "U-Bahn", "Tram", "Bus")) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCream)
            .padding(horizontal = 16.dp)
            .testTag("route_search_scroll"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // --- Header with Back Button ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = WienCharcoal)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (isGerman) "ROUTENPLANER" else "JOURNEY PLANNER",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = WienCharcoal
                    )
                    Text(
                        text = if (isGerman) "Suchen Sie Verbindungen in Echtzeit" else "Search connections in real time",
                        style = MaterialTheme.typography.labelLarge,
                        color = WienGrey
                    )
                }
            }
        }

        // --- Routing Inputs (Von, Nach, Via) ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Von (From)
                    Text(
                        text = if (isGerman) "VON (START)" else "FROM (ORIGIN)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = WienGrey
                    )
                    OutlinedTextField(
                        value = searchFrom,
                        onValueChange = { viewModel.updateSearchFrom(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("route_from_input"),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WienRed,
                            unfocusedBorderColor = WienLightGrey
                        ),
                        trailingIcon = {
                            if (searchFrom.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateSearchFrom("") }) {
                                    Icon(Icons.Filled.Clear, contentDescription = "Clear")
                                }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Nach (To)
                    Text(
                        text = if (isGerman) "NACH (ZIEL)" else "TO (DESTINATION)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = WienGrey
                    )
                    OutlinedTextField(
                        value = searchTo,
                        onValueChange = { viewModel.updateSearchTo(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("route_to_input"),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WienRed,
                            unfocusedBorderColor = WienLightGrey
                        ),
                        trailingIcon = {
                            if (searchTo.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateSearchTo("") }) {
                                    Icon(Icons.Filled.Clear, contentDescription = "Clear")
                                }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Via
                    Text(
                        text = if (isGerman) "VIA (ZWISCHENHALT - OPTIONAL)" else "VIA (INTERMEDIATE - OPTIONAL)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = WienGrey
                    )
                    OutlinedTextField(
                        value = viaInput,
                        onValueChange = { viaInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WienRed,
                            unfocusedBorderColor = WienLightGrey
                        )
                    )
                }
            }
        }

        // --- Time Options (Jetzt / Abfahrt / Ankunft) ---
        item {
            Text(
                text = if (isGerman) "ZEITPUNKT" else "DEPARTURE TIME",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = WienCharcoal,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            Row(modifier = Modifier.fillMaxWidth()) {
                val modes = listOf(
                    if (isGerman) "Jetzt" else "Now",
                    if (isGerman) "Abfahrt" else "Departure",
                    if (isGerman) "Ankunft" else "Arrival"
                )
                for (i in modes.indices) {
                    val active = travelTimeMode == i
                    Button(
                        onClick = { travelTimeMode = i },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (active) WienCharcoal else Color.White,
                            contentColor = if (active) Color.White else WienCharcoal
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(modes[i], fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // --- Accessibility Preference ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Accessible,
                            contentDescription = "Accessibility",
                            tint = WienRed,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isGerman) "BARRIEREFREI" else "100% STEP-FREE",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = WienCharcoal
                            )
                            Text(
                                text = if (isGerman) "Nutzung von Aufzügen bevorzugen" else "Prefer elevator routing",
                                fontSize = 11.sp,
                                color = WienGrey
                            )
                        }
                    }
                    Switch(
                        checked = isStepFreePref,
                        onCheckedChange = { viewModel.toggleStepFreePref() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = WienRed
                        ),
                        modifier = Modifier.testTag("accessibility_routing_toggle")
                    )
                }
            }
        }

        // --- Transport Modes Filtering ---
        item {
            Text(
                text = if (isGerman) "VERKEHRSMITTEL" else "TRANSPORT MODES",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = WienCharcoal,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                maxItemsInEachRow = 3
            ) {
                for ((icon, name, _) in transportModes) {
                    val isSelected = activeModes.contains(name)
                    Box(
                        modifier = Modifier
                            .padding(4.dp)
                            .background(
                                color = if (isSelected) WienRed else Color.White,
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable {
                                val current = activeModes.toMutableSet()
                                if (current.contains(name)) current.remove(name) else current.add(name)
                                activeModes = current
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                icon,
                                contentDescription = name,
                                tint = if (isSelected) Color.White else WienCharcoal,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = name,
                                color = if (isSelected) Color.White else WienCharcoal,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // --- Submit Search Button ---
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = { viewModel.executeRoutePlan() },
                colors = ButtonDefaults.buttonColors(containerColor = WienRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("submit_route_search_button"),
                enabled = searchFrom.isNotBlank() && searchTo.isNotBlank()
            ) {
                Text(
                    text = if (isGerman) "VERBINDUNGEN BERECHNEN" else "CALCULATE CONNECTIONS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    letterSpacing = 1.sp
                )
            }
        }

        // --- Shortcut Suggestions (POI & Commutes) ---
        item {
            Text(
                text = if (isGerman) "BELIEBTE ZIELE" else "FAVORITE DESTINATIONS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = WienCharcoal,
                modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
            )

            val suggestions = if (isGerman) {
                listOf("Schloss Schönbrunn", "Stephansdom", "Flughafen Wien (Airport)", "Prater & Riesenrad")
            } else {
                listOf("Schoenbrunn Palace", "St. Stephen's Cathedral", "Flughafen Wien (Airport)", "Prater Amusement Park")
            }

            for (target in suggestions) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable {
                            viewModel.updateSearchTo(target)
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Place, contentDescription = "POI", tint = WienRed)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = target,
                            fontWeight = FontWeight.Bold,
                            color = WienCharcoal
                        )
                    }
                }
            }
        }
    }
}
