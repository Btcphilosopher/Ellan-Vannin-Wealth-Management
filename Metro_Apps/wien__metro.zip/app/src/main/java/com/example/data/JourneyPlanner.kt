package com.example.data

import java.util.PriorityQueue

// --- Journey Result Models ---

data class RouteStep(
    val fromStationId: String,
    val toStationId: String,
    val lineId: String, // "WALK", "U1", "TRAM1", etc.
    val durationMinutes: Int,
    val directionDe: String,
    val directionEn: String
)

data class JourneyResult(
    val steps: List<RouteStep>,
    val totalDurationMinutes: Int,
    val totalChanges: Int,
    val walkingDistanceMeters: Int,
    val fareEur: Double,
    val isStepFree: Boolean,
    val isAffectedByDisruption: Boolean,
    val disruptionMessageDe: String? = null,
    val disruptionMessageEn: String? = null,
    val rankingTag: String = "" // "FASTEST", "FEWEST CHANGES", etc.
)

// --- Routing Engine ---

object JourneyPlanner {

    // Helper class for Dijkstra Node
    private data class Node(
        val stationId: String,
        val lastLineId: String?,
        val accumulatedTime: Int,
        val accumulatedChanges: Int,
        val accumulatedWalking: Int,
        val path: List<RouteStep>,
        val isStepFree: Boolean
    ) : Comparable<Node> {
        override fun compareTo(other: Node): Int {
            // Priority based on travel time primarily
            return this.accumulatedTime.compareTo(other.accumulatedTime)
        }
    }

    // Graph Construction & Pathfinding
    fun planJourney(
        fromStationId: String,
        toStationId: String,
        isStepFreePref: Boolean = false,
        avoidDisrupted: Boolean = true
    ): List<JourneyResult> {
        if (fromStationId == toStationId) return emptyList()

        val results = mutableListOf<JourneyResult>()

        // 1. Plan standard route (may be affected by disruption)
        val standardRoute = runDijkstra(fromStationId, toStationId, isStepFreePref, avoidDisruptions = false)
        if (standardRoute != null) {
            val isDisrupted = checkDisruptionsOnPath(standardRoute.path)
            val disruptionDetail = if (isDisrupted) getDisruptionForPath(standardRoute.path) else null
            
            results.add(
                createJourneyResult(
                    steps = standardRoute.path,
                    time = standardRoute.accumulatedTime,
                    changes = standardRoute.accumulatedChanges,
                    walking = standardRoute.accumulatedWalking,
                    isStepFree = standardRoute.isStepFree,
                    isAffected = isDisrupted,
                    disruption = disruptionDetail,
                    rankingTag = if (isDisrupted) "AFFECTED" else "FASTEST"
                )
            )
        }

        // 2. If standard route is disrupted, plan an alternative route bypassing disrupted segments
        if (checkDisruptionsOnPath(standardRoute?.path ?: emptyList()) && avoidDisrupted) {
            val alternativeRoute = runDijkstra(fromStationId, toStationId, isStepFreePref, avoidDisruptions = true)
            if (alternativeRoute != null && alternativeRoute.path != standardRoute?.path) {
                results.add(
                    createJourneyResult(
                        steps = alternativeRoute.path,
                        time = alternativeRoute.accumulatedTime,
                        changes = alternativeRoute.accumulatedChanges,
                        walking = alternativeRoute.accumulatedWalking,
                        isStepFree = alternativeRoute.isStepFree,
                        isAffected = false,
                        disruption = null,
                        rankingTag = "ALTERNATIVE"
                    )
                )
            }
        }

        // 3. Add an accessible/step-free route if the standard route wasn't completely step-free
        if (!isStepFreePref && standardRoute?.isStepFree == false) {
            val stepFreeRoute = runDijkstra(fromStationId, toStationId, forceStepFree = true, avoidDisruptions = avoidDisrupted)
            if (stepFreeRoute != null && stepFreeRoute.path != standardRoute.path) {
                results.add(
                    createJourneyResult(
                        steps = stepFreeRoute.path,
                        time = stepFreeRoute.accumulatedTime,
                        changes = stepFreeRoute.accumulatedChanges,
                        walking = stepFreeRoute.accumulatedWalking,
                        isStepFree = true,
                        isAffected = checkDisruptionsOnPath(stepFreeRoute.path),
                        disruption = if (checkDisruptionsOnPath(stepFreeRoute.path)) getDisruptionForPath(stepFreeRoute.path) else null,
                        rankingTag = "STEP-FREE"
                    )
                )
            }
        }

        // Sort results so the best/fastest working non-disrupted is presented nicely
        return results.sortedWith(compareBy({ it.isAffectedByDisruption }, { it.totalDurationMinutes }))
    }

    private fun runDijkstra(
        startId: String,
        endId: String,
        forceStepFree: Boolean = false,
        avoidDisruptions: Boolean = false
    ): Node? {
        val pq = PriorityQueue<Node>()
        // Map of stationId -> min time visited to prune states
        val visited = mutableMapOf<Pair<String, String?>, Int>()

        // Initialize queue
        pq.add(Node(startId, null, 0, 0, 0, emptyList(), true))

        while (!pq.isEmpty()) {
            val curr = pq.poll() ?: break

            if (curr.stationId == endId) {
                return curr
            }

            val stateKey = Pair(curr.stationId, curr.lastLineId)
            if (visited.containsKey(stateKey) && visited[stateKey]!! <= curr.accumulatedTime) {
                continue
            }
            visited[stateKey] = curr.accumulatedTime

            val station = TransitData.getStation(curr.stationId) ?: continue

            // For this station, check connections
            // Look through all lines passing through this station
            for (lineId in station.lines) {
                val line = TransitData.getLine(lineId) ?: continue
                
                // If we want to avoid disrupted lines
                if (avoidDisruptions) {
                    val isDisrupted = TransitData.activeDisruptions.any { 
                        it.lineId == lineId && it.affectedStations.contains(curr.stationId) 
                    }
                    if (isDisrupted) continue
                }

                val stationIdx = line.stations.indexOf(curr.stationId)
                if (stationIdx == -1) continue

                // Check direction forward and backward in stations list
                val directions = listOf(
                    Pair(stationIdx + 1, line.stations.last()), 
                    Pair(stationIdx - 1, line.stations.first())
                )

                for ((nextIdx, termStationId) in directions) {
                    if (nextIdx in line.stations.indices) {
                        val nextStationId = line.stations[nextIdx]
                        val nextStation = TransitData.getStation(nextStationId) ?: continue

                        // Filter step free
                        if (forceStepFree && (!station.hasLift || !nextStation.hasLift)) {
                            continue
                        }

                        // Calculate weights
                        val isTransfer = curr.lastLineId != null && curr.lastLineId != lineId
                        val transferPenalty = if (isTransfer) 4 else 0
                        
                        val travelTime = when (line.type) {
                            TransitType.UBAHN -> 2
                            TransitType.TRAM -> 3
                            TransitType.BUS -> 3
                            TransitType.SBAHN -> 3
                            TransitType.REGIONAL -> 4
                            TransitType.AIRPORT_CAT -> 8
                            TransitType.NIGHTLINE -> 4
                            else -> 5
                        }

                        val stepTime = travelTime + transferPenalty
                        val direction = TransitData.getStation(termStationId)
                        val step = RouteStep(
                            fromStationId = curr.stationId,
                            toStationId = nextStationId,
                            lineId = lineId,
                            durationMinutes = travelTime,
                            directionDe = direction?.name ?: "Endstation",
                            directionEn = direction?.name ?: "Terminus"
                        )

                        pq.add(
                            Node(
                                stationId = nextStationId,
                                lastLineId = lineId,
                                accumulatedTime = curr.accumulatedTime + stepTime,
                                accumulatedChanges = curr.accumulatedChanges + (if (isTransfer) 1 else 0),
                                accumulatedWalking = curr.accumulatedWalking,
                                path = curr.path + step,
                                isStepFree = curr.isStepFree && station.hasLift && nextStation.hasLift
                            )
                        )
                    }
                }
            }

            // Also check walking connections / micro mobility if relevant
            // For simplicity, we model micro mobility connections directly between nearby stations
            for (otherStation in TransitData.stations) {
                if (otherStation.id == curr.stationId) continue
                val dist = getDistanceInMeters(station, otherStation)
                if (dist < 1000) { // walkable distance (under 1km)
                    val walkTime = (dist / 80).toInt() + 1 // ~5 km/h
                    val step = RouteStep(
                        fromStationId = curr.stationId,
                        toStationId = otherStation.id,
                        lineId = "WALK",
                        durationMinutes = walkTime,
                        directionDe = otherStation.name,
                        directionEn = otherStation.name
                    )

                    pq.add(
                        Node(
                            stationId = otherStation.id,
                            lastLineId = "WALK",
                            accumulatedTime = curr.accumulatedTime + walkTime + (if (curr.lastLineId != null) 2 else 0), // transfer to walking penalty
                            accumulatedChanges = curr.accumulatedChanges,
                            accumulatedWalking = curr.accumulatedWalking + dist,
                            path = curr.path + step,
                            isStepFree = curr.isStepFree // walking is step free if stations have lifts
                        )
                    )
                }
            }
        }

        return null
    }

    private fun checkDisruptionsOnPath(steps: List<RouteStep>): Boolean {
        return steps.any { step ->
            TransitData.activeDisruptions.any { disruption ->
                disruption.lineId == step.lineId && 
                (disruption.affectedStations.contains(step.fromStationId) || 
                 disruption.affectedStations.contains(step.toStationId))
            }
        }
    }

    private fun getDisruptionForPath(steps: List<RouteStep>): Disruption? {
        for (step in steps) {
            val disp = TransitData.activeDisruptions.find { disruption ->
                disruption.lineId == step.lineId && 
                (disruption.affectedStations.contains(step.fromStationId) || 
                 disruption.affectedStations.contains(step.toStationId))
            }
            if (disp != null) return disp
        }
        return null
    }

    private fun createJourneyResult(
        steps: List<RouteStep>,
        time: Int,
        changes: Int,
        walking: Int,
        isStepFree: Boolean,
        isAffected: Boolean,
        disruption: Disruption?,
        rankingTag: String
    ): JourneyResult {
        // Compute consolidated steps (group consecutive same-line segments)
        val consolidatedSteps = mutableListOf<RouteStep>()
        if (steps.isNotEmpty()) {
            var currentSegment = steps.first()
            for (i in 1 until steps.size) {
                val nextStep = steps[i]
                if (nextStep.lineId == currentSegment.lineId && nextStep.lineId != "WALK" && nextStep.directionDe == currentSegment.directionDe) {
                    currentSegment = currentSegment.copy(
                        toStationId = nextStep.toStationId,
                        durationMinutes = currentSegment.durationMinutes + nextStep.durationMinutes
                    )
                } else {
                    consolidatedSteps.add(currentSegment)
                    currentSegment = nextStep
                }
            }
            consolidatedSteps.add(currentSegment)
        }

        // Calculate Fare
        val hasAirport = consolidatedSteps.any { it.fromStationId == "ST_CAT_AIRPORT" || it.toStationId == "ST_CAT_AIRPORT" }
        val hasCat = consolidatedSteps.any { it.lineId == "CAT" }
        val fare = when {
            hasCat -> 14.90
            hasAirport -> 4.40 // Vienna Core Zone (2.40) + Airport supplement (2.00)
            else -> 2.40 // Standard Single Zone ticket
        }

        return JourneyResult(
            steps = consolidatedSteps,
            totalDurationMinutes = time,
            totalChanges = changes,
            walkingDistanceMeters = walking,
            fareEur = fare,
            isStepFree = isStepFree,
            isAffectedByDisruption = isAffected,
            disruptionMessageDe = disruption?.titleDe,
            disruptionMessageEn = disruption?.titleEn,
            rankingTag = rankingTag
        )
    }

    private fun getDistanceInMeters(s1: Station, s2: Station): Int {
        // Simple Euclidean approximation for Vienna coordinates
        val dLat = s1.latitude - s2.latitude
        val dLon = s1.longitude - s2.longitude
        return (Math.sqrt(dLat * dLat + dLon * dLon) * 111000).toInt()
    }
}
