package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@Composable
fun RideModeScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    val journey by viewModel.selectedJourney.collectAsState()
    val activeIndex by viewModel.activeStepIndex.collectAsState()
    val secondsRemaining by viewModel.rideSecondsRemaining.collectAsState()

    val step = journey?.steps?.getOrNull(activeIndex)
    val fromStation = TransitData.getStation(step?.fromStationId ?: "")
    val toStation = TransitData.getStation(step?.toStationId ?: "")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCharcoal) // Dark high-contrast theme for Ride Mode
            .padding(16.dp)
            .testTag("ride_mode_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp), // Lift above bottom action
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // --- Live Indicator Pin ---
            Box(
                modifier = Modifier
                    .background(WienRed, RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "LIVE // RIDE MODE",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp,
                    letterSpacing = 2.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (step == null) {
                Text(
                    text = if (isGerman) "Fehler bei der Reiseroute." else "Journey route error.",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            } else {
                // --- Step Vehicle Branding & Direction ---
                if (step.lineId != "WALK") {
                    val line = TransitData.getLine(step.lineId)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .background(line?.color ?: WienRed, RoundedCornerShape(6.dp))
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = step.lineId,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 24.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (isGerman) step.directionDe.uppercase() else step.directionEn.uppercase(),
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp
                        )
                    }
                } else {
                    Text(
                        text = if (isGerman) "FUSSWEG" else "WALKING SEGMENT",
                        color = WienAmber,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // --- Next Train Countdown Monitor ---
                if (step.lineId != "WALK") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (isGerman) "NÄCHSTE ABFAHRT" else "NEXT TRAIN IN",
                                color = WienGrey,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )

                            val minutes = secondsRemaining / 60
                            val seconds = secondsRemaining % 60
                            val countdownStr = String.format("%02d:%02d", minutes, seconds)

                            Text(
                                text = countdownStr,
                                color = WienAmber,
                                fontSize = 64.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp,
                                modifier = Modifier.testTag("ride_countdown_timer")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Estimated Crowding per Wagon
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isGerman) "Auslastung: " else "Wagon Crowd: ",
                                    color = Color.White,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                
                                val crowding = RealtimeSimulator.getCrowdingForLine(step.lineId)
                                val text = when (crowding) {
                                    CrowdingLevel.LOW -> if (isGerman) "GERING" else "LOW"
                                    CrowdingLevel.MEDIUM -> if (isGerman) "MITTEL" else "MEDIUM"
                                    CrowdingLevel.HIGH -> if (isGerman) "HOCH" else "HIGH"
                                }
                                val color = when (crowding) {
                                    CrowdingLevel.LOW -> ColorU4
                                    CrowdingLevel.MEDIUM -> WienAmber
                                    CrowdingLevel.HIGH -> WienRed
                                }

                                Box(
                                    modifier = Modifier
                                        .background(color, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = text,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // --- Station Progression and Wayfinding ---
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isGerman) "AKTUELLE STATION" else "CURRENT STATION",
                        fontSize = 11.sp,
                        color = WienGrey,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = fromStation?.name?.uppercase() ?: "Wien Mitte",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )

                    Row(
                        modifier = Modifier.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(WienRed, RoundedCornerShape(6.dp))
                        )
                        Box(
                            modifier = Modifier
                                .width(120.dp)
                                .height(4.dp)
                                .background(WienGrey)
                        )
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(Color.White, RoundedCornerShape(6.dp))
                        )
                    }

                    Text(
                        text = if (isGerman) "NÄCHSTE STATION" else "NEXT STATION",
                        fontSize = 11.sp,
                        color = WienGrey,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = toStation?.name?.uppercase() ?: "Heiligenstadt",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Boarding Side metadata
                if (step.lineId != "WALK") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF222222)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isGerman) "Ausstiegseite: RECHTS" else "Exit Door: RIGHT SIDE",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                // --- Best Exit Smart metadata ---
                toStation?.let { st ->
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "💡 BEST EXIT SUGGESTION",
                                fontSize = 10.sp,
                                color = WienAmber,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isGerman) st.bestExitInfoDe else st.bestExitInfoEn,
                                fontSize = 12.sp,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Transfer change warning at Praterstern
                if (step.toStationId == "ST_PRATERSTERN") {
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WienAmber),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, contentDescription = "Transfer warning", tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isGerman) "UMSTEIGEN: U2 Richtung Seestadt" else "TRANSFER: U2 to Seestadt",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // --- Bottom Progress Advance bar button ---
        Button(
            onClick = { viewModel.advanceRideStep() },
            colors = ButtonDefaults.buttonColors(containerColor = WienRed),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .height(54.dp)
                .testTag("ride_advance_button")
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (activeIndex == (journey?.steps?.size ?: 0) - 1) {
                        if (isGerman) "ZIEL ERREICHT" else "ARRIVED AT DESTINATION"
                    } else {
                        if (isGerman) "NÄCHSTER FAHRTABSCHNITT" else "ADVANCE NEXT STEP"
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Filled.ChevronRight, contentDescription = "Next")
            }
        }
    }
}
