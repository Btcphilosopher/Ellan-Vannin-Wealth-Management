package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JourneyResultScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    val results by viewModel.journeyResults.collectAsState()
    val selectedJourney by viewModel.selectedJourney.collectAsState()
    val searchFrom by viewModel.searchFrom.collectAsState()
    val searchTo by viewModel.searchTo.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCream)
            .padding(horizontal = 16.dp)
            .testTag("journey_result_scroll"),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // --- Header with back button ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = WienCharcoal)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (isGerman) "SUCHERGEBNISSE" else "JOURNEY RESULTS",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = WienCharcoal
                    )
                    Text(
                        text = "${searchFrom.uppercase()} ➔ ${searchTo.uppercase()}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = WienRed
                    )
                }
            }
        }

        // --- List of Available Routes (Dijkstra Alternatives) ---
        item {
            Text(
                text = if (isGerman) "ROUTE AUSWÄHLEN" else "SELECT A ROUTE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = WienGrey,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        if (results.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = "No routes", tint = WienRed, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isGerman) "Keine Verbindungen gefunden." else "No connections found.",
                            fontWeight = FontWeight.Bold,
                            color = WienCharcoal
                        )
                        Text(
                            text = if (isGerman) "Bitte überprüfen Sie Ihre Stationen-Eingaben." else "Please check your station inputs.",
                            fontSize = 12.sp,
                            color = WienGrey
                        )
                    }
                }
            }
        }

        items(results) { journey ->
            val isSelected = selectedJourney == journey
            val isDisrupted = journey.isAffectedByDisruption

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) WienCharcoal else Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clickable { viewModel.selectJourney(journey) }
                    .border(
                        width = if (isDisrupted) 2.dp else 0.dp,
                        color = if (isDisrupted) WienRed else Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Tag
                        if (journey.rankingTag.isNotEmpty()) {
                            val tagBg = when (journey.rankingTag) {
                                "FASTEST" -> WienRed
                                "ALTERNATIVE" -> ColorU4
                                "STEP-FREE" -> ColorWienMobil
                                "AFFECTED" -> Color.Black
                                else -> WienGrey
                            }
                            Box(
                                modifier = Modifier
                                    .background(tagBg, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = when (journey.rankingTag) {
                                        "FASTEST" -> if (isGerman) "SCHNELLSTE" else "FASTEST"
                                        "ALTERNATIVE" -> if (isGerman) "STÖRUNGS-ALTERNATIVE" else "DISRUPTION ROUTE"
                                        "STEP-FREE" -> if (isGerman) "BARRIEREFREI" else "STEP-FREE"
                                        "AFFECTED" -> if (isGerman) "⚠️ BETROFFEN" else "⚠️ AFFECTED"
                                        else -> journey.rankingTag
                                    },
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Duration
                        Text(
                            text = "${journey.totalDurationMinutes} min",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = if (isSelected) Color.White else WienCharcoal
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Line icons representation
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        var first = true
                        for (step in journey.steps) {
                            if (step.lineId != "WALK") {
                                if (!first) {
                                    Icon(
                                        Icons.Filled.ChevronRight,
                                        contentDescription = "to",
                                        tint = if (isSelected) Color.White else WienGrey,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                first = false
                                val line = TransitData.getLine(step.lineId)
                                Box(
                                    modifier = Modifier
                                        .background(line?.color ?: WienRed, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = step.lineId,
                                        color = Color.White,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (journey.totalChanges == 0) {
                                if (isGerman) "Direktfahrt" else "Direct connection"
                            } else {
                                if (isGerman) "${journey.totalChanges}x Umsteigen" else "${journey.totalChanges} Transfers"
                            },
                            fontSize = 11.sp,
                            color = if (isSelected) Color.White else WienGrey
                        )

                        Text(
                            text = String.format("%.2f €", journey.fareEur),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) WienAmber else WienRed
                        )
                    }
                }
            }
        }

        // --- Selected Journey Detailed Steps ---
        selectedJourney?.let { journey ->
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = if (isGerman) "ROUTEN-TIMELINE" else "ROUTE TIMELINE",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = WienGrey,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            // Disruption Banner overlay
            if (journey.isAffectedByDisruption) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WienRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                            .testTag("disruption_warning_banner")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Warning, contentDescription = "Alert", tint = Color.White)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (isGerman) "⚠️ IHRE FAHRT IST BETROFFEN" else "⚠️ YOUR JOURNEY IS AFFECTED",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isGerman) {
                                    "Die U4 ist derzeit aufgrund einer Stellwerkstörung am Karlsplatz unterbrochen. " +
                                    "Bitte nutzen Sie das alternative Szenario im Routenplaner für eine störungsfreie Umfahrung."
                                } else {
                                    "Line U4 is currently suspended due to a signal failure. " +
                                    "Please use the suggested Alternative route to bypass the suspended line."
                                },
                                fontSize = 12.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            items(journey.steps) { step ->
                val fromStation = TransitData.getStation(step.fromStationId)
                val toStation = TransitData.getStation(step.toStationId)

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(modifier = Modifier.padding(16.dp)) {
                        // Timeline Bar & Line visual
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.width(28.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(WienCharcoal, RoundedCornerShape(5.dp))
                            )
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(48.dp)
                                    .background(WienLightGrey)
                            )
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(WienCharcoal, RoundedCornerShape(5.dp))
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            // Origin
                            Text(
                                text = fromStation?.name?.uppercase() ?: "Start",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = WienCharcoal
                            )

                            // Step Details
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (step.lineId == "WALK") {
                                    Icon(Icons.Filled.DirectionsWalk, contentDescription = "Walk", tint = WienGrey, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isGerman) "Fußweg (${step.durationMinutes} min)" else "Walk (${step.durationMinutes} mins)",
                                        fontSize = 12.sp,
                                        color = WienGrey
                                    )
                                } else {
                                    val line = TransitData.getLine(step.lineId)
                                    Box(
                                        modifier = Modifier
                                            .background(line?.color ?: WienRed, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = step.lineId,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isGerman) "Richtung: ${step.directionDe}" else "Direction: ${step.directionEn}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = WienCharcoal
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "(${step.durationMinutes} min)",
                                        fontSize = 12.sp,
                                        color = WienGrey
                                    )
                                }
                            }

                            // Destination
                            Text(
                                text = toStation?.name?.uppercase() ?: "Ziel",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = WienCharcoal
                            )
                        }
                    }
                }
            }

            // --- CTA: Start Journey / Enter Ride Mode ---
            item {
                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { viewModel.startRideMode(journey) },
                    colors = ButtonDefaults.buttonColors(containerColor = WienRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("start_ride_mode_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Start Journey", tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isGerman) "RITT STARTEN (EINSTEIGEN)" else "START JOURNEY (BOARD TRAIN)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }
    }
}
