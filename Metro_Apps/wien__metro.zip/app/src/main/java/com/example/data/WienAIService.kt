package com.example.data

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object WienAIService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private fun String.escapeJson(): String {
        return this.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
    }

    suspend fun askWienAI(userQuery: String, isGerman: Boolean): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        val hasDisruption = TransitData.activeDisruptions.isNotEmpty()
        val disruptionText = if (hasDisruption) {
            val d = TransitData.activeDisruptions.first()
            "STÖRUNG AKTIV: Linie ${d.lineId} unterbrochen zwischen ${d.affectedStations.joinToString(" und ") { TransitData.getStation(it)?.name ?: "" }}. Grund: ${d.descriptionDe}. Alternative: ${d.alternativeAdviceDe}."
        } else {
            "Keine bekannten Netzstörungen im U-Bahn-Netz."
        }

        val contextPrompt = """
            Du bist WIEN.AI, der digitale Reisebegleiter der Wiener Linien und WIEN//METRO App. 
            Aktuelle Uhrzeit im Simulator: ${RealtimeSimulator.getFormattedTime()}.
            Aktuelle Netzstörungen: $disruptionText
            
            U-Bahn-Netz der WIEN//METRO:
            - U1 (Oberlaa <-> Leopoldau) über Hauptbahnhof, Karlsplatz, Stephansplatz, Praterstern.
            - U2 (Karlsplatz <-> Seestadt) über Volkstheater, Schottentor, Praterstern.
            - U3 (Ottakring <-> Simmering) über Westbahnhof, Volkstheater, Stephansplatz, Landstraße (Wien Mitte).
            - U4 (Hütteldorf <-> Heiligenstadt) über Schönbrunn, Karlsplatz, Landstraße, Schwedenplatz, Spittelau.
            - U6 (Siebenhirten <-> Floridsdorf) über Bahnhof Meidling, Längenfeldgasse, Westbahnhof, Spittelau.
            
            Wichtige Orte & touristische Ziele:
            - Schloss Schönbrunn: U4 Station Schönbrunn oder Bus 10A.
            - Stephansdom: U1/U3 Station Stephansplatz.
            - Prater (Riesenrad): U1/U2 Station Praterstern.
            - Flughafen Wien (Airport): S-Bahn S7 oder City Airport Train (CAT) von Landstraße (Wien Mitte).
            - Hauptbahnhof: U1 Station Südtiroler Platz-Hauptbahnhof.
            
            Barrierefreiheit: Fast alle U-Bahn Stationen haben Aufzüge. Wenn U4 gestört ist, ist der Umstieg am Karlsplatz für U4 nicht möglich.
            
            Regeln:
            - Erfinde KEINE Linien oder Haltestellen, die nicht im Netz existieren.
            - Wenn der Benutzer fragt 'Wie komme ich am schnellsten nach Schönbrunn?' und die U4 gestört ist, weise ihn ausdrücklich auf die Störung hin und schlage die Alternative vor: U1 bis Meidling und dort Bus 10A oder Straßenbahn 62.
            - Antworte kurz, professionell und mit Wiener Höflichkeit.
            - Wenn der Benutzer auf Deutsch fragt, antworte auf Deutsch. Wenn auf Englisch, auf Englisch.
        """.trimIndent()

        // Fallback or Local Rule-Based Engine
        val localResponse = generateLocalResponse(userQuery, isGerman, hasDisruption)

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // No real API key configured, use the intelligent local rules which feel exactly like AI!
            return@withContext localResponse
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val jsonBody = """
                {
                  "contents": [
                    {
                      "parts": [
                        {
                          "text": "${userQuery.escapeJson()}"
                        }
                      ]
                    }
                  ],
                  "systemInstruction": {
                    "parts": [
                      {
                        "text": "${contextPrompt.escapeJson()}"
                      }
                    ]
                  },
                  "generationConfig": {
                    "temperature": 0.3,
                    "maxOutputTokens": 250
                  }
                }
            """.trimIndent()

            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val rawJson = response.body?.string() ?: return@withContext localResponse
                    val jsonObj = JSONObject(rawJson)
                    val candidates = jsonObj.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val content = candidates.getJSONObject(0).optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            return@withContext parts.getJSONObject(0).optString("text", localResponse)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Silently fall back to local response on connection error
        }

        return@withContext localResponse
    }

    private fun generateLocalResponse(query: String, isGerman: Boolean, hasDisruption: Boolean): String {
        val q = query.lowercase()
        return if (isGerman) {
            when {
                q.contains("schönbrunn") || q.contains("schoenbrunn") -> {
                    if (hasDisruption) {
                        "⚠️ **Achtung: Die U4 ist derzeit zwischen Karlsplatz und Schönbrunn gestört!**\n\n" +
                        "**Empfohlene Alternative:**\n" +
                        "1. Nehmen Sie die **U1** vom Stadtzentrum (Stephansplatz/Karlsplatz) Richtung Oberlaa bis **Bahnhof Meidling**.\n" +
                        "2. Steigen Sie dort in den **Bus 10A** oder die **Straßenbahn 62** um, um direkt nach Schönbrunn zu gelangen.\n\n" +
                        "Dauer: ca. 24 Minuten (barrierefrei)."
                    } else {
                        "🚇 **Schnellste Route nach Schönbrunn:**\n" +
                        "Nehmen Sie die Linie **U4** Richtung Hütteldorf direkt bis zur Station **Schönbrunn**.\n\n" +
                        "Dauer ab Karlsplatz: ca. 11 Minuten (6 Stationen)."
                    }
                }
                q.contains("flughafen") || q.contains("airport") -> {
                    "✈️ **Routen zum Flughafen Wien:**\n\n" +
                    "• **SCHNELLSTE (CAT):** Nehmen Sie den **City Airport Train (CAT)** ab Landstraße (Wien Mitte). Fahrtzeit: 16 Min. nonstop. *Sonderpreis: 14,90 €.*\n" +
                    "• **GÜNSTIGSTE (S-Bahn S7):** Nehmen Sie die **S7** ab Landstraße oder Praterstern. Fahrtzeit: ca. 25 Min. *Preis: 4,40 € (inkl. Kernzone).* \n\n" +
                    "Züge fahren alle 30 Minuten."
                }
                q.contains("u4") -> {
                    if (hasDisruption) {
                        "⚠️ **Aktuelle Betriebsstörung auf der U4:**\n" +
                        "Stellwerkstörung am Karlsplatz. Kein Betrieb zwischen Karlsplatz und Schönbrunn. Pendelzugbetrieb zwischen Schönbrunn und Hütteldorf bzw. Karlsplatz und Heiligenstadt. Bitte weichen Sie auf die Linien U1, U6 oder Straßenbahnen aus."
                    } else {
                        "✅ Die Linie **U4** (Hütteldorf <-> Heiligenstadt) fährt derzeit planmäßig und ohne bekannte Verzögerungen."
                    }
                }
                q.contains("barrierefrei") || q.contains("aufzug") || q.contains("lift") -> {
                    "♿ **Barrierefreiheit im Wiener Netz:**\n" +
                    "95% unserer Stationen sind vollkommen stufenlos zugänglich. Jede Metro-Station verfügt über mindestens einen Aufzug und Blindenleitsysteme.\n\n" +
                    "Aktuell sind alle Lifts auf Ihren Favoritenstrecken betriebsbereit."
                }
                q.contains("hallo") || q.contains("guten tag") || q.contains("servus") -> {
                    "Servus! Ich bin **WIEN.AI**, dein digitaler Metro-Assistent. Wie kann ich dir heute bei deiner Fahrt durch Wien helfen?"
                }
                else -> {
                    "Ich verstehe deine Frage zum Wiener Liniennetz. Hier sind die Schnellzugriffe auf der Startseite: \n" +
                    "• Nutze den **Routenplaner** für exakte Verbindungen inklusive Fußwege.\n" +
                    "• Unter **Abfahrten** findest du die Echtzeit-Monitore aller Stationen."
                }
            }
        } else {
            // English responses
            when {
                q.contains("schonbrunn") || q.contains("schoenbrunn") -> {
                    if (hasDisruption) {
                        "⚠️ **Attention: Line U4 is currently disrupted between Karlsplatz and Schönbrunn!**\n\n" +
                        "**Recommended Alternative:**\n" +
                        "1. Take Metro line **U1** from the city center (Stephansplatz/Karlsplatz) direction Oberlaa to **Bahnhof Meidling**.\n" +
                        "2. Transfer there to **Bus 10A** or **Tram 62** to reach Schönbrunn directly.\n\n" +
                        "Duration: approx. 24 minutes (100% step-free)."
                    } else {
                        "🚇 **Fastest route to Schönbrunn Palace:**\n" +
                        "Take Metro line **U4** direction Hütteldorf directly to the **Schönbrunn** station.\n\n" +
                        "Duration from Karlsplatz: approx. 11 minutes (6 stops)."
                    }
                }
                q.contains("airport") || q.contains("flughafen") -> {
                    "✈️ **Routes to Vienna Airport:**\n\n" +
                    "• **FASTEST (CAT):** Take the **City Airport Train (CAT)** from Landstraße (Wien Mitte). Travel time: 16 mins nonstop. *Fare: €14.90.*\n" +
                    "• **CHEAPEST (S-Bahn S7):** Take the **S-Bahn S7** from Landstraße or Praterstern. Travel time: approx. 25 mins. *Fare: €4.40 (including core zone).*\n\n" +
                    "Trains depart every 30 minutes."
                }
                q.contains("u4") -> {
                    if (hasDisruption) {
                        "⚠️ **Current service alert on U4:**\n" +
                        "Signal failure at Karlsplatz. Suspended service between Karlsplatz and Schönbrunn. Shuttle operation between Hütteldorf and Schönbrunn, and between Karlsplatz and Heiligenstadt. Please divert via lines U1, U6, or local trams."
                    } else {
                        "✅ Line **U4** (Hütteldorf <-> Heiligenstadt) is running normally with no reported delays."
                    }
                }
                q.contains("accessible") || q.contains("wheelchair") || q.contains("lift") || q.contains("elevator") -> {
                    "♿ **Accessibility in Vienna:**\n" +
                    "95% of our stations are completely step-free. Every metro station is equipped with at least one elevator, tactile paving, and low-floor trains.\n\n" +
                    "All lifts on your planned routes are currently operational."
                }
                q.contains("hello") || q.contains("hi") || q.contains("hey") -> {
                    "Hello! I am **WIEN.AI**, your digital metro companion. How can I assist you with your journey through Vienna today?"
                }
                else -> {
                    "I can help you navigate Vienna's transit network. Try asking about Schönbrunn Palace, Airport routes, accessibility, or live alerts!"
                }
            }
        }
    }
}
