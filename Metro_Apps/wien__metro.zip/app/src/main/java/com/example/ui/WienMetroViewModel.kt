package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AppScreen {
    HOME, ROUTE_SEARCH, JOURNEY_RESULT, DEPARTURES, TICKETS, TICKET_DETAILS, STATION_PAGES, LINE_PAGES, NETWORK_MAP, RIDE_MODE, WIEN_AI
}

data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: String
)

class WienMetroViewModel : ViewModel() {

    // --- Navigation & Localization ---
    private val _screenStack = MutableStateFlow(listOf(AppScreen.HOME))
    val screenStack: StateFlow<List<AppScreen>> = _screenStack.asStateFlow()

    private val _isGerman = MutableStateFlow(true)
    val isGerman: StateFlow<Boolean> = _isGerman.asStateFlow()

    // --- Search & Journey Planning ---
    private val _searchFrom = MutableStateFlow("Karlsplatz")
    val searchFrom: StateFlow<String> = _searchFrom.asStateFlow()

    private val _searchTo = MutableStateFlow("")
    val searchTo: StateFlow<String> = _searchTo.asStateFlow()

    private val _isStepFreePref = MutableStateFlow(false)
    val isStepFreePref: StateFlow<Boolean> = _isStepFreePref.asStateFlow()

    private val _journeyResults = MutableStateFlow<List<JourneyResult>>(emptyList())
    val journeyResults: StateFlow<List<JourneyResult>> = _journeyResults.asStateFlow()

    private val _selectedJourney = MutableStateFlow<JourneyResult?>(null)
    val selectedJourney: StateFlow<JourneyResult?> = _selectedJourney.asStateFlow()

    // --- Station & Line Details ---
    private val _selectedStationId = MutableStateFlow("ST_KARLSPLATZ")
    val selectedStationId: StateFlow<String> = _selectedStationId.asStateFlow()

    private val _selectedLineId = MutableStateFlow("U1")
    val selectedLineId: StateFlow<String> = _selectedLineId.asStateFlow()

    // --- Ride Mode (Active Journey Progress) ---
    private val _activeStepIndex = MutableStateFlow(0)
    val activeStepIndex: StateFlow<Int> = _activeStepIndex.asStateFlow()

    private val _rideSecondsRemaining = MutableStateFlow(102) // countdown for the next train in Ride Mode
    val rideSecondsRemaining: StateFlow<Int> = _rideSecondsRemaining.asStateFlow()

    // --- Tickets & Purchases ---
    private val _selectedTicketTypeId = MutableStateFlow("EINZEL")
    val selectedTicketTypeId: StateFlow<String> = _selectedTicketTypeId.asStateFlow()

    private val _viewingTicketId = MutableStateFlow("")
    val viewingTicketId: StateFlow<String> = _viewingTicketId.asStateFlow()

    private val _buyerName = MutableStateFlow("TOM")
    val buyerName: StateFlow<String> = _buyerName.asStateFlow()

    // --- Chat with Wien.AI ---
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    // --- Simulation ticker job ---
    private var simulationJob: Job? = null
    private var countdownJob: Job? = null

    // --- Favourites ---
    private val _favorites = MutableStateFlow<Set<String>>(setOf("ST_STEPHANSPLATZ", "ST_KARLSPLATZ"))
    val favorites: StateFlow<Set<String>> = _favorites.asStateFlow()

    init {
        // Start simulated realtime loop
        startSimulation()
        // Reset chat with welcome message
        resetChat()
    }

    // Navigation helper
    fun navigateTo(screen: AppScreen) {
        val current = _screenStack.value.toMutableList()
        current.add(screen)
        _screenStack.value = current
    }

    fun navigateBack() {
        val current = _screenStack.value.toMutableList()
        if (current.size > 1) {
            current.removeAt(current.size - 1)
            _screenStack.value = current
        }
    }

    fun navigateHome() {
        _screenStack.value = listOf(AppScreen.HOME)
    }

    fun setLanguage(german: Boolean) {
        _isGerman.value = german
        resetChat()
    }

    // Search and routing
    fun updateSearchFrom(from: String) {
        _searchFrom.value = from
    }

    fun updateSearchTo(to: String) {
        _searchTo.value = to
    }

    fun toggleStepFreePref() {
        _isStepFreePref.value = !_isStepFreePref.value
    }

    fun executeRoutePlan() {
        val fromStation = TransitData.findStationByName(_searchFrom.value)
        val toStation = TransitData.findStationByName(_searchTo.value)

        if (fromStation != null && toStation != null) {
            val results = JourneyPlanner.planJourney(
                fromStationId = fromStation.id,
                toStationId = toStation.id,
                isStepFreePref = _isStepFreePref.value,
                avoidDisrupted = true
            )
            _journeyResults.value = results
            if (results.isNotEmpty()) {
                _selectedJourney.value = results.first()
            } else {
                _selectedJourney.value = null
            }
            navigateTo(AppScreen.JOURNEY_RESULT)
        }
    }

    fun selectJourney(journey: JourneyResult) {
        _selectedJourney.value = journey
    }

    fun selectStation(stationId: String) {
        _selectedStationId.value = stationId
        navigateTo(AppScreen.STATION_PAGES)
    }

    fun selectLine(lineId: String) {
        _selectedLineId.value = lineId
        navigateTo(AppScreen.LINE_PAGES)
    }

    // Ride Mode management
    fun startRideMode(journey: JourneyResult) {
        _selectedJourney.value = journey
        _activeStepIndex.value = 0
        _rideSecondsRemaining.value = 102 // Reset countdown to 1:42
        navigateTo(AppScreen.RIDE_MODE)
        startRideCountdowns()
    }

    private fun startRideCountdowns() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_rideSecondsRemaining.value > 0) {
                    _rideSecondsRemaining.value = _rideSecondsRemaining.value - 1
                } else {
                    // Reset to a new simulated train arrival
                    _rideSecondsRemaining.value = (30..120).random()
                }
            }
        }
    }

    fun advanceRideStep() {
        val stepsSize = _selectedJourney.value?.steps?.size ?: 0
        if (_activeStepIndex.value < stepsSize - 1) {
            _activeStepIndex.value = _activeStepIndex.value + 1
            _rideSecondsRemaining.value = (30..120).random()
        } else {
            // Arrived! Go back to home
            navigateHome()
        }
    }

    // Ticketing
    fun setSelectedTicketType(typeId: String) {
        _selectedTicketTypeId.value = typeId
    }

    fun updateBuyerName(name: String) {
        _buyerName.value = name
    }

    fun buyTicket() {
        val ticket = TicketEngine.purchaseTicket(_selectedTicketTypeId.value, _buyerName.value)
        if (ticket != null) {
            _viewingTicketId.value = ticket.id
            navigateTo(AppScreen.TICKET_DETAILS)
        }
    }

    fun viewTicket(ticketId: String) {
        _viewingTicketId.value = ticketId
        navigateTo(AppScreen.TICKET_DETAILS)
    }

    // Wien.AI
    fun sendMessageToAI(text: String) {
        if (text.isBlank()) return
        val now = RealtimeSimulator.getFormattedTime()
        val userMsg = ChatMessage(text, isUser = true, timestamp = now)
        _chatMessages.value = _chatMessages.value + userMsg

        _isChatLoading.value = true
        viewModelScope.launch {
            val response = WienAIService.askWienAI(text, _isGerman.value)
            val aiMsg = ChatMessage(response, isUser = false, timestamp = RealtimeSimulator.getFormattedTime())
            _chatMessages.value = _chatMessages.value + aiMsg
            _isChatLoading.value = false
        }
    }

    fun resetChat() {
        val welcomeDe = "Servus! Ich bin **WIEN.AI**, dein digitaler Begleiter für WIEN//METRO. Frag mich alles über Verbindungen, Abfahrten oder Störungen im Wiener Liniennetz! Zum Beispiel: *'Wie komme ich am schnellsten nach Schönbrunn?'* oder *'Fährt die U4 heute?'*"
        val welcomeEn = "Servus! I am **WIEN.AI**, your digital guide for WIEN//METRO. Ask me anything about routes, departures, or service disruptions in Vienna! E.g. *'How do I get to the airport?'* or *'Is U4 running normally?'*"
        _chatMessages.value = listOf(
            ChatMessage(
                text = if (_isGerman.value) welcomeDe else welcomeEn,
                isUser = false,
                timestamp = RealtimeSimulator.getFormattedTime()
            )
        )
    }

    // Favourites toggle
    fun toggleFavorite(stationId: String) {
        val current = _favorites.value.toMutableSet()
        if (current.contains(stationId)) {
            current.remove(stationId)
        } else {
            current.add(stationId)
        }
        _favorites.value = current
    }

    // Simulation Trigger
    fun changeScenario(scenario: SimScenario) {
        RealtimeSimulator.setScenario(scenario)
    }

    private fun startSimulation() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            while (true) {
                delay(5000) // 5 seconds in real-world is 1 simulated minute
                RealtimeSimulator.tick()
            }
        }
    }

    override fun onCleared() {
        simulationJob?.cancel()
        countdownJob?.cancel()
        super.onCleared()
    }
}
