package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun WienMetroApp(viewModel: WienMetroViewModel) {
    val screenStack by viewModel.screenStack.collectAsState()
    val isGerman by viewModel.isGerman.collectAsState()

    val currentScreen = screenStack.lastOrNull() ?: AppScreen.HOME

    // Programmatic back handler configuration
    BackHandler(enabled = screenStack.size > 1) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Display standard bottom navigation bar when not in full-screen RIDE MODE
            if (currentScreen != AppScreen.RIDE_MODE) {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 8.dp,
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("app_bottom_navigation")
                ) {
                    val navItems = listOf(
                        Quadruple(AppScreen.HOME, Icons.Filled.Home, "Home", "Home"),
                        Quadruple(AppScreen.ROUTE_SEARCH, Icons.Filled.DirectionsTransit, "Route", "Route"),
                        Quadruple(AppScreen.DEPARTURES, Icons.Filled.Schedule, "Abfahrten", "Departures"),
                        Quadruple(AppScreen.TICKETS, Icons.Filled.ConfirmationNumber, "Tickets", "Tickets"),
                        Quadruple(AppScreen.WIEN_AI, Icons.Filled.AutoAwesome, "Wien.AI", "Wien.AI")
                    )

                    navItems.forEach { (screen, icon, labelDe, labelEn) ->
                        val active = currentScreen == screen || 
                                     (screen == AppScreen.ROUTE_SEARCH && currentScreen == AppScreen.JOURNEY_RESULT) ||
                                     (screen == AppScreen.TICKETS && currentScreen == AppScreen.TICKET_DETAILS)
                        
                        NavigationBarItem(
                            selected = active,
                            onClick = {
                                if (currentScreen != screen) {
                                    viewModel.navigateTo(screen)
                                }
                            },
                            icon = { Icon(icon, contentDescription = if (isGerman) labelDe else labelEn) },
                            label = { 
                                Text(
                                    text = if (isGerman) labelDe else labelEn,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                ) 
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = WienRed,
                                selectedTextColor = WienRed,
                                indicatorColor = WienLightGrey,
                                unselectedIconColor = WienGrey,
                                unselectedTextColor = WienGrey
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(WienCream)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> HomeScreen(viewModel)
                AppScreen.ROUTE_SEARCH -> RouteSearchScreen(viewModel)
                AppScreen.JOURNEY_RESULT -> JourneyResultScreen(viewModel)
                AppScreen.DEPARTURES -> DepartureBoardScreen(viewModel)
                AppScreen.TICKETS -> TicketWalletScreen(viewModel)
                AppScreen.TICKET_DETAILS -> TicketDetailsScreen(viewModel)
                AppScreen.STATION_PAGES -> StationPagesScreen(viewModel)
                AppScreen.LINE_PAGES -> LinePagesScreen(viewModel)
                AppScreen.NETWORK_MAP -> NetworkMapScreen(viewModel)
                AppScreen.RIDE_MODE -> RideModeScreen(viewModel)
                AppScreen.WIEN_AI -> WienAIScreen(viewModel)
            }
        }
    }
}

// Simple quad holder
data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
