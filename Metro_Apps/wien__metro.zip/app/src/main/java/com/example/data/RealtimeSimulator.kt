package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

// Simulation Scenarios
enum class SimScenario {
    NORMAL_DAY, RUSH_HOUR, DISRUPTION, MAJOR_EVENT, NIGHT_SERVICE
}

object RealtimeSimulator {
    private val _currentScenario = MutableStateFlow(SimScenario.NORMAL_DAY)
    val currentScenario: StateFlow<SimScenario> = _currentScenario.asStateFlow()

    // Clock state (simulated minutes in the day, e.g., 08:30 is 510)
    private val _simClock = MutableStateFlow(510) // 8:30 AM default
    val simClock: StateFlow<Int> = _simClock.asStateFlow()

    // WienMobil Rad (Bike Sharing) details: Station ID -> (Bikes available, Free docks)
    private val _bikeSharingState = MutableStateFlow<Map<String, Pair<Int, Int>>>(emptyMap())
    val bikeSharingState = _bikeSharingState.asStateFlow()

    // WienMobil Auto (Car Sharing) details: Station ID -> (EV, Transporter, Family)
    private val _carSharingState = MutableStateFlow<Map<String, Triple<Int, Int, Int>>>(emptyMap())
    val carSharingState = _carSharingState.asStateFlow()

    init {
        resetSimulator(SimScenario.NORMAL_DAY)
    }

    fun setScenario(scenario: SimScenario) {
        _currentScenario.value = scenario
        resetSimulator(scenario)
    }

    fun tick() {
        // Increment clock by 1 simulated minute
        var nextTime = _simClock.value + 1
        if (nextTime >= 1440) nextTime = 0 // Wrap around 24 hours
        _simClock.value = nextTime

        // Update bike and car state randomly to simulate real flow
        val currentBikes = _bikeSharingState.value.toMutableMap()
        for (stationId in currentBikes.keys) {
            val (bikes, docks) = currentBikes[stationId] ?: continue
            if (Random.nextDouble() < 0.2) {
                val total = bikes + docks
                val delta = if (Random.nextBoolean() && bikes > 2) -1 else if (docks > 2) 1 else 0
                val newBikes = (bikes + delta).coerceIn(0, total)
                currentBikes[stationId] = Pair(newBikes, total - newBikes)
            }
        }
        _bikeSharingState.value = currentBikes
    }

    private fun resetSimulator(scenario: SimScenario) {
        // Set clock based on scenario
        _simClock.value = when (scenario) {
            SimScenario.NORMAL_DAY -> 510   // 08:30 AM
            SimScenario.RUSH_HOUR -> 460    // 07:40 AM
            SimScenario.DISRUPTION -> 510   // 08:30 AM
            SimScenario.MAJOR_EVENT -> 1110  // 18:30 PM (Evening concert/match)
            SimScenario.NIGHT_SERVICE -> 120 // 02:00 AM
        }

        // Configure disruptions
        if (scenario == SimScenario.DISRUPTION) {
            if (TransitData.activeDisruptions.isEmpty()) {
                TransitData.activeDisruptions.add(
                    Disruption(
                        id = "DIS_U4",
                        lineId = "U4",
                        titleDe = "Signalstörung am Karlsplatz",
                        titleEn = "Signal failure at Karlsplatz",
                        descriptionDe = "Wegen einer Stellwerkstörung am Karlsplatz ist die Linie U4 zwischen Karlsplatz und Schönbrunn unterbrochen. Schienenersatzverkehr ist eingerichtet.",
                        descriptionEn = "Due to a signaling system failure at Karlsplatz, service on line U4 is suspended between Karlsplatz and Schönbrunn. Rail replacement buses are active.",
                        affectedStations = listOf("ST_KARLSPLATZ", "ST_SCHOENBRUNN"),
                        alternativeAdviceDe = "Bitte weichen Sie auf die Linie U1 bis Meidling aus und nutzen Sie dort die Straßenbahnlinie 62 oder Bus 10A nach Schönbrunn.",
                        alternativeAdviceEn = "Please use Metro line U1 to Meidling, then change to Tram 62 or Bus 10A to Schönbrunn.",
                        expectedDurationDe = "ca. 45 Minuten",
                        expectedDurationEn = "approx. 45 minutes"
                    )
                )
            }
        } else {
            TransitData.activeDisruptions.clear()
        }

        // Initialize bike sharing docks
        val initialBikes = mutableMapOf<String, Pair<Int, Int>>()
        for (station in TransitData.stations) {
            if (station.hasBikeSharing) {
                val totalDocks = Random.nextInt(15, 30)
                val bikes = Random.nextInt(5, totalDocks - 2)
                initialBikes[station.id] = Pair(bikes, totalDocks - bikes)
            }
        }
        _bikeSharingState.value = initialBikes

        // Initialize car sharing availability
        val initialCars = mutableMapOf<String, Triple<Int, Int, Int>>()
        for (station in TransitData.stations) {
            if (station.hasCarSharing) {
                initialCars[station.id] = Triple(
                    Random.nextInt(1, 4), // EV
                    Random.nextInt(0, 2), // Transporter
                    Random.nextInt(0, 3)  // Family
                )
            }
        }
        _carSharingState.value = initialCars
    }

    // Generate departures for a given station and line
    fun getDeparturesForStation(stationId: String, lineId: String): List<Int> {
        val scenario = _currentScenario.value
        val baseHeadway = when (scenario) {
            SimScenario.RUSH_HOUR -> 3
            SimScenario.NORMAL_DAY -> 5
            SimScenario.DISRUPTION -> 6
            SimScenario.MAJOR_EVENT -> 4
            SimScenario.NIGHT_SERVICE -> 15
        }

        val seed = stationId.hashCode() + lineId.hashCode() + _simClock.value / baseHeadway
        val rng = Random(seed)

        // Make first departure dynamic but deterministic
        val firstDep = rng.nextInt(1, baseHeadway)
        return listOf(firstDep, firstDep + baseHeadway, firstDep + 2 * baseHeadway)
    }

    fun getCrowdingForLine(lineId: String): CrowdingLevel {
        val scenario = _currentScenario.value
        return when (scenario) {
            SimScenario.RUSH_HOUR -> {
                if (lineId == "U1" || lineId == "U3") CrowdingLevel.HIGH else CrowdingLevel.MEDIUM
            }
            SimScenario.MAJOR_EVENT -> {
                if (lineId == "U1" || lineId == "U2") CrowdingLevel.HIGH else CrowdingLevel.LOW
            }
            SimScenario.NIGHT_SERVICE -> CrowdingLevel.LOW
            else -> {
                val r = Random(lineId.hashCode()).nextDouble()
                if (r < 0.3) CrowdingLevel.LOW else if (r < 0.8) CrowdingLevel.MEDIUM else CrowdingLevel.HIGH
            }
        }
    }

    fun getFormattedTime(): String {
        val minutes = _simClock.value
        val hours = minutes / 60
        val mins = minutes % 60
        return String.format("%02d:%02d", hours, mins)
    }
}
