package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LinePagesScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    val selectedLineId by viewModel.selectedLineId.collectAsState()

    var activeLineId by remember { mutableStateOf(selectedLineId) }
    val line = TransitData.getLine(activeLineId) ?: TransitData.lines.first()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCream)
            .padding(horizontal = 16.dp)
            .testTag("line_pages_scroll"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // --- Header ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = WienCharcoal)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (isGerman) "U-BAHN LINIE" else "METRO LINE INFO",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = WienCharcoal
                    )
                    Text(
                        text = if (isGerman) "Stationsreihenfolge und Linienstatus" else "Sequential stations and service status",
                        style = MaterialTheme.typography.labelLarge,
                        color = WienGrey
                    )
                }
            }
        }

        // --- Line Selector Tab bar ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val linesList = listOf("U1", "U2", "U3", "U4", "U6")
                for (id in linesList) {
                    val active = activeLineId == id
                    val lineObj = TransitData.getLine(id)
                    Button(
                        onClick = { activeLineId = id },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (active) (lineObj?.color ?: WienRed) else Color.White,
                            contentColor = if (active) Color.White else WienCharcoal
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        Text(id, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                }
            }
        }

        // --- Line Status Poster ---
        item {
            val isDisrupted = TransitData.activeDisruptions.any { it.lineId == line.id }
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isDisrupted) WienRed else line.color
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LINIE ${line.name}",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )

                        Icon(Icons.Filled.NotificationsActive, contentDescription = "Status", tint = Color.White)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isDisrupted) {
                            if (isGerman) "⚠️ STÖRUNG AKTIV: SIGNALSTÖRUNG" else "⚠️ SIGNAL FAILURE DISRUPTION"
                        } else {
                            if (isGerman) "✅ REGULÄRER BETRIEB" else "✅ NORMAL OPERATIONS"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    if (isDisrupted) {
                        val d = TransitData.activeDisruptions.first { it.lineId == line.id }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isGerman) d.descriptionDe else d.descriptionEn,
                            fontSize = 11.sp,
                            color = Color.White,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        // --- Sequential Station Lists ---
        item {
            Text(
                text = if (isGerman) "STATIONENREIHENFOLGE" else "STATIONS SEQUENCE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = WienGrey,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        items(line.stations) { stationId ->
            val station = TransitData.getStation(stationId)
            if (station != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { viewModel.selectStation(station.id) }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Sequential index dot
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(line.color, RoundedCornerShape(6.dp))
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = station.name,
                                    fontWeight = FontWeight.Bold,
                                    color = WienCharcoal,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (station.hasLift) "♿ Barrierefrei" else "Stufen",
                                    fontSize = 11.sp,
                                    color = WienGrey
                                )
                            }
                        }

                        // Display line transfers available at this node
                        Row {
                            for (otherLine in station.lines) {
                                if (otherLine != line.id) {
                                    val bg = when (otherLine) {
                                        "U1" -> ColorU1
                                        "U2" -> ColorU2
                                        "U3" -> ColorU3
                                        "U4" -> ColorU4
                                        "U6" -> ColorU6
                                        else -> WienGrey
                                    }
                                    Box(
                                        modifier = Modifier
                                            .padding(horizontal = 2.dp)
                                            .background(bg, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = otherLine,
                                            color = Color.White,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
