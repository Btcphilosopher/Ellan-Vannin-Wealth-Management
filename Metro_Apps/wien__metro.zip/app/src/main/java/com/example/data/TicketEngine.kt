package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

// Ticket Models
data class TicketType(
    val id: String,
    val nameDe: String,
    val nameEn: String,
    val price: Double,
    val descriptionDe: String,
    val descriptionEn: String,
    val validityHours: Int
)

data class DigitalTicket(
    val id: String,
    val typeId: String,
    val typeNameDe: String,
    val typeNameEn: String,
    val passengerName: String,
    val pricePaid: Double,
    val purchaseTimestamp: String,
    val validFrom: String,
    val validTo: String,
    val qrCodePayload: String,
    val isExpired: Boolean = false
)

object TicketEngine {
    // Standard Vienna Fare structure
    val ticketTypes = listOf(
        TicketType("EINZEL", "Einzelfahrt Wien", "Single Ticket Vienna", 2.40, "Gilt für eine Fahrt in eine Richtung, Umsteigen erlaubt.", "Valid for one single trip in one direction, transfers allowed.", 2),
        TicketType("24H", "24 Stunden Wien", "24 Hours Vienna", 8.00, "24 Stunden Netzkarten-Gültigkeit in Wien ab Entwertung.", "24 hours of unlimited travel within Vienna from validation.", 24),
        TicketType("48H", "48 Stunden Wien", "48 Hours Vienna", 14.10, "48 Stunden Netzkarten-Gültigkeit in Wien ab Entwertung.", "48 hours of unlimited travel within Vienna from validation.", 48),
        TicketType("72H", "72 Stunden Wien", "72 Hours Vienna", 17.10, "72 Stunden Netzkarten-Gültigkeit in Wien ab Entwertung.", "72 hours of unlimited travel within Vienna from validation.", 72),
        TicketType("31T", "31 Tage Wien Mobil", "31 Days Vienna Mobil", 51.00, "Persönliche Monatskarte, gültig für 31 aufeinanderfolgende Tage.", "Personal monthly ticket, valid for 31 consecutive days.", 744),
        TicketType("JAHRESKARTE", "Jahreskarte Wiener Linien", "Annual Pass Vienna", 365.00, "Österreichs unschlagbare Klassiker-Fahrkarte für Wien.", "Vienna's unbeatable classic transit pass for a whole year.", 8760),
        TicketType("KLIMA", "KlimaTicket Ö (U-Bahn)", "Climate Ticket Austria", 1095.00, "Freie Fahrt in allen Öffis in ganz Österreich.", "Unlimited travel on all public transport across Austria.", 8760),
        TicketType("CAT_SUPP", "CAT Ticket (Flughafen)", "CAT Airport Express", 14.90, "Einzelfahrt mit dem City Airport Train Express-Zug.", "Single trip on the express City Airport Train.", 2)
    )

    private val _myTickets = MutableStateFlow<List<DigitalTicket>>(emptyList())
    val myTickets = _myTickets.asStateFlow()

    init {
        // Seed an initial ticket for "TOM" so the wallet isn't empty on first run
        seedInitialTicket()
    }

    private fun seedInitialTicket() {
        val format = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMAN)
        val now = Date()
        val in24Hours = Date(now.time + 24 * 3600 * 1000)

        val ticket = DigitalTicket(
            id = "WM-${Random.nextInt(100000, 999999)}",
            typeId = "24H",
            typeNameDe = "24 STUNDEN WIEN",
            typeNameEn = "24 HOURS VIENNA",
            passengerName = "TOM",
            pricePaid = 8.00,
            purchaseTimestamp = format.format(now),
            validFrom = format.format(now),
            validTo = format.format(in24Hours),
            qrCodePayload = "WIENMETRO-24H-TOM-VALID-${Random.nextInt(1000, 9999)}"
        )
        _myTickets.value = listOf(ticket)
    }

    fun purchaseTicket(typeId: String, passengerName: String): DigitalTicket? {
        val type = ticketTypes.find { it.id == typeId } ?: return null
        val format = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMAN)
        val now = Date()
        val validUntil = Date(now.time + type.validityHours * 3600 * 1000L)

        val newTicket = DigitalTicket(
            id = "WM-${Random.nextInt(100000, 999999)}",
            typeId = type.id,
            typeNameDe = type.nameDe,
            typeNameEn = type.nameEn,
            passengerName = passengerName.ifBlank { "TOM" },
            pricePaid = type.price,
            purchaseTimestamp = format.format(now),
            validFrom = format.format(now),
            validTo = format.format(validUntil),
            qrCodePayload = "WIENMETRO-${type.id}-${passengerName.ifBlank { "TOM" }}-ACTIVE-${Random.nextInt(100000, 999999)}"
        )

        _myTickets.value = _myTickets.value + newTicket
        return newTicket
    }

    fun getTicket(id: String): DigitalTicket? {
        return _myTickets.value.find { it.id == id }
    }
}
