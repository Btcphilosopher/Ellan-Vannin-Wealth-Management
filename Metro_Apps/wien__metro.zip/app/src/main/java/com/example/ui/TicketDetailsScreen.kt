package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TicketEngine
import com.example.ui.theme.*
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketDetailsScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    val ticketId by viewModel.viewingTicketId.collectAsState()
    val tickets by TicketEngine.myTickets.collectAsState()

    val ticket = tickets.find { it.id == ticketId } ?: tickets.firstOrNull()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCream)
            .padding(16.dp)
            .testTag("ticket_details_screen")
    ) {
        // --- Header with back button ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = WienCharcoal)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = if (isGerman) "DIGITALES TICKET" else "DIGITAL PASS",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = WienCharcoal
                )
                Text(
                    text = if (isGerman) "Zur Ticketkontrolle vorzeigen" else "Present for ticket inspection",
                    style = MaterialTheme.typography.labelLarge,
                    color = WienGrey
                )
            }
        }

        if (ticket == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = if (isGerman) "Kein gültiges Ticket geladen." else "No valid ticket loaded.",
                    fontWeight = FontWeight.Bold
                )
            }
        } else {
            // --- Detailed Pass Card ---
            Card(
                colors = CardDefaults.cardColors(containerColor = WienCharcoal),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .testTag("digital_ticket_pass_card")
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Title Zone
                    Text(
                        text = "WIEN//LINIEN",
                        color = WienRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isGerman) ticket.typeNameDe.uppercase() else ticket.typeNameEn.uppercase(),
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // QR Code Visual
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Drawing a beautiful high-fidelity matrix QR-code pattern on canvas
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val dotSize = size.width / 15f
                            val seed = ticket.qrCodePayload.hashCode()
                            val rng = Random(seed)

                            for (r in 0 until 15) {
                                for (c in 0 until 15) {
                                    // Make corners square visual targets to look exactly like a real QR code
                                    val isCornerFinder = (r < 4 && c < 4) || (r < 4 && c > 10) || (r > 10 && c < 4)
                                    val isCenterSolid = (r in 1..2 && c in 1..2) || (r in 1..2 && c in 11..12) || (r in 11..12 && c in 1..2)
                                    
                                    val drawDot = if (isCornerFinder) {
                                        isCenterSolid || r == 0 || r == 3 || c == 0 || c == 3 || (c == 14 || c == 11) || (r == 14 || r == 11)
                                    } else {
                                        rng.nextBoolean()
                                    }

                                    if (drawDot) {
                                        drawRect(
                                            color = WienCharcoal,
                                            topLeft = androidx.compose.ui.geometry.Offset(c * dotSize, r * dotSize),
                                            size = androidx.compose.ui.geometry.Size(dotSize - 1f, dotSize - 1f)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Passenger Details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (isGerman) "PASSAGIER" else "PASSENGER",
                                fontSize = 10.sp,
                                color = WienGrey,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = ticket.passengerName.uppercase(),
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "TICKET-ID",
                                fontSize = 10.sp,
                                color = WienGrey,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = ticket.id,
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Validity Period
                    Divider(color = WienDarkGrey)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (isGerman) "GÜLTIG AB" else "VALID FROM",
                                fontSize = 10.sp,
                                color = WienGrey,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = ticket.validFrom,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = if (isGerman) "GÜLTIG BIS" else "VALID UNTIL",
                                fontSize = 10.sp,
                                color = WienGrey,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = ticket.validTo,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier
                            .background(Color.Black, RoundedCornerShape(8.dp))
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = "Valid", tint = ColorU4, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isGerman) "TICKET IST GÜLTIG" else "TICKET IS VALID",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // --- Receipts & Fares breakdown info ---
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Info, contentDescription = "Receipt", tint = WienRed)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isGerman) "BELEG & TRANSFEKTION" else "RECEIPT & FARES INFORMATION",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = WienGrey
                        )
                        Text(
                            text = "${if (isGerman) "Gekauft am" else "Purchased on"}: ${ticket.purchaseTimestamp}",
                            fontSize = 11.sp,
                            color = WienCharcoal
                        )
                        Text(
                            text = "Preis: ${String.format("%.2f €", ticket.pricePaid)} (Sichere syntetische Zahlung)",
                            fontSize = 11.sp,
                            color = WienCharcoal
                        )
                    }
                }
            }
        }
    }
}
