package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RealtimeSimulator
import com.example.data.SimScenario
import com.example.data.TransitData
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    val searchTo by viewModel.searchTo.collectAsState()
    val scenario by RealtimeSimulator.currentScenario.collectAsState()
    val clockMinutes by RealtimeSimulator.simClock.collectAsState()

    var showScenarioMenu by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCream)
            .padding(horizontal = 16.dp)
            .testTag("home_screen_scroll"),
        contentPadding = PaddingValues(bottom = 80.dp) // Avoid overlap with bottom nav
    ) {
        // --- App Branding Bar ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "WIEN//METRO",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Black,
                        color = WienRed,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (isGerman) "WIEN BEWEGT." else "VIENNA MOVES.",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium,
                        color = WienCharcoal
                    )
                }

                // DE | EN Language toggle & Scenario Picker
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "DE",
                        color = if (isGerman) WienRed else WienGrey,
                        fontWeight = if (isGerman) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier
                            .clickable { viewModel.setLanguage(true) }
                            .padding(8.dp)
                    )
                    Text(
                        text = "|",
                        color = WienGrey,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    Text(
                        text = "EN",
                        color = if (!isGerman) WienRed else WienGrey,
                        fontWeight = if (!isGerman) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier
                            .clickable { viewModel.setLanguage(false) }
                            .padding(8.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(onClick = { showScenarioMenu = true }) {
                        Icon(
                            Icons.Filled.Settings,
                            contentDescription = "Sim Scenarios",
                            tint = WienCharcoal
                        )
                    }
                }
            }
        }

        // --- Simulated Time & Scenario Header ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = WienCharcoal),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isGerman) "SYNTETISCHER METRO SIMULATOR" else "SYNTHETIC METRO SIMULATOR",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = WienAmber
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = when (scenario) {
                                SimScenario.NORMAL_DAY -> if (isGerman) "Normalbetrieb (Werktag)" else "Normal Operations"
                                SimScenario.RUSH_HOUR -> if (isGerman) "Hauptverkehrszeit" else "Rush Hour Peak"
                                SimScenario.DISRUPTION -> if (isGerman) "⚠️ U4 Signalstörung" else "⚠️ U4 Signal Interruption"
                                SimScenario.MAJOR_EVENT -> if (isGerman) "Großveranstaltung (Stadion)" else "Major Arena Event"
                                SimScenario.NIGHT_SERVICE -> if (isGerman) "NightLine Nachtnetz" else "NightLine Service"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(Color.Black, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = RealtimeSimulator.getFormattedTime(),
                            color = WienAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        // --- Destination Search Bar ---
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (isGerman) "Guten Morgen. Wohin soll es gehen?" else "Good morning. Where are you going?",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = WienCharcoal,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                OutlinedTextField(
                    value = searchTo,
                    onValueChange = { viewModel.updateSearchTo(it) },
                    placeholder = {
                        Text(if (isGerman) "Wo möchtest du hin?" else "Where do you want to go?")
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Filled.Search,
                            contentDescription = "Search",
                            tint = WienGrey
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_destination_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = WienRed,
                        unfocusedBorderColor = WienGrey,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    singleLine = true,
                    trailingIcon = {
                        if (searchTo.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchTo("") }) {
                                Icon(Icons.Filled.Clear, contentDescription = "Clear")
                            }
                        }
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (searchTo.isNotBlank()) {
                            viewModel.executeRoutePlan()
                        } else {
                            viewModel.navigateTo(AppScreen.ROUTE_SEARCH)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WienRed),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("home_search_submit_button")
                ) {
                    Text(
                        text = if (isGerman) "ROUTE SUCHEN" else "SEARCH ROUTE",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        // --- Primary Action Grid ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val actions = listOf(
                    Triple(Icons.Filled.DirectionsTransit, if (isGerman) "Route" else "Route", AppScreen.ROUTE_SEARCH),
                    Triple(Icons.Filled.Schedule, if (isGerman) "Abfahrten" else "Departures", AppScreen.DEPARTURES),
                    Triple(Icons.Filled.ConfirmationNumber, if (isGerman) "Tickets" else "Tickets", AppScreen.TICKETS),
                    Triple(Icons.Filled.Map, if (isGerman) "Karte" else "Map", AppScreen.NETWORK_MAP)
                )

                for ((icon, label, screen) in actions) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .padding(4.dp)
                            .clickable { viewModel.navigateTo(screen) }
                            .testTag("quick_action_${label.lowercase()}")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(icon, contentDescription = label, tint = WienRed, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = label.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = WienCharcoal
                            )
                        }
                    }
                }
            }
        }

        // --- Nearby Station Live departures ---
        item {
            Text(
                text = if (isGerman) "NÄCHSTE ABFAHRTEN (ST. STEPHANSPLATZ)" else "NEXT DEPARTURES (ST. STEPHANSPLATZ)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = WienCharcoal,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        val sampleDepartures = listOf(
            Triple("U1", "Leopoldau", ColorU1),
            Triple("U3", "Simmering", ColorU3),
            Triple("U1", "Oberlaa", ColorU1),
            Triple("U3", "Ottakring", ColorU3)
        )

        items(sampleDepartures) { (line, dest, color) ->
            val deptime = RealtimeSimulator.getDeparturesForStation("ST_STEPHANSPLATZ", line).first()
            
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(color, RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = line,
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = dest,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = WienCharcoal
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "$deptime",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = WienRed
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "min",
                            fontSize = 12.sp,
                            color = WienGrey
                        )
                    }
                }
            }
        }

        // --- Quick Wien.AI Banner ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = WienRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
                    .clickable { viewModel.navigateTo(AppScreen.WIEN_AI) }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.AutoAwesome,
                        contentDescription = "AI Assistant",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "WIEN.AI REISEBEGLEITER",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = WienCream
                        )
                        Text(
                            text = if (isGerman) "Fragen Sie den Metro-Assistenten..." else "Ask the digital transit assistant...",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }

    // Scenario Picker Dialog
    if (showScenarioMenu) {
        AlertDialog(
            onDismissRequest = { showScenarioMenu = false },
            title = { Text(if (isGerman) "Simulator-Szenario wählen" else "Choose Simulation Scenario") },
            text = {
                Column {
                    val scenarios = listOf(
                        Pair(SimScenario.NORMAL_DAY, if (isGerman) "Normalbetrieb" else "Normal Operations"),
                        Pair(SimScenario.RUSH_HOUR, if (isGerman) "Hauptverkehrszeit" else "Rush Hour Peak"),
                        Pair(SimScenario.DISRUPTION, if (isGerman) "U4 Stellwerkstörung am Karlsplatz" else "U4 Signal Interruption"),
                        Pair(SimScenario.MAJOR_EVENT, if (isGerman) "Großveranstaltung (Stadion)" else "Major Event Flow"),
                        Pair(SimScenario.NIGHT_SERVICE, if (isGerman) "NightLine Nachtverkehr" else "NightLine Network")
                    )

                    for ((scen, name) in scenarios) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.changeScenario(scen)
                                    showScenarioMenu = false
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = scenario == scen, onClick = {
                                viewModel.changeScenario(scen)
                                showScenarioMenu = false
                            })
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = name, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showScenarioMenu = false }) {
                    Text(if (isGerman) "Schließen" else "Close")
                }
            }
        )
    }
}
