package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Station
import com.example.data.TransitData
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkMapScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var selectedStationInMap by remember { mutableStateOf<Station?>(null) }

    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.6f, 3f)
        offset += offsetChange
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCream)
    ) {
        // --- Header ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 24.dp)
        ) {
            Text(
                text = "WIEN//NETZ",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = WienCharcoal
            )
            Text(
                text = if (isGerman) "INTERAKTIVER NETZPLAN" else "INTERACTIVE NETWORK MAP",
                style = MaterialTheme.typography.labelLarge,
                color = WienGrey
            )
        }

        // --- Interactive Map Canvas ---
        Box(
            modifier = Modifier
                .fillMaxSize()
                .transformable(state = state)
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                ),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .width(400.dp)
                    .height(400.dp)
            ) {
                // Draw transit line paths (U1, U2, U3, U4, U6) with their official colors
                // U1: Red
                drawLine(
                    color = ColorU1,
                    start = Offset(200f, 40f),
                    end = Offset(200f, 360f),
                    strokeWidth = 14f
                )
                // U2: Purple/Violet
                drawLine(
                    color = ColorU2,
                    start = Offset(100f, 300f),
                    end = Offset(300f, 300f),
                    strokeWidth = 14f
                )
                // U3: Orange
                drawLine(
                    color = ColorU3,
                    start = Offset(40f, 180f),
                    end = Offset(360f, 180f),
                    strokeWidth = 14f
                )
                // U4: Green
                drawLine(
                    color = ColorU4,
                    start = Offset(80f, 300f),
                    end = Offset(320f, 60f),
                    strokeWidth = 14f
                )
                // U6: Brown
                drawLine(
                    color = ColorU6,
                    start = Offset(110f, 50f),
                    end = Offset(110f, 350f),
                    strokeWidth = 14f
                )

                // Draw central interchange nodes
                // Stephansplatz (U1 x U3) at (200, 180)
                drawCircle(color = Color.White, radius = 22f, center = Offset(200f, 180f))
                drawCircle(color = WienCharcoal, radius = 16f, center = Offset(200f, 180f))

                // Karlsplatz (U1 x U2 x U4) at (200, 240)
                drawCircle(color = Color.White, radius = 24f, center = Offset(200f, 240f))
                drawCircle(color = WienCharcoal, radius = 18f, center = Offset(200f, 240f))

                // Westbahnhof (U3 x U6) at (110, 180)
                drawCircle(color = Color.White, radius = 22f, center = Offset(110f, 180f))
                drawCircle(color = WienCharcoal, radius = 16f, center = Offset(110f, 180f))

                // Landstraße (U3 x U4) at (260, 180)
                drawCircle(color = Color.White, radius = 22f, center = Offset(260f, 180f))
                drawCircle(color = WienCharcoal, radius = 16f, center = Offset(260f, 180f))

                // Schwedenplatz (U1 x U4) at (200, 120)
                drawCircle(color = Color.White, radius = 22f, center = Offset(200f, 120f))
                drawCircle(color = WienCharcoal, radius = 16f, center = Offset(200f, 120f))

                // Spittelau (U4 x U6) at (110, 90)
                drawCircle(color = Color.White, radius = 22f, center = Offset(110f, 90f))
                drawCircle(color = WienCharcoal, radius = 16f, center = Offset(110f, 90f))

                // Volkstheater (U2 x U3) at (160, 180)
                drawCircle(color = Color.White, radius = 22f, center = Offset(160f, 180f))
                drawCircle(color = WienCharcoal, radius = 16f, center = Offset(160f, 180f))
            }

            // Clickable pins overlay (mapped to approximate offsets on the 400x400 map)
            val mappedStations = listOf(
                Pair("ST_STEPHANSPLATZ", Offset(200f, 180f)),
                Pair("ST_KARLSPLATZ", Offset(200f, 240f)),
                Pair("ST_WESTBAHNHOF", Offset(110f, 180f)),
                Pair("ST_LANDSTRASSE", Offset(260f, 180f)),
                Pair("ST_SCHWEDENPLATZ", Offset(200f, 120f)),
                Pair("ST_SPITTELAU", Offset(110f, 90f)),
                Pair("ST_VOLKSTHEATER", Offset(160f, 180f)),
                Pair("ST_SCHOENBRUNN", Offset(140f, 240f)),
                Pair("ST_SEESTADT", Offset(300f, 300f)),
                Pair("ST_LEOPOLDAU", Offset(200f, 40f)),
                Pair("ST_OBERLAA", Offset(200f, 360f))
            )

            for ((stationId, offsetPos) in mappedStations) {
                val station = TransitData.getStation(stationId)
                if (station != null) {
                    Box(
                        modifier = Modifier
                            .offset(
                                x = (offsetPos.x - 200f).dp,
                                y = (offsetPos.y - 200f).dp
                            )
                            .size(36.dp)
                            .background(Color.Transparent)
                            .clickable {
                                selectedStationInMap = station
                            }
                    )
                }
            }
        }

        // --- Map Controls ---
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp)
        ) {
            FloatingActionButton(
                onClick = { scale = (scale + 0.2f).coerceAtMost(3f) },
                containerColor = Color.White,
                contentColor = WienCharcoal,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Zoom In")
            }
            Spacer(modifier = Modifier.height(8.dp))
            FloatingActionButton(
                onClick = { scale = (scale - 0.2f).coerceAtLeast(0.6f) },
                containerColor = Color.White,
                contentColor = WienCharcoal,
                modifier = Modifier.size(44.dp)
            ) {
                Icon(Icons.Filled.Remove, contentDescription = "Zoom Out")
            }
        }

        // --- Selected Station Card Overlay ---
        AnimatedVisibility(
            visible = selectedStationInMap != null,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        ) {
            selectedStationInMap?.let { station ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = WienCharcoal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 60.dp) // Lift above bottom menu
                        .testTag("station_map_overlay_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = station.name.uppercase(),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Row {
                                for (line in station.lines) {
                                    val bg = when (line) {
                                        "U1" -> ColorU1
                                        "U2" -> ColorU2
                                        "U3" -> ColorU3
                                        "U4" -> ColorU4
                                        "U6" -> ColorU6
                                        else -> WienGrey
                                    }
                                    Box(
                                        modifier = Modifier
                                            .padding(horizontal = 2.dp)
                                            .background(bg, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = line,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Button(
                                onClick = {
                                    viewModel.updateSearchFrom(station.name)
                                    selectedStationInMap = null
                                    viewModel.navigateTo(AppScreen.ROUTE_SEARCH)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = WienGrey),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(if (isGerman) "Als Start" else "Set Origin", fontSize = 12.sp)
                            }
                            Button(
                                onClick = {
                                    viewModel.updateSearchTo(station.name)
                                    selectedStationInMap = null
                                    viewModel.navigateTo(AppScreen.ROUTE_SEARCH)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = WienRed),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(if (isGerman) "Als Ziel" else "Set Destination", fontSize = 12.sp)
                            }
                            Button(
                                onClick = {
                                    viewModel.selectStation(station.id)
                                    selectedStationInMap = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (isGerman) "Info" else "Details",
                                    color = WienCharcoal,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
