package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

// --- Data Models ---

data class Station(
    val id: String,
    val name: String,
    val lines: List<String>,
    val hasLift: Boolean = true,
    val hasEscalator: Boolean = true,
    val hasWc: Boolean = false,
    val hasServiceCenter: Boolean = false,
    val hasBikeSharing: Boolean = false,
    val hasCarSharing: Boolean = false,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val bestExitInfoDe: String = "Ausgang Hauptgebäude",
    val bestExitInfoEn: String = "Exit Main Building"
)

data class Line(
    val id: String,
    val name: String,
    val type: TransitType,
    val stations: List<String>,
    val color: Color,
    val isNightActive: Boolean = false
)

enum class TransitType {
    UBAHN, TRAM, BUS, SBAHN, REGIONAL, NIGHTLINE, AIRPORT_CAT, WALK, BIKE, CAR
}

data class Disruption(
    val id: String,
    val lineId: String,
    val titleDe: String,
    val titleEn: String,
    val descriptionDe: String,
    val descriptionEn: String,
    val affectedStations: List<String>,
    val alternativeAdviceDe: String,
    val alternativeAdviceEn: String,
    val expectedDurationDe: String = "Unbekannt",
    val expectedDurationEn: String = "Unknown"
)

data class Vehicle(
    val id: String,
    val lineId: String,
    val directionDe: String,
    val directionEn: String,
    val currentStationId: String,
    val nextStationId: String?,
    val delayMinutes: Int,
    val occupancy: CrowdingLevel,
    val positionRatio: Float // 0.0 to 1.0 between current and next
)

enum class CrowdingLevel {
    LOW, MEDIUM, HIGH
}

// --- Data Seeding ---

object TransitData {
    val stations = listOf(
        // U1 Stations
        Station("ST_STEPHANSPLATZ", "Stephansplatz", listOf("U1", "U3"), hasLift = true, hasEscalator = true, hasWc = true, hasServiceCenter = true, hasBikeSharing = true, latitude = 48.2086, longitude = 16.3731, bestExitInfoDe = "Ausgang Stephansplatz / Graben", bestExitInfoEn = "Exit Stephansplatz / Graben"),
        Station("ST_KARLSPLATZ", "Karlsplatz", listOf("U1", "U2", "U4", "Tram 1", "Tram D"), hasLift = true, hasEscalator = true, hasWc = true, hasServiceCenter = true, hasBikeSharing = true, hasCarSharing = true, latitude = 48.2003, longitude = 16.3699, bestExitInfoDe = "Ausgang Oper / Resselpark", bestExitInfoEn = "Exit Opera / Resselpark"),
        Station("ST_SCHWEDENPLATZ", "Schwedenplatz", listOf("U1", "U4", "Tram 1", "Tram 2"), hasLift = true, hasEscalator = true, hasWc = false, hasBikeSharing = true, latitude = 48.2115, longitude = 16.3772, bestExitInfoDe = "Ausgang Rotenturmstraße", bestExitInfoEn = "Exit Rotenturmstrasse"),
        Station("ST_PRATERSTERN", "Praterstern", listOf("U1", "U2", "S-Bahn", "Tram 5", "Tram O"), hasLift = true, hasEscalator = true, hasWc = true, hasBikeSharing = true, latitude = 48.2185, longitude = 16.3917, bestExitInfoDe = "Ausgang Lassallestraße / Prater", bestExitInfoEn = "Exit Lassallestrasse / Prater"),
        Station("ST_LEOPOLDAU", "Leopoldau", listOf("U1", "S-Bahn"), hasLift = true, hasEscalator = true, hasWc = false, latitude = 48.2775, longitude = 16.4514, bestExitInfoDe = "Ausgang Thayagasse", bestExitInfoEn = "Exit Thayagasse"),
        Station("ST_REUMANNPLATZ", "Reumannplatz", listOf("U1", "Tram 6", "Bus 14A"), hasLift = true, hasEscalator = true, hasWc = true, hasBikeSharing = true, latitude = 48.1743, longitude = 16.3792, bestExitInfoDe = "Ausgang Favoritenstraße", bestExitInfoEn = "Exit Favoritenstrasse"),
        Station("ST_HAUPTBAHNHOF", "Südtiroler Pl.-Hauptbahnhof", listOf("U1", "S-Bahn", "Tram D", "Tram 18", "Bus 13A"), hasLift = true, hasEscalator = true, hasWc = true, hasServiceCenter = true, hasBikeSharing = true, hasCarSharing = true, latitude = 48.1851, longitude = 16.3762, bestExitInfoDe = "Ausgang Hauptbahnhof-Haupthalle", bestExitInfoEn = "Exit Central Station Concourse"),
        Station("ST_NESTROYPLATZ", "Nestroyplatz", listOf("U1"), hasLift = true, hasEscalator = true, hasWc = false, latitude = 48.2155, longitude = 16.3855, bestExitInfoDe = "Ausgang Tempelgasse", bestExitInfoEn = "Exit Tempelgasse"),
        Station("ST_KAISERMUEHLEN", "Kaisermühlen-VIC", listOf("U1"), hasLift = true, hasEscalator = true, hasWc = false, hasBikeSharing = true, latitude = 48.2330, longitude = 16.4161, bestExitInfoDe = "Ausgang Vienna International Centre", bestExitInfoEn = "Exit Vienna International Centre"),
        Station("ST_OBERLAA", "Oberlaa", listOf("U1"), hasLift = true, hasEscalator = true, hasWc = false, latitude = 48.1423, longitude = 16.4034, bestExitInfoDe = "Ausgang Therme Wien", bestExitInfoEn = "Exit Therme Wien"),

        // U2 Stations
        Station("ST_SCHOTTENTOR", "Schottentor", listOf("U2", "Tram 1", "Tram 5", "Tram D"), hasLift = true, hasEscalator = true, hasWc = true, hasBikeSharing = true, latitude = 48.2150, longitude = 16.3617, bestExitInfoDe = "Ausgang Universität / Ring", bestExitInfoEn = "Exit University / Ring"),
        Station("ST_VOLKSTHEATER", "Volkstheater", listOf("U2", "U3", "Tram 2"), hasLift = true, hasEscalator = true, hasWc = false, latitude = 48.2052, longitude = 16.3582, bestExitInfoDe = "Ausgang Museumsquartier", bestExitInfoEn = "Exit Museumsquartier"),
        Station("ST_SEESTADT", "Seestadt", listOf("U2"), hasLift = true, hasEscalator = true, hasWc = false, hasBikeSharing = true, latitude = 48.2265, longitude = 16.5076, bestExitInfoDe = "Ausgang Seebrücke", bestExitInfoEn = "Exit Lake Bridge"),

        // U3 Stations
        Station("ST_OTTAKRING", "Ottakring", listOf("U3", "S-Bahn", "Tram 2"), hasLift = true, hasEscalator = true, hasWc = true, hasBikeSharing = true, latitude = 48.2114, longitude = 16.3115, bestExitInfoDe = "Ausgang Thaliastraße", bestExitInfoEn = "Exit Thaliastrasse"),
        Station("ST_WESTBAHNHOF", "Westbahnhof", listOf("U3", "U6", "Tram 5", "Tram 6", "Tram 18"), hasLift = true, hasEscalator = true, hasWc = true, hasServiceCenter = true, hasBikeSharing = true, latitude = 48.1968, longitude = 16.3377, bestExitInfoDe = "Ausgang Äußere Mariahilfer Str.", bestExitInfoEn = "Exit Outer Mariahilfer Str."),
        Station("ST_NEUBAUGASSE", "Neubaugasse", listOf("U3", "Bus 13A", "Bus 14A"), hasLift = true, hasEscalator = true, hasWc = false, latitude = 48.1996, longitude = 16.3491, bestExitInfoDe = "Ausgang Mariahilfer Straße", bestExitInfoEn = "Exit Mariahilfer Strasse"),
        Station("ST_LANDSTRASSE", "Landstraße (Wien Mitte)", listOf("U3", "U4", "S-Bahn", "Tram O", "CAT"), hasLift = true, hasEscalator = true, hasWc = true, hasServiceCenter = true, hasBikeSharing = true, latitude = 48.2064, longitude = 16.3853, bestExitInfoDe = "Ausgang Invalidenstraße / Mall", bestExitInfoEn = "Exit Invalidenstrasse / Mall"),
        Station("ST_SIMMERING", "Simmering", listOf("U3", "S-Bahn", "Tram 6"), hasLift = true, hasEscalator = true, hasWc = false, latitude = 48.1706, longitude = 16.4194, bestExitInfoDe = "Ausgang Simmeringer Hauptstraße", bestExitInfoEn = "Exit Simmeringer Hauptstrasse"),

        // U4 Stations
        Station("ST_HUETTELDORF", "Hütteldorf", listOf("U4", "S-Bahn"), hasLift = true, hasEscalator = true, hasWc = true, latitude = 48.2014, longitude = 16.2514, bestExitInfoDe = "Ausgang Keißlergasse", bestExitInfoEn = "Exit Keisslergasse"),
        Station("ST_SCHOENBRUNN", "Schönbrunn", listOf("U4", "Tram 10", "Bus 10A"), hasLift = true, hasEscalator = false, hasWc = true, latitude = 48.1861, longitude = 16.3192, bestExitInfoDe = "Ausgang Schloß Schönbrunn", bestExitInfoEn = "Exit Schoenbrunn Palace"),
        Station("ST_LAENGENFELDGASSE", "Längenfeldgasse", listOf("U4", "U6"), hasLift = true, hasEscalator = true, hasWc = false, latitude = 48.1848, longitude = 16.3344, bestExitInfoDe = "Ausgang Storchengasse", bestExitInfoEn = "Exit Storchengasse"),
        Station("ST_HEILIGENSTADT", "Heiligenstadt", listOf("U4", "S-Bahn", "Bus 10A"), hasLift = true, hasEscalator = true, hasWc = true, latitude = 48.2492, longitude = 16.3639, bestExitInfoDe = "Ausgang Karl-Marx-Hof", bestExitInfoEn = "Exit Karl-Marx-Hof"),
        Station("ST_SPITTELAU", "Spittelau", listOf("U4", "U6", "S-Bahn", "Tram D"), hasLift = true, hasEscalator = true, hasWc = false, latitude = 48.2355, longitude = 16.3585, bestExitInfoDe = "Ausgang Guneschgasse", bestExitInfoEn = "Exit Guneschgasse"),

        // U6 Stations
        Station("ST_FLORIDSDORF", "Floridsdorf", listOf("U6", "S-Bahn", "Tram 25", "Tram 26"), hasLift = true, hasEscalator = true, hasWc = true, hasBikeSharing = true, latitude = 48.2597, longitude = 16.4005, bestExitInfoDe = "Ausgang Franz-Jonas-Platz", bestExitInfoEn = "Exit Franz-Jonas-Platz"),
        Station("ST_SIEBENHIRTEN", "Siebenhirten", listOf("U6"), hasLift = true, hasEscalator = false, hasWc = false, latitude = 48.1287, longitude = 16.3132, bestExitInfoDe = "Ausgang Ketzergasse", bestExitInfoEn = "Exit Ketzergasse"),
        Station("ST_MEIDLING", "Bahnhof Meidling", listOf("U6", "S-Bahn", "Tram 62", "Badner Bahn"), hasLift = true, hasEscalator = true, hasWc = true, hasBikeSharing = true, latitude = 48.1744, longitude = 16.3331, bestExitInfoDe = "Ausgang Wilhelmstraße", bestExitInfoEn = "Exit Wilhelmstrasse"),

        // S-Bahn / Airport Station
        Station("ST_CAT_AIRPORT", "Flughafen Wien (Airport)", listOf("S-Bahn", "CAT", "Bus VAL"), hasLift = true, hasEscalator = true, hasWc = true, hasCarSharing = true, latitude = 48.1206, longitude = 16.5631, bestExitInfoDe = "Ausgang Terminals 1, 2, 3", bestExitInfoEn = "Exit Terminals 1, 2, 3")
    )

    val lines = listOf(
        Line("U1", "U1", TransitType.UBAHN, listOf("ST_OBERLAA", "ST_REUMANNPLATZ", "ST_HAUPTBAHNHOF", "ST_KARLSPLATZ", "ST_STEPHANSPLATZ", "ST_SCHWEDENPLATZ", "ST_NESTROYPLATZ", "ST_PRATERSTERN", "ST_KAISERMUEHLEN", "ST_LEOPOLDAU"), ColorU1, isNightActive = true),
        Line("U2", "U2", TransitType.UBAHN, listOf("ST_KARLSPLATZ", "ST_VOLKSTHEATER", "ST_SCHOTTENTOR", "ST_PRATERSTERN", "ST_SEESTADT"), ColorU2, isNightActive = true),
        Line("U3", "U3", TransitType.UBAHN, listOf("ST_OTTAKRING", "ST_WESTBAHNHOF", "ST_NEUBAUGASSE", "ST_VOLKSTHEATER", "ST_STEPHANSPLATZ", "ST_LANDSTRASSE", "ST_SIMMERING"), ColorU3, isNightActive = true),
        Line("U4", "U4", TransitType.UBAHN, listOf("ST_HUETTELDORF", "ST_SCHOENBRUNN", "ST_LAENGENFELDGASSE", "ST_KARLSPLATZ", "ST_LANDSTRASSE", "ST_SCHWEDENPLATZ", "ST_SPITTELAU", "ST_HEILIGENSTADT"), ColorU4, isNightActive = false),
        Line("U6", "U6", TransitType.UBAHN, listOf("ST_SIEBENHIRTEN", "ST_MEIDLING", "ST_LAENGENFELDGASSE", "ST_WESTBAHNHOF", "ST_SPITTELAU", "ST_FLORIDSDORF"), ColorU6, isNightActive = true),
        
        Line("TRAM1", "1", TransitType.TRAM, listOf("ST_KARLSPLATZ", "ST_SCHWEDENPLATZ", "ST_SCHOTTENTOR"), ColorTram),
        Line("TRAM2", "2", TransitType.TRAM, listOf("ST_VOLKSTHEATER", "ST_SCHWEDENPLATZ", "ST_OTTAKRING"), ColorTram),
        Line("TRAMD", "D", TransitType.TRAM, listOf("ST_HAUPTBAHNHOF", "ST_KARLSPLATZ", "ST_SCHOTTENTOR", "ST_SPITTELAU"), ColorTram),
        
        Line("BUS13A", "13A", TransitType.BUS, listOf("ST_HAUPTBAHNHOF", "ST_NEUBAUGASSE"), ColorBus),
        Line("BUS14A", "14A", TransitType.BUS, listOf("ST_REUMANNPLATZ", "ST_NEUBAUGASSE"), ColorBus),
        Line("BUS10A", "10A", TransitType.BUS, listOf("ST_HEILIGENSTADT", "ST_SCHOENBRUNN"), ColorBus),
        
        Line("S7", "S7", TransitType.SBAHN, listOf("ST_LANDSTRASSE", "ST_PRATERSTERN", "ST_CAT_AIRPORT"), ColorSbahn),
        Line("CAT", "CAT (City Airport Train)", TransitType.AIRPORT_CAT, listOf("ST_LANDSTRASSE", "ST_CAT_AIRPORT"), ColorU3),
        Line("N25", "N25", TransitType.NIGHTLINE, listOf("ST_STEPHANSPLATZ", "ST_SCHWEDENPLATZ", "ST_PRATERSTERN", "ST_KAISERMUEHLEN"), ColorU2, isNightActive = true)
    )

    val touristPoisDe = mapOf(
        "Stephansdom" to "ST_STEPHANSPLATZ",
        "Schloss Schönbrunn" to "ST_SCHOENBRUNN",
        "Belvedere" to "ST_HAUPTBAHNHOF",
        "Prater & Riesenrad" to "ST_PRATERSTERN",
        "MuseumsQuartier" to "ST_VOLKSTHEATER",
        "Rathaus & Parlament" to "ST_SCHOTTENTOR",
        "Therme Wien" to "ST_OBERLAA"
    )

    val touristPoisEn = mapOf(
        "St. Stephen's Cathedral" to "ST_STEPHANSPLATZ",
        "Schoenbrunn Palace" to "ST_SCHOENBRUNN",
        "Belvedere Palace" to "ST_HAUPTBAHNHOF",
        "Prater Amusement Park" to "ST_PRATERSTERN",
        "MuseumsQuartier" to "ST_VOLKSTHEATER",
        "Town Hall (Rathaus)" to "ST_SCHOTTENTOR",
        "Vienna Thermal Baths" to "ST_OBERLAA"
    )

    // Initial disruptions
    var activeDisruptions = mutableListOf(
        Disruption(
            id = "DIS_U4",
            lineId = "U4",
            titleDe = "Signalstörung am Karlsplatz",
            titleEn = "Signal failure at Karlsplatz",
            descriptionDe = "Wegen einer Stellwerkstörung am Karlsplatz ist die Linie U4 zwischen Karlsplatz und Schönbrunn unterbrochen. Schienenersatzverkehr ist eingerichtet.",
            descriptionEn = "Due to a signaling system failure at Karlsplatz, service on line U4 is suspended between Karlsplatz and Schönbrunn. Rail replacement buses are active.",
            affectedStations = listOf("ST_KARLSPLATZ", "ST_SCHOENBRUNN"),
            alternativeAdviceDe = "Bitte weichen Sie auf die Linie U1 bis Meidling aus und nutzen Sie dort die Straßenbahnlinie 62 oder Bus 10A nach Schönbrunn.",
            alternativeAdviceEn = "Please use Metro line U1 to Meidling, then change to Tram 62 or Bus 10A to Schönbrunn.",
            expectedDurationDe = "ca. 45 Minuten",
            expectedDurationEn = "approx. 45 minutes"
        )
    )

    // Find station by ID
    fun getStation(id: String): Station? = stations.find { it.id == id }

    // Find station by Name
    fun findStationByName(name: String): Station? {
        val trimmed = name.trim().lowercase()
        return stations.find { 
            it.name.lowercase().contains(trimmed) || trimmed.contains(it.name.lowercase()) 
        } ?: touristPoisDe[name]?.let { getStation(it) } ?: touristPoisEn[name]?.let { getStation(it) }
    }

    // Find line by ID
    fun getLine(id: String): Line? = lines.find { it.id == id }
}
