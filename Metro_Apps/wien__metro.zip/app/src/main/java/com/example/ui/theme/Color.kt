package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// WIEN//METRO Color Palette
val WienRed = Color(0xFFE2001A)      // Official Vienna transport red
val WienCharcoal = Color(0xFF1E1E1E) // Elegant dark charcoal for high readability
val WienCream = Color(0xFFFCFAF7)    // Classic modernist cream white background
val WienAmber = Color(0xFFFF9F00)    // LED Amber for boards and notices
val WienGrey = Color(0xFF757575)     // Mid grey
val WienLightGrey = Color(0xFFEEEEEE)// Light grey for borders and backgrounds
val WienDarkGrey = Color(0xFF2D2D2D) // Dark card backgrounds

// Line specific colors (Authentic Vienna Network colors)
val ColorU1 = Color(0xFFE2001A) // Red
val ColorU2 = Color(0xFF9E1F63) // Violet/Purple
val ColorU3 = Color(0xFFEE7D00) // Orange
val ColorU4 = Color(0xFF009640) // Green
val ColorU6 = Color(0xFF7A4B30) // Brown
val ColorTram = Color(0xFFE2001A)// Red
val ColorBus = Color(0xFF005EA4) // Blue
val ColorSbahn = Color(0xFF003366)// Dark blue
val ColorWienMobil = Color(0xFF00A0E2) // Teal/Cyan
