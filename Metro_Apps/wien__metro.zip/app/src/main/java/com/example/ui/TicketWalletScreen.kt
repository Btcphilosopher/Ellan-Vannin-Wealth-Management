package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TicketEngine
import com.example.data.TicketType
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketWalletScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    val tickets by TicketEngine.myTickets.collectAsState()
    val selectedTicketTypeId by viewModel.selectedTicketTypeId.collectAsState()
    val buyerName by viewModel.buyerName.collectAsState()

    var showBuyForm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCream)
            .padding(horizontal = 16.dp)
            .testTag("ticket_wallet_scroll"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // --- Header ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isGerman) "TICKETS" else "TICKET SHOP",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = WienCharcoal
                    )
                    Text(
                        text = if (isGerman) "Fahrkarten und digitale Geldbörse" else "Passes and digital ticket wallet",
                        style = MaterialTheme.typography.labelLarge,
                        color = WienGrey
                    )
                }

                IconButton(onClick = { showBuyForm = !showBuyForm }) {
                    Icon(
                        if (showBuyForm) Icons.Filled.Close else Icons.Filled.AddCard,
                        contentDescription = "Buy Tickets",
                        tint = WienRed,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        // --- Buy Ticket Selector ---
        if (showBuyForm) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .testTag("buy_ticket_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isGerman) "FAHRKARTE AUSWÄHLEN" else "BUY A FARECARD",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = WienGrey
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Buyer Name Input
                        OutlinedTextField(
                            value = buyerName,
                            onValueChange = { viewModel.updateBuyerName(it) },
                            placeholder = { Text(if (isGerman) "Name des Passagiers" else "Passenger Name") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("buyer_name_input"),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = WienRed,
                                unfocusedBorderColor = WienLightGrey
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Fare Options
                        TicketEngine.ticketTypes.forEach { type ->
                            val isSelected = selectedTicketTypeId == type.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.setSelectedTicketType(type.id) }
                                    .background(
                                        color = if (isSelected) WienLightGrey else Color.Transparent,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isGerman) type.nameDe else type.nameEn,
                                        fontWeight = FontWeight.Bold,
                                        color = WienCharcoal
                                    )
                                    Text(
                                        text = if (isGerman) type.descriptionDe else type.descriptionEn,
                                        fontSize = 10.sp,
                                        color = WienGrey
                                    )
                                }
                                Text(
                                    text = String.format("%.2f €", type.price),
                                    fontWeight = FontWeight.Black,
                                    color = WienRed,
                                    fontSize = 14.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.buyTicket()
                                showBuyForm = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = WienRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("purchase_ticket_submit_button")
                        ) {
                            Text(
                                text = if (isGerman) "JETZT KOSTENPFLICHTIG KAUFEN" else "PAY & GENERATE PASS",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // --- Wallet Section ---
        item {
            Text(
                text = if (isGerman) "MEINE FAHRKARTEN" else "MY TICKETS & WALLET",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = WienCharcoal,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
            )
        }

        if (tickets.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Filled.CardMembership, contentDescription = "No tickets", tint = WienGrey, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isGerman) "Keine aktiven Tickets vorhanden." else "No active tickets found.",
                            fontWeight = FontWeight.Bold,
                            color = WienCharcoal
                        )
                        Text(
                            text = if (isGerman) "Erwerben Sie eine Fahrkarte über den Shop." else "Purchase a farecard from the shop.",
                            fontSize = 12.sp,
                            color = WienGrey
                        )
                    }
                }
            }
        }

        items(tickets) { ticket ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clickable { viewModel.viewTicket(ticket.id) }
                    .testTag("wallet_ticket_item")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(WienRed, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Icon(Icons.Filled.ConfirmationNumber, contentDescription = "Ticket", tint = Color.White)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = if (isGerman) ticket.typeNameDe.uppercase() else ticket.typeNameEn.uppercase(),
                                fontWeight = FontWeight.Black,
                                color = WienCharcoal,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${if (isGerman) "Fahrgast" else "Passenger"}: ${ticket.passengerName}",
                                fontSize = 11.sp,
                                color = WienGrey
                            )
                            Text(
                                text = "${if (isGerman) "Gültig bis" else "Valid until"}: ${ticket.validTo}",
                                fontSize = 11.sp,
                                color = WienGrey
                            )
                        }
                    }

                    Icon(Icons.Filled.QrCode, contentDescription = "View QR", tint = WienCharcoal, modifier = Modifier.size(32.dp))
                }
            }
        }
    }
}
