package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StationPagesScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val bikesMap by RealtimeSimulator.bikeSharingState.collectAsState()
    val carsMap by RealtimeSimulator.carSharingState.collectAsState()

    val station = TransitData.getStation(selectedStationId) ?: TransitData.stations.first()
    val isFav = favorites.contains(station.id)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCream)
            .padding(horizontal = 16.dp)
            .testTag("station_pages_scroll"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // --- Header ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = WienCharcoal)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isGerman) "STATIONSDETAILS" else "STATION DOSSIER",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = WienCharcoal
                        )
                        Text(
                            text = if (isGerman) "Ausstattungen und Mobilitäts-Verknüpfung" else "Facilities and mobility sharing status",
                            style = MaterialTheme.typography.labelLarge,
                            color = WienGrey
                        )
                    }
                }

                IconButton(onClick = { viewModel.toggleFavorite(station.id) }) {
                    Icon(
                        if (isFav) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (isFav) WienAmber else WienCharcoal,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        // --- Station Poster Card ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = WienCharcoal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = "HALTESTELLE",
                        fontSize = 10.sp,
                        color = WienGrey,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = station.name.uppercase(),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        for (line in station.lines) {
                            val bg = when (line) {
                                "U1" -> ColorU1
                                "U2" -> ColorU2
                                "U3" -> ColorU3
                                "U4" -> ColorU4
                                "U6" -> ColorU6
                                else -> WienGrey
                            }
                            Box(
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .background(bg, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = line,
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- Station exit metadata ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.ExitToApp, contentDescription = "Exit", tint = WienRed)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (isGerman) "EMPFOHLENER AUSSTIEG" else "SMART EXIT EXIT DOOR",
                            fontWeight = FontWeight.Bold,
                            color = WienCharcoal
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isGerman) station.bestExitInfoDe else station.bestExitInfoEn,
                        fontSize = 13.sp,
                        color = WienGrey
                    )
                }
            }
        }

        // --- Amenities / Facilities Grid ---
        item {
            Text(
                text = if (isGerman) "BAUWERK & AUSSTATTUNG" else "FACILITIES & AMENITIES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = WienGrey,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
            )

            val amenities = listOf(
                Pair(Icons.Filled.Elevator, if (isGerman) "Aufzug (Lift)" else "Elevator (Lift)") to station.hasLift,
                Pair(Icons.Filled.DirectionsWalk, if (isGerman) "Rolltreppe (Escalator)" else "Escalator") to station.hasEscalator,
                Pair(Icons.Filled.Wc, if (isGerman) "Sanitäranlagen (WC)" else "Public Restrooms") to station.hasWc,
                Pair(Icons.Filled.SupportAgent, if (isGerman) "Info & Service-Center" else "Customer Service") to station.hasServiceCenter,
                Pair(Icons.Filled.PedalBike, if (isGerman) "WienMobil Rad" else "WienMobil Bike") to station.hasBikeSharing,
                Pair(Icons.Filled.DirectionsCar, if (isGerman) "WienMobil Auto" else "WienMobil Car Sharing") to station.hasCarSharing
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    amenities.forEach { (meta, isAvailable) ->
                        val (icon, name) = meta
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(icon, contentDescription = name, tint = if (isAvailable) WienRed else WienGrey, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(text = name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = WienCharcoal)
                            }

                            Box(
                                modifier = Modifier
                                    .background(
                                        color = if (isAvailable) ColorU4 else WienLightGrey,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isAvailable) {
                                        if (isGerman) "BEREIT" else "OK"
                                    } else {
                                        if (isGerman) "NEIN" else "N/A"
                                    },
                                    color = if (isAvailable) Color.White else WienGrey,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- WienMobil Micro Mobility Details ---
        if (station.hasBikeSharing || station.hasCarSharing) {
            item {
                Text(
                    text = "WIENMOBIL URBAN LAYERS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = WienGrey,
                    modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)
                )
            }

            if (station.hasBikeSharing) {
                item {
                    val bikeDetails = bikesMap[station.id] ?: Pair(12, 8)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.DirectionsBike, contentDescription = "WienMobil Rad", tint = ColorWienMobil)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "WienMobil Rad Hub",
                                        fontWeight = FontWeight.Bold,
                                        color = WienCharcoal
                                    )
                                    Text(
                                        text = if (isGerman) "Fahrrad-Verleihstation" else "Bike rental dock",
                                        fontSize = 11.sp,
                                        color = WienGrey
                                    )
                                }
                            }

                            Row {
                                Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(horizontal = 8.dp)) {
                                    Text(text = "${bikeDetails.first}", fontSize = 18.sp, fontWeight = FontWeight.Black, color = ColorWienMobil)
                                    Text(text = if (isGerman) "Räder" else "Bikes", fontSize = 10.sp, color = WienGrey)
                                }
                                Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(horizontal = 8.dp)) {
                                    Text(text = "${bikeDetails.second}", fontSize = 18.sp, fontWeight = FontWeight.Black, color = WienCharcoal)
                                    Text(text = if (isGerman) "Frei" else "Docks", fontSize = 10.sp, color = WienGrey)
                                }
                            }
                        }
                    }
                }
            }

            if (station.hasCarSharing) {
                item {
                    val carDetails = carsMap[station.id] ?: Triple(2, 1, 0)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.DirectionsCar, contentDescription = "WienMobil Auto", tint = ColorWienMobil)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(text = "WienMobil Auto (CarSharing)", fontWeight = FontWeight.Bold, color = WienCharcoal)
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                val labels = listOf(
                                    Triple("EV", carDetails.first, "Elektro"),
                                    Triple("Cargo", carDetails.second, "Transporter"),
                                    Triple("Family", carDetails.third, "Kombi")
                                )

                                for ((cat, valNum, labelText) in labels) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                        Text(text = "$valNum", fontSize = 16.sp, fontWeight = FontWeight.Black, color = WienCharcoal)
                                        Text(text = if (isGerman) labelText else cat, fontSize = 11.sp, color = WienGrey)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
