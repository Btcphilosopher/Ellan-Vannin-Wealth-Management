package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WienAIScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isChatLoading by viewModel.isChatLoading.collectAsState()

    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Scroll to the bottom whenever a new chat message arrives
    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCream)
            .testTag("wien_ai_screen")
    ) {
        // --- Header ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, bottom = 12.dp, start = 16.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = WienCharcoal)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = "AI", tint = WienRed, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "WIEN.AI",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = WienCharcoal
                    )
                }
                Text(
                    text = if (isGerman) "Intelligenter Reisebegleiter" else "Intelligent passenger assistant",
                    style = MaterialTheme.typography.labelLarge,
                    color = WienGrey
                )
            }
        }

        // --- Chat messages area ---
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(chatMessages) { message ->
                val alignEnd = message.isUser
                val bubbleColor = if (alignEnd) WienCharcoal else Color.White
                val textColor = if (alignEnd) Color.White else WienCharcoal

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    contentAlignment = if (alignEnd) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = bubbleColor),
                        shape = RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (alignEnd) 16.dp else 4.dp,
                            bottomEnd = if (alignEnd) 4.dp else 16.dp
                        ),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .testTag(if (alignEnd) "user_chat_bubble" else "ai_chat_bubble")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Message text with custom simple bold parsing (**text**)
                            val parsedText = message.text
                            Text(
                                text = parsedText,
                                color = textColor,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = message.timestamp,
                                color = if (alignEnd) WienGrey else WienGrey,
                                fontSize = 9.sp,
                                textAlign = TextAlign.End,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            if (isChatLoading) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.padding(horizontal = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    color = WienRed,
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (isGerman) "WIEN.AI überlegt..." else "WIEN.AI thinking...",
                                    fontSize = 12.sp,
                                    color = WienGrey
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- Standard suggestions tray ---
        val suggestions = if (isGerman) {
            listOf("Wie komme ich nach Schönbrunn?", "Ist die U4 heute gestört?", "Wie fahre ich zum Flughafen?")
        } else {
            listOf("How do I get to Schönbrunn?", "Is U4 disrupted today?", "How do I travel to the airport?")
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .background(Color.Transparent),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (suggestion in suggestions) {
                Box(
                    modifier = Modifier
                        .background(WienLightGrey, RoundedCornerShape(16.dp))
                        .clickable { viewModel.sendMessageToAI(suggestion) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = suggestion,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = WienCharcoal
                    )
                }
            }
        }

        // --- Input Bar ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .background(Color.Transparent),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = {
                    Text(if (isGerman) "Fragen Sie WIEN.AI..." else "Ask WIEN.AI...")
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_chat_input"),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WienRed,
                    unfocusedBorderColor = WienGrey,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (textInput.isNotBlank()) {
                        viewModel.sendMessageToAI(textInput)
                        textInput = ""
                    }
                },
                modifier = Modifier
                    .background(WienRed, RoundedCornerShape(24.dp))
                    .size(48.dp)
                    .testTag("ai_send_button")
            ) {
                Icon(
                    Icons.Filled.Send,
                    contentDescription = "Send",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
