package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DepartureBoardScreen(viewModel: WienMetroViewModel) {
    val isGerman by viewModel.isGerman.collectAsState()
    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val clockMinutes by RealtimeSimulator.simClock.collectAsState()

    var activeStationId by remember { mutableStateOf(selectedStationId) }
    val station = TransitData.getStation(activeStationId) ?: TransitData.stations.first()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WienCream)
            .padding(horizontal = 16.dp)
            .testTag("departure_board_scroll"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // --- Header ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 40.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = WienCharcoal)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (isGerman) "ABFAHRTS-MONITOR" else "LIVE DEPARTURES",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = WienCharcoal
                    )
                    Text(
                        text = if (isGerman) "Echtzeit-Fahrplan Wiener Linien" else "Real-time departure board",
                        style = MaterialTheme.typography.labelLarge,
                        color = WienGrey
                    )
                }
            }
        }

        // --- Station Selector Row ---
        item {
            Text(
                text = if (isGerman) "HALTESTELLE WÄHLEN" else "SELECT STATION",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = WienGrey,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Main interchange stations for quick view
                val quickStations = listOf(
                    Pair("ST_STEPHANSPLATZ", "Stephansplatz"),
                    Pair("ST_KARLSPLATZ", "Karlsplatz"),
                    Pair("ST_WESTBAHNHOF", "Westbahnhof"),
                    Pair("ST_LANDSTRASSE", "Landstraße")
                )

                for ((id, name) in quickStations) {
                    val active = activeStationId == id
                    Button(
                        onClick = { activeStationId = id },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (active) WienRed else Color.White,
                            contentColor = if (active) Color.White else WienCharcoal
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                    ) {
                        Text(name, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // --- Live Station Information Summary ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = WienCharcoal),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = station.name.uppercase(),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )

                        Row {
                            for (line in station.lines) {
                                val bg = when (line) {
                                    "U1" -> ColorU1
                                    "U2" -> ColorU2
                                    "U3" -> ColorU3
                                    "U4" -> ColorU4
                                    "U6" -> ColorU6
                                    else -> WienGrey
                                }
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 2.dp)
                                        .background(bg, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(line, color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.NotificationsActive, contentDescription = "Alerts", tint = WienAmber, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        val isDisrupted = TransitData.activeDisruptions.any { disp ->
                            disp.affectedStations.contains(station.id)
                        }

                        Text(
                            text = if (isDisrupted) {
                                if (isGerman) "⚠️ Betriebsstörung aktiv (U4)" else "⚠️ Active service alert (U4)"
                            } else {
                                if (isGerman) "✅ Betrieb normal" else "✅ All services normal"
                            },
                            fontSize = 12.sp,
                            color = if (isDisrupted) WienAmber else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // --- Departure Lists ---
        item {
            Text(
                text = if (isGerman) "NÄCHSTE ABFAHRTEN" else "NEXT BOARDINGS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = WienGrey,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        val matchingLines = TransitData.lines.filter { line -> line.stations.contains(station.id) }

        if (matchingLines.isEmpty()) {
            item {
                Text(
                    text = if (isGerman) "Keine Linien ab dieser Station." else "No lines departing from this station.",
                    color = WienGrey,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        }

        matchingLines.forEach { line ->
            // Draw predictions for both directions of this line if sequential
            val idx = line.stations.indexOf(station.id)
            val directions = mutableListOf<String>()
            if (idx > 0) directions.add(line.stations.first())
            if (idx < line.stations.size - 1) directions.add(line.stations.last())

            items(directions) { destStationId ->
                val destStation = TransitData.getStation(destStationId)
                val isAffected = TransitData.activeDisruptions.any { disp ->
                    disp.lineId == line.id && disp.affectedStations.contains(station.id)
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .background(line.color, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = line.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = destStation?.name ?: "Endstation",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = WienCharcoal
                                )
                                Text(
                                    text = "Gleis ${if (line.id == "U6") "2" else "1"}",
                                    fontSize = 11.sp,
                                    color = WienGrey
                                )
                            }
                        }

                        if (isAffected) {
                            Text(
                                text = if (isGerman) "Ausfall" else "Cancelled",
                                color = WienRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        } else {
                            val times = RealtimeSimulator.getDeparturesForStation(station.id, line.id)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                times.forEachIndexed { index, time ->
                                    if (index > 0) {
                                        Text(
                                            text = ", ",
                                            color = WienGrey,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Text(
                                        text = "$time",
                                        fontSize = if (index == 0) 22.sp else 14.sp,
                                        fontWeight = if (index == 0) FontWeight.Black else FontWeight.Bold,
                                        color = if (index == 0) WienRed else WienCharcoal
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "min",
                                    fontSize = 11.sp,
                                    color = WienGrey
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
