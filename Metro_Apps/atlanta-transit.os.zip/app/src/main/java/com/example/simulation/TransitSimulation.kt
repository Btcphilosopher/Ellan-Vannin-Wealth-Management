package com.example.simulation

import com.example.data.*
import com.example.routing.TransitData

object TransitSimulation {

    fun getWeatherState(scenario: String): WeatherState {
        return when (scenario) {
            "RAIN" -> WeatherState(
                type = WeatherType.HEAVY_RAIN,
                description = "Heavy Rain",
                temperatureFahrenheit = 71,
                walkingDelayModifierMinutes = 4,
                message = "Steady Georgia rain. Concrete viaducts slick; please use handrails."
            )
            "THUNDERSTORM" -> WeatherState(
                type = WeatherType.THUNDERSTORM,
                description = "Thunderstorm Warning",
                temperatureFahrenheit = 76,
                walkingDelayModifierMinutes = 7,
                message = "Severe lightning in Fulton & DeKalb counties. Surface bus delays expected."
            )
            "HOT" -> WeatherState(
                type = WeatherType.HEAT_WARNING,
                description = "Excessive Heat Advisory",
                temperatureFahrenheit = 96,
                walkingDelayModifierMinutes = 1,
                message = "Southern summer peak temperature. Air-cooled trains running at maximum ventilation."
            )
            "WINTER_WEATHER" -> WeatherState(
                type = WeatherType.WINTER_WEATHER,
                description = "Flash Freeze Watch",
                temperatureFahrenheit = 29,
                walkingDelayModifierMinutes = 5,
                message = "Trace ice on outdoor tracks near North Springs. Speed restrictions active."
            )
            else -> WeatherState(
                type = WeatherType.CLEAR,
                description = "Clear Southern Sun",
                temperatureFahrenheit = 78,
                walkingDelayModifierMinutes = 0,
                message = "Optimal service conditions across the metro Atlanta tree canopy."
            )
        }
    }

    fun getIncidents(scenario: String): List<Incident> {
        val list = mutableListOf<Incident>()
        when (scenario) {
            "MAJOR_DELAY" -> {
                list.add(
                    Incident(
                        id = "inc_red_delay",
                        type = "delay",
                        severity = DisruptionSeverity.MINOR_DELAY,
                        affectedRoutes = listOf("Red Line"),
                        affectedStations = listOf("LIND_CENTER", "BUCKHEAD", "SANDY_SPRINGS"),
                        startTime = "08:15 AM",
                        expectedDuration = "45 mins",
                        description = "Northbound Red Line trains experiencing approximately 8-minute delays due to automated signaling updates at Buckhead station.",
                        alternatives = "Board any northbound Gold Line train to Lindbergh, then transfer to a temporary Red shuttle.",
                        status = "ACTIVE"
                    )
                )
            }
            "STATION_CLOSURE" -> {
                list.add(
                    Incident(
                        id = "inc_five_pts",
                        type = "station closure",
                        severity = DisruptionSeverity.SEVERE,
                        affectedRoutes = listOf("Red Line", "Gold Line", "Blue Line", "Green Line"),
                        affectedStations = listOf("Five Points"),
                        startTime = "10:00 AM",
                        expectedDuration = "Indefinite",
                        description = "Elevator rehabilitation work on the South-East platform at Five Points. No step-free transfer possible from North-South to East-West lines.",
                        alternatives = "Passengers requiring step-free access from Midtown to Decatur should transfer via Atlanta Streetcar at Peachtree Center.",
                        status = "ACTIVE"
                    )
                )
            }
            "EVENT" -> {
                list.add(
                    Incident(
                        id = "inc_stadium_event",
                        type = "major event",
                        severity = DisruptionSeverity.WATCH,
                        affectedRoutes = listOf("Blue Line", "Green Line", "Route 3"),
                        affectedStations = listOf("Dome/GWCC/Philips/CNN", "Five Points"),
                        startTime = "04:00 PM",
                        expectedDuration = "6 hours",
                        description = "Atlanta United Match at Mercedes-Benz Stadium. Gates open in 1 hour. Upwards of 55,000 fans expected. Extra rail transit cars added.",
                        alternatives = "Use Dome/GWCC or Vine City stations. Avoid driving on Northside Dr.",
                        status = "ACTIVE"
                    )
                )
            }
            "BUS_DETOUR" -> {
                list.add(
                    Incident(
                        id = "inc_bus_detour",
                        type = "bus detour",
                        severity = DisruptionSeverity.MINOR_DELAY,
                        affectedRoutes = listOf("Bus Route 15"),
                        affectedStations = listOf("Decatur", "East Lake"),
                        startTime = "07:00 AM",
                        expectedDuration = "3 hours",
                        description = "Construction block on Candler Rd. Route 15 executing an arterial detour via Memorial Dr.",
                        alternatives = "Board any Blue line rail train to Inman Park for Emory connections.",
                        status = "ACTIVE"
                    )
                )
            }
            "AIRPORT_SURGE" -> {
                list.add(
                    Incident(
                        id = "inc_airport_surge",
                        type = "emergency",
                        severity = DisruptionSeverity.WATCH,
                        affectedRoutes = listOf("Red Line", "Gold Line"),
                        affectedStations = listOf("Airport", "College Park"),
                        startTime = "11:30 AM",
                        expectedDuration = "5 hours",
                        description = "Holiday passenger peak at Hartsfield-Jackson Airport. TSA wait times exceed 45 minutes.",
                        alternatives = "MARTA rail trains operating with standard 8-minute headways direct to baggage claim. Avoid airport road lanes.",
                        status = "ACTIVE"
                    )
                )
            }
        }
        return list
    }

    fun getVehicles(scenario: String, ticksMs: Long): List<Vehicle> {
        val vehicles = mutableListOf<Vehicle>()
        
        // Let's model 6 train runs and 3 buses running along their paths
        // We use tickMs to advance vehicles on a deterministic track loop.
        
        // 1. Red Line Train (TRAIN-RD-101) - Airport to North Springs
        val rdProgress = (ticksMs % 120000L).toFloat() / 120000f
        val rdDirection = if (rdProgress < 0.5f) "North Springs-bound" else "Airport-bound"
        val rdRelativeProgress = if (rdProgress < 0.5f) rdProgress * 2f else (1.0f - rdProgress) * 2f
        vehicles.add(
            Vehicle(
                id = "TRAIN-RD-101",
                mode = TransitMode.RAIL,
                routeName = "Red Line",
                direction = rdDirection,
                progress = rdRelativeProgress,
                speedKmh = if (rdProgress in 0.2f..0.3f) 0 else 68, // simulate station dwell
                numCars = if (scenario == "RUSH_HOUR" || scenario == "EVENT") 6 else 4,
                passengerLoadPercent = getSyntheticOccupancy(scenario, rdProgress, "RAIL"),
                currentStationId = getRailStationAtProgress(rdRelativeProgress, listOf("AIRPORT", "FIVE_POINTS", "MIDTOWN", "LINDBERGH", "BUCKHEAD", "NORTH_SPRINGS"))
            )
        )

        // 2. Gold Line Train (TRAIN-GD-201) - Airport to Doraville
        val gdProgress = ((ticksMs + 30000L) % 150000L).toFloat() / 150000f
        val gdDirection = if (gdProgress < 0.5f) "Doraville-bound" else "Airport-bound"
        val gdRelativeProgress = if (gdProgress < 0.5f) gdProgress * 2f else (1.0f - gdProgress) * 2f
        vehicles.add(
            Vehicle(
                id = "TRAIN-GD-201",
                mode = TransitMode.RAIL,
                routeName = "Gold Line",
                direction = gdDirection,
                progress = gdRelativeProgress,
                speedKmh = 72,
                numCars = 6,
                passengerLoadPercent = getSyntheticOccupancy(scenario, gdProgress, "RAIL"),
                currentStationId = getRailStationAtProgress(gdRelativeProgress, listOf("AIRPORT", "FIVE_POINTS", "MIDTOWN", "LINDBERGH", "LENOX", "DORAVILLE"))
            )
        )

        // 3. Blue Line Train (TRAIN-BL-301) - Holmes to Indian Creek
        val blProgress = ((ticksMs + 60000L) % 100000L).toFloat() / 100000f
        val blDirection = if (blProgress < 0.5f) "Indian Creek-bound" else "H.E. Holmes-bound"
        val blRelativeProgress = if (blProgress < 0.5f) blProgress * 2f else (1.0f - blProgress) * 2f
        vehicles.add(
            Vehicle(
                id = "TRAIN-BL-301",
                mode = TransitMode.RAIL,
                routeName = "Blue Line",
                direction = blDirection,
                progress = blRelativeProgress,
                speedKmh = 64,
                numCars = 6,
                passengerLoadPercent = getSyntheticOccupancy(scenario, blProgress, "RAIL"),
                currentStationId = getRailStationAtProgress(blRelativeProgress, listOf("HE_HOLMES", "DOME_GWCC", "FIVE_POINTS", "INMAN_PARK", "DECATUR", "INDIAN_CREEK"))
            )
        )

        // 4. Atlanta Streetcar (STC-02) - Downtown Loop
        val stProgress = (ticksMs % 60000L).toFloat() / 60000f
        vehicles.add(
            Vehicle(
                id = "STC-02",
                mode = TransitMode.STREETCAR,
                routeName = "Atlanta Streetcar",
                direction = "Downtown Loop",
                progress = stProgress,
                speedKmh = 24,
                numCars = 1,
                passengerLoadPercent = if (scenario == "EVENT") 85 else 32,
                currentStationId = if (stProgress < 0.5f) "PEACHTREE_CENTER" else "KING_MEMORIAL"
            )
        )

        // 5. Bus Route 15 (BUS-15-221)
        val b15Progress = (ticksMs % 90000L).toFloat() / 90000f
        vehicles.add(
            Vehicle(
                id = "BUS-15-221",
                mode = TransitMode.BUS,
                routeName = "Bus 15",
                direction = if (b15Progress < 0.5f) "Emory-bound" else "Decatur-bound",
                progress = b15Progress,
                speedKmh = 35,
                numCars = 0,
                passengerLoadPercent = getSyntheticOccupancy(scenario, b15Progress, "BUS")
            )
        )

        // 6. Bus Route 110 (BUS-110-104) "The Peach"
        val b110Progress = ((ticksMs + 45000L) % 110000L).toFloat() / 110000f
        vehicles.add(
            Vehicle(
                id = "BUS-110-104",
                mode = TransitMode.BUS,
                routeName = "Bus 110",
                direction = if (b110Progress < 0.5f) "Buckhead-bound" else "Downtown-bound",
                progress = b110Progress,
                speedKmh = 28,
                numCars = 0,
                passengerLoadPercent = getSyntheticOccupancy(scenario, b110Progress, "BUS")
            )
        )

        return vehicles
    }

    private fun getSyntheticOccupancy(scenario: String, progress: Float, mode: String): Int {
        val base = when (scenario) {
            "RUSH_HOUR" -> 82
            "EVENT" -> if (mode == "RAIL") 88 else 45
            "NIGHT" -> 14
            else -> 42
        }
        // fluctuate by progress to feel alive
        val wave = (Math.sin(progress.toDouble() * Math.PI * 4).toFloat() * 15).toInt()
        return (base + wave).coerceIn(5, 98)
    }

    private fun getRailStationAtProgress(progress: Float, stations: List<String>): String {
        val index = (progress * (stations.size - 1)).toInt().coerceIn(0, stations.size - 1)
        return stations[index]
    }
}
