package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.TapState
import com.example.ui.TransitViewModel
import com.example.ui.theme.AccentClay
import com.example.ui.theme.MartaBlue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BreezeScreen(
    viewModel: TransitViewModel,
    modifier: Modifier = Modifier
) {
    val account by viewModel.breezeAccount.collectAsState()
    val tripHistory by viewModel.tripHistory.collectAsState()
    val tapState by viewModel.tapState.collectAsState()
    val transferSeconds by viewModel.remainingTransferTimeSeconds.collectAsState()

    var showTapSimDialog by remember { mutableStateOf(false) }
    var selectedMethod by remember { mutableStateOf(PaymentMethod.BREEZE_CARD) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // SCREEN TITLE
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Text(
                    text = "BREEZE FARE",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = (-1).sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "ACCOUNT-BASED METROPOLITAN FARE OS",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // BREEZE CARD METROPOLITAN ASSET
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MartaBlue,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .testTag("breeze_card_visual")
            ) {
                Box(modifier = Modifier.fillMaxSize().padding(20.dp)) {
                    // Header
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                "breeze",
                                style = MaterialTheme.typography.displayMedium,
                                fontWeight = FontWeight.Black,
                                letterSpacing = (-1).sp
                            )
                            Text(
                                "transit card",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Icon(
                            Icons.Filled.Nfc,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    // Card Info Bottom
                    Column(
                        modifier = Modifier.align(Alignment.BottomStart)
                    ) {
                        Text(
                            text = "BALANCE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                        Text(
                            text = "$${String.format("%.2f", account.balance)}",
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = account.cardNumber,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (account.autoloadOn) "AUTOLOAD ON" else "AUTOLOAD OFF",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (account.autoloadOn) Color.Green else Color.LightGray
                            )
                        }
                    }
                }
            }
        }

        // ACTIVE TRANSFER WINDOW CARD
        if (transferSeconds > 0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF238E5A).copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color(0xFF238E5A))
                        val hrs = transferSeconds / 3600
                        val mins = (transferSeconds % 3600) / 60
                        val secs = transferSeconds % 60
                        Column {
                            Text(
                                "ACTIVE TRANSFERS ACTIVE",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF238E5A)
                            )
                            Text(
                                text = "Up to 4 free transfers remaining on this trip.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "Expires in: ${String.format("%02d:%02d:%02d", hrs, mins, secs)}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // SIMULATE TAP TERMINAL QUICK LINK
        item {
            Button(
                onClick = { showTapSimDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onBackground),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth().testTag("simulate_tap_portal_button")
            ) {
                Icon(Icons.Filled.SendToMobile, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("OPEN FARE TAP SIMULATOR", fontWeight = FontWeight.Bold)
            }
        }

        // FARE ACCOUNT SETTINGS
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ADD FUNDS TO BREEZE",
                        style = MaterialTheme.typography.labelSmall,
                        color = MartaBlue,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val fundsOpts = listOf(5.0, 10.0, 20.0, 50.0)
                        fundsOpts.forEach { amt ->
                            OutlinedButton(
                                onClick = { viewModel.addFundsToBreeze(amt) },
                                modifier = Modifier.weight(1f).testTag("add_funds_${amt.toInt()}_button"),
                                shape = RoundedCornerShape(2.dp)
                            ) {
                                Text("+$${amt.toInt()}")
                            }
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 14.dp))

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text("Auto-load Balance", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Text("Reloads +$20.00 if balance drops below $2.50", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                        }
                        Switch(
                            checked = account.autoloadOn,
                            onCheckedChange = { viewModel.toggleAutoloadState(it) },
                            colors = SwitchDefaults.colors(checkedTrackColor = MartaBlue)
                        )
                    }
                }
            }
        }

        // RECENT TRIP LOGS
        item {
            Column {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "RECENT TRIP LOGS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = { viewModel.resetTap() }) {
                        Text("Reset Tap")
                    }
                }
                
                if (tripHistory.isEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier.padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No recent fare swipes.", color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                } else {
                    tripHistory.forEach { trip ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        if (trip.isTransfer) Icons.Filled.SwapHoriz else Icons.Filled.TransitEnterexit,
                                        contentDescription = null,
                                        tint = if (trip.isTransfer) MartaBlue else AccentClay
                                    )
                                    Column {
                                        Text("${trip.origin} ➔ ${trip.destination}", fontWeight = FontWeight.Bold)
                                        val timeStr = SimpleDateFormat("MMM dd, hh:mm a", Locale.US).format(Date(trip.timestamp))
                                        Text("${trip.routeName} — $timeStr", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                                    }
                                }
                                Text(
                                    text = if (trip.isTransfer) "FREE" else "-$${String.format("%.2f", trip.fareCharged)}",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (trip.isTransfer) Color(0xFF238E5A) else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // --- FARE TAP ANIMATOR OVERLAY DIALOG ---
    if (showTapSimDialog) {
        AlertDialog(
            onDismissRequest = { showTapSimDialog = false; viewModel.resetTap() },
            title = {
                Text("METROPOLITAN FARE TERMINAL", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "Tap payment instrument to MARTA reader. Simulated fare charge of $2.50.",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    // Payment Method selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val methods = listOf(PaymentMethod.BREEZE_CARD, PaymentMethod.APPLE_PAY, PaymentMethod.DEBIT_CARD)
                        methods.forEach { method ->
                            Card(
                                onClick = { selectedMethod = method },
                                modifier = Modifier
                                    .weight(1f)
                                    .border(
                                        width = if (selectedMethod == method) 2.dp else 0.dp,
                                        color = if (selectedMethod == method) MartaBlue else Color.Transparent,
                                        shape = RoundedCornerShape(2.dp)
                                    ),
                                shape = RoundedCornerShape(2.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Box(modifier = Modifier.padding(8.dp), contentAlignment = Alignment.Center) {
                                    Text(method.label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Physical terminal reader visual
                    val animatingScale by animateFloatAsState(
                        targetValue = if (tapState is TapState.Tapping) 1.1f else 1.0f,
                        animationSpec = spring(),
                        label = "tapScale"
                    )

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = when (tapState) {
                                is TapState.Accepted -> Color(0xFF238E5A).copy(alpha = 0.15f)
                                is TapState.Tapping -> MartaBlue.copy(alpha = 0.2f)
                                else -> MaterialTheme.colorScheme.surface
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .border(
                                width = 2.dp,
                                color = when (tapState) {
                                    is TapState.Accepted -> Color(0xFF238E5A)
                                    is TapState.Tapping -> MartaBlue
                                    else -> MaterialTheme.colorScheme.secondary
                                },
                                shape = RoundedCornerShape(4.dp)
                            ),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                when (tapState) {
                                    is TapState.Idle -> {
                                        Icon(Icons.Filled.Nfc, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                        Text("PLACE DEVICE NEAR READER", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                    }
                                    is TapState.Proximity -> {
                                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MartaBlue)
                                        Text("RECOGNIZING INSTRUMENT...", style = MaterialTheme.typography.labelSmall)
                                    }
                                    is TapState.Tapping -> {
                                        Text("SWIPING...", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MartaBlue)
                                    }
                                    is TapState.Accepted -> {
                                        val data = tapState as TapState.Accepted
                                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color(0xFF238E5A), modifier = Modifier.size(32.dp))
                                        Text("ACCEPTED $${String.format("%.2f", data.amount)}", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                                        Text(data.remainingTransferText, style = MaterialTheme.typography.labelSmall, color = Color(0xFF238E5A))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { viewModel.triggerTapPayment(selectedMethod) },
                        modifier = Modifier.fillMaxWidth().testTag("tap_trigger_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MartaBlue)
                    ) {
                        Text("SIMULATE CARD CONTACT")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTapSimDialog = false; viewModel.resetTap() }) {
                    Text("DONE")
                }
            }
        )
    }
}
