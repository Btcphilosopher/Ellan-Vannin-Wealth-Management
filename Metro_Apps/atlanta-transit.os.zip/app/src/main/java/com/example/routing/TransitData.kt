package com.example.routing

import com.example.data.*
import java.util.PriorityQueue

object TransitData {

    // --- RAIL STATIONS DEFINITIONS ---
    // Red, Gold, Blue, Green Lines
    val stations = listOf(
        // Centered interchange
        Station(
            id = "FIVE_POINTS",
            name = "Five Points",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD, RailLineColor.BLUE, RailLineColor.GREEN),
            gridX = 0f,
            gridY = 0f,
            entrances = listOf("Peachtree St NW", "Alabama St SW", "Broad St SW"),
            elevatorsCount = 4,
            escalatorsCount = 8,
            busConnections = listOf("Route 3", "Route 110", "Rapid 101"),
            streetcarConnection = true,
            nearbyDestinations = listOf("Underground Atlanta", "Woodruff Park", "Georgia State Capitol"),
            neighborhoodInfo = "The absolute center of the Atlanta transit network, Five Points is a high-capacity concrete transit cathedral connecting all four rail lines."
        ),
        // Red / Gold North Line
        Station(
            id = "PEACHTREE_CENTER",
            name = "Peachtree Center",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = -0.6f,
            entrances = listOf("Peachtree St NE", "Andrew Young International Blvd"),
            elevatorsCount = 2,
            escalatorsCount = 6,
            busConnections = listOf("Route 110"),
            streetcarConnection = true,
            nearbyDestinations = listOf("Centennial Olympic Park", "World of Coca-Cola", "Georgia Aquarium"),
            neighborhoodInfo = "Deep-cavern station blasted out of solid Georgia granite, featuring soaring escalators and raw-granite architectural walls."
        ),
        Station(
            id = "CIVIC_CENTER",
            name = "Civic Center",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = -1.2f,
            entrances = listOf("West Peachtree St NW"),
            elevatorsCount = 1,
            escalatorsCount = 4,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Emory University Hospital Midtown", "Civic Center Plaza"),
            neighborhoodInfo = "A bridge-like station built directly over the Downtown Connector highway, displaying spectacular city highway views."
        ),
        Station(
            id = "NORTH_AVENUE",
            name = "North Avenue",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = -1.8f,
            entrances = listOf("West Peachtree St NW", "Peachtree St NE (via BellSouth building)"),
            elevatorsCount = 2,
            escalatorsCount = 4,
            busConnections = listOf("Route 2", "Route 102"),
            nearbyDestinations = listOf("The Fox Theatre", "Georgia Tech Campus", "Ponce City Market (via Bus 2)"),
            neighborhoodInfo = "Located in Midtown South, directly serving the historic Fox Theatre and the southern edge of the Georgia Tech campus."
        ),
        Station(
            id = "MIDTOWN",
            name = "Midtown",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = -2.4f,
            entrances = listOf("10th St NW", "Peachtree St (via Midtown Plaza)"),
            elevatorsCount = 2,
            escalatorsCount = 4,
            busConnections = listOf("Route 12", "Route 110"),
            nearbyDestinations = listOf("Piedmont Park", "Margaret Mitchell House", "Federal Reserve Bank"),
            neighborhoodInfo = "Surrounded by modern glass residential and office towers, Midtown is a bustling node of pedestrian movement, street-level retail, and active city life."
        ),
        Station(
            id = "ARTS_CENTER",
            name = "Arts Center",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = -3.0f,
            entrances = listOf("15th St NE", "Lombardy Way"),
            elevatorsCount = 3,
            escalatorsCount = 6,
            busConnections = listOf("Route 110", "Route 37"),
            nearbyDestinations = listOf("High Museum of Art", "Alliance Theatre", "Atlanta Symphony Hall"),
            neighborhoodInfo = "A massive modern station integrated directly into the Woodruff Arts Center complex, serving Atlanta's premier cultural institutions."
        ),
        Station(
            id = "LINDBERGH",
            name = "Lindbergh Center",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = -3.8f,
            entrances = listOf("Piedmont Rd NE", "Garson Dr NE"),
            elevatorsCount = 4,
            escalatorsCount = 8,
            busConnections = listOf("Route 5", "Route 39", "Route 809"),
            nearbyDestinations = listOf("MARTA Headquarters", "Lindbergh City Center transit-oriented development"),
            neighborhoodInfo = "A major outdoor junction where the Red and Gold Lines split, surrounded by the landmark MARTA headquarters and high-density apartments."
        ),
        // Red Line North-West Branch
        Station(
            id = "BUCKHEAD",
            name = "Buckhead",
            lines = listOf(RailLineColor.RED),
            gridX = 0.5f,
            gridY = -4.4f,
            entrances = listOf("Peachtree Rd NE"),
            elevatorsCount = 2,
            escalatorsCount = 4,
            busConnections = listOf("Route 110"),
            nearbyDestinations = listOf("Lenox Square Mall", "Phipps Plaza", "Buckhead Financial District"),
            neighborhoodInfo = "A sleek, steel-and-glass structural node wedged directly in the median of the Georgia 400 highway, surrounded by Buckhead's towering skyscrapers."
        ),
        Station(
            id = "MEDICAL_CENTER",
            name = "Medical Center",
            lines = listOf(RailLineColor.RED),
            gridX = 0.9f,
            gridY = -5.0f,
            entrances = listOf("Lake Hearn Dr"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Northside Hospital", "St. Joseph's Hospital", "Children's Healthcare of Atlanta"),
            neighborhoodInfo = "Elevated transit link serving 'Pill Hill', Atlanta's premier high-density healthcare campus."
        ),
        Station(
            id = "DUNWOODY",
            name = "Dunwoody",
            lines = listOf(RailLineColor.RED),
            gridX = 0.9f,
            gridY = -5.6f,
            entrances = listOf("Hammond Dr"),
            elevatorsCount = 2,
            escalatorsCount = 4,
            busConnections = listOf("Route 150"),
            nearbyDestinations = listOf("Perimeter Mall", "Perimeter Center Office Parks"),
            neighborhoodInfo = "Major suburban transit hub serving Perimeter Center and Perimeter Mall."
        ),
        Station(
            id = "SANDY_SPRINGS",
            name = "Sandy Springs",
            lines = listOf(RailLineColor.RED),
            gridX = 0.9f,
            gridY = -6.2f,
            entrances = listOf("Mount Vernon Hwy"),
            elevatorsCount = 2,
            escalatorsCount = 4,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Sandy Springs Performing Arts Center", "City Springs"),
            neighborhoodInfo = "Deep underground cavern station built directly under major Sandy Springs commercial boulevards."
        ),
        Station(
            id = "NORTH_SPRINGS",
            name = "North Springs",
            lines = listOf(RailLineColor.RED),
            gridX = 0.9f,
            gridY = -6.8f,
            entrances = listOf("Peachtree Dunwoody Rd"),
            elevatorsCount = 3,
            escalatorsCount = 4,
            busConnections = listOf("Route 140", "Route 141", "Route 143"),
            nearbyDestinations = listOf("North Springs Park & Ride", "Chattahoochee River NRA"),
            neighborhoodInfo = "The northernmost terminal of the Red Line, featuring a massive multi-story park-and-ride garage."
        ),
        // Gold Line North-East Branch
        Station(
            id = "LENOX",
            name = "Lenox",
            lines = listOf(RailLineColor.GOLD),
            gridX = -0.5f,
            gridY = -4.4f,
            entrances = listOf("Lenox Rd NE"),
            elevatorsCount = 2,
            escalatorsCount = 4,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Lenox Square Mall", "JW Marriott Buckhead"),
            neighborhoodInfo = "Beautifully styled station integrated with direct walking corridors to Lenox Square, showcasing modern glass accents."
        ),
        Station(
            id = "BROOKHAVEN",
            name = "Brookhaven",
            lines = listOf(RailLineColor.GOLD),
            gridX = -0.9f,
            gridY = -5.0f,
            entrances = listOf("Apple Valley Rd"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = listOf("Route 8"),
            nearbyDestinations = listOf("Oglethorpe University", "Brookhaven Town Center"),
            neighborhoodInfo = "At-grade station with a massive open-air canopy, forming the centerpiece of the historic Brookhaven neighborhood."
        ),
        Station(
            id = "CHAMBLEE",
            name = "Chamblee",
            lines = listOf(RailLineColor.GOLD),
            gridX = -1.3f,
            gridY = -5.6f,
            entrances = listOf("Peachtree Rd"),
            elevatorsCount = 1,
            escalatorsCount = 2,
            busConnections = listOf("Route 19", "Route 103"),
            nearbyDestinations = listOf("Chamblee Antique Row", "Chamblee Chinatown"),
            neighborhoodInfo = "Sleek elevated platform station serving Chamblee's vibrant international culinary and cultural corridors."
        ),
        Station(
            id = "DORAVILLE",
            name = "Doraville",
            lines = listOf(RailLineColor.GOLD),
            gridX = -1.7f,
            gridY = -6.2f,
            entrances = listOf("New Peachtree Rd"),
            elevatorsCount = 2,
            escalatorsCount = 4,
            busConnections = listOf("Route 124", "Route 133", "Gwinnett Transit"),
            nearbyDestinations = listOf("Buford Highway International Corridor", "Doraville City Hall"),
            neighborhoodInfo = "The northeastern terminal of the Gold Line, directly adjacent to Buford Highway's legendary dense retail and culinary scene."
        ),
        // Red / Gold South Line
        Station(
            id = "GARNETT",
            name = "Garnett",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = 0.8f,
            entrances = listOf("Mitchell St SW", "Trinity Ave SW"),
            elevatorsCount = 1,
            escalatorsCount = 2,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Atlanta City Hall", "Fulton County Courthouse", "Greyhound Station"),
            neighborhoodInfo = "Elevated concrete viaduct station serving Atlanta's governmental center and court buildings."
        ),
        Station(
            id = "WEST_END",
            name = "West End",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = 1.4f,
            entrances = listOf("Ralph David Abernathy Blvd SW"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = listOf("Route 67", "Route 68", "Route 71"),
            nearbyDestinations = listOf("Mall West End", "Atlanta University Center (Morehouse, Spelman)"),
            neighborhoodInfo = "A vital elevated commuter station serving the historic West End neighborhood and the historic Atlanta University Center colleges."
        ),
        Station(
            id = "OAKLAND_CITY",
            name = "Oakland City",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = 2.0f,
            entrances = listOf("Campbellton Rd SW"),
            elevatorsCount = 1,
            escalatorsCount = 2,
            busConnections = listOf("Route 83", "Route 162"),
            nearbyDestinations = listOf("Fort McPherson Development", "Oakland City Park"),
            neighborhoodInfo = "At-grade station located in historic Oakland City, serving as a critical transfer point for South-West Atlanta bus routes."
        ),
        Station(
            id = "LAKEWOOD",
            name = "Lakewood/Fort McPherson",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = 2.6f,
            entrances = listOf("Lee St SW"),
            elevatorsCount = 1,
            escalatorsCount = 2,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Tyler Perry Studios", "Lakewood Amphitheatre"),
            neighborhoodInfo = "Sleek mid-century modern architectural station directly bordering Tyler Perry Studios at Fort McPherson."
        ),
        Station(
            id = "EAST_POINT",
            name = "East Point",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = 3.2f,
            entrances = listOf("East Point Path"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = listOf("Route 78", "Route 81"),
            nearbyDestinations = listOf("Downtown East Point", "East Point Library"),
            neighborhoodInfo = "Integrated with a pedestrian-friendly transit plaza in downtown historic East Point."
        ),
        Station(
            id = "COLLEGE_PARK",
            name = "College Park",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = 3.8f,
            entrances = listOf("Main St", "Camp Creek Pkwy"),
            elevatorsCount = 3,
            escalatorsCount = 4,
            busConnections = listOf("Route 82", "Route 180", "Route 181"),
            nearbyDestinations = listOf("Georgia International Convention Center (GICC)", "Main Street Historic District"),
            neighborhoodInfo = "Sleek elevated terminal station located in College Park, second busiest station in the entire network."
        ),
        Station(
            id = "AIRPORT",
            name = "Airport",
            lines = listOf(RailLineColor.RED, RailLineColor.GOLD),
            gridX = 0f,
            gridY = 4.6f,
            entrances = listOf("Hartsfield-Jackson Airport Domestic Terminal"),
            elevatorsCount = 4,
            escalatorsCount = 8,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Hartsfield-Jackson Airport", "ATL SkyTrain to Rental Car Center"),
            neighborhoodInfo = "Directly integrated into the baggage claim lobby of Hartsfield-Jackson Airport, providing premium terminal rail access."
        ),
        // Blue / Green East Line
        Station(
            id = "GEORGIA_STATE",
            name = "Georgia State",
            lines = listOf(RailLineColor.BLUE, RailLineColor.GREEN),
            gridX = 0.8f,
            gridY = 0f,
            entrances = listOf("Piedmont Ave SE", "Jesse Hill Jr Dr"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Georgia State Capitol", "GSU Campus", "Grady Memorial Hospital"),
            neighborhoodInfo = "Located directly inside the Twin Towers state office building complex, serving State Capitol employees and Georgia State University."
        ),
        Station(
            id = "KING_MEMORIAL",
            name = "King Memorial",
            lines = listOf(RailLineColor.BLUE, RailLineColor.GREEN),
            gridX = 1.6f,
            gridY = 0f,
            entrances = listOf("Decatur St SE"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Martin Luther King Jr. National Historical Park", "Oakland Cemetery"),
            neighborhoodInfo = "Elevated concrete viaduct station showcasing panoramic views of Atlanta's historic Oakland Cemetery and MLK historic district."
        ),
        Station(
            id = "INMAN_PARK",
            name = "Inman Park / Reynoldstown",
            lines = listOf(RailLineColor.BLUE, RailLineColor.GREEN),
            gridX = 2.4f,
            gridY = 0f,
            entrances = listOf("Dekalb Ave NE", "Seaboard Ave"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = listOf("Route 4"),
            nearbyDestinations = listOf("Atlanta BeltLine Eastside Trail", "Krog Street Market", "Inman Park Historic District"),
            neighborhoodInfo = "Dividing two historic, high-pedestrian districts, this beautifully renovated at-grade station offers direct access to the BeltLine and Krog Street."
        ),
        Station(
            id = "EDGEWOOD_CANDLER",
            name = "Edgewood / Candler Park",
            lines = listOf(RailLineColor.BLUE, RailLineColor.GREEN),
            gridX = 3.2f,
            gridY = 0f,
            entrances = listOf("Dekalb Ave NE"),
            elevatorsCount = 1,
            escalatorsCount = 2,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Candler Park", "Edgewood Retail District"),
            neighborhoodInfo = "The easternmost split station where the Green Line terminates, surrounded by leafy residential streets and parks."
        ),
        Station(
            id = "EAST_LAKE",
            name = "East Lake",
            lines = listOf(RailLineColor.BLUE),
            gridX = 4.0f,
            gridY = 0f,
            entrances = listOf("College Ave SE"),
            elevatorsCount = 1,
            escalatorsCount = 2,
            busConnections = emptyList(),
            nearbyDestinations = listOf("East Lake Golf Club", "Agnes Scott College"),
            neighborhoodInfo = "Quiet at-grade station nestled under tall Atlanta pines, serving the peaceful historic East Lake neighborhood."
        ),
        Station(
            id = "DECATUR",
            name = "Decatur",
            lines = listOf(RailLineColor.BLUE),
            gridX = 4.8f,
            gridY = 0f,
            entrances = listOf("Decatur Square NW", "Church St NW"),
            elevatorsCount = 2,
            escalatorsCount = 4,
            busConnections = listOf("Route 15", "Route 123"),
            nearbyDestinations = listOf("Decatur Square", "DeKalb County Courthouse", "Agnes Scott College"),
            neighborhoodInfo = "Sub-surface station directly venting into Decatur Square, surrounded by bustling cafes, booksellers, and boutique retail."
        ),
        Station(
            id = "AVONDALE",
            name = "Avondale",
            lines = listOf(RailLineColor.BLUE),
            gridX = 5.6f,
            gridY = 0f,
            entrances = listOf("East College Ave"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = listOf("Route 75", "Route 114"),
            nearbyDestinations = listOf("Historic Avondale Estates", "MARTA Avondale Yard"),
            neighborhoodInfo = "Massive commuter hub with an active maintenance facility nearby. Connects directly to Tudor-style Avondale Estates."
        ),
        Station(
            id = "KENSINGTON",
            name = "Kensington",
            lines = listOf(RailLineColor.BLUE),
            gridX = 6.4f,
            gridY = 0f,
            entrances = listOf("Memorial Dr"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = listOf("Route 115", "Route 119"),
            nearbyDestinations = listOf("DeKalb County Government Complex"),
            neighborhoodInfo = "Suburban commuter platform featuring a prominent architectural concrete canopy."
        ),
        Station(
            id = "INDIAN_CREEK",
            name = "Indian Creek",
            lines = listOf(RailLineColor.BLUE),
            gridX = 7.2f,
            gridY = 0f,
            entrances = listOf("Redan Rd"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = listOf("Route 111", "Route 116"),
            nearbyDestinations = listOf("Indian Creek Trail", "Wade Walker Park"),
            neighborhoodInfo = "The absolute easternmost terminal of the Blue Line, nestled next to Interstate 285, featuring a large commuter parking footprint."
        ),
        // Blue / Green West Line
        Station(
            id = "DOME_GWCC",
            name = "Dome/GWCC/Philips/CNN",
            lines = listOf(RailLineColor.BLUE, RailLineColor.GREEN),
            gridX = -0.8f,
            gridY = 0f,
            entrances = listOf("Mitchell St SW", "Centennial Olympic Park Dr NW"),
            elevatorsCount = 3,
            escalatorsCount = 6,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Mercedes-Benz Stadium", "Georgia World Congress Center", "State Farm Arena"),
            neighborhoodInfo = "High-capacity event-focused station designed to swallow and safely guide crowd surges of up to 70,000 sports fans in minutes."
        ),
        Station(
            id = "VINE_CITY",
            name = "Vine City",
            lines = listOf(RailLineColor.BLUE, RailLineColor.GREEN),
            gridX = -1.6f,
            gridY = 0f,
            entrances = listOf("Rhodes St NW"),
            elevatorsCount = 1,
            escalatorsCount = 2,
            busConnections = emptyList(),
            nearbyDestinations = listOf("Rodney Cook Sr. Park", "Morris Brown College"),
            neighborhoodInfo = "A vital historical community node situated in historic Vine City, serving local residents and universities."
        ),
        Station(
            id = "ASHBY",
            name = "Ashby",
            lines = listOf(RailLineColor.BLUE, RailLineColor.GREEN),
            gridX = -2.4f,
            gridY = 0f,
            entrances = listOf("Joseph E. Lowery Blvd NW"),
            elevatorsCount = 2,
            escalatorsCount = 2,
            busConnections = listOf("Route 68"),
            nearbyDestinations = listOf("Atlanta University Center Campus", "Ashby Park"),
            neighborhoodInfo = "Underground split-platform junction where the Green Line branches off towards Bankhead."
        ),
        Station(
            id = "WEST_LAKE",
            name = "West Lake",
            lines = listOf(RailLineColor.BLUE),
            gridX = -3.2f,
            gridY = 0f,
            entrances = listOf("Anderson Ave NW"),
            elevatorsCount = 1,
            escalatorsCount = 2,
            busConnections = emptyList(),
            nearbyDestinations = listOf("West Lake Park"),
            neighborhoodInfo = "Sleek modernist outdoor station serving the tight-knit residential communities of West Lake."
        ),
        Station(
            id = "HE_HOLMES",
            name = "Hamilton E. Holmes",
            lines = listOf(RailLineColor.BLUE),
            gridX = -4.0f,
            gridY = 0f,
            entrances = listOf("Hamilton E Holmes Dr NW"),
            elevatorsCount = 3,
            escalatorsCount = 4,
            busConnections = listOf("Route 3", "Route 201", "Route 153"),
            nearbyDestinations = listOf("Holmes Park & Ride", "I-20 Interchange Area"),
            neighborhoodInfo = "The westernmost terminal of the Blue Line, a major transfer hub connecting direct bus routes to South-West Atlanta."
        ),
        // Green Line Branch
        Station(
            id = "BANKHEAD",
            name = "Bankhead",
            lines = listOf(RailLineColor.GREEN),
            gridX = -3.0f,
            gridY = -0.8f,
            entrances = listOf("Donald Lee Hollowell Pkwy NW"),
            elevatorsCount = 1,
            escalatorsCount = 2,
            busConnections = listOf("Route 26", "Route 50"),
            nearbyDestinations = listOf("Proctor Creek Greenway", "Westside Park at Bellwood Quarry"),
            neighborhoodInfo = "Elevated terminal station serving Bankhead, recently expanded to accommodate longer modern rail cars."
        )
    )

    // Maps station ID to object for rapid lookup
    val stationMap = stations.associateBy { it.id }

    // --- LANDMARKS / PLACE PLACES IN ATLANTA ---
    val landmarks = listOf(
        Landmark(
            name = "Hartsfield-Jackson International Airport",
            district = "College Park",
            description = "The world's most efficient passenger hub, fully linked directly via MARTA Rail.",
            nearestStationId = "AIRPORT",
            walkingMinutes = 1,
            category = "HISTORIC" // Using categories: "STADIUM", "ARTS", "PARK", "SHOPPING", "HISTORIC"
        ),
        Landmark(
            name = "Piedmont Park",
            district = "Midtown",
            description = "Atlanta's green jewel, hosting expansive lawns, trees, and beautiful skyline vistas.",
            nearestStationId = "MIDTOWN",
            walkingMinutes = 10,
            category = "PARK"
        ),
        Landmark(
            name = "Mercedes-Benz Stadium",
            district = "Downtown",
            description = "Home of the Falcons and Atlanta United, recognizable by its pinwheel retractable roof.",
            nearestStationId = "DOME_GWCC",
            walkingMinutes = 4,
            category = "STADIUM"
        ),
        Landmark(
            name = "Ponce City Market",
            district = "Old Fourth Ward",
            description = "Historically a Sears building, now a bustling, premium food hall and creative retail complex.",
            nearestStationId = "NORTH_AVENUE",
            walkingMinutes = 15,
            category = "SHOPPING"
        ),
        Landmark(
            name = "High Museum of Art",
            district = "Midtown",
            description = "Stunning white enamel architecture housing premier fine art collections.",
            nearestStationId = "ARTS_CENTER",
            walkingMinutes = 2,
            category = "ARTS"
        ),
        Landmark(
            name = "Centennial Olympic Park",
            district = "Downtown",
            description = "Built for the 1996 Olympic games, now a sprawling downtown park surrounded by attractions.",
            nearestStationId = "PEACHTREE_CENTER",
            walkingMinutes = 6,
            category = "PARK"
        ),
        Landmark(
            name = "MLK Historic Site",
            district = "Sweet Auburn",
            description = "Preserving the birthplace, church, and resting place of Dr. Martin Luther King, Jr.",
            nearestStationId = "KING_MEMORIAL",
            walkingMinutes = 8,
            category = "HISTORIC"
        ),
        Landmark(
            name = "Decatur Square",
            district = "Decatur",
            description = "Pedestrian-friendly town square known for local dining, independent booksellers, and community festivals.",
            nearestStationId = "DECATUR",
            walkingMinutes = 1,
            category = "SHOPPING"
        ),
        Landmark(
            name = "Buckhead Financial District",
            district = "Buckhead",
            description = "Soaring towers, premium hotels, and fine dining at the center of Buckhead.",
            nearestStationId = "BUCKHEAD",
            walkingMinutes = 3,
            category = "SHOPPING"
        ),
        Landmark(
            name = "Krog Street Market",
            district = "Inman Park",
            description = "A compact, bustling food hall built in an old steel foundry right off the BeltLine.",
            nearestStationId = "INMAN_PARK",
            walkingMinutes = 6,
            category = "SHOPPING"
        )
    )

    // --- DIJKSTRA GRAPH BUILDER & PATH ROUTING ---

    data class Node(
        val id: String,
        val label: String,
        val type: NodeType
    )

    enum class NodeType {
        STATION, LANDMARK, BUS_STOP
    }

    data class Edge(
        val from: String,
        val to: String,
        val weightMinutes: Int,
        val mode: TransitMode,
        val lineName: String,
        val color: RailLineColor?,
        val stopsInBetween: List<String> = emptyList()
    )

    // Adjacency list representation
    private val adjList = mutableMapOf<String, MutableList<Edge>>()

    init {
        buildRoutingGraph()
    }

    private fun buildRoutingGraph() {
        // 1. Add Rail Links between adjacent stations (Red, Gold, Blue, Green)
        
        // --- RED/GOLD NORTH SHARED CORE ---
        // Five Points <-> Peachtree Center (2 min)
        addRailEdge("FIVE_POINTS", "PEACHTREE_CENTER", 2, "Red/Gold Line", RailLineColor.RED)
        // Peachtree Center <-> Civic Center (1 min)
        addRailEdge("PEACHTREE_CENTER", "CIVIC_CENTER", 2, "Red/Gold Line", RailLineColor.RED)
        // Civic Center <-> North Avenue (2 min)
        addRailEdge("CIVIC_CENTER", "NORTH_AVENUE", 2, "Red/Gold Line", RailLineColor.RED)
        // North Avenue <-> Midtown (2 min)
        addRailEdge("NORTH_AVENUE", "MIDTOWN", 2, "Red/Gold Line", RailLineColor.RED)
        // Midtown <-> Arts Center (2 min)
        addRailEdge("MIDTOWN", "ARTS_CENTER", 2, "Red/Gold Line", RailLineColor.RED)
        // Arts Center <-> Lindbergh Center (4 min)
        addRailEdge("ARTS_CENTER", "LINDBERGH", 4, "Red/Gold Line", RailLineColor.RED)

        // --- RED LINE NORTH BRANCH ---
        // Lindbergh <-> Buckhead (4 min)
        addRailEdge("LINDBERGH", "BUCKHEAD", 4, "Red Line", RailLineColor.RED)
        // Buckhead <-> Medical Center (4 min)
        addRailEdge("BUCKHEAD", "MEDICAL_CENTER", 4, "Red Line", RailLineColor.RED)
        // Medical Center <-> Dunwoody (2 min)
        addRailEdge("MEDICAL_CENTER", "DUNWOODY", 2, "Red Line", RailLineColor.RED)
        // Dunwoody <-> Sandy Springs (3 min)
        addRailEdge("DUNWOODY", "SANDY_SPRINGS", 3, "Red Line", RailLineColor.RED)
        // Sandy Springs <-> North Springs (3 min)
        addRailEdge("SANDY_SPRINGS", "NORTH_SPRINGS", 3, "Red Line", RailLineColor.RED)

        // --- GOLD LINE NORTH BRANCH ---
        // Lindbergh <-> Lenox (3 min)
        addRailEdge("LINDBERGH", "LENOX", 3, "Gold Line", RailLineColor.GOLD)
        // Lenox <-> Brookhaven (3 min)
        addRailEdge("LENOX", "BROOKHAVEN", 3, "Gold Line", RailLineColor.GOLD)
        // Brookhaven <-> Chamblee (3 min)
        addRailEdge("BROOKHAVEN", "CHAMBLEE", 3, "Gold Line", RailLineColor.GOLD)
        // Chamblee <-> Doraville (4 min)
        addRailEdge("CHAMBLEE", "DORAVILLE", 4, "Gold Line", RailLineColor.GOLD)

        // --- RED/GOLD SOUTH SHARED ---
        // Five Points <-> Garnett (2 min)
        addRailEdge("FIVE_POINTS", "GARNETT", 2, "Red/Gold Line", RailLineColor.RED)
        // Garnett <-> West End (2 min)
        addRailEdge("GARNETT", "WEST_END", 2, "Red/Gold Line", RailLineColor.RED)
        // West End <-> Oakland City (3 min)
        addRailEdge("WEST_END", "OAKLAND_CITY", 3, "Red/Gold Line", RailLineColor.RED)
        // Oakland City <-> Lakewood (2 min)
        addRailEdge("OAKLAND_CITY", "LAKEWOOD", 2, "Red/Gold Line", RailLineColor.RED)
        // Lakewood <-> East Point (3 min)
        addRailEdge("LAKEWOOD", "EAST_POINT", 3, "Red/Gold Line", RailLineColor.RED)
        // East Point <-> College Park (3 min)
        addRailEdge("EAST_POINT", "COLLEGE_PARK", 3, "Red/Gold Line", RailLineColor.RED)
        // College Park <-> Airport (3 min)
        addRailEdge("COLLEGE_PARK", "AIRPORT", 4, "Red/Gold Line", RailLineColor.RED)

        // --- BLUE/GREEN EAST SHARED CORE ---
        // Five Points <-> Georgia State (2 min)
        addRailEdge("FIVE_POINTS", "GEORGIA_STATE", 2, "Blue/Green Line", RailLineColor.BLUE)
        // Georgia State <-> King Memorial (2 min)
        addRailEdge("GEORGIA_STATE", "KING_MEMORIAL", 2, "Blue/Green Line", RailLineColor.BLUE)
        // King Memorial <-> Inman Park (2 min)
        addRailEdge("KING_MEMORIAL", "INMAN_PARK", 2, "Blue/Green Line", RailLineColor.BLUE)
        // Inman Park <-> Edgewood/Candler (2 min)
        addRailEdge("INMAN_PARK", "EDGEWOOD_CANDLER", 2, "Blue/Green Line", RailLineColor.BLUE)

        // --- BLUE LINE EAST BRANCH ---
        // Edgewood/Candler <-> East Lake (2 min)
        addRailEdge("EDGEWOOD_CANDLER", "EAST_LAKE", 2, "Blue Line", RailLineColor.BLUE)
        // East Lake <-> Decatur (2 min)
        addRailEdge("EAST_LAKE", "DECATUR", 2, "Blue Line", RailLineColor.BLUE)
        // Decatur <-> Avondale (2 min)
        addRailEdge("DECATUR", "AVONDALE", 2, "Blue Line", RailLineColor.BLUE)
        // Avondale <-> Kensington (3 min)
        addRailEdge("AVONDALE", "KENSINGTON", 3, "Blue Line", RailLineColor.BLUE)
        // Kensington <-> Indian Creek (3 min)
        addRailEdge("KENSINGTON", "INDIAN_CREEK", 3, "Blue Line", RailLineColor.BLUE)

        // --- BLUE/GREEN WEST SHARED ---
        // Five Points <-> Dome/GWCC (2 min)
        addRailEdge("FIVE_POINTS", "DOME_GWCC", 2, "Blue/Green Line", RailLineColor.BLUE)
        // Dome/GWCC <-> Vine City (1 min)
        addRailEdge("DOME_GWCC", "VINE_CITY", 1, "Blue/Green Line", RailLineColor.BLUE)
        // Vine City <-> Ashby (2 min)
        addRailEdge("VINE_CITY", "ASHBY", 2, "Blue/Green Line", RailLineColor.BLUE)

        // --- BLUE LINE WEST BRANCH ---
        // Ashby <-> West Lake (3 min)
        addRailEdge("ASHBY", "WEST_LAKE", 3, "Blue Line", RailLineColor.BLUE)
        // West Lake <-> HE Holmes (3 min)
        addRailEdge("WEST_LAKE", "HE_HOLMES", 3, "Blue Line", RailLineColor.BLUE)

        // --- GREEN LINE WEST BRANCH ---
        // Ashby <-> Bankhead (4 min)
        addRailEdge("ASHBY", "BANKHEAD", 4, "Green Line", RailLineColor.GREEN)

        // 2. Add Landmark <-> Nearest Station Walking Edges
        landmarks.forEach { lm ->
            addWalkEdge(lm.name, lm.nearestStationId, lm.walkingMinutes, "Walk")
        }

        // 3. Add Atlanta Streetcar Loop (12 stops, connects to Peachtree Center & King Memorial)
        // Model the streetcar loop as a continuous loop edge from PEACHTREE_CENTER <-> KING_MEMORIAL
        // In the real system, streetcar is a separate mode with $1 fare.
        addStreetcarEdge("PEACHTREE_CENTER", "KING_MEMORIAL", 6, "Atlanta Streetcar", listOf("Centennial Park", "Sweet Auburn Market"))
        addStreetcarEdge("KING_MEMORIAL", "PEACHTREE_CENTER", 6, "Atlanta Streetcar", listOf("Dobbs Plaza", "Park Place"))

        // 4. Add Next-Gen Bus Corridors
        // ROUTE 15: Clifton Rd / Candler Rd (Connects Decatur to East Lake, Inman Park or nearby)
        addBusEdge("DECATUR", "INMAN_PARK", 12, "Bus Route 15", BusType.LOCAL, listOf("Clifton Rd", "Candler Rd"))
        // ROUTE 3: MLK Dr (Connects HE Holmes to Five Points)
        addBusEdge("HE_HOLMES", "FIVE_POINTS", 16, "Bus Route 3", BusType.LOCAL, listOf("MLK Jr Dr", "Ashby Stop"))
        // ROUTE 110: "The Peach" (Buckhead to Midtown and Peachtree Center)
        addBusEdge("BUCKHEAD", "MIDTOWN", 15, "Bus Route 110", BusType.FREQUENT, listOf("Peachtree Rd NE", "Piedmont Hospital"))
        addBusEdge("MIDTOWN", "PEACHTREE_CENTER", 10, "Bus Route 110", BusType.FREQUENT, listOf("Peachtree St NE"))
        // Summerhill BRT (Rapid 101): High frequency, separate lanes, connects Five Points to South Atlanta
        addBusEdge("FIVE_POINTS", "OAKLAND_CITY", 8, "Rapid 101 BRT", BusType.RAPID, listOf("Summerhill Stadium", "Capitol Ave"))
    }

    private fun addRailEdge(from: String, to: String, mins: Int, lineName: String, color: RailLineColor) {
        addEdge(Edge(from, to, mins, TransitMode.RAIL, lineName, color))
        addEdge(Edge(to, from, mins, TransitMode.RAIL, lineName, color))
    }

    private fun addWalkEdge(from: String, to: String, mins: Int, name: String) {
        addEdge(Edge(from, to, mins, TransitMode.WALK, name, null))
        addEdge(Edge(to, from, mins, TransitMode.WALK, name, null))
    }

    private fun addStreetcarEdge(from: String, to: String, mins: Int, name: String, stops: List<String>) {
        addEdge(Edge(from, to, mins, TransitMode.STREETCAR, name, RailLineColor.STREETCAR_GRAY, stops))
    }

    private fun addBusEdge(from: String, to: String, mins: Int, name: String, type: BusType, stops: List<String>) {
        addEdge(Edge(from, to, mins, TransitMode.BUS, name, null, stops))
        addEdge(Edge(to, from, mins, TransitMode.BUS, name, null, stops))
    }

    private fun addEdge(edge: Edge) {
        adjList.getOrPut(edge.from) { mutableListOf() }.add(edge)
    }

    // --- DIJKSTRA CALCULATION ---

    data class PathNode(
        val nodeId: String,
        val cost: Int,
        val edge: Edge?,
        val parent: PathNode?
    ) : Comparable<PathNode> {
        override fun compareTo(other: PathNode): Int = this.cost.compareTo(other.cost)
    }

    fun findJourney(
        originName: String,
        destinationName: String,
        accessibleOnly: Boolean = false,
        weatherDelayMinutes: Int = 0
    ): Journey? {
        val startId = findNodeIdByName(originName)
        val endId = findNodeIdByName(destinationName)

        if (startId == null || endId == null) return null

        val pq = PriorityQueue<PathNode>()
        val minCosts = mutableMapOf<String, Int>()

        pq.add(PathNode(startId, 0, null, null))
        minCosts[startId] = 0

        var targetNode: PathNode? = null

        while (pq.isNotEmpty()) {
            val curr = pq.poll()

            if (curr.nodeId == endId) {
                targetNode = curr
                break
            }

            if (curr.cost > (minCosts[curr.nodeId] ?: Int.MAX_VALUE)) continue

            val edges = adjList[curr.nodeId] ?: emptyList()
            for (edge in edges) {
                // If accessibility is requested, filter out non-accessible stations (just for safety)
                if (accessibleOnly && edge.mode == TransitMode.WALK && edge.weightMinutes > 10) {
                    // Filter out long walking connections if requested
                    continue
                }

                // If station-specific accessibility issues occur, we can block that route here too.

                // Calculate edge weight
                var edgeWeight = edge.weightMinutes
                if (edge.mode == TransitMode.WALK) {
                    // Apply weather penalty on walking
                    edgeWeight += weatherDelayMinutes
                }

                val newCost = curr.cost + edgeWeight

                if (newCost < (minCosts[edge.to] ?: Int.MAX_VALUE)) {
                    minCosts[edge.to] = newCost
                    pq.add(PathNode(edge.to, newCost, edge, curr))
                }
            }
        }

        if (targetNode == null) return null

        // Reconstruct path
        val legs = mutableListOf<JourneyLeg>()
        var curr: PathNode? = targetNode
        while (curr != null) {
            val edge = curr.edge
            if (edge != null) {
                val originLocName = getNodeLabel(edge.from)
                val destLocName = getNodeLabel(edge.to)
                
                var boardInfo: String? = null
                if (edge.mode == TransitMode.RAIL) {
                    boardInfo = if (edge.to == "AIRPORT" || edge.from == "COLLEGE_PARK") "Southbound Platform" else "Platform B"
                }

                legs.add(
                    JourneyLeg(
                        mode = edge.mode,
                        lineName = edge.lineName,
                        lineColor = edge.color,
                        originStationName = originLocName,
                        destinationStationName = destLocName,
                        numStops = if (edge.stopsInBetween.isEmpty()) 1 else edge.stopsInBetween.size + 1,
                        durationMinutes = edge.weightMinutes + (if (edge.mode == TransitMode.WALK) weatherDelayMinutes else 0),
                        instruction = when (edge.mode) {
                            TransitMode.RAIL -> "Board ${edge.lineName} toward ${getLineDirection(edge.to, edge.lineName)}"
                            TransitMode.BUS -> "Take ${edge.lineName} (${edge.stopsInBetween.firstOrNull() ?: "Direct"})"
                            TransitMode.STREETCAR -> "Board the ${edge.lineName} Downtown Loop"
                            TransitMode.WALK -> "Walk ${edge.weightMinutes + weatherDelayMinutes} min to ${destLocName}"
                        },
                        boardingInfo = boardInfo,
                        stopList = edge.stopsInBetween
                    )
                )
            }
            curr = curr.parent
        }

        legs.reverse()

        // Combine adjacent walking legs if any
        val totalMinutes = legs.sumOf { it.durationMinutes }
        val walkingMinutes = legs.filter { it.mode == TransitMode.WALK }.sumOf { it.durationMinutes }
        val transfers = (legs.filter { it.mode != TransitMode.WALK }.size - 1).coerceAtLeast(0)

        // Fare System logic:
        // MARTA rail/bus/Rapid standard fare is $2.50 with up to 4 free transfers within 3 hours.
        // Streetcar is $1 separate fare (does not transfer to rail).
        var fare = 0.0
        var transitLegsCount = 0
        var hasStreetcar = false

        legs.forEach { leg ->
            if (leg.mode == TransitMode.RAIL || leg.mode == TransitMode.BUS) {
                transitLegsCount++
            } else if (leg.mode == TransitMode.STREETCAR) {
                hasStreetcar = true
            }
        }

        if (transitLegsCount > 0) {
            // Under 4 transfers, it's just one standard fare $2.50
            fare += 2.50
        }
        if (hasStreetcar) {
            // Streetcar is separate $1.00 regular one-way fare
            fare += 1.00
        }

        return Journey(
            origin = originName,
            destination = destinationName,
            legs = legs,
            totalDurationMinutes = totalMinutes,
            totalTransfers = transfers,
            totalWalkingMinutes = walkingMinutes,
            fareAmount = fare,
            isAccessible = !accessibleOnly || legs.none { it.mode == TransitMode.WALK && it.durationMinutes > 8 }
        )
    }

    private fun findNodeIdByName(name: String): String? {
        val s = stations.find { it.name.lowercase() == name.lowercase() }
        if (s != null) return s.id
        val lm = landmarks.find { it.name.lowercase() == name.lowercase() }
        if (lm != null) return lm.name
        return null
    }

    private fun getNodeLabel(id: String): String {
        val s = stationMap[id]
        if (s != null) return s.name
        return id
    }

    private fun getLineDirection(toId: String, lineName: String): String {
        return when {
            toId == "AIRPORT" -> "Airport"
            toId == "NORTH_SPRINGS" -> "North Springs"
            toId == "DORAVILLE" -> "Doraville"
            toId == "INDIAN_CREEK" -> "Indian Creek"
            toId == "HE_HOLMES" -> "Hamilton E. Holmes"
            toId == "BANKHEAD" -> "Bankhead"
            lineName.contains("Red") -> "North Springs / Airport"
            lineName.contains("Gold") -> "Doraville / Airport"
            lineName.contains("Blue") -> "Hamilton E. Holmes / Indian Creek"
            lineName.contains("Green") -> "Bankhead / Edgewood"
            else -> "City Center"
        }
    }
}
