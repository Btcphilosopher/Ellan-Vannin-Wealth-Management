package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.routing.TransitData
import com.example.simulation.TransitSimulation
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface TapState {
    object Idle : TapState
    object Proximity : TapState
    object Tapping : TapState
    data class Accepted(val amount: Double, val remainingTransferText: String) : TapState
}

class TransitViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = TransitRepository(database.breezeDao())

    // --- TIME TICKER & VEHICLES ---
    private val _simulationTicks = MutableStateFlow(0L)
    val simulationTicks: StateFlow<Long> = _simulationTicks.asStateFlow()

    private var tickerJob: Job? = null

    // --- VIEW SETTINGS & CONTROL ---
    val systemSettings: StateFlow<SystemSettings> = repository.systemSettings
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = SystemSettings()
        )

    val breezeAccount: StateFlow<BreezeAccount> = repository.breezeAccount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = BreezeAccount()
        )

    val tripHistory: StateFlow<List<TripHistory>> = repository.tripHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val savedJourneys: StateFlow<List<SavedJourney>> = repository.savedJourneys
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- LIVE SIMULATED DATA ---
    val weatherState: StateFlow<WeatherState> = systemSettings
        .map { TransitSimulation.getWeatherState(it.activeScenarioName) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = TransitSimulation.getWeatherState("NORMAL")
        )

    val activeIncidents: StateFlow<List<Incident>> = systemSettings
        .map { TransitSimulation.getIncidents(it.activeScenarioName) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val simulatedVehicles: StateFlow<List<Vehicle>> = combine(systemSettings, _simulationTicks) { settings, ticks ->
        TransitSimulation.getVehicles(settings.activeScenarioName, ticks * 1000L) // 1 tick = 1 second (1000ms)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // --- UI FLOW STATE ---
    val searchQuery = MutableStateFlow("")
    val isSearching = MutableStateFlow(false)

    val searchResults: StateFlow<List<Any>> = combine(searchQuery, systemSettings) { query, settings ->
        if (query.isBlank()) {
            emptyList()
        } else {
            val matchedStations = TransitData.stations.filter {
                it.name.contains(query, ignoreCase = true) || 
                it.lines.any { l -> l.name.contains(query, ignoreCase = true) }
            }
            val matchedLandmarks = TransitData.landmarks.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.district.contains(query, ignoreCase = true) ||
                it.category.contains(query, ignoreCase = true)
            }
            matchedStations + matchedLandmarks
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Selection Details
    val selectedStation = MutableStateFlow<Station?>(null)
    val selectedLine = MutableStateFlow<RailLineColor?>(null)

    // Route Planner State
    val routeOrigin = MutableStateFlow("")
    val routeDestination = MutableStateFlow("")
    val calculatedJourney = MutableStateFlow<Journey?>(null)

    // Journey Progression Mode
    val isJourneyActive = MutableStateFlow(false)
    val activeLegIndex = MutableStateFlow(0)

    // Tap Animation & Fare
    val tapState = MutableStateFlow<TapState>(TapState.Idle)
    val remainingTransferTimeSeconds = MutableStateFlow(0) // 3 hours limit = 10800

    init {
        startTicker()
        seedDefaultTrips()
    }

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (isActive) {
                _simulationTicks.value += 1
                if (remainingTransferTimeSeconds.value > 0) {
                    remainingTransferTimeSeconds.value -= 1
                }
                delay(1000)
            }
        }
    }

    private fun seedDefaultTrips() {
        viewModelScope.launch {
            repository.tripHistory.firstOrNull()?.let { list ->
                if (list.isEmpty()) {
                    repository.chargeFare(2.50, "Airport", "Midtown", "Gold Line", false)
                    repository.chargeFare(0.00, "Midtown", "Five Points", "Red Line", true)
                }
            }
        }
    }

    // --- ACTIONS ---

    fun changeScenario(scenario: String) {
        viewModelScope.launch {
            repository.updateScenario(scenario)
        }
    }

    fun toggleAccessibility(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateAccessibility(enabled)
            // Recalculate route if matching
            recalculateActiveRoute()
        }
    }

    fun toggleOfflineMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateOfflineMode(enabled)
        }
    }

    fun calculateRoute(origin: String, destination: String) {
        routeOrigin.value = origin
        routeDestination.value = destination
        
        viewModelScope.launch {
            val settings = systemSettings.value
            val weather = weatherState.value
            val journey = TransitData.findJourney(
                originName = origin,
                destinationName = destination,
                accessibleOnly = settings.isAccessibleOnly,
                weatherDelayMinutes = weather.walkingDelayModifierMinutes
            )
            calculatedJourney.value = journey
        }
    }

    private fun recalculateActiveRoute() {
        val o = routeOrigin.value
        val d = routeDestination.value
        if (o.isNotBlank() && d.isNotBlank()) {
            calculateRoute(o, d)
        }
    }

    fun startJourney() {
        if (calculatedJourney.value != null) {
            isJourneyActive.value = true
            activeLegIndex.value = 0
        }
    }

    fun endJourney() {
        isJourneyActive.value = false
        calculatedJourney.value = null
        routeOrigin.value = ""
        routeDestination.value = ""
    }

    fun advanceLeg() {
        val journey = calculatedJourney.value ?: return
        if (activeLegIndex.value < journey.legs.size - 1) {
            activeLegIndex.value += 1
        } else {
            // End trip & Charge fare or log transfer
            viewModelScope.launch {
                val hasActiveTransfer = remainingTransferTimeSeconds.value > 0
                val fare = journey.fareAmount
                val routeLabel = journey.legs.firstOrNull()?.lineName ?: "Transit.OS"
                repository.chargeFare(
                    amount = fare,
                    origin = journey.origin,
                    destination = journey.destination,
                    routeName = routeLabel,
                    isTransfer = hasActiveTransfer
                )
                if (!hasActiveTransfer) {
                    // Activate 3 hour transfer window (10800 seconds)
                    remainingTransferTimeSeconds.value = 10800
                }
                endJourney()
            }
        }
    }

    fun triggerTapPayment(method: PaymentMethod) {
        viewModelScope.launch {
            tapState.value = TapState.Proximity
            delay(800)
            tapState.value = TapState.Tapping
            delay(1200)

            val currentAccount = breezeAccount.value
            val hasActiveTransfer = remainingTransferTimeSeconds.value > 0
            
            // Calculate charge
            val charge = if (hasActiveTransfer) 0.00 else 2.50
            if (method == PaymentMethod.BREEZE_CARD || method == PaymentMethod.BREEZE_APP) {
                // Charge local card
                if (currentAccount.balance >= charge) {
                    repository.chargeFare(charge, "Five Points", "Airport", "MARTA Network", hasActiveTransfer)
                    if (!hasActiveTransfer) {
                        remainingTransferTimeSeconds.value = 10800
                    }
                    val hrs = remainingTransferTimeSeconds.value / 3600
                    val mins = (remainingTransferTimeSeconds.value % 3600) / 60
                    val text = if (hasActiveTransfer) "TRANSFER ACTIVE ($hrs hr $mins min remaining)" else "TRANSFER WINDOW OPEN"
                    tapState.value = TapState.Accepted(charge, text)
                } else {
                    // Out of funds, add auto-load simulation if enabled
                    if (currentAccount.autoloadOn) {
                        repository.addFunds(currentAccount.autoloadAmount)
                        repository.chargeFare(charge, "Five Points", "Airport", "MARTA Network", hasActiveTransfer)
                        if (!hasActiveTransfer) {
                            remainingTransferTimeSeconds.value = 10800
                        }
                        val hrs = remainingTransferTimeSeconds.value / 3600
                        val mins = (remainingTransferTimeSeconds.value % 3600) / 60
                        tapState.value = TapState.Accepted(charge, "AUTOLOAD TRIGGERED: +$${currentAccount.autoloadAmount}")
                    } else {
                        tapState.value = TapState.Accepted(0.0, "DECLINED: Insufficient Balance")
                    }
                }
            } else {
                // Bank/mobile wallets are assumed always accepted
                repository.chargeFare(charge, "Five Points", "Midtown", "MARTA Network", hasActiveTransfer)
                if (!hasActiveTransfer) {
                    remainingTransferTimeSeconds.value = 10800
                }
                val hrs = remainingTransferTimeSeconds.value / 3600
                val mins = (remainingTransferTimeSeconds.value % 3600) / 60
                val text = if (hasActiveTransfer) "TRANSFER ACTIVE ($hrs hr $mins min remaining)" else "ACCEPTED - DEVICE WALLET"
                tapState.value = TapState.Accepted(charge, text)
            }
        }
    }

    fun resetTap() {
        tapState.value = TapState.Idle
    }

    fun addFundsToBreeze(amount: Double) {
        viewModelScope.launch {
            repository.addFunds(amount)
        }
    }

    fun toggleAutoloadState(enabled: Boolean, amount: Double = 20.0) {
        viewModelScope.launch {
            repository.toggleAutoload(enabled, amount)
        }
    }

    fun saveJourneyToFavorites(origin: String, destination: String) {
        viewModelScope.launch {
            repository.saveJourney(origin, destination)
        }
    }

    fun deleteJourneyFromFavorites(id: String) {
        viewModelScope.launch {
            repository.deleteJourney(id)
        }
    }

    fun selectStation(station: Station?) {
        selectedStation.value = station
        selectedLine.value = null
    }

    fun selectLine(color: RailLineColor?) {
        selectedLine.value = color
        selectedStation.value = null
    }
}
