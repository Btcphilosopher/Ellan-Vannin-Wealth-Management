package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- SIGNATURE ATLANTA COLOUR PALETTE ---
val AtlantaGraphite = Color(0xFF121415)
val AtlantaWarmOffWhite = Color(0xFFFAF8F5)
val AtlantaConcreteGrey = Color(0xFF8E969D)
val MartaBlue = Color(0xFF0052A3)
val AtlantaRedClay = Color(0xFFBF3F1B)
val SouthernSunlight = Color(0xFFFFFDF9)

// Theme Palette Elements
val PrimaryDark = Color(0xFF0052A3)
val SecondaryDark = Color(0xFF8E969D)
val AccentClay = Color(0xFFBF3F1B)

val SurfaceDark = Color(0xFF1C1E1F)
val SurfaceLight = Color(0xFFFFFEFC)

val BackgroundDark = Color(0xFF121415)
val BackgroundLight = Color(0xFFFAF8F5)

val TextPrimaryDark = Color(0xFFF0F2F5)
val TextPrimaryLight = Color(0xFF121415)
val TextSecondaryDark = Color(0xFF8E969D)
val TextSecondaryLight = Color(0xFF5A626A)

// Rail lines colors for schematic maps and indicators
val RailColorRed = Color(0xFFE31B23)
val RailColorGold = Color(0xFFECA918)
val RailColorBlue = Color(0xFF0052A3)
val RailColorGreen = Color(0xFF238E5A)
val RailColorStreetcar = Color(0xFF6B7280)
val RailColorWalk = Color(0xFF10B981)
