package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map

class TransitRepository(private val dao: BreezeDao) {

    val breezeAccount: Flow<BreezeAccount> = dao.getBreezeAccount().map { 
        it ?: BreezeAccount().also { defaultAcc ->
            // Seed a default account if database is empty
            dao.insertBreezeAccount(defaultAcc)
        }
    }

    val tripHistory: Flow<List<TripHistory>> = dao.getTripHistory()

    val savedJourneys: Flow<List<SavedJourney>> = dao.getSavedJourneys()

    val systemSettings: Flow<SystemSettings> = dao.getSystemSettings().map {
        it ?: SystemSettings().also { defaultSettings ->
            // Seed default settings if database is empty
            dao.insertSystemSettings(defaultSettings)
        }
    }

    suspend fun addFunds(amount: Double) {
        val current = breezeAccount.firstOrNull() ?: BreezeAccount()
        val updated = current.copy(balance = current.balance + amount)
        dao.insertBreezeAccount(updated)
    }

    suspend fun chargeFare(amount: Double, origin: String, destination: String, routeName: String, isTransfer: Boolean) {
        val current = breezeAccount.firstOrNull() ?: BreezeAccount()
        val updatedBalance = if (isTransfer) current.balance else (current.balance - amount).coerceAtLeast(0.0)
        dao.insertBreezeAccount(current.copy(balance = updatedBalance))
        
        dao.insertTrip(
            TripHistory(
                origin = origin,
                destination = destination,
                fareCharged = if (isTransfer) 0.0 else amount,
                routeName = routeName,
                isTransfer = isTransfer
            )
        )
    }

    suspend fun toggleAutoload(enabled: Boolean, amount: Double = 20.00) {
        val current = breezeAccount.firstOrNull() ?: BreezeAccount()
        dao.insertBreezeAccount(current.copy(autoloadOn = enabled, autoloadAmount = amount))
    }

    suspend fun purchasePass(passName: String, price: Double) {
        val current = breezeAccount.firstOrNull() ?: BreezeAccount()
        val updatedBalance = (current.balance - price).coerceAtLeast(0.0)
        dao.insertBreezeAccount(
            current.copy(
                balance = updatedBalance,
                isPassActive = true,
                passName = passName
            )
        )
    }

    suspend fun clearHistory() {
        dao.clearTripHistory()
    }

    suspend fun saveJourney(origin: String, destination: String) {
        val id = "${origin}_to_${destination}"
        dao.insertSavedJourney(SavedJourney(id = id, originName = origin, destinationName = destination))
    }

    suspend fun deleteJourney(id: String) {
        dao.deleteSavedJourney(id)
    }

    suspend fun updateScenario(scenario: String) {
        val current = systemSettings.firstOrNull() ?: SystemSettings()
        dao.insertSystemSettings(current.copy(activeScenarioName = scenario))
    }

    suspend fun updateAccessibility(accessibleOnly: Boolean) {
        val current = systemSettings.firstOrNull() ?: SystemSettings()
        dao.insertSystemSettings(current.copy(isAccessibleOnly = accessibleOnly))
    }

    suspend fun updateOfflineMode(offline: Boolean) {
        val current = systemSettings.firstOrNull() ?: SystemSettings()
        dao.insertSystemSettings(current.copy(isOfflineMode = offline))
    }
}
