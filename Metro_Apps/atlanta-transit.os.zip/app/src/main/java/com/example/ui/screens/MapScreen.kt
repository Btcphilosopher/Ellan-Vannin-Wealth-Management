package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.TransitViewModel
import com.example.ui.components.AtlantaNetworkMap
import com.example.ui.theme.*

@Composable
fun MapScreen(
    viewModel: TransitViewModel,
    modifier: Modifier = Modifier
) {
    val vehicles by viewModel.simulatedVehicles.collectAsState()
    val selectedStation by viewModel.selectedStation.collectAsState()
    val selectedLine by viewModel.selectedLine.collectAsState()
    val settings by viewModel.systemSettings.collectAsState()
    val incidents by viewModel.activeIncidents.collectAsState()
    val weather by viewModel.weatherState.collectAsState()

    var showControlDeck by remember { mutableStateOf(true) }

    Box(modifier = modifier.fillMaxSize()) {
        // Main full screen Map
        AtlantaNetworkMap(
            vehicles = vehicles,
            selectedStation = selectedStation,
            selectedLine = selectedLine,
            onStationSelect = { viewModel.selectStation(it) },
            modifier = Modifier.fillMaxSize()
        )

        // "SIMULATION ACTIVE" Top Indicator
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.onBackground,
                contentColor = MaterialTheme.colorScheme.background
            ),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .testTag("simulation_active_badge")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(AccentClay)
                )
                Text(
                    text = "SIMULATION ENGINE ACTIVE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        // Active Weather widget
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                contentColor = MaterialTheme.colorScheme.onSurface
            ),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val weatherIcon = when (weather.type) {
                    WeatherType.CLEAR -> Icons.Filled.WbSunny
                    WeatherType.HOT -> Icons.Filled.Thermostat
                    WeatherType.HEAT_WARNING -> Icons.Filled.LocalFireDepartment
                    WeatherType.THUNDERSTORM -> Icons.Filled.Thunderstorm
                    WeatherType.HEAVY_RAIN -> Icons.Filled.Umbrella
                    else -> Icons.Filled.WbCloudy
                }
                Icon(weatherIcon, contentDescription = null, tint = MartaBlue, modifier = Modifier.size(16.dp))
                Column {
                    Text(text = weather.description, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Text(text = "${weather.temperatureFahrenheit}°F", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // Floating Control Deck Button
        FloatingActionButton(
            onClick = { showControlDeck = !showControlDeck },
            containerColor = MartaBlue,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
                .testTag("control_deck_toggle")
        ) {
            Icon(
                if (showControlDeck) Icons.Filled.VisibilityOff else Icons.Filled.Tune,
                contentDescription = "Toggle Scenario Controls"
            )
        }

        // CONTROL DECK & STATION DETAIL DRAWER (Overlay bottom panel)
        AnimatedVisibility(
            visible = showControlDeck,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 20.dp)
                .padding(start = 72.dp) // Leave space for float button
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                        .weight(1f, fill = false)
                ) {
                    if (selectedStation != null) {
                        // Station detail card inside map
                        val st = selectedStation!!
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "STATION METADATA: ${st.name.uppercase()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MartaBlue,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { viewModel.selectStation(null) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Close Detail")
                            }
                        }

                        Text(
                            text = st.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = st.neighborhoodInfo,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Real physical connectivity numbers
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("Elevators: ${st.elevatorsCount}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                Text("Escalators: ${st.escalatorsCount}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                val connectionsText = if (st.busConnections.isEmpty()) "None" else st.busConnections.joinToString()
                                Text("Bus Conns: $connectionsText", style = MaterialTheme.typography.bodyMedium)
                                Text("Streetcar Transfer: ${if (st.streetcarConnection) "Direct Available" else "No Connection"}", style = MaterialTheme.typography.bodyMedium)
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 10.dp))

                        Text(
                            text = "LIVE ESTIMATED DEPARTURES",
                            style = MaterialTheme.typography.labelSmall,
                            color = AccentClay,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )

                        // Live departures filtering by station
                        val stationVehicles = vehicles.filter { it.currentStationId == st.id || it.nextStationId == st.id }
                        if (stationVehicles.isEmpty()) {
                            Text("No immediate trains scheduled.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                        } else {
                            stationVehicles.forEach { v ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(if (v.routeName == "Red Line") RailColorRed else RailColorGold)
                                                .align(Alignment.CenterVertically)
                                        )
                                        Text(v.routeName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        Text("➔ ${v.direction}", style = MaterialTheme.typography.bodyMedium)
                                    }
                                    Text(
                                        text = "${(3..12).random()} min",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                }
                            }
                        }
                    } else {
                        // Default control deck screen
                        Text(
                            text = "ATLANTA DEMO CONTROL DECK",
                            style = MaterialTheme.typography.labelSmall,
                            color = MartaBlue,
                            fontWeight = FontWeight.Bold
                        )
                        
                        Text(
                            text = "Change the metropolitan scenario configuration to inject network delay, extreme weather, or stadium crowd surges.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Horizontally scrollable list of scenarios
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                        ) {
                            val scenarios = listOf(
                                "NORMAL" to "Normal",
                                "RUSH_HOUR" to "Rush Hour",
                                "RAIN" to "Rainy",
                                "THUNDERSTORM" to "Thunderstorm",
                                "EVENT" to "Stadium Event",
                                "MAJOR_DELAY" to "Red Line Delay",
                                "STATION_CLOSURE" to "Five Points Block"
                            )
                            scenarios.forEach { (scenId, label) ->
                                val active = settings.activeScenarioName == scenId
                                Button(
                                    onClick = { viewModel.changeScenario(scenId) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (active) MartaBlue else MaterialTheme.colorScheme.surface,
                                        contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                    ),
                                    shape = RoundedCornerShape(2.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("scenario_${scenId.lowercase()}_button")
                                ) {
                                    Text(label, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Display active incidents consequences
                        if (incidents.isNotEmpty()) {
                            Divider(modifier = Modifier.padding(vertical = 12.dp))
                            Text(
                                text = "ACTIVE NETWORK DELAYS",
                                style = MaterialTheme.typography.labelSmall,
                                color = AccentClay,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            incidents.forEach { inc ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = AccentClay.copy(alpha = 0.08f)),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(2.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(inc.description, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = AccentClay)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Re-routing: ${inc.alternatives}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                                        Text("Est. Duration: ${inc.expectedDuration}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
