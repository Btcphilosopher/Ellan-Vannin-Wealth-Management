package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RailLineColor
import com.example.data.Station
import com.example.data.TransitMode
import com.example.data.Vehicle
import com.example.routing.TransitData
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AtlantaNetworkMap(
    vehicles: List<Vehicle>,
    selectedStation: Station?,
    selectedLine: RailLineColor?,
    onStationSelect: (Station?) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    
    // Pan and Zoom offsets
    var scale by remember { mutableStateOf(1.2f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }
    
    // Smooth zoom target tracking
    LaunchedEffect(selectedStation) {
        if (selectedStation != null) {
            // Animate pan to center on the selected station
            // Convert grid coords (-7 to 7 range) to screen scale roughly
            val targetX = -selectedStation.gridX * 120f * scale
            val targetY = -selectedStation.gridY * 120f * scale
            
            // Limit coordinate changes so it centers beautifully
            animate(offsetX, targetX, animationSpec = spring()) { value, _ -> offsetX = value }
            animate(offsetY, targetY, animationSpec = spring()) { value, _ -> offsetY = value }
            animate(scale, 1.8f, animationSpec = spring()) { value, _ -> scale = value }
        }
    }

    // Interactive Pulsing for active entities
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 4f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseRadius"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("atlanta_now_canvas")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.6f, 3.5f)
                        offsetX += pan.x
                        offsetY += pan.y
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { tapOffset ->
                        // Find if user tapped close to a station
                        val centerX = size.width / 2f
                        val centerY = size.height / 2f
                        
                        var tappedStation: Station? = null
                        for (station in TransitData.stations) {
                            val stationScreenX = centerX + offsetX + (station.gridX * 120f * scale)
                            val stationScreenY = centerY + offsetY + (station.gridY * 120f * scale)
                            
                            val dist = Math.hypot(
                                (tapOffset.x - stationScreenX).toDouble(),
                                (tapOffset.y - stationScreenY).toDouble()
                            )
                            if (dist < 32f) { // tap target pixel buffer
                                tappedStation = station
                                break
                            }
                        }
                        onStationSelect(tappedStation)
                    }
                }
        ) {
            val centerX = size.width / 2f
            val centerY = size.height / 2f

            // Helpers to convert static grid (-7f..7f) to local Canvas pixels
            fun gridToPixel(x: Float, y: Float): Offset {
                return Offset(
                    x = centerX + offsetX + (x * 120f * scale),
                    y = centerY + offsetY + (y * 120f * scale)
                )
            }

            // --- DRAW BACKGROUND DISTRICT LABELS ---
            drawContext.canvas.nativeCanvas.apply {
                val paint = android.graphics.Paint().apply {
                    color = android.graphics.Color.GRAY
                    alpha = (60 * scale).toInt().coerceIn(10, 120)
                    textSize = 14f * scale
                    isAntiAlias = true
                    textAlign = android.graphics.Paint.Align.CENTER
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
                }
                
                val buckheadPos = gridToPixel(0f, -4.8f)
                drawText("BUCKHEAD", buckheadPos.x, buckheadPos.y, paint)

                val midtownPos = gridToPixel(0f, -2.1f)
                drawText("MIDTOWN", midtownPos.x, midtownPos.y, paint)

                val downtownPos = gridToPixel(-0.5f, -0.9f)
                drawText("DOWNTOWN", downtownPos.x, downtownPos.y, paint)

                val airportPos = gridToPixel(0.8f, 4.8f)
                drawText("ATL INTERNATIONAL AIRPORT", airportPos.x, airportPos.y, paint)
            }

            // --- DRAW RAIL NETWORK SCHEMATIC SHAPES ---
            
            // Red Line Path
            val redStations = TransitData.stations.filter { it.lines.contains(RailLineColor.RED) }
                .sortedBy { it.gridY } // top down
            val redPath = Path().apply {
                redStations.forEachIndexed { idx, st ->
                    val p = gridToPixel(st.gridX, st.gridY)
                    if (idx == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y)
                }
            }
            val redAlpha = if (selectedLine == null || selectedLine == RailLineColor.RED) 1f else 0.15f
            drawPath(
                path = redPath,
                color = RailColorRed.copy(alpha = redAlpha),
                style = Stroke(width = 8f * scale, pathEffect = PathEffect.cornerPathEffect(40f))
            )

            // Gold Line Path (diverges from Lindbergh to Doraville)
            val goldSharedStations = TransitData.stations.filter { it.lines.contains(RailLineColor.GOLD) && it.gridY >= -3.8f }
                .sortedBy { it.gridY }
            val goldDivergentStations = TransitData.stations.filter { it.lines.contains(RailLineColor.GOLD) && it.gridY < -3.8f }
                .sortedBy { it.gridY } // Lindbergh to Doraville
            val goldPath = Path().apply {
                // start from airport
                goldSharedStations.forEachIndexed { idx, st ->
                    val p = gridToPixel(st.gridX, st.gridY)
                    if (idx == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y)
                }
                // then branch
                goldDivergentStations.forEach { st ->
                    val p = gridToPixel(st.gridX, st.gridY)
                    lineTo(p.x, p.y)
                }
            }
            val goldAlpha = if (selectedLine == null || selectedLine == RailLineColor.GOLD) 1f else 0.15f
            drawPath(
                path = goldPath,
                color = RailColorGold.copy(alpha = goldAlpha),
                style = Stroke(width = 5f * scale, pathEffect = PathEffect.cornerPathEffect(40f))
            )

            // Blue Line Path (West to East)
            val blueStations = TransitData.stations.filter { it.lines.contains(RailLineColor.BLUE) }
                .sortedBy { it.gridX } // left to right
            val bluePath = Path().apply {
                blueStations.forEachIndexed { idx, st ->
                    val p = gridToPixel(st.gridX, st.gridY)
                    if (idx == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y)
                }
            }
            val blueAlpha = if (selectedLine == null || selectedLine == RailLineColor.BLUE) 1f else 0.15f
            drawPath(
                path = bluePath,
                color = RailColorBlue.copy(alpha = blueAlpha),
                style = Stroke(width = 8f * scale, pathEffect = PathEffect.cornerPathEffect(40f))
            )

            // Green Line Path
            val greenStations = TransitData.stations.filter { it.lines.contains(RailLineColor.GREEN) }
                .sortedBy { it.gridX }
            val greenPath = Path().apply {
                greenStations.forEachIndexed { idx, st ->
                    val p = gridToPixel(st.gridX, st.gridY)
                    if (idx == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y)
                }
            }
            val greenAlpha = if (selectedLine == null || selectedLine == RailLineColor.GREEN) 1f else 0.15f
            drawPath(
                path = greenPath,
                color = RailColorGreen.copy(alpha = greenAlpha),
                style = Stroke(width = 4f * scale, pathEffect = PathEffect.cornerPathEffect(40f))
            )

            // --- DRAW ATLANTA STREETCAR DOWNTOWN LOOP (Dashed Loop) ---
            val streetcarAlpha = if (selectedLine == null || selectedLine == RailLineColor.STREETCAR_GRAY) 0.8f else 0.15f
            val sc1 = gridToPixel(0f, -0.6f) // Peachtree center area
            val sc2 = gridToPixel(1.6f, 0f) // King Memorial area
            val streetcarRadiusX = Math.abs(sc2.x - sc1.x) * 0.45f
            val streetcarRadiusY = Math.abs(sc2.y - sc1.y) * 0.7f
            val streetcarCenter = Offset(sc1.x + (sc2.x - sc1.x) * 0.5f, sc1.y + (sc2.y - sc1.y) * 0.35f)
            
            drawCircle(
                color = RailColorStreetcar.copy(alpha = streetcarAlpha),
                radius = streetcarRadiusX,
                center = streetcarCenter,
                style = Stroke(
                    width = 3f * scale,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )
            )

            // --- DRAW STATION NODES ---
            for (station in TransitData.stations) {
                val nodePos = gridToPixel(station.gridX, station.gridY)
                val isSelected = selectedStation?.id == station.id
                
                // Dim non-focused station nodes
                val baseAlpha = if (selectedStation == null) 1f else if (isSelected) 1f else 0.4f

                // Pulsing accent for selected station
                if (isSelected) {
                    drawCircle(
                        color = AccentClay.copy(alpha = 0.3f),
                        radius = (14f + pulseRadius) * scale,
                        center = nodePos
                    )
                }

                // Inner core white node
                drawCircle(
                    color = Color.White,
                    radius = if (isSelected) 8f * scale else 6f * scale,
                    center = nodePos
                )

                // Outer border indicator
                val borderColor = when {
                    station.lines.contains(RailLineColor.RED) -> RailColorRed
                    station.lines.contains(RailLineColor.BLUE) -> RailColorBlue
                    station.lines.contains(RailLineColor.GOLD) -> RailColorGold
                    else -> RailColorGreen
                }
                
                drawCircle(
                    color = borderColor.copy(alpha = baseAlpha),
                    radius = if (isSelected) 8f * scale else 6f * scale,
                    center = nodePos,
                    style = Stroke(width = 3f * scale)
                )

                // Station Text Label
                if (scale >= 1.0f || isSelected) {
                    drawContext.canvas.nativeCanvas.apply {
                        val labelPaint = android.graphics.Paint().apply {
                            color = if (isSelected) android.graphics.Color.BLACK else android.graphics.Color.DKGRAY
                            alpha = (baseAlpha * 255).toInt().coerceIn(10, 255)
                            textSize = if (isSelected) 13f * scale else 9f * scale
                            isAntiAlias = true
                            typeface = android.graphics.Typeface.create(
                                android.graphics.Typeface.SANS_SERIF, 
                                if (isSelected) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL
                            )
                        }
                        // Draw label slightly offset
                        drawText(
                            station.name, 
                            nodePos.x, 
                            nodePos.y - (14f * scale), 
                            labelPaint
                        )
                    }
                }
            }

            // --- DRAW SIMULATED MOVING VEHICLES ---
            for (vehicle in vehicles) {
                // Approximate position along rail lines based on progress
                val (vx, vy) = when (vehicle.routeName) {
                    "Red Line" -> {
                        // Interpolated points
                        interpolateRailPosition(vehicle.progress, redStations)
                    }
                    "Gold Line" -> {
                        interpolateRailPosition(vehicle.progress, goldSharedStations + goldDivergentStations)
                    }
                    "Blue Line" -> {
                        interpolateRailPosition(vehicle.progress, blueStations)
                    }
                    "Green Line" -> {
                        interpolateRailPosition(vehicle.progress, greenStations)
                    }
                    "Atlanta Streetcar" -> {
                        // Circulate streetcar center
                        val angle = vehicle.progress * 2.0 * Math.PI
                        val x = streetcarCenter.x + streetcarRadiusX * Math.cos(angle).toFloat()
                        val y = streetcarCenter.y + streetcarRadiusX * 0.7f * Math.sin(angle).toFloat()
                        Offset(x, y)
                    }
                    else -> {
                        // default center
                        Offset(0f, 0f)
                    }
                }

                val vPixel = if (vehicle.routeName == "Atlanta Streetcar") Offset(vx, vy) else gridToPixel(vx, vy)

                // Draw indicator
                val vColor = when (vehicle.routeName) {
                    "Red Line" -> RailColorRed
                    "Gold Line" -> RailColorGold
                    "Blue Line" -> RailColorBlue
                    "Green Line" -> RailColorGreen
                    else -> RailColorStreetcar
                }

                // Glow ring
                drawCircle(
                    color = vColor.copy(alpha = 0.4f),
                    radius = 10f * scale,
                    center = vPixel
                )

                // Core marker
                drawCircle(
                    color = vColor,
                    radius = 6f * scale,
                    center = vPixel
                )
                
                drawCircle(
                    color = Color.White,
                    radius = 2.5f * scale,
                    center = vPixel
                )
            }
        }

        // --- MAP ZOOM & RESET FLOATING CONTROLS ---
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .width(48.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FloatingActionButton(
                onClick = { scale = (scale + 0.2f).coerceAtMost(3.5f) },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(40.dp).testTag("zoom_in_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Zoom In", modifier = Modifier.size(20.dp))
            }
            FloatingActionButton(
                onClick = { scale = (scale - 0.2f).coerceAtLeast(0.6f) },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(40.dp).testTag("zoom_out_button")
            ) {
                Icon(Icons.Filled.Remove, contentDescription = "Zoom Out", modifier = Modifier.size(20.dp))
            }
            FloatingActionButton(
                onClick = {
                    scale = 1.2f
                    offsetX = 0f
                    offsetY = 0f
                    onStationSelect(null)
                },
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(40.dp).testTag("reset_map_button")
            ) {
                Icon(Icons.Filled.RestartAlt, contentDescription = "Reset Map", modifier = Modifier.size(20.dp))
            }
        }
    }
}

// Map progress to grid coordinates
private fun interpolateRailPosition(progress: Float, stations: List<Station>): Offset {
    if (stations.isEmpty()) return Offset(0f, 0f)
    if (stations.size == 1) return Offset(stations[0].gridX, stations[0].gridY)
    
    val exactIndex = progress * (stations.size - 1)
    val startIndex = exactIndex.toInt().coerceIn(0, stations.size - 2)
    val endIndex = startIndex + 1
    val localProgress = exactIndex - startIndex
    
    val s1 = stations[startIndex]
    val s2 = stations[endIndex]
    
    val ix = s1.gridX + (s2.gridX - s1.gridX) * localProgress.toFloat()
    val iy = s1.gridY + (s2.gridY - s1.gridY) * localProgress.toFloat()
    
    return Offset(ix, iy)
}
