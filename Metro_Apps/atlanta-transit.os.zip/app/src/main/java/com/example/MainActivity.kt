package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.ExperimentalMaterial3Api
import com.example.data.*
import com.example.ui.TransitViewModel
import com.example.ui.screens.*
import com.example.ui.theme.AccentClay
import com.example.ui.theme.MartaBlue
import com.example.ui.theme.MyApplicationTheme

enum class ScreenTab(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    HOME("home", "Home", Icons.Filled.Home),
    MAP("map", "Atlanta Now", Icons.Filled.Map),
    LINES("lines", "MARTA Rail", Icons.Filled.Train),
    AIRPORT("airport", "ATL Airport", Icons.Filled.Flight),
    BREEZE("breeze", "My Breeze", Icons.Filled.CreditCard)
}

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    private val viewModel: TransitViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val settings by viewModel.systemSettings.collectAsState()
                var currentTab by remember { mutableStateOf(ScreenTab.HOME) }
                
                val configuration = LocalConfiguration.current
                val isTablet = configuration.screenWidthDp >= 600

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        CenterAlignedTopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "TRANSIT.OS",
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp,
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                    if (settings.isOfflineMode) {
                                        Badge(containerColor = AccentClay) {
                                            Text("OFFLINE", color = Color.White, modifier = Modifier.padding(2.dp))
                                        }
                                    }
                                }
                            },
                            actions = {
                                // Accessibility and Offline Quick Setting Toggles
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { viewModel.toggleAccessibility(!settings.isAccessibleOnly) },
                                        modifier = Modifier.testTag("accessible_toggle")
                                    ) {
                                        Icon(
                                            Icons.Filled.Accessible,
                                            contentDescription = "Toggle Step-free Routing only",
                                            tint = if (settings.isAccessibleOnly) MartaBlue else MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                    IconButton(
                                        onClick = { viewModel.toggleOfflineMode(!settings.isOfflineMode) },
                                        modifier = Modifier.testTag("offline_toggle")
                                    ) {
                                        Icon(
                                            Icons.Filled.WifiOff,
                                            contentDescription = "Toggle Offline Simulation",
                                            tint = if (settings.isOfflineMode) AccentClay else MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = MaterialTheme.colorScheme.background
                            )
                        )
                    },
                    bottomBar = {
                        if (!isTablet) {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface,
                                contentColor = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.testTag("bottom_nav_bar")
                            ) {
                                ScreenTab.values().forEach { tab ->
                                    NavigationBarItem(
                                        selected = currentTab == tab,
                                        onClick = { currentTab = tab },
                                        icon = { Icon(tab.icon, contentDescription = tab.title) },
                                        label = { Text(tab.title, style = MaterialTheme.typography.labelSmall) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = MartaBlue,
                                            selectedTextColor = MartaBlue,
                                            indicatorColor = MartaBlue.copy(alpha = 0.1f)
                                        ),
                                        modifier = Modifier.testTag("nav_tab_${tab.route}")
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    if (isTablet) {
                        // Wide Screen Dual Pane Layout
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            NavigationRail(
                                containerColor = MaterialTheme.colorScheme.surface,
                                contentColor = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.testTag("side_nav_rail")
                            ) {
                                ScreenTab.values().forEach { tab ->
                                    NavigationRailItem(
                                        selected = currentTab == tab,
                                        onClick = { currentTab = tab },
                                        icon = { Icon(tab.icon, contentDescription = tab.title) },
                                        label = { Text(tab.title) },
                                        colors = NavigationRailItemDefaults.colors(
                                            selectedIconColor = MartaBlue,
                                            selectedTextColor = MartaBlue,
                                            indicatorColor = MartaBlue.copy(alpha = 0.1f)
                                        ),
                                        modifier = Modifier.testTag("nav_rail_tab_${tab.route}")
                                    )
                                }
                            }
                            
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .weight(1f)
                            ) {
                                RenderScreen(tab = currentTab, viewModel = viewModel, onNavigateToTab = { currentTab = it })
                            }
                        }
                    } else {
                        // Standard Mobile Port Viewport
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            RenderScreen(tab = currentTab, viewModel = viewModel, onNavigateToTab = { currentTab = it })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RenderScreen(
    tab: ScreenTab,
    viewModel: TransitViewModel,
    onNavigateToTab: (ScreenTab) -> Unit
) {
    Crossfade(targetState = tab, label = "screenTransition") { state ->
        when (state) {
            ScreenTab.HOME -> HomeScreen(
                viewModel = viewModel,
                onNavigateToMap = { onNavigateToTab(ScreenTab.MAP) }
            )
            ScreenTab.MAP -> MapScreen(
                viewModel = viewModel
            )
            ScreenTab.LINES -> TransitNetworkScreen(
                viewModel = viewModel,
                onNavigateToMap = { onNavigateToTab(ScreenTab.MAP) }
            )
            ScreenTab.AIRPORT -> AirportScreen(
                viewModel = viewModel,
                onStartAirportTrip = { onNavigateToTab(ScreenTab.HOME) }
            )
            ScreenTab.BREEZE -> BreezeScreen(
                viewModel = viewModel
            )
        }
    }
}
