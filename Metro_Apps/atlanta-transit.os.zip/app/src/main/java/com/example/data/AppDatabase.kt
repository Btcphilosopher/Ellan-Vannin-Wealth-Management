package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BreezeDao {
    // Breeze Account
    @Query("SELECT * FROM breeze_account LIMIT 1")
    fun getBreezeAccount(): Flow<BreezeAccount?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBreezeAccount(account: BreezeAccount)

    @Update
    suspend fun updateBreezeAccount(account: BreezeAccount)

    // Trip History
    @Query("SELECT * FROM trip_history ORDER BY timestamp DESC")
    fun getTripHistory(): Flow<List<TripHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: TripHistory)

    @Query("DELETE FROM trip_history")
    suspend fun clearTripHistory()

    // Saved Journeys
    @Query("SELECT * FROM saved_journeys ORDER BY timestamp DESC")
    fun getSavedJourneys(): Flow<List<SavedJourney>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedJourney(journey: SavedJourney)

    @Query("DELETE FROM saved_journeys WHERE id = :id")
    suspend fun deleteSavedJourney(id: String)

    // System Settings
    @Query("SELECT * FROM system_settings WHERE id = 'active_settings' LIMIT 1")
    fun getSystemSettings(): Flow<SystemSettings?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSystemSettings(settings: SystemSettings)
}

@Database(
    entities = [
        BreezeAccount::class,
        TripHistory::class,
        SavedJourney::class,
        SystemSettings::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun breezeDao(): BreezeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "atlanta_transit_os_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
