package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.routing.TransitData
import com.example.ui.TransitViewModel
import com.example.ui.theme.AccentClay
import com.example.ui.theme.MartaBlue

@Composable
fun TransitNetworkScreen(
    viewModel: TransitViewModel,
    onNavigateToMap: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf(RailLineColor.RED) }
    val simulatedVehicles by viewModel.simulatedVehicles.collectAsState()

    val filteredStations = remember(activeTab) {
        TransitData.stations.filter { it.lines.contains(activeTab) }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // SCREEN TITLE
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Text(
                    text = "MARTA NETWORK",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = (-1).sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "RAIL LINES & STREETCAR INFRASTRUCTURE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // HORIZONTAL LINE CHIPS SELECTOR
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val lines = listOf(
                    RailLineColor.RED to "Red Line",
                    RailLineColor.GOLD to "Gold Line",
                    RailLineColor.BLUE to "Blue Line",
                    RailLineColor.GREEN to "Green Line"
                )
                lines.forEach { (colorToken, label) ->
                    val active = activeTab == colorToken
                    Button(
                        onClick = { activeTab = colorToken; viewModel.selectLine(colorToken) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (active) getRailColor(colorToken) else MaterialTheme.colorScheme.surface,
                            contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                        ),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.testTag("line_chip_${colorToken.name.lowercase()}")
                    ) {
                        Text(label, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // INFRASTRUCTURE ESTIMATED HEADWAYS
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("LINE FREQUENCY", style = MaterialTheme.typography.labelSmall, color = MartaBlue)
                        Text("Next departure: 8 min", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        Text("Following headway: 18 min", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                    }
                    Badge(containerColor = Color(0xFF238E5A)) {
                        Text("NORMAL SERVICE", color = Color.White, modifier = Modifier.padding(4.dp))
                    }
                }
            }
        }

        // STATION LIST SEQUENCE
        item {
            Text(
                text = "STATION VERTICAL GRID",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.Bold
            )
        }

        items(filteredStations) { station ->
            Card(
                onClick = { 
                    viewModel.selectStation(station)
                    onNavigateToMap()
                },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth().testTag("station_card_${station.id.lowercase()}")
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(getRailColor(activeTab))
                        )
                        Column {
                            Text(station.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Text("Elevators: ${station.elevatorsCount} | Escs: ${station.escalatorsCount}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                    Icon(
                        Icons.Filled.ChevronRight,
                        contentDescription = "Show on map",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        // ACCESSIBILITY STATEMENT
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MartaBlue.copy(alpha = 0.08f)),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("ACCESSIBILITY FIRST DESIGN", style = MaterialTheme.typography.labelSmall, color = MartaBlue, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "All MARTA rail stations are fully step-free with elevator connections to all platform levels. For current out-of-service elevator status alerts, please inspect the Atlanta Now live map incidents layer.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}
