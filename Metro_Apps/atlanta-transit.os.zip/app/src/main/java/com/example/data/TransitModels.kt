package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- ENUMS FOR MODES & SEVERITY ---
enum class TransitMode {
    RAIL, BUS, STREETCAR, WALK
}

enum class RailLineColor {
    RED, GOLD, BLUE, GREEN, STREETCAR_GRAY
}

enum class DisruptionSeverity {
    NORMAL, WATCH, MINOR_DELAY, DISRUPTED, SEVERE, RECOVERING
}

enum class CrowdingLevel {
    LOW, MODERATE, BUSY, VERY_BUSY, EXTREME
}

enum class WeatherType {
    CLEAR, HOT, HEAT_WARNING, THUNDERSTORM, HEAVY_RAIN, FLASH_FLOOD_RISK, WINTER_WEATHER
}

enum class PaymentMethod(val label: String) {
    BREEZE_CARD("Breeze Card"),
    BREEZE_APP("Breeze Mobile App"),
    DEBIT_CARD("Debit Card"),
    CREDIT_CARD("Credit Card"),
    APPLE_PAY("Apple Pay"),
    GOOGLE_PAY("Google Pay"),
    MOBILE_WALLET("Mobile Wallet")
}

// --- DOMAIN MODELS ---

data class Station(
    val id: String,
    val name: String,
    val lines: List<RailLineColor>,
    val gridX: Float, // Relative X coordinate for vector schematic map
    val gridY: Float, // Relative Y coordinate for vector schematic map
    val entrances: List<String>,
    val elevatorsCount: Int,
    val escalatorsCount: Int,
    val busConnections: List<String>,
    val streetcarConnection: Boolean = false,
    val nearbyDestinations: List<String>,
    val accessibilityInfo: String = "Step-free elevator access available to all platforms.",
    val neighborhoodInfo: String = ""
)

data class BusRoute(
    val id: String,
    val routeNumber: String,
    val routeName: String,
    val type: BusType, // RAPID, FREQUENT, LOCAL, EXPRESS, REACH
    val stops: List<String>
)

enum class BusType {
    RAPID, FREQUENT, LOCAL, EXPRESS, REACH
}

data class Vehicle(
    val id: String,
    val mode: TransitMode,
    val routeName: String, // Red, Gold, Route 15, Streetcar, etc.
    val direction: String, // e.g., "Airport-bound", "Northbound", "Loop"
    val progress: Float, // Progress along its line/route: 0.0 to 1.0
    val speedKmh: Int,
    val numCars: Int, // 0 for bus, 4 or 6 for train
    val passengerLoadPercent: Int,
    val currentStationId: String? = null,
    val nextStationId: String? = null
)

data class JourneyLeg(
    val mode: TransitMode,
    val lineName: String, // e.g. "Red Line", "Route 15", "Walking"
    val lineColor: RailLineColor?,
    val originStationName: String,
    val destinationStationName: String,
    val numStops: Int,
    val durationMinutes: Int,
    val instruction: String,
    val boardingInfo: String? = null,
    val stopList: List<String> = emptyList()
)

data class Journey(
    val origin: String,
    val destination: String,
    val legs: List<JourneyLeg>,
    val totalDurationMinutes: Int,
    val totalTransfers: Int,
    val totalWalkingMinutes: Int,
    val fareAmount: Double,
    val isAccessible: Boolean,
    val status: String = "On Schedule"
)

data class Incident(
    val id: String,
    val type: String, // e.g. "delay", "station closure", "elevator outage"
    val severity: DisruptionSeverity,
    val affectedRoutes: List<String>,
    val affectedStations: List<String>,
    val startTime: String,
    val expectedDuration: String,
    val description: String,
    val alternatives: String,
    val status: String // ACTIVE, RESOLVING, PLANNED
)

data class WeatherState(
    val type: WeatherType,
    val description: String,
    val temperatureFahrenheit: Int,
    val walkingDelayModifierMinutes: Int,
    val message: String
)

data class Landmark(
    val name: String,
    val district: String,
    val description: String,
    val nearestStationId: String,
    val walkingMinutes: Int,
    val category: String // "STADIUM", "ARTS", "PARK", "SHOPPING", "HISTORIC"
)

// --- ROOM PERSISTENT ENTITIES ---

@Entity(tableName = "breeze_account")
data class BreezeAccount(
    @PrimaryKey val cardNumber: String = "0164-9274-1058-4812",
    val balance: Double = 18.50,
    val autoloadOn: Boolean = true,
    val autoloadAmount: Double = 20.00,
    val isPassActive: Boolean = false,
    val passName: String = "No active pass"
)

@Entity(tableName = "trip_history")
data class TripHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val origin: String,
    val destination: String,
    val fareCharged: Double,
    val routeName: String,
    val isTransfer: Boolean = false
)

@Entity(tableName = "saved_journeys")
data class SavedJourney(
    @PrimaryKey val id: String,
    val originName: String,
    val destinationName: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "system_settings")
data class SystemSettings(
    @PrimaryKey val id: String = "active_settings",
    val activeScenarioName: String = "NORMAL",
    val isAccessibleOnly: Boolean = false,
    val isOfflineMode: Boolean = false,
    val testTapActive: Boolean = false
)
