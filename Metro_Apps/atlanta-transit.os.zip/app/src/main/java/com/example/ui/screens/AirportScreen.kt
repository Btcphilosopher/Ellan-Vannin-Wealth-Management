package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.TransitViewModel
import com.example.ui.theme.AccentClay
import com.example.ui.theme.MartaBlue

@Composable
fun AirportScreen(
    viewModel: TransitViewModel,
    onStartAirportTrip: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedOrigin by remember { mutableStateOf("Midtown") }
    var selectedConcourse by remember { mutableStateOf("Domestic Terminal") }

    val origins = listOf("Midtown", "Five Points", "Buckhead", "Decatur")
    val concourses = listOf("Domestic Terminal", "Concourse A", "Concourse B", "International Terminal", "Rental Car Center")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // SCREEN TITLE
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Text(
                    text = "ATL AIRPORT",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = (-1).sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "HARTSFIELD-JACKSON INFRASTRUCTURE PORTAL",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // CHOOSE STARTING LOCATION
        item {
            Column {
                Text(
                    text = "SELECT ATLANTA ORIGIN",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    origins.forEach { o ->
                        val active = selectedOrigin == o
                        Card(
                            onClick = { selectedOrigin = o },
                            colors = CardDefaults.cardColors(
                                containerColor = if (active) MartaBlue else MaterialTheme.colorScheme.surface,
                                contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(modifier = Modifier.padding(10.dp), contentAlignment = Alignment.Center) {
                                Text(o, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }

        // CHOOSE TERMINAL / CONCOURSE
        item {
            Column {
                Text(
                    text = "SELECT TARGET AIRPORT ZONE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val itemsToShow = concourses.take(3)
                    itemsToShow.forEach { c ->
                        val active = selectedConcourse == c
                        Card(
                            onClick = { selectedConcourse = c },
                            colors = CardDefaults.cardColors(
                                containerColor = if (active) MartaBlue else MaterialTheme.colorScheme.surface,
                                contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(modifier = Modifier.padding(10.dp), contentAlignment = Alignment.Center) {
                                Text(c, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val itemsToShow = concourses.drop(3)
                    itemsToShow.forEach { c ->
                        val active = selectedConcourse == c
                        Card(
                            onClick = { selectedConcourse = c },
                            colors = CardDefaults.cardColors(
                                containerColor = if (active) MartaBlue else MaterialTheme.colorScheme.surface,
                                contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(modifier = Modifier.padding(10.dp), contentAlignment = Alignment.Center) {
                                Text(c, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }

        // GENERATE AIRPORT TRANSIT SCHEDULE STRATEGY
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("airport_plan_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "AIRPORT FLIGHT CONNECTION STRATEGY",
                        style = MaterialTheme.typography.labelSmall,
                        color = MartaBlue,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text("Total Travel Time", style = MaterialTheme.typography.bodyMedium)
                            Text("34 mins", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Black)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Next Red/Gold Train", style = MaterialTheme.typography.bodyMedium)
                            Text("4 min", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF238E5A))
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp))

                    // Plan Leg List
                    AirportPlanLeg(
                        stepNum = 1,
                        instruction = "Board Gold Line Train (Southbound to Airport)",
                        sub = "From $selectedOrigin Station — Platform B. Standard $2.50 fare.",
                        duration = "22 min"
                    )
                    AirportPlanLeg(
                        stepNum = 2,
                        instruction = "De-board directly into Airport Terminal lobby",
                        sub = "Airport station is located adjacent to baggage claim. Under 2 minutes walking.",
                        duration = "2 min"
                    )
                    if (selectedConcourse == "Rental Car Center") {
                        AirportPlanLeg(
                            stepNum = 3,
                            instruction = "Board ATL SkyTrain to Rental Car Center",
                            sub = "Free automated people mover, departs every 3 minutes from terminal station.",
                            duration = "5 min"
                        )
                    } else if (selectedConcourse == "International Terminal") {
                        AirportPlanLeg(
                            stepNum = 3,
                            instruction = "Take free Airport Terminal Shuttle to International Gate F",
                            sub = "Runs every 10 minutes between Domestic and International arrivals.",
                            duration = "12 min"
                        )
                    } else {
                        AirportPlanLeg(
                            stepNum = 3,
                            instruction = "Pass TSA Security & board Plane Train to $selectedConcourse",
                            sub = "High-speed subterranean terminal connector train. Runs every 2 minutes.",
                            duration = "6 min"
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.calculateRoute(selectedOrigin, "Airport")
                            viewModel.startJourney()
                            onStartAirportTrip()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MartaBlue),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("INITIATE AIRPORT TRIP NAVIGATION", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // TRAVEL INFORMATION HELPER
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.onBackground, contentColor = MaterialTheme.colorScheme.background),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("HARTSFIELD-JACKSON EFFICIENCY NOTE", style = MaterialTheme.typography.labelSmall, color = AccentClay, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "MARTA rail provides direct access to the Domestic terminal of Hartsfield-Jackson Airport. Avoid heavy Interstate 85 airport exit lane delay peaks. The trip is fully step-free with elevator access from train platform direct to check-in desks.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

@Composable
fun AirportPlanLeg(
    stepNum: Int,
    instruction: String,
    sub: String,
    duration: String
) {
    Row(
        modifier = Modifier.padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MartaBlue),
            contentAlignment = Alignment.Center
        ) {
            Text("$stepNum", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(instruction, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
        }
        Text(duration, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
    }
}
