package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.TransitViewModel
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    viewModel: TransitViewModel,
    onNavigateToMap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val calculatedJourney by viewModel.calculatedJourney.collectAsState()
    val isJourneyActive by viewModel.isJourneyActive.collectAsState()
    val activeLegIndex by viewModel.activeLegIndex.collectAsState()
    val routeOrigin by viewModel.routeOrigin.collectAsState()
    val routeDestination by viewModel.routeDestination.collectAsState()
    val savedJourneys by viewModel.savedJourneys.collectAsState()
    val weather by viewModel.weatherState.collectAsState()

    var showSavedToast by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // WEATHER ALERT BANNER (If severe)
        if (weather.type != WeatherType.CLEAR) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = AccentClay.copy(alpha = 0.15f),
                        contentColor = AccentClay
                    ),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = "Weather Alert")
                        Text(
                            text = "${weather.description}: ${weather.message}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // HEADER
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Text(
                    text = "ATLANTA",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = (-1).sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "TRANSIT.OS — CITY MOBILITY PORTAL",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // JOURNEY ACTIVE LAYER: "MY NEXT MOVE"
        if (isJourneyActive && calculatedJourney != null) {
            item {
                val journey = calculatedJourney!!
                val currentLeg = journey.legs[activeLegIndex]
                
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.onBackground,
                        contentColor = MaterialTheme.colorScheme.background
                    ),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("my_next_move_panel")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "MY NEXT MOVE",
                                style = MaterialTheme.typography.labelLarge,
                                color = AccentClay,
                                fontWeight = FontWeight.Bold
                            )
                            Badge(containerColor = MartaBlue) {
                                Text(
                                    text = "ACTIVE TRIP",
                                    color = Color.White,
                                    modifier = Modifier.padding(2.dp)
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Text(
                            text = "GOING TO ${journey.destination.uppercase()}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            val modeIcon = when (currentLeg.mode) {
                                TransitMode.RAIL -> Icons.Filled.Train
                                TransitMode.BUS -> Icons.Filled.DirectionsBus
                                TransitMode.STREETCAR -> Icons.Filled.Tram
                                TransitMode.WALK -> Icons.Filled.DirectionsWalk
                            }
                            Icon(
                                modeIcon,
                                contentDescription = null,
                                modifier = Modifier.size(36.dp),
                                tint = currentLeg.lineColor?.let { getRailColor(it) } ?: MaterialTheme.colorScheme.secondary
                            )
                            Column {
                                Text(
                                    text = "NEXT: ${currentLeg.instruction}",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                currentLeg.boardingInfo?.let {
                                    Text(text = it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                                }
                                Text(
                                    text = "Duration: ${currentLeg.durationMinutes} min",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = { viewModel.advanceLeg() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MartaBlue,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.weight(1f).testTag("advance_leg_button")
                            ) {
                                val label = if (activeLegIndex < journey.legs.size - 1) "ADVANCE TRIP" else "ARRIVE & TAP OUT ($${String.format("%.2f", journey.fareAmount)})"
                                Text(label, fontWeight = FontWeight.Bold)
                            }
                            
                            OutlinedButton(
                                onClick = { viewModel.endJourney() },
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = AccentClay
                                )
                            ) {
                                Text("CANCEL")
                            }
                        }
                    }
                }
            }
        }

        // DESTINATION SEARCH FIELD
        item {
            Column {
                Text(
                    text = "Where are you going?",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                TextField(
                    value = searchQuery,
                    onValueChange = {
                        viewModel.searchQuery.value = it
                        viewModel.isSearching.value = it.isNotBlank()
                    },
                    placeholder = { Text("Search Airport, Midtown, Stadium, Ponce...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { 
                                viewModel.searchQuery.value = ""
                                viewModel.isSearching.value = false
                            }) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("destination_search_input"),
                    shape = RoundedCornerShape(2.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedIndicatorColor = MartaBlue
                    )
                )
            }
        }

        // SEARCH RESULTS OVERLAY
        if (isSearching) {
            if (searchResults.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No destinations found in Atlanta.", color = MaterialTheme.colorScheme.secondary)
                    }
                }
            } else {
                items(searchResults) { result ->
                    val name = when (result) {
                        is Station -> result.name
                        is Landmark -> result.name
                        else -> "Location"
                    }
                    val subtitle = when (result) {
                        is Station -> "MARTA Station — lines: " + result.lines.joinToString { it.name }
                        is Landmark -> "District: ${result.district} — ${result.description}"
                        else -> "Atlanta Spot"
                    }
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.calculateRoute("Five Points", name)
                                viewModel.searchQuery.value = ""
                                viewModel.isSearching.value = false
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val icon = if (result is Station) Icons.Filled.Train else Icons.Filled.Place
                        Icon(icon, contentDescription = null, tint = MartaBlue)
                        Column {
                            Text(name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }
        }

        // ROUTE PLANNING PANEL (Visible when query calculated but journey not active)
        if (!isJourneyActive && calculatedJourney != null) {
            item {
                val journey = calculatedJourney!!
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth().testTag("route_plan_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("SUGGESTED ROUTE", style = MaterialTheme.typography.labelSmall, color = MartaBlue, fontWeight = FontWeight.Bold)
                            IconButton(onClick = {
                                viewModel.saveJourneyToFavorites(journey.origin, journey.destination)
                                showSavedToast = true
                            }) {
                                Icon(Icons.Filled.BookmarkBorder, contentDescription = "Save Journey")
                            }
                        }

                        Text(
                            text = "${journey.origin} to ${journey.destination}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${journey.totalDurationMinutes} min",
                                style = MaterialTheme.typography.displayMedium,
                                fontWeight = FontWeight.Black
                            )
                            Column {
                                Text("Transfers: ${journey.totalTransfers}", style = MaterialTheme.typography.bodyMedium)
                                Text("Walk: ${journey.totalWalkingMinutes} min", style = MaterialTheme.typography.bodyMedium)
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 12.dp))

                        // Timeline of steps
                        journey.legs.forEachIndexed { index, leg ->
                            Row(
                                modifier = Modifier.padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                val legIcon = when (leg.mode) {
                                    TransitMode.RAIL -> Icons.Filled.Train
                                    TransitMode.BUS -> Icons.Filled.DirectionsBus
                                    TransitMode.STREETCAR -> Icons.Filled.Tram
                                    TransitMode.WALK -> Icons.Filled.DirectionsWalk
                                }
                                Icon(
                                    legIcon,
                                    contentDescription = null,
                                    tint = leg.lineColor?.let { getRailColor(it) } ?: MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Column {
                                    Text(leg.instruction, fontWeight = FontWeight.Bold)
                                    Text(
                                        "${leg.originStationName} ➔ ${leg.destinationStationName} (${leg.durationMinutes} min)",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { viewModel.startJourney() },
                            modifier = Modifier.fillMaxWidth().testTag("start_journey_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MartaBlue),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text("START JOURNEY NAVIGATION", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // QUICK METROPOLITAN PLANNER DESTINATIONS
        if (!isSearching && calculatedJourney == null) {
            item {
                Column {
                    Text(
                        text = "QUICK MOBILE ROUTES",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val destinations = listOf(
                            "Airport" to "AIRPORT",
                            "Midtown" to "MIDTOWN",
                            "Stadium" to "Mercedes-Benz Stadium",
                            "Decatur" to "Decatur"
                        )
                        destinations.forEach { (label, dest) ->
                            Card(
                                onClick = { viewModel.calculateRoute("Five Points", dest) },
                                shape = RoundedCornerShape(2.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier.padding(12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // SAVED FAVORITES LIST
        if (savedJourneys.isNotEmpty() && !isSearching) {
            item {
                Column {
                    Text(
                        text = "SAVED METROPOLITAN ROUTES",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    
                    savedJourneys.forEach { sj ->
                        Card(
                            onClick = { viewModel.calculateRoute(sj.originName, sj.destinationName) },
                            shape = RoundedCornerShape(2.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Bookmark, contentDescription = null, tint = MartaBlue)
                                    Column {
                                        Text("${sj.originName} ➔ ${sj.destinationName}", fontWeight = FontWeight.Bold)
                                        Text("Tap to recalculate routing graph", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                                    }
                                }
                                IconButton(onClick = { viewModel.deleteJourneyFromFavorites(sj.id) }) {
                                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete Favorite", tint = AccentClay)
                                }
                            }
                        }
                    }
                }
            }
        }

        // "YOUR CITY NOW" METROPOLITAN STATUS PANEL
        if (!isSearching) {
            item {
                Column {
                    Text(
                        text = "YOUR CITY NOW",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            CityStatusRow(
                                modeLabel = "MARTA RAIL",
                                status = "Normal Service",
                                statusColor = Color(0xFF238E5A),
                                icon = Icons.Filled.Train
                            )
                            CityStatusRow(
                                modeLabel = "BUS NETWORK",
                                status = "Most routes normal",
                                statusColor = Color(0xFF238E5A),
                                icon = Icons.Filled.DirectionsBus
                            )
                            CityStatusRow(
                                modeLabel = "ATLANTA STREETCAR",
                                status = "12-stop Loop active",
                                statusColor = MartaBlue,
                                icon = Icons.Filled.Tram
                            )
                            CityStatusRow(
                                modeLabel = "AIRPORT CONNS",
                                status = "Rail Terminal clear",
                                statusColor = Color(0xFF238E5A),
                                icon = Icons.Filled.Flight
                            )
                            CityStatusRow(
                                modeLabel = "REGIONAL LINES",
                                status = "Connections ready",
                                statusColor = MartaBlue,
                                icon = Icons.Filled.DirectionsTransit
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CityStatusRow(
    modeLabel: String,
    status: String,
    statusColor: Color,
    icon: ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp))
            Text(modeLabel, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(statusColor)
            )
            Text(status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
        }
    }
}

fun getRailColor(color: RailLineColor): Color {
    return when (color) {
        RailLineColor.RED -> RailColorRed
        RailLineColor.GOLD -> RailColorGold
        RailLineColor.BLUE -> RailColorBlue
        RailLineColor.GREEN -> RailColorGreen
        RailLineColor.STREETCAR_GRAY -> RailColorStreetcar
    }
}
