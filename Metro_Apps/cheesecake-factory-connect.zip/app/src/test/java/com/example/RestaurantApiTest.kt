package com.example

import com.example.data.model.*
import com.example.data.sample.SampleData
import com.example.data.service.RestaurantApiService
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class RestaurantApiTest {

    private lateinit var apiService: RestaurantApiService

    @Before
    fun setUp() {
        apiService = RestaurantApiService.getInstance()
        apiService.resetForTesting()
    }

    @Test
    fun testSuccessfulReservationCheckIn() {
        // Sarah Connor reservation exists at loc_beverly_hills
        val lookupResult = apiService.lookupReservation("loc_beverly_hills", "CCF-7821")
        assertTrue("Reservation should be found", lookupResult.isSuccess)
        val res = lookupResult.getOrNull()!!
        assertEquals("Sarah Connor", res.customerName)

        // Submit arrival check-in
        val checkInResult = apiService.checkInReservation(res.id, "idemp_test_1")
        assertTrue("Check-in should succeed", checkInResult.isSuccess)
        assertEquals(ArrivalStatus.AWAITING_SEATING, checkInResult.getOrNull()!!.arrivalStatus)
        assertNotNull(checkInResult.getOrNull()!!.checkInTimestamp)
    }

    @Test
    fun testInvalidReservationLookup() {
        val result = apiService.lookupReservation("loc_beverly_hills", "INVALID_CODE_9999")
        assertTrue("Lookup for invalid code should fail", result.isFailure)
    }

    @Test
    fun testDuplicateCheckInIdempotency() {
        val key = "idemp_dup_check"
        val lookup = apiService.lookupReservation("loc_beverly_hills", "CCF-7821").getOrNull()!!
        val firstAttempt = apiService.checkInReservation(lookup.id, key)
        assertTrue(firstAttempt.isSuccess)

        // Second attempt with exact same idempotency key
        val secondAttempt = apiService.checkInReservation(lookup.id, key)
        assertTrue("Duplicate with same idempotency key must not fail with error", secondAttempt.isSuccess)
    }

    @Test
    fun testWaitlistCreationAndCancellation() {
        val createResult = apiService.createWaitlistEntry(
            locationId = "loc_beverly_hills",
            name = "John Doe",
            phone = "(310) 555-9999",
            partySize = 4,
            notes = "Quiet booth"
        )
        assertTrue("Waitlist creation should succeed", createResult.isSuccess)
        val entry = createResult.getOrNull()!!
        assertEquals(WaitlistStatus.WAITING, entry.status)
        assertTrue(entry.queueCode.startsWith("W-"))

        // Cancellation
        val cancelResult = apiService.cancelWaitlistEntry(entry.id)
        assertTrue("Cancellation should succeed", cancelResult.isSuccess)
        assertEquals(WaitlistStatus.CANCELLED, cancelResult.getOrNull()!!.status)
    }

    @Test
    fun testQuoteCalculationExactTaxAndTip() {
        val item1 = SampleData.menuItems[0] // Original cheesecake ($10.95 = 1095 cents)
        val cartItem = CartItem(menuItem = item1, quantity = 2) // $21.90 = 2190 cents

        val quoteResult = apiService.calculateQuote(
            locationId = "loc_beverly_hills",
            diningMode = DiningMode.DINE_IN,
            tableNumber = 4,
            items = listOf(cartItem),
            promoCode = null,
            tipPercentage = 18
        )
        assertTrue("Quote calculation should succeed", quoteResult.isSuccess)
        val quote = quoteResult.getOrNull()!!
        assertEquals(2190, quote.subtotalCents)
        // 8.75% of 2190 = 191.625 -> 192 cents
        assertEquals(192, quote.taxCents)
        // Dine-in fee: 250 cents ($2.50)
        assertEquals(250, quote.serviceFeeCents)
        // 18% tip on 2190 = 394.2 -> 394 cents
        assertEquals(394, quote.tipCents)
        // Total = 2190 + 192 + 250 + 394 = 3026 cents ($30.26)
        assertEquals(3026, quote.totalCents)
    }

    @Test
    fun testPromoCodeDiscount() {
        val item = SampleData.menuItems[6] // Chicken Madeira ($24.95 = 2495) + cheesecake ($10.95 = 1095) = 3590 cents
        val cartItems = listOf(
            CartItem(menuItem = SampleData.menuItems[6], quantity = 1),
            CartItem(menuItem = SampleData.menuItems[0], quantity = 1)
        )

        val quoteResult = apiService.calculateQuote(
            locationId = "loc_beverly_hills",
            diningMode = DiningMode.PICKUP,
            tableNumber = null,
            items = cartItems,
            promoCode = "SWEET10",
            tipPercentage = 0
        )
        assertTrue(quoteResult.isSuccess)
        val quote = quoteResult.getOrNull()!!
        // $10 off (1000 cents)
        assertEquals(1000, quote.discountCents)
        assertNotNull(quote.promoCodeApplied)
    }

    @Test
    fun test86ItemAvailabilityRejectsQuote() {
        val item = SampleData.menuItems[1] // Strawberry cheesecake
        // Toggle item out of stock
        apiService.toggleItemAvailability(item.id)

        val cartItem = CartItem(menuItem = item, quantity = 1)
        val quoteResult = apiService.calculateQuote(
            locationId = "loc_beverly_hills",
            diningMode = DiningMode.PICKUP,
            tableNumber = null,
            items = listOf(cartItem),
            promoCode = null,
            tipPercentage = 0
        )
        assertTrue("Cart quote must fail if item is 86'd", quoteResult.isFailure)

        // Toggle back in stock
        apiService.toggleItemAvailability(item.id)
    }

    @Test
    fun testOrderLifecycleAndPaymentCapture() {
        val cartItems = listOf(CartItem(menuItem = SampleData.menuItems[0], quantity = 1))
        val quote = apiService.calculateQuote("loc_beverly_hills", DiningMode.PICKUP, null, cartItems, null, 15).getOrNull()!!

        val orderResult = apiService.createOrder(quote, "Alice Smith", "(310) 555-1234", "idemp_ord_test")
        assertTrue(orderResult.isSuccess)
        val order = orderResult.getOrNull()!!
        assertEquals(OrderStatus.AWAITING_PAYMENT, order.orderStatus)
        assertEquals(PaymentStatus.PENDING, order.paymentStatus)

        // Confirm payment
        val payResult = apiService.confirmPayment(order.id, "•••• 4242 (Visa)")
        assertTrue(payResult.isSuccess)
        val paidOrder = payResult.getOrNull()!!
        assertEquals(OrderStatus.CONFIRMED, paidOrder.orderStatus)
        assertEquals(PaymentStatus.PAID, paidOrder.paymentStatus)

        // Kitchen accepts
        val acceptResult = apiService.acceptOrder(paidOrder.id)
        assertEquals(OrderStatus.ACCEPTED, acceptResult.getOrNull()!!.orderStatus)

        // Kitchen prepares
        val prepResult = apiService.markOrderPreparing(paidOrder.id)
        assertEquals(OrderStatus.PREPARING, prepResult.getOrNull()!!.orderStatus)

        // Customer cannot cancel once preparing!
        val cancelAttempt = apiService.cancelOrder(paidOrder.id, "Change of mind")
        assertTrue("Cancellation must be rejected once kitchen is preparing", cancelAttempt.isFailure)

        // Mark ready and fulfilled
        val readyResult = apiService.markOrderReady(paidOrder.id)
        assertEquals(OrderStatus.READY, readyResult.getOrNull()!!.orderStatus)

        val fulfillResult = apiService.markOrderFulfilled(paidOrder.id)
        assertEquals(OrderStatus.FULFILLED, fulfillResult.getOrNull()!!.orderStatus)
    }

    @Test
    fun testRefundWorkflow() {
        val cartItems = listOf(CartItem(menuItem = SampleData.menuItems[0], quantity = 1))
        val quote = apiService.calculateQuote("loc_beverly_hills", DiningMode.PICKUP, null, cartItems, null, 0).getOrNull()!!
        val order = apiService.createOrder(quote, "Bob Miller", "(310) 555-5555", "idemp_ref_test").getOrNull()!!
        apiService.confirmPayment(order.id, "•••• 4242")

        val refundResult = apiService.refundOrder(order.id, "Customer requested refund at manager desk")
        assertTrue(refundResult.isSuccess)
        val refunded = refundResult.getOrNull()!!
        assertEquals(OrderStatus.REFUNDED, refunded.orderStatus)
        assertEquals(PaymentStatus.REFUNDED, refunded.paymentStatus)
    }

    @Test
    fun testStaffSeatingTransitions() {
        val res = apiService.lookupReservation("loc_beverly_hills", "CCF-7821").getOrNull()!!
        apiService.checkInReservation(res.id, "staff_seat_test_idemp")

        val seatResult = apiService.seatReservation(res.id, 5)
        assertTrue(seatResult.isSuccess)
        val seatedRes = seatResult.getOrNull()!!
        assertEquals(ArrivalStatus.SEATED, seatedRes.arrivalStatus)
        assertEquals(5, seatedRes.tableNumber)

        // Verify table status is updated
        val table5 = apiService.tables.value.first { it.tableNumber == 5 }
        assertEquals(TableStatus.OCCUPIED, table5.status)
        assertTrue(table5.assignedParty!!.contains("Sarah Connor"))
    }
}
