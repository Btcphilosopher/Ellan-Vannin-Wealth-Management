package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.MenuItem
import com.example.data.model.ModifierOption
import com.example.ui.theme.*

@Composable
fun DishCustomizerDialog(
    item: MenuItem,
    onDismiss: () -> Unit,
    onAddToCart: (item: MenuItem, quantity: Int, modifiers: Map<String, List<ModifierOption>>, notes: String) -> Unit
) {
    var quantity by remember { mutableIntStateOf(1) }
    var notes by remember { mutableStateOf("") }

    // Map groupId -> selected List<ModifierOption>
    val selectedModifiers = remember {
        mutableStateMapOf<String, List<ModifierOption>>().apply {
            item.modifierGroups.forEach { group ->
                val defaults = group.options.filter { it.isDefault }
                if (defaults.isNotEmpty()) {
                    put(group.id, defaults)
                } else if (group.required && group.options.isNotEmpty()) {
                    put(group.id, listOf(group.options.first()))
                }
            }
        }
    }

    // Calculate current unit price
    val unitPriceCents = remember(selectedModifiers.toMap()) {
        var price = item.priceCents
        selectedModifiers.values.forEach { opts ->
            opts.forEach { opt ->
                price += opt.priceDeltaCents
            }
        }
        price
    }

    val totalPriceCents = unitPriceCents * quantity

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.9f)
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Header with close button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BurgundyDeep)
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.name,
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$${"%.2f".format(item.priceCents / 100.0)} • ${item.calories} Calories",
                            style = MaterialTheme.typography.bodyMedium,
                            color = GoldLight
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_customizer_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                // Scrollable content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp)
                ) {
                    // Description
                    Text(
                        text = item.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedText,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Allergen Notice if present
                    if (!item.allergenNotice.isNullOrBlank()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFFFFBEB))
                                .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                Icons.Outlined.Warning,
                                contentDescription = "Allergen notice",
                                tint = StatusAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item.allergenNotice,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF92400E)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    // Modifier Groups
                    item.modifierGroups.forEach { group ->
                        Text(
                            text = group.name + if (group.required) " (Required)" else " (Optional)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (group.required) BurgundyDeep else CharcoalText
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        val currentSelections = selectedModifiers[group.id] ?: emptyList()

                        group.options.forEach { option ->
                            val isSelected = currentSelections.any { it.id == option.id }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) WarmSurfaceElevated else Color.Transparent)
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) GoldAccent else WarmBorder,
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable {
                                        if (group.maxSelections == 1) {
                                            selectedModifiers[group.id] = listOf(option)
                                        } else {
                                            if (isSelected) {
                                                selectedModifiers[group.id] =
                                                    currentSelections.filterNot { it.id == option.id }
                                            } else {
                                                if (currentSelections.size < group.maxSelections) {
                                                    selectedModifiers[group.id] =
                                                        currentSelections + option
                                                }
                                            }
                                        }
                                    }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = option.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CharcoalText,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                )
                                Text(
                                    text = if (option.priceDeltaCents > 0) "+$${"%.2f".format(option.priceDeltaCents / 100.0)}" else "Included",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (isSelected) BurgundyDeep else MutedText
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    // Special Instructions
                    Text(
                        text = "Chef & Kitchen Notes",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalText
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { if (it.length <= 150) notes = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dish_special_notes_input"),
                        placeholder = { Text("e.g. Dressing on side, extra crispy fries...") },
                        maxLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAccent,
                            unfocusedBorderColor = WarmBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Quantity Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Quantity",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(WarmSurfaceElevated)
                                .border(1.dp, WarmBorder, RoundedCornerShape(12.dp))
                                .padding(4.dp)
                        ) {
                            IconButton(
                                onClick = { if (quantity > 1) quantity-- },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("quantity_decrease_button")
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = BurgundyDeep)
                            }
                            Text(
                                text = quantity.toString(),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 14.dp)
                            )
                            IconButton(
                                onClick = { if (quantity < 20) quantity++ },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("quantity_increase_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Increase", tint = BurgundyDeep)
                            }
                        }
                    }
                }

                // Bottom Action Bar
                Surface(
                    tonalElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Total",
                                style = MaterialTheme.typography.labelMedium,
                                color = MutedText
                            )
                            Text(
                                text = "$${"%.2f".format(totalPriceCents / 100.0)}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = BurgundyDeep
                            )
                        }

                        Button(
                            onClick = {
                                onAddToCart(item, quantity, selectedModifiers.toMap(), notes)
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("confirm_add_to_cart_button")
                        ) {
                            Text(
                                text = "Add to Order • $${"%.2f".format(totalPriceCents / 100.0)}",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
