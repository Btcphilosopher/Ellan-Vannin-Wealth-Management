package com.example.data.service

import com.example.data.model.*
import com.example.data.sample.SampleData
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import kotlin.math.roundToInt

class RestaurantApiService private constructor() {

    companion object {
        @Volatile
        private var INSTANCE: RestaurantApiService? = null

        fun getInstance(): RestaurantApiService {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: RestaurantApiService().also { INSTANCE = it }
            }
        }
    }

    private val _locations = MutableStateFlow(SampleData.locations)
    val locations: StateFlow<List<RestaurantLocation>> = _locations.asStateFlow()

    private val _categories = MutableStateFlow(SampleData.categories)
    val categories: StateFlow<List<MenuCategory>> = _categories.asStateFlow()

    private val _menuItems = MutableStateFlow(SampleData.menuItems)
    val menuItems: StateFlow<List<MenuItem>> = _menuItems.asStateFlow()

    private val _reservations = MutableStateFlow(SampleData.reservations)
    val reservations: StateFlow<List<Reservation>> = _reservations.asStateFlow()

    private val _waitlist = MutableStateFlow(SampleData.waitlistEntries)
    val waitlist: StateFlow<List<WaitlistEntry>> = _waitlist.asStateFlow()

    private val _tables = MutableStateFlow(SampleData.tables)
    val tables: StateFlow<List<RestaurantTable>> = _tables.asStateFlow()

    private val _orders = MutableStateFlow(SampleData.sampleOrders)
    val orders: StateFlow<List<RestaurantOrder>> = _orders.asStateFlow()

    private val _eventFlow = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val eventFlow: SharedFlow<String> = _eventFlow.asSharedFlow()

    private val processedCheckIns = mutableSetOf<String>()
    private val processedOrderKeys = mutableSetOf<String>()

    fun resetForTesting() {
        _locations.value = SampleData.locations
        _categories.value = SampleData.categories
        _menuItems.value = SampleData.menuItems
        _reservations.value = SampleData.reservations
        _waitlist.value = SampleData.waitlistEntries
        _tables.value = SampleData.tables
        _orders.value = SampleData.sampleOrders
        processedCheckIns.clear()
        processedOrderKeys.clear()
    }

    // -------------------------------------------------------------
    // RESERVATIONS & CHECK-IN API
    // -------------------------------------------------------------

    fun lookupReservation(locationId: String, query: String): Result<Reservation> {
        val cleanQuery = query.trim().uppercase()
        val found = _reservations.value.firstOrNull { res ->
            res.locationId == locationId &&
                    (res.confirmationCode.uppercase() == cleanQuery ||
                            res.phone.replace(Regex("[^0-9]"), "").contains(query.replace(Regex("[^0-9]"), "")) ||
                            res.customerName.contains(query, ignoreCase = true))
        }
        return if (found != null) {
            Result.success(found)
        } else {
            Result.failure(IllegalArgumentException("No reservation matching '$query' found at this location. Please check your confirmation code or phone number."))
        }
    }

    fun checkInReservation(reservationId: String, idempotencyKey: String): Result<Reservation> {
        if (processedCheckIns.contains(idempotencyKey)) {
            val existing = _reservations.value.firstOrNull { it.id == reservationId }
            return if (existing != null) Result.success(existing)
            else Result.failure(IllegalStateException("Reservation not found"))
        }

        val currentList = _reservations.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == reservationId }
        if (index == -1) {
            return Result.failure(IllegalArgumentException("Reservation not found."))
        }

        val res = currentList[index]
        if (res.arrivalStatus != ArrivalStatus.RESERVED && res.arrivalStatus != ArrivalStatus.ARRIVAL_CONFIRMED) {
            return Result.failure(IllegalStateException("Cannot check in from state '${res.arrivalStatus.displayName}'"))
        }

        val updated = res.copy(
            arrivalStatus = ArrivalStatus.AWAITING_SEATING,
            checkInTimestamp = System.currentTimeMillis()
        )
        currentList[index] = updated
        _reservations.value = currentList
        processedCheckIns.add(idempotencyKey)

        _eventFlow.tryEmit("Arrival confirmed for ${updated.customerName} (Party of ${updated.partySize}). Table assignment in progress.")
        return Result.success(updated)
    }

    // -------------------------------------------------------------
    // WAITLIST API
    // -------------------------------------------------------------

    fun createWaitlistEntry(
        locationId: String,
        name: String,
        phone: String,
        partySize: Int,
        notes: String
    ): Result<WaitlistEntry> {
        if (name.isBlank() || phone.isBlank() || partySize <= 0) {
            return Result.failure(IllegalArgumentException("Invalid name, phone, or party size"))
        }

        val activeInLoc = _waitlist.value.filter {
            it.locationId == locationId && (it.status == WaitlistStatus.WAITING || it.status == WaitlistStatus.REQUESTED)
        }
        val nextQueueCode = "W-${100 + activeInLoc.size + 1}"
        val estWait = (activeInLoc.size + 1) * 8

        val entry = WaitlistEntry(
            id = "wait_${UUID.randomUUID()}",
            queueCode = nextQueueCode,
            locationId = locationId,
            customerName = name.trim(),
            phone = phone.trim(),
            partySize = partySize,
            status = WaitlistStatus.WAITING,
            queuePosition = activeInLoc.size + 1,
            estimatedWaitMinutes = estWait,
            requestedAt = System.currentTimeMillis(),
            seatingNotes = notes.trim()
        )

        _waitlist.value = _waitlist.value + entry
        _eventFlow.tryEmit("Waitlist ticket $nextQueueCode created for $name (Party of $partySize)")
        return Result.success(entry)
    }

    fun confirmWaitlistArrival(entryId: String): Result<WaitlistEntry> {
        val current = _waitlist.value.toMutableList()
        val index = current.indexOfFirst { it.id == entryId }
        if (index == -1) return Result.failure(IllegalArgumentException("Waitlist entry not found"))

        val item = current[index]
        val updated = item.copy(status = WaitlistStatus.WAITING)
        current[index] = updated
        _waitlist.value = current
        _eventFlow.tryEmit("Waitlist arrival confirmed for ${updated.customerName}")
        return Result.success(updated)
    }

    fun cancelWaitlistEntry(entryId: String): Result<WaitlistEntry> {
        val current = _waitlist.value.toMutableList()
        val index = current.indexOfFirst { it.id == entryId }
        if (index == -1) return Result.failure(IllegalArgumentException("Waitlist entry not found"))

        val item = current[index]
        val updated = item.copy(status = WaitlistStatus.CANCELLED)
        current[index] = updated
        _waitlist.value = current
        _eventFlow.tryEmit("Waitlist entry ${item.queueCode} cancelled")
        return Result.success(updated)
    }

    // -------------------------------------------------------------
    // CART & AUTHORITATIVE PRICING ENGINE
    // -------------------------------------------------------------

    fun calculateQuote(
        locationId: String,
        diningMode: DiningMode,
        tableNumber: Int?,
        items: List<CartItem>,
        promoCode: String?,
        tipPercentage: Int
    ): Result<CartQuote> {
        if (items.isEmpty()) {
            return Result.failure(IllegalArgumentException("Cart is empty"))
        }

        // Validate item availability at backend
        val currentMenuMap = _menuItems.value.associateBy { it.id }
        for (item in items) {
            val menuItem = currentMenuMap[item.menuItem.id]
            if (menuItem == null || !menuItem.isAvailable) {
                return Result.failure(IllegalStateException("Item '${item.menuItem.name}' is currently unavailable (86'd) at this location."))
            }
        }

        // Authoritative server-side calculation
        var subtotal = 0
        items.forEach { cartItem ->
            subtotal += cartItem.itemTotalCents
        }

        // Exact tax: 8.75%
        val tax = (subtotal * 0.0875).roundToInt()
        // Service fee: $2.00 for pickup packaging or $2.50 for dine-in operations
        val serviceFee = if (diningMode == DiningMode.PICKUP) 200 else 250

        // Tip calculation on subtotal
        val tip = if (tipPercentage > 0) (subtotal * (tipPercentage / 100.0)).roundToInt() else 0

        // Discount validation
        var discount = 0
        var validatedPromo: String? = null
        if (!promoCode.isNullOrBlank()) {
            when (promoCode.trim().uppercase()) {
                "SWEET10" -> {
                    // $10 off if cart subtotal is >= $25
                    if (subtotal >= 2500) {
                        discount = 1000
                        validatedPromo = "SWEET10 (-$10.00)"
                    }
                }
                "WELCOME" -> {
                    // 15% off subtotal
                    discount = (subtotal * 0.15).roundToInt()
                    validatedPromo = "WELCOME (15% off)"
                }
                else -> {
                    // invalid promo code ignored
                }
            }
        }

        val total = maxOf(0, subtotal + tax + serviceFee + tip - discount)
        val quote = CartQuote(
            quoteToken = "quote_${UUID.randomUUID().toString().take(12)}",
            expiresAtMillis = System.currentTimeMillis() + 15 * 60 * 1000L, // 15 min expiry
            locationId = locationId,
            diningMode = diningMode,
            tableNumber = tableNumber,
            items = items,
            subtotalCents = subtotal,
            taxCents = tax,
            serviceFeeCents = serviceFee,
            tipCents = tip,
            discountCents = discount,
            totalCents = total,
            promoCodeApplied = validatedPromo
        )
        return Result.success(quote)
    }

    // -------------------------------------------------------------
    // ORDERING & PAYMENT LIFECYCLE API
    // -------------------------------------------------------------

    fun createOrder(
        quote: CartQuote,
        customerName: String,
        customerPhone: String,
        idempotencyKey: String
    ): Result<RestaurantOrder> {
        if (processedOrderKeys.contains(idempotencyKey)) {
            val existing = _orders.value.firstOrNull { it.quoteToken == quote.quoteToken }
            if (existing != null) return Result.success(existing)
        }

        if (System.currentTimeMillis() > quote.expiresAtMillis) {
            return Result.failure(IllegalStateException("Quote has expired. Please refresh your cart quote to verify availability and current pricing."))
        }

        val location = _locations.value.firstOrNull { it.id == quote.locationId }
            ?: return Result.failure(IllegalArgumentException("Invalid restaurant location"))

        val orderNum = "CCF-ORD-${(1000..9999).random()}"
        val order = RestaurantOrder(
            id = "ord_${UUID.randomUUID().toString().take(8)}",
            orderNumber = orderNum,
            locationId = quote.locationId,
            locationName = location.name,
            customerName = customerName.trim(),
            customerPhone = customerPhone.trim(),
            diningMode = quote.diningMode,
            tableNumber = quote.tableNumber,
            items = quote.items,
            quoteToken = quote.quoteToken,
            subtotalCents = quote.subtotalCents,
            taxCents = quote.taxCents,
            serviceFeeCents = quote.serviceFeeCents,
            tipCents = quote.tipCents,
            discountCents = quote.discountCents,
            totalCents = quote.totalCents,
            paymentStatus = PaymentStatus.PENDING,
            orderStatus = OrderStatus.AWAITING_PAYMENT,
            paymentIntentId = "pi_${UUID.randomUUID().toString().take(12)}",
            auditLog = listOf(
                AuditEntry(
                    actor = "Customer",
                    action = "ORDER_CREATED",
                    details = "Order initiated for ${customerName}. Awaiting payment authorization."
                )
            )
        )

        _orders.value = listOf(order) + _orders.value
        processedOrderKeys.add(idempotencyKey)
        return Result.success(order)
    }

    fun confirmPayment(orderId: String, cardMask: String): Result<RestaurantOrder> {
        val currentOrders = _orders.value.toMutableList()
        val index = currentOrders.indexOfFirst { it.id == orderId }
        if (index == -1) return Result.failure(IllegalArgumentException("Order not found"))

        val order = currentOrders[index]
        if (order.paymentStatus == PaymentStatus.PAID) {
            return Result.success(order)
        }

        val updatedAudit = order.auditLog + AuditEntry(
            actor = "Payment Gateway",
            action = "PAYMENT_AUTHORIZED_AND_CAPTURED",
            details = "Card $cardMask authorized for $${"%.2f".format(order.totalCents / 100.0)}"
        ) + AuditEntry(
            actor = "System",
            action = "ORDER_CONFIRMED",
            details = "Order dispatched to Kitchen Display System"
        )

        val updatedOrder = order.copy(
            paymentStatus = PaymentStatus.PAID,
            orderStatus = OrderStatus.CONFIRMED,
            paymentMethodMask = cardMask,
            auditLog = updatedAudit
        )

        currentOrders[index] = updatedOrder
        _orders.value = currentOrders

        _eventFlow.tryEmit("Order ${order.orderNumber} confirmed & sent to Kitchen!")
        return Result.success(updatedOrder)
    }

    fun cancelOrder(orderId: String, reason: String): Result<RestaurantOrder> {
        val currentOrders = _orders.value.toMutableList()
        val index = currentOrders.indexOfFirst { it.id == orderId }
        if (index == -1) return Result.failure(IllegalArgumentException("Order not found"))

        val order = currentOrders[index]
        if (order.orderStatus == OrderStatus.PREPARING || order.orderStatus == OrderStatus.READY || order.orderStatus == OrderStatus.FULFILLED) {
            return Result.failure(IllegalStateException("Order is already being prepared or completed by the kitchen. Please speak with your server or manager."))
        }

        val updatedAudit = order.auditLog + AuditEntry(
            actor = "Customer",
            action = "ORDER_CANCELLED",
            details = "Cancelled: $reason"
        )
        val updatedOrder = order.copy(
            orderStatus = OrderStatus.CANCELLED,
            paymentStatus = if (order.paymentStatus == PaymentStatus.PAID) PaymentStatus.REFUNDED else order.paymentStatus,
            auditLog = updatedAudit
        )
        currentOrders[index] = updatedOrder
        _orders.value = currentOrders
        _eventFlow.tryEmit("Order ${order.orderNumber} cancelled by customer")
        return Result.success(updatedOrder)
    }

    // -------------------------------------------------------------
    // RESTAURANT STAFF CONSOLE OPERATIONS
    // -------------------------------------------------------------

    fun seatReservation(reservationId: String, tableNumber: Int): Result<Reservation> {
        val current = _reservations.value.toMutableList()
        val index = current.indexOfFirst { it.id == reservationId }
        if (index == -1) return Result.failure(IllegalArgumentException("Reservation not found"))

        val res = current[index]
        val updated = res.copy(
            arrivalStatus = ArrivalStatus.SEATED,
            tableNumber = tableNumber,
            seatedTimestamp = System.currentTimeMillis()
        )
        current[index] = updated
        _reservations.value = current

        // Update table status
        val currentTables = _tables.value.toMutableList()
        val tableIdx = currentTables.indexOfFirst { it.tableNumber == tableNumber }
        if (tableIdx != -1) {
            currentTables[tableIdx] = currentTables[tableIdx].copy(
                status = TableStatus.OCCUPIED,
                assignedParty = "${res.customerName} (${res.partySize})"
            )
            _tables.value = currentTables
        }

        _eventFlow.tryEmit("Party ${res.customerName} seated at Table $tableNumber")
        return Result.success(updated)
    }

    fun markReservationNoShow(reservationId: String): Result<Reservation> {
        val current = _reservations.value.toMutableList()
        val index = current.indexOfFirst { it.id == reservationId }
        if (index == -1) return Result.failure(IllegalArgumentException("Reservation not found"))

        val res = current[index]
        val updated = res.copy(arrivalStatus = ArrivalStatus.NO_SHOW)
        current[index] = updated
        _reservations.value = current
        _eventFlow.tryEmit("Reservation ${res.confirmationCode} marked as No-Show")
        return Result.success(updated)
    }

    fun markWaitlistReady(entryId: String, tableNumber: Int?): Result<WaitlistEntry> {
        val current = _waitlist.value.toMutableList()
        val index = current.indexOfFirst { it.id == entryId }
        if (index == -1) return Result.failure(IllegalArgumentException("Waitlist entry not found"))

        val item = current[index]
        val updated = item.copy(
            status = WaitlistStatus.READY_TO_SEAT,
            notifiedAt = System.currentTimeMillis(),
            tableNumber = tableNumber
        )
        current[index] = updated
        _waitlist.value = current
        _eventFlow.tryEmit("Table ready notification dispatched for ${item.customerName} (${item.queueCode})")
        return Result.success(updated)
    }

    fun seatWaitlistEntry(entryId: String, tableNumber: Int): Result<WaitlistEntry> {
        val current = _waitlist.value.toMutableList()
        val index = current.indexOfFirst { it.id == entryId }
        if (index == -1) return Result.failure(IllegalArgumentException("Waitlist entry not found"))

        val item = current[index]
        val updated = item.copy(
            status = WaitlistStatus.SEATED,
            seatedAt = System.currentTimeMillis(),
            tableNumber = tableNumber
        )
        current[index] = updated
        _waitlist.value = current

        // Update table
        val currentTables = _tables.value.toMutableList()
        val tableIdx = currentTables.indexOfFirst { it.tableNumber == tableNumber }
        if (tableIdx != -1) {
            currentTables[tableIdx] = currentTables[tableIdx].copy(
                status = TableStatus.OCCUPIED,
                assignedParty = "${item.customerName} (${item.partySize})"
            )
            _tables.value = currentTables
        }

        _eventFlow.tryEmit("Waitlist ${item.queueCode} (${item.customerName}) seated at Table $tableNumber")
        return Result.success(updated)
    }

    // Kitchen Operations
    fun acceptOrder(orderId: String): Result<RestaurantOrder> {
        return transitionOrderStatus(orderId, OrderStatus.ACCEPTED, "Kitchen Station", "ORDER_ACCEPTED", "Order sent to cook line")
    }

    fun markOrderPreparing(orderId: String): Result<RestaurantOrder> {
        return transitionOrderStatus(orderId, OrderStatus.PREPARING, "Chef Line", "START_PREPARING", "Dishes currently on grill & sauté stations")
    }

    fun markOrderReady(orderId: String): Result<RestaurantOrder> {
        return transitionOrderStatus(orderId, OrderStatus.READY, "Expediter", "ORDER_READY", "Plated, garnished, and boxed for serving/pickup")
    }

    fun markOrderFulfilled(orderId: String): Result<RestaurantOrder> {
        return transitionOrderStatus(orderId, OrderStatus.FULFILLED, "Service Staff", "ORDER_FULFILLED", "Handed off to guest")
    }

    fun refundOrder(orderId: String, reason: String): Result<RestaurantOrder> {
        val currentOrders = _orders.value.toMutableList()
        val index = currentOrders.indexOfFirst { it.id == orderId }
        if (index == -1) return Result.failure(IllegalArgumentException("Order not found"))

        val order = currentOrders[index]
        val updated = order.copy(
            orderStatus = OrderStatus.REFUNDED,
            paymentStatus = PaymentStatus.REFUNDED,
            auditLog = order.auditLog + AuditEntry(
                actor = "Manager",
                action = "ORDER_REFUNDED",
                details = "Authorized full refund of $${"%.2f".format(order.totalCents / 100.0)}: $reason"
            )
        )
        currentOrders[index] = updated
        _orders.value = currentOrders
        _eventFlow.tryEmit("Full refund issued for ${order.orderNumber}")
        return Result.success(updated)
    }

    private fun transitionOrderStatus(
        orderId: String,
        newStatus: OrderStatus,
        actor: String,
        action: String,
        details: String
    ): Result<RestaurantOrder> {
        val currentOrders = _orders.value.toMutableList()
        val index = currentOrders.indexOfFirst { it.id == orderId }
        if (index == -1) return Result.failure(IllegalArgumentException("Order not found"))

        val order = currentOrders[index]
        val updated = order.copy(
            orderStatus = newStatus,
            auditLog = order.auditLog + AuditEntry(actor = actor, action = action, details = details),
            completedAt = if (newStatus == OrderStatus.FULFILLED) System.currentTimeMillis() else order.completedAt
        )
        currentOrders[index] = updated
        _orders.value = currentOrders
        _eventFlow.tryEmit("Order ${order.orderNumber} is now ${newStatus.displayName}")
        return Result.success(updated)
    }

    // Menu Availability Management (86 Toggle)
    fun toggleItemAvailability(itemId: String): Result<MenuItem> {
        val currentItems = _menuItems.value.toMutableList()
        val index = currentItems.indexOfFirst { it.id == itemId }
        if (index == -1) return Result.failure(IllegalArgumentException("Menu item not found"))

        val item = currentItems[index]
        val updated = item.copy(isAvailable = !item.isAvailable)
        currentItems[index] = updated
        _menuItems.value = currentItems

        val statusWord = if (updated.isAvailable) "returned to stock" else "marked 86'd (Sold Out)"
        _eventFlow.tryEmit("${item.name} $statusWord")
        return Result.success(updated)
    }
}
