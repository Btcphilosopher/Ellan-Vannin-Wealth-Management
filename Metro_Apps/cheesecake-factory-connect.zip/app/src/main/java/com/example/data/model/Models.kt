package com.example.data.model

import java.util.UUID

enum class ArrivalStatus(val displayName: String) {
    RESERVED("Reserved"),
    ARRIVAL_CONFIRMED("Arrival Confirmed"),
    AWAITING_SEATING("Awaiting Seating"),
    SEATED("Seated"),
    CANCELLED("Cancelled"),
    NO_SHOW("No-Show")
}

enum class WaitlistStatus(val displayName: String) {
    REQUESTED("Requested"),
    ACCEPTED("Accepted"),
    WAITING("Waiting in Queue"),
    READY_TO_SEAT("Ready to Seat"),
    SEATED("Seated"),
    CANCELLED("Cancelled"),
    EXPIRED("Expired")
}

enum class TableStatus(val displayName: String) {
    AVAILABLE("Available"),
    OCCUPIED("Occupied"),
    RESERVED("Reserved"),
    CLEANING("Needs Cleaning")
}

enum class DiningMode(val displayName: String) {
    DINE_IN("Dine-In Table Service"),
    PICKUP("Curbside & Takeaway")
}

enum class OrderStatus(val displayName: String) {
    CREATED("Order Created"),
    AWAITING_PAYMENT("Awaiting Payment"),
    CONFIRMED("Order Confirmed"),
    ACCEPTED("Accepted by Kitchen"),
    PREPARING("Preparing in Kitchen"),
    READY("Ready for Serving / Pickup"),
    FULFILLED("Fulfilled / Completed"),
    CANCELLED("Cancelled"),
    REFUNDED("Refunded")
}

enum class PaymentStatus(val displayName: String) {
    PENDING("Payment Pending"),
    AUTHORIZED("Authorized"),
    PAID("Paid in Full"),
    FAILED("Payment Failed"),
    REFUNDED("Refunded")
}

data class RestaurantLocation(
    val id: String,
    val name: String,
    val address: String,
    val city: String,
    val state: String,
    val zip: String,
    val phone: String,
    val hours: String,
    val waitEstimateMinutes: Int,
    val currentWaitlistCount: Int,
    val waitlistEnabled: Boolean = true,
    val reservationsEnabled: Boolean = true,
    val dineInEnabled: Boolean = true,
    val pickupEnabled: Boolean = true
)

data class Reservation(
    val id: String,
    val confirmationCode: String,
    val locationId: String,
    val customerName: String,
    val phone: String,
    val email: String,
    val reservationDateTime: String,
    val partySize: Int,
    val arrivalStatus: ArrivalStatus,
    val seatingPreference: String = "No Preference",
    val tableNumber: Int? = null,
    val checkInTimestamp: Long? = null,
    val seatedTimestamp: Long? = null,
    val notes: String = ""
)

data class WaitlistEntry(
    val id: String,
    val queueCode: String,
    val locationId: String,
    val customerName: String,
    val phone: String,
    val partySize: Int,
    val status: WaitlistStatus,
    val queuePosition: Int,
    val estimatedWaitMinutes: Int,
    val requestedAt: Long,
    val notifiedAt: Long? = null,
    val seatedAt: Long? = null,
    val tableNumber: Int? = null,
    val seatingNotes: String = ""
) {
    val notes: String get() = seatingNotes
}

data class RestaurantTable(
    val id: String,
    val tableNumber: Int,
    val capacity: Int,
    val section: String,
    val status: TableStatus,
    val assignedParty: String? = null
)

data class MenuCategory(
    val id: String,
    val name: String,
    val description: String,
    val displayOrder: Int
)

data class ModifierOption(
    val id: String,
    val name: String,
    val priceDeltaCents: Int = 0,
    val isDefault: Boolean = false
)

data class ModifierGroup(
    val id: String,
    val name: String,
    val minSelections: Int = 0,
    val maxSelections: Int = 1,
    val required: Boolean = false,
    val options: List<ModifierOption> = emptyList()
)

data class MenuItem(
    val id: String,
    val categoryId: String,
    val locationId: String = "all",
    val name: String,
    val description: String,
    val priceCents: Int,
    val isAvailable: Boolean = true,
    val calories: Int,
    val dietaryTags: List<String> = emptyList(),
    val isSignature: Boolean = false,
    val allergenNotice: String? = null,
    val modifierGroups: List<ModifierGroup> = emptyList()
)

data class CartItem(
    val id: String = UUID.randomUUID().toString(),
    val menuItem: MenuItem,
    val quantity: Int = 1,
    val selectedModifiers: Map<String, List<ModifierOption>> = emptyMap(),
    val specialInstructions: String = ""
) {
    val unitPriceCents: Int
        get() {
            var total = menuItem.priceCents
            selectedModifiers.values.forEach { groupSelections ->
                groupSelections.forEach { opt ->
                    total += opt.priceDeltaCents
                }
            }
            return total
        }

    val itemTotalCents: Int
        get() = unitPriceCents * quantity
}

data class CartQuote(
    val quoteToken: String,
    val expiresAtMillis: Long,
    val locationId: String,
    val diningMode: DiningMode,
    val tableNumber: Int?,
    val items: List<CartItem>,
    val subtotalCents: Int,
    val taxCents: Int,
    val serviceFeeCents: Int,
    val tipCents: Int,
    val discountCents: Int,
    val totalCents: Int,
    val promoCodeApplied: String? = null
)

data class AuditEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val actor: String,
    val action: String,
    val details: String
)

data class RestaurantOrder(
    val id: String,
    val orderNumber: String,
    val locationId: String,
    val locationName: String,
    val customerName: String,
    val customerPhone: String,
    val diningMode: DiningMode,
    val tableNumber: Int? = null,
    val items: List<CartItem>,
    val quoteToken: String,
    val subtotalCents: Int,
    val taxCents: Int,
    val serviceFeeCents: Int,
    val tipCents: Int,
    val discountCents: Int,
    val totalCents: Int,
    val paymentStatus: PaymentStatus,
    val orderStatus: OrderStatus,
    val paymentIntentId: String,
    val paymentMethodMask: String = "•••• 4242 (Visa)",
    val createdAt: Long = System.currentTimeMillis(),
    val estimatedReadyAt: Long = System.currentTimeMillis() + 25 * 60 * 1000L,
    val completedAt: Long? = null,
    val auditLog: List<AuditEntry> = emptyList()
)

data class PaymentIntent(
    val id: String,
    val amountCents: Int,
    val currency: String = "USD",
    val status: PaymentStatus,
    val clientSecret: String
)
