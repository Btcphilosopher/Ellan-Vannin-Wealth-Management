package com.example.ui.screens.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CartQuote
import com.example.data.model.DiningMode
import com.example.ui.theme.*

@Composable
fun CheckoutScreen(
    quote: CartQuote?,
    customerName: String,
    customerPhone: String,
    isProcessing: Boolean,
    onAuthorizeAndPay: (cardMask: String) -> Unit,
    onBackToCart: () -> Unit
) {
    var selectedCardType by remember { mutableStateOf("VISA") } // VISA or GPAY

    if (quote == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No active quote found. Please return to cart.", color = MutedText)
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Secure Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Lock,
                contentDescription = "Secure Checkout",
                tint = StatusGreen,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Authorised Payment & Checkout",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BurgundyDeep
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Sandbox Simulator Notice
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F4F6)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Outlined.Shield,
                    contentDescription = null,
                    tint = StatusBlue,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Demonstration Payment Sandbox",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = StatusBlue
                    )
                    Text(
                        text = "Simulated card authorization tokenized without transmitting raw CVV or PAN data.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedText
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Order Summary Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, WarmBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Order Details",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = CharcoalText
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Guest Name", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                    Text(customerName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Phone", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                    Text(customerPhone, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Fulfillment Mode", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                    Text(
                        if (quote.diningMode == DiningMode.DINE_IN) "Dine-In (Table #${quote.tableNumber ?: 3})" else "Curbside Pickup",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = BurgundyDeep
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Items Ordered", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                    Text("${quote.items.sumOf { it.quantity }} items", style = MaterialTheme.typography.bodyMedium)
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = WarmBorder)
                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Authorised Amount", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = "$${"%.2f".format(quote.totalCents / 100.0)}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = BurgundyDeep
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Payment Method Selection
        Text(
            text = "Select Payment Method",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = CharcoalText
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Option 1: Visa 4242
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(
                    width = if (selectedCardType == "VISA") 2.dp else 1.dp,
                    color = if (selectedCardType == "VISA") GoldAccent else WarmBorder,
                    shape = RoundedCornerShape(14.dp)
                )
                .clickable { selectedCardType = "VISA" }
                .testTag("payment_option_visa"),
            colors = CardDefaults.cardColors(
                containerColor = if (selectedCardType == "VISA") WarmSurfaceElevated else MaterialTheme.colorScheme.surface
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CreditCard, contentDescription = null, tint = BurgundyDeep, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Visa ending in •••• 4242",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Expires 12/28 • Authorized test card",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedText
                        )
                    }
                }
                if (selectedCardType == "VISA") {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GoldAccent)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Option 2: Google Pay / Mobile Wallet
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(
                    width = if (selectedCardType == "GPAY") 2.dp else 1.dp,
                    color = if (selectedCardType == "GPAY") GoldAccent else WarmBorder,
                    shape = RoundedCornerShape(14.dp)
                )
                .clickable { selectedCardType = "GPAY" }
                .testTag("payment_option_gpay"),
            colors = CardDefaults.cardColors(
                containerColor = if (selectedCardType == "GPAY") WarmSurfaceElevated else MaterialTheme.colorScheme.surface
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.AccountBalanceWallet, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Google Pay / Apple Pay Express",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Instant 1-touch biometric token authorization",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedText
                        )
                    }
                }
                if (selectedCardType == "GPAY") {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GoldAccent)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Action Buttons
        Button(
            onClick = {
                val mask = if (selectedCardType == "VISA") "•••• 4242 (Visa)" else "Google Pay (Tokenized)"
                onAuthorizeAndPay(mask)
            },
            enabled = !isProcessing,
            colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("authorize_payment_button")
        ) {
            if (isProcessing) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text("Authorizing Payment Provider...")
            } else {
                Text(
                    text = "Authorize & Submit Order • $${"%.2f".format(quote.totalCents / 100.0)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedButton(
            onClick = onBackToCart,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Back to Cart", color = BurgundyDeep)
        }
    }
}
