package com.example.data.sample

import com.example.data.model.*
import java.util.UUID

object SampleData {

    val locations = listOf(
        RestaurantLocation(
            id = "loc_beverly_hills",
            name = "Beverly Hills Flagship",
            address = "364 N Beverly Dr",
            city = "Beverly Hills",
            state = "CA",
            zip = "90210",
            phone = "(310) 555-0192",
            hours = "11:00 AM - 11:30 PM",
            waitEstimateMinutes = 35,
            currentWaitlistCount = 7,
            waitlistEnabled = true,
            reservationsEnabled = true
        ),
        RestaurantLocation(
            id = "loc_chicago_mag_mile",
            name = "Chicago Magnificent Mile",
            address = "875 N Michigan Ave (John Hancock Ctr)",
            city = "Chicago",
            state = "IL",
            zip = "60611",
            phone = "(312) 555-0144",
            hours = "11:30 AM - 11:00 PM",
            waitEstimateMinutes = 20,
            currentWaitlistCount = 4,
            waitlistEnabled = true,
            reservationsEnabled = true
        ),
        RestaurantLocation(
            id = "loc_sf_union_sq",
            name = "San Francisco Union Square",
            address = "251 Geary St (8th Floor)",
            city = "San Francisco",
            state = "CA",
            zip = "94102",
            phone = "(415) 555-0188",
            hours = "11:00 AM - 10:30 PM",
            waitEstimateMinutes = 15,
            currentWaitlistCount = 2,
            waitlistEnabled = true,
            reservationsEnabled = true
        ),
        RestaurantLocation(
            id = "loc_orlando_millenia",
            name = "Orlando at The Mall at Millenia",
            address = "4200 Conroy Rd #A-140",
            city = "Orlando",
            state = "FL",
            zip = "32839",
            phone = "(407) 555-0112",
            hours = "11:00 AM - 11:00 PM",
            waitEstimateMinutes = 45,
            currentWaitlistCount = 9,
            waitlistEnabled = true,
            reservationsEnabled = true
        )
    )

    val categories = listOf(
        MenuCategory("cat_cheesecake", "Cheesecakes & Desserts", "Our world-famous legendary cheesecakes and specialty confections", 1),
        MenuCategory("cat_pastas", "Pastas & Specialties", "Rich, slow-simmered pastas and handcrafted entrees", 2),
        MenuCategory("cat_glamburgers", "Glamburgers & Sandwiches", "Prime artisan beef burgers on toasted brioche buns", 3),
        MenuCategory("cat_small_plates", "Small Plates & Appetizers", "Shareable crowd favorites made fresh to order", 4),
        MenuCategory("cat_salads", "Farm-Fresh Salads", "Crisp greens tossed with house-crafted vinaigrettes", 5),
        MenuCategory("cat_beverages", "Specialty Beverages", "Handcrafted lemonades, cold brews, and mocktails", 6)
    )

    // Common Modifier Groups
    val sideChoiceGroup = ModifierGroup(
        id = "mod_sides",
        name = "Choose Your Side",
        minSelections = 1,
        maxSelections = 1,
        required = true,
        options = listOf(
            ModifierOption("side_fries", "Skinny Fries", 0, isDefault = true),
            ModifierOption("side_spicy_fries", "Spicy Seasoned Fries", 75),
            ModifierOption("side_caesar", "Side Caesar Salad", 150),
            ModifierOption("side_sweet_potato", "Sweet Potato Crisps", 195)
        )
    )

    val burgerTempGroup = ModifierGroup(
        id = "mod_burger_temp",
        name = "Cooking Temperature",
        minSelections = 1,
        maxSelections = 1,
        required = true,
        options = listOf(
            ModifierOption("temp_rare", "Rare (Cool red center)", 0),
            ModifierOption("temp_med_rare", "Medium-Rare (Warm red center)", 0),
            ModifierOption("temp_medium", "Medium (Warm pink center)", 0, isDefault = true),
            ModifierOption("temp_med_well", "Medium-Well (Slight pink)", 0),
            ModifierOption("temp_well", "Well-Done (No pink)", 0)
        )
    )

    val cheesecakeToppingsGroup = ModifierGroup(
        id = "mod_cheesecake_toppings",
        name = "Extra Flourishes",
        minSelections = 0,
        maxSelections = 3,
        required = false,
        options = listOf(
            ModifierOption("top_fresh_strawberries", "Fresh Glazed Strawberries", 195),
            ModifierOption("top_extra_chantilly", "Extra Handcrafted Chantilly Whipped Cream", 95),
            ModifierOption("top_caramel_drizzle", "Fleur de Sel Salted Caramel Drizzle", 125),
            ModifierOption("top_chocolate_fudge", "Warm Belgian Chocolate Fudge", 150)
        )
    )

    val pastaProteinGroup = ModifierGroup(
        id = "mod_pasta_protein",
        name = "Add Protein",
        minSelections = 0,
        maxSelections = 1,
        required = false,
        options = listOf(
            ModifierOption("protein_chicken", "Herb-Grilled Chicken Breast", 495),
            ModifierOption("protein_shrimp", "Wild Jumbo Garlic Shrimp", 695),
            ModifierOption("protein_salmon", "Pan-Seared Atlantic Salmon", 895)
        )
    )

    val menuItems = listOf(
        // Cheesecakes
        MenuItem(
            id = "item_original_cheesecake",
            categoryId = "cat_cheesecake",
            name = "Original Grand Cheesecake",
            description = "Our legendary creamy cheesecake baked in a buttery graham cracker crust, finished with sour cream glaze and towering chantilly whipped cream.",
            priceCents = 1095,
            calories = 830,
            isSignature = true,
            dietaryTags = listOf("Signature", "Vegetarian"),
            allergenNotice = "Contains dairy, eggs, and wheat. Made in a facility handling tree nuts.",
            modifierGroups = listOf(cheesecakeToppingsGroup)
        ),
        MenuItem(
            id = "item_strawberry_cheesecake",
            categoryId = "cat_cheesecake",
            name = "Fresh Glazed Strawberry Cheesecake",
            description = "The most popular dessert in America for 40 years! Topped with fresh hand-glazed ripe strawberries and whipped cream.",
            priceCents = 1195,
            calories = 1000,
            isSignature = true,
            dietaryTags = listOf("Top Seller", "Vegetarian"),
            allergenNotice = "Contains dairy, eggs, and wheat.",
            modifierGroups = listOf(cheesecakeToppingsGroup)
        ),
        MenuItem(
            id = "item_godiva_chocolate_cheesecake",
            categoryId = "cat_cheesecake",
            name = "Godiva® Decadent Chocolate Cheesecake",
            description = "Layers of rich flourless Godiva chocolate cake, Godiva chocolate cheesecake, and chocolate mousse topped with ganache.",
            priceCents = 1250,
            calories = 1400,
            isSignature = true,
            dietaryTags = listOf("Gluten-Free Friendly", "Decadent"),
            allergenNotice = "Contains dairy and eggs. Flourless recipe; cross-contact possible.",
            modifierGroups = listOf(cheesecakeToppingsGroup)
        ),
        MenuItem(
            id = "item_salted_caramel_cheesecake",
            categoryId = "cat_cheesecake",
            name = "Salted Caramel Caramel Cheesecake",
            description = "Caramel cheesecake topped with caramel mousse and salted caramel drizzle on a vanilla crumb crust.",
            priceCents = 1195,
            calories = 1260,
            dietaryTags = listOf("Vegetarian"),
            allergenNotice = "Contains dairy, wheat, and eggs.",
            modifierGroups = listOf(cheesecakeToppingsGroup)
        ),
        MenuItem(
            id = "item_key_lime_cheesecake",
            categoryId = "cat_cheesecake",
            name = "Key Lime Tart Cheesecake",
            description = "Key Lime pie in a cheesecake! Tart and refreshing with authentic Florida key lime juice in a vanilla crumb crust.",
            priceCents = 1150,
            calories = 940,
            dietaryTags = listOf("Refreshing", "Vegetarian"),
            allergenNotice = "Contains dairy, wheat, and eggs.",
            modifierGroups = listOf(cheesecakeToppingsGroup)
        ),

        // Pastas & Specialties
        MenuItem(
            id = "item_pasta_carbonara",
            categoryId = "cat_pastas",
            name = "Spaghetti Alla Carbonara",
            description = "Spaghetti tossed with smoked pancetta, sweet green peas, and cracked black pepper in a silky garlic-parmesan cream sauce.",
            priceCents = 2195,
            calories = 1850,
            isSignature = true,
            dietaryTags = listOf("House Favorite"),
            allergenNotice = "Contains wheat, milk, eggs, pork.",
            modifierGroups = listOf(pastaProteinGroup)
        ),
        MenuItem(
            id = "item_chicken_madeira",
            categoryId = "cat_pastas",
            name = "Famous Chicken Madeira",
            description = "Our #1 most popular chicken dish. Sautéed chicken breast topped with fresh asparagus, melted fontina cheese, and savory mushroom Madeira sauce over mashed potatoes.",
            priceCents = 2495,
            calories = 1490,
            isSignature = true,
            dietaryTags = listOf("Signature"),
            allergenNotice = "Contains dairy and wine glaze."
        ),
        MenuItem(
            id = "item_fettuccine_alfredo",
            categoryId = "cat_pastas",
            name = "Fettuccine Alfredo Florentine",
            description = "Tender egg fettuccine tossed in a rich, velvety parmesan cream sauce with baby spinach, sweet garlic, and fresh nutmeg.",
            priceCents = 1995,
            calories = 1680,
            dietaryTags = listOf("Vegetarian"),
            allergenNotice = "Contains wheat, milk, and eggs.",
            modifierGroups = listOf(pastaProteinGroup)
        ),
        MenuItem(
            id = "item_shrimp_scampi",
            categoryId = "cat_pastas",
            name = "Bistro Shrimp Scampi",
            description = "Parisian bistro style! Sautéed wild white shrimp with garlic, white wine, fresh basil, and oven-roasted tomatoes tossed with angel hair pasta.",
            priceCents = 2550,
            calories = 1320,
            dietaryTags = listOf("Seafood"),
            allergenNotice = "Contains shellfish, wheat, and dairy."
        ),

        // Glamburgers
        MenuItem(
            id = "item_americana_burger",
            categoryId = "cat_glamburgers",
            name = "Americana Cheeseburger",
            description = "Certified Angus beef smash-griddled with American and Cheddar cheeses, crisp lettuce, vine-ripened tomato, red onion, pickles, and our signature secret thousand sauce.",
            priceCents = 1895,
            calories = 1180,
            isSignature = true,
            dietaryTags = listOf("Classic"),
            allergenNotice = "Contains wheat, dairy, and eggs.",
            modifierGroups = listOf(burgerTempGroup, sideChoiceGroup)
        ),
        MenuItem(
            id = "item_smokehouse_bbq_burger",
            categoryId = "cat_glamburgers",
            name = "Smokehouse BBQ Bacon Burger",
            description = "Smoked bacon, melted sharp cheddar, crispy beer-battered onion strings, and tangy bourbon BBQ sauce on brioche.",
            priceCents = 2050,
            calories = 1450,
            dietaryTags = listOf("Bold"),
            allergenNotice = "Contains wheat, dairy, and pork.",
            modifierGroups = listOf(burgerTempGroup, sideChoiceGroup)
        ),
        MenuItem(
            id = "item_truffle_bacon_burger",
            categoryId = "cat_glamburgers",
            name = "Black Truffle & Swiss Glamburger",
            description = "Glazed wild forest mushrooms, melted cave-aged Swiss cheese, black truffle aioli, and baby arugula on a brioche bun.",
            priceCents = 2195,
            calories = 1320,
            dietaryTags = listOf("Chef Special"),
            allergenNotice = "Contains dairy, eggs, and wheat.",
            modifierGroups = listOf(burgerTempGroup, sideChoiceGroup)
        ),

        // Small Plates
        MenuItem(
            id = "item_avocado_eggrolls",
            categoryId = "cat_small_plates",
            name = "Original Avocado Eggrolls",
            description = "Avocado, sun-dried tomato, red onion, and cilantro fried in a crisp wrapper. Served with tamarind-cashew dipping sauce.",
            priceCents = 1595,
            calories = 960,
            isSignature = true,
            dietaryTags = listOf("Signature", "Vegetarian"),
            allergenNotice = "Contains tree nuts (cashews) and wheat."
        ),
        MenuItem(
            id = "item_crispy_crab_wontons",
            categoryId = "cat_small_plates",
            name = "Crispy Crab & Cream Cheese Bites",
            description = "Crispy hand-pinched wontons filled with lump blue crab, cream cheese, scallions, and sweet spicy chili plum dip.",
            priceCents = 1450,
            calories = 720,
            dietaryTags = listOf("Seafood"),
            allergenNotice = "Contains shellfish, milk, and wheat."
        ),
        MenuItem(
            id = "item_thai_lettuce_wraps",
            categoryId = "cat_small_plates",
            name = "Thai Chicken Lettuce Wraps",
            description = "Create your own wraps with satay chicken strips, carrots, bean sprouts, rice noodles, and spicy peanut and tamarind-cashew sauces.",
            priceCents = 1750,
            calories = 1010,
            dietaryTags = listOf("Shareable"),
            allergenNotice = "Contains peanuts, tree nuts, and soy."
        ),

        // Salads
        MenuItem(
            id = "item_luau_salad",
            categoryId = "cat_salads",
            name = "Santa Fe Chopped Salad",
            description = "Crisp romaine, black beans, sweet roasted corn, cilantro, tortilla strips, jack cheese, and spicy peanut cilantro vinaigrette.",
            priceCents = 1795,
            calories = 890,
            dietaryTags = listOf("Vegetarian", "Gluten-Free Friendly"),
            allergenNotice = "Contains peanuts and milk.",
            modifierGroups = listOf(pastaProteinGroup)
        ),
        MenuItem(
            id = "item_caesar_salad",
            categoryId = "cat_salads",
            name = "Caesar Supreme Salad",
            description = "Crisp hearts of romaine tossed with our classic house-made creamy garlic caesar dressing, sourdough croutons, and shaved Parmigiano-Reggiano.",
            priceCents = 1595,
            calories = 620,
            dietaryTags = listOf("Classic"),
            allergenNotice = "Contains dairy, wheat, and anchovy.",
            modifierGroups = listOf(pastaProteinGroup)
        ),

        // Beverages
        MenuItem(
            id = "item_strawberry_lemonade",
            categoryId = "cat_beverages",
            name = "Handcrafted Strawberry Lemonade",
            description = "Freshly squeezed Meyer lemons infused with sweet California strawberry purée and mint leaves. Complimentary refills.",
            priceCents = 595,
            calories = 180,
            isSignature = true,
            dietaryTags = listOf("Vegan", "Refreshing")
        ),
        MenuItem(
            id = "item_passion_fruit_iced_tea",
            categoryId = "cat_beverages",
            name = "Tropical Passion Fruit Iced Tea",
            description = "Artisanal black tea brewed with crushed passion fruit and guava. Refreshing and unsweetened or sweetened upon request.",
            priceCents = 495,
            calories = 10,
            dietaryTags = listOf("Zero Sugar Available")
        ),
        MenuItem(
            id = "item_cold_brew_caramel",
            categoryId = "cat_beverages",
            name = "Salted Caramel Velvet Cold Brew",
            description = "Slow-steeped Arabica cold brew coffee topped with salted caramel cold foam and turbinado sugar crystals.",
            priceCents = 650,
            calories = 190,
            dietaryTags = listOf("Caffeinated", "Vegetarian")
        )
    )

    val tables = listOf(
        RestaurantTable("tbl_1", 1, 2, "Main Dining", TableStatus.AVAILABLE),
        RestaurantTable("tbl_2", 2, 4, "Window Booth", TableStatus.OCCUPIED, "Party Evans (4)"),
        RestaurantTable("tbl_3", 3, 4, "Window Booth", TableStatus.AVAILABLE),
        RestaurantTable("tbl_4", 4, 6, "Grand Pavilion", TableStatus.RESERVED, "Miller CCF-4412"),
        RestaurantTable("tbl_5", 5, 2, "Patio Terrace", TableStatus.AVAILABLE),
        RestaurantTable("tbl_6", 6, 2, "Patio Terrace", TableStatus.CLEANING),
        RestaurantTable("tbl_7", 7, 4, "Main Dining", TableStatus.AVAILABLE),
        RestaurantTable("tbl_8", 8, 8, "Private Alcove", TableStatus.AVAILABLE),
        RestaurantTable("tbl_9", 9, 4, "Main Dining", TableStatus.OCCUPIED, "Party Rodriguez (3)"),
        RestaurantTable("tbl_10", 10, 2, "Window Booth", TableStatus.AVAILABLE)
    )

    val reservations = listOf(
        Reservation(
            id = "res_1",
            confirmationCode = "CCF-7821",
            locationId = "loc_beverly_hills",
            customerName = "Sarah Connor",
            phone = "(310) 555-8822",
            email = "sarah.c@example.com",
            reservationDateTime = "Today, 7:30 PM",
            partySize = 4,
            arrivalStatus = ArrivalStatus.RESERVED,
            seatingPreference = "Quiet booth preferred",
            notes = "Anniversary celebration"
        ),
        Reservation(
            id = "res_2",
            confirmationCode = "CCF-4412",
            locationId = "loc_beverly_hills",
            customerName = "David Miller",
            phone = "(310) 555-3390",
            email = "dmiller@example.com",
            reservationDateTime = "Today, 7:45 PM",
            partySize = 6,
            arrivalStatus = ArrivalStatus.AWAITING_SEATING,
            seatingPreference = "High chair needed for toddler",
            tableNumber = 4,
            checkInTimestamp = System.currentTimeMillis() - 12 * 60 * 1000L,
            notes = "Checked in at host stand. Table being prepped."
        ),
        Reservation(
            id = "res_3",
            confirmationCode = "CCF-9031",
            locationId = "loc_beverly_hills",
            customerName = "Marcus Vance",
            phone = "(310) 555-9011",
            email = "marcus.v@example.com",
            reservationDateTime = "Today, 8:15 PM",
            partySize = 2,
            arrivalStatus = ArrivalStatus.RESERVED,
            seatingPreference = "Patio terrace preferred"
        ),
        Reservation(
            id = "res_4",
            confirmationCode = "CCF-1102",
            locationId = "loc_chicago_mag_mile",
            customerName = "Emily Zhang",
            phone = "(312) 555-6677",
            email = "emily.z@example.com",
            reservationDateTime = "Today, 7:00 PM",
            partySize = 3,
            arrivalStatus = ArrivalStatus.SEATED,
            tableNumber = 2,
            checkInTimestamp = System.currentTimeMillis() - 40 * 60 * 1000L,
            seatedTimestamp = System.currentTimeMillis() - 25 * 60 * 1000L
        )
    )

    val waitlistEntries = listOf(
        WaitlistEntry(
            id = "wait_1",
            queueCode = "W-101",
            locationId = "loc_beverly_hills",
            customerName = "James Thornton",
            phone = "(310) 555-7711",
            partySize = 2,
            status = WaitlistStatus.WAITING,
            queuePosition = 1,
            estimatedWaitMinutes = 8,
            requestedAt = System.currentTimeMillis() - 22 * 60 * 1000L,
            seatingNotes = "First available indoor booth"
        ),
        WaitlistEntry(
            id = "wait_2",
            queueCode = "W-102",
            locationId = "loc_beverly_hills",
            customerName = "Elena Rostova",
            phone = "(310) 555-4422",
            partySize = 4,
            status = WaitlistStatus.READY_TO_SEAT,
            queuePosition = 2,
            estimatedWaitMinutes = 2,
            requestedAt = System.currentTimeMillis() - 35 * 60 * 1000L,
            notifiedAt = System.currentTimeMillis() - 3 * 60 * 1000L,
            tableNumber = 3,
            seatingNotes = "SMS sent. Pager buzzer buzzing."
        ),
        WaitlistEntry(
            id = "wait_3",
            queueCode = "W-103",
            locationId = "loc_beverly_hills",
            customerName = "Alexandre Dupont",
            phone = "(310) 555-1199",
            partySize = 5,
            status = WaitlistStatus.WAITING,
            queuePosition = 3,
            estimatedWaitMinutes = 24,
            requestedAt = System.currentTimeMillis() - 10 * 60 * 1000L,
            seatingNotes = "Celebration dinner"
        )
    )

    val sampleOrders = listOf(
        RestaurantOrder(
            id = "ord_demo_101",
            orderNumber = "CCF-ORD-8821",
            locationId = "loc_beverly_hills",
            locationName = "Beverly Hills Flagship",
            customerName = "Rachel Green",
            customerPhone = "(310) 555-2244",
            diningMode = DiningMode.DINE_IN,
            tableNumber = 2,
            items = listOf(
                CartItem(
                    menuItem = menuItems[0], // Original cheesecake
                    quantity = 2,
                    specialInstructions = "Extra chantilly cream"
                ),
                CartItem(
                    menuItem = menuItems[5], // Chicken Madeira
                    quantity = 1
                ),
                CartItem(
                    menuItem = menuItems[17], // Strawberry lemonade
                    quantity = 2
                )
            ),
            quoteToken = "quote_seed_8821",
            subtotalCents = 5880,
            taxCents = 515,
            serviceFeeCents = 250,
            tipCents = 1176,
            discountCents = 0,
            totalCents = 7821,
            paymentStatus = PaymentStatus.PAID,
            orderStatus = OrderStatus.PREPARING,
            paymentIntentId = "pi_seed_8821",
            createdAt = System.currentTimeMillis() - 14 * 60 * 1000L,
            auditLog = listOf(
                AuditEntry(actor = "Customer", action = "ORDER_PLACED", details = "Order created and card authorized"),
                AuditEntry(actor = "Kitchen Station", action = "ORDER_ACCEPTED", details = "Cook line fired appetizers and entrees")
            )
        ),
        RestaurantOrder(
            id = "ord_demo_102",
            orderNumber = "CCF-ORD-8822",
            locationId = "loc_beverly_hills",
            locationName = "Beverly Hills Flagship",
            customerName = "Carlos Santana",
            customerPhone = "(310) 555-6611",
            diningMode = DiningMode.PICKUP,
            tableNumber = null,
            items = listOf(
                CartItem(
                    menuItem = menuItems[1], // Strawberry cheesecake
                    quantity = 1
                ),
                CartItem(
                    menuItem = menuItems[8], // Americana Burger
                    quantity = 2,
                    selectedModifiers = mapOf(
                        "mod_burger_temp" to listOf(burgerTempGroup.options[2]),
                        "mod_sides" to listOf(sideChoiceGroup.options[0])
                    )
                )
            ),
            quoteToken = "quote_seed_8822",
            subtotalCents = 4985,
            taxCents = 436,
            serviceFeeCents = 200,
            tipCents = 800,
            discountCents = 0,
            totalCents = 6421,
            paymentStatus = PaymentStatus.PAID,
            orderStatus = OrderStatus.READY,
            paymentIntentId = "pi_seed_8822",
            createdAt = System.currentTimeMillis() - 28 * 60 * 1000L,
            auditLog = listOf(
                AuditEntry(actor = "Customer", action = "ORDER_PLACED", details = "Curbside pickup requested"),
                AuditEntry(actor = "Kitchen Station", action = "ORDER_ACCEPTED", details = "Grill fired"),
                AuditEntry(actor = "Expediter", action = "ORDER_READY", details = "Packaged at Host counter with utensils")
            )
        )
    )
}
