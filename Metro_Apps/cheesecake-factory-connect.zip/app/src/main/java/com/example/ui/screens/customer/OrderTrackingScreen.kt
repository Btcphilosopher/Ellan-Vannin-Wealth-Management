package com.example.ui.screens.customer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DiningMode
import com.example.data.model.OrderStatus
import com.example.data.model.RestaurantOrder
import com.example.ui.components.OrderStatusBadge
import com.example.ui.components.PaymentStatusBadge
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun OrderTrackingScreen(
    order: RestaurantOrder?,
    onCancelOrder: (orderId: String, reason: String) -> Unit,
    onBackToHome: () -> Unit
) {
    var showAuditTrail by remember { mutableStateOf(false) }
    var showCancelDialog by remember { mutableStateOf(false) }

    if (order == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No active order being tracked", style = MaterialTheme.typography.titleMedium, color = MutedText)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = onBackToHome, colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep)) {
                    Text("Return Home")
                }
            }
        }
        return
    }

    val stepIndex = when (order.orderStatus) {
        OrderStatus.CREATED, OrderStatus.AWAITING_PAYMENT -> 0
        OrderStatus.CONFIRMED -> 1
        OrderStatus.ACCEPTED -> 2
        OrderStatus.PREPARING -> 3
        OrderStatus.READY -> 4
        OrderStatus.FULFILLED -> 5
        OrderStatus.CANCELLED, OrderStatus.REFUNDED -> -1
    }

    val canCancel = order.orderStatus == OrderStatus.CONFIRMED || order.orderStatus == OrderStatus.ACCEPTED

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Order Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = order.orderNumber,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = BurgundyDeep
                        )
                        Text(
                            text = "${order.locationName} • ${order.diningMode.displayName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedText
                        )
                        if (order.tableNumber != null) {
                            Text(
                                text = "Serving at Table #${order.tableNumber}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = StatusGreen
                            )
                        }
                    }
                    OrderStatusBadge(status = order.orderStatus)
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PaymentStatusBadge(status = order.paymentStatus)
                    Text(
                        text = "Total Paid: $${"%.2f".format(order.totalCents / 100.0)}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalText
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Live Kitchen Progress Stepper
        if (order.orderStatus != OrderStatus.CANCELLED && order.orderStatus != OrderStatus.REFUNDED) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, WarmBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Kitchen Fulfilment Progress",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalText
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    val steps = listOf(
                        "Order Confirmed" to "Dispatched to restaurant KDS",
                        "Accepted" to "Cook line confirmed ticket",
                        "Preparing" to "Dishes on grill, sauté & pastry stations",
                        "Ready" to if (order.diningMode == DiningMode.DINE_IN) "Being delivered to your table" else "Ready at host pickup counter",
                        "Fulfilled" to "Completed & enjoyed"
                    )

                    steps.forEachIndexed { idx, (title, desc) ->
                        val stepNumber = idx + 1
                        val isCompleted = stepIndex >= stepNumber
                        val isCurrent = stepIndex == stepNumber

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                isCompleted -> StatusGreen
                                                isCurrent -> BurgundyDeep
                                                else -> Color(0xFFE5E7EB)
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isCompleted) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    } else {
                                        Text(
                                            text = "$stepNumber",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isCurrent) GoldLight else Color(0xFF9CA3AF)
                                        )
                                    }
                                }

                                if (idx < steps.size - 1) {
                                    Box(
                                        modifier = Modifier
                                            .width(2.dp)
                                            .height(30.dp)
                                            .background(if (stepIndex > stepNumber) StatusGreen else Color(0xFFE5E7EB))
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.padding(bottom = if (idx < steps.size - 1) 16.dp else 0.dp)) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isCurrent) FontWeight.ExtraBold else FontWeight.SemiBold,
                                    color = if (isCurrent) BurgundyDeep else if (isCompleted) CharcoalText else MutedText
                                )
                                Text(
                                    text = desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isCurrent) CharcoalText else MutedText
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Order Line-Items Receipt Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, WarmBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.ReceiptLong, contentDescription = null, tint = BurgundyDeep)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Receipt & Items Breakdown",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalText
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                order.items.forEach { cartItem ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${cartItem.quantity}x ${cartItem.menuItem.name}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            cartItem.selectedModifiers.values.flatten().forEach { mod ->
                                Text(
                                    text = "  + ${mod.name}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BurgundyDeep
                                )
                            }
                            if (cartItem.specialInstructions.isNotBlank()) {
                                Text(
                                    text = "  Note: ${cartItem.specialInstructions}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MutedText
                                )
                            }
                        }
                        Text(
                            text = "$${"%.2f".format(cartItem.itemTotalCents / 100.0)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = WarmBorder)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Subtotal", style = MaterialTheme.typography.bodySmall, color = MutedText)
                    Text("$${"%.2f".format(order.subtotalCents / 100.0)}", style = MaterialTheme.typography.bodySmall)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Tax (8.75%)", style = MaterialTheme.typography.bodySmall, color = MutedText)
                    Text("$${"%.2f".format(order.taxCents / 100.0)}", style = MaterialTheme.typography.bodySmall)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Service Fee", style = MaterialTheme.typography.bodySmall, color = MutedText)
                    Text("$${"%.2f".format(order.serviceFeeCents / 100.0)}", style = MaterialTheme.typography.bodySmall)
                }
                if (order.tipCents > 0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Server Tip", style = MaterialTheme.typography.bodySmall, color = MutedText)
                        Text("$${"%.2f".format(order.tipCents / 100.0)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (order.discountCents > 0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Discount", style = MaterialTheme.typography.bodySmall, color = StatusGreen)
                        Text("-$${"%.2f".format(order.discountCents / 100.0)}", style = MaterialTheme.typography.bodySmall, color = StatusGreen)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Paid", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("$${"%.2f".format(order.totalCents / 100.0)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = BurgundyDeep)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Authoritative Audit Trail Collapsible
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, WarmBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAuditTrail = !showAuditTrail },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Authoritative Server Audit Trail (${order.auditLog.size} events)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalText
                    )
                    Icon(
                        if (showAuditTrail) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Toggle audit log"
                    )
                }

                AnimatedVisibility(visible = showAuditTrail) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                        order.auditLog.forEach { entry ->
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = sdf.format(Date(entry.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MutedText,
                                    modifier = Modifier.width(60.dp)
                                )
                                Column {
                                    Text(
                                        text = "${entry.actor} • ${entry.action}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = BurgundyDeep
                                    )
                                    Text(
                                        text = entry.details,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CharcoalText
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Cancellation Button (if eligible)
        if (canCancel) {
            OutlinedButton(
                onClick = { showCancelDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("cancel_order_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRed)
            ) {
                Icon(Icons.Outlined.Cancel, contentDescription = null, tint = StatusRed)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Cancel Order (Eligible before Kitchen Prep)")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }

    // Cancel confirmation dialog
    if (showCancelDialog) {
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            title = { Text("Cancel Order?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to cancel order ${order.orderNumber}? A full refund will be processed to your card.") },
            confirmButton = {
                Button(
                    onClick = {
                        onCancelOrder(order.id, "Customer requested cancellation from app")
                        showCancelDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRed)
                ) {
                    Text("Yes, Cancel & Refund", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) {
                    Text("Keep Order")
                }
            }
        )
    }
}
