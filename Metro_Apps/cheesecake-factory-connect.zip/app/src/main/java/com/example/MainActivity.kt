package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.MenuItem
import com.example.ui.components.DishCustomizerDialog
import com.example.ui.components.TopNavBar
import com.example.ui.screens.customer.*
import com.example.ui.screens.staff.StaffConsoleScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppMode
import com.example.ui.viewmodel.CustomerScreen
import com.example.ui.viewmodel.RestaurantViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CheesecakeConnectApp()
            }
        }
    }
}

@Composable
fun CheesecakeConnectApp(
    viewModel: RestaurantViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val locations by viewModel.locations.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val menuItems by viewModel.menuItems.collectAsStateWithLifecycle()
    val reservations by viewModel.reservations.collectAsStateWithLifecycle()
    val waitlist by viewModel.waitlist.collectAsStateWithLifecycle()
    val tables by viewModel.tables.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()

    val currentLocation = locations.firstOrNull { it.id == uiState.selectedLocationId }
        ?: locations.first()

    val activeOrder = orders.firstOrNull { it.id == uiState.activeTrackingOrderId }

    var showLocationPicker by remember { mutableStateOf(false) }
    var itemToCustomize by remember { mutableStateOf<MenuItem?>(null) }

    // BackHandler: Handle popping back stack safely
    BackHandler(enabled = uiState.activeMode == AppMode.STAFF_CONSOLE || uiState.currentScreen != CustomerScreen.HOME) {
        if (uiState.activeMode == AppMode.STAFF_CONSOLE) {
            viewModel.setAppMode(AppMode.CUSTOMER)
        } else if (uiState.currentScreen == CustomerScreen.CHECKOUT) {
            viewModel.navigateTo(CustomerScreen.CART)
        } else {
            viewModel.navigateTo(CustomerScreen.HOME)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopNavBar(
                locationName = currentLocation.name,
                cartItemCount = uiState.cartItems.sumOf { it.quantity },
                currentMode = uiState.activeMode,
                bannerMessage = uiState.bannerMessage,
                onOpenLocationPicker = { showLocationPicker = true },
                onToggleStaffMode = {
                    if (uiState.activeMode == AppMode.CUSTOMER) {
                        viewModel.setAppMode(AppMode.STAFF_CONSOLE)
                    } else {
                        viewModel.setAppMode(AppMode.CUSTOMER)
                    }
                },
                onOpenCart = {
                    viewModel.setAppMode(AppMode.CUSTOMER)
                    viewModel.navigateTo(CustomerScreen.CART)
                },
                onDismissBanner = { viewModel.dismissBanner() }
            )
        },
        bottomBar = {
            if (uiState.activeMode == AppMode.CUSTOMER) {
                NavigationBar(
                    containerColor = WarmSurfaceElevated,
                    contentColor = BurgundyDeep,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    NavigationBarItem(
                        selected = uiState.currentScreen == CustomerScreen.HOME,
                        onClick = { viewModel.navigateTo(CustomerScreen.HOME) },
                        icon = {
                            Icon(
                                if (uiState.currentScreen == CustomerScreen.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        },
                        label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BurgundyDeep,
                            selectedTextColor = BurgundyDeep,
                            indicatorColor = GoldAccent.copy(alpha = 0.35f)
                        ),
                        modifier = Modifier.testTag("nav_item_home")
                    )

                    NavigationBarItem(
                        selected = uiState.currentScreen == CustomerScreen.CHECK_IN,
                        onClick = { viewModel.navigateTo(CustomerScreen.CHECK_IN) },
                        icon = {
                            Icon(
                                if (uiState.currentScreen == CustomerScreen.CHECK_IN) Icons.Filled.HowToReg else Icons.Outlined.HowToReg,
                                contentDescription = "Check-In"
                            )
                        },
                        label = { Text("Check-In", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BurgundyDeep,
                            selectedTextColor = BurgundyDeep,
                            indicatorColor = GoldAccent.copy(alpha = 0.35f)
                        ),
                        modifier = Modifier.testTag("nav_item_checkin")
                    )

                    NavigationBarItem(
                        selected = uiState.currentScreen == CustomerScreen.MENU,
                        onClick = { viewModel.navigateTo(CustomerScreen.MENU) },
                        icon = {
                            Icon(
                                if (uiState.currentScreen == CustomerScreen.MENU) Icons.Filled.RestaurantMenu else Icons.Outlined.RestaurantMenu,
                                contentDescription = "Menu"
                            )
                        },
                        label = { Text("Menu", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BurgundyDeep,
                            selectedTextColor = BurgundyDeep,
                            indicatorColor = GoldAccent.copy(alpha = 0.35f)
                        ),
                        modifier = Modifier.testTag("nav_item_menu")
                    )

                    NavigationBarItem(
                        selected = uiState.currentScreen == CustomerScreen.CART,
                        onClick = { viewModel.navigateTo(CustomerScreen.CART) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    val count = uiState.cartItems.sumOf { it.quantity }
                                    if (count > 0) {
                                        Badge(containerColor = GoldAccent, contentColor = EspressoDark) {
                                            Text(count.toString(), fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    if (uiState.currentScreen == CustomerScreen.CART) Icons.Filled.ShoppingCart else Icons.Outlined.ShoppingCart,
                                    contentDescription = "Cart"
                                )
                            }
                        },
                        label = { Text("Cart", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BurgundyDeep,
                            selectedTextColor = BurgundyDeep,
                            indicatorColor = GoldAccent.copy(alpha = 0.35f)
                        ),
                        modifier = Modifier.testTag("nav_item_cart")
                    )

                    NavigationBarItem(
                        selected = uiState.currentScreen == CustomerScreen.ORDER_TRACKING || uiState.currentScreen == CustomerScreen.ORDER_HISTORY,
                        onClick = {
                            if (activeOrder != null) {
                                viewModel.navigateTo(CustomerScreen.ORDER_TRACKING)
                            } else {
                                viewModel.navigateTo(CustomerScreen.ORDER_HISTORY)
                            }
                        },
                        icon = {
                            Icon(
                                if (uiState.currentScreen == CustomerScreen.ORDER_TRACKING || uiState.currentScreen == CustomerScreen.ORDER_HISTORY) Icons.Filled.ReceiptLong else Icons.Outlined.ReceiptLong,
                                contentDescription = "Orders"
                            )
                        },
                        label = { Text("Orders", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BurgundyDeep,
                            selectedTextColor = BurgundyDeep,
                            indicatorColor = GoldAccent.copy(alpha = 0.35f)
                        ),
                        modifier = Modifier.testTag("nav_item_orders")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = uiState.activeMode, label = "mode_switch") { mode ->
                when (mode) {
                    AppMode.STAFF_CONSOLE -> {
                        StaffConsoleScreen(
                            currentLocation = currentLocation,
                            activeTab = uiState.activeStaffTab,
                            reservations = reservations,
                            waitlist = waitlist,
                            tables = tables,
                            orders = orders,
                            menuItems = menuItems,
                            onSelectTab = { viewModel.setStaffTab(it) },
                            onSeatReservation = { resId, tbl -> viewModel.staffSeatReservation(resId, tbl) },
                            onMarkNoShow = { viewModel.staffMarkNoShow(it) },
                            onNotifyWaitlist = { entryId, tbl -> viewModel.staffNotifyWaitlist(entryId, tbl) },
                            onSeatWaitlist = { entryId, tbl -> viewModel.staffSeatWaitlist(entryId, tbl) },
                            onAcceptOrder = { viewModel.staffAcceptOrder(it) },
                            onStartPreparingOrder = { viewModel.staffStartPreparing(it) },
                            onMarkOrderReady = { viewModel.staffMarkOrderReady(it) },
                            onFulfillOrder = { viewModel.staffMarkOrderFulfilled(it) },
                            onRefundOrder = { id, reason -> viewModel.staffRefundOrder(id, reason) },
                            onToggleItemStock = { viewModel.staffToggleItemStock(it) },
                            onReturnToCustomerMode = { viewModel.setAppMode(AppMode.CUSTOMER) }
                        )
                    }

                    AppMode.CUSTOMER -> {
                        Crossfade(targetState = uiState.currentScreen, label = "screen_switch") { screen ->
                            when (screen) {
                                CustomerScreen.HOME -> {
                                    HomeScreen(
                                        currentLocation = currentLocation,
                                        categories = categories,
                                        featuredItems = menuItems,
                                        activeReservation = uiState.activeCustomerReservation,
                                        activeWaitlist = uiState.activeCustomerWaitlist,
                                        activeOrder = activeOrder,
                                        onNavigate = { viewModel.navigateTo(it) },
                                        onSelectCategory = { viewModel.selectCategory(it) },
                                        onCustomizeItem = { itemToCustomize = it },
                                        onOpenLocationPicker = { showLocationPicker = true }
                                    )
                                }

                                CustomerScreen.CHECK_IN -> {
                                    CheckInScreen(
                                        currentLocation = currentLocation,
                                        activeReservation = uiState.activeCustomerReservation,
                                        activeWaitlist = uiState.activeCustomerWaitlist,
                                        errorMessage = uiState.errorMessage,
                                        onLookupReservation = { viewModel.lookupReservation(it) },
                                        onCheckInReservation = { viewModel.checkInReservation(it) },
                                        onJoinWaitlist = { name, phone, partySize, notes ->
                                            viewModel.joinWaitlist(name, phone, partySize, notes)
                                        },
                                        onConfirmWaitlistArrival = { viewModel.confirmWaitlistArrival(it) },
                                        onCancelWaitlist = { viewModel.cancelWaitlist(it) },
                                        onDismissError = { viewModel.clearError() }
                                    )
                                }

                                CustomerScreen.MENU -> {
                                    MenuScreen(
                                        categories = categories,
                                        items = menuItems,
                                        selectedCategoryId = uiState.selectedCategoryId,
                                        searchQuery = uiState.searchQuery,
                                        selectedDietaryFilter = uiState.selectedDietaryFilter,
                                        onSelectCategory = { viewModel.selectCategory(it) },
                                        onSearchChange = { viewModel.setSearchQuery(it) },
                                        onSelectDietaryFilter = { viewModel.selectDietaryFilter(it) },
                                        onCustomizeItem = { itemToCustomize = it }
                                    )
                                }

                                CustomerScreen.CART -> {
                                    CartScreen(
                                        cartItems = uiState.cartItems,
                                        diningMode = uiState.diningMode,
                                        tableNumber = uiState.tableNumber,
                                        tipPercentage = uiState.tipPercentage,
                                        promoCode = uiState.promoCode,
                                        activeQuote = uiState.activeQuote,
                                        isQuoteLoading = uiState.isQuoteLoading,
                                        errorMessage = uiState.errorMessage,
                                        onUpdateQuantity = { id, delta -> viewModel.updateCartQuantity(id, delta) },
                                        onRemoveItem = { viewModel.removeFromCart(it) },
                                        onSetDiningMode = { mode, tbl -> viewModel.setDiningMode(mode, tbl) },
                                        onSetTipPercentage = { viewModel.setTipPercentage(it) },
                                        onApplyPromoCode = { viewModel.applyPromoCode(it) },
                                        onProceedToCheckout = { viewModel.navigateTo(CustomerScreen.CHECKOUT) },
                                        onContinueShopping = { viewModel.navigateTo(CustomerScreen.MENU) }
                                    )
                                }

                                CustomerScreen.CHECKOUT -> {
                                    CheckoutScreen(
                                        quote = uiState.activeQuote,
                                        customerName = uiState.customerName,
                                        customerPhone = uiState.customerPhone,
                                        isProcessing = false,
                                        onAuthorizeAndPay = { cardMask ->
                                            viewModel.submitOrderAndPay(cardMask)
                                        },
                                        onBackToCart = { viewModel.navigateTo(CustomerScreen.CART) }
                                    )
                                }

                                CustomerScreen.ORDER_TRACKING -> {
                                    OrderTrackingScreen(
                                        order = activeOrder,
                                        onCancelOrder = { id, reason -> viewModel.cancelActiveOrder(id, reason) },
                                        onBackToHome = { viewModel.navigateTo(CustomerScreen.HOME) }
                                    )
                                }

                                CustomerScreen.ORDER_HISTORY -> {
                                    OrderHistoryScreen(
                                        orders = orders,
                                        customerName = uiState.customerName,
                                        customerPhone = uiState.customerPhone,
                                        customerEmail = uiState.customerEmail,
                                        onTrackOrder = { orderId ->
                                            viewModel.uiState.let {
                                                // select order to track
                                                viewModel.navigateTo(CustomerScreen.ORDER_TRACKING)
                                            }
                                        },
                                        onReorder = { ord ->
                                            ord.items.forEach { cartItem ->
                                                viewModel.addToCart(
                                                    cartItem.menuItem,
                                                    cartItem.quantity,
                                                    cartItem.selectedModifiers,
                                                    cartItem.specialInstructions
                                                )
                                            }
                                            viewModel.navigateTo(CustomerScreen.CART)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Location Picker
    if (showLocationPicker) {
        LocationPickerSheet(
            locations = locations,
            selectedLocationId = uiState.selectedLocationId,
            onSelectLocation = { viewModel.selectLocation(it) },
            onDismiss = { showLocationPicker = false }
        )
    }

    // Dish Customizer Dialog
    if (itemToCustomize != null) {
        DishCustomizerDialog(
            item = itemToCustomize!!,
            onDismiss = { itemToCustomize = null },
            onAddToCart = { item, quantity, modifiers, notes ->
                viewModel.addToCart(item, quantity, modifiers, notes)
            }
        )
    }
}
