package com.example.ui.screens.staff

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.ArrivalStatusBadge
import com.example.ui.components.OrderStatusBadge
import com.example.ui.components.WaitlistStatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.StaffTab
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun StaffConsoleScreen(
    currentLocation: RestaurantLocation,
    activeTab: StaffTab,
    reservations: List<Reservation>,
    waitlist: List<WaitlistEntry>,
    tables: List<RestaurantTable>,
    orders: List<RestaurantOrder>,
    menuItems: List<MenuItem>,
    onSelectTab: (StaffTab) -> Unit,
    onSeatReservation: (reservationId: String, tableNumber: Int) -> Unit,
    onMarkNoShow: (reservationId: String) -> Unit,
    onNotifyWaitlist: (entryId: String, tableNumber: Int?) -> Unit,
    onSeatWaitlist: (entryId: String, tableNumber: Int) -> Unit,
    onAcceptOrder: (orderId: String) -> Unit,
    onStartPreparingOrder: (orderId: String) -> Unit,
    onMarkOrderReady: (orderId: String) -> Unit,
    onFulfillOrder: (orderId: String) -> Unit,
    onRefundOrder: (orderId: String, reason: String) -> Unit,
    onToggleItemStock: (itemId: String) -> Unit,
    onReturnToCustomerMode: () -> Unit
) {
    var selectedOrderFilter by remember { mutableStateOf<OrderStatus?>(null) }
    var seatingDialogTarget by remember { mutableStateOf<Pair<String, Boolean>?>(null) } // (id, isReservation)
    var selectedTableNum by remember { mutableIntStateOf(1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StaffDarkBackground)
    ) {
        // Staff Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(StaffDarkSurface)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(StatusGreen)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "RESTAURANT OPS CONSOLE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = GoldAccent,
                        letterSpacing = 1.sp
                    )
                }
                Text(
                    text = currentLocation.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            OutlinedButton(
                onClick = onReturnToCustomerMode,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(36.dp)
                    .testTag("staff_exit_button")
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Exit to Guest App", color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Staff Tabs (Arrivals, KDS Kitchen, Tables, Menu 86)
        ScrollableTabRow(
            selectedTabIndex = activeTab.ordinal,
            containerColor = StaffDarkSurface,
            contentColor = GoldAccent,
            edgePadding = 16.dp,
            divider = {}
        ) {
            StaffTab.values().forEach { tab ->
                val isSelected = activeTab == tab
                val title = when (tab) {
                    StaffTab.ARRIVALS -> "Host Arrivals (${reservations.count { it.arrivalStatus == ArrivalStatus.AWAITING_SEATING }} arrived)"
                    StaffTab.KITCHEN_KDS -> "Kitchen KDS (${orders.count { it.orderStatus == OrderStatus.CONFIRMED || it.orderStatus == OrderStatus.PREPARING }})"
                    StaffTab.TABLES -> "Floor Map (${tables.count { it.status == TableStatus.AVAILABLE }} free)"
                    StaffTab.MENU_86 -> "Menu & 86'd (${menuItems.count { !it.isAvailable }} out)"
                }
                Tab(
                    selected = isSelected,
                    onClick = { onSelectTab(tab) },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) GoldAccent else Color.White.copy(alpha = 0.7f),
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        // TAB 1: ARRIVALS & WAITLIST
        if (activeTab == StaffTab.ARRIVALS) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Section 1: Checked-In & Reserved Parties
                item {
                    Text(
                        text = "Today's Reservations (${reservations.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                }

                items(reservations, key = { it.id }) { res ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .border(
                                width = 1.dp,
                                color = if (res.arrivalStatus == ArrivalStatus.AWAITING_SEATING) StatusAmber else StaffDarkBorder,
                                shape = RoundedCornerShape(14.dp)
                            ),
                        colors = CardDefaults.cardColors(containerColor = StaffDarkCard)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${res.customerName} (Party of ${res.partySize})",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "${res.confirmationCode} • ${res.phone} • ${res.reservationDateTime}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.7f)
                                    )
                                }
                                ArrivalStatusBadge(status = res.arrivalStatus)
                            }

                            if (res.seatingPreference.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Pref: ${res.seatingPreference}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldLight
                                )
                            }

                            if (res.tableNumber != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Assigned Table #${res.tableNumber}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = StatusGreen
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Staff Seating Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (res.arrivalStatus != ArrivalStatus.SEATED && res.arrivalStatus != ArrivalStatus.NO_SHOW) {
                                    Button(
                                        onClick = {
                                            seatingDialogTarget = Pair(res.id, true)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Text("Assign & Seat Table", color = EspressoDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }

                                    OutlinedButton(
                                        onClick = { onMarkNoShow(res.id) },
                                        shape = RoundedCornerShape(8.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444)),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Text("No-Show", color = Color(0xFFEF4444), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 2: Active Waitlist Queue
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Active Waitlist Queue (${waitlist.count { it.status == WaitlistStatus.WAITING || it.status == WaitlistStatus.READY_TO_SEAT }})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                }

                items(waitlist.filter { it.status != WaitlistStatus.CANCELLED }, key = { it.id }) { waitItem ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, StaffDarkBorder, RoundedCornerShape(14.dp)),
                        colors = CardDefaults.cardColors(containerColor = StaffDarkCard)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = waitItem.queueCode,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = GoldLight
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "${waitItem.customerName} (${waitItem.partySize}p)",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                    Text(
                                        text = "${waitItem.phone} • Position #${waitItem.queuePosition} • Est ~${waitItem.estimatedWaitMinutes}m",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.7f)
                                    )
                                }
                                WaitlistStatusBadge(status = waitItem.status)
                            }

                            if (waitItem.seatingNotes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Notes: ${waitItem.seatingNotes}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.6f)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (waitItem.status == WaitlistStatus.WAITING) {
                                    Button(
                                        onClick = { onNotifyWaitlist(waitItem.id, null) },
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusAmber),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                    ) {
                                        Text("Page: Table Ready", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }

                                if (waitItem.status != WaitlistStatus.SEATED) {
                                    Button(
                                        onClick = {
                                            seatingDialogTarget = Pair(waitItem.id, false)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusGreen),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                    ) {
                                        Text("Seat at Table...", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 2: KITCHEN DISPLAY SYSTEM (KDS)
        if (activeTab == StaffTab.KITCHEN_KDS) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                // Filter chips
                val filterOptions = listOf(
                    null to "All Orders",
                    OrderStatus.CONFIRMED to "New Tickets",
                    OrderStatus.PREPARING to "On Grill / Prep",
                    OrderStatus.READY to "Ready for Pickup",
                    OrderStatus.FULFILLED to "Completed"
                )

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filterOptions) { (st, label) ->
                        val isSelected = selectedOrderFilter == st
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedOrderFilter = st },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GoldAccent,
                                selectedLabelColor = EspressoDark,
                                containerColor = StaffDarkCard,
                                labelColor = Color.White.copy(alpha = 0.8f)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                val filteredOrders = orders.filter { ord ->
                    selectedOrderFilter == null || ord.orderStatus == selectedOrderFilter
                }

                if (filteredOrders.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No orders matching this station filter", color = Color.White.copy(alpha = 0.5f))
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(filteredOrders, key = { it.id }) { ord ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(
                                        width = 1.dp,
                                        color = when (ord.orderStatus) {
                                            OrderStatus.CONFIRMED -> Color(0xFF3B82F6)
                                            OrderStatus.PREPARING -> StatusAmber
                                            OrderStatus.READY -> StatusGreen
                                            else -> StaffDarkBorder
                                        },
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                colors = CardDefaults.cardColors(containerColor = StaffDarkCard)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = ord.orderNumber,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = GoldLight
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = if (ord.diningMode == DiningMode.DINE_IN) "DINE-IN T#${ord.tableNumber ?: '—'}" else "CURBSIDE PICKUP",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White
                                                )
                                            }
                                            Text(
                                                text = "${ord.customerName} • ${ord.customerPhone}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color.White.copy(alpha = 0.7f)
                                            )
                                        }
                                        OrderStatusBadge(status = ord.orderStatus)
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    HorizontalDivider(color = StaffDarkBorder)
                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Items & modifiers
                                    ord.items.forEach { item ->
                                        Column(modifier = Modifier.padding(vertical = 2.dp)) {
                                            Text(
                                                text = "${item.quantity}x ${item.menuItem.name}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            item.selectedModifiers.values.flatten().forEach { mod ->
                                                Text(
                                                    text = "   ▸ MOD: ${mod.name}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = GoldAccent
                                                )
                                            }
                                            if (item.specialInstructions.isNotBlank()) {
                                                Text(
                                                    text = "   ★ CHEF NOTE: ${item.specialInstructions}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFFDE68A)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Action buttons
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        when (ord.orderStatus) {
                                            OrderStatus.CONFIRMED -> {
                                                Button(
                                                    onClick = { onAcceptOrder(ord.id) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier.height(36.dp)
                                                ) {
                                                    Text("Accept Ticket", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                }
                                            }
                                            OrderStatus.ACCEPTED -> {
                                                Button(
                                                    onClick = { onStartPreparingOrder(ord.id) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = StatusAmber),
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier.height(36.dp)
                                                ) {
                                                    Text("Start Cooking (Grill/Line)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                }
                                            }
                                            OrderStatus.PREPARING -> {
                                                Button(
                                                    onClick = { onMarkOrderReady(ord.id) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = StatusGreen),
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier.height(36.dp)
                                                ) {
                                                    Text("Mark Order Ready", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                }
                                            }
                                            OrderStatus.READY -> {
                                                Button(
                                                    onClick = { onFulfillOrder(ord.id) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier.height(36.dp)
                                                ) {
                                                    Text("Hand Off / Fulfilled", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                }
                                            }
                                            else -> {}
                                        }

                                        if (ord.orderStatus != OrderStatus.FULFILLED && ord.orderStatus != OrderStatus.REFUNDED) {
                                            OutlinedButton(
                                                onClick = { onRefundOrder(ord.id, "Manager authorized refund") },
                                                shape = RoundedCornerShape(8.dp),
                                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444)),
                                                modifier = Modifier.height(36.dp)
                                            ) {
                                                Text("Refund", color = Color(0xFFEF4444), fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 3: TABLE FLOOR MAP
        if (activeTab == StaffTab.TABLES) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Text(
                    text = "Restaurant Dining Floor Map (${tables.size} tables)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = GoldLight
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Tap any table to assign or clear seating status.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.height(14.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(tables) { tbl ->
                        val (bgColor, borderCol) = when (tbl.status) {
                            TableStatus.AVAILABLE -> Pair(Color(0xFF064E3B), Color(0xFF10B981))
                            TableStatus.OCCUPIED -> Pair(Color(0xFF7F1D1D), Color(0xFFEF4444))
                            TableStatus.RESERVED -> Pair(Color(0xFF78350F), Color(0xFFF59E0B))
                            TableStatus.CLEANING -> Pair(Color(0xFF1E293B), Color(0xFF64748B))
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.5.dp, borderCol, RoundedCornerShape(12.dp)),
                            colors = CardDefaults.cardColors(containerColor = bgColor)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Table ${tbl.tableNumber}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "${tbl.capacity} Tops",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.8f)
                                    )
                                }

                                Text(
                                    text = tbl.assignedParty ?: tbl.section,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White.copy(alpha = 0.9f),
                                    maxLines = 1
                                )

                                Text(
                                    text = tbl.status.displayName.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = borderCol
                                )
                            }
                        }
                    }
                }
            }
        }

        // TAB 4: MENU 86 AVAILABILITY MANAGEMENT
        if (activeTab == StaffTab.MENU_86) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Text(
                    text = "Kitchen 86 Management (Dish Stock Toggle)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = GoldLight
                )
                Text(
                    text = "Toggling an item 86'd immediately marks it Sold Out on the Customer app and rejects new cart quotes.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.7f)
                )

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(menuItems, key = { it.id }) { item ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    width = 1.dp,
                                    color = if (item.isAvailable) StaffDarkBorder else Color(0xFFEF4444),
                                    shape = RoundedCornerShape(12.dp)
                                ),
                            colors = CardDefaults.cardColors(containerColor = StaffDarkCard)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "$${"%.2f".format(item.priceCents / 100.0)} • ${if (item.isAvailable) "IN STOCK" else "86'D (SOLD OUT)"}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (item.isAvailable) StatusGreen else Color(0xFFEF4444)
                                    )
                                }

                                Switch(
                                    checked = item.isAvailable,
                                    onCheckedChange = { onToggleItemStock(item.id) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = StatusGreen,
                                        checkedTrackColor = Color(0xFF064E3B),
                                        uncheckedThumbColor = Color(0xFFEF4444),
                                        uncheckedTrackColor = Color(0xFF450A0A)
                                    ),
                                    modifier = Modifier.testTag("toggle_86_${item.id}")
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Seating Table Assignment Dialog
    if (seatingDialogTarget != null) {
        val (targetId, isRes) = seatingDialogTarget!!
        AlertDialog(
            onDismissRequest = { seatingDialogTarget = null },
            title = { Text("Assign Table & Seat Party", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Select dining table number for this party:")
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        (1..8).forEach { num ->
                            FilterChip(
                                selected = selectedTableNum == num,
                                onClick = { selectedTableNum = num },
                                label = { Text("T#$num") }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isRes) {
                            onSeatReservation(targetId, selectedTableNum)
                        } else {
                            onSeatWaitlist(targetId, selectedTableNum)
                        }
                        seatingDialogTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep)
                ) {
                    Text("Seat Party", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { seatingDialogTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
