package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = GoldAccent,
    onPrimary = EspressoDark,
    primaryContainer = BurgundyDeep,
    onPrimaryContainer = GoldLight,
    secondary = GoldLight,
    onSecondary = EspressoDark,
    background = StaffDarkBackground,
    onBackground = WarmCreamBackground,
    surface = StaffDarkSurface,
    onSurface = WarmCreamBackground,
    surfaceVariant = StaffDarkCard,
    onSurfaceVariant = WarmCreamBackground,
    outline = StaffDarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = BurgundyDeep,
    onPrimary = WarmSurface,
    primaryContainer = WarmSurfaceElevated,
    onPrimaryContainer = BurgundyDeep,
    secondary = GoldAccent,
    onSecondary = EspressoDark,
    secondaryContainer = WarmSurfaceElevated,
    onSecondaryContainer = BurgundyDeep,
    background = WarmCreamBackground,
    onBackground = CharcoalText,
    surface = WarmSurface,
    onSurface = CharcoalText,
    surfaceVariant = WarmSurfaceElevated,
    onSurfaceVariant = MutedText,
    outline = WarmBorder,
    error = StatusRed,
    onError = WarmSurface,
    errorContainer = StatusRedContainer,
    onErrorContainer = StatusRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
