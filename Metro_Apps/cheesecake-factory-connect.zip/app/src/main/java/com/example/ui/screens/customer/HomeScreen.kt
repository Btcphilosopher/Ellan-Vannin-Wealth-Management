package com.example.ui.screens.customer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.components.ArrivalStatusBadge
import com.example.ui.components.OrderStatusBadge
import com.example.ui.components.WaitlistStatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.CustomerScreen

@Composable
fun HomeScreen(
    currentLocation: RestaurantLocation,
    categories: List<MenuCategory>,
    featuredItems: List<MenuItem>,
    activeReservation: Reservation?,
    activeWaitlist: WaitlistEntry?,
    activeOrder: RestaurantOrder?,
    onNavigate: (CustomerScreen) -> Unit,
    onSelectCategory: (String) -> Unit,
    onCustomizeItem: (MenuItem) -> Unit,
    onOpenLocationPicker: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Hero Banner with Ambient Lighting & Overlay
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_banner),
                contentDescription = "Dining Room & Gourmet Cheesecake",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Gradient scrim
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.5f),
                                BurgundyDeep.copy(alpha = 0.95f)
                            )
                        )
                    )
            )

            // Hero Text & Badges
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(GoldAccent.copy(alpha = 0.9f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = null,
                        tint = EspressoDark,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "THE ART OF CHEESECAKE & FINE CASUAL DINING",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = EspressoDark,
                        letterSpacing = 0.5.sp
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = currentLocation.name,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Current Host Stand Wait: ~${currentLocation.waitEstimateMinutes} min • Table Check-In Open",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.9f)
                )
            }
        }

        // Active State Cards (Reservation / Waitlist / Order)
        if (activeReservation != null || activeWaitlist != null || (activeOrder != null && activeOrder.orderStatus != OrderStatus.FULFILLED)) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Active Reservation Card
                if (activeReservation != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, GoldAccent, RoundedCornerShape(16.dp))
                            .clickable { onNavigate(CustomerScreen.CHECK_IN) }
                            .testTag("active_reservation_banner"),
                        colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Reservation ${activeReservation.confirmationCode}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = BurgundyDeep
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    ArrivalStatusBadge(status = activeReservation.arrivalStatus)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${activeReservation.customerName} • Party of ${activeReservation.partySize} • ${activeReservation.reservationDateTime}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MutedText
                                )
                                if (activeReservation.tableNumber != null) {
                                    Text(
                                        text = "Assigned Table #${activeReservation.tableNumber}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusGreen
                                    )
                                }
                            }
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "View Details",
                                tint = BurgundyDeep
                            )
                        }
                    }
                }

                // Active Waitlist Card
                if (activeWaitlist != null && activeWaitlist.status != WaitlistStatus.CANCELLED) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, GoldAccent, RoundedCornerShape(16.dp))
                            .clickable { onNavigate(CustomerScreen.CHECK_IN) }
                            .testTag("active_waitlist_banner"),
                        colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Queue Ticket ${activeWaitlist.queueCode}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = BurgundyDeep
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    WaitlistStatusBadge(status = activeWaitlist.status)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Position #${activeWaitlist.queuePosition} • Est. wait ~${activeWaitlist.estimatedWaitMinutes} min",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MutedText
                                )
                            }
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "View Waitlist",
                                tint = BurgundyDeep
                            )
                        }
                    }
                }

                // Active Order Tracker Card
                if (activeOrder != null && activeOrder.orderStatus != OrderStatus.FULFILLED && activeOrder.orderStatus != OrderStatus.CANCELLED) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, StatusGreen, RoundedCornerShape(16.dp))
                            .clickable { onNavigate(CustomerScreen.ORDER_TRACKING) }
                            .testTag("active_order_banner"),
                        colors = CardDefaults.cardColors(containerColor = StatusGreenContainer.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Live Order ${activeOrder.orderNumber}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusGreen
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    OrderStatusBadge(status = activeOrder.orderStatus)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${activeOrder.diningMode.displayName} • ${activeOrder.items.size} item(s) • $${"%.2f".format(activeOrder.totalCents / 100.0)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CharcoalText
                                )
                            }
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Track Order",
                                tint = StatusGreen
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Two Primary Action Cards (Check-In & Order)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Check-In & Waitlist Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(120.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onNavigate(CustomerScreen.CHECK_IN) }
                    .testTag("home_checkin_card"),
                colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BurgundyDeep),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Outlined.HowToReg,
                            contentDescription = "Check-In",
                            tint = GoldAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Check In & Waitlist",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalText
                        )
                        Text(
                            text = "Arrivals & queue tracker",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedText
                        )
                    }
                }
            }

            // Order Food Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(120.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onNavigate(CustomerScreen.MENU) }
                    .testTag("home_order_food_card"),
                colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BurgundyDeep),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Outlined.RestaurantMenu,
                            contentDescription = "Menu",
                            tint = GoldAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Order Food",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalText
                        )
                        Text(
                            text = "Dine-in or curbside pickup",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedText
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Category Highlights
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Explore Our Legendary Menu",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BurgundyDeep
                )
                TextButton(
                    onClick = { onNavigate(CustomerScreen.MENU) },
                    modifier = Modifier.testTag("view_all_menu_button")
                ) {
                    Text("View All", color = GoldDark, fontWeight = FontWeight.Bold)
                }
            }

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(categories) { cat ->
                    Card(
                        modifier = Modifier
                            .width(140.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                onSelectCategory(cat.id)
                                onNavigate(CustomerScreen.MENU)
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, WarmBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(WarmSurfaceElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    when (cat.id) {
                                        "cat_cheesecake" -> Icons.Outlined.Cake
                                        "cat_pastas" -> Icons.Outlined.DinnerDining
                                        "cat_glamburgers" -> Icons.Outlined.Fastfood
                                        "cat_salads" -> Icons.Outlined.Grass
                                        "cat_small_plates" -> Icons.Outlined.Tapas
                                        else -> Icons.Outlined.LocalBar
                                    },
                                    contentDescription = cat.name,
                                    tint = BurgundyDeep,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = cat.name,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = CharcoalText,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Signature Dishes Carousel
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Cheesecake Factory Classics",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BurgundyDeep,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(featuredItems.take(5)) { item ->
                    Card(
                        modifier = Modifier
                            .width(220.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, WarmBorder, RoundedCornerShape(16.dp)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (item.isSignature) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(BurgundyDeep)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "SIGNATURE",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = GoldLight
                                        )
                                    }
                                }
                                Text(
                                    text = "$${"%.2f".format(item.priceCents / 100.0)}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = BurgundyDeep
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = CharcoalText,
                                maxLines = 2
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MutedText,
                                maxLines = 3,
                                lineHeight = 16.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = { onCustomizeItem(item) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(36.dp)
                                    .testTag("customize_item_${item.id}"),
                                colors = ButtonDefaults.buttonColors(containerColor = WarmSurfaceElevated),
                                border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(
                                    text = "Customize & Order",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = BurgundyDeep,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
    }
}
