package com.example.ui.screens.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CartItem
import com.example.data.model.CartQuote
import com.example.data.model.DiningMode
import com.example.ui.theme.*

@Composable
fun CartScreen(
    cartItems: List<CartItem>,
    diningMode: DiningMode,
    tableNumber: Int?,
    tipPercentage: Int,
    promoCode: String,
    activeQuote: CartQuote?,
    isQuoteLoading: Boolean,
    errorMessage: String?,
    onUpdateQuantity: (cartItemId: String, delta: Int) -> Unit,
    onRemoveItem: (cartItemId: String) -> Unit,
    onSetDiningMode: (DiningMode, Int?) -> Unit,
    onSetTipPercentage: (Int) -> Unit,
    onApplyPromoCode: (String) -> Unit,
    onProceedToCheckout: () -> Unit,
    onContinueShopping: () -> Unit
) {
    var promoInput by remember { mutableStateOf(promoCode) }
    var tableNumInput by remember { mutableStateOf(tableNumber?.toString() ?: "3") }

    if (cartItems.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(40.dp))
                        .background(WarmSurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Outlined.ShoppingBag,
                        contentDescription = "Empty Cart",
                        tint = GoldDark,
                        modifier = Modifier.size(40.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Your Cart is Empty",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = BurgundyDeep
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Explore our legendary cheesecakes, pastas, and specialty entrees.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onContinueShopping,
                    colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("empty_cart_browse_button")
                ) {
                    Text("Explore Menu", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Dining Mode Selector
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, WarmBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Dining Service Mode",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = BurgundyDeep
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = diningMode == DiningMode.DINE_IN,
                                onClick = { onSetDiningMode(DiningMode.DINE_IN, tableNumInput.toIntOrNull() ?: 3) },
                                label = { Text("Dine-In Table") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BurgundyDeep,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("dine_in_mode_chip")
                            )
                            FilterChip(
                                selected = diningMode == DiningMode.PICKUP,
                                onClick = { onSetDiningMode(DiningMode.PICKUP, null) },
                                label = { Text("Curbside & Takeaway") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BurgundyDeep,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("pickup_mode_chip")
                            )
                        }

                        if (diningMode == DiningMode.DINE_IN) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Table #",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                OutlinedTextField(
                                    value = tableNumInput,
                                    onValueChange = {
                                        tableNumInput = it
                                        onSetDiningMode(DiningMode.DINE_IN, it.toIntOrNull())
                                    },
                                    modifier = Modifier
                                        .width(90.dp)
                                        .height(50.dp)
                                        .testTag("table_number_input"),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "(Listed on your table stand)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MutedText
                                )
                            }
                        }
                    }
                }
            }

            // Cart Items
            items(cartItems, key = { it.id }) { cartItem ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, WarmBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = cartItem.menuItem.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = CharcoalText
                                )
                                Text(
                                    text = "$${"%.2f".format(cartItem.unitPriceCents / 100.0)} each",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MutedText
                                )

                                // Selected Modifiers
                                cartItem.selectedModifiers.values.flatten().forEach { mod ->
                                    Text(
                                        text = "• ${mod.name}" + if (mod.priceDeltaCents > 0) " (+$${"%.2f".format(mod.priceDeltaCents / 100.0)})" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = BurgundyDeep
                                    )
                                }

                                if (cartItem.specialInstructions.isNotBlank()) {
                                    Text(
                                        text = "Note: \"${cartItem.specialInstructions}\"",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MutedTextLight,
                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                    )
                                }
                            }

                            Text(
                                text = "$${"%.2f".format(cartItem.itemTotalCents / 100.0)}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = BurgundyDeep
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = WarmBorder)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { onRemoveItem(cartItem.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.DeleteOutline,
                                    contentDescription = "Remove item",
                                    tint = StatusRed
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(WarmSurfaceElevated)
                                    .border(1.dp, WarmBorder, RoundedCornerShape(10.dp))
                            ) {
                                IconButton(
                                    onClick = { onUpdateQuantity(cartItem.id, -1) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = BurgundyDeep)
                                }
                                Text(
                                    text = cartItem.quantity.toString(),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp)
                                )
                                IconButton(
                                    onClick = { onUpdateQuantity(cartItem.id, 1) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Increase", tint = BurgundyDeep)
                                }
                            }
                        }
                    }
                }
            }

            // Promo Code & Tip
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, WarmBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Promotions & Gratuity",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalText
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Promo code row
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = promoInput,
                                onValueChange = { promoInput = it },
                                placeholder = { Text("Code: SWEET10 or WELCOME") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("promo_code_input"),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldAccent,
                                    unfocusedBorderColor = WarmBorder
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onApplyPromoCode(promoInput) },
                                colors = ButtonDefaults.buttonColors(containerColor = WarmSurfaceElevated),
                                border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .height(56.dp)
                                    .testTag("apply_promo_button")
                            ) {
                                Text("Apply", color = BurgundyDeep, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Tip selector
                        Text("Add Server Tip", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(15, 18, 20, 0).forEach { pct ->
                                val isSelected = tipPercentage == pct
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { onSetTipPercentage(pct) },
                                    label = { Text(if (pct == 0) "Custom/0%" else "$pct%") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = BurgundyDeep,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Authoritative Server Quote Breakdown
            item {
                if (activeQuote != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Authoritative Server Quote",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = BurgundyDeep
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Outlined.Timer,
                                        contentDescription = null,
                                        tint = StatusAmber,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Expires in 15m",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StatusAmber
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Subtotal", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                                Text("$${"%.2f".format(activeQuote.subtotalCents / 100.0)}", style = MaterialTheme.typography.bodyMedium)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Sales Tax (8.75%)", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                                Text("$${"%.2f".format(activeQuote.taxCents / 100.0)}", style = MaterialTheme.typography.bodyMedium)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Service & Dining Fee", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                                Text("$${"%.2f".format(activeQuote.serviceFeeCents / 100.0)}", style = MaterialTheme.typography.bodyMedium)
                            }

                            if (activeQuote.tipCents > 0) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Gratuity (${tipPercentage}%)", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                                    Text("$${"%.2f".format(activeQuote.tipCents / 100.0)}", style = MaterialTheme.typography.bodyMedium)
                                }
                            }

                            if (activeQuote.discountCents > 0) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Promo (${activeQuote.promoCodeApplied})", style = MaterialTheme.typography.bodyMedium, color = StatusGreen)
                                    Text("-$${"%.2f".format(activeQuote.discountCents / 100.0)}", style = MaterialTheme.typography.bodyMedium, color = StatusGreen, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = WarmBorder)
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = CharcoalText)
                                Text("$${"%.2f".format(activeQuote.totalCents / 100.0)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = BurgundyDeep)
                            }
                        }
                    }
                }
            }
        }

        // Bottom Checkout Bar
        Surface(
            tonalElevation = 8.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                if (errorMessage != null) {
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusRed,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                Button(
                    onClick = onProceedToCheckout,
                    enabled = activeQuote != null && !isQuoteLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("proceed_to_checkout_button")
                ) {
                    if (isQuoteLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    } else {
                        Text(
                            text = if (activeQuote != null) "Proceed to Payment • $${"%.2f".format(activeQuote.totalCents / 100.0)}" else "Calculating Quote...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
