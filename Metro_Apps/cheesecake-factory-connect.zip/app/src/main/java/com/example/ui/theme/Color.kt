package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm, opulent Casual Dining palette (Cheesecake Factory Grandeur)
val BurgundyDeep = Color(0xFF4A121A)
val BurgundyLight = Color(0xFF6B1D27)
val GoldAccent = Color(0xFFC89228)
val GoldLight = Color(0xFFE5B556)
val GoldDark = Color(0xFFA67417)

val EspressoDark = Color(0xFF1F1514)
val CharcoalText = Color(0xFF231A18)
val MutedText = Color(0xFF6E5F5A)
val MutedTextLight = Color(0xFF9E8F8A)

val WarmCreamBackground = Color(0xFFFBF8F4)
val WarmSurface = Color(0xFFFFFFFF)
val WarmSurfaceElevated = Color(0xFFFAF4EB)
val WarmBorder = Color(0xFFE6DDD0)
val WarmDivider = Color(0xFFEFE8DD)

// Semantic colors
val StatusGreen = Color(0xFF2E7D32)
val StatusGreenContainer = Color(0xFFE8F5E9)
val StatusAmber = Color(0xFFD97706)
val StatusAmberContainer = Color(0xFFFEF3C7)
val StatusRed = Color(0xFFC62828)
val StatusRedContainer = Color(0xFFFFEBEE)
val StatusBlue = Color(0xFF1565C0)
val StatusBlueContainer = Color(0xFFE3F2FD)

// Staff Console Dark Palette
val StaffDarkBackground = Color(0xFF140F0E)
val StaffDarkSurface = Color(0xFF201918)
val StaffDarkCard = Color(0xFF2C2220)
val StaffDarkBorder = Color(0xFF423431)
