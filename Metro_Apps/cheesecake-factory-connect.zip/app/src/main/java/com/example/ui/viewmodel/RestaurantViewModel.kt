package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.service.RestaurantApiService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppMode {
    CUSTOMER,
    STAFF_CONSOLE
}

enum class CustomerScreen {
    HOME,
    CHECK_IN,
    MENU,
    CART,
    CHECKOUT,
    ORDER_TRACKING,
    ORDER_HISTORY
}

enum class StaffTab {
    ARRIVALS,
    KITCHEN_KDS,
    TABLES,
    MENU_86
}

data class RestaurantUiState(
    val activeMode: AppMode = AppMode.CUSTOMER,
    val currentScreen: CustomerScreen = CustomerScreen.HOME,
    val activeStaffTab: StaffTab = StaffTab.ARRIVALS,
    val selectedLocationId: String = "loc_beverly_hills",
    val searchQuery: String = "",
    val selectedCategoryId: String? = null,
    val selectedDietaryFilter: String? = null,
    val cartItems: List<CartItem> = emptyList(),
    val diningMode: DiningMode = DiningMode.DINE_IN,
    val tableNumber: Int? = 3,
    val tipPercentage: Int = 18,
    val promoCode: String = "",
    val activeQuote: CartQuote? = null,
    val isQuoteLoading: Boolean = false,
    val errorMessage: String? = null,
    val bannerMessage: String? = null,
    // Active customer records
    val activeCustomerReservation: Reservation? = null,
    val activeCustomerWaitlist: WaitlistEntry? = null,
    val activeTrackingOrderId: String? = "ord_demo_101",
    // Customer profile info
    val customerName: String = "Sarah Jenkins",
    val customerPhone: String = "(310) 555-8902",
    val customerEmail: String = "sarah.j@example.com"
)

class RestaurantViewModel(
    private val apiService: RestaurantApiService = RestaurantApiService.getInstance()
) : ViewModel() {

    private val _uiState = MutableStateFlow(RestaurantUiState())
    val uiState: StateFlow<RestaurantUiState> = _uiState.asStateFlow()

    val locations = apiService.locations
    val categories = apiService.categories
    val menuItems = apiService.menuItems
    val reservations = apiService.reservations
    val waitlist = apiService.waitlist
    val tables = apiService.tables
    val orders = apiService.orders

    init {
        // Collect real-time events from API service
        viewModelScope.launch {
            apiService.eventFlow.collect { eventMsg ->
                _uiState.update { it.copy(bannerMessage = eventMsg) }
            }
        }
    }

    fun dismissBanner() {
        _uiState.update { it.copy(bannerMessage = null) }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun setAppMode(mode: AppMode) {
        _uiState.update { it.copy(activeMode = mode) }
    }

    fun navigateTo(screen: CustomerScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun setStaffTab(tab: StaffTab) {
        _uiState.update { it.copy(activeStaffTab = tab) }
    }

    fun selectLocation(locationId: String) {
        _uiState.update { it.copy(selectedLocationId = locationId) }
        recalculateQuoteIfCartNotEmpty()
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun selectCategory(categoryId: String?) {
        _uiState.update { it.copy(selectedCategoryId = categoryId) }
    }

    fun selectDietaryFilter(filter: String?) {
        _uiState.update {
            it.copy(selectedDietaryFilter = if (it.selectedDietaryFilter == filter) null else filter)
        }
    }

    // -------------------------------------------------------------
    // CHECK-IN & WAITLIST ACTIONS
    // -------------------------------------------------------------

    fun lookupReservation(query: String) {
        val result = apiService.lookupReservation(_uiState.value.selectedLocationId, query)
        result.onSuccess { reservation ->
            _uiState.update {
                it.copy(
                    activeCustomerReservation = reservation,
                    errorMessage = null,
                    bannerMessage = "Reservation found for ${reservation.customerName}"
                )
            }
        }.onFailure { error ->
            _uiState.update { it.copy(errorMessage = error.message) }
        }
    }

    fun checkInReservation(reservationId: String) {
        val idempotencyKey = "checkin_${reservationId}_${_uiState.value.customerPhone}"
        val result = apiService.checkInReservation(reservationId, idempotencyKey)
        result.onSuccess { updated ->
            _uiState.update {
                it.copy(
                    activeCustomerReservation = updated,
                    errorMessage = null,
                    bannerMessage = "Arrival Confirmed! The host stand is preparing your table."
                )
            }
        }.onFailure { error ->
            _uiState.update { it.copy(errorMessage = error.message) }
        }
    }

    fun joinWaitlist(name: String, phone: String, partySize: Int, notes: String) {
        val result = apiService.createWaitlistEntry(
            locationId = _uiState.value.selectedLocationId,
            name = name,
            phone = phone,
            partySize = partySize,
            notes = notes
        )
        result.onSuccess { entry ->
            _uiState.update {
                it.copy(
                    activeCustomerWaitlist = entry,
                    errorMessage = null,
                    bannerMessage = "Joined waitlist! Your queue ticket is ${entry.queueCode}."
                )
            }
        }.onFailure { error ->
            _uiState.update { it.copy(errorMessage = error.message) }
        }
    }

    fun confirmWaitlistArrival(entryId: String) {
        apiService.confirmWaitlistArrival(entryId).onSuccess { updated ->
            _uiState.update {
                it.copy(
                    activeCustomerWaitlist = updated,
                    bannerMessage = "Arrival acknowledged at host stand!"
                )
            }
        }
    }

    fun cancelWaitlist(entryId: String) {
        apiService.cancelWaitlistEntry(entryId).onSuccess { updated ->
            _uiState.update {
                it.copy(
                    activeCustomerWaitlist = updated,
                    bannerMessage = "You have left the waitlist."
                )
            }
        }
    }

    // -------------------------------------------------------------
    // CART & ORDERING ACTIONS
    // -------------------------------------------------------------

    fun addToCart(
        item: MenuItem,
        quantity: Int = 1,
        selectedModifiers: Map<String, List<ModifierOption>> = emptyMap(),
        instructions: String = ""
    ) {
        val newCartItem = CartItem(
            menuItem = item,
            quantity = quantity,
            selectedModifiers = selectedModifiers,
            specialInstructions = instructions
        )
        _uiState.update {
            it.copy(
                cartItems = it.cartItems + newCartItem,
                bannerMessage = "Added ${item.name} to cart"
            )
        }
        recalculateQuoteIfCartNotEmpty()
    }

    fun removeFromCart(cartItemId: String) {
        _uiState.update {
            it.copy(cartItems = it.cartItems.filterNot { item -> item.id == cartItemId })
        }
        recalculateQuoteIfCartNotEmpty()
    }

    fun updateCartQuantity(cartItemId: String, delta: Int) {
        val updated = _uiState.value.cartItems.mapNotNull { item ->
            if (item.id == cartItemId) {
                val newQ = item.quantity + delta
                if (newQ > 0) item.copy(quantity = newQ) else null
            } else item
        }
        _uiState.update { it.copy(cartItems = updated) }
        recalculateQuoteIfCartNotEmpty()
    }

    fun setDiningMode(mode: DiningMode, tableNum: Int?) {
        _uiState.update { it.copy(diningMode = mode, tableNumber = tableNum) }
        recalculateQuoteIfCartNotEmpty()
    }

    fun setTipPercentage(percentage: Int) {
        _uiState.update { it.copy(tipPercentage = percentage) }
        recalculateQuoteIfCartNotEmpty()
    }

    fun applyPromoCode(code: String) {
        _uiState.update { it.copy(promoCode = code) }
        recalculateQuoteIfCartNotEmpty()
    }

    fun recalculateQuoteIfCartNotEmpty() {
        val state = _uiState.value
        if (state.cartItems.isEmpty()) {
            _uiState.update { it.copy(activeQuote = null) }
            return
        }
        _uiState.update { it.copy(isQuoteLoading = true) }
        val result = apiService.calculateQuote(
            locationId = state.selectedLocationId,
            diningMode = state.diningMode,
            tableNumber = state.tableNumber,
            items = state.cartItems,
            promoCode = state.promoCode,
            tipPercentage = state.tipPercentage
        )
        result.onSuccess { quote ->
            _uiState.update {
                it.copy(
                    activeQuote = quote,
                    isQuoteLoading = false,
                    errorMessage = null
                )
            }
        }.onFailure { err ->
            _uiState.update {
                it.copy(
                    isQuoteLoading = false,
                    errorMessage = err.message
                )
            }
        }
    }

    fun submitOrderAndPay(cardMask: String) {
        val quote = _uiState.value.activeQuote
        if (quote == null) {
            _uiState.update { it.copy(errorMessage = "Please get a valid quote before payment") }
            return
        }

        val idempotencyKey = "order_${quote.quoteToken}_${System.currentTimeMillis()}"
        val orderResult = apiService.createOrder(
            quote = quote,
            customerName = _uiState.value.customerName,
            customerPhone = _uiState.value.customerPhone,
            idempotencyKey = idempotencyKey
        )

        orderResult.onSuccess { order ->
            // Simulate Payment Provider capture
            val payResult = apiService.confirmPayment(order.id, cardMask)
            payResult.onSuccess { confirmedOrder ->
                _uiState.update {
                    it.copy(
                        cartItems = emptyList(),
                        activeQuote = null,
                        activeTrackingOrderId = confirmedOrder.id,
                        currentScreen = CustomerScreen.ORDER_TRACKING,
                        bannerMessage = "Payment authorized! Order ${confirmedOrder.orderNumber} sent to kitchen."
                    )
                }
            }.onFailure { payErr ->
                _uiState.update { it.copy(errorMessage = "Payment failed: ${payErr.message}") }
            }
        }.onFailure { err ->
            _uiState.update { it.copy(errorMessage = err.message) }
        }
    }

    fun cancelActiveOrder(orderId: String, reason: String) {
        val res = apiService.cancelOrder(orderId, reason)
        res.onSuccess {
            _uiState.update { it.copy(bannerMessage = "Order cancelled successfully") }
        }.onFailure { err ->
            _uiState.update { it.copy(errorMessage = err.message) }
        }
    }

    // -------------------------------------------------------------
    // STAFF CONSOLE ACTIONS
    // -------------------------------------------------------------

    fun staffSeatReservation(reservationId: String, tableNumber: Int) {
        apiService.seatReservation(reservationId, tableNumber)
    }

    fun staffMarkNoShow(reservationId: String) {
        apiService.markReservationNoShow(reservationId)
    }

    fun staffNotifyWaitlist(entryId: String, tableNumber: Int?) {
        apiService.markWaitlistReady(entryId, tableNumber)
    }

    fun staffSeatWaitlist(entryId: String, tableNumber: Int) {
        apiService.seatWaitlistEntry(entryId, tableNumber)
    }

    fun staffAcceptOrder(orderId: String) {
        apiService.acceptOrder(orderId)
    }

    fun staffStartPreparing(orderId: String) {
        apiService.markOrderPreparing(orderId)
    }

    fun staffMarkOrderReady(orderId: String) {
        apiService.markOrderReady(orderId)
    }

    fun staffMarkOrderFulfilled(orderId: String) {
        apiService.markOrderFulfilled(orderId)
    }

    fun staffRefundOrder(orderId: String, reason: String) {
        apiService.refundOrder(orderId, reason)
    }

    fun staffToggleItemStock(itemId: String) {
        apiService.toggleItemAvailability(itemId).onSuccess {
            recalculateQuoteIfCartNotEmpty()
        }
    }
}
