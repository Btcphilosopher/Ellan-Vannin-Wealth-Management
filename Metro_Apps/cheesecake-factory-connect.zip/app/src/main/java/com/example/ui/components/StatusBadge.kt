package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ArrivalStatus
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentStatus
import com.example.data.model.WaitlistStatus
import com.example.ui.theme.*

@Composable
fun ArrivalStatusBadge(status: ArrivalStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (status) {
        ArrivalStatus.RESERVED -> Triple(Color(0xFFE3F2FD), Color(0xFF1565C0), Color(0xFF90CAF9))
        ArrivalStatus.ARRIVAL_CONFIRMED -> Triple(StatusAmberContainer, StatusAmber, Color(0xFFFDE68A))
        ArrivalStatus.AWAITING_SEATING -> Triple(StatusAmberContainer, StatusAmber, Color(0xFFFDE68A))
        ArrivalStatus.SEATED -> Triple(StatusGreenContainer, StatusGreen, Color(0xFFA7F3D0))
        ArrivalStatus.CANCELLED, ArrivalStatus.NO_SHOW -> Triple(StatusRedContainer, StatusRed, Color(0xFFFECACA))
    }

    BadgeBox(text = status.displayName, bgColor = bgColor, textColor = textColor, borderColor = borderColor, modifier = modifier)
}

@Composable
fun WaitlistStatusBadge(status: WaitlistStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (status) {
        WaitlistStatus.REQUESTED, WaitlistStatus.ACCEPTED -> Triple(Color(0xFFEDE9FE), Color(0xFF6D28D9), Color(0xFFDDD6FE))
        WaitlistStatus.WAITING -> Triple(StatusAmberContainer, StatusAmber, Color(0xFFFDE68A))
        WaitlistStatus.READY_TO_SEAT -> Triple(StatusGreenContainer, StatusGreen, Color(0xFFA7F3D0))
        WaitlistStatus.SEATED -> Triple(Color(0xFFE0F2FE), Color(0xFF0369A1), Color(0xFFBAE6FD))
        WaitlistStatus.CANCELLED, WaitlistStatus.EXPIRED -> Triple(StatusRedContainer, StatusRed, Color(0xFFFECACA))
    }

    BadgeBox(text = status.displayName, bgColor = bgColor, textColor = textColor, borderColor = borderColor, modifier = modifier)
}

@Composable
fun OrderStatusBadge(status: OrderStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (status) {
        OrderStatus.CREATED, OrderStatus.AWAITING_PAYMENT -> Triple(Color(0xFFF3F4F6), Color(0xFF4B5563), Color(0xFFE5E7EB))
        OrderStatus.CONFIRMED -> Triple(Color(0xFFEFF6FF), Color(0xFF1D4ED8), Color(0xFFBFDBFE))
        OrderStatus.ACCEPTED -> Triple(Color(0xFFF5F3FF), Color(0xFF7C3AED), Color(0xFFDDD6FE))
        OrderStatus.PREPARING -> Triple(StatusAmberContainer, StatusAmber, Color(0xFFFDE68A))
        OrderStatus.READY -> Triple(StatusGreenContainer, StatusGreen, Color(0xFFA7F3D0))
        OrderStatus.FULFILLED -> Triple(Color(0xFFE0E7FF), Color(0xFF3730A3), Color(0xFFC7D2FE))
        OrderStatus.CANCELLED, OrderStatus.REFUNDED -> Triple(StatusRedContainer, StatusRed, Color(0xFFFECACA))
    }

    BadgeBox(text = status.displayName, bgColor = bgColor, textColor = textColor, borderColor = borderColor, modifier = modifier)
}

@Composable
fun PaymentStatusBadge(status: PaymentStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (status) {
        PaymentStatus.PENDING -> Triple(StatusAmberContainer, StatusAmber, Color(0xFFFDE68A))
        PaymentStatus.AUTHORIZED, PaymentStatus.PAID -> Triple(StatusGreenContainer, StatusGreen, Color(0xFFA7F3D0))
        PaymentStatus.FAILED -> Triple(StatusRedContainer, StatusRed, Color(0xFFFECACA))
        PaymentStatus.REFUNDED -> Triple(Color(0xFFF3F4F6), Color(0xFF4B5563), Color(0xFFE5E7EB))
    }

    BadgeBox(text = status.displayName, bgColor = bgColor, textColor = textColor, borderColor = borderColor, modifier = modifier)
}

@Composable
private fun BadgeBox(
    text: String,
    bgColor: Color,
    textColor: Color,
    borderColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
