package com.example.ui.screens.customer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.ArrivalStatusBadge
import com.example.ui.components.WaitlistStatusBadge
import com.example.ui.theme.*

@Composable
fun CheckInScreen(
    currentLocation: RestaurantLocation,
    activeReservation: Reservation?,
    activeWaitlist: WaitlistEntry?,
    errorMessage: String?,
    onLookupReservation: (String) -> Unit,
    onCheckInReservation: (String) -> Unit,
    onJoinWaitlist: (name: String, phone: String, partySize: Int, notes: String) -> Unit,
    onConfirmWaitlistArrival: (String) -> Unit,
    onCancelWaitlist: (String) -> Unit,
    onDismissError: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Reservation Check-In, 1 = Join Waitlist
    var lookupQuery by remember { mutableStateOf("") }

    // Waitlist Form State
    var waitlistName by remember { mutableStateOf("Sarah Jenkins") }
    var waitlistPhone by remember { mutableStateOf("(310) 555-8902") }
    var waitlistPartySize by remember { mutableIntStateOf(2) }
    var waitlistNotes by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Location Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = currentLocation.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BurgundyDeep
                    )
                    Text(
                        text = "Current Host Stand Wait: ~${currentLocation.waitEstimateMinutes} min",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedText
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(StatusGreenContainer)
                        .border(1.dp, Color(0xFFA7F3D0), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Host Stand Open",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = StatusGreen
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tab Selector (Reservation Check-In vs Join Waitlist)
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = BurgundyDeep,
            divider = {}
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                modifier = Modifier.testTag("tab_reservation_checkin"),
                text = {
                    Text(
                        "Reservation Check-In",
                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                    )
                }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                modifier = Modifier.testTag("tab_join_waitlist"),
                text = {
                    Text(
                        "Join Waitlist",
                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                    )
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Error message box
        if (errorMessage != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(StatusRedContainer)
                    .border(1.dp, Color(0xFFFECACA), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = StatusRed,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDismissError, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = StatusRed, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // TAB 0: RESERVATION CHECK-IN
        if (selectedTab == 0) {
            // Lookup input
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, WarmBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Find Your Reservation",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalText
                    )
                    Text(
                        text = "Enter your confirmation code (e.g. CCF-7821) or phone number",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedText
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = lookupQuery,
                            onValueChange = { lookupQuery = it },
                            placeholder = { Text("Code (e.g. CCF-7821) or phone") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("reservation_lookup_input"),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldAccent,
                                unfocusedBorderColor = WarmBorder
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (lookupQuery.isNotBlank()) {
                                    onLookupReservation(lookupQuery)
                                } else {
                                    // Default demo lookup
                                    onLookupReservation("CCF-7821")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(56.dp)
                                .testTag("reservation_lookup_button")
                        ) {
                            Text("Find", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Demo codes: CCF-7821 (Sarah Connor) • CCF-4412 (David Miller)",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Display Active / Looked-up Reservation
            if (activeReservation != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.5.dp, GoldAccent, RoundedCornerShape(16.dp))
                        .testTag("reservation_details_card"),
                    colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Booking ${activeReservation.confirmationCode}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BurgundyDeep
                                )
                                Text(
                                    text = activeReservation.customerName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CharcoalText
                                )
                            }
                            ArrivalStatusBadge(status = activeReservation.arrivalStatus)
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = WarmBorder)
                        Spacer(modifier = Modifier.height(14.dp))

                        // Details rows
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Date & Time", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                            Text(activeReservation.reservationDateTime, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Party Size", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                            Text("${activeReservation.partySize} Guests", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Preferences", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                            Text(activeReservation.seatingPreference, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }

                        if (activeReservation.tableNumber != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Table Assignment", style = MaterialTheme.typography.bodyMedium, color = MutedText)
                                Text("Table #${activeReservation.tableNumber}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = StatusGreen)
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Check-In Action Button
                        when (activeReservation.arrivalStatus) {
                            ArrivalStatus.RESERVED -> {
                                Button(
                                    onClick = { onCheckInReservation(activeReservation.id) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("submit_arrival_checkin_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("I Have Arrived • Check In Now", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                            ArrivalStatus.AWAITING_SEATING -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(StatusAmberContainer)
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Text(
                                            text = "Arrival Confirmed! Table Preparation In Progress",
                                            fontWeight = FontWeight.Bold,
                                            color = StatusAmber,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "Please relax in our waiting lounge. You will receive an SMS and screen notification when your host is ready to seat your party.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = CharcoalText
                                        )
                                    }
                                }
                            }
                            ArrivalStatus.SEATED -> {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(StatusGreenContainer)
                                        .padding(12.dp)
                                ) {
                                    Text(
                                        text = "Party Seated at Table #${activeReservation.tableNumber ?: '—'}. Welcome to The Cheesecake Factory!",
                                        fontWeight = FontWeight.Bold,
                                        color = StatusGreen
                                    )
                                }
                            }
                            else -> {}
                        }
                    }
                }
            }
        }

        // TAB 1: JOIN WAITLIST
        if (selectedTab == 1) {
            // If already on waitlist
            if (activeWaitlist != null && activeWaitlist.status != WaitlistStatus.CANCELLED) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.5.dp, GoldAccent, RoundedCornerShape(16.dp))
                        .testTag("waitlist_ticket_card"),
                    colors = CardDefaults.cardColors(containerColor = WarmSurfaceElevated)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        WaitlistStatusBadge(status = activeWaitlist.status)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = activeWaitlist.queueCode,
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = BurgundyDeep
                        )
                        Text(
                            text = "${activeWaitlist.customerName} • Party of ${activeWaitlist.partySize}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Position in Line", style = MaterialTheme.typography.labelSmall, color = MutedText)
                                Text("#${activeWaitlist.queuePosition}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = BurgundyDeep)
                            }
                            VerticalDivider(modifier = Modifier.height(36.dp), color = WarmBorder)
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Estimated Wait", style = MaterialTheme.typography.labelSmall, color = MutedText)
                                Text("~${activeWaitlist.estimatedWaitMinutes} min", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = StatusAmber)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (activeWaitlist.status == WaitlistStatus.READY_TO_SEAT) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(StatusGreenContainer)
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "Your Table is Ready! Please proceed to the host stand now.",
                                    fontWeight = FontWeight.Bold,
                                    color = StatusGreen
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onCancelWaitlist(activeWaitlist.id) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("cancel_waitlist_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Leave Waitlist", color = StatusRed)
                            }

                            Button(
                                onClick = { onConfirmWaitlistArrival(activeWaitlist.id) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("confirm_waitlist_arrival_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("I'm Nearby", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                // Join Waitlist Form
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, WarmBorder)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Join Live Waitlist",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalText
                        )
                        Text(
                            text = "Get in line remotely. We will notify you when your table is ready.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedText
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text("Party Size", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(WarmSurfaceElevated)
                                .border(1.dp, WarmBorder, RoundedCornerShape(12.dp))
                                .padding(4.dp)
                        ) {
                            IconButton(
                                onClick = { if (waitlistPartySize > 1) waitlistPartySize-- },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = BurgundyDeep)
                            }
                            Text(
                                text = "$waitlistPartySize Guests",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                            IconButton(
                                onClick = { if (waitlistPartySize < 12) waitlistPartySize++ },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Increase", tint = BurgundyDeep)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Full Name", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = waitlistName,
                            onValueChange = { waitlistName = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("waitlist_name_input"),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldAccent,
                                unfocusedBorderColor = WarmBorder
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Mobile Phone (For SMS alert)", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = waitlistPhone,
                            onValueChange = { waitlistPhone = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("waitlist_phone_input"),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldAccent,
                                unfocusedBorderColor = WarmBorder
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Seating Notes / Accessibility (Optional)", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = waitlistNotes,
                            onValueChange = { waitlistNotes = it },
                            placeholder = { Text("e.g. Booth preferred, wheelchair access, high chair") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("waitlist_notes_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldAccent,
                                unfocusedBorderColor = WarmBorder
                            )
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = {
                                onJoinWaitlist(waitlistName, waitlistPhone, waitlistPartySize, waitlistNotes)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("join_waitlist_submit_button")
                        ) {
                            Text("Join Waitlist (~${currentLocation.waitEstimateMinutes} min wait)", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
