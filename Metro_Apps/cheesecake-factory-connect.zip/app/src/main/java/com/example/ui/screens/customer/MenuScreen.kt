package com.example.ui.screens.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MenuCategory
import com.example.data.model.MenuItem
import com.example.ui.theme.*

@Composable
fun MenuScreen(
    categories: List<MenuCategory>,
    items: List<MenuItem>,
    selectedCategoryId: String?,
    searchQuery: String,
    selectedDietaryFilter: String?,
    onSelectCategory: (String?) -> Unit,
    onSearchChange: (String) -> Unit,
    onSelectDietaryFilter: (String?) -> Unit,
    onCustomizeItem: (MenuItem) -> Unit
) {
    // Filter items
    val filteredItems = items.filter { item ->
        val matchesCategory = selectedCategoryId == null || item.categoryId == selectedCategoryId
        val matchesSearch = searchQuery.isBlank() ||
                item.name.contains(searchQuery, ignoreCase = true) ||
                item.description.contains(searchQuery, ignoreCase = true)
        val matchesDietary = selectedDietaryFilter == null ||
                item.dietaryTags.any { it.contains(selectedDietaryFilter, ignoreCase = true) }

        matchesCategory && matchesSearch && matchesDietary
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search & Filter Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search dishes, cheesecakes, pastas...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MutedText) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("menu_search_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldAccent,
                    unfocusedBorderColor = WarmBorder
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Dietary Filter Chips
            val dietaryOptions = listOf("Signature", "Vegetarian", "Gluten-Free")
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedDietaryFilter == null,
                        onClick = { onSelectDietaryFilter(null) },
                        label = { Text("All Dishes") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BurgundyDeep,
                            selectedLabelColor = Color.White
                        )
                    )
                }
                items(dietaryOptions) { filter ->
                    val isSelected = selectedDietaryFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectDietaryFilter(filter) },
                        label = { Text(filter) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GoldAccent,
                            selectedLabelColor = EspressoDark
                        )
                    )
                }
            }
        }

        // Horizontal Category Tabs
        ScrollableTabRow(
            selectedTabIndex = if (selectedCategoryId == null) 0 else {
                val idx = categories.indexOfFirst { it.id == selectedCategoryId }
                if (idx != -1) idx + 1 else 0
            },
            containerColor = WarmSurfaceElevated,
            contentColor = BurgundyDeep,
            edgePadding = 16.dp,
            divider = {}
        ) {
            Tab(
                selected = selectedCategoryId == null,
                onClick = { onSelectCategory(null) },
                text = {
                    Text(
                        "All Items",
                        fontWeight = if (selectedCategoryId == null) FontWeight.Bold else FontWeight.Normal
                    )
                }
            )
            categories.forEach { cat ->
                val isSelected = selectedCategoryId == cat.id
                Tab(
                    selected = isSelected,
                    onClick = { onSelectCategory(cat.id) },
                    text = {
                        Text(
                            cat.name,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        // Menu Items List
        if (filteredItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No dishes found",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BurgundyDeep
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Try clearing your search query or dietary filters.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedText
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredItems, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, WarmBorder, RoundedCornerShape(16.dp))
                            .clickable(enabled = item.isAvailable) { onCustomizeItem(item) }
                            .testTag("menu_item_card_${item.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (item.isAvailable) MaterialTheme.colorScheme.surface else Color(0xFFF5F5F5)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            // Top badges & price
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    if (!item.isAvailable) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(StatusRedContainer)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "86'D • SOLD OUT",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = StatusRed
                                            )
                                        }
                                    } else {
                                        item.dietaryTags.forEach { tag ->
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(if (tag == "Signature") BurgundyDeep else WarmSurfaceElevated)
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = tag.uppercase(),
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (tag == "Signature") GoldLight else BurgundyDeep
                                                )
                                            }
                                        }
                                    }
                                }

                                Text(
                                    text = "$${"%.2f".format(item.priceCents / 100.0)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (item.isAvailable) BurgundyDeep else MutedText
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (item.isAvailable) CharcoalText else MutedText
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MutedText,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${item.calories} Calories",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MutedTextLight
                                )

                                if (item.isAvailable) {
                                    Button(
                                        onClick = { onCustomizeItem(item) },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = BurgundyDeep),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Customize & Add", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Text(
                                        text = "Unavailable Today",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = StatusRed,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
