package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.*
import com.example.data.repository.BusRepository
import com.example.data.routing.RoutingEngine
import com.example.data.seed.SeedData
import com.example.data.simulation.SimVehicle
import com.example.data.simulation.SimulationEngine
import com.example.data.simulation.SimulationState
import com.example.ui.maps.BahrainMap
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Screen enum definitions
enum class AppScreen {
    ONBOARDING,
    HOME,
    MAP,
    JOURNEY_PLANNER,
    ROUTE_DIRECTORY,
    ROUTE_DETAIL,
    STOP_DIRECTORY,
    STOP_DETAIL,
    NEARBY_STOPS,
    ACTIVE_JOURNEY,
    TICKETS,
    TICKET_DETAIL,
    ALERTS_CENTER,
    PROFILE,
    ACCESSIBILITY_SETTINGS,
    NOTIFICATIONS_CENTER,
    HELP_SUPPORT,
    DEV_CONSOLE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContainer() {
    val context = LocalContext.current
    val repository = remember { BusRepository(context) }
    val scope = rememberCoroutineScope()

    // --- Global App States ---
    var currentLanguage by remember { mutableStateOf("ar") } // "ar" (Arabic) or "en" (English)
    var isLargeText by remember { mutableStateOf(false) }
    var avoidStairs by remember { mutableStateOf(false) }
    var minimizeWalking by remember { mutableStateOf(false) }
    var reducedMotion by remember { mutableStateOf(false) }

    // Navigation and sub-screen parameters
    var activeScreen by remember { mutableStateOf(AppScreen.ONBOARDING) }
    var previousScreen by remember { mutableStateOf(AppScreen.ONBOARDING) }
    var selectedRouteId by remember { mutableStateOf<String?>(null) }
    var selectedStopId by remember { mutableStateOf<String?>(null) }
    var selectedTicketId by remember { mutableStateOf<String?>(null) }

    // User Profile
    var passengerName by remember { mutableStateOf("جاسم آل خليفة") }
    var userOnboarded by remember { mutableStateOf(false) }

    // Journey Planner states
    var originStopId by remember { mutableStateOf("S1") } // Manama
    var destStopId by remember { mutableStateOf("S7") }   // Airport
    var computedPlans by remember { mutableStateOf<List<JourneyPlan>>(emptyList()) }
    var selectedPlan by remember { mutableStateOf<JourneyPlan?>(null) }
    var activeJourneyState by remember { mutableStateOf<ActiveJourneyState?>(null) }

    // Ticket purchase dialog state
    var showPurchaseDialogForProduct by remember { mutableStateOf<FareProduct?>(null) }
    var paymentCardNumber by remember { mutableStateOf("") }
    var paymentProcessing by remember { mutableStateOf(false) }

    // Support report form state
    var showSupportReportDialog by remember { mutableStateOf(false) }
    var reportCategory by remember { mutableStateOf(ReportCategory.STOP_CONDITION) }
    var reportDescription by remember { mutableStateOf("") }
    var reportLocation by remember { mutableStateOf("") }

    // Simulation Live States
    val simState by SimulationEngine.state.collectAsState()

    // Favourites caching
    var favourites by remember { mutableStateOf<List<FavouriteItem>>(emptyList()) }
    var purchasedTickets by remember { mutableStateOf<List<Ticket>>(emptyList()) }
    var notifications by remember { mutableStateOf<List<AppNotification>>(emptyList()) }
    var reportsList by remember { mutableStateOf<List<UserReport>>(emptyList()) }

    // Reload triggers
    fun reloadUserData() {
        scope.launch {
            favourites = repository.getFavourites()
            purchasedTickets = repository.getTickets()
            notifications = repository.getNotifications()
            reportsList = repository.getAllReports()
        }
    }

    LaunchedEffect(Unit) {
        SimulationEngine.initialize(context)
        reloadUserData()
    }

    // Navigation Helper
    fun navigateTo(screen: AppScreen) {
        previousScreen = activeScreen
        activeScreen = screen
        reloadUserData()
    }

    // Active simulated journey ticker
    LaunchedEffect(simState.simTime, activeJourneyState) {
        val currJourney = activeJourneyState
        if (currJourney != null && simState.isRunning) {
            // Find current leg
            val leg = currJourney.plan.legs.getOrNull(currJourney.currentLegIndex)
            if (leg != null && leg.type == "BUS") {
                // Find vehicle on this route to track progress
                val vehicle = simState.vehicles.find { it.routeNumber == leg.routeNumber }
                if (vehicle != null) {
                    val stopsList = SeedData.stops
                    val routeObj = SeedData.routes.find { it.routeNumber == vehicle.routeNumber }
                    val rStops = com.example.data.model.JsonHelper.fromJsonStringList(routeObj?.stopsListJson ?: "[]")
                    val targetStopIdx = rStops.indexOf(leg.endStopId)
                    val vehicleStopIdx = rStops.indexOf(vehicle.currentStopId)

                    val remaining = (targetStopIdx - vehicleStopIdx).coerceAtLeast(0)
                    val progress = vehicle.progressPercent
                    val eta = (remaining * 6 + (1 - progress) * 6).toInt().coerceAtLeast(1)

                    activeJourneyState = currJourney.copy(
                        currentStopId = vehicle.currentStopId,
                        nextStopId = vehicle.nextStopId,
                        etaMinutes = eta,
                        stopsRemaining = remaining,
                        progressPercent = progress
                    )

                    // Trigger alert if arriving (remaining is 1, progress > 0.8)
                    if (remaining == 1 && progress > 0.8f && currJourney.isApproachingReminderSet) {
                        repository.submitReport(
                            ReportCategory.FEEDBACK,
                            "الرحلة النشطة",
                            "تنبيه الاقتراب: اقتربت الحافلة من محطة ${stopsList.find { it.stopId == leg.endStopId }?.nameAr}",
                            leg.routeNumber,
                            leg.endStopId
                        )
                        // Also add an in-app local notification
                        repository.activateTicket(
                            ticketId = "", // simulated alert
                            validityHours = 0
                        )
                    }

                    if (remaining == 0 && progress >= 0.0f && vehicle.currentStopId == leg.endStopId) {
                        // End of leg
                        if (currJourney.currentLegIndex < currJourney.plan.legs.lastIndex) {
                            activeJourneyState = currJourney.copy(
                                currentLegIndex = currJourney.currentLegIndex + 1
                            )
                        } else {
                            // Completed journey!
                            activeJourneyState = null
                            navigateTo(AppScreen.HOME)
                        }
                    }
                }
            } else if (leg != null && leg.type == "WALK") {
                // Simulate walk progress every simulated tick
                val progress = currJourney.progressPercent + 0.25f
                if (progress >= 1.0f) {
                    if (currJourney.currentLegIndex < currJourney.plan.legs.lastIndex) {
                        activeJourneyState = currJourney.copy(
                            currentLegIndex = currJourney.currentLegIndex + 1,
                            progressPercent = 0.0f
                        )
                    } else {
                        activeJourneyState = null
                        navigateTo(AppScreen.HOME)
                    }
                } else {
                    activeJourneyState = currJourney.copy(
                        progressPercent = progress,
                        etaMinutes = (leg.durationMinutes * (1.0f - progress)).toInt().coerceAtLeast(1)
                    )
                }
            }
        }
    }

    // Force RTL for Arabic, LTR for English
    val layoutDirection = if (currentLanguage == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        val appThemeColors = MaterialTheme.colorScheme

        Scaffold(
            bottomBar = {
                if (activeScreen != AppScreen.ONBOARDING && activeScreen != AppScreen.ACTIVE_JOURNEY) {
                    NavigationBar(
                        containerColor = appThemeColors.surface,
                        tonalElevation = 8.dp,
                        modifier = Modifier.testTag("bottom_nav_bar")
                    ) {
                        val items = listOf(
                            Triple(AppScreen.HOME, Icons.Default.Home, Icons.Outlined.Home),
                            Triple(AppScreen.MAP, Icons.Default.Map, Icons.Outlined.Map),
                            Triple(AppScreen.JOURNEY_PLANNER, Icons.Default.DirectionsBus, Icons.Outlined.DirectionsBus),
                            Triple(AppScreen.TICKETS, Icons.Default.QrCode, Icons.Outlined.QrCode),
                            Triple(AppScreen.DEV_CONSOLE, Icons.Default.DashboardCustomize, Icons.Outlined.DashboardCustomize)
                        )

                        items.forEach { (screen, selectedIcon, unselectedIcon) ->
                            val isSelected = when (screen) {
                                AppScreen.HOME -> activeScreen == AppScreen.HOME || activeScreen == AppScreen.ROUTE_DIRECTORY || activeScreen == AppScreen.ROUTE_DETAIL || activeScreen == AppScreen.STOP_DIRECTORY || activeScreen == AppScreen.STOP_DETAIL || activeScreen == AppScreen.NEARBY_STOPS
                                AppScreen.MAP -> activeScreen == AppScreen.MAP
                                AppScreen.JOURNEY_PLANNER -> activeScreen == AppScreen.JOURNEY_PLANNER
                                AppScreen.TICKETS -> activeScreen == AppScreen.TICKETS || activeScreen == AppScreen.TICKET_DETAIL
                                AppScreen.DEV_CONSOLE -> activeScreen == AppScreen.DEV_CONSOLE || activeScreen == AppScreen.PROFILE || activeScreen == AppScreen.ACCESSIBILITY_SETTINGS || activeScreen == AppScreen.NOTIFICATIONS_CENTER || activeScreen == AppScreen.HELP_SUPPORT
                                else -> false
                            }

                            val label = when (screen) {
                                AppScreen.HOME -> if (currentLanguage == "ar") "الرئيسية" else "Home"
                                AppScreen.MAP -> if (currentLanguage == "ar") "الخريطة" else "Map"
                                AppScreen.JOURNEY_PLANNER -> if (currentLanguage == "ar") "الرحلات" else "Journeys"
                                AppScreen.TICKETS -> if (currentLanguage == "ar") "التذاكر" else "Tickets"
                                AppScreen.DEV_CONSOLE -> if (currentLanguage == "ar") "المزيد" else "More"
                                else -> ""
                            }

                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { navigateTo(screen) },
                                icon = {
                                    Icon(
                                        imageVector = if (isSelected) selectedIcon else unselectedIcon,
                                        contentDescription = label,
                                        tint = if (isSelected) appThemeColors.primary else appThemeColors.onSurfaceVariant
                                    )
                                },
                                label = {
                                    Text(
                                        text = label,
                                        fontSize = if (isLargeText) 14.sp else 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) appThemeColors.primary else appThemeColors.onSurfaceVariant
                                    )
                                }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(appThemeColors.background)
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = activeScreen,
                    transitionSpec = {
                        if (reducedMotion) {
                            fadeIn() togetherWith fadeOut()
                        } else {
                            slideInHorizontally { width -> if (layoutDirection == LayoutDirection.Rtl) -width else width } + fadeIn() togetherWith
                                    slideOutHorizontally { width -> if (layoutDirection == LayoutDirection.Rtl) width else -width } + fadeOut()
                        }
                    },
                    label = "screen_transition"
                ) { targetScreen ->
                    when (targetScreen) {
                        AppScreen.ONBOARDING -> {
                            OnboardingScreen(
                                currentLanguage = currentLanguage,
                                passengerName = passengerName,
                                onNameChange = { passengerName = it },
                                onLanguageToggle = { currentLanguage = if (currentLanguage == "ar") "en" else "ar" },
                                onStart = {
                                    userOnboarded = true
                                    navigateTo(AppScreen.HOME)
                                }
                            )
                        }

                        AppScreen.HOME -> {
                            HomeScreen(
                                currentLanguage = currentLanguage,
                                passengerName = passengerName,
                                simTime = simState.simTime,
                                repository = repository,
                                alertsCount = simState.alerts.size,
                                onActionClick = { action ->
                                    when (action) {
                                        "PLAN" -> navigateTo(AppScreen.JOURNEY_PLANNER)
                                        "ROUTES" -> navigateTo(AppScreen.ROUTE_DIRECTORY)
                                        "STOPS" -> navigateTo(AppScreen.STOP_DIRECTORY)
                                        "TICKETS" -> navigateTo(AppScreen.TICKETS)
                                        "DEV" -> navigateTo(AppScreen.DEV_CONSOLE)
                                        "ALERTS" -> navigateTo(AppScreen.ALERTS_CENTER)
                                    }
                                },
                                onStopSelected = { stopId ->
                                    selectedStopId = stopId
                                    navigateTo(AppScreen.STOP_DETAIL)
                                },
                                onLanguageToggle = { currentLanguage = if (currentLanguage == "ar") "en" else "ar" }
                            )
                        }

                        AppScreen.MAP -> {
                            MapScreen(
                                currentLanguage = currentLanguage,
                                activeVehicles = simState.vehicles,
                                closedStops = simState.closedStops,
                                selectedStopId = selectedStopId,
                                repository = repository,
                                onStopClick = { stop ->
                                    selectedStopId = stop.stopId
                                    navigateTo(AppScreen.STOP_DETAIL)
                                }
                            )
                        }

                        AppScreen.JOURNEY_PLANNER -> {
                            JourneyPlannerScreen(
                                currentLanguage = currentLanguage,
                                originStopId = originStopId,
                                destStopId = destStopId,
                                onOriginChange = { originStopId = it },
                                onDestChange = { destStopId = it },
                                computedPlans = computedPlans,
                                onSearch = {
                                    val startStop = SeedData.stops.find { it.stopId == originStopId }
                                    val destStop = SeedData.stops.find { it.stopId == destStopId }
                                    if (startStop != null && destStop != null) {
                                        computedPlans = RoutingEngine.planJourney(
                                            startLat = startStop.latitude,
                                            startLng = startStop.longitude,
                                            destLat = destStop.latitude,
                                            destLng = destStop.longitude,
                                            minimizeWalking = minimizeWalking,
                                            useBusOnly = avoidStairs
                                        )
                                    }
                                },
                                onSelectPlan = { plan ->
                                    selectedPlan = plan
                                    // Start journey active simulation
                                    activeJourneyState = ActiveJourneyState(
                                        plan = plan,
                                        currentLegIndex = 0,
                                        currentStopId = plan.legs.firstOrNull { it.type == "BUS" }?.startStopId,
                                        nextStopId = plan.legs.firstOrNull { it.type == "BUS" }?.endStopId,
                                        etaMinutes = plan.totalDurationMinutes,
                                        stopsRemaining = plan.legs.filter { it.type == "BUS" }.sumOf { it.stopCount },
                                        progressPercent = 0.0f
                                    )
                                    navigateTo(AppScreen.ACTIVE_JOURNEY)
                                },
                                avoidStairs = avoidStairs,
                                minimizeWalking = minimizeWalking,
                                onAvoidStairsToggle = { avoidStairs = it },
                                onMinimizeWalkingToggle = { minimizeWalking = it }
                            )
                        }

                        AppScreen.ROUTE_DIRECTORY -> {
                            RouteDirectoryScreen(
                                currentLanguage = currentLanguage,
                                repository = repository,
                                onRouteClick = { routeId ->
                                    selectedRouteId = routeId
                                    navigateTo(AppScreen.ROUTE_DETAIL)
                                }
                            )
                        }

                        AppScreen.ROUTE_DETAIL -> {
                            RouteDetailScreen(
                                currentLanguage = currentLanguage,
                                routeId = selectedRouteId ?: "10",
                                repository = repository,
                                onBack = { navigateTo(AppScreen.ROUTE_DIRECTORY) },
                                onStopClick = { stopId ->
                                    selectedStopId = stopId
                                    navigateTo(AppScreen.STOP_DETAIL)
                                }
                            )
                        }

                        AppScreen.STOP_DIRECTORY -> {
                            StopDirectoryScreen(
                                currentLanguage = currentLanguage,
                                repository = repository,
                                onStopClick = { stopId ->
                                    selectedStopId = stopId
                                    navigateTo(AppScreen.STOP_DETAIL)
                                }
                            )
                        }

                        AppScreen.STOP_DETAIL -> {
                            StopDetailScreen(
                                currentLanguage = currentLanguage,
                                stopId = selectedStopId ?: "S1",
                                repository = repository,
                                onBack = { navigateTo(AppScreen.HOME) },
                                onReportIssue = {
                                    reportLocation = selectedStopId ?: ""
                                    showSupportReportDialog = true
                                }
                            )
                        }

                        AppScreen.ACTIVE_JOURNEY -> {
                            ActiveJourneyScreen(
                                currentLanguage = currentLanguage,
                                activeJourneyState = activeJourneyState,
                                simTime = simState.simTime,
                                onCancel = {
                                    activeJourneyState = null
                                    navigateTo(AppScreen.HOME)
                                },
                                onReportIssue = {
                                    reportLocation = activeJourneyState?.currentStopId ?: "حافلة نشطة"
                                    showSupportReportDialog = true
                                },
                                onToggleReminder = {
                                    val curr = activeJourneyState
                                    if (curr != null) {
                                        activeJourneyState = curr.copy(
                                            isApproachingReminderSet = !curr.isApproachingReminderSet
                                        )
                                    }
                                }
                            )
                        }

                        AppScreen.TICKETS -> {
                            TicketsScreen(
                                currentLanguage = currentLanguage,
                                passengerName = passengerName,
                                repository = repository,
                                purchasedTickets = purchasedTickets,
                                onProductSelect = { showPurchaseDialogForProduct = it },
                                onTicketSelect = { ticketId ->
                                    selectedTicketId = ticketId
                                    navigateTo(AppScreen.TICKET_DETAIL)
                                }
                            )
                        }

                        AppScreen.TICKET_DETAIL -> {
                            TicketDetailScreen(
                                currentLanguage = currentLanguage,
                                ticketId = selectedTicketId ?: "",
                                repository = repository,
                                onBack = { navigateTo(AppScreen.TICKETS) },
                                onScanUsed = {
                                    scope.launch {
                                        repository.scanAndUseTicket(selectedTicketId ?: "")
                                        reloadUserData()
                                        navigateTo(AppScreen.TICKETS)
                                    }
                                }
                            )
                        }

                        AppScreen.DEV_CONSOLE -> {
                            DevConsoleScreen(
                                currentLanguage = currentLanguage,
                                simState = simState,
                                onAction = { action, value ->
                                    when (action) {
                                        "PAUSE" -> if (simState.isRunning) SimulationEngine.pauseSimulation() else SimulationEngine.startSimulation()
                                        "RESET" -> SimulationEngine.resetSimulation()
                                        "ADV_1" -> SimulationEngine.advanceOneMinute()
                                        "ADV_5" -> SimulationEngine.advanceFiveMinutes()
                                        "TRAFFIC" -> SimulationEngine.toggleHeavyTraffic()
                                        "WEATHER" -> SimulationEngine.toggleWeatherDisruption()
                                        "BREAKDOWN" -> SimulationEngine.toggleVehicleBreakdown()
                                        "DELAY" -> SimulationEngine.triggerDelay(value as String, 15)
                                        "DIVERSION" -> SimulationEngine.triggerRouteDiversion(value as String)
                                        "RESTORE" -> SimulationEngine.restoreNormalServices()
                                    }
                                },
                                onNavigateToProfile = { navigateTo(AppScreen.PROFILE) },
                                onNavigateToAccessibility = { navigateTo(AppScreen.ACCESSIBILITY_SETTINGS) },
                                onNavigateToNotifications = { navigateTo(AppScreen.NOTIFICATIONS_CENTER) },
                                onNavigateToHelp = { navigateTo(AppScreen.HELP_SUPPORT) }
                            )
                        }

                        AppScreen.ALERTS_CENTER -> {
                            AlertsCenterScreen(
                                currentLanguage = currentLanguage,
                                alerts = simState.alerts,
                                onBack = { navigateTo(AppScreen.HOME) }
                            )
                        }

                        AppScreen.PROFILE -> {
                            ProfileScreen(
                                currentLanguage = currentLanguage,
                                passengerName = passengerName,
                                onSave = { passengerName = it; navigateTo(AppScreen.HOME) },
                                onBack = { navigateTo(AppScreen.DEV_CONSOLE) }
                            )
                        }

                        AppScreen.ACCESSIBILITY_SETTINGS -> {
                            AccessibilitySettingsScreen(
                                currentLanguage = currentLanguage,
                                isLargeText = isLargeText,
                                avoidStairs = avoidStairs,
                                minimizeWalking = minimizeWalking,
                                reducedMotion = reducedMotion,
                                onLargeTextChange = { isLargeText = it },
                                onAvoidStairsChange = { avoidStairs = it },
                                onMinimizeWalkingChange = { minimizeWalking = it },
                                onReducedMotionChange = { reducedMotion = it },
                                onBack = { navigateTo(AppScreen.DEV_CONSOLE) }
                            )
                        }

                        AppScreen.NOTIFICATIONS_CENTER -> {
                            NotificationsCenterScreen(
                                currentLanguage = currentLanguage,
                                notifications = notifications,
                                onClear = {
                                    scope.launch {
                                        repository.clearNotifications()
                                        reloadUserData()
                                    }
                                },
                                onBack = { navigateTo(AppScreen.DEV_CONSOLE) }
                            )
                        }

                        AppScreen.HELP_SUPPORT -> {
                            HelpSupportScreen(
                                currentLanguage = currentLanguage,
                                reports = reportsList,
                                onSubmitReport = {
                                    reportLocation = "المنامة"
                                    showSupportReportDialog = true
                                },
                                onBack = { navigateTo(AppScreen.DEV_CONSOLE) }
                            )
                        }
                        else -> {
                            // Catch-all safety for preview compatibility
                        }
                    }
                }

                // --- Global Demo Mode Indicator Banner ---
                if (activeScreen != AppScreen.ONBOARDING) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 8.dp)
                            .background(Color(0xFFF77F00), RoundedCornerShape(16.dp))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (currentLanguage == "ar") "وضع العرض التجريبي ⚠️" else "Demo Sandbox Mode ⚠️",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // --- Offline Toast Banner if simulation paused ---
                if (!simState.isRunning && activeScreen != AppScreen.ONBOARDING) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 80.dp)
                            .background(Color.DarkGray.copy(alpha = 0.9f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = if (currentLanguage == "ar") "أنت غير متصل بالإنترنت. يتم عرض آخر بيانات محفوظة." else "You are offline. Showing cached local data.",
                            color = Color.White,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // --- Mock Purchase Payment Dialog ---
        if (showPurchaseDialogForProduct != null) {
            val product = showPurchaseDialogForProduct!!
            Dialog(onDismissRequest = { showPurchaseDialogForProduct = null }) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = appThemeColors.surface),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(24.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (currentLanguage == "ar") "الدفع المالي الآمن" else "Secure Payment",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = appThemeColors.primary
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (currentLanguage == "ar") "المنتج: ${product.nameAr}" else "Product: ${product.nameEn}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (currentLanguage == "ar") "السعر الإجمالي: ${product.priceBhd} د.ب" else "Price: ${product.priceBhd} BHD",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = appThemeColors.secondary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                        Divider(modifier = Modifier.padding(vertical = 12.dp))

                        Text(
                            text = if (currentLanguage == "ar") "أدخل رقم بطاقة الصراف للدفع التجريبي:" else "Enter Card Number for Sandbox Payment:",
                            fontSize = 12.sp,
                            color = appThemeColors.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = paymentCardNumber,
                            onValueChange = { paymentCardNumber = it },
                            placeholder = { Text("**** **** **** ****") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(24.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            TextButton(onClick = { showPurchaseDialogForProduct = null }) {
                                Text(if (currentLanguage == "ar") "إلغاء" else "Cancel")
                            }
                            Button(
                                onClick = {
                                    paymentProcessing = true
                                    scope.launch {
                                        delay(1500) // Mock payment gateway delays
                                        val ticket = repository.purchaseTicket(product, passengerName)
                                        repository.activateTicket(ticket.ticketId, product.validityPeriodHours)
                                        paymentProcessing = false
                                        showPurchaseDialogForProduct = null
                                        paymentCardNumber = ""
                                        reloadUserData()
                                    }
                                },
                                enabled = paymentCardNumber.length >= 8 && !paymentProcessing,
                                colors = ButtonDefaults.buttonColors(containerColor = appThemeColors.primary)
                            ) {
                                if (paymentProcessing) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                } else {
                                    Text(if (currentLanguage == "ar") "دفع وتفعيل" else "Pay & Activate")
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- Submit Support Report Dialog ---
        if (showSupportReportDialog) {
            Dialog(onDismissRequest = { showSupportReportDialog = false }) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = appThemeColors.surface),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(24.dp)
                            .fillMaxWidth()
                    ) {
                        Text(
                            text = if (currentLanguage == "ar") "إرسال تقرير وملاحظة" else "Submit Report",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = appThemeColors.primary,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (currentLanguage == "ar") "الفئة:" else "Category:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(vertical = 8.dp)
                        ) {
                            ReportCategory.values().forEach { cat ->
                                val label = when (cat) {
                                    ReportCategory.STOP_CONDITION -> if (currentLanguage == "ar") "حالة الموقف" else "Stop Condition"
                                    ReportCategory.MISSING_BUS -> if (currentLanguage == "ar") "حافلة متأخرة" else "Delayed Bus"
                                    ReportCategory.ACCESSIBILITY_ISSUE -> if (currentLanguage == "ar") "صعوبة صعود" else "Accessibility"
                                    ReportCategory.FEEDBACK -> if (currentLanguage == "ar") "ملاحظات" else "Feedback"
                                    else -> if (currentLanguage == "ar") "أخرى" else "Other"
                                }
                                FilterChip(
                                    selected = reportCategory == cat,
                                    onClick = { reportCategory = cat },
                                    label = { Text(label) },
                                    modifier = Modifier.padding(end = 8.dp)
                                )
                            }
                        }

                        Text(
                            text = if (currentLanguage == "ar") "الموقع أو الموقف:" else "Location / Stop:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedTextField(
                            value = reportLocation,
                            onValueChange = { reportLocation = it },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (currentLanguage == "ar") "تفاصيل البلاغ:" else "Details:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedTextField(
                            value = reportDescription,
                            onValueChange = { reportDescription = it },
                            minLines = 3,
                            maxLines = 5,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(24.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            TextButton(onClick = { showSupportReportDialog = false }) {
                                Text(if (currentLanguage == "ar") "إلغاء" else "Cancel")
                            }
                            Button(
                                onClick = {
                                    scope.launch {
                                        repository.submitReport(
                                            category = reportCategory,
                                            location = reportLocation,
                                            description = reportDescription,
                                            routeNum = null,
                                            stopId = null
                                        )
                                        showSupportReportDialog = false
                                        reportDescription = ""
                                        reloadUserData()
                                    }
                                },
                                enabled = reportDescription.isNotBlank() && reportLocation.isNotBlank()
                            ) {
                                Text(if (currentLanguage == "ar") "إرسال" else "Send")
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- ONBOARDING SCREEN ---
@Composable
fun OnboardingScreen(
    currentLanguage: String,
    passengerName: String,
    onNameChange: (String) -> Unit,
    onLanguageToggle: () -> Unit,
    onStart: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Language Toggle in header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(onClick = onLanguageToggle) {
                Text(
                    text = if (currentLanguage == "ar") "English" else "العربية",
                    fontWeight = FontWeight.Bold,
                    color = colors.secondary
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Large Premium Logo
        Icon(
            imageVector = Icons.Default.DirectionsBus,
            contentDescription = "Bahrain Bus Logo",
            tint = colors.primary,
            modifier = Modifier.size(100.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (currentLanguage == "ar") "حافلات البحرين" else "Bahrain Bus",
            fontSize = 32.sp,
            fontWeight = FontWeight.ExtraBold,
            color = colors.primary
        )

        Text(
            text = if (currentLanguage == "ar") "طريقك أسهل مع حافلات البحرين" else "Your journey made simple with Bahrain Bus",
            fontSize = 16.sp,
            color = colors.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp)
        )

        Spacer(modifier = Modifier.height(48.dp))

        // Graphic Sandbox card
        Card(
            colors = CardDefaults.cardColors(containerColor = colors.surface),
            border = BorderStroke(1.dp, colors.outline),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (currentLanguage == "ar") "تطبيق النقل العام التجريبي لمملكة البحرين" else "The Official Demo Transit App of Bahrain",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = colors.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (currentLanguage == "ar")
                        "يرجى تسجيل اسمك بالأسفل لإنشاء ملف ركاب وحجز تذاكر المسافات التجريبية الرقمية."
                    else
                        "Please enter your name to register a passenger profile and obtain demo boarding passes.",
                    fontSize = 12.sp,
                    color = colors.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = passengerName,
            onValueChange = onNameChange,
            label = { Text(if (currentLanguage == "ar") "اسم الراكب" else "Passenger Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = onStart,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(27.dp),
            colors = ButtonDefaults.buttonColors(containerColor = colors.primary)
        ) {
            Text(
                text = if (currentLanguage == "ar") "ابدأ رحلتك الآن" else "Start Journey Now",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// --- HOME SCREEN ---
@Composable
fun HomeScreen(
    currentLanguage: String,
    passengerName: String,
    simTime: String,
    repository: BusRepository,
    alertsCount: Int,
    onActionClick: (String) -> Unit,
    onStopSelected: (String) -> Unit,
    onLanguageToggle: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var departures by remember { mutableStateOf<List<Departure>>(emptyList()) }

    LaunchedEffect(simTime) {
        departures = repository.getDeparturesForStop("S1") // Manama terminal
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (currentLanguage == "ar") "أهلاً بك، $passengerName" else "Welcome, $passengerName",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.primary
                    )
                    Text(
                        text = if (currentLanguage == "ar") "مواقيت المحاكاة: $simTime" else "Sim Time: $simTime",
                        fontSize = 12.sp,
                        color = colors.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onLanguageToggle) {
                        Icon(Icons.Default.Language, contentDescription = "Language")
                    }
                    if (alertsCount > 0) {
                        IconButton(onClick = { onActionClick("ALERTS") }) {
                            BadgedBox(badge = { Badge { Text(alertsCount.toString()) } }) {
                                Icon(Icons.Default.Notifications, contentDescription = "Alerts")
                            }
                        }
                    }
                }
            }
        }

        // Primary Search Field trigger
        item {
            Card(
                onClick = { onActionClick("PLAN") },
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                border = BorderStroke(1.dp, colors.outline),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = colors.secondary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (currentLanguage == "ar") "إلى أين تريد الذهاب؟" else "Where to go?",
                        color = colors.onSurfaceVariant,
                        fontSize = 15.sp
                    )
                }
            }
        }

        // Quick Actions
        item {
            Column {
                Text(
                    text = if (currentLanguage == "ar") "الوصول السريع" else "Quick Actions",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onActionClick("PLAN") },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.primary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            if (currentLanguage == "ar") "تخطيط رحلة" else "Plan Journey",
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                    Button(
                        onClick = { onActionClick("ROUTES") },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.secondary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            if (currentLanguage == "ar") "الخطوط" else "Routes",
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                    Button(
                        onClick = { onActionClick("TICKETS") },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = colors.tertiary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            if (currentLanguage == "ar") "تذاكر" else "Tickets",
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Departures at Nearby stop (Manama Terminal)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, colors.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (currentLanguage == "ar") "محطة المنامة - الحافلات القادمة" else "Manama Terminal Departures",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = colors.primary
                        )
                        TextButton(onClick = { onActionClick("STOPS") }) {
                            Text(if (currentLanguage == "ar") "الكل" else "View All", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (departures.isEmpty()) {
                        Text(
                            text = if (currentLanguage == "ar") "الموقف مغلق مؤقتاً" else "Terminal closed temporarily",
                            color = Color.Red,
                            fontSize = 13.sp,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    } else {
                        departures.take(3).forEach { departure ->
                            val routeColor = Color(departure.routeColor.replace("0xFF", "FF").toLong(16))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .background(routeColor, RoundedCornerShape(8.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            departure.routeNumber,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = if (currentLanguage == "ar") departure.destinationAr else departure.destinationEn,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 13.sp
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${departure.expectedArrivalMinutes} " + (if (currentLanguage == "ar") "دقيقة" else "min"),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.secondary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = departure.statusAr,
                                        fontSize = 11.sp,
                                        color = if (departure.isRealTime) colors.secondary else Color.Gray,
                                        modifier = Modifier
                                            .background(
                                                if (departure.isRealTime) colors.secondary.copy(alpha = 0.15f) else Color.LightGray.copy(alpha = 0.2f),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Beautiful Travel Guidance Cards
        item {
            Column {
                Text(
                    text = if (currentLanguage == "ar") "معالم مخدومة بشبكة الحافلات" else "Destinations Served",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val locations = listOf(
                        Triple("مطار البحرين الدولي", "Airport Express", "الخط السريع للمطار A1 يوفر تنقل مريح وسريع."),
                        Triple("مجمع السيف", "Seef District", "تسوّق وتسوق بزيارة مجمع السيف عبر الخط X2."),
                        Triple("خليج البحرين", "Bahrain Bay", "واجهة بحرية ساحرة مخدومة بالخط X2 والخط 10.")
                    )

                    locations.forEach { (ar, en, desc) ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = colors.surface),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, colors.outline),
                            modifier = Modifier.width(220.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (currentLanguage == "ar") ar else en,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = colors.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = desc,
                                    fontSize = 11.sp,
                                    color = colors.onSurfaceVariant,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- MAP SCREEN ---
@Composable
fun MapScreen(
    currentLanguage: String,
    activeVehicles: List<SimVehicle>,
    closedStops: Set<String>,
    selectedStopId: String?,
    repository: BusRepository,
    onStopClick: (BusStop) -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var showAll by remember { mutableStateOf(true) }
    var stopsList by remember { mutableStateOf<List<BusStop>>(emptyList()) }

    LaunchedEffect(Unit) {
        stopsList = repository.getStops()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        BahrainMap(
            modifier = Modifier.fillMaxSize(),
            activeVehicles = activeVehicles,
            closedStops = closedStops,
            showAllRoutes = showAll,
            onStopSelected = onStopClick
        )

        // Float Layers Switch Column
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
                .background(colors.surface.copy(alpha = 0.9f), RoundedCornerShape(16.dp))
                .border(1.dp, colors.outline, RoundedCornerShape(16.dp))
                .padding(12.dp)
        ) {
            Text(
                text = if (currentLanguage == "ar") "طبقات الخريطة" else "Map Layers",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = colors.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = showAll, onCheckedChange = { showAll = it })
                Text(
                    text = if (currentLanguage == "ar") "جميع الخطوط" else "All Lines",
                    fontSize = 11.sp
                )
            }
            Text(
                text = if (currentLanguage == "ar") "انقر على أي موقف لمشاهدة المواعيد" else "Tap stop to view times",
                fontSize = 10.sp,
                color = colors.secondary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

// --- JOURNEY PLANNER SCREEN ---
@Composable
fun JourneyPlannerScreen(
    currentLanguage: String,
    originStopId: String,
    destStopId: String,
    onOriginChange: (String) -> Unit,
    onDestChange: (String) -> Unit,
    computedPlans: List<JourneyPlan>,
    onSearch: () -> Unit,
    onSelectPlan: (JourneyPlan) -> Unit,
    avoidStairs: Boolean,
    minimizeWalking: Boolean,
    onAvoidStairsToggle: (Boolean) -> Unit,
    onMinimizeWalkingToggle: (Boolean) -> Unit
) {
    val colors = MaterialTheme.colorScheme

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (currentLanguage == "ar") "مخطط الرحلات" else "Journey Planner",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = colors.primary
            )
        }

        // Selection Cards
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, colors.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        if (currentLanguage == "ar") "نقطة الانطلاق:" else "Origin:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 4.dp)
                    ) {
                        SeedData.stops.forEach { stop ->
                            FilterChip(
                                selected = originStopId == stop.stopId,
                                onClick = { onOriginChange(stop.stopId) },
                                label = { Text(if (currentLanguage == "ar") stop.nameAr else stop.nameEn, fontSize = 11.sp) },
                                modifier = Modifier.padding(end = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        if (currentLanguage == "ar") "الوجهة المطلوبة:" else "Destination:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 4.dp)
                    ) {
                        SeedData.stops.forEach { stop ->
                            FilterChip(
                                selected = destStopId == stop.stopId,
                                onClick = { onDestChange(stop.stopId) },
                                label = { Text(if (currentLanguage == "ar") stop.nameAr else stop.nameEn, fontSize = 11.sp) },
                                modifier = Modifier.padding(end = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Transit Filters
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, colors.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (currentLanguage == "ar") "استخدام الحافلات فقط" else "Bus Only", fontSize = 12.sp)
                        Switch(checked = avoidStairs, onCheckedChange = onAvoidStairsToggle)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (currentLanguage == "ar") "تقليل المشي قدر الإمكان" else "Minimize Walking", fontSize = 12.sp)
                        Switch(checked = minimizeWalking, onCheckedChange = onMinimizeWalkingToggle)
                    }
                }
            }
        }

        // Search Trigger Button
        item {
            Button(
                onClick = onSearch,
                enabled = originStopId != destStopId,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = colors.primary)
            ) {
                Text(
                    if (currentLanguage == "ar") "بحث عن مسارات" else "Find Routes",
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Computed Paths List
        if (computedPlans.isEmpty() && originStopId != destStopId) {
            item {
                Text(
                    text = if (currentLanguage == "ar") "انقر على زر البحث لحساب المسار الأمثل." else "Tap search to calculate optimal routes.",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            items(computedPlans) { plan ->
                Card(
                    onClick = { onSelectPlan(plan) },
                    colors = CardDefaults.cardColors(containerColor = colors.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.5.dp, colors.secondary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (currentLanguage == "ar") plan.selectionReasonAr else plan.selectionReasonEn,
                                fontWeight = FontWeight.Bold,
                                color = colors.secondary,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "${plan.totalDurationMinutes} " + (if (currentLanguage == "ar") "دقيقة" else "min"),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = colors.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Path bubbles timeline
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            plan.legs.forEachIndexed { index, leg ->
                                if (leg.type == "BUS") {
                                    val rColor = Color(leg.routeColor?.replace("0xFF", "FF")?.toLong(16) ?: 0xFF0A2540)
                                    Box(
                                        modifier = Modifier
                                            .background(rColor, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(leg.routeNumber ?: "", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Icon(Icons.Default.DirectionsWalk, contentDescription = "Walk", modifier = Modifier.size(16.dp), tint = Color.Gray)
                                }
                                if (index < plan.legs.lastIndex) {
                                    Icon(Icons.Default.ArrowForward, contentDescription = "Next", modifier = Modifier.size(12.dp).padding(horizontal = 4.dp), tint = Color.LightGray)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (currentLanguage == "ar") "المشي: ${plan.walkingDurationMinutes} د | الأجرة: ${plan.fareBhd} د.ب" else "Walk: ${plan.walkingDurationMinutes}m | Fare: ${plan.fareBhd} BHD",
                                fontSize = 11.sp,
                                color = colors.onSurfaceVariant
                            )
                            Text(
                                text = if (currentLanguage == "ar") "اضغط لبدء الرحلة 🚌" else "Tap to start ride 🚌",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- ACTIVE JOURNEY SCREEN ---
@Composable
fun ActiveJourneyScreen(
    currentLanguage: String,
    activeJourneyState: ActiveJourneyState?,
    simTime: String,
    onCancel: () -> Unit,
    onReportIssue: () -> Unit,
    onToggleReminder: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    if (activeJourneyState == null) return

    val state = activeJourneyState
    val leg = state.plan.legs.getOrNull(state.currentLegIndex) ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = if (currentLanguage == "ar") "الرحلة النشطة 🟢" else "Live Ride Active 🟢",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = colors.primary
            )
            Text(
                text = if (currentLanguage == "ar") "ساعة النظام: $simTime" else "Network Time: $simTime",
                fontSize = 12.sp,
                color = colors.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Pulse progress segment representation
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(2.dp, colors.secondary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (currentLanguage == "ar") leg.descriptionAr else leg.descriptionEn,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    LinearProgressIndicator(
                        progress = state.progressPercent,
                        color = colors.primary,
                        trackColor = colors.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                if (currentLanguage == "ar") "المحطة التالية:" else "Next Stop:",
                                fontSize = 11.sp,
                                color = colors.onSurfaceVariant
                            )
                            val nStop = SeedData.stops.find { it.stopId == state.nextStopId }
                            Text(
                                text = if (currentLanguage == "ar") nStop?.nameAr ?: "جاري الحساب" else nStop?.nameEn ?: "Calculating",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                if (currentLanguage == "ar") "الوقت المتبقي:" else "Time Left:",
                                fontSize = 11.sp,
                                color = colors.onSurfaceVariant
                            )
                            Text(
                                text = "${state.etaMinutes} " + (if (currentLanguage == "ar") "دقيقة" else "min"),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = colors.secondary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Actions
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onToggleReminder,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (state.isApproachingReminderSet) colors.tertiary else colors.secondary
                )
            ) {
                Text(
                    text = if (state.isApproachingReminderSet) {
                        if (currentLanguage == "ar") "تم تفعيل منبه الاقتراب 🔔" else "Approaching Alarm Set 🔔"
                    } else {
                        if (currentLanguage == "ar") "ذكّرني عند الاقتراب من الموقف" else "Remind me when approaching"
                    }
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onReportIssue,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                ) {
                    Text(if (currentLanguage == "ar") "إبلاغ عن مشكلة" else "Report Issue")
                }
                Button(
                    onClick = onCancel,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.primary)
                ) {
                    Text(if (currentLanguage == "ar") "إنهاء الرحلة" else "Finish Journey")
                }
            }
        }
    }
}

// --- TICKETS MARKETPLACE & WALLET ---
@Composable
fun TicketsScreen(
    currentLanguage: String,
    passengerName: String,
    repository: BusRepository,
    purchasedTickets: List<Ticket>,
    onProductSelect: (FareProduct) -> Unit,
    onTicketSelect: (String) -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var selectedTab by remember { mutableStateOf(0) } // 0: Wallet, 1: Marketplace

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = if (currentLanguage == "ar") "التذاكر والاشتراكات" else "Tickets & Passes",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = colors.primary
        )

        Spacer(modifier = Modifier.height(16.dp))

        TabRow(selectedTabIndex = selectedTab, containerColor = colors.background) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(if (currentLanguage == "ar") "محفظتي" else "My Wallet") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(if (currentLanguage == "ar") "شراء تذكرة" else "Buy Ticket") }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == 0) {
            // Wallet view
            if (purchasedTickets.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.ConfirmationNumber, contentDescription = "Empty Wallet", modifier = Modifier.size(64.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (currentLanguage == "ar") "لا توجد تذاكر نشطة حالياً" else "No active tickets found",
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                    Text(
                        text = if (currentLanguage == "ar") "تصفّح علامة التبويب المجاورة لشراء تذاكر حافلات البحرين التجريبية." else "Switch to 'Buy Ticket' tab to obtain digital demo boarding passes.",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(purchasedTickets) { ticket ->
                        Card(
                            onClick = { onTicketSelect(ticket.ticketId) },
                            colors = CardDefaults.cardColors(containerColor = colors.surface),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, colors.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = if (currentLanguage == "ar") ticket.typeAr else ticket.typeEn,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = colors.primary
                                    )
                                    Text(
                                        text = "ID: ${ticket.ticketId}",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }

                                Badge(
                                    containerColor = if (ticket.status == TicketStatus.ACTIVE) colors.secondary else Color.LightGray
                                ) {
                                    Text(
                                        text = if (ticket.status == TicketStatus.ACTIVE) {
                                            if (currentLanguage == "ar") "نشطة" else "Active"
                                        } else {
                                            if (currentLanguage == "ar") "مستخدمة" else "Used"
                                        },
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Marketplace view
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(repository.fareProducts) { product ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = colors.surface),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, colors.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (currentLanguage == "ar") product.nameAr else product.nameEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = colors.primary
                                )
                                Text(
                                    text = "${product.priceBhd} د.ب",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = colors.secondary
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (currentLanguage == "ar") product.descriptionAr else product.descriptionEn,
                                fontSize = 12.sp,
                                color = colors.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { onProductSelect(product) },
                                modifier = Modifier.align(Alignment.End),
                                colors = ButtonDefaults.buttonColors(containerColor = colors.primary)
                            ) {
                                Text(if (currentLanguage == "ar") "طلب شراء" else "Buy Now", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- TICKET DETAIL AND QR ---
@Composable
fun TicketDetailScreen(
    currentLanguage: String,
    ticketId: String,
    repository: BusRepository,
    onBack: () -> Unit,
    onScanUsed: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var ticket by remember { mutableStateOf<Ticket?>(null) }

    LaunchedEffect(ticketId) {
        ticket = repository.getTickets().find { it.ticketId == ticketId }
    }

    if (ticket == null) return
    val tk = ticket!!

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = if (currentLanguage == "ar") "تفاصيل التذكرة" else "Ticket Details",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colors.primary
            )
        }

        // Digital ticket receipt mockup
        Card(
            colors = CardDefaults.cardColors(containerColor = colors.surface),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(2.dp, colors.outline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (currentLanguage == "ar") tk.typeAr else tk.typeEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = colors.primary
                )
                Text(
                    text = "ID: ${tk.ticketId}",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Divider(modifier = Modifier.padding(vertical = 16.dp))

                // Beautiful Vector Simulated QR Code Box
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .background(Color.White)
                        .border(1.dp, Color.LightGray)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Draw custom vector representations of QR codes to make it visually realistic
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val stroke = 8f
                        drawRect(Color.Black, Offset(0f, 0f), Size(40f, 40f))
                        drawRect(Color.Black, Offset(size.width - 40f, 0f), Size(40f, 40f))
                        drawRect(Color.Black, Offset(0f, size.height - 40f), Size(40f, 40f))

                        // Draw random block matrices
                        for (i in 1..8) {
                            for (j in 1..8) {
                                if ((i * j + 3) % 2 == 0) {
                                    drawRect(
                                        color = Color.Black,
                                        topLeft = Offset(45f + i * 15f, 45f + j * 15f),
                                        size = Size(10f, 10f)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (currentLanguage == "ar") "امسح الرمز عند الصعود على متن الحافلة" else "Scan QR Code when boarding the bus",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }

        // Action Simulator
        Button(
            onClick = onScanUsed,
            enabled = tk.status == TicketStatus.ACTIVE,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = colors.secondary)
        ) {
            Text(
                if (currentLanguage == "ar") "محاكاة مسح التذكرة بالباص" else "Simulate Boarding Scan"
            )
        }
    }
}

// --- ALERTS CENTER SCREEN ---
@Composable
fun AlertsCenterScreen(
    currentLanguage: String,
    alerts: List<ServiceAlert>,
    onBack: () -> Unit
) {
    val colors = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = if (currentLanguage == "ar") "حالة الخدمة والتنبيهات" else "Service Alerts",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colors.primary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (alerts.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = "Safe", modifier = Modifier.size(64.dp), tint = Color(0xFF2D6A4F))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (currentLanguage == "ar") "جميع الخطوط تعمل بشكل طبيعي" else "All lines operating normally",
                    fontWeight = FontWeight.Bold,
                    color = colors.primary
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(alerts) { alert ->
                    val badgeColor = when (alert.severity) {
                        AlertSeverity.CRITICAL -> Color.Red
                        AlertSeverity.IMPORTANT -> Color(0xFFF77F00)
                        else -> Color.Gray
                    }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = colors.surface),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, colors.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (currentLanguage == "ar") alert.titleAr else alert.titleEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = colors.primary
                                )
                                Badge(containerColor = badgeColor) {
                                    Text(
                                        text = alert.severity.name,
                                        modifier = Modifier.padding(horizontal = 4.dp),
                                        color = Color.White,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (currentLanguage == "ar") alert.descriptionAr else alert.descriptionEn,
                                fontSize = 12.sp,
                                color = colors.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- BUS ROUTES DIRECTORY SCREEN ---
@Composable
fun RouteDirectoryScreen(
    currentLanguage: String,
    repository: BusRepository,
    onRouteClick: (String) -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var routes by remember { mutableStateOf<List<BusRoute>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        routes = repository.getRoutes()
    }

    val filteredRoutes = routes.filter {
        it.routeNumber.contains(searchQuery, ignoreCase = true) ||
                it.nameAr.contains(searchQuery, ignoreCase = true) ||
                it.nameEn.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = if (currentLanguage == "ar") "دليل الخطوط" else "Bus Routes",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = colors.primary
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(if (currentLanguage == "ar") "ابحث برقم الخط أو الوجهة..." else "Search by route number...") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(filteredRoutes) { route ->
                val rColor = Color(route.colorHex.replace("0xFF", "FF").toLong(16))
                Card(
                    onClick = { onRouteClick(route.routeNumber) },
                    colors = CardDefaults.cardColors(containerColor = colors.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, colors.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(rColor, RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(route.routeNumber, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = if (currentLanguage == "ar") route.nameAr else route.nameEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (currentLanguage == "ar") "${route.originAr} ⇄ ${route.destinationAr}" else "${route.originEn} ⇄ ${route.destinationEn}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Icon(Icons.Default.ArrowForward, contentDescription = "Go")
                    }
                }
            }
        }
    }
}

// --- ROUTE DETAIL SCREEN ---
@Composable
fun RouteDetailScreen(
    currentLanguage: String,
    routeId: String,
    repository: BusRepository,
    onBack: () -> Unit,
    onStopClick: (String) -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var route by remember { mutableStateOf<BusRoute?>(null) }
    var stopsList by remember { mutableStateOf<List<BusStop>>(emptyList()) }

    LaunchedEffect(routeId) {
        route = repository.getRouteById(routeId)
        stopsList = repository.getStops()
    }

    if (route == null) return
    val rt = route!!
    val stopIds = com.example.data.model.JsonHelper.fromJsonStringList(rt.stopsListJson)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = if (currentLanguage == "ar") "تفاصيل الخط ${rt.routeNumber}" else "Route ${rt.routeNumber}",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colors.primary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Card specs
        val rColor = Color(rt.colorHex.replace("0xFF", "FF").toLong(16))
        Card(
            colors = CardDefaults.cardColors(containerColor = colors.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(2.dp, rColor)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (currentLanguage == "ar") rt.nameAr else rt.nameEn,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = colors.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (currentLanguage == "ar") "أول رحلة: ${rt.firstService} | آخر رحلة: ${rt.lastService}" else "First: ${rt.firstService} | Last: ${rt.lastService}",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                Text(
                    text = if (currentLanguage == "ar") "وتيرة الخدمة: كل ${rt.frequencyMinutes} دقيقة" else "Frequency: Every ${rt.frequencyMinutes} mins",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (currentLanguage == "ar") "التسلسل الزمني للمواقف:" else "Stops Sequence:",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = colors.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Stop list timeline
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(stopIds) { stopId ->
                val stop = stopsList.find { it.stopId == stopId }
                if (stop != null) {
                    Card(
                        onClick = { onStopClick(stop.stopId) },
                        colors = CardDefaults.cardColors(containerColor = colors.surface),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(rColor, RoundedCornerShape(5.dp))
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    text = if (currentLanguage == "ar") stop.nameAr else stop.nameEn,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Icon(Icons.Default.ArrowForward, contentDescription = "View Stop", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

// --- BUS STOPS DIRECTORY SCREEN ---
@Composable
fun StopDirectoryScreen(
    currentLanguage: String,
    repository: BusRepository,
    onStopClick: (String) -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var stops by remember { mutableStateOf<List<BusStop>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        stops = repository.getStops()
    }

    val filteredStops = stops.filter {
        it.nameAr.contains(searchQuery, ignoreCase = true) ||
                it.nameEn.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = if (currentLanguage == "ar") "دليل ومواقع المواقف" else "Bus Stops Directory",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = colors.primary
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(if (currentLanguage == "ar") "ابحث عن الموقف بالاسم..." else "Search stop by name...") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(filteredStops) { stop ->
                Card(
                    onClick = { onStopClick(stop.stopId) },
                    colors = CardDefaults.cardColors(containerColor = colors.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, colors.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (currentLanguage == "ar") stop.nameAr else stop.nameEn,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Stop ID: ${stop.stopId}",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }

                        Icon(Icons.Default.ArrowForward, contentDescription = "Go")
                    }
                }
            }
        }
    }
}

// --- STOP DETAIL SCREEN ---
@Composable
fun StopDetailScreen(
    currentLanguage: String,
    stopId: String,
    repository: BusRepository,
    onBack: () -> Unit,
    onReportIssue: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var stop by remember { mutableStateOf<BusStop?>(null) }
    var departures by remember { mutableStateOf<List<Departure>>(emptyList()) }

    LaunchedEffect(stopId) {
        stop = repository.getStopById(stopId)
        departures = repository.getDeparturesForStop(stopId)
    }

    if (stop == null) return
    val st = stop!!

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = if (currentLanguage == "ar") st.nameAr else st.nameEn,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colors.primary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Facilities Card
        Card(
            colors = CardDefaults.cardColors(containerColor = colors.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, colors.outline)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (currentLanguage == "ar") "التجهيزات المتوفرة:" else "Amenities:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = colors.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                val amenities = mutableListOf<String>()
                if (st.hasShelter) amenities.add(if (currentLanguage == "ar") "مظلة مكيفة" else "Air-con Shelter")
                if (st.hasSeating) amenities.add(if (currentLanguage == "ar") "مقاعد استراحة" else "Seating")
                if (st.hasLighting) amenities.add(if (currentLanguage == "ar") "إضاءة ليلية" else "Lighting")
                if (st.hasWheelchairRamp) amenities.add(if (currentLanguage == "ar") "منحدر كراسي متحركة" else "Wheelchair Ramp")

                Text(amenities.joinToString(" • "), fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (currentLanguage == "ar") "الحافلات القادمة للموقف:" else "Departures Board:",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = colors.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            if (departures.isEmpty()) {
                item {
                    Text(
                        text = if (currentLanguage == "ar") "لا توجد رحلات قادمة حالياً" else "No departures scheduled",
                        color = Color.Red,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                items(departures) { departure ->
                    val routeColor = Color(departure.routeColor.replace("0xFF", "FF").toLong(16))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = colors.surface),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(routeColor, RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(departure.routeNumber, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    text = if (currentLanguage == "ar") departure.destinationAr else departure.destinationEn,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Text(
                                text = "${departure.expectedArrivalMinutes} " + (if (currentLanguage == "ar") "دقائق" else "mins"),
                                fontWeight = FontWeight.Bold,
                                color = colors.secondary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onReportIssue,
            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (currentLanguage == "ar") "الإبلاغ عن مشكلة في الموقف" else "Report Issue with Stop")
        }
    }
}

// --- PROFILE SCREEN ---
@Composable
fun ProfileScreen(
    currentLanguage: String,
    passengerName: String,
    onSave: (String) -> Unit,
    onBack: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    var nameInput by remember { mutableStateOf(passengerName) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = if (currentLanguage == "ar") "حسابي الشخصي" else "My Profile",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colors.primary
            )
        }

        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.AccountCircle, contentDescription = "Avatar", modifier = Modifier.size(100.dp), tint = colors.primary)
            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = nameInput,
                onValueChange = { nameInput = it },
                label = { Text(if (currentLanguage == "ar") "الاسم المسجل بالتذاكر" else "Ticket Name") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        Button(
            onClick = { onSave(nameInput) },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text(if (currentLanguage == "ar") "حفظ الملف" else "Save Settings")
        }
    }
}

// --- ACCESSIBILITY SETTINGS SCREEN ---
@Composable
fun AccessibilitySettingsScreen(
    currentLanguage: String,
    isLargeText: Boolean,
    avoidStairs: Boolean,
    minimizeWalking: Boolean,
    reducedMotion: Boolean,
    onLargeTextChange: (Boolean) -> Unit,
    onAvoidStairsChange: (Boolean) -> Unit,
    onMinimizeWalkingChange: (Boolean) -> Unit,
    onReducedMotionChange: (Boolean) -> Unit,
    onBack: () -> Unit
) {
    val colors = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = if (currentLanguage == "ar") "تفضيلات سهولة الوصول" else "Accessibility",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colors.primary
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = colors.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, colors.outline)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (currentLanguage == "ar") "زيادة حجم النص للمقروئية" else "Large Text Mode", fontSize = 14.sp)
                    Switch(checked = isLargeText, onCheckedChange = onLargeTextChange)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (currentLanguage == "ar") "تجنب السلالم ومناسب للكراسي" else "Step-free Paths", fontSize = 14.sp)
                    Switch(checked = avoidStairs, onCheckedChange = onAvoidStairsChange)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (currentLanguage == "ar") "تقليل مسافات المشي" else "Minimize Walking distance", fontSize = 14.sp)
                    Switch(checked = minimizeWalking, onCheckedChange = onMinimizeWalkingChange)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (currentLanguage == "ar") "تفعيل الحركة المخفضة" else "Reduced Motion", fontSize = 14.sp)
                    Switch(checked = reducedMotion, onCheckedChange = onReducedMotionChange)
                }
            }
        }
    }
}

// --- NOTIFICATIONS CENTER ---
@Composable
fun NotificationsCenterScreen(
    currentLanguage: String,
    notifications: List<AppNotification>,
    onClear: () -> Unit,
    onBack: () -> Unit
) {
    val colors = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = if (currentLanguage == "ar") "مركز الإشعارات" else "Notifications Center",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.primary
                )
            }

            TextButton(onClick = onClear) {
                Text(if (currentLanguage == "ar") "مسح الكل" else "Clear All")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (notifications.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.NotificationsOff, contentDescription = "No notifications", modifier = Modifier.size(64.dp), tint = Color.LightGray)
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (currentLanguage == "ar") "لا توجد إشعارات حالياً" else "No recent alerts",
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(notifications) { notif ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = colors.surface),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, colors.outline)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (currentLanguage == "ar") notif.titleAr else notif.titleEn,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = colors.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (currentLanguage == "ar") notif.bodyAr else notif.bodyEn,
                                fontSize = 12.sp,
                                color = colors.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- HELP AND SUPPORT ---
@Composable
fun HelpSupportScreen(
    currentLanguage: String,
    reports: List<UserReport>,
    onSubmitReport: () -> Unit,
    onBack: () -> Unit
) {
    val colors = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = if (currentLanguage == "ar") "الدعم الفني والبلاغات" else "Help & Support",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colors.primary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onSubmitReport,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (currentLanguage == "ar") "تقديم بلاغ أو ملاحظة" else "Submit Report / Feedback")
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = if (currentLanguage == "ar") "البلاغات السابقة:" else "Past Reports:",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = colors.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (reports.isEmpty()) {
            Text(
                text = if (currentLanguage == "ar") "لا توجد بلاغات مرسلة مسبقاً." else "No reports submitted.",
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(reports) { r ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = colors.surface),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, colors.outline)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = r.category.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = colors.primary
                                )
                                Text(
                                    text = if (currentLanguage == "ar") "تم الاستلام" else "RECEIVED",
                                    fontSize = 10.sp,
                                    color = colors.secondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(r.description, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// --- DEVELOPER SIMULATION CONSOLE ---
@Composable
fun DevConsoleScreen(
    currentLanguage: String,
    simState: SimulationState,
    onAction: (String, Any?) -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToAccessibility: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onNavigateToHelp: () -> Unit
) {
    val colors = MaterialTheme.colorScheme

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (currentLanguage == "ar") "لوحة المحاكاة والتحكم بالشبكة" else "Developer Simulation Console",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colors.primary
            )
        }

        // Sim controls
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, colors.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (currentLanguage == "ar") "حالة المحاكاة التلقائية:" else "Auto-Simulation status:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onAction("PAUSE", null) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (simState.isRunning) Color.Red else colors.secondary
                            )
                        ) {
                            Text(
                                if (simState.isRunning) {
                                    if (currentLanguage == "ar") "إيقاف مؤقت" else "Pause"
                                } else {
                                    if (currentLanguage == "ar") "تشغيل" else "Resume"
                                }
                            )
                        }

                        Button(
                            onClick = { onAction("RESET", null) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                        ) {
                            Text(if (currentLanguage == "ar") "إعادة ضبط" else "Reset")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onAction("ADV_1", null) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (currentLanguage == "ar") "تقديم دقيقة" else "+1 Min")
                        }

                        Button(
                            onClick = { onAction("ADV_5", null) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (currentLanguage == "ar") "تقديم ٥ دقائق" else "+5 Min")
                        }
                    }
                }
            }
        }

        // Disruption Injection
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, colors.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (currentLanguage == "ar") "أدوات تحفيز وإحداث الأعطال الفنية والازدحامات:" else "Disruptions Injectors:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = colors.primary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onAction("TRAFFIC", null) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (simState.heavyTrafficActive) colors.tertiary else colors.primary
                            )
                        ) {
                            Text(if (currentLanguage == "ar") "ازدحام مروري" else "Traffic Toggle")
                        }

                        Button(
                            onClick = { onAction("WEATHER", null) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (simState.weatherDisruptionActive) colors.tertiary else colors.primary
                            )
                        ) {
                            Text(if (currentLanguage == "ar") "طقس عاصف" else "Weather Toggle")
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onAction("BREAKDOWN", null) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (simState.brokenVehicleId != null) Color.Red else colors.primary
                            )
                        ) {
                            Text(if (currentLanguage == "ar") "عطل حافلة" else "Bus Breakdown")
                        }

                        Button(
                            onClick = { onAction("DELAY", "A1") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (currentLanguage == "ar") "تأخير الخط A1" else "Delay A1")
                        }
                    }

                    Button(
                        onClick = { onAction("RESTORE", null) },
                        colors = ButtonDefaults.buttonColors(containerColor = colors.secondary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (currentLanguage == "ar") "إلغاء كافة المشاكل وعودة الخدمة" else "Restore Services")
                    }
                }
            }
        }

        // Extra Sandbox pages links
        item {
            Column {
                Text(
                    text = if (currentLanguage == "ar") "الصفحات والتفضيلات الإضافية:" else "Other Options:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = colors.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onNavigateToProfile, modifier = Modifier.weight(1f)) {
                        Text(if (currentLanguage == "ar") "الملف الشخصي" else "Profile", fontSize = 11.sp, maxLines = 1)
                    }
                    Button(onClick = onNavigateToAccessibility, modifier = Modifier.weight(1f)) {
                        Text(if (currentLanguage == "ar") "سهولة الوصول" else "Accessibility", fontSize = 11.sp, maxLines = 1)
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onNavigateToNotifications, modifier = Modifier.weight(1f)) {
                        Text(if (currentLanguage == "ar") "الإشعارات" else "Notifications", fontSize = 11.sp, maxLines = 1)
                    }
                    Button(onClick = onNavigateToHelp, modifier = Modifier.weight(1f)) {
                        Text(if (currentLanguage == "ar") "الدعم الفني" else "Help Desk", fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
        }

        // Live Log Output
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                ) {
                    Text(
                        text = if (currentLanguage == "ar") "سجل المحاكاة المباشر:" else "Sim Live Logs:",
                        fontWeight = FontWeight.Bold,
                        color = Color.Green,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    simState.eventLogs.take(6).forEach { log ->
                        Text(
                            text = log,
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
