package com.example.data.seed

import com.example.data.model.AlertCategory
import com.example.data.model.AlertSeverity
import com.example.data.model.BusRoute
import com.example.data.model.BusStop
import com.example.data.model.RouteStatus
import com.example.data.model.ServiceAlert

object SeedData {
    val stops = listOf(
        BusStop(
            stopId = "S1",
            nameAr = "محطة المنامة للحافلات",
            nameEn = "Manama Bus Terminal",
            latitude = 26.2361,
            longitude = 50.5744,
            hasShelter = true,
            hasSeating = true,
            hasLighting = true,
            hasInformationBoard = true,
            hasWheelchairRamp = true,
            servedRoutesJson = "[\"A1\", \"10\", \"41\", \"X2\"]"
        ),
        BusStop(
            stopId = "S2",
            nameAr = "موقف باب البحرين",
            nameEn = "Bab Al Bahrain Stop",
            latitude = 26.2351,
            longitude = 50.5755,
            hasShelter = true,
            hasSeating = true,
            hasLighting = true,
            hasInformationBoard = true,
            hasWheelchairRamp = true,
            servedRoutesJson = "[\"A1\", \"10\", \"41\", \"X2\"]"
        ),
        BusStop(
            stopId = "S3",
            nameAr = "موقف جامع الفاتح - الجفير",
            nameEn = "Al Fateh Grand Mosque Stop - Juffair",
            latitude = 26.2185,
            longitude = 50.6015,
            hasShelter = true,
            hasSeating = true,
            hasLighting = true,
            hasInformationBoard = false,
            hasWheelchairRamp = true,
            servedRoutesJson = "[\"41\"]"
        ),
        BusStop(
            stopId = "S4",
            nameAr = "موقف مجمع السيف",
            nameEn = "Seef Mall Stop",
            latitude = 26.2335,
            longitude = 50.5432,
            hasShelter = true,
            hasSeating = true,
            hasLighting = true,
            hasInformationBoard = true,
            hasWheelchairRamp = true,
            servedRoutesJson = "[\"X2\"]"
        ),
        BusStop(
            stopId = "S5",
            nameAr = "موقف خليج البحرين",
            nameEn = "Bahrain Bay Stop",
            latitude = 26.2485,
            longitude = 50.5825,
            hasShelter = false,
            hasSeating = true,
            hasLighting = true,
            hasInformationBoard = false,
            hasWheelchairRamp = false,
            servedRoutesJson = "[\"10\", \"X2\"]"
        ),
        BusStop(
            stopId = "S6",
            nameAr = "محطة المحرق للحافلات",
            nameEn = "Muharraq Bus Terminal",
            latitude = 26.2492,
            longitude = 50.6122,
            hasShelter = true,
            hasSeating = true,
            hasLighting = true,
            hasInformationBoard = true,
            hasWheelchairRamp = true,
            servedRoutesJson = "[\"10\"]"
        ),
        BusStop(
            stopId = "S7",
            nameAr = "مطار البحرين الدولي",
            nameEn = "Bahrain International Airport",
            latitude = 26.2708,
            longitude = 50.6356,
            hasShelter = true,
            hasSeating = true,
            hasLighting = true,
            hasInformationBoard = true,
            hasWheelchairRamp = true,
            servedRoutesJson = "[\"A1\"]"
        ),
        BusStop(
            stopId = "S8",
            nameAr = "موقف سوق المحرق",
            nameEn = "Souq Al Muharraq Stop",
            latitude = 26.2512,
            longitude = 50.6151,
            hasShelter = true,
            hasSeating = false,
            hasLighting = true,
            hasInformationBoard = false,
            hasWheelchairRamp = true,
            servedRoutesJson = "[\"A1\", \"10\"]"
        ),
        BusStop(
            stopId = "S9",
            nameAr = "محطة مدينة عيسى للحافلات",
            nameEn = "Isa Town Bus Terminal",
            latitude = 26.1738,
            longitude = 50.5482,
            hasShelter = true,
            hasSeating = true,
            hasLighting = true,
            hasInformationBoard = true,
            hasWheelchairRamp = true,
            servedRoutesJson = "[\"41\", \"18\"]"
        ),
        BusStop(
            stopId = "S10",
            nameAr = "موقف الرفاع الشرقي",
            nameEn = "East Riffa Stop",
            latitude = 26.1285,
            longitude = 50.5711,
            hasShelter = true,
            hasSeating = true,
            hasLighting = false,
            hasInformationBoard = false,
            hasWheelchairRamp = true,
            servedRoutesJson = "[\"18\"]"
        ),
        BusStop(
            stopId = "S11",
            nameAr = "موقف الرفاع الغربي",
            nameEn = "West Riffa Stop",
            latitude = 26.1182,
            longitude = 50.5515,
            hasShelter = false,
            hasSeating = true,
            hasLighting = true,
            hasInformationBoard = false,
            hasWheelchairRamp = false,
            servedRoutesJson = "[\"18\"]"
        ),
        BusStop(
            stopId = "S12",
            nameAr = "موقف سترة",
            nameEn = "Sitra Stop",
            latitude = 26.1555,
            longitude = 50.6185,
            hasShelter = true,
            hasSeating = true,
            hasLighting = true,
            hasInformationBoard = true,
            hasWheelchairRamp = true,
            servedRoutesJson = "[\"18\"]"
        )
    )

    val routes = listOf(
        BusRoute(
            routeNumber = "A1",
            nameAr = "الخط السريع للمطار",
            nameEn = "Airport Express Line",
            colorHex = "0xFFE76F51", // Muted Coral
            originAr = "مطار البحرين الدولي",
            originEn = "Bahrain International Airport",
            destinationAr = "محطة المنامة للحافلات",
            destinationEn = "Manama Bus Terminal",
            status = RouteStatus.NORMAL,
            firstService = "05:00",
            lastService = "23:30",
            frequencyMinutes = 20,
            isWheelchairAccessible = true,
            stopsListJson = "[\"S7\", \"S8\", \"S2\", \"S1\"]"
        ),
        BusRoute(
            routeNumber = "10",
            nameAr = "خط المنامة - المحرق الدائري",
            nameEn = "Manama - Muharraq Circular",
            colorHex = "0xFF0A2540", // Deep Marine Blue
            originAr = "محطة المنامة للحافلات",
            originEn = "Manama Bus Terminal",
            destinationAr = "محطة المحرق للحافلات",
            destinationEn = "Muharraq Bus Terminal",
            status = RouteStatus.NORMAL,
            firstService = "05:15",
            lastService = "23:00",
            frequencyMinutes = 15,
            isWheelchairAccessible = true,
            stopsListJson = "[\"S1\", \"S2\", \"S5\", \"S8\", \"S6\"]"
        ),
        BusRoute(
            routeNumber = "41",
            nameAr = "خط المنامة - مدينة عيسى",
            nameEn = "Manama - Isa Town",
            colorHex = "0xFF00A3A6", // Gulf Turquoise
            originAr = "محطة المنامة للحافلات",
            originEn = "Manama Bus Terminal",
            destinationAr = "محطة مدينة عيسى للحافلات",
            destinationEn = "Isa Town Bus Terminal",
            status = RouteStatus.DELAYED,
            firstService = "06:00",
            lastService = "22:30",
            frequencyMinutes = 30,
            isWheelchairAccessible = true,
            stopsListJson = "[\"S1\", \"S2\", \"S3\", \"S9\"]"
        ),
        BusRoute(
            routeNumber = "X2",
            nameAr = "خط السيف - خليج البحرين السريع",
            nameEn = "Seef - Bahrain Bay Shuttle",
            colorHex = "0xFF2D6A4F", // Date-palm Green
            originAr = "موقف مجمع السيف",
            originEn = "Seef Mall Stop",
            destinationAr = "موقف خليج البحرين",
            destinationEn = "Bahrain Bay Stop",
            status = RouteStatus.NORMAL,
            firstService = "06:30",
            lastService = "22:00",
            frequencyMinutes = 25,
            isWheelchairAccessible = false,
            stopsListJson = "[\"S4\", \"S1\", \"S2\", \"S5\"]"
        ),
        BusRoute(
            routeNumber = "18",
            nameAr = "خط مدينة عيسى - الرفاع - سترة",
            nameEn = "Isa Town - Riffa - Sitra",
            colorHex = "0xFF8338EC", // Deep Violet
            originAr = "محطة مدينة عيسى للحافلات",
            originEn = "Isa Town Bus Terminal",
            destinationAr = "موقف سترة",
            destinationEn = "Sitra Stop",
            status = RouteStatus.NORMAL,
            firstService = "06:00",
            lastService = "21:30",
            frequencyMinutes = 45,
            isWheelchairAccessible = true,
            stopsListJson = "[\"S9\", \"S11\", \"S10\", \"S12\"]"
        )
    )

    val alerts = listOf(
        ServiceAlert(
            alertId = "A_AL_1",
            titleAr = "تأخير في الخط السريع للمطار (A1)",
            titleEn = "Airport Express A1 Delays",
            descriptionAr = "تأخير يصل إلى ١٥ دقيقة على الخط السريع للمطار بسبب الازدحام المروري الكثيف على جسر الشيخ عيسى بن سلمان.",
            descriptionEn = "Delays up to 15 minutes on Route A1 due to heavy traffic congestion on Sh. Isa bin Salman Bridge.",
            category = AlertCategory.DELAY,
            severity = AlertSeverity.WARNING,
            affectedRoutesJson = "[\"A1\"]",
            affectedStopsJson = "[\"S7\", \"S8\"]",
            startTime = System.currentTimeMillis() - 1200000,
            expectedEndTime = System.currentTimeMillis() + 7200000,
            isRead = false,
            lastUpdated = System.currentTimeMillis()
        ),
        ServiceAlert(
            alertId = "A_AL_2",
            titleAr = "أعمال طرق مؤقتة بالقرب من مجمع السيف",
            titleEn = "Temporary Roadworks Near Seef Mall",
            descriptionAr = "تم تحويل مسار الخط X2 جزئياً ليتجاوز الشارع الخلفي المغلق، ولا يوجد إلغاء لأي مواقف حالية.",
            descriptionEn = "Route X2 is slightly detoured due to back street closure near Seef Mall. No stops are currently skipped.",
            category = AlertCategory.ROADWORKS,
            severity = AlertSeverity.INFO,
            affectedRoutesJson = "[\"X2\"]",
            affectedStopsJson = "[\"S4\"]",
            startTime = System.currentTimeMillis() - 3600000,
            expectedEndTime = System.currentTimeMillis() + 86400000,
            isRead = false,
            lastUpdated = System.currentTimeMillis()
        ),
        ServiceAlert(
            alertId = "A_AL_3",
            titleAr = "تعديل مؤقت على خط مدينة عيسى 41",
            titleEn = "Schedule modification on Route 41",
            descriptionAr = "نظراً لأعمال صيانة الشوارع، يتم دمج رحلات هذا الخط لتغادر كل ٣٥ دقيقة مؤقتاً.",
            descriptionEn = "Due to street maintenance, departures are adjusted to run every 35 minutes temporarily.",
            category = AlertCategory.TEMP_CHANGE,
            severity = AlertSeverity.IMPORTANT,
            affectedRoutesJson = "[\"41\"]",
            affectedStopsJson = "[\"S3\", \"S9\"]",
            startTime = System.currentTimeMillis() - 7200000,
            expectedEndTime = System.currentTimeMillis() + 172800000,
            isRead = false,
            lastUpdated = System.currentTimeMillis()
        )
    )
}
