package com.example.data.simulation

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.model.AlertCategory
import com.example.data.model.AlertSeverity
import com.example.data.model.BusRoute
import com.example.data.model.BusStop
import com.example.data.model.RouteStatus
import com.example.data.model.ServiceAlert
import com.example.data.seed.SeedData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

data class SimVehicle(
    val vehicleId: String,
    val routeNumber: String,
    val currentStopId: String,
    val nextStopId: String,
    val latitude: Double,
    val longitude: Double,
    val delayMinutes: Int,
    val progressPercent: Float, // 0.0 to 1.0 between currentStop and nextStop
    val statusTextAr: String,
    val statusTextEn: String
)

data class SimulationState(
    val simTime: String = "08:00 AM",
    val simTimeMillis: Long = 0,
    val isRunning: Boolean = true,
    val vehicles: List<SimVehicle> = emptyList(),
    val closedStops: Set<String> = emptySet(),
    val heavyTrafficActive: Boolean = false,
    val brokenVehicleId: String? = null,
    val weatherDisruptionActive: Boolean = false,
    val alerts: List<ServiceAlert> = SeedData.alerts,
    val eventLogs: List<String> = listOf("بدء تشغيل نظام حافلات البحرين")
)

object SimulationEngine {
    private val _state = MutableStateFlow(SimulationState())
    val state: StateFlow<SimulationState> = _state.asStateFlow()

    private var simJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    private val calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 8)
        set(Calendar.MINUTE, 0)
    }

    private var dbInstance: AppDatabase? = null

    fun initialize(context: Context) {
        dbInstance = AppDatabase.getDatabase(context)
        // Seed database if empty in a background coroutine
        scope.launch {
            val dao = dbInstance?.busDao()
            val existingRoutes = dao?.getAllRoutes()
            if (existingRoutes.isNullOrEmpty()) {
                dao?.insertRoutes(SeedData.routes)
                dao?.insertStops(SeedData.stops)
                dao?.insertAlerts(SeedData.alerts)
            }
            initVehicles()
            startSimulation()
        }
    }

    private fun initVehicles() {
        val initialVehicles = mutableListOf<SimVehicle>()
        for (route in SeedData.routes) {
            val stopsList = com.example.data.model.JsonHelper.fromJsonStringList(route.stopsListJson)
            if (stopsList.size >= 2) {
                val s1 = SeedData.stops.find { it.stopId == stopsList[0] }
                val s2 = SeedData.stops.find { it.stopId == stopsList[1] }
                if (s1 != null && s2 != null) {
                    initialVehicles.add(
                        SimVehicle(
                            vehicleId = "V_${route.routeNumber}_1",
                            routeNumber = route.routeNumber,
                            currentStopId = s1.stopId,
                            nextStopId = s2.stopId,
                            latitude = s1.latitude,
                            longitude = s1.longitude,
                            delayMinutes = if (route.status == RouteStatus.DELAYED) 12 else 0,
                            progressPercent = 0.0f,
                            statusTextAr = "متحركة",
                            statusTextEn = "In Transit"
                        )
                    )
                }
            }
        }
        val currentMillis = calendar.timeInMillis
        val sdf = SimpleDateFormat("hh:mm a", Locale("ar"))
        _state.value = SimulationState(
            simTime = sdf.format(calendar.time),
            simTimeMillis = currentMillis,
            vehicles = initialVehicles
        )
    }

    fun startSimulation() {
        simJob?.cancel()
        _state.value = _state.value.copy(isRunning = true)
        logEvent("تم تفعيل المحاكاة التلقائية - دقيقة محاكاة كل ١.٥ ثانية", "Auto-simulation active - 1 min sim per 1.5s")
        simJob = scope.launch {
            while (true) {
                delay(1500) // 1.5s = 1 simulated minute
                advanceOneMinuteInternal()
            }
        }
    }

    fun pauseSimulation() {
        simJob?.cancel()
        _state.value = _state.value.copy(isRunning = false)
        logEvent("تم إيقاف المحاكاة مؤقتاً", "Simulation paused")
    }

    fun resetSimulation() {
        pauseSimulation()
        calendar.set(Calendar.HOUR_OF_DAY, 8)
        calendar.set(Calendar.MINUTE, 0)
        initVehicles()
        _state.value = _state.value.copy(
            closedStops = emptySet(),
            heavyTrafficActive = false,
            brokenVehicleId = null,
            weatherDisruptionActive = false,
            alerts = SeedData.alerts,
            eventLogs = listOf("تم إعادة ضبط المحاكاة ونظام الحافلات")
        )
        // Also reload SeedData to database
        scope.launch {
            val dao = dbInstance?.busDao()
            dao?.insertRoutes(SeedData.routes)
            dao?.insertStops(SeedData.stops)
            dao?.insertAlerts(SeedData.alerts)
        }
        startSimulation()
    }

    fun advanceOneMinute() {
        scope.launch {
            advanceOneMinuteInternal()
        }
    }

    fun advanceFiveMinutes() {
        scope.launch {
            for (i in 1..5) {
                advanceOneMinuteInternal()
            }
        }
    }

    private suspend fun advanceOneMinuteInternal() {
        calendar.add(Calendar.MINUTE, 1)
        val sdf = SimpleDateFormat("hh:mm a", Locale("ar"))
        val timeStr = sdf.format(calendar.time)

        // Move all vehicles forward
        val updatedVehicles = _state.value.vehicles.map { vehicle ->
            // If this vehicle is currently simulated broken down, don't move it
            if (vehicle.vehicleId == _state.value.brokenVehicleId) {
                return@map vehicle.copy(
                    statusTextAr = "عطل فني - متوقفة",
                    statusTextEn = "Technical Breakdown - Stopped"
                )
            }

            var progress = vehicle.progressPercent + 0.15f // Moves 15% of segment per minute
            // Traffic makes movement slower
            if (_state.value.heavyTrafficActive) {
                progress -= 0.07f
            }
            if (_state.value.weatherDisruptionActive) {
                progress -= 0.04f
            }

            var currentStopId = vehicle.currentStopId
            var nextStopId = vehicle.nextStopId
            var finalProgress = progress

            val route = SeedData.routes.find { it.routeNumber == vehicle.routeNumber }
            val stopsList = com.example.data.model.JsonHelper.fromJsonStringList(route?.stopsListJson ?: "[]")

            if (progress >= 1.0f) {
                // Advance to next stop
                val nextIdx = stopsList.indexOf(nextStopId)
                if (nextIdx != -1 && nextIdx < stopsList.size - 1) {
                    currentStopId = nextStopId
                    nextStopId = stopsList[nextIdx + 1]
                    finalProgress = 0.0f
                } else {
                    // Loop back to start (Inbound/Outbound shuttle loop)
                    currentStopId = stopsList.last()
                    nextStopId = stopsList.first()
                    finalProgress = 0.0f
                }
                logEvent(
                    "الحافلة ${vehicle.routeNumber} وصلت إلى ${SeedData.stops.find { it.stopId == currentStopId }?.nameAr}",
                    "Bus ${vehicle.routeNumber} arrived at ${SeedData.stops.find { it.stopId == currentStopId }?.nameEn}"
                )
            }

            // Interpolate position
            val stop1Obj = SeedData.stops.find { it.stopId == currentStopId }
            val stop2Obj = SeedData.stops.find { it.stopId == nextStopId }
            val lat: Double
            val lng: Double

            if (stop1Obj != null && stop2Obj != null) {
                lat = stop1Obj.latitude + (stop2Obj.latitude - stop1Obj.latitude) * finalProgress
                lng = stop1Obj.longitude + (stop2Obj.longitude - stop1Obj.longitude) * finalProgress
            } else {
                lat = stop1Obj?.latitude ?: 26.2361
                lng = stop1Obj?.longitude ?: 50.5744
            }

            vehicle.copy(
                currentStopId = currentStopId,
                nextStopId = nextStopId,
                latitude = lat,
                longitude = lng,
                progressPercent = finalProgress,
                statusTextAr = if (_state.value.heavyTrafficActive) "مزدحمة" else "تعمل بشكل طبيعي",
                statusTextEn = if (_state.value.heavyTrafficActive) "Delayed in traffic" else "On schedule"
            )
        }

        _state.value = _state.value.copy(
            simTime = timeStr,
            simTimeMillis = calendar.timeInMillis,
            vehicles = updatedVehicles
        )
    }

    // --- Disruptions Toggles ---

    fun triggerDelay(routeNumber: String, delayMin: Int) {
        scope.launch {
            val route = SeedData.routes.find { it.routeNumber == routeNumber } ?: return@launch
            val alertId = "AL_DL_" + UUID.randomUUID().toString().take(4)
            val alert = ServiceAlert(
                alertId = alertId,
                titleAr = "تأخير في الخط $routeNumber",
                titleEn = "Delay on Route $routeNumber",
                descriptionAr = "تأخير غير متوقع بمعدل $delayMin دقيقة للرحلات المتجهة إلى ${route.destinationAr}.",
                descriptionEn = "Unexpected delay of $delayMin mins affecting journeys towards ${route.destinationEn}.",
                category = AlertCategory.DELAY,
                severity = AlertSeverity.IMPORTANT,
                affectedRoutesJson = "[\"$routeNumber\"]",
                affectedStopsJson = route.stopsListJson,
                startTime = System.currentTimeMillis(),
                expectedEndTime = System.currentTimeMillis() + 3600000,
                isRead = false,
                lastUpdated = System.currentTimeMillis()
            )

            val updatedAlerts = _state.value.alerts + alert
            _state.value = _state.value.copy(alerts = updatedAlerts)

            dbInstance?.busDao()?.insertAlerts(listOf(alert))
            logEvent("تم تفعيل تأخير $delayMin د على خط $routeNumber", "Activated $delayMin min delay on route $routeNumber")
        }
    }

    fun triggerRouteDiversion(routeNumber: String) {
        scope.launch {
            val route = SeedData.routes.find { it.routeNumber == routeNumber } ?: return@launch
            val alertId = "AL_DV_" + UUID.randomUUID().toString().take(4)
            val alert = ServiceAlert(
                alertId = alertId,
                titleAr = "تحويل مسار الخط $routeNumber",
                titleEn = "Detour on Route $routeNumber",
                descriptionAr = "تم إجراء تحويل مسار مؤقت للخط $routeNumber للالتفاف حول الشوارع المغلقة لأعمال الرصف.",
                descriptionEn = "Temporary detour in place for route $routeNumber to bypass road paving closures.",
                category = AlertCategory.DIVERSION,
                severity = AlertSeverity.WARNING,
                affectedRoutesJson = "[\"$routeNumber\"]",
                affectedStopsJson = "[]",
                startTime = System.currentTimeMillis(),
                expectedEndTime = System.currentTimeMillis() + 86400000,
                isRead = false,
                lastUpdated = System.currentTimeMillis()
            )

            val updatedAlerts = _state.value.alerts + alert
            _state.value = _state.value.copy(alerts = updatedAlerts)

            dbInstance?.busDao()?.insertAlerts(listOf(alert))
            logEvent("تم تفعيل تحويل مسار الخط $routeNumber", "Detoured route $routeNumber")
        }
    }

    fun toggleCloseStop(stopId: String) {
        val currentClosed = _state.value.closedStops.toMutableSet()
        val stop = SeedData.stops.find { it.stopId == stopId } ?: return
        val isClosing = !currentClosed.contains(stopId)

        if (isClosing) {
            currentClosed.add(stopId)
            scope.launch {
                val alert = ServiceAlert(
                    alertId = "AL_ST_CL_$stopId",
                    titleAr = "إغلاق موقف ${stop.nameAr}",
                    titleEn = "Stop Closed: ${stop.nameEn}",
                    descriptionAr = "موقف الحافلة ${stop.nameAr} مغلق مؤقتاً لأعمال الصيانة والترقية.",
                    descriptionEn = "Bus stop ${stop.nameEn} is temporarily closed for platform upgrade maintenance.",
                    category = AlertCategory.STOP_CLOSURE,
                    severity = AlertSeverity.CRITICAL,
                    affectedRoutesJson = stop.servedRoutesJson,
                    affectedStopsJson = "[\"$stopId\"]",
                    startTime = System.currentTimeMillis(),
                    expectedEndTime = System.currentTimeMillis() + 43200000,
                    isRead = false,
                    lastUpdated = System.currentTimeMillis()
                )
                val updatedAlerts = _state.value.alerts + alert
                _state.value = _state.value.copy(closedStops = currentClosed, alerts = updatedAlerts)
                dbInstance?.busDao()?.insertAlerts(listOf(alert))
                logEvent("تم إغلاق موقف الحافلات ${stop.nameAr}", "Closed bus stop ${stop.nameEn}")
            }
        } else {
            currentClosed.remove(stopId)
            val updatedAlerts = _state.value.alerts.filter { it.alertId != "AL_ST_CL_$stopId" }
            _state.value = _state.value.copy(closedStops = currentClosed, alerts = updatedAlerts)
            logEvent("تم إعادة فتح موقف الحافلات ${stop.nameAr}", "Reopened bus stop ${stop.nameEn}")
        }
    }

    fun toggleHeavyTraffic() {
        val active = !_state.value.heavyTrafficActive
        _state.value = _state.value.copy(heavyTrafficActive = active)
        if (active) {
            logEvent("تنبيه: تم تشغيل محاكاة الازدحام المروري الكثيف في المنامة والمنطقة الدبلوماسية", "Warning: Heavy traffic simulation active in Manama.")
        } else {
            logEvent("تم تخفيف الازدحام المروري وعودة حركة الحافلات لسرعتها الطبيعية", "Traffic congestion cleared, buses back to normal speeds.")
        }
    }

    fun toggleVehicleBreakdown() {
        val currentBroken = _state.value.brokenVehicleId
        if (currentBroken == null) {
            val target = _state.value.vehicles.firstOrNull()?.vehicleId
            _state.value = _state.value.copy(brokenVehicleId = target)
            if (target != null) {
                logEvent("عطل طارئ: تعطل المحرك في الحافلة $target وتوقفها للخدمة والصيانة", "Emergency breakdown: Engine issue on $target. Out of service.")
            }
        } else {
            _state.value = _state.value.copy(brokenVehicleId = null)
            logEvent("تم إصلاح الحافلة المتعطلة وإعادتها للخدمة في الشبكة", "Broken bus repaired and restored to public network service.")
        }
    }

    fun toggleWeatherDisruption() {
        val active = !_state.value.weatherDisruptionActive
        _state.value = _state.value.copy(weatherDisruptionActive = active)
        if (active) {
            logEvent("تأثير الطقس: رياح شمالية قوية وأمطار خفيفة تؤثر على الرؤية وتبطئ الرحلات", "Weather update: High north winds and light rain affecting visibility and speeds.")
        } else {
            logEvent("تحسن الأحوال الجوية واستقرار حركة النقل العام بالكامل", "Weather stabilized, transport services operating smoothly.")
        }
    }

    fun restoreNormalServices() {
        _state.value = _state.value.copy(
            closedStops = emptySet(),
            heavyTrafficActive = false,
            brokenVehicleId = null,
            weatherDisruptionActive = false,
            alerts = emptyList()
        )
        logEvent("تم إلغاء كافة التعليقات وإعادة تشغيل شبكة الحافلات كلياً بشكل طبيعي", "All disruptions cleared. Full transport network service normalized.")
    }

    private fun logEvent(ar: String, en: String) {
        val sdf = SimpleDateFormat("hh:mm a", Locale("ar"))
        val timeLabel = sdf.format(Date())
        val updatedLogs = listOf("[$timeLabel] $ar") + _state.value.eventLogs
        _state.value = _state.value.copy(eventLogs = updatedLogs.take(30))
    }
}
