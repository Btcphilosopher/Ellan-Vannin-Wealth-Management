package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bahrain Modernist Color Palette
val BahrainMarineBlue = Color(0xFF0A2540)   // Deep marine blue (Primary branding)
val BahrainTurquoise = Color(0xFF00A3A6)    // Gulf turquoise (Active state/Secondary accent)
val BahrainLimestone = Color(0xFFF6F4ED)    // Warm Limestone (App scaffold background)
val BahrainPearlWhite = Color(0xFFFDFDFD)   // Pearl White (Card/Surface background)
val BahrainSoftSand = Color(0xFFEDE8DE)     // Soft Sand (Borders/Dividers)
val BahrainGraphite = Color(0xFF22252A)     // Dark Graphite (High contrast text)
val BahrainMutedCoral = Color(0xFFE76F51)   // Muted Coral (Highlights)
val BahrainPalmGreen = Color(0xFF2D6A4F)    // Date-palm Green (Success/Safe states)
val BahrainWarningRed = Color(0xFFD90429)   // Warning Red (Disruption/Cancel)
val BahrainDisruptionAmber = Color(0xFFF77F00) // Disruption Amber (Delay/Caution)

// Dark Mode Palette
val DarkBg = Color(0xFF121417)
val DarkSurface = Color(0xFF1E2126)
val DarkBorder = Color(0xFF2E333B)
val DarkText = Color(0xFFE3E6EB)
val DarkPrimary = Color(0xFF4FA3F7)
val DarkSecondary = Color(0xFF4FD1D9)
