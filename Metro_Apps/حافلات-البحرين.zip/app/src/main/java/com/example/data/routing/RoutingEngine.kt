package com.example.data.routing

import com.example.data.model.BusRoute
import com.example.data.model.BusStop
import com.example.data.model.JourneyLeg
import com.example.data.model.JourneyPlan
import com.example.data.seed.SeedData
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object RoutingEngine {

    // Simple geographical distance in meters
    fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
        val r = 6371000 // Earth's radius in meters
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return (r * c).toInt()
    }

    // Helper to get stop by ID
    private fun getStop(stopId: String): BusStop? {
        return SeedData.stops.find { it.stopId == stopId }
    }

    /**
     * Solves paths between two points using a state space search (BFS) over routes and stops.
     * Takes transfer penalties, walking to/from terminals, and transit travel times into account.
     */
    fun planJourney(
        startLat: Double,
        startLng: Double,
        destLat: Double,
        destLng: Double,
        useBusOnly: Boolean = false,
        minimizeWalking: Boolean = false,
        minimizeTransfers: Boolean = false
    ): List<JourneyPlan> {
        val resultPlans = mutableListOf<JourneyPlan>()

        // 1. Find nearest stops to origin and destination
        val originStops = SeedData.stops.map { stop ->
            stop to calculateDistance(startLat, startLng, stop.latitude, stop.longitude)
        }.sortedBy { it.second }.take(if (minimizeWalking) 2 else 3)

        val destinationStops = SeedData.stops.map { stop ->
            stop to calculateDistance(destLat, destLng, stop.latitude, stop.longitude)
        }.sortedBy { it.second }.take(if (minimizeWalking) 2 else 3)

        // 2. Search for routes between stops
        for ((startStop, startWalkDist) in originStops) {
            for ((destStop, destWalkDist) in destinationStops) {
                if (startStop.stopId == destStop.stopId) continue

                // Find transit paths between startStop and destStop
                val paths = findTransitPaths(startStop.stopId, destStop.stopId)
                for (path in paths) {
                    val legs = mutableListOf<JourneyLeg>()

                    // Initial walk leg (if distance > 20 meters)
                    val startWalkMinutes = (startWalkDist / 80.0).toInt().coerceAtLeast(1) // 80m/min walking
                    if (startWalkDist > 30 && !useBusOnly) {
                        legs.add(
                            JourneyLeg(
                                type = "WALK",
                                routeNumber = null,
                                routeColor = null,
                                durationMinutes = startWalkMinutes,
                                distanceMeters = startWalkDist,
                                startStopId = null,
                                startStopNameAr = "موقعك الحالي",
                                startStopNameEn = "Current Location",
                                endStopId = startStop.stopId,
                                endStopNameAr = startStop.nameAr,
                                endStopNameEn = startStop.nameEn,
                                descriptionAr = "اسلك طريق المشاة إلى ${startStop.nameAr}",
                                descriptionEn = "Walk to ${startStop.nameEn}",
                                points = generatePathPoints(startLat, startLng, startStop.latitude, startStop.longitude)
                            )
                        )
                    }

                    // Transit legs
                    var lastStopId = startStop.stopId
                    var totalTransitDuration = 0
                    var totalTransferCount = path.size - 1

                    for (i in path.indices) {
                        val transitSegment = path[i]
                        val route = SeedData.routes.find { it.routeNumber == transitSegment.routeNumber } ?: continue
                        val sStop = getStop(transitSegment.fromStopId) ?: continue
                        val eStop = getStop(transitSegment.toStopId) ?: continue

                        // Calculate stop index differences to estimate stop count and duration
                        val stopsList = com.example.data.model.JsonHelper.fromJsonStringList(route.stopsListJson)
                        val fromIndex = stopsList.indexOf(transitSegment.fromStopId)
                        val toIndex = stopsList.indexOf(transitSegment.toStopId)
                        val stopCount = if (fromIndex != -1 && toIndex != -1) Math.abs(toIndex - fromIndex) else 1
                        
                        val transitDuration = stopCount * 6 // average 6 minutes per stop

                        val busLegPoints = mutableListOf<Pair<Double, Double>>()
                        if (fromIndex != -1 && toIndex != -1) {
                            val range = if (fromIndex < toIndex) fromIndex..toIndex else fromIndex downTo toIndex
                            for (idx in range) {
                                val st = getStop(stopsList[idx])
                                if (st != null) {
                                    busLegPoints.add(Pair(st.latitude, st.longitude))
                                }
                            }
                        }

                        legs.add(
                            JourneyLeg(
                                type = "BUS",
                                routeNumber = route.routeNumber,
                                routeColor = route.colorHex,
                                durationMinutes = transitDuration,
                                distanceMeters = stopCount * 3000, // Estimate 3km per stop in Bahrain
                                startStopId = transitSegment.fromStopId,
                                startStopNameAr = sStop.nameAr,
                                startStopNameEn = sStop.nameEn,
                                endStopId = transitSegment.toStopId,
                                endStopNameAr = eStop.nameAr,
                                endStopNameEn = eStop.nameEn,
                                descriptionAr = "اركَب الحافلة ${route.routeNumber} باتجاه ${route.destinationAr}",
                                descriptionEn = "Board Bus ${route.routeNumber} towards ${route.destinationEn}",
                                stopCount = stopCount,
                                points = busLegPoints
                            )
                        )
                        totalTransitDuration += transitDuration
                        lastStopId = transitSegment.toStopId

                        // Add walk for transfer if there is a next transit leg and the stop IDs differ
                        if (i < path.size - 1) {
                            val nextSegment = path[i + 1]
                            if (transitSegment.toStopId != nextSegment.fromStopId) {
                                val sTransfer = getStop(transitSegment.toStopId) ?: continue
                                val eTransfer = getStop(nextSegment.fromStopId) ?: continue
                                val transferDist = calculateDistance(sTransfer.latitude, sTransfer.longitude, eTransfer.latitude, eTransfer.longitude)
                                val transferWalkMinutes = (transferDist / 80.0).toInt().coerceAtLeast(1)

                                legs.add(
                                    JourneyLeg(
                                        type = "WALK",
                                        routeNumber = null,
                                        routeColor = null,
                                        durationMinutes = transferWalkMinutes,
                                        distanceMeters = transferDist,
                                        startStopId = transitSegment.toStopId,
                                        startStopNameAr = sTransfer.nameAr,
                                        startStopNameEn = sTransfer.nameEn,
                                        endStopId = nextSegment.fromStopId,
                                        endStopNameAr = eTransfer.nameAr,
                                        endStopNameEn = eTransfer.nameEn,
                                        descriptionAr = "انتقِل سيراً على الأقدام للتبديل إلى ${eTransfer.nameAr}",
                                        descriptionEn = "Walk to transfer to ${eTransfer.nameEn}",
                                        points = generatePathPoints(sTransfer.latitude, sTransfer.longitude, eTransfer.latitude, eTransfer.longitude)
                                    )
                                )
                                totalTransitDuration += transferWalkMinutes
                            }
                        }
                    }

                    // Final walk leg (if distance > 20 meters)
                    val finalWalkMinutes = (destWalkDist / 80.0).toInt().coerceAtLeast(1)
                    if (destWalkDist > 30 && !useBusOnly) {
                        legs.add(
                            JourneyLeg(
                                type = "WALK",
                                routeNumber = null,
                                routeColor = null,
                                durationMinutes = finalWalkMinutes,
                                distanceMeters = destWalkDist,
                                startStopId = destStop.stopId,
                                startStopNameAr = destStop.nameAr,
                                startStopNameEn = destStop.nameEn,
                                endStopId = null,
                                endStopNameAr = "وجهتك",
                                endStopNameEn = "Your Destination",
                                descriptionAr = "امشِ مسافة ${destWalkDist}م للوصول إلى وجهتك",
                                descriptionEn = "Walk ${destWalkDist}m to your destination",
                                points = generatePathPoints(destStop.latitude, destStop.longitude, destLat, destLng)
                            )
                        )
                    }

                    // Complete plan calculations
                    val totalDuration = legs.sumOf { it.durationMinutes }
                    val walkingDuration = legs.filter { it.type == "WALK" }.sumOf { it.durationMinutes }
                    val waitingDuration = totalTransferCount * 5 // 5 mins average waiting per transfer

                    // Bahrain fare: Base flat fare is 0.275 BHD (275 fils) for a single bus trip
                    val fareEstimate = 0.275 * (totalTransferCount + 1)

                    val sdf = SimpleDateFormat("hh:mm a", Locale("ar"))
                    val depTime = System.currentTimeMillis()
                    val arrTime = depTime + (totalDuration * 60000L)

                    // Selection criteria messages in Arabic and English
                    val (reasonAr, reasonEn) = when {
                        minimizeTransfers && totalTransferCount == 0 -> 
                            "الخيار الأفضل بدون تبديل حافلات" to "Best option with direct service"
                        minimizeWalking && walkingDuration < 5 -> 
                            "المسار الأقل مشياً ومناسب لأصحاب الهمم" to "Minimum walking, fully accessible"
                        totalDuration < 30 -> 
                            "أسرع مسار متاح للوصول لوجهتك" to "Fastest route to destination"
                        else -> 
                            "المسار الموصى به باستخدام شبكة حافلات البحرين" to "Recommended route via Bahrain Bus network"
                    }

                    resultPlans.add(
                        JourneyPlan(
                            planId = UUID.randomUUID().toString(),
                            totalDurationMinutes = totalDuration + waitingDuration,
                            walkingDurationMinutes = walkingDuration,
                            waitingDurationMinutes = waitingDuration,
                            fareBhd = fareEstimate,
                            transferCount = totalTransferCount,
                            departureTime = sdf.format(Date(depTime)),
                            arrivalTime = sdf.format(Date(arrTime)),
                            legs = legs,
                            selectionReasonAr = reasonAr,
                            selectionReasonEn = reasonEn,
                            isWheelchairAccessible = legs.none { leg -> 
                                leg.type == "BUS" && SeedData.routes.find { it.routeNumber == leg.routeNumber }?.isWheelchairAccessible == false 
                            }
                        )
                    )
                }
            }
        }

        // Return sorted by priority (duration / walking preference)
        return if (minimizeWalking) {
            resultPlans.sortedBy { it.walkingDurationMinutes }
        } else if (minimizeTransfers) {
            resultPlans.sortedBy { it.transferCount }
        } else {
            resultPlans.sortedBy { it.totalDurationMinutes }
        }
    }

    // Transit Segment representing routing graph links
    private data class TransitSegment(
        val routeNumber: String,
        val fromStopId: String,
        val toStopId: String
    )

    // BFS Pathfinder over routes
    private fun findTransitPaths(startStopId: String, destStopId: String): List<List<TransitSegment>> {
        val solutions = mutableListOf<List<TransitSegment>>()

        // Build list of direct connections
        val directSegments = mutableListOf<TransitSegment>()
        for (route in SeedData.routes) {
            val stopsList = com.example.data.model.JsonHelper.fromJsonStringList(route.stopsListJson)
            for (i in stopsList.indices) {
                for (j in i + 1 until stopsList.size) {
                    directSegments.add(TransitSegment(route.routeNumber, stopsList[i], stopsList[j]))
                    // Reverse direction as well since bus lines go both directions
                    directSegments.add(TransitSegment(route.routeNumber, stopsList[j], stopsList[i]))
                }
            }
        }

        // Step 1: Direct paths (No transfers)
        val directs = directSegments.filter { it.fromStopId == startStopId && it.toStopId == destStopId }
        for (segment in directs) {
            solutions.add(listOf(segment))
        }

        // Step 2: 1-Transfer paths (Two legs)
        if (solutions.isEmpty()) {
            val startLegs = directSegments.filter { it.fromStopId == startStopId }
            val endLegs = directSegments.filter { it.toStopId == destStopId }

            for (sLeg in startLegs) {
                for (eLeg in endLegs) {
                    // Transfer stop can be the same, or a nearby walking transfer
                    if (sLeg.toStopId == eLeg.fromStopId && sLeg.routeNumber != eLeg.routeNumber) {
                        solutions.add(listOf(sLeg, eLeg))
                    } else {
                        // Walking transfer check (if they are within 400m)
                        val sStopObj = getStop(sLeg.toStopId)
                        val eStopObj = getStop(eLeg.fromStopId)
                        if (sStopObj != null && eStopObj != null) {
                            val dist = calculateDistance(sStopObj.latitude, sStopObj.longitude, eStopObj.latitude, eStopObj.longitude)
                            if (dist < 400 && sLeg.routeNumber != eLeg.routeNumber) {
                                solutions.add(listOf(sLeg, eLeg))
                            }
                        }
                    }
                }
            }
        }

        // Return unique paths to prevent duplicates
        return solutions.distinctBy { path -> 
            path.joinToString("-") { "${it.routeNumber}:${it.fromStopId}->${it.toStopId}" }
        }.take(3)
    }

    private fun generatePathPoints(lat1: Double, lon1: Double, lat2: Double, lon2: Double): List<Pair<Double, Double>> {
        val points = mutableListOf<Pair<Double, Double>>()
        // Draw 5 interpolating points to make the path beautiful and segmented on map
        for (i in 0..5) {
            val fraction = i / 5.0
            val lat = lat1 + (lat2 - lat1) * fraction
            val lon = lon1 + (lon2 - lon1) * fraction
            points.add(Pair(lat, lon))
        }
        return points
    }
}
