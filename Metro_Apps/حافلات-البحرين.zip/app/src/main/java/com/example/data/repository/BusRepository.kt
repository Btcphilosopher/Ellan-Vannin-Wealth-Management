package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.BusDao
import com.example.data.model.*
import com.example.data.seed.SeedData
import com.example.data.simulation.SimulationEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.text.SimpleDateFormat
import java.util.*

class BusRepository(private val context: Context) {
    private val db: AppDatabase = AppDatabase.getDatabase(context)
    private val dao: BusDao = db.busDao()

    // --- Routes ---

    suspend fun getRoutes(): List<BusRoute> {
        val dbRoutes = dao.getAllRoutes()
        // Override status if simulation has custom states
        return dbRoutes.map { route ->
            val hasActiveAlert = SimulationEngine.state.value.alerts.any { alert ->
                JsonHelper.fromJsonStringList(alert.affectedRoutesJson).contains(route.routeNumber)
            }
            if (hasActiveAlert) {
                route.copy(status = RouteStatus.DELAYED)
            } else {
                route
            }
        }
    }

    suspend fun getRouteById(routeNumber: String): BusRoute? {
        return dao.getRouteById(routeNumber)
    }

    // --- Stops ---

    suspend fun getStops(): List<BusStop> {
        return dao.getAllStops()
    }

    suspend fun getStopById(stopId: String): BusStop? {
        return dao.getStopById(stopId)
    }

    // --- Real-time Departures Board ---

    suspend fun getDeparturesForStop(stopId: String): List<Departure> {
        val stop = getStopById(stopId) ?: return emptyList()
        val servedRoutes = JsonHelper.fromJsonStringList(stop.servedRoutesJson)
        val departures = mutableListOf<Departure>()

        val simState = SimulationEngine.state.value

        // Check if stop is closed
        if (simState.closedStops.contains(stopId)) {
            return emptyList()
        }

        for (routeNum in servedRoutes) {
            val route = getRouteById(routeNum) ?: continue
            val stopsList = JsonHelper.fromJsonStringList(route.stopsListJson)
            val stopIdx = stopsList.indexOf(stopId)
            if (stopIdx == -1) continue

            // Check if there is an active simulated vehicle on this route
            val vehicle = simState.vehicles.find { it.routeNumber == routeNum }
            val minutesLeft: Int
            val statusAr: String

            if (vehicle != null) {
                // Determine vehicle stop sequence distance
                val vCurrStopIdx = stopsList.indexOf(vehicle.currentStopId)
                if (vCurrStopIdx != -1 && vCurrStopIdx <= stopIdx) {
                    val stopDiff = stopIdx - vCurrStopIdx
                    val progressPenalty = (1.0f - vehicle.progressPercent)
                    minutesLeft = ((stopDiff + progressPenalty) * 6).toInt().coerceAtLeast(1)
                    statusAr = if (vehicle.delayMinutes > 0) "متأخر ${vehicle.delayMinutes} د" else "بث مباشر"
                } else {
                    // Estimated scheduled arrival
                    minutesLeft = (stopIdx + 1) * route.frequencyMinutes / 2
                    statusAr = "مجدول"
                }
            } else {
                minutesLeft = (stopIdx + 1) * route.frequencyMinutes / 2
                statusAr = "مجدول"
            }

            val cal = Calendar.getInstance()
            cal.add(Calendar.MINUTE, minutesLeft)
            val sdf = SimpleDateFormat("hh:mm a", Locale("ar"))

            departures.add(
                Departure(
                    routeNumber = route.routeNumber,
                    routeColor = route.colorHex,
                    destinationAr = route.destinationAr,
                    destinationEn = route.destinationEn,
                    scheduledTime = sdf.format(cal.time),
                    expectedArrivalMinutes = minutesLeft,
                    statusAr = statusAr,
                    isRealTime = statusAr == "بث مباشر"
                )
            )
        }

        return departures.sortedBy { it.expectedArrivalMinutes }
    }

    // --- Tickets and Fares ---

    val fareProducts = listOf(
        FareProduct(
            productId = "P_SINGLE",
            nameAr = "تذكرة رحلة واحدة",
            nameEn = "Single Trip Ticket",
            descriptionAr = "صالحة لرحلة واحدة فقط وصعود واحد على متن الحافلة.",
            descriptionEn = "Valid for a single continuous trip on one bus.",
            priceBhd = 0.275,
            validityPeriodHours = 2
        ),
        FareProduct(
            productId = "P_DAILY",
            nameAr = "تذكرة اليوم الواحد اللامحدودة",
            nameEn = "Unlimited Day Pass",
            descriptionAr = "تنقل غير محدود على كافة خطوط الحافلات لمدة ٢٤ ساعة.",
            descriptionEn = "Unlimited travel on all Bahrain Bus lines for 24 hours.",
            priceBhd = 0.600,
            validityPeriodHours = 24
        ),
        FareProduct(
            productId = "P_WEEKLY",
            nameAr = "تذكرة الأسبوع الواحد اللامحدودة",
            nameEn = "Weekly Pass",
            descriptionAr = "تنقل غير محدود على جميع خطوط الحافلات طيلة ٧ أيام متتالية.",
            descriptionEn = "Unlimited travel on all network lines for 7 consecutive days.",
            priceBhd = 3.000,
            validityPeriodHours = 168
        ),
        FareProduct(
            productId = "P_MONTHLY",
            nameAr = "تذكرة شهرية مخفضة لطلاب المدارس",
            nameEn = "Monthly Student Pass",
            descriptionAr = "تنقل غير محدود طوال الشهر للطلاب المسجلين في مدارس مملكة البحرين.",
            descriptionEn = "Unlimited monthly travel for registered school and university students.",
            priceBhd = 5.000,
            validityPeriodHours = 720
        )
    )

    suspend fun getTickets(): List<Ticket> {
        return dao.getAllTickets()
    }

    suspend fun getActiveTickets(): List<Ticket> {
        return dao.getActiveTickets()
    }

    suspend fun purchaseTicket(product: FareProduct, passengerName: String): Ticket {
        val ticketId = "T_${UUID.randomUUID().toString().take(6).uppercase()}"
        val ticket = Ticket(
            ticketId = ticketId,
            passengerName = passengerName,
            typeAr = product.nameAr,
            typeEn = product.nameEn,
            priceBhd = product.priceBhd,
            validFromTime = null,
            expiryTime = null,
            status = TicketStatus.PENDING, // Awaiting activation/payment confirmation
            qrCodePayload = "BAHRAIN_BUS_TICKET:$ticketId:${product.productId}"
        )
        dao.insertTicket(ticket)
        return ticket
    }

    suspend fun activateTicket(ticketId: String, validityHours: Int) {
        val ticket = dao.getTicketById(ticketId)
        if (ticket != null) {
            val fromTime = System.currentTimeMillis()
            val expiry = fromTime + (validityHours * 3600000L)
            dao.insertTicket(
                ticket.copy(
                    validFromTime = fromTime,
                    expiryTime = expiry,
                    status = TicketStatus.ACTIVE
                )
            )
            // Push Notification
            dao.insertNotification(
                AppNotification(
                    notificationId = UUID.randomUUID().toString(),
                    titleAr = "تم تفعيل التذكرة بنجاح",
                    titleEn = "Ticket Activated Successfully",
                    bodyAr = "تذكرتك المخصصة لـ ${ticket.typeAr} جاهزة الآن للاستخدام والمسح عند صعود الحافلة.",
                    bodyEn = "Your ${ticket.typeEn} is active and ready to be scanned on the bus board.",
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun scanAndUseTicket(ticketId: String) {
        val ticket = dao.getTicketById(ticketId)
        if (ticket != null && ticket.status == TicketStatus.ACTIVE) {
            dao.insertTicket(ticket.copy(status = TicketStatus.USED))
            dao.insertNotification(
                AppNotification(
                    notificationId = UUID.randomUUID().toString(),
                    titleAr = "تم مسح تذكرتك بنجاح",
                    titleEn = "Ticket Scanned Successfully",
                    bodyAr = "تم التحقق من التذكرة رقم $ticketId على متن الحافلة. نتمنى لك رحلة سعيدة!",
                    bodyEn = "Ticket $ticketId verified on board. Have a safe and pleasant journey!",
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    // --- Service Alerts ---

    suspend fun getAlerts(): List<ServiceAlert> {
        return SimulationEngine.state.value.alerts
    }

    // --- User Feedback Reports ---

    suspend fun submitReport(category: ReportCategory, location: String, description: String, routeNum: String?, stopId: String?): UserReport {
        val report = UserReport(
            reportId = "REP_${UUID.randomUUID().toString().take(5).uppercase()}",
            category = category,
            location = location,
            routeNumber = routeNum,
            stopId = stopId,
            description = description,
            contactPreferenceAr = "بريد إلكتروني",
            status = ReportStatus.RECEIVED,
            submittedAt = System.currentTimeMillis()
        )
        dao.insertReport(report)
        return report
    }

    suspend fun getAllReports(): List<UserReport> {
        return dao.getAllReports()
    }

    // --- Favourites ---

    suspend fun toggleFavourite(id: String, type: String) {
        val favourites = dao.getAllFavourites()
        val exists = favourites.any { it.id == id && it.type == type }
        if (exists) {
            dao.removeFavourite(id)
        } else {
            dao.addFavourite(FavouriteItem(id, type, System.currentTimeMillis()))
        }
    }

    suspend fun getFavourites(): List<FavouriteItem> {
        return dao.getAllFavourites()
    }

    // --- Notifications ---

    suspend fun getNotifications(): List<AppNotification> {
        return dao.getAllNotifications()
    }

    suspend fun clearNotifications() {
        dao.clearAllNotifications()
    }
}
