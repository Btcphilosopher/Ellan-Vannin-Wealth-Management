package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import com.example.data.model.AppNotification
import com.example.data.model.BusRoute
import com.example.data.model.BusStop
import com.example.data.model.FavouriteItem
import com.example.data.model.RouteStatus
import com.example.data.model.ServiceAlert
import com.example.data.model.Ticket
import com.example.data.model.TicketStatus
import com.example.data.model.UserReport

// --- Type Converters ---

class AppTypeConverters {
    @TypeConverter
    fun fromRouteStatus(status: RouteStatus): String = status.name

    @TypeConverter
    fun toRouteStatus(value: String): RouteStatus = try {
        RouteStatus.valueOf(value)
    } catch (e: Exception) {
        RouteStatus.NORMAL
    }

    @TypeConverter
    fun fromTicketStatus(status: TicketStatus): String = status.name

    @TypeConverter
    fun toTicketStatus(value: String): TicketStatus = try {
        TicketStatus.valueOf(value)
    } catch (e: Exception) {
        TicketStatus.DRAFT
    }
}

// --- DAOs ---

@Dao
interface BusDao {
    // --- Routes ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutes(routes: List<BusRoute>)

    @Query("SELECT * FROM routes")
    suspend fun getAllRoutes(): List<BusRoute>

    @Query("SELECT * FROM routes WHERE routeNumber = :routeNumber")
    suspend fun getRouteById(routeNumber: String): BusRoute?

    // --- Stops ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStops(stops: List<BusStop>)

    @Query("SELECT * FROM stops")
    suspend fun getAllStops(): List<BusStop>

    @Query("SELECT * FROM stops WHERE stopId = :stopId")
    suspend fun getStopById(stopId: String): BusStop?

    // --- Tickets ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: Ticket)

    @Query("SELECT * FROM tickets ORDER BY validFromTime DESC")
    suspend fun getAllTickets(): List<Ticket>

    @Query("SELECT * FROM tickets WHERE ticketId = :ticketId")
    suspend fun getTicketById(ticketId: String): Ticket?

    @Query("SELECT * FROM tickets WHERE status = 'ACTIVE' OR status = 'PENDING'")
    suspend fun getActiveTickets(): List<Ticket>

    // --- Alerts ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<ServiceAlert>)

    @Query("SELECT * FROM alerts ORDER BY startTime DESC")
    suspend fun getAllAlerts(): List<ServiceAlert>

    @Query("UPDATE alerts SET isRead = 1 WHERE alertId = :alertId")
    suspend fun markAlertAsRead(alertId: String)

    // --- Reports ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: UserReport)

    @Query("SELECT * FROM reports ORDER BY submittedAt DESC")
    suspend fun getAllReports(): List<UserReport>

    // --- Favourites ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavourite(favourite: FavouriteItem)

    @Query("DELETE FROM favourites WHERE id = :id")
    suspend fun removeFavourite(id: String)

    @Query("SELECT * FROM favourites")
    suspend fun getAllFavourites(): List<FavouriteItem>

    // --- Notifications ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotification)

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    suspend fun getAllNotifications(): List<AppNotification>

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllNotificationsAsRead()

    @Query("DELETE FROM notifications")
    suspend fun clearAllNotifications()
}

// --- App Database ---

@Database(
    entities = [
        BusRoute::class,
        BusStop::class,
        Ticket::class,
        ServiceAlert::class,
        UserReport::class,
        FavouriteItem::class,
        AppNotification::class
    ],
    version = 2,
    exportSchema = false
)
@androidx.room.TypeConverters(AppTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun busDao(): BusDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "bahrain_bus_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
