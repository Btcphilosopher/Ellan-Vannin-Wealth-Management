package com.example.ui.maps

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import com.example.data.model.BusRoute
import com.example.data.model.BusStop
import com.example.data.seed.SeedData
import com.example.data.simulation.SimVehicle
import kotlin.math.absoluteValue

@Composable
fun BahrainMap(
    modifier: Modifier = Modifier,
    selectedRoute: BusRoute? = null,
    selectedStop: BusStop? = null,
    activeVehicles: List<SimVehicle> = emptyList(),
    closedStops: Set<String> = emptySet(),
    showAllRoutes: Boolean = true,
    showStops: Boolean = true,
    showInterchanges: Boolean = true,
    showNearbyOnly: Boolean = false,
    userLocation: Pair<Double, Double>? = Pair(26.2351, 50.5755), // Default to Bab Al Bahrain
    onStopSelected: (BusStop) -> Unit = {}
) {
    // Zoom & Pan states
    var zoomLevel by remember { mutableStateOf(1.2f) }
    var panOffset by remember { mutableStateOf(Offset(0f, 0f)) }

    // Bounding Box of Bahrain geography for coordinate-to-pixel projection
    val minLat = 25.98
    val maxLat = 26.29
    val minLng = 50.42
    val maxLng = 50.67

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    panOffset = Offset(
                        x = panOffset.x + dragAmount.x,
                        y = panOffset.y + dragAmount.y
                    )
                }
            }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = zoomLevel,
                    scaleY = zoomLevel,
                    translationX = panOffset.x,
                    translationY = panOffset.y
                )
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        // Reverse project tap offset to check click on any stop
                        val canvasWidth = size.width
                        val canvasHeight = size.height

                        // Find closest stop to tapped position
                        var closestStop: BusStop? = null
                        var closestDist = 30f // click threshold in DP/pixels

                        for (stop in SeedData.stops) {
                            val stopX = ((stop.longitude - minLng) / (maxLng - minLng) * canvasWidth).toFloat()
                            // Latitudes are inverted on screens (top is 0)
                            val stopY = ((1.0 - (stop.latitude - minLat) / (maxLat - minLat)) * canvasHeight).toFloat()

                            // Apply zoom and pan to comparison
                            val projectedX = stopX
                            val projectedY = stopY

                            val dx = offset.x - projectedX
                            val dy = offset.y - projectedY
                            val dist = kotlin.math.sqrt(dx * dx + dy * dy)
                            if (dist < closestDist) {
                                closestDist = dist
                                closestStop = stop
                            }
                        }

                        if (closestStop != null) {
                            onStopSelected(closestStop)
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // Helper lambda to project GPS to Screen coordinates
            val project = { lat: Double, lng: Double ->
                val x = ((lng - minLng) / (maxLng - minLng) * w).toFloat()
                val y = ((1.0 - (lat - minLat) / (maxLat - minLat)) * h).toFloat()
                Offset(x, y)
            }

            // --- 1. Draw Bahrain Islands Coastline Outline (Simplified vectors) ---
            val mainIsland = Path().apply {
                val p1 = project(26.230, 50.500)
                moveTo(p1.x, p1.y)
                lineTo(project(26.250, 50.530).x, project(26.250, 50.530).y) // Seef
                lineTo(project(26.240, 50.580).x, project(26.240, 50.580).y) // Manama
                lineTo(project(26.210, 50.610).x, project(26.210, 50.610).y) // Juffair
                lineTo(project(26.150, 50.620).x, project(26.150, 50.620).y) // Sitra passage
                lineTo(project(26.080, 50.630).x, project(26.080, 50.630).y) // East Coast
                lineTo(project(26.000, 50.610).x, project(26.000, 50.610).y) // South Coast
                lineTo(project(25.990, 50.480).x, project(25.990, 50.480).y) // Southwest
                lineTo(project(26.080, 50.440).x, project(26.080, 50.440).y) // West coast
                lineTo(project(26.150, 50.460).x, project(26.150, 50.460).y) // Jasra
                close()
            }
            drawPath(mainIsland, color = Color(0xFFE6DFD3)) // Warm Sand / Soft limestone

            // Draw Muharraq Island
            val muharraqIsland = Path().apply {
                val p1 = project(26.245, 50.605)
                moveTo(p1.x, p1.y)
                lineTo(project(26.255, 50.600).x, project(26.255, 50.600).y) // Souq area
                lineTo(project(26.275, 50.625).x, project(26.275, 50.625).y) // Airport
                lineTo(project(26.280, 50.660).x, project(26.280, 50.660).y) // Galali
                lineTo(project(26.250, 50.650).x, project(26.250, 50.650).y) // Hidd
                lineTo(project(26.238, 50.618).x, project(26.238, 50.618).y) // South Muharraq
                close()
            }
            drawPath(muharraqIsland, color = Color(0xFFDDD5C4))

            // Draw Sitra Island
            val sitraIsland = Path().apply {
                val p1 = project(26.160, 50.615)
                moveTo(p1.x, p1.y)
                lineTo(project(26.170, 50.635).x, project(26.170, 50.635).y)
                lineTo(project(26.120, 50.630).x, project(26.120, 50.630).y)
                lineTo(project(26.115, 50.608).x, project(26.115, 50.608).y)
                close()
            }
            drawPath(sitraIsland, color = Color(0xFFD6CEBD))

            // --- 2. Draw Bridges & Highways ---
            val bridges = listOf(
                Pair(project(26.236, 50.575), project(26.248, 50.610)), // Sh. Hamad Bridge
                Pair(project(26.242, 50.590), project(26.258, 50.615)), // Sh. Isa Bridge
                Pair(project(26.234, 50.542), project(26.236, 50.574)), // Khalifa Highway (Seef-Manama)
                Pair(project(26.173, 50.548), project(26.128, 50.571)), // Isa Town to Riffa Rd
                Pair(project(26.128, 50.571), project(26.155, 50.618))  // Riffa to Sitra Highway
            )
            for (bridge in bridges) {
                drawLine(
                    color = Color.White,
                    start = bridge.first,
                    end = bridge.second,
                    strokeWidth = 6f
                )
                drawLine(
                    color = Color.LightGray,
                    start = bridge.first,
                    end = bridge.second,
                    strokeWidth = 2f
                )
            }

            // --- 3. Draw Bus Routes (Colored connection lines) ---
            if (showAllRoutes) {
                val routesToDraw = if (selectedRoute != null) listOf(selectedRoute) else SeedData.routes
                for (route in routesToDraw) {
                    val stopIds = com.example.data.model.JsonHelper.fromJsonStringList(route.stopsListJson)
                    if (stopIds.size >= 2) {
                        val routeColor = Color(route.colorHex.replace("0xFF", "FF").toLong(16))
                        for (i in 0 until stopIds.size - 1) {
                            val st1 = SeedData.stops.find { it.stopId == stopIds[i] }
                            val st2 = SeedData.stops.find { it.stopId == stopIds[i + 1] }
                            if (st1 != null && st2 != null) {
                                drawLine(
                                    color = routeColor.copy(alpha = if (selectedRoute != null) 1.0f else 0.7f),
                                    start = project(st1.latitude, st1.longitude),
                                    end = project(st2.latitude, st2.longitude),
                                    strokeWidth = if (selectedRoute?.routeNumber == route.routeNumber) 12f else 6f
                                )
                            }
                        }
                    }
                }
            }

            // --- 4. Draw Bus Stops ---
            if (showStops) {
                for (stop in SeedData.stops) {
                    val stopOffset = project(stop.latitude, stop.longitude)
                    val isClosed = closedStops.contains(stop.stopId)
                    val isSelected = selectedStop?.stopId == stop.stopId

                    // Draw outer border / halo for active stops
                    drawCircle(
                        color = if (isSelected) Color(0xFF00A3A6) else if (isClosed) Color(0xFFD90429) else Color(0xFF0A2540),
                        radius = if (isSelected) 18f else 10f,
                        center = stopOffset
                    )

                    // Draw inner fill
                    drawCircle(
                        color = if (isClosed) Color.White else if (isSelected) Color(0xFFE76F51) else Color.White,
                        radius = if (isSelected) 10f else 6f,
                        center = stopOffset
                    )
                }
            }

            // --- 5. Draw Active Vehicles (Buses) ---
            for (vehicle in activeVehicles) {
                val vOffset = project(vehicle.latitude, vehicle.longitude)
                val route = SeedData.routes.find { it.routeNumber == vehicle.routeNumber }
                val routeColor = if (route != null) Color(route.colorHex.replace("0xFF", "FF").toLong(16)) else Color(0xFF00A3A6)

                // Pulsing outer aura
                drawCircle(
                    color = routeColor.copy(alpha = 0.3f),
                    radius = 24f,
                    center = vOffset
                )

                // Bus Icon indicator
                drawCircle(
                    color = routeColor,
                    radius = 12f,
                    center = vOffset
                )

                // Small white core
                drawCircle(
                    color = Color.White,
                    radius = 4f,
                    center = vOffset
                )
            }

            // --- 6. Draw User Location Indicator ---
            if (userLocation != null) {
                val userOffset = project(userLocation.first, userLocation.second)
                // Outer blue pulse
                drawCircle(
                    color = Color(0xFF00A3A6).copy(alpha = 0.4f),
                    radius = 30f,
                    center = userOffset
                )
                // Center point
                drawCircle(
                    color = Color(0xFF00A3A6),
                    radius = 10f,
                    center = userOffset
                )
                drawCircle(
                    color = Color.White,
                    radius = 5f,
                    center = userOffset
                )
            }
        }
    }
}
