package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

// --- Enums ---

enum class RouteStatus {
    NORMAL,      // يعمل بشكل طبيعي
    DELAYED,     // متأخر
    DIVERTED,    // محوّل
    SUSPENDED,   // متوقف مؤقتاً
    UNAVAILABLE  // غير متاح
}

enum class TicketStatus {
    DRAFT,       // مسودة
    PENDING,     // بانتظار الدفع
    ACTIVE,      // نشطة
    USED,        // مستخدمة
    EXPIRED,     // منتهية
    CANCELLED,   // ملغاة
    SUSPENDED    // معلّقة
}

enum class AlertSeverity {
    INFO,        // معلومة
    WARNING,     // تنبيه
    IMPORTANT,   // مهم
    CRITICAL     // عاجل
}

enum class AlertCategory {
    DELAY,       // تأخير
    DIVERSION,   // تحويل مسار
    STOP_CLOSURE,// إغلاق موقف
    TEMP_CHANGE, // تغيير مؤقت
    CONGESTION,  // ازدحام مروري
    ROADWORKS,   // أعمال طرق
    WEATHER,     // ظروف جوية
    OPERATIONAL, // تنبيه تشغيلي
    GENERAL      // معلومات عامة
}

enum class ReportCategory {
    MISSING_BUS,         // حافلة مفقودة
    STOP_CONDITION,      // حالة الموقف
    INCORRECT_INFO,      // معلومات غير صحيحة
    ACCESSIBILITY_ISSUE, // مشكلة سهولة الوصول
    LOST_PROPERTY,       // مفقودات
    TICKET_PROBLEM,      // مشكلة تذاكر
    FEEDBACK,            // ملاحظات
    OTHER                // أخرى
}

enum class ReportStatus {
    RECEIVED,    // تم الاستلام
    UNDER_REVIEW,// قيد المراجعة
    IN_PROGRESS, // قيد المعالجة
    RESOLVED,    // تم الحل
    CLOSED       // مغلق
}

// --- Room Entities ---

@Entity(tableName = "routes")
data class BusRoute(
    @PrimaryKey val routeNumber: String, // e.g. "A1", "10"
    val nameAr: String,
    val nameEn: String,
    val colorHex: String,
    val originAr: String,
    val originEn: String,
    val destinationAr: String,
    val destinationEn: String,
    val status: RouteStatus,
    val firstService: String, // e.g. "05:00"
    val lastService: String,  // e.g. "23:30"
    val frequencyMinutes: Int,
    val isWheelchairAccessible: Boolean = true,
    val stopsListJson: String // List of stop IDs (JSON array)
)

@Entity(tableName = "stops")
data class BusStop(
    @PrimaryKey val stopId: String,
    val nameAr: String,
    val nameEn: String,
    val latitude: Double,
    val longitude: Double,
    val hasShelter: Boolean,
    val hasSeating: Boolean,
    val hasLighting: Boolean,
    val hasInformationBoard: Boolean,
    val hasWheelchairRamp: Boolean,
    val servedRoutesJson: String // List of route numbers (JSON array)
)

@Entity(tableName = "tickets")
data class Ticket(
    @PrimaryKey val ticketId: String,
    val passengerName: String,
    val typeAr: String,
    val typeEn: String,
    val priceBhd: Double,
    val validFromTime: Long?,
    val expiryTime: Long?,
    val status: TicketStatus,
    val qrCodePayload: String
)

@Entity(tableName = "alerts")
data class ServiceAlert(
    @PrimaryKey val alertId: String,
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val category: AlertCategory,
    val severity: AlertSeverity,
    val affectedRoutesJson: String, // List of route numbers
    val affectedStopsJson: String,  // List of stop IDs
    val startTime: Long,
    val expectedEndTime: Long,
    val isRead: Boolean = false,
    val lastUpdated: Long
)

@Entity(tableName = "reports")
data class UserReport(
    @PrimaryKey val reportId: String,
    val category: ReportCategory,
    val location: String,
    val routeNumber: String?,
    val stopId: String?,
    val description: String,
    val contactPreferenceAr: String,
    val status: ReportStatus,
    val submittedAt: Long
)

@Entity(tableName = "favourites")
data class FavouriteItem(
    @PrimaryKey val id: String, // routeNumber or stopId
    val type: String, // "ROUTE" or "STOP"
    val addedAt: Long
)

@Entity(tableName = "saved_locations")
data class SavedLocation(
    @PrimaryKey val id: String, // "home", "work", etc.
    val labelAr: String,
    val labelEn: String,
    val latitude: Double,
    val longitude: Double
)

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey val notificationId: String,
    val titleAr: String,
    val titleEn: String,
    val bodyAr: String,
    val bodyEn: String,
    val timestamp: Long,
    val isRead: Boolean = false
)

// --- Domain Models for simulation & journey planning (Not Room-persisted but used in flows) ---

data class Departure(
    val routeNumber: String,
    val routeColor: String,
    val destinationAr: String,
    val destinationEn: String,
    val scheduledTime: String, // e.g. "14:35"
    val expectedArrivalMinutes: Int, // ETA in minutes from current simulation time
    val statusAr: String, // e.g. "في الوقت المحدد" or "متأخر ٥ د"
    val isRealTime: Boolean
)

data class VehiclePosition(
    val vehicleId: String,
    val routeNumber: String,
    val currentLatitude: Double,
    val currentLongitude: Double,
    val speedKmh: Double,
    val nextStopId: String?,
    val bearing: Float
)

data class JourneyLeg(
    val type: String, // "WALK" or "BUS"
    val routeNumber: String?,
    val routeColor: String?,
    val durationMinutes: Int,
    val distanceMeters: Int,
    val startStopId: String?,
    val startStopNameAr: String?,
    val startStopNameEn: String?,
    val endStopId: String?,
    val endStopNameAr: String?,
    val endStopNameEn: String?,
    val descriptionAr: String,
    val descriptionEn: String,
    val stopCount: Int = 0,
    val points: List<Pair<Double, Double>> // Lat Long path points for map
)

data class JourneyPlan(
    val planId: String,
    val totalDurationMinutes: Int,
    val walkingDurationMinutes: Int,
    val waitingDurationMinutes: Int,
    val fareBhd: Double,
    val transferCount: Int,
    val departureTime: String,
    val arrivalTime: String,
    val legs: List<JourneyLeg>,
    val selectionReasonAr: String,
    val selectionReasonEn: String,
    val isWheelchairAccessible: Boolean
)

data class ActiveJourneyState(
    val plan: JourneyPlan,
    val currentLegIndex: Int,
    val currentStopId: String?,
    val nextStopId: String?,
    val etaMinutes: Int,
    val stopsRemaining: Int,
    val progressPercent: Float,
    val isApproachingReminderSet: Boolean = false
)

data class FareProduct(
    val productId: String,
    val nameAr: String,
    val nameEn: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val priceBhd: Double,
    val validityPeriodHours: Int
)

// --- Moshi Utility Parser (For JSON deserialization in seed files) ---
object JsonHelper {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    fun fromJsonStringList(json: String): List<String> {
        return try {
            val adapter = moshi.adapter(Array<String>::class.java)
            adapter.fromJson(json)?.toList() ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun toJsonStringList(list: List<String>): String {
        val adapter = moshi.adapter(Array<String>::class.java)
        return adapter.toJson(list.toTypedArray())
    }
}
