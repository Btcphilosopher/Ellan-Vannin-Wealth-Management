package com.example.features.stations

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.TransportMode
import com.example.data.TransportNetworkData
import com.example.features.home.NearbyDepartureItem
import com.example.ui.AppViewModel
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.Screen
import com.example.ui.theme.*

@Composable
fun StationDetailScreen(viewModel: AppViewModel) {
    val selectedStationId by viewModel.selectedStationId.collectAsState()
    val favoriteStations by viewModel.favoriteStations.collectAsState()
    val isFavorite = favoriteStations.contains(selectedStationId)

    val station = TransportNetworkData.stations.find { it.id == selectedStationId } ?: TransportNetworkData.stations.first()

    val headerColor = when {
        station.lines.contains("A") -> MetroLineA
        station.lines.contains("B") -> MetroLineB
        station.lines.contains("C") -> MetroLineC
        else -> TransportRed
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- WAYFINDING ACTION BAR ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerColor)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.goBack() }) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Zpět",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = station.name.uppercase(),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 1.sp,
                        modifier = Modifier.testTag("station_title")
                    )
                    Text(
                        text = if (station.lines.isNotEmpty()) "LINKA " + station.lines.joinToString(" & ") else "ZASTÁVKA PID",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.8f),
                        letterSpacing = 1.5.sp
                    )
                }
            }

            // Favorite Toggle
            IconButton(onClick = { viewModel.toggleFavorite(station.id) }) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "Oblíbená",
                    tint = if (isFavorite) AmberWarning else Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // --- DETAILS SCROLLABLE CONTAINER ---
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // --- DEPARTURES BOARD (ODJEZDY) ---
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite, RoundedCornerShape(4.dp))
                        .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "AKTUÁLNÍ ODJEZDY",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = Graphite,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    if (station.id == "staromestska") {
                        NearbyDepartureItem("A", MetroLineA, "Nemocnice Motol", 2, true, "Kolej 1")
                        Divider(color = PragueStone.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 10.dp))
                        NearbyDepartureItem("A", MetroLineA, "Depo Hostivař", 7, true, "Kolej 2")
                        Divider(color = PragueStone.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 10.dp))
                        NearbyDepartureItem("17", TransportRed, "Levského", 4, true, "Zastávka 1")
                    } else if (station.id == "mustek") {
                        NearbyDepartureItem("A", MetroLineA, "Dejvická", 3, true, "Kolej 1")
                        Divider(color = PragueStone.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 10.dp))
                        NearbyDepartureItem("B", MetroLineB, "Černý Most", 5, true, "Kolej B1")
                        Divider(color = PragueStone.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 10.dp))
                        NearbyDepartureItem("22", TransportRed, "Bílá Hora", 1, true, "Zast. Tram")
                    } else if (station.id == "letiste") {
                        NearbyDepartureItem("119", MutedBlue, "Nádraží Veleslavín", 6, true, "Terminál 1")
                        Divider(color = PragueStone.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 10.dp))
                        NearbyDepartureItem("59", RestrainedGreen, "Nádraží Veleslavín", 12, true, "Terminál 1")
                    } else {
                        // Generic placeholder based on modes
                        val isBus = station.modes.contains(TransportMode.BUS)
                        NearbyDepartureItem(
                            lineLabel = if (isBus) "119" else "22",
                            lineColor = if (isBus) MutedBlue else TransportRed,
                            destination = "Centrum Prahy",
                            minutesLeft = 4,
                            isAccessible = station.isAccessible,
                            platform = "Stanoviště A"
                        )
                    }
                }
            }

            // --- EXITS (VÝSTUPY) ---
            item {
                Column {
                    Text(
                        text = "STREEST LEVEL EXITS (VÝSTUPY)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp,
                        color = Graphite.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (station.exits.isEmpty()) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, PragueStone, RoundedCornerShape(4.dp)),
                            colors = CardDefaults.cardColors(containerColor = OffWhite)
                        ) {
                            Text(
                                text = "Pouze jeden přímý uliční výstup.",
                                fontSize = 13.sp,
                                modifier = Modifier.padding(14.dp),
                                color = Graphite
                            )
                        }
                    } else {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            station.exits.forEachIndexed { idx, exitName ->
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .border(1.dp, PragueStone, RoundedCornerShape(4.dp)),
                                    colors = CardDefaults.cardColors(containerColor = OffWhite)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = "VÝCHOD ${idx + 1}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Black,
                                            color = TransportRed
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = exitName,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Graphite,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // --- FACILITIES (VYBAVENÍ STANICE) ---
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite, RoundedCornerShape(4.dp))
                        .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "VYBAVENÍ STANICE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = Graphite,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    FacilityRowItem(
                        icon = Icons.Default.Elevator,
                        label = "Bezbariérový výtah",
                        available = station.hasElevator
                    )
                    FacilityRowItem(
                        icon = Icons.Default.KeyboardArrowUp,
                        label = "Pohyblivé schody (Eskalátory)",
                        available = station.hasEscalator
                    )
                    FacilityRowItem(
                        icon = Icons.Default.CheckCircle,
                        label = "Uliční bezbariérový přístup",
                        available = station.isAccessible
                    )

                    if (station.facilities.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Ostatní služby: " + station.facilities.joinToString(", "),
                            fontSize = 12.sp,
                            color = Graphite.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            // --- SET AS ROUTE POINT ACTION ---
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.setOrigin(station.id)
                            viewModel.navigateTo(Screen.SPOJENI)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Graphite),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("ODKUD ODSUD", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.White)
                    }

                    Button(
                        onClick = {
                            viewModel.setDestination(station.id)
                            viewModel.navigateTo(Screen.SPOJENI)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TransportRed),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("SEM (CÍL)", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun FacilityRowItem(
    icon: ImageVector,
    label: String,
    available: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Graphite.copy(alpha = 0.7f),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = label, fontSize = 13.sp, color = Graphite)
        }

        Box(
            modifier = Modifier
                .background(
                    color = if (available) RestrainedGreen.copy(alpha = 0.15f) else TransportRed.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(2.dp)
                )
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = if (available) "ANO" else "NE",
                color = if (available) RestrainedGreen else TransportRed,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}
