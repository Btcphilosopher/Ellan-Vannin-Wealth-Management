package com.example.features.journey

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsWalk
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.data.TransportNetworkData
import com.example.features.home.StationSelectionDialog
import com.example.ui.AppViewModel
import com.example.ui.theme.*

@Composable
fun ConnectionScreen(viewModel: AppViewModel) {
    val originId by viewModel.originId.collectAsState()
    val destinationId by viewModel.destinationId.collectAsState()
    val routeOptions by viewModel.routeOptions.collectAsState()
    val selectedRoute by viewModel.selectedRoute.collectAsState()
    val wheelchairFilter by viewModel.wheelchairFilter.collectAsState()

    val stationsList = TransportNetworkData.stations

    var showOriginSelect by remember { mutableStateOf(false) }
    var showDestSelect by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER BAR WITH SELECTORS ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.goBack() }) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Zpět",
                        tint = Graphite
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "VYHLEDAT SPOJENÍ",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = Graphite
                )
            }

            // ODKUD selector row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.TripOrigin,
                    contentDescription = null,
                    tint = TransportRed,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
                        .clickable { showOriginSelect = true }
                        .padding(10.dp)
                ) {
                    val oName = stationsList.find { it.id == originId }?.name ?: "Zvolte počátek"
                    Text(text = oName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Graphite)
                }
            }

            // KAM selector row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Place,
                    contentDescription = null,
                    tint = Graphite,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
                        .clickable { showDestSelect = true }
                        .padding(10.dp)
                ) {
                    val dName = stationsList.find { it.id == destinationId }?.name ?: "Zvolte cíl"
                    Text(text = dName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Graphite)
                }
            }

            // FILTER ROW
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { viewModel.toggleWheelchairFilter() }
                ) {
                    Checkbox(
                        checked = wheelchairFilter,
                        onCheckedChange = { viewModel.toggleWheelchairFilter() },
                        colors = CheckboxDefaults.colors(checkedColor = RestrainedGreen)
                    )
                    Text(
                        text = "Pouze bezbariérové spoje",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Graphite
                    )
                }

                Box(
                    modifier = Modifier
                        .clickable { viewModel.swapStations() }
                        .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
                        .background(WarmIvory)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.SwapVert, contentDescription = null, modifier = Modifier.size(16.dp), tint = TransportRed)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Prohodit", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Graphite)
                    }
                }
            }
        }

        // --- RESULTS LIST ---
        if (routeOptions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SearchOff,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = PragueStone
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Žádné přímé spojení nebylo nalezeno.",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Graphite.copy(alpha = 0.5f)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 20.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(routeOptions.size) { index ->
                    val route = routeOptions[index]
                    val isSelected = route == selectedRoute

                    RouteOptionCard(
                        route = route,
                        isSelected = isSelected,
                        onClick = { viewModel.selectRoute(route) }
                    )
                }

                // Show selected route detail instructions
                selectedRoute?.let { route ->
                    item {
                        RouteSegmentsDetailBlock(
                            route = route,
                            onStartJourney = { viewModel.startJourney(route) }
                        )
                    }
                }
            }
        }
    }

    // --- POPUP SELECTORS ---
    if (showOriginSelect) {
        StationSelectionDialog(
            title = "Výchozí stanice (ODKUD)",
            stations = stationsList,
            onDismiss = { showOriginSelect = false },
            onSelect = {
                viewModel.setOrigin(it)
                showOriginSelect = false
            }
        )
    }

    if (showDestSelect) {
        StationSelectionDialog(
            title = "Cílová stanice (KAM)",
            stations = stationsList,
            onDismiss = { showDestSelect = false },
            onSelect = {
                viewModel.setDestination(it)
                showDestSelect = false
            }
        )
    }
}

@Composable
fun RouteOptionCard(
    route: RouteOption,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) TransportRed else PragueStone,
                shape = RoundedCornerShape(4.dp)
            )
            .clickable { onClick() }
            .testTag("route_card_${route.label.lowercase()}"),
        colors = CardDefaults.cardColors(containerColor = if (isSelected) OffWhite else MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Route Category Tag
                Box(
                    modifier = Modifier
                        .background(
                            color = when (route.label) {
                                "Nejrychlejší" -> RestrainedGreen
                                "Nejméně přestupů" -> MutedBlue
                                else -> AmberWarning
                            },
                            shape = RoundedCornerShape(2.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = route.label.uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }

                // Duration
                Text(
                    text = "${route.totalDurationMinutes} MIN",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Graphite
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Wayfinding Segment Badges
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                route.segments.forEachIndexed { idx, segment ->
                    if (idx > 0) {
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "přestup",
                            tint = PragueStone,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    if (segment.lineId != null) {
                        // Vehicle badge
                        val badgeColor = when (segment.mode) {
                            TransportMode.METRO -> when (segment.lineId) {
                                "A" -> MetroLineA
                                "B" -> MetroLineB
                                "C" -> MetroLineC
                                else -> TransportRed
                            }
                            TransportMode.TRAM -> TransportRed
                            TransportMode.BUS -> MutedBlue
                            TransportMode.TROLEJBUS -> RestrainedGreen
                            TransportMode.LANOVKA -> AmberWarning
                            else -> Graphite
                        }

                        Row(
                            modifier = Modifier
                                .background(badgeColor, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val icon = when (segment.mode) {
                                TransportMode.METRO -> Icons.Default.Subway
                                TransportMode.TRAM -> Icons.Default.Tram
                                TransportMode.LANOVKA -> Icons.Default.Tram
                                else -> Icons.Default.DirectionsBus
                            }
                            Icon(imageVector = icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = segment.lineId, fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color.White)
                        }
                    } else {
                        // Walking segment badge
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.DirectionsWalk,
                            contentDescription = "Pěšky",
                            tint = Graphite.copy(alpha = 0.5f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "${route.transfersCount} přestupů • pěšky cca ${route.walkDistanceMeters} m",
                fontSize = 12.sp,
                color = Graphite.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
fun RouteSegmentsDetailBlock(
    route: RouteOption,
    onStartJourney: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(OffWhite, RoundedCornerShape(4.dp))
            .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
            .padding(16.dp)
    ) {
        Text(
            text = "DETAIL SPOJENÍ",
            fontSize = 12.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp,
            color = Graphite
        )

        Spacer(modifier = Modifier.height(16.dp))

        route.segments.forEachIndexed { index, seg ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                // Connector Column
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(28.dp)
                ) {
                    val indicatorIcon = when {
                        seg.lineId == null -> Icons.AutoMirrored.Filled.DirectionsWalk
                        seg.mode == TransportMode.METRO -> Icons.Default.Subway
                        seg.mode == TransportMode.TRAM -> Icons.Default.Tram
                        seg.mode == TransportMode.LANOVKA -> Icons.Default.Tram
                        else -> Icons.Default.DirectionsBus
                    }
                    val indicatorColor = when {
                        seg.lineId == null -> PragueStone
                        seg.mode == TransportMode.METRO -> when (seg.lineId) {
                            "A" -> MetroLineA
                            "B" -> MetroLineB
                            "C" -> MetroLineC
                            else -> TransportRed
                        }
                        seg.mode == TransportMode.TRAM -> TransportRed
                        else -> MutedBlue
                    }

                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(indicatorColor, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = indicatorIcon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    // Vertical line to next segment if not last
                    if (index < route.segments.size - 1) {
                        Box(
                            modifier = Modifier
                                .width(2.dp)
                                .height(40.dp)
                                .background(PragueStone)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                // Segment info details
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = seg.fromStationName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = Graphite
                    )
                    
                    val detailDesc = if (seg.lineId != null) {
                        "Nastupte na linku ${seg.lineId} (směr ${seg.toStationName})"
                    } else {
                        "Pěší přesun do nástupní stanice"
                    }

                    Text(
                        text = "$detailDesc • ${seg.durationMinutes} min",
                        fontSize = 12.sp,
                        color = Graphite.copy(alpha = 0.6f)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Stanice příjezdu: ${seg.toStationName}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Graphite.copy(alpha = 0.8f)
                    )
                }
            }

            if (index < route.segments.size - 1) {
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // START LIVE NAVIGATION
        Button(
            onClick = onStartJourney,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("start_journey_button"),
            colors = ButtonDefaults.buttonColors(containerColor = TransportRed),
            shape = RoundedCornerShape(4.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Navigation, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ZAHÁJIT CESTU",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }
    }
}
