package com.example.features.more

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransportNetworkData
import com.example.ui.AppViewModel
import com.example.ui.theme.*

// ==========================================
// 1. NIGHT MODE SCREEN (NOČNÍ PROVOZ)
// ==========================================
@Composable
fun NightModeScreen(viewModel: AppViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Charcoal)
    ) {
        // HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NightSurface)
                .border(1.dp, color = OffWhite.copy(alpha = 0.15f))
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.goBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Zpět", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "NOČNÍ PROVOZ",
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 1.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Metro closed notice card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, TransportRed, RoundedCornerShape(4.dp)),
                    colors = CardDefaults.cardColors(containerColor = NightSurface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Error, contentDescription = null, tint = TransportRed)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "METRO JE UZAVŘENO",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 1.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Standardní denní provoz metra skončil ve 24:00. Využijte noční tramvajové linky (91-99) a noční autobusové linky (901-915).",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            item {
                Text(
                    text = "NOČNÍ PÁTEŘNÍ LINKY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White.copy(alpha = 0.6f),
                    letterSpacing = 1.5.sp
                )
            }

            // Night Lines list
            item {
                NightLineRowItem(line = "91", direction = "Divoká Šárka — Nádraží Strašnice", mode = "Tramvaj")
            }
            item {
                NightLineRowItem(line = "92", direction = "Levského — Lehovec", mode = "Tramvaj")
            }
            item {
                NightLineRowItem(line = "97", direction = "Bílá Hora — Nádraží Hostivař", mode = "Tramvaj")
            }
            item {
                NightLineRowItem(line = "904", direction = "Anděl — Sídliště Stodůlky", mode = "Autobus")
            }
            item {
                NightLineRowItem(line = "911", direction = "Nádraží Hostivař — Letiště Praha", mode = "Autobus")
            }
        }
    }
}

@Composable
fun NightLineRowItem(line: String, direction: String, mode: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NightSurface, RoundedCornerShape(4.dp))
            .border(1.dp, OffWhite.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .background(Charcoal, RoundedCornerShape(2.dp))
                    .border(1.dp, TransportRed, RoundedCornerShape(2.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = line, fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = direction, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(text = mode, fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
            }
        }

        Text(text = "30 min interval", fontSize = 12.sp, color = AmberWarning, fontWeight = FontWeight.Bold)
    }
}


// ==========================================
// 2. FUNICULAR SCREEN (PETŘÍNSKÁ LANOVKA)
// ==========================================
@Composable
fun FunicularScreen(viewModel: AppViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.goBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Zpět", tint = Graphite)
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "PETŘÍNSKÁ LANOVKA (LD)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = Graphite,
                letterSpacing = 1.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Funicular maintenance status alert
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, RestrainedGreen, RoundedCornerShape(4.dp)),
                    colors = CardDefaults.cardColors(containerColor = OffWhite)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = RestrainedGreen)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = "LANOVÁ DRÁHA V PROVOZU", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Graphite)
                            Text(text = "Provoz bez omezení dle jízdního řádu.", fontSize = 12.sp, color = Graphite.copy(alpha = 0.6f))
                        }
                    }
                }
            }

            item {
                Text(
                    text = "STANICE LANOVÉ DRÁHY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = Graphite.copy(alpha = 0.6f),
                    letterSpacing = 1.5.sp
                )
            }

            // Station 1: Újezd
            item {
                FunicularStationCard(name = "Újezd LD", altMeters = "196 m. n. m.", info = "Přestup na tramvaje (9, 12, 15, 20, 22, 23). Pokladna na lístky.")
            }
            // Station 2: Nebozízek
            item {
                FunicularStationCard(name = "Nebozízek", altMeters = "242 m. n. m.", info = "Mezistanice na vyžádání. Vyhlídková restaurace a vinice.")
            }
            // Station 3: Petřín
            item {
                FunicularStationCard(name = "Petřín LD", altMeters = "324 m. n. m.", info = "Cílová stanice. Petřínská rozhledna, Zrcadlové bludiště.")
            }
        }
    }
}

@Composable
fun FunicularStationCard(name: String, altMeters: String, info: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, PragueStone, RoundedCornerShape(4.dp)),
        colors = CardDefaults.cardColors(containerColor = OffWhite)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = name, fontSize = 15.sp, fontWeight = FontWeight.Black, color = Graphite)
                Text(text = altMeters, fontSize = 11.sp, color = Graphite.copy(alpha = 0.6f), fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = info, fontSize = 12.sp, color = Graphite.copy(alpha = 0.8f))
        }
    }
}


// ==========================================
// 3. FERRIES SCREEN (PŘÍVOZY VLTAVY)
// ==========================================
@Composable
fun FerriesScreen(viewModel: AppViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.goBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Zpět", tint = Graphite)
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "PŘÍVOZY VLTAVY (P)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = Graphite,
                letterSpacing = 1.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "LODNÍ PŘÍVOZY INTEGRÁLNÍ DOPRAVY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = Graphite.copy(alpha = 0.6f),
                    letterSpacing = 1.5.sp
                )
            }

            item {
                FerryLineCard(line = "P1", route = "Sedlec — Zámky", info = "Provoz v severní části Prahy. Propojení s cyklostezkami.")
            }
            item {
                FerryLineCard(line = "P2", route = "Podbaba — Podhoří", info = "Rychlé propojení Dejvic a pražské ZOO v Troji.")
            }
            item {
                FerryLineCard(line = "P3", route = "Lihovar — Veslařský ostrov", info = "Sezónní přívoz propojující Smíchov a Podolí.")
            }
        }
    }
}

@Composable
fun FerryLineCard(line: String, route: String, info: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, PragueStone, RoundedCornerShape(4.dp)),
        colors = CardDefaults.cardColors(containerColor = OffWhite)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(MutedBlue, RoundedCornerShape(2.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Default.DirectionsBoat, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Přívoz $line: ", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Graphite)
                    Text(text = route, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Graphite)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = info, fontSize = 12.sp, color = Graphite.copy(alpha = 0.6f))
            }
        }
    }
}


// ==========================================
// 4. ARCHITECTURAL MUSEUM (PRAHA MĚSTO A DOPRAVA)
// ==========================================
@Composable
fun ArchitecturalScreen(viewModel: AppViewModel) {
    val assets = TransportNetworkData.architecturalAssets

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.goBack() }) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Zpět", tint = Graphite)
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "MĚSTO A DOPRAVA",
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = Graphite,
                letterSpacing = 1.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                Text(
                    text = "ARCHITEKTURA PRAŽSKÉ INTEGRALNÍ DOPRAVY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = Graphite.copy(alpha = 0.6f),
                    letterSpacing = 1.5.sp
                )
            }

            items(assets.size) { index ->
                val asset = assets[index]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
                        .testTag("architectural_card_${asset.id.lowercase()}"),
                    colors = CardDefaults.cardColors(containerColor = OffWhite)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = asset.category.uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = TransportRed,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = asset.title,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = Graphite
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Autor: ${asset.architect} • ${asset.yearBuilt}",
                            fontSize = 12.sp,
                            color = Graphite.copy(alpha = 0.6f)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = asset.description,
                            fontSize = 13.sp,
                            color = Graphite
                        )
                    }
                }
            }
        }
    }
}
