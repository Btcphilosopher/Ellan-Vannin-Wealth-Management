package com.example.core.routing

import com.example.core.model.*
import com.example.data.TransportNetworkData
import java.util.PriorityQueue

object DijkstraRouter {

    data class DijkstraNode(
        val stationId: String,
        val currentLineId: String?,
        val gScore: Double, // Cost from start
        val parent: DijkstraNode?,
        val edgeUsed: RoutingEdge?
    ) : Comparable<DijkstraNode> {
        override fun compareTo(other: DijkstraNode): Int {
            return gScore.compareTo(other.gScore)
        }
    }

    /**
     * Finds paths between start and end station.
     * @param startId Start station ID
     * @param endId End station ID
     * @param wheelchairAccessible If true, filters out non-accessible stations or transfers
     */
    fun findRoutes(
        startId: String,
        endId: String,
        wheelchairAccessible: Boolean = false
    ): List<RouteOption> {
        if (startId == endId) return emptyList()

        // Filter stations if wheelchair accessible is requested
        val validStationIds = TransportNetworkData.stations
            .filter { !wheelchairAccessible || it.isAccessible }
            .map { it.id }
            .toSet()

        if (!validStationIds.contains(startId) || !validStationIds.contains(endId)) {
            return emptyList()
        }

        val allEdges = TransportNetworkData.edges.filter {
            validStationIds.contains(it.fromStationId) && validStationIds.contains(it.toStationId)
        }

        val options = mutableListOf<RouteOption>()

        // 1. NEJRYCHLEJŠÍ (Fastest) - Standard Dijkstra
        val fastestPath = runDijkstra(startId, endId, allEdges, transferPenalty = 2.0)
        if (fastestPath != null) {
            options.add(buildRouteOption(fastestPath, "Nejrychlejší", 120))
        }

        // 2. NEJMÉNĚ PŘESTUPŮ (Least Transfers) - High Transfer Penalty (15 min)
        val leastTransfersPath = runDijkstra(startId, endId, allEdges, transferPenalty = 25.0)
        if (leastTransfersPath != null) {
            val transfersCount = countTransfers(leastTransfersPath)
            val fastestTransfersCount = fastestPath?.let { countTransfers(it) } ?: 0
            if (transfersCount < fastestTransfersCount || options.isEmpty()) {
                options.add(buildRouteOption(leastTransfersPath, "Nejméně přestupů", 180))
            }
        }

        // 3. NEJPOHODLNĚJŠÍ (Most Comfortable) - Medium penalty, prefers Metro or direct Tram
        val comfortablePath = runDijkstra(startId, endId, allEdges, transferPenalty = 8.0, preferMetro = true)
        if (comfortablePath != null) {
            // Only add if it's different from the first two
            val routeOpt = buildRouteOption(comfortablePath, "Nejpohodlnější", 80)
            val exists = options.any { it.segments.map { s -> s.lineId } == routeOpt.segments.map { s -> s.lineId } }
            if (!exists) {
                options.add(routeOpt)
            }
        }

        // If no options, provide a default walk fallback
        if (options.isEmpty()) {
            val startStation = TransportNetworkData.stations.find { it.id == startId }
            val endStation = TransportNetworkData.stations.find { it.id == endId }
            if (startStation != null && endStation != null) {
                options.add(
                    RouteOption(
                        segments = listOf(
                            RouteSegment(
                                fromStationName = startStation.name,
                                toStationName = endStation.name,
                                lineId = null,
                                mode = null,
                                durationMinutes = 30,
                                sequenceNumber = 1
                            )
                        ),
                        totalDurationMinutes = 30,
                        transfersCount = 0,
                        label = "Pěší trasa (Bez spojení)",
                        walkDistanceMeters = 2000
                    )
                )
            }
        }

        return options.take(3)
    }

    private fun runDijkstra(
        startId: String,
        endId: String,
        edges: List<RoutingEdge>,
        transferPenalty: Double,
        preferMetro: Boolean = false
    ): List<RoutingEdge>? {
        val openSet = PriorityQueue<DijkstraNode>()
        val closedSet = mutableSetOf<Pair<String, String?>>() // Pair of (StationId, LineId)

        // Add initial states (all lines departing from startId)
        openSet.add(DijkstraNode(startId, null, 0.0, null, null))

        while (openSet.isNotEmpty()) {
            val current = openSet.poll()

            if (current.stationId == endId) {
                // Found path! Reconstruct
                return reconstructPath(current)
            }

            val stateKey = Pair(current.stationId, current.currentLineId)
            if (closedSet.contains(stateKey)) continue
            closedSet.add(stateKey)

            // Explore neighbors
            val outgoingEdges = edges.filter { it.fromStationId == current.stationId }
            for (edge in outgoingEdges) {
                var weight = edge.durationMinutes

                // Apply transfer penalties
                if (current.currentLineId != null && edge.lineId != null && current.currentLineId != edge.lineId) {
                    weight += transferPenalty
                }

                // If we prefer metro, discount metro edges slightly
                if (preferMetro && edge.mode == TransportMode.METRO) {
                    weight *= 0.8
                }

                val nextNode = DijkstraNode(
                    stationId = edge.toStationId,
                    currentLineId = edge.lineId,
                    gScore = current.gScore + weight,
                    parent = current,
                    edgeUsed = edge
                )

                openSet.add(nextNode)
            }
        }

        return null
    }

    private fun reconstructPath(node: DijkstraNode): List<RoutingEdge> {
        val path = mutableListOf<RoutingEdge>()
        var curr: DijkstraNode? = node
        while (curr?.parent != null) {
            curr.edgeUsed?.let { path.add(0, it) }
            curr = curr.parent
        }
        return path
    }

    private fun buildRouteOption(
        edges: List<RoutingEdge>,
        label: String,
        baseWalkDistance: Int
    ): RouteOption {
        val segments = mutableListOf<RouteSegment>()
        var seq = 1

        var currentSegmentFrom: String? = null
        var currentLineId: String? = null
        var currentMode: TransportMode? = null
        var currentDuration = 0.0

        for (edge in edges) {
            if (edge.lineId == null) {
                // It's a walk/transfer
                if (currentSegmentFrom != null) {
                    // Flush current active segment
                    val fromStation = TransportNetworkData.stations.find { it.id == currentSegmentFrom }?.name ?: currentSegmentFrom
                    val toStation = TransportNetworkData.stations.find { it.id == edge.fromStationId }?.name ?: edge.fromStationId
                    segments.add(
                        RouteSegment(
                            fromStationName = fromStation,
                            toStationName = toStation,
                            lineId = currentLineId,
                            mode = currentMode,
                            durationMinutes = Math.round(currentDuration).toInt(),
                            sequenceNumber = seq++
                        )
                    )
                }
                // Write walking segment
                val fromSt = TransportNetworkData.stations.find { it.id == edge.fromStationId }?.name ?: edge.fromStationId
                val toSt = TransportNetworkData.stations.find { it.id == edge.toStationId }?.name ?: edge.toStationId
                segments.add(
                    RouteSegment(
                        fromStationName = fromSt,
                        toStationName = toSt,
                        lineId = null,
                        mode = null,
                        durationMinutes = Math.round(edge.durationMinutes).toInt(),
                        sequenceNumber = seq++
                    )
                )
                currentSegmentFrom = null
                currentLineId = null
                currentMode = null
                currentDuration = 0.0
            } else {
                // Regular transit edge
                if (currentSegmentFrom == null) {
                    currentSegmentFrom = edge.fromStationId
                    currentLineId = edge.lineId
                    currentMode = edge.mode
                    currentDuration = edge.durationMinutes
                } else if (edge.lineId == currentLineId) {
                    currentDuration += edge.durationMinutes
                } else {
                    // Line changed, flush and start new
                    val fromStation = TransportNetworkData.stations.find { it.id == currentSegmentFrom }?.name ?: currentSegmentFrom
                    val toStation = TransportNetworkData.stations.find { it.id == edge.fromStationId }?.name ?: edge.fromStationId
                    segments.add(
                        RouteSegment(
                            fromStationName = fromStation,
                            toStationName = toStation,
                            lineId = currentLineId,
                            mode = currentMode,
                            durationMinutes = Math.round(currentDuration).toInt(),
                            sequenceNumber = seq++
                        )
                    )
                    currentSegmentFrom = edge.fromStationId
                    currentLineId = edge.lineId
                    currentMode = edge.mode
                    currentDuration = edge.durationMinutes
                }
            }
        }

        // Flush last active segment
        if (currentSegmentFrom != null) {
            val lastEdge = edges.last()
            val fromStation = TransportNetworkData.stations.find { it.id == currentSegmentFrom }?.name ?: currentSegmentFrom
            val toStation = TransportNetworkData.stations.find { it.id == lastEdge.toStationId }?.name ?: lastEdge.toStationId
            segments.add(
                RouteSegment(
                    fromStationName = fromStation,
                    toStationName = toStation,
                    lineId = currentLineId,
                    mode = currentMode,
                    durationMinutes = Math.round(currentDuration).toInt(),
                    sequenceNumber = seq++
                )
            )
        }

        val totalDuration = segments.sumOf { it.durationMinutes }
        val transfersCount = countTransfers(edges)

        return RouteOption(
            segments = segments,
            totalDurationMinutes = totalDuration,
            transfersCount = transfersCount,
            label = label,
            walkDistanceMeters = baseWalkDistance + (transfersCount * 150)
        )
    }

    private fun countTransfers(edges: List<RoutingEdge>): Int {
        var transfers = 0
        var currentLineId: String? = null
        for (edge in edges) {
            if (edge.lineId != null) {
                if (currentLineId != null && currentLineId != edge.lineId) {
                    transfers++
                }
                currentLineId = edge.lineId
            }
        }
        return transfers
    }
}
