package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.core.model.Ticket
import com.example.core.model.TicketState

class Converters {
    @TypeConverter
    fun toState(value: String): TicketState {
        return try {
            TicketState.valueOf(value)
        } catch (e: Exception) {
            TicketState.AVAILABLE
        }
    }

    @TypeConverter
    fun fromState(state: TicketState): String {
        return state.name
    }
}

@Database(entities = [Ticket::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun ticketDao(): TicketDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "praha_mhd_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
