package com.example.data.repository

import com.example.core.model.Ticket
import com.example.core.model.TicketState
import com.example.data.local.TicketDao
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class TicketRepository(private val ticketDao: TicketDao) {

    val allTickets: Flow<List<Ticket>> = ticketDao.getAllTickets()

    suspend fun getTicketById(id: String): Ticket? {
        return ticketDao.getTicketById(id)
    }

    suspend fun insertTicket(ticket: Ticket) {
        ticketDao.insertTicket(ticket)
    }

    suspend fun updateTicket(ticket: Ticket) {
        ticketDao.updateTicket(ticket)
    }

    suspend fun clearAll() {
        ticketDao.clearAllTickets()
    }

    /**
     * Purchases a ticket in demo mode.
     */
    suspend fun buyTicket(name: String, durationMinutes: Int, priceCzk: Int): Ticket {
        val ticket = Ticket(
            id = UUID.randomUUID().toString(),
            name = name,
            durationMinutes = durationMinutes,
            priceCzk = priceCzk,
            state = TicketState.AVAILABLE,
            purchaseTimestamp = System.currentTimeMillis(),
            qrCodePayload = "PRAHA_PID_DEMO_${UUID.randomUUID().toString().take(8).uppercase()}"
        )
        ticketDao.insertTicket(ticket)
        return ticket
    }

    /**
     * Triggers the 1-minute activation process.
     */
    suspend fun activateTicket(id: String) {
        val ticket = ticketDao.getTicketById(id) ?: return
        if (ticket.state == TicketState.AVAILABLE) {
            val updated = ticket.copy(
                state = TicketState.ACTIVATING,
                activationTimestamp = System.currentTimeMillis()
            )
            ticketDao.updateTicket(updated)
        }
    }

    /**
     * Updates and drives ticket state transitions based on simulated or current clock.
     * Activates tickets after 1 minute, expires them after duration expires.
     */
    suspend fun processTicketTransitions(currentTime: Long) {
        // Since we retrieve tickets from DAO, we can update any activating or active tickets whose status has changed.
        // Let's do this directly in the AppViewModel for simplicity and responsive reactive flow, or handle updates here.
    }
}
