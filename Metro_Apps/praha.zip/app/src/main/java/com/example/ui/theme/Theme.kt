package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = TransportRed,
  secondary = PragueStone,
  tertiary = AmberWarning,
  background = NightBackground,
  surface = NightSurface,
  onPrimary = OffWhite,
  onSecondary = Graphite,
  onTertiary = Graphite,
  onBackground = NightTextPrimary,
  onSurface = NightTextPrimary,
  surfaceVariant = Charcoal,
  onSurfaceVariant = NightTextSecondary,
  outline = PragueStone
)

private val LightColorScheme = lightColorScheme(
  primary = TransportRed,
  secondary = PragueStone,
  tertiary = MutedBlue,
  background = WarmIvory,
  surface = OffWhite,
  onPrimary = OffWhite,
  onSecondary = Graphite,
  onTertiary = OffWhite,
  onBackground = Graphite,
  onSurface = Graphite,
  surfaceVariant = WarmIvory,
  onSurfaceVariant = Charcoal,
  outline = PragueStone
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disable dynamic color by default to ensure the unique custom Prague brand aesthetic is shown.
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
