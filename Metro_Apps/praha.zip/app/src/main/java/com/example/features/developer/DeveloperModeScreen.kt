package com.example.features.developer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DeveloperModeScreen(viewModel: AppViewModel) {
    val simTime by viewModel.simTime.collectAsState()
    val isPaused by viewModel.isPaused.collectAsState()
    val speed by viewModel.simSpeed.collectAsState()
    val events by viewModel.simEvents.collectAsState()

    val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val simTimeStr = formatter.format(Date(simTime))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.goBack() }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Zpět",
                    tint = Graphite
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "VÝVOJÁŘSKÝ REŽIM (SIMULÁTOR)",
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = Graphite,
                modifier = Modifier.testTag("dev_mode_header")
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // --- TIME CONTROLLER PANEL ---
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite, RoundedCornerShape(4.dp))
                        .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "VIRTUÁLNÍ ČAS SIMULACE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = Graphite.copy(alpha = 0.5f),
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = simTimeStr,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = Graphite,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Buttons (Pause/Play, Multipliers)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Pause/Play Toggle Button
                        Button(
                            onClick = { viewModel.togglePauseSim() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPaused) RestrainedGreen else TransportRed
                            ),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Icon(
                                imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isPaused) "SPUSTIT" else "POZASTAVIT",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        // Speeds Multiplier Row
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(1, 10, 60).forEach { s ->
                                val active = speed == s
                                Box(
                                    modifier = Modifier
                                        .background(
                                            color = if (active) Graphite else PragueStone.copy(alpha = 0.3f),
                                            shape = RoundedCornerShape(2.dp)
                                        )
                                        .border(1.dp, Graphite, RoundedCornerShape(2.dp))
                                        .clickable { viewModel.setSimSpeed(s) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "${s}x",
                                        color = if (active) Color.White else Graphite,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // --- SIMULATOR LOGS (TERMINAL OVERLAY) ---
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Charcoal, RoundedCornerShape(4.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = "TERMINÁLOVÝ LOG UDÁLOSTÍ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = WarmIvory,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Simulated Terminal Console Box
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                            .background(Color.Black, RoundedCornerShape(2.dp))
                            .border(1.dp, PragueStone.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
                            .padding(10.dp)
                    ) {
                        LazyColumn(
                            reverseLayout = true,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(events.size) { index ->
                                // Reverse index to see newest first at the top
                                val e = events[events.size - 1 - index]
                                val timeText = formatter.format(Date(e.timestamp))
                                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                    Text(
                                        text = "[$timeText] ",
                                        color = AmberWarning,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${e.eventType}: ${e.message}",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // --- TEST DEMO INCIDENT DRIVER ---
            item {
                Button(
                    onClick = { viewModel.generateDemoDisruption() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TransportRed),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CrisisAlert, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SIMULOVAT MIMOŘÁDNOST (PID)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
