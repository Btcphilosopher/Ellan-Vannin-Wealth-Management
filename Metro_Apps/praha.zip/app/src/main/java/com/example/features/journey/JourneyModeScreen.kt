package com.example.features.journey

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.TransportMode
import com.example.ui.AppViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun JourneyModeScreen(viewModel: AppViewModel) {
    val activeJourney by viewModel.activeJourney.collectAsState()
    val activeSegmentIndex by viewModel.activeSegmentIndex.collectAsState()
    val activeSegmentProgress by viewModel.activeSegmentProgress.collectAsState()
    val simTime by viewModel.simTime.collectAsState()

    // Blinking pulsing indicator animation for active travel
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    if (activeJourney == null) {
        Box(
            modifier = Modifier.fillMaxSize().background(WarmIvory),
            contentAlignment = Alignment.Center
        ) {
            Text("Žádná aktivní cesta", color = Graphite, fontWeight = FontWeight.Bold)
        }
        return
    }

    val journey = activeJourney!!
    val currentSegment = journey.segments.getOrNull(activeSegmentIndex)

    val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
    val arrivalTimeStr = formatter.format(Date(simTime + (journey.totalDurationMinutes * 60 * 1000)))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmIvory)
    ) {
        // --- LIVE ACTIVE HEADER ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Graphite)
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(TransportRed)
                            .alpha(pulseAlpha)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NYNÍ JEDETE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 2.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .background(RestrainedGreen, RoundedCornerShape(2.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "AKTIVNÍ CESTOVNÍ REŽIM",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Destination and line pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (currentSegment?.lineId != null) {
                    val pillColor = when (currentSegment.mode) {
                        TransportMode.METRO -> when (currentSegment.lineId) {
                            "A" -> MetroLineA
                            "B" -> MetroLineB
                            "C" -> MetroLineC
                            else -> TransportRed
                        }
                        TransportMode.TRAM -> TransportRed
                        else -> MutedBlue
                    }
                    Box(
                        modifier = Modifier
                            .background(pillColor, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = currentSegment.lineId,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                }

                Text(
                    text = currentSegment?.toStationName ?: "Neznámý cíl",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    modifier = Modifier.testTag("journey_active_destination")
                )
            }
        }

        // --- SUB-BOARD SUMMARY ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(horizontal = 24.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ZBÝVÁ", fontSize = 10.sp, color = Graphite.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                Text("${journey.totalDurationMinutes} MIN", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Graphite)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("PŘESTUPY", fontSize = 10.sp, color = Graphite.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                Text("${journey.transfersCount}", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Graphite)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("PŘÍJEZD", fontSize = 10.sp, color = Graphite.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                Text(arrivalTimeStr, fontSize = 15.sp, fontWeight = FontWeight.Black, color = RestrainedGreen, fontFamily = FontFamily.Monospace)
            }
        }

        // --- SCHEMATIC VERTICAL POSTS VIEW ---
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "PRŮBĚH TRASY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = Graphite.copy(alpha = 0.5f)
                )
            }

            items(journey.segments.size) { index ->
                val seg = journey.segments[index]
                val isCurrent = index == activeSegmentIndex
                val isPassed = index < activeSegmentIndex

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .alpha(if (isPassed) 0.5f else 1.0f),
                    verticalAlignment = Alignment.Top
                ) {
                    // Vertical Progress Dot and Rail column
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(36.dp)
                    ) {
                        val nodeColor = when {
                            isCurrent -> TransportRed
                            isPassed -> PragueStone
                            else -> Graphite
                        }

                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(nodeColor)
                                .border(2.dp, Color.White, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCurrent) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(Color.White, RoundedCornerShape(5.dp))
                                )
                            }
                        }

                        // Connective rail drawing
                        if (index < journey.segments.size - 1) {
                            val railColor = if (isPassed) PragueStone else Graphite.copy(alpha = 0.5f)
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(60.dp)
                                    .background(railColor)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Station / Segment Text Info
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = seg.fromStationName,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = Graphite
                        )
                        
                        Text(
                            text = if (seg.lineId != null) "Spoj ${seg.lineId} — ${seg.durationMinutes} min" else "Pěší přesun — ${seg.durationMinutes} min",
                            fontSize = 12.sp,
                            color = Graphite.copy(alpha = 0.6f)
                        )

                        if (isCurrent) {
                            Spacer(modifier = Modifier.height(8.dp))
                            // Progress bar
                            LinearProgressIndicator(
                                progress = activeSegmentProgress,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = TransportRed,
                                trackColor = PragueStone
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Následující stanice: ${seg.toStationName}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TransportRed
                            )
                        } else if (!isPassed) {
                            Text(
                                text = "Příští stanice: ${seg.toStationName}",
                                fontSize = 12.sp,
                                color = Graphite.copy(alpha = 0.4f)
                            )
                        } else {
                            Text(
                                text = "Dokončeno",
                                fontSize = 12.sp,
                                color = RestrainedGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // --- STOP NAVIGATION BUTTON ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(16.dp)
        ) {
            Button(
                onClick = { viewModel.stopJourney() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("stop_journey_button"),
                colors = ButtonDefaults.buttonColors(containerColor = TransportRed),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "UKONČIT CESTU",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }
    }
}
