package com.example.features.account

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransportNetworkData
import com.example.ui.AppViewModel
import com.example.ui.theme.*

@Composable
fun AccountScreen(viewModel: AppViewModel) {
    val tickets by viewModel.tickets.collectAsState()
    val favorites by viewModel.favoriteStations.collectAsState()

    val activeTicketsCount = tickets.count { it.state == com.example.core.model.TicketState.ACTIVE }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.goBack() }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Zpět",
                    tint = Graphite
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "MŮJ ÚČET (LÍTAČKA)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = Graphite,
                modifier = Modifier.testTag("account_header_title")
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- USER CARD (LÍTAČKA COUPE) ---
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Graphite, RoundedCornerShape(4.dp)),
                    colors = CardDefaults.cardColors(containerColor = Graphite)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "LÍTAČKA KARTA",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = WarmIvory,
                                letterSpacing = 2.sp
                            )
                            Icon(
                                imageVector = Icons.Default.Contactless,
                                contentDescription = "Bezkontaktní",
                                tint = WarmIvory,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = "TOMÁŠ NOVÁK",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = "Identifikátor: 182-948-291",
                            fontSize = 12.sp,
                            color = WarmIvory.copy(alpha = 0.6f)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Box(
                            modifier = Modifier
                                .background(RestrainedGreen, RoundedCornerShape(2.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "OVĚŘENÝ PROFIL",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // --- MOJE PŘEDPLATNÉ (LONG TERM PASS) ---
            item {
                AccountSectionCard(
                    title = "DLOUHODOBÉ KUPÓNY (PŘEDPLATNÉ)",
                    icon = Icons.Default.CardMembership
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(OffWhite, RoundedCornerShape(2.dp))
                            .border(1.dp, PragueStone, RoundedCornerShape(2.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Roční kupón — Praha (P, 0, B)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Graphite
                            )
                            Text(
                                text = "AKTIVNÍ",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = RestrainedGreen
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Platnost do: 31. 12. 2026",
                            fontSize = 12.sp,
                            color = Graphite.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            // --- TICKETS SUMMARY ---
            item {
                AccountSectionCard(
                    title = "MOJE JÍZDENKY",
                    icon = Icons.Default.QrCode
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Aktivní jízdenky: $activeTicketsCount",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Graphite
                        )
                        Text(
                            text = "Celkem v paměti: ${tickets.size}",
                            fontSize = 13.sp,
                            color = Graphite.copy(alpha = 0.6f)
                        )
                    }
                }
            }

            // --- TRIP HISTORY (HISTORIE JÍZD) ---
            item {
                AccountSectionCard(
                    title = "HISTORIE NEDÁVNÝCH JÍZD",
                    icon = Icons.Default.History
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TripHistoryItemRow(
                            from = "Staroměstská",
                            to = "Hlavní nádraží",
                            date = "Včera, 18:42",
                            mode = "Metro A -> C"
                        )
                        TripHistoryItemRow(
                            from = "Dejvická",
                            to = "Můstek",
                            date = "18. září, 09:15",
                            mode = "Metro A"
                        )
                        TripHistoryItemRow(
                            from = "Nádraží Veleslavín",
                            to = "Letiště Praha",
                            date = "15. září, 14:30",
                            mode = "Trolejbus 59"
                        )
                    }
                }
            }

            // --- FAVORITE STATIONS GRID ---
            item {
                AccountSectionCard(
                    title = "OBLÍBENÉ ZASTÁVKY",
                    icon = Icons.Default.Star
                ) {
                    if (favorites.isEmpty()) {
                        Text("Nemáte uloženy žádné oblíbené zastávky.", fontSize = 13.sp, color = Graphite.copy(alpha = 0.5f))
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            favorites.forEach { fid ->
                                val name = TransportNetworkData.stations.find { it.id == fid }?.name ?: fid
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(OffWhite, RoundedCornerShape(2.dp))
                                        .border(1.dp, PragueStone, RoundedCornerShape(2.dp))
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Graphite)
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "Oblíbené",
                                        tint = AmberWarning,
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable { viewModel.toggleFavorite(fid) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AccountSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = Graphite.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = Graphite.copy(alpha = 0.6f)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        content()
    }
}

@Composable
fun TripHistoryItemRow(
    from: String,
    to: String,
    date: String,
    mode: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(OffWhite, RoundedCornerShape(2.dp))
            .border(1.dp, PragueStone.copy(alpha = 0.5f), RoundedCornerShape(2.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "$from → $to",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Graphite
            )
            Text(
                text = "Přes: $mode",
                fontSize = 11.sp,
                color = Graphite.copy(alpha = 0.6f)
            )
        }

        Text(
            text = date,
            fontSize = 11.sp,
            color = Graphite.copy(alpha = 0.5f)
        )
    }
}
