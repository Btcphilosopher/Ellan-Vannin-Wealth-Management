package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Prague Transport Palette (PID & Heritage inspired)
val WarmIvory = Color(0xFFFAF7F2)      // Base light background
val PragueStone = Color(0xFFDCD6CD)    // Borders, subtle dividers, cards
val TransportRed = Color(0xFFC8102E)   // Primary red for trams, metro C, branding
val Graphite = Color(0xFF1E2022)       // Dark background or text
val Charcoal = Color(0xFF2A2C2E)       // Dark cards or secondary elements
val OffWhite = Color(0xFFFAFAFA)       // High-contrast clean backgrounds
val MutedBlue = Color(0xFF2E6B9E)      // Train / River ferry info
val RestrainedGreen = Color(0xFF2C6B3F) // Success / Accessibility / Safe indicator
val AmberWarning = Color(0xFFE28413)   // Warning, delays, funicular accent

// Metro-specific exact colors (DPP standards)
val MetroLineA = Color(0xFF009348)     // Green
val MetroLineB = Color(0xFFF2A900)     // Yellow / Amber
val MetroLineC = Color(0xFFC8102E)     // Red

// Night specific shades
val NightBackground = Color(0xFF121314) // Deep carbon charcoal
val NightSurface = Color(0xFF1E2022)    // Dark graphite
val NightTextPrimary = Color(0xFFFAF7F2)
val NightTextSecondary = Color(0xFFB5AF9D)
