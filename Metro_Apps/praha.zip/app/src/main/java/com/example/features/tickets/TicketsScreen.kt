package com.example.features.tickets

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Ticket
import com.example.core.model.TicketState
import com.example.data.TransportNetworkData
import com.example.ui.AppViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TicketsScreen(viewModel: AppViewModel) {
    val tickets by viewModel.tickets.collectAsState()
    val simTime by viewModel.simTime.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: Nová jízdenka, 1: Moje jízdenky (X)
    var selectedProductToBuy by remember { mutableStateOf<Ticket?>(null) }

    val activeTicketsCount = tickets.count { it.state == TicketState.ACTIVE || it.state == TicketState.ACTIVATING }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "JÍZDENKY",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = Graphite
            )

            // Clear all tickets (simulation reload tool)
            TextButton(onClick = { viewModel.clearAllTickets() }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp), tint = TransportRed)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Smazat jízdenky", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TransportRed)
                }
            }
        }

        // --- TAB SELECTOR ---
        TabRow(
            selectedTabIndex = activeTab,
            containerColor = OffWhite,
            contentColor = TransportRed,
            indicator = { tabPositions ->
                TabRowDefaults.Indicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                    color = TransportRed
                )
            }
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Koupit jízdenku", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Moje jízdenky", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        if (activeTicketsCount > 0) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .background(TransportRed, RoundedCornerShape(9.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = activeTicketsCount.toString(),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            )
        }

        // --- TAB PANEL ---
        if (activeTab == 0) {
            // Purchase catalog
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 20.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        text = "JEDNORÁZOVÉ ELEKTRONICKÉ JÍZDENKY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = Graphite.copy(alpha = 0.6f)
                    )
                }

                val catalog = TransportNetworkData.fareProducts
                items(catalog.size) { index ->
                    val product = catalog[index]
                    FareCatalogCard(
                        product = product,
                        onClick = { selectedProductToBuy = product }
                    )
                }

                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp)
                            .border(1.dp, PragueStone.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            .background(WarmIvory)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "POUČENÍ O PLATBÁCH",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = Graphite
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Jedná se o prototyp. Platby probíhají přes DemoPaymentProvider a lístky jsou generovány systémem DemoTicketProvider. Jsou určeny výhradně pro demonstrační účely.",
                            fontSize = 11.sp,
                            color = Graphite.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        } else {
            // My bought tickets list
            if (tickets.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = PragueStone
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Nemáte žádné zakoupené jízdenky.",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Graphite.copy(alpha = 0.5f),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Zakupte si jízdenku v záložce 'Koupit jízdenku'.",
                            fontSize = 12.sp,
                            color = Graphite.copy(alpha = 0.4f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 20.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(tickets.size) { index ->
                        val ticket = tickets[index]
                        MyTicketItemRow(
                            ticket = ticket,
                            simTime = simTime,
                            onActivate = { viewModel.activateTicket(ticket.id) }
                        )
                    }
                }
            }
        }
    }

    // --- DIALOG FOR PURCHASE CONFIRMATION ---
    selectedProductToBuy?.let { product ->
        AlertDialog(
            onDismissRequest = { selectedProductToBuy = null },
            title = {
                Text(
                    text = "POTVRDIT NÁKUP",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = Graphite,
                    letterSpacing = 1.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Chcete zakoupit jízdenku '${product.name}' za ${product.priceCzk} Kč?",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Graphite
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Transakce bude schválena v simulátoru prostřednictvím DemoPaymentProvider bez reálného poplatku.",
                        fontSize = 11.sp,
                        color = Graphite.copy(alpha = 0.6f)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.buyTicket(product)
                        selectedProductToBuy = null
                        activeTab = 1 // Switch to my tickets list
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TransportRed),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text("KOUPIT", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedProductToBuy = null }) {
                    Text("ZRUŠIT", color = Graphite)
                }
            },
            containerColor = OffWhite,
            shape = RoundedCornerShape(4.dp)
        )
    }
}

@Composable
fun FareCatalogCard(
    product: Ticket,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .testTag("fare_product_${product.name.replace(" ", "_").lowercase()}"),
        colors = CardDefaults.cardColors(containerColor = OffWhite)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = product.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Graphite,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Platnost v pásmech P, 0, B (Praha)",
                    fontSize = 12.sp,
                    color = Graphite.copy(alpha = 0.6f)
                )
            }

            Text(
                text = "${product.priceCzk} Kč",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = TransportRed
            )
        }
    }
}

@Composable
fun MyTicketItemRow(
    ticket: Ticket,
    simTime: Long,
    onActivate: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (ticket.state == TicketState.ACTIVE) 2.dp else 1.dp,
                color = when (ticket.state) {
                    TicketState.ACTIVE -> TransportRed
                    TicketState.ACTIVATING -> AmberWarning
                    else -> PragueStone
                },
                shape = RoundedCornerShape(4.dp)
            )
            .clickable { expanded = !expanded }
            .testTag("ticket_row_${ticket.state.name.lowercase()}"),
        colors = CardDefaults.cardColors(
            containerColor = if (ticket.state == TicketState.ACTIVE) OffWhite else MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = ticket.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = Graphite
                    )

                    // Ticket validity duration text / status badge
                    val subtitleText = when (ticket.state) {
                        TicketState.AVAILABLE -> "Zakoupeno, připraveno k aktivaci"
                        TicketState.ACTIVATING -> "Aktivace zahájena..."
                        TicketState.ACTIVE -> {
                            val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
                            val startStr = formatter.format(Date(ticket.activeStartTimestamp ?: 0L))
                            val endStr = formatter.format(Date((ticket.activeStartTimestamp ?: 0L) + ticket.durationMinutes * 60 * 1000))
                            "Platnost: $startStr — $endStr"
                        }
                        TicketState.EXPIRED -> "Prošlá jízdenka (Konec platnosti)"
                        else -> "Zrušeno"
                    }
                    Text(text = subtitleText, fontSize = 12.sp, color = Graphite.copy(alpha = 0.6f))
                }

                // Dynamic Action/Status Button or Badge
                when (ticket.state) {
                    TicketState.AVAILABLE -> {
                        Button(
                            onClick = { onActivate() },
                            colors = ButtonDefaults.buttonColors(containerColor = RestrainedGreen),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("AKTIVAT", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                    TicketState.ACTIVATING -> {
                        val elapsedVirtualSecs = (simTime - (ticket.activationTimestamp ?: 0L)) / 1000
                        val remainingSecs = maxOf(0L, 60L - elapsedVirtualSecs)

                        Column(horizontalAlignment = Alignment.End) {
                            CircularProgressIndicator(
                                progress = remainingSecs / 60.0f,
                                modifier = Modifier.size(20.dp),
                                color = AmberWarning,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Lhůta: ${remainingSecs}s",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberWarning
                            )
                        }
                    }
                    TicketState.ACTIVE -> {
                        val elapsedMs = simTime - (ticket.activeStartTimestamp ?: 0L)
                        val totalMs = ticket.durationMinutes.toLong() * 60 * 1000
                        val remainingMs = maxOf(0L, totalMs - elapsedMs)
                        val remMin = remainingMs / (60 * 1000)
                        val remSec = (remainingMs / 1000) % 60

                        Column(horizontalAlignment = Alignment.End) {
                            Box(
                                modifier = Modifier
                                    .background(RestrainedGreen, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "AKTIVNÍ",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = String.format("%02d:%02d", remMin, remSec),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = RestrainedGreen,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    TicketState.EXPIRED -> {
                        Box(
                            modifier = Modifier
                                .background(PragueStone, RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "PROŠLÁ",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Graphite.copy(alpha = 0.6f)
                            )
                        }
                    }
                    else -> {}
                }
            }

            // --- EXPANDED VIEW (DIGITAL TICKET DETAIL SCREEN) ---
            AnimatedVisibility(
                visible = expanded || ticket.state == TicketState.ACTIVE,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                        .border(1.dp, PragueStone.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .background(WarmIvory)
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Title PRAGUE WAYFINDING
                    Text(
                        text = "PRAHA MĚSTSKÁ DOPRAVA",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = TransportRed,
                        letterSpacing = 1.5.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // QR Code Placeholder in Central European Industrial Precision style
                    Box(
                        modifier = Modifier
                            .size(150.dp)
                            .background(Color.White)
                            .border(2.dp, Graphite, RoundedCornerShape(4.dp))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            // Draw dynamic pseudo-QR code in high-contrast lines
                            Image(
                                imageVector = Icons.Default.QrCode2,
                                contentDescription = "QR kód jízdenky",
                                modifier = Modifier.size(110.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = ticket.qrCodePayload.take(12),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Graphite.copy(alpha = 0.6f),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "PID JÍZDNÍ DOKLAD",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Graphite
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Cena", fontSize = 10.sp, color = Graphite.copy(alpha = 0.5f))
                            Text("${ticket.priceCzk} Kč", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Graphite)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Pásma", fontSize = 10.sp, color = Graphite.copy(alpha = 0.5f))
                            Text("P, 0, B", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Graphite)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Doba", fontSize = 10.sp, color = Graphite.copy(alpha = 0.5f))
                            Text("${ticket.durationMinutes} min", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Graphite)
                        }
                    }
                }
            }
        }
    }
}
