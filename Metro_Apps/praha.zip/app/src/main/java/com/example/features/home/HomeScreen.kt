package com.example.features.home

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.TransportMode
import com.example.data.TransportNetworkData
import com.example.ui.AppViewModel
import com.example.ui.Screen
import com.example.ui.theme.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(viewModel: AppViewModel) {
    val originId by viewModel.originId.collectAsState()
    val destinationId by viewModel.destinationId.collectAsState()
    val favorites by viewModel.favoriteStations.collectAsState()
    val liveVehicles by viewModel.liveVehicles.collectAsState()

    val stationsList = TransportNetworkData.stations

    var showOriginSelect by remember { mutableStateOf(false) }
    var showDestSelect by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // --- HEADER ---
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "PRAHA",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    color = TransportRed,
                    modifier = Modifier.testTag("home_header_title")
                )
                Text(
                    text = "MĚSTSKÁ DOPRAVA",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 4.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
        }

        // --- QUICK LETIŠTĚ LINK (Airport Actions) ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MutedBlue.copy(alpha = 0.12f))
                    .border(1.dp, MutedBlue.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    .clickable { viewModel.setupAirportJourney(isFromAirport = false) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.FlightTakeoff,
                    contentDescription = "Letiště Václava Havla",
                    tint = MutedBlue,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "EXPRES NA LETIŠTĚ",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MutedBlue,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Rychlé vyhledání trasy z centra na Letiště Praha",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                    )
                }
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Přejít",
                    tint = MutedBlue,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // --- SEARCH PANEL ---
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(4.dp))
                    .border(2.dp, Graphite, RoundedCornerShape(4.dp))
                    .padding(16.dp)
            ) {
                // FROM (ODKUD)
                Text(
                    text = "ODKUD",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = Graphite.copy(alpha = 0.6f)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { showOriginSelect = true }
                        .border(1.dp, PragueStone, RoundedCornerShape(2.dp))
                        .padding(12.dp)
                ) {
                    val origName = stationsList.find { it.id == originId }?.name ?: "Vyberte stanici"
                    Text(
                        text = origName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Graphite
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // SWAP BUTTON
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .clickable { viewModel.swapStations() }
                        .border(1.dp, Graphite, RoundedCornerShape(4.dp))
                        .background(WarmIvory)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapVert,
                        contentDescription = "Prohodit stanice",
                        tint = TransportRed,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // TO (KAM)
                Text(
                    text = "KAM",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = Graphite.copy(alpha = 0.6f)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { showDestSelect = true }
                        .border(1.dp, PragueStone, RoundedCornerShape(2.dp))
                        .padding(12.dp)
                ) {
                    val destName = stationsList.find { it.id == destinationId }?.name ?: "Vyberte stanici"
                    Text(
                        text = destName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Graphite
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = "Čas odjezdu",
                            tint = Graphite.copy(alpha = 0.6f),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "TEĎ",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Graphite
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { viewModel.toggleWheelchairFilter() }
                    ) {
                        Checkbox(
                            checked = viewModel.wheelchairFilter.collectAsState().value,
                            onCheckedChange = { viewModel.toggleWheelchairFilter() },
                            colors = CheckboxDefaults.colors(checkedColor = RestrainedGreen)
                        )
                        Text(
                            text = "Bezbariérové",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Graphite
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.navigateTo(Screen.SPOJENI) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("home_search_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = TransportRed),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "VYHLEDAT SPOJENÍ",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = Color.White
                    )
                }
            }
        }

        // --- FAVORITES (OBLÍBENÉ) ---
        item {
            Column {
                Text(
                    text = "OBLÍBENÉ STANICE",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    favorites.forEach { favId ->
                        val station = stationsList.find { it.id == favId }
                        if (station != null) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(OffWhite)
                                    .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
                                    .clickable {
                                        viewModel.setDestination(station.id)
                                        viewModel.navigateTo(Screen.SPOJENI)
                                    }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "Oblíbená",
                                        tint = AmberWarning,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = station.name,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Graphite
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- ODJEZDY V OKOLÍ ---
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(OffWhite, RoundedCornerShape(4.dp))
                    .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ODJEZDY V OKOLÍ",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp,
                        color = Graphite
                    )
                    Text(
                        text = "Live simulace",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = RestrainedGreen
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Metro Departure Card (A Staroměstská)
                NearbyDepartureItem(
                    lineLabel = "A",
                    lineColor = MetroLineA,
                    destination = "Nemocnice Motol",
                    minutesLeft = 2,
                    isAccessible = true,
                    platform = "Kolej 1"
                )

                Divider(color = PragueStone.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 10.dp))

                // Tram Departure Card (22)
                NearbyDepartureItem(
                    lineLabel = "22",
                    lineColor = TransportRed,
                    destination = "Bílá Hora",
                    minutesLeft = 4,
                    isAccessible = true,
                    platform = "Zast. Újezd"
                )

                Divider(color = PragueStone.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 10.dp))

                // Tram Departure Card (9)
                NearbyDepartureItem(
                    lineLabel = "9",
                    lineColor = TransportRed,
                    destination = "Nádraží Hostivař",
                    minutesLeft = 9,
                    isAccessible = false,
                    platform = "Zast. Můstek"
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Custom Animated Tram City Indicator
                TramAnimationIndicator()
            }
        }
    }

    // --- DIALOGS FOR SELECTING STATIONS ---
    if (showOriginSelect) {
        StationSelectionDialog(
            title = "Výchozí stanice (ODKUD)",
            stations = stationsList,
            onDismiss = { showOriginSelect = false },
            onSelect = {
                viewModel.setOrigin(it)
                showOriginSelect = false
            }
        )
    }

    if (showDestSelect) {
        StationSelectionDialog(
            title = "Cílová stanice (KAM)",
            stations = stationsList,
            onDismiss = { showDestSelect = false },
            onSelect = {
                viewModel.setDestination(it)
                showDestSelect = false
            }
        )
    }
}

@Composable
fun NearbyDepartureItem(
    lineLabel: String,
    lineColor: Color,
    destination: String,
    minutesLeft: Int,
    isAccessible: Boolean,
    platform: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            // Line Badge
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .background(lineColor, RoundedCornerShape(2.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = lineLabel,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = destination,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Graphite
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = platform,
                        fontSize = 12.sp,
                        color = Graphite.copy(alpha = 0.6f)
                    )
                    if (isAccessible) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.WheelchairPickup,
                            contentDescription = "Bezbariérový přístup",
                            tint = RestrainedGreen,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }

        // Minutes Remaining Countdown
        Text(
            text = "$minutesLeft min",
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            color = if (minutesLeft <= 2) TransportRed else Graphite
        )
    }
}

@Composable
fun TramAnimationIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "tram_animation")
    val offsetX by infiniteTransition.animateFloat(
        initialValue = -50f,
        targetValue = 280f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "tram_x"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(36.dp)
            .background(Graphite, RoundedCornerShape(2.dp))
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Rails line
            Divider(
                color = PragueStone.copy(alpha = 0.3f),
                thickness = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
            )

            // Animated Tram icon
            Row(
                modifier = Modifier
                    .offset(x = offsetX.dp)
                    .align(Alignment.CenterStart),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Tram,
                    contentDescription = "Jedoucí tramvaj",
                    tint = TransportRed,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Box(
                    modifier = Modifier
                        .size(4.dp)
                        .background(AmberWarning, RoundedCornerShape(50))
                )
            }
        }
    }
}

@Composable
fun StationSelectionDialog(
    title: String,
    stations: List<com.example.core.model.Station>,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = Graphite
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 350.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(stations.size) { index ->
                    val station = stations[index]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(station.id) }
                            .padding(vertical = 12.dp, horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val icon = when {
                            station.modes.contains(TransportMode.METRO) -> Icons.Default.Subway
                            station.modes.contains(TransportMode.TRAM) -> Icons.Default.Tram
                            station.modes.contains(TransportMode.PRIVOZ) -> Icons.Default.DirectionsBoat
                            else -> Icons.Default.DirectionsBus
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Graphite.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = station.name,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Graphite
                        )
                    }
                    Divider(color = PragueStone.copy(alpha = 0.3f))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Zavřít", color = TransportRed, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = OffWhite,
        shape = RoundedCornerShape(4.dp)
    )
}
