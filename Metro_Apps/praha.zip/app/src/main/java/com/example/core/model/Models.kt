package com.example.core.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- 1. TRANSPORT NETWORK MODELS ---

enum class TransportMode {
    METRO,
    TRAM,
    BUS,
    TROLEJBUS,
    VLAK,
    LANOVKA,
    PRIVOZ
}

data class Station(
    val id: String,
    val name: String,
    val modes: List<TransportMode>,
    val lat: Double,
    val lon: Double,
    val hasElevator: Boolean = false,
    val hasEscalator: Boolean = false,
    val isAccessible: Boolean = true,
    val facilities: List<String> = emptyList(),
    val exits: List<String> = emptyList(),
    val lines: List<String> = emptyList() // Lines serving this station
)

data class TransitLine(
    val id: String, // e.g. "A", "22", "119"
    val name: String,
    val mode: TransportMode,
    val colorHex: String,
    val stops: List<String>, // List of Station IDs
    val isNight: Boolean = false
)

// --- 2. ROUTING MODEL ---

data class RoutingEdge(
    val fromStationId: String,
    val toStationId: String,
    val lineId: String?, // Null means walking transfer
    val mode: TransportMode?, // Null means walking
    val durationMinutes: Double
)

data class RouteSegment(
    val fromStationName: String,
    val toStationName: String,
    val lineId: String?,
    val mode: TransportMode?,
    val durationMinutes: Int,
    val sequenceNumber: Int
)

data class RouteOption(
    val segments: List<RouteSegment>,
    val totalDurationMinutes: Int,
    val transfersCount: Int,
    val label: String, // e.g. "Nejrychlejší", "Nejméně přestupů", "Nejpohodlnější"
    val walkDistanceMeters: Int
)

// --- 3. TICKETS (PERSISTENT VIA ROOM) ---

enum class TicketState {
    AVAILABLE,
    ACTIVATING, // 1 minute activation delay
    ACTIVE,
    EXPIRED,
    CANCELLED
}

@Entity(tableName = "tickets")
data class Ticket(
    @PrimaryKey val id: String,
    val name: String, // e.g. "30 MINUT", "90 MINUT", "24 HODIN", "72 HODIN"
    val durationMinutes: Int,
    val priceCzk: Int,
    val state: TicketState = TicketState.AVAILABLE,
    val purchaseTimestamp: Long = System.currentTimeMillis(),
    val activationTimestamp: Long? = null, // When the user clicked "Aktivovat"
    val activeStartTimestamp: Long? = null, // After 1 min activation delay
    val qrCodePayload: String
)

// --- 4. VEHICLE TELEMETRY ---

data class Vehicle(
    val vehicleId: String,
    val routeId: String,
    val mode: TransportMode,
    val latitude: Double,
    val longitude: Double,
    val heading: Float,
    val speed: Double, // km/h
    val delayMinutes: Int,
    val occupancyPercent: Int, // e.g. 40
    val lowFloor: Boolean = true,
    val airConditioning: Boolean = true,
    val destination: String,
    val status: String // e.g. "Jedoucí", "Ve stanici", "Zpožděn"
)

// --- 5. DISRUPTIONS (MIMOŘÁDNOSTI) ---

enum class DisruptionSeverity {
    LOW,
    MEDIUM,
    HIGH
}

data class Disruption(
    val incidentId: String,
    val severity: DisruptionSeverity,
    val affectedRoutes: List<String>,
    val affectedStops: List<String>,
    val startTime: String,
    val expectedEnd: String,
    val title: String,
    val description: String,
    val alternativeRoutes: String
)

// --- 6. ARCHITECTURAL MUSEUM ---

data class ArchitecturalAsset(
    val id: String,
    val title: String,
    val category: String, // e.g. "Metro", "Historické tramvaje", "Bridges"
    val subtitle: String,
    val description: String,
    val location: String,
    val yearBuilt: String,
    val architect: String
)

// --- 7. SIMULATION LOG EVENTS ---

data class SimEvent(
    val timestamp: String,
    val eventType: String, // "VEHICLE_DEPARTED", "VEHICLE_ARRIVED", etc.
    val message: String
)
