package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.*
import com.example.core.routing.DijkstraRouter
import com.example.core.simulation.SimulationEngine
import com.example.data.TransportNetworkData
import com.example.data.repository.TicketRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Screen {
    HOME,
    MAP,
    SPOJENI,
    JIZDENKY,
    MORE,
    STATION_DETAIL,
    JOURNEY_MODE,
    NIGHT_MODE,
    PETRIN_LANOVKA,
    PRIVOZY,
    ARCHITECTURAL,
    MŮJ_ÚČET,
    MIMOŘÁDNOSTI,
    DEVELOPER_MODE
}

class AppViewModel(private val ticketRepository: TicketRepository) : ViewModel() {

    // --- NAVIGATION ---
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenBackstack = mutableListOf<Screen>()

    fun navigateTo(screen: Screen) {
        screenBackstack.add(_currentScreen.value)
        _currentScreen.value = screen
    }

    fun goBack(): Boolean {
        if (screenBackstack.isNotEmpty()) {
            _currentScreen.value = screenBackstack.removeAt(screenBackstack.size - 1)
            return true
        }
        return false
    }

    // --- SEARCH / ROUTING STATE ---
    private val _originId = MutableStateFlow("staromestska")
    val originId: StateFlow<String> = _originId.asStateFlow()

    private val _destinationId = MutableStateFlow("letiste")
    val destinationId: StateFlow<String> = _destinationId.asStateFlow()

    private val _wheelchairFilter = MutableStateFlow(false)
    val wheelchairFilter: StateFlow<Boolean> = _wheelchairFilter.asStateFlow()

    private val _routeOptions = MutableStateFlow<List<RouteOption>>(emptyList())
    val routeOptions: StateFlow<List<RouteOption>> = _routeOptions.asStateFlow()

    private val _selectedRoute = MutableStateFlow<RouteOption?>(null)
    val selectedRoute: StateFlow<RouteOption?> = _selectedRoute.asStateFlow()

    // --- STATION SCREEN STATE ---
    private val _selectedStationId = MutableStateFlow("staromestska")
    val selectedStationId: StateFlow<String> = _selectedStationId.asStateFlow()

    // --- JOURNEY MODE STATE ---
    private val _activeJourney = MutableStateFlow<RouteOption?>(null)
    val activeJourney: StateFlow<RouteOption?> = _activeJourney.asStateFlow()

    private val _activeSegmentIndex = MutableStateFlow(0)
    val activeSegmentIndex: StateFlow<Int> = _activeSegmentIndex.asStateFlow()

    private val _activeSegmentProgress = MutableStateFlow(0.0f) // 0.0 to 1.0
    val activeSegmentProgress: StateFlow<Float> = _activeSegmentProgress.asStateFlow()

    // --- TICKETS STATE ---
    val tickets: StateFlow<List<Ticket>> = ticketRepository.allTickets.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // --- FAVORITES ---
    private val _favoriteStations = MutableStateFlow(setOf("staromestska", "mustek", "hlavni_nadrazi", "letiste"))
    val favoriteStations: StateFlow<Set<String>> = _favoriteStations.asStateFlow()

    // --- NIGHT TIME TOGGLE ---
    private val _isNightTimeMode = MutableStateFlow(false)
    val isNightTimeMode: StateFlow<Boolean> = _isNightTimeMode.asStateFlow()

    // --- MAP LAYERS ---
    private val _mapLayers = MutableStateFlow(
        mapOf(
            TransportMode.METRO to true,
            TransportMode.TRAM to true,
            TransportMode.BUS to true,
            TransportMode.TROLEJBUS to true,
            TransportMode.VLAK to true,
            TransportMode.PRIVOZ to true,
            TransportMode.LANOVKA to true
        )
    )
    val mapLayers: StateFlow<Map<TransportMode, Boolean>> = _mapLayers.asStateFlow()

    // --- SIMULATION LINKING ---
    val simTime: StateFlow<Long> = SimulationEngine.simTime
    val isPaused: StateFlow<Boolean> = SimulationEngine.isPaused
    val simSpeed: StateFlow<Int> = SimulationEngine.simSpeed
    val liveVehicles: StateFlow<List<Vehicle>> = SimulationEngine.liveVehicles
    val simEvents: StateFlow<List<SimEvent>> = SimulationEngine.eventsLog

    // Coroutine Job for Simulation Loop
    private var simJob: Job? = null

    init {
        // Run routing calculation initially
        calculateRoutes()

        // Start background simulation ticker (updates once per real second)
        simJob = viewModelScope.launch {
            var lastTime = System.currentTimeMillis()
            while (true) {
                delay(1000)
                val now = System.currentTimeMillis()
                val elapsed = now - lastTime
                lastTime = now

                // Advance simulation engine
                SimulationEngine.tick(elapsed)

                // Process ticket countdown transitions based on simTime
                val currentSimTime = SimulationEngine.simTime.value
                tickets.value.forEach { t ->
                    if (t.state == TicketState.ACTIVATING) {
                        val actTime = t.activationTimestamp ?: 0L
                        // PID activation delay is 60 virtual seconds (1 minute)
                        val elapsedVirtualSecs = (currentSimTime - actTime) / 1000
                        if (elapsedVirtualSecs >= 60) {
                            val activated = t.copy(
                                state = TicketState.ACTIVE,
                                activeStartTimestamp = currentSimTime
                            )
                            ticketRepository.insertTicket(activated)
                            SimulationEngine.logEvent("TICKET_ACTIVATED", "Jízdenka '${t.name}' byla úspěšně aktivována a je platná.")
                        }
                    } else if (t.state == TicketState.ACTIVE) {
                        val startTime = t.activeStartTimestamp ?: 0L
                        val durationMs = t.durationMinutes.toLong() * 60 * 1000
                        if (currentSimTime - startTime >= durationMs) {
                            val expired = t.copy(state = TicketState.EXPIRED)
                            ticketRepository.insertTicket(expired)
                            SimulationEngine.logEvent("TICKET_EXPIRED", "Platnost jízdenky '${t.name}' vypršela.")
                        }
                    }
                }

                // Advance active journey progress if in Journey Mode
                val journey = _activeJourney.value
                if (journey != null) {
                    val currentProgress = _activeSegmentProgress.value
                    // Advance by 10% each second scaled by sim speed
                    val speedMultiplier = SimulationEngine.simSpeed.value.toFloat()
                    val nextProgress = currentProgress + (0.04f * speedMultiplier)
                    if (nextProgress >= 1.0f) {
                        _activeSegmentProgress.value = 0.0f
                        val nextSegIndex = _activeSegmentIndex.value + 1
                        if (nextSegIndex < journey.segments.size) {
                            _activeSegmentIndex.value = nextSegIndex
                            val seg = journey.segments[nextSegIndex]
                            SimulationEngine.logEvent("TRANSFER_STARTED", "Cestující zahájil segment: ${seg.fromStationName} -> ${seg.toStationName} (Linka ${seg.lineId ?: "Pěšky"}).")
                        } else {
                            // Reached destination!
                            _activeJourney.value = null
                            SimulationEngine.logEvent("TRANSFER_COMPLETED", "Cesta úspěšně dokončena! Dorazili jste do cílové stanice.")
                            _currentScreen.value = Screen.HOME
                        }
                    } else {
                        _activeSegmentProgress.value = nextProgress
                    }
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        simJob?.cancel()
    }

    // --- SEARCH LOGIC ---
    fun setOrigin(stationId: String) {
        _originId.value = stationId
        calculateRoutes()
    }

    fun setDestination(stationId: String) {
        _destinationId.value = stationId
        calculateRoutes()
    }

    fun toggleWheelchairFilter() {
        _wheelchairFilter.value = !_wheelchairFilter.value
        calculateRoutes()
    }

    fun swapStations() {
        val temp = _originId.value
        _originId.value = _destinationId.value
        _destinationId.value = temp
        calculateRoutes()
    }

    fun calculateRoutes() {
        _routeOptions.value = DijkstraRouter.findRoutes(
            startId = _originId.value,
            endId = _destinationId.value,
            wheelchairAccessible = _wheelchairFilter.value
        )
        _selectedRoute.value = _routeOptions.value.firstOrNull()
        SimulationEngine.logEvent("ROUTE_RECALCULATED", "Trasa přepočítána: ${_originId.value} -> ${_destinationId.value}.")
    }

    fun selectRoute(route: RouteOption) {
        _selectedRoute.value = route
    }

    // --- JOURNEY MODE INITIATION ---
    fun startJourney(route: RouteOption) {
        _activeJourney.value = route
        _activeSegmentIndex.value = 0
        _activeSegmentProgress.value = 0.0f
        navigateTo(Screen.JOURNEY_MODE)
        SimulationEngine.logEvent("TRANSFER_STARTED", "Cesta zahájena: ${route.segments.first().fromStationName}.")
    }

    fun stopJourney() {
        _activeJourney.value = null
        goBack()
        SimulationEngine.logEvent("TRANSFER_COMPLETED", "Cesta byla uživatelem předčasně ukončena.")
    }

    // --- TICKET ACTIONS ---
    fun buyTicket(product: Ticket) {
        viewModelScope.launch {
            ticketRepository.buyTicket(product.name, product.durationMinutes, product.priceCzk)
            SimulationEngine.logEvent("TICKET_PURCHASED", "Zakoupena jízdenka ${product.name} za ${product.priceCzk} Kč.")
        }
    }

    fun activateTicket(ticketId: String) {
        viewModelScope.launch {
            ticketRepository.activateTicket(ticketId)
            SimulationEngine.logEvent("TICKET_ACTIVATION_PENDING", "Aktivace jízdenky zahájena. Probíhá minutová ochranná lhůta PID.")
        }
    }

    fun clearAllTickets() {
        viewModelScope.launch {
            ticketRepository.clearAll()
            SimulationEngine.logEvent("TICKET_RESET", "Všechny jízdenky byly smazány.")
        }
    }

    // --- FAVORITES TOGGLE ---
    fun toggleFavorite(stationId: String) {
        val current = _favoriteStations.value.toMutableSet()
        if (current.contains(stationId)) {
            current.remove(stationId)
        } else {
            current.add(stationId)
        }
        _favoriteStations.value = current
    }

    // --- MAP LAYER CONTROL ---
    fun toggleMapLayer(mode: TransportMode) {
        val current = _mapLayers.value.toMutableMap()
        current[mode] = !(current[mode] ?: true)
        _mapLayers.value = current
    }

    // --- QUICK ACTION: AIRPORT PORTAL ---
    fun setupAirportJourney(isFromAirport: Boolean) {
        if (isFromAirport) {
            _originId.value = "letiste"
            _destinationId.value = "staromestska"
        } else {
            _originId.value = "staromestska"
            _destinationId.value = "letiste"
        }
        calculateRoutes()
        navigateTo(Screen.SPOJENI)
    }

    // --- SELECT STATION DETAILS ---
    fun viewStationDetails(stationId: String) {
        _selectedStationId.value = stationId
        navigateTo(Screen.STATION_DETAIL)
    }

    // --- CLOCK SIMULATION DRIVERS ---
    fun togglePauseSim() {
        SimulationEngine.setPaused(!SimulationEngine.isPaused.value)
    }

    fun setSimSpeed(speed: Int) {
        SimulationEngine.setSpeed(speed)
    }

    fun toggleNightTimeMode() {
        _isNightTimeMode.value = !_isNightTimeMode.value
        SimulationEngine.logEvent("NIGHT_MODE_TOGGLE", "Režim nočního provozu změněn.")
    }

    // --- DISRUPTION TRIGGER FOR TESTING ---
    fun generateDemoDisruption() {
        // Invalidate or reload routing to simulate closed lines
        SimulationEngine.logEvent("DISRUPTION_CREATED", "Generován nový incident: Havárie vodovodu na Klárově.")
    }
}
