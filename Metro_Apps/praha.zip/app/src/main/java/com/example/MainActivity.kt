package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.data.local.AppDatabase
import com.example.data.repository.TicketRepository
import com.example.features.account.AccountScreen
import com.example.features.developer.DeveloperModeScreen
import com.example.features.disruptions.DisruptionsScreen
import com.example.features.home.HomeScreen
import com.example.features.journey.ConnectionScreen
import com.example.features.journey.JourneyModeScreen
import com.example.features.map.MapScreen
import com.example.features.more.*
import com.example.features.stations.StationDetailScreen
import com.example.features.tickets.TicketsScreen
import com.example.ui.AppViewModel
import com.example.ui.Screen
import com.example.ui.theme.MyApplicationTheme

class AppViewModelFactory(private val context: android.content.Context) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val database = AppDatabase.getDatabase(context)
        val repository = TicketRepository(database.ticketDao())
        @Suppress("UNCHECKED_CAST")
        return AppViewModel(repository) as T
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val viewModelFactory = AppViewModelFactory(applicationContext)
        val viewModel = ViewModelProvider(this, viewModelFactory)[AppViewModel::class.java]

        setContent {
            MyApplicationTheme {
                val currentScreen by viewModel.currentScreen.collectAsState()

                // Intercept hardware back press and pop our internal backstack
                BackHandler(enabled = true) {
                    val popped = viewModel.goBack()
                    if (!popped) {
                        finish() // Exit app if nothing is left on backstack
                    }
                }

                // Main Layout
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Display bottom bar only on the 5 primary tabs
                        if (currentScreen in listOf(Screen.HOME, Screen.MAP, Screen.SPOJENI, Screen.JIZDENKY, Screen.MORE)) {
                            MainBottomNavigation(
                                currentScreen = currentScreen,
                                onNavigate = { screen ->
                                    viewModel.navigateTo(screen)
                                }
                            )
                        } else if (currentScreen in listOf(
                                Screen.STATION_DETAIL, Screen.JOURNEY_MODE, Screen.NIGHT_MODE,
                                Screen.PETRIN_LANOVKA, Screen.PRIVOZY, Screen.ARCHITECTURAL,
                                Screen.MŮJ_ÚČET, Screen.MIMOŘÁDNOSTI, Screen.DEVELOPER_MODE
                            )) {
                            // Also show bottom nav on secondary screens but with appropriate selection,
                            // or keep it simple and show bottom nav everywhere except Journey Mode to let users jump out anytime!
                            MainBottomNavigation(
                                currentScreen = currentScreen,
                                onNavigate = { screen ->
                                    viewModel.navigateTo(screen)
                                }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentScreen) {
                            Screen.HOME -> HomeScreen(viewModel = viewModel)
                            Screen.MAP -> MapScreen(viewModel = viewModel)
                            Screen.SPOJENI -> ConnectionScreen(viewModel = viewModel)
                            Screen.JIZDENKY -> TicketsScreen(viewModel = viewModel)
                            Screen.MORE -> MoreMenuScreen(viewModel = viewModel)
                            
                            Screen.STATION_DETAIL -> StationDetailScreen(viewModel = viewModel)
                            Screen.JOURNEY_MODE -> JourneyModeScreen(viewModel = viewModel)
                            Screen.NIGHT_MODE -> NightModeScreen(viewModel = viewModel)
                            Screen.PETRIN_LANOVKA -> FunicularScreen(viewModel = viewModel)
                            Screen.PRIVOZY -> FerriesScreen(viewModel = viewModel)
                            Screen.ARCHITECTURAL -> ArchitecturalScreen(viewModel = viewModel)
                            Screen.MŮJ_ÚČET -> AccountScreen(viewModel = viewModel)
                            Screen.MIMOŘÁDNOSTI -> DisruptionsScreen(viewModel = viewModel)
                            Screen.DEVELOPER_MODE -> DeveloperModeScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MainBottomNavigation(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit
) {
    NavigationBar(
        modifier = Modifier.testTag("app_bottom_nav_bar")
    ) {
        // TAB 1: DOMŮ (HOME)
        val homeActive = currentScreen == Screen.HOME
        NavigationBarItem(
            selected = homeActive,
            onClick = { onNavigate(Screen.HOME) },
            icon = { Icon(imageVector = Icons.Default.Home, contentDescription = "Domů") },
            label = { Text("Domů", fontWeight = if (homeActive) FontWeight.Black else FontWeight.Normal) },
            modifier = Modifier.testTag("nav_tab_home")
        )

        // TAB 2: MAPA
        val mapActive = currentScreen == Screen.MAP
        NavigationBarItem(
            selected = mapActive,
            onClick = { onNavigate(Screen.MAP) },
            icon = { Icon(imageVector = Icons.Default.Map, contentDescription = "Mapa") },
            label = { Text("Mapa", fontWeight = if (mapActive) FontWeight.Black else FontWeight.Normal) },
            modifier = Modifier.testTag("nav_tab_map")
        )

        // TAB 3: SPOJENÍ (CONNECTIONS)
        val spojeniActive = currentScreen == Screen.SPOJENI
        NavigationBarItem(
            selected = spojeniActive,
            onClick = { onNavigate(Screen.SPOJENI) },
            icon = { Icon(imageVector = Icons.Default.Directions, contentDescription = "Spojení") },
            label = { Text("Spojení", fontWeight = if (spojeniActive) FontWeight.Black else FontWeight.Normal) },
            modifier = Modifier.testTag("nav_tab_connections")
        )

        // TAB 4: JÍZDENKY (TICKETS)
        val jizdenkyActive = currentScreen == Screen.JIZDENKY
        NavigationBarItem(
            selected = jizdenkyActive,
            onClick = { onNavigate(Screen.JIZDENKY) },
            icon = { Icon(imageVector = Icons.Default.QrCode, contentDescription = "Jízdenky") },
            label = { Text("Jízdenky", fontWeight = if (jizdenkyActive) FontWeight.Black else FontWeight.Normal) },
            modifier = Modifier.testTag("nav_tab_tickets")
        )

        // TAB 5: VÍCE (MORE SUB-SCREENS)
        // If they are inside any sub-menu item like Account or special views, highlight More
        val isMoreActive = currentScreen == Screen.MORE || currentScreen in listOf(
            Screen.PETRIN_LANOVKA, Screen.PRIVOZY, Screen.ARCHITECTURAL,
            Screen.MŮJ_ÚČET, Screen.MIMOŘÁDNOSTI, Screen.DEVELOPER_MODE, Screen.NIGHT_MODE
        )
        NavigationBarItem(
            selected = isMoreActive,
            onClick = { onNavigate(Screen.MORE) }, // Default go directly to more menu screen
            icon = { Icon(imageVector = Icons.Default.Menu, contentDescription = "Více") },
            label = { Text("Více", fontWeight = if (isMoreActive) FontWeight.Black else FontWeight.Normal) },
            modifier = Modifier.testTag("nav_tab_more")
        )
    }
}
