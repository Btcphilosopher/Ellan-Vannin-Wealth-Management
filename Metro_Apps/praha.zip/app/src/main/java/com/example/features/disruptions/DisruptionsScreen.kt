package com.example.features.disruptions

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Disruption
import com.example.core.model.DisruptionSeverity
import com.example.data.TransportNetworkData
import com.example.ui.AppViewModel
import com.example.ui.theme.*

@Composable
fun DisruptionsScreen(viewModel: AppViewModel) {
    val incidents = TransportNetworkData.disruptions

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.goBack() }) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Zpět",
                        tint = Graphite
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "MIMOŘÁDNOSTI (PID)",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = Graphite,
                    modifier = Modifier.testTag("disruptions_header_title")
                )
            }

            IconButton(onClick = { viewModel.generateDemoDisruption() }) {
                Icon(
                    imageVector = Icons.Default.AddAlert,
                    contentDescription = "Simulovat incident",
                    tint = TransportRed
                )
            }
        }

        // --- LIST OF DISRUPTIONS ---
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "AKTUÁLNÍ VÝLUKY A OMEZENÍ PROVOZU",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp,
                    color = Graphite.copy(alpha = 0.6f)
                )
            }

            items(incidents.size) { index ->
                val incident = incidents[index]
                DisruptionItemCard(incident = incident)
            }
        }
    }
}

@Composable
fun DisruptionItemCard(incident: Disruption) {
    var expanded by remember { mutableStateOf(false) }

    val severityColor = when (incident.severity) {
        DisruptionSeverity.HIGH -> TransportRed
        DisruptionSeverity.MEDIUM -> AmberWarning
        DisruptionSeverity.LOW -> MutedBlue
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
            .clickable { expanded = !expanded }
            .testTag("disruption_card_${incident.incidentId.lowercase()}"),
        colors = CardDefaults.cardColors(containerColor = OffWhite)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Affected Lines Badges Row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    incident.affectedRoutes.forEach { route ->
                        Box(
                            modifier = Modifier
                                .background(severityColor, RoundedCornerShape(2.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = route,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }

                    Text(
                        text = incident.incidentId,
                        fontSize = 11.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        color = Graphite.copy(alpha = 0.5f),
                        fontWeight = FontWeight.Bold
                    )
                }

                // Severity label
                Text(
                    text = when (incident.severity) {
                        DisruptionSeverity.HIGH -> "ZÁVAŽNÉ"
                        DisruptionSeverity.MEDIUM -> "STŘEDNÍ"
                        DisruptionSeverity.LOW -> "NÍZKÉ"
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = severityColor
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = incident.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = Graphite
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Zahájení: ${incident.startTime} • Odhad: ${incident.expectedEnd}",
                fontSize = 11.sp,
                color = Graphite.copy(alpha = 0.6f)
            )

            // Expanded detail drawer
            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Divider(color = PragueStone.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "POPIS MIMORÁDNOSTI:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = Graphite.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = incident.description,
                        fontSize = 13.sp,
                        color = Graphite
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "NÁHRADNÍ DOPRAVA / ALTERNATIVY:",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = severityColor
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = incident.alternativeRoutes,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Graphite
                    )
                }
            }
        }
    }
}
