package com.example.core.simulation

import com.example.core.model.*
import com.example.data.TransportNetworkData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SimulationEngine {

    // --- CLOCK CONFIGURATION ---
    private val _simTime = MutableStateFlow(System.currentTimeMillis())
    val simTime: StateFlow<Long> = _simTime.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _simSpeed = MutableStateFlow(1) // 1x, 10x, 60x
    val simSpeed: StateFlow<Int> = _simSpeed.asStateFlow()

    // --- VEHICLES STATE ---
    data class SimVehicle(
        val id: String,
        val lineId: String,
        val mode: TransportMode,
        val stops: List<String>, // list of station IDs
        var currentStopIndex: Int = 0,
        var progress: Double = 0.0, // 0.0 to 1.0 between current and next stop
        var isWaitingAtStation: Boolean = false,
        var waitTimeMinutes: Double = 0.0,
        var direction: Int = 1, // 1 for forward, -1 for backward
        var delayMinutes: Int = 0,
        var occupancy: Int = 30,
        val isLowFloor: Boolean = true,
        val hasAirConditioning: Boolean = true
    )

    private val simVehicles = mutableListOf<SimVehicle>()

    private val _liveVehicles = MutableStateFlow<List<Vehicle>>(emptyList())
    val liveVehicles: StateFlow<List<Vehicle>> = _liveVehicles.asStateFlow()

    // --- EVENTS LOG (DEVELOPER MODE) ---
    private val _eventsLog = MutableStateFlow<List<SimEvent>>(emptyList())
    val eventsLog: StateFlow<List<SimEvent>> = _eventsLog.asStateFlow()

    init {
        // Initialize simulated vehicles for our active transport lines
        TransportNetworkData.lines.forEach { line ->
            if (line.stops.size >= 2) {
                // Spawn one vehicle forward
                simVehicles.add(
                    SimVehicle(
                        id = "VOZ-${line.id}-01",
                        lineId = line.id,
                        mode = line.mode,
                        stops = line.stops,
                        currentStopIndex = 0,
                        direction = 1,
                        occupancy = (20..80).random()
                    )
                )
                // Spawn another vehicle in reverse if enough stops
                if (line.stops.size > 3) {
                    simVehicles.add(
                        SimVehicle(
                            id = "VOZ-${line.id}-02",
                            lineId = line.id,
                            mode = line.mode,
                            stops = line.stops,
                            currentStopIndex = line.stops.size - 1,
                            direction = -1,
                            occupancy = (15..75).random()
                        )
                    )
                }
            }
        }
        updateLiveVehiclesList()
        logEvent("SIMULATION_STARTED", "Simulační systém v Praze byl úspěšně spuštěn.")
    }

    fun setPaused(paused: Boolean) {
        _isPaused.value = paused
        logEvent("SIMULATION_CLOCK", if (paused) "Simulační čas byl pozastaven." else "Simulační čas byl obnoven.")
    }

    fun setSpeed(speed: Int) {
        if (speed in listOf(1, 10, 60)) {
            _simSpeed.value = speed
            logEvent("SIMULATION_CLOCK", "Rychlost simulace nastavena na ${speed}x.")
        }
    }

    fun logEvent(type: String, message: String) {
        val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val timeStr = formatter.format(Date(_simTime.value))
        val newEvent = SimEvent(timeStr, type, message)
        _eventsLog.value = (listOf(newEvent) + _eventsLog.value).take(100) // Keep last 100 events
    }

    /**
     * Advances the simulation by realElapsedMs.
     */
    fun tick(realElapsedMs: Long) {
        if (_isPaused.value) return

        val rate = _simSpeed.value
        val virtualElapsedMs = realElapsedMs * rate
        _simTime.value = _simTime.value + virtualElapsedMs

        val virtualElapsedMinutes = virtualElapsedMs.toDouble() / (60.0 * 1000.0)

        // 1. Advance vehicle movements
        simVehicles.forEach { v ->
            val totalTravelTimeMinutes = 2.0 // average travel time between consecutive stops

            if (v.isWaitingAtStation) {
                v.waitTimeMinutes += virtualElapsedMinutes
                if (v.waitTimeMinutes >= 0.5) { // wait for 30 virtual seconds (0.5 minutes)
                    v.isWaitingAtStation = false
                    v.waitTimeMinutes = 0.0
                    v.progress = 0.0
                    
                    val depStation = TransportNetworkData.stations.find { it.id == v.stops[v.currentStopIndex] }?.name ?: "Zastávka"
                    logEvent("VEHICLE_DEPARTED", "Vozidlo ${v.id} (linka ${v.lineId}) odjelo ze stanice $depStation.")
                }
            } else {
                v.progress += virtualElapsedMinutes / totalTravelTimeMinutes
                if (v.progress >= 1.0) {
                    // Reached next stop
                    val prevIndex = v.currentStopIndex
                    v.currentStopIndex += v.direction
                    v.progress = 0.0

                    // Bounds check / terminal bounce
                    if (v.currentStopIndex >= v.stops.size - 1) {
                        v.currentStopIndex = v.stops.size - 1
                        v.direction = -1
                    } else if (v.currentStopIndex <= 0) {
                        v.currentStopIndex = 0
                        v.direction = 1
                    }

                    val arrStation = TransportNetworkData.stations.find { it.id == v.stops[v.currentStopIndex] }?.name ?: "Zastávka"
                    v.isWaitingAtStation = true
                    v.waitTimeMinutes = 0.0
                    
                    // Trigger arrival log
                    logEvent("VEHICLE_ARRIVED", "Vozidlo ${v.id} (linka ${v.lineId}) dorazilo do stanice $arrStation.")
                    
                    // Randomize occupancy and delays occasionally
                    if ((1..10).random() == 1) {
                        v.occupancy = (10..95).random()
                    }
                }
            }
        }

        updateLiveVehiclesList()
    }

    private fun updateLiveVehiclesList() {
        val vehicles = simVehicles.map { sv ->
            val currentStationId = sv.stops[sv.currentStopIndex]
            val nextStationIndex = sv.currentStopIndex + sv.direction
            val nextStationId = if (nextStationIndex in sv.stops.indices) sv.stops[nextStationIndex] else currentStationId

            val currStation = TransportNetworkData.stations.find { it.id == currentStationId } ?: TransportNetworkData.stations.first()
            val nextStation = TransportNetworkData.stations.find { it.id == nextStationId } ?: currStation

            // Linear interpolation of coordinates
            val lat = currStation.lat + (nextStation.lat - currStation.lat) * sv.progress
            val lon = currStation.lon + (nextStation.lon - currStation.lon) * sv.progress

            // Calculate heading
            val latDiff = nextStation.lat - currStation.lat
            val lonDiff = nextStation.lon - currStation.lon
            val headingRad = Math.atan2(lonDiff, latDiff)
            val headingDeg = Math.toDegrees(headingRad).toFloat()

            // Find destination name
            val terminalId = if (sv.direction == 1) sv.stops.last() else sv.stops.first()
            val destinationName = TransportNetworkData.stations.find { it.id == terminalId }?.name ?: "Praha"

            // Get delay from disruptions
            val delay = TransportNetworkData.disruptions.firstOrNull { it.affectedRoutes.contains(sv.lineId) }?.let {
                if (it.severity == DisruptionSeverity.HIGH) 8 else 4
            } ?: 0

            Vehicle(
                vehicleId = sv.id,
                routeId = sv.lineId,
                mode = sv.mode,
                latitude = lat,
                longitude = lon,
                heading = headingDeg,
                speed = if (sv.isWaitingAtStation) 0.0 else 45.0,
                delayMinutes = delay,
                occupancyPercent = sv.occupancy,
                lowFloor = sv.isLowFloor,
                airConditioning = sv.hasAirConditioning,
                destination = destinationName,
                status = when {
                    sv.isWaitingAtStation -> "Ve stanici"
                    delay > 0 -> "Zpožděn (+${delay} min)"
                    else -> "Jedoucí"
                }
            )
        }
        _liveVehicles.value = vehicles
    }
}
