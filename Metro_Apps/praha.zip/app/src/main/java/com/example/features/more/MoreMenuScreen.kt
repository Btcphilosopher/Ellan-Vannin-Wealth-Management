package com.example.features.more

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppViewModel
import com.example.ui.Screen
import com.example.ui.theme.*

@Composable
fun MoreMenuScreen(viewModel: AppViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "VÍCE FUNKCÍ",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = Graphite
            )
        }

        // --- GRID MENU ---
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                MoreMenuGridItem(
                    title = "Můj Účet",
                    subtitle = "Lítačka, historie, nastavení",
                    icon = Icons.Default.AccountCircle,
                    color = MutedBlue,
                    testTag = "menu_account_card",
                    onClick = { viewModel.navigateTo(Screen.MŮJ_ÚČET) }
                )
            }

            item {
                MoreMenuGridItem(
                    title = "Noční Doprava",
                    subtitle = "Noční tramvaje a autobusy",
                    icon = Icons.Default.NightsStay,
                    color = Charcoal,
                    testTag = "menu_night_card",
                    onClick = { viewModel.navigateTo(Screen.NIGHT_MODE) }
                )
            }

            item {
                MoreMenuGridItem(
                    title = "Petřínská Lanovka",
                    subtitle = "Jízdní řád lanové dráhy",
                    icon = Icons.Default.FilterHdr,
                    color = AmberWarning,
                    testTag = "menu_lanovka_card",
                    onClick = { viewModel.navigateTo(Screen.PETRIN_LANOVKA) }
                )
            }

            item {
                MoreMenuGridItem(
                    title = "Přívozy Vltavy",
                    subtitle = "Lodní linky PID",
                    icon = Icons.Default.DirectionsBoat,
                    color = MutedBlue,
                    testTag = "menu_privozy_card",
                    onClick = { viewModel.navigateTo(Screen.PRIVOZY) }
                )
            }

            item {
                MoreMenuGridItem(
                    title = "Mimořádnosti",
                    subtitle = "Výluky, zpoždění a změny",
                    icon = Icons.Default.Warning,
                    color = TransportRed,
                    testTag = "menu_disruptions_card",
                    onClick = { viewModel.navigateTo(Screen.MIMOŘÁDNOSTI) }
                )
            }

            item {
                MoreMenuGridItem(
                    title = "Město a Doprava",
                    subtitle = "Muzeum architektury MHD",
                    icon = Icons.Default.Museum,
                    color = RestrainedGreen,
                    testTag = "menu_architectural_card",
                    onClick = { viewModel.navigateTo(Screen.ARCHITECTURAL) }
                )
            }

            item {
                MoreMenuGridItem(
                    title = "Vývojářský Režim",
                    subtitle = "Ovládání času, simulátor",
                    icon = Icons.Default.DeveloperMode,
                    color = Graphite,
                    testTag = "menu_dev_mode_card",
                    onClick = { viewModel.navigateTo(Screen.DEVELOPER_MODE) }
                )
            }
        }
    }
}

@Composable
fun MoreMenuGridItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .testTag(testTag),
        colors = CardDefaults.cardColors(containerColor = OffWhite)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = 0.15f), RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = Graphite
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Graphite.copy(alpha = 0.6f),
                    maxLines = 2,
                    lineHeight = 13.sp
                )
            }
        }
    }
}
