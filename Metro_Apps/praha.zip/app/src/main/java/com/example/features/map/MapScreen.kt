package com.example.features.map

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.TransportMode
import com.example.core.model.Vehicle
import com.example.data.TransportNetworkData
import com.example.ui.AppViewModel
import com.example.ui.theme.*

@Composable
fun MapScreen(viewModel: AppViewModel) {
    val liveVehicles by viewModel.liveVehicles.collectAsState()
    val mapLayers by viewModel.mapLayers.collectAsState()
    val isNight by viewModel.isNightTimeMode.collectAsState()

    var selectedVehicle by remember { mutableStateOf<Vehicle?>(null) }

    val stations = TransportNetworkData.stations

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isNight) NightBackground else WarmIvory)
    ) {
        // --- LAYER PANEL (LazyRow) ---
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (isNight) NightSurface else OffWhite)
                .border(1.dp, color = PragueStone)
                .padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TransportMode.values().forEach { mode ->
                val isEnabled = mapLayers[mode] ?: true
                item {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isEnabled) TransportRed else PragueStone.copy(alpha = 0.5f))
                            .clickable { viewModel.toggleMapLayer(mode) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = when (mode) {
                                TransportMode.METRO -> "METRO"
                                TransportMode.TRAM -> "TRAMVAJE"
                                TransportMode.BUS -> "AUTOBUSY"
                                TransportMode.TROLEJBUS -> "TROLEJBUSY"
                                TransportMode.VLAK -> "VLAKY"
                                TransportMode.LANOVKA -> "LANOVKA"
                                TransportMode.PRIVOZ -> "PŘÍVOZY"
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = if (isEnabled) Color.White else Graphite.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }

        // --- MAP GRAPH PANEL ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
                .border(2.dp, if (isNight) OffWhite.copy(alpha = 0.2f) else Graphite, RoundedCornerShape(4.dp))
                .clip(RoundedCornerShape(4.dp))
                .background(if (isNight) NightBackground else OffWhite)
        ) {
            // Schematic Map Canvas
            Canvas(modifier = Modifier.fillMaxSize().testTag("prague_schematic_canvas")) {
                val w = size.width
                val h = size.height

                // Mercator-like custom projection bounds for Prague (approximate matching to coordinate spaces)
                val minLat = 50.04
                val maxLat = 50.12
                val minLon = 14.24
                val maxLon = 14.60

                fun project(lat: Double, lon: Double): Offset {
                    val x = ((lon - minLon) / (maxLon - minLon)) * w
                    // Latitude increases upwards, so subtract from h
                    val y = h - (((lat - minLat) / (maxLat - minLat)) * h)
                    return Offset(x.toFloat(), y.toFloat())
                }

                // 1. Draw River Vltava (Blue Ribbon curve)
                val riverPath = Path()
                val riverCoords = listOf(
                    Pair(50.041, 14.401),
                    Pair(50.062, 14.410),
                    Pair(50.078, 14.412),
                    Pair(50.088, 14.414),
                    Pair(50.096, 14.410),
                    Pair(50.108, 14.432),
                    Pair(50.118, 14.398)
                )
                val firstPt = project(riverCoords[0].first, riverCoords[0].second)
                riverPath.moveTo(firstPt.x, firstPt.y)
                for (i in 1 until riverCoords.size) {
                    val pt = project(riverCoords[i].first, riverCoords[i].second)
                    riverPath.lineTo(pt.x, pt.y)
                }
                drawPath(
                    path = riverPath,
                    color = MutedBlue.copy(alpha = 0.25f),
                    style = Stroke(width = 30f)
                )

                // 2. Draw Metro Lines (A=Green, B=Yellow, C=Red)
                if (mapLayers[TransportMode.METRO] == true) {
                    // Line A
                    val lineAStations = listOf("veleslavin", "dejvicka", "hradcanska", "malostranska", "staromestska", "mustek", "muzeum")
                    val lineAPath = Path()
                    val pStart = stations.find { it.id == lineAStations.first() }?.let { project(it.lat, it.lon) }
                    if (pStart != null) {
                        lineAPath.moveTo(pStart.x, pStart.y)
                        for (i in 1 until lineAStations.size) {
                            val st = stations.find { it.id == lineAStations[i] }
                            if (st != null) {
                                val pt = project(st.lat, st.lon)
                                lineAPath.lineTo(pt.x, pt.y)
                            }
                        }
                        drawPath(path = lineAPath, color = MetroLineA, style = Stroke(width = 6f))
                    }

                    // Line B
                    val lineBStations = listOf("zlicin", "smichov", "mustek", "florenc", "cerny_most")
                    val lineBPath = Path()
                    val pBStart = stations.find { it.id == lineBStations.first() }?.let { project(it.lat, it.lon) }
                    if (pBStart != null) {
                        lineBPath.moveTo(pBStart.x, pBStart.y)
                        for (i in 1 until lineBStations.size) {
                            val st = stations.find { it.id == lineBStations[i] }
                            if (st != null) {
                                val pt = project(st.lat, st.lon)
                                lineBPath.lineTo(pt.x, pt.y)
                            }
                        }
                        drawPath(path = lineBPath, color = MetroLineB, style = Stroke(width = 6f))
                    }

                    // Line C
                    val lineCStations = listOf("holesovice", "florenc", "hlavni_nadrazi", "muzeum")
                    val lineCPath = Path()
                    val pCStart = stations.find { it.id == lineCStations.first() }?.let { project(it.lat, it.lon) }
                    if (pCStart != null) {
                        lineCPath.moveTo(pCStart.x, pCStart.y)
                        for (i in 1 until lineCStations.size) {
                            val st = stations.find { it.id == lineCStations[i] }
                            if (st != null) {
                                val pt = project(st.lat, st.lon)
                                lineCPath.lineTo(pt.x, pt.y)
                            }
                        }
                        drawPath(path = lineCPath, color = MetroLineC, style = Stroke(width = 6f))
                    }
                }

                // 3. Draw Stations
                stations.forEach { st ->
                    val hasMetro = st.modes.contains(TransportMode.METRO)
                    val pt = project(st.lat, st.lon)
                    drawCircle(
                        color = if (hasMetro) Graphite else PragueStone,
                        radius = if (hasMetro) 8f else 5f,
                        center = pt
                    )
                    drawCircle(
                        color = if (hasMetro) Color.White else TransportRed,
                        radius = if (hasMetro) 4f else 2.5f,
                        center = pt
                    )
                }
            }

            // Draw Live interactive Vehicles as layered composable overlays
            liveVehicles.forEach { vehicle ->
                val isEnabled = mapLayers[vehicle.mode] ?: true
                if (isEnabled) {
                    val lat = vehicle.latitude
                    val lon = vehicle.longitude

                    // Absolute coordinate calculation matched to canvas projection bounds
                    val minLat = 50.04
                    val maxLat = 50.12
                    val minLon = 14.24
                    val maxLon = 14.60

                    val pctX = (lon - minLon) / (maxLon - minLon)
                    val pctY = 1.0 - ((lat - minLat) / (maxLat - minLat))

                    // Multiply by dimensions inside parent layout BoxWithConstraints
                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val xPx = (pctX * maxWidth.value).dp
                        val yPx = (pctY * maxHeight.value).dp

                        val color = when (vehicle.mode) {
                            TransportMode.METRO -> when (vehicle.routeId) {
                                "A" -> MetroLineA
                                "B" -> MetroLineB
                                "C" -> MetroLineC
                                else -> TransportRed
                            }
                            TransportMode.TRAM -> TransportRed
                            TransportMode.BUS -> MutedBlue
                            TransportMode.TROLEJBUS -> RestrainedGreen
                            TransportMode.LANOVKA -> AmberWarning
                            else -> Graphite
                        }

                        Box(
                            modifier = Modifier
                                .offset(x = xPx - 8.dp, y = yPx - 8.dp)
                                .size(16.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(color)
                                .border(1.5.dp, Color.White, RoundedCornerShape(8.dp))
                                .clickable { selectedVehicle = vehicle }
                        )
                    }
                }
            }

            // --- SELECTED VEHICLE TELEMETRY CARD ---
            selectedVehicle?.let { vehicle ->
                Card(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(12.dp)
                        .border(1.dp, PragueStone, RoundedCornerShape(4.dp))
                        .testTag("vehicle_telemetry_card"),
                    colors = CardDefaults.cardColors(containerColor = OffWhite)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(TransportRed, RoundedCornerShape(2.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${vehicle.routeId} [${vehicle.vehicleId.takeLast(4)}]",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = vehicle.destination,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Graphite
                                )
                            }

                            IconButton(onClick = { selectedVehicle = null }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Zavřít",
                                    tint = Graphite,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Rychlost: ${vehicle.speed.toInt()} km/h", fontSize = 12.sp, color = Graphite)
                                Text("Obsazenost: ${vehicle.occupancyPercent}%", fontSize = 12.sp, color = Graphite)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("Status: ${vehicle.status}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (vehicle.delayMinutes > 0) TransportRed else RestrainedGreen)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (vehicle.lowFloor) {
                                        Icon(imageVector = Icons.Default.WheelchairPickup, contentDescription = "Bezbariérové", tint = RestrainedGreen, modifier = Modifier.size(16.dp))
                                    }
                                    if (vehicle.airConditioning) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(imageVector = Icons.Default.AcUnit, contentDescription = "Klimatizace", tint = MutedBlue, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
