package com.example.data

import com.example.core.model.*

object TransportNetworkData {

    // --- 1. FARE PRODUCTS ---
    val fareProducts = listOf(
        Ticket("30m", "30 MINUT", 30, 36, qrCodePayload = "PID_30M_36CZK_DEMO_VALID"),
        Ticket("90m", "90 MINUT", 90, 46, qrCodePayload = "PID_90M_46CZK_DEMO_VALID"),
        Ticket("24h", "24 HODIN", 1440, 140, qrCodePayload = "PID_24H_140CZK_DEMO_VALID"),
        Ticket("72h", "72 HODIN", 4320, 340, qrCodePayload = "PID_72H_340CZK_DEMO_VALID")
    )

    // --- 2. STATIONS ---
    val stations = listOf(
        Station(
            id = "staromestska",
            name = "Staroměstská",
            modes = listOf(TransportMode.METRO, TransportMode.TRAM),
            lat = 50.0881,
            lon = 14.4172,
            hasElevator = false,
            hasEscalator = true,
            isAccessible = false,
            facilities = listOf("Eskalátory", "Wi-Fi v hale", "Informace"),
            exits = listOf("Karlův most", "Staroměstské náměstí", "Klementinum", "Filozofická fakulta UK"),
            lines = listOf("A", "17")
        ),
        Station(
            id = "mustek",
            name = "Můstek",
            modes = listOf(TransportMode.METRO, TransportMode.TRAM),
            lat = 50.0838,
            lon = 14.4215,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("Výtah", "Eskalátory", "Trafika", "Toalety"),
            exits = listOf("Václavské náměstí", "Na Příkopě", "28. října", "Jungmannovo náměstí"),
            lines = listOf("A", "B", "9", "22")
        ),
        Station(
            id = "muzeum",
            name = "Muzeum",
            modes = listOf(TransportMode.METRO),
            lat = 50.0798,
            lon = 14.4302,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("Výtah", "Eskalátory", "Informační centrum DPP", "Toalety"),
            exits = listOf("Národní muzeum", "Václavské náměstí (horní část)", "Čelakovského sady"),
            lines = listOf("A", "C")
        ),
        Station(
            id = "dejvicka",
            name = "Dejvická",
            modes = listOf(TransportMode.METRO, TransportMode.TRAM, TransportMode.BUS),
            lat = 50.1012,
            lon = 14.3934,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("Výtah", "Eskalátory", "Prodejna jízdenek"),
            exits = listOf("Vítězné náměstí", "Evropská", "Technická (ČVUT)"),
            lines = listOf("A", "18", "26")
        ),
        Station(
            id = "veleslavin",
            name = "Nádraží Veleslavín",
            modes = listOf(TransportMode.METRO, TransportMode.TRAM, TransportMode.BUS, TransportMode.TROLEJBUS, TransportMode.VLAK),
            lat = 50.0972,
            lon = 14.3482,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("Výtah", "Eskalátory", "Přestup na vlaky", "Terminál letiště"),
            exits = listOf("Autobusové nádraží", "Vlakové nádraží Veleslavín", "Evropská"),
            lines = listOf("A", "59", "119")
        ),
        Station(
            id = "letiste",
            name = "Letiště Praha",
            modes = listOf(TransportMode.BUS, TransportMode.TROLEJBUS),
            lat = 50.1062,
            lon = 14.2642,
            hasElevator = true,
            hasEscalator = false,
            isAccessible = true,
            facilities = listOf("Terminál 1 & 2", "Informační přepážka", "Wi-Fi zdarma"),
            exits = listOf("Terminál 1 (Mezinárodní)", "Terminál 2 (Schengen)", "Parkoviště"),
            lines = listOf("59", "119", "100")
        ),
        Station(
            id = "zlicin",
            name = "Zličín",
            modes = listOf(TransportMode.METRO, TransportMode.BUS),
            lat = 50.0528,
            lon = 14.2905,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("Výtah", "Parkoviště P+R", "Toalety"),
            exits = listOf("Autobusový terminál", "Obchodní centrum"),
            lines = listOf("B", "100")
        ),
        Station(
            id = "cerny_most",
            name = "Černý Most",
            modes = listOf(TransportMode.METRO, TransportMode.BUS),
            lat = 50.1092,
            lon = 14.5772,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("P+R Parkoviště", "Eskalátory"),
            exits = listOf("Terminál BUS", "Centrum Černý Most"),
            lines = listOf("B")
        ),
        Station(
            id = "florenc",
            name = "Florenc",
            modes = listOf(TransportMode.METRO, TransportMode.TRAM, TransportMode.BUS),
            lat = 50.0911,
            lon = 14.4392,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("Výtah", "Centrální autobusové nádraží UAN", "Toalety"),
            exits = listOf("Sokolovská", "Autobusové nádraží Florenc", "Křižíkova"),
            lines = listOf("B", "C")
        ),
        Station(
            id = "hlavni_nadrazi",
            name = "Hlavní nádraží",
            modes = listOf(TransportMode.METRO, TransportMode.VLAK, TransportMode.TRAM),
            lat = 50.0831,
            lon = 14.4358,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("Mezinárodní pokladny", "Čekárna", "Úschovna zavazadel", "Lékárna"),
            exits = listOf("Vlaková nástupiště", "Vrchlického sady (Sherwood)", "Pokladny ČD"),
            lines = listOf("C", "9", "26")
        ),
        Station(
            id = "masarykovo_nadrazi",
            name = "Masarykovo nádraží",
            modes = listOf(TransportMode.VLAK, TransportMode.TRAM),
            lat = 50.0874,
            lon = 14.4328,
            hasElevator = true,
            hasEscalator = false,
            isAccessible = true,
            facilities = listOf("Vlakové pokladny", "Restaurace", "Historická hala"),
            exits = listOf("Havlíčkova", "Na Florenci", "Hybernská"),
            lines = listOf("9", "26")
        ),
        Station(
            id = "smichov",
            name = "Praha-Smíchov",
            modes = listOf(TransportMode.METRO, TransportMode.VLAK, TransportMode.TRAM),
            lat = 50.0617,
            lon = 14.4087,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("Vlakové pokladny", "Parkoviště P+R", "Toalety"),
            exits = listOf("Nádražní ulice", "Vlaková nástupiště"),
            lines = listOf("B", "12", "20")
        ),
        Station(
            id = "holesovice",
            name = "Praha-Holešovice",
            modes = listOf(TransportMode.METRO, TransportMode.VLAK, TransportMode.TRAM),
            lat = 50.1098,
            lon = 14.4398,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("Pokladny ČD", "Rychlé občerstvení", "Toalety"),
            exits = listOf("Plynární", "Nádraží Holešovice"),
            lines = listOf("C", "17")
        ),
        Station(
            id = "malostranska",
            name = "Malostranská",
            modes = listOf(TransportMode.METRO, TransportMode.TRAM),
            lat = 50.0931,
            lon = 14.4092,
            hasElevator = false,
            hasEscalator = true,
            isAccessible = false,
            facilities = listOf("Eskalátory", "Zahrady pod Pražským hradem"),
            exits = listOf("Klárov", "Valdštejnská zahrada", "Staré zámecké schody"),
            lines = listOf("A", "22", "12")
        ),
        Station(
            id = "hradcanska",
            name = "Hradčanská",
            modes = listOf(TransportMode.METRO, TransportMode.TRAM, TransportMode.BUS),
            lat = 50.0971,
            lon = 14.4035,
            hasElevator = true,
            hasEscalator = true,
            isAccessible = true,
            facilities = listOf("Výtah", "Eskalátory", "Kavárna"),
            exits = listOf("Milady Horákové", "Deštník", "Přestup na autobusy"),
            lines = listOf("A", "1", "22", "25")
        ),
        Station(
            id = "ujezd",
            name = "Újezd",
            modes = listOf(TransportMode.TRAM, TransportMode.LANOVKA),
            lat = 50.0822,
            lon = 14.4038,
            hasElevator = true,
            hasEscalator = false,
            isAccessible = true,
            facilities = listOf("Lanová dráha na Petřín", "Pokladna na lanovku"),
            exits = listOf("Újezd", "Seminářská zahrada"),
            lines = listOf("9", "22", "Lanovka")
        ),
        Station(
            id = "nebozizek",
            name = "Nebozízek",
            modes = listOf(TransportMode.LANOVKA),
            lat = 50.0821,
            lon = 14.3995,
            hasElevator = false,
            hasEscalator = false,
            isAccessible = false,
            facilities = listOf("Restaurace Nebozízek", "Vyhlídka"),
            exits = listOf("Petřínské sady"),
            lines = listOf("Lanovka")
        ),
        Station(
            id = "petrin",
            name = "Petřín",
            modes = listOf(TransportMode.LANOVKA),
            lat = 50.0820,
            lon = 14.3968,
            hasElevator = true,
            hasEscalator = false,
            isAccessible = true,
            facilities = listOf("Petřínská rozhledna", "Zrcadlové bludiště", "Růžový sad"),
            exits = listOf("Petřínské sady"),
            lines = listOf("Lanovka")
        ),
        Station(
            id = "podbaba",
            name = "Podbaba (Přívoz P2)",
            modes = listOf(TransportMode.PRIVOZ, TransportMode.TRAM),
            lat = 50.1132,
            lon = 14.3912,
            hasElevator = true,
            hasEscalator = false,
            isAccessible = true,
            facilities = listOf("Přístaviště přívozu P2", "Návazná tramvaj Podbaba"),
            exits = listOf("Nábřeží Vltavy"),
            lines = listOf("P2")
        ),
        Station(
            id = "podhori",
            name = "Podhoří (Přívoz P2)",
            modes = listOf(TransportMode.PRIVOZ),
            lat = 50.1145,
            lon = 14.4011,
            hasElevator = false,
            hasEscalator = false,
            isAccessible = true,
            facilities = listOf("Přístaviště přívozu", "Blízkost Zoo Praha"),
            exits = listOf("Zoo Praha (severní vstup)", "Cyklistická stezka"),
            lines = listOf("P2")
        )
    )

    // --- 3. TRANSIT LINES ---
    val lines = listOf(
        // METRO
        TransitLine("A", "Metro A", TransportMode.METRO, "009348", listOf("veleslavin", "dejvicka", "hradcanska", "malostranska", "staromestska", "mustek", "muzeum")),
        TransitLine("B", "Metro B", TransportMode.METRO, "F2A900", listOf("zlicin", "smichov", "mustek", "florenc", "cerny_most")),
        TransitLine("C", "Metro C", TransportMode.METRO, "C8102E", listOf("holesovice", "florenc", "hlavni_nadrazi", "muzeum")),

        // TRAM
        TransitLine("22", "Tramvaj 22", TransportMode.TRAM, "C8102E", listOf("hradcanska", "malostranska", "ujezd", "mustek")),
        TransitLine("9", "Tramvaj 9", TransportMode.TRAM, "C8102E", listOf("smichov", "ujezd", "mustek", "masarykovo_nadrazi", "hlavni_nadrazi")),
        TransitLine("17", "Tramvaj 17", TransportMode.TRAM, "C8102E", listOf("holesovice", "staromestska", "ujezd")),

        // BUS / TROLEJBUS (including Prague Airport)
        TransitLine("119", "Autobus 119", TransportMode.BUS, "2E6B9E", listOf("veleslavin", "letiste")),
        TransitLine("59", "Trolejbus 59", TransportMode.TROLEJBUS, "2C6B3F", listOf("veleslavin", "letiste")),
        TransitLine("100", "Autobus 100", TransportMode.BUS, "2E6B9E", listOf("zlicin", "letiste")),

        // FUNICULAR
        TransitLine("Lanovka", "Petřínská lanovka", TransportMode.LANOVKA, "E28413", listOf("ujezd", "nebozizek", "petrin")),

        // FERRY
        TransitLine("P2", "Přívoz P2", TransportMode.PRIVOZ, "2E6B9E", listOf("podbaba", "podhori"))
    )

    // --- 4. NETWORK EDGES (For Dijkstra Routing) ---
    val edges = listOf(
        // Metro A
        RoutingEdge("veleslavin", "dejvicka", "A", TransportMode.METRO, 4.0),
        RoutingEdge("dejvicka", "veleslavin", "A", TransportMode.METRO, 4.0),
        RoutingEdge("dejvicka", "hradcanska", "A", TransportMode.METRO, 2.0),
        RoutingEdge("hradcanska", "dejvicka", "A", TransportMode.METRO, 2.0),
        RoutingEdge("hradcanska", "malostranska", "A", TransportMode.METRO, 2.0),
        RoutingEdge("malostranska", "hradcanska", "A", TransportMode.METRO, 2.0),
        RoutingEdge("malostranska", "staromestska", "A", TransportMode.METRO, 2.0),
        RoutingEdge("staromestska", "malostranska", "A", TransportMode.METRO, 2.0),
        RoutingEdge("staromestska", "mustek", "A", TransportMode.METRO, 1.5),
        RoutingEdge("mustek", "staromestska", "A", TransportMode.METRO, 1.5),
        RoutingEdge("mustek", "muzeum", "A", TransportMode.METRO, 1.5),
        RoutingEdge("muzeum", "mustek", "A", TransportMode.METRO, 1.5),

        // Metro B
        // Zličín -> Smíchov -> Můstek -> Florenc -> Černý Most
        RoutingEdge("zlicin", "smichov", "B", TransportMode.METRO, 12.0),
        RoutingEdge("smichov", "zlicin", "B", TransportMode.METRO, 12.0),
        RoutingEdge("smichov", "mustek", "B", TransportMode.METRO, 6.0),
        RoutingEdge("mustek", "smichov", "B", TransportMode.METRO, 6.0),
        RoutingEdge("mustek", "florenc", "B", TransportMode.METRO, 3.0),
        RoutingEdge("florenc", "mustek", "B", TransportMode.METRO, 3.0),
        RoutingEdge("florenc", "cerny_most", "B", TransportMode.METRO, 15.0),
        RoutingEdge("cerny_most", "florenc", "B", TransportMode.METRO, 15.0),

        // Metro C
        RoutingEdge("holesovice", "florenc", "C", TransportMode.METRO, 4.0),
        RoutingEdge("florenc", "holesovice", "C", TransportMode.METRO, 4.0),
        RoutingEdge("florenc", "hlavni_nadrazi", "C", TransportMode.METRO, 2.0),
        RoutingEdge("hlavni_nadrazi", "florenc", "C", TransportMode.METRO, 2.0),
        RoutingEdge("hlavni_nadrazi", "muzeum", "C", TransportMode.METRO, 2.0),
        RoutingEdge("muzeum", "hlavni_nadrazi", "C", TransportMode.METRO, 2.0),

        // Tram 22
        RoutingEdge("hradcanska", "malostranska", "22", TransportMode.TRAM, 5.0),
        RoutingEdge("malostranska", "hradcanska", "22", TransportMode.TRAM, 5.0),
        RoutingEdge("malostranska", "ujezd", "22", TransportMode.TRAM, 6.0),
        RoutingEdge("ujezd", "malostranska", "22", TransportMode.TRAM, 6.0),
        RoutingEdge("ujezd", "mustek", "22", TransportMode.TRAM, 7.0),
        RoutingEdge("mustek", "ujezd", "22", TransportMode.TRAM, 7.0),

        // Tram 9
        RoutingEdge("smichov", "ujezd", "9", TransportMode.TRAM, 6.0),
        RoutingEdge("ujezd", "smichov", "9", TransportMode.TRAM, 6.0),
        RoutingEdge("ujezd", "mustek", "9", TransportMode.TRAM, 7.0),
        RoutingEdge("mustek", "ujezd", "9", TransportMode.TRAM, 7.0),
        RoutingEdge("mustek", "masarykovo_nadrazi", "9", TransportMode.TRAM, 4.0),
        RoutingEdge("masarykovo_nadrazi", "mustek", "9", TransportMode.TRAM, 4.0),
        RoutingEdge("masarykovo_nadrazi", "hlavni_nadrazi", "9", TransportMode.TRAM, 3.0),
        RoutingEdge("hlavni_nadrazi", "masarykovo_nadrazi", "9", TransportMode.TRAM, 3.0),

        // Tram 17
        RoutingEdge("holesovice", "staromestska", "17", TransportMode.TRAM, 10.0),
        RoutingEdge("staromestska", "holesovice", "17", TransportMode.TRAM, 10.0),
        RoutingEdge("staromestska", "ujezd", "17", TransportMode.TRAM, 5.0),
        RoutingEdge("ujezd", "staromestska", "17", TransportMode.TRAM, 5.0),

        // Airport Connections
        RoutingEdge("veleslavin", "letiste", "119", TransportMode.BUS, 15.0),
        RoutingEdge("letiste", "veleslavin", "119", TransportMode.BUS, 15.0),
        RoutingEdge("veleslavin", "letiste", "59", TransportMode.TROLEJBUS, 14.0),
        RoutingEdge("letiste", "veleslavin", "59", TransportMode.TROLEJBUS, 14.0),
        RoutingEdge("zlicin", "letiste", "100", TransportMode.BUS, 16.0),
        RoutingEdge("letiste", "zlicin", "100", TransportMode.BUS, 16.0),

        // Lanovka
        RoutingEdge("ujezd", "nebozizek", "Lanovka", TransportMode.LANOVKA, 3.0),
        RoutingEdge("nebozizek", "ujezd", "Lanovka", TransportMode.LANOVKA, 3.0),
        RoutingEdge("nebozizek", "petrin", "Lanovka", TransportMode.LANOVKA, 2.0),
        RoutingEdge("petrin", "nebozizek", "Lanovka", TransportMode.LANOVKA, 2.0),

        // Ferry P2
        RoutingEdge("podbaba", "podhori", "P2", TransportMode.PRIVOZ, 4.0),
        RoutingEdge("podhori", "podbaba", "P2", TransportMode.PRIVOZ, 4.0),

        // WALKING TRANSFERS (Transfer penalties represented as edges)
        RoutingEdge("mustek", "mustek", null, null, 2.0), // transfer A <-> B
        RoutingEdge("muzeum", "muzeum", null, null, 2.0), // transfer A <-> C
        RoutingEdge("florenc", "florenc", null, null, 2.5), // transfer B <-> C
        RoutingEdge("hlavni_nadrazi", "masarykovo_nadrazi", null, null, 8.0) // walk HLN <-> MSN
    )

    // --- 5. DEMO VEHICLES (FOR MAP SIMULATION) ---
    val demoVehicles = listOf(
        Vehicle("V-2201", "22", TransportMode.TRAM, 50.088, 14.405, 120f, 25.0, 0, 35, true, true, "Nádraží Hostivař", "Jedoucí"),
        Vehicle("V-2202", "22", TransportMode.TRAM, 50.095, 14.408, 300f, 0.0, 1, 65, true, true, "Bílá Hora", "Ve stanici"),
        Vehicle("V-901", "9", TransportMode.TRAM, 50.081, 14.415, 90f, 30.0, 0, 15, true, false, "Spojovací", "Jedoucí"),
        Vehicle("V-1701", "17", TransportMode.TRAM, 50.098, 14.425, 45f, 15.0, 2, 50, false, false, "Levského", "Jedoucí"),
        Vehicle("V-11901", "119", TransportMode.BUS, 50.103, 14.305, 270f, 60.0, 0, 80, true, true, "Letiště Praha", "Jedoucí"),
        Vehicle("V-5901", "59", TransportMode.TROLEJBUS, 50.098, 14.335, 90f, 40.0, 0, 45, true, true, "Nádraží Veleslavín", "Jedoucí"),
        Vehicle("V-MA01", "A", TransportMode.METRO, 50.085, 14.420, 180f, 75.0, 0, 20, true, true, "Depo Hostivař", "V tunelu"),
        Vehicle("V-MB01", "B", TransportMode.METRO, 50.055, 14.300, 45f, 80.0, 0, 55, true, true, "Zličín", "V tunelu"),
        Vehicle("V-LAN01", "Lanovka", TransportMode.LANOVKA, 50.082, 14.399, 270f, 10.0, 0, 95, false, false, "Petřín", "Stoupající")
    )

    // --- 6. INCIDENTS (MIMOŘÁDNOSTI) ---
    val disruptions = listOf(
        Disruption(
            incidentId = "INC-01",
            severity = DisruptionSeverity.MEDIUM,
            affectedRoutes = listOf("A"),
            affectedStops = listOf("mustek", "muzeum"),
            startTime = "06:15",
            expectedEnd = "12:00",
            title = "Zpoždění na lince A",
            description = "Z důvodu technické závady na zabezpečovacím zařízení ve stanici Můstek dochází k nepravidelnostem v provozu. Zpoždění spojů může dosáhnout 5 až 10 minut.",
            alternativeRoutes = "Využijte povrchovou tramvajovou dopravu (linky 9 a 22 v ose Můstek - Národní třída - I. P. Pavlova)."
        ),
        Disruption(
            incidentId = "INC-02",
            severity = DisruptionSeverity.HIGH,
            affectedRoutes = listOf("22"),
            affectedStops = listOf("ujezd", "malostranska"),
            startTime = "08:00",
            expectedEnd = "Včerejší stav",
            title = "Odklon linky 22 přes Národní divadlo",
            description = "Z důvodu havárie vodovodního řádu v ulici Karmelitská jsou tramvaje linky 22 obousměrně odkloněny přes zastávku Národní divadlo, Staroměstská a Právnická fakulta.",
            alternativeRoutes = "Zastávky Újezd, Hellichova a Malostranské náměstí nejsou obsluhovány tramvajemi. Využijte náhradní autobusovou linku X22."
        ),
        Disruption(
            incidentId = "INC-03",
            severity = DisruptionSeverity.LOW,
            affectedRoutes = listOf("Lanovka"),
            affectedStops = listOf("nebozizek"),
            startTime = "00:00",
            expectedEnd = "Nespecifikováno",
            title = "Dočasné uzavření mezistanice Nebozízek",
            description = "Z technických důvodů a údržby nástupiště projíždějí vozy lanové dráhy na Petřín stanici Nebozízek bez zastavení.",
            alternativeRoutes = "Pěší přístup z Újezdu nebo z vrcholu Petřína po značených turistických stezkách."
        )
    )

    // --- 7. ARCHITECTURAL MUSEUM DATA ---
    val architecturalAssets = listOf(
        ArchitecturalAsset(
            id = "arch_staromestska",
            title = "Stanice Staroměstská",
            category = "Metro",
            subtitle = "Hliníkové obklady a ikonické výlisky",
            description = "Staroměstská je typickou stanicí pražského metra trasy A ze 70. let. Stěny jsou obloženy charakteristickými eloxovanými hliníkovými výlisky (vypouklými a vydutými čočkami), které navrhl grafik Jiří Rathouský. Zlatavé a červené barvy odkazují na historické centrum Prahy.",
            location = "Praha 1, Staré Město",
            yearBuilt = "1978",
            architect = "Eva Jiřičná, Jiří Rathouský (vizuální styl)"
        ),
        ArchitecturalAsset(
            id = "arch_t22_old",
            title = "Tatra T3",
            category = "Historické tramvaje",
            subtitle = "Ikonický symbol pražských ulic",
            description = "Legendární tramvaj Tatra T3 navržená designérem Františkem Kardausem je považována za jeden ze symbolů Prahy. S laminátovými sedačkami a ikonickými kulatými světly se stala nejpočetněji vyráběným tramvajovým vozem na světě. V Praze stále jezdí retrovozy na lince 23 a nostalgických linkách.",
            location = "Pražská tramvajová síť",
            yearBuilt = "1960",
            architect = "František Kardaus"
        ),
        ArchitecturalAsset(
            id = "arch_p_bridge",
            title = "Karlův most",
            category = "Bridges",
            subtitle = "Nejstarší stojící most přes Vltavu",
            description = "Ačkoliv most sám neslouží veřejné dopravě od dob koňky a historických autobusů z počátku 20. století, zůstává hlavním pěším tranzitním uzlem mezi Staroměstskou a Malostranskou. Nabízí úchvatný výhled na pražské nábřeží a projíždějící přívozy.",
            location = "Karlův most, Praha 1",
            yearBuilt = "1357",
            architect = "Petr Parléř"
        ),
        ArchitecturalAsset(
            id = "arch_hlavní",
            title = "Fantova budova",
            category = "Nádraží",
            subtitle = "Secesní klenot železnice",
            description = "Historická odjezdová hala pražského hlavního nádraží postavena v secesním slohu. Impozantní půlkruhová klenba a bohatá sochařská výzdoba dělají z této budovy nejkrásnější bránu do Prahy pro miliony cestujících z celého světa.",
            location = "Wilsonova, Praha 2",
            yearBuilt = "1909",
            architect = "Josef Fanta"
        ),
        ArchitecturalAsset(
            id = "arch_m_stross",
            title = "Brutalistní metro",
            category = "Stanice",
            subtitle = "Syrová estetika betonových hal",
            description = "Trasa C přinesla do Prahy brutalismus a funkční inženýrskou architekturu. Stanice jako Vyšehrad (přemosťující Nuselské údolí s výhledem na město) nebo Florenc s rozsáhlými betonovými vestibuly reprezentují Central European modernismus té doby.",
            location = "Vyšehrad, linka C",
            yearBuilt = "1974",
            architect = "Stanislav Hubička"
        )
    )
}
