package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Shenzhen Airlines Palette
val AviationBlue = Color(0xFF002B49) // 深航空蓝
val SkyBlue = Color(0xFF1D70B8)      // 天空蓝
val GoldAccent = Color(0xFFD2AD5E)    // 深航金
val RedAccent = Color(0xFFC8102E)     // 深航红 (Use restrictively for warning/status)
val SubtleGray = Color(0xFF8F9BB3)    // 银灰
val GraphiteBlack = Color(0xFF1A1F26) // 石墨黑

val LightBackground = Color(0xFFF5F7FA) // 暖白/灰
val LightSurface = Color(0xFFFFFFFF)

val DarkBackground = Color(0xFF0E131F)
val DarkSurface = Color(0xFF161E2E)
