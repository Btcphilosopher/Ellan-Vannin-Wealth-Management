package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PassengerProfileDao {
    @Query("SELECT * FROM passenger_profiles WHERE id = 'profile_tom' LIMIT 1")
    fun getProfileFlow(): Flow<PassengerProfile?>

    @Query("SELECT * FROM passenger_profiles WHERE id = 'profile_tom' LIMIT 1")
    suspend fun getProfile(): PassengerProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: PassengerProfile)
}

@Dao
interface FlightDao {
    @Query("SELECT * FROM flights WHERE id = :id LIMIT 1")
    fun getFlightFlow(id: String): Flow<Flight?>

    @Query("SELECT * FROM flights WHERE id = :id LIMIT 1")
    suspend fun getFlight(id: String): Flight?

    @Query("SELECT * FROM flights ORDER BY flightNumber ASC")
    fun getAllFlightsFlow(): Flow<List<Flight>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlight(flight: Flight)

    @Update
    suspend fun updateFlight(flight: Flight)
}

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings WHERE id = :id LIMIT 1")
    fun getBookingFlow(id: String): Flow<Booking?>

    @Query("SELECT * FROM bookings ORDER BY createdTime DESC")
    fun getAllBookingsFlow(): Flow<List<Booking>>

    @Query("SELECT * FROM bookings WHERE id = :id LIMIT 1")
    suspend fun getBooking(id: String): Booking?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: Booking)

    @Update
    suspend fun updateBooking(booking: Booking)
}

@Dao
interface BaggageRecordDao {
    @Query("SELECT * FROM baggage_records WHERE bookingId = :bookingId")
    fun getBaggageFlowForBooking(bookingId: String): Flow<List<BaggageRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBaggage(baggage: BaggageRecord)

    @Update
    suspend fun updateBaggage(baggage: BaggageRecord)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getNotificationsFlow(): Flow<List<AppNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotification)

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteNotification(id: Int)

    @Query("DELETE FROM notifications")
    suspend fun clearAll()
}

@Dao
interface JourneyStateDao {
    @Query("SELECT * FROM journey_state WHERE id = 'active_journey' LIMIT 1")
    fun getJourneyStateFlow(): Flow<ActiveJourneyState?>

    @Query("SELECT * FROM journey_state WHERE id = 'active_journey' LIMIT 1")
    suspend fun getJourneyState(): ActiveJourneyState?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourneyState(state: ActiveJourneyState)

    @Update
    suspend fun updateJourneyState(state: ActiveJourneyState)
}
