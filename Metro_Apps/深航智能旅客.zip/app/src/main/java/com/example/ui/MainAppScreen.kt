package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MainAppScreen(viewModel: MainViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val subScreen by viewModel.subScreen.collectAsStateWithLifecycle()
    val activeJourneyVal by viewModel.activeJourney.collectAsStateWithLifecycle()
    val activeFlightVal by viewModel.activeFlight.collectAsStateWithLifecycle()
    val activeBookingVal by viewModel.activeBooking.collectAsStateWithLifecycle()
    val profileVal by viewModel.profile.collectAsStateWithLifecycle()

    val isAirportMode = activeJourneyVal?.isAirportMode == true && activeJourneyVal?.stage in listOf("TO_AIRPORT", "SECURITY", "BOARDING")

    Scaffold(
        bottomBar = {
            if (subScreen == "DEFAULT") {
                NavigationBar(
                    containerColor = if (isAirportMode) Color(0xFF071224) else MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    val tabs = listOf(
                        Triple("首页", Icons.Outlined.Home, Icons.Filled.Home),
                        Triple("行程", Icons.Outlined.FlightTakeoff, Icons.Filled.FlightTakeoff),
                        Triple("服务", Icons.Outlined.Widgets, Icons.Filled.Widgets),
                        Triple("凤凰知音", Icons.Outlined.CardMembership, Icons.Filled.CardMembership),
                        Triple("我的", Icons.Outlined.Person, Icons.Filled.Person)
                    )
                    tabs.forEachIndexed { index, tab ->
                        val selected = currentTab == index
                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.navigateToTab(index) },
                            icon = {
                                Icon(
                                    imageVector = if (selected) tab.third else tab.second,
                                    contentDescription = tab.first,
                                    tint = if (selected) {
                                        if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary
                                    } else {
                                        if (isAirportMode) SubtleGray else MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            },
                            label = {
                                Text(
                                    text = tab.first,
                                    color = if (selected) {
                                        if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary
                                    } else {
                                        if (isAirportMode) SubtleGray else MaterialTheme.colorScheme.onSurfaceVariant
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = if (isAirportMode) Color(0xFF0F233C) else MaterialTheme.colorScheme.secondaryContainer
                            ),
                            modifier = Modifier.testTag("nav_tab_$index")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(if (isAirportMode) Color(0xFF050D1A) else MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = subScreen,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                },
                label = "subScreenTransition"
            ) { activeSubScreen ->
                when (activeSubScreen) {
                    "DEFAULT" -> {
                        when (currentTab) {
                            0 -> HomeScreen(viewModel, isAirportMode)
                            1 -> TripsScreen(viewModel)
                            2 -> ServicesScreen(viewModel)
                            3 -> PhoenixMilesScreen(viewModel)
                            4 -> ProfileScreen(viewModel)
                        }
                    }
                    "SEARCH_RESULTS" -> FlightSearchResultsScreen(viewModel)
                    "BOOKING_DETAILS" -> BookingDetailsScreen(viewModel)
                    "BOOKING_CONFIRMATION" -> BookingConfirmationScreen(viewModel)
                    "CHECK_IN_FLOW" -> CheckInFlowScreen(viewModel)
                    "BOARDING_PASS_VIEW" -> BoardingPassViewScreen(viewModel)
                    "FLIGHT_MAP" -> FlightMapScreen(viewModel)
                    "AIRPORT_MAP" -> AirportMapScreen(viewModel)
                    "BAGGAGE_VIEW" -> BaggageViewScreen(viewModel)
                    "DISRUPTION_VIEW" -> DisruptionViewScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun HomeScreen(viewModel: MainViewModel, isAirportMode: Boolean) {
    val activeJourneyVal by viewModel.activeJourney.collectAsStateWithLifecycle()
    val activeFlightVal by viewModel.activeFlight.collectAsStateWithLifecycle()
    val activeBookingVal by viewModel.activeBooking.collectAsStateWithLifecycle()
    val profileVal by viewModel.profile.collectAsStateWithLifecycle()

    var showSimulator by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            if (isAirportMode) {
                AirportModeHeader(viewModel, activeFlightVal, activeJourneyVal)
            } else {
                StandardHomeHeader(profileVal)
            }
        }

        if (!isAirportMode) {
            item {
                HomeQuickActionsGrid(viewModel)
            }
        }

        item {
            JourneyCenterCard(
                viewModel = viewModel,
                activeBooking = activeBookingVal,
                activeFlight = activeFlightVal,
                activeJourney = activeJourneyVal,
                isAirportMode = isAirportMode
            )
        }

        if (!isAirportMode) {
            item {
                PromotionsAndFeaturesSection(viewModel)
            }
        }

        item {
            WeChatMiniProgramArchitectureShowcase()
        }

        item {
            SimulatorControlsCard(
                viewModel = viewModel,
                activeJourney = activeJourneyVal,
                activeFlight = activeFlightVal,
                onToggleVisibility = { showSimulator = !showSimulator },
                isVisible = showSimulator
            )
        }
    }
}

@Composable
fun StandardHomeHeader(profile: PassengerProfile?) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.sz_airlines_hero_1790250932718),
            contentDescription = "Shenzhen Airlines Dawn Banner",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.5f),
                            Color.Black.copy(alpha = 0.1f),
                            Color.Black.copy(alpha = 0.7f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(RedAccent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "ZH",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "深圳航空 SHENZHEN AIRLINES",
                    color = Color.White,
                    fontSize = 16.sp,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "早上好，${profile?.name ?: "Tom"}",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "深航金卡会员 | 凤凰知音卡：${profile?.phoenixMilesNumber ?: "ZH953610992"}",
                color = GoldAccent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun AirportModeHeader(
    viewModel: MainViewModel,
    flight: Flight?,
    journey: ActiveJourneyState?
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0B1B33), Color(0xFF050D1A))
                )
            )
            .padding(20.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(GoldAccent)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "机场模式 AIRPORT MODE",
                            color = Color(0xFF050D1A),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    if (flight?.status == "DELAYED") {
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(RedAccent)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "延误 +${flight.delayMinutes}M",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                IconButton(
                    onClick = { viewModel.navigateToSubScreen("AIRPORT_MAP") },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Map,
                        contentDescription = "查看航站楼地图",
                        tint = GoldAccent
                    )
                }
            }

            Text(
                text = "深圳宝安国际机场 T3 航站楼",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = "登机口 GATE",
                        color = SubtleGray,
                        fontSize = 11.sp
                    )
                    Text(
                        text = flight?.gate ?: "A12",
                        color = GoldAccent,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "登机倒计时 BOARDING TIME",
                        color = SubtleGray,
                        fontSize = 11.sp
                    )
                    Text(
                        text = if (flight?.status == "DELAYED") "87 分钟" else "42 分钟",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F223D)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsWalk,
                        contentDescription = "Walk",
                        tint = GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = when(journey?.stage) {
                            "TO_AIRPORT" -> "请前往T3航站楼值机柜台 ${flight?.checkInCounter ?: "C08-C12"} 托运行李"
                            "SECURITY" -> "安检排队约6分钟，安检后左转前往 ${flight?.gate ?: "A12"} 登机口"
                            "BOARDING" -> "当前正在登机，请出示登机牌尽快登机"
                            else -> "请前往 A12 登机口准备登机"
                        },
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun HomeQuickActionsGrid(viewModel: MainViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        val actions = listOf(
            Triple("选座值机", Icons.Outlined.EventSeat, { viewModel.startCheckin() }),
            Triple("航班动态", Icons.Outlined.Schedule, { viewModel.navigateToSubScreen("FLIGHT_MAP") }),
            Triple("行李到家", Icons.Outlined.Luggage, { viewModel.navigateToSubScreen("BAGGAGE_VIEW") }),
            Triple("消息通知", Icons.Outlined.NotificationsActive, { viewModel.navigateToSubScreen("DISRUPTION_VIEW") })
        )
        actions.forEach { action ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .weight(1f)
                    .clickable { action.third() }
                    .padding(vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = action.second,
                        contentDescription = action.first,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = action.first,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    }
}

@Composable
fun JourneyCenterCard(
    viewModel: MainViewModel,
    activeBooking: Booking?,
    activeFlight: Flight?,
    activeJourney: ActiveJourneyState?,
    isAirportMode: Boolean
) {
    if (activeBooking == null || activeFlight == null || activeJourney == null) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.FlightTakeoff,
                    contentDescription = "Search icon",
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                    modifier = Modifier.size(48.dp)
                )
                Text(
                    text = "下一站，想去哪里？",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "目前没有即将出行的行程。开启一段新旅程，让我们始终陪伴在你身边。",
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = { viewModel.navigateToTab(2) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("搜索航班 Search Flights")
                }
            }
        }
        return
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("journey_center_card"),
        colors = CardDefaults.cardColors(
            containerColor = if (isAirportMode) Color(0xFF0E1A2D) else MaterialTheme.colorScheme.surface
        ),
        border = if (isAirportMode) BorderStroke(1.dp, GoldAccent.copy(alpha = 0.3f)) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "ZH1234",
                            color = if (isAirportMode) Color.Black else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "2026年10月12日",
                        color = if (isAirportMode) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    val statusText = when (activeFlight.status) {
                        "ON_TIME" -> "准点 (ON TIME)"
                        "DELAYED" -> "延误 (DELAYED)"
                        "CANCELLED" -> "已取消 (CANCELLED)"
                        "LIVE" -> "飞行中 (LIVE)"
                        "ARRIVED" -> "已抵达 (ARRIVED)"
                        else -> "计划 (SCHEDULED)"
                    }
                    val statusColor = when (activeFlight.status) {
                        "ON_TIME" -> Color(0xFF2E7D32)
                        "DELAYED" -> RedAccent
                        "LIVE" -> SkyBlue
                        "ARRIVED" -> Color(0xFF1E88E5)
                        else -> SubtleGray
                    }
                    Box(
                        modifier = Modifier
                            .border(1.dp, statusColor, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = statusText,
                            color = statusColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "深圳宝安",
                        color = if (isAirportMode) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = activeFlight.departureCode,
                        color = if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = activeFlight.scheduledDeparture,
                        color = if (isAirportMode) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (activeFlight.delayMinutes > 0) "新预计" else "直飞",
                        color = if (activeFlight.status == "DELAYED") RedAccent else SubtleGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        imageVector = Icons.Default.Flight,
                        contentDescription = "Flight Icon",
                        tint = if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (activeFlight.delayMinutes > 0) "10:20 起飞" else "3小时20分",
                        color = if (activeFlight.status == "DELAYED") RedAccent else SubtleGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "北京首都",
                        color = if (isAirportMode) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = activeFlight.arrivalCode,
                        color = if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = if (activeFlight.delayMinutes > 0) "预计 13:40" else activeFlight.scheduledArrival,
                        color = if (activeFlight.status == "DELAYED") RedAccent else (if (isAirportMode) Color.White else MaterialTheme.colorScheme.onSurface),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            JourneyTimelineProgress(activeJourney.stage, isAirportMode)

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isAirportMode) Color(0xFF1B2A3F) else MaterialTheme.colorScheme.primaryContainer)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "座号 SEAT",
                        color = if (isAirportMode) SubtleGray else MaterialTheme.colorScheme.primary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = activeBooking.seatNumber.ifEmpty { "未选座" },
                        color = if (isAirportMode) Color.White else MaterialTheme.colorScheme.onPrimaryContainer,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "航站楼 TERMINAL",
                        color = if (isAirportMode) SubtleGray else MaterialTheme.colorScheme.primary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = activeFlight.terminal,
                        color = if (isAirportMode) Color.White else MaterialTheme.colorScheme.onPrimaryContainer,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "登机口 GATE",
                        color = if (isAirportMode) SubtleGray else MaterialTheme.colorScheme.primary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = activeFlight.gate,
                        color = if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.onPrimaryContainer,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (activeBooking.seatNumber.isEmpty() && activeJourney.stage == "BOOKED") {
                    Button(
                        onClick = { viewModel.startCheckin() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = "选座值机 (Select Seat)",
                            color = if (isAirportMode) Color.Black else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (activeJourney.stage in listOf("CHECKED_IN", "TO_AIRPORT", "SECURITY", "BOARDING")) {
                    OutlinedButton(
                        onClick = { viewModel.navigateToSubScreen("BOARDING_PASS_VIEW") },
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = "电子登机牌 (Boarding Pass)",
                            color = if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (isAirportMode) {
                        Button(
                            onClick = { viewModel.navigateToSubScreen("AIRPORT_MAP") },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
                        ) {
                            Text(
                                text = "航站楼导航 (Navigate)",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else if (activeJourney.stage in listOf("DEPARTED", "CRUISE", "DESCENDING", "ARRIVED")) {
                    Button(
                        onClick = { viewModel.navigateToSubScreen("FLIGHT_MAP") },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = "实时飞行地图 (Live Map)",
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (activeJourney.stage == "BAGGAGE_CLAIM") {
                    Button(
                        onClick = { viewModel.navigateToSubScreen("BAGGAGE_VIEW") },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = "追踪托运行李 (Track Baggage)",
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (activeJourney.stage == "COMPLETE") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Done",
                                tint = Color(0xFF2E7D32)
                            )
                            Text(
                                text = "本次行程已圆满完成！凤凰知音里程已计入您的账户。祝您起居愉快！",
                                color = Color(0xFF1B5E20),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                if (activeFlight.status == "DELAYED") {
                    Button(
                        onClick = { viewModel.navigateToSubScreen("DISRUPTION_VIEW") },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = RedAccent)
                    ) {
                        Text(
                            text = "航班异常处理",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun JourneyTimelineProgress(stage: String, isAirportMode: Boolean) {
    val stages = listOf(
        "购票" to "BOOKED",
        "值机" to "CHECKED_IN",
        "候机" to "BOARDING",
        "飞行" to "DEPARTED",
        "抵达" to "ARRIVED"
    )

    val activeIndex = when(stage) {
        "BOOKED" -> 0
        "CHECKED_IN" -> 1
        "TO_AIRPORT", "SECURITY", "BOARDING" -> 2
        "DEPARTED", "CRUISE", "DESCENDING" -> 3
        "ARRIVED", "BAGGAGE_CLAIM", "COMPLETE" -> 4
        else -> 0
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        stages.forEachIndexed { index, pair ->
            val isActive = index <= activeIndex
            val isCurrent = index == activeIndex

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(
                            if (isCurrent) {
                                if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary
                            } else if (isActive) {
                                if (isAirportMode) GoldAccent.copy(alpha = 0.6f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                            } else {
                                if (isAirportMode) Color(0xFF2B3A4F) else Color(0xFFE0E0E0)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isActive && !isCurrent) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "completed",
                            tint = if (isAirportMode) Color.Black else Color.White,
                            modifier = Modifier.size(10.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = pair.first,
                    fontSize = 11.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                    color = if (isCurrent) {
                        if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary
                    } else {
                        if (isAirportMode) SubtleGray else MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }

            if (index < stages.size - 1) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(2.dp)
                        .background(
                            if (index < activeIndex) {
                                if (isAirportMode) GoldAccent else MaterialTheme.colorScheme.primary
                            } else {
                                if (isAirportMode) Color(0xFF2B3A4F) else Color(0xFFE0E0E0)
                            }
                        )
                )
            }
        }
    }
}

@Composable
fun HomeQuickSearch(viewModel: MainViewModel) {
    val fromCity by viewModel.searchFromCity.collectAsStateWithLifecycle()
    val toCity by viewModel.searchToCity.collectAsStateWithLifecycle()
    val tripType by viewModel.searchTripType.collectAsStateWithLifecycle()
    val cabin by viewModel.searchCabin.collectAsStateWithLifecycle()

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("单程 (One Way)", "往返 (Round Trip)").forEach { type ->
                    val selected = tripType == type
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer)
                            .clickable { viewModel.searchTripType.value = type }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = type,
                            color = if (selected) Color.White else MaterialTheme.colorScheme.primary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            val tmpCity = viewModel.searchFromCity.value
                            val tmpCode = viewModel.searchFromCode.value
                            viewModel.searchFromCity.value = viewModel.searchToCity.value
                            viewModel.searchFromCode.value = viewModel.searchToCode.value
                            viewModel.searchToCity.value = tmpCity
                            viewModel.searchToCode.value = tmpCode
                        }
                ) {
                    Text("从哪里出发？ FROM", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(fromCity, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(viewModel.searchFromCode.value, fontSize = 12.sp, color = SubtleGray)
                }

                Icon(
                    imageVector = Icons.Default.SwapHoriz,
                    contentDescription = "Swap Cities",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .size(32.dp)
                        .clickable {
                            val tmpCity = viewModel.searchFromCity.value
                            val tmpCode = viewModel.searchFromCode.value
                            viewModel.searchFromCity.value = viewModel.searchToCity.value
                            viewModel.searchFromCode.value = viewModel.searchToCode.value
                            viewModel.searchToCity.value = tmpCity
                            viewModel.searchToCode.value = tmpCode
                        }
                )

                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text("到哪里？ TO", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(toCity, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(viewModel.searchToCode.value, fontSize = 12.sp, color = SubtleGray)
                }
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("出发日期 DEPARTURE", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("2026-10-12", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("星期一 (Mon)", fontSize = 11.sp, color = SubtleGray)
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("舱位 & 人数 CABIN", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("1 成人，$cabin", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("可享金卡权益", fontSize = 11.sp, color = GoldAccent)
                }
            }

            Button(
                onClick = { viewModel.performSearch() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("search_flights_button"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "搜索深航航班 (Search SZX Flights)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
fun PromotionsAndFeaturesSection(viewModel: MainViewModel) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "深航精选服务",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.navigateToSubScreen("BAGGAGE_VIEW") },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Icon(
                        imageVector = Icons.Default.AirportShuttle,
                        contentDescription = "Baggage home",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("行李到家 Service", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("托运行李直接派送到家，空手出行更轻松。", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { viewModel.navigateToTab(2) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Icon(
                        imageVector = Icons.Default.Restaurant,
                        contentDescription = "Meal booking",
                        tint = SkyBlue
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("机上热餐 Booking", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("经典深圳牛肉面及粤式精选点心提前预约。", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun WeChatMiniProgramArchitectureShowcase() {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Architecture",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "深航一站式数字生态 (Unified Backend Architecture)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Text(
                text = "本系统采用模块化后端网关设计，同一套共享行程模型（Shared Journey Domain Model）同时支持：原生 App (iOS/Android) ｜ 微信小程序 (WeChat Mini Program) ｜ 移动网页 Web。确保多渠道订单实时同步，延误通知秒级分发。",
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SimulatorControlsCard(
    viewModel: MainViewModel,
    activeJourney: ActiveJourneyState?,
    activeFlight: Flight?,
    onToggleVisibility: () -> Unit,
    isVisible: Boolean
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.Green)
                    )
                    Text(
                        text = "演示与测试模拟器 (FLIGHT CONTROLLER)",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                TextButton(onClick = onToggleVisibility) {
                    Text(
                        text = if (isVisible) "收起" else "展开控制器",
                        color = GoldAccent,
                        fontSize = 12.sp
                    )
                }
            }

            if (isVisible) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "当前仿真阶段 stage: ${activeJourney?.stage ?: "NONE"}",
                    color = Color.Green,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
                Text(
                    text = "航班状态: ${activeFlight?.status ?: "NONE"} (延误: ${activeFlight?.delayMinutes ?: 0}分钟)",
                    color = Color.Green,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = { viewModel.simulateNextStage() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        modifier = Modifier
                            .weight(1.5f)
                            .height(38.dp)
                            .testTag("simulator_next_stage_btn"),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("前进一阶段 ➔", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.simulateInjectDelay() },
                        colors = ButtonDefaults.buttonColors(containerColor = RedAccent),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(38.dp)
                            .testTag("simulator_delay_btn"),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (activeFlight?.status == "DELAYED") "恢复正常" else "注入45分延误",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "提示：点击‘前进一阶段’可完整演练【已购票 ➔ 办理值机选座 ➔ 触发机场模式 ➔ 安检 ➔ 开始登机 ➔ 起飞 ➔ 巡航 ➔ 下降 ➔ 降落 ➔ 提行李 ➔ 完成行程获得里程】的完整数字旅程链路。",
                    color = Color.LightGray,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }
        }
    }
}

@Composable
fun TripsScreen(viewModel: MainViewModel) {
    val bookings by viewModel.allBookings.collectAsStateWithLifecycle()
    val activeJourneyVal by viewModel.activeJourney.collectAsStateWithLifecycle()
    val activeFlightVal by viewModel.activeFlight.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(vertical = 16.dp, horizontal = 16.dp)
        ) {
            Text(
                text = "我的行程 (MY TRIPS)",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        JourneyCenterCard(
            viewModel = viewModel,
            activeBooking = bookings.firstOrNull { it.status == "TICKETED" || it.id == activeJourneyVal?.bookingId },
            activeFlight = activeFlightVal,
            activeJourney = activeJourneyVal,
            isAirportMode = false
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        Text(
            text = "历史行程 / 订单明细",
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 20.dp)
        ) {
            val history = bookings.filter { it.status != "TICKETED" }
            if (history.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "暂无历史行程记录 (No Past Trips)",
                            color = SubtleGray,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                items(history) { record ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "订单号: ${record.id}", fontSize = 11.sp, color = SubtleGray)
                                Text(text = "深圳 (SZX) ➔ 北京 (PEK)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(text = "日期: 2026年10月12日 | 状态: ${record.status}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            if (record.status != "REFUNDED") {
                                TextButton(
                                    onClick = { viewModel.refundTicket(record.id) },
                                    colors = ButtonDefaults.textButtonColors(contentColor = RedAccent)
                                ) {
                                    Text("退票 (Refund)", fontSize = 12.sp)
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .background(Color.LightGray, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("已退票", color = Color.DarkGray, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ServicesScreen(viewModel: MainViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(vertical = 16.dp, horizontal = 16.dp)
        ) {
            Text(
                text = "深圳航空精选服务与机票搜索",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 20.dp)
        ) {
            item {
                HomeQuickSearch(viewModel)
            }

            item {
                TransitHotelEligibilityCard()
            }
        }
    }
}

@Composable
fun TransitHotelEligibilityCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(
                    imageVector = Icons.Default.Hotel,
                    contentDescription = "Hotel icon",
                    tint = GoldAccent,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = "深航中转免费住宿服务 (Transit Hotel Eligible)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Text(
                text = "如果您乘坐深航且中转时间在 8-48 小时以内，可在本系统内直接申请‘中转免费酒店’服务（包含接送机与精选舒心大床房）。中转酒店规则后台引擎自动判别资格。",
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun PhoenixMilesScreen(viewModel: MainViewModel) {
    val profileVal by viewModel.profile.collectAsStateWithLifecycle()
    var milesToRedeem by remember { mutableStateOf(12000f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(vertical = 16.dp, horizontal = 16.dp)
        ) {
            Text(
                text = "凤凰知音会员中心 (PhoenixMiles)",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(200.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF152A3C)),
            border = BorderStroke(1.5.dp, GoldAccent),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        color = GoldAccent.copy(alpha = 0.05f),
                        radius = 280.dp.toPx(),
                        center = Offset(size.width * 0.9f, size.height * 0.1f)
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "凤凰知音 PHOENIXMILES",
                                color = GoldAccent,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "深圳航空 ZH AIRLINES",
                                color = Color.White,
                                fontSize = 10.sp,
                                letterSpacing = 1.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .border(1.dp, GoldAccent, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = profileVal?.tier ?: "金卡 (Gold)",
                                color = GoldAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = profileVal?.name ?: "Tom",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "会员卡号: ${profileVal?.phoenixMilesNumber ?: "ZH953610992"}",
                                color = SubtleGray,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "里程余额 (MILES)",
                                color = GoldAccent,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = String.format("%,d", profileVal?.miles ?: 18420),
                                color = Color.White,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "里程 + 现金 混合支付规则引擎 (Miles + Cash Simulator)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "在深航购票流程中，您可以选择‘里程+现金’混合支付。每 100 凤凰知音里程可抵扣 ¥5 人民币票款（起兑限额 2,000 里程）。滑动调整兑换比例：",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )

                Slider(
                    value = milesToRedeem,
                    onValueChange = { milesToRedeem = (it / 100).toInt() * 100f },
                    valueRange = 0f..18000f,
                    steps = 18,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "兑换里程: ${milesToRedeem.toInt()} 里程", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = "抵扣金额: ¥${(milesToRedeem.toInt() / 100) * 5}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RedAccent)
                }
            }
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "最近里程明细 (Mileage Statement)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                listOf(
                    Triple("2026-09-15", "购买机票 ZH4567 消费里程", "-12,000 MILES"),
                    Triple("2026-08-20", "乘机累积 ZH1234 SZX-PEK", "+1,240 MILES"),
                    Triple("2026-07-05", "深航尊鹏阁里程好礼活动", "+500 MILES")
                ).forEach { transaction ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = transaction.second, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(text = transaction.first, fontSize = 11.sp, color = SubtleGray)
                        }

                        Text(
                            text = transaction.third,
                            color = if (transaction.third.startsWith("+")) Color(0xFF2E7D32) else RedAccent,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                }
            }
        }
        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun ProfileScreen(viewModel: MainViewModel) {
    val profileVal by viewModel.profile.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(vertical = 16.dp, horizontal = 16.dp)
        ) {
            Text(
                text = "我的深航 (MY SHENZHEN AIRLINES)",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = profileVal?.name?.take(1) ?: "T",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column {
                    Text(text = profileVal?.name ?: "Tom", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(text = "常用证件: ${profileVal?.documentType ?: "护照"} - ${profileVal?.documentNumber ?: "EE12345678"}", fontSize = 12.sp, color = SubtleGray)
                    Text(text = "手机号: ${profileVal?.mobile ?: "+86 138****9922"}", fontSize = 12.sp, color = SubtleGray)
                }
            }
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                val menuItems = listOf(
                    Triple("我的订单 (My Orders)", Icons.Default.Receipt, { viewModel.navigateToTab(1) }),
                    Triple("电子行程单 (E-Itinerary)", Icons.Default.Description, { viewModel.navigateToSubScreen("DISRUPTION_VIEW") }),
                    Triple("行李到家服务 (Baggage Delivery)", Icons.Default.AirportShuttle, { viewModel.navigateToSubScreen("BAGGAGE_VIEW") }),
                    Triple("消息通知中心 (Notifications)", Icons.Default.Notifications, { viewModel.navigateToSubScreen("DISRUPTION_VIEW") }),
                )

                menuItems.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { item.third() }
                            .padding(horizontal = 12.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(imageVector = item.second, contentDescription = item.first, tint = MaterialTheme.colorScheme.primary)
                            Text(text = item.first, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        }
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Go", tint = SubtleGray)
                    }
                }
            }
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.SupportAgent, contentDescription = "Hotline", tint = MaterialTheme.colorScheme.primary)
                    Text(text = "深航一站式智慧客诉客服 (Support)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Text(
                    text = "如需获取任何紧急乘机、特殊行李配额或改签支持，请随时点击致电深航官方直达服务热线：95361。我们的数字专家将随时提供 24/7 航班调度与延误保障。",
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = {  },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("拨打深航服务热线：95361 (Simulated Call)")
                }
            }
        }
    }
}

@Composable
fun FlightSearchResultsScreen(viewModel: MainViewModel) {
    val results by viewModel.searchResults.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = { viewModel.goBack() }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "${viewModel.searchFromCity.value} ➔ ${viewModel.searchToCity.value} 航班结果",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (results.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(40.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "暂无匹配的深航航班。请尝试选择 深圳(SZX) 到 北京(PEK)。", color = SubtleGray, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(results) { flight ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectFlight(flight) }
                            .testTag("flight_result_card_${flight.flightNumber}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.primary)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = flight.flightNumber, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text(text = flight.aircraftType, fontSize = 11.sp, color = SubtleGray)
                                }

                                Text(
                                    text = "¥${flight.basePrice} 起",
                                    color = RedAccent,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = flight.scheduledDeparture, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "${flight.departureCity}${flight.departureCode}", fontSize = 12.sp, color = SubtleGray)
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "直飞 Direct", fontSize = 10.sp, color = SubtleGray)
                                    Icon(imageVector = Icons.Default.TrendingFlat, contentDescription = "Arrow", tint = MaterialTheme.colorScheme.primary)
                                    Text(text = "约 3h 20m", fontSize = 10.sp, color = SubtleGray)
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = flight.scheduledArrival, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "${flight.arrivalCity}${flight.arrivalCode}", fontSize = 12.sp, color = SubtleGray)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BookingDetailsScreen(viewModel: MainViewModel) {
    val selectedFlight by viewModel.selectedFlightForBooking.collectAsStateWithLifecycle()
    val extraBaggage by viewModel.bookingExtraBaggageKg.collectAsStateWithLifecycle()
    val mealSelected by viewModel.bookingMealSelected.collectAsStateWithLifecycle()
    val hotelBooked by viewModel.bookingHotelBooked.collectAsStateWithLifecycle()
    val useMilesCash by viewModel.bookingUseMilesCash.collectAsStateWithLifecycle()

    val profileVal by viewModel.profile.collectAsStateWithLifecycle()

    if (selectedFlight == null) return

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = { viewModel.navigateToSubScreen("SEARCH_RESULTS") }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "购买 ${selectedFlight!!.flightNumber} 机票",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "${selectedFlight!!.flightNumber} | ${selectedFlight!!.aircraftType}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = "${selectedFlight!!.departureCity} ➔ ${selectedFlight!!.arrivalCity}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(text = "出发时间: 2026-10-12 ${selectedFlight!!.scheduledDeparture}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Text(text = "¥${selectedFlight!!.basePrice}", color = RedAccent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }

            Text(text = "乘机人档案 (Passenger Profile)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "姓名 (Name): ${profileVal?.name ?: "Tom"}", fontWeight = FontWeight.Bold)
                    Text(text = "证件 (Document): ${profileVal?.documentType ?: "护照"} | ${profileVal?.documentNumber ?: "EE12345678"}")
                    Text(text = "手机号 (Mobile): ${profileVal?.mobile ?: "+86 138****9922"}")
                }
            }

            Text(text = "定制附加增值服务 (Extra Services)", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column {
                        Text(text = "航班精选餐食 (Flight Meal Selection)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("经典深航牛肉面", "粤式精选点心", "标准配餐").forEach { meal ->
                                val selected = mealSelected == meal
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (selected) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f))
                                        .clickable { viewModel.bookingMealSelected.value = meal }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = meal, color = if (selected) Color.White else Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Column {
                        Text(text = "额外托运行李 (Extra Baggage Surcharge)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "+ ${extraBaggage} kg (¥${extraBaggage * 30})", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { if (extraBaggage > 0) viewModel.bookingExtraBaggageKg.value -= 5 },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.primary),
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Text("-")
                                }
                                Button(
                                    onClick = { if (extraBaggage < 40) viewModel.bookingExtraBaggageKg.value += 5 },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.primary),
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Text("+")
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "中转舒心大床房住宿服务", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(text = "中转时间长，免费赠送或优享 ¥180 起中转酒店服务", fontSize = 10.sp, color = SubtleGray)
                        }
                        Checkbox(checked = hotelBooked, onCheckedChange = { viewModel.bookingHotelBooked.value = it })
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "使用凤凰知音里程抵扣票款", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(text = "您当前里程余额: ${profileVal?.miles ?: 18420}", fontSize = 11.sp, color = GoldAccent)
                        }
                        Switch(checked = useMilesCash, onCheckedChange = { viewModel.bookingUseMilesCash.value = it })
                    }

                    if (useMilesCash) {
                        Text(
                            text = "已应用混合支付：抵扣 12,000 里程 (减免 ¥600)",
                            color = Color(0xFF2E7D32),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.LightGray.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("机票价 Ticket:")
                        Text("¥${selectedFlight!!.basePrice}")
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("民航发展基金 Taxes:")
                        Text("¥50")
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("燃油附加费 Fuel:")
                        Text("¥110")
                    }
                    if (extraBaggage > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("附加托运行李 Surcharge:")
                            Text("¥${extraBaggage * 30}")
                        }
                    }
                    if (useMilesCash) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("里程抵扣 Credit:", color = Color(0xFF2E7D32))
                            Text("- ¥600", color = Color(0xFF2E7D32))
                        }
                    }
                    HorizontalDivider()
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("应付总额 Total Payable:", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            text = "¥${viewModel.calculateTotalPayment()}",
                            color = RedAccent,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Button(
                onClick = { viewModel.confirmBooking() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("pay_booking_button"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "确认支付 ¥${viewModel.calculateTotalPayment()}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun BookingConfirmationScreen(viewModel: MainViewModel) {
    val activeBookingVal by viewModel.activeBooking.collectAsStateWithLifecycle()
    val activeFlightVal by viewModel.activeFlight.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Success",
                    tint = Color(0xFF2E7D32),
                    modifier = Modifier.size(72.dp)
                )

                Text(
                    text = "深航机票购买成功！",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = "我们已成功接收您的款项，机票已出票。您的数字行程已准备好，深航出行管家将时刻保障您的每一次出行安全舒适。",
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                HorizontalDivider()

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("订单编号 Order Ref:", color = SubtleGray)
                        Text(activeBookingVal?.id ?: "ZH88992", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("航班代码 Flight No:", color = SubtleGray)
                        Text(activeFlightVal?.flightNumber ?: "ZH1234", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("航程 Route:", color = SubtleGray)
                        Text("${activeFlightVal?.departureCity} ➔ ${activeFlightVal?.arrivalCity}", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("座位 Seat Status:", color = SubtleGray)
                        Text(if (activeBookingVal?.seatNumber?.isEmpty() == true) "未选 (请办理值机选座)" else activeBookingVal?.seatNumber ?: "", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.navigateToTab(0) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("返回首页查看行程", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun CheckInFlowScreen(viewModel: MainViewModel) {
    val checkinStep by viewModel.checkinStep.collectAsStateWithLifecycle()
    val activeFlightVal by viewModel.activeFlight.collectAsStateWithLifecycle()
    val activeBookingVal by viewModel.activeBooking.collectAsStateWithLifecycle()
    val selectedSeat by viewModel.selectedSeatNumber.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = { viewModel.goBack() }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
                Text(
                    text = "深航 ZH1234 选座值机 (Seat Map)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        when (checkinStep) {
            0 -> {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "选择您心仪的座位 Seat Grid A-F",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)
                    ) {
                        SeatIndicatorItem("可选 AVAILABLE", Color.White, BorderStroke(1.dp, Color.Gray))
                        SeatIndicatorItem("已选 SELECTED", GoldAccent, null)
                        SeatIndicatorItem("占用 OCCUPIED", Color.DarkGray, null)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.LightGray.copy(alpha = 0.2f))
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 16.dp),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            for (row in 12..20) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "$row",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.width(20.dp),
                                        textAlign = TextAlign.Center
                                    )

                                    listOf("A", "B", "C").forEach { letter ->
                                        val seatId = "$row$letter"
                                        val isOccupied = row % 3 == 0 && letter != "A"
                                        val isSelected = selectedSeat == seatId

                                        SeatBox(
                                            seatId = seatId,
                                            isOccupied = isOccupied,
                                            isSelected = isSelected,
                                            onClick = { if (!isOccupied) viewModel.selectSeat(seatId) }
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(16.dp))

                                    listOf("D", "E", "F").forEach { letter ->
                                        val seatId = "$row$letter"
                                        val isOccupied = row % 4 == 0
                                        val isSelected = selectedSeat == seatId

                                        SeatBox(
                                            seatId = seatId,
                                            isOccupied = isOccupied,
                                            isSelected = isSelected,
                                            onClick = { if (!isOccupied) viewModel.selectSeat(seatId) }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (selectedSeat.isEmpty()) "请先在上方客舱图选择座位" else "已选座位: $selectedSeat (经济舱-靠窗)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Button(
                            onClick = { viewModel.advanceCheckinStep() },
                            enabled = selectedSeat.isNotEmpty(),
                            modifier = Modifier.testTag("confirm_seat_btn")
                        ) {
                            Text("下一步", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            1 -> {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Luggage,
                        contentDescription = "Baggage details",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(64.dp)
                    )

                    Text(
                        text = "确认随身和托运行李安全规范",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )

                    Text(
                        text = "尊敬的旅客：根据中国民航局安全管理要求，打火机、充电宝及锂电池【禁止托运】。充电宝容量不得超过 20,000mAh，且须随身携带。托运行李中不得含有任何易燃、易爆、有毒腐蚀性危险品。",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center
                    )

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("您托运的行李 Baggage:", color = SubtleGray)
                        Text("1 件托运行李 (约 18.5 kg)", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.advanceCheckinStep() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("confirm_baggage_btn")
                    ) {
                        Text("同意规范并完成值机", fontWeight = FontWeight.Bold)
                    }
                }
            }
            2 -> {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Check-in completed",
                        tint = Color(0xFF2E7D32),
                        modifier = Modifier.size(72.dp)
                    )

                    Text(
                        text = "值机选座办理成功！",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "已为您自动生成数字登机牌 (Boarding Pass) 并完成人脸安全匹配。登机口 A12 计划 09:05 开放登机，座位号 $selectedSeat。行程即将起航！",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )

                    Button(
                        onClick = { viewModel.navigateToSubScreen("BOARDING_PASS_VIEW") },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("出示电子登机牌", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun BoardingPassViewScreen(viewModel: MainViewModel) {
    val activeBookingVal by viewModel.activeBooking.collectAsStateWithLifecycle()
    val activeFlightVal by viewModel.activeFlight.collectAsStateWithLifecycle()
    val profileVal by viewModel.profile.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = { viewModel.goBack() }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "电子登机牌 (BOARDING PASS)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("digital_boarding_pass"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "深圳航空 SHENZHEN AIRLINES",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 13.sp,
                            letterSpacing = 1.sp
                        )

                        Text(
                            text = "ZH1234",
                            fontWeight = FontWeight.ExtraBold,
                            color = RedAccent,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = Color.LightGray)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "SZX", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                            Text(text = "深圳宝安 T3", fontSize = 12.sp, color = SubtleGray)
                            Text(text = "09:35", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }

                        Icon(
                            imageVector = Icons.Default.FlightTakeoff,
                            contentDescription = "Flight",
                            tint = GoldAccent,
                            modifier = Modifier
                                .size(36.dp)
                                .align(Alignment.CenterVertically)
                        )

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "PEK", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                            Text(text = "北京首都 T3", fontSize = 12.sp, color = SubtleGray)
                            Text(text = "12:55", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = Color.LightGray)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "旅客 PASSENGER", fontSize = 9.sp, color = SubtleGray)
                            Text(text = profileVal?.name ?: "Tom", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Column {
                            Text(text = "登机口 GATE", fontSize = 9.sp, color = SubtleGray)
                            Text(text = activeFlightVal?.gate ?: "A12", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = GoldAccent)
                        }
                        Column {
                            Text(text = "座位 SEAT", fontSize = 9.sp, color = SubtleGray)
                            Text(text = activeBookingVal?.seatNumber?.ifEmpty { "18A" } ?: "18A", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "舱等 CABIN", fontSize = 9.sp, color = SubtleGray)
                            Text(text = "经济舱 CLASS Y", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(120.dp)) {
                            val lineCount = 30
                            for (i in 0 until lineCount) {
                                val width = if (i % 3 == 0) 6.dp.toPx() else 2.dp.toPx()
                                val x = i * 4.dp.toPx()
                                drawRect(
                                    color = Color.Black,
                                    topLeft = Offset(x, 0f),
                                    size = androidx.compose.ui.geometry.Size(width, size.height)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "SIMULATED / 模拟登机牌",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        color = RedAccent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun FlightMapScreen(viewModel: MainViewModel) {
    val activeJourneyVal by viewModel.activeJourney.collectAsStateWithLifecycle()

    var progress by remember { mutableStateOf(0.1f) }

    LaunchedEffect(activeJourneyVal?.stage) {
        progress = when(activeJourneyVal?.stage) {
            "DEPARTED" -> 0.15f
            "CRUISE" -> 0.5f
            "DESCENDING" -> 0.82f
            "ARRIVED", "BAGGAGE_CLAIM", "COMPLETE" -> 1.0f
            else -> 0.0f
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = { viewModel.goBack() }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "实时航线航迹图 (LIVE FLIGHT MAP)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF071224))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                val szx = Offset(canvasWidth * 0.45f, canvasHeight * 0.85f)
                val pek = Offset(canvasWidth * 0.62f, canvasHeight * 0.28f)
                val sha = Offset(canvasWidth * 0.80f, canvasHeight * 0.62f)
                val ctu = Offset(canvasWidth * 0.28f, canvasHeight * 0.68f)
                val xiy = Offset(canvasWidth * 0.42f, canvasHeight * 0.52f)

                val strokeColor = Color.White.copy(alpha = 0.05f)
                for (i in 1..8) {
                    val y = canvasHeight * (i / 9f)
                    drawLine(strokeColor, Offset(0f, y), Offset(canvasWidth, y))
                    val x = canvasWidth * (i / 9f)
                    drawLine(strokeColor, Offset(x, 0f), Offset(x, canvasHeight))
                }

                val routeStroke = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )

                val controlPoint = Offset(canvasWidth * 0.58f, canvasHeight * 0.58f)
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(szx.x, szx.y)
                    quadraticTo(controlPoint.x, controlPoint.y, pek.x, pek.y)
                }
                drawPath(path, color = SkyBlue.copy(alpha = 0.4f), style = routeStroke)

                val cities = listOf(
                    "深圳 SZX" to szx,
                    "北京 PEK" to pek,
                    "上海 SHA" to sha,
                    "成都 CTU" to ctu,
                    "西安 XIY" to xiy
                )
                cities.forEach { city ->
                    drawCircle(color = GoldAccent, radius = 5.dp.toPx(), center = city.second)
                    drawCircle(color = Color.White.copy(alpha = 0.2f), radius = 12.dp.toPx(), center = city.second)
                }

                if (progress > 0f) {
                    val t = progress
                    val mt = 1f - t
                    val planeX = mt * mt * szx.x + 2 * mt * t * controlPoint.x + t * t * pek.x
                    val planeY = mt * mt * szx.y + 2 * mt * t * controlPoint.y + t * t * pek.y
                    val planePos = Offset(planeX, planeY)

                    drawCircle(color = Color.White, radius = 8.dp.toPx(), center = planePos)
                    drawCircle(color = SkyBlue.copy(alpha = 0.3f), radius = 24.dp.toPx(), center = planePos)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F233D).copy(alpha = 0.85f)),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp),
                border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "ZH1234 深圳 ➔ 北京 在飞航路",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = when(activeJourneyVal?.stage) {
                            "DEPARTED" -> "飞机刚刚起飞，正在爬升至巡航高度 10,100米。时速 780km/h。"
                            "CRUISE" -> "飞机处于巡航阶段，正在飞越咸宁上空。时速 890km/h。气压平稳。"
                            "DESCENDING" -> "飞机开始向北京下降，空管已指派进场航道。时速 420km/h。"
                            "ARRIVED", "COMPLETE" -> "飞机已顺利安全着陆。航班任务完成。"
                            else -> "飞机处于地面计划阶段。预计起飞时间: 09:35。"
                        },
                        color = SubtleGray,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}

@Composable
fun AirportMapScreen(viewModel: MainViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = { viewModel.goBack() }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "航站楼室内智能导航 (AIRPORT MAP)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF0A1424))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                val lobby = Offset(w * 0.5f, h * 0.85f)
                val security = Offset(w * 0.5f, h * 0.55f)
                val gateA12 = Offset(w * 0.35f, h * 0.25f)
                val lounge = Offset(w * 0.65f, h * 0.35f)

                drawRect(
                    color = Color.White.copy(alpha = 0.05f),
                    topLeft = Offset(w * 0.15f, h * 0.15f),
                    size = androidx.compose.ui.geometry.Size(w * 0.7f, h * 0.75f)
                )

                drawLine(Color.White.copy(alpha = 0.1f), lobby, security, strokeWidth = 8.dp.toPx())
                drawLine(Color.White.copy(alpha = 0.1f), security, gateA12, strokeWidth = 8.dp.toPx())
                drawLine(Color.White.copy(alpha = 0.1f), security, lounge, strokeWidth = 8.dp.toPx())

                drawCircle(color = SkyBlue, radius = 10.dp.toPx(), center = lobby)
                drawCircle(color = RedAccent, radius = 10.dp.toPx(), center = security)
                drawCircle(color = GoldAccent, radius = 12.dp.toPx(), center = gateA12)
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 40.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(SkyBlue)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("当前位置 (YOU ARE HERE)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(4.dp))
                        .background(RedAccent)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("安检口 (SECURITY)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(top = 40.dp, start = 20.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(GoldAccent)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("登机口 A12 (GATE A12)", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun BaggageViewScreen(viewModel: MainViewModel) {
    val activeBaggageVal by viewModel.activeBaggage.collectAsStateWithLifecycle()
    var addressInput by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = { viewModel.goBack() }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "行李全流程状态监控 (BAGGAGE)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(text = "我的行李详情", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            activeBaggageVal.forEach { bg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("行李牌号 Tag No:", fontWeight = FontWeight.Bold)
                            Text(bg.id, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("重量 Weight:")
                            Text("${bg.weightKg} kg")
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("当前位置 Position:")
                            Text(bg.location, fontWeight = FontWeight.Bold, color = GoldAccent)
                        }
                    }
                }
            }

            HorizontalDivider()

            Text(text = "行李到家服务预约 (BAGGAGE DELIVERY)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "下了飞机不想拿大行李？预约深航行李到家，专属配送员将在到达层为您提取托运行李，安全配送至您指定的深圳或北京市区住址。",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )

                    OutlinedTextField(
                        value = addressInput,
                        onValueChange = { addressInput = it },
                        label = { Text("配送目的地详细地址 Address") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            viewModel.requestBaggageDelivery(addressInput)
                            addressInput = ""
                        },
                        enabled = addressInput.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("提交配送申请 (Submit Request)")
                    }
                }
            }
        }
    }
}

@Composable
fun DisruptionViewScreen(viewModel: MainViewModel) {
    val activeFlightVal by viewModel.activeFlight.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = { viewModel.goBack() }, modifier = Modifier.size(36.dp)) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    text = "深航出行管家通知与保障中心",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (activeFlightVal?.status == "DELAYED") {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                        border = BorderStroke(1.5.dp, RedAccent),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(imageVector = Icons.Default.Warning, contentDescription = "Warning", tint = RedAccent)
                                Text("航班延误无忧改签保障 (Rebook)", fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                            }
                            Text(
                                text = "由于前序天气原因，您的航班 ZH1234 预计延误 45 分钟。根据深航客规规则，您可以免费改签至今日后续航班，不收取任何手续费。",
                                fontSize = 12.sp,
                                color = Color(0xFFC62828),
                                lineHeight = 18.sp
                            )
                            Button(
                                onClick = { viewModel.performRebooking() },
                                colors = ButtonDefaults.buttonColors(containerColor = RedAccent),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("rebook_btn")
                            ) {
                                Text("立即一键免费改签 (Free Rebook)", color = Color.White)
                            }
                        }
                    }
                }
            }

            item {
                Text(text = "系统消息与历史通知", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
            }

            if (notifications.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        Text("暂无任何消息 (No Notifications)", color = SubtleGray)
                    }
                }
            } else {
                items(notifications) { msg ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = msg.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                                val dateStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(msg.timestamp))
                                Text(text = dateStr, fontSize = 11.sp, color = SubtleGray)
                            }
                            Text(text = msg.content, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SeatIndicatorItem(label: String, color: Color, border: BorderStroke?) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(color)
                .then(if (border != null) Modifier.border(border, RoundedCornerShape(4.dp)) else Modifier)
        )
        Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SeatBox(
    seatId: String,
    isOccupied: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(
                if (isOccupied) Color.DarkGray
                else if (isSelected) GoldAccent
                else Color.White
            )
            .border(
                1.dp,
                if (isSelected) GoldAccent else Color.Gray,
                RoundedCornerShape(6.dp)
            )
            .clickable(enabled = !isOccupied) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = seatId.takeLast(1),
            color = if (isOccupied) Color.LightGray else Color.Black,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

