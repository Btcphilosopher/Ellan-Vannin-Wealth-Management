package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PassengerProfile::class,
        Flight::class,
        Booking::class,
        BaggageRecord::class,
        AppNotification::class,
        ActiveJourneyState::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun passengerProfileDao(): PassengerProfileDao
    abstract fun flightDao(): FlightDao
    abstract fun bookingDao(): BookingDao
    abstract fun baggageRecordDao(): BaggageRecordDao
    abstract fun notificationDao(): NotificationDao
    abstract fun journeyStateDao(): JourneyStateDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "sz_airlines_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
