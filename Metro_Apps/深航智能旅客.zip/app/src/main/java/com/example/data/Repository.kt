package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Repository(private val db: AppDatabase) {

    val profileFlow: Flow<PassengerProfile?> = db.passengerProfileDao().getProfileFlow()
    val allFlightsFlow: Flow<List<Flight>> = db.flightDao().getAllFlightsFlow()
    val activeJourneyFlow: Flow<ActiveJourneyState?> = db.journeyStateDao().getJourneyStateFlow()
    val allBookingsFlow: Flow<List<Booking>> = db.bookingDao().getAllBookingsFlow()
    val notificationsFlow: Flow<List<AppNotification>> = db.notificationDao().getNotificationsFlow()

    fun getFlightFlow(flightId: String): Flow<Flight?> = db.flightDao().getFlightFlow(flightId)
    fun getBookingFlow(bookingId: String): Flow<Booking?> = db.bookingDao().getBookingFlow(bookingId)
    fun getBaggageFlow(bookingId: String): Flow<List<BaggageRecord>> = db.baggageRecordDao().getBaggageFlowForBooking(bookingId)

    suspend fun getProfile(): PassengerProfile? = db.passengerProfileDao().getProfile()
    suspend fun updateProfile(profile: PassengerProfile) = db.passengerProfileDao().insertProfile(profile)

    suspend fun getFlight(flightId: String): Flight? = db.flightDao().getFlight(flightId)
    suspend fun updateFlight(flight: Flight) = db.flightDao().updateFlight(flight)
    suspend fun insertFlight(flight: Flight) = db.flightDao().insertFlight(flight)

    suspend fun getBooking(bookingId: String): Booking? = db.bookingDao().getBooking(bookingId)
    suspend fun insertBooking(booking: Booking) = db.bookingDao().insertBooking(booking)
    suspend fun updateBooking(booking: Booking) = db.bookingDao().updateBooking(booking)

    suspend fun getJourneyState(): ActiveJourneyState? = db.journeyStateDao().getJourneyState()
    suspend fun insertJourneyState(state: ActiveJourneyState) = db.journeyStateDao().insertJourneyState(state)
    suspend fun updateJourneyState(state: ActiveJourneyState) = db.journeyStateDao().updateJourneyState(state)

    suspend fun insertBaggage(baggage: BaggageRecord) = db.baggageRecordDao().insertBaggage(baggage)
    suspend fun updateBaggage(baggage: BaggageRecord) = db.baggageRecordDao().updateBaggage(baggage)

    suspend fun insertNotification(title: String, content: String) {
        db.notificationDao().insertNotification(
            AppNotification(title = title, content = content, timestamp = System.currentTimeMillis())
        )
    }
    suspend fun deleteNotification(id: Int) = db.notificationDao().deleteNotification(id)
    suspend fun clearNotifications() = db.notificationDao().clearAll()

    suspend fun seedDatabase() {
        // Check if already seeded
        val existingProfile = getProfile()
        if (existingProfile != null) return

        // 1. Seed Passenger Profile (Tom)
        val tomProfile = PassengerProfile(
            id = "profile_tom",
            name = "Tom",
            documentType = "护照 (Passport)",
            documentNumber = "EE12345678",
            birthDate = "1994-08-15",
            mobile = "+86 138****9922",
            email = "tom@ahyx.org",
            phoenixMilesNumber = "ZH953610992",
            tier = "金卡 (Gold)",
            miles = 18420,
            yearMiles = 24000,
            redeemableMiles = 18420
        )
        db.passengerProfileDao().insertProfile(tomProfile)

        // 2. Seed Flights
        val flights = listOf(
            Flight(
                id = "ZH1234-20261012",
                flightNumber = "ZH1234",
                departureCity = "深圳",
                departureCode = "SZX",
                arrivalCity = "北京",
                arrivalCode = "PEK",
                scheduledDeparture = "09:35",
                scheduledArrival = "12:55",
                gate = "A12",
                terminal = "T3",
                checkInCounter = "C08-C12",
                aircraftType = "波音787-9 (Dreamliner)",
                status = "ON_TIME",
                basePrice = 860
            ),
            Flight(
                id = "ZH1235-20261012",
                flightNumber = "ZH1235",
                departureCity = "北京",
                departureCode = "PEK",
                arrivalCity = "深圳",
                arrivalCode = "SZX",
                scheduledDeparture = "14:20",
                scheduledArrival = "17:45",
                gate = "C23",
                terminal = "T3",
                checkInCounter = "F04-F08",
                aircraftType = "空中客车A350-900",
                status = "ON_TIME",
                basePrice = 920
            ),
            Flight(
                id = "ZH4567-20261012",
                flightNumber = "ZH4567",
                departureCity = "深圳",
                departureCode = "SZX",
                arrivalCity = "上海",
                arrivalCode = "SHA",
                scheduledDeparture = "10:15",
                scheduledArrival = "12:30",
                gate = "B15",
                terminal = "T3",
                checkInCounter = "C05-C07",
                aircraftType = "空中客车A320neo",
                status = "ON_TIME",
                basePrice = 680
            ),
            Flight(
                id = "ZH4568-20261012",
                flightNumber = "ZH4568",
                departureCity = "上海",
                departureCode = "SHA",
                arrivalCity = "深圳",
                arrivalCode = "SZX",
                scheduledDeparture = "13:45",
                scheduledArrival = "16:10",
                gate = "A02",
                terminal = "T2",
                checkInCounter = "D10-D12",
                aircraftType = "空中客车A320neo",
                status = "ON_TIME",
                basePrice = 710
            ),
            Flight(
                id = "ZH7890-20261012",
                flightNumber = "ZH7890",
                departureCity = "深圳",
                departureCode = "SZX",
                arrivalCity = "成都",
                arrivalCode = "CTU",
                scheduledDeparture = "08:00",
                scheduledArrival = "10:30",
                gate = "A22",
                terminal = "T3",
                checkInCounter = "C01-C03",
                aircraftType = "波音737-800",
                status = "ON_TIME",
                basePrice = 780
            ),
            Flight(
                id = "ZH7891-20261012",
                flightNumber = "ZH7891",
                departureCity = "成都",
                departureCode = "CTU",
                arrivalCity = "深圳",
                arrivalCode = "SZX",
                scheduledDeparture = "11:45",
                scheduledArrival = "14:15",
                gate = "106",
                terminal = "T2",
                checkInCounter = "H01-H04",
                aircraftType = "波音737-800",
                status = "ON_TIME",
                basePrice = 800
            ),
            Flight(
                id = "ZH8912-20261012",
                flightNumber = "ZH8912",
                departureCity = "深圳",
                departureCode = "SZX",
                arrivalCity = "西安",
                arrivalCode = "XIY",
                scheduledDeparture = "15:30",
                scheduledArrival = "18:05",
                gate = "A31",
                terminal = "T3",
                checkInCounter = "C15-C17",
                aircraftType = "空中客车A330-300",
                status = "ON_TIME",
                basePrice = 640
            ),
            Flight(
                id = "ZH8913-20261012",
                flightNumber = "ZH8913",
                departureCity = "西安",
                departureCode = "XIY",
                arrivalCity = "深圳",
                arrivalCode = "SZX",
                scheduledDeparture = "19:15",
                scheduledArrival = "21:50",
                gate = "228",
                terminal = "T3",
                checkInCounter = "T01-T03",
                aircraftType = "空中客车A330-300",
                status = "ON_TIME",
                basePrice = 670
            )
        )
        for (f in flights) {
            db.flightDao().insertFlight(f)
        }

        // 3. Seed active booking (ZH88992, Flight ZH1234, Ticketed)
        val initialBooking = Booking(
            id = "ZH88992",
            flightId = "ZH1234-20261012",
            passengerId = "profile_tom",
            seatNumber = "18A",
            mealSelected = "粤式点心 (Cantonese Dim Sum)",
            extraBaggageKg = 0,
            transitHotelBooked = false,
            baggageDeliveryRequest = false,
            status = "TICKETED",
            paymentMethod = "WECHAT",
            cashPaid = 1020, // Ticket 860 + Tax 50 + Fuel 110
            milesPaid = 0,
            createdTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        )
        db.bookingDao().insertBooking(initialBooking)

        // 4. Seed Checked Baggage
        val initialBaggage = BaggageRecord(
            id = "ZH-BG-9921",
            bookingId = "ZH88992",
            type = "CHECKED",
            weightKg = 18.5,
            status = "CHECKED_IN",
            location = "SZX 航站楼 T3 托运柜台已接收"
        )
        db.baggageRecordDao().insertBaggage(initialBaggage)

        // 5. Seed Journey State
        val initialJourneyState = ActiveJourneyState(
            bookingId = "ZH88992",
            stage = "BOOKED",
            isAirportMode = false
        )
        db.journeyStateDao().insertJourneyState(initialJourneyState)

        // 6. Seed some default messages / notifications
        insertNotification(
            title = "深航出行管家提示",
            content = "您的航班 ZH1234 (深圳 SZX → 北京 PEK) 将于10月12日 09:35 起飞。请提前完成选座值机。"
        )
    }
}
