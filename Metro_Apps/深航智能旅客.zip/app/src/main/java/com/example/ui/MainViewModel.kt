package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.simulation.FlightSimulator
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = Repository(db)
    private val simulator = FlightSimulator(repository)

    // Base UI Navigation State
    val currentTab = MutableStateFlow(0) // 0: Home, 1: Trips, 2: Services, 3: PhoenixMiles, 4: Me

    // Sub-screen Navigation state
    // "DEFAULT", "SEARCH_RESULTS", "BOOKING_CONFIRMATION", "CHECK_IN_FLOW", "BOARDING_PASS_VIEW", "FLIGHT_MAP", "AIRPORT_MAP", "BAGGAGE_VIEW", "DISRUPTION_VIEW"
    val subScreen = MutableStateFlow("DEFAULT")

    // Active Data Flows from Room Database
    val profile: StateFlow<PassengerProfile?> = repository.profileFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeJourney: StateFlow<ActiveJourneyState?> = repository.activeJourneyFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allBookings: StateFlow<List<Booking>> = repository.allBookingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<AppNotification>> = repository.notificationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFlights: StateFlow<List<Flight>> = repository.allFlightsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Derived active journey items
    private val _activeBookingId = activeJourney.map { it?.bookingId ?: "ZH88992" }
    
    val activeBooking: StateFlow<Booking?> = _activeBookingId.flatMapLatest { id ->
        repository.getBookingFlow(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeFlight: StateFlow<Flight?> = activeBooking.flatMapLatest { booking ->
        if (booking != null) repository.getFlightFlow(booking.flightId) else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeBaggage: StateFlow<List<BaggageRecord>> = activeBooking.flatMapLatest { booking ->
        if (booking != null) repository.getBaggageFlow(booking.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Flight Search UI state
    val searchFromCity = MutableStateFlow("深圳")
    val searchFromCode = MutableStateFlow("SZX")
    val searchToCity = MutableStateFlow("北京")
    val searchToCode = MutableStateFlow("PEK")
    val searchCabin = MutableStateFlow("经济舱 (Economy)")
    val searchPassengerCount = MutableStateFlow(1)
    val searchTripType = MutableStateFlow("单程 (One Way)") // "单程 (One Way)", "往返 (Round Trip)"

    val searchResults = MutableStateFlow<List<Flight>>(emptyList())
    val selectedFlightForBooking = MutableStateFlow<Flight?>(null)

    // Booking Flow state
    val bookingExtraBaggageKg = MutableStateFlow(0)
    val bookingMealSelected = MutableStateFlow("标准配餐 (Standard Meal)")
    val bookingHotelBooked = MutableStateFlow(false)
    val bookingPaymentMethod = MutableStateFlow("ALIPAY") // ALIPAY, WECHAT, BANK_CARD, MILES_CASH
    val bookingUseMilesCash = MutableStateFlow(false)
    val bookingMilesToUse = MutableStateFlow(12000)

    // Online Check-in & Seat selection
    val checkinStep = MutableStateFlow(0) // 0: Select Seat, 1: Confirm Baggage, 2: Completed
    val selectedSeatNumber = MutableStateFlow("")

    init {
        viewModelScope.launch {
            repository.seedDatabase()
        }
    }

    // --- Tab / Screen Navigation ---
    fun navigateToTab(tabIndex: Int) {
        currentTab.value = tabIndex
        subScreen.value = "DEFAULT"
    }

    fun navigateToSubScreen(screen: String) {
        subScreen.value = screen
    }

    fun goBack() {
        subScreen.value = "DEFAULT"
    }

    // --- Search & Booking Logic ---
    fun performSearch() {
        viewModelScope.launch {
            val flights = allFlights.value.filter {
                it.departureCity == searchFromCity.value && it.arrivalCity == searchToCity.value
            }
            searchResults.value = flights
            navigateToSubScreen("SEARCH_RESULTS")
        }
    }

    fun selectFlight(flight: Flight) {
        selectedFlightForBooking.value = flight
        bookingExtraBaggageKg.value = 0
        bookingMealSelected.value = "标准配餐 (Standard Meal)"
        bookingHotelBooked.value = false
        bookingPaymentMethod.value = "WECHAT"
        bookingUseMilesCash.value = false
        navigateToSubScreen("BOOKING_DETAILS")
    }

    fun calculateTotalPayment(): Int {
        val flight = selectedFlightForBooking.value ?: return 0
        var total = flight.basePrice + 50 + 110 // Base + Tax + Fuel
        total += bookingExtraBaggageKg.value * 30 // ¥30 per extra kg
        if (bookingHotelBooked.value) {
            total += 180 // Simulated transit hotel surcharge (if co-pay is active)
        }
        return total
    }

    fun confirmBooking() {
        val flight = selectedFlightForBooking.value ?: return
        viewModelScope.launch {
            val totalAmount = calculateTotalPayment()
            var cashToPay = totalAmount
            var milesToPay = 0

            if (bookingUseMilesCash.value) {
                val userMiles = profile.value?.miles ?: 0
                val milesApplicable = if (userMiles >= bookingMilesToUse.value) bookingMilesToUse.value else userMiles
                milesToPay = milesApplicable
                // Rule Engine: 100 miles = 5 CNY discount
                val discount = (milesApplicable / 100) * 5
                cashToPay = (totalAmount - discount).coerceAtLeast(0)

                // Update user mileage
                val currentProfile = profile.value
                if (currentProfile != null) {
                    val updatedProfile = currentProfile.copy(
                        miles = currentProfile.miles - milesToPay,
                        redeemableMiles = currentProfile.redeemableMiles - milesToPay
                    )
                    repository.updateProfile(updatedProfile)
                }
            }

            val bookingId = "ZH" + (10000..99999).random()
            val newBooking = Booking(
                id = bookingId,
                flightId = flight.id,
                passengerId = "profile_tom",
                seatNumber = "", // Empty initially for check-in
                mealSelected = bookingMealSelected.value,
                extraBaggageKg = bookingExtraBaggageKg.value,
                transitHotelBooked = bookingHotelBooked.value,
                status = "TICKETED",
                paymentMethod = if (bookingUseMilesCash.value) "MILES_CASH" else bookingPaymentMethod.value,
                cashPaid = cashToPay,
                milesPaid = milesToPay,
                createdTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            )
            repository.insertBooking(newBooking)

            // Make it the active journey
            val currentJourney = activeJourney.value
            if (currentJourney != null) {
                repository.insertJourneyState(
                    currentJourney.copy(
                        bookingId = bookingId,
                        stage = "BOOKED",
                        isAirportMode = false
                    )
                )
            }

            // Create initial baggage record
            repository.insertBaggage(
                BaggageRecord(
                    id = "ZH-BG-" + (1000..9999).random(),
                    bookingId = bookingId,
                    type = "CHECKED",
                    weightKg = 15.0 + bookingExtraBaggageKg.value,
                    status = "CHECKED_IN",
                    location = "深圳宝安 T3 登机办理处"
                )
            )

            // Notification
            repository.insertNotification(
                "购票成功 (TICKETED)",
                "【深圳航空】您已成功购买 ${flight.departureCity} 飞往 ${flight.arrivalCity} 的 ZH${flight.flightNumber} 航班。机票已生成，订单编号: $bookingId。"
            )

            navigateToSubScreen("BOOKING_CONFIRMATION")
        }
    }

    // --- Check-in & Seat selection ---
    fun startCheckin() {
        selectedSeatNumber.value = ""
        checkinStep.value = 0
        navigateToSubScreen("CHECK_IN_FLOW")
    }

    fun selectSeat(seat: String) {
        selectedSeatNumber.value = seat
    }

    fun advanceCheckinStep() {
        if (checkinStep.value == 0) {
            if (selectedSeatNumber.value.isEmpty()) return
            checkinStep.value = 1
        } else if (checkinStep.value == 1) {
            viewModelScope.launch {
                val bookingVal = activeBooking.value
                val stateVal = activeJourney.value
                if (bookingVal != null && stateVal != null) {
                    // Update seat and status
                    val updatedBooking = bookingVal.copy(seatNumber = selectedSeatNumber.value)
                    repository.updateBooking(updatedBooking)

                    // Advance stage to CHECKED_IN
                    val updatedState = stateVal.copy(stage = "CHECKED_IN")
                    repository.updateJourneyState(updatedState)

                    // Add Notification
                    repository.insertNotification(
                        "选座值机成功 (CHECKED IN)",
                        "您已顺利完成在线选座值机。座位号: ${selectedSeatNumber.value}。请查看您的电子登机牌。"
                    )
                }
                checkinStep.value = 2
            }
        }
    }

    // --- Baggage Delivery / 行李到家 ---
    fun requestBaggageDelivery(address: String) {
        viewModelScope.launch {
            val bookingVal = activeBooking.value
            if (bookingVal != null) {
                val updatedBooking = bookingVal.copy(
                    baggageDeliveryRequest = true,
                    baggageDeliveryAddress = address
                )
                repository.updateBooking(updatedBooking)
                repository.insertNotification(
                    "行李到家服务申请成功",
                    "深航行李管家已收到您的‘行李到家’配送申请。目的地: $address。"
                )
            }
        }
    }

    // --- Disruption & Rebooking ---
    fun performRebooking() {
        viewModelScope.launch {
            simulator.rebookFlight()
            subScreen.value = "DEFAULT"
        }
    }

    fun refundTicket(bookingId: String) {
        viewModelScope.launch {
            val bookingVal = repository.getBooking(bookingId)
            if (bookingVal != null) {
                val refundedBooking = bookingVal.copy(status = "REFUNDED")
                repository.updateBooking(refundedBooking)
                repository.insertNotification(
                    "退票处理完成 (REFUNDED)",
                    "【深圳航空】您的退票申请已处理完成。退款金额 ¥${bookingVal.cashPaid} 将原路退回您的支付账户。"
                )
            }
        }
    }

    // --- Simulator Controller actions ---
    fun simulateNextStage() {
        viewModelScope.launch {
            simulator.advanceStage()
        }
    }

    fun simulateInjectDelay() {
        viewModelScope.launch {
            simulator.injectDelay()
        }
    }
}
