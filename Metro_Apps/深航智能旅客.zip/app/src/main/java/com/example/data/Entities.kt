package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "passenger_profiles")
data class PassengerProfile(
    @PrimaryKey val id: String = "profile_tom",
    val name: String,
    val documentType: String,
    val documentNumber: String,
    val birthDate: String,
    val mobile: String,
    val email: String,
    val phoenixMilesNumber: String,
    val tier: String, // PhoenixMiles Tier: "白金卡" (Platinum), "金卡" (Gold), "银卡" (Silver), "普通卡" (Regular)
    val miles: Int,
    val yearMiles: Int,
    val redeemableMiles: Int
)

@Entity(tableName = "flights")
data class Flight(
    @PrimaryKey val id: String, // e.g. "ZH1234-20261012"
    val flightNumber: String, // e.g. "ZH1234"
    val departureCity: String, // e.g. "深圳"
    val departureCode: String, // e.g. SZX
    val arrivalCity: String, // e.g. "北京"
    val arrivalCode: String, // e.g. PEK
    val scheduledDeparture: String, // e.g. "09:35"
    val scheduledArrival: String, // e.g. "12:55"
    val gate: String,
    val terminal: String,
    val checkInCounter: String,
    val aircraftType: String, // e.g. "B787-9" or "A350-900"
    val status: String, // "ON_TIME", "DELAYED", "CANCELLED"
    val delayMinutes: Int = 0,
    val mealDescription: String = "粤式点心 / 经典深航牛肉面 (Cantonese Dim Sum / Signature Beef Noodles)",
    val basePrice: Int = 860
)

@Entity(tableName = "bookings")
data class Booking(
    @PrimaryKey val id: String, // Booking Reference, e.g. "ZH88992"
    val flightId: String,
    val passengerId: String,
    val seatNumber: String, // Empty if not selected yet
    val mealSelected: String = "未选择",
    val extraBaggageKg: Int = 0,
    val transitHotelBooked: Boolean = false,
    val baggageDeliveryRequest: Boolean = false,
    val baggageDeliveryAddress: String = "",
    val status: String, // "PENDING", "PAID", "TICKETED", "USED", "CANCELLED", "REFUNDING", "REFUNDED"
    val paymentMethod: String = "", // "ALIPAY", "WECHAT", "BANK_CARD", "MILES_CASH"
    val cashPaid: Int = 0,
    val milesPaid: Int = 0,
    val createdTime: String
)

@Entity(tableName = "baggage_records")
data class BaggageRecord(
    @PrimaryKey val id: String, // Tag number, e.g. "ZH-BG-9921"
    val bookingId: String,
    val type: String, // "CHECKED", "CABIN"
    val weightKg: Double,
    val status: String, // "CHECKED_IN", "LOADING", "IN_TRANSIT", "ARRIVED", "DELIVERED"
    val location: String // e.g. "T3 行李分拣区", "SZX-PEK 货舱", "PEK 34号转盘"
)

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

// Active active journey state for simulation
@Entity(tableName = "journey_state")
data class ActiveJourneyState(
    @PrimaryKey val id: String = "active_journey",
    val bookingId: String,
    // Journey Stages: "BOOKED", "CHECKED_IN", "TO_AIRPORT", "SECURITY", "BOARDING", "DEPARTED", "CRUISE", "DESCENDING", "ARRIVED", "BAGGAGE_CLAIM", "COMPLETE"
    val stage: String,
    val isAirportMode: Boolean = false,
    val simulatorSpeedMultiplier: Float = 1.0f
)
