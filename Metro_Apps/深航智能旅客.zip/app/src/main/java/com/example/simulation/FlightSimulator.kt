package com.example.simulation

import com.example.data.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FlightSimulator(private val repository: Repository) {

    suspend fun advanceStage() {
        val currentState = repository.getJourneyState() ?: return
        val currentStage = currentState.stage
        val booking = repository.getBooking(currentState.bookingId) ?: return
        val flight = repository.getFlight(booking.flightId) ?: return
        val profile = repository.getProfile() ?: return

        val (nextStage, isAirportMode) = when (currentStage) {
            "BOOKED" -> "CHECKED_IN" to false
            "CHECKED_IN" -> "TO_AIRPORT" to true
            "TO_AIRPORT" -> "SECURITY" to true
            "SECURITY" -> "BOARDING" to true
            "BOARDING" -> "DEPARTED" to true
            "DEPARTED" -> "CRUISE" to false
            "CRUISE" -> "DESCENDING" to false
            "DESCENDING" -> "ARRIVED" to false
            "ARRIVED" -> "BAGGAGE_CLAIM" to false
            "BAGGAGE_CLAIM" -> "COMPLETE" to false
            "COMPLETE" -> "BOOKED" to false // Loop back for demo purposes
            else -> "BOOKED" to false
        }

        // Apply state consequences in database
        val updatedState = currentState.copy(stage = nextStage, isAirportMode = isAirportMode)
        repository.insertJourneyState(updatedState)

        when (nextStage) {
            "BOOKED" -> {
                // Reset everything to original seeded state
                val resetFlight = flight.copy(
                    status = "ON_TIME",
                    delayMinutes = 0,
                    gate = "A12",
                    scheduledArrival = "12:55"
                )
                repository.updateFlight(resetFlight)

                val resetBooking = booking.copy(
                    status = "TICKETED",
                    seatNumber = "18A",
                    baggageDeliveryRequest = false
                )
                repository.updateBooking(resetBooking)

                val resetProfile = profile.copy(
                    miles = 18420,
                    redeemableMiles = 18420
                )
                repository.updateProfile(resetProfile)

                // Re-seed original baggage
                repository.insertBaggage(
                    BaggageRecord(
                        id = "ZH-BG-9921",
                        bookingId = booking.id,
                        type = "CHECKED",
                        weightKg = 18.5,
                        status = "CHECKED_IN",
                        location = "SZX 航站楼 T3 托运柜台已接收"
                    )
                )

                repository.insertNotification(
                    "行程已重置",
                    "模拟旅程已重置为已购票状态 (BOOKED)。"
                )
            }
            "CHECKED_IN" -> {
                // Ensure seat is selected
                val updatedBooking = booking.copy(seatNumber = "18A")
                repository.updateBooking(updatedBooking)

                repository.insertNotification(
                    "值机完成提示 (CHECKED IN)",
                    "您已成功办理值机。座位号: 18A (靠窗/经济舱)。电子登机牌已为您生成。"
                )
            }
            "TO_AIRPORT" -> {
                repository.insertNotification(
                    "深航机场出行提示 (TO AIRPORT)",
                    "今天深圳宝安 T3 航站楼交通畅通。您的航班预计 09:35 起飞，建议您尽快前往机场。"
                )
            }
            "SECURITY" -> {
                // Update baggage status
                val bg = repository.getBaggageFlow(booking.id)
                repository.insertNotification(
                    "安全检查已通过 (SECURITY)",
                    "您已通过人身和随身行李安全检查。请前往 A12 登机口，距离您 280 米，步行约 4 分钟。"
                )
            }
            "BOARDING" -> {
                repository.insertNotification(
                    "航班开始登机通知 (BOARDING)",
                    "深航 ZH1234 航班现已在 A12 登机口开始登机。请您出示电子登机牌，有序登机。"
                )
            }
            "DEPARTED" -> {
                // Flight status is live
                val liveFlight = flight.copy(status = "LIVE")
                repository.updateFlight(liveFlight)

                // Update baggage to loading
                val bgList = listOf(
                    BaggageRecord(
                        id = "ZH-BG-9921",
                        bookingId = booking.id,
                        type = "CHECKED",
                        weightKg = 18.5,
                        status = "LOADING",
                        location = "ZH1234 飞机货仓装载完成"
                    )
                )
                repository.insertBaggage(bgList[0])

                repository.insertNotification(
                    "航班已起飞 (DEPARTED)",
                    "ZH1234 航班已于 09:38 从深圳宝安机场顺利起飞。巡航高度 10,100米。预计抵达时间 12:55。"
                )
            }
            "CRUISE" -> {
                val bgList = listOf(
                    BaggageRecord(
                        id = "ZH-BG-9921",
                        bookingId = booking.id,
                        type = "CHECKED",
                        weightKg = 18.5,
                        status = "IN_TRANSIT",
                        location = "在途 (飞行高度 10,400米)"
                    )
                )
                repository.insertBaggage(bgList[0])

                repository.insertNotification(
                    "航班平稳飞行中 (CRUISE)",
                    "ZH1234 航班当前正处于巡航状态，正飞越武汉上空。客舱开始提供热餐服务。"
                )
            }
            "DESCENDING" -> {
                repository.insertNotification(
                    "航班开始下降 (DESCENDING)",
                    "ZH1234 航班已开始下降，预计 25 分钟后降落北京首都国际机场。请您系好安全带。"
                )
            }
            "ARRIVED" -> {
                val liveFlight = flight.copy(status = "ARRIVED")
                repository.updateFlight(liveFlight)

                repository.insertNotification(
                    "欢迎抵达北京 (ARRIVED)",
                    "ZH1234 航班已于 12:52 降落北京首都 T3 航站楼。感谢您选择深圳航空，祝您在北京生活愉快！"
                )
            }
            "BAGGAGE_CLAIM" -> {
                val claimBaggage = BaggageRecord(
                    id = "ZH-BG-9921",
                    bookingId = booking.id,
                    type = "CHECKED",
                    weightKg = 18.5,
                    status = "ARRIVED",
                    location = "北京首都 T3 34号行李转盘"
                )
                repository.insertBaggage(claimBaggage)

                repository.insertNotification(
                    "行李提取提示 (BAGGAGE CLAIM)",
                    "您的行李已运达北京首都 T3 34号行李转盘。请凭借托运条码核对提取。"
                )
            }
            "COMPLETE" -> {
                // Update booking status
                val completeBooking = booking.copy(status = "USED")
                repository.updateBooking(completeBooking)

                // Credit Miles
                val creditMiles = 1240
                val updatedProfile = profile.copy(
                    miles = profile.miles + creditMiles,
                    redeemableMiles = profile.redeemableMiles + creditMiles
                )
                repository.updateProfile(updatedProfile)

                repository.insertNotification(
                    "里程已到账提示 (MILES CREDITED)",
                    "感谢您的出行！本次乘机为您累积的 1,240 凤凰知音里程已计入您的账户。当前里程余额: ${updatedProfile.redeemableMiles}。"
                )
            }
        }
    }

    suspend fun injectDelay() {
        val currentState = repository.getJourneyState() ?: return
        val booking = repository.getBooking(currentState.bookingId) ?: return
        val flight = repository.getFlight(booking.flightId) ?: return

        // Toggle delay state
        if (flight.delayMinutes == 0) {
            // Inject +45 mins delay
            val delayedFlight = flight.copy(
                status = "DELAYED",
                delayMinutes = 45,
                scheduledArrival = "13:40"
            )
            repository.updateFlight(delayedFlight)

            repository.insertNotification(
                "航班延误警报 (FLIGHT DELAY)",
                "【深圳航空】尊敬的旅客：您乘坐的 ZH1234 航班因天气原因预计延误45分钟，起飞时间调整为10:20。给您带来不便，深表歉意。"
            )
        } else {
            // Restore to normal
            val normalFlight = flight.copy(
                status = "ON_TIME",
                delayMinutes = 0,
                scheduledArrival = "12:55"
            )
            repository.updateFlight(normalFlight)

            repository.insertNotification(
                "航班状态恢复正常 (FLIGHT RESTORED)",
                "【深圳航空】尊敬的旅客：ZH1234 航班运力及天气情况已恢复正常，起飞时间恢复为 09:35。请各位旅客按时前往登机口。"
            )
        }
    }

    suspend fun rebookFlight() {
        // Passenger clicks Rebook during disruption
        val currentState = repository.getJourneyState() ?: return
        val booking = repository.getBooking(currentState.bookingId) ?: return
        val flight = repository.getFlight(booking.flightId) ?: return

        if (flight.status == "DELAYED") {
            // Simulate rebooking to later flight (e.g., ZH1238 or a special relief flight)
            val rebookedFlight = flight.copy(
                id = "ZH1234-REBOOKED",
                flightNumber = "ZH1234 (重安排)",
                status = "ON_TIME",
                delayMinutes = 0,
                gate = "A15",
                scheduledDeparture = "11:15",
                scheduledArrival = "14:35"
            )
            repository.insertFlight(rebookedFlight)

            val updatedBooking = booking.copy(
                flightId = "ZH1234-REBOOKED",
                seatNumber = "12C" // New Seat
            )
            repository.updateBooking(updatedBooking)

            repository.insertNotification(
                "航班改签成功通知 (REBOOKED)",
                "您已成功改签。新航班 ZH1234 将于 11:15 在 A15 登机口起飞。新座位: 12C (靠过道)。"
            )
        }
    }
}
