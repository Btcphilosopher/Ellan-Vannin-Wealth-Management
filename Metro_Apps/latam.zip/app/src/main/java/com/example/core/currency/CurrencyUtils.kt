package com.example.core.currency

import java.text.NumberFormat
import java.util.Locale

object CurrencyUtils {
    fun formatClp(amount: Int): String {
        val formatter = NumberFormat.getInstance(Locale("es", "CL"))
        return "CLP $${formatter.format(amount)}"
    }
}
