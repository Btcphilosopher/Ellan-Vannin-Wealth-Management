package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LATAM Brand Colors
val LatamNavy = Color(0xFF0F1A3A)
val LatamNavyLight = Color(0xFF1D2B56)
val LatamRed = Color(0xFFE2001A)
val LatamRedDark = Color(0xFFB30012)
val LatamGold = Color(0xFFD4AF37)
val LatamGoldLight = Color(0xFFFFF7DB)

val LatamBackground = Color(0xFFF6F8FC)
val LatamSurface = Color(0xFFFFFFFF)
val LatamSurfaceVariant = Color(0xFFEEF2F8)
val LatamTextPrimary = Color(0xFF0D1424)
val LatamTextSecondary = Color(0xFF5A667A)
val LatamBorder = Color(0xFFE2E8F0)

val StatusGreen = Color(0xFF10B981)
val StatusOrange = Color(0xFFF59E0B)
val StatusRed = Color(0xFFEF4444)
val StatusBlue = Color(0xFF3B82F6)

