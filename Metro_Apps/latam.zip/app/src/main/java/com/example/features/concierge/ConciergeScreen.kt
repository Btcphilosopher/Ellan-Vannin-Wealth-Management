package com.example.features.concierge

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun ConciergeScreen(viewModel: MainViewModel) {
    var userMessage by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            "¡Hola, Tomás! Soy tu Asistente Virtual LATAM. ¿En qué te puedo ayudar hoy con tu viaje a Lima?"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
            .testTag("concierge_screen")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "ASISTENCIA INTELIGENTE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "CONCIERGE LATAM",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            messages.forEach { msg ->
                Card(
                    modifier = Modifier.fillMaxWidth(0.85f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = LatamSurfaceVariant)
                ) {
                    Text(
                        text = msg,
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodyMedium.copy(color = LatamNavy)
                    )
                }
            }
        }

        // Quick prompt chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SuggestionChip(
                onClick = {
                    messages.add("¿Cuál es mi equipaje permitido?")
                    messages.add("Tu tarifa en el vuelo LA 640 incluye 1 bolso de mano (10kg) y 1 equipaje en bodega (23kg).")
                },
                label = { Text("Equipaje") }
            )
            SuggestionChip(
                onClick = {
                    messages.add("¿A qué hora abre el mostrador en SCL?")
                    messages.add("El mostrador en SCL para vuelos internacionales abre a las 05:30 AM (3 horas antes de la salida).")
                },
                label = { Text("Horarios Mostrador") }
            )
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .padding(12.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = userMessage,
                    onValueChange = { userMessage = it },
                    placeholder = { Text("Escribe tu consulta...") },
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (userMessage.isNotBlank()) {
                            val q = userMessage
                            messages.add(q)
                            userMessage = ""
                            messages.add("Procesando tu consulta sobre '$q'. En vuelos de demostración te recomendamos verificar tu puerta de embarque en el panel del aeropuerto SCL.")
                        }
                    },
                    modifier = Modifier.background(LatamNavy, RoundedCornerShape(8.dp))
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = "Enviar", tint = Color.White)
                }
            }
        }
    }
}
