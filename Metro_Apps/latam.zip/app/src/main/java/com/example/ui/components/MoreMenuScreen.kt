package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun MoreMenuScreen(
    onNavigateTo: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
            .verticalScroll(rememberScrollState())
            .testTag("more_menu_screen")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "SERVICIOS Y CONFIGURACIÓN",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "MÁS OPCIONES",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            MoreMenuItem("Modo Desarrollador y Simulador", "Prueba estados, reloj simulado y registros", Icons.Default.Build, "developer_mode", onNavigateTo)
            MoreMenuItem("Seguimiento de Vuelo", "Consulta el estado en tiempo real de vuelos LATAM", Icons.Default.Schedule, "flight_status", onNavigateTo)
            MoreMenuItem("Mapa de Aeropuerto SCL", "Ubicación esquemática de salas VIP, puertas y servicios", Icons.Default.Map, "airport_map", onNavigateTo)
            MoreMenuItem("Modo Día de Viaje", "Panel concentrado de actividades el día del vuelo", Icons.Default.FlightLand, "airport_mode", onNavigateTo)
            MoreMenuItem("Concierge Virtual", "Asistente de viaje para preguntas frecuentes", Icons.Default.SupportAgent, "concierge", onNavigateTo)
            MoreMenuItem("Equipaje y Servicios", "Gestiona tu franquicia e imprevistos", Icons.Default.Luggage, "baggage", onNavigateTo)
            MoreMenuItem("Servicios Adicionales", "eSIM, Asistencia médica, Upgrades, Hoteles", Icons.Default.MoreHoriz, "extras", onNavigateTo)
            MoreMenuItem("Mi Perfil", "Datos personales del pasajero ficticio", Icons.Default.Person, "profile", onNavigateTo)
            MoreMenuItem("Centro de Notificaciones", "Historial de alertas y avisos de vuelo", Icons.Default.Notifications, "notifications", onNavigateTo)
        }
    }
}

@Composable
fun MoreMenuItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    route: String,
    onNavigateTo: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigateTo(route) },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, LatamBorder)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = LatamNavy, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))
            }
            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = LatamTextSecondary)
        }
    }
}
