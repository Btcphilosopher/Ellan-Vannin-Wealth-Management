package com.example.data.providers

import com.example.core.model.*
import java.util.UUID

object DemoBookingProvider {
    fun generatePnr(): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return "LA" + (1..4).map { chars.random() }.joinToString("")
    }

    fun createDemoBooking(
        flight: Flight,
        passenger: Passenger,
        cabinClass: CabinClass,
        farePrice: Int,
        selectedSeat: String = "14A",
        checkedBaggageCount: Int = 1
    ): Booking {
        val pnr = generatePnr()
        return Booking(
            pnrCode = pnr,
            flightNumber = flight.flightNumber,
            originCode = flight.origin.code,
            originCity = flight.origin.city,
            destinationCode = flight.destination.code,
            destinationCity = flight.destination.city,
            departureDate = "Mañana",
            departureTime = flight.departureTime,
            arrivalTime = flight.arrivalTime,
            passengerName = "${passenger.firstName} ${passenger.lastName}",
            cabinClass = cabinClass.displayName,
            status = BookingStatus.PENDIENTE_DE_PAGO.name,
            seatNumber = selectedSeat,
            checkedBaggageCount = checkedBaggageCount,
            totalPriceClp = farePrice,
            gate = flight.gate,
            terminal = flight.terminal,
            checkInCompleted = false
        )
    }
}

object DemoPaymentProvider {
    suspend fun processDemoPayment(
        pnrCode: String,
        amountClp: Int,
        paymentMethodName: String = "Tarjeta Crédito Ficticia **** 4920"
    ): Boolean {
        // Simulated network delay
        kotlinx.coroutines.delay(800)
        return true
    }
}
