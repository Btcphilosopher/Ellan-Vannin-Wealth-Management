package com.example.features.extras

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun ExtrasScreen(viewModel: MainViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
            .verticalScroll(rememberScrollState())
            .testTag("extras_screen")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "COMPLEMENTA TU EXPERIENCIA",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "SERVICIOS ADICIONALES",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ExtraItemCard("eSIM LATAM Travel Data", "Internet ilimitado en tu destino desde $8.990 CLP", Icons.Default.SimCard)
            ExtraItemCard("Asistencia Médica y Seguro de Viaje", "Cobertura completa ante contingencias desde $12.500 CLP", Icons.Default.MedicalServices)
            ExtraItemCard("Upgrade a Cabina Premium", "Acceso a asientos ejecutivos y menú exclusivo", Icons.Default.AirlineSeatReclineExtra)
            ExtraItemCard("Arriendo de Autos (Rent-a-Car)", "Descuentos exclusivos acumulando millas LATAM Pass", Icons.Default.DirectionsCar)
            ExtraItemCard("Hoteles y Alojamientos", "Reserva con cancelación gratuita", Icons.Default.Hotel)
        }
    }
}

@Composable
fun ExtraItemCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, LatamBorder)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = LatamNavy, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))
            }
            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(containerColor = LatamRed),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("VER", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
