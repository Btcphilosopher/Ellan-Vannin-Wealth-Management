package com.example.data.json

import com.example.core.model.*

object SeedData {

    val ChileanAirports = listOf(
        Airport("SCL", "Aeropuerto Internacional Arturo Merino Benítez", "Santiago", "Chile", "T2 Nacional"),
        Airport("ANF", "Aeropuerto Andrés Sabella", "Antofagasta", "Chile", "T1"),
        Airport("CJC", "Aeropuerto El Loa", "Calama", "Chile", "T1"),
        Airport("CCP", "Aeropuerto Carriel Sur", "Concepción", "Chile", "T1"),
        Airport("PMC", "Aeropuerto El Tepual", "Puerto Montt", "Chile", "T1"),
        Airport("PUQ", "Aeropuerto Presidente Carlos Ibáñez del Campo", "Punta Arenas", "Chile", "T1"),
        Airport("LSC", "Aeropuerto La Florida", "La Serena", "Chile", "T1"),
        Airport("ZCO", "Aeropuerto La Araucanía", "Temuco", "Chile", "T1"),
        Airport("IPC", "Aeropuerto Mataveri", "Isla de Pascua", "Chile", "T1"),
        Airport("LIM", "Aeropuerto Internacional Jorge Chávez", "Lima", "Perú", "T1"),
        Airport("EZE", "Aeropuerto Internacional Ministro Pistarini", "Buenos Aires", "Argentina", "T1"),
        Airport("GRU", "Aeropuerto Internacional de Guarulhos", "São Paulo", "Brasil", "T3"),
        Airport("BOG", "Aeropuerto Internacional El Dorado", "Bogotá", "Colombia", "T1"),
        Airport("MAD", "Aeropuerto Adolfo Suárez Madrid-Barajas", "Madrid", "España", "T4"),
        Airport("AKL", "Aeropuerto de Auckland", "Auckland", "Nueva Zelanda", "T1")
    )

    fun getAirportByCode(code: String): Airport {
        return ChileanAirports.find { it.code.equals(code, ignoreCase = true) }
            ?: Airport(code.uppercase(), "Aeropuerto $code", code.uppercase(), "Chile", "T1")
    }

    val DemoFlights = listOf(
        Flight(
            flightNumber = "LA 640",
            origin = getAirportByCode("SCL"),
            destination = getAirportByCode("LIM"),
            departureTime = "08:35",
            arrivalTime = "11:20",
            duration = "3h 45m",
            stopsCount = 0,
            aircraft = "Airbus A320neo",
            fares = mapOf(
                CabinClass.ECONOMY to Fare(CabinClass.ECONOMY, 189990, "Bolso de mano de 10kg", "Sin cambios", 450),
                CabinClass.PREMIUM_ECONOMY to Fare(CabinClass.PREMIUM_ECONOMY, 289990, "Equipaje de mano + 1 Maleta 23kg", "Cambio sin multa", 900),
                CabinClass.BUSINESS to Fare(CabinClass.BUSINESS, 499900, "2 Maletas 23kg + Asiento Cama", "Reembolsable", 1800)
            ),
            ecoEmissionsKg = 110,
            gate = "B12",
            terminal = "T2 Internacional"
        ),
        Flight(
            flightNumber = "LA 142",
            origin = getAirportByCode("SCL"),
            destination = getAirportByCode("CJC"),
            departureTime = "06:15",
            arrivalTime = "08:18",
            duration = "2h 03m",
            stopsCount = 0,
            aircraft = "Airbus A321",
            fares = mapOf(
                CabinClass.ECONOMY to Fare(CabinClass.ECONOMY, 49990, "Bolso de mano de 10kg", "Cambio con comisión", 150),
                CabinClass.PREMIUM_ECONOMY to Fare(CabinClass.PREMIUM_ECONOMY, 99990, "Mano 10kg + Bodega 23kg", "Flexibilidad total", 350)
            ),
            ecoEmissionsKg = 85,
            gate = "C04",
            terminal = "T2 Nacional"
        ),
        Flight(
            flightNumber = "LA 280",
            origin = getAirportByCode("SCL"),
            destination = getAirportByCode("PUQ"),
            departureTime = "13:40",
            arrivalTime = "17:10",
            duration = "3h 30m",
            stopsCount = 0,
            aircraft = "Airbus A320neo",
            fares = mapOf(
                CabinClass.ECONOMY to Fare(CabinClass.ECONOMY, 89900, "Bolso de mano de 10kg", "Cambio con comisión", 280),
                CabinClass.PREMIUM_ECONOMY to Fare(CabinClass.PREMIUM_ECONOMY, 159900, "Mano + Bodega 23kg", "Cambio gratis", 550)
            ),
            ecoEmissionsKg = 140,
            gate = "B08",
            terminal = "T2 Nacional"
        ),
        Flight(
            flightNumber = "LA 841",
            origin = getAirportByCode("SCL"),
            destination = getAirportByCode("IPC"),
            departureTime = "09:30",
            arrivalTime = "13:05",
            duration = "5h 35m",
            stopsCount = 0,
            aircraft = "Boeing 787-9 Dreamliner",
            fares = mapOf(
                CabinClass.ECONOMY to Fare(CabinClass.ECONOMY, 240000, "Bolso de mano de 10kg + 1 Bodega", "Cambio con comisión", 800),
                CabinClass.BUSINESS to Fare(CabinClass.BUSINESS, 650000, "2 Bodega 23kg + Premium Access", "Flexible", 2100)
            ),
            ecoEmissionsKg = 210,
            gate = "A15",
            terminal = "T2 Nacional"
        ),
        Flight(
            flightNumber = "LA 704",
            origin = getAirportByCode("SCL"),
            destination = getAirportByCode("MAD"),
            departureTime = "19:50",
            arrivalTime = "13:30 (+1)",
            duration = "12h 40m",
            stopsCount = 0,
            aircraft = "Boeing 787-9 Dreamliner",
            fares = mapOf(
                CabinClass.ECONOMY to Fare(CabinClass.ECONOMY, 780000, "Bolso mano + Bodega 23kg", "Cambio con costo", 2500),
                CabinClass.BUSINESS to Fare(CabinClass.BUSINESS, 2100000, "2 Maletas + Menú Gourmet + Lounge VIP", "Flexible total", 7000)
            ),
            ecoEmissionsKg = 480,
            gate = "E02",
            terminal = "T2 Internacional"
        )
    )

    val DefaultBooking = Booking(
        pnrCode = "LA7492",
        flightNumber = "LA 640",
        originCode = "SCL",
        originCity = "Santiago",
        destinationCode = "LIM",
        destinationCity = "Lima",
        departureDate = "Mañana",
        departureTime = "08:35",
        arrivalTime = "11:20",
        passengerName = "Tomás Valenzuela",
        cabinClass = "Económica",
        status = BookingStatus.CONFIRMADA.name,
        seatNumber = "14A",
        checkedBaggageCount = 1,
        totalPriceClp = 189990,
        gate = "B12",
        terminal = "T2 Internacional",
        checkInCompleted = false
    )

    val DefaultBoardingPass = BoardingPass(
        id = "BP-LA640-SCL-LIM",
        pnrCode = "LA7492",
        flightNumber = "LA 640",
        originCity = "Santiago",
        originCode = "SCL",
        destinationCity = "Lima",
        destinationCode = "LIM",
        departureDate = "21 SEP",
        departureTime = "08:35",
        passengerName = "Tomás Valenzuela",
        seatNumber = "14A",
        boardingGroup = "Grupo 3",
        gate = "B12",
        terminal = "T2 Internacional",
        cabinClass = "Económica",
        status = BoardingPassStatus.VALIDA_DEMO.name,
        qrCodePayload = "LATAM-DEMO-BOARDING-PASS-LA640-SCL-LIM-TOMAS-VALENZUELA-14A"
    )

    val SclAirportFacilities = listOf(
        AirportFacility("FAC-1", "Mostradores Check-in LATAM", "Check-in", "Nivel 3, Filas D-G", 0.20f, 0.45f, "assignment"),
        AirportFacility("FAC-2", "Seguridad PDI y AVSEC", "Seguridad", "Nivel 3, Control Central", 0.40f, 0.45f, "security"),
        AirportFacility("FAC-3", "Puerta de Embarque B12", "Puertas", "Espigón B, Nivel 2", 0.70f, 0.30f, "flight_takeoff"),
        AirportFacility("FAC-4", "Puerta de Embarque C04", "Puertas", "Espigón C, Nivel 2", 0.75f, 0.65f, "flight_takeoff"),
        AirportFacility("FAC-5", "Salón VIP LATAM Lounge", "VIP", "Espigón B, Piso 4", 0.60f, 0.25f, "star"),
        AirportFacility("FAC-6", "Restaurante El Muelle", "Restaurantes", "Nivel 3, Plaza Comida", 0.35f, 0.25f, "restaurant"),
        AirportFacility("FAC-7", "Duty Free Shop Chile", "Tiendas", "Nivel 3, Embarque", 0.50f, 0.45f, "shopping_bag"),
        AirportFacility("FAC-8", "Recogida de Equipaje Bodega", "Equipaje", "Nivel 1, Carrusel 4", 0.25f, 0.80f, "luggage"),
        AirportFacility("FAC-9", "Estacionamiento E1", "Transporte", "Acceso Principal", 0.10f, 0.85f, "local_parking")
    )

    val TravelExtrasList = listOf(
        TravelExtra("EX-1", "eSIM Internacional LATAM", "Conectividad", "Datos roaming ilimitados para Sudamérica", 12990),
        TravelExtra("EX-2", "Asistencia de Viaje Premium", "Seguro", "Cobertura médica USD $100.000 + cancelación", 18900),
        TravelExtra("EX-3", "Upgrade a Premium Economy", "Cabina", "Espacio extra para piernas y menú especial", 35000),
        TravelExtra("EX-4", "Arriendo de Auto en Destino", "Movilidad", "Categoría SUV con kilometraje libre", 42000),
        TravelExtra("EX-5", "Acceso a Salón VIP LATAM", "Confort", "Buffet gourmet, duchas y espacio relax", 28000),
        TravelExtra("EX-6", "Traslado Privado Aeropuerto", "Transporte", "Vehículo ejecutivo directo a tu hotel", 22000)
    )
}
