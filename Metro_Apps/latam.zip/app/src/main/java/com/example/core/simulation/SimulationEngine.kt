package com.example.core.simulation

import com.example.core.model.*
import com.example.data.local.DevLogDao
import com.example.data.local.NotificationDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class SimulationEngine(
    private val devLogDao: DevLogDao,
    private val notificationDao: NotificationDao
) {
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _simulatedTime = MutableStateFlow(Date())
    val simulatedTime: StateFlow<Date> = _simulatedTime.asStateFlow()

    private val _timeSpeedMultiplier = MutableStateFlow(1) // 1x, 10x, 60x
    val timeSpeedMultiplier: StateFlow<Int> = _timeSpeedMultiplier.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _activeFlight = MutableStateFlow(
        Flight(
            flightNumber = "LA 640",
            origin = Airport("SCL", "Aeropuerto Int. Arturo Merino Benítez", "Santiago", "Chile", "T2 Internacional"),
            destination = Airport("LIM", "Aeropuerto Int. Jorge Chávez", "Lima", "Perú", "T1"),
            departureTime = "08:35",
            arrivalTime = "11:20",
            duration = "3h 45m",
            stopsCount = 0,
            aircraft = "Airbus A320neo",
            fares = emptyMap(),
            currentStatus = FlightStatusEnum.PROGRAMADO,
            gate = "B12",
            terminal = "T2 Internacional"
        )
    )
    val activeFlight: StateFlow<Flight> = _activeFlight.asStateFlow()

    private var simulationJob: Job? = null

    init {
        startClock()
    }

    fun startClock() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            while (true) {
                delay(1000)
                if (!_isPaused.value) {
                    val current = _simulatedTime.value
                    val advanceMs = 1000L * _timeSpeedMultiplier.value
                    _simulatedTime.value = Date(current.time + advanceMs)
                }
            }
        }
    }

    fun togglePause() {
        _isPaused.value = !_isPaused.value
        logEvent("SIMULATION_PAUSE_TOGGLED", "Pausa: ${_isPaused.value}")
    }

    fun setSpeedMultiplier(multiplier: Int) {
        _timeSpeedMultiplier.value = multiplier
        logEvent("SIMULATION_SPEED_CHANGED", "Velocidad cambiada a ${multiplier}x")
    }

    fun forceFlightStatus(status: FlightStatusEnum) {
        val current = _activeFlight.value
        val updated = current.copy(currentStatus = status)
        _activeFlight.value = updated
        logEvent("FLIGHT_STATUS_FORCED", "Vuelo ${current.flightNumber} -> ${status.displayName}")
        
        // Trigger notification
        scope.launch {
            val df = SimpleDateFormat("HH:mm", Locale("es", "CL"))
            notificationDao.insertNotification(
                NotificationItem(
                    id = "NOTIF-${System.currentTimeMillis()}",
                    title = "Estado de Vuelo Actualizado",
                    body = "Tu vuelo ${current.flightNumber} cambió su estado a ${status.displayName}.",
                    type = NotificationType.SCHEDULE_UPDATE.name,
                    priority = NotificationPriority.ALTA.name,
                    timestampFormatted = df.format(Date()),
                    relatedPnr = "LA7492"
                )
            )
        }
    }

    fun forceGateChange(newGate: String) {
        val current = _activeFlight.value
        val updated = current.copy(gate = newGate)
        _activeFlight.value = updated
        logEvent("GATE_CHANGED", "Vuelo ${current.flightNumber} cambió a Puerta $newGate")

        scope.launch {
            val df = SimpleDateFormat("HH:mm", Locale("es", "CL"))
            notificationDao.insertNotification(
                NotificationItem(
                    id = "NOTIF-${System.currentTimeMillis()}",
                    title = "Cambio de Puerta de Embarque",
                    body = "Atención: La puerta de embarque para ${current.flightNumber} ha cambiado a $newGate.",
                    type = NotificationType.GATE_CHANGE.name,
                    priority = NotificationPriority.ALTA.name,
                    timestampFormatted = df.format(Date()),
                    relatedPnr = "LA7492"
                )
            )
        }
    }

    fun logEvent(eventType: String, details: String) {
        scope.launch {
            devLogDao.insertLog(DevLogEvent(eventType = eventType, details = details))
        }
    }
}
