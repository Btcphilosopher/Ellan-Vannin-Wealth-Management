package com.example.features.booking

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.currency.CurrencyUtils
import com.example.core.model.CabinClass
import com.example.core.model.Flight
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun BookingFlowScreen(
    viewModel: MainViewModel,
    onFinishBooking: () -> Unit
) {
    val flight by viewModel.selectedFlightForBooking.collectAsState()
    val step by viewModel.bookingStep.collectAsState()
    val passenger by viewModel.bookingPassenger.collectAsState()
    val cabin by viewModel.selectedCabinClass.collectAsState()
    val selectedSeat by viewModel.selectedSeatNumber.collectAsState()
    val baggageCount by viewModel.selectedBaggageCount.collectAsState()
    val isProcessing by viewModel.isBookingInProcess.collectAsState()
    val createdBooking by viewModel.createdBookingResult.collectAsState()

    val currentFlight = flight ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
    ) {
        // Step Indicator Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "RESERVA DE DEMOSTRACIÓN • ETAPA $step DE 8",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = when (step) {
                        1 -> "1. VUELO SELECCIONADO"
                        2 -> "2. DATOS DEL PASAJERO"
                        3 -> "3. SELECCIÓN DE TARIFA"
                        4 -> "4. SELECCIÓN DE ASIENTO"
                        5 -> "5. EQUIPAJE Y SERVICIOS"
                        6 -> "6. REVISAR ITINERARIO"
                        7 -> "7. PAGO SIMULADO"
                        else -> "8. RESERVA CONFIRMADA"
                    },
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        LinearProgressIndicator(
            progress = { step / 8f },
            modifier = Modifier.fillMaxWidth(),
            color = LatamRed,
            trackColor = LatamNavyLight,
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            when (step) {
                1 -> Stage1FlightSummary(currentFlight, cabin)
                2 -> Stage2PassengerInput(
                    passengerName = "${passenger.firstName} ${passenger.lastName}",
                    onUpdateName = { name ->
                        val parts = name.split(" ")
                        val first = parts.firstOrNull() ?: "Tomás"
                        val last = if (parts.size > 1) parts.subList(1, parts.size).joinToString(" ") else "Valenzuela"
                        viewModel.bookingPassenger.value = passenger.copy(firstName = first, lastName = last)
                    }
                )
                3 -> Stage3FareSelection(currentFlight, cabin) { selected ->
                    viewModel.selectedCabinClass.value = selected
                }
                4 -> Stage4SeatPicker(selectedSeat) { seatCode ->
                    viewModel.selectedSeatNumber.value = seatCode
                }
                5 -> Stage5BaggageOptions(baggageCount) { count ->
                    viewModel.selectedBaggageCount.value = count
                }
                6 -> Stage6ReviewTrip(currentFlight, passenger.firstName + " " + passenger.lastName, cabin, selectedSeat, baggageCount)
                7 -> Stage7SimulatedPayment(isProcessing) {
                    viewModel.processDemoBooking()
                }
                8 -> Stage8Confirmation(createdBooking, onFinishBooking)
            }
        }

        // Navigation Footer Buttons
        if (step in 1..6) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (step > 1) {
                        OutlinedButton(
                            onClick = { viewModel.bookingStep.value = step - 1 },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("ANTERIOR", color = LatamNavy)
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    Button(
                        onClick = { viewModel.bookingStep.value = step + 1 },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = LatamRed),
                        modifier = Modifier.testTag("booking_next_step_btn")
                    ) {
                        Text("CONTINUAR", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
    }
}

@Composable
fun Stage1FlightSummary(flight: Flight, cabin: CabinClass) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, LatamBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "VUELO SELECCIONADO", style = MaterialTheme.typography.labelSmall.copy(color = LatamRed, fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "${flight.flightNumber} • ${flight.origin.city} (${flight.origin.code}) → ${flight.destination.city} (${flight.destination.code})", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text(text = "Horario: ${flight.departureTime} - ${flight.arrivalTime} (${flight.duration})", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Aeronave: ${flight.aircraft}", style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = "Cabina seleccionada: ${cabin.displayName}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
        }
    }
}

@Composable
fun Stage2PassengerInput(passengerName: String, onUpdateName: (String) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "DATOS DEL PASAJERO FICTICIO", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Este prototipo utiliza datos puramente simulados.", style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = passengerName,
                onValueChange = onUpdateName,
                label = { Text("Nombre Completo Ficticio") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("passenger_name_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = "18.492.012-K",
                onValueChange = {},
                readOnly = true,
                label = { Text("Documento / RUT Ficticio") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = "Chile",
                onValueChange = {},
                readOnly = true,
                label = { Text("Nacionalidad") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun Stage3FareSelection(flight: Flight, currentCabin: CabinClass, onSelectCabin: (CabinClass) -> Unit) {
    Column {
        Text(text = "SELECCIONA TU TARIFA", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
        Spacer(modifier = Modifier.height(12.dp))

        CabinClass.entries.forEach { cabin ->
            val fare = flight.fares[cabin]
            val isSelected = cabin == currentCabin

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clickable { onSelectCabin(cabin) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = if (isSelected) LatamNavyLight.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) LatamNavy else LatamBorder)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = isSelected, onClick = { onSelectCabin(cabin) })
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = cabin.displayName, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                        Text(text = fare?.baggageIncluded ?: "Bolso de mano", style = MaterialTheme.typography.bodySmall)
                        Text(text = fare?.flexCondition ?: "Sin flexibilidad", style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))
                    }
                    Text(
                        text = CurrencyUtils.formatClp(fare?.priceClp ?: 189990),
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = LatamRed)
                    )
                }
            }
        }
    }
}

@Composable
fun Stage4SeatPicker(selectedSeat: String, onSelectSeat: (String) -> Unit) {
    Column {
        Text(text = "SELECCIONA TU ASIENTO", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
        Text(text = "Asiento actual: $selectedSeat", style = MaterialTheme.typography.bodyMedium.copy(color = LatamRed, fontWeight = FontWeight.Bold))

        Spacer(modifier = Modifier.height(16.dp))

        listOf("12A", "14A", "14B", "15C", "18F").forEach { seat ->
            val isSel = seat == selectedSeat
            Button(
                onClick = { onSelectSeat(seat) },
                colors = ButtonDefaults.buttonColors(containerColor = if (isSel) LatamRed else LatamNavy),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Text("Asiento $seat ${if (isSel) "(SELECCIONADO)" else ""}")
            }
        }
    }
}

@Composable
fun Stage5BaggageOptions(count: Int, onUpdateCount: (Int) -> Unit) {
    Column {
        Text(text = "EQUIPAJE Y SERVICIOS ADICIONALES", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Equipaje de Bodega (23kg)", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (count > 0) onUpdateCount(count - 1) }) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Menos")
                    }
                    Text(text = "$count piezas de equipaje", modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = { onUpdateCount(count + 1) }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Más")
                    }
                }
            }
        }
    }
}

@Composable
fun Stage6ReviewTrip(flight: Flight, passengerName: String, cabin: CabinClass, seat: String, baggage: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "RESUMEN DE RESERVA DE DEMOSTRACIÓN", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            Text(text = "Vuelo: ${flight.flightNumber} (${flight.origin.code} → ${flight.destination.code})", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Pasajero: $passengerName", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Cabina: ${cabin.displayName}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Asiento: $seat", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Equipaje en bodega: $baggage pieza(s)", style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(12.dp))
            val farePrice = flight.fares[cabin]?.priceClp ?: 189990
            Text(text = "TOTAL ESTIMADO DE DEMOSTRACIÓN:", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
            Text(text = CurrencyUtils.formatClp(farePrice), style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = LatamRed))
        }
    }
}

@Composable
fun Stage7SimulatedPayment(isProcessing: Boolean, onConfirmPayment: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "PASARELA DE PAGO SIMULADO", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "ESTE PROTOTIPO NO PROCESA PAGOS REALES NI ALMACENA DATOS BANCARIOS.",
                style = MaterialTheme.typography.labelSmall.copy(color = LatamRed, fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(20.dp))

            if (isProcessing) {
                CircularProgressIndicator(color = LatamRed)
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = "Procesando pago simulado...")
            } else {
                Button(
                    onClick = onConfirmPayment,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("confirm_demo_payment_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = LatamRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("CONFIRMAR PAGO SIMULADO", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}

@Composable
fun Stage8Confirmation(booking: com.example.core.model.Booking?, onFinish: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Éxito",
                tint = StatusGreen,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = "¡RESERVA CONFIRMADA!", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
            Text(
                text = "Código de Reserva PNR: ${booking?.pnrCode ?: "LA7492"}",
                style = MaterialTheme.typography.titleMedium.copy(color = LatamRed, fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Tu itinerario ha sido guardado en 'Mis Viajes'. Puedes realizar tu check-in y obtener tu tarjeta de embarque digital.", style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onFinish,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = LatamNavy),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("IR A MIS VIAJES")
            }
        }
    }
}
