package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = LatamRed,
    onPrimary = Color.White,
    primaryContainer = LatamNavyLight,
    onPrimaryContainer = Color.White,
    secondary = LatamGold,
    onSecondary = LatamNavy,
    background = LatamNavy,
    onBackground = Color.White,
    surface = LatamNavyLight,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF233566),
    onSurfaceVariant = Color(0xFFCFD9EA),
    outline = LatamBorder
)

private val LightColorScheme = lightColorScheme(
    primary = LatamRed,
    onPrimary = Color.White,
    primaryContainer = LatamNavy,
    onPrimaryContainer = Color.White,
    secondary = LatamGold,
    onSecondary = LatamNavy,
    background = LatamBackground,
    onBackground = LatamTextPrimary,
    surface = LatamSurface,
    onSurface = LatamTextPrimary,
    surfaceVariant = LatamSurfaceVariant,
    onSurfaceVariant = LatamTextSecondary,
    outline = LatamBorder
)

@Composable
fun LatamTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

