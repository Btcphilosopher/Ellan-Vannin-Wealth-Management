package com.example.data.local

import androidx.room.*
import com.example.core.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY createdAtTimestamp DESC")
    fun getAllBookings(): Flow<List<Booking>>

    @Query("SELECT * FROM bookings WHERE pnrCode = :pnrCode LIMIT 1")
    suspend fun getBookingByPnr(pnrCode: String): Booking?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: Booking)

    @Update
    suspend fun updateBooking(booking: Booking)

    @Query("DELETE FROM bookings WHERE pnrCode = :pnrCode")
    suspend fun deleteBookingByPnr(pnrCode: String)

    @Query("DELETE FROM bookings")
    suspend fun deleteAll()
}

@Dao
interface BoardingPassDao {
    @Query("SELECT * FROM boarding_passes")
    fun getAllBoardingPasses(): Flow<List<BoardingPass>>

    @Query("SELECT * FROM boarding_passes WHERE pnrCode = :pnrCode LIMIT 1")
    suspend fun getBoardingPassByPnr(pnrCode: String): BoardingPass?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBoardingPass(boardingPass: BoardingPass)

    @Query("DELETE FROM boarding_passes")
    suspend fun deleteAll()
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestampFormatted DESC")
    fun getAllNotifications(): Flow<List<NotificationItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationItem)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("DELETE FROM notifications")
    suspend fun deleteAll()
}

@Dao
interface LatamPassDao {
    @Query("SELECT * FROM latam_pass WHERE accountId = :id LIMIT 1")
    fun getAccountFlow(id: String = "LP_CHILE_101"): Flow<LatamPassAccount?>

    @Query("SELECT * FROM latam_pass WHERE accountId = :id LIMIT 1")
    suspend fun getAccount(id: String = "LP_CHILE_101"): LatamPassAccount?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAccount(account: LatamPassAccount)
}

@Dao
interface DevLogDao {
    @Query("SELECT * FROM dev_logs ORDER BY id DESC LIMIT 100")
    fun getLogsFlow(): Flow<List<DevLogEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(event: DevLogEvent)

    @Query("DELETE FROM dev_logs")
    suspend fun clearLogs()
}
