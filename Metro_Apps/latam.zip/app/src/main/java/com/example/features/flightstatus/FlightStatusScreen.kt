package com.example.features.flightstatus

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.FlightStatusEnum
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun FlightStatusScreen(viewModel: MainViewModel) {
    val activeFlight by viewModel.simulationEngine.activeFlight.collectAsState()
    var flightQuery by remember { mutableStateOf("LA 640") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
            .testTag("flight_status_screen")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "SEGUIMIENTO EN TIEMPO REAL (SIMULADO)",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "ESTADO DE VUELO",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = flightQuery,
                onValueChange = { flightQuery = it },
                label = { Text("Número de vuelo o Ruta") },
                trailingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Buscar") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Status Flight Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, LatamBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = activeFlight.flightNumber,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = LatamRed)
                        )
                        Surface(
                            color = when (activeFlight.currentStatus) {
                                FlightStatusEnum.A_TIEMPO -> StatusGreen.copy(alpha = 0.15f)
                                FlightStatusEnum.EMBARCANDO -> StatusBlue.copy(alpha = 0.15f)
                                FlightStatusEnum.RETRASADO -> StatusOrange.copy(alpha = 0.15f)
                                else -> LatamNavyLight.copy(alpha = 0.15f)
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = activeFlight.currentStatus.displayName.uppercase(),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "${activeFlight.origin.city} (${activeFlight.origin.code}) → ${activeFlight.destination.city} (${activeFlight.destination.code})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Salida programada: ${activeFlight.departureTime} • Puerta: ${activeFlight.gate}", style = MaterialTheme.typography.bodyMedium)

                    Spacer(modifier = Modifier.height(20.dp))

                    // Timeline
                    Text(
                        text = "LÍNEA DEL TIEMPO DE VUELO",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    StatusTimelineStep("PROGRAMADO", true)
                    StatusTimelineStep("EMBARQUE", activeFlight.currentStatus == FlightStatusEnum.EMBARCANDO || activeFlight.currentStatus == FlightStatusEnum.DESPEGADO || activeFlight.currentStatus == FlightStatusEnum.EN_VUELO || activeFlight.currentStatus == FlightStatusEnum.ATERRIZADO)
                    StatusTimelineStep("DESPEGUE", activeFlight.currentStatus == FlightStatusEnum.DESPEGADO || activeFlight.currentStatus == FlightStatusEnum.EN_VUELO || activeFlight.currentStatus == FlightStatusEnum.ATERRIZADO)
                    StatusTimelineStep("EN VUELO", activeFlight.currentStatus == FlightStatusEnum.EN_VUELO || activeFlight.currentStatus == FlightStatusEnum.ATERRIZADO)
                    StatusTimelineStep("ATERRIZAJE", activeFlight.currentStatus == FlightStatusEnum.ATERRIZADO, isLast = true)
                }
            }
        }
    }
}

@Composable
fun StatusTimelineStep(title: String, isCompleted: Boolean, isLast: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .background(if (isCompleted) StatusGreen else LatamBorder, RoundedCornerShape(8.dp))
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = if (isCompleted) FontWeight.Bold else FontWeight.Normal,
                color = if (isCompleted) LatamNavy else LatamTextSecondary
            )
        )
    }
    if (!isLast) {
        Box(
            modifier = Modifier
                .padding(start = 7.dp, top = 2.dp, bottom = 2.dp)
                .width(2.dp)
                .height(20.dp)
                .background(if (isCompleted) StatusGreen else LatamBorder)
        )
    }
}
