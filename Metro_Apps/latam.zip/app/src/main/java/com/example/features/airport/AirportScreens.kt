package com.example.features.airport

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.json.SeedData
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun AirportMapScreen(viewModel: MainViewModel) {
    var selectedCategory by remember { mutableStateOf("TODOS") }
    var selectedFacilityId by remember { mutableStateOf<String?>(null) }

    val categories = listOf("TODOS", "Check-in", "Seguridad", "Puertas", "VIP", "Restaurantes", "Tiendas", "Equipaje")

    val filteredFacilities = remember(selectedCategory) {
        if (selectedCategory == "TODOS") SeedData.SclAirportFacilities
        else SeedData.SclAirportFacilities.filter { it.category == selectedCategory }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
            .testTag("airport_map_screen")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "MAPA ESQUEMÁTICO CONCEPTUAL DE DEMOSTRACIÓN",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "AEROPUERTO SCL (SANTIAGO)",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        // Category Filter
        ScrollableTabRow(
            selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
            edgePadding = 16.dp,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            categories.forEach { cat ->
                Tab(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    text = { Text(cat, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)) }
                )
            }
        }

        // Map Canvas Box
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = LatamNavyLight)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    // Draw terminal layout schematic background lines
                    drawLine(color = LatamBorder, start = Offset(size.width * 0.1f, size.height * 0.5f), end = Offset(size.width * 0.9f, size.height * 0.5f), strokeWidth = 4f)
                    drawLine(color = LatamBorder, start = Offset(size.width * 0.5f, size.height * 0.2f), end = Offset(size.width * 0.5f, size.height * 0.8f), strokeWidth = 4f)
                }

                // Facility Markers
                filteredFacilities.forEach { fac ->
                    val isSel = fac.id == selectedFacilityId
                    Box(
                        modifier = Modifier
                            .offset((fac.xPercent * 300).dp, (fac.yPercent * 180).dp)
                            .size(if (isSel) 28.dp else 22.dp)
                            .background(if (isSel) LatamRed else LatamGold, RoundedCornerShape(14.dp))
                            .clickable { selectedFacilityId = fac.id },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = fac.name.take(2),
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        // Facilities List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredFacilities) { fac ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedFacilityId = fac.id },
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (fac.id == selectedFacilityId) LatamNavyLight.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, LatamBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Place, contentDescription = null, tint = LatamNavy)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = fac.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                            Text(text = "${fac.category} • ${fac.locationDescription}", style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AirportModeScreen(viewModel: MainViewModel) {
    val activeFlight by viewModel.simulationEngine.activeFlight.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
            .verticalScroll(rememberScrollState())
            .testTag("airport_mode_screen")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "MI DÍA DE VIAJE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "TU VUELO SALE EN",
                    style = MaterialTheme.typography.labelMedium.copy(color = Color.White.copy(alpha = 0.8f))
                )
                Text(
                    text = "02 H 18 MIN",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamGold,
                        fontSize = 36.sp
                    )
                )
                Text(
                    text = "Vuelo ${activeFlight.flightNumber} • ${activeFlight.origin.code} → ${activeFlight.destination.code}",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Color.White)
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "SIGUIENTE PASO RECOMENDADO",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "1. REALIZA TU CHECK-IN", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamRed))
                    Text(text = "Obtén tu tarjeta de embarque digital desde la app.", style = MaterialTheme.typography.bodySmall)

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "2. ENTREGA TU EQUIPAJE", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                    Text(text = "Dirígete a los mostradores LATAM en Nivel 3, Filas D-G.", style = MaterialTheme.typography.bodySmall)

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "3. DIRÍGETE A LA PUERTA ${activeFlight.gate}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                    Text(text = "Embarque estimado a las 08:00 hrs en ${activeFlight.terminal}.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
