package com.example.features.trips

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Booking
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun TripsScreen(
    viewModel: MainViewModel,
    onNavigateToCheckIn: (Booking) -> Unit,
    onNavigateToBoardingPass: (Booking) -> Unit,
    onNavigateToSeats: (Booking) -> Unit,
    onNavigateToBaggage: (Booking) -> Unit
) {
    val bookings by viewModel.bookings.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "GESTIÓN DE ITINERARIOS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "MIS VIAJES",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        if (bookings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Flight,
                        contentDescription = null,
                        tint = LatamTextSecondary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "PLANIFICA TU PRÓXIMA AVENTURA",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = LatamNavy
                        )
                    )
                    Text(
                        text = "Aún no tienes viajes registrados.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = LatamTextSecondary)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(bookings) { booking ->
                    TripItineraryCard(
                        booking = booking,
                        onCheckIn = { onNavigateToCheckIn(booking) },
                        onBoardingPass = { onNavigateToBoardingPass(booking) },
                        onSeats = { onNavigateToSeats(booking) },
                        onBaggage = { onNavigateToBaggage(booking) }
                    )
                }
            }
        }
    }
}

@Composable
fun TripItineraryCard(
    booking: Booking,
    onCheckIn: () -> Unit,
    onBoardingPass: () -> Unit,
    onSeats: () -> Unit,
    onBaggage: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("itinerary_card_${booking.pnrCode}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, LatamBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RESERVA: ${booking.pnrCode}",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = LatamRed)
                )
                Surface(
                    color = if (booking.checkInCompleted) StatusGreen.copy(alpha = 0.15f) else StatusOrange.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (booking.checkInCompleted) "CHECK-IN COMPLETADO" else "CHECK-IN DISPONIBLE",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (booking.checkInCompleted) StatusGreen else StatusOrange,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "${booking.originCity} (${booking.originCode}) → ${booking.destinationCity} (${booking.destinationCode})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
            )
            Text(text = "Vuelo ${booking.flightNumber} • Fechas: ${booking.departureDate}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Pasajero: ${booking.passengerName}", style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = LatamBorder)
            Spacer(modifier = Modifier.height(12.dp))

            // Action grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (booking.checkInCompleted) onBoardingPass() else onCheckIn()
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = LatamNavy),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = if (booking.checkInCompleted) "VER TARJETA" else "CHECK-IN")
                }

                OutlinedButton(
                    onClick = onSeats,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "ASIENTO", color = LatamNavy)
                }

                OutlinedButton(
                    onClick = onBaggage,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "EQUIPAJE", color = LatamNavy)
                }
            }
        }
    }
}
