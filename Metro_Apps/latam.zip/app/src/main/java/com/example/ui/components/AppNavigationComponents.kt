package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainNavTab
import com.example.ui.theme.*

@Composable
fun AppConceptualBanner() {
    Surface(
        color = LatamRed,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "PROTOTIPO FUNCIONAL DE DEMOSTRACIÓN • SISTEMA CONCEPTUAL LATAM AIRLINES CHILE",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall.copy(
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp
            )
        )
    }
}

@Composable
fun AppBottomBar(
    selectedTab: MainNavTab,
    onTabSelected: (MainNavTab) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("main_bottom_nav")
    ) {
        MainNavTab.entries.forEach { tab ->
            val isSelected = selectedTab == tab
            val icon = when (tab) {
                MainNavTab.INICIO -> Icons.Default.Home
                MainNavTab.MIS_VIAJES -> Icons.Default.FlightTakeoff
                MainNavTab.BUSCAR -> Icons.Default.Search
                MainNavTab.LATAM_PASS -> Icons.Default.Star
                MainNavTab.MAS -> Icons.Default.Menu
            }

            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = tab.title,
                        tint = if (isSelected) LatamRed else LatamTextSecondary
                    )
                },
                label = {
                    Text(
                        text = tab.title,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) LatamNavy else LatamTextSecondary,
                            fontSize = 9.sp
                        )
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = LatamNavyLight.copy(alpha = 0.15f)
                ),
                modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
            )
        }
    }
}
