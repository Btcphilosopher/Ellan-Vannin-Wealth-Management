package com.example.features.boardingpass

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.BoardingPass
import com.example.core.model.Booking
import com.example.ui.theme.*

@Composable
fun BoardingPassScreen(
    booking: Booking,
    boardingPass: BoardingPass? = null,
    onBack: () -> Unit
) {
    val pass = boardingPass ?: BoardingPass(
        id = "BP-${booking.pnrCode}",
        pnrCode = booking.pnrCode,
        flightNumber = booking.flightNumber,
        originCity = booking.originCity,
        originCode = booking.originCode,
        destinationCity = booking.destinationCity,
        destinationCode = booking.destinationCode,
        departureDate = booking.departureDate,
        departureTime = booking.departureTime,
        passengerName = booking.passengerName,
        seatNumber = booking.seatNumber,
        boardingGroup = "Grupo 3",
        gate = booking.gate,
        terminal = booking.terminal,
        cabinClass = booking.cabinClass,
        status = "VÁLIDA_DEMO",
        qrCodePayload = "LATAM-DEMO-BP-${booking.pnrCode}"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LatamNavy)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("boarding_pass_screen")
    ) {
        // Disclaimer Warning Header
        Surface(
            color = LatamRed,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Text(
                text = "TARJETA DE EMBARQUE DE DEMOSTRACIÓN • DOCUMENTO NO VÁLIDO PARA VIAJAR",
                modifier = Modifier.padding(10.dp),
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            )
        }

        // Pass Ticket Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header Brand
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LATAM",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = LatamRed,
                            letterSpacing = 2.sp
                        )
                    )
                    Surface(
                        color = LatamNavy,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = pass.cabinClass.uppercase(),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Route
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = pass.originCode,
                            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                        )
                        Text(text = pass.originCity, style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = pass.flightNumber, style = MaterialTheme.typography.labelSmall.copy(color = LatamRed, fontWeight = FontWeight.Bold))
                        Text(text = "→", style = MaterialTheme.typography.titleLarge.copy(color = LatamNavy))
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = pass.destinationCode,
                            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                        )
                        Text(text = pass.destinationCity, style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Dashed Cut Line
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                ) {
                    val pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    drawLine(
                        color = LatamBorder,
                        start = Offset(0f, 0f),
                        end = Offset(size.width, 0f),
                        pathEffect = pathEffect
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Key Info Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "PASAJERO", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
                        Text(text = pass.passengerName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                    }
                    Column {
                        Text(text = "FECHA", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
                        Text(text = pass.departureDate, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "SALIDA", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
                        Text(text = pass.departureTime, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                    }
                    Column {
                        Text(text = "PUERTA", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
                        Text(text = pass.gate, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamRed))
                    }
                    Column {
                        Text(text = "GRUPO", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
                        Text(text = pass.boardingGroup, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                    }
                    Column {
                        Text(text = "ASIENTO", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
                        Text(text = pass.seatNumber, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamRed))
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Simulated QR Code Display
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(LatamSurfaceVariant, shape = RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Código QR Demo",
                            tint = LatamNavy,
                            modifier = Modifier.size(140.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = pass.qrCodePayload,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 8.sp,
                                color = LatamTextSecondary
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(text = "VOLVER A MIS VIAJES", color = LatamNavy, fontWeight = FontWeight.Bold)
        }
    }
}
