package com.example.features.search

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.currency.CurrencyUtils
import com.example.core.model.CabinClass
import com.example.core.model.Flight
import com.example.data.json.SeedData
import com.example.ui.MainViewModel
import com.example.ui.theme.*

enum class SortOption(val displayName: String) {
    RECOMENDADOS("Recomendados"),
    PRECIO_MAS_BAJO("Precio más bajo"),
    SALIDA_TEMPRANA("Salida más temprana"),
    DURACION_CORTA("Duración más corta")
}

@Composable
fun SearchScreen(
    viewModel: MainViewModel,
    onFlightSelected: (Flight) -> Unit
) {
    val originCode by viewModel.originCode.collectAsState()
    val destinationCode by viewModel.destinationCode.collectAsState()
    val selectedCabin by viewModel.selectedCabinClass.collectAsState()

    var selectedSort by remember { mutableStateOf(SortOption.RECOMENDADOS) }
    var filterDirectOnly by remember { mutableStateOf(false) }
    var detailedFlight by remember { mutableStateOf<Flight?>(null) }

    val rawFlights = remember(originCode, destinationCode) {
        viewModel.repository.searchFlights(originCode, destinationCode)
    }

    val filteredFlights = remember(rawFlights, filterDirectOnly, selectedSort) {
        var list = if (filterDirectOnly) rawFlights.filter { it.stopsCount == 0 } else rawFlights
        when (selectedSort) {
            SortOption.PRECIO_MAS_BAJO -> list = list.sortedBy { it.fares[selectedCabin]?.priceClp ?: Int.MAX_VALUE }
            SortOption.SALIDA_TEMPRANA -> list = list.sortedBy { it.departureTime }
            SortOption.DURACION_CORTA -> list = list.sortedBy { it.duration }
            else -> {}
        }
        list
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
    ) {
        // Search Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "RESULTADOS DE VUELOS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "${SeedData.getAirportByCode(originCode).city} (${originCode.uppercase()}) → ${SeedData.getAirportByCode(destinationCode).city} (${destinationCode.uppercase()})",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                Text(
                    text = "${filteredFlights.size} opciones encontradas • Cabina ${selectedCabin.displayName}",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.8f))
                )
            }
        }

        // Filters and Sorting Row
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Ordenar por:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = filterDirectOnly,
                        onCheckedChange = { filterDirectOnly = it },
                        modifier = Modifier.testTag("filter_direct_checkbox")
                    )
                    Text(text = "Solo directos", style = MaterialTheme.typography.bodySmall)
                }
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 4.dp)
            ) {
                items(SortOption.entries) { sort ->
                    val isSelected = selectedSort == sort
                    Surface(
                        onClick = { selectedSort = sort },
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) LatamNavy else LatamSurfaceVariant,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = sort.displayName,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (isSelected) Color.White else LatamTextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        )
                    }
                }
            }
        }

        Divider(color = LatamBorder)

        // Flights List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredFlights) { flight ->
                FlightResultCard(
                    flight = flight,
                    cabinClass = selectedCabin,
                    onViewDetails = { detailedFlight = flight },
                    onSelect = { onFlightSelected(flight) }
                )
            }
        }
    }

    // Detailed Flight Dialog Page
    detailedFlight?.let { flight ->
        AlertDialog(
            onDismissRequest = { detailedFlight = null },
            confirmButton = {
                Button(
                    onClick = {
                        val selected = flight
                        detailedFlight = null
                        onFlightSelected(selected)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LatamRed)
                ) {
                    Text("SELECCIONAR VUELO")
                }
            },
            dismissButton = {
                TextButton(onClick = { detailedFlight = null }) {
                    Text("VOLVER")
                }
            },
            title = {
                Text(
                    text = "DETALLE DEL VUELO ${flight.flightNumber}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                )
            },
            text = {
                Column(modifier = Modifier.padding(vertical = 8.dp)) {
                    Text(
                        text = "${flight.origin.city} (${flight.origin.code}) ${flight.departureTime}  →  ${flight.destination.city} (${flight.destination.code}) ${flight.arrivalTime}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Duración: ${flight.duration}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Aeronave: ${flight.aircraft}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Escalas: ${if (flight.stopsCount == 0) "Directo" else "${flight.stopsCount} escala"}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "Emisiones est.: ${flight.ecoEmissionsKg} kg CO2/pasajero", style = MaterialTheme.typography.bodySmall)

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "SERVICIOS E EQUIPAJE INCLUIDO",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = LatamRed)
                    )
                    val fare = flight.fares[selectedCabin]
                    Text(text = "• Cabina: ${selectedCabin.displayName}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "• Equipaje: ${fare?.baggageIncluded ?: "Bolso de mano"}", style = MaterialTheme.typography.bodySmall)
                    Text(text = "• Flexibilidad: ${fare?.flexCondition ?: "Estándar"}", style = MaterialTheme.typography.bodySmall)

                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = LatamNavyLight,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "PRECIO DE DEMOSTRACIÓN: ${CurrencyUtils.formatClp(fare?.priceClp ?: 189990)}",
                            modifier = Modifier.padding(8.dp),
                            style = MaterialTheme.typography.labelMedium.copy(color = Color.White, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        )
    }
}

@Composable
fun FlightResultCard(
    flight: Flight,
    cabinClass: CabinClass,
    onViewDetails: () -> Unit,
    onSelect: () -> Unit
) {
    val fare = flight.fares[cabinClass] ?: flight.fares[CabinClass.ECONOMY]
    val priceClp = fare?.priceClp ?: 189990

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("flight_card_${flight.flightNumber}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, LatamBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = LatamNavy,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = flight.flightNumber,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                    )
                }
                Text(
                    text = if (flight.stopsCount == 0) "Directo" else "${flight.stopsCount} Escala",
                    style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = flight.departureTime,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                    )
                    Text(
                        text = "${flight.origin.city} (${flight.origin.code})",
                        style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary)
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = flight.duration,
                        style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(24.dp, 2.dp).background(LatamBorder))
                        Icon(imageVector = Icons.Default.FlightTakeoff, contentDescription = null, tint = LatamRed, modifier = Modifier.size(16.dp))
                        Box(modifier = Modifier.size(24.dp, 2.dp).background(LatamBorder))
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = flight.arrivalTime,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                    )
                    Text(
                        text = "${flight.destination.city} (${flight.destination.code})",
                        style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = LatamBorder)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PRECIO DE DEMOSTRACIÓN",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = LatamTextSecondary,
                            fontSize = 9.sp
                        )
                    )
                    Text(
                        text = CurrencyUtils.formatClp(priceClp),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = LatamRed
                        )
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onViewDetails,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("DETALLES", style = MaterialTheme.typography.labelSmall.copy(color = LatamNavy))
                    }

                    Button(
                        onClick = onSelect,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = LatamNavy),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("select_flight_${flight.flightNumber}")
                    ) {
                        Text("SELECCIONAR", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
    }
}
