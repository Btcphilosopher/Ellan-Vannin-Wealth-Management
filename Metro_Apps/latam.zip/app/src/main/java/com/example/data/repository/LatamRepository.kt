package com.example.data.repository

import com.example.core.model.*
import com.example.data.json.SeedData
import com.example.data.local.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.*

class LatamRepository(
    private val bookingDao: BookingDao,
    private val boardingPassDao: BoardingPassDao,
    private val notificationDao: NotificationDao,
    private val latamPassDao: LatamPassDao,
    private val devLogDao: DevLogDao
) {
    val allBookings: Flow<List<Booking>> = bookingDao.getAllBookings()
    val allBoardingPasses: Flow<List<BoardingPass>> = boardingPassDao.getAllBoardingPasses()
    val allNotifications: Flow<List<NotificationItem>> = notificationDao.getAllNotifications()
    val latamPassAccount: Flow<LatamPassAccount?> = latamPassDao.getAccountFlow()
    val devLogs: Flow<List<DevLogEvent>> = devLogDao.getLogsFlow()

    suspend fun seedInitialDataIfNeeded() {
        val existingBookings = bookingDao.getAllBookings().first()
        if (existingBookings.isEmpty()) {
            bookingDao.insertBooking(SeedData.DefaultBooking)
            boardingPassDao.insertBoardingPass(SeedData.DefaultBoardingPass)
            
            val df = SimpleDateFormat("HH:mm", Locale("es", "CL"))
            val nowStr = df.format(Date())
            
            notificationDao.insertNotification(
                NotificationItem(
                    id = "NOTIF-WELCOME",
                    title = "¡Bienvenido a LATAM!",
                    body = "Tu próximo vuelo a Lima (LA 640) está programado para mañana. Puedes revisar los detalles en Mis Viajes.",
                    type = NotificationType.BOOKING_UPDATE.name,
                    priority = NotificationPriority.MEDIA.name,
                    timestampFormatted = nowStr,
                    relatedPnr = SeedData.DefaultBooking.pnrCode
                )
            )

            latamPassDao.insertOrUpdateAccount(
                LatamPassAccount(
                    accountId = "LP_CHILE_101",
                    memberName = "Tomás Valenzuela",
                    availableMiles = 42850,
                    expiringMiles = 3200,
                    qualifyingPoints = 18400,
                    category = PassCategory.GOLD.displayName
                )
            )

            devLogDao.insertLog(
                DevLogEvent(
                    eventType = "APP_INITIALIZED",
                    details = "Base de datos inicializada con reserva por defecto LA7492 (SCL -> LIM)"
                )
            )
        }
    }

    fun getFlightByNumber(flightNumber: String): Flight? {
        return SeedData.DemoFlights.find { it.flightNumber.equals(flightNumber, ignoreCase = true) }
            ?: SeedData.DemoFlights.firstOrNull()
    }

    fun searchFlights(originCode: String, destinationCode: String): List<Flight> {
        val results = SeedData.DemoFlights.filter { flight ->
            (originCode.isEmpty() || flight.origin.code.equals(originCode, ignoreCase = true)) &&
            (destinationCode.isEmpty() || flight.destination.code.equals(destinationCode, ignoreCase = true))
        }
        return if (results.isNotEmpty()) results else SeedData.DemoFlights
    }

    suspend fun saveBooking(booking: Booking) {
        bookingDao.insertBooking(booking)
        devLogDao.insertLog(
            DevLogEvent(
                eventType = "BOOKING_CREATED",
                details = "PNR: ${booking.pnrCode}, Vuelo: ${booking.flightNumber}, Tarifa: CLP $${booking.totalPriceClp}"
            )
        )
    }

    suspend fun updateBooking(booking: Booking) {
        bookingDao.updateBooking(booking)
        devLogDao.insertLog(
            DevLogEvent(
                eventType = "BOOKING_UPDATED",
                details = "PNR: ${booking.pnrCode}, Estado: ${booking.status}, CheckIn: ${booking.checkInCompleted}"
            )
        )
    }

    suspend fun createAndSaveBoardingPass(booking: Booking): BoardingPass {
        val pass = BoardingPass(
            id = "BP-${booking.pnrCode}-${System.currentTimeMillis()}",
            pnrCode = booking.pnrCode,
            flightNumber = booking.flightNumber,
            originCity = booking.originCity,
            originCode = booking.originCode,
            destinationCity = booking.destinationCity,
            destinationCode = booking.destinationCode,
            departureDate = booking.departureDate,
            departureTime = booking.departureTime,
            passengerName = booking.passengerName,
            seatNumber = booking.seatNumber,
            boardingGroup = "Grupo 3",
            gate = booking.gate,
            terminal = booking.terminal,
            cabinClass = booking.cabinClass,
            status = BoardingPassStatus.VALIDA_DEMO.name,
            qrCodePayload = "LATAM-DEMO-BP-${booking.pnrCode}-${booking.seatNumber}-${booking.passengerName}"
        )
        boardingPassDao.insertBoardingPass(pass)

        // Mark booking checkin complete
        val updatedBooking = booking.copy(checkInCompleted = true)
        bookingDao.updateBooking(updatedBooking)

        devLogDao.insertLog(
            DevLogEvent(
                eventType = "BOARDING_PASS_CREATED",
                details = "Tarjeta de embarque generada para PNR ${booking.pnrCode}, Asiento ${booking.seatNumber}"
            )
        )

        return pass
    }

    suspend fun redeemMiles(milesRequired: Int, rewardTitle: String): Boolean {
        val currentAccount = latamPassDao.getAccount() ?: return false
        if (currentAccount.availableMiles >= milesRequired) {
            val updated = currentAccount.copy(
                availableMiles = currentAccount.availableMiles - milesRequired
            )
            latamPassDao.insertOrUpdateAccount(updated)

            devLogDao.insertLog(
                DevLogEvent(
                    eventType = "MILES_REDEEMED",
                    details = "Canje de $milesRequired millas por '$rewardTitle'. Saldo resultante: ${updated.availableMiles}"
                )
            )
            return true
        }
        return false
    }

    suspend fun resetAllData() {
        bookingDao.deleteAll()
        boardingPassDao.deleteAll()
        notificationDao.deleteAll()
        devLogDao.clearLogs()
        seedInitialDataIfNeeded()
    }
}
