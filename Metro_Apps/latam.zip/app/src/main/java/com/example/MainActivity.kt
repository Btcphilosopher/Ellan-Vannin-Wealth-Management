package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.core.model.Booking
import com.example.features.airport.AirportMapScreen
import com.example.features.airport.AirportModeScreen
import com.example.features.baggage.BaggageScreen
import com.example.features.boardingpass.BoardingPassScreen
import com.example.features.booking.BookingFlowScreen
import com.example.features.checkin.CheckInScreen
import com.example.features.concierge.ConciergeScreen
import com.example.features.developer.DeveloperModeScreen
import com.example.features.extras.ExtrasScreen
import com.example.features.flightstatus.FlightStatusScreen
import com.example.features.home.HomeScreen
import com.example.features.latampass.LatamPassScreen
import com.example.features.latampass.RedeemMilesScreen
import com.example.features.notifications.NotificationsScreen
import com.example.features.profile.ProfileScreen
import com.example.features.search.SearchScreen
import com.example.features.seats.SeatMapScreen
import com.example.features.trips.TripsScreen
import com.example.ui.MainNavTab
import com.example.ui.MainViewModel
import com.example.ui.components.AppBottomBar
import com.example.ui.components.AppConceptualBanner
import com.example.ui.components.MoreMenuScreen
import com.example.ui.theme.LatamTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            LatamTheme {
                LatamAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun LatamAppContent(viewModel: MainViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val activeSubScreen by viewModel.activeSubScreen.collectAsState()
    val bookings by viewModel.bookings.collectAsState()

    var activeCheckInBooking by remember { mutableStateOf<Booking?>(null) }
    var activeBoardingPassBooking by remember { mutableStateOf<Booking?>(null) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            AppConceptualBanner()
        },
        bottomBar = {
            AppBottomBar(
                selectedTab = selectedTab,
                onTabSelected = { tab ->
                    viewModel.selectTab(tab)
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (activeSubScreen != null) {
                when (activeSubScreen) {
                    "booking_flow" -> BookingFlowScreen(
                        viewModel = viewModel,
                        onFinishBooking = {
                            viewModel.backToTabRoot()
                            viewModel.selectTab(MainNavTab.MIS_VIAJES)
                        }
                    )
                    "checkin" -> activeCheckInBooking?.let { b ->
                        CheckInScreen(
                            viewModel = viewModel,
                            booking = b,
                            onCheckInCompleted = {
                                activeBoardingPassBooking = b
                                viewModel.navigateToSubScreen("boarding_pass")
                            }
                        )
                    }
                    "boarding_pass" -> activeBoardingPassBooking?.let { b ->
                        BoardingPassScreen(
                            booking = b,
                            onBack = {
                                viewModel.backToTabRoot()
                                viewModel.selectTab(MainNavTab.MIS_VIAJES)
                            }
                        )
                    }
                    "seat_map" -> SeatMapScreen(
                        viewModel = viewModel,
                        onSeatSaved = { viewModel.backToTabRoot() }
                    )
                    "baggage" -> BaggageScreen(
                        viewModel = viewModel,
                        onSave = { viewModel.backToTabRoot() }
                    )
                    "flight_status" -> FlightStatusScreen(viewModel = viewModel)
                    "airport_map" -> AirportMapScreen(viewModel = viewModel)
                    "airport_mode" -> AirportModeScreen(viewModel = viewModel)
                    "concierge" -> ConciergeScreen(viewModel = viewModel)
                    "extras" -> ExtrasScreen(viewModel = viewModel)
                    "profile" -> ProfileScreen(viewModel = viewModel)
                    "notifications" -> NotificationsScreen(viewModel = viewModel)
                    "developer_mode" -> DeveloperModeScreen(viewModel = viewModel)
                    "redeem_miles" -> RedeemMilesScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateToSubScreen("latam_pass_root") }
                    )
                    else -> viewModel.backToTabRoot()
                }
            } else {
                when (selectedTab) {
                    MainNavTab.INICIO -> HomeScreen(
                        viewModel = viewModel,
                        onNavigateToSearch = { viewModel.selectTab(MainNavTab.BUSCAR) },
                        onNavigateToTrips = { viewModel.selectTab(MainNavTab.MIS_VIAJES) },
                        onNavigateToCheckIn = { b ->
                            activeCheckInBooking = b
                            viewModel.navigateToSubScreen("checkin")
                        },
                        onNavigateToBoardingPass = { b ->
                            activeBoardingPassBooking = b
                            viewModel.navigateToSubScreen("boarding_pass")
                        },
                        onNavigateToAirportMode = { viewModel.navigateToSubScreen("airport_mode") }
                    )
                    MainNavTab.MIS_VIAJES -> TripsScreen(
                        viewModel = viewModel,
                        onNavigateToCheckIn = { b ->
                            activeCheckInBooking = b
                            viewModel.navigateToSubScreen("checkin")
                        },
                        onNavigateToBoardingPass = { b ->
                            activeBoardingPassBooking = b
                            viewModel.navigateToSubScreen("boarding_pass")
                        },
                        onNavigateToSeats = { b ->
                            viewModel.navigateToSubScreen("seat_map")
                        },
                        onNavigateToBaggage = { b ->
                            viewModel.navigateToSubScreen("baggage")
                        }
                    )
                    MainNavTab.BUSCAR -> SearchScreen(
                        viewModel = viewModel,
                        onFlightSelected = { flight ->
                            viewModel.startBookingFlow(flight)
                        }
                    )
                    MainNavTab.LATAM_PASS -> LatamPassScreen(
                        viewModel = viewModel,
                        onRedeemMilesClicked = { viewModel.navigateToSubScreen("redeem_miles") }
                    )
                    MainNavTab.MAS -> MoreMenuScreen(
                        onNavigateTo = { route -> viewModel.navigateToSubScreen(route) }
                    )
                }
            }
        }
    }
}
