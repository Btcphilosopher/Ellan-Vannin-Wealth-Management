package com.example.features.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.currency.CurrencyUtils
import com.example.core.model.Booking
import com.example.core.model.CabinClass
import com.example.data.json.SeedData
import com.example.ui.MainViewModel
import com.example.ui.SearchMode
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToSearch: () -> Unit,
    onNavigateToTrips: () -> Unit,
    onNavigateToCheckIn: (Booking) -> Unit,
    onNavigateToBoardingPass: (Booking) -> Unit,
    onNavigateToAirportMode: () -> Unit
) {
    val userName by viewModel.userName.collectAsState()
    val bookings by viewModel.bookings.collectAsState()
    val searchMode by viewModel.searchMode.collectAsState()
    val originCode by viewModel.originCode.collectAsState()
    val destinationCode by viewModel.destinationCode.collectAsState()
    val departureDate by viewModel.departureDateStr.collectAsState()
    val selectedCabin by viewModel.selectedCabinClass.collectAsState()

    var showOriginPicker by remember { mutableStateOf(false) }
    var showDestPicker by remember { mutableStateOf(false) }

    val nextTrip = bookings.firstOrNull { it.status == "CONFIRMADA" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 90.dp)
    ) {
        // Top Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (userName.isNotBlank()) "HOLA, $userName" else "HOLA, VIAJERO",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = "¿A DÓNDE VOLAMOS?",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.White.copy(alpha = 0.8f),
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                    IconButton(
                        onClick = { viewModel.navigateToSubScreen("notifications") },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.1f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notificaciones",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // Upcoming Trip Priority Card ("TU PRÓXIMO VIAJE")
        if (nextTrip != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .testTag("next_trip_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TU PRÓXIMO VIAJE",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = LatamRed,
                                letterSpacing = 1.sp
                            )
                        )
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = StatusGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = if (nextTrip.checkInCompleted) "CHECK-IN LISTO" else "CHECK-IN DISPONIBLE",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = StatusGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = nextTrip.originCode,
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = LatamNavy
                                )
                            )
                            Text(
                                text = nextTrip.originCity,
                                style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary)
                            )
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = nextTrip.flightNumber,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = LatamRed
                                )
                            )
                            Icon(
                                imageVector = Icons.Default.FlightTakeoff,
                                contentDescription = "Flight",
                                tint = LatamNavy
                            )
                            Text(
                                text = "08:35 MAÑANA",
                                style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary)
                            )
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = nextTrip.destinationCode,
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = LatamNavy
                                )
                            )
                            Text(
                                text = nextTrip.destinationCity,
                                style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary)
                            )
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp), color = LatamBorder)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Terminal: ${nextTrip.terminal}", style = MaterialTheme.typography.bodySmall)
                        Text(text = "Puerta: ${nextTrip.gate}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                        Text(text = "Asiento: ${nextTrip.seatNumber}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (nextTrip.checkInCompleted) {
                                    onNavigateToBoardingPass(nextTrip)
                                } else {
                                    onNavigateToCheckIn(nextTrip)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("view_trip_action_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = LatamNavy),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = if (nextTrip.checkInCompleted) "TARJETA DE EMBARQUE" else "HACER CHECK-IN")
                        }

                        OutlinedButton(
                            onClick = onNavigateToAirportMode,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "MODO AEROPUERTO", color = LatamNavy)
                        }
                    }
                }
            }
        }

        // Search Flights Card Container
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "BUSCADOR DE VUELOS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamNavy
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Search Modes Switcher
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(LatamSurfaceVariant, shape = RoundedCornerShape(8.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SearchMode.entries.forEach { mode ->
                        val isSelected = searchMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) LatamNavy else Color.Transparent)
                                .clickable { viewModel.searchMode.value = mode }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = mode.displayName,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else LatamTextSecondary
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Origin / Destination Selectors
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // DESDE
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, LatamBorder, RoundedCornerShape(8.dp))
                            .clickable { showOriginPicker = true }
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(text = "DESDE", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
                            val airport = SeedData.getAirportByCode(originCode)
                            Text(
                                text = "${airport.city} (${airport.code})",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                            )
                        }
                    }

                    // HASTA
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, LatamBorder, RoundedCornerShape(8.dp))
                            .clickable { showDestPicker = true }
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(text = "HASTA", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
                            val airport = SeedData.getAirportByCode(destinationCode)
                            Text(
                                text = "${airport.city} (${airport.code})",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Date & Passengers Selectors
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, LatamBorder, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(text = "SALIDA", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
                            Text(text = departureDate, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, LatamBorder, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(text = "CABINA", style = MaterialTheme.typography.labelSmall.copy(color = LatamTextSecondary))
                            Text(text = selectedCabin.displayName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onNavigateToSearch,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("search_flights_main_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = LatamRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "BUSCAR VUELOS",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }
        }

        // Quick Service Shortcuts
        Spacer(modifier = Modifier.height(8.dp))
        PaddingValues(horizontal = 16.dp).let {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "SERVICIOS RÁPIDOS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamNavy
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickShortcutCard(
                        title = "Estado Vuelo",
                        icon = Icons.Default.Schedule,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateToSubScreen("flight_status") }
                    )
                    QuickShortcutCard(
                        title = "Mapa SCL",
                        icon = Icons.Default.Map,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateToSubScreen("airport_map") }
                    )
                    QuickShortcutCard(
                        title = "Concierge",
                        icon = Icons.Default.SupportAgent,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateToSubScreen("concierge") }
                    )
                    QuickShortcutCard(
                        title = "Extras",
                        icon = Icons.Default.MoreHoriz,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.navigateToSubScreen("extras") }
                    )
                }
            }
        }
    }

    // Origin Airport Dialog Picker
    if (showOriginPicker) {
        AlertDialog(
            onDismissRequest = { showOriginPicker = false },
            title = { Text("SELECCIONAR ORIGEN") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    SeedData.ChileanAirports.forEach { ap ->
                        Text(
                            text = "${ap.city} — ${ap.code} (${ap.name})",
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.originCode.value = ap.code
                                    showOriginPicker = false
                                }
                                .padding(vertical = 12.dp, horizontal = 8.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Divider(color = LatamBorder)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showOriginPicker = false }) {
                    Text("CERRAR")
                }
            }
        )
    }

    // Destination Airport Dialog Picker
    if (showDestPicker) {
        AlertDialog(
            onDismissRequest = { showDestPicker = false },
            title = { Text("SELECCIONAR DESTINO") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    SeedData.ChileanAirports.forEach { ap ->
                        Text(
                            text = "${ap.city} — ${ap.code} (${ap.name})",
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.destinationCode.value = ap.code
                                    showDestPicker = false
                                }
                                .padding(vertical = 12.dp, horizontal = 8.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Divider(color = LatamBorder)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDestPicker = false }) {
                    Text("CERRAR")
                }
            }
        )
    }
}

@Composable
fun QuickShortcutCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, LatamBorder)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = LatamNavy,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = LatamNavy
                )
            )
        }
    }
}
