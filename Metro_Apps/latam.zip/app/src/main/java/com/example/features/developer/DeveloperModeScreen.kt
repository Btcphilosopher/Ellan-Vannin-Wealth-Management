package com.example.features.developer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.FlightStatusEnum
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun DeveloperModeScreen(viewModel: MainViewModel) {
    val simEngine = viewModel.simulationEngine
    val isPaused by simEngine.isPaused.collectAsState()
    val speed by simEngine.timeSpeedMultiplier.collectAsState()
    val activeFlight by simEngine.activeFlight.collectAsState()
    val devLogs by viewModel.devLogs.collectAsState()

    var newGateInput by remember { mutableStateOf("C04") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
            .verticalScroll(rememberScrollState())
            .testTag("developer_mode_screen")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "PANEL DE CONTROL DE DEMOSTRACIÓN",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "MODO DESARROLLADOR Y SIMULADOR",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Simulation Controls Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "RELOJ DE SIMULACIÓN", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { simEngine.togglePause() },
                            modifier = Modifier.background(if (isPaused) StatusOrange else LatamNavy, RoundedCornerShape(8.dp))
                        ) {
                            Icon(imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause, contentDescription = "Pausa", tint = Color.White)
                        }

                        listOf(1, 10, 60).forEach { spd ->
                            Button(
                                onClick = { simEngine.setSpeedMultiplier(spd) },
                                colors = ButtonDefaults.buttonColors(containerColor = if (speed == spd) LatamRed else LatamNavy)
                            ) {
                                Text("${spd}x")
                            }
                        }
                    }
                }
            }

            // Force Flight Status Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "FORZAR ESTADO DE VUELO (${activeFlight.flightNumber})", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Estado actual: ${activeFlight.currentStatus.displayName}", style = MaterialTheme.typography.bodyMedium.copy(color = LatamRed, fontWeight = FontWeight.Bold))

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FlightStatusEnum.entries.forEach { status ->
                            Button(
                                onClick = { simEngine.forceFlightStatus(status) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = LatamNavyLight)
                            ) {
                                Text("Forzar: ${status.displayName}")
                            }
                        }
                    }
                }
            }

            // Gate Change
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "SIMULAR CAMBIO DE PUERTA", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newGateInput,
                            onValueChange = { newGateInput = it },
                            label = { Text("Nueva Puerta") },
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { simEngine.forceGateChange(newGateInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = LatamRed)
                        ) {
                            Text("CAMBIAR")
                        }
                    }
                }
            }

            // Reset Data Button
            Button(
                onClick = { viewModel.resetAllData() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = LatamRedDark)
            ) {
                Text("REINICIAR TODA LA BASE DE DATOS Y ESTADO")
            }

            // Dev Logs List
            Text(
                text = "REGISTRO DE EVENTOS (ULTIMOS 100)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
            )

            devLogs.forEach { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = LatamSurfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(text = log.eventType, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = LatamRed))
                        Text(text = log.details, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
