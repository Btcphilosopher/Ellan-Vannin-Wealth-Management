package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.core.model.*

@Database(
    entities = [
        Booking::class,
        BoardingPass::class,
        NotificationItem::class,
        LatamPassAccount::class,
        DevLogEvent::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun bookingDao(): BookingDao
    abstract fun boardingPassDao(): BoardingPassDao
    abstract fun notificationDao(): NotificationDao
    abstract fun latamPassDao(): LatamPassDao
    abstract fun devLogDao(): DevLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "latam_travel_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
