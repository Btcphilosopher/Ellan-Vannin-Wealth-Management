package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.*
import com.example.core.simulation.SimulationEngine
import com.example.data.local.AppDatabase
import com.example.data.providers.DemoBookingProvider
import com.example.data.providers.DemoPaymentProvider
import com.example.data.repository.LatamRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class MainNavTab(val title: String, val iconName: String) {
    INICIO("INICIO", "home"),
    MIS_VIAJES("MIS VIAJES", "flight_takeoff"),
    BUSCAR("BUSCAR", "search"),
    LATAM_PASS("LATAM PASS", "star"),
    MAS("MÁS", "menu")
}

enum class SearchMode(val displayName: String) {
    IDA_Y_VUELTA("IDA Y VUELTA"),
    SOLO_IDA("SOLO IDA"),
    MULTIDESTINO("MULTIDESTINO")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = LatamRepository(
        bookingDao = db.bookingDao(),
        boardingPassDao = db.boardingPassDao(),
        notificationDao = db.notificationDao(),
        latamPassDao = db.latamPassDao(),
        devLogDao = db.devLogDao()
    )

    val simulationEngine = SimulationEngine(
        devLogDao = db.devLogDao(),
        notificationDao = db.notificationDao()
    )

    val bookings: StateFlow<List<Booking>> = repository.allBookings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val boardingPasses: StateFlow<List<BoardingPass>> = repository.allBoardingPasses.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notifications: StateFlow<List<NotificationItem>> = repository.allNotifications.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val latamPassAccount: StateFlow<LatamPassAccount?> = repository.latamPassAccount.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val devLogs: StateFlow<List<DevLogEvent>> = repository.devLogs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // UI Navigation State
    private val _selectedTab = MutableStateFlow(MainNavTab.INICIO)
    val selectedTab: StateFlow<MainNavTab> = _selectedTab.asStateFlow()

    private val _activeSubScreen = MutableStateFlow<String?>(null)
    val activeSubScreen: StateFlow<String?> = _activeSubScreen.asStateFlow()

    // User authentication state
    val userName = MutableStateFlow("TOMÁS")

    // Flight Search State
    val searchMode = MutableStateFlow(SearchMode.IDA_Y_VUELTA)
    val originCode = MutableStateFlow("SCL")
    val destinationCode = MutableStateFlow("LIM")
    val departureDateStr = MutableStateFlow("Mañana")
    val returnDateStr = MutableStateFlow("Próxima semana")
    val passengerCount = MutableStateFlow(1)
    val selectedCabinClass = MutableStateFlow(CabinClass.ECONOMY)

    // Booking Flow State
    val selectedFlightForBooking = MutableStateFlow<Flight?>(null)
    val bookingStep = MutableStateFlow(1) // 1..8
    val bookingPassenger = MutableStateFlow(
        Passenger(
            id = "PASS-1",
            firstName = "Tomás",
            lastName = "Valenzuela",
            documentType = "RUT Ficticio",
            documentNumber = "18.492.012-K",
            nationality = "Chile"
        )
    )
    val selectedSeatNumber = MutableStateFlow("14A")
    val selectedBaggageCount = MutableStateFlow(1)
    val isBookingInProcess = MutableStateFlow(false)
    val createdBookingResult = MutableStateFlow<Booking?>(null)

    // Active Checkin Session
    val activeCheckInBooking = MutableStateFlow<Booking?>(null)

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
        }
    }

    fun selectTab(tab: MainNavTab) {
        _selectedTab.value = tab
        _activeSubScreen.value = null
    }

    fun navigateToSubScreen(subScreenRoute: String) {
        _activeSubScreen.value = subScreenRoute
    }

    fun backToTabRoot() {
        _activeSubScreen.value = null
    }

    fun startBookingFlow(flight: Flight) {
        selectedFlightForBooking.value = flight
        bookingStep.value = 1
        _activeSubScreen.value = "booking_flow"
    }

    fun processDemoBooking() {
        val flight = selectedFlightForBooking.value ?: return
        val passenger = bookingPassenger.value
        val cabin = selectedCabinClass.value
        val farePrice = flight.fares[cabin]?.priceClp ?: 189990

        viewModelScope.launch {
            isBookingInProcess.value = true
            val demoBooking = DemoBookingProvider.createDemoBooking(
                flight = flight,
                passenger = passenger,
                cabinClass = cabin,
                farePrice = farePrice,
                selectedSeat = selectedSeatNumber.value,
                checkedBaggageCount = selectedBaggageCount.value
            )
            val paymentSuccess = DemoPaymentProvider.processDemoPayment(
                pnrCode = demoBooking.pnrCode,
                amountClp = farePrice
            )
            if (paymentSuccess) {
                val confirmed = demoBooking.copy(status = BookingStatus.CONFIRMADA.name)
                repository.saveBooking(confirmed)
                createdBookingResult.value = confirmed
                bookingStep.value = 8 // Confirmation stage
            }
            isBookingInProcess.value = false
        }
    }

    fun performCheckIn(booking: Booking) {
        viewModelScope.launch {
            repository.createAndSaveBoardingPass(booking)
        }
    }

    fun redeemMiles(miles: Int, rewardTitle: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = repository.redeemMiles(miles, rewardTitle)
            onResult(success)
        }
    }

    fun resetAllData() {
        viewModelScope.launch {
            repository.resetAllData()
        }
    }
}
