package com.example.features.seats

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EventSeat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.currency.CurrencyUtils
import com.example.core.model.CabinClass
import com.example.core.model.Seat
import com.example.core.model.SeatAvailability
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun SeatMapScreen(
    viewModel: MainViewModel,
    onSeatSaved: () -> Unit
) {
    val selectedSeatCode by viewModel.selectedSeatNumber.collectAsState()
    var currentSelection by remember { mutableStateOf(selectedSeatCode) }

    val mockSeats = remember {
        listOf(
            Seat("12A", 12, 'A', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE, true, 12000, "Espacio extra para piernas"),
            Seat("12B", 12, 'B', CabinClass.ECONOMY, SeatAvailability.OCUPADO),
            Seat("12C", 12, 'C', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),
            Seat("12D", 12, 'D', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),
            Seat("12E", 12, 'E', CabinClass.ECONOMY, SeatAvailability.OCUPADO),
            Seat("12F", 12, 'F', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE, true, 12000),

            Seat("14A", 14, 'A', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),
            Seat("14B", 14, 'B', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),
            Seat("14C", 14, 'C', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),
            Seat("14D", 14, 'D', CabinClass.ECONOMY, SeatAvailability.OCUPADO),
            Seat("14E", 14, 'E', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),
            Seat("14F", 14, 'F', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),

            Seat("15A", 15, 'A', CabinClass.ECONOMY, SeatAvailability.OCUPADO),
            Seat("15B", 15, 'B', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),
            Seat("15C", 15, 'C', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),
            Seat("15D", 15, 'D', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),
            Seat("15E", 15, 'E', CabinClass.ECONOMY, SeatAvailability.DISPONIBLE),
            Seat("15F", 15, 'F', CabinClass.ECONOMY, SeatAvailability.OCUPADO)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
            .testTag("seat_map_screen")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "MAPA DE CABINA INTERACTIVO",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamRed,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "SELECCIÓN DE ASIENTO",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                Text(
                    text = "Asiento seleccionado: $currentSelection",
                    style = MaterialTheme.typography.bodyMedium.copy(color = LatamGold, fontWeight = FontWeight.Bold)
                )
            }
        }

        // Legend Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            LegendBadge(color = LatamNavy, label = "Disponible")
            LegendBadge(color = LatamRed, label = "Seleccionado")
            LegendBadge(color = LatamBorder, label = "Ocupado")
            LegendBadge(color = LatamGold, label = "Espacio Extra")
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val rows = mockSeats.groupBy { it.row }
            items(rows.keys.toList()) { rowNum ->
                val rowSeats = rows[rowNum] ?: emptyList()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Fila $rowNum", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))

                    rowSeats.take(3).forEach { seat ->
                        SeatBox(seat, isSelected = seat.code == currentSelection) {
                            if (seat.status != SeatAvailability.OCUPADO) {
                                currentSelection = seat.code
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp)) // Aisle

                    rowSeats.drop(3).forEach { seat ->
                        SeatBox(seat, isSelected = seat.code == currentSelection) {
                            if (seat.status != SeatAvailability.OCUPADO) {
                                currentSelection = seat.code
                            }
                        }
                    }
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shadowElevation = 8.dp,
            color = MaterialTheme.colorScheme.surface
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "ASIENTO ELEGIDO", style = MaterialTheme.typography.labelSmall)
                    Text(text = currentSelection, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamRed))
                }

                Button(
                    onClick = {
                        viewModel.selectedSeatNumber.value = currentSelection
                        onSeatSaved()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LatamNavy),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("save_seat_selection_btn")
                ) {
                    Text("GUARDAR SELECCIÓN")
                }
            }
        }
    }
}

@Composable
fun LegendBadge(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(color, RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun SeatBox(seat: Seat, isSelected: Boolean, onClick: () -> Unit) {
    val bgColor = when {
        isSelected -> LatamRed
        seat.status == SeatAvailability.OCUPADO -> LatamBorder
        seat.extraLegroom -> LatamGold
        else -> LatamNavy
    }

    Box(
        modifier = Modifier
            .size(40.dp)
            .background(bgColor, RoundedCornerShape(6.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "${seat.column}",
                style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
            )
        }
    }
}
