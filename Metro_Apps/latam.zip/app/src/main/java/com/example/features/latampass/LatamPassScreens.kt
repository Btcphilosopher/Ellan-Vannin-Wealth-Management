package com.example.features.latampass

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun LatamPassScreen(
    viewModel: MainViewModel,
    onRedeemMilesClicked: () -> Unit
) {
    val account by viewModel.latamPassAccount.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 80.dp)
            .verticalScroll(rememberScrollState())
            .testTag("latam_pass_screen")
    ) {
        // Gold Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(LatamNavy)
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PROGRAMA DE FIDELIZACIÓN",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = LatamGold,
                            letterSpacing = 1.sp
                        )
                    )
                    Surface(
                        color = LatamGold,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = account?.category ?: "GOLD",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall.copy(color = LatamNavy, fontWeight = FontWeight.Bold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = account?.memberName ?: "Tomás Valenzuela",
                    style = MaterialTheme.typography.titleMedium.copy(color = Color.White.copy(alpha = 0.8f))
                )

                Text(
                    text = "${account?.availableMiles ?: 42850} MILLAS",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = LatamGold,
                        fontSize = 34.sp
                    )
                )

                Text(
                    text = "Próximas a vencer: ${account?.expiringMiles ?: 3200} millas (31 dic 2026)",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.7f))
                )
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            // Category Status Progress Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "PROGRESO DE CATEGORÍA 2026", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Puntos Calificables acumulados: ${account?.qualifyingPoints ?: 18400} / 25.000", style = MaterialTheme.typography.bodyMedium)

                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { (account?.qualifyingPoints ?: 18400) / 25000f },
                        modifier = Modifier.fillMaxWidth(),
                        color = LatamGold,
                        trackColor = LatamSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Te faltan 6.600 Puntos Calificables para alcanzar la categoría PLATINUM.", style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onRedeemMilesClicked,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("redeem_miles_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = LatamRed),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("CANJEAR MILLAS (CATÁLOGO DEMO)", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "HISTORIAL DE MOVIMIENTOS SIMULADOS",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = LatamNavy)
            )

            Spacer(modifier = Modifier.height(12.dp))

            listOf(
                Triple("Vuelo SCL - ANF (LA 140)", "+ 1.200 Millas", "15 Ago 2026"),
                Triple("Bono Tarjeta Crédito LATAM Pass", "+ 5.000 Millas", "01 Ago 2026"),
                Triple("Vuelo SCL - PUQ (LA 095)", "+ 2.100 Millas", "10 Jul 2026")
            ).forEach { (desc, miles, date) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = desc, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text(text = date, style = MaterialTheme.typography.bodySmall.copy(color = LatamTextSecondary))
                        }
                        Text(text = miles, style = MaterialTheme.typography.bodyMedium.copy(color = StatusGreen, fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
    }
}

@Composable
fun RedeemMilesScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    var redeemMessage by remember { mutableStateOf<String?>(null) }

    val catalog = listOf(
        Pair("Vuelo Nacional Santiago → Iquique", 12000),
        Pair("Upgrade a Premium Economy", 8500),
        Pair("Acceso a Salón VIP SCL", 4500),
        Pair("Equipaje Adicional 23kg", 3000)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(text = "CATÁLOGO DE CANJE DEMO", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = LatamNavy))
        Spacer(modifier = Modifier.height(16.dp))

        redeemMessage?.let { msg ->
            Surface(
                color = LatamNavy,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Text(text = msg, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium.copy(color = Color.White))
            }
        }

        catalog.forEach { (item, miles) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = item, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        Text(text = "$miles Millas", style = MaterialTheme.typography.bodySmall.copy(color = LatamGold, fontWeight = FontWeight.Bold))
                    }

                    Button(
                        onClick = {
                            viewModel.redeemMiles(miles, item) { success ->
                                redeemMessage = if (success) "¡Canje exitoso por '$item'!" else "Saldo de millas insuficiente."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LatamNavy)
                    ) {
                        Text("CANJEAR")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedButton(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("VOLVER A LATAM PASS")
        }
    }
}
